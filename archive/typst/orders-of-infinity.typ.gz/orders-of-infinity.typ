// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/
// Converted to Typst by tao2typ: "2026-10-14T11:13:56.670742+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Orders of infinity", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Orders of infinity")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 May 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/")[#text("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Many problems in analysis (as well as adjacent fields such as combinatorics, theoretical computer science, and PDE) are interested in the order of growth (or decay) of some quantity ")#mi("{X}")#text(" that depends on one or more asymptotic parameters (such as ")#mi("{N}")#text(") – for instance, whether the quantity ")#mi("{X}")#text(" grows or decays linearly, quadratically, polynomially, exponentially, etc. in ")#mi("{N}")#text(". In the case where these quantities grow to infinity, these growth rates had once been termed “orders of infinity” – for instance, in ")#link("https://archive.org/details/G_H_HARDY___ORDERS_OF_INFINITY/page/n9/mode/2up")[#text("the 1910 book of this name by Hardy")]#text(" – although this term has fallen out of use in recent years. (")#link("https://en.wikipedia.org/wiki/Hardy_field")[#text("Hardy fields")]#text(" are still a thing, though.)")

#text("In modern analysis, ")#link("https://en.wikipedia.org/wiki/Big_O_notation")[#text("asymptotic notation")]#text(" is the preferred device to organize orders of infinity. There are a couple of flavors of this notation, but here is one such (a blend of Hardy’s notation and Landau’s notation). Formally, we need a parameter space ")#mi("{\\Omega}")#text(" equipped with a non-principal ")#link("https://en.wikipedia.org/wiki/Filter_(mathematics)")[#text("filter")]#text(" ")#mi("{{\\mathcal F}}")#text(" that describes the subsets of parameter space that are “sufficiently large” (e.g., the ")#link("https://en.wikipedia.org/wiki/Fr%C3%A9chet_filter")[#text("cofinite (Fréchet) filter")]#text(" on ")#mi("{{\\bf N}}")#text(", or the cocompact filter on ")#mi("{{\\bf R}}")#text("). We will use ")#mi("{N}")#text(" to denote elements of this filter; thus, an assertion holds for sufficiently large ")#mi("{N}")#text(" if and only if it holds for all ")#mi("{N}")#text(" in some element ")#mi("{U}")#text(" of the filter ")#mi("{{\\mathcal F}}")#text(". Given two positive quantities ")#mi("{X = X(N), Y = Y(N)}")#text(" that are defined for sufficiently large ")#mi("{N \\in \\Omega}")#text(", one can then define the following notions:")

#list(
[#text("(i) We write ")#mi("{X = O(Y)}")#text(", ")#mi("{X \\lesssim Y}")#text(", or ")#mi("{Y \\gtrsim X}")#text(" (and sometimes ")#mi("{Y = \\Omega(X)}")#text(") if there exists a constant ")#mi("{C>0}")#text(" such that ")#mi("{X(N) \\leq CY(N)}")#text(" for all sufficiently large ")#mi("{N}")#text(".")],
[#text("(ii) We write ")#mi("{X = o(Y)}")#text(", ")#mi("{X \\ll Y}")#text(", or ")#mi("{Y \\gg X}")#text(" (and sometimes ")#mi("{Y = \\omega(X)}")#text(") if, for every ")#mi("{\\varepsilon>0}")#text(", one has ")#mi("{X(N) \\leq \\varepsilon Y(N)}")#text(" for all sufficiently large ")#mi("{N}")#text(".")],
[#text("(iii) We write ")#mi("{X \\asymp Y}")#text(" (and sometimes ")#mi("{X \\sim Y}")#text(" or ")#mi("{Y = \\Theta(X)}")#text(") if ")#mi("{X \\lesssim Y \\lesssim X}")#text(", or equivalently if there exist constants ")#mi("{C, c > 0}")#text(" such that ")#mi("{c Y(N) \\leq X(N) \\leq C Y(N)}")#text(" for all sufficiently large ")#mi("{N}")#text(".")]
)

#text("We caution that in analytic number theory and adjacent fields, the slightly different notation of Vinogradov is favored, in which ")#mi("{X \\ll Y}")#text(" would denote the concept (i) instead of (ii), and ")#mi("{X \\sim Y}")#text(" would denote a fourth concept ")#mi("{X = (1+o(1)) Y}")#text(" instead of (iii). However, we will use the Hardy-Landau notation exclusively in this blog post.")

#text("Anyone who works with asymptotic notation for a while will quickly recognize that it enjoys various algebraic properties akin to the familiar algebraic properties of order ")#mi("{<}")#text(" on the real line. For instance, the symbols ")#mi("{\\lesssim, \\ll, \\gg, \\gtrsim}")#text(" behave very much like ")#mi("{\\leq}")#text(", ")#mi("{<}")#text(", ")#mi("{>}")#text(", ")#mi("{\\gtrsim}")#text(", with properties such as the following:")

#list(
[#text("If ")#mi("{X \\lesssim Y}")#text(" and ")#mi("{Y \\lesssim Z}")#text(", then ")#mi("{X \\lesssim Z}")#text(".")],
[#mi("{X \\lesssim Y}")#text(" if and only if ")#mi("{XZ \\lesssim YZ}")#text(".")],
[#text("If ")#mi("{N}")#text(" is restricted to a sequence, then (after passing to a subsequence if necessary), exactly one of ")#mi("{X \\ll Y}")#text(", ")#mi("{X \\asymp Y}")#text(", and ")#mi("{X \\gg Y}")#text(" is true.")]
)

#text("One also has the “tropical” property ")#mi("{X+Y \\asymp \\max(X,Y)}")#text(", making asymptotic notation a kind of “")#link("https://en.wikipedia.org/wiki/Tropical_geometry")[#text("tropical algebra")]#text("“.")

#text("However, in contrast with other standard algebraic structures (such as ")#link("https://en.wikipedia.org/wiki/Ordered_field")[#text("ordered fields")]#text(") that blend order and arithmetic operations, the precise laws of orders of infinity are usually not written down as a short list of axioms. Part of this is due to cultural differences between analysis and algebra – as discussed in ")#link("https://www.dpmms.cam.ac.uk/~wtg10/2cultures.pdf")[#text("this essay by Gowers")]#text(", analysis is often not well suited to the axiomatic approach to mathematics that algebra benefits so much from. But another reason is due to our orthodox implementation of analysis via “epsilon-delta” type concepts, such as the notion of “sufficiently large” used above, which notoriously introduces a large number of both universal and existential quantifiers into the subject (for every epsilon, there exists a delta…) which tends to interfere with the smooth application of algebraic laws (which are optimized for the universal quantifier rather than the existential quantifier).")

#text("But there is an alternate approach to analysis, namely ")#link("https://en.wikipedia.org/wiki/Nonstandard_analysis")[#text("nonstandard analysis")]#text(", which rearranges the foundations so that many of quantifiers (particularly the existential ones) are concealed from view (usually via the device of ultrafilters). This makes the subject of analysis considerably more “algebraic” in nature, as the “epsilon management” that is so prevalent in orthodox analysis is now performed much more invisibly. For instance, as we shall see, in the nonstandard framework, orders of infinity acquire the algebraic structure of a totally ordered vector space that also enjoys a completeness property reminiscent, though not identical to, the completeness of the real numbers. There is also a ")#link("https://en.wikipedia.org/wiki/Hyperreal_number#The_transfer_principle")[#text("transfer principle")]#text(" that allows one to convert assertions in orthodox asymptotic notation into logically equivalent assertions about nonstandard orders of infinity, allowing one to then prove asymptotic statements in a purely algebraic fashion. There is a price to pay for this “algebrization” of analysis; the spaces one works with become quite large (in particular, they tend to be “inseparable” and not “countably generated” in any reasonable fashion), and it becomes difficult to extract explicit constants ")#mi("{C}")#text(" (or explicit decay rates) from the asymptotic notation. However, there are some cases in which the tradeoff is worthwhile. For instance, symbolic computations tend to be easier to perform in algebraic settings than in orthodox analytic settings, so formal computations of orders of infinity (such as the ones discussed in the ")#link("https://terrytao.wordpress.com/2025/05/01/a-proof-of-concept-tool-to-verify-estimates/")[#text("previous blog post")]#text(") could benefit from the nonstandard approach. (See also ")#link("https://terrytao.wordpress.com/tag/nonstandard-analysis/")[#text("my previous posts")]#text(" on nonstandard analysis for more discussion about these tradeoffs.)")

#text("Let us now describe the nonstandard approach to asymptotic notation. With the above formalism, the switch from standard to nonstandard analysis is actually quite simple: one assumes that the asymptotic filter ")#mi("{{\\mathcal F}}")#text(" is in fact an ")#link("https://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(". In terms of the concept of “sufficiently large”, this means adding the following useful axiom:")

#list(
[#text("Given any predicate ")#mi("{P(N)}")#text(", exactly one of the two statements “")#mi("{P(N)}")#text(" holds for sufficiently large ")#mi("{N}")#text("” and “")#mi("{P(N)}")#text(" does not hold for sufficiently large ")#mi("{N}")#text("” is true.")]
)

#text("This can be compared with the situation with, say, the Fréchet filter on the natural numbers ")#mi("{{\\bf N}}")#text(", in which one has to insert some qualifier such as “after passing to a subsequence if necessary” in order to make the above axiom true.")

#text("The existence of an ultrafilter requires some weak version of the axiom of choice (specifically, the ")#link("https://en.wikipedia.org/wiki/Ultrafilter_on_a_set#The_ultrafilter_lemma")[#text("ultrafilter lemma")]#text("), but for this post we shall just take the existence of ultrafilters for granted.")

#text("We can now define the nonstandard orders of infinity ")#mi("{{\\mathcal O}}")#text(" to be the space of all non-negative functions ")#mi("{X(N)}")#text(" defined for sufficiently large ")#mi("{N \\in \\Omega}")#text(", modulo the equivalence relation ")#mi("{\\asymp}")#text(" defined previously. That is to say, a nonstandard order of infinity is an equivalence class")

#align(center)[#tao-fit-display[#mitex("\\Theta(X) := \\{ Y : U \\rightarrow {\\bf R}^+: X \\asymp Y \\}")]]

#text("of functions ")#mi("{Y: U \\rightarrow {\\bf R}^+}")#text(" defined on elements ")#mi("{U}")#text(" of the ultrafliter. For instance, if ")#mi("{\\Omega}")#text(" is the natural numbers, then ")#mi("{\\Theta(N)}")#text(" itself is an order of infinity, as is ")#mi("{\\Theta(N^2)}")#text(", ")#mi("{\\Theta(e^N)}")#text(", ")#mi("{\\Theta(1/N)}")#text(", ")#mi("{\\Theta(N \\log N)}")#text(", and so forth. But we exclude ")#mi("{0}")#text("; it will be important for us that the order of infinity is strictly positive for all sufficiently large ")#mi("{N}")#text(".")

#text("We can place various familiar algebraic operations on ")#mi("{{\\mathcal O}}")#text(":")

#list(
[#emph[#text("Addition")]#text(". We define ")#mi("{\\Theta(X)+\\Theta(Y) :=\\Theta(X+Y)}")#text(". It is easy to see that this is well-defined, by verifying that if ")#mi("{X \\asymp X^{\\prime}}")#text(" and ")#mi("{Y \\asymp Y^{\\prime}}")#text(", then ")#mi("{X+Y \\asymp X^{\\prime}+Y^{\\prime}}")#text(". However, because of our positivity requirement, we do not define subtraction on ")#mi("{{\\mathcal O}}")#text(".")],
[#emph[#text("Multiplication and division")]#text(" We define ")#mi("{\\Theta(X) \\times \\Theta(Y) := \\Theta(XY)}")#text(" and ")#mi("{\\Theta(X)/\\Theta(Y) = \\Theta(X/Y)}")#text("; we do not need to worry about division by zero, thanks to the positivity requirement. Again it is easy to verify this is well-defined.")],
[#emph[#text("Scalar exponentiation")]#text(" If ")#mi("{\\lambda}")#text(" is a real number, we define ")#mi("{\\Theta(X)^\\lambda := \\Theta(X^\\lambda)}")#text(". Again, this is easily checked to be well-defined.")],
[#emph[#text("Order")]#text(" We define ")#mi("{\\Theta(X) \\leq \\Theta(Y)}")#text(" if ")#mi("{X \\lesssim Y}")#text(", and ")#mi("{\\Theta(X) < \\Theta(Y)}")#text(" if ")#mi("{X \\ll Y}")#text(". Again, this is easily checked to be well-defined. (And the ultrafilter axiom ensures that ")#mi("{\\Theta(X) \\leq \\Theta(Y)}")#text(" holds iff exactly one of ")#mi("{\\Theta(X)=\\Theta(Y)}")#text(" and ")#mi("{\\Theta(X) < \\Theta(Y)}")#text(" holds.)")]
)

#text("With these operations, combined with the ultrafilter axiom, we see that ")#mi("{{\\mathcal O}}")#text(" obeys the laws of many standard algebraic structures, the proofs of which we leave as exercises for the reader:")

#list(
[#mi("{({\\mathcal O}, \\leq)}")#text(" is a totally ordered set.")],
[#text("In fact, ")#mi("{({\\mathcal O}, \\leq, \\Theta(1), \\times, (\\cdot)^{\\cdot})}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Ordered_vector_space")[#text("totally ordered vector space")]#text(", with ")#mi("{\\Theta(1)}")#text(" playing the role of the zero vector, multiplication ")#mi("{(\\Theta(X), \\Theta(Y)) \\mapsto \\Theta(X) \\times \\Theta(Y)}")#text(" playing the role of vector addition, and scalar exponentiation ")#mi("{(\\lambda, \\Theta(X)) \\mapsto \\Theta(X)^\\lambda}")#text(" playing the role of scalar multiplication. (Of course, division would then play the role of vector subtraction.) To avoid confusion, one might refer to ")#mi("{{\\mathcal O}}")#text(" as a ")#emph[#text("log-vector space")]#text(" rather than a vector space to emphasize the fact that the vector structure is coming from multiplication (and exponentiation) rather than addition (and multiplication). Ordered log-vector spaces may seem like a strange and exotic concept, but they are actually already studied implicitly in analysis, albeit under the guise of other names such as ")#link("https://en.wikipedia.org/wiki/Logarithmically_convex_function")[#text("log-convexity")]#text(".")],
[#mi("{({\\mathcal O}, +, \\times, 1)}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Semiring")[#text("semiring")]#text(" (albeit one without an additive identity element), which is idempotent: ")#mi("{\\Theta(X) + \\Theta(X) = \\Theta(X)}")#text(" for all ")#mi("{\\Theta(X) \\in {\\mathcal O}}")#text(".")],
[#text("More generally, addition can be described in purely order-theoretic terms: ")#mi("{\\Theta(X) + \\Theta(Y) = \\max(\\Theta(X), \\Theta(Y))}")#text(" for all ")#mi("{\\Theta(X), \\Theta(Y) \\in {\\mathcal O}}")#text(". (It would therefore be natural to call ")#mi("{{\\mathcal O}}")#text(" a ")#link("https://en.wikipedia.org/wiki/Tropical_semiring")[#text("tropical semiring")]#text(", although the precise axiomatization of this term does not appear to be fully standardized currently.)")]
)

#text("The ordered (log-)vector space structure of ")#mi("{{\\mathcal O}}")#text(" in particular opens up the ability to prove asymptotic implications by (log-)linear programming; this was implicitly used in ")#link("https://terrytao.wordpress.com/2025/05/01/a-proof-of-concept-tool-to-verify-estimates/")[#text("my previous post")]#text(". One can also use the language of (log-)linear algebra to describe further properties of various orders of infinity. For instance, if ")#mi("{\\Omega}")#text(" is the natural numbers, we can form the subspace")

#align(center)[#tao-fit-display[#mitex("N^{O(1)} := \\bigcup_{k \\geq 0} [\\Theta(N)^{-k}, \\Theta(N)^k]")]]

#text("of ")#mi("{{\\mathcal O}}")#text(" consisting of those orders of infinity ")#mi("{\\Theta(X)}")#text(" which are of polynomial type in the sense that ")#mi("{N^{-C} \\lesssim X \\lesssim N^C}")#text(" for some ")#mi("{C>0}")#text("; this is then a (log)-vector subspace of ")#mi("{{\\mathcal O}}")#text(", and has a canonical (log-)linear surjection ")#mi("{\\mathrm{ord}: N^{O(1)} \\rightarrow {\\bf R}}")#text(" that assigns to each order of infinity ")#mi("{\\Theta(X)}")#text(" of polynomial type the unique real number ")#mi("{\\alpha}")#text(" such that ")#mi("{X(N) = N^{\\alpha+o(1)}}")#text(", that is to say for all ")#mi("{\\varepsilon>0}")#text(" one has ")#mi("{N^{\\alpha-\\varepsilon} \\lesssim X(N) \\lesssim N^{\\alpha+\\varepsilon}}")#text(" for all sufficiently large ")#mi("{N}")#text(". (The existence of such an ")#mi("{\\alpha}")#text(" follows from the ultrafilter axiom and by a variant of the proof of the Bolzano–Weierstrass theorem; the uniqueness is also easy to establish.) The kernel ")#mi("{N^{o(1)}}")#text(" of this surjection is then the log-subspace of quasilogarithmic orders of infinity – ")#mi("{\\Theta(X)}")#text(" for which ")#mi("{N^{-\\varepsilon} \\lesssim X \\lesssim N^\\varepsilon}")#text(" for all ")#mi("{\\varepsilon>0}")#text(".")

#text("In addition to the above algebraic properties, the nonstandard orders of infinity ")#mi("{{\\mathcal O}}")#text(" also enjoy a completeness property that is reminiscent of the completeness of the real numbers. In the reals, it is true that any nested sequence ")#mi("{K_1 \\supset K_2 \\supset \\dots}")#text(" of non-empty closed intervals has a non-empty intersection, which is a property closely tied to the more familiar definition of completeness as the assertion that Cauchy sequences are always convergent. This claim of course fails for open intervals: for instance, ")#mi("{(0,1/n)}")#text(" for ")#mi("{n=1,2,\\dots}")#text(" is a nested sequence of non-empty open intervals whose intersection is empty. However, in the nonstandard orders of infinity ")#mi("{{\\mathcal O}}")#text(", we have the same property for both open and closed intervals!")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Completeness for arbitrary intervals)")]#text(" Let ")#mi("{I_1 \\supset I_2 \\supset \\dots}")#text(" be a nested sequence of non-empty intervals in ")#mi("{{\\mathcal O}}")#text(" (which can be open, closed, or half-open). Then the intersection ")#mi("{\\bigcap_{n=1}^\\infty I_n}")#text(" is non-empty.")
]

#emph[#text("Proof:")]#text(" For sake of notation we shall assume the intervals are open intervals ")#mi("{I_n = (\\Theta(X_n), \\Theta(Y_n))}")#text(", although much the same argument would also work for closed or half-open intervals (and then by the pigeonhole principle one can then handle nested sequences of arbitrary intervals); we leave this extension to the interested reader.")

#text("Pick an element ")#mi("{\\Theta(Z_n)}")#text(" of each ")#mi("{I_n}")#text(", then we have ")#mi("{X_m \\ll Z_n \\ll Y_m}")#text(" whenever ")#mi("{m \\leq n}")#text(". In particular, one can find a set ")#mi("{U_n}")#text(" in the ultrafilter such that")

#align(center)[#tao-fit-display[#mitex("n X_m(N) \\leq Z_n(N) \\leq \\frac{1}{n} Y_m(N)")]]

#text("whenever ")#mi("{N \\in U_n}")#text(" and ")#mi("{m \\leq n}")#text(", and by taking suitable intersections that these sets are nested: ")#mi("{U_1 \\supset U_2 \\supset \\dots}")#text(". If we now define ")#mi("{Z(N)}")#text(" to equal ")#mi("{Z_n(N)}")#text(" for ")#mi("{N \\in U_n \\backslash U_{n+1}}")#text(" (and leave ")#mi("{Z}")#text(" undefined outside of ")#mi("{U_1}")#text("), one can check that ")#mi("{X_m \\ll Z \\ll Y_m}")#text(" for all ")#mi("{m}")#text(", thus ")#mi("{\\Theta(Z)}")#text(" lies in the intersection of all the ")#mi("{I_n}")#text(", giving the claim. ")#mi("\\Box")

#text("This property is closely related to the ")#link("https://en.wikipedia.org/wiki/Saturated_model")[#text("countable saturation")]#text(" and ")#link("https://en.wikipedia.org/wiki/Overspill")[#text("overspill")]#text(" properties in nonstandard analysis. From this property one might expect that ")#mi("{{\\mathcal O}}")#text(" has better topological structure than say the reals. This is not exactly true, because unfortunately ")#mi("{{\\mathcal O}}")#text(" is not metrizable (or separable, or first or second countable). It is perhaps better to view ")#mi("{{\\mathcal O}}")#text(" as obeying a parallel type of completeness that is neither strictly stronger nor strictly weaker than the more familiar notion of metric completeness, but is otherwise rather analogous.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b423fadc513ac0411dd0514ea026a2d16a4135f02398c6cf3e216875f731e7-f10415d608fb7f54446cf1edbfc12d995d6764cec76d613dd19362a166d378a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin Bian")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687915")[#strong[#text("Justin Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2025")])]

#text("Nothing too much, just to say thank you for your interesting posts and productive works ♥️🍀")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/930345820541562c408299dddb02ca33171702ddc827bf6fd8a8dcb2f450e73f-8f42ed8057ccfe5eca3708b5f5d246a7bd50509989305bf7714243c1d045eded.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hideoutleftca8790a9b5")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687916")[#strong[#text("hideoutleftca8790a9b5")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2025")])]

#text("Dear Professor Tao,")

#text("Your exposition on orders of infinity and their algebraic structure in nonstandard analysis is illuminating, particularly the completeness property of \\mathcal{O} and its log-vector space structure.")

#text("I wonder if the tropical semiring perspective could be further leveraged to connect with optimization problems, such as those in combinatorial geometry or network theory, where tropical algebra often simplifies asymptotic bounds.")

#text("For instance, could the idempotent addition \\Theta(X) + \\Theta(Y) = \\max(\\Theta(X), \\Theta(Y)) inform algorithms for scaling limits in graph problems?")

#text("Additionally, the non-metrizability of \\mathcal{O} seems to limit explicit constant extraction, but might there be a way to define a “coarse” metric or topology on a quotient of \\mathcal{O} (e.g., by grouping orders within bounded logarithmic ratios) to regain some computational tractability?")

#text("This could bridge the algebraic elegance of nonstandard analysis with practical applications in symbolic computation, as you hinted.")

#text("Finally, your mention of symbolic computations suggests potential for automated theorem proving or computer algebra systems. Have you considered formalizing parts of \\mathcal{O}’s structure in a system like Lean or Coq to test conjectures about asymptotic relations?")

#text("Such tools might uncover new algebraic identities or streamline the verification of your exercises.")

#text("Thank you for this thought-provoking post! I look forward to seeing how these ideas evolve. Best regards,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687917")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2025")])]

#text("In fact, I have thought about doing exactly this, and started a bare-bones repository at ")#link("https://github.com/teorth/estimate_tools")[#text("https://github.com/teorth/estimate_tools")]#text(" to set this up. Right now it contains almost no content – just a proof of concept of a single Lean derivation done in the setting of totally ordered vector fields (which are already set up in Lean’s Mathlib) – but if there is interest, I could expand this into a collaborative formalization project.")

#text("It is indeed true that while the full space ")#mi("{\\mathcal O}")#text(" is non-metrizable, there are many useful metrizable subquotients of this log-vector space, for instance the canonical linear surjection from ")#mi("N^{O(1)}")#text(" to ")#mi("{\\mathbb R}")#text(" discussed in the blog post gives one such example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687951")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2025")])]

#text("Might it be useful to use an approach like Nelson’s internal set theory instead of Robinson’s non-standard analysis for such tools? You could add in the predicate “standard” to the tool and then avoid ultrafilters and the corresponding choice, and stay close to the axioms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687954")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2025")])]

#text("Internal Set Theory will give you the transfer principle, but with its emphasis on syntax rather than semantics, one has to work harder in IST to get the countably saturated models that which the ultrafilter approach yields naturally. This in turn allows one to apply other infinitary tools (such as measure theory, ergodic theory, or topological group theory) to the resulting nonstandard spaces, which has been useful in many contexts (e.g., many finitary combinatorial problems can be converted into ergodic theory problems using the Loeb measure construction in ultrafilter-based nonstandard analysis).")

#text("Besides, analysts are already quite comfortable with filters (although often described under other names such as “limits”, “sufficiently large/small/close”, or “neighbourhood bases”). I don’t view the step from filters to ultrafilters being that huge of a conceptual difference when passing from standard analysis to nonstandard analysis.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687961")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2025")])]

#text("I think this seems like the right approach if one designs a tool which should work with close feedback from the practitioner. On the other hand if we like to design a tool which should solve the problem automatically. Maybe such a tool should pursue solution in all theories (Robinson, IST, standard analysis) with exchange of information between them at some points. Due to the halting problem and other reason such as available proofs each could contribute solutions no other could find in reasonable time. Maybe standard analysis proofs are easier for LLMs to achieve, and the other are better for certain brute force searches…. Maybe such an approach is too complicated now, but maybe in some years it will be easy to generate a tool for all 3 theories.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-688063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2025")])]

#text("Hi Professor Tao,")

#text("The estimate_tools repo looks really interesting. Hope you eventually decide to turn it to a collaborative formalization project!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2229b984900b0b520d8c24e92fa34bb161f9c42ef66ae594ae1e6dad0308d3a2-95bd257c2e2657147882ed1a4dd3b375234491bb53f444fec1701f1ecf47600e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby Bartels")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687919")[#strong[#text("Toby Bartels")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2025")])]

#text("Another way to extend completeness to arbitrary intervals is to look at the interiors of the intervals. If these interiors have non-empty intersection, then certainly the original intervals do.")

#text("(There’s a slight technicality: a non-empty closed interval could have empty interior, by being a single point. But if that ever happens, then every further interval in the sequence must also be that point, so the intersection is that point.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2025")])]

#text("few elementary questions.. when we say 1/0 or for that matter talk about blowups in navier stokes do we know it is enough to use the smallest infinity? When you talk about using halting problem for navier stokes for blowup is it still the countable infinity even though reals are uncountable and pdes are over reals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687924")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2025")])]

#text("yay for non-standard non-standard analysis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687928")[#strong[#text("Asymptotic – eryanghsu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2025")]

#text("[…] Orders of infinity […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28547dae59fa96ee98f408babcb393f20ee787b66433d3bd20533cc65811d694-2f4065266ad1539353881337a8f89e0e5ff832e3d38cf9f5b91aebbd5bcd50e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joerg Grande")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687932")[#strong[#text("Joerg Grande")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2025")])]

#text("Should the link “totally ordered vector space” point to the Wikipedia article?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687937")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2025")])]

#text("Actually when you remove very small components, it actually changes the direction of the inequality. A visual example is n/phi(n) or p_n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ce1623e247178b2ab0e55ac58d47fc667f6c5d605275f724da067d3a83dd861-1d39f265b53ce9d60ddc22af59ede136f74028367b65d718e310cf01f70e6957.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lawrence Paulson")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687975")[#strong[#text("Lawrence Paulson")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2025")])]

#text("So interesting… Isabelle/HOL includes an ")#link("https://www.cl.cam.ac.uk/research/hvg/Isabelle/dist/library/HOL/HOL-Nonstandard_Analysis/Free_Ultrafilter.html")[#text("ultrafilter-based development")]#text(" of nonstandard analysis that hasn’t been used since Jacques Fleuriot’s PhD thesis in the 1990s, when he formalised some infinitesimal proofs as given by Newton in his Principia. It would be great to see your post formalised in that environment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-687976")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2025")])]

#text("I made a start on ")#link("https://github.com/teorth/estimate_tools")[#text("formalizing this material")]#text(" in Lean, based on the ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Data/Real/Hyperreal.html#Hyperreal")[#text("existing support in Mathlib for hyperreals")]#text(", which was more extensive than I expected. In particular, a large part of the ultrafilter foundations of nonstandard analysis are already present in Mathlib; for instance, ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/ModelTheory/Ultraproducts.html#FirstOrder.Language.Ultraproduct.sentence_realize")[#text("here is Los’s theorem")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-688064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2025")])]

#text("Dear Professor Tao,")

#text("Could you let me know (e.g. in the Readme.md of the repo.) if or when the project might be open to collaboration? Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-688084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2025")])]

#text("This post and the one from a few years ago on partially specified objects are two approaches to formalizing asymptotic notation–how closely related are these frameworks and can they be synthesized?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Lean companion to “Analysis I” | What's new")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-688201")[#strong[#text("A Lean companion to “Analysis I” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("[…] of my repositories, which was aimed at formalizing the theory of orders of magnitude discussed in this previous blog post. I may eventually split off this companion into its own repository, but at this stage I think it is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/#comment-693598")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("The link in the sentence “For instance, symbolic computations tend to be easier…could benefit from the nonstandard approach.” does not seem to point to the intended “previous blog post”.")

#emph[#text("[Corrected, thanks – T.]")]
]
