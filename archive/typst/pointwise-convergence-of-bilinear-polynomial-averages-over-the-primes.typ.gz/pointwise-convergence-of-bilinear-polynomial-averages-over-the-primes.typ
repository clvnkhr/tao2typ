// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/
// Converted to Typst by tao2typ: "2026-10-14T15:21:01.554565+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Pointwise convergence of bilinear polynomial averages over the primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Pointwise convergence of bilinear polynomial averages over the primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 September 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/")[#text("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://benkrause.wixsite.com/homepage")[#text("Ben Krause")]#text(", ")#link("https://kclpure.kcl.ac.uk/portal/en/persons/seyyed_hamed.mousavi")[#text("Hamed Mousavi")]#text(", ")#link("https://sites.google.com/view/joniteravainen/")[#text("Joni Teräväinen")]#text(", and I have just uploaded to the arXiv the paper “")#link("https://arxiv.org/abs/2409.10510")[#text("Pointwise convergence of bilinear polynomial averages over the primes")]#text("“. This paper builds upon a previous ")#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/")[#text("result of Krause, Mirek, and myself")]#text(", in which we demonstrated the pointwise almost everywhere convergence of the ergodic averages ")#metadata(none) <tao-589f2376ee2c18afc70b>#mi("\\displaystyle  \\frac{1}{N} \\sum_{n=1}^N f(T^n x) g(T^{P(n)} x) \\ \\ \\ \\ \\ (1)")#text(" ")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(" and almost all ")#mi("{x \\in X}")#text(", whenever ")#mi("{(X,T,\\mu)}")#text(" is a measure-preserving system (not necessarily of finite measure), and ")#mi("{f \\in L^{p_1}(X,\\mu)}")#text(", ")#mi("{g \\in L^{p_2}(X,\\mu)}")#text(" for some ")#mi("{1 < p_1,p_2 < \\infty}")#text(" with ")#mi("{1/p_1 + 1/p_2 \\leq 1}")#text(", where ")#mi("{P}")#text(" is a polynomial with integer coefficients and degree at least two. Here we establish the prime version of this theorem, that is to say we establish the pointwise almost everywhere convergence of the averages")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\pi(N)} \\sum_{p \\leq N} f(T^p x) g(T^{P(p)} x)")]]

#text("under the same hypotheses on ")#mi("{(X,T,\\mu)}")#text(", ")#mi("{f, g}")#text(". By standard arguments this is equivalent to the pointwise almost everywhere convergence of the weighted averages")

#metadata(none) <tao-a36afe9b682ed50dfc21>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{N} \\sum_{n \\leq N} \\Lambda(n) f(T^n x) g(T^{P(n)} x)")]]

#text("where ")#mi("{\\Lambda}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(". Our argument also borrows from results in a ")#link("https://arxiv.org/abs/2401.03174")[#text("recent paper of Teräväinen")]#text(", who showed (among other things) that the similar averages")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n \\leq N} \\mu(n) f(T^n x) g(T^{P(n)} x)")]]

#text("converge almost everywhere (quite fast) to zero, at least if ")#mi("{X}")#text(" is assumed to be finite measure. Here of course ")#mi("{\\mu}")#text(" denotes the ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(".")

#text("The basic strategy is to try to insert the weight ")#mi("{\\Lambda}")#text(" everywhere in the proof of the convergence of ")#link(<tao-589f2376ee2c18afc70b>)[#text("(1)")]#text(" and adapt as needed. The weighted averages are bilinear averages associated to the bilinear symbol")

#align(center)[#tao-fit-display[#mitex("(\\xi_1,\\xi_2) \\mapsto \\frac{1}{N} \\sum_{n \\leq N} \\Lambda(n) e(n \\xi_1 + P(n) \\xi_2).")]]

#text("In the unweighted case, results from the additive combinatorics theory ")#link("https://arxiv.org/abs/1903.02592")[#text("of Peluse and Prendiville")]#text(" were used to essentially reduce matters to the contribution where ")#mi("{\\xi_1,\\xi_2}")#text(" were “major arc”, at which point this symbol could be approximated by a more tractable symbol. Setting aside the Peluse-Prendiville step for now, the first obstacle is that the natural approximation to the symbol does not have sufficiently accurate error bounds if a Siegel zero exists. While one could in principle fix this by adding a Siegel correction term to the approximation, we found it simpler to use the arguments of Teräväinen to essentially replace the von Mangoldt weight ")#mi("{\\Lambda}")#text(" by a “Cramér approximant”")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{\\mathrm{Cramer}, w}(n) := \\frac{W}{\\phi(W)} 1_{(n,W)=1}")]]

#text("where ")#mi("{W = \\prod_{p \\leq w} p}")#text(" and ")#mi("{w}")#text(" is a parameter (we make the quasipolynomial choice ")#mi("{w = \\exp(\\log^{1/C_0} N)}")#text(" for a suitable absolute constant ")#mi("{N}")#text("). This approximant is then used for most of the argument, with relatively routine changes; for instance, an ")#mi("{L^p}")#text(" improving estimate needs to be replaced by a weighted analogue that is relatively easy to establish from the unweighted version due to an ")#mi("{L^2}")#text(" smoothing effect, and a sharp ")#mi("{p}")#text("-adic bilinear averaging estimate for large ")#mi("{p}")#text(" can also be adapted to handle a suitable ")#mi("{p}")#text("-adic weight by a minor variant of the arguments. The most tricky step is to obtain a weighted version of the Peluse-Prendiville inverse theorem. Here we encounter the technical problem that the Cramér approximant, despite having many good properties (in particular, it is non-negative and has well-controlled correlations thanks to the ")#link("https://en.wikipedia.org/wiki/Fundamental_lemma_of_sieve_theory")[#text("fundamental lemma of sieve theory")]#text("), is not of “Type I”, which turns out to be quite handy when establishing inverse theorems. So for this portion of the argument, we switch from the Cramér approximant to the ")#emph[#text("Heath-Brown approximant")]

#align(center)[#tao-fit-display[#mitex("\\Lambda_{\\mathrm{HB},Q}(n) := \\sum_{q<Q} \\frac{\\mu(q)}{\\phi(q)} c_q(n)")]]

#text("where ")#mi("{c_q(n)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Ramanujan%27s_sum")[#text("Ramanujan sum")]

#align(center)[#tao-fit-display[#mitex("c_q(n) := \\sum_{r \\in ({\\bf Z}/q{\\bf Z})^\\times} e(-rn/q).")]]

#text("While this approximant is no longer non-negative, it is of Type I, and thus well suited for inverse theory. In our paper we set up some basic comparison theorems between ")#mi("{\\Lambda}")#text(", ")#mi("{\\Lambda_{\\mathrm{Cramer},w}}")#text(", and ")#mi("{\\Lambda_{\\mathrm{HB},Q}}")#text(" in various Gowers uniformity-type norms, which allows us to switch relatively easily between the different weights in practice; hopefully these comparison theorems will be useful in other applications as well.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/#comment-685793")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2024")])]

#text("Great Professor! please consider:")#linebreak()#text("By thinking of ")#strong[#emph[#text("prime multiplication for primes greater than 3 modulo 6 as a bilinear polynomial")]]#text(", we can explore the modular relationships between products of primes congruent to ")#strong[#text("1")]#text(" and ")#strong[#text("5")]#text(" ")#strong[#text("mod 6")]

#text("Since there are infinitely many primes congruent to 1 and 5 modulo 6, the number of possible multiplications among these primes is infinite as well. Each pair of primes, or higher products of more than two primes, can generate a different composite number, which will lie in one of the two classes (congruent to 1 or 5 modulo 6).")#linebreak()#text("Thus, if we consider the multiplicative structure of these primes under modular arithmetic, we can think of these products as forming “subgroups” in some sense. The idea of a subgroup comes from observing that the set of products of primes congruent to 1 modulo 6, for example, remains closed under multiplication and forms a structure akin to a multiplicative group (mod 6). ")#strong[#text("Z/6Z")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/#comment-685795")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2024")])]

#text("In the paper it’s assumed that ")#mi("P(X)")#text(" is a polynomial of degree at least 2. If I understand it correctly, the a.e. convergence of the bilinear sum like ")#mi("\\frac{1}{N}\\sum_{n=1}^N f(T^{p_n}x)g(T^{-p_n}x)")#text(" is still open.")

#text("Why the higher degree case is easier? Is it because of the “true complexity zero situation” you mentioned in the paper?")

#text("For the ordinary bilinear average ")#mi("\\frac{1}{N}\\sum_{n=1}^N f(T^{n}x)g(T^{-n)}x)")#text(", I remembered that Bourgain gave a proof in his 1990 J. Reine Angew. Math. paper, and later Demeter gave another proof based on Time-Frequency analysis in 2007. Nowadays, do we have a satisfied time-frequency tools when dealing with the non-conventional averages like ")#mi("\\frac{1}{N}\\sum_{n=1}^N f(T^{P(n)}x)g(T^{Q(n)}x)")#text(", or ")#mi("\\frac{1}{N}\\sum_{n=1}^N f(T^{p_n}x)g(T^{-p_n}x)")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/#comment-685835")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("Yes, our techniques rely crucially on the “true complexity zero” nature of the average, allowing us to restrict attention to major arcs. The average you mention are (morally at least) of “true complexity one” should presumably require time-frequency analysis methods (or something similar), but at present these methods are not well integrated at a technical level with additive combinatorial techniques (such as Peluse-Prendiville theory). But this seems like a temporary technical issue that should get resolved over time; I would expect a pointwise ergodic theorem to be available for these prime averages by some combination of known methods. Perhaps a model problem would be to first locate a proof of Bourgain’s theorem in more modern, additive combinatorics-friendly language (e.g., using Gowers norms etc.).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/#comment-685796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2024")])]

#text("Are there any applications of this result to proving new statements about primes that not mention measure-preserving systems?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/#comment-685836")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("Of course one could apply the pointwise ergodic theorem to specific systems (e.g., circle rotations, skew shifts, nilsystems, etc.) to obtain convergence of various mean exponential sums over the primes, although these sums are either somewhat artificial or could be handled more directly by more traditional analytic number theory methods (e.g., Vinogradov’s bilinear sum technique). We are currently exploring whether the Peluse-Prendiville theorem for the primes established in the paper has some consequences for Szemeredi-type theorems with prime (or shifted prime) differences, but this is work in progress.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/#comment-685799")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2024")])]

#text("amazing! Great job Ben!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/#comment-685801")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2024")])]

#text("congrats Hamed and Ben!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/#comment-685808")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2024")])]

#text("Terence Tao! What a wonderful mathematician you are!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/17/pointwise-convergence-of-bilinear-polynomial-averages-over-the-primes/#comment-685837")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("cringemaxxing")
]
]
