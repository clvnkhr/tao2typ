// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T15:21:16.841248+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Crowdsourcing a list of general resources on AI and mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Crowdsourcing a list of general resources on AI and mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/")[#text("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Given current events, I think it is worthwhile to start collecting useful online resources with regards to AI and mathematics in general. I will start a list below, but ask contributors to contribute further links in the comments. Note that while I personally do not agree with 100% of the content of every single link below, I find each of them interesting enough to be worth mentioning here.")

#text("I am excluding my own writings on these topics, which can be found ")#link("https://teorth.github.io/tao-web/mastodon-posts.html")[#text("here")]#text(" (and summarized ")#link("https://teorth.github.io/tao-web/ai-views.html")[#text("here")]#text(") instead. Resources specific to individual results, such as global regularity for Navier-Stokes, should be submitted as comments to other appropriate blog posts instead.")

#text("UPDATE: due to volume of submissions, I will no longer update the main blog post (other than to update links etc.), and will refer to the comments to the post for further resources.")

#text("Statements and advocacy")

#list(
[#text("The ")#link("https://leidendeclaration.ai/")[#text("Leiden declaration")]],
[#text("Max Weinreich, “")#link("https://arxiv.org/abs/2608.02859")[#text("The crisis of AI-generated mathematics")]#text("“, 3 Aug 2026")],
[#link("https://www.ahmath.org/")[#text("The Association for Human Mathematics")]],
[#link("https://proofsandprompts.com/2026/09/10/open-letter-about-the-mathathon/")[#text("Open Letter about the Mathathon")]#text(", Sep 10 2026 (see also ")#link("https://proofsandprompts.com/2026/09/10/a-response-from-mathathon/")[#text("this response from the organizers")]#text("). Update, Sep 21 2026: there has been significant progress in resolving the concerns in the petition; stay tuned for further announcements.")],
[#link("https://mathandai.org/")[#text("A Severe Misalignment of AI in Mathematics")]#text(", Sep 11 2026")],
[#link("https://www.change.org/p/a-manifesto-for-the-creation-of-a-european-center-for-ai")[#text("A Manifesto for the creation of a European Center for AI")]#text(", Oct 3 2025")],
[#link("https://math.mit.edu/~elmos/petition.html")[#text("Give Authors Control: Let Us Decide If AI Bots Can Read Our arXiv Papers")]#text(", 9 Sep 2026")]
)

#text("Reports and analyses")

#list(
[#link("https://1stproof.org/")[#text("First Proof")]],
[#link("https://aiandeducation.mit.edu/report/")[#text("Report by the MIT Ad Hoc Committee on AI Use in Teaching, Learning, and Research Training")]#text(" (Aug 13, 2026)")]
)

#text("Opinions and community discussion")

#list(
[#text("Jeremy Avigad, “")#link("https://arxiv.org/abs/2603.03684")[#text("Mathematicians in the age of AI")]#text("“, Mar 2026.")],
[#text("David Bessis, “")#link("https://davidbessis.substack.com/p/the-fall-of-the-theorem-economy")[#text("The fall of the theorem economy")]#text("“, Apr 21, 2026.")],
[#text("Johan Commelin, Mateja Jamnik, Rodrigo Ochigame, Lenny Taelman, Akshay Venkatesh, “")#link("https://arxiv.org/abs/2603.24914")[#text("Shaping the Future of Mathematics in the Age of AI")]#text("“, Mar 2026.")],
[#text("David Donoho, “")#link("https://arxiv.org/abs/2310.00865")[#text("Data science at the Singularity")]#text("“, Oct 2023.")],
[#text("Hugo Duminil-Copin, “")#link("https://proofsandprompts.com/2026/08/30/care-for-a-little-more-ai/")[#text("Care for a little more AI?")]#text("“, Proofs and Prompts, Aug 30, 2026.")],
[#text("Pavel Etingof, “")#link("https://math.mit.edu/~etingof/aiuse.pdf")[#text("Use of AI in mathematical research: A guide for young mathematicians")]#text("“, May 2026.")],
[#text("Timothy Gowers, “")#link("https://link.springer.com/book/10.1007/978-3-0346-0422-2")[#text("Rough structure and classification")]#text("“, GAFA 2000 Special Volume “Visions in Mathematics”, 79-117 (see in particular the section “Will Mathematics Exist in 2009?”).")],
[#text("Martin Hairer, “")#link("https://www.youtube.com/watch?v=fbVqc1tPLos")[#text("Do Mathematicians need computers?")]#text("“, Simons Foundation, Dec 5, 2025.")],
[#text("Martin Hairer, “")#link("https://proofsandprompts.com/2026/08/07/writing-mathematics-in-the-age-of-ai/")[#text("Writing mathematics in the age of AI")]#text("“, Proofs and Prompts, Aug 7, 2026.")],
[#text("Minas Karimanis, “")#link("https://ergosphere.blog/posts/the-machines-are-fine/")[#text("The machines are fine. I’m worried about us.")]#text("“, Mar 30, 2026.")],
[#text("Daniel Litt, “")#link("https://www.daniellitt.com/blog/2026/2/20/mathematics-in-the-library-of-babel")[#text("Mathematics in the Library of Babel")]#text("“, Feb 21, 2026.")],
[#text("Heather Macbeth, “")#link("https://arxiv.org/abs/2405.04699")[#text("Algorithm and abstraction in formal mathematics")]#text("“, May 2024.")],
[#text("Matilde Marcolli, “")#link("https://www.its.caltech.edu/~matilde/AImathNew.pdf")[#text("Duet for the end of math")]#text("“, Sep 2026. (To appear, Newsletter of the London Mathematical Society.)")],
[#text("Arvind Narayanan, “")#link("https://www.normaltech.ai/p/what-will-be-left-for-us-to-work")[#text("What will be left for us to work on?")]#text("“, AI as Normal Technology, Jul 13, 2026.")],
[#text("Emily Riehl, “")#link("https://www.youtube.com/watch?v=fzxW2XJS6SE")[#text("A New Paradigm for Mathematical Proof?")]#text("“, Hopkins Natural Philosophy Forum, Nov 7, 2025.")],
[#text("Talia Ringer, “")#link("https://dependenttyp.es/pdf/conversations.pdf")[#text("Proofs and Conversations")]#text("“, AMS Early Career Notices, May 2024.")],
[#text("Francis Su, “")#link("https://francissu.substack.com/p/the-enduring-value-of-math-in-an")[#text("The Enduring Value of Math, in an Age of AI")]#text("“, Aug 20, 2026.")],
[#text("Akshay Venkatesh, “")#link("https://www.youtube.com/watch?v=STTvEmBM3rg")[#text("What do we tell our students about AI?")]#text("“, Mathematics in the age of automated proofs, Oct 1, 2025.")],
[#text("The ")#link("https://proofsandprompts.com/")[#text("Proofs and Prompts")]#text(" blog collects essays and discussions on mathematics and AI, some of which are listed separately here.")],
[#text("The Bulletin of the AMS published ")#link("https://www.ams.org/journals/bull/2024-61-02/")[#text("two")]#text(" ")#link("https://www.ams.org/journals/bull/2024-61-03/")[#text("issues")]#text(" devoted to mathematics and AI, featuring articles by Fraser-Granville-Harris-McLarty-Riehl-Venkatesh, Venkatesh, Buzzard, Avigad, Commelin-Topaz, Shulman, Williamson, Davis, Cheng, Granville, Harris, Romeo, DeDeo, Davies, De Toffoli, McLarty, Ochigame, Poggio-Fraser, and Bengio-Malkin.")],
[#text("The Feb 2023 ")#link("https://www.ipam.ucla.edu/programs/workshops/machine-assisted-proofs/?tab=schedule")[#text("IPAM workshop on Machine Assisted Proofs")]#text(" has a number of interesting talks recorded on these topics.")],
[#text("The Erdos problem website currently has an ")#link("https://www.erdosproblems.com/forum/thread/blog:8")[#text("active discussion forum on this topic")]#text(".")]
)

#text("Other resource lists")

#list(
[#text("Northwestern’s ")#link("https://sites.northwestern.edu/airesourcesmath/")[#text("AI + Mathematics Resources")]],
[#text("Proof and Prompts ")#link("https://proofsandprompts.com/newsfeed/")[#text("newsfeed/links page")]]
)

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Dear Prof. Tao,")

#text("It is worth for including this statements as well, following Max Weinreich (one of the organization committee)")#linebreak()#link("https://www.ahmath.org/")[#text("https://www.ahmath.org/")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694402")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Bryna and I also made a list: ")#link("https://sites.northwestern.edu/airesourcesmath/")[#text("https://sites.northwestern.edu/airesourcesmath/")]

#emph[#text("[Added, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694403")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#link("https://xenaproject.wordpress.com/2026/07/20/human-mathematicians-are-being-outcounterexampled/")[#text("https://xenaproject.wordpress.com/2026/07/20/human-mathematicians-are-being-outcounterexampled/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("This one may be of interest:")

#link("https://www.begin-proof.com/declaration")[#text("https://www.begin-proof.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694406")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("There is ")#link("https://vibemathed.com/")[#text("https://vibemathed.com/")]#text(" although it doesn’t seem in the spirit of the existing list.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694411")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#link("https://maisi.org/")[#text("https://maisi.org/")]#text(" is hiring for semester-long positions — Sucharit")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I work in a state university math department right now and it’s complete and utter chaos. We don’t know what work to give graduate students that is “meaningful” right now. We don’t know what work WE will be doing one year or several years from now that will be meaningful. Just a strange and sad feeling, like death of lavoisier. I suppose this moment was inevitable, but I just feel extremely bad for those that are currently grad or undergrad in math. Since the way forward for them is murky :-(")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Do you think AI will replace human mathematicians? Don’t think that will happen.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-695968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I don’t see the work of a mathematician as that of a programmer, it will become a soulless activity, restricted to a smaller number of people. The brilliance and what most enchants a person in mathematics will be lost. If the person didn’t bother to write, I won’t bother to read. Things lately are soulless, when you do a simple search on a search engine, you find generated texts on the first page, whereas before I found texts written by people. What kind of world is this that is removing humanity from things?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694413")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Peter Woit, “Requiem for a Field?”: ")#link("https://www.math.columbia.edu/~woit/wordpress/?p=15787")[#text("https://www.math.columbia.edu/~woit/wordpress/?p=15787")]

#text("Peter Woit, “A Modest Proposal”: ")#link("https://www.math.columbia.edu/~woit/wordpress/?p=15864")[#text("https://www.math.columbia.edu/~woit/wordpress/?p=15864")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e37d83042ea1d4f58c5a6c88e4ea66b4b6780ebc05556e1d809fa0b303b24598-eb8853300cf52bdecc8460e4f6fbb365692ab97b3300303605c00be3d5c07d76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Proofs Prompts")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694414")[#strong[#text("Proofs Prompts")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Hi this is Francesco, one of the hosts of P&P. We also have a newsfeed on the website and some stable links, which overlap a lot with yours ")#link("https://proofsandprompts.com/newsfeed/")[#text("https://proofsandprompts.com/newsfeed/")]

#emph[#text("[Added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35c17b63fc40928d9f8607c8b3c15bf73ab4b7b93348c35d8827af26432eb134-5f9a079590a8bb7300b06fdeac5c32d8e4885ae44a61da4201b6c9bf3cc6c66d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mcsc2016")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694416")[#strong[#text("mcsc2016")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("A couple of podcast episodes with Cathy O’Neil: Daniel Litt ( ")#link("https://mathbabe.org/2026/07/06/ai-skeptics-erdoss-conjecture-was-just-the-beginning-with-daniel-litt/")[#text("https://mathbabe.org/2026/07/06/ai-skeptics-erdoss-conjecture-was-just-the-beginning-with-daniel-litt/")]#text(" ) and Jacob Tsimerman ( ")#link("https://mathbabe.org/2026/08/26/ai-skeptics-from-mathematics-to-ai-safety-with-jacob-tsimerman/")[#text("https://mathbabe.org/2026/08/26/ai-skeptics-from-mathematics-to-ai-safety-with-jacob-tsimerman/")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694417")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("There’s a lot written on this topic by many different people in the questions (& answers) tagged “artificial intelligence” on MathOverflow: ")#link("https://mathoverflow.net/questions/tagged/artificial-intelligence")[#text("https://mathoverflow.net/questions/tagged/artificial-intelligence")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Doron Zeilberger’s Opinions, though often rather contrarian and at times bordering on crankish, do seem to have at least some bearing on present developments. ")#link("https://sites.math.rutgers.edu/~zeilberg/OPINIONS.html")[#text("https://sites.math.rutgers.edu/~zeilberg/OPINIONS.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694419")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Inasmuch as mathematicians are part of humanity:")

#link("https://secure.avaaz.org/en/campaigns/human_ai_2_1/")[#text("https://secure.avaaz.org/en/campaigns/human_ai_2_1/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I find the interviews of AI experts on the machine learning street talk (MLST) podcast to generally be of very high quality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a3bf8a3068e1df5e8e515db87c945ca142ba1773d998a685d137eb0f17a7429-303bd6780e62957c36cc111771e204de072bfc3c875677a6ccaf4d2af0760cc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vinícius Machado Vogt")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694422")[#strong[#text("Vinícius Machado Vogt")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("From the United Nations website (4 June 2026): “AI’s environmental costs threaten water, land and climate” ")#link("https://news.un.org/en/story/2026/06/1167658")[#text("https://news.un.org/en/story/2026/06/1167658")]

#text("From Forbes: “AI Companies Are Buying—And Destroying—Antique Books. Here’s Why.” (by Mary Whitfill Roeloffs, 17 August 2026) ")#link("https://www.forbes.com/sites/maryroeloffs/2026/08/17/ai-companies-are-buying-and-destroying-antique-books-heres-why/")[#text("https://www.forbes.com/sites/maryroeloffs/2026/08/17/ai-companies-are-buying-and-destroying-antique-books-heres-why/")]

#text("In short: tech companies are destroying our planet and physical (print) books, and we still pay them for it. Very sad.")

#text("P.S. From NewScientist: “Rogue hacking AIs have changed the cybersecurity landscape” (by Matthew Sparkes, 17 August 2026) ")#link("https://www.newscientist.com/article/2583927-rogue-hacking-ais-have-changed-the-cybersecurity-landscape/")[#text("https://www.newscientist.com/article/2583927-rogue-hacking-ais-have-changed-the-cybersecurity-landscape/")]#text("“")

#text("Just as countries took measures against the proliferation of other types of weapons, should we combat the proliferation of massive data centers or something similar? The way things are going, the future of humanity doesn’t look good.")

#text("P.P.S. I am a layperson, but I stay informed and I am concerned!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694435")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Mathematics in the age of AI paper")

#link("https://www.nature.com/articles/s41567-025-03042-0")[#text("https://www.nature.com/articles/s41567-025-03042-0")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694437")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("This article in the New Yorker is a must-read:")

#link("https://www.newyorker.com/magazine/2026/04/13/sam-altman-may-control-our-future-can-he-be-trusted")[#text("https://www.newyorker.com/magazine/2026/04/13/sam-altman-may-control-our-future-can-he-be-trusted")]

#text("Best regards,")

#text("José Hdz.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694439")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Timothy Gowers’ description of using ChatGPT5.5-Pro: ")#link("https://gowers.wordpress.com/2026/05/08/a-recent-experience-with-chatgpt-5-5-pro/")[#text("https://gowers.wordpress.com/2026/05/08/a-recent-experience-with-chatgpt-5-5-pro/")]#text(". Note that this was published in May, just to take in the rate of progress. Erdos 1196 was proved in April, which woke me up to the capabilities (I believe it was the first instance where an AI seemed to come up with a novel argument).")

#text("Kirwin Hampshire’s The Dark Night of Mathematics: ")#link("https://kirwinhampshire.substack.com/p/the-dark-night-of-mathematics")[#text("https://kirwinhampshire.substack.com/p/the-dark-night-of-mathematics")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35c17b63fc40928d9f8607c8b3c15bf73ab4b7b93348c35d8827af26432eb134-5f9a079590a8bb7300b06fdeac5c32d8e4885ae44a61da4201b6c9bf3cc6c66d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mcsc2016")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694444")[#strong[#text("mcsc2016")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Quanta Magazine just launched a dedicated section, Transformation: ")#link("https://www.quantamagazine.org/updates/transformation/")[#text("https://www.quantamagazine.org/updates/transformation/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694448")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I’m glad to see a link to Gowers’s 1999/2000 essay because I was starting to think I was the only person who remembered it! (Copy freely available at ")#link("https://www.dpmms.cam.ac.uk/~wtg10/papers.html#surveys")[#text("https://www.dpmms.cam.ac.uk/~wtg10/papers.html#surveys")]#text(" for those who don’t have a Springer subscription but do have software that can read/convert Postscript files :) )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694457")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Here is an on going thread about AI Contributions to math on erdosproblems.com — ")#link("https://www.erdosproblems.com/forum/thread/AI%20Contributions%202")[#text("https://www.erdosproblems.com/forum/thread/AI%20Contributions%202")]

#text("I wrote (with AI) this slide deck to summarize what has happened until late June: ")#link("https://ai-in-math.netlify.app/#/title")[#text("https://ai-in-math.netlify.app")]

#text("Here is a discussion about what we should teach in math in the age of AI: ")#link("https://matheducators.stackexchange.com/questions/29900/if-ai-solves-the-problem-what-are-we-grading")[#text("https://matheducators.stackexchange.com/questions/29900/if-ai-solves-the-problem-what-are-we-grading")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694467")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I’m not sure if it’s poor form to recommend your own work – but this piece on Ennio De Giorgi and the value of mathematics may be of interest Terry:")

#link("https://firstthings.com/mathematics-after-ai/")[#text("https://firstthings.com/mathematics-after-ai/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694476")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Probably the most in-depth “blog” on the subject is Silicon Reckoner, which was created 5 years ago and the first posts are still quite relevant to this day.")#linebreak()#link("https://siliconreckoner.substack.com/")[#text("https://siliconreckoner.substack.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694484")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("“Mathematical anxiety in the age of AI: Opacity, role inversion, and the changing place of the mathematician” by Michael Friedman")

#link("https://www.sciencedirect.com/science/article/pii/S2949882126001398")[#text("https://www.sciencedirect.com/science/article/pii/S2949882126001398")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91382a05b195a0a1bb350d81d48b36860d18af309196732328efe2446c5d5ef3-2d37b689a29de14fb009f4865fcc316b233b9db9a2c6ba1e2199a3a3c9747e8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694493")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I would like to add the following thought that maybe was raised elsewhere before.")

#text("Should we, mathematicians, not, as a whole community/group, speak up more loudly about our current experience and concerns, and call out for a pause or at least slow down in AI research?")

#text("I think, this is possible for us, since mathematician all over the world have currently the same experience, and I assume that a pause or slow down in AI research is close to being consensus among us.")

#text("And I make this point not to turn back time. I believe the way we work as mathematicians has changed forever in the last 5 month. The current models will not go away.")

#text("And although I’m also excited about the mathematical progress achieved by these models, I think the accelerated speed how AI develops is not healthy, sustainable, useful or safe for humanity as whole.")

#text("As a group, mathematicians are in a position to address this point such that people (leaders) will take it serious.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694513")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#link("https://blog.kolen.dev/math/Navier-Stokes#sec-ethics")[#text("https://blog.kolen.dev/math/Navier-Stokes#sec-ethics")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Another Michael Friedman article: ")#link("https://doi.org/10.1007/s00283-026-10561-y")[#text("https://doi.org/10.1007/s00283-026-10561-y")]

#text("Friedman, M., Kish Bar-On, K. Rethinking Mathematical Intuition in the Age of AI. ")#emph[#text("Math Intelligencer")]#text(" (2026). (published 26 August 2026)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694840")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I am wondering whether the math community considers building its own LLMs or collaborating with certain medium (or small) AI labs. It is known that to train and run LLMs is expansive. But if focusing on maths, there may be chances to control the cost and make its capabilities competent in the future. If the math community takes actions to build its own LLM, those leading AI companies may change their attitudes to our subject and community.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694883")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("The SAIR foundation I am working with are currently negotiating with several academics and smaller companies on precisely this. We hope to be able to make an announcement soon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8d858d22db3368c69a23944e0d58cb62ef481e672fa38c741422ef35e15bc8-2e46cce8f4f2aa7bc7e4461507ea373189c38fcd0db0ed29a7774ade34e3ca69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kolen Cheung")]], [#link("https://terrytao.wordpress.com/2026/09/10/crowdsourcing-a-list-of-general-resources-on-ai-and-mathematics/#comment-694991")[#strong[#text("Kolen Cheung")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I have an idea called “Progressive disclosure for mathematical proofs” borrowing some concepts from cybersecurity laid out here: ")#link("https://blog.kolen.dev/math/math-vs-cybersecurity")[#text("https://blog.kolen.dev/math/math-vs-cybersecurity")]#text(" In short, a registry where mathematicians privately record work as it develops, with timestamps others can verify. This could be a draft, a partial calculation, or even a handwritten page. Access then widens in stages before public release, similar to coordinated vulnerability disclosure in security. People would have a record of their contribution without rushing an unfinished proof out when an AI lab announces. AI-assisted work could then become a collaboration rather than a race. Unlike Palomar, it’s meant for unfinished work that may not be formalized.")
]
