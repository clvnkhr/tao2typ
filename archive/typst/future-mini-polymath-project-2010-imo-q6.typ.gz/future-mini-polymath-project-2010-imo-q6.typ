// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/
// Converted to Typst by tao2typ: "2026-10-14T15:17:47.837148+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Future mini-polymath project: 2010 IMO Q6?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Future mini-polymath project: 2010 IMO Q6?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 June 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/")[#text("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("About a year ago, as an experiment, I set up on this blog a ")#link("http://en.wordpress.com/tag/mini-polymath1/")[#text("“mini-polymath” project")]#text(", in which readers were invited to collaboratively solve the sixth question on the ")#link("http://www.imo2009.de")[#text("2009 International Mathematical Olympiad")]#text(" (aka “the grasshopper problem”). After two or three days of somewhat chaotic activity, multiple solutions to this problem were obtained, and have been archived on ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6")[#text("this page")]#text(".")

#text("In the ")#link("https://terrytao.wordpress.com/2009/07/22/imo-2009-q6-mini-polymath-project-impressions-reflections-analysis/")[#text("post-mortem discussion of this experiment")]#text(", it became clear that the project could have benefited from some more planning and organisation, for instance by setting up a wiki page early on to try to collect strategies, insights, partial results, etc. Also, the project was opened without any advance warning or prior discussion, which led to an interesting but chaotic opening few hours to the project.")

#text("About a month from now, the 51st International Mathematical Olympiad ")#link("http://www.imo2010org.kz/")[#text("will be held in Kazahkstan")]#text(", with the actual problems being released on July 7 and 8. Traditionally, the sixth problem of the Olympiad (which would thus be made public on July 8) is the hardest, and often the most interesting to solve. So in the interest of getting another data point for the polymath process, I am thinking of setting up another mini-polymath for this question (though I of course do not know in advance what this question will be!). But this time, I would like to try to plan things out well in advance, to see if this makes much of a difference in how the project unfolds.")

#text("So I would like to open a discussion among those readers who might be interested in such a project, regarding the logistics of such a project. Some basic issues include:")

#enum(start: 1, 
[#strong[#text("Date and time.")]#text(" Clearly, the project cannot start any earlier than July 8. One could either try to fix a specific time (to within an hour, say), to officially start the project, or one could open the thread in advance of the IMO organisers releasing the questions, and just let the first person to find the questions post them to the thread, and start the clock from there. I assume one can rely on the honour code to refrain from privately trying to solve the question before any official starting time.")],
[#strong[#text("Location.")]#text(" In addition to this blog here, there is now also a dedicated ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text(" for these projects, which has some minor advantages over this one (e.g. numbered and threaded comments with wide margins). It has fairly low levels of activity right now (though we are just starting to write up some modest progress from the ongoing Polymath4 “finding primes” project), but this may actually be a plus when running the project, to minimise cross-traffic. Also, another benefit of the other blog is that the project can be co-administered by several people, and not just by myself. This blog here admittedly has significantly higher traffic than the polymath blog at present, but I would certainly post a crosslink to the polymath blog if the project started.")],
[#strong[#text("Ground rules")]#text(". The rules for the first mini-polymath project can be ")#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/")[#text("found here")]#text(". Basically the spirit of the rules is that the objective is not to be the first to produce an individual solution, but instead to contribute to a collective solution by sharing one’s insights, even if they are small or end up being inconclusive. (See also ")#link("http://gowers.wordpress.com/2009/01/27/is-massively-collaborative-mathematics-possible/")[#text("Tim Gowers’ original post")]#text(" regarding polymath projects.) But perhaps some tweaking to the rules may be needed. (For instance, we may want to have some semi-official role for moderators to organise the discussion. Ideally I would prefer not to be the sole moderator, in part because I want to see the extent to which such projects can flourish independently of one key person.)")],
[#strong[#text("Set up")]#text(". It seems clear that we should have an official wiki page (probably a subpage from the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath wiki")]#text(") well in advance of the project actually starting (which could also be used to advertise the project beyond the usual readership of this blog). Is there anything else which it might be useful to have in place before the project starts?")],
[#strong[#text("Contingency planning.")]#text(" It may happen that for one reason or another, 2010 IMO Q6 will not turn out to be that good of a polymath problem. I suppose it may be sensible to reserve the right to switch to, say, 2010 IMO Q5, if need be. This might be one place where I might exercise some unilateral judgement, as it may be difficult to quickly get consensus on these sorts of issues. I don’t know if it’s worth discussing these sorts of possibilities in advance; it may simply be better to improvise when and if some course corrections need to be made.")]
)

#text("Anyway, I hope that this project will be interesting, and am hoping to get some good suggestions as to how make it an instructive and enjoyable experience for all.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mini-polymath proposal: IMO 2010 Q6 « The polymath blog")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45462")[#strong[#text("Mini-polymath proposal: IMO 2010 Q6 « The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2010")])]

#text("[…] of the six problems) as a mini-polymath project for next month. Details and discussions are in this post on my other blog. Leave a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0af042bf9b8c6afe3fb307f953857727093f6db41dd13a04c13db4366cc0572-8eb4d1511733286836c9547eec439829a3d38ec528b2a29183ae61577026f105.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45466")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2010")])]

#text("Traditionally, the 3rd problem of the first day is also difficult and on the same level with the 3rd problem of the second day (the 6th problem). So you may consider both problems for the project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45467")[#strong[#text("Future mini-polymath project: 2010 IMO Q6? » News, Hacker, View, Comments » Adjoozey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2010")]

#text("[…] Comments View flooded place on Hacker News […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45474")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2010")])]

#text("It strikes me that there are some Olympiad problems where one trick basically unlocks the problem. It might seem that such problems are not suited to Polymath, or at least that the whole would not be more than the sum of its parts. And yet, to uncover the magic key usually involves quite a bit of digging, so this view is not necessarily correct. Therefore, any procedure that encourages a process that is clearly collective (as opposed to, say 100 people racing to find the solution, which on purely probabilistic grounds is therefore found quite quickly) would find favour with me.")

#text("I think one way of doing this is what you have already suggested: having participants who continually keep up with the discussion and write careful and comprehensible summaries of what has been discovered so far. Given the speed at which the project developed last year, there was a strong temptation not to read too much of what other people had written: if someone could pick out the important parts (of course, that selection process raises problems, but if someone thinks they’ve been wrongly overlooked, they can always post again to explain why) and present them nicely, it would reduce substantially the temptation to go it alone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45478")[#strong[#text("Future Mini-Polymath project « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2010")]

#text("[…] Mini-Polymath project By kristalcantwell There is a discussion here about a future mini-Polymath project based on 2010 IMO question […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45482")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2010")])]

#text("The project does look interesting. I remember the last mini-Polymath project based on the IMO. It seemed to work out well although the changes you are discussing will probably improve things.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T.")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45502")[#strong[#text("T.")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2010")])]

#text("For an olympiad-size problem with a polymath number of contributors, a ground rule that may be useful is “NO PENCIL AND PAPER”. Any calculation would be mental or something that can be done (without additional pencil and paper) while typing the blog posts.")

#text("The idea is to simulate a roomful of people where anyone can muse out loud about ideas as they come to mind, but all concrete progress is recorded on a blackboard at the front of the room, so that it can be assimilated by the whole group. Reducing unshared workspace to a minimum (single brains) would keep the group better synchronized.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2010")])]

#text("An open starting time may be an issue.")

#text("KZ is GMT+4")

#text("Say they release the questions at 9am local.")#linebreak()#text(" If you leave the thread open and allow the first person to see the question to make the first post, the US will be asleep or going to bed, anyone in Asia or Australia will get several hours at it followed by anyone in UK or Europe.")

#text("You will also not get a chance to review and change the question or moderate the initial direction.")

#text("On the other hand, if you do fix an arbitrary, US convenient, starting time, I hope you announce it well in advance. I am in GMT+10 and would like to join in but will need to stock up on coffee and plan to have the schedule for the next day empty!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45549")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2010")])]

#text("Hmm. I guess an open thread would have some disadvantages. Given that there is really no need to turn this project into a speed race, a fixed starting time seems like a better idea (and I can then exercise discretion to pick which of the six problems would be best for the mini-polymath project, given Gowers’ point that some problems may be less suited to this format than others). In a few days I will set up a poll to figure out what starting time would be best (and may also poll other questions too if a relevant issue arises).")

#text("Incidentally, Hassan Al-Sibyani pointed out to me the following list of past IMO questions:")

#link("http://www.artofproblemsolving.com/Forum/resources.php?c=1&cid=16&sid=60f6444833b5d8bd7250338798565a28")[#text("http://www.artofproblemsolving.com/Forum/resources.php?c=1&cid=16&sid=60f6444833b5d8bd7250338798565a28")]

#text("Looking through these, it does seem that Q6 is not always the most interesting candidate for a polymath project, and so exercising discretion is probably the way to go.")

#text("I was thinking about issuing a call for volunteer moderators, but perhaps one can rely on an ")#emph[#text("ad hoc")]#text(" system where active participants will take the initiative and try to organise the discussion by summarising progress (either on the blog or on the wiki). But it might be a good idea to have at least one formal moderator from a time zone quite distinct from my own (GMT -8), to ensure uniform coverage…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45576")[#strong[#text("Nothing is impossible (?) « Woett's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2010")]

#text("[…] Nothing is impossible (?) By Woett Something’s been bothering me for a while now. While my statistical intuition is usually quite sharp, in this case I’m wrong, although I never really heard a convincing argument why exactly. So I’ll try to explain my problem, and hopefully someone with a sound argument could reply. Basically, my confusion starts with the sentence ‘Some event that has a chance of 0 of happening, can still happen.’ Let P(x) be the chance that x happens. To me `‘ is equivalent to the statement: ‘We are certain that x will not be the case’. So saying that doesn’t exclude x from happening sounds just like a contradictio in terminis. For example, the chance that you throw a (normal) die and a 7 turns up*. But this is a silly example, because everybody agrees that the chance of this happening is 0 and also that it is impossible. But now, consider the following game: we flip a coin until heads turns up. Is it possible that this game never ends? To me, it’s not. Of course, it could take arbitrarily long, but it can’t take an infinite number of flips. Can it? Another example. If we pick a random number N, the chance that we we would have picked this number beforehand, is clearly equal to 0. You might argue that this implies I’m wrong, because apparently something happenend which had a chance of 0. To me this just implies that it’s not possible to choose a number randomly. As a last example, a problem I (sort of) solved a while ago; An invisible submarine travels along the (integral) number line. It starts at some unknown integer x and every second it travels with a constant unknown velocity y integers. You are aloud to shoot your canon every second at a number. If one of your canon balls and the submarine meet each other at the same time and place, you sank the sub and you won. Devise a strategy that guarantees that you will sink the sub. My solution: let be the n-th prime. At second n, shoot at a random integer in the interval . It’s not hard to show that this strategy will sink the sub with probability 1. This solution was definitely not the intended solution. And not because it’s not applicable to similar questions and the ‘average shooting time’ is a lot longer that the normal solution, but because it’s not deterministic. So I got the criticism that my solution doesn’t solve the problem, because it doesn’t guarantee that I eventually sink the sub, I can only guarentee a chance of 100, which isn’t enough. While I kind of expected this reply, it still confused me. How could it ever be possible that we will never hit the sub, while the chance is 1? How how how? *maybe it actually could happen by some weird quantum effect, but mathematically speaking, it’s not an issue PS. Terry Tao is going to set up another mini-Polymath Project next month. Check it out. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45580")[#strong[#text("Nothing is impossible (?) « Woett's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2010")]

#text("[…] PS. Terry Tao is going to set up another mini-Polymath Project next month. Check it out. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Organising mini-polymath2 « What’s new")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45614")[#strong[#text("Organising mini-polymath2 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2010")])]

#text("[…] June, 2010 in Uncategorized | by Terence Tao This is a continuation of the preceding post regarding the setting up of the mini-polymath2 project. From the discussion, it seems that it is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45643")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2010")])]

#text("Where do IMO problems like these come from? Last year’s IMO6 is an additive combinatorics problem. It is about ordering a sequence of numbers so their partial sums avoid a given set. Do mathematicians study this type of “avoidance”? Also, I wonder if there is probabilistic proof…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/814f017f375292b2cad17d0ad5af80f334ab12960ef2e2c626a1ef65c8efcb81-de6d24f505a07a8e8ea59a014cd97cf0662c533f58f2aa0694ed018e671ec8ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dora")]], [#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45806")[#strong[#text("Dora")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2010")])]

#text("Wow! What a long post! It takes one and half Hours to read it. I’m Korean. Do you know Korea? I’m from south Korea. Although I’m just twelve years old, I want to solve that problem.")#linebreak()#text(" You will Know the feelings that when we solve hard problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/#comment-45839")[#strong[#text("Wiskundemeisjes » Blog Archive » Los samen met anderen een olympiade-opgave op!")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")]

#text("[…] Terences blog vind je meer informatie. « The geometry of […]")
]
