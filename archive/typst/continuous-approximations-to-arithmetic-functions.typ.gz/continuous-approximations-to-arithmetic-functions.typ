// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/
// Converted to Typst by tao2typ: "2026-10-14T16:38:13.752107+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Continuous approximations to arithmetic functions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Continuous approximations to arithmetic functions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 November 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/")[#text("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A basic object of study in multiplicative number theory are the ")#link("https://en.wikipedia.org/wiki/Arithmetic_function")[#text("arithmetic functions")]#text(": functions ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" from the natural numbers to the complex numbers. Some fundamental examples of such functions include")

#list(
[#text("The constant function ")#mi("{1: n \\mapsto 1}")#text(";")],
[#text("The ")#link("https://en.wikipedia.org/wiki/Kronecker_delta")[#text("Kronecker delta function")]#text(" ")#mi("{\\delta: n \\mapsto 1_{n=1}}")#text(";")],
[#text("The natural logarithm function ")#mi("{L: n \\mapsto \\log n}")#text(";")],
[#text("The ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(" ")#mi("{d_2: n \\mapsto \\sum_{d|n} 1}")#text(";")],
[#text("The ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda}")#text(", with ")#mi("{\\Lambda(n)}")#text(" defined to equal ")#mi("{\\log p}")#text(" when ")#mi("{n}")#text(" is a power ")#mi("{p^j}")#text(" of a prime ")#mi("{p}")#text(" for some ")#mi("{j \\geq 1}")#text(", and defined to equal zero otherwise; and")],
[#text("The ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu}")#text(", with ")#mi("{\\mu(n)}")#text(" defined to equal ")#mi("{(-1)^k}")#text(" when ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" distinct primes, and defined to equal zero otherwise.")]
)

#text("Given an arithmetic function ")#mi("{f}")#text(", we are often interested in statistics such as the summatory function ")#metadata(none) <tao-09f5ffef28309853265c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq x} f(n),")]]



#text(" the logarithmically (or harmonically) weighted summatory function ")#metadata(none) <tao-ec005930dcb5b5eaa6f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\frac{f(n)}{n},")]]



#text(" or the ")#link("https://en.wikipedia.org/wiki/Dirichlet_series")[#text("Dirichlet series")]

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}[f](s) := \\sum_n \\frac{f(n)}{n^s}.")]]

#text("In the latter case, one typically has to first restrict ")#mi("{s}")#text(" to those complex numbers whose real part is large enough in order to ensure the series on the right converges; but in many important cases, one can then extend the Dirichlet series to almost all of the complex plane by analytic continuation. One is also interested in correlations involving additive shifts, such as ")#mi("{\\sum_{n \\leq x} f(n) f(n+h)}")#text(", but these are significantly more difficult to study and cannot be easily estimated by the methods of classical multiplicative number theory.")

#text("A key operation on arithmetic functions is that of ")#link("https://en.wikipedia.org/wiki/Dirichlet_convolution")[#text("Dirichlet convolution")]#text(", which when given two arithmetic functions ")#mi("{f,g: {\\bf N} \\rightarrow {\\bf C}}")#text(", forms a new arithmetic function ")#mi("{f*g: {\\bf N} \\rightarrow {\\bf C}}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("f*g(n) := \\sum_{d|n} f(d) g(\\frac{n}{d}).")]]

#text("Thus for instance ")#mi("{1*1 = d_2}")#text(", ")#mi("{1 * \\Lambda = L}")#text(", ")#mi("{1 * \\mu = \\delta}")#text(", and ")#mi("{\\delta * f = f}")#text(" for any arithmetic function ")#mi("{f}")#text(". Dirichlet convolution and Dirichlet series are related by the fundamental formula ")#metadata(none) <tao-16ba121a04d5ad3b885f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\mathcal D}[f * g](s) = {\\mathcal D}[f](s) {\\mathcal D}[g](s),")]]



#text(" at least when the real part of ")#mi("{s}")#text(" is large enough that all sums involved become absolutely convergent (but in practice one can use analytic continuation to extend this identity to most of the complex plane). There is also the identity ")#metadata(none) <tao-5da9578e2d85fabb9599>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("{\\mathcal D}[Lf](s) = - \\frac{d}{ds} {\\mathcal D}[f](s),")]]



#text(" at least when the real part of ")#mi("{s}")#text(" is large enough to justify interchange of differentiation and summation. As a consequence, many Dirichlet series can be expressed in terms of the Riemann zeta function ")#mi("{\\zeta = {\\mathcal D}[1]}")#text(", thus for instance")

#tao-aligned(keep: true)[


#tao-math("{\\mathcal D}[d_2](s)  & = \\zeta^2(s)", block: true)



#tao-math("{\\mathcal D}[L](s)  & = - \\zeta^{\\prime}(s)", block: true)



#tao-math("{\\mathcal D}[\\delta](s)  & = 1", block: true)



#tao-math("{\\mathcal D}[\\mu](s)  & = \\frac{1}{\\zeta(s)}", block: true)



#tao-math("{\\mathcal D}[\\Lambda](s)  & = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}.", block: true)
]

#text("Much of the difficulty of multiplicative number theory can be traced back to the discrete nature of the natural numbers ")#mi("{{\\bf N}}")#text(", which form a rather complicated abelian semigroup with respect to multiplication (in particular the set of generators is the set of prime numbers). One can obtain a simpler analogue of the subject by working instead with the half-infinite interval ")#mi("{{\\bf N}_\\infty := [1,+\\infty)}")#text(", which is a much simpler abelian semigroup under multiplication (being a one-dimensional Lie semigroup). (I will think of this as a sort of “completion” of ")#mi("{{\\bf N}}")#text(" at the infinite ")#link("https://en.wikipedia.org/wiki/Place_(mathematics)")[#text("place")]#text(" ")#mi("{\\infty}")#text(", hence the terminology.) Accordingly, let us define a ")#emph[#text("continuous arithmetic function")]#text(" to be a locally integrable function ")#mi("{f: {\\bf N}_\\infty \\rightarrow {\\bf C}}")#text(". The analogue of the summatory function ")#link(<tao-09f5ffef28309853265c>)[#text("(1)")]#text(" is then an integral")

#align(center)[#tao-fit-display[#mitex("\\int_1^x f(t)\\ dt,")]]

#text("and similarly the analogue of ")#link(<tao-ec005930dcb5b5eaa6f0>)[#text("(2)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\int_1^x \\frac{f(t)}{t}\\ dt.")]]

#text("The analogue of the Dirichlet series is the ")#link("https://en.wikipedia.org/wiki/Mellin_transform")[#text("Mellin-type transform")]

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_\\infty[f](s) := \\int_1^\\infty \\frac{f(t)}{t^s}\\ dt,")]]

#text("which will be well-defined at least if the real part of ")#mi("{s}")#text(" is large enough and if the continuous arithmetic function ")#mi("{f: {\\bf N}_\\infty \\rightarrow {\\bf C}}")#text(" does not grow too quickly, and hopefully will also be defined elsewhere in the complex plane by analytic continuation.")

#text("For instance, the continuous analogue of the discrete constant function ")#mi("{1: {\\bf N} \\rightarrow {\\bf C}}")#text(" would be the constant function ")#mi("{1_\\infty: {\\bf N}_\\infty \\rightarrow {\\bf C}}")#text(", which maps any ")#mi("{t \\in [1,+\\infty)}")#text(" to ")#mi("{1}")#text(", and which we will denote by ")#mi("{1_\\infty}")#text(" in order to keep it distinct from ")#mi("{1}")#text(". The two functions ")#mi("{1_\\infty}")#text(" and ")#mi("{1}")#text(" have approximately similar statistics; for instance one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1 = \\lfloor x \\rfloor \\approx x-1 = \\int_1^x 1\\ dt")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1}{n} = H_{\\lfloor x \\rfloor} \\approx \\log x = \\int_1^x \\frac{1}{t}\\ dt")]]

#text("where ")#mi("{H_n}")#text(" is the ")#mi("{n^{th}}")#text(" ")#link("https://en.wikipedia.org/wiki/Harmonic_number")[#text("harmonic number")]#text(", and we are deliberately vague as to what the symbol ")#mi("{\\approx}")#text(" means. Continuing this analogy, we would expect")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}[1](s) = \\zeta(s) \\approx \\frac{1}{s-1} = {\\mathcal D}_\\infty[1_\\infty](s)")]]

#text("which reflects the fact that ")#mi("{\\zeta}")#text(" has a simple pole at ")#mi("{s=1}")#text(" with residue ")#mi("{1}")#text(", and no other poles. Note that the identity ")#mi("{{\\mathcal D}_\\infty[1_\\infty](s) = \\frac{1}{s-1}}")#text(" is initially only valid in the region ")#mi("{\\mathrm{Re} s > 1}")#text(", but clearly the right-hand side can be continued analytically to the entire complex plane except for the pole at ")#mi("{1}")#text(", and so one can define ")#mi("{{\\mathcal D}_\\infty[1_\\infty]}")#text(" in this region also.")

#text("In a similar vein, the logarithm function ")#mi("{L: {\\bf N} \\rightarrow {\\bf C}}")#text(" is approximately similar to the logarithm function ")#mi("{L_\\infty: {\\bf N}_\\infty \\rightarrow {\\bf C}}")#text(", giving for instance the crude form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} L(n) = \\log \\lfloor x \\rfloor! \\approx x \\log x - x = \\int_1^\\infty L_\\infty(t)\\ dt")]]

#text("of ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("Stirling’s formula")]#text(", or the Dirichlet series approximation")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}[L](s) = -\\zeta^{\\prime}(s) \\approx \\frac{1}{(s-1)^2} = {\\mathcal D}_\\infty[L_\\infty](s).")]]

#text("The continuous analogue of Dirichlet convolution is multiplicative convolution using the multiplicative Haar measure ")#mi("{\\frac{dt}{t}}")#text(": given two continuous arithmetic functions ")#mi("{f_\\infty, g_\\infty: {\\bf N}_\\infty \\rightarrow {\\bf C}}")#text(", one can define their convolution ")#mi("{f_\\infty *_\\infty g_\\infty: {\\bf N}_\\infty \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f_\\infty *_\\infty g_\\infty(t) := \\int_1^t f_\\infty(s) g_\\infty(\\frac{t}{s}) \\frac{ds}{s}.")]]

#text("Thus for instance ")#mi("{1_\\infty * 1_\\infty = L_\\infty}")#text(". A short computation using Fubini’s theorem shows the analogue")

#align(center)[#tao-fit-display[#mitex("D_\\infty[f_\\infty *_\\infty g_\\infty](s) = D_\\infty[f_\\infty](s) D_\\infty[g_\\infty](s)")]]

#text("of ")#link(<tao-16ba121a04d5ad3b885f>)[#text("(3)")]#text(" whenever the real part of ")#mi("{s}")#text(" is large enough that Fubini’s theorem can be justified; similarly, differentiation under the integral sign shows that ")#metadata(none) <tao-c5b0c71bd7997d9698ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("D_\\infty[L_\\infty f_\\infty](s) = -\\frac{d}{ds} D_\\infty[f_\\infty](s)")]]



#text(" again assuming that the real part of ")#mi("{s}")#text(" is large enough that differentiation under the integral sign (or some other tool like this, such as the Cauchy integral formula for derivatives) can be justified.")

#text("Direct calculation shows that for any complex number ")#mi("{\\rho}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{s-\\rho} = D_\\infty[ t \\mapsto t^{\\rho-1} ](s)")]]

#text("(at least for the real part of ")#mi("{s}")#text(" large enough), and hence by several applications of ")#link(<tao-c5b0c71bd7997d9698ae>)[#text("(5)")]

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(s-\\rho)^k} = D_\\infty[ t \\mapsto \\frac{1}{(k-1)!} t^{\\rho-1} \\log^{k-1} t ](s)")]]

#text("for any natural number ")#mi("{k}")#text(". This can lead to the following heuristic: if a Dirichlet series ")#mi("{D[f](s)}")#text(" behaves like a linear combination of poles ")#mi("{\\frac{1}{(s-\\rho)^k}}")#text(", in that")

#align(center)[#tao-fit-display[#mitex("D[f](s) \\approx \\sum_\\rho \\frac{c_\\rho}{(s-\\rho)^{k_\\rho}}")]]

#text("for some set ")#mi("{\\rho}")#text(" of poles and some coefficients ")#mi("{c_\\rho}")#text(" and natural numbers ")#mi("{k_\\rho}")#text(" (where we again are vague as to what ")#mi("{\\approx}")#text(" means, and how to interpret the sum ")#mi("{\\sum_\\rho}")#text(" if the set of poles is infinite), then one should expect the arithmetic function ")#mi("{f}")#text(" to behave like the continuous arithmetic function")

#align(center)[#tao-fit-display[#mitex("t \\mapsto \\sum_\\rho \\frac{c_\\rho}{(k_\\rho-1)!} t^{\\rho-1} \\log^{k_\\rho-1} t.")]]

#text("In particular, if we only have simple poles,")

#align(center)[#tao-fit-display[#mitex("D[f](s) \\approx \\sum_\\rho \\frac{c_\\rho}{s-\\rho}")]]

#text("then we expect to have ")#mi("{f}")#text(" behave like continuous arithmetic function")

#align(center)[#tao-fit-display[#mitex("t \\mapsto \\sum_\\rho c_\\rho t^{\\rho-1}.")]]

#text("Integrating this from ")#mi("{1}")#text(" to ")#mi("{x}")#text(", this heuristically suggests an approximation")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} f(n) \\approx \\sum_\\rho c_\\rho \\frac{x^\\rho-1}{\\rho}")]]

#text("for the summatory function, and similarly")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{f(n)}{n} \\approx \\sum_\\rho c_\\rho \\frac{x^{\\rho-1}-1}{\\rho-1},")]]

#text("with the convention that ")#mi("{\\frac{x^\\rho-1}{\\rho}}")#text(" is ")#mi("{\\log x}")#text(" when ")#mi("{\\rho=0}")#text(", and similarly ")#mi("{\\frac{x^{\\rho-1}-1}{\\rho-1}}")#text(" is ")#mi("{\\log x}")#text(" when ")#mi("{\\rho=1}")#text(". One can make these sorts of approximations more rigorous by means of ")#link("https://en.wikipedia.org/wiki/Perron%27s_formula")[#text("Perron’s formula")]#text(" (or one of its variants) combined with the residue theorem, provided that one has good enough control on the relevant Dirichlet series, but we will not pursue these rigorous calculations here. (But see for instance ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("this previous blog post")]#text(" for some examples.)")

#text("For instance, using the more refined approximation")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) \\approx \\frac{1}{s-1} + \\gamma")]]

#text("to the zeta function near ")#mi("{s=1}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}[d_2](s) = \\zeta^2(s) \\approx \\frac{1}{(s-1)^2} + \\frac{2 \\gamma}{s-1}")]]

#text("we would expect that")

#align(center)[#tao-fit-display[#mitex("d_2 \\approx L_\\infty + 2 \\gamma")]]

#text("and thus for instance")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} d_2(n) \\approx x \\log x - x + 2 \\gamma x")]]

#text("which matches what one actually gets from the Dirichlet hyperbola method (see e.g. equation (44) of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("this previous post")]#text(").")

#text("Or, noting that ")#mi("{\\zeta(s)}")#text(" has a simple pole at ")#mi("{s=1}")#text(" and assuming simple zeroes elsewhere, the log derivative ")#mi("{-\\zeta^{\\prime}(s)/\\zeta(s)}")#text(" will have simple poles of residue ")#mi("{+1}")#text(" at ")#mi("{s=1}")#text(" and ")#mi("{-1}")#text(" at all the zeroes, leading to the heuristic")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}[\\Lambda](s) = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} \\approx \\frac{1}{s-1} - \\sum_\\rho \\frac{1}{s-\\rho}")]]

#text("suggesting that ")#mi("{\\Lambda}")#text(" should behave like the continuous arithmetic function")

#align(center)[#tao-fit-display[#mitex("t \\mapsto 1 - \\sum_\\rho t^{\\rho-1}")]]

#text("leading for instance to the summatory approximation")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\approx x - \\sum_\\rho \\frac{x^\\rho-1}{\\rho}")]]

#text("which is a heuristic form of the Riemann-von Mangoldt explicit formula (see Exercise 45 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("these notes")]#text(" for a rigorous version of this formula).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Go through some of the other explicit formulae listed at ")#link("https://en.wikipedia.org/wiki/Explicit_formulae_(L-function)")[#text("this Wikipedia page")]#text(" and give heuristic justifications for them (up to some lower order terms) by similar calculations to those given above.")
]

#text("Given the “")#link("https://en.wikipedia.org/wiki/Adele_ring")[#text("adelic")]#text("” perspective on number theory, I wonder if there are also ")#mi("{p}")#text("-adic analogues of arithmetic functions to which a similar set of heuristics can be applied, perhaps to study sums such as ")#mi("{\\sum_{n \\leq x: n = a \\text{ mod } p^j} f(n)}")#text(". A key problem here is that there does not seem to be any good interpretation of the expression ")#mi("{\\frac{1}{t^s}}")#text(" when ")#mi("{s}")#text(" is complex and ")#mi("{t}")#text(" is a ")#mi("{p}")#text("-adic number, so it is not clear that one can analyse a Dirichlet series ")#mi("{p}")#text("-adically. For similar reasons, we don’t have a canonical way to define ")#mi("{\\chi(t)}")#text(" for a Dirichlet character ")#mi("{\\chi}")#text(" (unless its conductor happens to be a power of ")#mi("{p}")#text("), so there doesn’t seem to be much to say in the ")#mi("{q}")#text("-aspect either.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488635")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("There must be a typo in the equation after the mention of Fubini’s theorem, cause the LHS and RHS are identical. I guess you meant to swap f and g.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488636")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("More likely, he wanted to show that the Mellin transform takes the convolution of two functions to products in the frequency space.")

#emph[#text("[Yes, this is now corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488637")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("Is there a systematic way to convert the heuristic equivalencies to rigorous statements? I know how to individually do some of them, but I’m having a hard time seeing if there’s a more general point of view which let’s one see, for example, the explicit formula for the Chebyshev function and the summatory function asymptotics for the divisor function by Dirichlet’s hyberbola method as the application of the same technique for rigorizing these heuristics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488641")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("It’s not a single technique, but rather a choice between “physical space” techniques (such as the hyperbola method) that involve manipulating sums over spatial variables such as ")#mi("n")#text(", and “frequency space” techniques (such as contour shifting) that involve manipulating integrals over frequency variables such as ")#mi("s")#text(" (or the imaginary part ")#mi("t")#text(" of ")#mi("s")#text("). In principle, Perron’s formula and its relatives allow one to move back and forth between physical space and frequency space, and so any physical space argument ought to have a frequency space counterpart and vice versa. However, some notions that are easy to understand and use in one space are difficult to use in the other; for instance, positivity of an arithmetic function is easy to see on the physical space side but difficult to discern from looking at the Dirichlet series, and conversely zeroes of a Dirichlet series are hard to see in physical space. Furthermore, there is not a clean equivalence between error term estimates in physical space and error term estimates in frequency space, with the important exception of ")#mi("L^2")#text(" type error estimates in which Parseval’s identity (or Plancherel’s theorem) becomes available. So one often has to make tactical decisions as to what parts of the argument should be conducted in physical space and what parts should be conducted in frequency space. Nevertheless, on a heuristic level, and ignoring the issue of obtaining optimal control on error terms, the two families of approaches are morally equivalent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488642")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("Sort of like we have a simple criterion for a function to have its Fourier transform in L2 but not in L1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488675")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2017")])]

#text("Thanks for the response!")

#text("Is there any textbook / course notes / survey that explicitly takes a Fourier viewpoint like this, rather than couching all the theorems in the classical viewpoint (i.e. complex analysis)? I’m not sure if the question is even well-formed, since I understand you can prove the same results with both techniques.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488681")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2017")])]

#text("There is a some emphasis on Fourier transforms in my Analytic Number Theory ")#link("https://www.math.ubc.ca/~lior/teaching/1516/539_W16/539_notes.pdf")[#text("lecture notes")]#text(". Chapters 1-3 should be ok (bonus points if you report errors); please ignore Chapters 4,5 which are incomplete sketches.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488742")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2017")])]

#text("Thank you!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488709")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("I made some notes on this regarding Fourier perspectives on the prime number theorem at ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/prime.dvi")[#text("http://www.math.ucla.edu/~tao/preprints/Expository/prime.dvi")]#text(" . I found though it was ultimately more useful (particularly when working with more classically trained analytic number theorists) to try to transfer my Fourier-analytic intuition to the complex variable language, rather than replace complex analytic arguments with their Fourier analogues.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488743")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2017")])]

#text("Thanks!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488653")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("There are some ")#mi("p")#text("-adic analogues. You may want to look at ")#link("https://en.wikipedia.org/wiki/Igusa_zeta-function")[#text("Igusa’s zetafunction")]#text(" for one example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488708")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("On the list of Dirichlet series after (4), the one for the von Mangoldt function is missing the argument s on the LHS.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f449649ee72aacb2a1bebb13b00532f0d6edf19f93054a8f037494fefc9365f-e6eabfd6cf52e8405b36520df83897941bd673491e3a3b4800c445f3f22b1b7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lionel")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488712")[#strong[#text("Lionel")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("A typo ")#mi("x=\\int_1^x 1\\ dt")#text(" ;-)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/299ba58fa862b9260b304953e86b347c200c90d6a5717c106eec4cf7f4db8e14-8900a71c6070f4c47b848a25732153b179ae118fa56043613d900955f09419e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of charlie")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488798")[#strong[#text("charlie")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2017")])]

#text("Hey I finally understand one!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488811")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2017")])]

#text("To get “adelic” analogues, one could try replacing")

#enum(start: 1, 
[#mi("\\mathbf{N}")#text(",")],
[#mi("\\mathbf{N}_{\\infty} := \\mathbf{R}_{\\geq 1}")#text(",")],
[#tao-math("\\{\\left|.\\right|^s : s \\in \\mathbb{C}\\}", block: false)#text(" and")],
[#text("the inclusion map")#linebreak()#text(" ")#mi("\\mathbf{N} \\rightarrow \\mathbf{N}_{\\infty}")]
)

#text("with")

#enum(start: 1, 
[#mi("\\mathbf{N}^{(q)} := \\{n \\in \\mathbf{N} : (n,q) = 1\\}")#text(",")],
[#mi("\\mathbf{N}^{(q)}_{\\infty} := \\mathbf{R}_{\\geq 1} \\times (\\mathbf{Z}/q)^\\times")#text(",")],
[#tao-math("\\{\\left|.\\right|^s \\otimes \\chi : s \\in \\mathbb{C}, \\chi \\text{ a Dirichlet character mod } q\\}", block: false)#text(" and")],
[#text("the diagonal map ")#mi("\\mathbf{N}^{(q)} \\rightarrow \\mathbf{N}^{(q)}_{\\infty}")]
)

#text("and then define Dirichlet series ")#mi("\\mathcal{D}[f](s,\\chi)")#text(" and Mellin transforms ")#mi("\\mathcal{D}_{\\infty}[f](s,\\chi)")#text(" as in the post. One could then take inverse limits (e.g., over powers of ")#mi("q")#text(") and work ")#mi("S")#text("-arithmetically or adelically, but I’m not sure what that would add.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1fba2dec28a8e4d1b233936bebc595cd57eed616c23c66e67cdd0a6868dcccd6-04332b5676c7228a89c28b23c08139b9deb4335ef00954c67491155f5e2be8b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488817")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2017")])]

#text("I think that Tate’s thesis ( e.g. equation (22) in ")#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/")[#text("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/")]#text(" ) gives some insight here.")

#text("Begin by replacing ")#mi("\\mathbb{N}_\\infty")#text(" with ")#mi("\\mathbb{N}_p := \\mathbb{Z}_p \\setminus \\{0\\}")#text(" where ")#mi("\\mathbb{Z}_p")#text(" are the usual ")#mi("p")#text("-adics and ")#mi("1_p")#text(" defined to the the characteristic function on this set. Define multiplicative convolution ")#mi("*_p")#text(" by")

#tao-math("\\displaystyle f *_p g(s) := \\int_{\\left|s\\right|_p \\leq \\left|t\\right|_p \\leq 1} f(t)g(s/t) d^\\times t", block: false)

#text("where ")#mi("|\\cdot|_p")#text(" denotes the ")#mi("p")#text("-adic norm with normalization so that ")#tao-math("\\left|p\\right|_p := p^{-1}", block: false)#text(" and ")#mi("d^\\times t")#text(" is the multiplicative Haar measure on ")#mi("\\mathbb{Q}_p^\\times")#text(" normalized so that")

#tao-math("\\displaystyle d^\\times t := \\frac{p}{p-1} \\cdot \\frac{dt}{\\left|t\\right|_p}", block: false)

#text("with ")#mi("dt")#text(" denoting the Haar measure on ")#mi("\\mathbb{Q}_p")#text(" normalized so that ")#mi("\\mathbb{Z}_p")#text(" has measure 1.")

#text("Claim: ")#mi("1_p *_p 1_p = L_p")#text(" where ")#tao-math("L_p(y) := -\\log_p \\left|y\\right|_p", block: false)#text(" for ")#mi("y \\in \\mathbb{N}_p")#text(".")

#text("This follows from the computation that")

#tao-math("\\displaystyle \\int_{\\left|t\\right|_p = p^{-A}} 1_p(t) 1_p(s/t) d^\\times t = 1", block: false)

#text("for each ")#mi("A")#text(" such that ")#tao-math("1 \\geq p^{-A} \\geq \\left|s\\right|_p", block: false)#text(".")

#text("Remark: Initially it seemed to me that the condition ")#tao-math("\\left|s\\right|_p \\leq \\left|t\\right|_p \\leq 1", block: false)#text(" in the definition of convolution is wrong since it reverses the Archimedean one ")#tao-math("\\left|s\\right|_\\infty \\geq \\left|t\\right|_\\infty \\geq 1", block: false)#text(". However, it makes sense since on ")#mi("\\mathbb{N}_p")#text(" the norm is at most one instead of growing on ")#mi("\\mathbb{N}_\\infty")#text(". This also accounts for the minus sign in the definition of ")#mi("L_p")#text(".")

#text("Carrying on, we define the Mellin type transform as above:")

#tao-math("\\displaystyle D_p[f](s) := \\int_{\\left|s\\right|_p \\leq \\left|t\\right|_p \\leq 1} f(t)\\left|t\\right|_p^{-s} d^\\times t.", block: false)

#text("I don’t have the time to follow through at the moment, but this feels like the way forward to me…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-488897")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("The natural analogue of a Dirichlet series of an arithmetic function ")#mi("f: {\\bf N} \\to {\\bf C}")#text(" over a p-adic place would be ")#tao-math("{\\mathcal D}_p[f](s_p) := \\sum_n \\frac{f(n)}{\\left|n\\right|_p^{s_p}}", block: false)#text(", but this usually diverges for every ")#mi("s_p \\in {\\bf C}")#text(", so one probably has to work with a hybrid of p-adic places and the place at infinity, e.g.")

#tao-math("\\displaystyle {\\mathcal D}_{\\infty,p}[f](s_\\infty,s_p) := \\sum_n \\frac{f(n)}{\\left|n\\right|_\\infty^{s_\\infty} \\left|n_p\\right|^{s_p}}.", block: false)

#text("This generalises the usual Dirichlet series which corresponds to the case ")#mi("s_p=0")#text(". One could also work with multiple primes ")#mi("p")#text(" rather than a single prime, but I think this is already illustrative. For instance, the ")#mi("\\infty,p")#text(" Dirichlet series of ")#mi("1")#text(" is")

#mi("\\displaystyle {\\mathcal D}_{\\infty,p}[1](s_\\infty,s_p) = \\zeta(s_\\infty) (1-\\frac{1}{p^{s_\\infty}}) (1-\\frac{1}{p^{s_\\infty-s_p}}).")

#text("One still has good behaviour with respect to Dirichlet convolution:")

#mi("\\displaystyle {\\mathcal D}_{\\infty,p}[f*g](s_\\infty,s_p) = {\\mathcal D}_{\\infty,p}[f](s_\\infty,s_p) {\\mathcal D}_{\\infty,p}[g](s_\\infty,s_p).")

#text("Presumably, continuous counterparts come from functions on ")#mi("{\\bf N}_\\infty \\times {\\bf N}_p")#text(" using a two-variable Mellin type transform")

#tao-math("\\displaystyle {\\mathcal D}_{\\infty,p}[f](s_\\infty,s_p) = \\int_{{\\bf N}_\\infty \\times {\\bf N}_p} f(x,y) \\left|x\\right|_\\infty^{-s_\\infty} \\left|y\\right|_p^{-s_p} dx dy,", block: false)

#text("but I haven’t computed this carefully to see what it gives as far as heuristic predictions are concerned (presumably it makes predictions for sums like ")#mi("\\sum_{n \\leq x: p^j |n} f(n)")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cac5ea8ff9882c9ea2f5d7a06a0e5a63dfbfb69b69ffaa26099a2bb46209b75-f7cbe2c3b89fd2ab09916943359549441c87132826b91ab5aa38ed7af4f4d5ed.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mallesham kummari")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-489134")[#strong[#text("mallesham kummari")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2017")])]

#text("Using the estimates ")#mi("\\sum_{n \\leq x} \\frac {\\Lambda(n) } {n} \\sim \\log{x}")#text(" and ")#mi("\\sum_{n \\leq x} \\frac {\\Lambda(n) } {n} \\approx \\log{x} - \\sum_{\\rho} \\frac{x^{\\rho -1} -1}{ \\rho -1}")#text(", can one conclude that Riemann zeta function does not vanish on the line ")#mi("Re(s) =1")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-489225")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2017")])]

#text("Not quite: if one only has a single pair of zeroes ")#mi("1+it, 1-it")#text(" then the two ")#mi("\\frac{x^{\\rho-1}-1}{\\rho-1}")#text(" terms in the sum will end up being only ")#mi("O(1)")#text(" and thus negligible compared to the ")#mi("\\log x")#text(" main term (or the existing ")#mi("O(1)")#text(" error term).")

#text("However, the Erdos-Selberg proof of the prime number theorem can be interpreted somewhat along these lines, but working with ")#mi("\\sum_{n \\leq x} \\Lambda_2(x)")#text(" rather than ")#mi("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n}")#text(". I discuss this at ")#link("https://mathoverflow.net/questions/259698/ideas-in-the-elementary-proof-of-the-prime-number-theorem-selberg-erd%C5%91s/259719#259719")[#text("https://mathoverflow.net/questions/259698/ideas-in-the-elementary-proof-of-the-prime-number-theorem-selberg-erd%C5%91s/259719#259719")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d188e8a4b98e52e7f60556353102fd436bf2240777b5d809927e7edb7c8ea6e-1e29daa8adbc1faba2abda6add320c98d228e44be8fa4cef2623bea7e9e05d94.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Caceres")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-489349")[#strong[#text("Pedro Caceres")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2017")])]

#text("The Harmonic function can be expressed as a function of any z*=1/2+ßi non-trivial zero of Zeta in the critical line. The expression is the following and is valid for all z*:")

#text("X(n) = n/(ß^2+(1-α)^2)) for α=1/2")#linebreak()#text(" O(n) = ∑(k=1)^n ∑(j≠k)^n (k^(-1/2)*j^(-1/2)*cos(ß*(ln(k/j))")#linebreak()#text(" H(n) = ∑(k=1)^n (1/k)")

#text("Then:")

#text("H(n) = X(n) – O(n) for all z*=1/2+ßi non-trivial zero of zeta")

#text("This is easily to see graphically as H(n)+O(n) = X(n) is a straight line as n->infinity, and actually it happens very quickly after n>100. You can see that at:")

#link("https://drive.google.com/open?id=1c--u6CJR2Rj4p8YmSteaYbWdNTaztdvS")[#text("https://drive.google.com/open?id=1c–u6CJR2Rj4p8YmSteaYbWdNTaztdvS")]

#text("For values of α 1/2, H(n)+O(n) is always a curve, some examples:")

#link("https://drive.google.com/open?id=1zHy-C3UM89IRK5Q4SQiCszx_-VeD3T1M")[#text("https://drive.google.com/open?id=1zHy-C3UM89IRK5Q4SQiCszx_-VeD3T1M")]

#link("https://drive.google.com/open?id=1x1OlpuDBzvKGeV_CiDgWIZEyZYm1ARoI")[#text("https://drive.google.com/open?id=1x1OlpuDBzvKGeV_CiDgWIZEyZYm1ARoI")]

#text("It seems like the “music of the primes shuts down at the non-trivial zeros”, the waves become a straight line.")

#text("As a corollary, all non-trivial zeros of zeta can be linked algebraically by the following expression.")

#text("if z1=1/2+i*ß1 , z2=1/2+i*ß2 are non-trivial zeros, then:")

#text("X(n,z) = n/(ß^2+(1-α)^2)")#linebreak()#text(" O(n,z) = ∑(k=1)^n ∑(j≠k)^n (k^(-1/2)*j^(-1/2)*cos(ß*(ln(k/j))")

#text("then X(n,z1)+O(n,z1) = X(n,z2)+O(n,z2)")

#text("I have developed a Python code to find all non-trivial zeros knowing that z1=1/2+14.13472514173469379*I and it works well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d188e8a4b98e52e7f60556353102fd436bf2240777b5d809927e7edb7c8ea6e-1e29daa8adbc1faba2abda6add320c98d228e44be8fa4cef2623bea7e9e05d94.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Caceres")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-489355")[#strong[#text("Pedro Caceres")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2017")])]

#text("As acontinuation of the previous post,")

#text("H(n) = + n/(ß^2+0.25) – sum_(k=1)^n (2*sum_(j=k+1)^n (k^(-1/2)*j^(-1/2)*cos(ß*ln(k/j))))")

#text("for those of you that like WolframAlfa, you can try this approximation (for a very low n=20 as WolframAlfa does not want to work for higher values on n):")

#text("1) for ß=14.134725, n=20")

#text("****** 20/(ß^2+0.25)-H(20) = 20/(ß^2+0.25)-sum_(k-1)^n (1/k) = -3.49776")#linebreak()#text(" ****** sum_(k=1)^n (2*sum_(j=k+1)^n (k^(-1/2)*j^(-1/2)*cos(ß*ln(k/j)))) = -3.491098")

#text("1) for ß=37.586178, n=20")

#text("***** 20/(ß^2+0.25)-H(20) = 20/(ß^2+0.25)-sum_(k-1)^n (1/k) = -3.58359")#linebreak()#text(" ***** sum_(k=1)^n (2*sum_(j=k+1)^n (k^(-1/2)*j^(-1/2)*cos(ß*ln(k/j)))) = -3.57838")

#text("with n>500, the error is less than 0.0001.")

#text("You can see more results at:")

#link("https://drive.google.com/open?id=1t2k690rHr0zes5YrS1dvF7ZWFP1PxEEx")[#text("https://drive.google.com/open?id=1t2k690rHr0zes5YrS1dvF7ZWFP1PxEEx")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/670b4434f8ccadf4db097d7f7bfcc861a90c9823e1c7222786c739b110a6e5c7-5a5b98e17c9a17c20630f6a2187db352ca441339070c06f04040d52629aa4c85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Occasional corrector")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-489468")[#strong[#text("Occasional corrector")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2017")])]

#text("Dear Prof. Tao,")

#text("I’d like to thank you for always correcting the mistakes that I may find. I’ve witnessed that occasionally, people react very reluctantly to corrections of all sorts, but I found that those who are the best in their subject will include corrections, because no-one can hurt their scientific reputation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a329a29a85e9df2cb0ed0f8acc5f45348caa439a9f57206b6c73d921408d02b-dfb59d08392ca67171f8f28cfe7955258a3428ff6a009b5230b4959b23199f8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Catalin T.")]], [#link("https://terrytao.wordpress.com/2017/11/09/continuous-approximations-to-arithmetic-functions/#comment-506730")[#strong[#text("Catalin T.")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2018")])]

#text("Dear Prof. Tao,")

#text("I have a question on prime zeta function approximations")#linebreak()#text(" ")#mi("\\displaystyle P(s) = \\sum_{k=1}^{\\infty} \\frac{1}{p_k^s}")

#text("Have you encountered in the math literature one that resembles the following")#linebreak()#text(" ")#mi("\\displaystyle  P(s) = \\zeta(s)-1-\\frac{\\zeta(s)}{\\log{}(2)}\\log{}(\\frac{\\frac{1}{2}(\\zeta(s)^2+\\zeta(2s))}{\\zeta(s)}) + \\mathcal{O}(c^{-s}), \\Re(s)\\textgreater 1, c\\geq 2")

#text("Thanks,")#linebreak()#text(" Catalin")
]
