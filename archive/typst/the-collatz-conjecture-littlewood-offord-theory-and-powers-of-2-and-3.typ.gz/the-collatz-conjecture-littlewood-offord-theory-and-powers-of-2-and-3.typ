// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/
// Converted to Typst by tao2typ: "2026-10-14T09:19:27.529981+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 August 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/")[#text("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the most notorious problems in elementary mathematics that remains unsolved is the ")#link("http://en.wikipedia.org/wiki/Collatz_conjecture")[#text("Collatz conjecture")]#text(", concerning the function ")#mi("{f_0: {\\bf N} \\rightarrow {\\bf N}}")#text(" defined by setting ")#mi("{f_0(n) := 3n+1}")#text(" when ")#mi("{n}")#text(" is odd, and ")#mi("{f_0(n) := n/2}")#text(" when ")#mi("{n}")#text(" is even. (Here, ")#mi("{{\\bf N}}")#text(" is understood to be the positive natural numbers ")#mi("{\\{1,2,3,\\ldots\\}}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Collatz conjecture)")]#text(" ")#metadata(none) <tao-d1a73570aa079cee4251>#text(" For any given natural number ")#mi("{n}")#text(", the orbit ")#mi("{n, f_0(n), f^2_0(n), f^3_0(n), \\ldots}")#text(" passes through ")#mi("{1}")#text(" (i.e. ")#mi("{f^k_0(n)=1}")#text(" for some ")#mi("{k}")#text(").")
]

#text("Open questions with this level of notoriety can lead to what Richard Lipton calls “")#link("http://rjlipton.wordpress.com/2009/11/04/on-mathematical-diseases/")[#text("mathematical diseases")]#text("” (and what I termed an ")#link("https://terrytao.wordpress.com/career-advice/dont-prematurely-obsess-on-a-single-big-problem-or-big-theory/")[#text("unhealthy amount of obsession on a single famous problem")]#text("). (See also ")#link("http://xkcd.com/710/")[#text("this xkcd comic")]#text(" regarding the Collatz conjecture.) As such, most practicing mathematicians tend to spend the majority of their time on more productive research areas that are ")#link("https://terrytao.wordpress.com/career-advice/continually-aim-just-beyond-your-current-range/")[#text("only just beyond the range of current techniques")]#text(". Nevertheless, it can still be diverting to spend a day or two each year on these sorts of questions, before returning to other matters; so I recently had a go at the problem. Needless to say, I didn’t solve the problem, but I have a better appreciation of why the conjecture is (a) plausible, and (b) unlikely be proven by current technology, and I thought I would share what I had found out here on this blog.")

#text("Let me begin with some very well known facts. If ")#mi("{n}")#text(" is odd, then ")#mi("{f_0(n) = 3n+1}")#text(" is even, and so ")#mi("{f_0^2(n) = \\frac{3n+1}{2}}")#text(". Because of this, one could replace ")#mi("{f_0}")#text(" by the function ")#mi("{f_1: {\\bf N} \\rightarrow {\\bf N}}")#text(", defined by ")#mi("{f_1(n) = \\frac{3n+1}{2}}")#text(" when ")#mi("{n}")#text(" is odd, and ")#mi("{f_1(n)=n/2}")#text(" when ")#mi("{n}")#text(" is even, and obtain an equivalent conjecture. Now we see that if one chooses ")#mi("{n}")#text(" “at random”, in the sense that it is odd with probability ")#mi("{1/2}")#text(" and even with probability ")#mi("{1/2}")#text(", then ")#mi("{f_1}")#text(" increases ")#mi("{n}")#text(" by a factor of roughly ")#mi("{3/2}")#text(" half the time, and decreases it by a factor of ")#mi("{1/2}")#text(" half the time. Furthermore, if ")#mi("{n}")#text(" is uniformly distributed modulo ")#mi("{4}")#text(", one easily verifies that ")#mi("{f_1(n)}")#text(" is uniformly distributed modulo ")#mi("{2}")#text(", and so ")#mi("{f_1^2(n)}")#text(" should be roughly ")#mi("{3/2}")#text(" times as large as ")#mi("{f_1(n)}")#text(" half the time, and roughly ")#mi("{1/2}")#text(" times as large as ")#mi("{f_1(n)}")#text(" the other half of the time. Continuing this at a heuristic level, we expect generically that ")#mi("{f_1^{k+1}(n) \\approx \\frac{3}{2} f_1^k(n)}")#text(" half the time, and ")#mi("{f_1^{k+1}(n) \\approx \\frac{1}{2} f_1^k(n)}")#text(" the other half of the time. The logarithm ")#mi("{\\log f_1^k(n)}")#text(" of this orbit can then be modeled heuristically by a random walk with steps ")#mi("{\\log \\frac{3}{2}}")#text(" and ")#mi("{\\log \\frac{1}{2}}")#text(" occuring with equal probability. The expectation")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\log \\frac{3}{2} + \\frac{1}{2} \\log \\frac{1}{2} = \\frac{1}{2} \\log \\frac{3}{4}")]]

#text("is negative, and so (by the classic ")#link("http://en.wikipedia.org/wiki/Gambler's_ruin")[#text("gambler’s ruin")]#text(") we expect the orbit to decrease over the long term. This can be viewed as heuristic justification of the Collatz conjecture, at least in the “average case” scenario in which ")#mi("{n}")#text(" is chosen uniform at random (e.g. in some large interval ")#mi("{\\{1,\\ldots,N\\}}")#text("). (It also suggests that if one modifies the problem, e.g. by replacing ")#mi("{3n+1}")#text(" to ")#mi("{5n+1}")#text(", then one can obtain orbits that tend to increase over time, and indeed numerically for this variant one sees orbits that appear to escape to infinity.) Unfortunately, one can only rigorously keep the orbit uniformly distributed modulo ")#mi("{2}")#text(" for time about ")#mi("{O(\\log N)}")#text(" or so; after that, the system is too complicated for naive methods to control at anything other than a heuristic level.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can obtain a rigorous analogue of the above arguments by extending ")#mi("{f_1}")#text(" from the integers ")#mi("{{\\bf Z}}")#text(" to the ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#mi("{2}")#text("-adics")]#text(" ")#mi("{{\\bf Z}_2}")#text(". This compact abelian group comes with a ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar probability measure")]#text(", and one can verify that this measure is invariant with respect to ")#mi("{f_1}")#text("; with a bit more effort one can verify that it is ergodic. This suggests the introduction of ergodic theory methods. For instance, using the ")#link("http://en.wikipedia.org/wiki/Ergodic_theory#Probabilistic_formulation:_Birkhoff.E2.80.93Khinchin_theorem")[#text("pointwise ergodic theorem")]#text(", we see that if ")#mi("{n}")#text(" is a random ")#emph[#mi("{2}")#text("-adic")]#text(" integer, then almost surely the orbit ")#mi("{n, f_1(n), f_1^2(n), \\ldots}")#text(" will be even half the time and odd half the time asymptotically, thus supporting the above heuristics. Unfortunately, this does not directly tell us much about the dynamics on ")#mi("{{\\bf Z}}")#text(", as this is a measure zero subset of ")#mi("{{\\bf Z}_2}")#text(". More generally, unless a dynamical system is somehow “polynomial”, “nilpotent”, or “unipotent” in nature, the current state of ergodic theory is usually only able to say something meaningful about ")#emph[#text("generic")]#text(" orbits, but not about ")#emph[#text("all")]#text(" orbits. For instance, the very simple system ")#mi("{x \\rightarrow 10x}")#text(" on the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" is well understood from ergodic theory (in particular, almost all orbits will be uniformly distributed), but the orbit of a specific point, e.g. ")#mi("{\\pi\\text{ mod } 1}")#text(", is still nearly impossible to understand (this particular problem being equivalent to the notorious unsolved question of whether the digits of ")#mi("{\\pi}")#text(" are uniformly distributed).")
]

#text("The above heuristic argument only suggests decreasing orbits for ")#emph[#text("almost all")]#text(" ")#mi("{n}")#text(" (though even this remains unproven, the state of the art is that the number of ")#mi("{n}")#text(" in ")#mi("{\\{1,\\ldots,N\\}}")#text(" that eventually go to ")#mi("{1}")#text(" is ")#mi("{\\gg N^{0.84}}")#text(", a ")#link("http://www.ams.org/mathscinet-getitem?mr=1980260")[#text("result of Krasikov and Lagarias")]#text("). It leaves open the possibility of some very rare exceptional ")#mi("{n}")#text(" for which the orbit goes to infinity, or gets trapped in a periodic loop. Since the only loop that ")#mi("{1}")#text(" lies in is ")#mi("{1,4,2}")#text(" (for ")#mi("{f_0}")#text(") or ")#mi("{1,2}")#text(" (for ")#mi("{f_1}")#text("), we thus may isolate a weaker consequence of the Collatz conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Weak Collatz conjecture)")]#text(" ")#metadata(none) <tao-dbef5168c52de4091a09>#text(" Suppose that ")#mi("{n}")#text(" is a natural number such that ")#mi("{f^k_0(n)=n}")#text(" for some ")#mi("{k \\geq 1}")#text(". Then ")#mi("{n}")#text(" is equal to ")#mi("{1}")#text(", ")#mi("{2}")#text(", or ")#mi("{4}")#text(".")
]

#text("Of course, we may replace ")#mi("{f_0}")#text(" with ")#mi("{f_1}")#text(" (and delete “")#mi("{4}")#text("“) and obtain an equivalent conjecture.")

#text("This weaker version of the Collatz conjecture is also unproven. However, it was observed ")#link("http://www.ams.org/mathscinet-getitem?mr=551509")[#text("by Bohm and Sontacchi")]#text(" that this weak conjecture is equivalent to a divisibility problem involving powers of ")#mi("{2}")#text(" and ")#mi("{3}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3 (Reformulated weak Collatz conjecture)")]#text(" ")#metadata(none) <tao-7b993dec18383a0f2312>#text(" There does not exist ")#mi("{k \\geq 1}")#text(" and integers")

#align(center)[#tao-fit-display[#mitex("0 = a_1 < a_2 < \\ldots < a_{k+1}")]]

#text("such that ")#mi("{2^{a_{k+1}}-3^k}")#text(" is a positive integer that is a proper divisor of")

#align(center)[#tao-fit-display[#mitex("3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k},")]]

#text("i.e. ")#metadata(none) <tao-cf50252908e527ebc5ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(2^{a_{k+1}} - 3^k) n = 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k}")]]



#text(" for some natural number ")#mi("{n > 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-785fda86872f7ba2ab7c>#text(" Conjecture ")#link(<tao-dbef5168c52de4091a09>)[#text("2")]#text(" and Conjecture ")#link(<tao-7b993dec18383a0f2312>)[#text("3")]#text(" are equivalent.")
]

#emph[#text("Proof:")]#text(" To see this, it is convenient to reformulate Conjecture ")#link(<tao-dbef5168c52de4091a09>)[#text("2")]#text(" slightly. Define an equivalence relation ")#mi("{\\sim}")#text(" on ")#mi("{{\\bf N}}")#text(" by declaring ")#mi("{a \\sim b}")#text(" if ")#mi("{a/b = 2^m}")#text(" for some integer ")#mi("{m}")#text(", thus giving rise to the quotient space ")#mi("{{\\bf N}/\\sim}")#text(" of equivalence classes ")#mi("{[n]}")#text(" (which can be placed, if one wishes, in one-to-one correspondence with the odd natural numbers). We can then define a function ")#mi("{f_2: {\\bf N}/\\sim \\rightarrow {\\bf N}/\\sim}")#text(" by declaring ")#metadata(none) <tao-64916201a5b21e8c4893>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f_2( [n] ) := [3n + 2^a]")]]



#text(" for any ")#mi("{n \\in {\\bf N}}")#text(", where ")#mi("{2^a}")#text(" is the largest power of ")#mi("{2}")#text(" that divides ")#mi("{n}")#text(". It is easy to see that ")#mi("{f_2}")#text(" is well-defined (it is essentially the ")#emph[#text("Syracuse function")]#text(", after identifying ")#mi("{{\\bf N}/\\sim}")#text(" with the odd natural numbers), and that periodic orbits of ")#mi("{f_2}")#text(" correspond to periodic orbits of ")#mi("{f_1}")#text(" or ")#mi("{f_0}")#text(". Thus, Conjecture ")#link(<tao-dbef5168c52de4091a09>)[#text("2")]#text(" is equivalent to the conjecture that ")#mi("{[1]}")#text(" is the only periodic orbit of ")#mi("{f_2}")#text(".")

#text("Now suppose that Conjecture ")#link(<tao-dbef5168c52de4091a09>)[#text("2")]#text(" failed, thus there exists ")#mi("{[n] \\neq [1]}")#text(" such that ")#mi("{f_2^k([n])=[n]}")#text(" for some ")#mi("{k \\geq 1}")#text(". Without loss of generality we may take ")#mi("{n}")#text(" to be odd, then ")#mi("{n>1}")#text(". It is easy to see that ")#mi("{[1]}")#text(" is the only fixed point of ")#mi("{f_2}")#text(", and so ")#mi("{k>1}")#text(". An easy induction using ")#link(<tao-64916201a5b21e8c4893>)[#text("(2)")]#text(" shows that")

#align(center)[#tao-fit-display[#mitex("f_2^k([n]) = [3^k n + 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k}]")]]

#text("where, for each ")#mi("{1 \\leq i \\leq k}")#text(", ")#mi("{2^{a_i}}")#text(" is the largest power of ")#mi("{2}")#text(" that divides ")#metadata(none) <tao-32000e140c9ebe9ba782>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("n_i := 3^{i-1} n + 3^{i-2} 2^{a_1} + \\ldots + 2^{a_{i-1}}.")]]



#text(" In particular, as ")#mi("{n_1 = n}")#text(" is odd, ")#mi("{a_1=0}")#text(". Using the recursion ")#metadata(none) <tao-1a1e52b2e2af0791119e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("n_{i+1} = 3n_i + 2^{a_i},")]]



#text(" we see from induction that ")#mi("{2^{a_i+1}}")#text(" divides ")#mi("{n_{i+1}}")#text(", and thus ")#mi("{a_{i+1}>a_i}")#text(":")

#align(center)[#tao-fit-display[#mitex("0 = a_1 < a_2 < \\ldots < a_k.")]]

#text("Since ")#mi("{f_2^k([n]) = [n]}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("2^{a_{k+1}} n = 3^k n + 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k} = 3 n_k + 2^{a_k}")]]

#text("for some integer ")#mi("{a_{k+1}}")#text(". Since ")#mi("{3 n_k + 2^{a_k}}")#text(" is divisible by ")#mi("{2^{a_k+1}}")#text(", and ")#mi("{n}")#text(" is odd, we conclude ")#mi("{a_{k+1} > a_k}")#text("; if we rearrange the above equation as ")#link(<tao-cf50252908e527ebc5ca>)[#text("(1)")]#text(", then we obtain a counterexample to Conjecture ")#link(<tao-7b993dec18383a0f2312>)[#text("3")]#text(".")

#text("Conversely, suppose that Conjecture ")#link(<tao-7b993dec18383a0f2312>)[#text("3")]#text(" failed. Then we have ")#mi("{k \\geq 1}")#text(", integers")

#align(center)[#tao-fit-display[#mitex("0 = a_1 < a_2 < \\ldots < a_{k+1}")]]

#text("and a natural number ")#mi("{n > 1}")#text(" such that ")#link(<tao-cf50252908e527ebc5ca>)[#text("(1)")]#text(" holds. As ")#mi("{a_1=0}")#text(", we see that the right-hand side of ")#link(<tao-cf50252908e527ebc5ca>)[#text("(1)")]#text(" is odd, so ")#mi("{n}")#text(" is odd also. If we then introduce the natural numbers ")#mi("{n_i}")#text(" by the formula ")#link(<tao-32000e140c9ebe9ba782>)[#text("(3)")]#text(", then an easy induction using ")#link(<tao-1a1e52b2e2af0791119e>)[#text("(4)")]#text(" shows that ")#metadata(none) <tao-3fc4ccfe745870e2c0d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("(2^{a_{k+1}} - 3^k) n_i = 3^{k-1} 2^{a_i} + 3^{k-2} 2^{a_{i+1}} + \\ldots + 2^{a_{i+k-1}}")]]



#text(" with the periodic convention ")#mi("{a_{k+j} := a_j + a_{k+1}}")#text(" for ")#mi("{j>1}")#text(". As the ")#mi("{a_i}")#text(" are increasing in ")#mi("{i}")#text(" (even for ")#mi("{i \\geq k+1}")#text("), we see that ")#mi("{2^{a_i}}")#text(" is the largest power of ")#mi("{2}")#text(" that divides the right-hand side of ")#link(<tao-3fc4ccfe745870e2c0d9>)[#text("(5)")]#text("; as ")#mi("{2^{a_{k+1}}-3^k}")#text(" is odd, we conclude that ")#mi("{2^{a_i}}")#text(" is also the largest power of ")#mi("{2}")#text(" that divides ")#mi("{n_i}")#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("f_2([n_i]) = [3n_i + 2^{a_i}] = [n_{i+1}]")]]

#text("and thus ")#mi("{[n]}")#text(" is a periodic orbit of ")#mi("{f_2}")#text(". Since ")#mi("{n}")#text(" is an odd number larger than ")#mi("{1}")#text(", this contradicts Conjecture ")#link(<tao-7b993dec18383a0f2312>)[#text("3")]#text(". ")#mi("\\Box")

#text("Call a ")#emph[#text("counterexample")]#text(" a tuple ")#mi("{(k,a_1,\\ldots,a_{k+1})}")#text(" that contradicts Conjecture ")#link(<tao-7b993dec18383a0f2312>)[#text("3")]#text(", i.e. an integer ")#mi("{k \\geq 1}")#text(" and an increasing set of integers")

#align(center)[#tao-fit-display[#mitex("0 = a_1 < a_2 < \\ldots < a_{k+1}")]]

#text("such that ")#link(<tao-cf50252908e527ebc5ca>)[#text("(1)")]#text(" holds for some ")#mi("{n \\geq 1}")#text(". We record a simple bound on such counterexamples, due ")#link("http://www.ams.org/mathscinet-getitem?mr=568274")[#text("to Terras")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=603593")[#text("to Garner")]#text(" :")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Exponent bounds)")]#text(" ")#metadata(none) <tao-e4ee80cfa07821f0bf44>#text(" Let ")#mi("{N \\geq 1}")#text(", and suppose that the Collatz conjecture is true for all ")#mi("{n < N}")#text(". Let ")#mi("{(k,a_1,\\ldots,a_{k+1})}")#text(" be a counterexample. Then")

#align(center)[#tao-fit-display[#mitex("\\frac{\\log 3}{\\log 2} k < a_{k+1} < \\frac{\\log(3+\\frac{1}{N})}{\\log 2} k.")]]
]

#emph[#text("Proof:")]#text(" The first bound is immediate from the positivity of ")#mi("{2^{a_{k+1}}-3^k}")#text(". To prove the second bound, observe from the proof of Proposition ")#link(<tao-785fda86872f7ba2ab7c>)[#text("4")]#text(" that the counterexample ")#mi("{(k,a_1,\\ldots,a_{k+1})}")#text(" will generate a counterexample to Conjecture ")#link(<tao-dbef5168c52de4091a09>)[#text("2")]#text(", i.e. a non-trivial periodic orbit ")#mi("{n, f(n), \\ldots, f^K(n) = n}")#text(". As the conjecture is true for all ")#mi("{n < N}")#text(", all terms in this orbit must be at least ")#mi("{N}")#text(". An inspection of the proof of Proposition ")#link(<tao-785fda86872f7ba2ab7c>)[#text("4")]#text(" reveals that this orbit consists of ")#mi("{k}")#text(" steps of the form ")#mi("{x \\mapsto 3x+1}")#text(", and ")#mi("{a_{k+1}}")#text(" steps of the form ")#mi("{x \\mapsto x/2}")#text(". As all terms are at least ")#mi("{N}")#text(", the former steps can increase magnitude by a multiplicative factor of at most ")#mi("{3+\\frac{1}{N}}")#text(". As the orbit returns to where it started, we conclude that")

#align(center)[#tao-fit-display[#mitex("1 \\leq (3+\\frac{1}{N})^k (\\frac{1}{2})^{a_{k+1}}")]]

#text("whence the claim. ")#mi("\\Box")

#text("The Collatz conjecture has already been verified for many values of ")#mi("{n}")#text(" (up to at least ")#mi("{N = 5 \\times 10^{18}}")#text(", according to ")#link("http://www.ieeta.pt/~tos/3x+1.html")[#text("this web site")]#text("). Inserting this into the above lemma, one can get lower bounds on ")#mi("{k}")#text(". For instance, by methods such as this, it is known that any non-trivial periodic orbit has length at least ")#mi("{105{,}000}")#text(", as shown in Garner’s paper (and this bound, which uses the much smaller value ")#mi("{N = 2 \\times 10^9}")#text(" that was available in 1981, can surely be improved using the most recent computational bounds).")

#text("Now we can perform a heuristic count on the number of counterexamples. If we fix ")#mi("{k}")#text(" and ")#mi("{a := a_{k+1}}")#text(", then ")#mi("{2^a > 3^k}")#text(", and from basic combinatorics we see that there are ")#mi("{\\binom{a-1}{k-1}}")#text(" different ways to choose the remaining integers")

#align(center)[#tao-fit-display[#mitex("0 = a_1 < a_2 < \\ldots < a_{k+1}")]]

#text("to form a potential counterexample ")#mi("{(k,a_1,\\ldots,a_{k+1})}")#text(". As a crude heuristic, one expects that for a “random” such choice of integers, the expression ")#link(<tao-cf50252908e527ebc5ca>)[#text("(1)")]#text(" has a probability ")#mi("{1/q}")#text(" of holding for some integer ")#mi("{n}")#text(". (Note that ")#mi("{q}")#text(" is not divisible by ")#mi("{2}")#text(" or ")#mi("{3}")#text(", and so one does not expect the special structure of the right-hand side of ")#link(<tao-cf50252908e527ebc5ca>)[#text("(1)")]#text(" with respect to those moduli to be relevant. There will be some choices of ")#mi("{a_1,\\ldots,a_k}")#text(" where the right-hand side in ")#link(<tao-cf50252908e527ebc5ca>)[#text("(1)")]#text(" is too small to be divisible by ")#mi("{q}")#text(", but using the estimates in Lemma ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("5")]#text(", one expects this to occur very infrequently.) Thus, the total expected number of solutions for this choice of ")#mi("{a, k}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{q} \\binom{a-1}{k-1}.")]]

#text("The heuristic number of solutions overall is then expected to be ")#metadata(none) <tao-bcbb0eeac8d6a4240d57>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{a,k} \\frac{1}{q} \\binom{a-1}{k-1},")]]



#text(" where, in view of Lemma ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("5")]#text(", one should restrict the double summation to the heuristic regime ")#mi("{a \\approx \\frac{\\log 3}{\\log 2} k}")#text(", with the approximation here accurate to many decimal places.")

#text("We need a lower bound on ")#mi("{q}")#text(". Here, we will use ")#link("http://en.wikipedia.org/wiki/Baker%27s_theorem")[#text("Baker’s theorem")]#text(" (as discussed in ")#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/")[#text("this previous post")]#text("), which among other things gives the lower bound ")#metadata(none) <tao-c73b1c1765580dc9e0a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("q = 2^a - 3^k \\gg 2^a / a^C")]]



#text(" for some absolute constant ")#mi("{C}")#text(". Meanwhile, ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text(" (as discussed in ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("this previous post")]#text(") combined with the approximation ")#mi("{k \\approx \\frac{\\log 2}{\\log 3} a}")#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\binom{a-1}{k-1} \\approx \\exp(h(\\frac{\\log 2}{\\log 3}))^a")]]

#text("where ")#mi("{h}")#text(" is the ")#emph[#text("entropy function")]

#align(center)[#tao-fit-display[#mitex("h(x) := - x \\log x - (1-x) \\log (1-x).")]]

#text("A brief computation shows that")

#align(center)[#tao-fit-display[#mitex("\\exp(h(\\frac{\\log 2}{\\log 3})) \\approx 1.9318 \\ldots")]]

#text("and so (ignoring all subexponential terms)")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{q} \\binom{a-1}{k-1} \\approx (0.9659\\ldots)^a")]]

#text("which makes the series ")#link(<tao-bcbb0eeac8d6a4240d57>)[#text("(6)")]#text(" convergent. (Actually, one does not need the full strength of Lemma ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("5")]#text(" here; anything that kept ")#mi("{k}")#text(" well away from ")#mi("{a/2}")#text(" would suffice. In particular, one does not need an enormous value of ")#mi("{N}")#text("; even ")#mi("{N=5}")#text(" (say) would be more than sufficient to obtain the heuristic that there are finitely many counterexamples.) Heuristically applying the ")#link("http://en.wikipedia.org/wiki/Borel%E2%80%93Cantelli_lemma")[#text("Borel-Cantelli lemma")]#text(", we thus expect that there are only a finite number of counterexamples to the weak Collatz conjecture (and inserting a bound such as ")#mi("{k \\geq 105{,}000}")#text(", one in fact expects it to be extremely likely that there are no counterexamples at all).")

#text("This, of course, is far short of any rigorous proof of Conjecture ")#link(<tao-dbef5168c52de4091a09>)[#text("2")]#text(". In order to make rigorous progress on this conjecture, it seems that one would need to somehow exploit the structural properties of numbers of the form ")#metadata(none) <tao-36d2c3997d6b67084312>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k}.")]]



#text(" In some very special cases, this can be done. For instance, suppose that one had ")#mi("{a_{i+1}=a_i+1}")#text(" with at most one exception (this is essentially what is called a ")#emph[#mi("{1}")#text("-cycle")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=535032")[#text("by Steiner")]#text("). Then ")#link(<tao-36d2c3997d6b67084312>)[#text("(8)")]#text(" simplifies via the geometric series formula to a combination of just a bounded number of powers of ")#mi("{2}")#text(" and ")#mi("{3}")#text(", rather than an unbounded number. In that case, one can start using tools from transcendence theory such as Baker’s theorem to obtain good results; for instance, in the above-referenced paper of Steiner, it was shown that ")#mi("{1}")#text("-cycles cannot actually occur, and similar methods have been used to show that ")#mi("{m}")#text("-cycles (in which there are at most ")#mi("{m}")#text(" exceptions to ")#mi("{a_{i+1}=a_i+1}")#text(") do not occur for any ")#mi("{m \\leq 63}")#text(", as was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=2110503")[#text("by Simons and de Weger")]#text(". However, for general increasing tuples of integers ")#mi("{a_1,\\ldots,a_k}")#text(", there is no such representation by bounded numbers of powers, and it does not seem that methods from transcendence theory will be sufficient to control the expressions ")#link(<tao-36d2c3997d6b67084312>)[#text("(8)")]#text(" to the extent that one can understand their divisibility properties by quantities such as ")#mi("{2^a-3^k}")#text(".")

#text("Amusingly, there is a slight connection to ")#link("http://en.wikipedia.org/wiki/Littlewood%E2%80%93Offord_problem")[#text("Littlewood-Offord theory")]#text(" in additive combinatorics – the study of the ")#mi("{2^n}")#text(" random sums")

#align(center)[#tao-fit-display[#mitex("\\pm v_1 \\pm v_2 \\pm \\ldots \\pm v_n")]]

#text("generated by some elements ")#mi("{v_1,\\ldots,v_n}")#text(" of an additive group ")#mi("{G}")#text(", or equivalently, the vertices of an ")#mi("{n}")#text("-dimensional parallelepiped inside ")#mi("{G}")#text(". Here, the relevant group is ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(". The point is that if one fixes ")#mi("{k}")#text(" and ")#mi("{a_{k+1}}")#text(" (and hence ")#mi("{q}")#text("), and lets ")#mi("{a_1,\\ldots,a_k}")#text(" vary inside the simplex")

#align(center)[#tao-fit-display[#mitex("\\Delta := \\{ (a_1,\\ldots,a_k) \\in {\\bf N}^k: 0 = a_1 < \\ldots < a_k < a_{k+1}\\}")]]

#text("then the set ")#mi("{S}")#text(" of all sums of the form ")#link(<tao-36d2c3997d6b67084312>)[#text("(8)")]#text(" (viewed as an element of ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(") contains many large parallelepipeds. (Note, incidentally, that once one fixes ")#mi("{k}")#text(", all the sums of the form ")#link(<tao-36d2c3997d6b67084312>)[#text("(8)")]#text(" are distinct; because given ")#link(<tao-36d2c3997d6b67084312>)[#text("(8)")]#text(" and ")#mi("{k}")#text(", one can read off ")#mi("{2^{a_1}}")#text(" as the largest power of ")#mi("{2}")#text(" that divides ")#link(<tao-36d2c3997d6b67084312>)[#text("(8)")]#text(", and then subtracting off ")#mi("{3^{k-1} 2^{a_1}}")#text(" one can then read off ")#mi("{2^{a_2}}")#text(", and so forth.) This is because the simplex ")#mi("{\\Delta}")#text(" contains many large cubes. Indeed, if one picks a typical element ")#mi("{(a_1,\\ldots,a_k)}")#text(" of ")#mi("{\\Delta}")#text(", then one expects (thanks to Lemma ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("5")]#text(") that there there will be ")#mi("{\\gg k}")#text(" indices ")#mi("{1 \\leq i_1 < \\ldots < i_m \\leq k}")#text(" such that ")#mi("{a_{i_j+1} > a_{i_j}+1}")#text(" for ")#mi("{j=1,\\ldots,m}")#text(", which allows one to adjust each of the ")#mi("{a_{i_j}}")#text(" independently by ")#mi("{1}")#text(" if desired and still remain inside ")#mi("{\\Delta}")#text(". This gives a cube in ")#mi("{\\Delta}")#text(" of dimension ")#mi("{\\gg k}")#text(", which then induces a parallelepiped of the same dimension in ")#mi("{S}")#text(". A short computation shows that the generators of this parallelepiped consist of products of a power of ")#mi("{2}")#text(" and a power of ")#mi("{3}")#text(", and in particular will be coprime to ")#mi("{q}")#text(".")

#text("If the weak Collatz conjecture is true, then the set ")#mi("{S}")#text(" must avoid the residue class ")#mi("{0}")#text(" in ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(". Let us suppose temporarily that we did not know about Baker’s theorem (and the associated bound ")#link(<tao-c73b1c1765580dc9e0a7>)[#text("(7)")]#text("), so that ")#mi("{q}")#text(" could potentially be quite small. Then we would have a large parallelepiped inside a small cyclic group ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" that did not cover all of ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(", which would not be possible for ")#mi("{q}")#text(" small enough. Indeed, an easy induction shows that a ")#mi("{d}")#text("-dimensional parallelepiped in ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(", with all generators coprime to ")#mi("{q}")#text(", has cardinality at least ")#mi("{\\min(q, d+1)}")#text(". This argument already shows the lower bound ")#mi("{q \\gg k}")#text(". In other words, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" Suppose the weak Collatz conjecture is true. Then for any natural numbers ")#mi("{a, k}")#text(" with ")#mi("{2^a > 3^k}")#text(", one has ")#mi("{2^a-3^k \\gg k}")#text(".")
]

#text("This bound is very weak when compared against the unconditional bound ")#link(<tao-c73b1c1765580dc9e0a7>)[#text("(7)")]#text(". However, I know of no way to get a nontrivial separation property between powers of ")#mi("{2}")#text(" and powers of ")#mi("{3}")#text(" other than via transcendence theory methods. Thus, this result strongly suggests that any proof of the Collatz conjecture must either use existing results in transcendence theory, or else must contribute a new method to give non-trivial results in transcendence theory. (This already rules out a lot of possible approaches to solve the Collatz conjecture.)")

#text("By using more sophisticated tools in additive combinatorics, one can improve the above proposition (though it is still well short of the transcendence theory bound ")#link(<tao-c73b1c1765580dc9e0a7>)[#text("(7)")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" Suppose the weak Collatz conjecture is true. Then for any natural numbers ")#mi("{a, k}")#text(" with ")#mi("{2^a > 3^k}")#text(", one has ")#mi("{2^a-3^k \\gg (1+\\epsilon)^k}")#text(" for some absolute constant ")#mi("{\\epsilon > 0}")#text(".")
]

#emph[#text("Proof:")]#text(" (Informal sketch only) Suppose not, then we can find ")#mi("{a, k}")#text(" with ")#mi("{q := 2^a-3^k}")#text(" of size ")#mi("{(1+o(1))^k = \\exp(o(k))}")#text(". We form the set ")#mi("{S}")#text(" as before, which contains parallelepipeds in ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" of large dimension ")#mi("{d \\gg k}")#text(" that avoid ")#mi("{0}")#text(". We can count the number of times ")#mi("{0}")#text(" occurs in one of these parallelepipeds by a standard Fourier-analytic computation involving Riesz products (see Chapter 7 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(", or ")#link("http://arxiv.org/abs/1012.2372")[#text("this recent preprint of Maples")]#text("). Using this Fourier representation, the fact that this parallelepiped avoids ")#mi("{0}")#text(" (and the fact that ")#mi("{q = \\exp(o(k)) = \\exp(o(d))}")#text(") forces the generators ")#mi("{v_1,\\ldots,v_d}")#text(" to be concentrated in a ")#emph[#text("Bohr set")]#text(", in that one can find a non-zero frequency ")#mi("{\\xi \\in {\\bf Z}/q{\\bf Z}}")#text(" such that ")#mi("{(1-o(1))d}")#text(" of the ")#mi("{d}")#text(" generators lie in the set ")#mi("{\\{ v: \\xi v = o(q) \\text{ mod } q \\}}")#text(". However, one can choose the generators to essentially have the structure of a (generalised) geometric progression (up to scaling, it resembles something like ")#mi("{2^i 3^{\\lfloor \\alpha i \\rfloor}}")#text(" for ")#mi("{i}")#text(" ranging over a generalised arithmetic progression, and ")#mi("{\\alpha}")#text(" a fixed irrational), and one can show that such progressions cannot be concentrated in Bohr sets (this is similar in spirit to the ")#link("http://www.ams.org/mathscinet-getitem?mr=2140627")[#text("exponential sum estimates of Bourgain")]#text(" on approximate multiplicative subgroups of ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(", though one can use more elementary methods here due to the very strong nature of the Bohr set concentration (being of the “")#mi("{99\\%}")#text(" concentration” variety rather than the “")#mi("{1\\%}")#text(" concentration”).). This furnishes the required contradiction. ")#mi("\\Box")

#text("Thus we see that any proposed proof of the Collatz conjecture must either use transcendence theory, or introduce new techniques that are powerful enough to create exponential separation between powers of ")#mi("{2}")#text(" and powers of ")#mi("{3}")#text(".")

#text("Unfortunately, once one uses the transcendence theory bound ")#link(<tao-c73b1c1765580dc9e0a7>)[#text("(7)")]#text(", the size ")#mi("{q}")#text(" of the cyclic group ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" becomes larger than the volume of any cube in ")#mi("{S}")#text(", and Littlewood-Offord techniques are no longer of much use (they can be used to show that ")#mi("{S}")#text(" is highly equidistributed in ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(", but this does not directly give any way to prevent ")#mi("{S}")#text(" from containing ")#mi("{0}")#text(").")

#text("One possible toy model problem for the (weak) Collatz conjecture is a ")#link("http://www.ams.org/mathscinet-getitem?mr=527408")[#text("conjecture of Erdos")]#text(" asserting that for ")#mi("{n>8}")#text(", the base ")#mi("{3}")#text(" representation of ")#mi("{2^n}")#text(" contains at least one ")#mi("{2}")#text(". (See ")#link("http://www.ams.org/mathscinet-getitem?mr=2506687")[#text("this paper of Lagarias")]#text(" for some work on this conjecture and on related problems.) To put it another way, the conjecture asserts that there are no integer solutions to")

#align(center)[#tao-fit-display[#mitex("2^n = 3^{a_1} + 3^{a_2} + \\ldots + 3^{a_k}")]]

#text("with ")#mi("{n > 8}")#text(" and ")#mi("{0 \\leq a_1 < \\ldots < a_k}")#text(". (When ")#mi("{n=8}")#text(", of course, one has ")#mi("{2^8 = 3^0 + 3^1 + 3^2 + 3^5}")#text(".) In this form we see a resemblance to Conjecture ")#link(<tao-7b993dec18383a0f2312>)[#text("3")]#text(", but it looks like a simpler problem to attack (though one which is still a fair distance beyond what one can do with current technology). Note that one has a similar heuristic support for this conjecture as one does for Proposition ")#link(<tao-7b993dec18383a0f2312>)[#text("3")]#text("; a number of magnitude ")#mi("{2^n}")#text(" has about ")#mi("{n \\frac{\\log 2}{\\log 3}}")#text(" base ")#mi("{3}")#text(" digits, so the heuristic probability that none of these digits are equal to ")#mi("{2}")#text(" is ")#mi("{3^{-n\\frac{\\log 2}{\\log 3}} = 2^{-n}}")#text(", which is absolutely summable.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (382)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ec6deadb09b58964545a29ae3967f4b34923a74fb4602e7c6b3a627bc057cf4-d4dfbb0997ac905ad0d50f399768f907e6eebbcf1c09f80cc88d1c79d3687ea0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich Sondermann")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-674128")[#strong[#text("Ulrich Sondermann")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2023")])]

#text("While working on recursion, I noticed that 3x+1 returns repunits in base 3. Generally bx+c returns repunits in base b of c digits c<b. I have no idea if this will help anyone working on collatz. All of the repunit numbers lead to 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-676973")[#strong[#text("Terence Tao makes development on the Collatz conjecture (2019) – CYBE")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2023")]

#text("[…] this previous August an anonymous reader left a observation on Tao’s weblog. The commenter urged in search of to clear up the Collatz conjecture for “virtually […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682359")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2023")])]

#text("Hello everyone. Again here. If you find it interesting, I would like to discuss the possibility of entering a periodic orbit.")#linebreak()#text(" As we know, multiples of 3 odd cannot enter a periodic orbit. In fact, if the conjecture is true, ignoring the possibility of unbounded orbits, every sequence until reaching 1 has as its origin a multiple of 3 odd, so we can prove that every collatz sequence, that is, in reverse, will always be found with a multiple of 3. To do this I have made a table where we can see all the odd numbers that are not multiples of 3 and follow their path by multiplying them by a power of 2 and subtract 1 and where we can recognize those numbers that are multiples of 9, which when divided by 3 will be multiples of 3. I would have liked to make this table larger, but it is the best thing to do, so I invite you to make it larger if it is of your interest.")#linebreak()#text(" In short, the question would be whether for every odd n that runs through, like a Collatz sequence going backwards, this table is always trapped in a multiple of 9.")#linebreak()#text(" Note that for every 6 positions both from left to right and from top to bottom we find a multiple of 9.")#linebreak()#text(" Thank you and I hope you may have some interest. All the best")

#mi("\\begin{table}     \\centering     \\begin{tabular}{c|ccccccccc}         1 & 2  & 4 & 8  &16  &32  & 64  & 128  & 256 \\\\ \\hline          1 &1  & 3 &  7 &  15& 31 & \\underline{63}  & 127  & 255 & \\\\          5 & \\underline{9} & 19 &39  &79  &159  &319  &\\underline{639}  &1279  & \\\\          7 &13  &\\underline{27}  &55  &111  &223  &447  &  895& \\underline{1791} & \\\\          11 & 21 & 43 & 87 & 175 & \\underline{351} & 703 & 1407 & 2815 & \\\\          13 & 25 & 51 & 103 &  \\underline{207}&415  & 831 & 1663 & 3327 & \\\\          17 & 33 & 67 & \\underline{135} &  271&543  &1087  &  2175& 4351 & \\\\          19 & 37 &75  & 151 &  303& 607 & \\underline{1215} & 2431 & 4863 & \\\\          23 & \\underline{45} & 91 & 183 &  367& 735 & 1471 & \\underline{2943} & 5887 & \\\\          25 & 49 & \\underline{99} & 199 & 399 & 799 &  1599& 3199 &\\underline{6399}  & \\\\     \\end{tabular}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682361")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2023")])]

#text("Sorry, I can’t upload it correctly. I write the latex in case you can upload it correctly.")

#text("Thank you")

#text("\\begin{table}")#linebreak()#text(" \\centering")#linebreak()#text(" \\begin{tabular}{c|ccccccccc}")#linebreak()#text(" 1 & 2 & 4 & 8 &16 &32 & 64 & 128 & 256 \\\\ \\hline")#linebreak()#text(" 1 &1 & 3 & 7 & 15& 31 & \\underline{63} & 127 & 255 & \\\\")#linebreak()#text(" 5 & \\underline{9} & 19 &39 &79 &159 &319 &\\underline{639} &1279 & \\\\")#linebreak()#text(" 7 &13 &\\underline{27} &55 &111 &223 &447 & 895& \\underline{1791} & \\\\")#linebreak()#text(" 11 & 21 & 43 & 87 & 175 & \\underline{351} & 703 & 1407 & 2815 & \\\\")#linebreak()#text(" 13 & 25 & 51 & 103 & \\underline{207}&415 & 831 & 1663 & 3327 & \\\\")#linebreak()#text(" 17 & 33 & 67 & \\underline{135} & 271&543 &1087 & 2175& 4351 & \\\\")#linebreak()#text(" 19 & 37 &75 & 151 & 303& 607 & \\underline{1215} & 2431 & 4863 & \\\\")#linebreak()#text(" 23 & \\underline{45} & 91 & 183 & 367& 735 & 1471 & \\underline{2943} & 5887 & \\\\")#linebreak()#text(" 25 & 49 & \\underline{99} & 199 & 399 & 799 & 1599& 3199 &\\underline{6399} & \\\\")#linebreak()#text(" \\end{tabular}")#linebreak()#text(" \\caption{9 multiples}")#linebreak()#text(" \\label{tab:my_label}")#linebreak()#text(" \\end{table}")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682364")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2023")])]

#text("Is anyone jnterested in my research results concerning the Collatz-Problem (w-schlund@web.de)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682366")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2023")])]

#text("No not at all interested in ur ‘obsessions’")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682413")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2023")])]

#text("“Note, incidentally, that once one fixes {k}, all the sums of the form (8) are distinct; because given (8) and {k}, one can read off {2^{a_1}} as the largest power of {2} that divides (8), and then subtracting off {3^{k-1} 2^{a_1}} one can then read off {2^{a_2}}, and so forth.”")

#text("Intuitively yes all the sums of the form (8) are distinct, but this argument can’t be correct as otherwise a1, a2… will be determined by k alone using this algorithm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682414")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2023")])]

#text("The argument does not assert that ")#mi("a_1,a_2,\\dots")#text(" can be determined by ")#mi("k")#text(" alone, but rather by a combination of ")#mi("k")#text(" and the quantity (8).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682444")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")])]

#text("Sorry the copy/paste seems to have messed up so I’ll post again.")

#text("“Now we can perform a heuristic count on the number of counterexamples. If we fix {k} and {a := a_{k+1}}, then {2^a > 3^k}, and from basic combinatorics we see that there are {\\binom{a-1}{k-1}} different ways to choose the remaining integers.”")

#text("The number of different ways of choosing a_1, a_2 etc should be k^(a-k)")

#text("If we define d_i as a_{i+1} – a_{i} , then d_i >= 1, and the number of different ways of choosing a_1, a_2 etc. is the same as choosing d_1, d_2 etc.")

#text("This can be calculated by setting d_i = 1 initially, then putting the rest of the balls (a-k in total) into different d_i positions (k in total to choose from). There are {k^(a-k)} different ways to do this.")

#text("The {k^(a-k)} different ways to choose a_1, a_2 are not independent in term of co-prime with {q}, as if one of them is divisible by q, then the other k-1 values in the same cycle will be divisible by q as well. Therefore the top term should be {k^(a-k-1)}. This gives the total number of solutions as:")

#text("\\sum_{k}^{}\\frac{1}{q}{k}^{a-k-1}")

#text("I don’t think the series is convergent given the lower bound from Baker’s thereom.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682446")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")])]

#text("Your procedure is not injective: if you put the first ball into the ")#mi("d_3")#text(" position and the second ball into the ")#mi("d_5")#text(" position, for instance, this produces the same outcome as when you instead put the first ball into the ")#mi("d_5")#text(" position and the second ball into the ")#mi("d_3")#text(" position. So the number of combinations is much smaller than ")#mi("k^{a-k}")#text(", and as I stated is actually ")#mi("\\binom{a-1}{k-1}")#text(" (these results are sometimes known as “")#link("https://en.wikipedia.org/wiki/Stars_and_bars_(combinatorics)")[#text("Stars and bars")]#text("” theorems).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-684543")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2024")])]

#text("On the existence of non-trivial periodic orbits")

#text("We have that")

#mi("q=2^{a}-3^{k}")

#text("Professor says “In order to make rigorous progress on this conjecture, it seems that one would need to somehow exploit the structural properties of numbers of the form (8)”")

#mi("displaystyle 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + ldots + 2^{a_k}")

#text("which for simplicity we can call TCR")

#text("whose size is")

#mi("binom{a-1}{k-1}")

#text("If there are at least k values of this set that are multiples of q, then a non-trivial orbit will exist.")

#text("if we can establish")

#mi("q=left ( 2^{a}-2^{k} right )-left ( 3^{k}-2^{k} right )")#linebreak()#text("where ")#mi("3^{k}-2^{k}")#text(" is the difference of nth power")

#text("and")

#mi("TCR_{min}=3^{k}-2^{k}")

#text("and")

#mi("TCR_{max}=3^{k}-2^{k}+3x+left ( 2^{a-1}-2^{k} right )")

#text("We will have within the set of TCR numbers of the form 8 several subsets that differ in a multiple of 3 and the last term, which is a difference in powers of 2 ")#mi("left ( 2^{k+1}-2^{k} right )…left ( 2^{k+2}-2^{k} right )…left ( 2^{a-1}-2^{k} right )")

#text("The question, which I am not able to resolve, is whether these subsets are easier to study if it is possible that they are multiples of q.")

#text("Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-684589")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2024")])]

#text("On the existence of non-trivial periodic orbits")

#text("I want to propose a possible way to attack this question.")

#text("It would be about studying the minimum value of q for each power of 3 and the smallest power of 2 greater than that power of 3, for positive q.")

#text("With the means I have done an excel and see the values up to 3^45 and you can see that the value of q grows and grows. Surely this may be very obvious to all of you and perfectly established")

#text("We also know that for each power of 3 and depending on the value of the power of 2 we have a finite set of numbers of the form (8), which for simplicity is called TCR, possible candidates to form a periodic orbit, with a maximum value and minimum")#linebreak()#text("The idea would be to study the maximum value of this set for each power of 3 and the minimum value of q. This would already be far outside my possibilities beyond a few calculations.I’m sure many of you can formalize these calculations, if they are possible.")

#text("If we divide this value of TCR max for each value of q min, for each power of 3, we obtain the highest number that would form that possible periodic orbit, and if in some way it will be observed that the limit(?) of this function(?) will remain below the values that today we know reach 1, perhaps it could be established that there is no possibility that any number (set of numbers) can be part of a periodic orbit.")

#text("I really don’t know if this approach could have any interest and is worth studying.")

#text("Anyway, thanks")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-684590")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2024")])]

#text("Related:")#linebreak()#link("https://oeis.org/history/view?seq=A370354&v=9999")[#text("https://oeis.org/history/view?seq=A370354&v=9999")]#linebreak()#link("https://oeis.org/history/view?seq=A370484&v=9999")[#text("https://oeis.org/history/view?seq=A370484&v=9999")]#linebreak()#link("https://oeis.org/history/view?seq=A370935&v=9999")[#text("https://oeis.org/history/view?seq=A370935&v=9999")]

#text("(not approved and published yet, so treat as WIP)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682448")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2023")])]

#text("See also ")#link("https://oeis.org/A100982")[#text("https://oeis.org/A100982")]#text(".")#linebreak()#text(" (and its “history”)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc2f97211cfeb689d8cad9a5a561c8c7f8afdeca09ff86cb2b379d59f5d6eae3-09ec9d7437035b3aec5899dc66db60337d178535ac965bb6d6a19a8942574cb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aleksandr Turnaev")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-682795")[#strong[#text("Aleksandr Turnaev")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2024")])]

#text("Based on the formulation of conjecture 3, it actually seems that it is not true.")

#text("Indeed, if we extend the hypothesis to negative n, it will obviously be incorrect, since in addition to the cycle starting from 1, there are also cycles starting from $-1,-5,-17$.")

#text("Let’s consider what is remarkable about the cases $n=1, -1, -5$.")

#text("Note that")

#tao-aligned(keep: true)[


#tao-math("1 & =\\frac{2^0}{2^2-3^1}=\\frac{2^0}{1}", block: true)



#tao-math("-1 & =\\frac{2^0}{2^1-3^1}=\\frac{2^0}{-1}", block: true)



#tao-math("-5 & =\\frac{2^{1}+2^{0}\\cdot3^{1}}{2^{3}-3^{2}}=\\frac{2^1+2^0\\cdot 3^1}{-1}", block: true)
]

#text("That is, in a sense, all these cycles are trivial, since the denominator is $1$ or $-1$ and therefore the numerator does not matter.")

#text("But in the case of negative numbers, there are also non-trivial cycles, for example, induced by $-17$:")

#text("$$")#linebreak()#text(" -17 = \\frac{2^{7}+2^{6}\\cdot3+2^{5}\\cdot3^{2}+2^{3}\\cdot3^{3}+2^{2}\\cdot3^{4}+2^{1}\\cdot3^{5}+2^{0}\\cdot3^{6}}{2^{11}-3^{7}} = \\frac{\\ldots}{-139}")#linebreak()#text(" $$")

#text("Of course, the number is small in absolute value, but nevertheless. The question arises, what is the fundamental difference between the cases of positive natural numbers and negative ones, why can’t some non-trivial cycle suddenly arise?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-684457")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2024")])]

#text("The is no difference, in both cases total number of cycles is thought to be finite. And taken that for values at least up to 2^70 conjecture is already verified, chances are there are no more cycles.. Unless one finds a way to construct series of n with exponentially growing stopping times, which seems unlikely")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-684711")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2024")])]

#text("See also")

#link("https://oeis.org/history/view?seq=A370484&v=78")[#text("https://oeis.org/history/view?seq=A370484&v=")]#text("9999")

#text("for the transcendental angle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685252")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2024")])]

#text("i am trying to show what are the conditions needed for a collatz cycle")#linebreak()#text("i am using collatz cycles over the rational numbers")

#text("meaning:")

#text("if n is odd -> 3n+P")#linebreak()#text("if n is even -> n/2")

#text("where:")

#text("P=2^x-3^y")#linebreak()#text("x is the number of even values in that cycle")#linebreak()#text("y is the number of odd values in that cycle")

#text("btw a few more conditions need for a cycle such as:")

#text("P need to be prime number")#linebreak()#text("gcd(x,y)=1")

#text("now i am trying to show that:")

#enum(start: 1, 
[#text("P must also be a prime with primitive root 2 using Modular Arithmetic Mapping")],
[#text("the cycle need to be on top of the continued fraction of ln3/ln2 meaning: x/y gives ")#link("https://oeis.org/A028507")[#text("https://oeis.org/A028507")]]
)

#text("for this i built:")

#enum(start: 1, 
[#text("a big chart for x and y sizes of a cycle")],
[#text("Collatz 3n+P Cycles List")],
[#text("Collatz 3n+P Cycles 3D Representation (with 4 restriction rings)")],
[#text("Collatz Modular Arithmetic Mapping in 3d model")]
)

#text("please check:")

#link("http://collatz.125mb.com")[#text("http://collatz.125mb.com")]

#text("can someone point me to something similar that anyone else did on this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78e619c2b75464e70525875bf11e084378721ac7f2f0fe4efa065d0151d3bcf3-be24d5a4c20f81da5b1dd49d69205c208ddf9a2d40c6cc746362bd6f50ced2e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel Núñez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685777")[#strong[#text("Manuel Núñez")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2024")])]

#text("Dear Professor Tao,")

#text("I am pleased to share with you a summary of my proof of the Collatz Conjecture, titled ")#strong[#text("“Aline’s Tree: A Proof of the Collatz Conjecture")]#strong[#text("”")]#text(".")

#text("You can find full documents on this link at reddit: ")#link("https://www.reddit.com/r/collatzConjeturePaper/")[#text("https://www.reddit.com/r/collatzConjeturePaper/")]

#text("I hope this summary provides a clear overview of my proof. I am enthusiastic about discussing these findings and hearing your thoughts on the matter.")

#text("Kind regards.")

#strong[#text("Summary of the Proof of the Collatz Conjecture")]

#text("In this work, I present a proof of the Collatz Conjecture by constructing a ")#strong[#text("directed graph G=(V,E)")]#text(", where:")

#list(
[#strong[#text("V")]#text(" is the set of all positive integers greater than zero.")],
[#strong[#text("E")]#text(" is the set of directed edges representing the unique and bidirectional relationships between positive integers, based on the transformations of the Collatz sequence.")]
)

#strong[#text("Construction of the Graph G=(V,E):")]

#enum(start: 1, 
[#strong[#text("Relations for Even Numbers:")]

#list(
[#text("Every even number n can be expressed as: n=2^k*p where p is a positive odd integer and k∈Z+")],
[#text("The ")#strong[#text("parent")]#text(" p of n is obtained as: p=n*2^k with k being the highest exponent such that 2^k divides n.")]
)],
[#strong[#text("Relations for Odd Numbers:")]

#list(
[#text("Every odd number n can be related to a positive odd ")#strong[#text("parent")]#text(" p through the equation: n=(2^k⋅p−1)/3 where k∈Z+ and p are such that 2^k*p−1 is a multiple of 3.")],
[#text("This implies the condition: 2^k*p≡1(mod3)")],
[#text("The ")#strong[#text("parent")]#text(" p is calculated as: p=(3n+1)/2^k where k is the highest exponent such that 2^k divides 3n+1.")]
)]
)

#strong[#text("Key Properties of the Graph:")]

#list(
[#strong[#text("Uniqueness of Parent-Child Relationships:")]

#list(
[#text("Every positive integer has a ")#strong[#text("unique odd parent")]#text(" in the graph.")],
[#text("The relationships are ")#strong[#text("injective")]#text(", ensuring there are no overlaps or ambiguities.")]
)],
[#strong[#text("Absence of Non-Trivial Cycles:")]

#list(
[#text("The graph G=(V,E) is ")#strong[#text("acyclic")]#text(", except for the trivial cycle at the root node n=1.")],
[#text("This is due to the uniqueness of the relationships and the fact that each number has exactly one parent.")]
)],
[#strong[#text("Hierarchical Structure and Reachability of the Root Node:")]

#list(
[#text("The graph has the structure of a ")#strong[#text("directed tree")]#text(" with a single root node at n=1.")],
[#strong[#text("Every positive integer")]#text(" can trace a unique path to the root node by following the defined parent-child relationships.")],
[#text("Example:")

#list(
[#text("Starting with n=12: 12→(6)→3→(10)→5→(16→8→4→2)→1")],
[#text("By applying the relationships, one inevitably reaches the number 1.")]
)]
)]
)

#text("Conclusions:")

#list(
[#strong[#text("Proof of the Collatz Conjecture:")]

#list(
[#text("It has been demonstrated that ")#strong[#text("all positive integers")]#text(" eventually reach the number 1 by following the rules of the Collatz sequence.")],
[#text("The construction of the graph and the demonstration of its properties ensure that there are no exceptions.")]
)],
[#strong[#text("The Aline’s Tree:")]

#list(
[#text("This structured and hierarchical graph represents all possible Collatz sequences.")],
[#strong[#text("The Aline’s Tree")]#text(" is a tool that visualizes and confirms the universal validity of the conjecture.")]
)]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78e619c2b75464e70525875bf11e084378721ac7f2f0fe4efa065d0151d3bcf3-be24d5a4c20f81da5b1dd49d69205c208ddf9a2d40c6cc746362bd6f50ced2e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel Núñez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685778")[#strong[#text("Manuel Núñez")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2024")])]

#text("*Typo fix ")#strong[#text("p=n*2^k")]#text(" is p=n/2^k")

#enum(start: 1, 
[#strong[#text("Relations for Even Numbers:")]

#list(
[#text("Every even number n can be expressed as: n=2^k*p where p is a positive odd integer and k∈Z+")],
[#text("The ")#strong[#text("parent")]#text(" p of n is obtained as: p=n/2^k with k being the highest exponent such that 2^k divides n.")]
)]
)
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78e619c2b75464e70525875bf11e084378721ac7f2f0fe4efa065d0151d3bcf3-be24d5a4c20f81da5b1dd49d69205c208ddf9a2d40c6cc746362bd6f50ced2e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel Núñez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685804")[#strong[#text("Manuel Núñez")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2024")])]

#list(
[#strong[#text("Temporal growth is a transient phenomenon:")]

#list(
[#text("Temporal growth under ")#strong[#text("3*x+1")]#text(" can be viewed as a ")#strong[#text("local or transient phenomenon")]#text(". In other words, some numbers may experience growth before reducing, but this growth is not due to “chaotic” behavior that invalidates the conjecture; rather, it is due to the position of the number in the hierarchical structure.")],
[#text("The relationship between ")#strong[#text("the hierarchical distance")]#text(" of a number in the graph and ")#strong[#text("temporal growth")]#text(" is an important observation. This means that numbers “far” from the root node may experience more prolonged growth before collapsing, but they are still subject to the injective structure of the graph, where parent-child relationships are unique and well-defined.")],
[#text("The ")#emph[#text("hierarchy in the graph guarantees that growth will eventually stop")]#text(" and turn into reduction, as it is not possible to move “outside” the graph without converging toward the root node (1).")]
)]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78e619c2b75464e70525875bf11e084378721ac7f2f0fe4efa065d0151d3bcf3-be24d5a4c20f81da5b1dd49d69205c208ddf9a2d40c6cc746362bd6f50ced2e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel Núñez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685805")[#strong[#text("Manuel Núñez")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2024")])]

#list(
[#strong[#text("The complete coverage of positive integers is guaranteed")]#text(". All positive integers, whether even or odd, have a defined place in the hierarchical graph. Every odd number can be represented in terms of another odd number (its parent), and every even number can be represented in terms of an odd number (its parent) using the decomposition into powers of 2.")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685815")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2024")])]

#text("I have reviewed your proof and would like to sincerely congratulate you on the magnificent work you have done in demonstrating the Collatz Conjecture. Although your presentation does not strictly follow traditional mathematical standards, such as formalizing in terms of “Theorems,” “Lemmas,” and “Corollaries,” this does not in any way affect the rigor of your assertions or the validity of your proof. You have successfully constructed a solid argument, supported by a careful organization of the hierarchical relationships between numbers, which is fundamental in studying this problem.")

#text("Your approach offers a novel and very interesting perspective on how numbers can be related within the framework of the conjecture. The rigorous identification of how disjoint subsets of even numbers are hierarchically linked to each specific odd number by the injective transformation n = 2^k")#emph[#text("*p, as well as the hierarchical relationship between odd numbers within the subsets of even numbers defined by the injective transformation 3x + 1 = 2^k*")]#text("p, provides a structural clarity that sheds light on the internal organization of the Collatz sequence.")

#text("Likewise, I share your view on the temporal growth in the sequence. Through the hierarchical structure you propose, this phenomenon can be understood as a reflection of the hierarchical distance that certain numbers have from the root node. This interpretation is particularly convincing, as it reinforces the idea that, although some sequences may experience growth before reducing, this does not alter the final convergence to the root node (number 1).")

#text("Allow me once again to congratulate you on the effort and deep understanding you have demonstrated regarding the conjecture. You have not only offered a rigorous way to approach the problem, but you have also provided a structural perspective that could be of great interest for future research in this field.")

#text("My sincerest congratulations on your excellent work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78e619c2b75464e70525875bf11e084378721ac7f2f0fe4efa065d0151d3bcf3-be24d5a4c20f81da5b1dd49d69205c208ddf9a2d40c6cc746362bd6f50ced2e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel Núñez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685816")[#strong[#text("Manuel Núñez")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2024")])]

#text("Thank you very much for your kind words. I deeply appreciate your recognition of the work I have done on the proof of the Collatz Conjecture. It’s motivating to know that, despite not adhering strictly to traditional mathematical standards, the rigor of my proof has been acknowledged.")

#text("I’m also pleased to see that you share my interpretation of the temporal growth phenomenon as a reflection of the hierarchical distance from the root node. I believe this explanation provides a more intuitive understanding of the apparent complexity in the sequences without contradicting the final convergence to the number 1.")

#text("Once again, thank you for your thoughtful comments and for recognizing the effort I’ve put into this work. Your feedback is invaluable, and I hope this perspective will indeed contribute to future research in this field.")

#text("I would like to take this opportunity to update the links to the proof, as the Reddit community link is temporarily unavailable:")

#text("Spanish: ")#link("https://www.safecreative.org/creators/work/27081")[#text("https://www.safecreative.org/creators/work/27081")]

#text("English: ")#link("https://www.safecreative.org/creators/work/27080")[#text("https://www.safecreative.org/creators/work/27080")]

#text("French: ")#link("https://www.safecreative.org/creators/work/27079")[#text("https://www.safecreative.org/creators/work/27079")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685818")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2024")])]

#text("sock-puppets are not useful – cranks still cranks, fake proof still fake proof regardless of how many sock puppets one has")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685820")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2024")])]

#text("I completely agree with you, but in order to consider it fake, we will have to refute it. “Crankery” is not a mathematical concept that we can use.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685824")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2024")])]

#text("refute what – the handwaving above; let trhe author wtite and submit a proper math paper not the bs above; crank all around")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685828")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("In my many years of experience in the field of mathematics, I have learned that every idea, regardless of its origin or initial appearance, deserves to be considered and evaluated with an educated critical discourse. Great contributions to science have often emerged from unexpected places and from perspectives that might have initially been dismissed.")

#text("It is important to remember that criticism, when exercised with humility and respect, enriches both the one who offers it and the one who receives it. Disqualifying ideas in a dismissive manner without giving them a proper review not only undermines the spirit of scientific inquiry but also limits the growth of knowledge. Science advances when we keep an open mind and commit to evaluating arguments with rigor, without falling into the trap of disparaging what could potentially contribute to the development of the field.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("Sorry, what is disrespectful is pushing a famous mathematician to review your work by spamming comments on his blog; as I noted let the author first write up a paper – not send to a blog or anything 0 and second submit it to a journal and possibly uploading it on arXiv for interested people to take a look if they so wish")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685833")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("What kind of fascism is this? I’m not sure if you somehow represent Professor Tao, but your comments on what can or cannot be written on this blog seem to suggest so. There are other ways to moderate who can or cannot share ideas in a public space, but attempting to silence someone so bluntly is truly despicable. Blogs, by their very nature, are open spaces for discussion and the exchange of ideas. If you’re not interested in what’s being said, you can simply ignore it, but imposing control over who can speak goes against the spirit of any healthy academic debate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78e619c2b75464e70525875bf11e084378721ac7f2f0fe4efa065d0151d3bcf3-be24d5a4c20f81da5b1dd49d69205c208ddf9a2d40c6cc746362bd6f50ced2e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel Núñez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685831")[#strong[#text("Manuel Núñez")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("Thank you for your comment.")

#text("I would like to clarify that at no point was Professor Tao pressured, nor was there any attempt to force him to review the work. A vision or approach to the problem was simply shared on his blog, with no expectations of a formal review or comment from him.")

#text("I believe that the exchange of ideas and open discussion in spaces like blogs can be beneficial for everyone, as they provide a platform for sharing different perspectives.")

#text("I understand the importance of following formal channels, such as submitting to a journal or uploading to arXiv, but I also consider the open dialogue that informal platforms like this one offer to be valuable.")

#text("The intention was never to disrespect anyone, but simply to contribute to the mathematical debate in a constructive manner.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685832")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("oh boy we just got collatz before gta6")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-685834")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("Don’t pay attention to this person, Mr. Nuñez. Either (s)he is related to Professor Tao or wishes (s)he was, with all that emphasis on don’t bother a “famous” mathematician… Anyway, sarcasm seems to be the only thing (s)he has mastered. In any case, congrats on your effort")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-687205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2025")])]

#text("In a preprint (arxiv:1911.01229v2), it was proposed that for Collatz sequence generated by ")#mi("T(n)=3n+1 \\text{(if n is odd), } T(n)=n/2 \\text{(if n is even)}")#text(", the total stopping time is related to odd iterates by ")#mi("\\sigma_\\infty(n)=\\lceil  \\log_2\\left(n6^{O(n)}\\right)\\rceil")#text(". The author also verified his formula for a lot of seeds (n). I have verify the formulas for a few seeds as well. Is this kind of formula new and useful?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-687209")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2025")])]

#text("Cute question! I think it should be feasible to prove it with a computer-assisted proof, though more as an application of existing known results about the Collatz conjecture rather than as any development of new methods.")

#text("Define the score ")#mi("s(n)")#text(" of a natural number ")#mi("n")#text(" to be ")#mi("6^{O(n)} n / 2^{\\sigma_\\infty(n)}")#text(", where ")#mi("\\sigma_\\infty(n)")#text(" is the stopping time and ")#mi("O(n)")#text(" is the number of odd values other than 1 in the orbit. Then the question asks whether ")#mi("1 \\leq s(n) < 2")#text(" for all ")#mi("n")#text(". It is easy to see that ")#mi("s(1) = 1")#text(", that ")#mi("s(n/2) = s(n)")#text(" for ")#mi("n")#text(" even, and ")#mi("s(3n+1) = s(n) (1 + \\frac{1}{3n})")#text(" when ")#mi("n")#text(" is odd and not 1. So (assuming the Collatz conjecture) the question then boils down to whether the odd numbers ")#mi("n_1, n_2, \\dots")#text(" other than 1 in a Collatz orbit are sparse enough that ")#mi("\\prod_j (1 + \\frac{1}{3n_j}) < 2")#text(".")

#text("One can show that ")#mi("\\prod_j (1 + \\frac{1}{3n_j})")#text(" is bounded (or equivalently, that the conjectured formula is true up to bounded error) by the existing facts about almost all Collatz orbits. For instance, it follows from ")#link("https://eudml.org/doc/32414")[#text("the work of Korec")]#text(" (working out the error terms carefully, as is essentially done in ")#link("https://arxiv.org/abs/2402.03276")[#text("this recent paper of Inselmann")]#text(") that in any dyadic block ")#mi("[N,2N]")#text(", all but ")#mi("O(N^{1-c})")#text(" of the starting points in this block will iterate to something less than ")#mi("O(N^{1-c})")#text(", for some absolute constant ")#mi("c>0")#text(". This implies that any given orbit can only contain ")#mi("O(N^{1-c})")#text(" elements from this dyadic block, which implies the bounded nature of ")#mi("\\prod_j (1 + \\frac{1}{3n_j})")#text(".")

#text("It is then conceivable that one could make the above analysis sufficiently quantitative that one could upper bound ")#mi("\\prod_{j: n_j \\geq N_0} (1 + \\frac{1}{3n_j})")#text(" by something close to 1 for a reasonably sized threshold ")#mi("N_0")#text(", and use a computer to upper bound ")#mi("s(n)")#text(" for all ")#mi("n < N_0")#text(", and together this could establish the conjecture. This is not something I would have the time and bandwidth to work on myself, but perhaps there would be others who would be interested in pursuing this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-687211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2025")])]

#text("Thanks a lot for quick and detailed reply! We found a pair of similar formulas, i.e., for Collatz sequence generated by")

#align(center)[
#mi("T(n)=3n+1 \\text{(if n is odd), } T(n)=n/2 \\text{(if n is even)}")
]

#text("assuming that we stop the stop the sequence if ")#mi("T^{(k)}=1")#text(", the even iterates ")#mi("E(n)")#text(" is found to be related to odd iterates ")#mi("O(n)")#text(" by ")#mi("E(n)=\\lceil \\log_2\\left(n3^{O(n)}\\right)\\rceil,(2)")#text(",")#linebreak()#mi("O(n)=\\lfloor \\log_3\\left(\\tfrac{1}{n}2^{E(n)}\\right)\\rfloor,(3)")#text(". We also verified this two formulas for a lot of seeds (n). Yesterday, in preprint (arxiv:1911.01229v2), we found the formula")

#align(center)[
#mi("\\sigma_\\infty(n)=\\lceil  \\log_2\\left(n6^{O(n)}\\right)\\rceil")
]

#text("For convenience, let us call it eq.(1). If we write ")#mi("6^{O(n)}=2^{O(n)}3^{O(n)}")#text(" and ")#mi("\\sigma_\\infty(n)=E(n)+O(n)")#text(" in eq.(1), then we can ")#mi("O(n)")#text(" on both sides and eq.(1) becomes eq.(2). The surprising thing is that formulas like eq.(2) also work for each individual step in the Syracuse formulation. Supposed that after ")#mi("j")#text(" steps of application of Syracuse mapping,")#mi("n\\to n_1\\to\\cdot\\to n_j")#text(" and ")#mi("n,n_i")#text(" are odd numbers, we obtain ")#mi("2^{a_{[1,j]}} n_j= 3^j n +Q=3^j n(1+r_j),(4)")#text(", where ")#mi("Q=3^{j-1}+\\sum_{0\\leqslant i\\leqslant j-2} 3^{j-2-i}2^{a_{[1,i+1]}},(5)")#text(". This two formulas are copied from your paper titled “almost all…”. We notice that ")#mi("a_{[1,j]}=E(n,n_j)")#text(" and ")#mi("j=O(n,n_j)")#text(". Ignore ")#mi("r_j")#text(" terms, we obtain, from eq.(4), that ")#mi("E(n,n_j)=\\lceil \\log_2\\left(\\tfrac{n}{n_j}3^{O(n,n_j)}\\right)\\rceil,(6)")#text(",")#linebreak()#mi("O(n,n_j)=\\lfloor \\log_3\\left(\\tfrac{n_j}{n}2^{E(n,n_j)}\\right)\\rfloor,(7)")#text(". where ")#mi("E(n,1)=E(n), O(n,1)=O(n),(8)")#text(". We verified eq.(6) and eq.(7) using the same seeds that we verified eq.(2) and eq.(3). For all seeds that we tested, the ")#mi("r_j(n)")#text(" terms are found to monotonicly increasing from a small real number to about ")#mi("0.2")#text(" as j goes from ")#mi("1")#text(" to ")#mi("O(n)")#text(". The nice thing about eq.(6) and eq.(7) is that they do not rely on the truthfullness of Collatz conjecture any more. We hope that eq.(6) and eq.(7) could shed some light on our understanding of Collatz sequence. Sorry for the long question. Best regards and wishes, -Mike")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-687225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2025")])]

#text("See also ")#link("https://oeis.org/A368514/a368514.svg")[#text("https://oeis.org/A368514/a368514.svg")]#text(" which maps succession parity on a lattice, and shows that there are no loops and that each value eventually leads to a drop.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-687453")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2025")])]

#text("Is there a more in depth explanation of the separation of powers of 2 and 3 you derived? Preferably something like a formal paper. What I am trying to understand is how it relates to the part of your argument which uses the entropy function.")

#emph[#text("[I have not developed this blog post into a more formal paper. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-687461")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2025")])]

#text("Would you ever be interested in developing it into a full paper in the future? Similarly to this blog post, I have found a connection between the Collatz problem and the entropy function. Specifically, I believe that the function has a multifractal spectrum, and the cycles have an associated Renyi entropy. Yet, I am at a loss on how this might connect to the arguments you’ve presented.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-687789")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2025")])]

#text("Dear Professor!")

#text("Are there consequences from ABC to the Collatz conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-687790")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2025")])]

#text("There is a very slight connection, in that ABC-type bounds can help rule out certain special types of Collatz cycles; see ")#link("https://arxiv.org/abs/2306.15284")[#text("https://arxiv.org/abs/2306.15284")]#text(" . However, they are not expected to be able to eliminate all such cycles.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba32d311959bcd5fc22bdbd564410e0635b83d02f892863158b1bf5ae4ce-2f4b2b5dafec2e2abc7e8714af36ad74401d82ddaaecbe212cdbdab60f559d17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kurt repository")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-687810")[#strong[#text("kurt repository")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2025")])]

#text("I’ve spent most of my life casually studying the Collatz Conjecture — not as a professional mathematician, but as a passionate and persistent hobbyist. Recently, I had a breakthrough that I believe might offer a genuinely new angle.")

#text("It’s not a formal proof, but I’ve written up a clear and detailed sketch of the idea. If you have a moment, I’d be incredibly grateful if you’d take a look — even just to let me know whether it’s worth developing further.")

#link("https://drive.google.com/file/d/1fkHtkJJ1SRDF7li6nArwBK8ARLABfxfX/view?usp=sharing")[#text("https://drive.google.com/file/d/1fkHtkJJ1SRDF7li6nArwBK8ARLABfxfX/view?usp=sharing")]

#text("Thank you for your time and all the inspiration you’ve provided to curious minds like mine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6be473cd27878a16c05724d91c3636638c3c90a62166449ca3b9b719cce7aaa3-e312ad17d5eed29d6e8aeba9be006f9c0a8eafbe6097bb02d8e2dbbc4b95dc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Mayers")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-688515")[#strong[#text("Andrew Mayers")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2025")])]

#text("Hello Dr Tao,")

#text("I believe there is a connection between the conjecture and “multifractal measures” by Evertsz and Mandelbrot. Specifically the leading term multiplied by n can be represented by a measure ")#mi("mu")#text(" with masses 1/4 and 3/4 multiplied by a weight of ")#mi("2^k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-688798")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2025")])]

#text("In Garner the stopping time is defined as the smallest ")#mi("k")#text(" for which ")#mi("f_0^k(n) < n")#text(" with ")#mi("f_0^k(n)= \\frac {n \\cdot 3^m +r}{2^{k-m}}")#text(" where ")#mi("r=3^{m-1}+\\sum\\limits_{i=2}^{m}{3^{m-i}\\cdot2^{d_1+\\cdots+d_{i-1}}}")#text(" where ")#mi("m")#text(" is the number of odd terms in the first ")#mi("k")#text(" terms of the sequence, ")#mi("d_i")#text(" is the number of consecutive even terms immediately following the i−th odd term.")#linebreak()#text("The value of ")#mi("r")#text(" can be seen as an alternative to the parity vector to identify the trajectory up to the m-th odd term.")#linebreak()#text("Garner also highlights that some residue classes modulo ")#mi("2^{k-m}")#text(" have a stopping time equal to ")#mi("k=m+ \\lfloor 1 + m \\cdot \\log_2(3) \\rfloor")#text(". It is possible to develop an algorithm that allows us to obtain these residue classes for a given value of ")#mi("m>1")#text(" from the values ​​obtained for ")#mi("m-1")#text(".")#linebreak()#text("It can be shown that for ")#mi("n")#text(" odd and ")#mi("n \\equiv x \\pmod{2^{k-m}}")#text(" if ")#mi("n")#text(" has stopping time ")#mi("k=m+ \\lfloor 1 + m \\cdot \\log_2(3) \\rfloor")#text(" as seen ")#mi("f_0^k(n)= \\frac {n \\cdot 3^m +r}{2^{k-m}}")#text(" where ")#mi("k-m=2^{d_1+\\cdots+d_m}")#text(" then for ")#mi("1\\leq d^{\\prime}_m < d_m")#text(" from ")#mi("r^{\\prime}=3\\cdot r+2^{d_1+\\cdots+d_{m-1}+d^{\\prime}_m}")#text(" using the modular inverse ")#mi("x^{\\prime}\\equiv \\frac {-r^{\\prime}}{3^{m+1}}\\pmod{2^{k^{\\prime}-(m+1)}}")#text(" where ")#mi("k^{\\prime}=m+1+\\lfloor 1 + (m+1) \\cdot \\log_2(3) \\rfloor")#text(" it is possible to find values ​​of ")#mi("n \\equiv x^{\\prime} \\mod{2^{k^{\\prime}-(m+1)}}")#text(" that have stopping time equal to ")#mi("k^{\\prime}")#text(".")#linebreak()#text("I think that studying these values ​​of ")#mi("r")#text(" for the different residue classes is equivalent to studying the properties of numbers of the form described in (8) on this page, has anyone already addressed this aspect?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-688807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2025")])]

#link("https://zenodo.org/records/16886068")[#text("Here ")]#text("is a more detailed explanation with some examples.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4dac58488ffdd068dfa9e07d9066be6efb2a9ee45d878391fde15c56a39e528-3df670c88644e738af444cf932c91531175d639c8470ea7e8219e184ba696400.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pinkthoughtfullydc9abc2e99")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-5/#comment-691651")[#strong[#text("pinkthoughtfullydc9abc2e99")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("Rather than separating powers of 2 and 3 via additive-combinatorial methods, one can rephrase the obstruction to nontrivial cycles as a finitary projective constraint on binary alignment, encoded by a DFA. In this formulation, any putative cycle would have to correspond to a cycle in the automaton that is incompatible with unbounded growth")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/299cf347497591e2825a98fe3ed4bfd64279952115afbb4130aa0182d43874c0-8464bd819c940e65b941c9e38aecf394aba5dbab4b860bb4703a6f35032fa8ce.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giả thuyết 3n+1 | REDSTAR-BLOG DÀNH CHO TOÁN")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-532754")[#strong[#text("Giả thuyết 3n+1 | REDSTAR-BLOG DÀNH CHO TOÁN")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2019")])]

#text("[…] học đương đại.” Terence Tao cũng đồng ý với quan điểm trên trong bài blog năm 2011 của […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-657638")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2022")])]

#text("6/2=3, odd")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/538fb09b2211f1d93ff034a7f417948a1dbfe26953bf86655e11bf8d47905f3d-9f76b0270f01cfc61fbde9f5ac4466d2cd463e7b831ea09d7805b6cf3ebbbde2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-532780")[#strong[#text("Joao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2019")])]

#text("Hi. It all cames down to n/2. Because if the number is odd it becomes an even number in the first operation. And if a number is even you divide by 2. Any even number divided by 2 results in a even number, exeption being 2 which results in 1. So all calculations in sequence for n/2 will end in 1. And 1 will be transformed in a even number and so we are back to n/2 resulting in 1 in a cycle. So we can be sure collatz results allways in 1. This reasoning may not mathematicaly prove it, I dont know mathematics enough to understand where I am making my leap of fate, but it sure made it seem unecessary to try to find and exeption by brute force computing. Finding that exception would disporve it, right? But there will not be one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b80b846dd5de0412fffc8bc3874cd9cc938ba907404f4e9d5a2efdc09a56760-29947c666d5d9a42a14bc8d0a9646a88d024daec5e76a3e54ee3b6c6b551ce7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus Mödinger")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-632414")[#strong[#text("Klaus Mödinger")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2021")])]

#text("Each uneven number multiplied by 2 gives an even number. So there is an infinite amount of even numbers which, divided by 2, result in an odd number.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7d88aff4854dda66d04b24483d3b3f4b869135debde8cfbd7ce31faaabbecfe-9cbf6fe2df0e6a23d06ab1b1d0762ba7ad2e856988d8c305f94f5ba4b5755742.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-637161")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2021")])]

#text("Tu deducción es razonable pero el problema que se pide resolver no es ese pues el algoritmo sigue los pasos que hasta que no se obtiene un resultado de 1 no se detiene. Es decir que se cuestiona si existe un número que utilice el algoritmo de forma infinita que nunca se pueda detener (órbitas no acotadas) y si no existe otra órbita recursiva diferente a 4-2-1. Si no existen estas 2 situaciones se entiende que el algoritmo siempre llega a 1 y como dije eso no es de lo que se duda y por lo tanto no se pide una demostración orientada en esa dirección.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7d88aff4854dda66d04b24483d3b3f4b869135debde8cfbd7ce31faaabbecfe-9cbf6fe2df0e6a23d06ab1b1d0762ba7ad2e856988d8c305f94f5ba4b5755742.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-637162")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2021")])]

#text("Your deduction is reasonable but the problem that is asked to solve is not that because the algorithm follows the steps that until a result of 1 is obtained it does not stop. In other words, it is questioned whether there is a number that the algorithm uses infinitely that can never be stopped (unbounded orbits) and whether there is no other recursive orbit other than 4-2-1. If these 2 situations do not exist, it is understood that the algorithm always reaches 1 and as I said that is not in doubt and therefore a demonstration oriented in that direction is not requested.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e86a6f6c3cc58f0a311a9b0c93c1517ee97a8639c0e224dddd61a600782989e-e9cd0b862ae749f2733bf352f2ccd438c8c96f44db0de526de6f1ed83630dcd4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Comments and Collatz Conundrum – Matt Mullenweg")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-532852")[#strong[#text("Comments and Collatz Conundrum – Matt Mullenweg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2019")])]

#text("[…] Medal-winning mathematician considered one of the best of his generation, got an anonymous comment on his WordPress blog post from 2011 exploring the Collatz conjecture — one of the most persistent problems in math — suggesting he explore the problem for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-532866")[#strong[#text("Mathematician Terence Tao Cracks a ‘Dangerous’ Problem – My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2019")]

#text("[…] this past August an anonymous reader left a comment on Tao’s blog. The commenter suggested trying to solve the Collatz conjecture for “almost all” numbers, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-532911")[#strong[#text("Matt: Comments And Collatz Conundrum - RSSFeedsCloud")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2019")]

#text("[…] Medal-winning mathematician considered one of the best of his generation, got an anonymous comment on his WordPress blog post from 2011 exploring the Collatz conjecture — one of the most persistent problems in math — suggesting he explore the problem for “almost […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-533022")[#strong[#text("Mathematician Terence Tao Cracks a ‘Dangerous’ Problem - CLICK NOW")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2019")]

#text("[…] this past August an anonymous reader left a comment on Tao’s blog. The commenter suggested trying to solve the Collatz conjecture for “almost all” numbers, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbf9735ff708824cce275186f810929b6333fc8308817d14ee510a3e2c83a72f-c03467fe53b7334d309b171b84b685624408633e4ee26325889a558964253ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marco Maga")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-533252")[#strong[#text("Marco Maga")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2019")])]

#text("A “9n+1” problem would be easier to solve?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-673697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2023")])]

#text("In a sense, yes, it actually would be easier to solve. Particularly because there is absolutely no reason to believe it would ever resolve. The 9x+1 variant has been heuristically and rigorously determined to increase over iterations of the transformation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b2f99642e1f2a0d6478a8200ebe5517ca3682179ba26afc5d3ecc0c6d17738a-571892e5f13b72894e52093fbd1c3ea92f18886f155c4dec0597360a7fdd428c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zhihao81")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-533337")[#strong[#text("zhihao81")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("In order to solve the issue, you might like to use the method of a hologram and taoist concept.")#linebreak()#text(" ")#link("https://www.learnreligions.com/tao-te-ching-verse-42-3183165")[#text("https://www.learnreligions.com/tao-te-ching-verse-42-3183165")]#linebreak()#text(" You should have noted that odd numbers have a longer lifespan-taoist call them Yang numbers, while even numbers have a shorter lifespan(yin numbers).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b2f99642e1f2a0d6478a8200ebe5517ca3682179ba26afc5d3ecc0c6d17738a-571892e5f13b72894e52093fbd1c3ea92f18886f155c4dec0597360a7fdd428c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zhihao81")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-533340")[#strong[#text("zhihao81")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("You can combine the hologram concept with taoist philosophy to prove the validity of 3x+1.")#linebreak()#text(" Taoist are highly sensitive to numbers.")#linebreak()#text(" You should have observed by now that odd numbers last longer than even numbers. Taoists call odd number Yang, even numbers yin.")#linebreak()#text(" ")#link("https://www.learnreligions.com/tao-te-ching-verse-42-3183165")[#text("https://www.learnreligions.com/tao-te-ching-verse-42-3183165")]#linebreak()#text(" Remember that many philosophies mention that so above, as below(universe is holographic).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f48757a6cb07fe9fcb955f3e0acbb15a9915bd4413cea01343ae4889eeb7bf1a-48503663c34c9d860192d3cdb04273d159b1224d1391a8f7d076d3648c008259.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peng Yu (@unameit8626348)")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-533721")[#strong[#text("Peng Yu (@unameit8626348)")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2019")])]

#text("n can be even or odd, \\vec{n} = (2k, 2k+1). f(\\vec{n}) = (k, 3k+2).")#linebreak()#text(" we can use a 2×2 matrix A = { {1/2, -1/2}, {0, 2} }, to implement f(\\vec{n})= F(\\vec{n}) = A * \\vec{n} . to prove F(\\vec{n}) always converge to (1, 0). we only need to study the convergence of A . which has eigenvalue (2, -1/2).")#linebreak()#text(" from the Jordan normal form, A won’t converge.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f48757a6cb07fe9fcb955f3e0acbb15a9915bd4413cea01343ae4889eeb7bf1a-48503663c34c9d860192d3cdb04273d159b1224d1391a8f7d076d3648c008259.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peng Yu (@unameit8626348)")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-533728")[#strong[#text("Peng Yu (@unameit8626348)")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2019")])]

#text("nvm… this linear function only applies to the first step :(")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-534243")[#strong[#text("Comments and Collatz Conundrum – Matt Mullenweg | Wordpress Tutorials")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2019")]

#text("[…] Medal-winning mathematician considered one of the best of his generation, got an anonymous comment on his WordPress blog post from 2011 exploring the Collatz conjecture — one of the most persistent problems in math — suggesting he explore the problem for “almost […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ebfca13f8209a64c13961205331399bac0ffcc3f033070593fae6ed1718b849-b11a1c5711807d240363b9dc51d8c6b8463fd4814d141b629929756f2cd8a0b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iiiduncaniii")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-534618")[#strong[#text("iiiduncaniii")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2020")])]

#text("I don’t know, maybe it’s just me, I think all these attempts to prove this conjecture, is just a bunch of people trying to show off their advanced math skills. The problem starts as 2 simple statements. The only argument you can make that you can’t prove every number will eventually fall to the 4-2-1 loop is because of 1) the amount of time it would take a person to one by one try every possible number to infinity and 2) the limitation on computers to find an answer. Sad story is that computers will never reach infinity no matter how powerful they become. I guess this would mean this conjecture will never be proven. To me though proving this conjecture to not fall to 4-2-1 loop would be like saying try to find 2 numbers x and y where y=x-1 and they are both divisible by 3. Well start using computers until you find that number! I am sure someone out there would attempt this. Probably the same one/ones who try to prove that 1=2 or that infinity =12 or that need 300 pages to prove 1+1=2 (consider that it took Einstein 46 pages to show the theory of relativity).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-536176")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2020")])]

#text("It’s true, you don’t know it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-536620")[#strong[#text("Zahlentheorie: Das Collatz-Problem, Sirenengesang für Mathematiker – Multilingual Scrapper")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2020")]

#text("[…] sollte sich ändern, als im August 2019 ein anonymer Leser einen Kommentar auf Taos Blog hinterließ. Darin schlug er vor, das Problem nicht allgemein anzugehen, sondern es […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-536621")[#strong[#text("Number theory: The Collatz problem, siren singing for mathematicians - 2NYZ.com")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2020")]

#text("[…] ‘d change when in aug 2019 an anonymous reader a comment on tao’s blog. in it, he suggested that the problem ‘d not be tackled in general, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-571112")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2020")])]

#text("Is it possible to to get a nontrivial separation between power of 2 and 3 by some (specifically designed) sieve method (as was done for twin primes)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-572504")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2020")])]

#text("I doubt sieving methods are effective for capturing such extremely sparse sets of numbers as powers of 2 and 3; the tools that have proven to be effective for such problems (transcendence theory and diophantine approximation, mostly, and potentially also arithmetic geometry) are quite different from sieve methods.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b640e39318e58ca461f43c9353f22d68c53e749ab7539c1a0237bef528a4dac5-8ebabe409732a6bc6642fd1bcf4e2f881d9cf6c9640007e23e0a931e4517faf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David S")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-572464")[#strong[#text("David S")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2020")])]

#text("You can use Ellison’s estimate, $|2^x-3^y| \\geq 2^x e^{-x/10}$, which holds for $x \\geq 12$ with $ x \\neq 13, 14, 16 19, 27$ and all $y$. This is based on results by Pillai and Baker. Reference: “WJ Ellison, On a theorem of S. Sivasankaranarayana Pillai, S´eminaire de th´eorie des nombres de")#linebreak()#text(" Bordeaux, 1970 (1971), pp. 1–10.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a149ac49363eb75d5f9e1f22f498d5e23a198a27aa7e151a42388192a83d96d9-cd7886553e95a63dd1004e081328308460b2e82d4c38e5f1a21e7532a00473a1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dabler")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-572963")[#strong[#text("dabler")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2020")])]

#text("This post is to let you know that the limit has been raised to which Collatz problem is computationally verified, and at the moment it is 2^68.")

#text("Reference: D. Barina. Convergence verification of the Collatz problem. The Journal of Supercomputing, 2020. DOI: 10.1007/s11227-020-03368-x URL: ")#link("https://rdcu.be/b5nn1")[#text("https://rdcu.be/b5nn1")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-573263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2020")])]

#text("The reduction of the Collatz iteration into simpler bit operations may indicate the possibility to prove the Collatz conjecture by a similar (entropy based) technique as recently done in the solution of Erdos discrepancy problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/283a79f79ccc4803244efe562e5fb3e80240ac3451dcae2614718721bb567787-c9b8137060354fa185a642e6d0401866365137ae66777d3d6e1d3480498027be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mugbuff")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-579038")[#strong[#text("mugbuff")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")])]

#text("It is a fact that you can list all the integers that converge to any integer for up to 6 levels (i. 6 iterations of 3n+1) above that integer without any possibility of a loop. You can then go 6 levels above each integer at those 6 levels, effectively going 12 levels up and so on to infinity. Thus no loop is possible.")#linebreak()#text(" A reverse of the argument precludes an endless process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-581785")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2020")])]

#text("The essence of the 3x+1 conjecture is the iterative operation of odd numbers. It is known from the basic theorem of arithmetic: the number of factors with a value equal to 2 in each even number is determined for the even number, so an iterative operation for odd numbers x can be defined, that is:")#linebreak()#text(" ")#mi("T=\\frac{3x+1}{2^a}")#text(", (where ")#mi("a")#text(" is the number of factors whose value in ")#mi("3x+1")#text(" is equal to 2), the result of the operation ")#mi("T")#text(" is still odd number.")#linebreak()#text(" According to this definition, the general formula for odd continuous iteration can be derived, that is")#linebreak()#text(" ")#mi("T^{(k)}(x)=\\dfrac{\\displaystyle{3^k x+\\sum_{i=1}^{k}2^{g(i-1)}3^{k-i}}}{2^{g(k)}}.")#text(" (where ")#mi("g(i+1)>g(i), g(0)=1")#text(")")#linebreak()#text(" From this, if the odd continuous iteration may cause loops, then we can deduce the equation that")#linebreak()#text(" ")#mi("x=\\dfrac{\\displaystyle{3^k x+\\sum_{i=1}^{k}2^{g(i-1)}3^{k-i}}}{2^{g(k)}}.")#linebreak()#text(" Solving this equation can get the result that the equation has no positive integer solution except 1, which indicates that continuous iteration cannot cause a loop.")#linebreak()#text(" On the other hand, the odd-number continuous iterative formula can be transformed into a linear indefinite equation.")#linebreak()#text(" ")#mi("A_kY=B_kx+C_k.")#text(" (where ")#mi("\\displaystyle{Y=T^{(k)}(x), A_k=2^{g(k)}, B_k=3^k, C_k=\\sum_{i=1}^{k}2^{g(i-1)}3^{k-i}}")#text(")")#linebreak()#text(" The process of solving the equation reveals that it is impossible for odd numbers to reach infinity through iterative operations. Therefore, all odd numbers will return to 1 after a limited number of iterations.")#linebreak()#text(" By extending this result to even numbers, it can be determined that all positive integers will return to 1 after a finite number of iterations, which fully proves the 3x + 1 conjecture.")

#text("My article The Collatz conjecture and linear indefinite equation is in the following website")#linebreak()#text(" ")#link("http://www.sciepub.com/tjant/content/8/2")[#text("http://www.sciepub.com/tjant/content/8/2")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-581787")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2020")])]

#text("Correction: ")#mi("g(0)=0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/423b9edd6cabc6d205096f9a31574b20ee234a2fd9b10ccf9ad72a22cc48e352-dae76dcdccd62669d1088ead427e8b08a47cf40ca240c6a9fd147a782e85fd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-581828")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2020")])]

#text("Dear Li Jiang,")

#text("The flaw in your paper is that you omit that, according to your own definitions, both a and g depend on x. Hence your “linear equation” in x is in fact not a linear equation. It is very non-linear, and unsolvable with current techniques.")

#text("Best regards,")

#text("Antoine")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-581866")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#text("Dear Antoine Deleforge,")

#text("That’s right, because both a and g depend on x, so as parameters, for every certain x, a and g are certain. The linear equation here is a linear indefinite equation, and the value of the parameter does not affect the linear relationship between Y and x.")

#text("Best regards,")

#text("Li Jiang")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b24ea14e7c066552508ac1704b0f4e9d1a9a424f127308cd86974e701c8c2e38-f79fd15aace800f59d9c7b5d2de7815697fda7db3aa41b5041d95ff2d68c7eab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lyndon Clarke")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-588987")[#strong[#text("Lyndon Clarke")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2020")])]

#text("I have failed the years of contour integration over multi-dimensional manifolds. I think it is perhaps provable that this problem is unprovable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77f60baad5e7b450eb757bc55732fab5fd2416704a24c38fbc8f4777d2d85359-e836f97369c995b9b7a9c26b2ecb69ead9cc133bc11b8b9cc5279aa96849454c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dick Pountain")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-591084")[#strong[#text("Dick Pountain")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2020")])]

#text("I’ve been doing computational experiments on Collatz sequences, and have found something approaching a power-law relationship between successive numbers with peak Collatz heights: height appears roughly proportional to seventh root of the number. Not exact, subject to random noise, but roughly constant magnitude. A sample:")

#text("N Collatz height N N^⅟₇ / height (x100)")#linebreak()#text(" 156159 382 1.44502")#linebreak()#text(" 216367 385 1.50213")#linebreak()#text(" 230631 442 1.32041")#linebreak()#text(" 410011 448 1.41432")#linebreak()#text(" 511935 469 1.39453")#linebreak()#text(" 626331 508 1.32510")#linebreak()#text(" 837799 524 1.33915")#linebreak()#text(" 1117065 527 1.38739")#linebreak()#text(" 1501353 530 1.43905")#linebreak()#text(" 1723519 556 1.39907")#linebreak()#text(" 2298025 559 1.44995")#linebreak()#text(" 3064033 562 1.50271")#linebreak()#text(" 3542887 583 1.47895")#linebreak()#text(" 3732423 596 1.45750")#linebreak()#text(" 5649499 612 1.50598")#linebreak()#text(" 6649279 664 1.42073")#linebreak()#text(" 8400511 685 1.42395")#linebreak()#text(" 11200681 688 1.47722")#linebreak()#text(" 14934241 691 1.53251")#linebreak()#text(" 15733191 704 1.51545")

#text("Is this sort of stuff of interest to anyone, or any group?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-591090")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2020")])]

#text("No.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77f60baad5e7b450eb757bc55732fab5fd2416704a24c38fbc8f4777d2d85359-e836f97369c995b9b7a9c26b2ecb69ead9cc133bc11b8b9cc5279aa96849454c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dick Pountain")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-591085")[#strong[#text("Dick Pountain")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2020")])]

#text("Oops, doesn’t like my tabs")

#text("N Height N N⅟₇ / Height")#linebreak()#text(" 156159 382 1.44502")#linebreak()#text(" 216367 385 1.50213")#linebreak()#text(" 230631 442 1.32041")#linebreak()#text(" 410011 448 1.41432")#linebreak()#text(" 511935 469 1.39453")#linebreak()#text(" 626331 508 1.32510")#linebreak()#text(" 837799 524 1.33915")#linebreak()#text(" 1117065 527 1.38739")#linebreak()#text(" 1501353 530 1.43905")#linebreak()#text(" 1723519 556 1.39907")#linebreak()#text(" 2298025 559 1.44995")#linebreak()#text(" 3064033 562 1.50271")#linebreak()#text(" 3542887 583 1.47895")#linebreak()#text(" 3732423 596 1.45750")#linebreak()#text(" 5649499 612 1.50598")#linebreak()#text(" 6649279 664 1.42073")#linebreak()#text(" 8400511 685 1.42395")#linebreak()#text(" 11200681 688 1.47722")#linebreak()#text(" 14934241 691 1.53251")#linebreak()#text(" 15733191 704 1.51545")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8801f7c57f1ea9ac8d5c24cd6f7fb74a6ee089ab5a708992fe18412d14b2141d-2c349bb2bc987c90836c3c28ada1b47a2795c8db1a4827ca4bc37fc07633a542.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hashem salarvand rostamy")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-597443")[#strong[#text("Hashem salarvand rostamy")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("Hi")#linebreak()#text(" Mr. Terry Tao")

#text("I have good news for the world’s mathematicians.")#linebreak()#text(" The collatz conjecture was proved.")

#text("I endured many hardships and insomnia to prove this extremely difficult conjecture.")#linebreak()#text(" When I was 19 years old, I proved a theorem that allowed me to logarithmize numbers directly on a random basis with a regular calculator that could only do multiplication and division. And I did this without using math series. And for some reason I never sent an article about it.")#linebreak()#text(" Until in 2018, I stumbled upon the issue of Kolatz’s conjecture. I immediately began my research on this conjecture, and on October 18, 2020, I finally succeeded in proving the Kolatz conjecture mathematically and logically. And I ended the myth of the 83-year-old unsolvable mystery.")

#text("I do not want to have my own 19-year-old problem, and I strongly want this method of proof to be registered in my name and to keep the results available to me.")

#text("I disagree with this article and can only prove Kolatz’s conjecture live at a math conference or an online webinar in the presence of several mathematicians at the University of Los Angeles or another university at your suggestion and in the presence of several reporters.")

#text("I currently live in Iran, Lorestan province, Doroud city, Andisheh neighborhood. And I sent you a message from here.")

#text("Hoping to meet in Los Angeles")#linebreak()#text(" من از مترجم گوگل استفاده کردم")#linebreak()#text(" منتظر جواب شما هستم")#linebreak()#text(" موفق باشید")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fa5e57e7aeb8f9388712db5a42f3ee4a0a348a897d6e207acdd6e822217b712-76a2905122a55068b2dca680b3df3b9b364c16eb0c4b6baed4fb9e6e019309d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rafael Leal")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-598697")[#strong[#text("Rafael Leal")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("One thing that I noticed is that at first the numbers seem to climb up (increase) and the number gets bigger and bigger. However, eventually you will get a number that will start a sequence of long even numbers, which means the number decreases in value rather rapidly. Then, the number will continue to increase, but this will happen less and less frequently and the long even sequences will occur more often and often. It seems to me that one trick is to figure out how long will it take a number to reach a point where a long sequence of even numbers will occur. And, then how long will it be to the next cycle and so on. This process of decreasing by half is quick once you start encountering the long even sequences. It becomes clear that the cycles of even numbers increase in frequency (and length) over time while the cycles of odd numbers decrease in length and frequency as well. It follows that the probability that this n number will reach a long number that has already been proven to reach 1 will increase over time. The trick would be to choose a long number and using computers (like Charity Engine) prove that it will reach 1. Then choose an even longer number and prove that it will reach any of the results of the smaller number that reached 1. I would probably choose a handful of numbers to show that this is true of all numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7ef0f6a36d47130f269709a4d446ee4d73ec3d4009cd6e6253407021e3ecabc-0a6575ec824653b06941f38e2140095efadc02777f23e7f051f9b85569f97b9a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of markmca")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-598985")[#strong[#text("markmca")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2020")])]

#text("Not sure my previous reply worked, but you’re welcome to use our grid for free if it helps. We are very fond of helping pure maths projects that (supposedly) have no “value”. Cheers, MMcA")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b814aca81679ef4e95a5403793b87461dfed645a40b232e3cb64d9eff455858-c69f178c3aba01956b4c77f84f4dd55d5dcd0085778adca2c06402b17bd1dcb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-613643")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2020")])]

#text("Observation 1: If this problem has been solved for all numbers up to a certain number, then it should be easy to demonstrate that all even numbers up to double that number will also eventually lead to 1. That’s because the first step would be to divide the starting number in half, thus reaching a number that has already been shown to lead to 1.")

#text("Observation 2: If in the sequence, you hit on a power of 2, it will lead to 1 very quickly.")

#text("I’m sure I’m not the first one to think of this, but thought I’d share.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-622626")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2021")])]

#text("1. I’ve altered 3n+1 to run as 3n+K, where K is odd and greater than 2. Much failure due to trapped inside infinite loops. With K=1 there are no infinite loops and all go to 1. I see why with K=1 there are no infinite loops b/c all new generated values from 3n+1 fall between previous generated values.")

#text("2. Analyzed 3n+1 ST to see the numbers that have the same ST (grouping)")

#text("ST 2^n")#linebreak()#text(" ————")#linebreak()#text(" 1 2")#linebreak()#text(" 2 4")#linebreak()#text(" 3 8")#linebreak()#text(" 4 16")#linebreak()#text(" 5 32 5")#linebreak()#text(" 6 64 10")#linebreak()#text(" 7 128 21 20 3")#linebreak()#text(" 8 256 42 40 6")#linebreak()#text(" 9 512 85 84 80 13 12")#linebreak()#text(" 10 1024 170 168 160 26 24")#linebreak()#text(" 11 2048 341 340 336 320 53 52 48")#linebreak()#text(" 12 4096 682 680 672 640 113 106 104 96 17")#linebreak()#text(" 13 etc etc")

#text("3. Have you tried running 3n+1 just on a subset on numbers like all numbers evenly divisible by P, where P is Prime?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-622715")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2021")])]

#text("ops… must have steps on toes. I’ll stay off your blog. But you problem is NOT n/2, it’s 3n+1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c108f254caf233b52049ab85f39443a1bd0df9efd82fea15076121f91f3e7e89-32cf6c3637e4a660f4b5a8694e36e950de8b6a4f8727e7f67509f7cffc0fd349.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ngandji Ted")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-622644")[#strong[#text("Ngandji Ted")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2021")])]

#text("Quiconque crains ou vénére une incertitude fini par l’assimiler à Dieu. Vénérez donc comme tel quiconque démasquera ce faux Dieu.")#linebreak()#text(" La conjecture de Syracuse n’est rien d’autre qu’un enfant turbulent qui se prend pour Dieu.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notlikeireallyknow")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-623006")[#strong[#text("Notlikeireallyknow")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2021")])]

#text("Over thinking it.")

#text("Doesn’t matter what number it is, the fact that you add +1 to an odd makes it even. In a decimal system, , once you hit a multiple of 10, it will end the sequence. Since both equations results in an even number and we are working in a decimal system, the equation on each calculation has a 1/5 chance of hitting that magical 0 but because we work in a decimal system, it is guaranteed to hit that magical 0 because 2 is the basis of all even numbers so in an infinite sequence, it will always work out in a decimal system")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6ee0c495adc7bbccf57be29cdd12effcca838cd107ef762d0641df82e9ab10e-b067ca0d6bfea95b4882bfb2ddb9e3d53e87a35d21d4e8d1043316d636bdb516.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-623095")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2021")])]

#text("Use Base 6. Let that do the heavy work.")#linebreak()#text(" Checkout the last digits in the numbers base 6.")#linebreak()#text(" I believe:")#linebreak()#text(" 1) numbers ending in zero only occur at branch tips unless preceded by a zero")#linebreak()#text(" 2) numbers ending in 3 only occur once, following a zero or on a branch tip and followed by a number ending in 4")#linebreak()#text(" 3) numbers ending in 5 always followed by 4")#linebreak()#text(" 4) numbers ending in 2 always followed by 4")#linebreak()#text(" Interesting patterns and long increased values are produced by 55base6 or 555base6 or 5555base6 etc.")#linebreak()#text(" This may illustrate some of the underlying mechanisms.")#linebreak()#text(" I haven’t realized any relationship between the modulo 2 to recognize even numbers with the 3 used as the multiplier and 1 as an additive. There might be some reason that it works because 2 and 3 are relatively prime and have a difference of 1.")

#text("Good hunting.")

#text("Robert")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-624073")[#strong[#text("Links – Pug Charlie's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2021")]

#text("[…] hello […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01bf25d56c4e52b88f5b2452f58a1595c7a80e5f08b820eec49e6f8ad6760908-09c8b27efe61f545b178c07652999dae6407250ccd568650fe3bf99c94b504c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Naman Tenguriya")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-625161")[#strong[#text("Naman Tenguriya")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2021")])]

#text("I’ve tried to prove collatz conjecture and I don’t think it is incorrect. What should I do…🤔")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8801f7c57f1ea9ac8d5c24cd6f7fb74a6ee089ab5a708992fe18412d14b2141d-2c349bb2bc987c90836c3c28ada1b47a2795c8db1a4827ca4bc37fc07633a542.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hashemmath")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-625188")[#strong[#text("hashemmath")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2021")])]

#text("Hi")#linebreak()#text(" Today I am trying to submit the first article on collatz conjecture to a journal of the American Mathematical Society.")#linebreak()#text(" What made the Collatz problem confusing and Unproven was the unpredictability of the number of steps divided by two.")#linebreak()#text(" I got formulas for calculating the exact number of “divisibles” and the exact number of “triples plus one”.")#linebreak()#text(" Which are in fact the reasons for proving collatz conjecture.")#linebreak()#text(" If the American Mathematical Society accepts my article, then wait for the good news in mathematics.")#linebreak()#text(" Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-625212")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2021")])]

#text("Go to a dungeon and don’t come out until you prove it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3be7947fe05796281bd04c9e6d3ad6adad4d83d8e85679edb8f608beb98a597d-179d81dcb1caee909880a150a71bc70b568617208fc772545a3d2f6e4f2c4590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-625417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2021")])]

#text("You should read ")#link("https://frankheyne.de/collatz")[#text("https://frankheyne.de/collatz")]#linebreak()#text(" There is an amazing new view at the Collatz conjecture, which might be quite eye opening. And there is the proof that when the Collatz conjecture would be wrong, there should be an infinite number of different paths not leading to 1.")#linebreak()#text(" It is in German language, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78c93065c929e6823a66ea39a9e6e68deba1b09b194675546a515257fe600cd5-d86126683c6fe82886c195f3c3dbb09e975ae0b125f933cce15c4f46ab4c700d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob-8000")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-625940")[#strong[#text("Bob-8000")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2021")])]

#link("https://www.quantamagazine.org/mathematician-terence-tao-and-the-collatz-conjecture-20191211/")[#text("https://www.quantamagazine.org/mathematician-terence-tao-and-the-collatz-conjecture-20191211/")]

#text("The above article mentioned that you encountered some sort of skewing. Could this be related to prime numbers? At least to me it seems like one always ends up with a prime-number after one repeated the divide by two steps reaching an uneven number.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/255639aeca08319bae535cd7d1f3a668324572faa5955aefb0e72728c3cdbaad-ce8b9923293919953ac3fa1f025322fade0e1687c06cbaeb7a70ec938bb18ce9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walter")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-632404")[#strong[#text("Walter")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2021")])]

#text("Dr. Tao,")

#text("I have found families of Collatz type conjectures that may be of interest to you.")

#text("For any integer n >= 2, each n has a family of conjectures. Starting with initial value X, the sequences for each member in the family of n will eventually reach 1.")

#text("Rule set for generating the sequences for each family member of n with starting value X and positive integer k:")#linebreak()#text(" 1. If X is divisible by n then the next value of the sequence is X/n")#linebreak()#text(" 2. If X is not divisible by n then the next value of the sequence is (n^k)*X + n^k")

#text("I have written python programs that tested several values of n. Some of the values of n tested were 2, 3, 5, 6, 7, 10, 11, 13, 16, 101, and 210. For each of these n values, the values of k tested were 1, 2, 12, and 22. The sequences with starting values X that were tested all eventually reached 1.")

#text("Sorry if this was an inappropriate place to post the conjectures. I wasn’t sure how to address this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/255639aeca08319bae535cd7d1f3a668324572faa5955aefb0e72728c3cdbaad-ce8b9923293919953ac3fa1f025322fade0e1687c06cbaeb7a70ec938bb18ce9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walter")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-632467")[#strong[#text("Walter")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2021")])]

#text("On reflection. The construction above is trivially true. My bad")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c90dc59d020b6b7ceced9cb4b642f63881a652367b7d1037825a7098af7fd2cf-d2501b8777faf7f4e61e18b393dfa2d08455fda519b704608e5fafdbdb7f9cf8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Κωνσταντίνος Κουρουζίδης")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-632468")[#strong[#text("Κωνσταντίνος Κουρουζίδης")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2021")])]

#text("As professor Kontorovich said, it’s unlikely that more progress will be made to this problem. There are so many problems out there for people to try…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95703cb64738bf251f2138af0140e5c1a76ffe994b4771c93e89e05d290a9ef0-9b50b3852f96816721fe32bbc75b1dbc46ba8ad8d4a9f99141405a88bd6bf885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Di Savino")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-632883")[#strong[#text("Giovanni Di Savino")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2021")])]

#text("The Collatz conjecture. We take any whole number, if it is even we divide it by two, if it is odd we multiply it by three and add one unit to the result. Repeating this algorithm, after a certain number of steps, one always obtains 1. It is trivial to think of being able to represent or verify all integers that are infinite but Collatz applying a 3 * n + 1 algorithm, to each of the infinite integers, obtains l ‘nth odd number that generates the result of a power of 2 ^ n_pari which, by halving it for a known number of steps, we obtain 1. pdf of the display and simulation of the pdf how, when and why in ")#link("https://www.facebook.com/groups/280310948785723")[#text("https://www.facebook.com/groups/280310948785723")]

#text("Dott: Cinzia Di Savino")#linebreak()#text(" student: Silvana Di Savino")#linebreak()#text(" 75 enne: Giovanni Di Savino")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7d88aff4854dda66d04b24483d3b3f4b869135debde8cfbd7ce31faaabbecfe-9cbf6fe2df0e6a23d06ab1b1d0762ba7ad2e856988d8c305f94f5ba4b5755742.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-637160")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2021")])]

#text("Tu deducción es razonable pero el problema que se pide resolver no es ese pues el algoritmo sigue los pasos que hasta que no se obtenga un resultado de 1 no se detiene. Es decir que se cuestiona si existe un número que utilice el algoritmo de forma infinita que nunca se pueda detener (órbitas no acotadas) y si no existe otra órbita recursiva diferente a 4-2-1. Si no existen estas 2 situaciones se entiende que el algoritmo siempre llega a 1 y como dije eso no es de lo que se duda y por lo tanto no se pide una demostración orientada en esa dirección.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7d88aff4854dda66d04b24483d3b3f4b869135debde8cfbd7ce31faaabbecfe-9cbf6fe2df0e6a23d06ab1b1d0762ba7ad2e856988d8c305f94f5ba4b5755742.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-637163")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2021")])]

#text("Your deduction is reasonable but the problem that is asked to solve is not that because the algorithm follows the steps that until a result of 1 is obtained it does not stop. In other words, it is questioned whether there is a number that the algorithm uses infinitely that can never be stopped (unbounded orbits) and whether there is no other recursive orbit other than 4-2-1. If these 2 situations do not exist, it is understood that the algorithm always reaches 1 and as I said that is not in doubt and therefore a demonstration oriented in that direction is not requested.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/589d95b05b9b43c9be484289c424908a94be1f94aeb83fd0621a5e92bb249cb1-44915e3e19b4ff1c41534abf24855a0c940450a1f94414a331b09316fcd36ea6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Murillo")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-638773")[#strong[#text("Gastón Murillo")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("It is not necessary to process all the numbers. There are limits that can give a general solution, so a test is requested to show that all the orbits are bounded.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95703cb64738bf251f2138af0140e5c1a76ffe994b4771c93e89e05d290a9ef0-9b50b3852f96816721fe32bbc75b1dbc46ba8ad8d4a9f99141405a88bd6bf885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sacirisi")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-638280")[#strong[#text("sacirisi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2021")])]

#text("With the Collatz algorithm it is not possible to process all natural numbers because we do not know: quantities and values ​​of even and odd numbers and all their factors. From Tartaglia’s triangle we can detect odd numbers which are the sum of the results of the infinite powers of 2 which have an even index and which are also equal to the previous odd * 4 + 1. These are all the odd numbers that * 3 + 1 generate an even number that is the result of a base power 2 and even index 2 ^ (2 * n≥1) and that, the nth half, ends at 1 because ½ of 2 ^ 1 = 2 ^ 0 = 1. ")#link("https://vixra.org/abs/2112.0004")[#text("https://vixra.org/abs/2112.0004")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5170010f70c29afc35e4e33fa2a14517e816f9b215b890ec6435784900b6660-4b2ec332aeca9225cebfa98f36f767e2e5441d244b50e4e9c609910bdbc6b341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wulf Rehder")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-633254")[#strong[#text("Wulf Rehder")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2021")])]

#text("Rephrase the Collatz Conjecture: If m is the number of multiplications by 3 and m+k die number of divisions by 2 at index N=m+m+k of a Collatz sequence, then the sequence reaches its stopping time at N (i.e. the first time the sequence dips below its starting value) iff 2^(m+k) divided by 3^m is larger than 1 at this N for the first time, i.e., here the powers of 2 “win out” for the first time. Taking logs, this happens beyond the threshold t= [log3/log2]/[log3/log2+1]=0.613147… for every Collatz sequence, regardless of starting value. Therefore: For a sequence, find the index N=m+m+k where the “2-density” d=(m+k)/N exceeds t for the first time: this N is the stopping time. If in a sequence no d exists that exceeds t, then the Conjecture fails. No such sequence has been found.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c90cdbe25b4e9b694fb2fe670a5417380654fdc72432ad66721db07aa1c72b8-d58a5e154c465ca0da53167ade842972f47061d08f979ac1f650b686d575e4e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ℒℰℬÅℕℕℐ")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-633287")[#strong[#text("ℒℰℬÅℕℕℐ")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2021")])]

#text("Bonjour")

#mi("x=r.2^{n+1}+2^{n}-1\\\\\\\\f(x)=r.3^{n}+\\frac{3^{n}-1}{2})")#linebreak()#text(" 27=3.2²⁺¹ + 2²-1 ")#mi("3.3^{2}+(3^{2}-1)/2)=31")#linebreak()#text(" 31=0.2⁵⁺¹ + 2⁵-1 …")#linebreak()#text(" 121, 91, 103, 175, 445, 167, 283, 319, 911, 577, 433, 325, 61, 23, 5, 1")

#text("Amicalement")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ecbbee6c7d7e9d57c57390daa9c1de6f6e813577f2b4a18fb8a61a727985c90-c9e9038ba17dae7494f4e3d1cb3af1b41caec5eadb9f51d8a9ab5a1b7da872d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ℒℰℬÅℕℕℐ")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-637126")[#strong[#text("ℒℰℬÅℕℕℐ")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2021")])]

#text("Bonjour")#linebreak()#text(" 00.2⁵⁺¹ + 2⁵-1=_31_______011111")#linebreak()#text(" 01.2⁴⁺¹ + 2⁴-1=_47______101111")#linebreak()#text(" 04.2³⁺¹ + 2³-1=_71____1000111")#linebreak()#text(" 13.2²⁺¹ + 2²-1=107___1101011")#linebreak()#text(" 40.2¹⁺¹ + 2¹-1=161_10100001")

#text("\\\\x=r.2^{n+1}+2^{n}-1\\\\")#linebreak()#text(" 3x+1\\\\")#linebreak()#text(" =3.(r.2^{n+1}+2^{n}-1)+1\\\\")#linebreak()#text(" =3.r.2^{n+1}+3.2^{n}-2\\\\")#linebreak()#text(" (3x+1)/2\\\\")#linebreak()#text(" =3.r.2^{n} +3.2^{(n-1)}-1\\\\")#linebreak()#text(" =3.r.2^{n} +2^{n}+2^{(n-1)}-1\\\\")#linebreak()#text(" =(3.r+1).2^{n}+2^{(n-1)}-1\\\\")

#text("Converge vers 4X+1 successeur 3X+1")#linebreak()#text(" 161=4.40+1 -> 3.40+1=121")#linebreak()#text(" 5,9,13,17, 21, 25…")#linebreak()#text(" {3,5}")#linebreak()#text(" {9}")#linebreak()#text(" {13}")#linebreak()#text(" {7, …, 17}")#linebreak()#text(" {21}")#linebreak()#text(" {25}")#linebreak()#text(" {19,29}")#linebreak()#text(" {33}")#linebreak()#text(" {37}")#linebreak()#text(" {27,41}")#linebreak()#text(" {45}")#linebreak()#text(" {49}")#linebreak()#text(" {15, … , 53}")#linebreak()#text(" etc…")

#text("3x+1=2x+x+1")#linebreak()#text(" si")#linebreak()#text(" 1.x=010101")#linebreak()#text(" 2x =101010")#linebreak()#text(" 3x =111111")#linebreak()#text(" 3x+1=1000000 nombre de divisions par 2")#linebreak()#text(" Amicalement")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/140f6f19e9be19b78f64aa794194fb621eecc33bf03845bbe4f15a36a6c4f783-4b0d62f6bf9fc779c466fb586c30d5f04c691cd1470e502559a5ea5470068a43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ℒℰℬÅℕℕℐ")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-637127")[#strong[#text("ℒℰℬÅℕℕℐ")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2021")])]

#text("désolé")#linebreak()#text(" ")#mi("\\\\x=r.2^{n+1}+2^{n}-1\\\\ 3x+1\\\\ =3.(r.2^{n+1}+2^{n}-1)+1\\\\ =3.r.2^{n+1}+3.2^{n}-2\\\\ (3x+1)/2\\\\ =3.r.2^{n} +3.2^{(n-1)}-1\\\\ =3.r.2^{n} +2^{n}+2^{(n-1)}-1\\\\ =(3.r+1).2^{n}+2^{(n-1)}-1\\\\")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c5a68e67e38c2a754fe7e2261ce850d9eb1ca145e29996eb1bb195276e6a38c-0fc9ec5db7fb61d57d00ac384d020651e049dca057429032eced0d52d736caeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Watson")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-633545")[#strong[#text("Eric Watson")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2021")])]

#text("Here is my work that I have done to see if I could prove the Collatz conjecture. Let me know what you think of this work. To some it may seem elementary. To me it is only the beginning of a wonderful journey.")

#text("Summary: The Collatz conjecture deals with sequences that are defined in the following manner: Begin with any positive integer x. You will get each value from the previous term according to the following rules: If your previous value is even, the next term is half of the previous term. If the previous value is odd, the next term will be three times the previous value plus one. The conjecture made is that no matter what value of x, the sequence will always reach 1.")

#text("Rules of the Collatz Conjecture:")#linebreak()#text(" Rule 1: f(x) = 3x + 1 for odd number, x = 2k + 1 for k = 0, 1, 2, 3,… for the sequence of odd numbers.")#linebreak()#text(" Rule 2:f(x) = x/2 for even number, x = 2k + 2 for k = 0, 1, 2, 3,… for the sequence of even numbers.")#linebreak()#text(" Conjecture: Choose any positive integer, x. If it is odd plug into Rule 1. Else, if it is even plug into Rule 2. No matter what initial value you start with, the sequence will always reduce down to 1.")

#text("Step 1: Rewrite Rule 1, and Rule 2 in terms of the sequences for odd, and even numbers.")#linebreak()#text(" Rule 1: f(x = 2k + 1) = 3(2k + 1) + 1 = 6k + 3 + 1 = 6k + 4 = 2(3k + 2)")#linebreak()#text(" Rule 2: f(x = 2k + 2) = (2k + 2)/2 = k + 1")

#text("Step 2: Generate ordered pairs to graph out on the xy-plane.")#linebreak()#text(" Example – For k = 0, Rule 1 gives 4, and Rule 2 gives 1 so the ordered pair would be (4, 1). Here is what I found for the values of k from zero, to 101.")#linebreak()#text(" k X-values Y-values")#linebreak()#text(" 0 4 1")#linebreak()#text(" 1 10 2")#linebreak()#text(" 2 16 3")#linebreak()#text(" 3 22 4")#linebreak()#text(" 4 28 5")#linebreak()#text(" 5 34 6")#linebreak()#text(" 6 40 7")#linebreak()#text(" 7 46 8")#linebreak()#text(" 8 52 9")#linebreak()#text(" 9 58 10")#linebreak()#text(" 10 64 11")#linebreak()#text(" 11 70 12")#linebreak()#text(" 12 76 13")#linebreak()#text(" 13 82 14")#linebreak()#text(" 14 88 15")#linebreak()#text(" 15 94 16")#linebreak()#text(" 16 100 17")#linebreak()#text(" 17 106 18")#linebreak()#text(" 18 112 19")#linebreak()#text(" 19 118 20")#linebreak()#text(" 20 124 21")#linebreak()#text(" 21 130 22")#linebreak()#text(" 22 136 23")#linebreak()#text(" 23 142 24")#linebreak()#text(" 24 148 25")#linebreak()#text(" 25 154 26")#linebreak()#text(" 26 160 27")#linebreak()#text(" 27 166 28")#linebreak()#text(" 28 172 29")#linebreak()#text(" 29 178 30")#linebreak()#text(" 30 184 31")#linebreak()#text(" 31 190 32")#linebreak()#text(" 32 196 33")#linebreak()#text(" 33 202 34")#linebreak()#text(" 34 208 35")#linebreak()#text(" 35 214 36")#linebreak()#text(" 36 220 37")#linebreak()#text(" 37 226 38")#linebreak()#text(" 38 232 39")#linebreak()#text(" 39 238 40")#linebreak()#text(" 40 244 41")#linebreak()#text(" 41 250 42")#linebreak()#text(" 42 256 43")#linebreak()#text(" 43 262 44")#linebreak()#text(" 44 268 45")#linebreak()#text(" 45 274 46")#linebreak()#text(" 46 280 47")#linebreak()#text(" 47 286 48")#linebreak()#text(" 48 292 49")#linebreak()#text(" 49 298 50")#linebreak()#text(" 50 304 51")#linebreak()#text(" 51 310 52")#linebreak()#text(" 52 316 53")#linebreak()#text(" 53 322 54")#linebreak()#text(" 54 328 55")#linebreak()#text(" 55 334 56")#linebreak()#text(" 56 340 57")#linebreak()#text(" 57 346 58")#linebreak()#text(" 58 352 59")#linebreak()#text(" 59 358 60")#linebreak()#text(" 60 364 61")#linebreak()#text(" 61 370 62")#linebreak()#text(" 62 376 63")#linebreak()#text(" 63 382 64")#linebreak()#text(" 64 388 65")#linebreak()#text(" 65 394 66")#linebreak()#text(" 66 400 67")#linebreak()#text(" 67 406 68")#linebreak()#text(" 68 412 69")#linebreak()#text(" 69 418 70")#linebreak()#text(" 70 424 71")#linebreak()#text(" 71 430 72")#linebreak()#text(" 72 436 73")#linebreak()#text(" 73 442 74")#linebreak()#text(" 74 448 75")#linebreak()#text(" 75 454 76")#linebreak()#text(" 76 460 77")#linebreak()#text(" 77 466 78")#linebreak()#text(" 78 472 79")#linebreak()#text(" 79 478 80")#linebreak()#text(" 80 484 81")#linebreak()#text(" 81 490 82")#linebreak()#text(" 82 496 83")#linebreak()#text(" 83 502 84")#linebreak()#text(" 84 508 85")#linebreak()#text(" 85 514 86")#linebreak()#text(" 86 520 87")#linebreak()#text(" 87 526 88")#linebreak()#text(" 88 532 89")#linebreak()#text(" 89 538 90")#linebreak()#text(" 90 544 91")#linebreak()#text(" 91 550 92")#linebreak()#text(" 92 556 93")#linebreak()#text(" 93 562 94")#linebreak()#text(" 94 568 95")#linebreak()#text(" 95 574 96")#linebreak()#text(" 96 580 97")#linebreak()#text(" 97 586 98")#linebreak()#text(" 98 592 99")#linebreak()#text(" 99 598 100")#linebreak()#text(" 100 604 101")

#text("Step 3: Graph the ordered pairs you generate, and find that the equation of the line you get is y = x/6 + 1/3.")

#text("Step 4: Make some observations.")#linebreak()#text(" Observations:")#linebreak()#text(" A. The y-values for this equation are always one greater than chosen k-value, (where k = 0, 1, 2, 3,…).")#linebreak()#text(" B. The smallest y-value is y = 1.")#linebreak()#text(" C. The smallest x-value is x = 4.")#linebreak()#text(" D. The x-values increase by six each time (4, 10, 16, 22, 28, 34, 40,…)")

#text("Step 5: What happens when you plug in y = k + 1 (even-values), and x = 2(3k + 2)(odd values) into y = x/6 + 1/3?")#linebreak()#text(" y = x/6 + 1/3")#linebreak()#text(" k + 1 = 2(3k + 2)/6 + 1/3")#linebreak()#text(" k + 1 = (3k + 2)/3 + 1/3")#linebreak()#text(" k + 1 = (3k + 2 + 1)/3")#linebreak()#text(" k + 1 = (3k + 3)/3")#linebreak()#text(" k + 1 = 3(k + 1)/3")#linebreak()#text(" k + 1 = k + 1")#linebreak()#text(" 1 = 1")

#text("No matter what value we choose for k (k = 0, 1, 2, 3,…), the sequence will always reach 1 for y = x/6 + 1/3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e12d6f565659322969372ef57cb82edd90602534e7c4e94d8b6e826fe795b9f6-fdecd02bc9ee7ba32d0561a410ae80b3fd9428f2e6bfd07ffdc39772d064bebb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-636909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2021")])]

#text("Dr. Tao,")#linebreak()#text(" On this conjecture,I have a new idea. I have finished an articale in chinese.Can I email it to you?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8e16b162435fa0027ef88063c22592aebfa720b632e2a03c76692374cae22fb-c01dbda0fa6069f8c8f14f9331598cb02c06d7e87ee1677d3edcb0be66a3675e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Croft")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-637228")[#strong[#text("Andrew Croft")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2021")])]

#text("re Collatz using Syracuse odd numbers only, I note that the cases where N mod 8 is 3 or 7 then the next item is (3N+1)/2 and when N mod 8=1 then next item (3N+1)/4. Only when N mod 8=5, do we potentially have multiple divide by 2s. However when N mod 8=5, the following number in the sequence is the same for N or (N-1)/4. For example 29 and 117 both have 11 as the next number in the sequence. For purpose of demonstrating solution to 1 to the non-mathematicians, it would be clearer to amend Collatz sequence for N mod 8=5 to use (N-1)/4, and then resume as normal. Point being that it really highlights just how stacked the deck is, to stay away from the attractor for any period of time one needs >3 cases where N mod 8 is 3 or 7 for every case where N mod 8 equals 5 … which we see for a while with 27, but eventually not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-637447")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2021")])]

#text("Can the Mandelbrot set be used to test Cllatz conjecture? or do the numbers generated by Cllatz conjecture form a Bifurcation diagram?")

#text("— I’m not a mathematician just curious")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-637476")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2021")])]

#text("The formula (1) from conjecture 3 works for negative cycles ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0bd77bb5bfbd992fedd6b78becac29deed2f8b7e6956bddf9f2c13f692df47-91af081fab92e1c21a2ce216a9554fbbdb524c7390678abf96655ee52f0c066f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dennis Estenson")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-638273")[#strong[#text("Dennis Estenson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2021")])]

#text("I came across your website because I recently decided to try to prove the Collatz conjecture. I found it really boils down to one fairly easy to prove statement. The next odd number in the sequence cannot grow by more than 1 binary digit, and often shrinks by more than one binary digit, and there are no sequences that only grow. One can build a seed that grows an arbitrary number of digits, but no finite seed will cause the sequence to grow forever.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-643485")[#strong[#text("A Method to Not Prove the Collatz Conjecture - good fibrations")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")]

#text("[…] theory is the cocaine of mathematics. The following resulted not from my intention to prove the conjecture, but from the drive to deeply understand its underlying […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/655de7fb9073c427d020cbe8eebca883bf094165bf6643b0ac8c8bf2848cc2d7-e97d95b5de80e834b2ee7c238376344d82ad0375922c0bee1122180fe81b015c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-643830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2022")])]

#text("Collatz looks like a decision tree. I wonder if there’s any dimensional relation with Riemann’s.")#linebreak()#text(" Also, on a graph, a Collatz sequence looks like the collapse of a particle wave function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-650565")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2022")])]

#text("Hello everyone. Here again trying to help to find the solution to the conjecture.")

#text("WE START FROM THE IDEA THAT THE CONJECTURE IS EQUIVALENT TO that for all n odd")

#mi("n\\times 3^{k}+d_{k}= 2^{k+y}")

#text("where ")#mi("d_{k}")#text(" is a positive value of the form(8)")

#mi("3^{k-1}2^{a_{1}}+3^{k-2}2^{a_{2}}+...+2^{a_{k}}")

#text("where k is the number of times you multiply by 3 and k+y is the number of times you divide by 2")

#text("then there are infinite solutions for ")#mi("3^{k+1}")#text(" and ")#mi("2^{k+y+2}")#text(",")#mi("3^{k+2}")#text(" and ")#mi("2^{k+y+4}")#text(" ,…")

#text("So, how do you find infinite solutions to this equation? Well, I really don’t know, but this is what I have observed.")

#text("If there is a solution for")

#mi("n\\times 3^{k}+d_{k}= 2^{k+y}")

#text("then it exists")

#mi("n-d_{n}= 2^{y-k}")

#text("(Important note. Perhaps here we are already assuming the truth of the conjecture and everything else is meaningless)")

#text("such that")

#mi("d_{k}= -d_{n}\\times 3^{k}+2^{y-k}3^{k-1}+2^{y-k+2}3^{k-2}+2^{y-k-4}3^{k-3}+2^{y-k-6}3^{k-4}+...+2^{y+k-2}")

#text("then")

#mi("n\\times 3^{k}-d_{n}\\times 3^{k}+2^{y-k}3^{k-1}+2^{y-k+2}3^{k-2}+2^{y-k-4}3^{k-3}+2^{y-k-6}3^{k-4}+...+2^{y+k-2}=2^{y+k}")

#text("and")

#mi("(n-d_{n})\\times 3^{k}+2^{y-k}3^{k-1}+2^{y-k+2}3^{k-2}+2^{y-k-4}3^{k-3}+2^{y-k-6}3^{k-4}+...+2^{y+k-2}=2^{y+k}")

#text("then")

#mi("2^{y-k}\\times 3^{k}+2^{y-k}3^{k-1}+2^{y-k+2}3^{k-2}+2^{y-k-4}3^{k-3}+2^{y-k-6}3^{k-4}+...+2^{y+k-2}=2^{y+k}")

#mi("2^{y-k}\\times (3^{k}+3^{k-1})+2^{y-k+2}3^{k-2}+2^{y-k-4}3^{k-3}+2^{y-k-6}3^{k-4}+...+2^{y+k-2}=2^{y+k}")

#mi("2^{y-k}\\times (3^{k-1}\\times 2^{2})+2^{y-k+2}3^{k-2}+2^{y-k-4}3^{k-3}+2^{y-k-6}3^{k-4}+...+2^{y+k-2}=2^{y+k}")

#mi("2^{y-k+2}\\times 3^{k-1}+2^{y-k+2}3^{k-2}+2^{y-k-4}3^{k-3}+2^{y-k-6}3^{k-4}+...+2^{y+k-2}=2^{y+k}")

#text("…")

#mi("2^{y-k}\\times 3^{k}+...=2^{y+k}")

#text("So at this point, one might ask if for all ")#mi("n")#text(" odd and ")#mi("d_{n}")#text(" there is a value ")#mi("d_{k}")#text(" or some other type of relationship or restriction such that there are infinite solutions and establish the validity of the conjecture .")

#text("I hope it is of some interest. Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd18a0c129516022e325fe0b142a54e0d634175b77bebf5b9855ffb90d368a8b-dff90523cfdd680dc95ef4bceccc3af35386afa989d98d4250b082d32305058c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leszek Mazurek")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-657860")[#strong[#text("Leszek Mazurek")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2022")])]

#text("Your observation is the key component of my proof available here -> ")#link("https://www.researchgate.net/publication/351347153")[#text("https://www.researchgate.net/publication/351347153")]

#text("abstract: In this paper, we prove the Collatz conjecture. We show that if a given number can be represented in a form of a certain specific equation then Collatz conjecture is true for that particular number. Next we propose a procedure that for a given number produces this specific equation and we prove that for every initial positive integer, such equation can be found.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e883f61848b085491b0b5c672939df21e5727ccb12f1da3d50301ae521a0a59-f6bf4ab766852d147b2b0d691e3ac1cd744cce6b6c0c1841dfbd96a0c9976de5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fábio Sanches")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-659849")[#strong[#text("Fábio Sanches")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2022")])]

#text("Terry Tao, would you be able to prove the Collatz Conjecture if there was a simple formula to calculate the iterations?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-671473")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2023")])]

#text("Hello everyone. Happy New Year. As the professor recommends, once or twice a year it is not bad to spend a little time on this crazy conjecture. I don’t know if this post has been a bit out of date due to the professor’s subsequent work, but following the professor’s instructions, I continue to investigate about the structural properties of numbers of the form")

#mi("\\displaystyle 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k}")#text("(8)")

#text("I don’t know if someone has made any progress on these numbers, but I put forward the proposal in this comment to study a characteristic of these numbers.")#linebreak()#text(" As it is said in the post,”Now we can perform a heuristic count on the number of counterexamples. If we fix ")#mi("{k}")#text(" and ")#mi("{a := a_{k+1}}")#text(", then ")#mi("{2^a > 3^k}")#text(", and from basic combinatorics we see that there are")

#mi("\\binom{a-1}{k-1}")

#text("different ways to choose the remaining integers”, when for there to be a counterexample we need at least k integers.")#linebreak()#text(" If we could somehow reduce the possible values to k-1, then there could be no counterexample to the weak conjecture.")#linebreak()#text(" For this I wonder if studying the different values of the numbers of the form (8) and more specifically, all those that are equal, except for the final term ")#mi("2^{a_{k}}")#text(", and we could establish that they are coprimes, independently of the value of ")#mi("2^{a}-3^{k}")#text(", then it would be possible to establish that the different ways to choose the remaining integers are less than k?")

#text("Thanks and greetings to all")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-671498")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2023")])]

#text("Many deterministic “chaotic-like” dynamical systems can produce approximate statistical distribution laws (e.g. in probabilistic number theory, statistical classical mechanics, etc.) – so it is reasonable that this iteration may also produce such emergent approximate statistical distribution “empirical laws”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b24ea14e7c066552508ac1704b0f4e9d1a9a424f127308cd86974e701c8c2e38-f79fd15aace800f59d9c7b5d2de7815697fda7db3aa41b5041d95ff2d68c7eab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lyndon Clarke")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-671525")[#strong[#text("Lyndon Clarke")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2023")])]

#text("Interesting comment, but a bit boring. It is already proved that Collatz has no solution, lost to Godel space.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-671746")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2023")])]

#text("The post says “I know of no way to get a nontrivial separation property between powers of ")#mi("2")#text(" and powers of ")#mi("3")#text(" other than via transcendence theory methods” and “Thus we see that any proposed proof of the Collatz conjecture must either use transcendence theory, or introduce new techniques that are powerful enough to create exponential separation between powers of ")#mi("2")#text(" and powers of ")#mi("3")#text("”")

#text("Observing the numbers of the form")

#mi("3^{k-1}+3^{k-2}2^{a^{_{1}}}+...+2^{a_{k}}")#text("(8)")

#text("We can see that the minimum value of this set of numbers coincides with the value of the little-known Difference of nth powers for 3 and 2")

#mi("a^{n}-b^{n}=(a-b)(a^{n-1}+a^{n-2}b^{1}+...+b^{n-1} )")

#link("https://proofwiki.org/wiki/Difference_of_Two_Powers")[#text("https://proofwiki.org/wiki/Difference_of_Two_Powers")]

#text("then for a fixed ")#mi("k")#text(" and ")#mi("a")#text(", where ")#mi("a =k+y")#text(" and ")#mi("2^{k+y} - 3^{k}= q >0")#text(" , could we set a way to get a nontrivial separation property between powers of 3 and powers of 2 of the form")

#mi("2^{k+y}-3^{k}=2^{k}(2^{y-1})-(3^{k}-2^{k})=q")#text(" ???")

#text("and study in the set of values of the form (8) if they could be multiples of this value, which is beyond my knowledge.")#linebreak()#text(" Thanks . Regards")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-672817")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2023")])]

#text("Hi again. Correction to previous comment")#linebreak()#text(" ")#mi("2^{k+y}-3^{k}=2^{k}(2^{y-k}-1)-(3^{k}-2^{k})")

#text("Ok, now let’s try another way")

#text("REMEMBER THAT WE ARE STUDYING THE POSSIBILITY OF FALLING INTO A NON-TRIVIAL PERIODIC ORBIT WITH A BOUNDED SET OF ODD INTEGER")

#text("TO DO THIS WE ARE GOING TO INTRODUCE A TYPE OF ACCELERATED MAP THAT I AM NOT SURE IF IT IS TRIVIAL OR ALREADY KNOWN BEFORE AND THAT I TALKED ABOUT IN A PREVIOUS COMMENT. FOR ME IT IS A KIND OF COL 2.1 MAP, SINCE IT TELLS US HOW MANY TIMES THE COL 2 MAP IS REPEATED FOLLOWING THE WORST POSSIBLE PATH, AND THAT THIS WORST INITIAL OR SUB-ORBIT IS FINITE")

#text("for all odd ")#mi("n_{0}")

#mi("n_{0}=z_{0}2^{x}-1")

#mi("n_{0}=z_{0}2^{x}-1\\rightarrow n_{1}=z_{1}2^{x-1}-1\\rightarrow n_{3}=z_{3}2^{x-2}-1\\rightarrow ...\\rightarrow n_{x}=z_{x}2^{1}-1")

#text("map that we can summarize")

#mi("n_{0}=z_{0}2^{x}-1\\rightarrow n_{0 }+z_{0}(3^{x}-2^{x})=n_{x}2^{y}")

#text("That is to say, that any worse orbit, the one that after 1 multiplication by 3 is followed only by a division by 2, ends in an even number that is divided by 2 at least one more time.Although we still don’t know the exact number of times it will be divided by 2")

#text("Then we can establish a list of values based on best orbit to worst orbit")

#mi("\\begin{matrix} k=1\\rightarrow  & 1 & 5 & 9 & ...\\\\   k=2\\rightarrow & 3 &11  & 19 &... \\\\   k=3\\rightarrow & 7 & 23 & 39 & ...\\\\   ...\\rightarrow & ... & ... & ... &.... \\\\   k=\\infty \\rightarrow & ... &...  & ... &...  \\end{matrix}")

#text("This map can be useful to speed up or summarize the orbit from one integer k=1 to another. Also as a heuristic that the orbit is decreasing: the difference between the number of times you divide by 2 and the number of times you multiply by 3 tends to infinity.")

#text("But how could we use this map to establish that there is no periodic orbit, except the trivial one?")#linebreak()#text(" As we know, a periodic orbit is bounded, that is, it is formed by a finite number of integers (always speaking of odd numbers).")

#text("At this point I ask for your help.")

#text("If we use this map in reverse, as Collatz preimages, don’t we find that this map tells us that th iteration in reverse is infinite, unbounded?")#linebreak()#text(" Or do we reach a multiple of 3 and the iteration cannot go backwards, but neither can it form a non-trivial periodic orbit?")

#text("Thank you and greetings")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22c3210a1ff18ee6127e6829f7266f70c6519aba7de93db909937057b9ccc773-aa9eee1047d07ca9e62c0ccf24041511f0ef6f15fe755edc373dc97cd25e73ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WG")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-673643")[#strong[#text("WG")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2023")])]

#text("This recent work claims progress on non-trivial Collatz cycles: ")#link("https://doi.org/10.31219/osf.io/u24gq")[#text("https://doi.org/10.31219/osf.io/u24gq")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-4/#comment-673646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2023")])]

#text("Thank you for letting us know. It must be correct.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480531")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("There is a combinatorial rule about stopping time, which cannot be violated. I don’t know if we’re talking about the same rule:")

#text("The same first odd term (following ")#mi("n")#text(") recurs for ")#mi("n*4+1")#text(", ")#mi("n*4^2+4+1")#text(", ")#mi("n*4^3+4^2+4+1")#text(", ")#mi("n*4^4+4^3+4^2+4+1")#text(", and so on. All ")#mi("n")#text("s belong to such a set. If you know the stopping time for one member of the set you know it for all.")

#text("Here’s a small table demonstrating this is true: ")#link("https://qph.ec.quoracdn.net/main-qimg-cc48a7a7dfe4b957b6bd9062202cae9b.webp")[#text("https://qph.ec.quoracdn.net/main-qimg-cc48a7a7dfe4b957b6bd9062202cae9b.webp")]#text(".")

#text("Explanation: An iterative function ")#mi("{f(n)=3n+1}")#text(" is going to generate composites with odd prime or composite factors multiplied by an exponent of ")#mi("2")#text(". So, one half of the Collatz sequence is generating these ")#mi("*2")#text(" or ")#mi("*2*2...")#text(", and the other half is stripping them away. A ")#mi("4n+1")#text(" function is going to find primes or odd composite factors, but geometrically further apart. These primes or odd composites are going to be the first terms of sequences – for example, ones that begin with ")#mi("29")#text(".")

#text("58 = 2 * 29")#linebreak()#text(" 232 = 2 * 2 * 2 * 29")#linebreak()#text(" 928 = 2 * 2 * 2 * 2 * 2 * 29")#linebreak()#text(" 3712 = 2 * 2 * 2 * 2 * 2 * 2 * 2 * 29")

#text("The reason that the stopping time increases by ")#mi("2")#text(" according to size is the two extra divisions by ")#mi("2")#text(" to strip the padding from the odd number.")

#text("P.S.")#linebreak()#text(" I’m following the instructions for latex formatting – forgive me if this comes out disastrously wrong. I’ve written about this subject in further detail here: ")#link("https://www.quora.com/In-the-Collatz-conjecture-why-do-the-numbers-n-and-4n+1-share-the-same-Collatz-sequence/answer/Michael-M-Ross")[#text("https://www.quora.com/In-the-Collatz-conjecture-why-do-the-numbers-n-and-4n+1-share-the-same-Collatz-sequence/answer/Michael-M-Ross")]

#emph[#text("[LaTeX repaired – one needs to put a space after $latex – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480717")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2017")])]

#text("Yes, It is able to define the stopping time in that case, as you said.")

#text("But your question above about a superset, I call something like the set as the parent set.")#linebreak()#text(" Where the one member of the set is also being as a member of the child set.")#linebreak()#text(" So that the sequence called the hailstone. And defining the stopping time of such superset seems to be difficult or undefinable.")

#text("It seems to be hard to prove the conjecture by showing the well-defined stopping time.")#linebreak()#text(" But all number have their own ID as a member of the child set. Those members of the set are well-ordered, and the parent sets are also well-ordered.")#linebreak()#text(" Plus, such odd number: x<f(x) can maps to the number x'≻f(x').")

#text("It's the key to all number converge 1. It is just in my opinion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480740")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2017")])]

#text("This may sound radical, but neither 3n+1 nor Powers of 2 are required to generate Collatz sequences.")

#text("There’s another type of function, call it “x-1/x+1”, that produces a proper superset of the odd numbers of each sequence. Every odd number is generated, in order, by this function – and some additional odd numbers that could not be with 3n+1. Those are multiples of 3 and prime numbers.")

#mi("f(n) = \\begin{cases} n+ \\frac {n+1}{2}, & \\text{if } n+1 \\equiv 0 \\text{ mod } 4 \\\\ n-\\frac{n-1}{4}, & \\text{if } n-1 \\equiv 0 \\text{ mod } 8 \\\\ \\frac {n-\\frac{n+1}{2}}{2}, & \\text{otherwise} \\end{cases}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480747")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2017")])]

#text("The superset I’m thinking about is different to yours, sorry. I don’t use the 4n+1 rule.")

#text("So I could not understand clearly what your function suggests.")#linebreak()#text(" “every odd number is generated, in order” yes it looks right. But it could be more simplified by another way of representation, I think.")

#text("And I just follow the ordinary (called shortcut?) rule for the conjecture.")

#text("f^1+j (n) = 3(n)+1 /2^j if n = odd")#linebreak()#text(" f^h (n) = (n) /2^h if n = even j,h ≥ 1.")

#text("Thank you for sharing your ideas!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480750")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2017")])]

#text("So I mean, the function like your x-1/x+1 function could be also represented by another definition. I am not certain the function is completely the same of yours.")#linebreak()#text(" But your function genarates all odd number is right, then the results of the both functions must be the same.")

#text("*I am sorry for my poor explanation and bad english.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480756")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2017")])]

#mi("3n+1")#linebreak()#text(" **43**, 130, **65**, 196, 98, **49**, 148, 74, **37**, 112, 56, 28, 14, **7**, 22, **11**, 34, **17**, 52, 26, **13**, 40, 20, 10, **5**, 16, 8, 4, 2, **1**")

#mi("n-1/n+1")#linebreak()#text(" **43**, **65**, **49**, **37**, 9, **7**, **11**, **17**, **13**, 3, **5**, **1**")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480796")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2017")])]

#text("(I’m sure your work with DB trees and hierarchies is far more interesting than my ideas.)")

#text("I want to address this point of the “ordinary function” as you’ve written it: It uses *3 and /2…. That’s half the problem.* What my function does is express much more precisely that there are three and only three results for every odd n:")

#text("1. If n+1 is divisible by 4, add 0.5n to n.")#linebreak()#text(" 2. If n-1 is divisible by 8, subtract 0.25n from n.")#linebreak()#text(" 3. If neither case applies, subtract 0.75n from n.")

#text("No surprise then that when we look at the odd ns of any sequence, values increase by half and decrease by a quarter or three-quarters:")

#text("27")#linebreak()#text(" 41 + 0.518")#linebreak()#text(" 31 -0.756")#linebreak()#text(" 47 + 0.516")#linebreak()#text(" 71 + 0.510")#linebreak()#text(" 107 + 0.507")#linebreak()#text(" 161 + 0.504")#linebreak()#text(" 121 -0.751")#linebreak()#text(" 91 -0.752")#linebreak()#text(" 137 + 0.505")#linebreak()#text(" 103 -0.751")#linebreak()#text(" 155 + 0.504")#linebreak()#text(" 233 + 0.503")#linebreak()#text(" 175 -0.751")#linebreak()#text(" 263 + 0.502")#linebreak()#text(" 395 + 0.501")#linebreak()#text(" 593 + 0.501")#linebreak()#text(" 445 -0.75")#linebreak()#text(" 111 -0.25")

#text("Hmm, has this regularity ever been noted for the odd ns? The sum of these values is a negative sum. The sequence terminates because of the frequency of mods 4 and 8 (and their absence).")

#text("Now it turns out that the disjoint occurrence of the moduli for x-1/x+1 eliminates the possibility of circularity because n+1 and n-1 cannot have moduli 4 and 8 for the same n. It’s one or the other (or the third condition of divisibility by 3 or 1, or a prime).")

#text("mod 4 mod 8 mod 3")#linebreak()#text(" 27 28 0")#linebreak()#text(" 41 40 0")#linebreak()#text(" 31 32 0")#linebreak()#text(" 47")#linebreak()#text(" 71")#linebreak()#text(" 107")#linebreak()#text(" 161 160 0")#linebreak()#text(" 121 120 0")#linebreak()#text(" 91 92 0")#linebreak()#text(" 137 136 0")#linebreak()#text(" 103 104 0")#linebreak()#text(" 155 156 0")#linebreak()#text(" 233 232 0")#linebreak()#text(" 175 176 0")#linebreak()#text(" 263 264 0")#linebreak()#text(" 395 396 0")#linebreak()#text(" 593 592 0")#linebreak()#text(" 445 444 0")#linebreak()#text(" 111 112 0")

#text("*It’s a bad thing that this puzzle got the title the “3x+1 Problem”. It’s been rattling around in peoples’ heads too long; it even sells books. The conjecture is not the formula.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480797")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2017")])]

#text("That second list of numbers is meant to look like this: ")#link("https://qph.ec.quoracdn.net/main-qimg-c8f24efd5ed20026ddb50c08aaa43de2")[#text("https://qph.ec.quoracdn.net/main-qimg-c8f24efd5ed20026ddb50c08aaa43de2")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480811")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2017")])]

#text("So your x±1 function shows the odd number≢0 (mod.3) ?")#linebreak()#text(" If so, It would of course generates every odd number. But there is the certain rules about the indices of 2. I mean, because the generator of every odd number is the Collatz odd (multivalued) inverse mapping.")#linebreak()#text(" That’s why I use the shortcut function ” f^1+j= 3x+1 /2^j ” for x≔odd≢0(mod.3). I don’t deal with 3x+1 and /2^j separately.")

#text("And even is just the (multivalued) inverse mapping of odd. So even can be ignored.")

#text("Your findings:")#linebreak()#text(" 1. If n+1 is divisible by 4, add 0.5n to n.")#linebreak()#text(" 2. If n-1 is divisible by 8, subtract 0.25n from n.")#linebreak()#text(" 3. If neither case applies, subtract 0.75n from n.")

#text("Actually I still could not understand cleary(..sorry that’s why I am an amatrue!) But I think it might be related the rules of the indices of 2 what I explained above.")#linebreak()#text(" And the mod. 4 list of 27–111, there is {27,41,31,47,71…}≡{-1,+1,-1,-1,-1…(mod.4)} Does it have any regularity of the ordering of -,+,-.. ?")#linebreak()#text(" Personally, I think this randomness IS undefinable.")

#text("My mind image of the 3x+1 structure, there is actually the symmetrical or fractal hierarchy (which represents the depths of the subsets of odd), but it’s not so important. There is just the permutation of the terms of odd number.")#linebreak()#text(" I have only four formulea which represent about the sets: Two parent sets(sueprset) and Two child sets(which converge thier parent sets). But the member of the parent sets is also being a member of the child sets… I can not explain cleary anymore.")

#text("Anyway, that sets can show almost all x≻1 is converge the number which less than x.")#linebreak()#text(" So, the final problem of the conjecture will be able to done If all such number; x<f^1+j(x) can be mapped to x'≻f^1+j(x'). It is just my personal opinion. ..And it can.")

#text("Our approachs are different, but I hope they will reach the same conclusion :) …I can not write the paper, though..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480826")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2017")])]

#text("That above three results for every odd is very definite and surprising.")#linebreak()#text(" I can grasp a part of it but not completely a whole thing.")#linebreak()#text(" I’m tackling the conjecture with another way of yours, although each of them seem to describe something like the same thing, I think.")#linebreak()#text(" Forgive me my lack of understanding. lack of explanation, English and my rudeness.")

#text("Thanks for sharing your ideas!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jrg")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480844")[#strong[#text("jrg")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2017")])]

#text("Don’t think I’ve seen this function before and humbly suggest you try to prove something useful with it and that takes a lot of work! But I bet it took a lot more thinking and work to come up with this function than you perhaps realize. So to me, from an ethics point of view, that means your name, if you wished, ought to be listed as coauthor on the first published peer reviewed paper to ‘prove’ anything new or useful with it. Good luck!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480872")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2017")])]

#text("I’m not certain that your comment is for me or Mr.Ross or someone else.")#linebreak()#text(" If it is to me, thanks! if not, sorry I’m embarassing..")

#text("Although I’ve found these ideas in my own way, however I found a paper by Prof. Hellekalek just yesterday. and found in there that my notion for the conjecture is almost the same to his notion. I don’t understand the paper completely because I’m an amateur, but I would like to support his study.")

#text("Here is the paper by Professor Perter Hellekalek.")

#link("https://arxiv.org/pdf/1605.02634.pdf")[#text("Click to access 1605.02634.pdf")]

#text("According to his paper, these above inverse mapping and shortcut fuction are not new. such function is called “the accelerated Collatz function” T.")

#text("I’m just an amature, so my result for the conjecture is more specific…well, what I would like to say is, there is more straightfoward formulea with numbers.")

#text("Anyway, thanks for your comment! (..if it is to me)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480873")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2017")])]

#text("I am very sorry that if your comment is for Mr.Ross…!! His function is specific!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480830")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2017")])]

#text("Your English is good, you’re very polite. I think of it as a boardgame with three moves. It’s a probability game with a 100% probability that the piece will land on 1 given the moves permitted by either x-1 or x+1 being congruent 0 with Mod 8, Mod 4, or the Otherwise case (of 3, prime, or 1).")

#text("I am the ultimate amateur. It may be heresy: I don’t see this as a difficult problem. That doesn’t mean a formal proof would be easy or that there is not a lot of interesting work to be done, like yours, but from my POV I feel confident the game has only one solution.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-480876")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2017")])]

#text("I agree with you that “think of it as a boadgame.” it is the reason why I soppose that the hierarchy is not so important.")#linebreak()#text(" And you say “with three moves”, …Yes!! It might be the same thing to you what I see in there. but I don’t think the conjecture is a probability game, though!")

#text("Your point of veiw and the data is very exact, Thank you very much for sharing your study with us!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1168be2c8d8669b3544da7fe93f8e4ef4048eb2a464bf4b6c7d69eae4a7b6b21-25ad86cbdc2b8df30c593ff5139429374ed711a9c4d0edfb1b8ae38f19897be0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chris3991m")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-481061")[#strong[#text("chris3991m")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2017")])]

#text("So I’m not sure about my so-called proof, but I have a couple ideas (read if you want Dr. Tao):")

#text("1. Notice as I mentioned, in the weak Collatz conjecture, 2^(ak+1) > 3^k. Thus, if we keep repeating this cycle, the ratio (3^k)/(2^(ak+1)) keeps decreasing. Could we use this fact to somehow prove that the cycle also would have to be decreasing (or close), leaving the only option n = 1?")

#text("2. Would it be possible to find the maximum of (3^(k-1) + 3^(k-2)*2^(a2) + … + 2^(ak))/(2^(ak+1) – 3^(k)) using calculus or advanced analysis? This is beyond my knowledge, but if we could find this value, and show that every value of n below it converges to 1, we will have proven that the only possible value of n can be 1.")

#text("Chris Smith")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1168be2c8d8669b3544da7fe93f8e4ef4048eb2a464bf4b6c7d69eae4a7b6b21-25ad86cbdc2b8df30c593ff5139429374ed711a9c4d0edfb1b8ae38f19897be0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chris3991m")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-481074")[#strong[#text("chris3991m")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2017")])]

#text("One more thing to add: If you can find the maximum of number 2, I have already developed a method to prove that every odd number must converge to 1. This uses a combination of probability and algebra. Hopefully, you will be interested.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-483414")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2017")])]

#strong[#text("Five simple ideas for untangling this loopy conjecture")]

#strong[#text("Idea 1")]#linebreak()#text(" Every ")#mi("3n+x")#text(" (Collatz-type conjecture) contains an input-output loop for ")#mi("n=x")#text(" (where ")#mi("n")#text(" is odd). The twist is that this includes ")#mi("x = 1")#text(".")#linebreak()#text(" This is merely a factual statement because:")#linebreak()#text(" If ")#mi("n = x")#text(" then ")#mi("3x+x=4x")#text(" and ")#mi("\\frac {4x}{4} = x")#text(".")#linebreak()#text(" It is only trivial for ")#mi("3n+1")#text(". Why? Because ")#mi("1")#text(" is the starting point and the endpoint of the loop.")

#strong[#text("Idea 2")]#linebreak()#text(" The even numbers can be eliminated. Let me call this the ")#mi("n-1/n+1")#text(" function.")

#mi("f(n) = \\begin{cases} n+ \\frac {n+x}{2} & \\text{if } n+x \\equiv 0 \\text{ (mod } 4) \\\\ n-\\frac{n-x}{4} & \\text{if } n-x \\equiv 0 \\text{ (mod } 8) \\\\ \\frac {n-\\frac{n+x}{2}}{2} & \\text{otherwise} \\end{cases}")

#text("Since the next even term following ")#mi("3n+1")#text(" is half, we know that it’s also latex $1$ minus the product of the previous odd ")#mi("n")#text(" and ")#mi("1.5")#text(":")#linebreak()#text(" ")#mi("n_{e} =")#text(" ")#mi("(n_{o}+1*1.5)-1")

#text("For example:")#linebreak()#text(" ")#mi("n_{o} =661")#text(" and ")#mi("n_{e} = 992")#text(", ")#mi("n_{o} =165")#text(" and ")#mi("n_{e} = 248")#text(", ")#mi("n_{o} =41")#text(" and ")#mi("n_{e} = 62")

#text("Each smaller ")#mi("n")#text(" is one-quarter of the previous one:")#linebreak()#text(" For the odds: ")#mi("(n_{o2}= \\frac {n_o1}{4})-1")#linebreak()#text(" For the evens: ")#mi("n_{e2}= \\frac {n_e1}{4}")

#strong[#text("Idea 3")]#linebreak()#text(" All odd-numbered sequences can be reduced to three operations of multiplication:")#linebreak()#text(" ")#strong[#text("a.")]#text(" If ")#mi("n+x")#text(" is divisible by ")#mi("4")#text(", multiply by ")#mi("1.5")#text(", subtract ")#mi("x")#linebreak()#text(" ")#strong[#text("b.")]#text(" if ")#mi("n-x")#text(" is divisible by ")#mi("8")#text(", multiply by ")#mi("0.75")#text(", add ")#mi("x")#linebreak()#text(" ")#strong[#text("c.")]#text(" Else multiply ")#mi("n-x")#text(" by ")#mi("0.25")

#text("We can call this the a, b, c congruence. It’s important for a number of reasons, including the fact that they are self-switching according the follow rules:")#linebreak()#text(" –For ")#strong[#text("a")]#text(", ")#mi("n+1")#text(" has a minimum exponent of ")#mi("2^2")#text(" for multiplication by ")#mi("1.5")#text(". With each ")#mi("n")#text(" product of ")#mi("1.5")#text(", the exponent decreases by latex$2$.")#linebreak()#text(" –For ")#strong[#text("b")]#text(", ")#mi("n-1")#text(" has a minimum prime factor exponent of $latex2^4$ for multiplication by ")#mi("0.75")#text(". With each ")#mi("n")#text(" product of ")#mi("0.75")#text(", the exponent decreases by ")#mi("2")#text(".")#linebreak()#text(" –For ")#strong[#text("c")]#text(", which for ")#mi("(n\\geq13)-1")#text(" always has prime factors ")#mi("2^2")#text(", is a class that contains the odd terminating numbers, say for ")#mi("27")#text(": ")#strong[#text("53")]#text(", 13, 3, ")#strong[#text("5")]#text(", ")#strong[#text("1")]#text(".")

#strong[#text("Idea 4")]#linebreak()#text(" All complex loops are determined by the congruence of two successive numbers equaling ")#mi("x")#text(".")

#text("For example, take sequence ")#mi("27")#text(" and ")#mi("x=11")#text(":")#linebreak()#text(" ")#strong[#text("31→5")]#text(", 5→13, 13→25, 25→43, 43→35, 35→29, 29→49, 49→79, ")#strong[#text("79→17")]#text(", 17→31")

#text("There are two looping pairs: ")#mi("31")#text(", ")#mi("5")#text(" and ")#mi("79")#text(", ")#mi("17")#text(" because:")#linebreak()#text(" ")#mi("11 \\equiv 31")#text(" (mod ")#mi("5")#text(")")#linebreak()#text(" ")#mi("11 \\equiv 79")#text(" (mod ")#mi("17")#text(")")

#text("The amusing twist is that again this must be true for $latex $x = 1$. But unless the modulus is $latex $\\geq 3$ this congruence-based looping cannot occur.")

#strong[#text("Idea 5")]#linebreak()#text(" The regression to ")#mi("1")#text(" occurs because of exponents of ")#mi("2")#text(", not powers of ")#mi("2")#text(".")

#text("As we know, powers of ")#mi("2")#text(" terminate conventional sequences. For example, to take an extreme case, the entire ")#mi("3n+1")#text(" sequence of ")#mi("87381")#text(" is:")#linebreak()#text(" 262144, 131072, 65536, 32768, 16384, 8192, 4096, 2048, 1024, 512, 256, 128, 64, 32, 16, 8, 4, 2, 1")

#text("This becomes, in the ")#mi("n-1/n+1")#text(" sequence:")#linebreak()#text(" 87381, 21845, 5461, 1365, 341, 85, 21, 5, 1")

#text("It’s the same pattern described above of division by ")#mi("4")#text(", quartering in every step: ")#mi("(n_{o2}= \\frac {n_o1}{4})-1")#text(".")

#text("There are no common odd numbers save one, ")#mi("1")#text(".")

#text("(Excuse the long post.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/589d95b05b9b43c9be484289c424908a94be1f94aeb83fd0621a5e92bb249cb1-44915e3e19b4ff1c41534abf24855a0c940450a1f94414a331b09316fcd36ea6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Granfernando")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-523709")[#strong[#text("Granfernando")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2019")])]

#text("These propositions are very close to the work of Carolin Zobelein About the proof of the Collatz conjecture ")#link("https://arxiv.org/pdf/1303.2073.pdf")[#text("https://arxiv.org/pdf/1303.2073.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ebe8e128bc91eec28cccf42eff4db42a08632630b08c92d46086147b379f19a-274507f1dc5cfdb21b9c916b6a3b9279e9f88bccfde8e345b41275ace08d083f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lz2263546927")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-488564")[#strong[#text("lz2263546927")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2017")])]

#text("The algebraic structure of collatz conjecture：Construct the domain transformation: x = 3n + d, y = 3n-d, z = n/2. 1. d = 0, n = 0, x = 3 × 0 + 0 = 0, y = 3 × 0-0 = 0, z = 0/2 = 0. 2. d = 1, n = 0, x = 3 = 0 + 1 = 1, y = 3 × 0-1 = 1, z = 0/2 = 0. 3. If d belongs to Z, n belongs to N+, x = 3 × 1 + d, y = 3 ×1-d, z=n/2; If d belongs to Z and n belongs to N,x= 3× (-1) + d, y = 3 × (-1) -d, z = n / 2. (1) If d belongs to Z, n belongs to N+.【1】 (3 × 1 + d1-1) / 3 = (3 × 1-d1) / 2, d1 = 1; (3 × 1-d2-1) / 3 = (3 × 1 + d2) / 2 , d2 = -1. 【2】 (3 × 1 + d3) / 2 = 2 (3 × 1 + d3), d3 = 9/5; (3 × 1 + d4) / 2 = 2 (3 × 1-d4), d4 = 9/5. 【3】 3 (3 × 1 + d5) + 1 = 2 (3 × 1 + d5), d5 = 4/5; 3 (3 × 1 + d6) + 1 = 2 (3 × 1-d6) ,d6= -4 / 5. Take d = 1, then x = 4, y = 2, eavailable loop A = (4,2,1,4). According to the principle of transformation, when n = 1 satisfies 3 × 1 + 1 = 4,3 × 1-1 = 2, the circular circle F = (4,2,1,4) = A is obtained, so available loop circle(A , A). Therefore, the 3n + 1 transformation on the positive domain has only the loop A = (4,2,1,4). (2) If d belongs to Z, n belongs to N. ＜1＞ Shows that n = 1 when the transformation is equivalent to (1), then d =1, x = -2, y = -4, the loop can be obtained B = (-1, -2, -1), because -4 does not belong to B, so n = -1 does not meet the transformation principle, so take n = -2. ＜2＞【1】[3×(2)-d7-1]/3= [3 × (-2) + d7] / 2, d7 = 4/5; [3 × (-2) + d8 – 1] / 3 = [3 × (-2) – d8] / 2, d8 = -4 / 5. 【2】[3 × (-2) -d9] / 2 = 2 [3 × (-2) + d9], d9 = 18/5; [3 × (-2) + d10] / 2 = 2 [3 × (-2) -d10], d10 = -18 / 5.【3】3 [3 × (-2) – d12] + 1 = 2 [3 × (-2) + d12], d12 = -1. Eavailable loop circle C= (-5, -14, -7, -20, -10, -5), according to the transformation principle, take d =1, x= -5 and y = -7. According to the transformation principle, take n=-14. ＜3＞【1】 [3 × (-14) – d13-1] / 3 = [3 × (-14) + d13] / 2, d13 = 8; [3 × (-14) + d14-1] / 3 = [3 × (-14) – d14] / 2, d14 = -8. 【2】[3 × (-14) + d16] / 2 = 2 [3 × (-14) + d15], d15 = 126/5; [3 × (-14) + d16] × (-14) -d16], d16 = -126 / 5. 【3】3 [3 × (-14) + d17] + 1 = 2[3 × (-14) -d17], d17 = 41/5; 3 [3 × (-14) -d18] +1=2[3× (-14) + d18], d18 = -41 / 5. Take d = 8, then x = -34, y = -50, eavailable loop circl D = ( -34,- 17, -50, -25, -74, -37, -110, -55 ,-164, -82, -41, -122, -61, -182, -91, -272, -136, -68, -34), according to the transformation principle, take n = -17. ＜4＞【1】 [3×(-17)-d19-1]/3=[3 × (-17) + d19] / 2, d19 = 49/5; [3 × (-17) + d20 1] / 3 = [3 × (-17) -d20] / 2, d20 = -49 / 5. 【2】 [3 × (-17) + d22] / 2 = 2 [3 × (-17) + d21], d21 = 153/5; [3 × (-17) + d22] × (-17) -d22], d22 = -153 / 5. 【3】3 [3 × (-17) + d2] + 1 = 2 [3 × (-17) -d23], d23 = 10; 3[3 × (-17) -d24] + 1 = 2 [3 × (-17) +d24], d24 = -10. Vailable loop circle E= (-41, -122, -61, …, -41) = D, so that the loop (D, D) can be obtained by taking d = 10, then x = -41, y = -61. So the transformation of each cycle on the negative domain ends in the loop D, and the 3n + 1 transformation on the negative domain has B, C, and D 3 cycles. Conclusion: The 3n + 1 transformation on the whole domain has A, B, C, D 4 cycles.﻿")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ebe8e128bc91eec28cccf42eff4db42a08632630b08c92d46086147b379f19a-274507f1dc5cfdb21b9c916b6a3b9279e9f88bccfde8e345b41275ace08d083f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lz2263546927")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-489059")[#strong[#text("lz2263546927")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2017")])]

#text("The algebraic structure of collatz conjecture：Construct the domain transformation: x = 3n + d, y = 3n-d, z = n/2。1. d = 0, n = 0, x = 3 × 0 + 0 = 0, y = 3 × 0-0 = 0, z = 0/2 = 0。 2. d = 1, n = 0, x = 3×0 + 1 = 1, y = 3 × 0-1 =-1, z = 0/2 = 0。 3. If d belongs to Z, n belongs to N+, x = 3 × 1 + d, y = 3 ×1-d, z=n/2; If d belongs to Z and n belongs to N-,x= 3× (-1) + d, y = 3 × (-1) -d, z = n / 2. (1) If d belongs to Z, n belongs to N+.【1】 (3 × 1 + d1-1) / 3 = (3 × 1-d1) / 2, d1 = 1; (3 × 1-d2-1) / 3 = (3 × 1 + d2) / 2 , d2 = -1. 【2】 (3 × 1 + d3) / 2 = 2 (3 × 1 + d3), d3 = 9/5; (3 × 1 + d4) / 2 = 2 (3 × 1-d4), d4 = 9/5. 【3】 3 (3 × 1 + d5) + 1 = 2 (3 × 1 + d5), d5 = 4/5; 3 (3 × 1 + d6) + 1 = 2 (3 × 1-d6) ,d6= -4 / 5. Take d = 1, then x = 4, y = 2, eavailable loop A = (4,2,1,4). According to the principle of transformation, when n = 1 satisfies 3 × 1 + 1 = 4,3 × 1-1 = 2, the circular circle F = (4,2,1,4) = A is obtained, so available loop circle(A , A). Therefore, the 3n + 1 transformation on the positive domain has only the loop A = (4,2,1,4). (2) If d belongs to Z, n belongs to N-. ＜1＞ Shows that n = -1 when the transformation is equivalent to (1), then d =1, x = -2, y = -4, the loop can be obtained B = (-1, -2, -1), because -4 does not belong to B, so n = -1 does not meet the transformation principle, so take n = -2. ＜2＞【1】[3×(2)-d7-1]/3= [3 × (-2) + d7] / 2, d7 = 4/5; [3 × (-2) + d8 – 1] / 3 = [3 × (-2) – d8] / 2, d8 = -4 / 5. 【2】[3 × (-2) -d9] / 2 = 2 [3 × (-2) + d9], d9 = 18/5; [3 × (-2) + d10] / 2 = 2 [3 × (-2) -d10], d10 = -18 / 5.【3】3 [3 × (-2) – d12] + 1 = 2 [3 × (-2) + d12], d12 = -1. Eavailable loop circle C= (-5, -14, -7, -20, -10, -5), according to the transformation principle, take d =1, x= -5 and y = -7. According to the transformation principle, take n=-14. ＜3＞【1】 [3 × (-14) – d13-1] / 3 = [3 × (-14) + d13] / 2, d13 = 8; [3 × (-14) + d14-1] / 3 = [3 × (-14) – d14] / 2, d14 = -8. 【2】[3 × (-14) + d16] / 2 = 2 [3 × (-14) + d15], d15 = 126/5; [3 × (-14) + d16] × (-14) -d16], d16 = -126 / 5. 【3】3 [3 × (-14) + d17] + 1 = 2[3 × (-14) -d17], d17 = 41/5; 3 [3 × (-14) -d18] +1=2[3× (-14) + d18], d18 = -41 / 5. Take d = 8, then x = -34, y = -50, eavailable loop circl D = ( -34,- 17, -50, -25, -74, -37, -110, -55 ,-164, -82, -41, -122, -61, -182, -91, -272, -136, -68, -34), according to the transformation principle, take n = -17. ＜4＞【1】 [3×(-17)-d19-1]/3=[3 × (-17) + d19] / 2, d19 = 49/5; [3 × (-17) + d20 1] / 3 = [3 × (-17) -d20] / 2, d20 = -49 / 5. 【2】 [3 × (-17) + d22] / 2 = 2 [3 × (-17) + d21], d21 = 153/5; [3 × (-17) + d22] × (-17) -d22], d22 = -153 / 5. 【3】3 [3 × (-17) + d2] + 1 = 2 [3 × (-17) -d23], d23 = 10; 3[3 × (-17) -d24] + 1 = 2 [3 × (-17) +d24], d24 = -10. Vailable loop circle E= (-41, -122, -61, …, -41) = D, so that the loop (D, D) can be obtained by taking d = 10, then x = -41, y = -61. So the transformation of each cycle on the negative domain ends in the loop D, and the 3n + 1 transformation on the negative domain has B, C, and D 3 cycles. Conclusion: The 3n + 1 transformation on the whole domain has A, B, C, D 4 cycles.﻿")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/176874668d54be635b60678f791aa505d9e325ddb79cb714cbed103a89ce1f07-3e91068029e3666409bbaa1ea49065699f2046757ef08c44c860d78ccb8ee6f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of juststudent")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-501626")[#strong[#text("juststudent")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2018")])]

#text("what if 0 is natural number?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e56585db621b41a08296d5c75274bec46a17836a6830fb83773a5f2164759dd7-e8e57b7792a08c4612542db934f36f2ef1215b4825ead7345e8179acf0255d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-501630")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2018")])]

#text("A bit late to the party here, but I am confused by the statements")

#text("“As a crude heuristic, one expects that for a “random” such choice of integers, the expression (1) has a probability 1/q of holding for some integer n. (Note that q is not divisible by 2 or 3, and so one does not expect the special structure of the right-hand side of (1) with respect to those moduli to be relevant.”")

#text("that appear just above equation (6). As far as I can see the first sentence in the quote is the first place where the number q is introduced and so the properties of q mentioned in the second sentence should be obvious from this very implicit definition? But I have no idea how to derive any properties of q from this definition as the reciprocal of some ‘heuristic’ probability. For all I know it is not even an integer. Am I missing something? Can the equality ")#mi("q = 2^a - 3^k")#text(" that appears somewhere further down be taken as the definition instead?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-501635")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2018")])]

#text("One can confidently say that 90% of the words expended on this conjecture are hot air, no matter the oracular elevation. I congratulate you on calling the kettle black.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d210fd8c2282974094c5b0ec70764015e9f464772b074e4a8c64a615f710e86-8bfdac7e02a220d21b9f99c50ad872b4566ef3d419d72e8e9fb9a934fd881889.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shugui xu")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-503073")[#strong[#text("shugui xu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2018")])]

#text("Proof of Collatz Conjecture(3N+1)​​​​")#linebreak()#text(" ")#link("https://weibo.com/6058390182/profile?rightmod=1&wvr=6&mod=personnumber&is_all=1#_rnd1531793858470")[#text("https://weibo.com/6058390182/profile?rightmod=1&wvr=6&mod=personnumber&is_all=1#_rnd1531793858470")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-505886")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2018")])]

#text("It seems that this particular (Collatz) sequence is not the only one having this (empirically observed) property, and many similar sequences may be constructed (via computerized “trial and error” process) having this property. One may try (via some “reasonable” probabilistic model) to find necessary and/or sufficient conditions for certain classes of such sequences to have (in some probabilistic sense) this property.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-505903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2018")])]

#text("Your empirical approach (examining the data) and you probabilistic idea for a proof of the Collatz conjecture is a good idea!")

#text("One may inquire according what are the distributions of divisors, the powers of two, in the Collatz processing. For example, according to the data and according to the Law of Large Numbers, we have the divisor, 2, appearing 50% of all divisions, the divisor, 4, appearing in 25% of all divisions, the divisor, 8, appearing in 12.5% of all divisions, …")

#text("Relevant Reference Link:")

#link("https://www.math10.com/forum/viewtopic.php?f=63&t=1485&sid=1310ff9981e3719c19610834a15f5a27")[#text("https://www.math10.com/forum/viewtopic.php?f=63&t=1485&sid=1310ff9981e3719c19610834a15f5a27")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-505904")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2018")])]

#text("Your empirical approach (examining the data) and your probabilistic idea for a proof of the Collatz conjecture is a good idea!")

#text("One may inquire about the distributions of divisors, the powers of two, in the Collatz processing. For example, according to the data and according to the Law of Large Numbers, we have the divisor, 2, appearing 50% of all divisions, the divisor, 4, appearing in 25% of all divisions, the divisor, 8, appearing in 12.5% of all divisions, …")

#text("Relevant Reference Link:")

#link("https://www.math10.com/forum/viewtopic.php?f=63&t=1485&sid=1310ff9981e3719c19610834a15f5a27")[#text("https://www.math10.com/forum/viewtopic.php?f=63&t=1485&sid=1310ff9981e3719c19610834a15f5a27")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-505924")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2018")])]

#text("It is known (e.g. by Godel incompleteness theorem) that there are (probably many “simple looking”) undecidable propositions in number theory. The “simple looking” collatz conjecture (and perhaps also the binary Goldbach conjecture and the twin prime conjecture) could be undecidable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-505925")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2018")])]

#text("Words of Wisdom:")

#text("“We hear within us the perpetual call: There is the problem. Seek its solution. You can find it by pure reason; for in Mathematics there is no ignorabimus.” — David Hilbert.")

#text("Godel’s Incompleteness Theorems are for things (math problems) we cannot yet comprehend, and they do not apply to the Goldbach conjecture and to the Collatz Conjecture. Those conjectures are provable.")

#text("Keep the faith and keep searching for answers to the big problems…")

#text("Relevant Reference Link:")

#link("https://plus.google.com/communities/108425727800772966512?sqinv=QWI4ZFhwRnVuUjRRbzU1SlliUEswOHJwSG53VC13")[#text("https://plus.google.com/communities/108425727800772966512?sqinv=QWI4ZFhwRnVuUjRRbzU1SlliUEswOHJwSG53VC13")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-505949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2018")])]

#text("Relevant Reference Link:")

#link("https://www.researchgate.net/post/Is_mathematics_becoming_too_difficult_for_mathematicians")[#text("https://www.researchgate.net/post/Is_mathematics_becoming_too_difficult_for_mathematicians")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-507041")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2018")])]

#text("Hello. I have been reading the post and comments. Could we talk about a “something like a weak Collatz conjecture” with the form: if n is even, f:=n/2, and if n is odd f:=n+1(or n-1). I am not sure if someone has told about it. This sequence goes very quickly to 1. Is this very weak Collatz conjecture easy to prove?. And the most important, of course, could be this demonstration useful for the Collatz conjecture 3n+1")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-507520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2018")])]

#text("Hello, community. Another form of application (3n+1)/2 rule is the equivalent rule if n is odd :")

#text("n +( (n+1)/2)")

#text("I have been playing with this rule and I have to try to expand the function always about the first n. we do not need the powers of 3. I have seen interesting things, I think. Could someone try to expand this rule and talk about it?. Thank you. I keep on “working”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-508252")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2018")])]

#text("This is the question: Can the existence of cycles for sequences that are 3x+n where n>1 prove by contradiction that 3x+1 sequences cannot cycle? I think so. ")#link("https://mathrodite.quora.com/Does-the-existence-of-cycles-for-sequences-that-are-3x-n-where-n-1-prove-by-contradiction-that-3x-1-sequences-cannot-1")[#text("https://mathrodite.quora.com/Does-the-existence-of-cycles-for-sequences-that-are-3x-n-where-n-1-prove-by-contradiction-that-3x-1-sequences-cannot-1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-508374")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2018")])]

#mi("f^{k}(n)= f^{l+m}(n)= \\frac{n\\times 3^{l} + 3^{l-1}\\times 2_{a1}^{x} + 3^{l-2}\\times 2_{a2}^{x+y} +...+ 3^{l-l}\\times 2_{al}^{x+y+...+z}}{2_{a1}^{x}\\times 2_{a2}^{y}\\times ...\\times 2_{al}^{z}\\times 2_{al+1}^{m-x-y-...-z}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-511143")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#text("*A cycle is a single set of integers")#linebreak()#text(" that for a certain sequential order")#linebreak()#text(" share common differences")#linebreak()#text(" such that each member can occur only once.*")#linebreak()#text(" This leads to four questions about the anatomy and dynamics of a cycle:")#linebreak()#text(" * *Question One:* Given that each number occurs once, how can one of those numbers have two different input operations: one that inserts it into the cycle and another that keeps it in the cycle’s orbit)?")#linebreak()#text(" * *Question Two:* Given two different input operations for one output, is this a sufficient condition for a loop? It’s tempting to think yes. But think again. One can show that the answer is in fact no. (I will hint at why here by saying only there are “congruence swim lanes”.)")#linebreak()#text(" Two questions, two necessary conditions. Two more questions, each essential and both required to be sufficient conditions for a cycle:")#linebreak()#text(" * *Question Three*: Given an input-output operation where there are two inputs and one output, what is the essential requirement for a recurrence of each number in the sequence? Here I suggest there must be two inverse input-output operations, so that you can imagine an equilibrium point, with inverse operations crossing it.")#linebreak()#text(" * *Question Four:* Does every sequence that cycles have a set of input-output operations whose common differences sum to zero? If this is true, one has the sufficient property for a cycle. (The common differences must be calculated in the the order of the sequence, beginning with any member of it, for there to be a perfect cancellation of positive and negative operations.)")

#link("https://mathrodite.quora.com/Equilibrium-and-Cyclicality-in-Congruent-Functions")[#text("https://mathrodite.quora.com/Equilibrium-and-Cyclicality-in-Congruent-Functions")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-523963")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("The algorithm allows the cycles to have several inputs and an output for example 31, 125, 501, 2005, 8.021, using the algorithm will calculate 47, however 47 will only calculate 71.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-512946")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2019")])]

#text(":idea: :!: :star: :star: :star: hi all havent posted an update here for a few yrs, meantime have been banging very hard on this problem. found many new angles on the fractal aspects of this problem, but am writing this motivated by ")#strong[#text("some new breakthru results to announce.")]#text(" the basic structure of the collatz problem seems to be revealed with the help of a powerful Terras 1976 lemma/ construction that is obscure/ mostly overlooked. empirical evidence shows that its a “predetermined random walk” for n iterations where n is the # of bits in the initial iterate, and the postdetermined region, ie all iterations after n, is a slope-mean-returning random walk. this seems to hold for all iterates empirically and now its just a matter of proving it, and have some rough/ early outline for that based on the density property noted here earlier. open invitation to volunteers/ collaborators. ")#link("https://vzn1.wordpress.com/2019/02/01/collatz-comb/#rosetta")[#text("https://vzn1.wordpress.com/2019/02/01/collatz-comb/#rosetta")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-523964")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("I don’t agree, the algorithm is not a random walk at all. Although I am not convinced that the zero density for the divergent orbits indicated by Manuel Garcia and Fabio Tal in their 1999 article “A note on the generalized 3n + 1 problem” I definitely think that is feasible in which case the density of the orbits Convergents should be 1 and it would be a good way to prove the conjecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-512948")[#strong[#text("collatz comb | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2019")]

#text("[…] construct13 diagram is a very big deal. might as well call it the rosetta diagram. just cited it on Taos collatz page! (forgot to say, the time is ripe!) havent posted there in 4 years! currently have a total of maybe […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07afb427a275e4dc902a392692c8fc94b4fec90f7e40010c76347f51b17f8fa2-deeca69636fedc2a3ea9bbaec0b78770b331d78feb9d6be3af954ec90d92f3a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of georgiy480511")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-516354")[#strong[#text("georgiy480511")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2019")])]

#text("If you really wonder what a harmonious system is formed by odd natural numbers and how it relates to the Collatz Conjecture, then in March 2019 a book was published")

#text("Paperback")

#text("EBook")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4245fd8d6293832adbf462aa4d0ed859d058d06bffc34e5614248035ffe8a4ea-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-517175")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("Bijection, injection, and surjection. The domain of a function. The Collatz conjecture is a function?. The powers of 2 are the first elements. the 2^x-1/3 generates the next elements.")#linebreak()#text(" In the 5x+1 problem, some number goes to infinity. Are those numbers that are not of the 2^x-1/5 form? Are not in the domain of the function?, There are more cycles than the trivial 4,2,1. Is it because each number not generate one and only one different number, that not is repeated.")

#text("Therefore can we talk about the domain of the function 3n+1? is infinity? Every element on the Collatz function is mapped to 1 and only 1 element, so there is just one trivial cycle 4,2,1.¿?.Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-523965")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("The Collatz conjecture can be expressed in an analytical way. Chamberland has a continuous extension of 3n + 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4245fd8d6293832adbf462aa4d0ed859d058d06bffc34e5614248035ffe8a4ea-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-517250")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2019")])]

#text("I am not sure if the cycle 4,2,1, is the unique trivial cycle when you talk in the post about Steiner.")#linebreak()#text(" in the 5x+1 problem exist more cycles than 1421. At the moment I know 13…13, and 17…17. let´s call 3^k-1*2^a1+3^k-2*2^a2+…+2^ak (8) Tao-Collatz remainder=t-c-r. This condition is equivalent to")

#text("n*3^k + t-c-r / 2^ak+1 = n")#linebreak()#text(" 17*5^3 +17*3 / 2^7 =17")#linebreak()#text(" 13*5^3 +13*3 / 2^7 =13.")#linebreak()#text(" this could be just a casuality, i know")

#text("n*5^k + nk = n*2^ak+1")

#text("in the 3x+1 problem")

#text("n*3^k + t-c-r / 2^ak+1 = n is only possible when n =1. if it is possible to prove this, that will be that 1241 is the unique cycle.")

#text("otherwise, 2^ak+1=t-c-r (mod n). is this fact important for Collatz conjecture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4245fd8d6293832adbf462aa4d0ed859d058d06bffc34e5614248035ffe8a4ea-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-517333")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2019")])]

#text("Collatz conjecture is equivalent to")#linebreak()#text(" ")#mi("n\\times 3^{k} = 2^{ak+1} - TCS")#linebreak()#text(" where, for me, k=odd steps, and ak+1 =even steps.")#linebreak()#text(" Note that total steps = k +( ak+1) steps. Some numbers have the same total steps, but k steps and ak+1 steps are different because it is unique for every n.")#linebreak()#text(" Even numbers are = (mod2) remaider 0 and =(mod3) remainder 0,1,2.")#linebreak()#text(" Odd numbers are =(mod2) remainder 1 and =(mod3) remainder 0,1,2.")

#text("About the properties of (8), the Tao-Collatz remainder, TCS for me, I think that")

#mi("2^{ak+1}\\equiv TCS (modn)")

#text("The G.c.d.(2^ak+1, TCS) =1 , so exist just 1 solution for this congruence.And 2^ak+1 – TCS is a multiple from n.")

#text("With this information and Bézout’s identity, linear congruence resolution and Extended Euclidean algorithm, I am studying if it is possible to obtain the value of 2^ak+1 or TCR and 3^k and a demonstration of Collatz conjecture. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4245fd8d6293832adbf462aa4d0ed859d058d06bffc34e5614248035ffe8a4ea-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-517671")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2019")])]

#text("If ")#mi("n\\times 3^{k} = 2^{ak+1} - TCR")#text(" and ")#mi("2^{ak+1}\\equiv TCR \\left ( mod n \\right )")#text(" are true, exist 1 solution. And efectively, for each ")#mi("2^{x}> n\\times 3^{k}")#text(" exist a r that satisfy the equality. So, we need another condtion for TCR. Somehow, TCR is relational to k, because when k=0, TCR=0, and k=1, TCS=1, and when ")#mi("k> 1")#text(" ,then ")#mi("TCR =  3^{K-1}\\times 2^{a1} +3^{k-2}\\times 2^{a2}+...+3^{0}\\times 2^{ak}")#text(" we could explore another condition of TCR by ")#mi("ax\\equiv b\\left ( modn \\right )")#text(" and ")#mi("a^{\\varphi \\left ( n \\right )}\\equiv 1 \\left ( modn \\right )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4245fd8d6293832adbf462aa4d0ed859d058d06bffc34e5614248035ffe8a4ea-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-517806")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2019")])]

#text("Hello again. The objective of my comments in this blog is to share ideas, talk about them and also receive help and guidance. Normally I do not usually get any feedback, because maybe this is not the appropriate place for this (and because my ideas are usually silly too), so I am always open to advise me the appropriate places for this work. Always respecting Professor Tao and thanking him for writing on his blog.")#linebreak()#text(" continuing with Collatz and the second condition that we look for I found")

#mi("n^{i}\\equiv r_{i}\\left ( mod n \\right )")#text(",")

#text("In Spanish are “restos potenciales”, in English I have not found what it’s called. They could be “powers remainders” or “exponential remaider”.")#linebreak()#text(" I think that")

#mi("2^{ak+1}\\chi  \\equiv TCR\\left ( modn \\right )\\leftrightarrow 3^{k-1}\\equiv \\chi \\left ( modn \\right )")

#text("I hope I have expressed it well. I would be very grateful if you would help me to verify the validity of this fact, and of the others, and if I have not explained it well I will try to do it better. In trying to unmask this conjecture with my basic mathematics, I had to learn the concepts of modular arithmetic. I hope you’ll excuse me if I’ve been wrong too much. Can the simple algorithm of the division prove the Collatz conjecture? Is the modular arithmetic sufficiently powerful for the Collatz conjecture? I suppose I’ll keep trying. Thanks to all … and Excuse me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-523966")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("Personally, I do not think that modular arithmetic can be fundamental for the demonstration of the conjecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-518282")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2019")])]

#mi("\\begin{matrix} ... & ... & ... & ... & ... & ... & ... & ... & ... & ... \\\\  128 & 84 & 52 & 136 & 88 & 58 & 74 & 100 & 260 & ... \\\\ 64 & 80 & 48 & 75 & 49 & 56 & 72 & 99 & 133 & ... \\\\ 32 & 42 & 26 & 74 & 46 & 30 & 38 & 98 & 132 & ... \\\\ 16 & 40 & 24 & 70 & 45 & 29 & 37 & 96 & 130 & ... \\\\ 8 & 21 & 13 & 68 & 44 & 28 & 36 & 51 & 67 & ... \\\\ 4 & 20 & 12 & 35 & 23 & 15 & 19 & 50 & 66 & ... \\\\ 2 & 10 & 6 & 34 & 22 & 14 & 18 & 49 & 65 & ... \\\\ 1 & 5 & 3 & 17 & 11 & 7 & 9 & 25 & 33 & ... \\\\ \\hline\\\\ k=0 & k=1 & k=2&k=3&k=4&k=5&k=6&k=7&k=8&k=... \\end{matrix}")

#text("This is a matrix of n as a function of k = odd steps. The even numbers descend to an odd number (divided by 2) and the odd numbers jump to the left column (3n +1). We will be useful for visualizing because the cycle 1,4,2,1 is the only possible cycle. Otherwise,")

#mi("f\\left ( n \\right )= n")#text(" , and this is only possible when n = 1, taking the odd n.This implies that the function takes a value from the form")

#mi("f_{0}^{k}\\left ( n \\right )= \\frac{n\\times 2^{x}}{2^{x}}")

#text("and the even numbers of the form ")#mi("n\\times 2^{x}")#text(" are the numbers where n comes from and therefore the function does not go through those numbers again. In the matrix, they are always above n and the function always moves downwards for the pairs and to the left-up for the odd ones, looking for its corresponding pair number. It is easy to see that the function from n always leaves behind the numbers that would give rise to another cycle other than 4, 2.1. Mathematically, for now, I do not know how to express it, it’s as if the function had to do the reverse cycle for this to happen, and a little intuitively, it could be that ")#mi("2^{x}\\equiv 0\\left ( modn \\right )")#text(" is negative, but I’m not sure. What do you think?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-523967")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("I do not understand the matrix well because it does not indicate which orbit each quantity refers to, but the algorithm itself seems to indicate that all its calculations decrease towards 1. If it is demonstrated then the matrix would no longer be necessary, which in passing would be another problem to be demonstrated. In any case, if an orbit was not bounded it would also show its number of steps but towards the return value but would not indicate that it is not bounded. It is what happens with 1 that requires 3 steps to return to 1 but does not indicate that the orbit is not really bounded.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-518619")[#strong[#text("What do mathematicians mean when they say some conjecture can’t be proven using the current technology?What does the Hodge conjecture mean?Please help. Great confusion about the “two levels of discourse” mathematical logic.Does mathematics r")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2019")]

#text("[…] The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-518941")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2019")])]

#link("https://math.stackexchange.com/questions/3301706/hausdorff-space-homeomorphism-and-collatz-conjecture")[#text("https://math.stackexchange.com/questions/3301706/hausdorff-space-homeomorphism-and-collatz-conjecture")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519099")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2019")])]

#text("Morphism and permutations on Collatz conjecture.")

#text("Of all that I have been able to read and understand about the Collatz conjecture, I have not found references to some type of morphism in Collatz’s function with respect to natural numbers. If we assume the conjecture as true, what implications it would have, speaking of morphisms. For example, very heuristically,")#linebreak()#text(" -If 1 is a generator of N, the inverse function of Collatz will have 1 as a generator")#linebreak()#text(" -In set theory, an arbitrary permutation of the elements of a set X is an automorphism The automorphism group of X is also called the symmetric group on X. (Wikipedia)")#linebreak()#text(" -If the automorphisms of an object X form a set (instead of a proper class), then they form a group under composition of morphisms. This group is called the automorphism group of X. (wiki)")#linebreak()#text(" -In graph theory, an automorphism of a graph is a permutation of the nodes that preserves edges and non-edges. In particular, if two nodes are joined by an edge, so are their images under the permutation (wiki) …")#linebreak()#text(" In short, if there is any morphism, automorphism, endomorphism, permutation, … if the conjecture is true, and if Through these statements you can make a contradiction that states that it is true.")#linebreak()#text(" The professor says that we ask dumb questions, maybe mine are too silly, so I don’t usually get answers. Hopefully, someday someone will answer me because my questions are not too dumb. I hope this approach is understood.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-523969")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("Recently a topological co-relation of the Collatz conjecture was published. It is not a demonstration but it may be that in this article you can find the answers you are looking for.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519373")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2019")])]

#link("https://arxiv.org/abs/1908.01509v1")[#text("https://arxiv.org/abs/1908.01509v1")]#linebreak()#text(" ")#link("https://arxiv.org/abs/1907.07088v2")[#text("https://arxiv.org/abs/1907.07088v2")]#linebreak()#text(" ")#link("https://arxiv.org/abs/1906.10566v1")[#text("https://arxiv.org/abs/1906.10566v1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2019")])]

#text("Please check my proof of the convergence of collatz cngecture: ")#link("https://doi.org/10.1155/2019/6814378")[#text("https://doi.org/10.1155/2019/6814378")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519412")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2019")])]

#text("Hello, community. Maybe I have been a little sparing in words. These are some recent papers on the conjecture, with this one ")#link("https://arxiv.org/abs/1907.00775")[#text("https://arxiv.org/abs/1907.00775")]#text(". My intention is that you can share your opinions on these works to the friends of the conjecture. For me, this post is a bit the reference center of the Collatz conjecture. I don’t know if there is another more suitable place to compile the advances, news or discussions about the conjecture, or if it would be convenient to create that place. In any case, I always want to be respectful to Professor Tao.")#linebreak()#text(" Regarding recent papers, I like that of Zenon Batang. The theory of graphs and their trees has always been present in the conjecture, and their connections with the theory of sets seem interesting to me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519428")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2019")])]

#text("> Maybe I have been a little sparing in words")

#text("(ﾟ⊿ﾟ)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-523971")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("I don’t understand why they continue to develop Collatz trees. Odd numbers calculated with the algorithm are ordered subsets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519417")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2019")])]

#text("Let $ \\mathbb{N}$ be the set of natural numbers. We can represent it as an ordered set $ \\mathbb{N}=\\begin{Bmatrix}")#linebreak()#text(" 1,2,3,4,5,6,,,")#linebreak()#text(" \\end{Bmatrix}$, and I suppose we can say that it is a connected graph. The odd numbers and their 2 multiples are disjoint subsets of N, and in turn, they are graphs connected.$ O_{n}= \\begin{Bmatrix}")#linebreak()#text(" n,2n,4n,8n,16n,…")#linebreak()#text(" \\end{Bmatrix}$")#linebreak()#text(" Its intersection is 0 and its union is N")#linebreak()#text(" $ O_{1}\\cap O_{3}\\cap O_{5}\\cap O_{7}\\cap …\\cap O_{\\infty }= \\varnothing$")#linebreak()#text(" $ O_{1}\\cup O_{3}\\cup O_{5}\\cup O_{7}\\cup …\\cup O_{\\infty }= \\mathbb{N}$. With this collection of disjoint graphs, we can construct a graph labeled, connected and oriented so that all its vertices reach 1?. The even numbers of the formn$ \\equiv 1\\left ( mod\\, 3 \\right )$ are the vertices of connection between disjoint graphs. If the subset 1-2-4-8-16-32 is the primary branch and we have it horizontally above we see how each odd subset is joining, say vertically, in its corresponding place , and successively secondary branches are being formed to which other branches are joined in a precise and univocal way, forming the famous Collatz tree, equivalent to N. From this point of view, if the relevant questions are raised and if they can be answered, you could come up with a solution, although the solution has already been reached.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519773")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2019")])]

#text("Is it possible to fix the latex ?. Take this opportunity to know if it would be interesting to see how latex looks like, as in StackExchange. Thanks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519797")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2019")])]

#text("About periodical loops")

#text("$")#mi("n\\times 3^{k}+3^{k-1}\\times 2^{a1}+3^{k-2}\\times 2^{a2}+...+2^{ak}=\\begin{Bmatrix}n\\times 2^{x} \\\\ \\infty  \\\\ 2^{ak+1}\\; ,where\\: 2^{ak+1}> n\\times 3^{k} \\end{Bmatrix}")#text("$")

#text("“In order to make rigorous progress on this conjecture, it seems that one would need to somehow exploit the structural properties of numbers of the form”(Terence Tao )")

#mi("3^{k-1}\\times 2^{a1}+3^{k-2}\\times 2^{a2}+...+2^{ak}")

#text("“It leaves open the possibility of some very rare exceptional ")#mi("{n}")#text(" for which the orbit goes to infinity, or gets trapped in a periodic loop.” (Terence Tao)")

#text("I call")

#mi("3^{k-1}\\times 2^{a1}+3^{k-2}\\times 2^{a2}+...+2^{ak}")#text("= TCR")

#text("When we say that")

#mi("n = \\frac{2^x-TCR}{3^b}")

#text("we are assuming the conjecture true. If the series")

#mi("n\\times 3^{k}+3^{k-1}\\times 2^{a1}+3^{k-2}\\times 2^{a2}+...+2^{ak}")#text(" converges (or its equal) to a power of 2, It is a sufficient condition for the demonstration of the conjecture. But I understand that this condition has to be extremely difficult to prove. Although exceptionally rare, the circumstance can be given that the conjecture converges to infinity")#linebreak()#text(" ")#mi("f^{k}(n)= \\infty")#text(" , or enters a periodic loop,")#linebreak()#text(" ")#mi("f^{k}(n)=n\\times2 ^{x}")

#text("therefore, if we are able to demonstrate that the series does not converge to infinity and does not converge to a multiple of n, the conjecture must converge to a power of 2.")#linebreak()#text(" I argued that")

#mi("2^{ak+1}\\equiv TCR \\pmod{n}")

#text("The GCD (")#mi("2^{ak+1}")#text(", n) =1 , so there exists just 1 solution for this congruence.And ")#mi("2^{ak+1}")#text(" – TCR is a multiple of n. Effectively for each power of 2, ")#mi("2^{ak+1}>n×3^{k}")#text(" exist 1 solution with the form ")#mi("2^{ak+1}")#text("−TCR .For small TCR it could be easy that is of the form ")#mi("3^{k-1}\\times 2^{a1}+3^{k-2}\\times 2^{a2}+...+2^{ak}")#text(" even being 1 we have that ")#mi("3^{0}\\times2^{0} = 1")#text(", but if the value of TCR is very large, it seems more difficult to verify if its structure is correct.In any case, we would always arrive at the fact that if the conjecture is true, this implies that it is true, that it does not seem like a demonstration.")

#text("We could use this argument in the possible solutions to get trapped in a periodic loop, although exceptionally rare, not ruled out. If")

#mi("f^{k}(n)=n\\times2 ^{x}")#text(", then we have that ")#mi("n\\times 3^{k} + TCR = n\\times2^{x}")#text(", so ")#mi("TCR\\equiv0(mod\\:n)")#text(" and ")#mi("n\\times 3^{k}+ny=nz")#text(", with $z=2^{x}=3^{k}+y$")

#text("If")

#mi("3^{k-1}\\times 2^{a1}+3^{k-2}\\times 2^{a2}+...+2^{ak}=ny= TCR\\not\\equiv0(mod\\:n)\\rightarrow f^{k}(n)\\neq n\\times2^{x}")

#text("Otherwise,")

#mi("TCR= n\\times 2^{x}= Even")#linebreak()#text(" ")#mi("n\\times 3^{k}+TCR=n\\times 2^{x}")#text(" we have that ")#mi("Odd + Even=Even")#text(",that is not possible, so with ")#mi("n=odd")

#mi("TCR\\not\\equiv 0(Mod\\:2)\\not\\equiv 0(mod\\:n)\\neq n\\times y\\neq Even\\rightarrow n\\times 3^{k}+ TCR\\neq n\\times 2^{x}\\rightarrow f^{k}(n)\\neq n\\times 2^{x}")

#text("If this reasoning is correct, then there can not be periodic orbits. On the orbits that seem to escape to infinity, if it is independent of the non-existence of periodic orbits, it can be seen that the Collatz tree is equivalent to N ")#link("https://math.stackexchange.com/questions/3324379/is-collatz-tree-n")[#text("https://math.stackexchange.com/questions/3324379/is-collatz-tree-n")]#text(" and if it is a rooted tree, no orbit escapes to infinity. Thanks As always I wait for your opinion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519804")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2019")])]

#text("Ooops It seems not right. I keep working")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-519882")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2019")])]

#mi("n\\times 3^{k}+n\\times y\\neq n\\times 2^{x}")#text(", With this strategy we can rule out the absence of cycles when y = even.")

#mi("f^{-\\infty }(n)=n\\times 2^{\\infty }\\rightarrow  ...\\rightarrow  f^{-2}(n)= n\\times 2^{2}\\rightarrow f^{-1}(n)=n\\times 2^{1} \\rightarrow n\\rightarrow f^{1}(n)= 3n+1")

#text("So close and yet so far")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520002")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#text("About periodical loops(2)")

#text("Another possibility of attacking the existence of periodic cycles is to study what type is the binary relation that establishes the conjecture and its characteristics. For me they are the cornerstone of the conjecture, then I have realized how obvious this is since they are the conjecture itself.")

#mi("f(n)\\left\\{\\begin{matrix}n/2\\; \\; \\; \\; \\;if\\: even \\\\ 3n+1\\; \\; \\; \\; \\; if\\: odd \\end{matrix}\\right.")

#text("The inverse")#mi("f(n)\\left\\{\\begin{matrix}2n\\; \\; \\; \\; \\;if\\: even\\equiv 0,2 (mod\\, 3) \\\\ \\frac{n-1}{3}\\; \\; and\\; \\; 2n \\; \\; \\; \\; \\; if\\: even\\equiv 1(mod\\, 3)    \\\\2n\\; \\; \\; \\; \\; if \\; odd \\end{matrix}\\right.")

#text("Let’s start with ")#mi("f(n)=n/2\\;  if \\; even")#text(", ")#mi("f:O_{i}\\rightarrow O_{i}")

#text("Where ")#mi("O_{i}= (,,,16n,8n,4n,2n,n)")#text(" are the subsets formed by each odd number and its 2 multiples.Applying this binary relationship to all even numbers, we can intuitively see that we have a partition of N in disjoint subsets, which intuitively I think can be considered disjoint graphs directed towards each odd number. Even, perhaps, this binary relationship can be represented with a matrix. In this context, we could analyze what kind of binary relationship we talk about, its equivalence classes, the resulting quotient space, the image of the function and even the relationship of linear dependence, if I have understood well that it is a binary relationship.")#linebreak()#text(" But let’s continue with the second binary relationship")

#mi("f(n)= 3n+1 \\; if\\; odd")#text(",")#mi("f:O_{i}\\rightarrow O_{j}")

#text("This binary relationship, in the context in which we find ourselves, joins each set disjoint with another and this new set with another and so on, all the disjoint subsets are joined in a single set, where the binary relationship keeps each union disjoint. If the conjecture is true, we have a set or graph equivalent to N and directed at 1, with a single equivalence class equal to the quotient space and where the image of the function is equal to N.")

#text("In the problem 5n + 1 we observe how at 13 and 17 they form periodic loops, that is to say, they reach 2 multiples of themselves and therefore to themselves, these loops are disconnected from the others, which can be interpreted as forming equivalence relations different, or even that they are linearly independent. Viewed from the inverse function, we can see, perhaps more easily, that they are not an image of the function, or that they are not generated from 1.")

#text("Therefore, in this context, and given the manifest difficulty of being able to demonstrate that a number cannot reach a number 2 multiple of itself, and therefore that there are no periodic loops, we can propose other approaches.")

#text("1. The study, if possible, that numbers are not an image of the function, even the inverse function seems more affordable. Maybe this is where there can be a connection with the theory of transcendence.")#linebreak()#text(" 2.If all binary relationships seen as vectors are linearly dependent, in the inverse function from 1.")#linebreak()#text(" 3.If from the properties of binary relations it can be inferred that the binary relation 3n + 1 joins disjoint sets")#linebreak()#text(" 4. That somehow, despite the difficulties with the infinite, we can represent these binary relationships in a matrix and study their properties. This seems to be the most promising because in the context outlined in this comment the representative matrices of these relationships are not chaotic or random.")#linebreak()#text(" Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2019")])]

#text("Another possibility is to show that the conjecture is true “almost everywhere” in the sense that the number of integers below ")#mi("N")#text(" which belong to any periodic loop is ")#mi("o(N)")#text(" for large ")#mi("N")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520077")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2019")])]

#text("Boolean matrices of binary relations")

#mi("n\\rightarrow 2n")

#mi("\\begin{matrix}  & n & 2n & 4n & ...\\\\ \\hline n &0 & 1 &0  &... \\\\  2n &0 & 0 & 1 &... \\\\   4n& 0 & 0 &0  &... \\\\   ...&  ...& ... & ... &  \\end{matrix}")

#mi("odd\\rightarrow 5n+1")

#mi("\\begin{matrix} & 6 & 16 &26  & 36 & 46 & 56 &... \\\\ \\hline  1& 1 &0  & 0 &  0&0 &0&...\\\\   3& 0 & 1 &  0& 0 & 0 & 0 & ...\\\\   5& 0 & 0 &1  & 0 &  0&0  &... \\\\   7& 0 & 0 & 0 &  1&0  &0  & ...\\\\   9& 0 & 0 & 0 & 0 & 1& 0 &.... \\\\   11&  0& 0 & 0 & 0 &0& 1 &...\\\\    ...&...  & ... &...  & ... &...  & ... &...  & ... &...  \\end{matrix}")

#mi("odd\\rightarrow 3n+1")

#mi("\\begin{matrix} & 4 & 10 &16  & 22 & 28 & 34 &... \\\\ \\hline  1& 1 &0  & 0 &  0&0 &0&...\\\\   3& 0 & 1 &  0& 0 & 0 & 0 & ...\\\\   5& 0 & 0 &1  & 0 &  0&0  &... \\\\   7& 0 & 0 & 0 &  1&0  &0  & ...\\\\   9& 0 & 0 & 0 & 0 & 1& 0 &.... \\\\   11&  0& 0 & 0 & 0 &0& 1 &...\\\\    ...&...  & ... &...  & ... &...  & ... &...  & ... &...  \\end{matrix}")

#text("And maybe the most important, The NxN 5n+1 map boolean matrix, to see where it fails, and the NxN 3n+1 map boolean matrix.")

#text("Unfortunately, to appreciate these matrices, they must be very large and I am thinking about how to make them and upload them. If anyone knows how they can be done and how to upload them, I would be very interested in your help. If somehow these matrices were appropriate and correct we could obtain the characteristic polyonomy and calculate its roots, and we could also calculate its determinant and know if it is singular or degenerate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520121")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2019")])]

#text("I don’t understand this possibility exactly, because I don’t know what it is exactly o(N). I think it’s a “certain unknown operator.” Although in my view, I think it means that assuming there are no periodical loops, the conjecture is true for N. I think this is so in the sense that if there are no periodic loops, the Collatz tree is equal to or equivalent to N, and if this implies that no orbit escapes to infinity (which I think is so), then the conjecture is true.")#linebreak()#text(" On this “certain unknown operator”, there may be a connection with the repressive Boolean matrix of the Collatz map, if it exists, for the conjecture to be true, its determinant must be 0. Investigating determinants of infinite dimension, if this our case, I found in Wikipedia the functional determinant and")

#mi("f(x)= \\phi (x)+\\int_{0}^{1}K(x,y)\\phi (y)dy")#text(", where ")#mi("\\phi (x)")#text(" is the incognito function, may be our “unknown operator”.")

#text("Since we have talked about determinants, one of the properties of the determinants is “The absolute value of the determinant is equal to the surface of the parallelogram … The determinant is null if and only if the two vectors are collinear (the parallelogram becomes a line) (Wikipedia). Professor Tao talks about “large parallelepipeds” in the post and somehow we could relate it, although all this is really well above my level and just be a great fantasy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520138")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2019")])]

#text("The (standard) notation ")#mi("o(N)")#text(" is used for any function of ")#mi("N")#text(" for which ")#mi("\\lim_{N \\to \\infty} = 0")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2019")])]

#text("Correction: The limit above should be")#linebreak()#text(" ")#mi("\\lim_{N \\to \\infty} (o(N)/ N) = 0")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520196")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("I prefer dispensing with all two-part definitions of the iterated function, and thinking of it as a map on the equivalence classes Z+ / (n ~ 2n) (whose representatives are just the positive odd numbers), taking [n] to [3n+1].")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520218")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("I believe, if the conjecture is true, it means that there is a single equivalence class, that of 1, and the quotient space is formed by this unique equivalence class, then they are equal. The directed tree of Collatz therefore always reaches 1, because it is connected (weakly) and does not form periodic loops. Seen binary relationships as vectors, it means that everyone is linearly dependent. That is why I would like to explore the properties of the infinite Boolean matrix that represents the conjecture, to see if it is possible that its determinant is nonzero, because, if the conjecture is true, this determinant is always 0.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c6a36407d4be468c0a8024beb25723d5c8c8caf75cb7b116d69955550ba9f2c-c7727639b732d46296836c835109404887e284338b2082ff5dce07cbb7997a98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zachary Kyle Knutson")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520198")[#strong[#text("Zachary Kyle Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("what about 2n+2 for those who think that n could be more accurately 2n…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c90dc59d020b6b7ceced9cb4b642f63881a652367b7d1037825a7098af7fd2cf-d2501b8777faf7f4e61e18b393dfa2d08455fda519b704608e5fafdbdb7f9cf8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Κωνσταντίνος Κουρουζίδης")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520200")[#strong[#text("Κωνσταντίνος Κουρουζίδης")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("I wonder why people are thinking so hard about this problem. Erdős said that mathematics are not yet ready for such problems. He knew something more…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("This is because any mathematical problem reputed to be “hard” – usually draws attention. Moreover, attempts to solve it (or some variants) may lead to the development of new mathematical tools (and even theories) which are much more valuable to mathematics (as in the cases of fundamental theorem of algebra, FLT, PNT, and the four color theorem) than the solution of the particular problem itself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("Stop wasting your time on proving the Collatz conjecture! It’s a solved problem! …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("Yes! The Collatz conjecture is true!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520249")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2019")])]

#text("I have thought about that possibility, even more so considering some recent arxiv papers, but if it is resolved, why is the news not given?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520220")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("Erdős was a great mathematical who was wrong about the Collatz conjecture…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-520222")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("Erdős was a great mathematician…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-521282")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("I am not sure if the conjecture has been raised from a trigonometric point of view or if it is possible to do so. The coversed sine function, ")#mi("cvs(\\theta )= 1-sin(\\theta )")#text(", could help us study the distance that separates the powers of 2 and 3 in the unit circle. For the function to be trapped in a periodic loop it must be fulfilled that ")#mi("n\\times 3^{k}+TCR= n\\times 2^{x}")#text(", where ")#mi("TCR= n\\times y")#text(", or ")#mi("TCR\\equiv 0\\pmod n")#text(", multiple of n.I am sorry I cannot make the graphic representation to visualize it better. We would have then that")#linebreak()#text(" ")#mi("cvs(\\theta )= TCR")#linebreak()#text(" ")#mi("sin(\\theta )= n\\times 3^{k}")#linebreak()#text(" ")#mi("hypotenuse= n\\times 2^{x}")#text(",")#linebreak()#text(" it seems that then ")#mi("cos(\\theta )= n\\times 3^{k}")#linebreak()#text(" , if ")#mi("hypotenuse= n\\times 2^{x}=1")#text(", we have the unit circle. If this approach is possible, we can ask ourselves if it is possible, with ")#mi("n= odd")#text(", ")#mi("y=odd")#text(", and ")#mi("3^{k}+y= 2^{x}")#linebreak()#text(" If ")#mi("cvs(\\theta )= 1-sin(\\theta )")#text(",")#linebreak()#text(" $\\frac{TCR}{n\\times 2^{x}}=\\frac{n\\times y}{n\\times 2^{x}}=1-\\frac{n\\times 3^{k}}{n\\times 2^{x}}$,")#linebreak()#text(" or ")#mi("n\\times 2^{x}= \\sqrt{(n\\times 3^{k})^2+(n\\times 3^{k})^2}")#text(", and equivalently ")#mi("1= \\sqrt{\\left ( \\frac{n\\times 3^{k}}{n\\times 2^{x}} \\right )^{2}+\\left ( \\frac{n\\times 3^{k}}{n\\times 2^{x}} \\right )^{2}}")#text(",")#linebreak()#text(" or , of course, raise any other interesting option that could leads us to a contradiction. Also, if it makes any sense, we could use this strategy for the option of assuming certain the conjecture, where,")#mi("hypotenuse= 2^{x}")#text(",")#linebreak()#text(" I await your opinions, thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-526098")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2019")])]

#text("I don’t know if I achieve a trigonometric point of view but I do have a proof with the Pythagorean triads that explain why unbounded orbits cannot be calculated in addition to the known 4,2,1 …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Almost all Collatz orbits attain almost bounded values | What's new")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-521788")[#strong[#text("Almost all Collatz orbits attain almost bounded values | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("[…] the notorious Collatz conjecture (also known as the conjecture), which I previously discussed in this blog post. This conjecture can be phrased as follows. Let denote the positive integers (with the natural […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-532142")[#strong[#text("Mathematician Proves Huge Result on ‘Dangerous’ Problem – Book Booster")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2019")]

#text("[…] this past August an anonymous reader left a comment on Tao’s blog. The commenter suggested trying to solve the Collatz conjecture for “almost all” numbers, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/546a50f6ac1cac806051af8a7333159c994ce5420096845020e4cd71a80cefd2-726f93ab6a919b8ca7eedfcb3dcb111f9ad0816400557ae8ef130ceff3225199.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathematician Proves Huge Result on “Dangerous” Problem | Later On")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-532183")[#strong[#text("Mathematician Proves Huge Result on “Dangerous” Problem | Later On")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2019")])]

#text("[…] this past August an anonymous reader left a comment on Tao’s blog. The commenter suggested trying to solve the Collatz conjecture for “almost all” numbers, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/082de53177af115dd2bcd7eaa4c120f1c41b97bc332c2c278569474a644ca7e6-33b0bbf5eb6b259b8319f14f0b7581281da18290ded5030fe34fbda077a09726.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xavier")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-532252")[#strong[#text("Xavier")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2019")])]

#text("Perhaps we could achieve it with inverse problem: from 1 we can reach any number through inverse function, that is, for all n, there is k > 1 such that (f^{-1})^k(1) = n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-532389")[#strong[#text("CH Mathematician Proves Result on ‘Dangerous’ Problem - CyberHero.TV")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2019")]

#text("[…] this past August an anonymous reader left a comment on Tao’s blog. The commenter suggested trying to solve the Collatz conjecture for “almost all” numbers, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-532466")[#strong[#text("Read : 2019-12-14 | thegraywolff")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2019")]

#text("[…] An article on Terry Tao’s recent contribution to the Collatz conjecture. The article cites this 2011 blog post by Tao, which in turn cites this xkcd […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a06305c485a4b074baa68637c308ab8e9663207429fa7bfdbb2f3c8b8ba6fb11-b9e65773a54a44ea93299868ed8a17b12c525dcd0a7c77f7193338f148d197c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lucian M.")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-3/#comment-532697")[#strong[#text("Lucian M.")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2019")])]

#text("The problem is actually nx+1, not just 3x+1. It’s a way of generating even numbers, x+1 works pretty well too. Each even number has a root in a odd number and eventually 1 which is odd.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-370914")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2014")])]

#text("This is funny and curious: ")#link("http://www.collatz3xplus1problem.com/")[#text("http://www.collatz3xplus1problem.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-385289")[#strong[#text("$3M Breakthrough Prizes now awarded in mathematics! | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2014")]

#text("[…] Tao among them. who is a great blogger and have commented on his great blog in the past (he has a great page on Collatz theory). cybersynchronicity! just wrote him a congratulatory comment yesterday. am hoping he reacts in his […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-395819")[#strong[#text("Number Theory is the Cocaine of Mathematics | fractalcows")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2014")]

#text("[…] following resulted not from my intention to prove the conjecture, but from the drive to deeply understand its underlying […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-410632")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2014")])]

#text("new ")#link("http://vzn1.wordpress.com/2014/08/29/collatz-breakthru/")[#text("very promising property on collatz conjecture discovered")]#text(". invitation to ")#link("http://meta.cstheory.stackexchange.com/questions/2858/looking-for-volunteers-collaborators-on-a-computer-verified-proof-of-collat")[#text("collaborators")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4714034167716801287888936f9442eaf8fec93f361b5e8dab928916154a1ee-4ad16f0ff2dace13b1bdbe37928dd3f9bd275b0301d4b18065c3f3d28c925771.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rlv")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-416386")[#strong[#text("rlv")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2014")])]

#text("Let c(n) be the number of steps to convert n to 1 using the Collatz rules. I just noticed that c(5) = 5. Are there any other number n such that c(n) = n? Or is there a simple explanation as to why only 5?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-443539")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2014")])]

#link("http://vzn1.wordpress.com/2014/11/26/collatz-striking-visualization-of-binary-density-for-3x-1-operation/")[#text("Collatz, striking visualization of binary density for 3x + 1 operation!")]#text(" crucial new piece of the puzzle! ruby/ gnuplot experimental math results")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-449739")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2015")])]

#text("attack on collatz using a ")#link("http://vzn1.wordpress.com/2015/01/01/ambitious-collatz-genetic-algorithm-code-graph-results/")[#text("novel genetic algorithm approach")]#text(" with some interesting results under further development, building on prior density results. the general high level idea is to create a new random walk out of collatz random walks with adjustable parameters, and the new random walk can be quantatively measured as “less random”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59ca7f79c6f1b16aaf88c680e00053602267f859d716d3c5cb2bd35afa98a9f5-b9234b930c2f9b933c07fc5df8f1882734b01f261782f33548a15245a86a49cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of herberthelling")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-453961")[#strong[#text("herberthelling")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2015")])]

#link("https://collatzproof.wordpress.com/")[#text("https://collatzproof.wordpress.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e0683a516d5e183002c1821a2bcf77f6dd2048dc7ce652e9eedd2f9745e5a2f-975bc0d752bf5e467bd62ac81478e64b6bcc54536820ca57125439f3daf6a05d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carlos Toscano-Ochoa")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-456428")[#strong[#text("Carlos Toscano-Ochoa")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2015")])]

#text("Could any of you send me the PDF by Bohm and Sontacchi?? I cannot get it and I need it for my research on Collatz conjecture. My email is ")#link("mailto:biotoscano@gmail.com")[#text("biotoscano@gmail.com")]#text(". Thank you very much!!")

#text("This is the URL that points to the paper, but it cannot be accessed:")

#link("http://www.ams.org/mathscinet-getitem?mr=551509")[#text("http://www.ams.org/mathscinet-getitem?mr=551509")]

#text("Thank you!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-458997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2015")])]

#text("Demonstrated the Collatz Conjecture.")

#text("There are infinity of algorithms in the form ")#mi("(X.a + 1)")#text(" for the cycle 4,2,1.")#linebreak()#text(" The first with $latex(X = 3)$; the second ")#mi("(X = 7)")#text("; the third ")#mi("(X = 15)")#text(".")

#text("See:")

#link("http://www.hrpub.org/journals/article_info.php?aid=2882")[#text("http://www.hrpub.org/journals/article_info.php?aid=2882")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-459500")[#strong[#text("Unsolved problems with the common core | Bits of DNA")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")]

#text("[…] despite much numeric evidence that it is true, has eluded proof. Mathematician Terence Tao has an interesting blog post explaining why (a) the conjecture is likely to be true and (b) why it is likely out of reach of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-459640")[#strong[#text("TECNOLOGÍA » Unsolved problems with the common core")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")]

#text("[…] much numeric evidence that it is true, has eluded proof. Mathematician Terence Tao has an interesting blog post explaining why (a) the conjecture is likely to be true and (b) why it is likely out of reach of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of o")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-466434")[#strong[#text("o")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2016")])]

#text("On the toy model for the weak Collatz conjecture: The correct constraint is \\\\ ")#tao-fit-display[#mitex("a_1=0<a_2<\\cdots<a_k")]

#text("[")#emph[#text("The two constraints are logically equivalent, since ")#mi("2^n")#text(" is never divisible by 3. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-467526")[#strong[#text("Pętle w ciągach typu collatza | Problem Collatza - co nowego?")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2016")]

#text("[…] The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-468770")[#strong[#text("Collatz Conjecture – Ket Space")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")]

#text("[…] Tao wrote an excellent post on the Collatz Conjecture on his blog. If you’re interested in taking a shot at this problem or just playing around with it a bit, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f6d475f7d90aa4c26ee6de969d7ae938e50f739586093aa4a3364fa06443e60-b43528e86b1661b003cbb5362cebd2cce5c88e13261005996021b587aa7de137.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thor X. Jones")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-468799")[#strong[#text("Thor X. Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("Restate Collatz’ conjecturre: Following the 3n+1 or /2 rule will produce a number which is a power of 2.")#linebreak()#text(" And incidentally every other power of 2 is 3*an odd number +1 and the others are 3*and odd number minus 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-469620")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("1) Let us find the upper limit ")#mi("1>")#text(" (")#link("https://en.wikipedia.org/wiki/Schnirelmann_density#Schnirelmann.27s_theorems")[#text("https://en.wikipedia.org/wiki/Schnirelmann_density#Schnirelmann.27s_theorems")]#text(" – Look at ")#mi("Corollary")#text("), then for the equation ")#mi("\\displaystyle  2^n = 3^{a_1} + 3^{a_2} + \\ldots + 3^{a_k}\" title=\"\\displaystyle  2^n = 3^{a_1} + 3^{a_2} + \\ldots + 3^{a_k}")#text(" there is ")#mi("k")#text(" for which the equation has no solution?")

#text("2) For example, we find this constant (let it be ")#mi("k=20")#text(") whether it will improve the latter estimate ")#mi("N^{0.84}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/493cabd4e191725b0c82ba0ea026478dee03a5b70be4e648c6385a897c720ef2-7aef8dd7e51c869168435b77d6651abdab42a63faac71b0d9e2b5d2adeb40960.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sawon Pratiher")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-471493")[#strong[#text("Sawon Pratiher")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2016")])]

#text("It has been shown in the below arxiv preprint version. that, there exists only six, i.e., a finite number of recurrent forms in which the path elements of the Collatz sequence switches, till one of them reaches a number of the form 2^m.")#linebreak()#text(" ")#link("http://arxiv.org/abs/1608.03600")[#text("http://arxiv.org/abs/1608.03600")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73c41f40beee793dd13687ed07250ba8dc99621d21174e9ccea703fd7051c22b-1921013e446970eebc335c987eab86b949c588d53975d6b4623ff9c3b684c68a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-471497")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2016")])]

#text("I think Sawon Pratiher’s approach is correct. I have thought about the same idea before and I am more or less sure looking at mod 4 and mod 8 suffices. Professor Tao please take a look at Sawon’s Pratiher’s result. Even if not correct he is extremely close to correct path.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/493cabd4e191725b0c82ba0ea026478dee03a5b70be4e648c6385a897c720ef2-7aef8dd7e51c869168435b77d6651abdab42a63faac71b0d9e2b5d2adeb40960.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sawon Pratiher")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-471875")[#strong[#text("Sawon Pratiher")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("The recurrences shown here, can it be solved using the method of solving simultaneous solution of linear congruence equations?")#linebreak()#text(" ")#link("http://arxiv.org/abs/1608.03600")[#text("http://arxiv.org/abs/1608.03600")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a206486953aa84d7bfc3dabc824894fb43d36074ccb40945ea33100ba1ed533d-80cf840618106f98108763ea202a0911db3947994f845dbb1510abf59c20daa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miklos Kontra")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-471958")[#strong[#text("Miklos Kontra")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2016")])]

#text("Hi, I would like to tell everyone that i found the solution to the problem, i am working on the problem since 3 years and i m glad to show the results in my computer science thesis here in Argentina University UNLAM I show that as the hungarian Paul Erdos said mathematics are not ready to solve this kind of problem, basically the answer is as Conway states that it s a tree b, but i showed that it behaves as a tree if you take out the cycle 4 2 1 since a tree can not have a cycle on it, i found the 3 patterns that shows how to get from any points before getting to the cycle which i removed. The good thing once i get the graph is that it shows why it s really deterministic and shows in it the randomness behaviour i wrote to conway but i was told that he is not able to understand my work may be due to some hilness I would like to get in touch with Tao to discuss the work is it posible? Thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71280b536b1432843064021ecbabec32996edc30f12b8acfafc84b23bab30255-89664768714fbf7bf0cdb2537f159120e7a7041707c42ffc99959ecf53e57175.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuvallevental")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-472572")[#strong[#text("yuvallevental")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2016")])]

#text("I have discovered an infinite number of solutions for the Collatz conjecture. This does not prove it, but shows that there is no upper bound. Is this already known/good enough for a research paper? Does anyone want to give advice?")

#link("http://pastebin.com/raw/q5DyHGiz")[#text("http://pastebin.com/raw/q5DyHGiz")]

#text("Yuval Levental")#linebreak()#text(" ")#link("http://linkedin.com/in/yuvallevental")[#text("http://linkedin.com/in/yuvallevental")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-472713")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2016")])]

#text("Two professors from Italy and Belgium recently announced a proof of the Collatz Conjecture. Any comments on it? ")#link("https://www.researchgate.net/publication/299749569_A_proof_of_the_Collatz_conjecture")[#text("https://www.researchgate.net/publication/299749569_A_proof_of_the_Collatz_conjecture")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/493cabd4e191725b0c82ba0ea026478dee03a5b70be4e648c6385a897c720ef2-7aef8dd7e51c869168435b77d6651abdab42a63faac71b0d9e2b5d2adeb40960.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-472718")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2016")])]

#text("Request to please have a look at the recurring patterns in the 3n+1 problem.")#linebreak()#text(" ")#link("https://arxiv.org/abs/1608.03600")[#text("https://arxiv.org/abs/1608.03600")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-472732")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2016")])]

#text("The argument in theorem 9 (excluding the existence of any zero-measure unbounded deterministic trajectory) is not sufficiently clear. It would be clearer if it could be made effective (e.g. by giving an explicit bound ")#mi("M(n_0)")#text(" for all the iterates of any ")#mi("n_0")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-472736")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2016")])]

#text("I think they mean that since there are no zero measure sets of integers given the measure that they defined, there cannot be a zero-measure trajectories, by the ergodic theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dd8939a7a37f6fadf1367a4156f1629dcfd72f868c2761d7688707a181852f1-02578546d12d05789bed34b72cdf5f1cd8d5cbc0d63b5cb15be73c6313bb190d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitri Kamenetsky")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-476394")[#strong[#text("Dmitri Kamenetsky")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2017")])]

#text("The paper looks legit. I would love to know the opinion of the experts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anh quốc nguyễn")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-473373")[#strong[#text("anh quốc nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("collatz conjecture’s proof")#linebreak()#text(" 1. Introduction:")#linebreak()#text(" Collatz conjecture are define that with G(n)={ n÷2 n≡0(mod2)")#linebreak()#text(" 3n+1 n≡1(mod2)")#linebreak()#text(" conjecture said that there will alway exist k that Gk(n)=1.")#linebreak()#text(" 2. backround of the proof")#linebreak()#text(" the proof will base on the position of odd number in the chart. the problem of this situation is about the input and the out put of the equation.")#linebreak()#text(" 3. proof")

#text("by observing G(n)≡0(mod2) => G(n)= 2k×m")#linebreak()#text(" m=2 =>G(n)k+1=1")#linebreak()#text(" m≡1(mod2) => G(n)k=m")#linebreak()#text(" base on that fact")#linebreak()#text(" we will mainly focus on the behavior of G(n) when m≡1(mod2)")

#text("let O be the group of odd number")#linebreak()#text(" O={O1, O2, O3, …, OL,…}")#linebreak()#text(" where OL+1-OL =2")#linebreak()#text(" O1 =1")#linebreak()#text(" L: the position of odd start from 1")#linebreak()#text(" =>OL= 2L-1")

#text("by another observation")#linebreak()#text(" G(OL)-G(OL-1)=3 (since O1-O2 =2)")#linebreak()#text(" => the output of the equation as O1-> infinity is alternating odd and even.")#linebreak()#text(" since G(1)≡0 (mod2)")#linebreak()#text(" => G(O2L-1)≡0 (mod2) and G(O2L)≡1(mod2)")#linebreak()#text(" same agument, we will just forcus on output odd.")#linebreak()#text(" since G(O2L)≡1 (mod2) => G(O2L)= Osomething")

#text("we know that G(1)=G(O1)=2, G(OL)-G(OL-1)=3 and OL=2L-1")#linebreak()#text(" => other way of writting for the equation of n ≡1(mod2)")#linebreak()#text(" G(O2L) =2+3(2L-1)= 6L-1= O3L")#linebreak()#text(" O3L=G(O2L)")

#text("now we look at G(odd)≡0(mod2)")#linebreak()#text(" G(n)≡0(mod2)")#linebreak()#text(" =>G(n)=2k×m")#linebreak()#text(" m≡1(mod2) (did mention)")#linebreak()#text(" m=2 =>G(n)=2k+1")#linebreak()#text(" 2k+1=2+3L")#linebreak()#text(" =>L=2k+1-2÷3")#linebreak()#text(" => 2k≡1(mod3)")#linebreak()#text(" =>k≡0(mod2)")

#text("with the position of odd that")#linebreak()#text(" L=(2k-2)/3 k≡1(mod2)")#linebreak()#text(" G(x)->1")#linebreak()#text(" since there are infinite k≡1(mod2)")#linebreak()#text(" => there are infinite L that make G(x)->1")#linebreak()#text(" => the conjecture is true")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-474265")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("Why did Professor Tao say it is only possible to prove uniform convergence for the first O(log n) iterations and that it gets too complicated afterwards for known techniques?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a206486953aa84d7bfc3dabc824894fb43d36074ccb40945ea33100ba1ed533d-80cf840618106f98108763ea202a0911db3947994f845dbb1510abf59c20daa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of miklos kontra")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-474271")[#strong[#text("miklos kontra")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("Hi, i ve worked out a way to show that Collatz conjecture is true using a tree structure just like Conway did , but my tree is better than the one that Conway did it also shows why mathematics can t show how to solve the problem since in the tree structure it can be seen that there is some kind of randomness, i would apreciate if some one could help me showing me or teaching me how to upload the tree structure and it s explanation, i live in Argentina and i m working on this problem at one of the University but since it is not amathematical proof but a perfect tree structure that holds all the numbers showing all the paths, i think that if matematicians sees the structure they would better understand what s going on and might use their knowledge to solve mathematically the problem which i know is not under my knowledge since i m an electronic engineer but a real entusiasm and i love maths, i thing it would really benefit the math word to understand that the Collatz conjecture is true and help mathematicians.")#linebreak()#text(" Miklos Kontra from Argentina")

#text("Enviado desde mi iPad")

#text("El 11 nov 2016, a las 6:28 p. m., What’s new <comment-reply@wordpress.com> escribió:")

#text("Craig commented: “Why did Professor Tao say it is only possible to prove uniform convergence for the first O(log n) iterations and that it gets too complicated afterwards for known techniques?”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-474496")[#strong[#text("Collatz-formodningen. | Matematikbloggen på AAU")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")]

#text("[…] Erdös har efter sigende sagt, at matematikken endnu ikke er klar til at løse Collatzproblemet og Terry Tao er enig. Det er et fint problem, fordi det er let at forklare, man kan selv finde på lignende problemer […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fa2407571d652c95791a6c98881536f5b90e17136cc20d929756462ae9cd957-925fd9e1d8b68994630baeb6c07376fc8827a207d1129110885a11c2ae8fa804.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Madera")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478024")[#strong[#text("Martin Madera")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2017")])]

#text("I have noticed a surprising and very strong regularity in the distribution of orbit lengths. I define chain(n) as the orbit, skipping even numbers and terminating once a number in some earlier chain(k) for k<n has been reached. So the first few chains are as follows:")

#text("chain(1) = {1}")#linebreak()#text(" chain(3) = {3, 5, 1}")#linebreak()#text(" chain(5) = {5}")#linebreak()#text(" chain(7) = {7, 11, 17, 13, 5}")#linebreak()#text(" chain(9) = {9, 7}")#linebreak()#text(" chain(11) = {11}")#linebreak()#text(" chain(13) = {13}")#linebreak()#text(" chain(15) = {15, 23, 35, 53, 5}")

#text("and the corresponding chain lengths are 1, 3, 1, 5, 2, 1, 1 and 5, respectively. The idea is to iterate until you hit a number that you've seen before.")

#text("I have calculated all chains up to n=50,000,000. I then looked at the distribution of chain lengths for 0 < n < 100,000 and compared this to the distribution for 49,900,000 < n < 50,000,000. To my surprise the distributions are virtually identical!")

#text("Here's a snippet:")

#text("Chain length — Number of occurrences 0-100k — Number of occurrences 49,900k-50M")

#text("1 — 23401 — 23418")#linebreak()#text(" 2 — 13665 — 13646")#linebreak()#text(" 3 — 3238 — 3244")#linebreak()#text(" 4 — 3333 — 3342")#linebreak()#text(" 5 — 1671 — 1677")#linebreak()#text(" 6 — 1413 — 1393")#linebreak()#text(" 7 — 841 — 844")#linebreak()#text(" 8 — 525 — 512")#linebreak()#text(" 9 — 397 — 380")#linebreak()#text(" 10 — 271 — 267")

#text("I don't see a way of attaching the full graph, so I will post a link to my Google Drive instead:")

#link("https://drive.google.com/file/d/0B9yj-Ue4a4e9SXlwMnJxWTcxMU0/view?usp=sharing")[#text("https://drive.google.com/file/d/0B9yj-Ue4a4e9SXlwMnJxWTcxMU0/view?usp=sharing")]

#text("For higher lengths (where there are fewer occurrences) there is more noise, but overall these look to me like two samples drawn from an identical distribution. The accuracy with which fine details are reproduced (e.g. the dip at length=3) in both samples is very surprising to me.")

#text("Here is my very simple Perl5 script for calculating chains:")

#link("https://drive.google.com/file/d/0B9yj-Ue4a4e9ZFJxSmVNTHlDV1E/view?usp=sharing")[#text("https://drive.google.com/file/d/0B9yj-Ue4a4e9ZFJxSmVNTHlDV1E/view?usp=sharing")]

#text("and its output up to 10,000:")

#link("https://drive.google.com/file/d/0B9yj-Ue4a4e9cWNOOFB3T2kwVnM/view?usp=sharing")[#text("https://drive.google.com/file/d/0B9yj-Ue4a4e9cWNOOFB3T2kwVnM/view?usp=sharing")]

#text("These results seem to suggest that chains around n=50,000,000 behave exactly like chains around n=1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fa2407571d652c95791a6c98881536f5b90e17136cc20d929756462ae9cd957-925fd9e1d8b68994630baeb6c07376fc8827a207d1129110885a11c2ae8fa804.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Madera")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478030")[#strong[#text("Martin Madera")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2017")])]

#text("P.S. It has occurred to me that calling these objects “branches” rather than “chains” would make more sense. The word “branch” makes one think of something attached to the rest of the tree, which is a very good intuition for what these objects are.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2017")])]

#link("https://www.quora.com/Is-the-Collatz-Conjecture-solvable/answer/David-Cole-146")[#text("https://www.quora.com/Is-the-Collatz-Conjecture-solvable/answer/David-Cole-146")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ebc4f712071929c2bb834316d5571ae59209835e5af903e7d18afc1bcc24b2f-5bf3a998f063321246b921a2f716093e854ef90694b866ea0fdc72668782bcbf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerry")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478050")[#strong[#text("Gerry")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2017")])]

#text("“Conjecture of Erdos” links to a review of his 1979 paper, Some unconventional problems in Number Theory. That paper is available at ")#link("http://www.renyi.hu/~p_erdos/1979-21.pdf")[#text("http://www.renyi.hu/~p_erdos/1979-21.pdf")]#text(" but I don’t see the powers-of-2 conjecture in it.")

#emph[#text("[Link corrected – seems Erdos published two papers with the same name in 1979! -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fa2407571d652c95791a6c98881536f5b90e17136cc20d929756462ae9cd957-925fd9e1d8b68994630baeb6c07376fc8827a207d1129110885a11c2ae8fa804.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Madera")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478081")[#strong[#text("Martin Madera")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2017")])]

#text("I have made further progress. The definition of branches in my previous post is fairly difficult to reason about, because it involves looking at the content of all earlier branches.")

#text("So I tried a simpler definition: branch(n) is the orbit of n, leaving out even numbers, which terminates once it reaches a number k < n. So the first few branches are as follows:")

#text("branch(3) = {3, 5, 1}")#linebreak()#text(" branch(5) = {5, 1}")#linebreak()#text(" branch(7) = {7, 11, 17, 13, 5}")#linebreak()#text(" branch(9) = {9, 7}")#linebreak()#text(" branch(11) = {11, 17, 13, 5}")

#text("and the lengths are 3, 2, 5 and 2, respectively.")

#text("It turns out that the behaviour for this simpler definition is even more regular! I have looked at two intervals:")

#text("I1 = 2 … 2^22 (= 4,194,304)")#linebreak()#text(" I2 = 2^50 + 2 … 2^50 + 2^22")

#text("Both contain exactly 2,097,151 odd numbers. The number of occurrences of branch lengths up to and including 26 is exactly the same in both intervals (!), and it is as follows:")

#text("2 1048575")#linebreak()#text(" 3 262144")#linebreak()#text(" 4 262144")#linebreak()#text(" 5 98304")#linebreak()#text(" 6 114688")#linebreak()#text(" 7 49152")#linebreak()#text(" 8 30720")#linebreak()#text(" 9 43520")#linebreak()#text(" 10 22144")#linebreak()#text(" 11 30464")#linebreak()#text(" 12 15376")#linebreak()#text(" 13 10608")#linebreak()#text(" 14 16090")#linebreak()#text(" 15 8818")#linebreak()#text(" 16 12750")#linebreak()#text(" 17 6806")#linebreak()#text(" 18 9807")#linebreak()#text(" 19 5170")#linebreak()#text(" 20 3737")#linebreak()#text(" 21 5909")#linebreak()#text(" 22 3348")#linebreak()#text(" 23 5034")#linebreak()#text(" 24 2746")#linebreak()#text(" 25 1984")#linebreak()#text(" 26 3189")

#text("I find it more helpful to transform these into stopping probabilities, defined as:")

#text("P(stop at length L | not stopped earlier) = (number of branches of length L) / (number of branches of length >= L)")

#text("The first three stopping probabilities are as follows:")

#text("2 … 50.0000%")#linebreak()#text(" 3 … 25.0000%")#linebreak()#text(" 4 … 33.3333%")

#text("I have looked at the values of n for which L := |branch(n)| = 2, and it is fairly easy to spot that they appear to be of the form:")

#text("L=2 branches: n = 4k+1")

#text("where k is an integer >=0.")

#text("It is quite easy to see what is going on here: all even integers are of the form 2k+1, which can also be written as either 4k+1 or 4k+3. Since n is odd, the first step must be:")

#text("n –> 1/2 * ( 3n + 1 )")

#text("which gives:")

#text("4k+1 –> 6k+2 … even, so /2 to 3k+1, which is less than 4k+1 = stop")#linebreak()#text(" 4k+3 –> 6k+5 … odd, so another iteration of 1/2 * (3n + 1)")

#text("So we can see that n=4k+1 stops at L=2, whereas n=4k+3 continues. This explains why exactly 1/2 of all branches stop at L=2.")

#text("I have further looked at branches of length 3, and noticed that all of the n for which |branch(n)|=3 appear to be of the form:")

#text("L=3 branches: n = 16k+3")

#text("This would explain why the stopping probability is 1/4:")

#text("– the branches that did not stop at L=2 are of the form 4k+3")#linebreak()#text(" – this is equivalent to 16k+3, 16k+7, 16k+11 or 16k+15")#linebreak()#text(" – of these, 16k+3 stop at L=3, i.e. exactly 1/4")

#text("As a final exercise I looked at branches of length 4, and these appear to be of the form:")

#text("L=4 branches: n = 32k+11 or 32k+23")

#text("Once again it is fairly simple to explain why the stopping probability is 1/3:")

#text("– the branches that did not stop at L=3 are of the form 16k+7, +11, +15")#linebreak()#text(" – this is equivalent to 32k+7, +11, +15, +23, +27, +31")#linebreak()#text(" – of these, 32k+11 and +23 stop at L=4, i.e. exactly 2/6 = 1/3")

#text("Once I noticed the key role of powers of 2 (i.e. 4, 16, 32), I changed the intervals to reflect this and produced the statistics above.")

#text("If this behaviour continues for longer lengths, it would explain why there are differences at L>26: the base at this point has presumably grown to >2^22, so the various classes relevant at those lengths start having different numbers of members in the two intervals I have chosen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fa2407571d652c95791a6c98881536f5b90e17136cc20d929756462ae9cd957-925fd9e1d8b68994630baeb6c07376fc8827a207d1129110885a11c2ae8fa804.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Madera")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478087")[#strong[#text("Martin Madera")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2017")])]

#text("I have found a neat way of generating orbits longer than any arbitrary length.")

#text("If we call the two transformations g and h,")

#text("g: n –> (3n+1)/2")#linebreak()#text(" h: n –> n/2 … the “h” is short for “halve”")

#text("and then define g^k to have the obvious meaning:")

#text("g^k (n) := g{ g^(k-1) (n) }")

#text("i.e. k successive applications of g, then I believe that")

#text("N(L) := (2^L) – 1")

#text("is obviously odd, and more importantly will remain odd under each of (L-1) successive applications of g.")

#text("For the record, the result of L applications of g will be:")

#text("g^L {N(L)} = (3^L) – 1")

#text("Unless I messed up somewhere, this relation can be derived by iteratively repeating the following steps:")

#text("1) Apply the substitution:")

#text("k –> 2k + 1")

#text("to the equation derived during previous iteration, or to the following equation in the first iteration:")

#text("k = k.")

#text("In the first iteration this simply results in:")

#text("2k + 1 = 2k + 1.")

#text("In general, assuming that we are in iteration n+1 and the equation resulting from iteration n was:")

#text("g^n { (2^n)k + (2^n) – 1 } = (3^n)k + (3^n) – 1")

#text("this step will give:")

#text("g^n { (2^(n+1))k + (2^(n+1)) – 1 } = 2*(3^n)k + 2*(3^n) – 1 .")

#text("2) Note that following the substitution, the RHS is now clearly odd, so we can generate the next number in the orbit by applying g to both sides. In the first iteration this results in:")

#text("g(2k+1) = 3k + 2")

#text("which just happens to be of the form noted above. In general, applying g to the RHS from step 1 gives:")

#text("g{ 2*(3^n)k + 2*(3^n) – 1 } = (3^n)k + (3^n) – 1")

#text("and the LHS is simply:")

#text("g^(n+1) { (2^(n+1))k + (2^(n+1)) – 1 }")

#text("This is precisely the equation for n+1.")

#text("As the final step in the proof, we may as well set k=0 to simplify the result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478121")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Quite neat indeed. Just an extension your observation:")

#mi("g^k(3^a \\cdot 2^b - 1) = 3^{a+k} \\cdot 2^{b-k} - 1")

#text("which is odd for ")#mi("k \\textless b")#text(" and even for ")#mi("k = b")#text(", where of course ")#mi("a, b, k \\in \\mathbb{N} \\cup \\{ 0 \\}")#text(".")

#text("In particular this means that all numbers of the form ")#mi("3^a \\cdot 2^b - 1")#text(" have orbits of length at least ")#mi("b")#text(" for ")#mi("\\forall a, b \\in \\mathbb{N} \\cup \\{ 0 \\}")#text(".")

#text("P.S.")#linebreak()#text(" Of course it holds that ")#mi("g(n) \\textgreater n")#text(" for ")#mi("\\forall n \\in \\mathbb{N}")#text(" which means that the first ")#mi("b")#text(" elements of the orbit of ")#mi("3^a \\cdot 2^b - 1")#text(" (from ")#mi("k = 0")#text(" to ")#mi("k = b-1")#text(") actually form a monotonously increasing sequence of odd numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478126")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Even more generally for ")#mi("b, k \\in \\mathbb{N} \\cup \\{ 0 \\}")#text(" and ")#mi("o \\in 2 \\mathbb{N} - 1")#text(" odd:")

#mi("g^k(o \\cdot 2^b - 1) = o \\cdot 3^k \\cdot 2^{b-k} - 1")

#text("which is odd for ")#mi("k \\textless b")#text(" and even for ")#mi("k = b")#text(". All numbers of the form ")#mi("o \\cdot 2^b - 1")#text(" for odd ")#mi("o")#text(" thus have orbits of length at least ")#mi("b")#text(".")

#text("(The above formula can be easily checked by writing ")#mi("g")#text(" as ")#mi("g(n) = \\frac{3}{2} (n + 1) - 1")#text(".)")

#text("The length of the orbit is actually a bit longer, if we count halving even numbers with ")#mi("h")#text(" as steps (we usually do). After ")#mi("k = b")#text(" iterations we arrive at:")

#mi("g^b(o \\cdot 2^b - 1) = o \\cdot 3^b - 1")

#text("after which we would need at least ")#mi("m = \\lceil \\log_2 o + b \\cdot \\log_2 3 \\rceil")#text(" halvings to reach ")#mi("1")#text(" as fast as possible. The actual orbit is thus at least ")#mi("b + \\lceil \\log_2 o + b \\cdot \\log_2 3 \\rceil \\approx \\log_2 o + 2.58496 b")#text(" steps long assuming we don’t end up in a non-trivial cycle (in which case the Collatz conjecture would be false).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matjaž Gomilšek")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478137")[#strong[#text("Matjaž Gomilšek")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Of course every odd number can be written in the form ")#mi("o \\cdot 2^b - 1")#text(" and every even number can be written in the form ")#mi("o \\cdot 2^b")#text(" where ")#mi("o")#text(" is odd and ")#mi("b \\in \\mathbb(N)")#text(". We can thus define a compressed version of the Collatz function ")#mi("f_1")#text(":")

#mi("F_1(o \\cdot 2^b - 1) = g^b(o \\cdot 2^b - 1) = o \\cdot 3^b - 1")#linebreak()#text(" ")#mi("F_1(o \\cdot 2^b) = h^b(o \\cdot 2^b) = o")

#text("This function is just ")#mi("f_1")#text(" iterated ")#mi("b")#text(" times on numbers of the form ")#mi("o \\cdot 2^b - c")#text(" for ")#mi("c \\in \\{ 0, 1 \\}")#text(". The function ")#mi("F_1")#text(" maps odd numbers to even ones and vice versa:")

#mi("F_1(2 \\mathbb{N} - 1) \\subset 2 \\mathbb{N}")#linebreak()#text(" ")#mi("F_1(2 \\mathbb{N}) \\subset 2 \\mathbb{N} - 1")

#text("and the trivial cycle of ")#mi("F_1")#text(" is again the same as for ")#mi("f_1")#text(", namely: ")#mi("1, 2")#text(".")

#text("It can also be quite efficiently implemented in a binary encoding. Explicitly:")

#text("1.) If ")#mi("n")#text(" is even: delete the trailing zeros in its binary encoding.")#linebreak()#text(" 2.) If ")#mi("n")#text(" is odd: add ")#mi("1")#text(" to it, delete the ")#mi("b")#text(" trailing zeros from the resulting binary encoding, multiply the resulting number ")#mi("o")#text(" by ")#mi("3^b")#text(" (= append a trailing zero to ")#mi("o")#text(" and add this to ")#mi("o")#text("; repeat ")#mi("b")#text(" times), and finally subtract ")#mi("1")#text(" from it.")

#text("Whether this is useful I do not know, but I do like the fact that this compressed ")#mi("F_1")#text(" always exchanges odd and even numbers … :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matjaž Gomilšek")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478138")[#strong[#text("Matjaž Gomilšek")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Finally, ")#mi("F_1")#text(" can be compressed a bit further by defining ")#mi("F_2(n) = F_1(F_1(n))")#text(" as the composition of ")#mi("F_1")#text(" with itself, restricted (for example) to just the odd integers. Then:")

#mi("F_2 : 2 {\\mathbb N} - 1 \\rightarrow 2 {\\mathbb N} - 1")

#text("and the trivial cycle is simply a fixed point: ")#mi("F_2(1) = 1")#text(". I believe this to be a most economical way of writing the (iterated) Collatz function.")

#text("Explicitly, ")#mi("F_2")#text(" is equivalent to:")

#mi("F_2(n) = h^a(g^b(n)) = f_1^{a+b}(n)")

#text("where: ")#mi("a, b \\in {\\mathbb N}")#text(" are uniquely defined for a given odd ")#mi("n \\in 2 {\\mathbb N} - 1")#text(" by (here ")#mi("o, p \\in 2 {\\mathbb N} - 1")#text(" are odd integers):")

#mi("n = o \\cdot 2^b - 1")#linebreak()#text(" ")#mi("o \\cdot 3^b - 1 = p \\cdot 2^a")

#text("Or in other words, you can look at the occurrences of ")#mi("h...hg...g")#text(" sequences in the application of ")#mi("f_1")#text(" to ")#mi("n")#text(" and replace each such sequence with a single application of ")#mi("F_2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matjaž Gomilšek")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478151")[#strong[#text("Matjaž Gomilšek")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Forgot to add that upon (uniquely) solving the system:")

#mi("o \\cdot 2^b - 1 = n")#linebreak()#text(" ")#mi("o \\cdot 3^b - 1 = p \\cdot 2^a")

#text("where ")#mi("n, o, p \\in 2 \\mathbb{N} - 1")#text(" odd and ")#mi("a, b \\in \\mathbb{N}")#text(" the result of applying ")#mi("F_2")#text(" to ")#mi("n")#text(" can be simply written as:")

#mi("F_2(n) = p")

#text("P.S. Solving the system is really easy, as detailed in a previous post. Explicitly:")

#text("1.) ")#mi("b")#text(" = (number of trailing binary zeros in ")#mi("n + 1")#text(")")#linebreak()#text(" 2.) ")#mi("o")#text(" = (")#mi("n + 1")#text(" without the trailing binary zeros)")#linebreak()#text(" 3.) ")#mi("p")#text(" = (")#mi("o \\cdot 3^b - 1")#text(" without the trailing binary zeros) = ")#mi("F_2(n)")

#text("P.P.S. I must look over your posts in more detail as well, Martin. Will most likely post more tomorrow.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fa2407571d652c95791a6c98881536f5b90e17136cc20d929756462ae9cd957-925fd9e1d8b68994630baeb6c07376fc8827a207d1129110885a11c2ae8fa804.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Madera")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478131")[#strong[#text("Martin Madera")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("You are on the right track, but this can be generalised much, much futher.")

#text("I believe I have understood the reason for the periodicity shown in my earlier comments, but I’ve been too busy to post.")

#text("If we call the two operations")

#mi("g: n \\rightarrow \\frac{1}{2}(3n+1)")

#mi("h: n \\rightarrow \\frac{1}{2}n")#text(" … “half”")

#text("(as before) and then compose the operations into operations like")

#mi("hgg(n) := h\\left( g\\left( g\\left(n \\right) \\right) \\right)")

#text("then these “operators” have something that, for lack of a better word, I call eigensets.")

#text("I will start by writing out a few interesting equations, and then explain the meaning (to the extent that I’ve understood it) later.")

#text("hhh(8k + 0) = 1k + 0")

#text("ghg(8k + 1) = 9k + 2")

#text("hgh(8k + 2) = 3k + 1")

#text("hgg(8k + 3) = 9k + 4")

#text("ghh(8k + 4) = 3k + 2")

#text("hhg(8k + 5) = 3k + 2")

#text("ggh(8k + 6) = 9k + 8")

#text("ggg(8k + 7) = 27k + 26")

#text("The sets in the left bracket are what I call “eigensets” of the operator: they are the only integers ")#mi("\\ge 0")#text(" for which the operator returns an integer (as opposed to a fraction).")

#text("We see that there are exactly 2^3 = 8 operators of order 3, and their eigensets span the integers.")

#text("This explains the periodicity observed in my earlier comments.")

#text("The general form of the eigen-equation is as follows:")

#mi("T_{a,b} (2^a k + c) = 3^{a-b} k + T_{a,b} (c)")

#text("where the operator T consists of a sequence of a total of ")#emph[#text("a")]#text(" operators, of which ")#emph[#text("(a-b)")]#text(" are g-operators and ")#emph[#text("b")]#text(" are h-operators.")

#text("Here I’ve used the fact that")

#mi("g(m+n) = \\frac{3}{2} m + g(n)")

#text("or more generally")

#mi("g^a (m+n) = \\left(\\frac{3}{2}\\right)^a m + g^a (n)")

#text("and since a similar relation holds for the h-operator as well, I get")

#mi("T_{a,b}(m+n) = \\frac{ 3^{a-b} }{ 2^a } m  +  T_{a,b} (n)")

#text("Now there are two questions:")

#text("Q1: Given an eigenset, how do you find its corresponding operator?")

#text("Q2: Given an operator, how do you find its eigenset?")

#text("Rest in the next post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fa2407571d652c95791a6c98881536f5b90e17136cc20d929756462ae9cd957-925fd9e1d8b68994630baeb6c07376fc8827a207d1129110885a11c2ae8fa804.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Madera")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478134")[#strong[#text("Martin Madera")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Following on from my previous post …")

#strong[#text("Q1: Given an eigenset, how do you find its corresponding operator?")]

#text("This is fairly easy: in order to find the operator associated with eigenset ")#mi("2^a k + c")#text(", you simply follow the orbit of ")#emph[#text("c")]#text(" for ")#emph[#text("a")]#text(" steps and note the sequence of g and h operations. For example, for 8k+6 above, we first halve to 3, then g from 3 to 5, and then g again from 5 to 8. Hence, the operator associated with the eigenset 8k+6 is ggh, and the RHS constant is ggh(6)=8.")

#strong[#text("Q2: Given an operator, how do you find its eigenset?")]

#text("Going the other way is a bit harder. The method I use generalizes the approach from my earlier post. It starts from the equation")

#text("k = k")

#text("and uses one of these two substitions at each step: either")

#mi("k \\rightarrow 2k")

#text("or")

#mi("k \\rightarrow 2k+1")#text(" .")

#text("For example for the operator ggh, we start with")

#text("k = k")

#text("and since we want to apply h, we need it to be even (at the moment it could be either). So we apply ")#mi("k \\rightarrow 2k")#text(" giving")

#text("2k = 2k")

#text("Now the RHS expression is clearly even, so we can apply h:")

#text("h(2k) = h(2k)")

#text("and simplifying the h on the RHS gives us the first-order eigen-equation")

#text("h(2k) = k .")

#text("Next we need an odd number for g, so looking at the RHS, we see that in this case we need to apply ")#mi("k \\rightarrow 2k+1")#text(":")

#text("h(2(2k+1)) = 2k + 1")

#text("The RHS is now odd, so we can apply g:")

#text("gh(4k + 2) = g(2k + 1)")

#text("Working out the g() on the RHS then gives us the second-order eigen-equation")

#text("gh(4k + 2) = 3k + 2 .")

#text("Next we need the RHS to be odd for the final g, and we once again achieve this by applying ")#mi("k \\rightarrow 2k+1")#text(" :")

#text("gh( 4(2k+1) + 2 ) = 3(2k+1) + 2")

#text("i.e.")

#text("gh(8k + 6) = 6k + 5")

#text("The RHS is now odd for any k, so we can apply g once again:")

#text("ggh(8k + 6) = g(6k + 5)")

#text("and working out the RHS gives us the eigen-equation for our chosen third-order operator ggh:")

#text("ggh(8k + 6) = 9k + 8 .")

#text("The constant next to k on the RHS is always a power of 3, i.e. odd. So which substitution is applied at each step depends on the final number on the RHS and whether we need the result to be odd (for g) or even (for h). In the above example the relevant numbers were all even (0, 0 and 2, respectively). Had one of them been odd, we would have used the other transformation instead, e.g. if we wanted to turn")

#text("3k + 3")

#text("into an even expression, we would use ")#mi("k \\rightarrow 2k+1")#text(", which gives us")

#text("3(2k+1) + 3 = 6k + 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fa2407571d652c95791a6c98881536f5b90e17136cc20d929756462ae9cd957-925fd9e1d8b68994630baeb6c07376fc8827a207d1129110885a11c2ae8fa804.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Madera")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478135")[#strong[#text("Martin Madera")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("As a final observation for the above posts, at any given order ")#emph[#text("a")]#text(" the “first” i.e. 0 eigenset is:")

#mi("h^a (2^a k) = k")

#text("and the last one is:")

#mi("g^a (2^a k + 2^a - 1) = 3^a k + 3^a - 1")

#text("The 1 and 2 eigensets are as follows:")

#text("– for even orders:")

#mi("hg..hghg(2^a k + 1) = 3^\\frac{a}{2} k + 1")

#mi("gh..ghgh(2^a k + 2) = 3^\\frac{a}{2} k + 2")

#text("– whereas for odd orders:")

#mi("ghg..hghg(2^a k + 1) = 3^\\frac{a+1}{2} k + 2")

#mi("hgh..ghgh(2^a k + 2) = 3^\\frac{a-1}{2} k + 1")

#text("I have a bit more to say on operators, orbit length and the possibility of cycles, but need to go and earn a living. Hopefully more over the weekend!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fa2407571d652c95791a6c98881536f5b90e17136cc20d929756462ae9cd957-925fd9e1d8b68994630baeb6c07376fc8827a207d1129110885a11c2ae8fa804.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Madera")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-478152")[#strong[#text("Martin Madera")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("4. One idea I’m pursuing is that it might be more efficient to search (for cycles) in operator space as opposed to number space — in theory it could speed up the search because you don’t need to deal with all the copies, over and over again.")

#text("The idea rests on two insights:")

#text("i) All the operators I’ve looked at so far (except those corresponding to 0, 1 and 2 eigensets, which contain the ")#mi("0 \\to 0")#text(" and ")#mi("1 \\to 2 \\to 1")#text(" cycles) have the following property: in the eigen-equation")

#mi("T(2^a k + c) = 3^{a-b} k + T(c)")

#text("– either ")#mi("2^a > 3^{a-b}")#text(" and ")#mi("c > T(c)")#text(" … an “underwater” operator")

#text("– or ")#mi("3^{a-b} > 2^a")#text(" and ")#mi("T(c) > c")

#text("i.e. the result is either always less than the argument, or always greater, for all k.")

#text("I am only interested in “branches”, defined as orbits that stop once you hit a lower number than the one you started from. (The rationale here is that if you’re lower than you started, you’ve “joined the tree” — the rest is a problem you’ve dealt with earlier in your search.)")

#text("ii) One can use the approach from Q2 in my previous post to grow the operator eigen-equations indefinitely. At each iteration one discards any operators that are “underwater”, and the rest are bifurcated via ")#mi("k \\to 2k")#text(" and ")#mi("k \\to 2k+1")#text(" and then grown by one.")

#text("5. Quickly regarding cycles. A cycle is T(n) = n.")

#text("If I remember correctly, it’s elementary number theory that prime decompositions are unique, so you can’t have ")#mi("2^a = 3^{a-b}")#text(" and the only options are ")#mi("2^a > 3^{a-b}")#text(" and ")#mi("3^{a-b} > 2^a")#text(".")

#text("So the only options for cycles are:")

#text("i) ")#mi("2^a > 3^{a-b}, c \\leq T(c)")

#text("ii) ")#mi("3^{a-b} > 2^a, T(c) \\leq c")

#text("It can be shown fairly easily that (ii) can’t happen — I will post the proof tomorrow. I’ve got a bit to say about (i) as well, but that’s clearly the place where the really really hard problem is buried. I recognize things from Terry Tao’s initial post.")

#text("@MatjazG – sorry I haven’t read your posts in detail, will do so tomorrow and will respond.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38a7b93a3f71ae1b404b1c557c34b501f599de7676194419123f8994699833d2-e893fc125cb4a8c60e7bb96513f5336c32338bcad9a5d5ed1335b1af4c62b98a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelghaffar Slimane")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479180")[#strong[#text("Abdelghaffar Slimane")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2017")])]

#text("Hi all, I think I proved the Collatz’s conjecture for positive integers (cycle … 4, 2, 1) and for negative integers (cycle …-4, -2, -1). I submitted recently two papers to the AMS.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38a7b93a3f71ae1b404b1c557c34b501f599de7676194419123f8994699833d2-e893fc125cb4a8c60e7bb96513f5336c32338bcad9a5d5ed1335b1af4c62b98a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelghaffar Slimane")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479336")[#strong[#text("Abdelghaffar Slimane")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2017")])]

#text("I strongly denounce the laxity of some mathematical journals. What is more frustrating than after finding the demonstration of a conjecture spelled out for more than 80 years which is Collatz’s conjecture and to see his manuscript being refused without plausible reason. May be my name !!!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matjaž Gomilšek")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479345")[#strong[#text("Matjaž Gomilšek")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("Have you published anything before? Have you considered posting it on arXiv first (like Perelman)? What was the “unplausible” reason given to you by the AMS? It’s kind of hard to judge without answers to those questions …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38a7b93a3f71ae1b404b1c557c34b501f599de7676194419123f8994699833d2-e893fc125cb4a8c60e7bb96513f5336c32338bcad9a5d5ed1335b1af4c62b98a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelghaffar Slimane")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479351")[#strong[#text("Abdelghaffar Slimane")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("Here is their reply :")#linebreak()#text(" Dear Dr. Slimane,")#linebreak()#text(" This message concerns the manuscript")

#text("An elementary proof of the Collatz’s conjecture")#linebreak()#text(" by Abdelghaffar Slimane")

#text("Thank you for your submission to the Bulletin of the JJJ.")#linebreak()#text(" However your article is not suitable for publication in")#linebreak()#text(" this journal. JJJJ publishes only a very small number of")#linebreak()#text(" articles and we look for articles that appeal to a wide")#linebreak()#text(" audience. You may wish to submit your article to a more")#linebreak()#text(" specialised journal.")

#text("Best wishes,")#linebreak()#text(" …….. end of the message")

#text("So, at their point of view , solving an old problem (80 years old) is not an important thing !!!!!!")

#text("Please, what I want is just someone who endorse me on ARXIV for the submission of this proof. Please, consider my message as asking for endorsement.You can post your proposition on my email-adress : ")#link("mailto:aslimane@gmail.com")[#text("aslimane@gmail.com")]

#text("Thank you")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbd810e60b282bfb2775bd592c1180627ec342ab4fc7bca02052cf8331a94576-93235870fc8d3ed4c41b02b8454d5d2237e65cc1615ee5aa9a27cc4b14561d14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Czerno")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479348")[#strong[#text("Czerno")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("@Abdelghaffar Slimane : Hey! Please review or explain your above claim, Surely you’re aware Collatz has 3 well-known (trivial?) cycles in the negatives, not just one, Also “…-4, -2, -1” is not a collatz sequence. Your typo, I presume.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38a7b93a3f71ae1b404b1c557c34b501f599de7676194419123f8994699833d2-e893fc125cb4a8c60e7bb96513f5336c32338bcad9a5d5ed1335b1af4c62b98a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelghaffar Slimane")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479352")[#strong[#text("Abdelghaffar Slimane")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("I proved that all the positive integers finish their Collatz’s sequence by 4, 2, 1, and all the negative integers finish their Collatz’s sequence by -4, -2, -2. Those are the unique cycles for the Collatz’s sequence por negative and positive integers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38a7b93a3f71ae1b404b1c557c34b501f599de7676194419123f8994699833d2-e893fc125cb4a8c60e7bb96513f5336c32338bcad9a5d5ed1335b1af4c62b98a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelghaffar Slimane")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479353")[#strong[#text("Abdelghaffar Slimane")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("sorry for the eror in typing : and all the negative integers finish their Collatz’s sequence by -4, -2, -1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38a7b93a3f71ae1b404b1c557c34b501f599de7676194419123f8994699833d2-e893fc125cb4a8c60e7bb96513f5336c32338bcad9a5d5ed1335b1af4c62b98a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelghaffar Slimane")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479354")[#strong[#text("Abdelghaffar Slimane")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("May be my proof for the negative integers is wrong, but for the positive, I think is correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38a7b93a3f71ae1b404b1c557c34b501f599de7676194419123f8994699833d2-e893fc125cb4a8c60e7bb96513f5336c32338bcad9a5d5ed1335b1af4c62b98a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelghaffar Slimane")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479358")[#strong[#text("Abdelghaffar Slimane")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("@Czerno :")#linebreak()#text(" Sorry, my proof seems correct. I am talking about a modified (conjugate) form of Collatz’s sequence for negative integers of the form :")

#text("Theorem:")#linebreak()#text(" Let V ∶ -N* → -N* be the modified Collatz sequence on negative integers defined by:")

#text("V(n)= n/2 if n is even")#linebreak()#text(" V(n)= (3n-1)/2 if n is odd,")

#text("Then")#linebreak()#text(" ∀ n∈-N* ,∃ d∈N∶ V^d (n)=-1")

#text("Notice 3n-1 for negative integers instead of 3n+1 for positive integers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbd810e60b282bfb2775bd592c1180627ec342ab4fc7bca02052cf8331a94576-93235870fc8d3ed4c41b02b8454d5d2237e65cc1615ee5aa9a27cc4b14561d14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Czerno")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479365")[#strong[#text("Czerno")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("Ah, alright then Abdelghaffar – but you do realize that your “modified” Collatz process in the negative integers just mirrors the postive, i.e. it essentially adds nothing new : you’re essentially considering the positive case twice…")

#text("The interesting extension is : either consider the original Collatz (3 n +1) formula extended to negative integers, or; equivalently, study the alternate (3 n -1) variant on the positives.")

#text("Anyways, your claim to a proof for the “classical” Collatz problem on the positives would be a remarkable feat, provided such proof holds scrutiny, of course…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38a7b93a3f71ae1b404b1c557c34b501f599de7676194419123f8994699833d2-e893fc125cb4a8c60e7bb96513f5336c32338bcad9a5d5ed1335b1af4c62b98a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelghaffar Slimane")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479366")[#strong[#text("Abdelghaffar Slimane")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("Thanks for your reply Czerno.I agree with you that it mirrors the real Collatz sequence of positive integers. All I want now is someone to endorse me to submit my manuscript on ARXIV and then you will see the proof.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27433cc2e674e2317c407a05a8a09db793167baf1985d905d1b0a649e5596c9c-d056e2a611bbc7fe02e9739c7b414f9fb444f5847c797316ed31e8129bb9716e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CHENG GAO")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479779")[#strong[#text("CHENG GAO")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2017")])]

#text("I ever thought that we could try to study the question from the opposite direction, that is, starting from 1, then exploring the random structure of the “tree”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479869")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2017")])]

#text("It’s not beyond the realm of possibility that simple conjectures have elementary proofs. It seems to me that half of the Collatz – the question of cyclicality – could be dismissed with the following:")

#text("Consider the values of even set {a} and even set {d} where the sets represent the ascending and descending numbers, respectively. They are disjoint sets of elements a (every 3x+1) and elements d (every a divided by 2∗2…).")

#text("If 3x+1 is true for every a=4+(6∗k)")

#text("(4, 10, 16, 22, 28, 34…)")

#text("and")

#text("If a/(2∗2…) is true for every d=2+(6∗k)")

#text("(2, 8, 14, 20, 26, 32…)")

#text("Then, a≠d for ∞")

#text("(A Collatz and mn+x calculator/grapher: ")#link("http://questafi.net/numbers/CollatzCalcNGraph-1.xlsm")[#text("http://questafi.net/numbers/CollatzCalcNGraph-1.xlsm")]#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-479906")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2017")])]

#text("The distribution of the sequence of the Collatz function is similar to random variables, if this is true, then this problem lies in the theory of symmetric functions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-507040")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2018")])]

#text("I like your idea, from my basic maths. From my simple view, the symmetry, if it is possible, could be the fact that n=4=2+2=2^2=3+1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480106")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2017")])]

#text("I would like to say that the structure of the Collatz sequence have already been found. All odd numbers finally converge the smallest numbers of just the 6-type parent nodes. Then they reach 1. There is no repeating cycles exclude 1 and It is only 1 which can be a root node.")#linebreak()#text(" I am a real amateur, non-English speaker woman who is hard to conversation in English. but I think I understand well for the “structure” of the sequence than other people, sorry. And how all N; especially such numbers odd<f(odd) finally decrease and reach 1.")#linebreak()#text(" However It may be defficult to describe the total stopping time k for all N.")#linebreak()#text(" Collatz sequence' structure seems to have some interesting properties which relates other mathematical areas also computer science. Because this sequence can be represented as a rather simple data structure.")#linebreak()#text(" 2017 is the 80th since L. Collatz have found this fascinate sequence. I hope the problem proved in this year.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480112")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2017")])]

#text("FYI:")#linebreak()#text(" ")#link("https://www.quora.com/Is-the-Collatz-Conjecture-solvable/answer/David-Cole-146")[#text("https://www.quora.com/Is-the-Collatz-Conjecture-solvable/answer/David-Cole-146")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480123")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2017")])]

#text("ok. thank you very much.")#linebreak()#text(" I don’t use probability by the way. just thought the numbers as some subsets then permute them to be a simple structure.")

#text("I said there are only six(2*3)-typed parent nodes. and finally all odds converge the smallest numbers of each these typed parents.")#linebreak()#text(" but more interesting thing is that there are two-kinds of exponent tuples which formed three-forms by the circular shift oparation, respectively.")

#text("I only understand the structure of the sequence and how all N reach 1 without using probability. but I can’t give a rigid proof for it. I am very elementary amateur.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c950a0c0c93c77bb282d73255cbf1f06d8a59ce807a467102d2317647ac2b58d-9cec043ca4cc2bb1adbfcae08168b16e21b3c0bf841b96a6d80b317515bfa8ce.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Rai")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480350")[#strong[#text("Abhishek Rai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("Does being true automatically imply that the stopping time is a total (non PR) function?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480376")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("Question for anyone: If there existed another function that generates a proper superset of the odd numbers in every Collatz sequence (in the same order), would proving that function always had a stopping time also prove the Collatz conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a41fa9ba28d4ba8f94539abcc212b7dba70bc7f932b944b83e3ff27beedcac27-aa2c29b35a811d8092b3df96feb90a5fe1aac4a9e6237e0ff51049c74f886934.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mikllos kontra")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480398")[#strong[#text("mikllos kontra")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2017")])]

#text("I ve found a graph that proves that collatz conjecture is true and also that mathematics series will never or at least for the moment solve the problem, math are just not yet ready to solve the problem. in the graph that i found after 3 years of work shows that in all the paths of the graph there is a part that shows some randomness behavior, except for the case of 4k +1 sorry for the language I m from Argentina. There is a main branch 4k +1 from which all the others branch starts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480405")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2017")])]

#text("When I see 4k+1, my eyes light up. I wonder if we’re talking about the same thing: You can divide Collatz sequences into sets of any size with equal stopping times. The same first odd term recurs for $n*4+1$, $n*4^2+4+1$, $n*4^3+4^2+4+1$, $n*4^4+4^3+4^2+4+1$, and so on. This means that the stopping times of such sequences may be deduced based on one member of the set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a206486953aa84d7bfc3dabc824894fb43d36074ccb40945ea33100ba1ed533d-80cf840618106f98108763ea202a0911db3947994f845dbb1510abf59c20daa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ing. Kontra Miklos")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480461")[#strong[#text("Ing. Kontra Miklos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2017")])]

#text("Well as i said before there is a main branch 4k +1 from which each nodes starts a new branch going to infinity, i just can add for the moment that from each nodes it enters variable nodes which could be seen as random but well defines ( only 2 kinds of nodes) then each branch after this that appears to be randomness!! goes to infinity but first passing by multiple of 6 and goes to infinity passing by only even numbers to infinity, i can t tell much more because it s a final thesis that i m presenting in the University of Argentina in computer science and i already have presented a paper which shows the result in a legal place called in Argentina Propiedad Intelectual.")#linebreak()#text(" As soon as i present my thesis i will upload the paper, it s really wonderfull to see how the graph with infinities branches deriving from a principal 4k +1 branch, each of these goes to infinity passing trough a couple of nodes then reaches a multiple of 6 then to infinity (there is another point out there that the graph have infinite branches and each of them goes to infinity, but that is another question to be solved by mathematician infinite infinities, therer are some works out there but that is not the point for the moment)")#linebreak()#text(" I spend almost 3 years of work, and i would like to add that the Hungarian Mathematician Paul Erdos and Craig are right, there is no way to solve the problem using at least in my opinin using series, this small randomness which is not really randomness makes imposible to use series, in each case or each branch the numbers of nodes that shows this behavior before going to infinity passing before by a multiple of 6 are variables.")#linebreak()#text(" Sorry for my poor english.")#linebreak()#text(" The only thing that I would like to add is efectively the conjecture is RIGHT!!!!!!")#linebreak()#text(" By the way I woul like to add one more thing, the only work that i saw out there that is near but missing a couple of things is the work done by Conrow.")#linebreak()#text(" I wish you good luck in your journey Michael, may be you l be able to find another way to solve the problem.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480513")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2017")])]

#text("“two kinds of nodes” which you explain is odd inverse mapping, I think?")#linebreak()#text(" If so, it can be classified even more separately and exactly. or if you use matrices, then the nodes would be just two.")#linebreak()#text(" Did the tree (it’s not actually called a tree, maybe) become symmetry? many people do this inverse approrch, but they don’t find the symmetrical tree.")

#text("In my approach, there is any randomness at all. All odd have their own (as it were) seat number and there is actually a seating chart..")#linebreak()#text(" Solving the Collatz problem needs no new mathematical tools nor ideas at least in my way. but it’s quite for the computer science because of its’ structure.")

#text("Were you able to define the stopping time?")#linebreak()#text(" Personally I think it’s not able to define well even if the problem will be solved. or just due to my skilllessness.")#linebreak()#text(" I don’t count the depths of nodes also. because solving the problem is just the permutation of odd numbers to every numbers conclude 1. it’s just in my opinion.")

#text("Only a difficult thing of the problem was such numbers; x<f(x). but they can map to a part of the members of their same subsets. those numbers are x≻f(x).")

#text("I can not write a paper of this. why, because I don't know the proper way of writing, mathematics also english. so good luck to all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a206486953aa84d7bfc3dabc824894fb43d36074ccb40945ea33100ba1ed533d-80cf840618106f98108763ea202a0911db3947994f845dbb1510abf59c20daa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ing. Kontra Miklos")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480521")[#strong[#text("Ing. Kontra Miklos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("Hi Yuko, First of all I thought it was a tree structure, but anlysing my papers on grapph structure, acording to strict definition it s no a tree but a graph structure composed by nodes, from each of these nodes borns two nodes where 2 new branches borns that i call in my work upward branch which always starts from these node and goes to infinity using 4k +1, so as i told you before ther is a main branch 4k + 1, then from each of these nodes starts 2 others nodes *branches* the funny thing is that again there will be as i called an upper branch which again keeps the pattern 4k +1 and goes to infinity and a branch that goes downward passing through these nodes that seems to be random but i showed that the re not random ang goes to infinty after passing this randomness path to some multiple numbers and then comes up all even (multiply by 2 this is cCollatz rule for even and reaches infinity), there is no way to calculate the stopping time because of this randomnes, Another thing tha i can tell you and is on my paper that there the nodes should not be taken as a number but a group of numbers, this is the trick of the thing to get the structure of the graph, again the graph is like a binary tree but there is one caractherisitc that do not belong strictly to the definition of tree and tah ts the reason why it s a graph.")

#text("i tried to look out for som symmetry but i did not find any and i left this part of my thesis as future branch of investigation, I can t follow investigating this work because I m working now on my PHD in computer science where i m demostrating THAT RSA criptography is not secure I showing a way to find P an Q without looking for prime number.")

#text("I wish you good luck in your work, i wish that you can find another way that Collatz conjecture is true, believe me it is but it woul be nice if some one out ther could find another way……good luck again.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1168be2c8d8669b3544da7fe93f8e4ef4048eb2a464bf4b6c7d69eae4a7b6b21-25ad86cbdc2b8df30c593ff5139429374ed711a9c4d0edfb1b8ae38f19897be0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chris3991m")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480407")[#strong[#text("chris3991m")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2017")])]

#text("Proof of the weak Collatz conjecture (please read this):")

#text("We start with (2^(ak+1) – 3^k)*n as the value of the left hand after the first cycle. Note that 2^(ak+1) > 3^k.")

#text("We perform an infinite amount of cycles. This results in (2^inf*(ak+1) – 3^(inf*k)*n. Because 2^(ak+1) > 3^k, (2^inf*(ak+1) – 3^(inf*k)*n ~= (2^inf*(ak+1))*n")

#text("Therefore, – 3^(inf*k)*n ~= 0. Because – 3^(inf*k) is fixed, we must have a minimum value of n to be 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1168be2c8d8669b3544da7fe93f8e4ef4048eb2a464bf4b6c7d69eae4a7b6b21-25ad86cbdc2b8df30c593ff5139429374ed711a9c4d0edfb1b8ae38f19897be0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chris3991m")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480408")[#strong[#text("chris3991m")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2017")])]

#text("Corrections:")

#text("This results in (2^inf*(ak+1) – 3^(inf*k))*n. Because 2^(ak+1) > 3^k, (2^inf*(ak+1) – 3^(inf*k))*n ~= (2^inf*(ak+1))*n")

#text("Therefore, – 3^(inf*k)*n ~= 0. Because – 3^(inf*k) is fixed, we must have a minimum value of n to be 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480409")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2017")])]

#text("But what do you mean by the “weak” version of the conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480410")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2017")])]

#text("Nevermind my question. I see it’s defined above ;)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a206486953aa84d7bfc3dabc824894fb43d36074ccb40945ea33100ba1ed533d-80cf840618106f98108763ea202a0911db3947994f845dbb1510abf59c20daa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ing. Kontra Miklos")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480523")[#strong[#text("Ing. Kontra Miklos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("Yuko one more thing to be said about your stopping time on Collatz, as i told you there is a main branch of type 4k + 1 passing by 1,5,9…… this is the only branch on which you can calculate the stopping time, but remember that i told you that on each nodes starts 2 new branches one will be again of type 4k + 1 that goes upward to infinity but in these cases there is no way to find a stopping time because all these branches that lies on the case 4k + 1 and do not belong to the main branch must pass through a randomness path.")

#text("So Concluding, there is a main branch of type 4k +1 starting at 1 and there are infinite branches of type 4k + 1 starting from each other nodes but must pass before reaching the main branch by a path wih have some randomnes nodes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480718")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2017")])]

#text("Maybe our approaches seem to be a little different.")#linebreak()#text(" But there is something similar perspectives that we have.")

#text("Actually what I saw the structure of the Collatz sequence is also not a tree.")#linebreak()#text(" But there is the hierarchical structure like the binary trees just as you said.")#linebreak()#text(" Althogh the charactaristics of the structure is not only this one.")

#text("If you have some knowledge of the database structure, it might help to find the symmetry in that binary-like branches, I think.")

#text("thank you for telling your study and advice ;)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a206486953aa84d7bfc3dabc824894fb43d36074ccb40945ea33100ba1ed533d-80cf840618106f98108763ea202a0911db3947994f845dbb1510abf59c20daa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miklos Kontra")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480762")[#strong[#text("Miklos Kontra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2017")])]

#text("Hi Yuko, yes i know well database structure i m old enough to tell you tha t i ve a solid experience on database structure i ve start working on btrieve from Novel 3.12 where the structure were of b and b+ structure, if you think about this you ve got your way to Collatz solution where you will see that is of type of a binary structure from each node borns 2 nodes that i call in my work leaves lije in database structure that s why my thesis is in computer science and not pure math thesis, the solution to the problem is very easy and took me more than 3 years i ve start like every one using series binary numbers etc.. Nothing came out of this but if you think as a b tree structure and use logical math you ll get the answer, just be patient by the end of the year i will make my defense thesis at the university in Argentina and then upload the work, just hope that no one gets to the same result as i did, that s one of the reason why i writing in this chat to see if some one is on the same path, at the univerity they we re looking out there to see if some one had done my work before but it s seems that not, soon i will post all the results and you won t believe how easy it is and why you ll never be able to solve it using pure math, Anyway it would be wonderfull if someone out there could find another way to show that the conjecture is true, i can add one more thing and is that all the computers out there trying to prove or to find a case where it shows that s is not true will never find a case. Good luck Yuko")#linebreak()#text(" I would like to upload the work and ask the mathematician to find a way to show using math theory and finishing with this conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea6c007a4935588fc00c6336f740f3f2afaefa187a010e0da16e01497ecb56a4-64c4d259eea0fffa7a1d87b3c993303c7ac1b7a38a972f101a898e169197542d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuko.y")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-2/#comment-480812")[#strong[#text("yuko.y")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2017")])]

#text("B tree. My mind image of the 3x+1 structure is not actually a B tree, but I see there is more similarities in our approaches.")

#text("I’ve done the generalisation of the convergence of the sets and the representration of ID for all number. So there is no randomness.")#linebreak()#text(" *but it’s very elementary way, so mathematicians will laugh at it when they look at it.")#linebreak()#text(" Those are not enough for solving the conjecture, I know. But the result of the structure is simple and interesting.")

#text("Our approaches seem to be different, but very similar I think.")#linebreak()#text(" so good luck, looking forward to read your paper in near future :)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70362")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("I don’t have a reference, but I was told once (by Conway I think) that if you generalize the recursion to “fix a k, and for each residue class i mod k, apply an affine-linear map x |-> (x-i)/k”, then one can prove that most of those limiting-cycle problems are undecidable in ZFC. That doesn’t prove that Collatz is one of the undecidable ones, but why shouldn’t it be.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70365")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("Yes, this is a result of Conway from 1972 (link ")#link("http://www.ams.org/mathscinet-getitem?mr=392904")[#text("here")]#text("). I guess I should have mentioned it in the main post. Note though that the examples of undecidable recursions of Conway’s type are (as far as I am aware) examples that tend to have an output larger than the input, whereas with the original Collatz recursion it is the other way around (after one normalises ")#mi("f_0")#text(" to ")#mi("f_1")#text("). This opens up a lot of time for the recursion to do some interesting computation (and in particular to encode a problem known to be undecidable, e.g. solving an arbitrary Diophantine equation). In contrast, the original Collatz recursion, when starting with a large integer n, should only last about ")#mi("O( \\log n )")#text(" iterations before collapsing to the 1-2-4 cycle, and it doesn’t seem like there is enough time to do any undecidably complicated mathematics in the interim. Of course, this is not a rigorous proof of anything…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70378")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("Typos —")

#text("Conjecture 3 should read")#linebreak()#text(" “There do not exist $k \\ge 1$ and integers … such that … ”")

#text("“non-trivial periodic orbit has length at least {105,000}”")#linebreak()#text(" prints space after the comma — maybe {$105,000$} ? (twice)")

#text("Para. previous to equn. (6) — {q} undefined — see equn. (7).")

#text("For “counterexmaples” read “counterexamples”")#linebreak()#text(" (plenty of the former around for CAS users …)")

#text("Para. after equn. (8) —")#linebreak()#text(" For “parallelopiped” read “parallelepiped”")#linebreak()#text(" (and several times later — I agree it’s strange!).")

#text("Something wrong in next paragraph — maybe")#linebreak()#text(" “count number of times {S} contains {0}” ??")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70406")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("Conjecture 3: it would make more sense to me if you re-indexed to a_0,…,a_k and then set n>1. As it is stated now, n = 1 is actually the trivial cycle with k=1, a_1 = 0 and a_2 =2 (note the empty sum), because 1 divides 1 right? See equation (7.3) in Crandall’s paper.")

#link("http://www.ams.org/journals/mcom/1978-32-144/S0025-5718-1978-0480321-3/S0025-5718-1978-0480321-3.pdf")[#text("Click to access S0025-5718-1978-0480321-3.pdf")]

#emph[#text("[Oops, you’re right, n should be strictly greater than 1 rather than greater than or equal to 1. I’ll keep the a indexing currently because I don’t want to inadvertently create other typos while trying to re-index. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("More on Conjecture 3: when talking of periodic orbits, loops or cycles, it helps to state, for the sake of the lay reader, that the value a_{k+1} is the number of evens and the value k is the number of odds (not double counting n) in such a non-trivial cycle, should one exist.")

#text("If you really are interested in equation (8), I have a draft paper under consideration with a peer-reviewed journal which aims to get an explicit description of equation (8) when it is part of a representation of a value for which the conjecture holds,i.e., I got em all. Perhaps, it would give you something to exploit. I actually need help finishing the key proof, but I do have all of the pieces in place. Please ,let me know if you are interested via comment. There is some clumsy stuff in the draft, but it’s not bad.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70569")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("I see you made mention of my suggestion about what a_k+1 and k mean later on in the proof of Lemma 5, but it might be better to mention it sooner for boneheads like me.")

#text("To be clear, by “explicit desc. of equation (8)” I meant a partition of the a_k such that one knows what choices of a_k correspond with a value m (for which the conjecture holds), where m is congruent to 3(mod 4), 1(mod 8), 5(mod 8), and 13(mod 8). Here m = (2^{a_k+1} – n) / 3^k. Of course, I have not solved the conjecture. But the lightbulbs went off this morning in my head when thinking about the Erdos conjecture you mentioned. I had never heard of it. In layman terms, the last odd term in a non-trivial cycle would be a power of 2 times the starting value n. So now I’m wondering if my partitioning scheme would be of any help. I’ll poke around with it this weekend.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70571")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("I abused n, by my first use of n I meant the sum in equation (8). By the 2nd use, I meant the root of a non-trivial cycle, should one exist. Good grief…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05839e35d2d4b460097e9b0aa1f6d33193c546900fbafc3329cc926b5308c9a1-2ba6b7b46b909ed697e07813fbd12d8c0ce02fa832c660888faafd19e341a096.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcus Hutter")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70497")[#strong[#text("Marcus Hutter")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("Thought from an amateur:")

#text("One can break up the Collatz conjecture into")#linebreak()#text(" (i) The sequence f^1(n), f^2(n), f^3(n), … never diverges (i.e. always reaches a limit cycle)")#linebreak()#text(" (ii) 1,2,4 is the only limit-cycle of f (i.e. if the sequence does not diverge, then it ends in limit-cycle 1,2,4)")

#text("Your interesting Proposition 6 indicates that (ii) is hard to prove, but it does not indicate that (i) is hard.")

#text("As far as I remember, there are many Collatz-like functions f that satisfy (i)")#linebreak()#text(" but that have more than one limit cycle.")#linebreak()#text(" This makes (ii) for me less interesting, since it appears coincidental.")#linebreak()#text(" It would be nice to be able to also “show” “hardness” of (i) or prove (i).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5b808554ecca1027588ad7a63e0410519db248c1277a48857bdca241c1c1928-61aac7b24a73d8baac76fe81c844b7d3cc046c5473f947048267bf5af3eb2001.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Farah Herbal")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70500")[#strong[#text("Farah Herbal")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("its so difficult… how to start… :(")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ca9b21ed639971fe0dd8f127397a44d17587342eb081208f5908fdd6567e0-67b88326b3417e4cea1a4c861181ac9944d6b619a7c5e33a6a75bcd67c609bf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomer shalev")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70587")[#strong[#text("tomer shalev")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("Hello Terrence. a very nice webtalk. there was a time that this problem amused me when I was looking for a break from my current thesis.")#linebreak()#text(" It is worth mentioning the fundamental work of Terra on the subject regarding")#linebreak()#text(" the stopping time of a sequence, which if proved to be finite for all numbers, then simple induction can prove the whole conjecture.")#linebreak()#text(" Terras proved that almost all numbers have a finite stopping time.")#linebreak()#text(" Ivan Korec gave another tighter version of terras theorem.")#linebreak()#text(" If I’m not mistaken, Erdos was cited saying that this problem is beyond math’s")#linebreak()#text(" reach. I guess it is not that different from Goldbach’s and other out of reach and dangerous problems to explore when one is at a stage where productivity")#linebreak()#text(" is an important goal.")#linebreak()#text(" I regard this problem as a true math gem, I also was arguing with a friend about how should “real” mathematics look and sound like. I refereed him to")#linebreak()#text(" one of Erdos’ papers. my friend said that the paper looks like homework in")#linebreak()#text(" graduate Calculus. but then he didn’t stop saying that everything about Erdos’")#linebreak()#text(" observations are mind changing. Who knows, maybe Collatz’s conjecture has")#linebreak()#text(" a messy Erdos’s proof which is not as deep as much as it is cleverly constructed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bdc6fd040b49e30b6d01b0403cc5f0631cdc23999732c28aca2f98e6722dbea-bb0106bc9831ab76555e3bef6924f514c78e33f48760af13fb67409c6402d0cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry A. davis")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70722")[#strong[#text("Terry A. davis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("Maybe, you’d like the “magic pairs” problem. Let SumFact(n) be the sum of factors.")

#text("Find all n1,n2 in a range such that")

#text("SumFact(n1)-1-n1=n2")

#text("and")

#text("SumFact(n2)-1-n2=n1")

#link("http://www.losethos.com/code/MagicPairs.html")[#text("http://www.losethos.com/code/MagicPairs.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e97407343b60b836608eff5202ef35c525bfb19719ebefea678d1d8bfb35e40a-90a8fd29cc5a3644fb95691f80f172f9784c4972beb0bbaac0595db8e4b39f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan D")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70723")[#strong[#text("Jonathan D")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("Has anyone tried to prove this conjecture using an iterative proof?")

#text("For example: It would seem that you can show that (as initial conditions) by starting with 4 as a known “true” value, and then testing n=5, you can show manually that the conjecture is true for 5. Then repeating with true values for all the members in the set {1->5}, when you test n=6, you don’t need to show the conjecture reaches 4,2,1 you just have to show that somewhere in the sequence for 6 it reaches 5 or less. Then you can simply iterate test 7 with {1-6} as true, test 8 with {1-7} as true… onward.")

#text("Given some high value for n, for which we’ve already and checked all values less than n, [[you could start the proof at 1,000,000, and then for all values greater than 1,000,001]] – you have to prove that at some point in the sequence evolution the values hit a result less than n => you don’t need to prove it all the way back to 4,2,1.")

#text("But it gets even easier – every even value in this method is already proven true – the first step in the sequence for n rolls it below n-1, so even values for n are automatically true.")

#text("For the odd values, you have to look at the prime factors of 3n+1, and here we can could use a sieve method. All you need it some number in the sequence were the prime factors (removing all the 2 values) multiply to some number less than n. It was at this point I couldn’t really take it any farther, but could see that as n increases, there are more prime factors below it, and eventually, the sequence will hit some 2**j {factors} where factors are less than n.")

#text("Perhaps there is a way to prove that that for odd n above a certain size, the series will reach (must reach) a point less than n /before/ it reaches a cycle. I also don’t have the math to prove that.")

#text("-JD")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e97407343b60b836608eff5202ef35c525bfb19719ebefea678d1d8bfb35e40a-90a8fd29cc5a3644fb95691f80f172f9784c4972beb0bbaac0595db8e4b39f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan D")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70725")[#strong[#text("Jonathan D")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("this was how far I got looking at the inductive proof")#linebreak()#text(" ")#link("http://pastebin.ca/raw/2078636")[#text("http://pastebin.ca/raw/2078636")]#linebreak()#text(" just scrabbled together code")#linebreak()#text(" -JD")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cfdd51220e0e9e48ad39dacede4e89e8b5ac5733ab7a17e45dcbc615d18511c-45bb1870fc84d7fdc38729bf770d0f9393d2e317c149c30fa8ed1860c18b9748.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan D")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70734")[#strong[#text("Jonathan D")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("here is a much cleaner copy of the code, with references and explanation")#linebreak()#text(" ")#link("http://pastebin.ca/raw/2078648")[#text("http://pastebin.ca/raw/2078648")]

#text("there are several really interesting patterns that emerge")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7f1896f02c147da953032ea955c128c7069bb74282880b47fc6ee6a4e51c4be-da7b3ea8906beb63878591a4413909b94e6228c4e6fd79db894506e002716a34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon W")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-70761")[#strong[#text("Jon W")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("I notice you spend more time on the weaker version than the actual conjecture. Is that just because you make better headway there?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-83456")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2011")])]

#text("I suggest a 10% rule is in order here. All peer-reviewed journals should immediately reject any purported proof of the 3x 1 Problem not properly referencing at least 10% of the literature, regardless of the authorship.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-83790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2011")])]

#text("You’ll have better luck with the Diophantine properties of the “proxies” of local minima (those having the smallest absolute value) in 3n+c cycles than Bohm and Sontacchi’s formula; these are the ideals of the 3n+c problem. An “attachment point” in a cycle is an even integer i such that 3 divides i-c (and (i-c)/3 is not already in the cycle). An attachment point i is “primary” if 4i is not an attachment point. Extending the 3n+c sequence backwards from primary attachment points (taking the path (i-c)/3 and [not 2i] at nodes) gives an odd integer divisible by 3, the proxy of the local minimum immediately after the previous primary attachment point. For cycles with only one attachment point, the previous primary attachment point is the primary attachment point. For example, the proxy of -17 in the c=1 cycle of {-34,-17,-50,-25,-74,-37,-110,-55,-164,-82,-41,-122,-61,-182,-91,-272,-136,-68} is -21 (the primary attachment point is -68). These extended sequences have many interesting properties.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-84553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2011")])]

#text("Erdos called such diophantine equations unconventional, hmm. In 1978 money cow VanHalen hit the music scene. Critics called the finger tapping solo style guitar playing unconventional. Now the adjective is toy model. Looks like the snobs are still in the lead in mathematics! Solving such exponential equations includes an adhoc grab bag of tricks, try surveying those before wimping out. No wonder amateurs love this problem, they want to find the cool trick. The pros avoid such lowly styles, and the ones who don’t say words like trajectory rather than sequence to make their work sound cool.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-84973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("Opinion 111 of Doron Zeilberger says it all, please see there the following quote in context,")

#text("“”Almost” proving something is often a piece of cake (for example that almost all x wind up at 1 after iterating the 3x+1 map).”")

#text("I like Zeilberger, he tells it like it is. Most of the work on this 3x+1 Problem is absolutely worthless but fashionable at the time of creation, so it sees publication in prestigious journals. What a joke.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-85184")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("Actually, that precise statement (almost all x wind up at 1 after iterating the 3x+1 map) remains open; the best result currently known in this direction, as noted in the post, is that ")#mi("\\gg N^{0.84}")#text(" of the numbers less than N tend to 1, a result of ")#link("http://www.ams.org/mathscinet-getitem?mr=1980260")[#text("Krasikov and Lagarias")]#text(". Getting a density 1 set of numbers tending to zero would, in my opinion, be quite a significant achievement, even if it still falls well short of the full conjecture. (Perhaps Zeilberger was thinking of the weaker result that almost all x end up at some point at an integer less than x, which is indeed an easy result by modern ergodic theory methods, and was already noted in the first few papers on this problem, but which is nowhere near strong enough to push almost all numbers to 1.)")

#text("Ultimately, the precise problems solved are not what is the most important here, but what types of new technology and insights are developed, and a better sense of which obstructions are more substantial than others, and what types of tools are suited for each such obstruction. For instance, the accidental discovery of some sporadic cycle of length in the millions would, technically, resolve the Collatz conjecture, but for rather “uninteresting” reasons, for (unless there was some insight provided by the way the cycle was found) we have not learned anything broader about how to control an exponentially unstable recursion for an extended period of time, how to control the interaction between powers of small exponents such as 2 and 3, what fields of mathematics might be connected by posing these sorts of questions, etc. I recommend Thurston’s “")#link("http://arxiv.org/abs/math.HO/9404236")[#text("On proof and progress in mathematics")]#text("” for a great discussion as to why theorems (or “theorem-credits”, as he puts them) are the way we keep “score” in mathematics, but why ")#emph[#text("insights")]#text(" are the real objective.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-141145")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2012")])]

#emph[#text("[Unsubstantiated anonymous allegation deleted. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-85215")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("Now you are talking semantics, “almost all” is a fuzzy statement and infinity is infinity, loosly speaking :-), so your assignment of significant achievement status is rather relative. Your point is well taken though.")

#text("I think a less objectionable conclusion to your article would be that the solution to the 3x+1 Problem ought to offer a means to solve an entire class of exponential Diophantine equations. Saying some equation is a “Toy model” is a derogatory statement, and a sequence is a sequence, not a trajectory – see Knuth’s comments on putting useless jargon into the literature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-85220")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("There are indeed ")#link("http://en.wikipedia.org/wiki/Almost_all")[#text("a number of ways to formalise the concept of “almost all”")]#text(" in mathematics, but in number theory it is almost always (ha!) understood in the sense of density.")

#text("The concept of a ")#link("http://en.wikipedia.org/wiki/Toy_model")[#text("toy model")]#text(" is also standard usage in both mathematics and physics, and is not intended as a derogatory term. (For instance, I have worked for many years on the Korteweg-de Vries equation, which is ")#link("http://www.google.com/search?gcx=w&ix=c1&sourceid=chrome&ie=UTF-8&q=korteweg+de+vries+toy+model")[#text("often called")]#text(" a toy model for more sophisticated (but less tractable to analyse) dispersive and water wave PDE.) See also the post ")#link("http://mathoverflow.net/questions/1354/what-are-examples-of-good-toy-models-in-mathematics")[#text("http://mathoverflow.net/questions/1354/what-are-examples-of-good-toy-models-in-mathematics")]

#text("I did not use the term “trajectory” in my post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-85228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("Score card:")#linebreak()#text(" 1. On “almost all” – you win.")#linebreak()#text(" 2. On “toy model” – just because the apparent norm is to do so, doesn’t make it OK. Thoughts?")#linebreak()#text(" 3. On “tracjectory” – I know, and you seem to agree … mute point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-85233")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("There are certainly circumstances in which it would be desirable to refer to a sequence as a trajectory, if one wished to emphasise the dynamical systems features of that sequence, and to emphasise the interpretation of the index parameter as a time variable. In this particular post, though, the dynamical systems aspects of Collatz sequences, while present, were not the primary feature I wished to emphasise, and so I did not use the terminology of trajectories (or orbits, although the latter term often suggests time-reversibility, which is not a feature of the Collatz iteration). See also ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/use-good-notation/")[#text("my post on selection of good notation")]#text(" for more discussion of when a given mathematical notation is appropriate for a given situation, and when it is not.")

#text("Regarding any normative connotations that one may impute to terms such as “toy model”, I think you may be reading too much into this term, which is used in a specialised technical sense rather than as a colloquial one. A “")#link("http://en.wikipedia.org/wiki/Conservative_vector_field")[#text("conservative vector field")]#text("“, for instance, is not a vector field with right-wing tendencies, “")#link("http://en.wikipedia.org/wiki/Natural_transformation")[#text("natural transformations")]#text("” are no more eco-friendly than any other type of transformation, a “")#link("http://en.wikipedia.org/wiki/Simple_group")[#text("simple group")]#text("” is no less worthy of respect than any other group (such as, say, a ")#link("http://en.wikipedia.org/wiki/Perfect_group")[#text("perfect group")]#text("), and a “toy model” is no more childish than any other type of model; it is simply a model that is worth toying with, nothing more.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-85263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2011")])]

#text("I think we agree on (3), as I have seen the term used far too loosly: as if pushing the latest fashionable approach in a subtle way. I cannot cave on (2). It is a non-value add description, and can be offensive to some (the minority) and abused by those wanting to push the importance of their focus above those of others. It’s really no different than kids teasing each other with nicknames. So if by specialised you mean insidious, then I might concede.")

#text("Suppose somebody solves that conjecture of Erdos 10 years from now and submits a paper (using some trick offering no new insights) to a prestigious journal. Then a rejection letter arrives to the author saying something broiler plate like: Because competition is fierce, and though your proof of this “toy model” is valid, we must reject your paper as it offers no new insights. The same journal then goes on to publish a proof of positive density 1 (at a later time) offering no new insights either. I’m just saying…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-87250")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("There are some empirical results on a new way to tackle Simons and de Weger’s Lemma 14 at ")#link("http://home.graysoncable.com/dkcox/")[#text("http://home.graysoncable.com/dkcox/")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a206486953aa84d7bfc3dabc824894fb43d36074ccb40945ea33100ba1ed533d-80cf840618106f98108763ea202a0911db3947994f845dbb1510abf59c20daa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ing. Kontra Miklos")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-479402")[#strong[#text("Ing. Kontra Miklos")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2017")])]

#text("Hi Terence, I would like to know if there is anyway to get in touch with you to show the graph and the teory behind the graph tahat shows that for all positive number the conjecture is true, thank s in advance for your time.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of human mathematics")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-86479")[#strong[#text("human mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("I’m sure someone has computed a large number of $(k,n)$ pairs. Do you know roughly for how many $n$ this has been done?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of human mathematics")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-86483")[#strong[#text("human mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("This blog post ")#link("http://jpcameron.com/blog/?p=47")[#text("http://jpcameron.com/blog/?p=47")]#text(" has some interesting pictures of the patterns in k for the first billion n. Visually appealing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of human mathematics")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-86488")[#strong[#text("human mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("Your method of assuming that “half the time” n is even and half the time odd got me thinking about “autocorrelation” of Collatz sequences. There are certain numbers, like 32, which if f_0 reaches them, will instantiate a long path “straight” down to 1. Of course these numbers are the powers of 2. So what if you think about the n as products of primes? Thinking that way you can “jump ahead” whenever 2^x is included in the number’s prime decomposition 2^x 3^y 5^z 7^w …. You can “jump ahead” in the sequence to just 3^y 5^z 7^w. Considered this way the conjecture is saying that (3n+1, scrape 2^powers, 3n+1, scrape 2^powers, 3n+1, … ) will eventually find a number whose prime decomposition is only 2’s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of human mathematics")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-86489")[#strong[#text("human mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("Sorry, maybe that is just a longer way of saying what you said about 2-adic’s and ergodicity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aks prime test amateur bojan vasiljevic")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-87736")[#strong[#text("aks prime test amateur bojan vasiljevic")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2011")])]

#text("My view of The Collatz conjecture is next:")

#text("First key statement:")

#text("Numbers that are result of odd numbers and factor 3 are of digit value 3 or 6 or 9.")

#text("So plus 1 gives us numbers of digit value 1 or 4 or 7 (interestlingly only even numbers)")

#text("Second key:")

#text("Doubling seguence numbers (1,2,4,8,16,32,64,128,256,512,…) are of digit value 1 or 2 or 4 or 8 or 7 or 5; and are the only numbers that will get us to number 1 when dividing with 2.")

#text("So conclusion is that function for odd numbers tries to push number in doubling sequence area because there is the only posible way to find such number that leads to ending result 1. Also it ensures more even numbers than odd numbers in whole process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur bojan vasiljevic")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-88694")[#strong[#text("amateur bojan vasiljevic")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2011")])]

#text("I was playing on the next Collatz conjecture applet")

#link("http://www.staff.science.uu.nl/~beuke106/collatz/bigCollatz.html")[#text("http://www.staff.science.uu.nl/~beuke106/collatz/bigCollatz.html")]

#text("And I have realized that everything that i siad above is valid also for odd number function 3*n – 1")

#text("But 3*n -1 doesnt end on number 1 at the end always!(use applet).")

#text("So i started to play with both functions 3*n -1 and 3*n +1 for odd numbers with the help of the next picture.")

#link("http://t1.gstatic.com/images?q=tbn:ANd9GcQ-E2yQmH3qf2aXYK3lKsCQEqB3p6wYJmEF6QKFprNxSSOD0Wvc")[#text("http://t1.gstatic.com/images?q=tbn:ANd9GcQ-E2yQmH3qf2aXYK3lKsCQEqB3p6wYJmEF6QKFprNxSSOD0Wvc")]

#text("treat this numbers around the circle as digit values( for all natural numbers)")

#text("And I have acknowleged that with the 3*n +1 you always end up on 1 for every odd number or even one eventually.")

#text("With 3*n – 1 is is not such a case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-89423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2011")])]

#text("In the first paragraph, you can remove the word positive as the naturals are positive by definition.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b179d8ee6f4d5b4dff9f9448b1481c17fd2f4443d39ee0df63700d9f0bfe8985-e6fbcec0789c4f38f4e0a3ba97846a44326ea462a278e177850eebbae1cc100f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wade A. Mosely")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-479239")[#strong[#text("Wade A. Mosely")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2017")])]

#text("The need for the word “positive” in this case depends upon the reader. Some include zero in the set of Natural Numbers and some do not. For set theorists, the inclusion of zero seems to be the convention. See ")#link("https://plato.stanford.edu/entries/set-theory/")[#text("https://plato.stanford.edu/entries/set-theory/")]

#text("Some even include negative integers as members of the set of Natural Numbers. (Egad!)")

#text("Anyway, the inclusion of the single word “positive” to ensure a lack of ambiguity seems harmless and actually quite constructive, in my opinion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-89448")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2011")])]

#text("Operators act instantaneously, such as the limit operator. Thus we think of the limit at infinity, even though the word approaches appears in the definition. To this end saying things like WHEN n is odd or Passes through is silly. Just say if or for, and for the later: has.")

#text("The problem with using any is that the reader or student can often find multiple meanings for its usage. So in the statement of conjecture 1 I would replace any given with every. What is orbit again?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur bojan vasiljevic")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-89865")[#strong[#text("amateur bojan vasiljevic")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2011")])]

#text("Let me also say that that almost all primes (exception is prime number 3) is in range of digit value 1 or 2 or 4 or 8 or 7 or 5.")

#text("So Collatz conjecture algorithm pushes odd numbers connected to primes by some factor inside doubling sequence area so that they become divisible by 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur bojan vasiljevic")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-89880")[#strong[#text("amateur bojan vasiljevic")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2011")])]

#text("with the help of 3*n+1 function")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-91965")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2011")])]

#text("Reducing the set of integers to density 0 for which one must check is the conjecture is true is conceptually the same as showing the conjecture holds for almost all of them. So the result of Korec and Znam is state of the art, in my opinion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-92502")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2011")])]

#text("Actually, there is a major formal (and conceptual) difference between a reduction to a small set of cases, and the verification of all but a small set of cases: before the conjecture is proven in full, the former situation yields no unconditional cases of the conjecture, whereas the latter situation yields plenty of unconditional cases of the conjecture. So, as a measure of partial progress, the latter is far more satisfactory than the former.")

#text("A good example is provided by Fermat’s last theorem: for every ")#mi("n>2")#text(", there are no solutions to ")#mi("a^n+b^n=c^n")#text(" in the positive integers. It is a trivial matter to observe that to prove Fermat’s last theorem for all ")#mi("n>2")#text(", it suffices to verify it for the odd primes and for ")#mi("n=4")#text(" (just because Fermat’s last theorem for an exponent ")#mi("n")#text(" automatically implies Fermat’s last theorem for all multiples of ")#mi("n")#text(".) This observation already reduces the exponents ")#mi("n")#text(" that one needs to verify to a density 0 set; however, this is considered a trivial reduction that only comprises a very tiny portion of the full proof. In contrast, the much stronger assertion that Fermat’s last theorem holds for almost every n is a much more difficult and significant statement, which I believe was in fact not even established by the time of the Wiles-Taylor proof of the theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dea805f89ee00c35cfc8cc4573bb754fe7c944154a48164c0fb8e54e65342bb-c1ae1e6dc384f0ebf67aeb7d493a4623dda0620d7cd0144a4bfa1d33b56868dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Ford")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-109976")[#strong[#text("Kevin Ford")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2011")])]

#text("Minor correction: FLT for almost all n follows quickly from Faltings’ theorem, as shown in a short note by Heath-Brown in 1985 (Bull. London Math Soc, vol 17, p. 15-16).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a206486953aa84d7bfc3dabc824894fb43d36074ccb40945ea33100ba1ed533d-80cf840618106f98108763ea202a0911db3947994f845dbb1510abf59c20daa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ing. Kontra Miklos")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-479401")[#strong[#text("Ing. Kontra Miklos")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2017")])]

#text("Hi Terence, I was looking at the work of Conway and I would say that his work is very good but he is missing a few branches in his work, i mail him but it seem s that he is very hill, but a familiar told me that he woulld like to see my work, I ve been working for almost for 4 years on a similar work that did Conway and I found a proof od Collatz Conjecture it is really true for every positive number, my proof is based on a graph, and looking at the final graph I would say that the hungarian mathematician Paul Erdoss was true that mathematics are not ready for this kinf of things, I know that i am not a mathematicain but an electronic engineer and i know of my limitation, i m presenting my work at the university of Matanza in Argentina as a thesis, in the graph that i found it can t be seen in some branches that there is no way to show by any means of series the conjecture of Collatz.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-92539")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2011")])]

#text("Why would reduction to a set of density 0 have to yield a remaining set of conditional cases? Why not one abstract case? A method of proof is unknown at present.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur bv")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-92664")[#strong[#text("amateur bv")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2011")])]

#text("Who ever wants to solve Collatz conjecture must also prove that no natural number in a sequence doesnt repeat its self.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Collatz Conjecture « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-109686")[#strong[#text("Collatz Conjecture « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2011")])]

#text("[…] Terry Tao on the Collatz Conjecture Share this:TwitterFacebookLike this:LikeBe the first to like this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59b1d2b66124953f7534140a66604838b5f6b203a3ed38a5883dd22a850d6f86-8224519be8289d8ad2d025ef6960ad43d33d25b0f54228747954b1a2c008b70d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of d005")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-120459")[#strong[#text("d005")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2012")])]

#text("I’ve recently caught this particular mathematical disease, and I’m having a hard time finding someone to point me in the direction I’m interested. It seems to me that if you go from the assumptions that:")#linebreak()#text(" a. All numbers eventually become odd or 1,")#linebreak()#text(" b. all numbers which are not even or 1 can be represented as 2b+1,")#linebreak()#text(" c. every step in the conjecture must remain whole,")#linebreak()#text(" d. a number may never have factors larger than it is, and")#linebreak()#text(" e. the conjecture is described by (3x+1)/2 and x/2")#linebreak()#text(" Eventually the process must come to an ‘end’ given any integer input, because the ‘b’ term requires an increasingly complicated and large set of input factors to go through a series of processes that make the remainder caused by division progressively more complicated.")

#text("Noone will help me, and I’m curious why I can’t find literature or get an easy answer. It seems a simplistic argument.")#linebreak()#text(" Dylan.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e672c608d3cf0676ed48b4da123b626f33cc82b710216843dcd3a9d0456e74fe-8b7e21ccc323ecbe29a5f2603030afce2f5b9c40da35cd338567109b4412ded4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marie Gaudin")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-171747")[#strong[#text("Marie Gaudin")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2012")])]

#text("Hello, my father has done a very hard work on this theme. He is looking for someone to read and appreciate his work (in french).Marie")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-127140")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2012")])]

#text("about the toy model problem for the (weak) Collatz conjecture:")#linebreak()#text(" a1 = 0 < a2 < … < ak ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of strange nickname")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-129964")[#strong[#text("strange nickname")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2012")])]

#text("tomer shalev wrote:")

#text("“Terras proved that almost all numbers have a finite stopping time.”")

#text("I have a question. How he did it? Is it a rigorous proof or just random-probabalistic proof (based on uncertain propositions)?")

#text("I ask, because I found some quite simple proof (but still has about 10 pages) that almost all numbers shouldn’t has a divergent trajectory. What’s more we can prove this way that, for example in 5x+1 problem almost all numbers has a divergent trajectory.")

#text("I ask you that also, because I read some publications of Jeffrey’s Lagarias and I was thinking why he do that many “random tests” of collatz conjecture (wchich has proved for example that almost all positive integers has a finite stopping time) while it is known since Terras has been proven it…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9022ca0788b47be0f20473b1c1290101a0ded6ffc43ce8022cb24a0d39a30ee-79ce5be6a16f952e0387220a9a192d77dc949d2d17d7ebec96dea7305f103b61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-130817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2012")])]

#text("Having a proof that there exists a divergent trajectory for the 5x+1 problem is a new result(i think). Have you shown your proof to anyone?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-140913")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2012")])]

#text("Terras’ proof is not rigorous, and I think it is flawed in a way similar to Everett’ proof of the same result. Everett’ proof is flawed towards the end. Cranks with Phds… Sorry if the truth seems rude… We all make mistakes, but passing off trash as something great for decades on end, like certain other results, shows a lack of Academic honesty, and a waste of student tuition ultimately.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of strange nickname")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-130220")[#strong[#text("strange nickname")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2012")])]

#text("Anonymous wrote:")

#text("“Most of the work on this 3x+1 Problem is absolutely worthless but fashionable at the time of creation, so it sees publication in prestigious journals.”")

#text("1. I think it’s good to explain some things even if they are obvious. If someone will do this, all the rest of mathematicians doesn’t need to explain it all over and over again, they can only cite the source.")

#text("2. Even if someone wrote obvious publication, this publication can induce the others to valuable thoughts. What’s more “obvious” things aren’t always obvious for all, sometimes it’s subjective issue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-130372")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2012")])]

#text("Ternce Tao wrote:")

#text("“The above heuristic argument only suggests decreasing orbits for almost all n”")

#text("For some time I have an explanation and proof of why this heuristic argument works (we can prove that the Collatz sequence performs Bernoulli process, such that p = 0.5), but I’m just a student and I have no way to publication this (I do not even know where I should try to do it). I even have trouble to find someone who assess the reliability and validity of this proof, because mathematicians who are familiar in this area is relatively not much.")

#text("Ternce Tao wrote:")

#text("“though even this remains unproven, the state of the art is that the number of n in {1,…,N} that eventually go to 1 is >> N^0.84, a result of Krasikov and Lagarias”")

#text("Can be proved that if N goes to infinity then the number of n that eventually go to 1 is N^c and c=sqrt(3)/2.")

#text("By the way I’ll show you an equivalent version of the weak Collatz conjecture (I don’t know if it is known to mathematicians):")

#text("Let’s some geometric series. Suppose we have two sequences (n = 0,1,2,3, …):")

#text("c_ {n} = 1.5^{n}")

#text("and a sequence which is defined in such way that we take any vector")#linebreak()#text(" consisting of any natural numbers with zero:")

#text("[a_ {1}, a_ {2}, …, a_ {k}]")

#text("and create on its basis the sequence of vectors assuming a constant r:")

#text("[a_{1}+r, a_{2}+r, …, a_{k}+r]")#linebreak()#text(" [a_{1}+2r, a_{2}+2r, …, a_{k}+2r]")#linebreak()#text(" [a_{1}+3r, a_{2}+3r, …, a_{k}+3r]")#linebreak()#text(" …")#linebreak()#text(" [a_{1}+p*r, a_{2}+p*r, …, a_{k}+ p*r]")

#text("Our second sequence will be as follows:")

#text("2^{a_{1}}, 2^{a_{2}}, … , 2^{a_{k}}, 2^{a_{1}+r}, 2^{a_{2}+r}, … ,")#linebreak()#text(" 2^{a_{k}+r}, 2^{a_{1}+2r}, …")

#text("Now create an infinite number of consecutive terms of taking quotients")#linebreak()#text(" these two sequences:")

#text("SUM = {1,5^{0}}/{2^{a_{1}}} + {1,5^{1}}/{2^{a_{2}}} + … + {1,5^{n}}/")#linebreak()#text(" {2^{a_{k}}} + {1,5^{n+1}}/{2^{a_{1}+r}} + {1,5^{n+2}}/{2^{a_{2}+r}}")#linebreak()#text(" + … + {1,5^{2n}}/{2^{a_{k}+r}} + …")

#text("Question: Is there a finite amount of natural numbers which")#linebreak()#text(" such series can be convergent? Are the only solutions are 1 and 2?")

#text("All indications are that there are only two natural numbers which")#linebreak()#text(" such series can be convergent. Whatever the sequence of vectors")#linebreak()#text(" themselves and what we assume a constant r. Here are that series:")

#text("vector:")#linebreak()#text(" [1]")#linebreak()#text(" r = 1")

#text("(1,5^(0))/(2^(1)) + (1,5^(1))/(2^(1+1)) + (1,5^(2))/(2^(1+2*1)) + …")#linebreak()#text(" = SUM_(n=0)^(infty) (1,5^(n))/(2^(n+1)) = 2")

#text("and")

#text("vector:")

#text("[2]")#linebreak()#text(" r = 1")

#text("(1,5^(0))/(2^(2)) + (1,5^(1))/(2^(2+1)) + (1,5^(2))/(2^(2+2*1)) + …")#linebreak()#text(" = SUM_(n=0)^(infty) (1,5^(n))/(2^(n+2)) = 1")

#text("Can be shown that if these are the only natural numbers to")#linebreak()#text(" which such series can be convergent, the only cycle in the")#linebreak()#text(" Collatz sequences is a trivial cycle, and conversely, if for some")#linebreak()#text(" vector and the constant r series can converge to some other natural numbers, there are non-trivial cycles in Collatz sequences.")

#text("After a moment’s thought is easy to find the criteria for convergence of such series. You can also bring the problem to the following issues:")

#text("– for which r exists a k and k – elements sequence of natural numbers for which this expression takes the value of natural:")

#text("(2^(r+k))/(2^(r+k)-3^k) * [1/2^a_{1} + 1,5^1/2^a_{2} + 1,5^2/2^a_{3} +… + 1,5^(k-1)/2^a_{k}]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-141085")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2012")])]

#text("Wow, since when did non-rigorous heuristics suggest anything meaningful?")

#text("Maybe it’s because many of todays grad students write very few rigorous proofs. Now these sort just memorize and reproduce sketchs to earn a degree and then go with the flow.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-130388")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2012")])]

#text("I wrote:")

#text("“Can be proved that if N goes to infinity then the number of n that eventually go to 1 is N^c and c=sqrt(3)/2.”")

#text("I’m sorry, I made a little mistake. If can be proved that Collatz sequence performs Bernoulli process, then it suggests that almost all n collatz ssequnces are converge.")

#text("I mean, it can be proved that almost all numbers in trajectories converge as if they were multiplied by sqrt(3)/2 or faster and it has no connection with the results of Lagarias and Krasikov.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/207a4babf41035bd784bfd10ad8c39d73bd067865f9a0b96eafc02d6acc73594-3d7204d199a198c2e80027b646392cfaf77aeaab0c253c28fbf7a55f689df552.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Sinyor")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-130477")[#strong[#text("Joseph Sinyor")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2012")])]

#text("At the risk of being self-serving, I suggest that one possible key to understanding the pattern behind the 3x+1 conjecture is related to the Mersenne numbers (2^k-1). See my 2010 paper published in the International Journal of Mathematics & Mathematical Sciences: “The 3x+1 Problem as a String Rewriting System”:")

#link("http://www.hindawi.com/journals/ijmms/2010/458563.html")[#text("http://www.hindawi.com/journals/ijmms/2010/458563.html")]#linebreak()#text(" Joseph Sinyor")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-138929")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("I have seen a rigorous proof using curves that the ones-ratio approaches zero as the number of odds increases for sequenes containing the trivial cycle.")

#text("One can split the sequences for the set 2^k – 1 in half and see that the first half of each seaquence has a ratio above a bound, where the number of odds is unbounded. The question is whether there is a rigorous result on the other half of said sequences to produce a contradiction that the conjecture is false.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/207a4babf41035bd784bfd10ad8c39d73bd067865f9a0b96eafc02d6acc73594-3d7204d199a198c2e80027b646392cfaf77aeaab0c253c28fbf7a55f689df552.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Sinyor")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-139121")[#strong[#text("Joseph Sinyor")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2012")])]

#text("If I may restate your comment, It is easy to show that the path from 2^k – 1 for a given k leads to 3^k – 1 (rapid expansion). The trick is to show that the sequence from that point leads to 2^m – 1 where m < k")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-139125")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2012")])]

#text("No, the trick is to keep track of, and say something rigorous about, the ones-ratio.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-139343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2012")])]

#text("For example, fix n equal to one in equation one above. Then if the conjecture is true, there exists a finite value k whereupon the other variables enumerate every value of the form of mersenne numbers.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of strange nickname")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-131287")[#strong[#text("strange nickname")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2012")])]

#text("Anonymous wrote:")

#text("“Having a proof that there exists a divergent trajectory for the 5x+1")#linebreak()#text(" problem is a new result(i think).”")

#text("I think so too. In fact I have proved that density of numbers which have convergent")#linebreak()#text(" trajectories is zero and it does not necessarily mean that we can find a natural number which has divergent trajectory, but we can be sure that these trajectories exist in the infinity, for example, divergent trajectory for 2.5x+0.5 occurs in the limit:")

#text("lim (n to infty) [sum_(i=0)^(n) 4^i]")

#text("Anonymous wrote:")

#text("“Have you shown your proof to anyone?”")

#text("I posted the proof on some mathematical forum, but I have got no answers,")#linebreak()#text(" only one person said that is a bit long and incomprehensible. But it’s")#linebreak()#text(" not exactly true, if someone knows the subject matter poorly, than any")#linebreak()#text(" evidence may seem difficult.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-131295")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2012")])]

#text("Joseph Sinyor wrote:")

#text("“At the risk of being self-serving, I suggest that one possible key to understanding the pattern behind the 3x+1 conjecture is related to the Mersenne numbers (2^k-1). ”")

#text("An interesting publication about Mersenne numbers is here as well: ")#link("http://arxiv.org/pdf/1104.2804.pdf")[#text("http://arxiv.org/pdf/1104.2804.pdf")]#text(". The authors noted that a path length of a Mersenne number (2^n-1) is approximately proportional to 13.45n.")

#text("By the way I have proof, that if the standard heuristic arguments for the path length is true, then there are infinitely many numbers 2^n-c (c is some natural number) which have approximately proportional path length. What’s more if the Collatz for negative numbers has no divergent trajectories, then all the numbers 2^n-d (d is any natural number) in Collatz path for positive numbers have approximately proportional path length.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-137329")[#strong[#text("Conjetura de Collatz « Blog de Alex Moretó, un lugar para disfrutar aprendiendo matemáticas")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2012")]

#text("[…] Para quien quiera ver como un matemático de primer nivel piensa sobre ella le recomiendo esta entrada del blog de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomaszdz")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-137347")[#strong[#text("tomaszdz")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2012")])]

#text("Here:")

#link("http://www.occampress.com/solutionsubmit2.pdf")[#text("Click to access solutionsubmit2.pdf")]

#text("I found another collatz conjecture proof. Is it correct?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-141090")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2012")])]

#text("It’s every bit as rigorous as the two thousand and three paper of Applegate and Lagarias in MCOM.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of singularnickname")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-140325")[#strong[#text("singularnickname")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2012")])]

#text("We can extend Bohm’s and Sontacchi’s result (weak collatz conjecture equivalent) and we can obtain any loop which has any “structure” (explained below) in collatz-like function by model (for obvious reasons, we limit here only to give the formula for the odd numbers):")

#mi("f(n) = \\begin{cases} \\frac {p}{2} \\cdot n+ \\frac {2^{x+y}-p^{y}}{2} \\cdot r \\ \\ \\ if \\ n \\ is \\ odd\\\\ \\ \\ \\frac {n}{2} \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ if \\ n \\ is \\ even\\end{cases}")

#text("Let ")#mi("p")#text(" be any odd integer. Let ")#mi("c")#text(" be odd number, defined as follows:")

#mi("c = [1, (\\frac {p}{2})^{1}, (\\frac {p}{2})^{2}, ... , (\\frac {p}{2})^{y-1}] \\cdot \\begin{bmatrix} 2^{x^{^{\\prime}}}\\\\2^{x^{^{\\prime\\prime}}}\\\\.\\\\.\\\\.\\\\2^{x^{y-1}}\\\\1\\end{bmatrix} \\cdot 2^{y-1}")

#text("and the conditions are met:")

#text("1) ")#mi("x^{^{\\prime}}, x^{^{\\prime\\prime}}, ... , x^{y-1} \\in [0, x]")

#text("2) ")#mi("x^{^{\\prime}} \\ge x^{^{\\prime\\prime}} \\ge ... \\ge x^{y-1}")

#text("Let ")#mi("x")#text(" be any natural number and the number of operations such as ")#mi("n \\mapsto \\frac {n}{2}")#text(" in the loop of number ")#mi("L = c \\cdot r")#text(".")#linebreak()#text(" Let ")#mi("y")#text(" be any natural number and the number of operations such as ")#mi("n \\mapsto \\frac {p}{2} \\cdot n + \\frac {2^{x+y}-p^{y}}{2} \\cdot r")#text(" in the loop of number ")#mi("L = c \\cdot r")#text(".")

#text("Let ")#mi("r")#text(" be a rational number such that ")#mi("(2^{x+y}-p^{y}) \\cdot r")#text(" is an integer and ")#mi("c \\cdot r")#text(" also is an integer.")

#text("Using this formula, after the adoption of relevant variables that define our function, we can determine any number ")#mi("L = c \\cdot r")#text(" which goes into a loop in a Collatz-like sequences.")

#text("Example:")

#text("First, we select a variable ")#mi("p")#text(", assume ")#mi("p=3")#text(". Then we define ")#mi("y=4")#text(" and ")#mi("x=4")#text(". It is easy to predict that our loop length will therefore ")#mi("x+y=8")#text(". Assume that ")#mi("r=3")#text(". The definition of our function will be as follows:")

#mi("f(n) = \\begin{cases} 1.5 \\cdot n+ 262.5 \\ \\ \\ if \\ n \\ is \\ odd\\\\ \\ \\ \\frac {n}{2} \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ if \\ n \\ is \\ even\\end{cases}")

#text("Let’s define ")#mi("c")#text(". Note that the different selections of the variable ")#mi("c")#text(" so that the conditions are met:")

#text("1) ")#mi("x^{^{\\prime}}, x^{^{\\prime\\prime}}, ... , x^{y-1} \\in [0, x]")

#text("2) ")#mi("x^{^{\\prime}} \\ge x^{^{\\prime\\prime}} \\ge ... \\ge x^{y-1}")

#text("are:")

#mi("{x+y-1 \\choose y-1} = \\frac {(4+4-1)!}{4! \\cdot (4-1)!} = 35")

#text("And for each of these options we will get a loop, but we take the variable ")#mi("c")#text(" described as follows:")

#mi("c = [1, (\\frac {3}{2})^{1}, (\\frac {3}{2})^{2}, (\\frac {3}{2})^{3}] \\cdot \\begin{bmatrix} 2^{4}\\\\2^{2}\\\\2^{2}\\\\1\\end{bmatrix} \\cdot 2^{3} = (8 + 6 + 9 + 3,375) \\cdot 8 = 211")

#text("Number which is a loop in our sequence is therefore:")

#mi("L=211 \\cdot 3 = 633")

#text("Here is this loop:")

#mi("633, 1212, 606, 303, 717, 1338, 669, 1266, 633, ...")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b67a895520134d2734023738eec12819e7cc10aa21eca78706741503656948a1-a46d1bf41715d3dad30b16281072632fefef5c3da9d621edc2ba6f11488ad374.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leszek3")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-141135")[#strong[#text("leszek3")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2012")])]

#text("Hi.")#linebreak()#text(" I have question:")

#text("Are two problems 3n+1 and 3n-1 equivalent ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of singularnickname")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-141714")[#strong[#text("singularnickname")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2012")])]

#text("In which way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b67a895520134d2734023738eec12819e7cc10aa21eca78706741503656948a1-a46d1bf41715d3dad30b16281072632fefef5c3da9d621edc2ba6f11488ad374.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leszek3")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-141789")[#strong[#text("leszek3")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2012")])]

#text("The existence of unusual trajectory (new period or divergent) in one,")#linebreak()#text(" implies such trajectory in the other. Consider e.g. only positive n.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of singularnickname")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-141955")[#strong[#text("singularnickname")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2012")])]

#text("“The existence of unusual trajectory (new period or divergent) in one,")#linebreak()#text(" implies such trajectory in the other.”")

#text("Not exactly. Can be proven only that if for example ")#mi("p")#text(" is number of divergent trajectory in one of sequences and ")#mi("2^{a-1}<p<2^{a}")#text(" then for sure the ")#mi("k")#text("-th elements of trajectories ")#mi("2^{a+k}-p")#text(" (")#mi("k=0,1,2,3,...")#text(") will be grow to infinity. In other words trajektory of ")#mi("\\lim\\limits_{k\\to\\infty} 2^{a+k}-p")#text(" also will be divergent.")

#text("There are many compounds of 3x+1 and 3x-1 sequences. What is more these two sequences are mirror images if we consider the structure of transformations in these sequences. This fact has many implications which indicate very strong relationships of these sequences.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b67a895520134d2734023738eec12819e7cc10aa21eca78706741503656948a1-a46d1bf41715d3dad30b16281072632fefef5c3da9d621edc2ba6f11488ad374.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leszek3")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-142050")[#strong[#text("leszek3")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2012")])]

#text("Thank You very much.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-141864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2012")])]

#text("I believe they are two separate problems; no one has proven that one is equivilant to the other.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5347fc50f19397e0ced1139696487417d81b9049c4b0e679f2fa49a80e826290-9191c9249982afff271a6c0fb2ead52524a831fffe51803fdf3117ae1cb09773.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-307779")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2014")])]

#text("Yes, in that 3n-1 is what you would get if you took the 3n+1 algorithm into the negative numbers but looked at the in the positive. it contains the loops containing each smallest number here: -1, 1, 5, 17. whereas the loops for 3n+1 have as their smallest numbers; 1, -1, -5, -17.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fb5921904498429846ffc199fa537674b44edd8d57d6f45a3f9781bad8f8e10-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of April Nicole")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-170738")[#strong[#text("April Nicole")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2012")])]

#text("Basically, if you add 1 to every odd number, you get an even number. you dont even have to multiply by three. The equation is the same and can be stated many different ways with the same result. If even divide by two, if odd just add 1. If you can prove any odd number plus 1 = an even number, you have essentially proven the Collatz conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-171788")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2012")])]

#text("Hello! Would you know please, which journal would be appropriate to submit to an article on this subject? Thanks for helping me")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bd19f1a3abc6177da5f8de209597088c061eaef91b12501e4c89722e0118756-7c5183fdd0334377eabc4a2a0c97894c27b78a7682497de11ddc0090f84b0785.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Bernardini")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-211137")[#strong[#text("Chris Bernardini")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2012")])]

#text("the sets of odd numbers are three infinite and one finite sets that separate all odd N. they are based on cardinality and in order to keep it simpler i will only state cardinality in these definitions because we already know what these mapping of values to the set of all N entails and their true meaning.")

#text("Set X = Odds 2,5,8,11,14,17,….etc…..infinity")

#text("Set – = odds 3,6,9,12,15,18,…etc….infinity")

#text("Set + = Odds 4,7,10,13,16,….etc…..infinity")

#text("Set ???? = 1 and ONLY 1.")

#text("now the true point of these set designations is this. due to prime factorization and the fact that every odd number is factorized by a unique set of odd prime factors and all evens are just adding a string of multiplications of 2s on each unique odd numbers factorization. essentially what I’m saying is every even integer is composed of an odd base and multiplication of a string of 2’s that each even number has a particular unique number of 2s In its factorization and all even numbers if stripped of 2s will descend to a particular odd number and that number as well as the movements leading to that number are predetermined because due to he rules every number can ONLY move one preset direction. a few rules involving these sets are this")

#text("if any element of set X has ANY amount of 2’s in is prime factorization no whole positive odd integer X can ever equal that value as a result of (X*3)+1")

#text("if any element of set – has any odd number of 2’s in its prime factorization then One and only one X will satisfy for X*3+1. that value is predetermined in the following ways.")

#text("if an element of set – is multiplied by 2^1 then the value that produces that even as an odd within the collatz system is the element of -‘s actual numerical value minus its cardinality within set – multiplied by 2. for 5 which is the first element of this set it would be for example 5 – 2*1 and the next number in set x is 11 and the value that creates it times 2 is 11 – 2*2 and so on so forth into infinity.")

#text("the other infinite set + acts directly parallel to set – except that it does this by adding its cardinality multiplied by 2 instead of subtracting. also where for set – all of the odd numbers of twos in is prime factorization gets switched with evens for this one. and the minimal case where the producing value is directly related to the odd is that odd multiplied by 4 for example 7 is the first number in this set and 7 *4 is equal to (7+(2*1)*3+1 and 13 which is the second number in this set times 4 is equal to 13+(2*2)*3+1")

#text("this is for the most part everything involving how to split up and see the predictable nature. but one will notice that logically it seems that you could have 1 be part of set + based on the progression of those numbers. BUT it cannot for it would throw off every other numbers cardinality and causes 1 to be left alone as 1 *4 = 1*3(+1) and is the only number that causes a number hat breaks down to itself on immediate removal of all 2’s on successive division of two.")

#text("also for all Odds numbers X. if X * 2^n = n*3+1 then X*2^n+2 = n*4+1 or n+x*2^n both of these give the exact same values.")

#text("also another reason 1 mus be in a set of itself is another way of splitting odds hat requires it to be so. it basically falls on my concept of the way a number must move is a transform stage. so in my notation for this part x—–>y means that X becomes Y under all circumstances and Xx then x——>1.")

#text("if element of set E——>X then X———>Y and y is always Greater than E for ALL E’s")

#text("if element of set O———->X then X———–Y and y is always less than E for all E’s")

#text("also if N———>X————–>Y if N is any odd Y will be odd and NO Y will EVER be an Element of set X from the previous groups.(no number divisible by 3 will occur as Y and if y——–>z——->f,,,, so on so forth and no number will ever be divisible by 3 after a value divisible by three has occurred.")

#text("this last part is the one area i haven’t gone too much into. I’m sure there might be a real rule that pinpoints exactly how much larger or smaller a number will be on second transform but i haven’t really felt like going into this any further as i am currently working on a new problem. Hopefully this gives news answers and may be the part needed to prove this “Hard” problem. i just think its more absurd to think any other number would cause a cycle based on the two different clearly explained reasons why one causes an exception when working with the set of all odd numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bd19f1a3abc6177da5f8de209597088c061eaef91b12501e4c89722e0118756-7c5183fdd0334377eabc4a2a0c97894c27b78a7682497de11ddc0090f84b0785.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Bernardini")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-211140")[#strong[#text("Chris Bernardini")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2012")])]

#text("there are simple ways to turn an odd into is set and its cardinality very simply. i left this out simply due to laziness. but the method is whether or not you have to add 2 or subract two from it to make it divisbile by 3 and that tells you which set and then you simply divide that value that is divisible by 3 and thats N’s cardinality in that set. for the set X they are all the odds divisible by three and u just divide by 3 to get their cardinality although that set is completely unessecary for anything.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-214893")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2013")])]

#text("The result of Krasikov and Lagarias, world record five in Lagarias’s 2010 book, does not have a rigorous proof: and therefor is unessecery for anything.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec51eeb7eb59a035e06bb682142725ae17c20787d5aa922ed0577a20184a8dab-ea61f2f87d9b9e26500e81bc01ad334cdc53611b9d5bdd9fdd3c5c9d3dcffbad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huenyk")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-215502")[#strong[#text("Huenyk")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2013")])]

#text("I am a control system engineer. 3n+1 problem has attracted my attention as a controller tuning problem for stability to 1. After one month, I give up for good. The reason is that n/2 cannot be touched. You can’t go to n/4. 3n+1 can be finely tuned to either 3n+3 or 3n-1 both of which are nonconvergent. This is a highly nonlinear control system. As a control engineer I give up. But number theorists don’t know that. So they plod on!")#linebreak()#text(" HuenYK (dr)")#linebreak()#text(" ")#link("mailto:cosmolog92@gmail.com")[#text("cosmolog92@gmail.com")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-215523")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2013")])]

#text("how could it not be linear when the entire equation and operations is linear? slopes up (3n+1) and comes back down with slope 0(N/2).")

#text("N/4 is touchable for sure but you just need to look at one very particular string of odd numbers. this particular string of odd numbers to be exact 1+8n for all N. ex. 1,9,17,……")

#text("ill even make it easier for you with a simple proposition.")

#text("3(1 + 8N) +1 = (1 + 6M) 2^2 iff N is any Natural number and M is dependent on N. meaning there is only one M for each N.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-229156")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2013")])]

#text("hi all great to see the intense enthusiasm for the problem here. here is a ")#link("http://vzn1.wordpress.com/code/collatz-conjecture-experiments/")[#text("brief writeup")]#text(" on my ")#link("http://vzn1.wordpress.com/")[#text("Turing machine blog")]#text(" of an approach based on a real FSM (finite state machine) transducer constructed for iterates (briefly mentioned but not given in the ")#link("http://en.wikipedia.org/wiki/Collatz_conjecture#As_an_abstract_machine_that_computes_in_base_two")[#text("wikipedia article>")]#text(") which also has a close connection to an old paper by Shallit/Wilson on its relation to regular languages. its also ruby “tool box” code for experimenting with different enumeration orders that might be helpful for finding an inductive structure/proof. it also cites Sinyor’s paper as a very “nearby” approach. hope to chat with anyone on the subj & interested in experimental/computational approaches to & attacks on the problem via comments etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06f399bd66400ba541a8d7a1d669b99c25df5869e4695f1e07cb14dca8bdcbf6-2f0c0bf78b1e216b62aeb7d0aa5a6d463b082d2bdb77396a193001a0299f84fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of helloparth")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-238880")[#strong[#text("helloparth")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("There is a typing error in: “An inspection of the proof of Proposition 4 reveals that this orbit consists of {k} steps of the form {x \\mapsto 3x+1}, and {a_{k+1}} steps of the form {x \\mapsto x/2}. As all terms are at least {n}, the former steps can increase magnitude by a multiplicative factor of at most {3+\\frac{1}{N}}. Should say “As all terms are at least {N}…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-239165")[#strong[#text("summer fun/break/vac & the may collatz breakthru | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")]

#text("[…] 5. The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3 | What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6bb406facdf0503c558d877eac146fc650c4f38c71eaa50cd54763216feba147-a5d865fa0f8a4fee5b2ebeda361605c2f158c0ad25c44d09b0305091680b8858.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-247088")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("By working with a fully reduced version of the Collatz function $f(n) = (3n+1)/(2^r)$ to produce only odd number values, one is able to generate new solutions (and therefore new trajectories of equal size) to the associated exponential Diophantine equation by performing arithmetic on the exponents.")

#text("For example, if $n$ is an odd number (with finite trajectory) and $(k, a_1, a_2, … , a_k+1)$ is its associated (reduced map) tuple, then $(k, a_1, a_2 + 2, a_3 + 2, … a_{k+1} + 2)$ is another solution, namely $4n+1$. Here we are adding 2 to each exponent other than $a_1 = 0$. $4n+1$ then has the same trajectory as $n$ (after the seed value). Indeed, you can add any even integer $2m$ the exponents to obtain the $m’th$ iterate of $n$ under $4n+1$.")

#text("One can also add integer multiples of $phi(3^k)$ to $a_{k+1}$ to obtain new solutions. Here, $phi$ denotes Euler’s Totient function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-303149")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2014")])]

#text("hi TT, back… some interesting hot-off-(word)press ")#link("http://vzn1.wordpress.com/2014/04/18/collatz-gamechanger-finally/")[#text("new ideas re collatz")]#text("…gamechanger? :idea: just found that looking at “blocks” starting at ")#mi("n")#text(" through ")#mi("n + c")#text(", and algorithms that choose next values in the blocks to decrease, can create “aggregate trajectories” that stay smaller than a ceiling (close to the initial ceiling which is sum of the starting block values). if these aggregate trajectories can always be proven to converge, theres a proof…. :!:")#linebreak()#text(" polymath prj, anyone?")#linebreak()#text(" am planning to crunch on this further but at a pause point, dont have next step in mind yet….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5347fc50f19397e0ced1139696487417d81b9049c4b0e679f2fa49a80e826290-9191c9249982afff271a6c0fb2ead52524a831fffe51803fdf3117ae1cb09773.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-307810")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2014")])]

#text("after 10 years working on the collatz conjecture I feel pretty stupid having all of my independently derived formulas splashed all over the page up top. :) specifically the formula")

#mi("\\displaystyle (2^{a_{k+1}} - 3^k) n = 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k} \\ \\ \\ \\ \\ (1)")

#text("but i write a(k+1) as x1+…+xn, k as n and a1,a2, as x1,x1+x2…")#linebreak()#text(" But i’ve noticed that integer solutions pop up everywhere once you bend the rules. for example, plug in values for the accumulative totals of the exponent of 2’s that dont exist as a 3n+1 function, and put a zero or negative number in the mix and you get loops with even numbers where there should be odd, loops with a single number only being an integer. etc etc.")

#text("if the cumulative sum of x1 to xn is between n and 2n an integer solution can exist for the ‘n’ in in equation (1) (which i denote as a function of x1,x2…xn, representing how many times you divide by 2 between each time you multiply by 3 then add 1: as B(x1,…,xn) )")

#text("its essentially the same formula, but I use each value as a sum, instead of a1<a2…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5347fc50f19397e0ced1139696487417d81b9049c4b0e679f2fa49a80e826290-9191c9249982afff271a6c0fb2ead52524a831fffe51803fdf3117ae1cb09773.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/comment-page-1/#comment-307844")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2014")])]

#text("formula didnt display right :(. ")#emph[#text("[Corrected – T.]")]

#text("anyways, here are some of my results you guys may find interesting:")#linebreak()#text(" NB:")#linebreak()#text(" B(x) = B(x,x,x,x,x,x,x) repeating loops")#linebreak()#text(" B(X,Y) = B(X,Y,X,Y) repeating loops")#linebreak()#text(" B1(X,Y,Z) = B(X,Y,Z) 1 means first term first")#linebreak()#text(" B2(X,Y,Z) = B(Y,Z,X) 2 means second term first")

#text("B(2) = 1 (trivial cycle, 1,4,2,1…)")

#text("B(1) = -1 (true negative cycle, -1,-2,-1…)")#linebreak()#text(" B(1,2) = -5 (true negative cycle, -5,-14,-7,-20,-10,-5…)")#linebreak()#text(" B2(1,2) = -7 (true negative cycle above, -7,-20,-10,-5,-14,-7…)")#linebreak()#text(" B(1,1,1,4,1,1,2) = -17 (true negative cycle)")

#text("Non 3n+1 values that DO fit the formula:")#linebreak()#text(" B(-2,0,7) = 2")#linebreak()#text(" B(4,3,-1) = 5")#linebreak()#text(" B(1,6,-3) = -13")#linebreak()#text(" B(0,6,-3) = -4")

#text("I have 53 integers so far in ‘n = 3’ sets for outside collatz parameters.")
]
]
