// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/04/reading-seminar-6-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/
// Converted to Typst by tao2typ: "2026-10-14T15:17:32.362346+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Reading seminar 6: “Stable group theory and approximate subgroups”, by Ehud Hrushovski", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Reading seminar 6: “Stable group theory and approximate subgroups”, by Ehud Hrushovski")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/04/reading-seminar-6-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("https://terrytao.wordpress.com/2009/12/04/reading-seminar-6-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This is the last ")#link("https://terrytao.wordpress.com/category/teaching/logic-reading-seminar/")[#text("reading seminar")]#text(" of this quarter for the ")#link("http://arxiv.org/abs/0909.2190")[#text("Hrushovski paper")]#text(". ")#link("http://www.math.ucla.edu/~anush/")[#text("Anush Tserunyan")]#text(" continued working through ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/12/w-stable-theories-1.pdf")[#text("her notes")]#text(" on stable theories. We introduced the key notion of ")#emph[#text("non-forking extensions")]#text(" (in the context of stable theories, at least) of types when constants are added; these are extensions which are “as generic as possible” with respect to the constants being added. The existence of non-forking extensions can be used for instance to generate ")#emph[#text("Morley sequences")]#text(" – sequences of indiscernibles which are “in general position” in some sense.")

#metadata(none) <tao-fb91da23a39ef84e8d80>

#heading(level: 1)[#strong[#text(" — 1. Summary of previous notes — ")]]

#text("Throughout this set of notes, we are working with a ")#mi("{\\omega}")#text("-stable theory ")#mi("{T}")#text(" in some language ")#mi("{L}")#text(", i.e. a complete theory with the property that any countable set of constants ")#mi("{A}")#text(" can only generate at most a countable number of types. ")#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/")[#text("Last time")]#text(", we showed that ")#mi("{\\omega}")#text("-stability also implied that for any other infinite cardinal ")#mi("{\\kappa}")#text(", a set of constants of cardinality ")#mi("{\\kappa}")#text(" can only generate at most ")#mi("{\\kappa}")#text(" many types. ")#mi("{\\omega}")#text("-stability was also shown to be equivalent to the non-existence of an infinite binary tree of formulae in any model ")#mi("{M}")#text(" of ")#mi("{T}")#text(".")

#mi("{\\omega}")#text("-stable theories also had the nice property that any sequence of order-indiscernibles were automatically indiscernible.")

#text("Definable sets (or, equivalently, formulae; we will frequently identify the two) can be recursively assigned a ")#emph[#text("Morley rank")]#text(", which is either an ordinal or ")#mi("{\\infty}")#text(" (where ")#mi("{\\infty}")#text(" is considered larger than all the other ordinals. (Strictly speaking, one has to pass to a countably saturated model before the rank stabilises, but let us ignore this technical point.) Morley rank is similar to the notion of dimension of an algebraic variety. In particular, a definable set of Morley rank ")#mi("{\\alpha}")#text(" cannot be covered by finitely many sets of Morley rank less than ")#mi("{\\alpha}")#text(".")

#text("A refinement to the notion of Morley rank is the notion of ")#emph[#text("Morley degree")]#text(". The Morley degree of a definable set ")#mi("{A}")#text(" of some ordinal Morley rank ")#mi("{\\alpha}")#text(" is equal to the maximal number of disjoint subsets of Morley rank ")#mi("{\\alpha}")#text(" one can partition ")#mi("{A}")#text(" into. It is always a positive integer, and is analogous to the number of top dimension components of an algebraic set.")

#text("We will order rank and degree by lexicographical ordering. Thus one set has smaller Morley rank and degree than another if it has smaller Morley rank, or if it has equal Morley rank and smaller degree.")

#heading(level: 1)[#strong[#text(" — 2. Morley rank of types — ")]]

#text("Given a type ")#mi("{p}")#text(" over some set ")#mi("{A}")#text(" of constants, we define the Morley rank and degree of the type to be the infimum of all the Morley ranks and degrees of all the definable sets (over ")#mi("{A}")#text(") that contain ")#mi("{p}")#text(" (or equivalently, of the formulae in ")#mi("{p}")#text("), using the lexicographical ordering. If ")#mi("{p}")#text(" has an ordinal Morley rank, we use ")#mi("{\\phi_p}")#text(" to denote a definable set (or formula) that contains ")#mi("{p}")#text(" with the minimal Morley rank and degree. This is well-defined up to lower-rank sets (otherwise, by intersecting, we could reduce the rank or degree). Except for this lower rank ambiguity, one could view ")#mi("{\\phi_p}")#text(" as vaguely like a “Zariski closure” of ")#mi("{p}")#text(".")

#text("One should think of ")#mi("{p}")#text(" as occupying the “generic” points of the definable set ")#mi("{\\phi_p}")#text(". One notes that two different types ")#mi("{p, q}")#text(" with ordinal Morley rank must have distinct definable sets ")#mi("{\\phi_p, \\phi_q}")#text(", as if ")#mi("{p \\neq q}")#text(", then ")#mi("{p, q}")#text(" are separated by some definable set ")#mi("{\\psi}")#text(", and by splitting ")#mi("{\\phi_p=\\phi_q}")#text(" by ")#mi("{\\psi}")#text(" one could lower the degree or rank of one of the two types. As a consequence ")#mi("{\\phi_p, \\phi_q}")#text(" must in fact be disjoint up to lower rank errors.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" If ")#mi("{A}")#text(" is a countably saturated model of the theory ")#mi("{T}")#text(", then all types ")#mi("{p}")#text(" with ordinal Morley rank have a degree of ")#mi("{1}")#text(", since if one covers ")#mi("{p}")#text(" by a definable set with Morley degree greater than ")#mi("{1}")#text(", one could partition that set into subsets that are definable in ")#mi("{A}")#text(", and the type ")#mi("{p}")#text(" belongs to just one of these sets. (Is countable saturation necessary here?)")
]

#text("Conversely, given a definable set ")#mi("{X}")#text(" defined by some set ")#mi("{A}")#text(" of constants, we can find a type ")#mi("{p}")#text(" inside it with the same Morley rank and degree as ")#mi("{X}")#text(", simply by taking the formula defining ")#mi("{X}")#text(", and adding the negation of all the formulae defining sets of smaller rank or degree than that of ")#mi("{X}")#text(". This is still consistent (i.e. a partial type) and so can be completed to a type.")

#text("As an application of the above discussion we show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" A theory ")#mi("{T}")#text(" is ")#mi("{\\omega}")#text("-stable if and only if every definable set (i.e. formula) has an ordinal Morley rank (so the rank ")#mi("{\\infty}")#text(" never occurs).")
]

#emph[#text("Proof:")]#text(" Firstly, if all definable sets have an ordinal rank, then so do all types. We can then set up an injection ")#mi("{p \\mapsto \\phi_p}")#text(" from types over a countable set ")#mi("{A}")#text(" to formulae; since there are only countably many formulae over ")#mi("{A}")#text(", we have countably many types, and the claim follows.")

#text("Now suppose instead that we have a definable set ")#mi("{E}")#text(" of infinite rank. Then we can find inside it two disjoint definable sets of infinite rank. (This is because in any model, the ordinal ranks that can occur must be bounded by some ordinal ")#mi("{\\kappa}")#text(", and ")#mi("{E}")#text(", having infinite rank, certainly has rank at least ")#mi("{\\kappa+2}")#text(", and thus must contain at least two disjoint definable sets of rank at least ")#mi("{\\kappa+1}")#text(".) Continuing this process we obtain an infinite binary tree, contradicting ")#mi("{\\omega}")#text("-stability. ")#mi("\\Box")

#text("Thus we may henceforth take all definable sets to have an ordinal Morley rank.")

#heading(level: 1)[#strong[#text(" — 3. Forking — ")]]

#text("Let ")#mi("{p}")#text(" be a type over some set of constants ")#mi("{A}")#text(". If we enlarge the set of constants to some larger set ")#mi("{B}")#text(", thus creating more formulae, then ")#mi("{p}")#text(" is no longer a type in general; but we can ")#emph[#text("extend")]#text(" ")#mi("{p}")#text(" to a type ")#mi("{p^{\\prime}}")#text(" over ")#mi("{B}")#text(" by adding in enough formulae over ")#mi("{B}")#text(" to regain completeness. The set that the type realises shrinks when one does so, of course. In particular, the rank and degree of the extension ")#mi("{p^{\\prime}}")#text(" is less than or equal to that of ")#mi("{p}")#text(". If the rank of ")#mi("{p^{\\prime}}")#text(" is the same as that of ")#mi("{p}")#text(", we say that the extension is ")#emph[#text("non-forking")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" There are finitely many non-forking extensions ")#mi("{p^{\\prime}}")#text(" of ")#mi("{p}")#text(", and the degrees of ")#mi("{p^{\\prime}}")#text(" add up to the degree of ")#mi("{p}")#text(". In particular, there exists at least one non-forking extension, and there is at most one for which ")#mi("{p^{\\prime}}")#text(" has the same degree as ")#mi("{p}")#text(".")
]

#emph[#text("Proof:")]#text(" Say that ")#mi("{p}")#text(" has rank ")#mi("{\\alpha}")#text(" and degree ")#mi("{d}")#text(", so we can find a definable set ")#mi("{\\phi_p}")#text(" containing ")#mi("{p}")#text(" with this rank and degree. We split ")#mi("{\\phi_p}")#text(" into ")#mi("{d}")#text(" definable sets ")#mi("{\\psi_1,\\ldots,\\psi_d}")#text(" (over some countably saturated model) of rank ")#mi("{\\alpha}")#text(" and degree ")#mi("{1}")#text(".")

#text("For each ")#mi("{\\psi_i}")#text(", we can create a non-forking extension ")#mi("{p^{\\prime}_i}")#text(" by taking all the formulae over ")#mi("{B}")#text(" which intersect ")#mi("{\\psi_i}")#text(" in a set of Morley rank ")#mi("{\\alpha}")#text(". Every non-forking extension ")#mi("{p^{\\prime}}")#text(" has to arise in this manner, because any formula covering ")#mi("{p^{\\prime}}")#text(" must intersect at least one of the ")#mi("{\\psi_i}")#text(" in a set of rank ")#mi("{\\alpha}")#text(", otherwise its intersection with ")#mi("{\\phi_p}")#text(" would cover ")#mi("{p^{\\prime}}")#text(" and have rank less than ")#mi("{\\alpha}")#text(", contradicting the non-forking property. It is also easy to see that the degree of ")#mi("{p^{\\prime}}")#text(" is nothing more than the number of ")#mi("{i}")#text(" for which ")#mi("{p^{\\prime}_i=p^{\\prime}}")#text(". The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" In the theory of algebraically closed fields of dimension zero, the set ")#mi("{\\{\\pm \\sqrt{2}\\}}")#text(" determines a type over ")#mi("{{\\mathbb Q}}")#text(" (basically given by the formula ")#mi("{x^2=2}")#text("), of rank zero and degree ")#mi("{2}")#text(". Once one adds the additional constant ")#mi("{\\sqrt{2}}")#text(" to ")#mi("{{\\mathbb Q}}")#text(", one obtains two non-forking extensions of this type: ")#mi("{\\{+\\sqrt{2}\\}}")#text(" and ")#mi("{\\{-\\sqrt{2}\\}}")#text(", which have rank zero and degree ")#mi("{1}")#text(". Similarly for higher rank; for instance, the type over ")#mi("{{\\mathbb Q}}")#text(" corresponding to “generic” points on the double circle ")#mi("{\\{(x,y): (x^2+y^2)^2 = 2 \\}}")#text(" has rank ")#mi("{1}")#text(" and degree ")#mi("{2}")#text(", but upon adjoining ")#mi("{\\sqrt{2}}")#text(", has two non-forking extensions, the generic points of ")#mi("{\\{ (x,y): x^2+y^2 = \\sqrt{2} \\}}")#text(" and the generic points of ")#mi("{\\{ (x,y): x^2+y^2 = -\\sqrt{2} \\}}")#text(", which have rank ")#mi("{1}")#text(" and degree ")#mi("{1}")#text(". (Three are also some forking extensions, for instance the rank ")#mi("{0}")#text(" set ")#mi("{\\{ (x,y): x^2+y^2 = \\sqrt{2}; x = \\sqrt{2} y \\}}")#text(".)")
]

#text("An element ")#mi("{a}")#text(" is said to be ")#emph[#text("independent")]#text(" of a set of constants ")#mi("{B}")#text(" over a set of constants ")#mi("{A}")#text(" if the type of ")#mi("{a}")#text(" over ")#mi("{A \\cup B}")#text(" is a non-forking extension of the type ")#mi("{a}")#text(" over ")#mi("{A}")#text(". Informally, this means knowledge of ")#mi("{B}")#text(" only restricts the degree of ")#mi("{a}")#text(" at best, but not the rank, and is thus a weak statement that ")#mi("{a}")#text(" is in “general position” with respect to ")#mi("{B}")#text(", relative to ")#mi("{A}")#text(". For example, in the above example, the generic points of ")#mi("{\\{ (x,y): x^2+y^2 = \\sqrt{2} \\}}")#text(" and ")#mi("{\\{ (x,y): x^2+y^2 = -\\sqrt{2} \\}}")#text(" are independent of ")#mi("{\\sqrt{2}}")#text(", but the elements of ")#mi("{\\{ (x,y): x^2+y^2 = \\sqrt{2} \\}}")#text(" are not.")

#text("There is a non-trivial theorem that independence is symmetric: if ")#mi("{a}")#text(" is independent of ")#mi("{b}")#text(" over ")#mi("{A}")#text(", then ")#mi("{b}")#text(" is independent of ")#mi("{a}")#text(" over ")#mi("{A}")#text(", which relies on the important concept of ")#emph[#text("definable types")]#text(", which unfortunately we did not have time to cover in detail (but see ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/11/w-stable-theories.pdf")[#text("Anush’s notes")]#text(").")

#heading(level: 1)[#strong[#text(" — 4. Morley sequences — ")]]

#text("A ")#emph[#text("Morley sequence")]#text(" for a type ")#mi("{p}")#text(" over a set of constants ")#mi("{A}")#text(" is a sequence ")#mi("{(a_\\alpha)_{\\alpha < \\delta}}")#text(" of elements realising ")#mi("{p}")#text(" for all ordinals ")#mi("{\\alpha}")#text(" up to some ")#mi("{\\delta}")#text(", such that for each ")#mi("{\\alpha}")#text(", the type of ")#mi("{a_\\alpha}")#text(" over ")#mi("{A \\cup \\{ a_\\beta: \\beta < \\alpha \\}}")#text(" is an extension of ")#mi("{p}")#text(" of the same rank and degree. In particular, ")#mi("{a_\\alpha}")#text(" is independent of all previous ")#mi("{a_\\beta}")#text(" over ")#mi("{A}")#text(", and ")#mi("{a_\\alpha}")#text(" realises the unique non-forking extension of ")#mi("{p}")#text(" over ")#mi("{A \\cup \\{ a_\\beta: \\beta < \\alpha \\}}")#text(".")

#text("Morley sequences are automatically order-indiscernible (and hence indiscernible, by ")#mi("{\\omega}")#text("-stability) over ")#mi("{A}")#text(". We will illustrate this by showing that the pair ")#mi("{(a_1,a_2)}")#text(" and the pair ")#mi("{(a_1,a_3)}")#text(" are indistinguishable over ")#mi("{A}")#text(". Indeed, ")#mi("{a_3}")#text(" realises the unique non-forking extension of ")#mi("{p}")#text(" over ")#mi("{A \\cup \\{a_1,a_2\\}}")#text(", and so must also do so over ")#mi("{A \\cup \\{a_1\\}}")#text(". But ")#mi("{a_2}")#text(" realises this extension also, so ")#mi("{a_2, a_3}")#text(" have the same type over ")#mi("{A \\cup \\{a_1\\}}")#text(", which gives indistinguishability of ")#mi("{(a_1,a_2)}")#text(" and ")#mi("{(a_1,a_3)}")#text(". (For the general case, see ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/11/w-stable-theories.pdf")[#text("Anush’s notes")]#text(".)")

#text("Morley sequences thus provide a way to generate indiscernibles without needing to resort to Ramsey theory. For instance, suppose we have a model ")#mi("{M}")#text(" whose cardinality is ")#mi("{\\aleph_1}")#text(" (the least uncountable cardinal), and let ")#mi("{A}")#text(" be a set of smaller cardinality than ")#mi("{M}")#text(" (i.e. at most countable). Then there are at most countably many types over ")#mi("{A}")#text(" (by stability), hence one of these types must have an uncountable number of realisations in ")#mi("{M}")#text(". Now take a countable set ")#mi("{B}")#text(" containing ")#mi("{A}")#text(", and a type ")#mi("{p}")#text(" of ")#mi("{B}")#text(" with an uncountable number of realisations, with a minimal Morley rank and degree among all such types. If we extend ")#mi("{B}")#text(" to any larger (but still countable) ")#mi("{B^{\\prime}}")#text(", at least one of the extensions of ")#mi("{p}")#text(" must remain uncountable, and thus have the same rank and degree as ")#mi("{p}")#text("; in particular, this must be the unique non-forking extension of ")#mi("{p}")#text(". We can then construct a countable Morley sequence by repeatedly selecting an element in this extension, then adding the element to ")#mi("{B}")#text(" and extending again.")

#text("The above argument works just as well for models ")#mi("{M}")#text(" whose cardinality is an uncountable successor cardinal, and one can then also handle limit cardinals by appealing to the downward Lowenheim-Skolem theorem.")
