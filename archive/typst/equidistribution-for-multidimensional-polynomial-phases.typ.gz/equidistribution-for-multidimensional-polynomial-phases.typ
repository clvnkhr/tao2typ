// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/
// Converted to Typst by tao2typ: "2026-10-14T16:37:44.562442+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Equidistribution for multidimensional polynomial phases", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Equidistribution for multidimensional polynomial phases")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 August 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/")[#text("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("https://en.wikipedia.org/wiki/Equidistribution_theorem")[#text("equidistribution theorem")]#text(" asserts that if ")#mi("{\\alpha \\in {\\bf R}/{\\bf Z}}")#text(" is an irrational phase, then the sequence ")#mi("{(n\\alpha)_{n=1}^\\infty}")#text(" is equidistributed on the unit circle, or equivalently that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n=1}^N F(n\\alpha) \\rightarrow \\int_{{\\bf R}/{\\bf Z}} F(x)\\ dx")]]

#text("for any continuous (or equivalently, for any smooth) function ")#mi("{F: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(". By approximating ")#mi("{F}")#text(" uniformly by a Fourier series, this claim is equivalent to that of showing that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n=1}^N e(hn\\alpha) \\rightarrow 0")]]

#text("for any non-zero integer ")#mi("{h}")#text(" (where ")#mi("{e(x) := e^{2\\pi i x}}")#text("), which is easily verified from the irrationality of ")#mi("{\\alpha}")#text(" and the geometric series formula. Conversely, if ")#mi("{\\alpha}")#text(" is rational, then clearly ")#mi("{\\frac{1}{N} \\sum_{n=1}^N e(hn\\alpha)}")#text(" fails to go to zero when ")#mi("{h}")#text(" is a multiple of the denominator of ")#mi("{\\alpha}")#text(".")

#text("One can then ask for more quantitative information about the decay of exponential sums of ")#mi("{\\frac{1}{N} \\sum_{n=1}^N e(n \\alpha)}")#text(", or more generally on exponential sums of the form ")#tao-math("{\\frac{1}{\\left|Q\\right|} \\sum_{n \\in Q} e(P(n))}", block: false)#text(" for an arithmetic progression ")#mi("{Q}")#text(" (in this post all progressions are understood to be finite) and a polynomial ")#mi("{P: Q \\rightarrow \\hspace{0pt}{\\bf Z}}")#text(". It will be convenient to phrase such information in the form of an ")#emph[#text("inverse theorem")]#text(", describing those phases for which the exponential sum is large. Indeed, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Geometric series formula, inverse form)")]#text(" ")#metadata(none) <tao-b23bdd6952cda0417398>#text(" Let ")#mi("{Q \\subset {\\bf Z}}")#text(" be an arithmetic progression of length at most ")#mi("{N}")#text(" for some ")#mi("{N \\geq 1}")#text(", and let ")#mi("{P(n) = n \\alpha + \\beta}")#text(" be a linear polynomial for some ")#mi("{\\alpha,\\beta \\in {\\bf R}/{\\bf Z}}")#text(". If")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N} \\left|\\sum_{n \\in Q} e(P(n))\\right| \\geq \\delta", block: true)]]

#text("for some ")#mi("{\\delta > 0}")#text(", then there exists a subprogression ")#mi("{Q^{\\prime}}")#text(" of ")#mi("{Q}")#text(" of size ")#tao-math("{\\left|Q^{\\prime}\\right| \\gg \\delta^2 N}", block: false)#text(" such that ")#mi("{P(n)}")#text(" varies by at most ")#mi("{\\delta}")#text(" on ")#mi("{Q^{\\prime}}")#text(" (that is to say, ")#mi("{P(n)}")#text(" lies in a subinterval of ")#mi("{{\\bf R}/{\\bf Z}}")#text(" of length at most ")#mi("{\\delta}")#text(").")
]

#emph[#text("Proof:")]#text(" By a linear change of variable we may assume that ")#mi("{Q}")#text(" is of the form ")#mi("{\\{0,\\dots,N^{\\prime}-1\\}}")#text(" for some ")#mi("{N^{\\prime} \\geq 1}")#text(". We may of course assume that ")#mi("{\\alpha}")#text(" is non-zero in ")#mi("{{\\bf R}/{\\bf Z}}")#text(", so that ")#tao-math("{\\left\\|\\alpha\\right\\|_{{\\bf R}/{\\bf Z}} > 0}", block: false)#text(" (")#tao-math("{\\left\\|x\\right\\|_{{\\bf R}/{\\bf Z}}}", block: false)#text(" denotes the distance from ")#mi("{x}")#text(" to the nearest integer). From the geometric series formula we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in Q} e(P(n))\\right| \\leq \\frac{2}{\\left|e(\\alpha) - 1\\right|} \\ll \\frac{1}{\\left\\|\\alpha\\right\\|_{{\\bf R}/{\\bf Z}}},", block: true)]]

#text("and so ")#tao-math("{\\left\\|\\alpha\\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{1}{\\delta N}}", block: false)#text(". Setting ")#mi("{Q^{\\prime} := \\{ n \\in Q: n \\leq c \\delta^2 N \\}}")#text(" for some sufficiently small absolute constant ")#mi("{c}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Thus, in order for a linear phase ")#mi("{P(n)}")#text(" to fail to be equidistributed on some long progression ")#mi("{Q}")#text(", ")#mi("{P}")#text(" must in fact be almost constant on large piece of ")#mi("{Q}")#text(".")

#text("As is well known, this phenomenon generalises to higher order polynomials. To achieve this, we need two elementary additional lemmas. The first relates the exponential sums of ")#mi("{P}")#text(" to the exponential sums of its “first derivatives” ")#mi("{n \\mapsto P(n+h)-P(n)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Van der Corput lemma, inverse form)")]#text(" Let ")#mi("{Q \\subset {\\bf Z}}")#text(" be an arithmetic progression of length at most ")#mi("{N}")#text(", and let ")#mi("{P: Q \\rightarrow {\\bf R}/{\\bf Z}}")#text(" be an arbitrary function such that ")#metadata(none) <tao-9b2d5b4678781e53038e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\frac{1}{N} \\left|\\sum_{n \\in Q} e(P(n))\\right| \\geq \\delta", block: true)]]



#text(" for some ")#mi("{\\delta > 0}")#text(". Then, for ")#mi("{\\gg \\delta^2 N}")#text(" integers ")#mi("{h \\in Q-Q}")#text(", there exists a subprogression ")#mi("{Q_h}")#text(" of ")#mi("{Q}")#text(", of the same spacing as ")#mi("{Q}")#text(", such that ")#metadata(none) <tao-87dcc88da74e0c48ae06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\frac{1}{N} \\left|\\sum_{n \\in Q_h} e(P(n+h)-P(n))\\right| \\gg \\delta^2.", block: true)]]




]

#emph[#text("Proof:")]#text(" Squaring ")#link(<tao-9b2d5b4678781e53038e>)[#text("(1)")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n,n^{\\prime} \\in Q} e(P(n^{\\prime}) - P(n)) \\geq \\delta^2 N^2.")]]

#text("We write ")#mi("{n^{\\prime} = n+h}")#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{h \\in Q-Q} \\sum_{n \\in Q_h} e( P(n+h)-P(n) ) \\geq \\delta^2 N^2")]]

#text("where ")#mi("{Q_h := Q \\cap (Q-h)}")#text(" is a subprogression of ")#mi("{Q}")#text(" of the same spacing. Since ")#mi("{\\sum_{n \\in Q_h} e( P(n+h)-P(n) ) = O(N)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in Q_h} e( P(n+h)-P(n) )\\right| \\gg \\delta^2 N", block: true)]]

#text("for ")#mi("{\\gg \\delta^2 N}")#text(" values of ")#mi("{h}")#text(" (this can be seen, much like the pigeonhole principle, by arguing via contradiction for a suitable choice of implied constants). The claim follows. ")#mi("\\Box")

#text("The second lemma (which we recycle from ")#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")[#text("this previous blog post")]#text(") is a variant of the equidistribution theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Vinogradov lemma)")]#text(" ")#metadata(none) <tao-f734ad4e842854d4f5c1>#text(" Let ")#mi("{I \\subset [-N,N] \\cap {\\bf Z}}")#text(" be an interval for some ")#mi("{N \\geq 1}")#text(", and let ")#mi("{\\theta \\in{\\bf R}/{\\bf Z}}")#text(" be such that ")#tao-math("{\\left\\|n\\theta\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(" for at least ")#mi("{\\delta N}")#text(" values of ")#mi("{n \\in I}")#text(", for some ")#mi("{0 < \\varepsilon, \\delta < 1}")#text(". Then either")

#align(center)[#tao-fit-display[#mitex("N < \\frac{2}{\\delta}")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\varepsilon > 10^{-2} \\delta")]]

#text("or else there is a natural number ")#mi("{q \\leq 2/\\delta}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\varepsilon}{\\delta N}.", block: true)]]
]

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{N \\geq \\frac{2}{\\delta}}")#text(" and ")#mi("{\\varepsilon \\leq 10^{-2} \\delta}")#text(", since we are done otherwise. Then there are at least two ")#mi("{n \\in I}")#text(" with ")#tao-math("{\\left\\|n \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(", and by the pigeonhole principle we can find ")#mi("{n_1 < n_2}")#text(" in ")#mi("{Q}")#text(" with ")#tao-math("{\\left\\|n_1 \\theta \\right\\|_{{\\bf R}/{\\bf Z}}, \\left\\|n_2 \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(" and ")#mi("{n_2-n_1 \\leq \\frac{2}{\\delta}}")#text(". By the triangle inequality, we conclude that there exists at least one natural number ")#mi("{q \\leq \\frac{2}{\\delta}}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq 2\\varepsilon.", block: true)]]

#text("We take ")#mi("{q}")#text(" to be minimal amongst all such natural numbers, then we see that there exists ")#mi("{a}")#text(" coprime to ")#mi("{q}")#text(" and ")#tao-math("{\\left|\\kappa\\right| \\leq 2\\varepsilon}", block: false)#text(" such that ")#metadata(none) <tao-8ed3f6ad685b959ead70>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\theta = \\frac{a}{q} + \\frac{\\kappa}{q}.")]]





#text("If ")#mi("{\\kappa=0}")#text(" then we are done, so suppose that ")#mi("{\\kappa \\neq 0}")#text(". Suppose that ")#mi("{n < m}")#text(" are elements of ")#mi("{I}")#text(" such that ")#tao-math("{\\left\\|n\\theta \\right\\|_{{\\bf R}/{\\bf Z}}, \\left\\|m\\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(" and ")#mi("{m-n \\leq \\frac{1}{10 \\kappa}}")#text(". Writing ")#mi("{m-n = qk + r}")#text(" for some ")#mi("{0 \\leq r < q}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (m-n) \\theta \\right\\|_{{\\bf R}/{\\bf Z}} = \\left\\| \\frac{ra}{q} + (m-n) \\frac{\\kappa}{q} \\right\\|_{{\\bf R}/{\\bf Z}} \\leq 2\\varepsilon.", block: true)]]

#text("By hypothesis, ")#mi("{(m-n) \\frac{\\kappa}{q} \\leq \\frac{1}{10 q}}")#text("; note that as ")#mi("{q \\leq 2/\\delta}")#text(" and ")#mi("{\\varepsilon \\leq 10^{-2} \\delta}")#text(" we also have ")#mi("{\\varepsilon \\leq \\frac{1}{10q}}")#text(". This implies that ")#tao-math("{\\left\\| \\frac{ra}{q} \\right\\|_{{\\bf R}/{\\bf Z}} < \\frac{1}{q}}", block: false)#text(" and thus ")#mi("{r=0}")#text(". We then have")

#align(center)[#tao-fit-display[#tao-math("\\left|k \\kappa\\right| \\leq 2 \\varepsilon.", block: true)]]

#text("We conclude that for fixed ")#mi("{n \\in I}")#text(" with ")#tao-math("{\\left\\|n\\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(", there are at most ")#tao-math("{\\frac{2\\varepsilon}{\\left|\\kappa\\right|}}", block: false)#text(" elements ")#mi("{m}")#text(" of ")#tao-math("{[n, n + \\frac{1}{10 \\left|\\kappa\\right|}]}", block: false)#text(" such that ")#tao-math("{\\left\\|m\\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(". Iterating this with a greedy algorithm, we see that the number of ")#mi("{n \\in I}")#text(" with ")#tao-math("{\\left\\|n\\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(" is at most ")#tao-math("{(\\frac{N}{1/10\\left|\\kappa\\right|} + 1) 2\\varepsilon/\\left|\\kappa\\right|}", block: false)#text("; since ")#mi("{\\varepsilon < 10^{-2} \\delta}")#text(", this implies that")

#align(center)[#tao-fit-display[#mitex("\\delta N \\ll 2 \\varepsilon / \\kappa")]]

#text("and the claim follows. ")#mi("\\Box")

#text("Now we can quickly obtain a higher degree version of Lemma ")#link(<tao-b23bdd6952cda0417398>)[#text("1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Weyl exponential sum estimate, inverse form)")]#text(" ")#metadata(none) <tao-60c64a02004a92cca70b>#text(" Let ")#mi("{Q \\subset {\\bf Z}}")#text(" be an arithmetic progression of length at most ")#mi("{N}")#text(" for some ")#mi("{N \\geq 1}")#text(", and let ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" be a polynomial of some degree at most ")#mi("{d \\geq 0}")#text(". If")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N} \\left|\\sum_{n \\in Q} e(P(n))\\right| \\geq \\delta", block: true)]]

#text("for some ")#mi("{\\delta > 0}")#text(", then there exists a subprogression ")#mi("{Q^{\\prime}}")#text(" of ")#mi("{Q}")#text(" with ")#tao-math("{\\left|Q^{\\prime}\\right| \\gg_d \\delta^{O_d(1)} N}", block: false)#text(" such that ")#mi("{P}")#text(" varies by at most ")#mi("{\\delta}")#text(" on ")#mi("{Q^{\\prime}}")#text(".")
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{d}")#text(". The cases ")#mi("{d=0,1}")#text(" are immediate from Lemma ")#link(<tao-b23bdd6952cda0417398>)[#text("1")]#text(". Now suppose that ")#mi("{d \\geq 2}")#text(", and that the claim had already been proven for ")#mi("{d-1}")#text(". To simplify the notation we allow implied constants to depend on ")#mi("{d}")#text(". Let the hypotheses be as in the proposition. Clearly ")#mi("{\\delta}")#text(" cannot exceed ")#mi("{1}")#text(". By shrinking ")#mi("{\\delta}")#text(" as necessary we may assume that ")#mi("{\\delta \\leq c}")#text(" for some sufficiently small constant ")#mi("{c}")#text(" depending on ")#mi("{d}")#text(".")

#text("By rescaling we may assume ")#mi("{Q \\subset [0,N] \\cap {\\bf Z}}")#text(". By Lemma ")#link(<tao-f734ad4e842854d4f5c1>)[#text("3")]#text(", we see that for ")#mi("{\\gg \\delta^2 N}")#text(" choices of ")#mi("{h \\in [-N,N] \\cap {\\bf Z}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N} \\left|\\sum_{n \\in I_h} e(P(n+h) - P(n))\\right| \\gg \\delta^2", block: true)]]

#text("for some interval ")#mi("{I_h \\subset [0,N] \\cap {\\bf Z}}")#text(". We write ")#mi("{P(n) = \\sum_{i \\leq d} \\alpha_i n^i}")#text(", then ")#mi("{P(n+h)-P(n)}")#text(" is a polynomial of degree at most ")#mi("{d-1}")#text(" with leading coefficient ")#mi("{h \\alpha_d n^{d-1}}")#text(". We conclude from induction hypothesis that for each such ")#mi("{h}")#text(", there exists a natural number ")#mi("{q_h \\ll \\delta^{-O(1)}}")#text(" such that ")#tao-math("{\\left\\|q_h h \\alpha_d \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\delta^{-O(1)} / N^{d-1}}", block: false)#text(", by double-counting, this implies that there are ")#mi("{\\gg \\delta^{O(1)} N}")#text(" integers ")#mi("{n}")#text(" in the interval ")#mi("{[-\\delta^{-O(1)} N, \\delta^{-O(1)} N] \\cap {\\bf Z}}")#text(" such that ")#tao-math("{\\left\\|n \\alpha_d \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\delta^{-O(1)} / N^{d-1}}", block: false)#text(". Applying Lemma ")#link(<tao-f734ad4e842854d4f5c1>)[#text("3")]#text(", we conclude that either ")#mi("{N \\ll \\delta^{-O(1)}}")#text(", or that ")#metadata(none) <tao-03fa2bb8d7e1eb20f5b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| q \\alpha_d \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\delta^{-O(1)} / N^d.", block: true)]]



#text(" In the former case the claim is trivial (just take ")#mi("{Q^{\\prime}}")#text(" to be a point), so we may assume that we are in the latter case.")

#text("We partition ")#mi("{Q}")#text(" into arithmetic progressions ")#mi("{Q^{\\prime}}")#text(" of spacing ")#mi("{q}")#text(" and length comparable to ")#mi("{\\delta^{-C} N}")#text(" for some large ")#mi("{C}")#text(" depending on ")#mi("{d}")#text(" to be chosen later. By hypothesis, we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|Q\\right|} \\left|\\sum_{n \\in Q} e(P(n))\\right| \\geq \\delta", block: true)]]

#text("so by the pigeonhole principle, we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|Q^{\\prime}\\right|} \\left|\\sum_{n \\in Q^{\\prime}} e(P(n))\\right| \\geq \\delta", block: true)]]

#text("for at least one such progression ")#mi("{Q^{\\prime}}")#text(". On this progression, we may use the binomial theorem and ")#link(<tao-03fa2bb8d7e1eb20f5b3>)[#text("(4)")]#text(" to write ")#mi("{\\alpha_d n^d}")#text(" as a polynomial in ")#mi("{n}")#text(" of degree at most ")#mi("{d-1}")#text(", plus an error of size ")#mi("{O(\\delta^{C - O(1)})}")#text(". We thus can write ")#mi("{P(n) = P^{\\prime}(n) + O(\\delta^{C-O(1)})}")#text(" for ")#mi("{n \\in Q^{\\prime}}")#text(" for some polynomial ")#mi("{P^{\\prime}}")#text(" of degree at most ")#mi("{d-1}")#text(". By the triangle inequality, we thus have (for ")#mi("{C}")#text(" large enough) that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|Q^{\\prime}\\right|} \\left|\\sum_{n \\in Q^{\\prime}} e(P^{\\prime}(n))\\right| \\gg \\delta", block: true)]]

#text("and hence by induction hypothesis we may find a subprogression ")#mi("{Q^{\\prime\\prime}}")#text(" of ")#mi("{Q^{\\prime}}")#text(" of size ")#tao-math("{\\left|Q^{\\prime\\prime}\\right| \\gg \\delta^{O(1)} N}", block: false)#text(" such that ")#mi("{P^{\\prime}}")#text(" varies by most ")#mi("{\\delta/2}")#text(" on ")#mi("{Q^{\\prime\\prime}}")#text(", and thus (for ")#mi("{C}")#text(" large enough again) that ")#mi("{P}")#text(" varies by at most ")#mi("{\\delta}")#text(" on ")#mi("{Q^{\\prime\\prime}}")#text(", and the claim follows. ")#mi("\\Box")

#text("This gives the following corollary (also given as Exercise 16 in ")#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")[#text("this previous blog post")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5 (Weyl exponential sum estimate, inverse form II)")]#text(" ")#metadata(none) <tao-3f14d6277c6e981dcbd1>#text(" Let ")#mi("{I \\subset [-N,N] \\cap {\\bf Z}}")#text(" be a discrete interval for some ")#mi("{N \\geq 1}")#text(", and let ")#mi("{P(n) = \\sum_{i \\leq d} \\alpha_i n^i}")#text(" polynomial of some degree at most ")#mi("{d \\geq 0}")#text(" for some ")#mi("{\\alpha_0,\\dots,\\alpha_d \\in {\\bf R}/{\\bf Z}}")#text(". If")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N} \\left|\\sum_{n \\in I} e(P(n))\\right| \\geq \\delta", block: true)]]

#text("for some ")#mi("{\\delta > 0}")#text(", then there is a natural number ")#mi("{q \\ll_d \\delta^{-O_d(1)}}")#text(" such that ")#tao-math("{\\left\\| q\\alpha_i \\right\\|_{{\\bf R}/{\\bf Z}} \\ll_d \\delta^{-O_d(1)} N^{-i}}", block: false)#text(" for all ")#mi("{i=0,\\dots,d}")#text(".")
]

#text("One can obtain much better exponents here using Vinogradov’s mean value theorem; see Theorem 1.6 ")#link("https://www.math.purdue.edu/~twooley/publ/ecvin20110711.pdf")[#text("this 2011 paper of Wooley")]#text(". (Thanks to Mariusz Mirek for this reference.) However, this weaker result already suffices for many applications, and does not need any result as deep as the mean value theorem.")

#emph[#text("Proof:")]#text(" To simplify notation we allow implied constants to depend on ")#mi("{d}")#text(". As before, we may assume that ")#mi("{\\delta \\leq c}")#text(" for some small constant ")#mi("{c>0}")#text(" depending only on ")#mi("{d}")#text(". We may also assume that ")#mi("{N \\geq \\delta^{-C}}")#text(" for some large ")#mi("{C}")#text(", as the claim is trivial otherwise (set ")#mi("{q=1}")#text(").")

#text("Applying Proposition ")#link(<tao-60c64a02004a92cca70b>)[#text("4")]#text(", we can find a natural number ")#mi("{q \\ll \\delta^{-O(1)}}")#text(" and an arithmetic subprogression ")#mi("{Q}")#text(" of ")#mi("{I}")#text(" such that ")#tao-math("{\\left|Q\\right| \\gg \\delta^{O(1)}}", block: false)#text(" and such that ")#mi("{P}")#text(" varies by at most ")#mi("{\\delta}")#text(" on ")#mi("{Q}")#text(". Writing ")#mi("{Q = \\{ qn+r: n \\in I^{\\prime}\\}}")#text(" for some interval ")#mi("{I^{\\prime} \\subset [0,N] \\cap {\\bf Z}}")#text(" of length ")#mi("{\\gg \\delta^{O(1)}}")#text(" and some ")#mi("{0 \\leq r < q}")#text(", we conclude that the polynomial ")#mi("{n \\mapsto P(qn+r)}")#text(" varies by at most ")#mi("{\\delta}")#text(" on ")#mi("{I^{\\prime}}")#text(". Taking ")#mi("{d^{th}}")#text(" order differences, we conclude that the ")#mi("{d^{th}}")#text(" coefficient of this polynomial is ")#mi("{O(\\delta^{-O(1)} / N^d)}")#text("; by the binomial theorem, this implies that ")#mi("{n \\mapsto P(qn+r)}")#text(" differs by at most ")#mi("{O(\\delta)}")#text(" on ")#mi("{I^{\\prime}}")#text(" from a polynomial of degree at most ")#mi("{d-1}")#text(". Iterating this, we conclude that the ")#mi("{i^{th}}")#text(" coefficient of ")#mi("{n \\mapsto P(qn+r)}")#text(" is ")#mi("{O(\\delta N^{-i})}")#text(" for ")#mi("{i=0,\\dots,d}")#text(", and the claim then follows by inverting the change of variables ")#mi("{n \\mapsto qn+r}")#text(" (and replacing ")#mi("{q}")#text(" with a larger quantity such as ")#mi("{q^d}")#text(" as necessary). ")#mi("\\Box")

#text("For future reference we also record a higher degree version of the Vinogradov lemma.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Polynomial Vinogradov lemma)")]#text(" ")#metadata(none) <tao-dc48e543b04769cbe0ca>#text(" Let ")#mi("{I \\subset [-N,N] \\cap {\\bf Z}}")#text(" be a discrete interval for some ")#mi("{N \\geq 1}")#text(", and let ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" be a polynomial ")#mi("{P(n) = \\sum_{i \\leq d} \\alpha_i n^i}")#text(" of degree at most ")#mi("{d}")#text(" for some ")#mi("{d \\geq 1}")#text(" such that ")#tao-math("{\\left\\|P(n)\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(" for at least ")#mi("{\\delta N}")#text(" values of ")#mi("{n \\in I}")#text(", for some ")#mi("{0 < \\varepsilon, \\delta < 1}")#text(". Then either ")#metadata(none) <tao-676b8bb84ce7267dd520>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("N \\ll_d \\delta^{-O_d(1)}")]]



#text(" or ")#metadata(none) <tao-0480a93d2e9b094b89e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\varepsilon \\gg_d \\delta^{O_d(1)}")]]



#text(" or else there is a natural number ")#mi("{q \\ll_d \\delta^{-O_d(1)}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q \\alpha_i \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\delta^{-O(1)} \\varepsilon}{N^i}", block: true)]]

#text("for all ")#mi("{i=0,\\dots,d}")#text(".")
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{d}")#text(". For ")#mi("{d=1}")#text(" this follows from Lemma ")#link(<tao-f734ad4e842854d4f5c1>)[#text("3")]#text(" (noting that if ")#tao-math("{\\left\\|P(n)\\right\\|_{{\\bf R}/{\\bf Z}}, \\left\\|P(n_0)\\right\\|_{{\\bf R}/Z} \\leq \\varepsilon}", block: false)#text(" then ")#tao-math("{\\left\\|P(n)-P(n_0)\\right\\|_{{\\bf R}/{\\bf Z}} \\leq 2\\varepsilon}", block: false)#text("), so suppose that ")#mi("{d \\geq 2}")#text(" and that the claim is already proven for ")#mi("{d-1}")#text(". We now allow all implied constants to depend on ")#mi("{d}")#text(".")

#text("For each ")#mi("{h \\in [-2N,2N] \\cap {\\bf Z}}")#text(", let ")#mi("{N_h}")#text(" denote the number of ")#mi("{n \\in [-N,N] \\cap {\\bf Z}}")#text(" such that ")#tao-math("{\\left\\| P(n+h)\\right\\|_{{\\bf R}/{\\bf Z}}, \\left\\|P(n)\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(". By hypothesis, ")#mi("{\\sum_{h \\in [-2N,2N] \\cap {\\bf Z}} N_h \\gg \\delta^2 N^2}")#text(", and clearly ")#mi("{N_h = O(N)}")#text(", so we must have ")#mi("{N_h \\gg \\delta^2 N}")#text(" for ")#mi("{\\gg \\delta^2 N}")#text(" choices of ")#mi("{h}")#text(". For each such ")#mi("{h}")#text(", we then have ")#tao-math("{\\left\\|P(n+h)-P(n)\\right\\|_{{\\bf R}/{\\bf Z}} \\leq 2\\varepsilon}", block: false)#text(" for ")#mi("{\\gg \\delta^2 N}")#text(" choices of ")#mi("{n \\in [-N,N] \\cap {\\bf Z}}")#text(", so by induction hypothesis, either ")#link(<tao-676b8bb84ce7267dd520>)[#text("(5)")]#text(" or ")#link(<tao-0480a93d2e9b094b89e0>)[#text("(6)")]#text(" holds, or else for ")#mi("{\\gg \\delta^{O(1)} N}")#text(" choices of ")#mi("{h \\in [-2N,2N] \\cap {\\bf Z}}")#text(", there is a natural number ")#mi("{q_h \\ll \\delta^{-O(1)}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q_h \\alpha_{i,h} \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\delta^{-O(1)} \\varepsilon}{N^i}", block: true)]]

#text("for ")#mi("{i=1,\\dots,d-1}")#text(", where ")#mi("{\\alpha_{i,h}}")#text(" are the coefficients of the degree ")#mi("{d-1}")#text(" polynomial ")#mi("{n \\mapsto P(n+h)-P(n)}")#text(". We may of course assume it is the latter which holds. By the pigeonhole principle we may take ")#mi("{q_h= q}")#text(" to be independent of ")#mi("{h}")#text(".")

#text("Since ")#mi("{\\alpha_{d-1,h} = dh \\alpha_d}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| qd h \\alpha_d \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\delta^{-O(1)} \\varepsilon}{N^{d-1}}", block: true)]]

#text("for ")#mi("{\\gg \\delta^{O(1)} N}")#text(" choices of ")#mi("{h}")#text(", so by Lemma ")#link(<tao-f734ad4e842854d4f5c1>)[#text("3")]#text(", either ")#link(<tao-676b8bb84ce7267dd520>)[#text("(5)")]#text(" or ")#link(<tao-0480a93d2e9b094b89e0>)[#text("(6)")]#text(" holds, or else (after increasing ")#mi("{q}")#text(" as necessary) we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q \\alpha_d \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\delta^{-O(1)} \\varepsilon}{N^d}.", block: true)]]

#text("We can again assume it is the latter that holds. This implies that ")#mi("{q \\alpha_{d-2,h} = (d-1) h \\alpha_{d-1} + O( \\delta^{-O(1)} \\varepsilon / N^{d-2} )}")#text(" modulo ")#mi("{1}")#text(", so that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q(d-1) h \\alpha_{d-1} \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\delta^{-O(1)} \\varepsilon}{N^{d-2}}", block: true)]]

#text("for ")#mi("{\\gg \\delta^{O(1)} N}")#text(" choices of ")#mi("{h}")#text(". Arguing as before and iterating, we obtain the claim. ")#mi("\\Box")

#text("The above results also extend to higher dimensions. Here is the higher dimensional version of Proposition ")#link(<tao-60c64a02004a92cca70b>)[#text("4")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Multidimensional Weyl exponential sum estimate, inverse form)")]#text(" ")#metadata(none) <tao-60e0e4a47ce198e8bb25>#text(" Let ")#mi("{k \\geq 1}")#text(" and ")#mi("{N_1,\\dots,N_k \\geq 1}")#text(", and let ")#mi("{Q_i \\subset {\\bf Z}}")#text(" be arithmetic progressions of length at most ")#mi("{N_i}")#text(" for each ")#mi("{i=1,\\dots,k}")#text(". Let ")#mi("{P: {\\bf Z}^k \\rightarrow {\\bf R}/{\\bf Z}}")#text(" be a polynomial of degrees at most ")#mi("{d_1,\\dots,d_k}")#text(" in each of the ")#mi("{k}")#text(" variables ")#mi("{n_1,\\dots,n_k}")#text(" separately. If")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N_1 \\dots N_k} \\left|\\sum_{n \\in Q_1 \\times \\dots \\times Q_k} e(P(n))\\right| \\geq \\delta", block: true)]]

#text("for some ")#mi("{\\delta > 0}")#text(", then there exists a subprogression ")#mi("{Q^{\\prime}_i}")#text(" of ")#mi("{Q_i}")#text(" with ")#tao-math("{\\left|Q^{\\prime}_i\\right| \\gg_{k,d_1,\\dots,d_k} \\delta^{O_{k,d_1,\\dots,d_k}(1)} N_i}", block: false)#text(" for each ")#mi("{i=1,\\dots,k}")#text(" such that ")#mi("{P}")#text(" varies by at most ")#mi("{\\delta}")#text(" on ")#mi("{Q^{\\prime}_1 \\times \\dots \\times Q^{\\prime}_k}")#text(".")
]

#text("A much more general statement, in which the polynomial phase ")#mi("{n \\mapsto e(P(n))}")#text(" is replaced by a nilsequence, and in which one does not necessarily assume the exponential sum is small, is given in Theorem 8.6 of ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("this paper of Ben Green and myself")]#text(", but it involves far more notation to even state properly.")

#emph[#text("Proof:")]#text(" We induct on ")#mi("{k}")#text(". The case ")#mi("{k=1}")#text(" was established in Proposition ")#link(<tao-3f14d6277c6e981dcbd1>)[#text("5")]#text(", so we assume that ")#mi("{k \\geq 2}")#text(" and that the claim has already been proven for ")#mi("{k-1}")#text(". To simplify notation we allow all implied constants to depend on ")#mi("{k,d_1,\\dots,d_k}")#text(". We may assume that ")#mi("{\\delta \\leq c}")#text(" for some small ")#mi("{c>0}")#text(" depending only on ")#mi("{k,d_1,\\dots,d_k}")#text(".")

#text("By a linear change of variables, we may assume that ")#mi("{Q_i \\subset [0,N_i] \\cap {\\bf Z}}")#text(" for all ")#mi("{i=1,\\dots,k}")#text(".")

#text("We write ")#mi("{n^{\\prime} := (n_1,\\dots,n_{k-1})}")#text(". First suppose that ")#mi("{N_k = O(\\delta^{-O(1)})}")#text(". Then by the pigeonhole principle we can find ")#mi("{n_k \\in I_k}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N_1 \\dots N_{k-1}} \\left|\\sum_{n^{\\prime} \\in Q_1 \\times \\dots \\times Q_{k-1}} e(P(n^{\\prime},n_k))\\right| \\geq \\delta", block: true)]]

#text("and the claim then follows from the induction hypothesis. Thus we may assume that ")#mi("{N_k \\geq \\delta^{-C}}")#text(" for some large ")#mi("{C}")#text(" depending only on ")#mi("{k,d_1,\\dots,d_k}")#text(". Similarly we may assume that ")#mi("{N_i \\geq \\delta^{-C}}")#text(" for all ")#mi("{i=1,\\dots,k}")#text(".")

#text("By the triangle inequality, we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{N_1 \\dots N_k} \\sum_{n_k \\in Q_k} \\left|\\sum_{n^{\\prime} \\in Q_1 \\times \\dots \\times Q_{k-1}} e(P(n^{\\prime},n_k))\\right| \\geq \\delta.", block: true)]]

#text("The inner sum is ")#mi("{O(N_k)}")#text(", and the outer sum has ")#mi("{O(N_1 \\dots N_{k-1})}")#text(" terms. Thus, for ")#mi("{\\gg \\delta N_1 \\dots N_{k-1}}")#text(" choices of ")#mi("{n^{\\prime} \\in Q_1 \\times \\dots \\times Q_{k-1}}")#text(", one has ")#metadata(none) <tao-af1a411ed6a2fdf0eddd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\frac{1}{N_k} \\left|\\sum_{n_k \\in Q_k} e(P(n^{\\prime},n_k))\\right| \\gg \\delta.", block: true)]]



#text(" We write")

#align(center)[#tao-fit-display[#mitex("P(n^{\\prime},n_k) = \\sum_{i_k \\leq d_k} P_{i_k}(n^{\\prime}) n_k^i")]]

#text("for some polynomials ")#mi("{P_{i_k}: {\\bf Z}^{k-1} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" of degrees at most ")#mi("{d_1,\\dots,d_{k-1}}")#text(" in the variables ")#mi("{n_1,\\dots,n_{k-1}}")#text(". For each ")#mi("{n^{\\prime}}")#text(" obeying ")#link(<tao-af1a411ed6a2fdf0eddd>)[#text("(7)")]#text(", we apply Corollary ")#link(<tao-3f14d6277c6e981dcbd1>)[#text("5")]#text(" to conclude that there exists a natural number ")#mi("{q_{n^{\\prime}} \\ll \\delta^{-O(1)}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q_{n^{\\prime}} P_{i_k}(n^{\\prime}) \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\delta^{-O(1)} / N_k^{i_k}", block: true)]]

#text("for ")#mi("{i_k=1,\\dots,d_k}")#text(" (the claim also holds for ")#mi("{i_k=0}")#text(" but we discard it as being trivial). By the pigeonhole principle, there thus exists a natural number ")#mi("{q \\ll \\delta^{-O(1)}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q P_{i_k}(n^{\\prime}) \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\delta^{-O(1)} / N_k^{i_k}", block: true)]]

#text("for all ")#mi("{i_k=1,\\dots,d_k}")#text(" and for ")#mi("{\\gg \\delta^{O(1)} N_1 \\dots N_{k-1}}")#text(" choices of ")#mi("{n^{\\prime} \\in Q_1 \\times \\dots \\times Q_{k-1}}")#text(". If we write")

#align(center)[#tao-fit-display[#mitex("P_{i_k}(n^{\\prime}) = \\sum_{i_{k-1} \\leq d_{k-1}} P_{i_{k-1},i_k}(n_1,\\dots,n_{k-2}) n_{k-1}^{i_{k-1}},")]]

#text("where ")#mi("{P_{i_{k-1},i_k}: {\\bf Z}^{k-2} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a polynomial of degrees at most ")#mi("{d_1,\\dots,d_{k-2}}")#text(", then for ")#mi("{\\gg \\delta^{O(1)} N_1 \\dots N_{k-2}}")#text(" choices of ")#mi("{(n_1,\\dots,n_{k-2}) \\in Q_1 \\times \\dots \\times Q_{k-2}}")#text(" we then have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i_{k-1} \\leq d_{k-1}} q P_{i_{k-1},i_k}(n_1,\\dots,n_{k-2}) n_{k-1}^{i_{k-1}} \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\delta^{-O(1)} / N_k^{i_k}.", block: true)]]

#text("Applying Lemma ")#link(<tao-dc48e543b04769cbe0ca>)[#text("6")]#text(" in the ")#mi("{n_{k-1}}")#text(" and the largeness hypotheses on the ")#mi("{N_i}")#text(" (and also the assumption that ")#mi("{i_k \\geq 1}")#text(") we conclude (after enlarging ")#mi("{q}")#text(" as necessary, and pigeonholing to keep ")#mi("{q}")#text(" independent of ")#mi("{n_1,\\dots,n_{k-2}}")#text(") that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q P_{i_{k-1},i_k}(n_1,\\dots,n_{k-2}) \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\delta^{-O(1)}}{N_{k-1}^{i_{k-1}} N_k^{i_k}}", block: true)]]

#text("for all ")#mi("{i_{k-1}=0,\\dots,d_{k-1}}")#text(" (note that we now include that ")#mi("{i_{k-1}=0}")#text(" case, which is no longer trivial) and for ")#mi("{\\gg \\delta^{O(1)} N_1 \\dots N_{k-2}}")#text(" choices of ")#mi("{(n_1,\\dots,n_{k-2}) \\in Q_1 \\times \\dots \\times Q_{k-2}}")#text(". Iterating this, we eventually conclude (after enlarging ")#mi("{q}")#text(" as necessary) that ")#metadata(none) <tao-b0e9dc663382addcc0d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| q \\alpha_{i_1,\\dots,i_k} \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\delta^{-O(1)}}{N_1^{i_1} \\dots N_k^{i_k}}", block: true)]]



#text(" whenever ")#mi("{i_j \\in \\{0,\\dots,d_j\\}}")#text(" for ")#mi("{j=1,\\dots,k}")#text(", with ")#mi("{i_k}")#text(" nonzero. Permuting the indices, and observing that the claim is trivial for ")#mi("{(i_1,\\dots,i_k) = (0,\\dots,0)}")#text(", we in fact obtain ")#link(<tao-b0e9dc663382addcc0d7>)[#text("(8)")]#text(" for all ")#mi("{(i_1,\\dots,i_k) \\in \\{0,\\dots,d_1\\} \\times \\dots \\times \\{0,\\dots,d_k\\}}")#text(", at which point the claim easily follows by taking ")#mi("{Q^{\\prime}_j := \\{ qn_j: n_j \\leq \\delta^C N_j\\}}")#text(" for each ")#mi("{j=1,\\dots,k}")#text(". ")#mi("\\Box")

#text("An inspection of the proof of the above result (or alternatively, by combining the above result again with many applications of Lemma ")#link(<tao-dc48e543b04769cbe0ca>)[#text("6")]#text(") reveals the following general form of Proposition ")#link(<tao-60c64a02004a92cca70b>)[#text("4")]#text(", which was posed as Exercise 17 in ")#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")[#text("this previous blog post")]#text(", but had a slight misprint in it (it did not properly treat the possibility that some of the ")#mi("{N_j}")#text(" could be small) and was a bit trickier to prove than anticipated (in fact, the reason for this post was that I was asked to supply a more detailed solution for this exercise):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8 (Multidimensional Weyl exponential sum estimate, inverse form, II)")]#text(" Let ")#mi("{k \\geq 1}")#text(" be an natural number, and for each ")#mi("{j=1,\\dots,k}")#text(", let ")#mi("{I_j \\subset [0,N_j]_{\\bf Z}}")#text(" be a discrete interval for some ")#mi("{N_j \\geq 1}")#text(". Let")

#align(center)[#tao-fit-display[#mitex("P(n_1,\\dots,n_k) = \\sum_{i_1 \\leq d_1, \\dots, i_k \\leq d_k} \\alpha_{i_1,\\dots,i_k} n_1^{i_1} \\dots n_k^{i_k}")]]

#text("be a polynomial in ")#mi("{k}")#text(" variables of multidegrees ")#mi("{d_1,\\dots,d_k \\geq 0}")#text(" for some ")#mi("{\\alpha_{i_1,\\dots,i_k} \\in {\\bf R}/{\\bf Z}}")#text(". If ")#metadata(none) <tao-7dd7fe99a51b25537f5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\frac{1}{N_1 \\dots N_k} \\left|\\sum_{n \\in I_1 \\times \\dots \\times I_k} e(P(n))\\right| \\geq \\delta", block: true)]]



#text(" for some ")#mi("{\\delta > 0}")#text(", then either ")#metadata(none) <tao-d1fee3a146636cbf458f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("N_j \\ll_{k,d_1,\\dots,d_k} \\delta^{-O_{k,d_1,\\dots,d_k}(1)}")]]



#text(" for some ")#mi("{1 \\leq j \\leq d_k}")#text(", or else there is a natural number ")#mi("{q \\ll_{k,d_1,\\dots,d_k} \\delta^{-O_{k,d_1,\\dots,d_k}(1)}}")#text(" such that ")#metadata(none) <tao-3d9fc4bde7ceef058d65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\| q\\alpha_{i_1,\\dots,i_k} \\right\\|_{{\\bf R}/{\\bf Z}} \\ll_{k,d_1,\\dots,d_k} \\delta^{-O_d(1)} N_1^{-i_1} \\dots N_k^{-i_k}", block: true)]]



#text(" whenever ")#mi("{i_j \\leq d_j}")#text(" for ")#mi("{j=1,\\dots,k}")#text(".")
]

#text("Again, the factor of ")#mi("{N_1^{-i_1} \\dots N_k^{-i_k}}")#text(" is natural in this bound. In the ")#mi("{k=1}")#text(" case, the option ")#link(<tao-d1fee3a146636cbf458f>)[#text("(10)")]#text(" may be deleted since ")#link(<tao-3d9fc4bde7ceef058d65>)[#text("(11)")]#text(" trivially holds in this case, but this simplification is no longer available for ")#mi("{k>1}")#text(" since one needs ")#link(<tao-d1fee3a146636cbf458f>)[#text("(10)")]#text(" to hold for ")#emph[#text("all")]#text(" ")#mi("{j}")#text(" (not just one ")#mi("{j}")#text(") to make ")#link(<tao-3d9fc4bde7ceef058d65>)[#text("(11)")]#text(" completely trivial. Indeed, the above proposition fails for ")#mi("{k \\geq 2}")#text(" if one removes ")#link(<tao-d1fee3a146636cbf458f>)[#text("(10)")]#text(" completely, as can be seen for instance by inspecting the exponential sum ")#mi("{\\sum_{n_1 \\in \\{0,1\\}} \\sum_{n_2 \\in [1,N] \\cap {\\bf Z}} e( \\alpha n_1 n_2)}")#text(", which has size comparable to ")#mi("{N}")#text(" regardless of how irrational ")#mi("{\\alpha}")#text(" is.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/#comment-458000")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2015")])]

#text("[…] Show that either one has for some , or else there exists a natural number such that for all . (Note: this is a rather tricky exercise, and is only recommended for students who have mastered the arguments needed to solve the one-dimensional version of this exercise from Exercise 16. A solution is given in this blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/#comment-458003")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2015")])]

#text("I think Equation (2) of Lemma 2 is missing the subtraction. It should be P(n+h)-P(n).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/#comment-458019")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2015")])]

#text("In the beginning of the proof of Lemma 1, ")#mi("N^{\\prime}\\leq 1")#text(" should be ")#mi("N^{\\prime}\\geq 1")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/#comment-458021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2015")])]

#text("In proposition 8, can (10), (11) be made effective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/#comment-458025")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2015")])]

#text("Yes, all the estimates here are effective, though the explicit constants will be quite poor. To get the best exponents one should probably go through the Vinogradov mean value theorem, as was done in the one-dimensional case in the Wooley reference given in the post, though to my knowledge this argument has not yet been extended to the multidimensional setting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03986b1625abac921719e979bb3eeaffbe4bc4d9a984bed6b78e03ec8840cfb0-1bf3d4daad903a9940fb682fba7835b56f833f6923a2da116288a13acd1d96ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Prendiville")]], [#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/#comment-458126")[#strong[#text("Sean Prendiville")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2015")])]

#text("There is some history of multidimensional versions of the Vinogradov mean value theorem, an older reference being ")#link("http://www.ams.org/mathscinet-getitem?mr=608411")[#text("http://www.ams.org/mathscinet-getitem?mr=608411")]#text(".")

#text("A multidimensional analogue of Wooley’s efficient congruencing method has been developed in ")#link("http://arxiv.org/pdf/1205.6331")[#text("http://arxiv.org/pdf/1205.6331")]#text(" . This yields associated Weyl sum estimates (Theorem 1.3).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/#comment-458167")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2015")])]

#text("Are there such equidistribution results for more general groups that the circle ? Thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/#comment-458169")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2015")])]

#text("For polynomial orbits in nilmanifolds, this is the main focus of ")#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/")[#text("this paper of Ben Green and myself")]#text(". For orbits of unipotently generated groups on homogeneous spaces, there are the deep theorems of Ratner and later authors that describe the possible ways in which orbits can equidistribute, but most of the theorems are not quantitative (but there is work in this direction, for instance ")#link("http://arxiv.org/abs/0708.4040")[#text("by Einseidler, Margulis, and Venkatesh")]#text(" for actions of semisimple groups). Once one leaves the unipotently generated regime, though, the problem becomes much more difficult (one no longer expects the limiting distribution to be nicely algebraic in general).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/#comment-458188")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2015")])]

#text("Here is a slightly more “square” interpretation of the Vinogradov lemma")#linebreak()#text(" ")#link("http://i.imgur.com/x6CEe08.gif")[#image("../assets/b3841d1b12f31f367dc9f748c4b4af86920799311fbbddb1c81cddcc7c934212-faa24ec881e6040655c187a681d6dc496eb8aa41e1bd0652a180b3a40b457187.png", width: 90%)]
]
