// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/
// Converted to Typst by tao2typ: "2026-10-14T16:35:54.537974+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Reading seminar: “Stable group theory and approximate subgroups”, by Ehud Hrushovski", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Reading seminar: “Stable group theory and approximate subgroups”, by Ehud Hrushovski")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of my favorite open problems, which I have ")#link("https://terrytao.wordpress.com/2007/03/02/open-question-noncommutative-freiman-theorem/")[#text("blogged about in the past")]#text(", is that of establishing (or even correctly formulating) a non-commutative analogue of Freiman’s theorem. Roughly speaking, the question is this: given a finite set ")#mi("{X}")#text(" in a non-commutative group ")#mi("{G}")#text(" which is of ")#emph[#text("small doubling")]#text(" in the sense that the product set ")#mi("{X \\cdot X := \\{ xy: x, y \\in X \\}}")#text(" is not much larger than ")#mi("{X}")#text(" (e.g. ")#tao-math("{\\left|X \\cdot X\\right| \\leq K\\left|X\\right|}", block: false)#text(" for some ")#mi("{K = O(1)}")#text("), what does this say about the structure of ")#mi("{X}")#text("? (For various technical reasons one may wish to replace small doubling by, say, small tripling (i.e. ")#tao-math("{\\left|X \\cdot X \\cdot X\\right| = O( \\left|X\\right| )}", block: false)#text("), and one may also wish to assume that ")#mi("{X}")#text(" contains the identity and is symmetric, ")#mi("{X^{-1} = X}")#text(", but these are relatively minor details.)")

#text("Sets of small doubling (or tripling), etc. can be thought of as “approximate groups”, since groups themselves have a doubling constant ")#tao-math("{K := \\left|X \\cdot X\\right|/\\left|X\\right|}", block: false)#text(" equal to one. Another obvious example of an approximate group is that of an arithmetic progression in an additive group, and more generally of a ball (in the word metric) in a nilpotent group of bounded rank and step. It is tentatively conjectured that in fact all examples can somehow be “generated” out of these basic examples, although it is not fully clear at present what “generated” should mean.")

#text("A weaker conjecture along the same lines is that if ")#mi("{X}")#text(" is a set of small doubling, then there should be some sort of “pseudo-metric” ")#mi("{\\rho}")#text(" on ")#mi("{G}")#text(" which is left-invariant, and for which ")#mi("{X}")#text(" is controlled (in some suitable sense) by the unit ball in this metric. (For instance, if ")#mi("{X}")#text(" was a subgroup of ")#mi("{G}")#text(", one would take the metric which identified all the left cosets of ")#mi("{X}")#text(" to a point, but was otherwise a discrete metric; if ")#mi("{X}")#text(" were a ball in a nilpotent group, one would use some rescaled version of the word metric, and so forth.) Actually for technical reasons one would like to work with a slightly weaker notion than a pseudo-metric, namely a ")#emph[#text("Bourgain system")]#text(", but let us again ignore this technicality here.")

#text("Recently, using some powerful tools from model theory combined with the theory of topological groups, Ehud Hrushovski has ")#link("http://arxiv.org/abs/0909.2190")[#text("apparently achieved some breakthroughs on this problem")]#text(", obtaining new structural control on sets of small doubling in arbitrary groups that was not previously accessible to the known combinatorial methods. The precise results are technical to state, but here are informal versions of two typical theorems. The first applies to sets of small tripling in an arbitrary group:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" (Rough version of Hrushovski Theorem 1.1) Let ")#mi("{X}")#text(" be a set of small tripling, then one can find a long sequence of nested symmetric sets ")#mi("{X_1 \\supset X_2 \\supset X_3 \\supset \\ldots}")#text(", all of size comparable to ")#mi("{X}")#text(" and contained in ")#mi("{(X^{-1} X)^2}")#text(", which are somewhat closed under multiplication in the sense that ")#mi("{X_i \\cdot X_i \\subset X_{i-1}}")#text(" for all ")#mi("{i > 1}")#text(", and which are fairly well closed under commutation in the sense that ")#mi("{[X_i, X_j] \\subset X_{i+j-1}}")#text(". (There are also some additional statements to the effect that the ")#mi("{X_n}")#text(" efficiently cover each other, and also cover ")#mi("{X}")#text(", but I will omit those here.)")
]

#text("This nested sequence is somewhat analogous to a Bourgain system, though it is not quite the same notion.")

#text("If one assumes that ")#mi("{X}")#text(" is “perfect” in a certain sense, which roughly means that there is no non-trivial abelian quotient, then one can do significantly better:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" (Rough version of Hrushovski Corollary 1.2) Let ")#mi("{X_0}")#text(" be a set of small tripling, let ")#mi("{X := X_0^{-1} X_0}")#text(", and suppose that for almost all ")#mi("{l}")#text("-tuples ")#mi("{a_1, \\ldots, a_l \\in X}")#text(" (where ")#mi("{l=O(1)}")#text("), the conjugacy classes ")#mi("{a_i^X := \\{ x^{-1} ax: x \\in X \\}}")#text(" generate most of ")#mi("{X}")#text(" in the sense that ")#tao-math("{\\left|a_1^X \\cdot \\ldots \\cdot a_l^X\\right| \\gg \\left|X\\right|}", block: false)#text(". Then a large part of ")#mi("{X}")#text(" is contained in a subgroup of size comparable to ")#mi("{X}")#text(".")
]

#text("Note that if one quotiented out by the commutator ")#mi("{[X,X]}")#text(", then all of the conjugacy classes ")#mi("{a_i^X}")#text(" would collapse to points. So the hypothesis here is basically a strong quantitative assertion to the effect that the commutator ")#mi("{[X,X]}")#text(" is extremely large, and rapidly fills out most of ")#mi("{X}")#text(" itself.")

#text("Here at UCLA, a group of logicians and I (consisting of ")#link("http://www.math.ucla.edu/~matthias/")[#text("Matthias Aschenbrenner")]#text(", ")#link("http://www.math.ucla.edu/~isaac/")[#text("Isaac Goldbring")]#text(", ")#link("http://www.math.ucla.edu/~greg/")[#text("Greg Hjorth")]#text(", ")#link("http://www.math.ucla.edu/~hpt/")[#text("Henry Towsner")]#text(", ")#link("http://www.math.ucla.edu/~anush/")[#text("Anush Tserunyan")]#text(", and possibly others) have just started a weekly reading seminar to come to grips with the various combinatorial, logical, and group-theoretic notions in Hrushovski’s paper, of which we only have a partial understanding at present. The seminar is a physical one, rather than an online one, but I am going to try to put some notes on the seminar on this blog as it progresses, as I know that there are a couple of other mathematicians who are interested in these developments.")

#text("So far there have been two meetings of the seminar. In the first, I surveyed the state of knowledge of the noncommutative Freiman theorem, covering broadly the material in ")#link("https://terrytao.wordpress.com/2007/03/02/open-question-noncommutative-freiman-theorem/")[#text("my previous blog post")]#text(". In the second meeting, Isaac reviewed some key notions of model theory used in Hrushovski’s paper, in particular the notions of definability and type, which I will review below. It is not yet clear how these are going to be connected with the combinatorial side of things, but this is something which we will hopefully develop in future seminars. The near-term objective is to understand the statement of the main theorem on the model-theoretic side (Theorem 3.4 of Hrushovski), and then understand some of its easier combinatorial consequences, before going back and trying to understand the ")#emph[#text("proof")]#text(" of that theorem.")

#text("[")#emph[#text("Update")]#text(", Oct 19: Given the level of interest in this paper, readers are encouraged to discuss any aspect of that paper in the comments below, even if they are not currently being covered by the UCLA seminar.]")

#metadata(none) <tao-51b446f093f4f8941cd2>

#heading(level: 1)[#strong[#text(" — 1. Definability — ")]]

#link("http://en.wikipedia.org/wiki/Model_theory")[#text("Model theory")]#text(" studies ")#emph[#text("models")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Structure_(mathematical_logic)")[#text("structures")]#text(") of ")#link("http://en.wikipedia.org/wiki/Formal_language")[#text("languages")]#text(". For our purposes, a language ")#mi("{L}")#text(" consists of the basic symbols in logic (the boolean connectives, parentheses, the quantifiers, variables, and the equals sign) plus some additional relation and function symbols. For instance, the language of groups could be denoted as ")#mi("{(e, \\cdot, \\cdot^{-1})}")#text(", since one needs the identity ")#mi("{e}")#text(" (which can be thought of as a ")#mi("{0}")#text("-ary function, i.e. a constant symbol), the multiplication ")#mi("{\\cdot}")#text(" (a binary function), and the inverse function ")#mi("{\\cdot^{-1}}")#text(". The language of rings could be denoted as ")#mi("{(0, 1, +, -, \\times)}")#text(", the language of ordered rings could be denoted as ")#mi("{(0, 1, +, -, \\times, <)}")#text(", and so forth. To avoid cluttering the discussion with irrelevant formalities, we will use all the usual conventions of mathematical notation (e.g. using ")#mi("{x \\neq y}")#text(" as shorthand for ")#mi("{\\neg (x = y)}")#text(", using ")#mi("{x^3}")#text(" as short-hand for ")#mi("{x \\cdot x \\cdot x}")#text(", etc.). In the applications to additive combinatorics, the language ")#mi("{L}")#text(" will either be the language of groups, or an extension thereof.")

#text("A ")#emph[#text("structure")]#text(" ")#mi("{M}")#text(" for a language ")#mi("{L}")#text(" consists of some domain (which, by abuse of notation, we will also call ")#mi("{M}")#text("), together with an interpretation of the various relations and functions of ")#mi("{L}")#text(" as relations or functions on ")#mi("{M}")#text(". For instance, every group ")#mi("{G}")#text(" is naturally a structure for the language of groups. (Indeed, one does not need ")#mi("{G}")#text(" to obey the group axioms in order to be a structure for this language; as long as ")#mi("{G}")#text(" contains a distinguished element ")#mi("{e}")#text(", some binary operation ")#mi("{\\cdot: G \\times G \\rightarrow G}")#text(", and some unary operation ")#mi("{\\cdot^{-1}: G \\rightarrow G}")#text(", it is a structure.)")

#text("Given a sentence ")#mi("{\\phi}")#text(" (i.e. a formula with no free variables) in ")#mi("{L}")#text(", a structure ")#mi("{M}")#text(" can interpret that sentence and give it a truth value in the usual manner; if it gives ")#mi("{\\phi}")#text(" a true value, we write ")#mi("{M \\models \\phi}")#text(". For instance, in the language of groups, if ")#mi("{\\phi}")#text(" is the associativity sentence ")#mi("{\\forall x,y,z: (x \\cdot y) \\cdot z = x \\cdot (y \\cdot z)}")#text(", then ")#mi("{M \\models \\phi}")#text(" will hold if ")#mi("{M}")#text(" is a group, but need not hold for other structures in the language of groups.")

#text("Given a formula ")#mi("{\\phi(x_1,\\ldots,x_n)}")#text(" with ")#mi("{n}")#text(" free variables in ")#mi("{L}")#text(", ")#mi("{M}")#text(" cannot interpret that formula directly, but given any values ")#mi("{a_1,\\ldots,a_n \\in M}")#text(" for the free variables, ")#mi("{M}")#text(" can assign a truth value to the substituted formula ")#mi("{\\phi(a_1,\\ldots,a_n)}")#text(", and we write ")#mi("{M \\models \\phi(a_1,\\ldots,a_n)}")#text(" if that sentence is true. The set")

#align(center)[#tao-fit-display[#mitex("\\{ (a_1,\\ldots,a_n) \\in M^n: M \\models \\phi(a_1,\\ldots,a_n) \\}")]]

#text("is then referred to as a ")#emph[#mi("{\\emptyset}")#text("-definable")]#text(" subset of ")#mi("{M^n}")#text(", defined by the formula ")#mi("{\\phi(x_1,\\ldots,x_n)}")#text(". For instance, in a group ")#mi("{G}")#text(", the set ")#mi("{\\{ a \\in G: a^2 = e; a \\neq e \\}}")#text(" of elements of order two is a ")#mi("{\\emptyset}")#text("-definable set, defined using the formula")

#align(center)[#tao-fit-display[#mitex("\\phi(x) := `` x^2 = e \\wedge x \\neq e ^{\\prime\\prime}.")]]

#text("Most subsets ")#mi("{M^n}")#text(" in a structure are not ")#mi("{\\emptyset}")#text("-definable. However one can increase the ability to define sets by adding constants. Given a set ")#mi("{A \\subset M}")#text(", we can ")#emph[#text("extend")]#text(" the language ")#mi("{L}")#text(" to a new language ")#mi("{L(A)}")#text(" by adding a constant symbol ")#mi("{c_a}")#text(" for each element ")#mi("{a \\in A}")#text(" (actually we shall usually abuse notation and write ")#mi("{a}")#text(" for ")#mi("{c_a}")#text("). The structure ")#mi("{M}")#text(" similarly extends to a structure ")#mi("{M(A)}")#text(" for ")#mi("{L(A)}")#text(" which has the same domain as ")#mi("{M}")#text(", and interprets all existing symbols in ")#mi("{L}")#text(" the same way, but also interprets the constant symbol ")#mi("{c_a}")#text(" as ")#mi("{a}")#text(". A subset of ")#mi("{M^n}")#text(" is said to be ")#emph[#mi("{A}")#text("-definable")]#text(" if it is ")#mi("{\\emptyset}")#text("-definable in ")#mi("{M(A)}")#text(", i.e. there is a formula ")#mi("{\\phi(x_1,\\ldots,x_n)}")#text(" which can use constants from ")#mi("{A}")#text(" to define the set.")

#text("For instance, in the language of rings, and in the structure ")#mi("{{\\mathbb R}}")#text(" given by the real line (which is, of course, a ring), the singleton set ")#mi("{\\{ \\sqrt{\\pi} \\}}")#text(" is not ")#mi("{\\emptyset}")#text("-definable, but it is ")#mi("{\\{ \\pi \\}}")#text("-definable, since one can use the formula “")#mi("{x^2 = \\pi \\wedge \\exists y: x=y^2}")#text("” to define it.")

#text("Even when one uses the entire domain ")#mi("{M}")#text(" as a set of constants, one cannot always define every single set. For instance, in the empty language (which has the basic notion of equality, but no other relations or symbols), and in an infinite model ")#mi("{M}")#text(", the only ")#mi("{M}")#text("-definable subsets of ")#mi("{M}")#text(" turn out to be the finite and ")#link("http://en.wikipedia.org/wiki/Cofinite")[#text("cofinite")]#text(" subsets of ")#mi("{M}")#text("; one cannot for instance define the even integers from the integers from a single first-order formula in the empty language, even if one is allowed to use all the integers as constant symbols. (Of course, one can do so once one has the addition or multiplication symbol available.)")

#text("Another example: in the language of fields (or rings), if ")#mi("{M}")#text(" is an algebraically closed field, then the ")#mi("{M}")#text("-definable sets are the boolean combinations of ")#link("http://en.wikipedia.org/wiki/Algebraic_set")[#text("algebraic sets")]#text("; this fact is closely related to ")#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")[#text("Hilbert’s nullstellensatz")]#text(" (and can be proven by ")#link("http://en.wikipedia.org/wiki/Quantifier_elimination")[#text("quantifier elimination")]#text("). Similarly, in the language of ordered rings, if ")#mi("{M}")#text(" is the real line, then the ")#mi("{M}")#text("-definable sets are the ")#link("http://en.wikipedia.org/wiki/Semialgebraic_set")[#text("semi-algebraic sets")]#text(", which is essentially a ")#link("http://en.wikipedia.org/wiki/Tarski%E2%80%93Seidenberg_theorem")[#text("famous result of Tarski and Seidenberg")]#text(". In particular, the one-dimensional ")#mi("{M}")#text("-definable sets are finite boolean combinations of half-lines, a property known as ")#link("http://en.wikipedia.org/wiki/O-minimal_theory")[#text("o-minimality")]#text(".")

#text("Sometimes it is necessary to leave the original structure ")#mi("{M}")#text(" for a larger structure ")#mi("{N}")#text(" that is an ")#link("http://en.wikipedia.org/wiki/Elementary_equivalence")[#text("elementary extension")]#text(" of ")#mi("{M}")#text(". What this means is that")

#list(
[#mi("{N}")#text(" is an extension of ")#mi("{M}")#text(" (thus the domain of ")#mi("{N}")#text(" includes the domain of ")#mi("{M}")#text(", and the interpretations of the relations and functions on ")#mi("{N}")#text(" and on ")#mi("{M}")#text(" agree on ")#mi("{M}")#text("); and")],
[#text("Every sentence (allowing constant symbols from ")#mi("{M}")#text(") that is true in ")#mi("{M}")#text(", is also true on ")#mi("{N}")#text(". (The converse implication is then also true by taking negations.)")]
)

#text("For instance, in the language of rings, the ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("non-standard reals")]#text(" are an elementary extension of the standard reals. On the other hand, the reals are not an elementary extension of the rationals, because there are formulae such as ")#mi("{\\not \\exists x: x^2=2}")#text(" which make sense and are true in the rationals, but not the reals.")

#text("Now for an important definition. Let ")#mi("{N}")#text(" be an elementary extension of ")#mi("{M}")#text(", let ")#mi("{A}")#text(" be a subset of ")#mi("{M}")#text(", and let ")#mi("{\\vec a = (a_1,\\ldots,a_n) \\in N^n}")#text(" be a tuple in ")#mi("{N}")#text(". The ")#emph[#text("type")]#text(" ")#mi("{tp(\\vec a/A)}")#text(" of ")#mi("{\\vec a}")#text(" over ")#mi("{A}")#text(" is the set of all formulae ")#mi("{\\phi(x_1,\\ldots,x_n)}")#text(" (using ")#mi("{A}")#text(" as constant symbols) which are satisfied by ")#mi("{\\vec a}")#text(":")

#align(center)[#tao-fit-display[#mitex("tp(\\vec a/A) := \\{ \\phi(x_1,\\ldots,x_n) \\in L(A): N \\models \\phi(a_1,\\ldots,a_n) \\}.")]]

#text("Informally, the type captures everything one can say in first-order logic about ")#mi("{\\vec a}")#text(" if one is only allowed to use the constant symbols ")#mi("{A}")#text(".")

#text("A ")#emph[#text("complete type")]#text(" over ")#mi("{A}")#text(" is a collection of formulae in ")#mi("{A}")#text(" which is the type of some tuple ")#mi("{\\vec a}")#text(" in some elementary extension ")#mi("{N}")#text(" of ")#mi("{M}")#text(". A ")#emph[#text("partial type")]#text(" ")#mi("{p}")#text(" over ")#mi("{A}")#text(" is a subset of a complete type over ")#mi("{A}")#text(", i.e. a collection of formulae involving ")#mi("{A}")#text(" which is satisfied by some ")#mi("{a}")#text(" in some elementary extension. In that case we say that ")#mi("{a}")#text(" ")#emph[#text("realises")]#text(" the partial type ")#mi("{p}")#text(", and write ")#mi("{a \\models p}")#text(".")

#text("For instance, each real number can be identified with a complete type over the rationals (using all the rationals as constants) in the language of totally ordered sets, by the ")#link("http://en.wikipedia.org/wiki/Dedekind_cut")[#text("Dedekind cut")]#text(" construction. However, there are additional complete types as well, such as those arising from infinitesimals.")

#text("By the ")#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/")[#text("completeness theorem")]#text(", a partial type is nothing more than a set of formulae of a given arity involving ")#mi("{A}")#text(" which is logically consistent with all the sentences in ")#mi("{A}")#text(" that are true in ")#mi("{M}")#text("; and a complete type is a partial type which is maximal (given any formula ")#mi("{\\phi}")#text(", either ")#mi("{\\phi}")#text(" or its negation lie in the complete type). One can view complete types as being ultrafilters on the language ")#mi("{L(A)}")#text(" (modulo equivalence by sentences that are true in ")#mi("{M}")#text(", i.e. modulo the ")#link("http://en.wikipedia.org/wiki/Theory_(mathematical_logic)")[#text("theory")]#text(" of ")#mi("{M}")#text(").")

#text("For instance, in the language of ordered sets, and with ")#mi("{M}")#text(" being the natural numbers, the collection of formulae ")#mi("{\\{ `` x > n^{\\prime\\prime}: n \\in {\\mathbb N} \\}}")#text(" in ")#mi("{L({\\mathbb N})}")#text(" cannot be satisfied in the natural numbers, but can be satisfied in elementary extensions of the natural numbers, e.g. the ordered set ")#mi("{{\\mathbb N} \\uplus {\\mathbb Z}}")#text(" or the non-standard natural numbers, and so is a partial type over ")#mi("{{\\mathbb N}}")#text(".")

#text("Thus we see that in order to realise a partial type, one may have to move to a larger structure, which can be inconvenient. There is a related inconvenience involving tuples ")#mi("{\\vec a, \\vec b \\in N^n}")#text(" in an elementary extension ")#mi("{n}")#text(" which are ")#emph[#text("elementarily indistinguishable")]#text(" over ")#mi("{A}")#text(" if ")#mi("{tp(\\vec a/A) = tp(\\vec b/A)}")#text(", i.e. there is no formula involving ")#mi("{A}")#text(" that can distinguish ")#mi("{\\vec a}")#text(" from ")#mi("{\\vec b}")#text(". One obvious way in which indistinguishability can occur is if there is an ")#emph[#text("automorphism")]#text(" ")#mi("{\\phi: N \\rightarrow N}")#text(" on ")#mi("{N}")#text(" that fixes ")#mi("{A}")#text(" (where an automorphism is defined as a bijection which preserves all the structures in the language) and maps ")#mi("{\\vec a}")#text(" to ")#mi("{\\vec b}")#text(", much as two elements of a field extension which are Galois conjugate to each other cannot be distinguished using polynomials in the base field. However, it is possible to have two elementary indistinguishable tuples ")#mi("{\\vec a, \\vec b}")#text(" in a structure ")#mi("{N}")#text(" for which no automorphism of ")#mi("{N}")#text(" exists that maps ")#mi("{\\vec a}")#text(" to ")#mi("{\\vec b}")#text(".")

#text("Here is a concrete example: we use the language of order, let ")#mi("{M=N}")#text(" be the rationals, and let ")#mi("{A}")#text(" be the set consisting of ")#mi("{\\{ -1/n: n \\in {\\mathbb N} \\} \\cup \\{1 + 1/n: n \\in {\\mathbb N} \\}}")#text(". Then ")#mi("{0}")#text(" and ")#mi("{1}")#text(" have the same type over ")#mi("{A}")#text(" (i.e. are elementarily indistinguishable), but there is no ")#mi("{A}")#text("-fixing automorphism that maps ")#mi("{0}")#text(" to ")#mi("{1}")#text(" because ")#mi("{0}")#text(" is the supremum of a subset of ")#mi("{A}")#text(", and ")#mi("{1}")#text(" is not. On the other hand, if one extends the rationals to contain non-standard rationals, then an automorphism becmomes possible.")

#text("More generally, whenever ")#mi("{\\vec a}")#text(" and ")#mi("{\\vec b}")#text(" are elementarily indistinguishable, one can always find an elementary extension ")#mi("{N^{\\prime}}")#text(" of ")#mi("{N}")#text(" (and hence of ")#mi("{M}")#text(") and an automorphism of ")#mi("{N^{\\prime}}")#text(" for which ")#mi("{\\vec a}")#text(" maps to ")#mi("{\\vec b}")#text(". (This appears to be some sort of swindle type argument, but I do not know the details.)")

#text("It is convenient to pre-empt all these issues of passing to an elementary extension by working with a ")#emph[#text("universal extension")]#text(" ")#mi("{{\\Bbb U}}")#text(" of ")#mi("{M}")#text(" with the following two properties:")

#list(
[#text("(i) (Saturation) If ")#mi("{A \\subset {\\Bbb U}}")#text(" has strictly smaller cardinality than ")#mi("{{\\Bbb U}}")#text(", then every partial type over ")#mi("{A}")#text(" is realisable in ")#mi("{{\\Bbb U}}")#text(" (no need to pass to a further extension); and")],
[#text("(ii) (Homogeneity) If ")#mi("{A}")#text(" is as above and ")#mi("{\\vec a, \\vec b \\in {\\Bbb U}^n}")#text(" are elementarily indistinguishable over ")#mi("{A}")#text(", then there is an automorphism of ")#mi("{{\\Bbb U}}")#text(" that maps ")#mi("{\\vec a}")#text(" to ")#mi("{\\vec b}")#text(" (so again, no need to pass to a further extension).")]
)

#text("I do not know fully how to obtain a saturated model (though it is standard in model theory textbooks); it does require some set-theoretic assumptions, such as the ")#link("http://en.wikipedia.org/wiki/Generalized_continuum_hypothesis#The_generalized_continuum_hypothesis")[#text("generalised continuum hypothesis")]#text(", or the existence of a ")#link("http://en.wikipedia.org/wiki/Inaccessible_cardinal")[#text("strongly inaccessible cardinal")]#text(", though in practice one does not need such an absurdly huge model because one usually only needs saturation for sets ")#mi("{A}")#text(" of much smaller cardinality (e.g. countable). For instance, given any uncountable ordinal ")#mi("{\\kappa}")#text(", one can obtain saturation for all ")#mi("{A}")#text(" of cardinality ")#mi("{\\kappa}")#text(" or less with a structure ")#mi("{{\\Bbb U}}")#text(" of cardinality ")#tao-math("{\\left|M\\right|^\\kappa}", block: false)#text(". It seems that for the combinatorial applications we will in fact only need ")#mi("{A}")#text(" and ")#mi("{M}")#text(" to be countable, though we have not yet checked this fully.")

#text("It turns out that (i) formally implies (ii). Here is a sketch of a proof: to build an automorphism ")#mi("{f: {\\Bbb U} \\rightarrow {\\Bbb U}}")#text(" that fixes ")#mi("{A}")#text(" and maps ")#mi("{\\vec a}")#text(" to ")#mi("{\\vec b}")#text(", we will greedily build up partial automorphisms ")#mi("{f_C: C \\rightarrow {\\Bbb U}}")#text(" that fix ")#mi("{A}")#text(" and map ")#mi("{\\vec a}")#text(" to ")#mi("{\\vec b}")#text(", where ")#mi("{C}")#text(" is a set of strictly smaller cardinality than ")#mi("{{\\Bbb U}}")#text(". By “partial automorphism”, we mean that if ")#mi("{c_1,\\ldots,c_n \\in C}")#text(", then ")#mi("{(f_C(c_1),\\ldots,f_C(c_n))}")#text(" has the same type over ")#mi("{A}")#text(" (or over any other subset of ")#mi("{C}")#text(") as ")#mi("{(c_1,\\ldots,c_n)}")#text(".")

#text("Clearly one can build a partial automorphism on the set ")#mi("{A \\cup \\{ \\vec a, \\vec b\\}}")#text(". By transfinite induction (and by well-ordering ")#mi("{{\\Bbb U}}")#text(" using the least ordinal with the cardinality of ")#mi("{{\\Bbb U}}")#text("), it then suffices to show that whenever one has a partial automorphism ")#mi("{f_C: C \\rightarrow {\\Bbb U}}")#text(", and an element ")#mi("{c}")#text(" outside of ")#mi("{C}")#text(", one can extend the automorphism to an automorphism ")#mi("{f_{C \\cup \\{c\\}}: C \\cup \\{c\\} \\rightarrow {\\Bbb U}}")#text(". But if one looks at the set of constraints that ")#mi("{d := f_{C \\cup \\{c\\}}(c)}")#text(" needs to satisfy (roughly, that any formula that is true for ")#mi("{c}")#text(" and ")#mi("{c_1,\\ldots,c_n \\in C}")#text(", must also be true for ")#mi("{d}")#text(" and ")#mi("{f(c_1),\\ldots,f(c_n) \\in C}")#text("), we see that any finite collection of these constraints is satisfiable (because it can be encoded as an existential sentence ")#mi("{\\exists d: \\ldots}")#text(" involving finitely many ")#mi("{f(c_1),\\ldots,f(c_n)}")#text(", which by the partial automorphism property of ")#mi("{f}")#text(" is equivalent to the corresponding (true) existential sentence ")#mi("{\\exists c: \\ldots}")#text(" involving ")#mi("{c_1,\\ldots,c_n}")#text("), and so by (i) it is realisable in ")#mi("{{\\Bbb U}}")#text(", and the claim follows.")

#text("Property (ii) has a nice consequence: a ")#mi("{{\\Bbb U}}")#text("-definable subset of ")#mi("{{\\Bbb U}^n}")#text(" is ")#mi("{A}")#text("-definable if and only if it is invariant under all automorphisms of ")#mi("{{\\Bbb U}}")#text(" that fix ")#mi("{A}")#text(".")

#text("Let’s now work in this universal model, with some set ")#mi("{A}")#text(" of constants. Every partial type ")#mi("{p}")#text(" (of some arity ")#mi("{n}")#text(") over ")#mi("{A}")#text(" defines a subset ")#mi("{\\{ \\vec a \\in {\\Bbb U}^n: \\vec a \\models p \\}}")#text(" of ")#mi("{{\\Bbb U}^n}")#text("; this is an intersection of ")#mi("{A}")#text("-definable sets (one for each formula in ")#mi("{p}")#text("), and is thus called a ")#mi("{\\bigwedge}")#text("-definable set over ")#mi("{A}")#text(". For instance, in the language of groups, if ")#mi("{A}")#text(" is a (possibly infinite) subset of a group ")#mi("{G}")#text(", the ")#emph[#text("centraliser")]#text(" ")#mi("{C(A) := \\{ g \\in G: ag=ga \\text{ for all } a \\in A \\}}")#text(" is a ")#mi("{\\bigwedge}")#text("-definable set over ")#mi("{A}")#text(", but is not ")#mi("{A}")#text("-definable in general. One can view ")#mi("{A}")#text("-definable sets as analogous to a base of ")#link("http://en.wikipedia.org/wiki/Clopen_set")[#text("clopen sets")]#text(" in topology, whereas ")#mi("{\\bigwedge}")#text("-definable sets are analogous to closed sets. Dually, we have the notion of a ")#mi("{\\bigvee}")#text("-definable set over ")#mi("{A}")#text(", which is the complement of a ")#mi("{\\bigwedge}")#text("-definable set over ")#mi("{A}")#text(", or equivalently the union of ")#mi("{A}")#text("-definable sets; this is the analogue of an open set. (For instance, ")#mi("{A}")#text(" is automatically ")#mi("{\\bigvee}")#text("-definable over ")#mi("{A}")#text(".)")

#text("Not every interesting object involving ")#mi("{A}")#text(" is ")#mi("{\\bigwedge}")#text("-definable or ")#mi("{\\bigvee}")#text("-definable; for instance, in the language of groups, if ")#mi("{A}")#text(" is a subgroup of ")#mi("{G}")#text(", the ")#emph[#text("normaliser")]#text(" ")#mi("{N(A) := \\{ g \\in G: gAg^{-1} = A \\}}")#text(" is neither ")#mi("{\\bigwedge}")#text("-definable or ")#mi("{\\bigvee}")#text("-definable in general (there are too many quantifiers hidden inside the statement ")#mi("{gAg^{-1} = A}")#text("!). Things might improve if one adds in a predicate for membership in ")#mi("{A}")#text(", though I was a little unclear on this point.")

#text("(Thanks to Matthias Aschenbrenner, Juan Diego Caycedo, and Isaac Goldbring for comments and suggestions.)")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41853")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2009")])]

#text("Terry,")

#text("I’ll be following this with interest; I find this paper of Hrushovskii very intruiging indeed.")

#text("Best")#linebreak()#text(" Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41857")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2009")])]

#text("Would you mind if we had an online component of sorts using this thread? If there’s a question posed here nobody knows the answer to could it be relayed to the reading group?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41858")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2009")])]

#text("That would be fine! This is somewhat experimental (as are so many other online mathematical activities); it will be interesting to see how the online and offline groups interact.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20dad6bfbcb9227edbe4568b3b1daeec815c7b85c8240785827738f7b3ece12f-6102be506782b1d53c6921ce761670ea2b51e01730e09c2f76813c915cf7ec3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joe the rat")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41863")[#strong[#text("joe the rat")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2009")])]

#text("Thank you for this post. This is amazing that this problem seems to be located between group theory and model theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41866")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2009")])]

#text("I tried to learn some model theory a few years ago when it turned out that the Group Configuration Theorem of Hrushovski has some amazing combinatorial corollaries. I did find an informal introduction to model theory by Ludomir Newelski which might complement Terry’s gentle introduction; “")#link("http://www.springerlink.com/content/y980221226434164/")[#text("An essay on model theory")]#text("” Central European Journal of Mathematics, Volume 1, Number 3 / September, 2003, pages 398-410.")#linebreak()#text(" While I’m still fighting with this classical result of Hrushovski, I’m looking forward to see some explanations of his new theorem by non-model-theorists.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41884")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("Hi Jozsef,")

#text("Do you have any references on these combinatorial corollaries? I would be very interested.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41895")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("Hi Andres,")

#text("Well, I can give you some indirect references only. I learned about the connection between the Group Configuration Theorem (GCT) and some combinatorial problems from my late friend and teacher Gyuri Elekes.")#linebreak()#text(" In 2001 Endre Szabo proved a beautiful theorem in algebraic geometry which is (partly) a corollary of GCT. (Endre Szabo wasn’t aware of this connection, but the result remained unpublished) Loosely speaking it says that if a low degree varieties contains at least ")#mi("n^{1.9}")#text(" points of an n x n x n Cartesian product then it is a cylinder or it is a pullback from the graph of the multiplication function of a group. My favorite application of this result is the following (due to Elekes and Szabo): the number of distinct distances between three non-collinear points and n point in the plane is at least ")#mi("n^{0.55}")#text(" (Much more than ")#mi("n^{0.5}")#text(") The only pointer which I can give you for these results is Elekes’ survey paper “Sums versus products in Number Theory, Algebra and Erdös Geometry” which is downloadable from the website")#linebreak()#text(" ")#link("http://www.cs.elte.hu/~elekes/")[#text("http://www.cs.elte.hu/~elekes/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41900")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("This is very interesting! Thanks.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eeb82776ca3313391a3042b8fbe443af20159f5354b12b0c3228da48ffe3e589-82fd7d70acecd53c96c5ecb7e6998afac8bcef7a53610c60fbf269acf40d32f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Scanlon")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41880")[#strong[#text("Thomas Scanlon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2009")])]

#text("We have been reading (very slowly — we are at Theorem 3.4 now) Udi’s paper in our model theory seminar at Berkeley. What kind of on-line component to your seminar do you have in mind? Would it be more than threaded comments on this topic? It could be useful for us to post the questions and solutions from our respective seminars here or at whatever forum or wiki you establish for the on-line seminar.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b7ab700e796350ddebdfa8bacb73b8eb00b355248eb55f2c4990be11062ec42-3638053882aa8f4b29bdd6a4f5b04e496113c361cef5cc9541735f14c6bebdab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anand Pillay")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41882")[#strong[#text("Anand Pillay")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("We at Leeds have also been looking at the paper since early September.")#linebreak()#text(" I first went through the proof of Theorem 3.4 , essentially stating the required background as needed. Dugald Macpherson has since then been looking at other sections, including 2 and 5. I will begin on section 4 this week.")#linebreak()#text(" The whole thing is very nice but there could be some clarifications here and there. We will first communicate any suggestions to Udi. But we would be otherwise happy to share insights and/or questions (although personally I may have trouble with any fancy online technology).")

#text("For motivation concerning Thm. 3.4 or treatment of special cases, one might want to look at section 7 of Pseudo-finite fields and related structures (Hrushovski, in Model Theory and Applications, quaderni di matematica, vol. 11), and section 4 of my ")#link("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.jsl/1183745566")[#text("Definability and definable groups in simple theories")]#text(", JSL 1998.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41883")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("Well, as with most of my forays into online mathematics, the planning for this online seminar is being made up as it goes along. It does seem that there is broader interest in this topic than I had previously realised, though.")

#text("It seems that UCLA is lagging a bit behind the Berkeley and Leeds seminars (our immediate goal is just to understand the ")#emph[#text("statement")]#text(" of Theorem 3.4, and how it gives some of the easier combinatorial applications), but it does seem to make a lot of sense to have a common location to discuss things.")

#text("I think the simplest thing to do is to continue using this blog for now, but to encourage discussion in the comments of ")#emph[#text("all")]#text(" aspects of the Hrushovski paper (not just whatever is currently being looked at by the UCLA group). Hopefully this will help us to catch up to wherever the other groups are at, and I doubt the volume of postings will be so huge as to cause chaos. (If this does turn out to be the case, I may try to set up some fancier forum to organise things, but this seems to be a bit premature at this stage. The blog does have the advantages of having an established readership (in particular, Ehud himself has commented on this blog before), and the ability to comment without needing registration or any technical expertise.)")

#text("Also, if anyone would like to start their own thread on this topic (e.g. if someone is willing to write up lecture notes from the Berkeley or Leeds seminar) then they can contact me and I can put the text on the blog here as a “guest blog”. (If I get a regular flow of submissions of this type, I may look to finding a more organised way to set this up, e.g. using the polymath resources, but I think that can wait until the level of activity becomes sufficiently high.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41885")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("Here is a set of lecture notes on model theory:")

#link("http://www.math.uiuc.edu/People/pillay/lecturenotes_modeltheory.pdf")[#text("Click to access lecturenotes_modeltheory.pdf")]

#text("Here is an article about saturated models:")

#link("http://en.wikipedia.org/wiki/Saturated_model")[#text("http://en.wikipedia.org/wiki/Saturated_model")]

#text("From the above the statement that every model has a saturated elementary extension implies the generalized continuum hypothesis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41905")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2009")])]

#text("Actually, the last statement is not quite true.")

#text("In any case, although there is a slight set theoretic issue with saturated models, it can be easily avoided: in model theory, one only needs to work with a model U which is saturated and homogeneous with respect to some big cardinal lamda (so the properties “saturation” and “homogeneity” mentioned in Terry’s post hold over sets of cardinality less than lamda), and it is not so important that the cardinality of U is exactly lamda. Such models provably exist in ZFC.")

#text("There are other ways to deal with existence of saturated models, for example “proof by absoluteness”: most properties we are interested in in model theory are set-theoretically absolute (their truth does not depend on the model of set theory one works with), so it is harmless to assume that GCH holds for some big cardinal lamda.")

#text("Another small general remark that makes a (mild) connection between this blog and a previous online course of Terry’s on ergodic theory: types over a set A are simply ultra-filters on the Boolean algebra of A-definable sets (formulas). One can also look at a more general concept of a (finitely additive) probability measure on this space (a Keisler measure). The space of types is a compact totally disconnected topological space. Some of Keisler measures (in particular types) turn out (or can be assumed) to be definable, which means that they can be viewed as continuous functions from the type space to the reals. This allows the use of topological tools, which are often quite helpful.")

#text("Lastly a short response to Terry’s question about the power of the infinitary situation: it seems to be that some of it can be seen in Theorem 2.15, which is a variant of the so-called “Independence Theorem” (“3-Amalgamation Theorem” would be a better name), which roughly states that under certain conditions “free” (“large”) extensions of a type are compatible. This is a generalization of uniqueness of “free” (non-forking) extensions in stable theories, and has had many consequences in simple theories (generalizing results from stability). It also plays a crucial role in the proof of Theorem 3.4 in Udi’s paper, which is the central result on the model theoretic side.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41953")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("I am sorry: it was pointed out to me that I have been reading an old version of Udi’s paper. In the most recent version, the Independence Theorem is Theorem 2.16.")

#text("Also, in my previous comment I forgot to mention that if you add a predicate for membership in a subgroup A (so if A is definable), then N(A) is definable as well: you need to say that for all x in A there is x’ in A such that yx=x’y (and vice versa).")

#text("The model theory group in Lisbon is also (slowly) reading Udi’s paper. We will be very happy to participate in an online reading group (although at this point it is too early for us to be able to say or ask anything intelligent).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a022da01152e3dde5846f2de1bd575448f16f0c2b25cb5457728bcdde5772dd-44bf270365203d7f774adfe883e55c9aca3a49763e7a209601abec5a843a12ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ward Henson")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41887")[#strong[#text("Ward Henson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("In Urbana we also have had a working seminar since early September around the topic of Hruskovski’s paper. We began with some background (especially Terence Tao’s paper “The sum-product phenomenon in arbitrary rings”) and for the last four weeks we have been diving into Hrushovski. It would doubtless be helpful and also interesting for the various groups working in parallel to share their understanding (and confusion).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41889")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("It looks like there is indeed a significant economy of scale to be gained here by having a common online seminar for all the separate physical seminars out there. (I’ve long felt that a similar economy of scale should be present for undergraduate teaching, but didn’t realise that it would also work at the research level.) So, I would like to open the comments here to everyone who has a question or comment about the paper or some other related topic to discuss.")

#text("I’ll start the ball rolling with the following question. From what I can see of the paper so far, the proofs of the combinatorial statements in Hrushovski’s paper proceed by a “correspondence principle” or “compactness and contradiction” method, in which one assumes that the combinatorial statement fails, and extracts from this (via compactness) some infinitary limit structure which is supposed to ultimately lead to some sort of contradiction. Fair enough – I’ve seen many arguments of this sort before, such as in Gromov’s proof of his theorem on groups of polynomial growth, or Furstenberg’s proof of Szemeredi’s theorem. My question though is what is the secret ingredient in the infinitary world that makes this correspondence powerful, and which is then difficult to replicate in the finitary world? In the case of Gromov’s theorem, it is the Montgomery-Zippin-Yamabe theory of topological groups; in the case of Furstenberg’s proof, it is the various tools of measurable dynamics, such as the ergodic theorem, conditional expectation, the Gram-Schmidt process, etc.. In Hrushovski’s paper, there is use of the Montgomery-Zippin-Yamabe theory, but this comes only for some of the deeper applications; as far as I can tell the proof of Hrushovski Corollary 1.2 (for instance) does not use any Lie theory or topological group theory, and still is something which looks beyond the reach of current combinatorial methods, so something nontrivial must be happening at the infinitary level (beyond just compactness).")

#text("I guess we’ll understand this once we get a better grip on Theorem 3.4, which the UCLA team is going to tackle later this week, I think, but I would be interested to hear other people’s thoughts on the matter. (Examples of simpler versions of Theorem 3.4 which still have non-trivial finitary implications would also be very much appreciated; I will have a look at the papers Pillay mentions. The Quaderni paper does not seem to be available online, though.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b7ab700e796350ddebdfa8bacb73b8eb00b355248eb55f2c4990be11062ec42-3638053882aa8f4b29bdd6a4f5b04e496113c361cef5cc9541735f14c6bebdab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anand Pillay")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41902")[#strong[#text("Anand Pillay")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2009")])]

#text("Here is a kind of response to Terence Tao’s question about the power of the model theoretic methods. As with the other examples he mentions (theory of topological groups, measurable dynamics,..) there is a powerful and nontrivial theory around, namely stability theory, or rather neo-stability theory. This is a specialised area of model theory, which many people in the subject may not be exposed to. Stability theory (developed originally by Shelah) includes notions of forking, stationarity, orthogonality,…and was originally developed just in the context of stable (first order) theories, for reasons I will not go into here.")#linebreak()#text(" In fact if you are interested in more than simply getting through the paper there would be no harm in taking a bit of time to talk about stable theories in the UCLA seminar.")#linebreak()#text(" Anyway, in the past 15 years or so there has been an extension of this technology outside the realm of stable theories , to e.g. “simple” theories, and NIP theories. There are new features, such as independence theorem in simple theories, and studying measures in place of types in NIP theories…I call this neo-stability theory. (Neo) Stable group theory is just (neo) stability theory in the presence of a definable group operation, which has special features like the theory of generic types, connected components, stabilizers, invariant measures,.. What Udi has done beautifully in say 3.4 is to isolate some local assumptions on a situation (and which are consequences of being an ultraproduct of finite sets or structures) and which allow arguments in the case of groups definable in SIMPLE theories to go through, with of course additional finessing. There is an additional level of generality of working with v-definable (ind-definable) groups rather than definable ones, but it doesn’t really present technical obstacles.")

#text("So my basic point is that there is a theory here, going considerably beyond compactness, which one is plugging into. One can of course ask further, what precise technical aspects or specific theorems, provide the power to encode finite combinatorics or even to say “meaningful” things at the infinitary level. I may say more about it later.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41920")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2009")])]

#text("Thanks for your comments! I will definitely be interested in understanding more about stability theory as the seminar here progresses.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42027")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("I have finally gathered my thoughts enough to say something concerning Terry’s question above. In other words, this is my current (quite limited) view of some of the “secret ingredients” of the “finite-infinite” correspondence in Udi’s paper.")

#text("It seems to me that there are, in fact, two “correspondences” going on. The first is the more usual one, roughly between families of finite sets that look like subgroups and “near-subgroups” in the ultra-product (Definition 3.6). Given a near-subgroup ")#mi("X")#text(", Udi obtains in Theorem 3.4 the “stabilizer” subgroup. This “bounds” ")#mi("X")#text(" between two subgroups (one type-definable, another ind-definable) which are very “close” (the quotient is of bounded index). This already allows him to deduce certain consequences on the “finite” world, using the first “finite-infinite correspondence” (the end of section 3 – of course, quite a bit of model theory on the “infinite side” is used just in those proofs). As I mentioned before, some of the power here is hidden in the stabilizer theorem, one of the main ingredients of which is the Independence Theorem 2.16. The techniques, as Anand was saying, generalize those of stability, simplicity, etc., and some of the main tools seem to be local stability, forking, and definable measures.")

#text("The second correspondence is possibly even more intriguing, and it is that between definable (type-definable, ind-definable…) groups in the “infinite” world (in a monster model) and compact (or locally compact) topological groups. These connections have been studied quite a bit recently in the context of dependent groups, specifically in the o-minimal context (“Pillay’s Conjecture”). In order to establish this correspondence, one again uses the fact that the stabilizer obtained in Theorem 3.4 is of bounded index. Now the tools of locally compact topological groups become available. It seems that Udi uses kind of a “transfer” principle for certain type of statements between the “Lie” world and the “infinite” world of the monster model, which then can be transferred back to the “finite” world; but I am less clear on this part at the moment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41894")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("I’m forwarding (with permission) some earlier correspondence I had from Hrushovski about the intuition behind several key concepts in the paper, namely ")#emph[#text("indiscernibles")]#text(", the ")#emph[#text("forking ideal")]#text(", and ")#emph[#text("invariant measures")]#text(", as this may be of interest to various readers.")

#text("—")

#strong[#text("Indiscernibles")]#text(" are usually just a systematic way of using Ramsey’s theorem. Given a sequence ")#mi("(a_1,a_2,\\ldots)")#text(", any formula in ")#mi("m")#text(" variables (and no parameters) can be viewed as a coloring of ")#mi("m")#text("-subsets of the sequence, with two colors, true and false. Conversely a “definable” coloring in ")#mi("c")#text(" colors can be coded by about ")#mi("\\log(c)")#text(" formulas. Logical compactness means that one can apply Ramsey’s theorem to ")#emph[#text("all")]#text(" definable colorings sequentially and then take a limit, obtaining a fully homogeneous set. This is what we call an indiscernible sequence. In practice one can usually rewrite proofs using indiscernibles in such a way that Ramsey’s theorem is applied for a specific definable coloring. (But not always; the Paris-Harrington theorem can be viewed as a counterexample.)")

#text("The ")#strong[#text("forking ideal")]#text(" over a set of parameters A: it is contained in the intersection of the measure-0 ideal over all automorphism-invariant measures (Lemma 2.9), in particular over all A-definable measures. It’s not too wrong to think of “forking over A” as “measure zero for any measure defined over A” (but the definition is more elementary, and not identical to this.)")

#strong[#text("Invariant measures")]#text(": very close to the usual intuition of a finite ")#mi("\\sigma")#text("-additive measure, but only sets definable with parameters are measured; on the other hand, there is an additional condition, that the measure be invariant under automorphisms acting on the parameters. For example Lebesgue measure on the interval ")#mi("[0,1]")#text(" or more generally on ")#mi("[0,1]^n")#text(", restricted to semi-algebraic subsets, admits a unique extension to the interval ")#mi("[0,1]")#text(" (or ")#mi("[0,1]^n")#text(" in any bigger real closed field. (For ")#mi("n=1")#text(" this is an easy excercise: infinitesimal intervals must have measure ")#mi("0")#text(", since they can be approximated by intervals with rational endpoints.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reading seminar 2: “Stable group theory and approximate subgroups”‘, by Ehud Hrushovski « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-41970")[#strong[#text("Reading seminar 2: “Stable group theory and approximate subgroups”‘, by Ehud Hrushovski « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("[…] made some more general remarks about universal saturated models (extending the discussion from the previous seminar), and then Henry Towsner gave some preliminaries on Kiesler measures, in preparation for connecting […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reading seminar 3: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42087")[#strong[#text("Reading seminar 3: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2009")])]

#text("[…] extension of (i.e. one that obeys the saturation and homogeneity properties as discussed in Notes 1. Later on, will contain the language of groups, and then we will rename as to emphasise […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/10/15/reading-seminar-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42332")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2009")])]

#text("in the second paragraph ”….since groups themselves have a doubling constant ….” is it G or X?")
]
