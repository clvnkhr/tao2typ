// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/
// Converted to Typst by tao2typ: "2026-10-14T15:20:25.801575+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Cut norms and degree lowering", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Cut norms and degree lowering")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 March 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/")[#text("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the modern theory of additive combinatorics, a large role is played by the ")#emph[#text("Gowers uniformity norms")]#text(" ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)}}", block: false)#text(", where ")#mi("{k \\geq 1}")#text(", ")#mi("{G = (G,+)}")#text(" is a finite abelian group, and ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" is a function (one can also consider these norms in finite approximate groups such as ")#mi("{[N] = \\{1,\\dots,N\\}}")#text(" instead of finite groups, but we will focus on the group case here for simplicity). These norms can be defined by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^k(G)} := (\\mathop{\\bf E}_{x,h_1,\\dots,h_k \\in G} \\Delta_{h_1} \\dots \\Delta_{h_k} f(x))^{1/2^k}", block: true)]]

#text("where we use the averaging notation")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{x \\in A} f(x) := \\frac{1}{\\left|A\\right|} \\sum_{x \\in A} f(x)", block: true)]]

#text("for any non-empty finite set ")#mi("{A}")#text(" (with ")#tao-math("{\\left|A\\right|}", block: false)#text(" denoting the cardinality of ")#mi("{A}")#text("), and ")#mi("{\\Delta_h}")#text(" is the multiplicative discrete derivative operator")

#align(center)[#tao-fit-display[#mitex("\\Delta_h f(x) := f(x+h) \\overline{f(x)}.")]]

#text("One reason why these norms play an important role is that they control various multilinear averages. We give two sample examples here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" ")#metadata(none) <tao-d2629e20f4001547dc62>#text(" Let ")#mi("{G = {\\bf Z}/N{\\bf Z}}")#text(".")

#list(
[#text("(i) If ")#mi("{a_1,\\dots,a_k}")#text(" are distinct elements of ")#mi("{G}")#text(" for some ")#mi("{k \\geq 2}")#text(", and ")#mi("{f_1,\\dots,f_k: G \\rightarrow {\\bf C}}")#text(" are ")#mi("{1}")#text("-bounded functions (thus ")#tao-math("{\\left|f_j(x)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{j=1,\\dots,k}")#text(" and ")#mi("{x \\in G}")#text("), then ")#metadata(none) <tao-987965a5c3d175576ef7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\mathop{\\bf E}_{x, h \\in G} f_1(x+a_1 h) \\dots f_k(x+a_k h) \\leq \\left\\|f_i\\right\\|_{U^{k-1}(G)}", block: true)]]

#text("for any ")#mi("{i=1,\\dots,k}")#text(".")],
[#text("(ii) If ")#mi("{f_1,f_2,f_3: G \\rightarrow {\\bf C}}")#text(" are ")#mi("{1}")#text("-bounded, then one has")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{x, h \\in G} f_1(x) f_2(x+h) f_3(x+h^2) \\ll \\left\\|f_3\\right\\|_{U^4(G)} + N^{-1/4}.", block: true)]]]
)
]

#text("We establish these claims a little later in this post.")

#text("In some more recent literature (e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3361771")[#text("this paper of Conlon, Fox, and Zhao")]#text("), the role of Gowers norms have been replaced by (generalisations) of the ")#emph[#text("cut norm")]#text(", a concept originating from graph theory. In this blog post, it will be convenient to define these cut norms in the language of probability theory (using boldface to denote random variables).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Cut norm)")]#text(" Let ")#mi("{{\\bf X}_1,\\dots,{\\bf X}_k, {\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(" be independent random variables with ")#mi("{k,l \\geq 0}")#text("; to avoid minor technicalities we assume that these random variables are discrete and take values in a finite set. Given a random variable ")#mi("{{\\bf F} = F( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )}")#text(" of these independent random variables, we define the ")#emph[#text("cut norm")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )} := \\sup \\left| \\mathop{\\bf E} {\\bf F} {\\bf B}_1 \\dots {\\bf B}_k \\right|", block: true)]]

#text("where the supremum ranges over all choices ")#mi("{{\\bf B}_1,\\dots,{\\bf B}_k}")#text(" of random variables ")#mi("{{\\bf B}_i = B_i( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )}")#text(" that are ")#mi("{1}")#text("-bounded (thus ")#tao-math("{\\left|{\\bf B}_i\\right| \\leq 1}", block: false)#text(" surely), and such that ")#mi("{{\\bf B}_i}")#text(" does not depend on ")#mi("{{\\bf X}_i}")#text(".")

#text("If ")#mi("{l=0}")#text(", we abbreviate ")#tao-math("{\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )}}", block: false)#text(" as ")#tao-math("{\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k )}}", block: false)#text(".")
]

#text("Strictly speaking, the cut norm is only a cut semi-norm when ")#mi("{k=0,1}")#text(", but we will abuse notation by referring to it as a norm nevertheless.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" If ")#mi("{G = (V_1,V_2,E)}")#text(" is a bipartite graph, and ")#mi("{\\mathbf{v_1}}")#text(", ")#mi("{\\mathbf{v_2}}")#text(" are independent random variables chosen uniformly from ")#mi("{V_1,V_2}")#text(" respectively, then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_E(\\mathbf{v_1},\\mathbf{v_2}) \\right\\|_{\\mathrm{CUT}(\\mathbf{v_1}, \\mathbf{v_2})}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= \\sup_{\\left\\|f\\right\\|_\\infty, \\left\\|g\\right\\|_\\infty \\leq 1} \\left|\\mathop{\\bf E}_{v_1 \\in V_1, v_2 \\in V_2} 1_E(v_1,v_2) f(v_1) g(v_2)\\right|", block: true)]]

#text("where the supremum ranges over all ")#mi("{1}")#text("-bounded functions ")#mi("{f: V_1 \\rightarrow [-1,1]}")#text(", ")#mi("{g: V_2 \\rightarrow [-1,1]}")#text(". The right hand side is essentially the cut norm of the graph ")#mi("{G}")#text(", as defined for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1723039")[#text("by Frieze and Kannan")]#text(".")
]

#text("The cut norm is basically an expectation when ")#mi("{k=0,1}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" ")#metadata(none) <tao-6ab9f1eb8f7d3388f4f9>#text(" If ")#mi("{k=0}")#text(", we see from definition that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( ; {\\bf Y}_1,\\dots,{\\bf Y}_l )} =\\left| \\mathop{\\bf E} {\\bf F} \\right|.", block: true)]]

#text("If ")#mi("{k=1}")#text(", one easily checks that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}; {\\bf Y}_1,\\dots,{\\bf Y}_l )} = \\mathop{\\bf E} \\left| \\mathop{\\bf E}_{\\bf X} {\\bf F} \\right|,", block: true)]]

#text("where ")#mi("{\\mathop{\\bf E}_{\\bf X} {\\bf F} = \\mathop{\\bf E}( {\\bf F} | {\\bf Y}_1,\\dots,{\\bf Y}_l )}")#text(" is the conditional expectation of ")#mi("{{\\bf F}}")#text(" to the ")#mi("{\\sigma}")#text("-algebra generated by all the variables other than ")#mi("{{\\bf X}}")#text(", i.e., the ")#mi("{\\sigma}")#text("-algebra generated by ")#mi("{{\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(". In particular, if ")#mi("{{\\bf X}, {\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(" are independent random variables drawn uniformly from ")#mi("{X,Y_1,\\dots,Y_l}")#text(" respectively, then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F( {\\bf X}; {\\bf Y}_1,\\dots, {\\bf Y}_l) \\right\\|_{\\mathrm{CUT}( {\\bf X}; {\\bf Y}_1,\\dots,{\\bf Y}_l )}", block: true)]]

#align(center)[#tao-fit-display[#mitex("= \\mathop{\\bf E}_{y_1 \\in Y_1,\\dots, y_l \\in Y_l} |\\mathop{\\bf E}_{x \\in X} F(x; y_1,\\dots,y_l)|.")]]
]

#text("Here are some basic properties of the cut norm:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Basic properties of cut norm)")]#text(" ")#metadata(none) <tao-99f486ee7cf30b68f7cc>#text(" Let ")#mi("{{\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(" be independent discrete random variables, and ")#mi("{{\\bf F} = F({\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l)}")#text(" a function of these variables.")

#list(
[#text("(i) (Permutation invariance) The cut norm ")#tao-math("{\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )}}", block: false)#text(" is invariant with respect to permutations of the ")#mi("{{\\bf X}_1,\\dots,{\\bf X}_k}")#text(", or permutations of the ")#mi("{{\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(".")],
[#text("(ii) (Conditioning) One has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )} = \\mathop{\\bf E} \\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k )}", block: true)]]

#text("where on the right-hand side we view, for each realisation ")#mi("{y_1,\\dots,y_l}")#text(" of ")#mi("{{\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(", ")#mi("{{\\bf F}}")#text(" as a function ")#mi("{F( {\\bf X}_1,\\dots,{\\bf X}_k; y_1,\\dots,y_l)}")#text(" of the random variables ")#mi("{{\\bf X}_1,\\dots, {\\bf X}_k}")#text(" alone, thus the right-hand side may be expanded as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{y_1,\\dots,y_l} \\left\\| F( {\\bf X}_1,\\dots,{\\bf X}_k; y_1,\\dots,y_l) \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k )}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\times \\mathop{\\bf P}( Y_1=y_1,\\dots,Y_l=y_l).")]]],
[#text("(iii) (Monotonicity) If ")#mi("{k \\geq 1}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )} \\geq \\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_{k-1}; {\\bf X}_k, {\\bf Y}_1,\\dots,{\\bf Y}_l )}.", block: true)]]],
[#text("(iv) (Multiplicative invariances) If ")#mi("{{\\bf B} = B({\\bf X}_1,\\dots,{\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l)}")#text(" is a ")#mi("{1}")#text("-bounded function that does not depend on one of the ")#mi("{{\\bf X}_i}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf B} {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )} \\leq \\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )}.", block: true)]]

#text("In particular, if we additionally assume ")#tao-math("{\\left|{\\bf B}\\right|=1}", block: false)#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf B} {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )} = \\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )}.", block: true)]]],
[#text("(v) (Cauchy-Schwarz) If ")#mi("{k \\geq 1}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )} \\leq \\left\\| \\Box_{{\\bf X}_1, {\\bf X}^{\\prime}_1} {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_2, \\dots, {\\bf X}_k; {\\bf X}_1, {\\bf X}^{\\prime}_1, {\\bf Y}_1,\\dots,{\\bf Y}_l )}^{1/2}", block: true)]]

#text("where ")#mi("{{\\bf X}^{\\prime}_1}")#text(" is a copy of ")#mi("{{\\bf X}_1}")#text(" that is independent of ")#mi("{{\\bf X}_1,\\dots,{\\bf X}_k,{\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(" and ")#mi("{\\Box_{{\\bf X}_1, {\\bf X}^{\\prime}_1} {\\bf F}}")#text(" is the random variable")

#align(center)[#tao-fit-display[#mitex("\\Box_{{\\bf X}_1, {\\bf X}^{\\prime}_1} {\\bf F} := F( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )")]]

#align(center)[#tao-fit-display[#mitex("\\times \\overline{F}( {\\bf X}^{\\prime}_1, {\\bf X}_2, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l ).")]]],
[#text("(vi) (Averaging) If ")#mi("{k \\geq 1}")#text(" and ")#mi("{{\\bf F} = \\mathop{\\bf E}_{\\bf Z} {\\bf F}_{\\bf Z}}")#text(", where ")#mi("{{\\bf Z}}")#text(" is another random variable independent of ")#mi("{{\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(", and ")#mi("{{\\bf F}_{\\bf Z} = F_{\\bf Z}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )}")#text(" is a random variable depending on both ")#mi("{{\\bf Z}}")#text(" and ")#mi("{{\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf F} \\right\\|_{\\mathrm{CUT}( {\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )} \\leq \\left\\| {\\bf F}_{\\bf Z} \\right\\|_{\\mathrm{CUT}( ({\\bf X}_1, {\\bf Z}), {\\bf X}_2, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l )}", block: true)]]]
)
]

#emph[#text("Proof:")]#text(" The claims (i), (ii) are clear from expanding out all the definitions. The claim (iii) also easily follows from the definitions (the left-hand side involves a supremum over a more general class of multipliers ")#mi("{{\\bf B}_1,\\dots,{\\bf B}_{k}}")#text(", while the right-hand side omits the ")#mi("{{\\bf B}_k}")#text(" multiplier), as does (iv) (the multiplier ")#mi("{{\\bf B}}")#text(" can be absorbed into one of the multipliers in the definition of the cut norm). The claim (vi) follows by expanding out the definitions, and observing that all of the terms in the supremum appearing in the left-hand side also appear as terms in the supremum on the right-hand side. It remains to prove (v). By definition, the left-hand side is the supremum over all quantities of the form")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E} {\\bf F} {\\bf B}_1 \\dots {\\bf B}_k\\right|", block: true)]]

#text("where the ")#mi("{{\\bf B}_i}")#text(" are ")#mi("{1}")#text("-bounded functions of ")#mi("{{\\bf X}_1, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l}")#text(" that do not depend on ")#mi("{{\\bf X}_i}")#text(". We average out in the ")#mi("{{\\bf X}_1}")#text(" direction (that is, we condition out the variables ")#mi("{{\\bf X}_2, \\dots, {\\bf X}_k; {\\bf Y}_1,\\dots,{\\bf Y}_l}")#text("), and pull out the factor ")#mi("{{\\bf B}_1}")#text(" (which does not depend on ")#mi("{{\\bf X}_1}")#text("), to write this as")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E} {\\bf B}_1 {\\bf E}_{{\\bf X}_1}( {\\bf F} {\\bf B}_2 \\dots {\\bf B}_k )\\right|,", block: true)]]

#text("which by Cauchy-Schwarz is bounded by")

#align(center)[#tao-fit-display[#tao-math("( \\left|{\\bf E} \\right|{\\bf E}_{{\\bf X}_1}( {\\bf F} {\\bf B}_2 \\dots {\\bf B}_k )|^2)^{1/2},", block: true)]]

#text("which can be expanded using the copy ")#mi("{{\\bf X}_1}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E} \\Box_{{\\bf X}_1,{\\bf X}^{\\prime}_1} ({\\bf F} {\\bf B}_2 \\dots {\\bf B}_k) \\right|^{1/2}.", block: true)]]

#text("Expanding")

#align(center)[#tao-fit-display[#mitex("\\Box_{{\\bf X}_1,{\\bf X}^{\\prime}_1} ({\\bf F} {\\bf B}_2 \\dots {\\bf B}_k) = (\\Box_{{\\bf X}_1,{\\bf X}^{\\prime}_1} {\\bf F}) (\\Box_{{\\bf X}_1,{\\bf X}^{\\prime}_1} {\\bf B}_2) \\dots (\\Box_{{\\bf X}_1,{\\bf X}^{\\prime}_1} {\\bf B}_k)")]]

#text("and noting that each ")#mi("{\\Box_{{\\bf X}_1,{\\bf X}^{\\prime}_1} {\\bf B}_i}")#text(" is ")#mi("{1}")#text("-bounded and independent of ")#mi("{{\\bf X}_i}")#text(" for ")#mi("{i=2,\\dots,k}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Now we can relate the cut norm to Gowers uniformity norms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#metadata(none) <tao-4b020389c3289782a403>#text(" Let ")#mi("{G}")#text(" be a finite abelian group, let ")#mi("{{\\bf x}, {\\bf h}_1,\\dots,{\\bf h}_k}")#text(" be independent random variables uniformly drawn from ")#mi("{G}")#text(" for some ")#mi("{k \\geq 0}")#text(", and let ")#mi("{f: G \\rightarrow {\\bf C}}")#text(". Then ")#metadata(none) <tao-3097e26b7f3cbdb92076>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| f({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_k) \\right\\|_{\\mathrm{CUT}( {\\bf h}_1,\\dots,{\\bf h}_k, {\\bf x} )} \\leq \\left\\|f\\right\\|_{U^{k+1}(G)}", block: true)]]

#text("and similarly (if ")#mi("{k \\geq 1}")#text(") ")#metadata(none) <tao-5f3731b52ad0fb2f820b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| f({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_k) \\right\\|_{\\mathrm{CUT}( {\\bf h}_1,\\dots,{\\bf h}_k; {\\bf x} )} \\leq \\left\\|f\\right\\|_{U^{k}(G)}", block: true)]]

#text("If ")#mi("{f}")#text(" is additionally assumed to be ")#mi("{1}")#text("-bounded, we have the converse inequalities ")#metadata(none) <tao-8312c5d48baec3e2cb31>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\|f\\right\\|_{U^{k+1}(G)}^{2^{k+1}} \\leq \\left\\| f({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_k) \\right\\|_{\\mathrm{CUT}( {\\bf h}_1,\\dots,{\\bf h}_k, {\\bf x} )}", block: true)]]

#text("and (if ")#mi("{k \\geq 1}")#text(") ")#metadata(none) <tao-8bd574fdb05c2dc50171>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|f\\right\\|_{U^{k}(G)}^{2^{k}} \\leq \\left\\| f({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_k) \\right\\|_{\\mathrm{CUT}( {\\bf h}_1,\\dots,{\\bf h}_k; {\\bf x} )}.", block: true)]]
]

#emph[#text("Proof:")]#text(" Applying Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(v) ")#mi("{k}")#text(" times, we can bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_k) \\right\\|_{\\mathrm{CUT}( {\\bf h_1},\\dots,{\\bf h_k}, {\\bf x} )}", block: true)]]

#text("by ")#metadata(none) <tao-a665a45920422f9d417e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| \\Box_{{\\bf h}_k,{\\bf h}^{\\prime}_k} \\dots \\Box_{{\\bf h}_1,{\\bf h}^{\\prime}_1} (f({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_k)) \\right\\|_{\\mathrm{CUT}( {\\bf x}; {\\bf h}_1, {\\bf h}^{\\prime}_1, \\dots, {\\bf h}_k, {\\bf h}^{\\prime}_k )}^{1/2^k}", block: true)]]

#text("where ")#mi("{{\\bf h}^{\\prime}_1,\\dots,{\\bf h}^{\\prime}_k}")#text(" are independent copies of ")#mi("{{\\bf h}_1,\\dots,{\\bf h}_k}")#text(" that are also independent of ")#mi("{{\\bf x}}")#text(". The expression inside the norm can also be written as")

#align(center)[#tao-fit-display[#mitex("\\Delta_{{\\bf h}_k - {\\bf h}^{\\prime}_k} \\dots \\Delta_{{\\bf h}_1 - {\\bf h}^{\\prime}_1} f({\\bf x} + {\\bf h}^{\\prime}_1 + \\dots + {\\bf h}^{\\prime}_k)")]]

#text("so by Example ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("4")]#text(" one can write ")#link(<tao-a665a45920422f9d417e>)[#text("(6)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{h_1,\\dots,h_k,h^{\\prime}_1,\\dots,h^{\\prime}_k \\in G} \\right|\\mathop{\\bf E}_{x \\in G} \\Delta_{h_k - h^{\\prime}_k} \\dots \\Delta_{h_1 - h^{\\prime}_1} f(x+h^{\\prime}_1+\\dots+h^{\\prime}_k)||^{1/2^k}", block: true)]]

#text("which after some change of variables simplifies to")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{h_1,\\dots,h_k \\in G} \\right|\\mathop{\\bf E}_{x \\in G} \\Delta_{h_k} \\dots \\Delta_{h_1} f(x)||^{1/2^k}", block: true)]]

#text("which by Cauchy-Schwarz is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{h_1,\\dots,h_k \\in G} \\right|\\mathop{\\bf E}_{x \\in G} \\Delta_{h_k} \\dots \\Delta_{h_1} f(x)\\left|^2\\right|^{1/2^{k+1}}", block: true)]]

#text("which one can rearrange as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{h_1,\\dots,h_k,h_{k+1},x \\in G} \\Delta_{h_{k+1}} \\Delta_{h_k} \\dots \\Delta_{h_1} f(x)\\right|^{1/2^{k+1}}", block: true)]]

#text("giving ")#link(<tao-3097e26b7f3cbdb92076>)[#text("(2)")]#text(". A similar argument bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_k) \\right\\|_{\\mathrm{CUT}( {\\bf h_1},\\dots,{\\bf h_k}; {\\bf x} )}", block: true)]]

#text("by")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{h_1,\\dots,h_k \\in G} \\mathop{\\bf E}_{x \\in G} \\Delta_{h_k} \\dots \\Delta_{h_1} f(x)\\right|^{1/2^k}", block: true)]]

#text("which gives ")#link(<tao-5f3731b52ad0fb2f820b>)[#text("(3)")]#text(".")

#text("For ")#link(<tao-8312c5d48baec3e2cb31>)[#text("(4)")]#text(", we can reverse the above steps and expand ")#tao-math("{\\left\\|f\\right\\|_{U^{k+1}(G)}^{2^{k+1}}}", block: false)#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{h_1,\\dots,h_k \\in G} \\left|\\mathop{\\bf E}_{x \\in G} \\Delta_{h_k} \\dots \\Delta_{h_1} f(x)\\right|^2", block: true)]]

#text("which we can write as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{h_1,\\dots,h_k \\in G} b(h_1,\\dots,h_k) \\mathop{\\bf E}_{x \\in G} \\Delta_{h_k} \\dots \\Delta_{h_1} f(x)\\right|", block: true)]]

#text("for some ")#mi("{1}")#text("-bounded function ")#mi("{b}")#text(". This can in turn be expanded as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{h_1,\\dots,h_k,x \\in G} f(x+h_1+\\dots+h_k) b(h_1,\\dots,h_k) \\prod_{i=1}^k b_i(x,h_1,\\dots,h_k)\\right|", block: true)]]

#text("for some ")#mi("{1}")#text("-bounded functions ")#mi("{b_i}")#text(" that do not depend on ")#mi("{h_i}")#text(". By Example ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("4")]#text(", this can be written as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f({\\bf x} + {\\bf h_1}+\\dots+{\\bf h}_k) b({\\bf h}_1,\\dots,{\\bf h}_k) \\prod_{i=1}^k b_i(x,h_1,\\dots,h_k) \\right\\|_{\\mathrm{CUT}(; {\\bf h}_1,\\dots,{\\bf h}_k, {\\bf x})}", block: true)]]

#text("which by several applications of Theorem ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(iii) and then Theorem ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(iv) can be bounded by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f({\\bf x} + {\\bf h_1}+\\dots+{\\bf h}_k) \\right\\|_{\\mathrm{CUT}( {\\bf h}_1,\\dots,{\\bf h}_k, {\\bf x})},", block: true)]]

#text("giving ")#link(<tao-8312c5d48baec3e2cb31>)[#text("(4)")]#text(". A similar argument gives ")#link(<tao-8bd574fdb05c2dc50171>)[#text("(5)")]#text(". ")#mi("\\Box")

#text("Now we can prove Proposition ")#link(<tao-d2629e20f4001547dc62>)[#text("1")]#text(". We begin with part (i). By permutation we may assume ")#mi("{i=k}")#text(", then by translation we may assume ")#mi("{a_k=0}")#text(". Replacing ")#mi("{x}")#text(" by ")#mi("{x+h_1+\\dots+h_{k-1}}")#text(" and ")#mi("{h}")#text(" by ")#mi("{h - a_1^{-1} h_1 - \\dots - a_{k-1}^{-1} h_{k-1}}")#text(", we can write the left-hand side of ")#link(<tao-987965a5c3d175576ef7>)[#text("(1)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{x,h,h_1,\\dots,h_{k-1} \\in G} f_k(x+h_1+\\dots+h_{k-1}) \\prod_{i=1}^{k-1} b_i(x,h,h_1,\\dots,h_{k-1})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("b_i(x,h,h_1,\\dots,h_{k-1})")]]

#align(center)[#tao-fit-display[#mitex(":= f_i( x + h_1+\\dots+h_{k-1}+ a_i(h - a_1^{-1} h_1 - \\dots - a_k^{-1} h_{k-1}))")]]

#text("is a ")#mi("{1}")#text("-bounded function that does not depend on ")#mi("{h_i}")#text(". Taking ")#mi("{{\\bf x}, {\\bf h}, {\\bf h}_1,\\dots,{\\bf h}_k}")#text(" to be independent random variables drawn uniformly from ")#mi("{G}")#text(", the left-hand side of ")#link(<tao-987965a5c3d175576ef7>)[#text("(1)")]#text(" can then be written as")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} f_k({\\bf x}+{\\bf h}_1+\\dots+{\\bf h}_{k-1}) \\prod_{i=1}^{k-1} b_i({\\bf x},{\\bf h},{\\bf h}_1,\\dots,{\\bf h}_{k-1})")]]

#text("which by Example ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("4")]#text(" is bounded in magnitude by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_k({\\bf x}+{\\bf h}_1+\\dots+{\\bf h}_{k-1}) \\prod_{i=1}^{k-1} b_i({\\bf x},{\\bf h},{\\bf h}_1,\\dots,{\\bf h}_{k-1}) \\right\\|_{\\mathrm{CUT}(; {\\bf h}_1,\\dots,{\\bf h}_{k-1}, {\\bf x}, {\\bf h})}.", block: true)]]

#text("After many applications of Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(iii), (iv), this is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_k({\\bf x}+{\\bf h_1}+\\dots+{\\bf h_{k-1}}) \\right\\|_{\\mathrm{CUT}({\\bf h}_1,\\dots,{\\bf h}_{k-1}; {\\bf x}, {\\bf h})}", block: true)]]

#text("By Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(ii) we may drop the ")#mi("{{\\bf h}}")#text(" variable, and then the claim follows from Lemma ")#link(<tao-4b020389c3289782a403>)[#text("6")]#text(".")

#text("For part (ii), we replace ")#mi("{x}")#text(" by ")#mi("{x+a-h^2}")#text(" and ")#mi("{h}")#text(" by ")#mi("{h-a+b}")#text(" to write the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{x, a,b,h \\in G} f_1(x+a-h^2) f_2(x+h+b-h^2) f_3(x+a+(h-a+b)^2-h^2);")]]

#text("the point here is that the first factor does not involve ")#mi("{b}")#text(", the second factor does not involve ")#mi("{a}")#text(", and the third factor has no quadratic terms in ")#mi("{h}")#text(". Letting ")#mi("{{\\bf x}, {\\bf a}, {\\bf b}, {\\bf h}}")#text(" be independent variables drawn uniformly from ")#mi("{G}")#text(", we can use Example ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("4")]#text(" to bound this in magnitude by")

#align(center)[#tao-fit-display[#mitex("\\| f_1({\\bf x}+{\\bf a}-{\\bf h}^2) f_2({\\bf x}+{\\bf h}+{\\bf b}-{\\bf h}^2)")]]

#align(center)[#tao-fit-display[#mitex("f_3( {\\bf x}+{\\bf a}+({\\bf h}-{\\bf a}+{\\bf b})^2-{\\bf h}^2 ) \\|_{\\mathrm{CUT}(; {\\bf x}, {\\bf a}, {\\bf b}, {\\bf h})}")]]

#text("which by Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(i),(iii),(iv) is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_3( {\\bf x}+{\\bf a}+({\\bf h}-{\\bf a}+{\\bf b})^2 - {\\bf h}^2 ) \\right\\|_{\\mathrm{CUT}({\\bf a}, {\\bf b}; {\\bf x}, {\\bf h})}", block: true)]]

#text("and then by Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(v) we may bound this by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Box_{{\\bf a}, {\\bf a}^{\\prime}} \\Box_{{\\bf b}, {\\bf b}^{\\prime}} f_3( {\\bf x}+{\\bf a}+({\\bf h}-{\\bf a}+{\\bf b})^2 - {\\bf h}^2 ) \\right\\|_{\\mathrm{CUT}(;{\\bf a}, {\\bf a}^{\\prime}, {\\bf b}, {\\bf b}^{\\prime}, {\\bf x}, {\\bf h})}^{1/4}", block: true)]]

#text("which by Example ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("4")]#text(" is")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E} \\Box_{{\\bf a}, {\\bf a}^{\\prime}} \\Box_{{\\bf b}, {\\bf b}^{\\prime}} f_3( {\\bf x}+{\\bf a}+({\\bf h}-{\\bf a}+{\\bf b})^2 - {\\bf h}^2 )\\right|^{1/4}", block: true)]]

#text("Now the expression inside the expectation is the product of four factors, each of which is ")#mi("{f_3}")#text(" or ")#mi("{\\overline{f}_3}")#text(" applied to an affine form ")#mi("{{\\bf x} + {\\bf c} + {\\bf a} {\\bf h}}")#text(" where ")#mi("{{\\bf c}}")#text(" depends on ")#mi("{{\\bf a}, {\\bf a}^{\\prime}, {\\bf b}, {\\bf b}^{\\prime}}")#text(" and ")#mi("{{\\bf a}}")#text(" is one of ")#mi("{2({\\bf b}-{\\bf a})}")#text(", ")#mi("{2({\\bf b}^{\\prime}-{\\bf a})}")#text(", ")#mi("{2({\\bf b}-{\\bf a}^{\\prime})}")#text(", ")#mi("{2({\\bf b}^{\\prime}-{\\bf a}^{\\prime})}")#text(". With probability ")#mi("{1-O(1/N)}")#text(", the four different values of ")#mi("{{\\bf a}}")#text(" are distinct, and then by part (i) we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}(\\Box_{{\\bf a}, {\\bf a}^{\\prime}} \\Box_{{\\bf b}, {\\bf b}^{\\prime}} f_3( {\\bf x}+{\\bf a}+({\\bf h}-{\\bf a}+{\\bf b})^2 - {\\bf h}^2 )|{\\bf a}, {\\bf a}^{\\prime}, {\\bf b}, {\\bf b}^{\\prime})\\right| \\leq \\left\\|f_3\\right\\|_{U^4({\\bf Z}/N{\\bf Z})}.", block: true)]]

#text("When they are not distinct, we can instead bound this quantity by ")#mi("{1}")#text(". Taking expectations in ")#mi("{{\\bf a}, {\\bf a}^{\\prime}, {\\bf b}, {\\bf b}^{\\prime}}")#text(", we obtain the claim. ")#mi("\\Box")

#text("The analogue of the inverse ")#mi("{U^2}")#text(" theorem for cut norms is the following claim (which I learned from Ben Green):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (")#mi("{U^2}")#text("-type inverse theorem)")]#text(" ")#metadata(none) <tao-8d7ec9aa29b87f7634b2>#text(" Let ")#mi("{\\mathbf{x}, \\mathbf{h}}")#text(" be independent random variables drawn from a finite abelian group ")#mi("{G}")#text(", and let ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" be ")#mi("{1}")#text("-bounded. Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f(\\mathbf{x} + \\mathbf{h}) \\right\\|_{\\mathrm{CUT}(\\mathbf{x}, \\mathbf{h})} = \\sup_{\\xi \\in\\hat G} \\left\\| f(\\mathbf{x}) e(\\xi \\cdot \\mathbf{x}) \\right\\|_{\\mathrm{CUT}(\\mathbf{x})}", block: true)]]

#text("where ")#mi("{\\hat G}")#text(" is the group of homomorphisms ")#mi("{\\xi: x \\mapsto \\xi \\cdot x}")#text(" is a homomorphism from ")#mi("{G}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(", and ")#mi("{e(\\theta) := e^{2\\pi i \\theta}}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose first that ")#tao-math("{\\left\\| f(\\mathbf{x} + \\mathbf{h}) \\right\\|_{\\mathrm{CUT}(\\mathbf{x}, \\mathbf{h})} > \\delta}", block: false)#text(" for some ")#mi("{\\delta}")#text(", then by definition")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,h \\in G} f(x+h) a(x) b(h)\\right| > \\delta", block: true)]]

#text("for some ")#mi("{1}")#text("-bounded ")#mi("{a,b: G \\rightarrow {\\bf C}}")#text(". By Fourier expansion, the left-hand side is also")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\xi \\in \\hat G} \\hat f(-\\xi) \\hat a(\\xi) \\hat b(\\xi)")]]

#text("where ")#mi("{\\hat f(\\xi) := \\mathop{\\bf E}_{x \\in G} f(x) e(-\\xi \\cdot x)}")#text(". From Plancherel’s theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi \\in \\hat G} \\left|\\hat a(\\xi)\\right|^2, \\sum_{\\xi \\in \\hat G} \\left|\\hat b(\\xi)\\right|^2 \\leq 1", block: true)]]

#text("hence by Hölder’s inequality one has ")#tao-math("{\\left|\\hat f(-\\xi)\\right| > \\delta}", block: false)#text(" for some ")#mi("{\\xi \\in \\hat G}")#text(", and hence ")#metadata(none) <tao-a39bec7c3dc2c0bae76c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\sup_{\\xi \\in\\hat G} \\left\\| f(\\mathbf{x}) e(\\xi \\cdot \\mathbf{x}) \\right\\|_{\\mathrm{CUT}(\\mathbf{x})} > \\delta.", block: true)]]

#text("Conversely, suppose ")#link(<tao-a39bec7c3dc2c0bae76c>)[#text("(7)")]#text(" holds. Then there is ")#mi("{\\xi \\in \\hat G}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f(\\mathbf{x}) e(\\xi \\cdot \\mathbf{x}) \\right\\|_{\\mathrm{CUT}(\\mathbf{x})} > \\delta", block: true)]]

#text("which on substitution and Example ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("4")]#text(" implies")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f(\\mathbf{x}+\\mathbf{h}) e(\\xi \\cdot (\\mathbf{x}+\\mathbf{h})) \\right\\|_{\\mathrm{CUT}(;\\mathbf{x}, \\mathbf{h})} > \\delta.", block: true)]]

#text("The term ")#mi("{e(\\xi \\cdot (\\mathbf{x}+\\mathbf{h}))}")#text(" splits into the product of a factor ")#mi("{e(\\xi \\cdot \\mathbf{x})}")#text(" not depending on ")#mi("{\\mathbf{h}}")#text(", and a factor ")#mi("{e(\\xi \\cdot \\mathbf{h})}")#text(" not depending on ")#mi("{\\mathbf{x}}")#text(". Applying Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(iii), (iv) we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f(\\mathbf{x}+\\mathbf{h}) \\right\\|_{\\mathrm{CUT}(\\mathbf{x}, \\mathbf{h})} > \\delta.", block: true)]]

#text("The claim follows. ")#mi("\\Box")

#text("The higher order inverse theorems are much less trivial (and the optimal quantitative bounds are not currently known). However, there is a useful ")#emph[#text("degree lowering")]#text(" argument, ")#link("https://arxiv.org/abs/1903.02592")[#text("due to Peluse and Prendiville")]#text(", that can allow one to lower the order of a uniformity norm in some cases. We give a simple version of this argument here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Degree lowering argument, special case)")]#text(" Let ")#mi("{G}")#text(" be a finite abelian group, let ")#mi("{Y}")#text(" be a non-empty finite set, and let ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" be a function of the form ")#mi("{f(x) := \\mathop{\\bf E}_{y \\in Y} F_y(x)}")#text(" for some ")#mi("{1}")#text("-bounded functions ")#mi("{F_y: G \\rightarrow {\\bf C}}")#text(" indexed by ")#mi("{y \\in Y}")#text(". Suppose that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^k(G)} \\geq \\delta", block: true)]]

#text("for some ")#mi("{k \\geq 2}")#text(" and ")#mi("{0 < \\delta \\leq 1}")#text(". Then one of the following claims hold (with implied constants allowed to depend on ")#mi("{k}")#text("):")

#list(
[#text("(i) (Degree lowering) one has ")#tao-math("{\\left\\|f\\right\\|_{U^{k-1}(G)} \\gg \\delta^{O(1)}}", block: false)#text(".")],
[#text("(ii) (Non-zero frequency) There exist ")#mi("{h_1,\\dots,h_{k-2} \\in G}")#text(" and non-zero ")#mi("{\\xi \\in \\hat G}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in G, y \\in Y} \\Delta_{h_1} \\dots \\Delta_{h_{k-2}} F_y(x) e( \\xi \\cdot x )\\right| \\gg \\delta^{O(1)}.", block: true)]]]
)
]

#text("There are more sophisticated versions of this argument in which the frequency ")#mi("{\\xi}")#text(" is “minor arc” rather than “zero frequency”, and then the Gowers norms are localised to suitable large arithmetic progressions; this is implicit in the above-mentioned paper of Peluse and Prendiville.")

#emph[#text("Proof:")]#text(" One can write")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^k(G)}^{2^k} = \\mathop{\\bf E}_{h_1,\\dots,h_{k-2} \\in G} \\left\\|\\Delta_{h_1} \\dots \\Delta_{h_{k-2}} f \\right\\|_{U^2(G)}^4", block: true)]]

#text("and hence we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\Delta_{h_1} \\dots \\Delta_{h_{k-2}} f \\right\\|_{U^2(G)} \\gg \\delta^{O(1)}", block: true)]]

#text("for a set ")#mi("{\\Sigma}")#text(" of tuples ")#mi("{(h_1,\\dots,h_{k-2}) \\in G^{k-2}}")#text(" of density ")#mi("{h_1,\\dots,h_{k-2}}")#text(". Applying Lemma ")#link(<tao-4b020389c3289782a403>)[#text("6")]#text(" and Lemma ")#link(<tao-8d7ec9aa29b87f7634b2>)[#text("7")]#text(", we see that for each such tuple, there exists ")#mi("{\\phi(h_1,\\dots,h_{k-2}) \\in \\hat G}")#text(" such that ")#metadata(none) <tao-3c2d493a01a75bfecc82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| \\Delta_{h_1} \\dots \\Delta_{h_{k-2}} f({\\bf x}) e( \\phi(h_1,\\dots,h_{k-2}) \\cdot {\\bf x} ) \\right\\|_{\\mathrm{CUT}({\\bf x})} \\gg \\delta^{O(1)},", block: true)]]

#text("where ")#mi("{{\\bf x}}")#text(" is drawn uniformly from ")#mi("{G}")#text(".")

#text("Let us adopt the convention that ")#mi("{e( \\phi( _1,\\dots,h_{k-2}) \\cdot {\\bf x} ) }")#text(" vanishes for ")#mi("{(h_1,\\dots,h_{k-2})}")#text(" not in ")#mi("{\\Sigma}")#text(", then from Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(ii) we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Delta_{{\\bf h}_1} \\dots \\Delta_{{\\bf h}_{k-2}} f({\\bf x}) e( \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot {\\bf x} ) \\right\\|_{\\mathrm{CUT}({\\bf x}; {\\bf h}_1,\\dots, {\\bf h}_{k-2})} \\gg \\delta^{O(1)},", block: true)]]

#text("where ")#mi("{{\\bf h}_1,\\dots,{\\bf h}_{k-2}}")#text(" are independent random variables drawn uniformly from ")#mi("{G}")#text(" and also independent of ")#mi("{{\\bf x}}")#text(". By repeated application of Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(iii) we then have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Delta_{{\\bf h}_1} \\dots \\Delta_{{\\bf h}_{k-2}} f({\\bf x}) e( \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot {\\bf x} ) \\right\\|_{\\mathrm{CUT}({\\bf x},{\\bf h}_1,\\dots, {\\bf h}_{k-2})} \\gg \\delta^{O(1)}.", block: true)]]

#text("Expanding out ")#mi("{\\Delta_{h_1} \\dots \\Delta_{h_{k-2}} f({\\bf x})}")#text(" and using Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(iv) repeatedly we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_{k-2}) e( \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot {\\bf x} ) \\right\\|_{\\mathrm{CUT}({\\bf x},{\\bf h}_1,\\dots, {\\bf h}_{k-2})} \\gg \\delta^{O(1)}.", block: true)]]

#text("From definition of ")#mi("{f}")#text(" we then have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf E}_{y \\in Y} F_y({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_{k-2}) e( \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot {\\bf x} ) \\right\\|_{\\mathrm{CUT}({\\bf x},{\\bf h}_1,\\dots, {\\bf h}_{k-2})}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\gg \\delta^{O(1)}.")]]

#text("By Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(vi), we see that the left-hand side is less than")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F_{\\bf y}({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_{k-2}) e( \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot {\\bf x} ) \\right\\|_{\\mathrm{CUT}(({\\bf x}, {\\bf y}),{\\bf h}_1,\\dots, {\\bf h}_{k-2})},", block: true)]]

#text("where ")#mi("{{\\bf y}}")#text(" is drawn uniformly from ")#mi("{Y}")#text(", independently of ")#mi("{{\\bf x}, {\\bf h}_1,\\dots,{\\bf h}_{k-2}}")#text(". By repeated application of Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(i), (v) repeatedly, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Box_{{\\bf h}_1, {\\bf h}^{\\prime}_1} \\dots \\Box_{{\\bf h}_{k-2}, {\\bf h}^{\\prime}_{k-2}} (F_{\\bf y}({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_{k-2}) e( \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot {\\bf x} )) \\right\\|_{\\mathrm{CUT}(({\\bf x},{\\bf y}); {\\bf h}_1,{\\bf h}^{\\prime}_1,\\dots, {\\bf h}_{k-2}, {\\bf h}^{\\prime}_{k-2})} \\gg \\delta^{O(1)},", block: true)]]

#text("where ")#mi("{{\\bf h}^{\\prime}_1,\\dots,{\\bf h}^{\\prime}_{k-2}}")#text(" are independent copies of ")#mi("{{\\bf h}_1,\\dots,{\\bf h}_{k-2}}")#text(" that are also independent of ")#mi("{{\\bf x}}")#text(", ")#mi("{{\\bf y}}")#text(". By Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(ii) and Example ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("4")]#text(" we conclude that ")#metadata(none) <tao-17550e2bb9ff2c26dcce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|\\mathop{\\bf E}( \\Box_{{\\bf h}_1, {\\bf h}^{\\prime}_1} \\dots \\Box_{{\\bf h}_{k-2}, {\\bf h}^{\\prime}_{k-2}} (F_{\\bf y}({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_{k-2}) e( \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot {\\bf x} )) | {\\bf h}_1,{\\bf h}^{\\prime}_1,\\dots, {\\bf h}_{k-2}, {\\bf h}^{\\prime}_{k-2}) )\\right| \\gg \\delta^{O(1)}", block: true)]]

#text("with probability ")#mi("{\\gg \\delta^{O(1)}}")#text(".")

#text("The left-hand side can be rewritten as")

#align(center)[#tao-fit-display[#mitex("|\\mathop{\\bf E}_{x \\in G, y \\in Y} \\Delta_{{\\bf h}_1 - {\\bf h}^{\\prime}_1} \\dots \\Delta_{{\\bf h}_{k-2} - {\\bf h}^{\\prime}_{k-2}} F_y( x + {\\bf h}^{\\prime}_1 + \\dots + {\\bf h}^{\\prime}_{k-2})")]]

#align(center)[#tao-fit-display[#mitex("e( \\delta_{{\\bf h}_1, {\\bf h}^{\\prime}_1} \\dots \\delta_{{\\bf h}_{k-2}, {\\bf h}^{\\prime}_{k-2}} \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot x )|")]]

#text("where ")#mi("{\\delta_{{\\bf h}_1, {\\bf h}^{\\prime}_1}}")#text(" is the additive version of ")#mi("{\\Box_{{\\bf h}_1, {\\bf h}^{\\prime}_1}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\delta_{{\\bf h}_1, {\\bf h}^{\\prime}_1} \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) := \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) - \\phi({\\bf h}^{\\prime}_1,\\dots,{\\bf h}_{k-2}).")]]

#text("Translating ")#mi("{x}")#text(", we can simplify this a little to")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in G, y \\in Y} \\Delta_{{\\bf h}_1 - {\\bf h}^{\\prime}_1} \\dots \\Delta_{{\\bf h}_k - {\\bf h}^{\\prime}_k} F_y( x ) e( \\delta_{{\\bf h}_1, {\\bf h}^{\\prime}_1} \\dots \\delta_{{\\bf h}_{k-2}, {\\bf h}^{\\prime}_{k-2}} \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot x )\\right|", block: true)]]

#text("If the frequency ")#mi("{\\delta_{{\\bf h}_1, {\\bf h}^{\\prime}_1} \\dots \\delta_{{\\bf h}_{k-2}, {\\bf h}^{\\prime}_{k-2}} \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2})}")#text(" is ever non-vanishing in the event ")#link(<tao-17550e2bb9ff2c26dcce>)[#text("(9)")]#text(" then conclusion (ii) applies. We conclude that")

#align(center)[#tao-fit-display[#mitex("\\delta_{{\\bf h}_1, {\\bf h}^{\\prime}_1} \\dots \\delta_{{\\bf h}_{k-2}, {\\bf h}^{\\prime}_{k-2}} \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) = 0")]]

#text("with probability ")#mi("{\\gg \\delta^{O(1)}}")#text(". In particular, by the pigeonhole principle, there exist ")#mi("{h^{\\prime}_1,\\dots,h^{\\prime}_{k-2} \\in G}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\delta_{{\\bf h}_1, h^{\\prime}_1} \\dots \\delta_{{\\bf h}_{k-2}, h^{\\prime}_{k-2}} \\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) = 0")]]

#text("with probability ")#mi("{\\gg \\delta^{O(1)}}")#text(". Expanding this out, we obtain a representation of the form")

#align(center)[#tao-fit-display[#mitex("\\phi({\\bf h}_1,\\dots,{\\bf h}_{k-2}) = \\sum_{i=1}^{k-2} \\phi_i({\\bf h}_1,\\dots,{\\bf h}_{k-2})")]]

#text("holding with probability ")#mi("{\\gg \\delta^{O(1)}}")#text(", where the ")#mi("{\\phi_i: G^{k-2} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" are functions that do not depend on the ")#mi("{i^{th}}")#text(" coordinate. From ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(8)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Delta_{h_1} \\dots \\Delta_{h_{k-2}} f({\\bf x}) e( \\sum_{i=1}^{k-2} \\phi_i(h_1,\\dots,h_{k-2}) \\cdot {\\bf x} ) \\right\\|_{\\mathrm{CUT}({\\bf x})} \\gg \\delta^{O(1)}", block: true)]]

#text("for ")#mi("{\\gg \\delta^{O(1)}}")#text(" of the tuples ")#mi("{(h_1,\\dots,h_{k-2}) \\in G^{k-2}}")#text(". Thus by Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(ii)")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Delta_{{\\bf h}_1} \\dots \\Delta_{{\\bf h}_{k-2}} f({\\bf x}) e( \\sum_{i=1}^{k-2} \\phi_i({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot {\\bf x} ) \\right\\|_{\\mathrm{CUT}({\\bf x}; {\\bf h}_1,\\dots,{\\bf h}_{k-2})} \\gg \\delta^{O(1)}.", block: true)]]

#text("By repeated application of Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(iii) we then have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Delta_{{\\bf h}_1} \\dots \\Delta_{{\\bf h}_{k-2}} f({\\bf x}) e( \\sum_{i=1}^{k-2} \\phi_i({\\bf h}_1,\\dots,{\\bf h}_{k-2}) \\cdot {\\bf x} ) \\right\\|_{\\mathrm{CUT}({\\bf x}, {\\bf h}_1,\\dots,{\\bf h}_{k-2})} \\gg \\delta^{O(1)}", block: true)]]

#text("and then by repeated application of Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(iv)")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f({\\bf x} + {\\bf h}_1 + \\dots + {\\bf h}_{k-2}) \\right\\|_{\\mathrm{CUT}({\\bf x}, {\\bf h}_1,\\dots,{\\bf h}_{k-2})} \\gg \\delta^{O(1)}", block: true)]]

#text("and then the conclusion (i) follows from Lemma ")#link(<tao-4b020389c3289782a403>)[#text("6")]#text(". ")#mi("\\Box")

#text("As an application of degree lowering, we give an inverse theorem for the average in Proposition ")#link(<tao-d2629e20f4001547dc62>)[#text("1")]#text("(ii), first established ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3704938")[#text("by Bourgain-Chang")]#text(" and later reproved ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3874848")[#text("by Peluse")]#text(" (by different methods from those given here):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" Let ")#mi("{G = {\\bf Z}/N{\\bf Z}}")#text(" be a cyclic group of prime order. Suppose that one has ")#mi("{1}")#text("-bounded functions ")#mi("{f_1,f_2,f_3: G \\rightarrow {\\bf C}}")#text(" such that ")#metadata(none) <tao-66ab09544685c9217dad>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|\\mathop{\\bf E}_{x, h \\in G} f_1(x) f_2(x+h) f_3(x+h^2)\\right| \\geq \\delta", block: true)]]

#text("for some ")#mi("{\\delta > 0}")#text(". Then either ")#mi("{N \\ll \\delta^{-O(1)}}")#text(", or one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in G} f_1(x)\\right|, \\left|\\mathop{\\bf E}_{x \\in G} f_2(x)\\right| \\gg \\delta^{O(1)}.", block: true)]]
]

#text("We remark that a modification of the arguments below also give ")#tao-math("{\\left|\\mathop{\\bf E}_{x \\in G} f_3(x)\\right| \\gg \\delta^{O(1)}}", block: false)#text(".")

#emph[#text("Proof:")]#text(" The left-hand side of ")#link(<tao-66ab09544685c9217dad>)[#text("(10)")]#text(" can be written as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in G} F(x) f_3(x)\\right|", block: true)]]

#text("where ")#mi("{F}")#text(" is the ")#emph[#text("dual function")]

#align(center)[#tao-fit-display[#mitex("F(x) := \\mathop{\\bf E}_{h \\in G} f_1(x-h^2) f_2(x-h^2+h).")]]

#text("By Cauchy-Schwarz one thus has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in G} F(x) \\overline{F}(x)\\right| \\geq \\delta^2", block: true)]]

#text("and hence by Proposition ")#link(<tao-d2629e20f4001547dc62>)[#text("1")]#text(", we either have ")#mi("{N \\ll \\delta^{-O(1)}}")#text(" (in which case we are done) or")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{U^4(G)} \\gg \\delta^2.", block: true)]]

#text("Writing ")#mi("{F = \\mathop{\\bf E}_{h \\in G} F_h}")#text(" with ")#mi("{F_h(x) := f_1(x-h^2) f_2(x-h^2+h)}")#text(", we conclude that either ")#tao-math("{\\left\\|F\\right\\|_{U^3(G)} \\gg \\delta^{O(1)}}", block: false)#text(", or that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,h \\in G} \\Delta_{h_1} \\Delta_{h_2} F_h(x) e(\\xi x / N )\\right| \\gg \\delta^{O(1)}", block: true)]]

#text("for some ")#mi("{h_1,h_2 \\in G}")#text(" and non-zero ")#mi("{\\xi \\in G}")#text(". The left-hand side can be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,h \\in G} g_1(x-h^2) g_2(x-h^2+h) e(\\xi x/N)\\right|", block: true)]]

#text("where ")#mi("{g_1 = \\Delta_{h_1} \\Delta_{h_2} f_1}")#text(" and ")#mi("{g_2 = \\Delta_{h_1} \\Delta_{h_2} f_2}")#text(". We can rewrite this in turn as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,y \\in G} g_1(x) g_2(y) e(\\xi (x + (y-x)^2) / N)\\right|", block: true)]]

#text("which is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e(\\xi({\\bf x} + ({\\bf y}-{\\bf x})^2)/N) \\right\\|_{\\mathrm{CUT}({\\bf x}, {\\bf y})}", block: true)]]

#text("where ")#mi("{{\\bf x}, {\\bf y}}")#text(" are independent random variables drawn uniformly from ")#mi("{G}")#text(". Applying Lemma ")#link(<tao-99f486ee7cf30b68f7cc>)[#text("5")]#text("(v), we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Box_{{\\bf y}, {\\bf y}^{\\prime}} e(\\xi({\\bf x} + ({\\bf y}-{\\bf x})^2)/N) \\right\\|_{\\mathrm{CUT}({\\bf x}; {\\bf y}, {\\bf y}^{\\prime})} \\gg \\delta^{O(1)}.", block: true)]]

#text("However, a routine Gauss sum calculation reveals that the left-hand side is ")#mi("{O(N^{-c})}")#text(" for some absolute constant ")#mi("{c>0}")#text(" because ")#mi("{\\xi}")#text(" is non-zero, so that ")#mi("{N \\ll \\delta^{-O(1)}}")#text(". The only remaining case to consider is when")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{U^3(G)} \\gg \\delta^{O(1)}.", block: true)]]

#text("Repeating the above arguments we then conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{U^2(G)} \\gg \\delta^{O(1)},", block: true)]]

#text("and then")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{U^1(G)} \\gg \\delta^{O(1)}.", block: true)]]

#text("The left-hand side can be computed to equal ")#tao-math("{\\left|\\mathop{\\bf E}_{x \\in G} f_1(x)\\right| \\left|\\mathop{\\bf E}_{x \\in G} f_2(x)\\right|}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#text("This argument was given for the cyclic group setting, but the argument can also be applied to the integers (see ")#link("https://arxiv.org/abs/1903.02592")[#text("Peluse-Prendiville")]#text(") and can also be used to establish an analogue over the reals (that was first obtained ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=942826")[#text("by Bourgain")]#text(").")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a861b523fdb5071ea2d4a76fc38e1e600a3ba2bd97dce963341b3770c82a2e-f09146c65c3fa56f5cfde78a2d6c10c19270ab040979ff9bf0dfd539cba72163.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-544444")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2020")])]

#text("Lemma 6 implies, roughly speaking, that Gowers norms can be replaced with cut norms in any area where very precise bounds are not important. Is the post intended to suggest that it is often a good idea to do this, as the proofs will become more elegant? I’m not familiar enough with the more traditional proofs of these results to know off the top of my head if these ones are substantially simpler.")

#text("Is there a reason the application of example 4 and Lemma 5(iv) in the proof of Proposition 1 is not done using the definition?")

#text("There is a typo (“remainin gcase”) near the end.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-544485")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2020")])]

#text("Thanks for the correction. I think both Gowers norms and cut norms have their place in additive combinatorics; they are nearly equivalent, so the advantages to preferring one over the other are slight, but the point I wanted to make here was that there was a relatively clean calculus for cut norms which can be used for complicated Cauchy-Schwarz + triangle inequality + change of variables type arguments, whereas the analogous computations for Gowers norms are somewhat more notationally awkward (in particular, the Gowers-Cauchy-Schwarz inequality has to be twisted a fair deal before it can be used as broadly as Lemma 5(v) is here). One drawback of the cut norm approach is that it tends to rely more heavily on all the functions involved being bounded, but the “densification” technology in the Conlon-Fox-Zhao paper mentioned in the blog post goes a long way to ameliorating that (at least in the important case where the functions involved are bounded by a pseudorandom measure).")

#text("There is also a potentially useful hierarchy of cut norms, analogous to the hierarchy of slice rank type concepts ranging from true slice rank to tensor rank, in which the additional factors ")#mi("{\\bf B}")#text(" are more constrained in their variable dependencies than just being independent of a single variable. (This is also related to the hierarchy of possible types of hypergraph regularity.) I don’t yet know of any compelling application of these more general cut norms though.")

#text("I’m not sure what you are referring to you in your remark concerning the proof of Proposition 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a861b523fdb5071ea2d4a76fc38e1e600a3ba2bd97dce963341b3770c82a2e-f09146c65c3fa56f5cfde78a2d6c10c19270ab040979ff9bf0dfd539cba72163.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-544574")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2020")])]

#text("Thanks, that’s very enlightening! It would be great to see if this calculus makes it easier to find difficult Cauchy-Schwarz+change-of-variables arguments in the future – these have always seemed to me like they come out of nowhere.")

#text("WRT the proof of Proposition 1: After “the left-hand side of (1) can then be written as” and the equation that immediately follows, I think you can write “which is less than or equal to ")#tao-math("\\displaystyle  \\left\\| f_k({\\bf x}+{\\bf h_1}+\\dots+{\\bf h_{k-1}}) \\right\\|_{\\mathrm{CUT}({\\bf h}_1,\\dots,{\\bf h}_{k-1}; {\\bf x}, {\\bf h})}", block: false)#text(" because the supremum over a set is always greater than or equal to any element of the set” and then continue on from there.")

#text("But if the point is to demonstrate the effectiveness of the calculus you may want to prove things using the calculus rather than using the definitions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-544606")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2020")])]

#text("Ah, I see what you are saying now. My preference is to work with a more “object oriented” approach by relying on the calculus more than the definitions. (Somewhat annoyingly, I still need to use the definition directly at one stage in the proof of Lemma 8, as I was not able to come up with a clean abstraction of that step that could be made part of the calculus, but presumably such an abstraction is possible.) ")#emph[#text("[Update: I added such an abstraction to Lemma 5.]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-544501")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2020")])]

#text("there seems to be a displaying problem in Lemma 8")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a47d47e95fcd24a3f41dfbff1015ccb0d0936409c31ad8a95de463d8e71cca86-537a73a0ee4ae2704991ef894a45295132a107125042924a108fb86d88bcfd11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-544519")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2020")])]

#text("I have a latex rendering error for Lemma 8.")

#text("Screenshot: ")#link("https://imgur.com/a/ueLaxpP")[#text("https://imgur.com/a/ueLaxpP")]

#text("Rest of the latex-elements in your post render fine in my browser.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a47d47e95fcd24a3f41dfbff1015ccb0d0936409c31ad8a95de463d8e71cca86-537a73a0ee4ae2704991ef894a45295132a107125042924a108fb86d88bcfd11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-544537")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2020")])]

#text("Some more:")

#text("finite sert A (below second centered formula from top)")

#text("are discrete take values in a finite set (Definition 2)")

#text("homomrphisms (Lemma 7)")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-544552")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2020")])]

#text("There is a typo “sert” in the line below the second displayed formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-545344")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2020")])]

#text("In proposition 1, (ii) there is a typo: 1-boudned instead of 1-bounded. Great post! I wonder what example applications there could be for cut norms (besides providing an alternative to Gowers’ norms)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-549148")[#strong[#text("Tao – Ruhollas Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")]

#text("[…] current article is inspired by this post of Terrence Tao. Let’s first remember some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba47469313497327de3de34efa15122c0b7b7351949fd77046cd325c79354966-3499be251a3e5f87ef149fc193557ab0bd43ccb934695cb53c5677db06058e9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of majdoddin")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-549152")[#strong[#text("majdoddin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("I have proved a stronger version of Proposition 1(i):")#linebreak()#text(" The inequality (1) holds for the Gowers universal Norm of any order (not just ")#mi("k-1")#text(") on the right-hand side.")

#text("See its proof (and of some other inequalities for Gowers universal norms) here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://majdoddin.wordpress.com/2020/03/30/gowers_uniformity_norms/")[#text("Some inequalities for Gowers uniformity norms")]
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-549162")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("I think the function ")#mi("b_i")#text(" in your link is not well defined (the quantity ")#mi("x-a_k h + a_i h")#text(" is not a function purely of ")#mi("x-h")#text(", but depends on ")#mi("x")#text(" and ")#mi("h")#text(" separately).")

#text("In general it is known that the Gowers exponent in Proposition 1(i) is optimal. A typical counterexample is that if ")#mi("f_1(x) = f_3(x) = e(\\xi x/N)")#text(" and ")#mi("f_2(x) = e(-2\\xi x/N)")#text(" for some non-zero ")#mi("\\xi \\in {\\bf Z}/N{\\bf Z}")#text(" then ")#mi("{\\bf E}_{x,h \\in {\\bf Z}/N{\\bf Z}} f_1(x) f_2(x+h) f_3(x+2h) = 1")#text(" even though ")#mi("f_1,f_3")#text(" have vanishing ")#mi("U^1")#text(" norms. More generally, for length ")#mi("k")#text(" correlations one can use suitably chosen polynomial phases of degree ")#mi("k-2")#text(" (that are large in ")#mi("U^{k-1}")#text(" norm, but small in lower norms) to demonstrate optimality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pointwise ergodic theorems for non-conventional bilinear polynomial averages | What's new")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-579458")[#strong[#text("Pointwise ergodic theorems for non-conventional bilinear polynomial averages | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2020")])]

#text("[…] on the “degree lowering argument” of Peluse and Prendiville, which I discussed in this previous blog post. Crucially for our application, the estimates are very quantitative, with all bounds being […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-684623")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2024")])]

#text("Hello, professor Tao, I have few questions: In Peluse-Prendiville’s paper, they deal with the 3-term progression of the form x, x+y, x+y^2.")

#text("The Sarkozy theorem states that for positive density subset of integers, it must contain two elements x, x+(p-1), where p is a prime.")

#text("If we use Sarkozy theorem as an analogy, what the possible form of the 3-term Sarkozy theorem should be? Could we expect 3-terms of the form x, x+(p-1), x+(p-1)^2? And is it possible to use the tools of Peluse-Prendiville to obtain some results on this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/#comment-684643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2024")])]

#text("Qualitatively, this result is known: see ")#link("https://arxiv.org/abs/1001.4081")[#text("https://arxiv.org/abs/1001.4081")]#text(" . With recent advances it may be possible to get a decent quantitative result, though perhaps not the polynomially strong results of Peluse and Prendiville.")
]
]
