// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/
// Converted to Typst by tao2typ: "2026-10-14T11:11:49.239953+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Two announcements: AI for Math resources, and erdosproblems.com", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Two announcements: AI for Math resources, and erdosproblems.com")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 April 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/")[#text("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This post contains two unrelated announcements. Firstly, I would like to promote a useful ")#link("https://docs.google.com/document/d/1kD7H4E28656ua8jOGZ934nbH2HcBLyxcRgFDduH5iQ0/edit")[#text("list of resources for AI in Mathematics")]#text(", that was initiated by ")#link("https://dependenttyp.es/")[#text("Talia Ringer")]#text(" (with the crowdsourced assistance of many others) during the ")#link("https://www.nationalacademies.org/our-work/ai-to-assist-mathematical-reasoning-a-workshop")[#text("National Academies workshop on “AI in mathematical reasoning”")]#text(" last year. This list is now accepting new contributions, updates, or corrections; please feel free to submit them ")#link("https://docs.google.com/document/d/1kD7H4E28656ua8jOGZ934nbH2HcBLyxcRgFDduH5iQ0/edit")[#text("directly to the list")]#text(" (which I am helping Talia to edit). Incidentally, next week there will be a second ")#link("https://www.nationalacademies.org/event/42508_04-2024_artificial-intelligence-to-assist-mathematical-reasoning-webinar-on-the-future-of-collaboration")[#text("followup webinar")]#text(" to the aforementioned workshop, building on the topics covered there. (The first webinar may be found ")#link("https://www.nationalacademies.org/event/42508_04-2024_artificial-intelligence-to-assist-mathematical-reasoning-webinar-on-the-future-of-collaboration")[#text("here")]#text(".)")

#text("Secondly, I would like to advertise the ")#link("https://www.erdosproblems.com/")[#text("erdosproblems.com")]#text(" website, launched recently by ")#link("https://www.thomasbloom.org/")[#text("Thomas Bloom")]#text(". This is intended to be a living repository of the many mathematical problems proposed in various venues by ")#link("https://en.wikipedia.org/wiki/Paul_Erd%C5%91s")[#text("Paul Erdős")]#text(", who was particularly noted for his influential posing of such problems. For a tour of the site and an explanation of its purpose, I can recommend Thomas’s ")#link("https://www.youtube.com/watch?v=snAjIjo8Qy4")[#text("recent talk on this topic")]#text(" at a ")#link("https://www.newton.ac.uk/event/ooew04/")[#text("conference last week in honor of Timothy Gowers")]#text(".")

#text("Thomas is currently issuing a ")#link("https://www.erdosproblems.com/help")[#text("call for help")]#text(" to develop the erdosproblems.com website in a number of ways (quoting directly from that page):")

#list(
[#strong[#text("You know Github")]#text(" and could set a suitable project up to allow people to contribute new problems (and corrections to old ones) to the database, and could help me maintain the Github project;")],
[#strong[#text("You know things about web design")]#text(" and have suggestions for how this website could look or perform better;")],
[#strong[#text("You know things about Python/Flask/HTML/SQL/whatever")]#text(" and want to help me code cool new features on the website;")],
[#strong[#text("You know about accessibility")]#text(" and have an idea how I can make this website more accessible (to any group of people);")],
[#strong[#text("You are a mathematician")]#text(" who has thought about some of the problems here and wants to write an expanded commentary for one of them, with lots of references, comparisons to other problems, and other miscellaneous insights (mathematician here is interpreted broadly, in that if you have thought about the problems on this site and are willing to write such a commentary you qualify);")],
[#strong[#text("You knew Erdős")]#text(" and have any memories or personal correspondence concerning a particular problem;")],
[#strong[#text("You have solved an Erdős problem")]#text(" and I’ll update the website accordingly (and apologies if you solved this problem some time ago);")],
[#strong[#text("You have spotted a mistake, typo, or duplicate problem, or anything else that has confused you")]#text(" and I’ll correct things;")],
[#strong[#text("You are a human being with an internet connection")]#text(" and want to volunteer a particular Erdős paper or problem list to go through and add new problems from (please let me know before you start, to avoid duplicate efforts);")],
[#strong[#text("You have any other ideas or suggestions")]#text(" – there are probably lots of things I haven’t thought of, both in ways this site can be made better, and also what else could be done from this project. Please get in touch with any ideas!")]
)

#text("I for instance contributed a ")#link("https://www.erdosproblems.com/587")[#text("problem to the site")]#text(" (#587) that Erdős himself gave to me personally (this was the topic of a somewhat well known photo of Paul and myself, and which he communicated again to be shortly afterwards on a postcard; links to both images can be found by following the above link). As it turns out, this particular problem was essentially solved in 2010 ")#link("https://zbmath.org/1222.11012")[#text("by Nguyen and Vu")]#text(".")

#text("(Incidentally, I also spoke at the same conference that Thomas spoke at, on ")#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/")[#text("my recent work with Gowers, Green, and Manners")]#text("; ")#link("https://www.youtube.com/watch?v=ywJF4as9ocA&ab_channel=INISeminarRoom1")[#text("here is the video of my talk")]#text(", and ")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/04/pfr.pdf")[#text("here are my slides")]#text(".)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684756")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2024")])]

#text("It will be great to see if AI can solve some of Erdos’s problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684763")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2024")])]

#text("Suggestion for the Erdös problems website: when giving Math Reviews links, link to the relay station rather than directly to the review. This makes the link work even for those who aren’t logged in to Math Reviews (or have no access rights at all).")

#text("For example for ")#link("https://www.erdosproblems.com/48")[#text("problem 48")]#text(" I would replace the current link")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://mathscinet.ams.org/mathscinet/article?mr=2651943")[#text("https://mathscinet.ams.org/mathscinet/article?mr=2651943")]
]

#text("with")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://mathscinet.ams.org/mathscinet/relay-station?mr=2651943")[#text("https://mathscinet.ams.org/mathscinet/relay-station?mr=2651943")]
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684765")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2024")])]

#text("This change has been made, thanks!")

#text("I’ll try to check this comment section also, but for all others and to avoid filling this comment section with typo spotting etc, if you have a correction/suggestion please email it directly to ")#link("mailto:erdosproblemsonline@gmail.com")[#text("erdosproblemsonline@gmail.com")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2024")])]

#text("Do you know ")#link("https://zbmath.org/")[#text("https://zbmath.org/")]#text(" ???")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-685181")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2024")])]

#text("Re to Lior Silberman’s suggestion: it would be even better to use Zbmath instead of Mathscinet, since Zbmath has an open license and Mathscinet is paywalled. Let us promote the use of open resources.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684764")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2024")])]

#text("I would disagree in widespread use of ai within mathematics , it is such that we are giving up on our intuition for ai , ai wouldn’t have been intuitive as human being does , they couldn’t objectively verifies a proof , it was much so from the predecessor’s knowledge . Now I shall outline some critical flaws of ai system.")

#enum(start: 1, 
[#text("it can’t determine implication , when a computer sees A and B proposition , it can’t objectively verifies of A -> B , in reality , A -> B means A event causes B event , but in computer , it verifies using truth tables , which is completely of error , since there is a difference between implication in computer terms by means of cause in real life , we mean A cause B in nature to propose that there exists some chain of causation that A causes B , but in computer sense , A is true and B is true doesn’t verify itself as some chain of causation . False in itself at the time of conception .")],
[#text("second , it couldn’t wait , evolve , progress , nourish as human thinks , these neural networks are constantly connected with each other , making all of the ideas are in constant body of knowledge , even though it might be possible in isolating it , but it would require some infinite amount of resources , in keeping all of the new ideas programmed into some neural body of ai in check , whereas in human , they objectively verifies , by human intuition , which is somewhat natural to human conscious , which is unable to be programmed into some ai , of some knowledge and slowly builds upon .")],
[#text("it is simply based on previous knowledge , which has in itself , no internal contradiction , henceforth , not just that it would face errors from contradiction in real world , it also can’t , in fact , objectively produce any constructive criticism on itself")]
)

#text("no matter how many ai is being programmed wouldn’t change the matter , in fact , problem is only exponential speaking by the amount of ai")

#text("in short , ai would simply mimics human thinking and consciousness , perhaps constant stream of real time data , it would mimic their thinking , but it wouldn’t be somehow transcends over human being due to it being the artificial creation of human , it would always be dumber than human , of course , it can be said maybe , if there exists some god , is the same terminology , it that makes some easier relation for you in understanding , ai would always be dumber than human beings , at least , philosophers .")

#text("So stop relying on some ai , and believe it to be some kind of smart of something , by experience , for example bard ai , as commented by lots of their internal employee , from what I have encountered , it always takes a specific pattern of praising , and then forcefully criticising you in any matter , citing the previous research or studies as a matter of refute , for such non-constructive pure criticism , I wonder if it is being smart at all , any children of age 10 would have done it , and in reality , they does it often")

#text("as a comment on your previous work , so to say , I don’t think that entropy should be applied in some geometry work , perhaps I am not being an expert , but in such a sense , it is definitely being irrational .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684776")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2024")])]

#text("April 21st, Ji, everything is going well")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d74331769f9884e83d09fbea5aa3c694231dd7dc9c45b24c9d994abc561d2d1-7dd61dbef07912d01f591751c5a1a7840231681245ca73889bdb4c133bc0eed4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prashant Patil")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684777")[#strong[#text("Prashant Patil")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2024")])]

#text("Loving where it is going. We finally have people come together to solve problems ( not mentioning a math problem ), Isn’t this what we always wanted. All people who have something to contribute come together and do something about it?")

#text("This is a real utopia. Slowly we will see people from every fields doing the same thing. Hope everyone doing good.")

#text("Have a nice day/evening ahead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29aa23328daec42bb47540bb823bd8b5e470e2bf51e42ca11d2aa276e676496d-5beeea2d53aa7f21d94d536aaa2517b534660e10cdb380f85f3d4a4e340835d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oliverknill")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684782")[#strong[#text("oliverknill")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2024")])]

#text("Posting a list of link resources is a bit of a deja-vue from the 1990ies, when the web started to grow. Everybody who had some presence then, posted their favorite link lists, like also in math. Then “search” came and made these efforts obsolete, also because web-designers constantly reorganized and link rot exploded (in a typical math blog, many of the linked math blogs are obsolete). And then came the SOE’s, challenging search with content rot. How to organize this in a time when the target moves every year a multiple times faster than before. In a field like AI, where every few weeks, the landscape looks different. A public spread-sheet like the one posted would have to be updated a lot. If public editing is possible, it will be polluted soon by players wanting to promote their own model. On Wikipedia, one has the moderator constraints. Search companies promote their own models. Bots of course are biased too: I just asked Chat GPT about “a list of web resources on AI”. Of course Open AI appeared first and competitors like Claude or Llama were not even mentioned in the top 10. That’s where one of the main problem of AI will be. Who controls the knowledge and information? Who can sell better and faster?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684786")[#strong[#text("El problema de Erdős-Tao - Gaussianos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2024")]

#text("[…] y ha sido el propio Tao quien nos lo ha contado. Hace un par de días, Tao publicaba en su blog un post en el que hablaba del tema. El contexto era hablar del reciente lanzamiento de la web erdosproblems.com, en la que el […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2024")])]

#text("AI (if) can solve, isn’t it a risky thing ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2024")])]

#text("The current link to your talk is inaccessible as it is a “private video”. The right link is here: ")#link("https://www.youtube.com/watch?v=ywJF4as9ocA&ab_channel=INISeminarRoom1")[#text("https://www.youtube.com/watch?v=ywJF4as9ocA&ab_channel=INISeminarRoom1")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684838")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2024")])]

#text("I must admit, I am disappointed by your unreserved promotion of AI. AI has far greater social implications, which includes mass automation of work previously done by humans using creative decisions. It also isolates people and is a powerful tool for enhancing consumerism within the context of global capitalism. It is designed to squeeze out the part of art that is to transmit human experience and will be used exactly to that effect so that we no longer have the strength we gain by such communication, which in turn is another step towards our enslavement by technology.")

#text("As tool for computer science, of course it has its uses for mathematics but I wish you and other mathematicians would go beyond the needs of playing the game of creating these abstractions and actually look at the impact of your work and the support you give to this tool.")

#text("You are certainly an exceptionally intelligent individual so it would be useful to take a moment to study the power of mathematics and computer science to further a consumerist society that is destroying the biosphere — with AI now at the forefront.")

#text("-Dr. Jason Polak (PhD Mathematics in number theory).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-684933")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2024")])]

#text("The YouTube link you gave to Thomas Bloom’s talk is private. I assume this is unintentional?")

#emph[#text("[It seems the status of this video has changed recently; I do not know why. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-685595")[#strong[#text("Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("[…] Erdös problem site was created last year, and announced earlier this year on this blog. Every so often, I have taken a look at a random problem from the site for fun. A few times, I was […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/19/two-announcements-ai-for-math-resources-and-erdosproblems-com/#comment-687234")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2025")])]

#text("Also the link to the talk by Thomas leads to a private video. A search didn’t lead to the particular talk. Hopefully this can be corrected as well.")
]
