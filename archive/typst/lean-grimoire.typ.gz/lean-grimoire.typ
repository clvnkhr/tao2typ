// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/11/lean-grimoire/
// Converted to Typst by tao2typ: "2026-11-12T15:28:31.944648+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lean Grimoire", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lean Grimoire")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-12 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Back in July, I ")#link("https://terrytao.wordpress.com/tag/applets/")[#text("started experimenting")]#text(" with using modern coding agents to build a number of mathematical visualization applets. With the extremely hectic events of the last few months, I had to set those projects aside; but I recently found a bit of time to work on one such project that I had started back then, which was to modernize a ")#link("https://teorth.github.io/QED/")[#text("Javascript interactive textbook I had made back in 2018")]#text(", entitled “QED”, and ")#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/")[#text("announced previously on this blog")]#text(". The purpose of that textbook was to teach propositional and first-order logic in the form of a “crafting game”, where one applied various rules of logic to reach a desired conclusion from a given set of hypotheses.")

#text("With a coding agent, I ")#link("https://teorth.github.io/tao-web/apps/grimoire.html")[#text("rebuilt the game")]#text(" (which I have given the working title of “Lean Grimoire”) with a number of new features, for instance giving the option to show an in-progress Lean proof of one’s game state. Just for fun, I also added an option to play in a “fantasy mode” in which various game elements are depicted using fantasy-themed flavor text (for instance, mathematical statements become “potions”, mathematical expressions become “scrolls”, and so forth). Here is a typical screenshot, in which one has nearly completed the proof of the assertion ")#mi("A \\implies A \\wedge B")#text(" given ")#mi("A \\implies B")#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/11/image.png")[#image("../assets/bd433c29948de0dce562a92747f23674ed6033562b5d6a9bc1e8bd30aaf4e639-04c4fb70831fb4f411b60b7482e30b6e05c03c69c80f2adab32da7dc498a792f.png", width: 90%)]
]

#text("I would be interested in having some playtesting of this app to make it more useful as a means to teach logical proofs and/or Lean.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699349")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A question for clarification: By “game” you mean “deterministic 1-player game”? In that case it might also be called “crafting puzzle” to avoid confusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A implies A and B?")

#emph[#text("[Oops, forgot to mention that ")#mi("A \\implies B")#text(" is given as a hypothesis for this particular level -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699352")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I played several of the levels. I think the intro tactic is confusing for players who are just being introduced to it as a game, without prior exposure to this sort of tactic in a theorem prover.")

#text("In my opinion, if you want to make it engaging and understandable for people who don’t already understand the material on some level, I would really lean into the visualization. Things should fit together and break apart in a visual/animated way. I am thinking of something like Opus Magnum, if you have seen that game.")

#text("I might treat implications as “recipes”, when you start an intro tactic, it zooms into a scroll depicting a world with the introduced variables added. Then when you are done it zooms back out to show that scroll existing in the real world as an implication. You could show this zoom in and out recursively.")

#text("Just my two cents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699354")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("Thanks for the feedback! I had been following reasonably closely the interface of my previously (manually coded) interactive textbook, which was limited by my ability to work with complex graphics, but I am now realizing that with modern coding agents I can indeed implement more sophisticated animations. I got my agent to create a mockup of how one might animate a level that involves ")#raw("intro")#text(", such as ")#mi("A \\implies A \\wedge A")#text(", by creating a “scroll” one zooms into and out of as you suggest: ")#link("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")[#text("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")]#text(" . If this seems like a significantly more conceptual type of interface to navigate, I can try to develop it further.")

#text("p.s. my agent also pointed me to the game “")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” that has a similar “zoom in / zoom out” mechanic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699359")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("“")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” is interesting. It reminds me of “Sokoban”. there is complexity analysis (NP-hard; PSpace-complete) back in the late 1990s.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/161ebc022821268b1c80f6715fa7acfa514968bc9066623550ba9f9edc7055ca-50459a384a3c566d54cd879c52a49550d995fa421d4e8360dd59349761953378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shawn Hood")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699353")[#strong[#text("Shawn Hood")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I’m not familiar with Lean myself, but have been armchair following some various discussions in mathematical discipline due to the LLM action of late. My son and I would love to play test the Fantasy version and happy to share feedback")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a190384e2d1962e7bf8a57e87c41fdae71e8488202eb4f0c1d8732b6fa7bedb0-8579eeaa773bd1662be7cd243dd9e7d6da105934c6a5acea8eaa1627ea766af2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neunhoef")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699355")[#strong[#text("neunhoef")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I would recommend to switch on “Explicit Parantheses” by default in the beginning, because then one does not have to know that conjunction binds right associatively in Lean. I got confused for a moment by this.")

#emph[#text("[Now implemented – T.]")]
]
