// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/11/lean-grimoire/
// Converted to Typst by tao2typ: "2026-11-17T16:16:57.884791+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lean Grimoire", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lean Grimoire")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-17 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Back in July, I ")#link("https://terrytao.wordpress.com/tag/applets/")[#text("started experimenting")]#text(" with using modern coding agents to build a number of mathematical visualization applets. With the extremely hectic events of the last few months, I had to set those projects aside; but I recently found a bit of time to work on one such project that I had started back then, which was to modernize a ")#link("https://teorth.github.io/QED/")[#text("Javascript interactive textbook I had made back in 2018")]#text(", entitled “QED”, and ")#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/")[#text("announced previously on this blog")]#text(". The purpose of that textbook was to teach propositional and first-order logic in the form of a “crafting game”, where one applied various rules of logic to reach a desired conclusion from a given set of hypotheses.")

#text("With a coding agent, I ")#link("https://teorth.github.io/tao-web/apps/grimoire.html")[#text("rebuilt the game")]#text(" (which I have given the working title of “Lean Grimoire”) with a number of new features, for instance giving the option to show an in-progress Lean proof of one’s game state. Just for fun, I also added an option to play in a “fantasy mode” in which various game elements are depicted using fantasy-themed flavor text (for instance, mathematical statements become “potions”, mathematical expressions become “scrolls”, and so forth). Here is a typical screenshot, in which one has nearly completed the proof of the assertion ")#mi("A \\implies A \\wedge B")#text(" given ")#mi("A \\implies B")#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/11/image.png")[#image("../assets/bd433c29948de0dce562a92747f23674ed6033562b5d6a9bc1e8bd30aaf4e639-04c4fb70831fb4f411b60b7482e30b6e05c03c69c80f2adab32da7dc498a792f.png", width: 90%)]
]

#text("I would be interested in having some playtesting of this app to make it more useful as a means to teach logical proofs and/or Lean.")

#heading(level: 1)[#text("Comments (53)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699349")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A question for clarification: By “game” you mean “deterministic 1-player game”? In that case it might also be called “crafting puzzle” to avoid confusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A implies A and B?")

#emph[#text("[Oops, forgot to mention that ")#mi("A \\implies B")#text(" is given as a hypothesis for this particular level -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699352")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I played several of the levels. I think the intro tactic is confusing for players who are just being introduced to it as a game, without prior exposure to this sort of tactic in a theorem prover.")

#text("In my opinion, if you want to make it engaging and understandable for people who don’t already understand the material on some level, I would really lean into the visualization. Things should fit together and break apart in a visual/animated way. I am thinking of something like Opus Magnum, if you have seen that game.")

#text("I might treat implications as “recipes”, when you start an intro tactic, it zooms into a scroll depicting a world with the introduced variables added. Then when you are done it zooms back out to show that scroll existing in the real world as an implication. You could show this zoom in and out recursively.")

#text("Just my two cents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699354")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("Thanks for the feedback! I had been following reasonably closely the interface of my previously (manually coded) interactive textbook, which was limited by my ability to work with complex graphics, but I am now realizing that with modern coding agents I can indeed implement more sophisticated animations. I got my agent to create a mockup of how one might animate a level that involves ")#raw("intro")#text(", such as ")#mi("A \\implies A \\wedge A")#text(", by creating a “scroll” one zooms into and out of as you suggest: ")#link("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")[#text("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")]#text(" . If this seems like a significantly more conceptual type of interface to navigate, I can try to develop it further.")

#text("p.s. my agent also pointed me to the game “")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” that has a similar “zoom in / zoom out” mechanic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699359")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("“")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” is interesting. It reminds me of “Sokoban”. there is complexity analysis (NP-hard; PSpace-complete) back in the late 1990s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/161ebc022821268b1c80f6715fa7acfa514968bc9066623550ba9f9edc7055ca-50459a384a3c566d54cd879c52a49550d995fa421d4e8360dd59349761953378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of enchantingsecretlyfc1dc3c400")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699367")[#strong[#text("enchantingsecretlyfc1dc3c400")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Sokoban! Great game")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/161ebc022821268b1c80f6715fa7acfa514968bc9066623550ba9f9edc7055ca-50459a384a3c566d54cd879c52a49550d995fa421d4e8360dd59349761953378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shawn Hood")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699353")[#strong[#text("Shawn Hood")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I’m not familiar with Lean myself, but have been armchair following some various discussions in mathematical discipline due to the LLM action of late. My son and I would love to play test the Fantasy version and happy to share feedback")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a190384e2d1962e7bf8a57e87c41fdae71e8488202eb4f0c1d8732b6fa7bedb0-8579eeaa773bd1662be7cd243dd9e7d6da105934c6a5acea8eaa1627ea766af2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neunhoef")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699355")[#strong[#text("neunhoef")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I would recommend to switch on “Explicit Parantheses” by default in the beginning, because then one does not have to know that conjunction binds right associatively in Lean. I got confused for a moment by this.")

#emph[#text("[Now implemented – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52582ede8a5998612e024b8d9b2d998c2df38c0556b73e6e5f4e7e379e0ef205-e01020e5c2c5ba180b5dbbd6559399cfd4ac3050527395cfca30cf59e487d019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699360")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("I love the idea, but perhaps the logic notation (A ^ B) needs more expansion than the logic terms (hypothesis, statements)? The informal presentation of the steps is excellent, and if you had similarly informal ways of expressing the goal and the steps you could take to get there you might connect with a more general audience of players (and from there tempt them into learning the more technical notation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699376")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Thanks for the suggestion! There is now a “Plain English” version for the logical expressions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd8bf3c8c75562ac54bebde0a10d320060702c3d66248d9aae05ff0288669b1-db6a5199b74e557e6890b959866d30c559ceb23327c55ad5dc74eb77f141a626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Daly")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699361")[#strong[#text("Timothy Daly")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("You might want to look at Patrick Massot’s graph of the LEAN theorems.")

#text("I show those that need to be proven. Your game might be an interesting")

#text("student guidance project, especially if they use an LLM to help. The")

#text("students could be proving real theorems while learning")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Check out the comments on Hacker News: ")#link("https://news.ycombinator.com/item?id=50462375")[#text("https://news.ycombinator.com/item?id=50462375")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699363")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Maybe add a “Hint” system? Even knowing istintively why a proposition is true, it is not easy to translate it into Lean procedures.")

#text("On the other hand, you can run an agent and add for each problem what is the minimum possible number of steps for any given problem given the available resources/recipes at the moment. This would add to the challenge for already experienced users that are not satisfied with longer solutions.")

#text("It has always been a dream of mine programming an actual videogame on math, but I barely can scrape time for anything, and not having access to any agent makes it borderline infeasible")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Thanks for the suggestions! Hints have now been added for each level, as well as an explicit count of steps compared against the shortest known solution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699364")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and I just noticed 7.12 is used in previous ones like 7.2")

#emph[#text("[Now re-ordered. Hopefully this should not impact existing saved game states. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699379")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and also I don’t see how to do 13.4 without knowing Pick that is explained later in 14.1")

#emph[#text("[Hint updated on this – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa7002f980bc9f3adff257e08ba0aa57205ecd6048d18584d87e6d4ee2228437-52285627566ef753cc59cb85ca6f216fb6631b1fde677af2e4157bdd39668a8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lovinged57041eed")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699371")[#strong[#text("lovinged57041eed")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Hello Terence.Thank you for sharing your conceptual scheme for “Lean Grimoire”. The name resonates right away.Initial thoughts and observations:- having a conformal analog, a locally “familiar” model,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("This is a very nice idea! Also, all good games for developing visualization, better logical reasoning (like finding reasoning flaws, for example), detecting patterns etc are all very welcome!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699378")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Something that I was telling my students that they have to battle when writing by hand, but they won’t face in the game, is malformed expressions. In the game they could combine recipes and get the wrong goal due to, say parentheses in places that are not those of the real goal. However, I didn’t see a way to obtain malformed expressions.")

#text("Maybe there could be a version of the grimoire that was scribbled over by a wizard apprentice and some recipes are malformed, perhaps deceptively close to other recipes that are well formed. The user still has to use the right ones. Or perhaps, both get to the goal and delete the malformed recipes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699484")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("Thinking about this, I think that *Lean* itself is the correct environment for this “hard mode” version of the game. To this end, I (through my coding agent) have now implemented a “playground” button that takes the current Lean “spellbook” and takes you to the Lean playground, where you can then complete the proof yourself using the full expressive power of Lean. (Of course, many of the exercises can be one-shotted using powerful Lean tactics such as ")#raw("grind")#text(", but presumably a serious student wanting to learn proof technique would eschew such tactics.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Shorter proof for 4.8:")

#text("— Lean Grimoire — exercise 4.8 (And.symm’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 5. THIS ONE IS SHORTER.")

#text("— We wish to prove (A ∧ B) → (B ∧ A).")#linebreak()#text("— Introduce A ∧ B:")#linebreak()#text("— From A ∧ B we deduce B ∧ A (the lemma And.comm’).")#linebreak()#text("— Discharging, we obtain (A ∧ B) → (B ∧ A).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem And.symm’ : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("have hABBA : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hBA : B ∧ A := And.comm’ hAB")#linebreak()#text("exact hBA")#linebreak()#text("exact hABBA")

#text("Also, there is a somewhat similar game if anyone is interested:")

#link("https://adam.math.hhu.de/#/g/leanprover-community/nng4")[#text("https://adam.math.hhu.de/#/g/leanprover-community/nng4")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699391")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("That works! I’ve updated the game to record this new proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699385")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and it would also be very helpful to know how to write statements with forall and exists in the scrolls…. it does not accept \\exists or ∃ or any other variant that I can think of")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Can you make a linear logic dlc?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/280e4053f2c99fc48d025d37b8e5c097fb942ffddaabc8d3c3e49a32ee0c8073-b8161083f39fb5f211b74368ffde5e9c1646c2c8479436b18b93401eb8ae9012.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PistachioCake")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699392")[#strong[#text("PistachioCake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("A shorter proof for Exercise 2.3!")

#raw("-- Lean Grimoire — exercise 2.3  (And.assoc_right)\n-- https://terrytao.wordpress.com/2026/11/11/lean-grimoire/\n-- Proved in 5 moves.  The shortest proof the game knows takes 6.  THIS ONE IS SHORTER.\n--\n-- We are given A ∧ (B ∧ C).\n-- We wish to prove (A ∧ B) ∧ C.\n-- From A ∧ (B ∧ C) we deduce (B ∧ C) ∧ A  (the lemma And.comm').\n-- From (B ∧ C) ∧ A we deduce B ∧ (C ∧ A)  (the lemma And.assoc_left).\n-- From B ∧ (C ∧ A) we deduce (C ∧ A) ∧ B  (the lemma And.comm').\n-- From (C ∧ A) ∧ B we deduce C ∧ (A ∧ B)  (the lemma And.assoc_left).\n-- From C ∧ (A ∧ B) we deduce (A ∧ B) ∧ C  (the lemma And.comm').\n-- This is what we wished to prove.  ∎\n\n-- Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with\n-- it. 2 of them, each as you proved it, deepest first.\n\n-- 2.1  (And.comm')\nsection\nvariable {A B : Prop}\n\ntheorem And.comm' (hAB : A ∧ B) : B ∧ A := by\n  have hA : A := And.left hAB\n  have hB : B := And.right hAB\n  have hBA : B ∧ A := And.intro hB hA\n  exact hBA\nend\n\n-- 2.2  (And.assoc_left)\nsection\nvariable {A B C : Prop}\n\ntheorem And.assoc_left (hABC : (A ∧ B) ∧ C) : A ∧ (B ∧ C) := by\n  have hAB : A ∧ B := And.left hABC\n  have hA : A := And.left hAB\n  have hB : B := And.right hAB\n  have hC : C := And.right hABC\n  have hBC : B ∧ C := And.intro hB hC\n  have hABC2 : A ∧ (B ∧ C) := And.intro hA hBC\n  exact hABC2\nend\n\n-- and the proof itself:\n\nvariable {A B C : Prop}\n\ntheorem And.assoc_right (hABC : A ∧ (B ∧ C)) : (A ∧ B) ∧ C := by\n  have hBCA : (B ∧ C) ∧ A := And.comm' hABC\n  have hBCA2 : B ∧ (C ∧ A) := And.assoc_left hBCA\n  have hCAB : (C ∧ A) ∧ B := And.comm' hBCA2\n  have hCAB2 : C ∧ (A ∧ B) := And.assoc_left hCAB\n  have hABC2 : (A ∧ B) ∧ C := And.comm' hCAB2\n  exact hABC2\n", block: true)

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("one step proof for Exercise 4.3:")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("— Lean Grimoire — exercise 6.8 (Or.assoc_left)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 14 moves. The shortest proof the game knows takes 17. THIS ONE IS SHORTER.")

#text("— We are given (A ∨ B) ∨ C.")#linebreak()#text("— We wish to prove A ∨ (B ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∨ C we deduce A ∨ (B ∨ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, C we deduce B ∨ C (disjunction introduction (left)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From C, B we deduce B ∨ C (disjunction introduction (right)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∨ C)).")#linebreak()#text("— From A → (A ∨ (B ∨ C)), B → (A ∨ (B ∨ C)) we deduce (A ∨ B) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)), (A ∨ B) ∨ C we deduce A ∨ (B ∨ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by")#linebreak()#text("have hAABC : A → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inl hA")#linebreak()#text("exact hABC2")#linebreak()#text("have hBABC : B → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBC : B ∨ C := Or.inl hB")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hCABC : C → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hC")#linebreak()#text("have hBC : B ∨ C := Or.inr hC")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text("have hABCABC : ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) := fun h => Or.elim h hABABC hCABC")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := hABCABC hABC")#linebreak()#text("exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699396")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("— Lean Grimoire — exercise 9.7 (not_or_of_imp’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given A → B.")#linebreak()#text("— We wish to prove (¬ A) ∨ B.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), A → B we deduce B ∨ (¬ A) (the lemma Or.imp_left’).")#linebreak()#text("— From B ∨ (¬ A) we deduce (¬ A) ∨ B (the lemma Or.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : (A ∨ B) → (B ∨ A) := by")#linebreak()#text("have hABA : A → (B ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → (B ∨ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_or_of_imp’ (hAB : A → B) : (¬ A) ∨ B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hBA : B ∨ (¬ A) := Or.imp_left’ hAA hAB")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.comm’ hBA")#linebreak()#text("exact hAB2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efab1854848648e6c4948288f69a4c59799a16b6404b128267d77781fe5736dd-a2561b2000fbb44883fc1cc8398d7ab85870aff1df22756714c8c156b46caf8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699399")[#strong[#text("Jacob")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Shorter proof for 4.3:")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6de08af996f1b13b848c07305d34e8876f7bc6b7a77eb42047dcdc8ac5900725-85b0d5b83f7030bb5c34eb01a958aa331cef9d7e5909f3d107a929253025af54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dario Bajo")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699401")[#strong[#text("Dario Bajo")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Exercise 4.3")

#strong[#text("QED!")]#text(" You brewed ")#emph[#text("((A ∧ B) ∨ C) → ((A ∧ B) ∨ C)")]#text(" in 1 move.🏆 ")#strong[#text("A new record.")]#text(" The shortest proof this game knows takes 2 moves, so you have found something it does not. Please tell me about it: ")#strong[#text("Copy")]#text(" or ")#strong[#text("Save")]#text(" the proof below and leave it in the comments on ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("the blog post")]#text(".")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Shorter proof for 2.3 :D")#linebreak()#text("(Tried commenting this earlier, but it didn’t show up… If there’s a duplicate, sorry!)")

#text("— Lean Grimoire — exercise 2.3 (And.assoc_right)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 6. THIS ONE IS SHORTER.")

#text("— We are given A ∧ (B ∧ C).")#linebreak()#text("— We wish to prove (A ∧ B) ∧ C.")#linebreak()#text("— From A ∧ (B ∧ C) we deduce (B ∧ C) ∧ A (the lemma And.comm’).")#linebreak()#text("— From (B ∧ C) ∧ A we deduce B ∧ (C ∧ A) (the lemma And.assoc_left).")#linebreak()#text("— From B ∧ (C ∧ A) we deduce (C ∧ A) ∧ B (the lemma And.comm’).")#linebreak()#text("— From (C ∧ A) ∧ B we deduce C ∧ (A ∧ B) (the lemma And.assoc_left).")#linebreak()#text("— From C ∧ (A ∧ B) we deduce (A ∧ B) ∧ C (the lemma And.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 2.2 (And.assoc_left)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.assoc_left (hABC : (A ∧ B) ∧ C) : A ∧ (B ∧ C) := by")#linebreak()#text("have hC : C := And.right hABC")#linebreak()#text("have hAB : A ∧ B := And.left hABC")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBC : B ∧ C := And.intro hB hC")#linebreak()#text("have hABC2 : A ∧ (B ∧ C) := And.intro hA hBC")#linebreak()#text("exact hABC2")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem And.assoc_right (hABC : A ∧ (B ∧ C)) : (A ∧ B) ∧ C := by")#linebreak()#text("have hBCA : (B ∧ C) ∧ A := And.comm’ hABC")#linebreak()#text("have hBCA2 : B ∧ (C ∧ A) := And.assoc_left hBCA")#linebreak()#text("have hCAB : (C ∧ A) ∧ B := And.comm’ hBCA2")#linebreak()#text("have hCAB2 : C ∧ (A ∧ B) := And.assoc_left hCAB")#linebreak()#text("have hABC2 : (A ∧ B) ∧ C := And.comm’ hCAB2")#linebreak()#text("exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d8743ae0fe0c9a25f7a64cc22f010e4d6e7284961c7cd41c6bef0c04b0afdd-99b1fdce4cbf1d63453450780711acdac96e460d2707765fc440a052f7f99a20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kantian")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699406")[#strong[#text("Kantian")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("You advise to post shorter proof if we find one, so here is one")

#text("— Lean Grimoire — exercise 6.8 (Or.assoc_left)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 14 moves. The shortest proof the game knows takes 17. THIS ONE IS SHORTER.")#linebreak()#text("—")#linebreak()#text("— We are given (A ∨ B) ∨ C.")#linebreak()#text("— We wish to prove A ∨ (B ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∨ C we deduce A ∨ (B ∨ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, C we deduce B ∨ C (disjunction introduction (left)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∨ C)).")#linebreak()#text("— From A → (A ∨ (B ∨ C)), B → (A ∨ (B ∨ C)) we deduce (A ∨ B) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From C, B we deduce B ∨ C (disjunction introduction (right)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∨ C)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)), (A ∨ B) ∨ C we deduce A ∨ (B ∨ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by")#linebreak()#text(" have hAABC : A → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hA")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inl hA")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hBABC : B → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hB")#linebreak()#text(" have hBC : B ∨ C := Or.inl hB")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text(" have hCABC : C → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hC")#linebreak()#text(" have hBC : B ∨ C := Or.inr hC")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hABCABC : ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) := fun h => Or.elim h hABABC hCABC")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := hABCABC hABC")#linebreak()#text(" exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699428")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.5")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 11 moves. The shortest proof the game knows takes 14. THIS ONE IS SHORTER.")

#text("— We wish to prove (¬ (∃ X : Ω, P(X))) ↔ (∀ X : Ω, (¬ P(X))).")#linebreak()#text("— Introduce ¬ (∃ x : Ω, P(x)), then an arbitrary X : Ω:")#linebreak()#text("— Introduce P(X):")#linebreak()#text("— From P(X), X we deduce ∃ x : Ω, P(x) (existential introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ P(X).")#linebreak()#text("— Discharging, we obtain (¬ (∃ x : Ω, P(x))) → (∀ X : Ω, (¬ P(X))).")#linebreak()#text("— From (¬ (∃ x : Ω, P(x))) → (∀ X : Ω, (¬ P(X))) we deduce (¬ (¬ (∃ x : Ω, P(x)))) ∨ (∀ X : Ω, (¬ P(X))) (the lemma not_or_of_imp’).")#linebreak()#text("— Introduce ∀ X : Ω, (¬ P(X)):")#linebreak()#text("— From ∀ X : Ω, (¬ P(X)) we deduce ¬ (∃ X : Ω, P(X)) (the lemma forall_not_not_exists).")#linebreak()#text("— Discharging, we obtain (∀ X : Ω, (¬ P(X))) → (¬ (∃ X : Ω, P(X))).")#linebreak()#text("— From (¬ (∃ x : Ω, P(x))) → (∀ X : Ω, (¬ P(X))), (∀ X : Ω, (¬ P(X))) → (¬ (∃ X : Ω, P(X))) we deduce (¬ (∃ x : Ω, P(x))) ↔ (∀ X : Ω, (¬ P(X))) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 16 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hCCD : C → (C ∨ D) := by")#linebreak()#text("intro hC")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hACD : A → (C ∨ D) := implies_trans hAC hCCD")#linebreak()#text("have hDCD : D → (C ∨ D) := by")#linebreak()#text("intro hD")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := implies_trans hBD hDCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : (A ∨ B) → (B ∨ A) := by")#linebreak()#text("have hABA : A → (B ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → (B ∨ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 9.7 (not_or_of_imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem not_or_of_imp’ (hAB : A → B) : (¬ A) ∨ B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hBA : B ∨ (¬ A) := Or.imp_left’ hAA hAB")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.comm’ hBA")#linebreak()#text("exact hAB2")#linebreak()#text("end")

#text("— 6.11 (and_or_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem and_or_left’ (hABC : A ∧ (B ∨ C)) : (A ∧ B) ∨ (A ∧ C) := by")#linebreak()#text("have hA : A := And.left hABC")#linebreak()#text("have hBC : B ∨ C := And.right hABC")#linebreak()#text("have hBAB : B → (A ∧ B) := by")#linebreak()#text("intro hB")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("exact hAB")#linebreak()#text("have hCAC : C → (A ∧ C) := by")#linebreak()#text("intro hC")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.imp’ hBC hBAB hCAC")#linebreak()#text("exact hABAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hBA : B ∨ A := Or.comm’ hAB")#linebreak()#text("have hCA : C ∨ A := Or.imp_left’ hBA hBC")#linebreak()#text("have hAC : A ∨ C := Or.comm’ hCA")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.10 (or_and_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem or_and_left’ (hABC : A ∨ (B ∧ C)) : (A ∨ B) ∧ (A ∨ C) := by")#linebreak()#text("have hBCB : (B ∧ C) → B := by")#linebreak()#text("intro hBC")#linebreak()#text("have hB : B := And.left hBC")#linebreak()#text("exact hB")#linebreak()#text("have hAB : A ∨ B := Or.imp_right’ hABC hBCB")#linebreak()#text("have hBCC : (B ∧ C) → C := by")#linebreak()#text("intro hBC")#linebreak()#text("have hC : C := And.right hBC")#linebreak()#text("exact hC")#linebreak()#text("have hAC : A ∨ C := Or.imp_right’ hABC hBCC")#linebreak()#text("have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC")#linebreak()#text("exact hABAC")#linebreak()#text("end")

#text("— 8.14 (resolution’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem resolution’ (hAB : A ∨ B) (hnAC : (¬ A) ∨ C) : C ∨ B := by")#linebreak()#text("have hABAC : (A ∨ B) ∧ ((¬ A) ∨ C) := And.intro hAB hnAC")#linebreak()#text("have hABAABC : ((A ∨ B) ∧ (¬ A)) ∨ ((A ∨ B) ∧ C) := and_or_left’ hABAC")#linebreak()#text("have hABAB : ((A ∨ B) ∧ (¬ A)) → B := by")#linebreak()#text("intro hABA")#linebreak()#text("have hA : ¬ A := And.right hABA")#linebreak()#text("have hAB2 : A → B := by")#linebreak()#text("intro hA2")#linebreak()#text("have hB : B := absurd hA2 hA")#linebreak()#text("exact hB")#linebreak()#text("have hBB : B ∨ B := Or.imp_left’ hAB hAB2")#linebreak()#text("have hB : B := or_self_elim’ hBB")#linebreak()#text("exact hB")#linebreak()#text("have hBABC : B ∨ ((A ∨ B) ∧ C) := Or.imp_left’ hABAABC hABAB")#linebreak()#text("have hABCCAB : ((A ∨ B) ∧ C) → (C ∧ (A ∨ B)) := by")#linebreak()#text("intro hABC")#linebreak()#text("have hCAB : C ∧ (A ∨ B) := And.comm’ hABC")#linebreak()#text("exact hCAB")#linebreak()#text("have hBCAB : B ∨ (C ∧ (A ∨ B)) := Or.imp_right’ hBABC hABCCAB")#linebreak()#text("have hBCBAB : (B ∨ C) ∧ (B ∨ (A ∨ B)) := or_and_left’ hBCAB")#linebreak()#text("have hBC : B ∨ C := And.left hBCBAB")#linebreak()#text("have hCB : C ∨ B := Or.comm’ hBC")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 9.2 (not_not_elim)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) ∨ A := Or.comm’ hAA")#linebreak()#text("have hAA3 : (¬ (¬ A)) ∨ A := Or.inl hnnA")#linebreak()#text("have hAA4 : A ∨ A := resolution’ hAA2 hAA3")#linebreak()#text("have hA : A := or_self_elim’ hAA4")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 13.4 (forall_not_not_exists)")#linebreak()#text("section")#linebreak()#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")

#text("theorem forall_not_not_exists (hfn : ∀ X : Ω, (¬ P X)) : ¬ (∃ X : Ω, P X) := by")#linebreak()#text("have X : Ω := Classical.choice inferInstance")#linebreak()#text("have hX : ¬ P X := hfn X")#linebreak()#text("have hx : ¬ (¬ (¬ (∃ x : Ω, P x))) := by")#linebreak()#text("intro hx")#linebreak()#text("have hx2 : ∃ x : Ω, P x := not_not_elim hx")#linebreak()#text("have hx3 := hx2")#linebreak()#text("obtain ⟨a, ha⟩ := hx3")#linebreak()#text("have ha2 : ¬ P a := hfn a")#linebreak()#text("exact absurd ha ha2")#linebreak()#text("have hx2 : ¬ (∃ x : Ω, P x) := not_not_elim hx")#linebreak()#text("exact hx2")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")

#text("example : (¬ (∃ X : Ω, P X)) ↔ (∀ X : Ω, (¬ P X)) := by")#linebreak()#text("have hxX : (¬ (∃ x : Ω, P x)) → (∀ X : Ω, (¬ P X)) := by")#linebreak()#text("intro hx")#linebreak()#text("intro X")#linebreak()#text("have hX : ¬ P X := by")#linebreak()#text("intro hX")#linebreak()#text("have hx2 : ∃ x : Ω, P x := ⟨X, hX⟩")#linebreak()#text("exact absurd hx2 hx")#linebreak()#text("exact hX")#linebreak()#text("have hxX2 : (¬ (¬ (∃ x : Ω, P x))) ∨ (∀ X : Ω, (¬ P X)) := not_or_of_imp’ hxX")#linebreak()#text("have hXX : (∀ X : Ω, (¬ P X)) → (¬ (∃ X : Ω, P X)) := by")#linebreak()#text("intro hX")#linebreak()#text("have hX2 : ¬ (∃ X : Ω, P X) := forall_not_not_exists hX")#linebreak()#text("exact hX2")#linebreak()#text("have hxX3 : (¬ (∃ x : Ω, P x)) ↔ (∀ X : Ω, (¬ P X)) := Iff.intro hxX hXX")#linebreak()#text("exact hxX3")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699429")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.6")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 9. THIS ONE IS SHORTER.")

#text("— We are given ¬ (∃ X : Ω, (P(X) ∧ Q(X))), ∀ X : Ω, (R(X) → P(X)).")#linebreak()#text("— We wish to prove ¬ (∃ X : Ω, (R(X) ∧ Q(X))).")#linebreak()#text("— Introduce ∃ X : Ω, (R(X) ∧ Q(X)):")#linebreak()#text("— Since ∃ X : Ω, (R(X) ∧ Q(X)), fix X : Ω with R(X) ∧ Q(X).")#linebreak()#text("— From ∀ X : Ω, (R(X) → P(X)), X we deduce R(X) → P(X) (universal instantiation (specialization)).")#linebreak()#text("— From R(X) ∧ Q(X), R(X) → P(X) we deduce P(X) ∧ Q(X) (the lemma And.imp_left’).")#linebreak()#text("— From P(X) ∧ Q(X), X we deduce ∃ x : Ω, (P(x) ∧ Q(x)) (existential introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (∃ X : Ω, (R(X) ∧ Q(X))).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.8 (And.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_left’ (hAB : A ∧ B) (hAC : A → C) : C ∧ B := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hCB : C ∧ B := And.intro hC hB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hnpq : ¬ (∃ X : Ω, (P X ∧ Q X))) (hRP : ∀ X : Ω, (R X → P X)) : ¬ (∃ X : Ω, (R X ∧ Q X)) := by")#linebreak()#text("have hXX : ¬ (∃ X : Ω, (R X ∧ Q X)) := by")#linebreak()#text("intro hXX")#linebreak()#text("have hXX3 := hXX")#linebreak()#text("obtain ⟨X, hXX2⟩ := hXX3")#linebreak()#text("have hXX3 : R X → P X := hRP X")#linebreak()#text("have hXX4 : P X ∧ Q X := And.imp_left’ hXX2 hXX3")#linebreak()#text("have hxx : ∃ x : Ω, (P x ∧ Q x) := ⟨X, hXX4⟩")#linebreak()#text("exact absurd hxx hnpq")#linebreak()#text("exact hXX")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699430")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.7")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 4 moves. The shortest proof the game knows takes 7. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → Q(X)), ∃ X : Ω, (R(X) ∧ P(X)).")#linebreak()#text("— We wish to prove ∃ X : Ω, (R(X) ∧ Q(X)).")#linebreak()#text("— Since ∃ X : Ω, (R(X) ∧ P(X)), fix X : Ω with R(X) ∧ P(X).")#linebreak()#text("— From ∀ X : Ω, (P(X) → Q(X)), X we deduce P(X) → Q(X) (universal instantiation (specialization)).")#linebreak()#text("— From R(X) ∧ P(X), P(X) → Q(X) we deduce R(X) ∧ Q(X) (the lemma And.imp_right’).")#linebreak()#text("— From R(X) ∧ Q(X), X we deduce ∃ x : Ω, (R(x) ∧ Q(x)) (existential introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.9 (And.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_right’ (hAB : A ∧ B) (hBC : B → C) : A ∧ C := by")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ P X)) : ∃ X : Ω, (R X ∧ Q X) := by")#linebreak()#text("have hXX2 := hex")#linebreak()#text("obtain ⟨X, hXX⟩ := hXX2")#linebreak()#text("have hXX2 : P X → Q X := hPQ X")#linebreak()#text("have hXX3 : R X ∧ Q X := And.imp_right’ hXX hXX2")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ Q x) := ⟨X, hXX3⟩")#linebreak()#text("exact hxx")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699431")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.15")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → Q(X)), ∃ X : Ω, (R(X) ∧ (¬ Q(X))).")#linebreak()#text("— We wish to prove ∃ X : Ω, (R(X) ∧ (¬ P(X))).")#linebreak()#text("— Since ∃ X : Ω, (R(X) ∧ (¬ Q(X))), fix X : Ω with R(X) ∧ (¬ Q(X)).")#linebreak()#text("— From ∀ X : Ω, (P(X) → Q(X)), X we deduce P(X) → Q(X) (universal instantiation (specialization)).")#linebreak()#text("— From P(X) → Q(X) we deduce (¬ Q(X)) → (¬ P(X)) (the lemma mt’).")#linebreak()#text("— From R(X) ∧ (¬ Q(X)), (¬ Q(X)) → (¬ P(X)) we deduce R(X) ∧ (¬ P(X)) (the lemma And.imp_right’).")#linebreak()#text("— From R(X) ∧ (¬ P(X)), X we deduce ∃ x : Ω, (R(x) ∧ (¬ P(x))) (existential introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 5.9 (And.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_right’ (hAB : A ∧ B) (hBC : B → C) : A ∧ C := by")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ (¬ Q X))) : ∃ X : Ω, (R X ∧ (¬ P X)) := by")#linebreak()#text("have hXX2 := hex")#linebreak()#text("obtain ⟨X, hXX⟩ := hXX2")#linebreak()#text("have hXX2 : P X → Q X := hPQ X")#linebreak()#text("have hXX3 : (¬ Q X) → (¬ P X) := mt’ hXX2")#linebreak()#text("have hXX4 : R X ∧ (¬ P X) := And.imp_right’ hXX hXX3")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ (¬ P x)) := ⟨X, hXX4⟩")#linebreak()#text("exact hxx")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699432")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.16")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 4 moves. The shortest proof the game knows takes 7. THIS ONE IS SHORTER.")

#text("— We are given ∃ X : Ω, (P(X) ∧ (¬ Q(X))), ∀ X : Ω, (P(X) → R(X)).")#linebreak()#text("— We wish to prove ∃ X : Ω, (R(X) ∧ (¬ Q(X))).")#linebreak()#text("— Since ∃ X : Ω, (P(X) ∧ (¬ Q(X))), fix X : Ω with P(X) ∧ (¬ Q(X)).")#linebreak()#text("— From ∀ X : Ω, (P(X) → R(X)), X we deduce P(X) → R(X) (universal instantiation (specialization)).")#linebreak()#text("— From P(X) ∧ (¬ Q(X)), P(X) → R(X) we deduce R(X) ∧ (¬ Q(X)) (the lemma And.imp_left’).")#linebreak()#text("— From R(X) ∧ (¬ Q(X)), X we deduce ∃ x : Ω, (R(x) ∧ (¬ Q(x))) (existential introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.8 (And.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_left’ (hAB : A ∧ B) (hAC : A → C) : C ∧ B := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hCB : C ∧ B := And.intro hC hB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hex : ∃ X : Ω, (P X ∧ (¬ Q X))) (hPR : ∀ X : Ω, (P X → R X)) : ∃ X : Ω, (R X ∧ (¬ Q X)) := by")#linebreak()#text("have hXX2 := hex")#linebreak()#text("obtain ⟨X, hXX⟩ := hXX2")#linebreak()#text("have hXX2 : P X → R X := hPR X")#linebreak()#text("have hXX3 : R X ∧ (¬ Q X) := And.imp_left’ hXX hXX2")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ (¬ Q x)) := ⟨X, hXX3⟩")#linebreak()#text("exact hxx")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699433")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("In Exercise 16.1, trying to introduce X : Set, it instead introduces X : \\Omega, so following the hints gets you to a wrong solution")

#emph[#text("[Now fixed, hopefully – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699439")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 7.4 (Iff.refl’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We wish to prove A ↔ A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From A → A, A → A we deduce A ↔ A (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem Iff.refl’ : A ↔ A := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAA2 : A ↔ A := Iff.intro hAA hAA")#linebreak()#text("exact hAA2")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699450")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2026")])]

#text("If this is going to be hosted, perhaps it could automatically accept and integrate shorter proofs for exercises, since they can be verified? Adding them manually will not scale well. (Perhaps it could also record multiple known proofs of various lengths and say if they’re known to it – though that’s getting into territory where you’d an agent to try to decide if it was really “new” for anything that isn’t super short)")

#emph[#text("[The game is not hosted right now (to avoid various security/privacy/cost issues), but I have implemented a streamlining of the reporting process -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96cd159cba9b8645acb676fd46ad3f5324a0d34780dfd4efaeb11538bbe5264a-1253958c83b482d3d0fdf4c302c8b082789c9abd8a4a85078f0ce09b2efee4a8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ram Anvesh Reddy")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699454")[#strong[#text("Ram Anvesh Reddy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2026")])]

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("Two shorter proofs.")

#text("— Lean Grimoire — exercise 12.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → R(X)), ∀ X : Ω, (S(X) → P(X)).")#linebreak()#text("— We wish to prove ∀ X : Ω, (S(X) → R(X)).")#linebreak()#text("— Introduce an arbitrary X : Ω:")#linebreak()#text("— From ∀ X : Ω, (S(X) → P(X)), X we deduce S(X) → P(X) (universal instantiation (specialization)).")#linebreak()#text("— From ∀ X : Ω, (P(X) → R(X)), X we deduce P(X) → R(X) (universal instantiation (specialization)).")#linebreak()#text("— From S(X) → P(X), P(X) → R(X) we deduce S(X) → R(X) (the lemma implies_trans).")#linebreak()#text("— Discharging, we obtain ∀ X : Ω, (S(X) → R(X)).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")#linebreak()#text("variable {S : Ω → Prop}")

#text("example (hpr : ∀ X : Ω, (P X → R X)) (hsp : ∀ X : Ω, (S X → P X)) : ∀ X : Ω, (S X → R X) := by")#linebreak()#text("have hXX : ∀ X : Ω, (S X → R X) := by")#linebreak()#text("intro X")#linebreak()#text("have hXX : S X → P X := hsp X")#linebreak()#text("have hXX2 : P X → R X := hpr X")#linebreak()#text("have hXX3 : S X → R X := implies_trans hXX hXX2")#linebreak()#text("exact hXX3")#linebreak()#text("exact hXX")

#text("— Lean Grimoire — exercise 9.2 (not_not_elim)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 7 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ¬ (¬ A).")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From ¬ A, ¬ (¬ A), A we deduce A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ A) → A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From A → A, (¬ A) → A we deduce (A ∨ (¬ A)) → A (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ (¬ A)) → A, A ∨ (¬ A) we deduce A (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : A → A := Impl.idem")#linebreak()#text("have hAAA : (A ∨ (¬ A)) → A := fun h => Or.elim h hAA3 hAA2")#linebreak()#text("have hA : A := hAAA hAA")#linebreak()#text("exact hA")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#enum(start: 1, 
[#text("Thank you for the nice game. For me it proved to be quite addictive. There are a couple of bugs in the Lean Gimoire in the later levels.")]
)

#text("In Exercise 16.1 if one introduces X : Set, it actually introduces X : Omega, which breaks things. I was able to patch it on the JavaScript console using the following snippet (LLM generated):")

#text("(() => {")#linebreak()#text("const game = window.__grimoire;")#linebreak()#text("const original = game.G.openVariable;")

#text("game.G.openVariable = (env, v) => {")#linebreak()#text("const term = game.state.terms.find(")#linebreak()#text("t => t.tag === “var” && t.name === v.name")#linebreak()#text(");")

#raw("return original(env, {\n  ...v,\n  sort: term?.sort ?? v.sort\n});\n", block: true)

#text("};")

#text("console.log(“Variable sort bug patched!”);")#linebreak()#text("})();")

#emph[#text("[Now fixed, hopefully – T.]")]

#text("2. In Exercise 17.3, I got “unexpected character “*”” when entering f(c) * c on the term bench. Apparently the Lean Grimoire expects the Unicode symbol ∗ (U+2217), not the ordinary asterisk * (U+002A).")

#emph[#text("[Now fixed, hopefully – T.]")]

#text("3. When solving Exercise 18.9, I managed to slow down Firefox to a crawl. My solution was apparently far from optimal, but it did work in Chromium. (Not sure where the problem is, but this affect other people as well.)")

#emph[#text("[This may possibly be due to the savefile bug, so the fix implemented below may also address this issue – T.]")]

#text("4. The saved progress got somehow messed up for me. It forgot to record some solutions. I had a look at the data in Local Storage under the key grimoire.v2. The stored json string is 5.1 Mbyte for me, which seems large. The biggest junk of the data is apparently the progress stored for Exercise 6.13. Maybe I did something stupid there, maybe it got corrupted during an update.")#linebreak()#text("(Not sure where the problem is, but this affect other people as well.)")

#emph[#text("[The save file format was excessively bloated. This should now be fixed. – T.]")]

#text("5. Suppose one unlocks all problems, selects an unsolved problem and makes a bit of progress. If one then reloads the page, for me it jumps back to Exercise 1.1 and the problems are locked again. This does not seem like the intuitive/expected behaviour.")

#emph[#text("[Unlock is now persistent – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c44df296f4245adf3d3caeb19f2749a1d210cafa2769aff6f0ec6bd2d21c4341-3c12c69ecb80d93a22eea9bf7410efc77094096e0a2354c6e071b51ead8d9bbe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex P")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699468")[#strong[#text("Alex P")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("To be honest, I don’t really follow the interface at a glance. Maybe I’m missing something obvious. I think it needs to hold my hand a bit more.")

#text("I also find the fantasy mode distracting and would prefer it was not the default.")

#text("I would say the audience for this is not people who completely new to logic or programs such as these, but someone more advanced.")

#text("There needs to be a lot more hand holding for someone coming from a less familiar background such as mine.")

#text("ex: Starting with very first principles, interactively, and introducing components of the UI/UX and their effects one step at a time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699472")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 6.13 (or_and_left_rev)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 15 moves. The shortest proof the game knows takes 18. THIS ONE IS SHORTER.")

#text("— We are given (A ∨ B) ∧ (A ∨ C).")#linebreak()#text("— We wish to prove A ∨ (B ∧ C).")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ B (conjunction elimination (left)).")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ C (conjunction elimination (right)).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∧ C we deduce A ∨ (B ∧ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∧ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— Introduce C:")#linebreak()#text("— From B, C we deduce B ∧ C (conjunction introduction).")#linebreak()#text("— From B ∧ C, A we deduce A ∨ (B ∧ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∧ C)).")#linebreak()#text("— From A → (A ∨ (B ∧ C)), C → (A ∨ (B ∧ C)) we deduce (A ∨ C) → (A ∨ (B ∧ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ C) → (A ∨ (B ∧ C)), A ∨ C we deduce A ∨ (B ∧ C) (modus ponens).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∧ C)).")#linebreak()#text("— From A → (A ∨ (B ∧ C)), B → (A ∨ (B ∧ C)) we deduce (A ∨ B) → (A ∨ (B ∧ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∧ C)), A ∨ B we deduce A ∨ (B ∧ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem or_and_left_rev (hABC : (A ∨ B) ∧ (A ∨ C)) : A ∨ (B ∧ C) := by")#linebreak()#text("have hAB : A ∨ B := And.left hABC")#linebreak()#text("have hAC : A ∨ C := And.right hABC")#linebreak()#text("have hAABC : A → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.inl hA")#linebreak()#text("exact hABC2")#linebreak()#text("have hBABC : B → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("have hCABC : C → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hC")#linebreak()#text("have hBC : B ∧ C := And.intro hB hC")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hACABC : (A ∨ C) → (A ∨ (B ∧ C)) := fun h => Or.elim h hAABC hCABC")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := hACABC hAC")#linebreak()#text("exact hABC2")#linebreak()#text("have hABABC : (A ∨ B) → (A ∨ (B ∧ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := hABABC hAB")#linebreak()#text("exact hABC2")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699473")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 7.4 (Iff.refl’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We wish to prove A ↔ A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From A → A, A → A we deduce A ↔ A (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem Iff.refl’ : A ↔ A := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAA2 : A ↔ A := Iff.intro hAA hAA")#linebreak()#text("exact hAA2")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699474")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 7.6 (Or.congr_left’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 4 moves. The shortest proof the game knows takes 9. THIS ONE IS SHORTER.")

#text("— We are given A ∨ B, A ↔ C.")#linebreak()#text("— We wish to prove C ∨ B.")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A ↔ C, A we deduce C (iff elimination (forward)).")#linebreak()#text("— Discharging, we obtain A → C.")#linebreak()#text("— From A ∨ B, A → C we deduce C ∨ B (the lemma Or.imp_left’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 3 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem Or.congr_left’ (hAB : A ∨ B) (hAC : A ↔ C) : C ∨ B := by")#linebreak()#text("have hAC2 : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC.mp hA")#linebreak()#text("exact hC")#linebreak()#text("have hCB : C ∨ B := Or.imp_left’ hAB hAC2")#linebreak()#text("exact hCB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699475")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.8 (not_or_intro’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 9 moves. The shortest proof the game knows takes 11. THIS ONE IS SHORTER.")

#text("— We are given (¬ A) ∧ (¬ B).")#linebreak()#text("— We wish to prove ¬ (A ∨ B).")#linebreak()#text("— From (¬ A) ∧ (¬ B) we deduce ¬ A (conjunction elimination (left)).")#linebreak()#text("— From (¬ A) ∧ (¬ B) we deduce ¬ B (conjunction elimination (right)).")#linebreak()#text("— Introduce A ∨ B:")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, ¬ B, A we deduce A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain B → A.")#linebreak()#text("— From A ∨ B, B → A we deduce A ∨ A (the lemma Or.imp_right’).")#linebreak()#text("— From A ∨ A we deduce A (the lemma or_self_elim’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (A ∨ B).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_or_intro’ (hnAnB : (¬ A) ∧ (¬ B)) : ¬ (A ∨ B) := by")#linebreak()#text("have hA : ¬ A := And.left hnAnB")#linebreak()#text("have hB : ¬ B := And.right hnAnB")#linebreak()#text("have hAB : ¬ (A ∨ B) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hBA : B → A := by")#linebreak()#text("intro hB2")#linebreak()#text("have hA2 : A := absurd hB2 hB")#linebreak()#text("exact hA2")#linebreak()#text("have hAA : A ∨ A := Or.imp_right’ hAB hBA")#linebreak()#text("have hA2 : A := or_self_elim’ hAA")#linebreak()#text("exact absurd hA2 hA")#linebreak()#text("exact hAB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699476")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.9 (not_and_of_not_or’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 9 moves. The shortest proof the game knows takes 11. THIS ONE IS SHORTER.")

#text("— We are given (¬ A) ∨ (¬ B).")#linebreak()#text("— We wish to prove ¬ (A ∧ B).")#linebreak()#text("— Introduce A ∧ B:")#linebreak()#text("— From A ∧ B we deduce A (conjunction elimination (left)).")#linebreak()#text("— From A ∧ B we deduce B (conjunction elimination (right)).")#linebreak()#text("— Introduce ¬ B:")#linebreak()#text("— From B, ¬ B, ¬ A we deduce ¬ A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ B) → (¬ A).")#linebreak()#text("— From (¬ A) ∨ (¬ B), (¬ B) → (¬ A) we deduce (¬ A) ∨ (¬ A) (the lemma Or.imp_right’).")#linebreak()#text("— From (¬ A) ∨ (¬ A) we deduce ¬ A (the lemma or_self_elim’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (A ∧ B).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_and_of_not_or’ (hnAonB : (¬ A) ∨ (¬ B)) : ¬ (A ∧ B) := by")#linebreak()#text("have hAB : ¬ (A ∧ B) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB2")#linebreak()#text("have hA2 : ¬ A := absurd hB hB2")#linebreak()#text("exact hA2")#linebreak()#text("have hAA : (¬ A) ∨ (¬ A) := Or.imp_right’ hnAonB hBA")#linebreak()#text("have hA2 : ¬ A := or_self_elim’ hAA")#linebreak()#text("exact absurd hA hA2")#linebreak()#text("exact hAB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699477")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.13 (not_of_imp_not’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We are given A → (¬ B), B.")#linebreak()#text("— We wish to prove ¬ A.")#linebreak()#text("— From B we deduce ¬ (¬ B) (the lemma not_not_intro’).")#linebreak()#text("— From A → (¬ B), ¬ (¬ B) we deduce ¬ A (the lemma mt_apply’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 3 of them, each as you proved it, deepest first.")

#text("— 8.3 (not_not_intro’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_intro’ (hA : A) : ¬ (¬ A) := by")#linebreak()#text("have hA2 : ¬ (¬ A) := by")#linebreak()#text("intro hA2")#linebreak()#text("exact absurd hA hA2")#linebreak()#text("exact hA2")#linebreak()#text("end")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 8.11 (mt_apply’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt_apply’ (hAB : A → B) (hnB : ¬ B) : ¬ A := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := mt’ hAB")#linebreak()#text("have hA : ¬ A := hBA hnB")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_of_imp_not’ (hAnB : A → (¬ B)) (hB : B) : ¬ A := by")#linebreak()#text("have hB2 : ¬ (¬ B) := not_not_intro’ hB")#linebreak()#text("have hA : ¬ A := mt_apply’ hAnB hB2")#linebreak()#text("exact hA")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699478")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.15 (not_iff_imp_false)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 10 moves. The shortest proof the game knows takes 11. THIS ONE IS SHORTER.")

#text("— We wish to prove (¬ A) ↔ (A → False).")#linebreak()#text("— Introduce ¬ A, then A:")#linebreak()#text("— From A, ¬ A, False we deduce False (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ A) → (A → False).")#linebreak()#text("— Introduce A → False:")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A → False, A we deduce False (modus ponens).")#linebreak()#text("— This is a contradiction, so we conclude ¬ A.")#linebreak()#text("— Discharging, we obtain (A → False) → (¬ A).")#linebreak()#text("— From (¬ A) → (A → False), (A → False) → (¬ A) we deduce (¬ A) ↔ (A → False) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A : Prop}")

#text("theorem not_iff_imp_false : (¬ A) ↔ (A → False) := by")#linebreak()#text("have hAA : (¬ A) → (A → False) := by")#linebreak()#text("intro hA")#linebreak()#text("intro hA2")#linebreak()#text("have h : False := absurd hA2 hA")#linebreak()#text("exact h")#linebreak()#text("have hAA2 : (A → False) → (¬ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : ¬ A := by")#linebreak()#text("intro hA2")#linebreak()#text("have h : False := hA hA2")#linebreak()#text("exact h")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : (¬ A) ↔ (A → False) := Iff.intro hAA hAA2")#linebreak()#text("exact hAA3")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699479")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 9.2 (not_not_elim)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ¬ (¬ A).")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From ¬ A, ¬ (¬ A), A we deduce A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ A) → A.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), (¬ A) → A we deduce A ∨ A (the lemma Or.imp_right’).")#linebreak()#text("— From A ∨ A we deduce A (the lemma or_self_elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA2 : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA3 : A ∨ A := Or.imp_right’ hAA2 hAA")#linebreak()#text("have hA : A := or_self_elim’ hAA3")#linebreak()#text("exact hA")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699480")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 9.3 (by_cases’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We are given A → B, (¬ A) → B.")#linebreak()#text("— We wish to prove B.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), A → B, (¬ A) → B we deduce B (the lemma Or.elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem by_cases’ (hAB : A → B) (hnAB : (¬ A) → B) : B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hB : B := Or.elim’ hAA hAB hnAB")#linebreak()#text("exact hB")

#emph[#text("[New solution added – T.]")]
]
