// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/11/lean-grimoire/
// Converted to Typst by tao2typ: "2026-11-14T13:42:15.860874+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lean Grimoire", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lean Grimoire")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Back in July, I ")#link("https://terrytao.wordpress.com/tag/applets/")[#text("started experimenting")]#text(" with using modern coding agents to build a number of mathematical visualization applets. With the extremely hectic events of the last few months, I had to set those projects aside; but I recently found a bit of time to work on one such project that I had started back then, which was to modernize a ")#link("https://teorth.github.io/QED/")[#text("Javascript interactive textbook I had made back in 2018")]#text(", entitled “QED”, and ")#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/")[#text("announced previously on this blog")]#text(". The purpose of that textbook was to teach propositional and first-order logic in the form of a “crafting game”, where one applied various rules of logic to reach a desired conclusion from a given set of hypotheses.")

#text("With a coding agent, I ")#link("https://teorth.github.io/tao-web/apps/grimoire.html")[#text("rebuilt the game")]#text(" (which I have given the working title of “Lean Grimoire”) with a number of new features, for instance giving the option to show an in-progress Lean proof of one’s game state. Just for fun, I also added an option to play in a “fantasy mode” in which various game elements are depicted using fantasy-themed flavor text (for instance, mathematical statements become “potions”, mathematical expressions become “scrolls”, and so forth). Here is a typical screenshot, in which one has nearly completed the proof of the assertion ")#mi("A \\implies A \\wedge B")#text(" given ")#mi("A \\implies B")#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/11/image.png")[#image("../assets/bd433c29948de0dce562a92747f23674ed6033562b5d6a9bc1e8bd30aaf4e639-04c4fb70831fb4f411b60b7482e30b6e05c03c69c80f2adab32da7dc498a792f.png", width: 90%)]
]

#text("I would be interested in having some playtesting of this app to make it more useful as a means to teach logical proofs and/or Lean.")

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699349")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A question for clarification: By “game” you mean “deterministic 1-player game”? In that case it might also be called “crafting puzzle” to avoid confusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A implies A and B?")

#emph[#text("[Oops, forgot to mention that ")#mi("A \\implies B")#text(" is given as a hypothesis for this particular level -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699352")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I played several of the levels. I think the intro tactic is confusing for players who are just being introduced to it as a game, without prior exposure to this sort of tactic in a theorem prover.")

#text("In my opinion, if you want to make it engaging and understandable for people who don’t already understand the material on some level, I would really lean into the visualization. Things should fit together and break apart in a visual/animated way. I am thinking of something like Opus Magnum, if you have seen that game.")

#text("I might treat implications as “recipes”, when you start an intro tactic, it zooms into a scroll depicting a world with the introduced variables added. Then when you are done it zooms back out to show that scroll existing in the real world as an implication. You could show this zoom in and out recursively.")

#text("Just my two cents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699354")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("Thanks for the feedback! I had been following reasonably closely the interface of my previously (manually coded) interactive textbook, which was limited by my ability to work with complex graphics, but I am now realizing that with modern coding agents I can indeed implement more sophisticated animations. I got my agent to create a mockup of how one might animate a level that involves ")#raw("intro")#text(", such as ")#mi("A \\implies A \\wedge A")#text(", by creating a “scroll” one zooms into and out of as you suggest: ")#link("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")[#text("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")]#text(" . If this seems like a significantly more conceptual type of interface to navigate, I can try to develop it further.")

#text("p.s. my agent also pointed me to the game “")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” that has a similar “zoom in / zoom out” mechanic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699359")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("“")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” is interesting. It reminds me of “Sokoban”. there is complexity analysis (NP-hard; PSpace-complete) back in the late 1990s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/161ebc022821268b1c80f6715fa7acfa514968bc9066623550ba9f9edc7055ca-50459a384a3c566d54cd879c52a49550d995fa421d4e8360dd59349761953378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of enchantingsecretlyfc1dc3c400")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699367")[#strong[#text("enchantingsecretlyfc1dc3c400")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Sokoban! Great game")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/161ebc022821268b1c80f6715fa7acfa514968bc9066623550ba9f9edc7055ca-50459a384a3c566d54cd879c52a49550d995fa421d4e8360dd59349761953378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shawn Hood")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699353")[#strong[#text("Shawn Hood")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I’m not familiar with Lean myself, but have been armchair following some various discussions in mathematical discipline due to the LLM action of late. My son and I would love to play test the Fantasy version and happy to share feedback")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a190384e2d1962e7bf8a57e87c41fdae71e8488202eb4f0c1d8732b6fa7bedb0-8579eeaa773bd1662be7cd243dd9e7d6da105934c6a5acea8eaa1627ea766af2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neunhoef")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699355")[#strong[#text("neunhoef")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I would recommend to switch on “Explicit Parantheses” by default in the beginning, because then one does not have to know that conjunction binds right associatively in Lean. I got confused for a moment by this.")

#emph[#text("[Now implemented – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52582ede8a5998612e024b8d9b2d998c2df38c0556b73e6e5f4e7e379e0ef205-e01020e5c2c5ba180b5dbbd6559399cfd4ac3050527395cfca30cf59e487d019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699360")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("I love the idea, but perhaps the logic notation (A ^ B) needs more expansion than the logic terms (hypothesis, statements)? The informal presentation of the steps is excellent, and if you had similarly informal ways of expressing the goal and the steps you could take to get there you might connect with a more general audience of players (and from there tempt them into learning the more technical notation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699376")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Thanks for the suggestion! There is now a “Plain English” version for the logical expressions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd8bf3c8c75562ac54bebde0a10d320060702c3d66248d9aae05ff0288669b1-db6a5199b74e557e6890b959866d30c559ceb23327c55ad5dc74eb77f141a626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Daly")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699361")[#strong[#text("Timothy Daly")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("You might want to look at Patrick Massot’s graph of the LEAN theorems.")

#text("I show those that need to be proven. Your game might be an interesting")

#text("student guidance project, especially if they use an LLM to help. The")

#text("students could be proving real theorems while learning")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Check out the comments on Hacker News: ")#link("https://news.ycombinator.com/item?id=50462375")[#text("https://news.ycombinator.com/item?id=50462375")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699363")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Maybe add a “Hint” system? Even knowing istintively why a proposition is true, it is not easy to translate it into Lean procedures.")

#text("On the other hand, you can run an agent and add for each problem what is the minimum possible number of steps for any given problem given the available resources/recipes at the moment. This would add to the challenge for already experienced users that are not satisfied with longer solutions.")

#text("It has always been a dream of mine programming an actual videogame on math, but I barely can scrape time for anything, and not having access to any agent makes it borderline infeasible")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Thanks for the suggestions! Hints have now been added for each level, as well as an explicit count of steps compared against the shortest known solution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699364")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and I just noticed 7.12 is used in previous ones like 7.2")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699379")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and also I don’t see how to do 13.4 without knowing Pick that is explained later in 14.1")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa7002f980bc9f3adff257e08ba0aa57205ecd6048d18584d87e6d4ee2228437-52285627566ef753cc59cb85ca6f216fb6631b1fde677af2e4157bdd39668a8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lovinged57041eed")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699371")[#strong[#text("lovinged57041eed")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Hello Terence.Thank you for sharing your conceptual scheme for “Lean Grimoire”. The name resonates right away.Initial thoughts and observations:- having a conformal analog, a locally “familiar” model,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("This is a very nice idea! Also, all good games for developing visualization, better logical reasoning (like finding reasoning flaws, for example), detecting patterns etc are all very welcome!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699378")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Something that I was telling my students that they have to battle when writing by hand, but they won’t face in the game, is malformed expressions. In the game they could combine recipes and get the wrong goal due to, say parentheses in places that are not those of the real goal. However, I didn’t see a way to obtain malformed expressions.")

#text("Maybe there could be a version of the grimoire that was scribbled over by a wizard apprentice and some recipes are malformed, perhaps deceptively close to other recipes that are well formed. The user still has to use the right ones. Or perhaps, both get to the goal and delete the malformed recipes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Shorter proof for 4.8:")

#text("— Lean Grimoire — exercise 4.8 (And.symm’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 5. THIS ONE IS SHORTER.")

#text("— We wish to prove (A ∧ B) → (B ∧ A).")#linebreak()#text("— Introduce A ∧ B:")#linebreak()#text("— From A ∧ B we deduce B ∧ A (the lemma And.comm’).")#linebreak()#text("— Discharging, we obtain (A ∧ B) → (B ∧ A).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem And.symm’ : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("have hABBA : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hBA : B ∧ A := And.comm’ hAB")#linebreak()#text("exact hBA")#linebreak()#text("exact hABBA")

#text("Also, there is a somewhat similar game if anyone is interested:")

#link("https://adam.math.hhu.de/#/g/leanprover-community/nng4")[#text("https://adam.math.hhu.de/#/g/leanprover-community/nng4")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699391")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("That works! I’ve updated the game to record this new proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699385")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and it would also be very helpful to know how to write statements with forall and exists in the scrolls…. it does not accept \\exists or ∃ or any other variant that I can think of")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Can you make a linear logic dlc?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/280e4053f2c99fc48d025d37b8e5c097fb942ffddaabc8d3c3e49a32ee0c8073-b8161083f39fb5f211b74368ffde5e9c1646c2c8479436b18b93401eb8ae9012.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PistachioCake")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699392")[#strong[#text("PistachioCake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("A shorter proof for Exercise 2.3!")

#raw("-- Lean Grimoire — exercise 2.3  (And.assoc_right)\n-- https://terrytao.wordpress.com/2026/11/11/lean-grimoire/\n-- Proved in 5 moves.  The shortest proof the game knows takes 6.  THIS ONE IS SHORTER.\n--\n-- We are given A ∧ (B ∧ C).\n-- We wish to prove (A ∧ B) ∧ C.\n-- From A ∧ (B ∧ C) we deduce (B ∧ C) ∧ A  (the lemma And.comm').\n-- From (B ∧ C) ∧ A we deduce B ∧ (C ∧ A)  (the lemma And.assoc_left).\n-- From B ∧ (C ∧ A) we deduce (C ∧ A) ∧ B  (the lemma And.comm').\n-- From (C ∧ A) ∧ B we deduce C ∧ (A ∧ B)  (the lemma And.assoc_left).\n-- From C ∧ (A ∧ B) we deduce (A ∧ B) ∧ C  (the lemma And.comm').\n-- This is what we wished to prove.  ∎\n\n-- Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with\n-- it. 2 of them, each as you proved it, deepest first.\n\n-- 2.1  (And.comm')\nsection\nvariable {A B : Prop}\n\ntheorem And.comm' (hAB : A ∧ B) : B ∧ A := by\n  have hA : A := And.left hAB\n  have hB : B := And.right hAB\n  have hBA : B ∧ A := And.intro hB hA\n  exact hBA\nend\n\n-- 2.2  (And.assoc_left)\nsection\nvariable {A B C : Prop}\n\ntheorem And.assoc_left (hABC : (A ∧ B) ∧ C) : A ∧ (B ∧ C) := by\n  have hAB : A ∧ B := And.left hABC\n  have hA : A := And.left hAB\n  have hB : B := And.right hAB\n  have hC : C := And.right hABC\n  have hBC : B ∧ C := And.intro hB hC\n  have hABC2 : A ∧ (B ∧ C) := And.intro hA hBC\n  exact hABC2\nend\n\n-- and the proof itself:\n\nvariable {A B C : Prop}\n\ntheorem And.assoc_right (hABC : A ∧ (B ∧ C)) : (A ∧ B) ∧ C := by\n  have hBCA : (B ∧ C) ∧ A := And.comm' hABC\n  have hBCA2 : B ∧ (C ∧ A) := And.assoc_left hBCA\n  have hCAB : (C ∧ A) ∧ B := And.comm' hBCA2\n  have hCAB2 : C ∧ (A ∧ B) := And.assoc_left hCAB\n  have hABC2 : (A ∧ B) ∧ C := And.comm' hCAB2\n  exact hABC2\n", block: true)

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("one step proof for Exercise 4.3:")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("— Lean Grimoire — exercise 6.8 (Or.assoc_left)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 14 moves. The shortest proof the game knows takes 17. THIS ONE IS SHORTER.")

#text("— We are given (A ∨ B) ∨ C.")#linebreak()#text("— We wish to prove A ∨ (B ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∨ C we deduce A ∨ (B ∨ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, C we deduce B ∨ C (disjunction introduction (left)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From C, B we deduce B ∨ C (disjunction introduction (right)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∨ C)).")#linebreak()#text("— From A → (A ∨ (B ∨ C)), B → (A ∨ (B ∨ C)) we deduce (A ∨ B) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)), (A ∨ B) ∨ C we deduce A ∨ (B ∨ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by")#linebreak()#text("have hAABC : A → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inl hA")#linebreak()#text("exact hABC2")#linebreak()#text("have hBABC : B → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBC : B ∨ C := Or.inl hB")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hCABC : C → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hC")#linebreak()#text("have hBC : B ∨ C := Or.inr hC")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text("have hABCABC : ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) := fun h => Or.elim h hABABC hCABC")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := hABCABC hABC")#linebreak()#text("exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699396")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("— Lean Grimoire — exercise 9.7 (not_or_of_imp’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given A → B.")#linebreak()#text("— We wish to prove (¬ A) ∨ B.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), A → B we deduce B ∨ (¬ A) (the lemma Or.imp_left’).")#linebreak()#text("— From B ∨ (¬ A) we deduce (¬ A) ∨ B (the lemma Or.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : (A ∨ B) → (B ∨ A) := by")#linebreak()#text("have hABA : A → (B ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → (B ∨ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_or_of_imp’ (hAB : A → B) : (¬ A) ∨ B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hBA : B ∨ (¬ A) := Or.imp_left’ hAA hAB")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.comm’ hBA")#linebreak()#text("exact hAB2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efab1854848648e6c4948288f69a4c59799a16b6404b128267d77781fe5736dd-a2561b2000fbb44883fc1cc8398d7ab85870aff1df22756714c8c156b46caf8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699399")[#strong[#text("Jacob")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Shorter proof for 4.3:")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6de08af996f1b13b848c07305d34e8876f7bc6b7a77eb42047dcdc8ac5900725-85b0d5b83f7030bb5c34eb01a958aa331cef9d7e5909f3d107a929253025af54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dario Bajo")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699401")[#strong[#text("Dario Bajo")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Exercise 4.3")

#strong[#text("QED!")]#text(" You brewed ")#emph[#text("((A ∧ B) ∨ C) → ((A ∧ B) ∨ C)")]#text(" in 1 move.🏆 ")#strong[#text("A new record.")]#text(" The shortest proof this game knows takes 2 moves, so you have found something it does not. Please tell me about it: ")#strong[#text("Copy")]#text(" or ")#strong[#text("Save")]#text(" the proof below and leave it in the comments on ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("the blog post")]#text(".")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Shorter proof for 2.3 :D")#linebreak()#text("(Tried commenting this earlier, but it didn’t show up… If there’s a duplicate, sorry!)")

#text("— Lean Grimoire — exercise 2.3 (And.assoc_right)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 6. THIS ONE IS SHORTER.")

#text("— We are given A ∧ (B ∧ C).")#linebreak()#text("— We wish to prove (A ∧ B) ∧ C.")#linebreak()#text("— From A ∧ (B ∧ C) we deduce (B ∧ C) ∧ A (the lemma And.comm’).")#linebreak()#text("— From (B ∧ C) ∧ A we deduce B ∧ (C ∧ A) (the lemma And.assoc_left).")#linebreak()#text("— From B ∧ (C ∧ A) we deduce (C ∧ A) ∧ B (the lemma And.comm’).")#linebreak()#text("— From (C ∧ A) ∧ B we deduce C ∧ (A ∧ B) (the lemma And.assoc_left).")#linebreak()#text("— From C ∧ (A ∧ B) we deduce (A ∧ B) ∧ C (the lemma And.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 2.2 (And.assoc_left)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.assoc_left (hABC : (A ∧ B) ∧ C) : A ∧ (B ∧ C) := by")#linebreak()#text("have hC : C := And.right hABC")#linebreak()#text("have hAB : A ∧ B := And.left hABC")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBC : B ∧ C := And.intro hB hC")#linebreak()#text("have hABC2 : A ∧ (B ∧ C) := And.intro hA hBC")#linebreak()#text("exact hABC2")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem And.assoc_right (hABC : A ∧ (B ∧ C)) : (A ∧ B) ∧ C := by")#linebreak()#text("have hBCA : (B ∧ C) ∧ A := And.comm’ hABC")#linebreak()#text("have hBCA2 : B ∧ (C ∧ A) := And.assoc_left hBCA")#linebreak()#text("have hCAB : (C ∧ A) ∧ B := And.comm’ hBCA2")#linebreak()#text("have hCAB2 : C ∧ (A ∧ B) := And.assoc_left hCAB")#linebreak()#text("have hABC2 : (A ∧ B) ∧ C := And.comm’ hCAB2")#linebreak()#text("exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d8743ae0fe0c9a25f7a64cc22f010e4d6e7284961c7cd41c6bef0c04b0afdd-99b1fdce4cbf1d63453450780711acdac96e460d2707765fc440a052f7f99a20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kantian")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/#comment-699406")[#strong[#text("Kantian")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("You advise to post shorter proof if we find one, so here is one")

#text("— Lean Grimoire — exercise 6.8 (Or.assoc_left)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 14 moves. The shortest proof the game knows takes 17. THIS ONE IS SHORTER.")#linebreak()#text("—")#linebreak()#text("— We are given (A ∨ B) ∨ C.")#linebreak()#text("— We wish to prove A ∨ (B ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∨ C we deduce A ∨ (B ∨ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, C we deduce B ∨ C (disjunction introduction (left)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∨ C)).")#linebreak()#text("— From A → (A ∨ (B ∨ C)), B → (A ∨ (B ∨ C)) we deduce (A ∨ B) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From C, B we deduce B ∨ C (disjunction introduction (right)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∨ C)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)), (A ∨ B) ∨ C we deduce A ∨ (B ∨ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by")#linebreak()#text(" have hAABC : A → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hA")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inl hA")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hBABC : B → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hB")#linebreak()#text(" have hBC : B ∨ C := Or.inl hB")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text(" have hCABC : C → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hC")#linebreak()#text(" have hBC : B ∨ C := Or.inr hC")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hABCABC : ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) := fun h => Or.elim h hABABC hCABC")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := hABCABC hABC")#linebreak()#text(" exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]
