// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/11/lean-grimoire/
// Converted to Typst by tao2typ: "2026-11-19T15:58:22.704023+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lean Grimoire", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lean Grimoire")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-19 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Back in July, I ")#link("https://terrytao.wordpress.com/tag/applets/")[#text("started experimenting")]#text(" with using modern coding agents to build a number of mathematical visualization applets. With the extremely hectic events of the last few months, I had to set those projects aside; but I recently found a bit of time to work on one such project that I had started back then, which was to modernize a ")#link("https://teorth.github.io/QED/")[#text("Javascript interactive textbook I had made back in 2018")]#text(", entitled “QED”, and ")#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/")[#text("announced previously on this blog")]#text(". The purpose of that textbook was to teach propositional and first-order logic in the form of a “crafting game”, where one applied various rules of logic to reach a desired conclusion from a given set of hypotheses.")

#text("With a coding agent, I ")#link("https://teorth.github.io/tao-web/apps/grimoire.html")[#text("rebuilt the game")]#text(" (which I have given the working title of “Lean Grimoire”) with a number of new features, for instance giving the option to show an in-progress Lean proof of one’s game state. Just for fun, I also added an option to play in a “fantasy mode” in which various game elements are depicted using fantasy-themed flavor text (for instance, mathematical statements become “potions”, mathematical expressions become “scrolls”, and so forth). Here is a typical screenshot, in which one has nearly completed the proof of the assertion ")#mi("A \\implies A \\wedge B")#text(" given ")#mi("A \\implies B")#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/11/image.png")[#image("../assets/bd433c29948de0dce562a92747f23674ed6033562b5d6a9bc1e8bd30aaf4e639-04c4fb70831fb4f411b60b7482e30b6e05c03c69c80f2adab32da7dc498a792f.png", width: 90%)]
]

#text("I would be interested in having some playtesting of this app to make it more useful as a means to teach logical proofs and/or Lean.")

#heading(level: 1)[#text("Comments (68)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699498")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 12.7 (forall_imp_comm’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 13 moves. The shortest proof the game knows takes 16. THIS ONE IS SHORTER.")

#text("— We wish to prove (A → (∀ X : Ω, P(X))) ↔ (∀ X : Ω, (A → P(X))).")#linebreak()#text("— Introduce ∀ X : Ω, (A → P(X)), then A, then an arbitrary X : Ω:")#linebreak()#text("— From ∀ X : Ω, (A → P(X)), X we deduce A → P(X) (universal instantiation (specialization)).")#linebreak()#text("— From A → P(X), A we deduce P(X) (modus ponens).")#linebreak()#text("— Discharging, we obtain (∀ X : Ω, (A → P(X))) → (A → (∀ X : Ω, P(X))).")#linebreak()#text("— Introduce A → (∀ X : Ω, P(X)), then an arbitrary X : Ω, then A:")#linebreak()#text("— From A → (∀ X : Ω, P(X)), A we deduce ∀ X : Ω, P(X) (modus ponens).")#linebreak()#text("— From ∀ X : Ω, P(X), X we deduce P(X) (universal instantiation (specialization)).")#linebreak()#text("— Discharging, we obtain (A → (∀ X : Ω, P(X))) → (∀ X : Ω, (A → P(X))).")#linebreak()#text("— From (A → (∀ X : Ω, P(X))) → (∀ X : Ω, (A → P(X))), (∀ X : Ω, (A → P(X))) → (A → (∀ X : Ω, P(X))) we deduce (A → (∀ X : Ω, P(X))) ↔ (∀ X : Ω, (A → P(X))) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {Ω}")#linebreak()#text("variable {A : Prop}")#linebreak()#text("variable {P : Ω → Prop}")

#text("theorem forall_imp_comm’ : (A → (∀ X : Ω, P X)) ↔ (∀ X : Ω, (A → P X)) := by")#linebreak()#text("have hAXAX : (∀ X : Ω, (A → P X)) → (A → (∀ X : Ω, P X)) := by")#linebreak()#text("intro hAX")#linebreak()#text("intro hA")#linebreak()#text("intro X")#linebreak()#text("have hAX2 : A → P X := hAX X")#linebreak()#text("have hX : P X := hAX2 hA")#linebreak()#text("exact hX")#linebreak()#text("have hAXAX2 : (A → (∀ X : Ω, P X)) → (∀ X : Ω, (A → P X)) := by")#linebreak()#text("intro hAX")#linebreak()#text("intro X")#linebreak()#text("intro hA")#linebreak()#text("have hX : ∀ X : Ω, P X := hAX hA")#linebreak()#text("have hX2 : P X := hX X")#linebreak()#text("exact hX2")#linebreak()#text("have hAXAX3 : (A → (∀ X : Ω, P X)) ↔ (∀ X : Ω, (A → P X)) := Iff.intro hAXAX2 hAXAX")#linebreak()#text("exact hAXAX3")

#text("— grimoire-replay v1 12.7 W1siYSIseyJ0YWciOiJiaW5kZXIiLCJxIjoiZm9yYWxsIiwidiI6eyJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IklNUExJRVMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LCJzb3J0IjoiUHJvcCJ9XSxbImEiLHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSxbInYiLCJYIiwizqkiXSxbImMiLCJ1bml2ZXJzYWxfaW5zdGFudGlhdGlvbiIsWyJoQVgiLHsidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwibW9kdXNfcG9uZW5zIixbImhBWDIiLCJoQSJdLHsidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImQiLCJoWCIsM10sWyJhIix7InRhZyI6ImFwcCIsInN5bSI6IklNUExJRVMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJiaW5kZXIiLCJxIjoiZm9yYWxsIiwidiI6eyJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsidiIsIlgiLCLOqSJdLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIm1vZHVzX3BvbmVucyIsWyJoQVgiLCJoQSJdLHsidGFnIjoiYmluZGVyIiwicSI6ImZvcmFsbCIsInYiOnsibmFtZSI6IlgiLCJzb3J0IjoizqkifSwiYm9keSI6eyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLFsiYyIsInVuaXZlcnNhbF9pbnN0YW50aWF0aW9uIixbImhYIix7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImQiLCJoWDIiLDNdLFsiYyIsIklmZi5pbnRybyIsWyJoQVhBWDIiLCJoQVhBWCJdLHsidGFnIjoiYXBwIiwic3ltIjoiSUZGIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6ImJpbmRlciIsInEiOiJmb3JhbGwiLCJ2Ijp7Im5hbWUiOiJYIiwic29ydCI6Is6pIn0sImJvZHkiOnsidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9LCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImJpbmRlciIsInEiOiJmb3JhbGwiLCJ2Ijp7Im5hbWUiOiJYIiwic29ydCI6Is6pIn0sImJvZHkiOnsidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699499")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 15.10")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 11 moves. The shortest proof the game knows takes 12. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → (¬ Q(X))), ∀ X : Ω, ((¬ Q(X)) → R(X)), ¬ (∃ X : Ω, (R(X) ∧ S(X))).")#linebreak()#text("— We wish to prove ∀ X : Ω, (P(X) → (¬ S(X))).")#linebreak()#text("— Introduce an arbitrary X : Ω, then P(X):")#linebreak()#text("— From ∀ X : Ω, (P(X) → (¬ Q(X))), X we deduce P(X) → (¬ Q(X)) (universal instantiation (specialization)).")#linebreak()#text("— From ∀ X : Ω, ((¬ Q(X)) → R(X)), X we deduce (¬ Q(X)) → R(X) (universal instantiation (specialization)).")#linebreak()#text("— From P(X) → (¬ Q(X)), (¬ Q(X)) → R(X) we deduce P(X) → R(X) (the lemma implies_trans).")#linebreak()#text("— From P(X) → R(X), P(X) we deduce R(X) (modus ponens).")#linebreak()#text("— Introduce S(X):")#linebreak()#text("— From R(X), S(X) we deduce R(X) ∧ S(X) (conjunction introduction).")#linebreak()#text("— From R(X) ∧ S(X), X we deduce ∃ x : Ω, (R(x) ∧ S(x)) (existential introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ S(X).")#linebreak()#text("— Discharging, we obtain ∀ X : Ω, (P(X) → (¬ S(X))).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")#linebreak()#text("variable {S : Ω → Prop}")

#text("example (hPnQ : ∀ X : Ω, (P X → (¬ Q X))) (hnQR : ∀ X : Ω, ((¬ Q X) → R X)) (hnrs : ¬ (∃ X : Ω, (R X ∧ S X))) : ∀ X : Ω, (P X → (¬ S X)) := by")#linebreak()#text("have hXX : ∀ X : Ω, (P X → (¬ S X)) := by")#linebreak()#text("intro X")#linebreak()#text("have hXX : P X → (¬ Q X) := hPnQ X")#linebreak()#text("have hXX2 : (¬ Q X) → R X := hnQR X")#linebreak()#text("have hXX3 : P X → R X := implies_trans hXX hXX2")#linebreak()#text("intro hX")#linebreak()#text("have hX2 : R X := hXX3 hX")#linebreak()#text("have hX3 : ¬ S X := by")#linebreak()#text("intro hX3")#linebreak()#text("have hXX4 : R X ∧ S X := And.intro hX2 hX3")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ S x) := ⟨X, hXX4⟩")#linebreak()#text("exact absurd hxx hnrs")#linebreak()#text("exact hX3")#linebreak()#text("exact hXX")

#text("— grimoire-replay v1 15.10 W1sidiIsIlgiLCLOqSJdLFsiYyIsInVuaXZlcnNhbF9pbnN0YW50aWF0aW9uIixbImhQblEiLHsidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUSIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsInVuaXZlcnNhbF9pbnN0YW50aWF0aW9uIixbImhuUVIiLHsidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUSIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlIiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsImltcGxpZXNfdHJhbnMiLFsiaFhYIiwiaFhYMiJdLHsidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlIiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIm1vZHVzX3BvbmVucyIsWyJoWFgzIiwiaFgiXSx7InRhZyI6ImFwcCIsInN5bSI6IlIiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sWyJhIix7InRhZyI6ImFwcCIsInN5bSI6IlMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiQW5kLmludHJvIixbImhYMiIsImhYMyJdLHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiUyIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiRXhpc3RzLmludHJvIixbImhYWDQiLHsidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0seyJ0YWciOiJiaW5kZXIiLCJxIjoiZXhpc3RzIiwidiI6eyJuYW1lIjoieCIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IlIiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoieCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoieCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLFsibiIsImh4eCIsImhucnMiXSxbImQiLCJoWDMiLDJdXQ==")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699500")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 18.7 (Eq.congr_iff’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given α = β.")#linebreak()#text("— We wish to prove P(α) ↔ P(β).")#linebreak()#text("— Introduce P(α):")#linebreak()#text("— Discharging, we obtain P(α) → P(α).")#linebreak()#text("— From P(α) → P(α), α = β we deduce P(α) → P(β) (rewrite along an equation).")#linebreak()#text("— From P(α) → P(α), α = β we deduce P(β) → P(α) (rewrite along an equation).")#linebreak()#text("— From P(α) → P(β), P(β) → P(α) we deduce P(α) ↔ P(β) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")

#text("theorem Eq.congr_iff’ (α : Ω) (β : Ω) (hab : α = β) : P α ↔ P β := by")#linebreak()#text("have hαα : P α → P α := by")#linebreak()#text("intro hα")#linebreak()#text("exact hα")#linebreak()#text("have hαβ : P α → P β := Eq.subst (motive := fun x => P α → P x) hab hαα")#linebreak()#text("have hβα : P β → P α := Eq.subst (motive := fun x => P x → P α) hab hαα")#linebreak()#text("have hαβ2 : P α ↔ P β := Iff.intro hαβ hβα")#linebreak()#text("exact hαβ2")

#text("— grimoire-replay v1 18.7 W1siYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImQiLCJozrEiLDFdLFsiYyIsInJ3IixbImjOsc6xIiwiaGFiIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiLOsSIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrIiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJydyIsWyJozrHOsSIsImhhYiJdLHsidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrIiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiSWZmLmludHJvIixbImjOsc6yIiwiaM6yzrEiXSx7InRhZyI6ImFwcCIsInN5bSI6IklGRiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrEiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6Is6yIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV1d")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699506")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("Really enjoyed the game!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb877f83f1a046ce2e62a5bc1cb974918e1dd30b66b9b68f834be33de02caf1-b2fe0f4c9e754bfc0c459babc8c487c187448796456dc9557efcc3a2eae032f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petrov")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699510")[#strong[#text("petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("Sorry, formatting came out wrong on previous comment and forgot to mention the problem above was 8.9. Surprinsingly addicting game! Here’s an 8 move solution to 8.9:")

#text("variable {A B : Prop}")

#text("theorem not_and_of_not_or’ (hnAonB : (¬ A) ∨ (¬ B)) : ¬ (A ∧ B) := by")

#text("have hAB : ¬ (A ∧ B) := by")

#text("intro hAB")

#text("have hA : A := And.left hAB")

#text("have hB : B := And.right hAB")

#text("have hA2 : ¬ (¬ A) := not_not_intro’ hA")

#text("have hB2 : ¬ (¬ B) := not_not_intro’ hB")

#text("have hAB2 : (¬ (¬ A)) ∧ (¬ (¬ B)) := And.intro hA2 hB2")

#text("have hAB3 : ¬ ((¬ A) ∨ (¬ B)) := not_or_intro’ hAB2")

#text("exact absurd hnAonB hAB3")

#text("exact hAB")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699511")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("Chrome slows down to a crawl and sometimes crashes on 18.8 and successive exercises. The RAM usage is huge (greater than the usual big usage of Chrome), like 3.5GB. Trying to do any action takes ages.")

#emph[#text("[There was an unnecessary exponential time search in the code which has now been removed and which should hopefully fix the problem. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699513")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("— Lean Grimoire — exercise 6.13 (or_and_left_rev)– ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/--")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/–")]#text(" Proved in 13 moves. The shortest proof the game knows takes 15, found by qwq zty on 16 November 2026. THIS ONE IS SHORTER.—- We are given (A ∨ B) ∧ (A ∨ C).– We wish to prove A ∨ (B ∧ C).– From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ B (conjunction elimination (left)).– From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ C (conjunction elimination (right)).– Introduce A:– From A, B ∧ C we deduce A ∨ (B ∧ C) (disjunction introduction (left)).– Discharging, we obtain A → (A ∨ (B ∧ C)).– Introduce B:– Introduce C:– From B, C we deduce B ∧ C (conjunction introduction).– From B ∧ C, A we deduce A ∨ (B ∧ C) (disjunction introduction (right)).– Discharging, we obtain C → (A ∨ (B ∧ C)).– From A ∨ C, A → (A ∨ (B ∧ C)), C → (A ∨ (B ∧ C)) we deduce A ∨ (B ∧ C) (the lemma Or.elim’).– Discharging, we obtain B → (A ∨ (B ∧ C)).– From A ∨ B, A → (A ∨ (B ∧ C)), B → (A ∨ (B ∧ C)) we deduce A ∨ (B ∧ C) (the lemma Or.elim’).– This is what we wished to prove. ∎– Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with– it. 1 of them, each as you proved it, deepest first.– 6.4 (Or.elim’)sectionvariable {A B C : Prop}theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC have hC : C := hABC hAB exact hCend– and the proof itself:variable {A B C : Prop}theorem or_and_left_rev (hABC : (A ∨ B) ∧ (A ∨ C)) : A ∨ (B ∧ C) := by have hAB : A ∨ B := And.left hABC have hAC : A ∨ C := And.right hABC have hAABC : A → (A ∨ (B ∧ C)) := by intro hA have hABC2 : A ∨ (B ∧ C) := Or.inl hA exact hABC2 have hBABC : B → (A ∨ (B ∧ C)) := by intro hB have hCABC : C → (A ∨ (B ∧ C)) := by intro hC have hBC : B ∧ C := And.intro hB hC have hABC2 : A ∨ (B ∧ C) := Or.inr hBC exact hABC2 have hABC2 : A ∨ (B ∧ C) := Or.elim’ hAC hAABC hCABC exact hABC2 have hABC2 : A ∨ (B ∧ C) := Or.elim’ hAB hAABC hBABC exact hABC2– grimoire-replay v1 6.13 W1siYyIsIkFuZC5sZWZ0IixbImhBQkMiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiQW5kLnJpZ2h0IixbImhBQkMiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJhIix7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5sIixbImhBIix7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJkIiwiaEFCQzIiLDFdLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5pbnRybyIsWyJoQiIsImhDIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJPci5pbnIiLFsiaEJDIix7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImQiLCJoQUJDMiIsMV0sWyJjIiwiT3IuZWxpbSciLFsiaEFDIiwiaEFBQkMiLCJoQ0FCQyJdLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJkIiwiaEFCQzIiLDFdLFsiYyIsIk9yLmVsaW0nIixbImhBQiIsImhBQUJDIiwiaEJBQkMiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dXQ==")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d8743ae0fe0c9a25f7a64cc22f010e4d6e7284961c7cd41c6bef0c04b0afdd-99b1fdce4cbf1d63453450780711acdac96e460d2707765fc440a052f7f99a20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kantian")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699520")[#strong[#text("Kantian")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("A batch of shorter proofs I found (some may have already been found, I didn’t check). I stopped at exercice 18.8 because Firefox has crashed during the proof (maybe a time-space complexity problem with the aglorithm).")

#text("#5.9 (3 moves instead of 4)")

#raw("variable {A B C : Prop}\n\ntheorem And.imp_right' (hAB : A ∧ B) (hBC : B → C) : A ∧ C := by\n  have hBA : B ∧ A := And.comm' hAB\n  have hCA : C ∧ A := And.imp_left' hBA hBC\n  have hAC : A ∧ C := And.comm' hCA\n  exact hAC", block: true)

#text("#6.5 (9 moves instead of 10)")

#raw("variable {A B C D : Prop}\n\ntheorem Or.imp' (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by\n  have hACD : A → (C ∨ D) := by\n    intro hA\n    have hC : C := hAC hA\n    have hCD : C ∨ D := Or.inl hC\n    exact hCD\n  have hBCD : B → (C ∨ D) := by\n    intro hB\n    have hD : D := hBD hB\n    have hCD : C ∨ D := Or.inr hD\n    exact hCD\n  have hCD : C ∨ D := Or.elim' hAB hACD hBCD\n  exact hCD", block: true)

#text("#6.10 (13 instead of 14)")

#raw("variable {A B C : Prop}\n\ntheorem or_and_left' (hABC : A ∨ (B ∧ C)) : (A ∨ B) ∧ (A ∨ C) := by\n  have hAABAC : A → ((A ∨ B) ∧ (A ∨ C)) := by\n    intro hA\n    have hAB : A ∨ B := Or.inl hA\n    have hAC : A ∨ C := Or.inl hA\n    have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC\n    exact hABAC\n  have hBCABAC : (B ∧ C) → ((A ∨ B) ∧ (A ∨ C)) := by\n    intro hBC\n    have hB : B := And.left hBC\n    have hC : C := And.right hBC\n    have hAB : A ∨ B := Or.inr hB\n    have hAC : A ∨ C := Or.inr hC\n    have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC\n    exact hABAC\n  have hABAC : (A ∨ B) ∧ (A ∨ C) := Or.elim' hABC hAABAC hBCABAC\n  exact hABAC", block: true)

#text("#6.11 (11 moves instead of 12)")

#raw("variable {A B C : Prop}\n\ntheorem and_or_left' (hABC : A ∧ (B ∨ C)) : (A ∧ B) ∨ (A ∧ C) := by\n  have hA : A := And.left hABC\n  have hBABAC : B → ((A ∧ B) ∨ (A ∧ C)) := by\n    intro hB\n    have hAB : A ∧ B := And.intro hA hB\n    have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.inl hAB\n    exact hABAC\n  have hCABAC : C → ((A ∧ B) ∨ (A ∧ C)) := by\n    intro hC\n    have hAC : A ∧ C := And.intro hA hC\n    have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.inr hAC\n    exact hABAC\n  have hBC : B ∨ C := And.right hABC\n  have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.elim' hBC hBABAC hCABAC\n  exact hABAC", block: true)

#text("#6.12 (13 moves instead of 14)")

#raw("theorem and_or_left_rev (hABC : (A ∧ B) ∨ (A ∧ C)) : A ∧ (B ∨ C) := by\n  have hABABC : (A ∧ B) → (A ∧ (B ∨ C)) := by\n    intro hAB\n    have hA : A := And.left hAB\n    have hB : B := And.right hAB\n    have hBC : B ∨ C := Or.inl hB\n    have hABC2 : A ∧ (B ∨ C) := And.intro hA hBC\n    exact hABC2\n  have hACABC : (A ∧ C) → (A ∧ (B ∨ C)) := by\n    intro hAC\n    have hA : A := And.left hAC\n    have hC : C := And.right hAC\n    have hBC : B ∨ C := Or.inr hC\n    have hABC2 : A ∧ (B ∨ C) := And.intro hA hBC\n    exact hABC2\n  have hABC2 : A ∧ (B ∨ C) := Or.elim' hABC hABABC hACABC\n  exact hABC2", block: true)

#text("#6.13 (13 moves instead of 18)")

#raw("variable {A B C : Prop}\n\ntheorem or_and_left_rev (hABC : (A ∨ B) ∧ (A ∨ C)) : A ∨ (B ∧ C) := by\n  have hAB : A ∨ B := And.left hABC\n  have hAC : A ∨ C := And.right hABC\n  have hAABC : A → (A ∨ (B ∧ C)) := by\n    intro hA\n    have hABC2 : A ∨ (B ∧ C) := Or.inl hA\n    exact hABC2\n  have hBABC : B → (A ∨ (B ∧ C)) := by\n    intro hB\n    have hCABC : C → (A ∨ (B ∧ C)) := by\n      intro hC\n      have hBC : B ∧ C := And.intro hB hC\n      have hABC2 : A ∨ (B ∧ C) := Or.inr hBC\n      exact hABC2\n    have hABC2 : A ∨ (B ∧ C) := Or.elim' hAC hAABC hCABC\n    exact hABC2\n  have hABC2 : A ∨ (B ∧ C) := Or.elim' hAB hAABC hBABC\n  exact hABC2", block: true)

#text("#7.4 (2 moves instead of 3)")

#raw("variable {A : Prop}\n\ntheorem Iff.refl' : A ↔ A := by\n  have hAA : A → A := Impl.idem\n  have hAA2 : A ↔ A := Iff.intro hAA hAA\n  exact hAA2", block: true)

#text("#7.6 (8 moves instead of 9)")

#raw("variable {A B C : Prop}\n\ntheorem Or.congr_left' (hAB : A ∨ B) (hAC : A ↔ C) : C ∨ B := by\n  have hACB : A → (C ∨ B) := by\n    intro hA\n    have hC : C := hAC.mp hA\n    have hCB : C ∨ B := Or.inl hC\n    exact hCB\n  have hBCB : B → (C ∨ B) := by\n    intro hB\n    have hCB : C ∨ B := Or.inr hB\n    exact hCB\n  have hCB : C ∨ B := Or.elim' hAB hACB hBCB\n  exact hCB", block: true)

#text("#7.13 (6 moves instead of 7)")

#raw("variable {A : Prop}\n\ntheorem or_self_iff' : A ↔ (A ∨ A) := by\n  have hAAA : A → (A ∨ A) := by\n    intro hA\n    have hAA : A ∨ A := Or.idem hA\n    exact hAA\n  have hAA : A → A := Impl.idem\n  have hAAA2 : (A ∨ A) → A := fun h => Or.elim h hAA hAA\n  have hAAA3 : A ↔ (A ∨ A) := Iff.intro hAAA hAAA2\n  exact hAAA3", block: true)

#text("#8.8 (9 moves instead of 11)")

#raw("variable {A B : Prop}\n\ntheorem not_or_intro' (hnAnB : (¬ A) ∧ (¬ B)) : ¬ (A ∨ B) := by\n  have hA : ¬ A := And.left hnAnB\n  have hB : ¬ B := And.right hnAnB\n  have hAB : ¬ (A ∨ B) := by\n    intro hAB\n    have hAB2 : A → B := by\n      intro hA2\n      have hB2 : B := absurd hA2 hA\n      exact hB2\n    have hBB : B → B := Impl.idem\n    have hB2 : B := Or.elim' hAB hAB2 hBB\n    exact absurd hB2 hB\n  exact hAB", block: true)

#text("#8.9 (9 moves instead of 11)")

#raw("variable {A B : Prop}\n\ntheorem not_and_of_not_or' (hnAonB : (¬ A) ∨ (¬ B)) : ¬ (A ∧ B) := by\n  have hAB : ¬ (A ∧ B) := by\n    intro hAB\n    have hAB2 : (¬ A) → (¬ B) := by\n      intro hA\n      have hA2 : A := And.left hAB\n      have hB : ¬ B := absurd hA2 hA\n      exact hB\n    have hBB : (¬ B) → (¬ B) := Impl.idem\n    have hB : ¬ B := Or.elim' hnAonB hAB2 hBB\n    have hB2 : B := And.right hAB\n    exact absurd hB2 hB\n  exact hAB", block: true)

#text("#8.15 (10 moves instead of 11)")

#raw("variable {A : Prop}\n\ntheorem not_iff_imp_false : (¬ A) ↔ (A → False) := by\n  have hAA : (A → False) → (¬ A) := by\n    intro hA\n    have hA2 : ¬ A := by\n      intro hA2\n      have h : False := hA hA2\n      exact h\n    exact hA2\n  have hAA2 : (¬ A) → (A → False) := by\n    intro hA\n    intro hA2\n    have h : False := absurd hA2 hA\n    exact h\n  have hAA3 : (¬ A) ↔ (A → False) := Iff.intro hAA2 hAA\n  exact hAA3", block: true)

#text("#9.2 (6 moves instead of 8)")

#raw("variable {A : Prop}\n\ntheorem not_not_elim (hnnA : ¬ (¬ A)) : A := by\n  have hAA : A ∨ (¬ A) := Classical.em (A)\n  have hAA2 : A → A := Impl.idem\n  have hAA3 : (¬ A) → A := by\n    intro hA\n    have hA2 : A := absurd hA hnnA\n    exact hA2\n  have hA : A := Or.elim' hAA hAA2 hAA3\n  exact hA", block: true)

#text("#9.3 (2 moves instead of 3)")

#raw("variable {A B : Prop}\n\ntheorem by_cases' (hAB : A → B) (hnAB : (¬ A) → B) : B := by\n  have hAA : A ∨ (¬ A) := Classical.em (A)\n  have hB : B := Or.elim' hAA hAB hnAB\n  exact hB", block: true)

#text("#9.6 (8 moves instead of 10)")

#raw("variable {A B : Prop}\n\ntheorem not_and_or' (hnAB : ¬ (A ∧ B)) : (¬ A) ∨ (¬ B) := by\n  have hAA : A ∨ (¬ A) := Classical.em (A)\n  have hAB : A → (¬ B) := by\n    intro hA\n    have hB : ¬ B := by\n      intro hB\n      have hAB : A ∧ B := And.intro hA hB\n      exact absurd hAB hnAB\n    exact hB\n  have hAA2 : (¬ A) ∨ A := Or.comm' hAA\n  have hAB2 : (¬ A) ∨ (¬ B) := Or.imp_right' hAA2 hAB\n  exact hAB2", block: true)

#text("#10.5 (9 moves instead of 13)")

#raw("variable {A : Prop}\n\ntheorem false_or' : A ↔ (False ∨ A) := by\n  have hAA : A → (False ∨ A) := by\n    intro hA\n    have hA2 : False ∨ A := Or.inr hA\n    exact hA2\n  have hA : False → A := by\n    intro h\n    have hA : A := False.elim h\n    exact hA\n  have hAA2 : A → A := Impl.idem\n  have hAA3 : (False ∨ A) → A := fun h => Or.elim h hA hAA2\n  have hAA4 : A ↔ (False ∨ A) := Iff.intro hAA hAA3\n  exact hAA4", block: true)

#text("#11.4 (1 move instead of 2)")

#raw("variable {Ω}\nvariable {Q : Ω → Ω → Prop}\n\nexample : (∀ X : Ω, (∀ Y : Ω, Q X Y)) → (∀ X : Ω, (∀ Y : Ω, Q X Y)) := by\n  have hXYXY : (∀ X : Ω, (∀ Y : Ω, Q X Y)) → (∀ X : Ω, (∀ Y : Ω, Q X Y)) := Impl.idem\n  exact hXYXY", block: true)

#text("#12.3 (5 moves instead of 8)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {R : Ω → Prop}\nvariable {S : Ω → Prop}\n\nexample (hpr : ∀ X : Ω, (P X → R X)) (hsp : ∀ X : Ω, (S X → P X)) : ∀ X : Ω, (S X → R X) := by\n  have hXX : ∀ X : Ω, (S X → R X) := by\n    intro X\n    intro hX\n    have hX2 : P X := barbara X hsp hX\n    have hX3 : R X := barbara X hpr hX2\n    exact hX3\n  exact hXX", block: true)

#text("#12.7 (13 moves instead of 16)")

#raw("variable {Ω}\nvariable {A : Prop}\nvariable {P : Ω → Prop}\n\ntheorem forall_imp_comm' : (A → (∀ X : Ω, P X)) ↔ (∀ X : Ω, (A → P X)) := by\n  have hAXAX : (A → (∀ X : Ω, P X)) → (∀ X : Ω, (A → P X)) := by\n    intro hAX\n    intro X\n    intro hA\n    have hX : ∀ X : Ω, P X := hAX hA\n    have hX2 : P X := hX X\n    exact hX2\n  have hAXAX2 : (∀ X : Ω, (A → P X)) → (A → (∀ X : Ω, P X)) := by\n    intro hAX\n    intro hA\n    intro X\n    have hAX2 : A → P X := hAX X\n    have hX : P X := hAX2 hA\n    exact hX\n  have hAXAX3 : (A → (∀ X : Ω, P X)) ↔ (∀ X : Ω, (A → P X)) := Iff.intro hAXAX hAXAX2\n  exact hAXAX3", block: true)

#text("#15.5 (10 moves instead of 14)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\n\nexample : (¬ (∃ X : Ω, P X)) ↔ (∀ X : Ω, (¬ P X)) := by\n  have hxX : (¬ (∃ x : Ω, P x)) → (∀ X : Ω, (¬ P X)) := by\n    intro hx\n    intro X\n    have hX : ¬ P X := by\n      intro hX\n      have hx2 : ∃ x : Ω, P x := ⟨X, hX⟩\n      exact absurd hx2 hx\n    exact hX\n  have hxX2 : (∀ x : Ω, (¬ P x)) → (¬ (∃ X : Ω, P X)) := by\n    intro hx\n    have hX : ¬ (∃ X : Ω, P X) := forall_not_not_exists hx\n    exact hX\n  have hxX3 : (¬ (∃ x : Ω, P x)) ↔ (∀ X : Ω, (¬ P X)) := Iff.intro hxX hxX2\n  exact hxX3", block: true)

#text("#15.6 (6 moves instead of 9)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hnpq : ¬ (∃ X : Ω, (P X ∧ Q X))) (hRP : ∀ X : Ω, (R X → P X)) : ¬ (∃ X : Ω, (R X ∧ Q X)) := by\n  have hxx : ¬ (∃ x : Ω, (R x ∧ Q x)) := by\n    intro hxx\n    have hxx2 := hxx\n    obtain ⟨X, hXX⟩ := hxx2\n    have hXX2 : R X → P X := hRP X\n    have hXX3 : P X ∧ Q X := And.imp_left' hXX hXX2\n    have hxx2 : ∃ x : Ω, (P x ∧ Q x) := ⟨X, hXX3⟩\n    exact absurd hxx2 hnpq\n  exact hxx", block: true)

#text("#15.7 (4 moves instead of 7)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ P X)) : ∃ X : Ω, (R X ∧ Q X) := by\n  have hXX2 := hex\n  obtain ⟨X, hXX⟩ := hXX2\n  have hXX2 : P X → Q X := hPQ X\n  have hXX3 : R X ∧ Q X := And.imp_right' hXX hXX2\n  have hxx : ∃ x : Ω, (R x ∧ Q x) := ⟨X, hXX3⟩\n  exact hxx", block: true)

#text("#15.10 (9 moves instead of 12)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\nvariable {S : Ω → Prop}\n\nexample (hPnQ : ∀ X : Ω, (P X → (¬ Q X))) (hnQR : ∀ X : Ω, ((¬ Q X) → R X)) (hnrs : ¬ (∃ X : Ω, (R X ∧ S X))) : ∀ X : Ω, (P X → (¬ S X)) := by\n  have hXX : ∀ X : Ω, (P X → (¬ S X)) := by\n    intro X\n    intro hX\n    have hX2 : ¬ Q X := barbara X hPnQ hX\n    have hX3 : R X := barbara X hnQR hX2\n    have hX4 : ¬ S X := by\n      intro hX4\n      have hXX : R X ∧ S X := And.intro hX3 hX4\n      have hxx : ∃ x : Ω, (R x ∧ S x) := ⟨X, hXX⟩\n      exact absurd hxx hnrs\n    exact hX4\n  exact hXX", block: true)

#text("#15.15 (5 moves instead of 8)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ (¬ Q X))) : ∃ X : Ω, (R X ∧ (¬ P X)) := by\n  have hXX2 := hex\n  obtain ⟨X, hXX⟩ := hXX2\n  have hXX2 : P X → Q X := hPQ X\n  have hXX3 : (¬ Q X) → (¬ P X) := mt' hXX2\n  have hXX4 : R X ∧ (¬ P X) := And.imp_right' hXX hXX3\n  have hxx : ∃ x : Ω, (R x ∧ (¬ P x)) := ⟨X, hXX4⟩\n  exact hxx", block: true)

#text("#15.16 (4 moves instead of 7)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hex : ∃ X : Ω, (P X ∧ (¬ Q X))) (hPR : ∀ X : Ω, (P X → R X)) : ∃ X : Ω, (R X ∧ (¬ Q X)) := by\n  have hXX2 := hex\n  obtain ⟨X, hXX⟩ := hXX2\n  have hXX2 : P X → R X := hPR X\n  have hXX3 : R X ∧ (¬ Q X) := And.imp_left' hXX hXX2\n  have hxx : ∃ x : Ω, (R x ∧ (¬ Q x)) := ⟨X, hXX3⟩\n  exact hxx", block: true)

#text("#15.17 (8 moves instead of 9)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hnpq : ¬ (∃ X : Ω, (P X ∧ Q X))) (hRP : ∀ X : Ω, (R X → P X)) (hex : ∃ X : Ω, R X) : ∃ X : Ω, (R X ∧ (¬ Q X)) := by\n  have hX2 := hex\n  obtain ⟨X, hX⟩ := hX2\n  have hX2 : P X := barbara X hRP hX\n  have hX3 : ¬ Q X := by\n    intro hX3\n    have hXX : P X ∧ Q X := And.intro hX2 hX3\n    have hxx : ∃ x : Ω, (P x ∧ Q x) := ⟨X, hXX⟩\n    exact absurd hxx hnpq\n  have hXX : R X ∧ (¬ Q X) := And.intro hX hX3\n  have hxx : ∃ x : Ω, (R x ∧ (¬ Q x)) := ⟨X, hXX⟩\n  exact hxx", block: true)

#text("#15.18 (8 moves instead of 9)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hPQ : ∀ X : Ω, (P X → Q X)) (hnrq : ¬ (∃ X : Ω, (R X ∧ Q X))) (hex : ∃ X : Ω, R X) : ∃ X : Ω, (R X ∧ (¬ P X)) := by\n  have hX2 := hex\n  obtain ⟨X, hX⟩ := hX2\n  have hX2 : ¬ P X := by\n    intro hX2\n    have hX3 : Q X := barbara X hPQ hX2\n    have hXX : R X ∧ Q X := And.intro hX hX3\n    have hxx : ∃ x : Ω, (R x ∧ Q x) := ⟨X, hXX⟩\n    exact absurd hxx hnrq\n  have hXX : R X ∧ (¬ P X) := And.intro hX hX2\n  have hxx : ∃ x : Ω, (R x ∧ (¬ P x)) := ⟨X, hXX⟩\n  exact hxx", block: true)

#text("#15.19 (8 moves instead of 9)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hnpq : ¬ (∃ X : Ω, (P X ∧ Q X))) (hPR : ∀ X : Ω, (P X → R X)) (hex : ∃ X : Ω, P X) : ∃ X : Ω, (R X ∧ (¬ Q X)) := by\n  have hX2 := hex\n  obtain ⟨X, hX⟩ := hX2\n  have hX2 : R X := barbara X hPR hX\n  have hX3 : ¬ Q X := by\n    intro hX3\n    have hXX : P X ∧ Q X := And.intro hX hX3\n    have hxx : ∃ x : Ω, (P x ∧ Q x) := ⟨X, hXX⟩\n    exact absurd hxx hnpq\n  have hXX : R X ∧ (¬ Q X) := And.intro hX2 hX3\n  have hxx : ∃ x : Ω, (R x ∧ (¬ Q x)) := ⟨X, hXX⟩\n  exact hxx", block: true)

#text("#15.20 (5 moves instead of 7)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hPQ : ∀ X : Ω, (P X → Q X)) (hPR : ∀ X : Ω, (P X → R X)) (hex : ∃ X : Ω, P X) : ∃ X : Ω, (R X ∧ Q X) := by\n  have hX2 := hex\n  obtain ⟨X, hX⟩ := hX2\n  have hX2 : Q X := barbara X hPQ hX\n  have hX3 : R X := barbara X hPR hX\n  have hXX : R X ∧ Q X := And.intro hX3 hX2\n  have hxx : ∃ x : Ω, (R x ∧ Q x) := ⟨X, hXX⟩\n  exact hxx", block: true)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36a873420220b8f7587cbdb263783d10825545c4c39b3886ff52c44b8d27c39a-2d59e429fb1e34e7041f8e854197363cf7478294ddcc4a7b886431a225723798.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ericnbrown")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699526")[#strong[#text("ericnbrown")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("This was an 8 move proof of game 9.6 (not_and_or’). It can probably be altered slightly to make it 7 moves. Not sure though (I’ve never used lean before today.)")

#text("— Lean Grimoire — exercise 9.6 (not_and_or’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 8 moves. The shortest proof the game knows takes 10. THIS ONE IS SHORTER.")

#text("— We are given ¬ (A ∧ B).")#linebreak()#text("— We wish to prove (¬ A) ∨ (¬ B).")#linebreak()#text("— Introduce A:")#linebreak()#text("— Introduce B:")#linebreak()#text("— From A, B we deduce A ∧ B (conjunction introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ B.")#linebreak()#text("— Discharging, we obtain A → (¬ B).")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), A → (¬ B) we deduce (¬ B) ∨ (¬ A) (the lemma Or.imp_left’).")#linebreak()#text("— From (¬ B) ∨ (¬ A) we deduce (¬ A) ∨ (¬ B) (the lemma Or.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : (A ∨ B) → (B ∨ A) := by")#linebreak()#text("have hABA : A → (B ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → (B ∨ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_and_or’ (hnAB : ¬ (A ∧ B)) : (¬ A) ∨ (¬ B) := by")#linebreak()#text("have hAB : A → (¬ B) := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : ¬ B := by")#linebreak()#text("intro hB")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("exact absurd hAB hnAB")#linebreak()#text("exact hB")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hBA : (¬ B) ∨ (¬ A) := Or.imp_left’ hAA hAB")#linebreak()#text("have hAB2 : (¬ A) ∨ (¬ B) := Or.comm’ hBA")#linebreak()#text("exact hAB2")

#text("— grimoire-replay v1 9.6 W1siYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5pbnRybyIsWyJoQSIsImhCIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbIm4iLCJoQUIiLCJobkFCIl0sWyJkIiwiaEIiLDFdLFsiYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJhYiIsMV0sWyJjIiwiQ2xhc3NpY2FsLmVtIixbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW1wX2xlZnQnIixbImhBQSIsImhBQiJdLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmNvbW0nIixbImhCQSJdLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dXQ==")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36a873420220b8f7587cbdb263783d10825545c4c39b3886ff52c44b8d27c39a-2d59e429fb1e34e7041f8e854197363cf7478294ddcc4a7b886431a225723798.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ericnbrown")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699527")[#strong[#text("ericnbrown")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("Oops, sorry it looks like Leaving Leaves found this same solution yesterday. Sorry for the duplicate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699349")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A question for clarification: By “game” you mean “deterministic 1-player game”? In that case it might also be called “crafting puzzle” to avoid confusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A implies A and B?")

#emph[#text("[Oops, forgot to mention that ")#mi("A \\implies B")#text(" is given as a hypothesis for this particular level -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699352")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I played several of the levels. I think the intro tactic is confusing for players who are just being introduced to it as a game, without prior exposure to this sort of tactic in a theorem prover.")

#text("In my opinion, if you want to make it engaging and understandable for people who don’t already understand the material on some level, I would really lean into the visualization. Things should fit together and break apart in a visual/animated way. I am thinking of something like Opus Magnum, if you have seen that game.")

#text("I might treat implications as “recipes”, when you start an intro tactic, it zooms into a scroll depicting a world with the introduced variables added. Then when you are done it zooms back out to show that scroll existing in the real world as an implication. You could show this zoom in and out recursively.")

#text("Just my two cents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699354")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("Thanks for the feedback! I had been following reasonably closely the interface of my previously (manually coded) interactive textbook, which was limited by my ability to work with complex graphics, but I am now realizing that with modern coding agents I can indeed implement more sophisticated animations. I got my agent to create a mockup of how one might animate a level that involves ")#raw("intro")#text(", such as ")#mi("A \\implies A \\wedge A")#text(", by creating a “scroll” one zooms into and out of as you suggest: ")#link("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")[#text("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")]#text(" . If this seems like a significantly more conceptual type of interface to navigate, I can try to develop it further.")

#text("p.s. my agent also pointed me to the game “")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” that has a similar “zoom in / zoom out” mechanic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699359")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("“")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” is interesting. It reminds me of “Sokoban”. there is complexity analysis (NP-hard; PSpace-complete) back in the late 1990s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/161ebc022821268b1c80f6715fa7acfa514968bc9066623550ba9f9edc7055ca-50459a384a3c566d54cd879c52a49550d995fa421d4e8360dd59349761953378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of enchantingsecretlyfc1dc3c400")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699367")[#strong[#text("enchantingsecretlyfc1dc3c400")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Sokoban! Great game")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/161ebc022821268b1c80f6715fa7acfa514968bc9066623550ba9f9edc7055ca-50459a384a3c566d54cd879c52a49550d995fa421d4e8360dd59349761953378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shawn Hood")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699353")[#strong[#text("Shawn Hood")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I’m not familiar with Lean myself, but have been armchair following some various discussions in mathematical discipline due to the LLM action of late. My son and I would love to play test the Fantasy version and happy to share feedback")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a190384e2d1962e7bf8a57e87c41fdae71e8488202eb4f0c1d8732b6fa7bedb0-8579eeaa773bd1662be7cd243dd9e7d6da105934c6a5acea8eaa1627ea766af2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neunhoef")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699355")[#strong[#text("neunhoef")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I would recommend to switch on “Explicit Parantheses” by default in the beginning, because then one does not have to know that conjunction binds right associatively in Lean. I got confused for a moment by this.")

#emph[#text("[Now implemented – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52582ede8a5998612e024b8d9b2d998c2df38c0556b73e6e5f4e7e379e0ef205-e01020e5c2c5ba180b5dbbd6559399cfd4ac3050527395cfca30cf59e487d019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699360")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("I love the idea, but perhaps the logic notation (A ^ B) needs more expansion than the logic terms (hypothesis, statements)? The informal presentation of the steps is excellent, and if you had similarly informal ways of expressing the goal and the steps you could take to get there you might connect with a more general audience of players (and from there tempt them into learning the more technical notation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699376")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Thanks for the suggestion! There is now a “Plain English” version for the logical expressions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd8bf3c8c75562ac54bebde0a10d320060702c3d66248d9aae05ff0288669b1-db6a5199b74e557e6890b959866d30c559ceb23327c55ad5dc74eb77f141a626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Daly")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699361")[#strong[#text("Timothy Daly")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("You might want to look at Patrick Massot’s graph of the LEAN theorems.")

#text("I show those that need to be proven. Your game might be an interesting")

#text("student guidance project, especially if they use an LLM to help. The")

#text("students could be proving real theorems while learning")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Check out the comments on Hacker News: ")#link("https://news.ycombinator.com/item?id=50462375")[#text("https://news.ycombinator.com/item?id=50462375")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699363")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Maybe add a “Hint” system? Even knowing istintively why a proposition is true, it is not easy to translate it into Lean procedures.")

#text("On the other hand, you can run an agent and add for each problem what is the minimum possible number of steps for any given problem given the available resources/recipes at the moment. This would add to the challenge for already experienced users that are not satisfied with longer solutions.")

#text("It has always been a dream of mine programming an actual videogame on math, but I barely can scrape time for anything, and not having access to any agent makes it borderline infeasible")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Thanks for the suggestions! Hints have now been added for each level, as well as an explicit count of steps compared against the shortest known solution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699364")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and I just noticed 7.12 is used in previous ones like 7.2")

#emph[#text("[Now re-ordered. Hopefully this should not impact existing saved game states. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699379")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and also I don’t see how to do 13.4 without knowing Pick that is explained later in 14.1")

#emph[#text("[Hint updated on this – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa7002f980bc9f3adff257e08ba0aa57205ecd6048d18584d87e6d4ee2228437-52285627566ef753cc59cb85ca6f216fb6631b1fde677af2e4157bdd39668a8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lovinged57041eed")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699371")[#strong[#text("lovinged57041eed")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Hello Terence.Thank you for sharing your conceptual scheme for “Lean Grimoire”. The name resonates right away.Initial thoughts and observations:- having a conformal analog, a locally “familiar” model,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("This is a very nice idea! Also, all good games for developing visualization, better logical reasoning (like finding reasoning flaws, for example), detecting patterns etc are all very welcome!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699378")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Something that I was telling my students that they have to battle when writing by hand, but they won’t face in the game, is malformed expressions. In the game they could combine recipes and get the wrong goal due to, say parentheses in places that are not those of the real goal. However, I didn’t see a way to obtain malformed expressions.")

#text("Maybe there could be a version of the grimoire that was scribbled over by a wizard apprentice and some recipes are malformed, perhaps deceptively close to other recipes that are well formed. The user still has to use the right ones. Or perhaps, both get to the goal and delete the malformed recipes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699484")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("Thinking about this, I think that *Lean* itself is the correct environment for this “hard mode” version of the game. To this end, I (through my coding agent) have now implemented a “playground” button that takes the current Lean “spellbook” and takes you to the Lean playground, where you can then complete the proof yourself using the full expressive power of Lean. (Of course, many of the exercises can be one-shotted using powerful Lean tactics such as ")#raw("grind")#text(", but presumably a serious student wanting to learn proof technique would eschew such tactics.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Shorter proof for 4.8:")

#text("— Lean Grimoire — exercise 4.8 (And.symm’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 5. THIS ONE IS SHORTER.")

#text("— We wish to prove (A ∧ B) → (B ∧ A).")#linebreak()#text("— Introduce A ∧ B:")#linebreak()#text("— From A ∧ B we deduce B ∧ A (the lemma And.comm’).")#linebreak()#text("— Discharging, we obtain (A ∧ B) → (B ∧ A).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem And.symm’ : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("have hABBA : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hBA : B ∧ A := And.comm’ hAB")#linebreak()#text("exact hBA")#linebreak()#text("exact hABBA")

#text("Also, there is a somewhat similar game if anyone is interested:")

#link("https://adam.math.hhu.de/#/g/leanprover-community/nng4")[#text("https://adam.math.hhu.de/#/g/leanprover-community/nng4")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699391")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("That works! I’ve updated the game to record this new proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699385")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and it would also be very helpful to know how to write statements with forall and exists in the scrolls…. it does not accept \\exists or ∃ or any other variant that I can think of")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Can you make a linear logic dlc?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/280e4053f2c99fc48d025d37b8e5c097fb942ffddaabc8d3c3e49a32ee0c8073-b8161083f39fb5f211b74368ffde5e9c1646c2c8479436b18b93401eb8ae9012.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PistachioCake")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699392")[#strong[#text("PistachioCake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("A shorter proof for Exercise 2.3!")

#raw("-- Lean Grimoire — exercise 2.3  (And.assoc_right)\n-- https://terrytao.wordpress.com/2026/11/11/lean-grimoire/\n-- Proved in 5 moves.  The shortest proof the game knows takes 6.  THIS ONE IS SHORTER.\n--\n-- We are given A ∧ (B ∧ C).\n-- We wish to prove (A ∧ B) ∧ C.\n-- From A ∧ (B ∧ C) we deduce (B ∧ C) ∧ A  (the lemma And.comm').\n-- From (B ∧ C) ∧ A we deduce B ∧ (C ∧ A)  (the lemma And.assoc_left).\n-- From B ∧ (C ∧ A) we deduce (C ∧ A) ∧ B  (the lemma And.comm').\n-- From (C ∧ A) ∧ B we deduce C ∧ (A ∧ B)  (the lemma And.assoc_left).\n-- From C ∧ (A ∧ B) we deduce (A ∧ B) ∧ C  (the lemma And.comm').\n-- This is what we wished to prove.  ∎\n\n-- Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with\n-- it. 2 of them, each as you proved it, deepest first.\n\n-- 2.1  (And.comm')\nsection\nvariable {A B : Prop}\n\ntheorem And.comm' (hAB : A ∧ B) : B ∧ A := by\n  have hA : A := And.left hAB\n  have hB : B := And.right hAB\n  have hBA : B ∧ A := And.intro hB hA\n  exact hBA\nend\n\n-- 2.2  (And.assoc_left)\nsection\nvariable {A B C : Prop}\n\ntheorem And.assoc_left (hABC : (A ∧ B) ∧ C) : A ∧ (B ∧ C) := by\n  have hAB : A ∧ B := And.left hABC\n  have hA : A := And.left hAB\n  have hB : B := And.right hAB\n  have hC : C := And.right hABC\n  have hBC : B ∧ C := And.intro hB hC\n  have hABC2 : A ∧ (B ∧ C) := And.intro hA hBC\n  exact hABC2\nend\n\n-- and the proof itself:\n\nvariable {A B C : Prop}\n\ntheorem And.assoc_right (hABC : A ∧ (B ∧ C)) : (A ∧ B) ∧ C := by\n  have hBCA : (B ∧ C) ∧ A := And.comm' hABC\n  have hBCA2 : B ∧ (C ∧ A) := And.assoc_left hBCA\n  have hCAB : (C ∧ A) ∧ B := And.comm' hBCA2\n  have hCAB2 : C ∧ (A ∧ B) := And.assoc_left hCAB\n  have hABC2 : (A ∧ B) ∧ C := And.comm' hCAB2\n  exact hABC2\n", block: true)

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("one step proof for Exercise 4.3:")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("— Lean Grimoire — exercise 6.8 (Or.assoc_left)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 14 moves. The shortest proof the game knows takes 17. THIS ONE IS SHORTER.")

#text("— We are given (A ∨ B) ∨ C.")#linebreak()#text("— We wish to prove A ∨ (B ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∨ C we deduce A ∨ (B ∨ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, C we deduce B ∨ C (disjunction introduction (left)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From C, B we deduce B ∨ C (disjunction introduction (right)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∨ C)).")#linebreak()#text("— From A → (A ∨ (B ∨ C)), B → (A ∨ (B ∨ C)) we deduce (A ∨ B) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)), (A ∨ B) ∨ C we deduce A ∨ (B ∨ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by")#linebreak()#text("have hAABC : A → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inl hA")#linebreak()#text("exact hABC2")#linebreak()#text("have hBABC : B → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBC : B ∨ C := Or.inl hB")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hCABC : C → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hC")#linebreak()#text("have hBC : B ∨ C := Or.inr hC")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text("have hABCABC : ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) := fun h => Or.elim h hABABC hCABC")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := hABCABC hABC")#linebreak()#text("exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699396")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("— Lean Grimoire — exercise 9.7 (not_or_of_imp’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given A → B.")#linebreak()#text("— We wish to prove (¬ A) ∨ B.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), A → B we deduce B ∨ (¬ A) (the lemma Or.imp_left’).")#linebreak()#text("— From B ∨ (¬ A) we deduce (¬ A) ∨ B (the lemma Or.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : (A ∨ B) → (B ∨ A) := by")#linebreak()#text("have hABA : A → (B ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → (B ∨ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_or_of_imp’ (hAB : A → B) : (¬ A) ∨ B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hBA : B ∨ (¬ A) := Or.imp_left’ hAA hAB")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.comm’ hBA")#linebreak()#text("exact hAB2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efab1854848648e6c4948288f69a4c59799a16b6404b128267d77781fe5736dd-a2561b2000fbb44883fc1cc8398d7ab85870aff1df22756714c8c156b46caf8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699399")[#strong[#text("Jacob")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Shorter proof for 4.3:")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6de08af996f1b13b848c07305d34e8876f7bc6b7a77eb42047dcdc8ac5900725-85b0d5b83f7030bb5c34eb01a958aa331cef9d7e5909f3d107a929253025af54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dario Bajo")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699401")[#strong[#text("Dario Bajo")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Exercise 4.3")

#strong[#text("QED!")]#text(" You brewed ")#emph[#text("((A ∧ B) ∨ C) → ((A ∧ B) ∨ C)")]#text(" in 1 move.🏆 ")#strong[#text("A new record.")]#text(" The shortest proof this game knows takes 2 moves, so you have found something it does not. Please tell me about it: ")#strong[#text("Copy")]#text(" or ")#strong[#text("Save")]#text(" the proof below and leave it in the comments on ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("the blog post")]#text(".")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Shorter proof for 2.3 :D")#linebreak()#text("(Tried commenting this earlier, but it didn’t show up… If there’s a duplicate, sorry!)")

#text("— Lean Grimoire — exercise 2.3 (And.assoc_right)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 6. THIS ONE IS SHORTER.")

#text("— We are given A ∧ (B ∧ C).")#linebreak()#text("— We wish to prove (A ∧ B) ∧ C.")#linebreak()#text("— From A ∧ (B ∧ C) we deduce (B ∧ C) ∧ A (the lemma And.comm’).")#linebreak()#text("— From (B ∧ C) ∧ A we deduce B ∧ (C ∧ A) (the lemma And.assoc_left).")#linebreak()#text("— From B ∧ (C ∧ A) we deduce (C ∧ A) ∧ B (the lemma And.comm’).")#linebreak()#text("— From (C ∧ A) ∧ B we deduce C ∧ (A ∧ B) (the lemma And.assoc_left).")#linebreak()#text("— From C ∧ (A ∧ B) we deduce (A ∧ B) ∧ C (the lemma And.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 2.2 (And.assoc_left)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.assoc_left (hABC : (A ∧ B) ∧ C) : A ∧ (B ∧ C) := by")#linebreak()#text("have hC : C := And.right hABC")#linebreak()#text("have hAB : A ∧ B := And.left hABC")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBC : B ∧ C := And.intro hB hC")#linebreak()#text("have hABC2 : A ∧ (B ∧ C) := And.intro hA hBC")#linebreak()#text("exact hABC2")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem And.assoc_right (hABC : A ∧ (B ∧ C)) : (A ∧ B) ∧ C := by")#linebreak()#text("have hBCA : (B ∧ C) ∧ A := And.comm’ hABC")#linebreak()#text("have hBCA2 : B ∧ (C ∧ A) := And.assoc_left hBCA")#linebreak()#text("have hCAB : (C ∧ A) ∧ B := And.comm’ hBCA2")#linebreak()#text("have hCAB2 : C ∧ (A ∧ B) := And.assoc_left hCAB")#linebreak()#text("have hABC2 : (A ∧ B) ∧ C := And.comm’ hCAB2")#linebreak()#text("exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d8743ae0fe0c9a25f7a64cc22f010e4d6e7284961c7cd41c6bef0c04b0afdd-99b1fdce4cbf1d63453450780711acdac96e460d2707765fc440a052f7f99a20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kantian")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699406")[#strong[#text("Kantian")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("You advise to post shorter proof if we find one, so here is one")

#text("— Lean Grimoire — exercise 6.8 (Or.assoc_left)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 14 moves. The shortest proof the game knows takes 17. THIS ONE IS SHORTER.")#linebreak()#text("—")#linebreak()#text("— We are given (A ∨ B) ∨ C.")#linebreak()#text("— We wish to prove A ∨ (B ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∨ C we deduce A ∨ (B ∨ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, C we deduce B ∨ C (disjunction introduction (left)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∨ C)).")#linebreak()#text("— From A → (A ∨ (B ∨ C)), B → (A ∨ (B ∨ C)) we deduce (A ∨ B) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From C, B we deduce B ∨ C (disjunction introduction (right)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∨ C)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)), (A ∨ B) ∨ C we deduce A ∨ (B ∨ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by")#linebreak()#text(" have hAABC : A → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hA")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inl hA")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hBABC : B → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hB")#linebreak()#text(" have hBC : B ∨ C := Or.inl hB")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text(" have hCABC : C → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hC")#linebreak()#text(" have hBC : B ∨ C := Or.inr hC")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hABCABC : ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) := fun h => Or.elim h hABABC hCABC")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := hABCABC hABC")#linebreak()#text(" exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699428")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.5")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 11 moves. The shortest proof the game knows takes 14. THIS ONE IS SHORTER.")

#text("— We wish to prove (¬ (∃ X : Ω, P(X))) ↔ (∀ X : Ω, (¬ P(X))).")#linebreak()#text("— Introduce ¬ (∃ x : Ω, P(x)), then an arbitrary X : Ω:")#linebreak()#text("— Introduce P(X):")#linebreak()#text("— From P(X), X we deduce ∃ x : Ω, P(x) (existential introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ P(X).")#linebreak()#text("— Discharging, we obtain (¬ (∃ x : Ω, P(x))) → (∀ X : Ω, (¬ P(X))).")#linebreak()#text("— From (¬ (∃ x : Ω, P(x))) → (∀ X : Ω, (¬ P(X))) we deduce (¬ (¬ (∃ x : Ω, P(x)))) ∨ (∀ X : Ω, (¬ P(X))) (the lemma not_or_of_imp’).")#linebreak()#text("— Introduce ∀ X : Ω, (¬ P(X)):")#linebreak()#text("— From ∀ X : Ω, (¬ P(X)) we deduce ¬ (∃ X : Ω, P(X)) (the lemma forall_not_not_exists).")#linebreak()#text("— Discharging, we obtain (∀ X : Ω, (¬ P(X))) → (¬ (∃ X : Ω, P(X))).")#linebreak()#text("— From (¬ (∃ x : Ω, P(x))) → (∀ X : Ω, (¬ P(X))), (∀ X : Ω, (¬ P(X))) → (¬ (∃ X : Ω, P(X))) we deduce (¬ (∃ x : Ω, P(x))) ↔ (∀ X : Ω, (¬ P(X))) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 16 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hCCD : C → (C ∨ D) := by")#linebreak()#text("intro hC")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hACD : A → (C ∨ D) := implies_trans hAC hCCD")#linebreak()#text("have hDCD : D → (C ∨ D) := by")#linebreak()#text("intro hD")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := implies_trans hBD hDCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : (A ∨ B) → (B ∨ A) := by")#linebreak()#text("have hABA : A → (B ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → (B ∨ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 9.7 (not_or_of_imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem not_or_of_imp’ (hAB : A → B) : (¬ A) ∨ B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hBA : B ∨ (¬ A) := Or.imp_left’ hAA hAB")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.comm’ hBA")#linebreak()#text("exact hAB2")#linebreak()#text("end")

#text("— 6.11 (and_or_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem and_or_left’ (hABC : A ∧ (B ∨ C)) : (A ∧ B) ∨ (A ∧ C) := by")#linebreak()#text("have hA : A := And.left hABC")#linebreak()#text("have hBC : B ∨ C := And.right hABC")#linebreak()#text("have hBAB : B → (A ∧ B) := by")#linebreak()#text("intro hB")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("exact hAB")#linebreak()#text("have hCAC : C → (A ∧ C) := by")#linebreak()#text("intro hC")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.imp’ hBC hBAB hCAC")#linebreak()#text("exact hABAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hBA : B ∨ A := Or.comm’ hAB")#linebreak()#text("have hCA : C ∨ A := Or.imp_left’ hBA hBC")#linebreak()#text("have hAC : A ∨ C := Or.comm’ hCA")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.10 (or_and_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem or_and_left’ (hABC : A ∨ (B ∧ C)) : (A ∨ B) ∧ (A ∨ C) := by")#linebreak()#text("have hBCB : (B ∧ C) → B := by")#linebreak()#text("intro hBC")#linebreak()#text("have hB : B := And.left hBC")#linebreak()#text("exact hB")#linebreak()#text("have hAB : A ∨ B := Or.imp_right’ hABC hBCB")#linebreak()#text("have hBCC : (B ∧ C) → C := by")#linebreak()#text("intro hBC")#linebreak()#text("have hC : C := And.right hBC")#linebreak()#text("exact hC")#linebreak()#text("have hAC : A ∨ C := Or.imp_right’ hABC hBCC")#linebreak()#text("have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC")#linebreak()#text("exact hABAC")#linebreak()#text("end")

#text("— 8.14 (resolution’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem resolution’ (hAB : A ∨ B) (hnAC : (¬ A) ∨ C) : C ∨ B := by")#linebreak()#text("have hABAC : (A ∨ B) ∧ ((¬ A) ∨ C) := And.intro hAB hnAC")#linebreak()#text("have hABAABC : ((A ∨ B) ∧ (¬ A)) ∨ ((A ∨ B) ∧ C) := and_or_left’ hABAC")#linebreak()#text("have hABAB : ((A ∨ B) ∧ (¬ A)) → B := by")#linebreak()#text("intro hABA")#linebreak()#text("have hA : ¬ A := And.right hABA")#linebreak()#text("have hAB2 : A → B := by")#linebreak()#text("intro hA2")#linebreak()#text("have hB : B := absurd hA2 hA")#linebreak()#text("exact hB")#linebreak()#text("have hBB : B ∨ B := Or.imp_left’ hAB hAB2")#linebreak()#text("have hB : B := or_self_elim’ hBB")#linebreak()#text("exact hB")#linebreak()#text("have hBABC : B ∨ ((A ∨ B) ∧ C) := Or.imp_left’ hABAABC hABAB")#linebreak()#text("have hABCCAB : ((A ∨ B) ∧ C) → (C ∧ (A ∨ B)) := by")#linebreak()#text("intro hABC")#linebreak()#text("have hCAB : C ∧ (A ∨ B) := And.comm’ hABC")#linebreak()#text("exact hCAB")#linebreak()#text("have hBCAB : B ∨ (C ∧ (A ∨ B)) := Or.imp_right’ hBABC hABCCAB")#linebreak()#text("have hBCBAB : (B ∨ C) ∧ (B ∨ (A ∨ B)) := or_and_left’ hBCAB")#linebreak()#text("have hBC : B ∨ C := And.left hBCBAB")#linebreak()#text("have hCB : C ∨ B := Or.comm’ hBC")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 9.2 (not_not_elim)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) ∨ A := Or.comm’ hAA")#linebreak()#text("have hAA3 : (¬ (¬ A)) ∨ A := Or.inl hnnA")#linebreak()#text("have hAA4 : A ∨ A := resolution’ hAA2 hAA3")#linebreak()#text("have hA : A := or_self_elim’ hAA4")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 13.4 (forall_not_not_exists)")#linebreak()#text("section")#linebreak()#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")

#text("theorem forall_not_not_exists (hfn : ∀ X : Ω, (¬ P X)) : ¬ (∃ X : Ω, P X) := by")#linebreak()#text("have X : Ω := Classical.choice inferInstance")#linebreak()#text("have hX : ¬ P X := hfn X")#linebreak()#text("have hx : ¬ (¬ (¬ (∃ x : Ω, P x))) := by")#linebreak()#text("intro hx")#linebreak()#text("have hx2 : ∃ x : Ω, P x := not_not_elim hx")#linebreak()#text("have hx3 := hx2")#linebreak()#text("obtain ⟨a, ha⟩ := hx3")#linebreak()#text("have ha2 : ¬ P a := hfn a")#linebreak()#text("exact absurd ha ha2")#linebreak()#text("have hx2 : ¬ (∃ x : Ω, P x) := not_not_elim hx")#linebreak()#text("exact hx2")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")

#text("example : (¬ (∃ X : Ω, P X)) ↔ (∀ X : Ω, (¬ P X)) := by")#linebreak()#text("have hxX : (¬ (∃ x : Ω, P x)) → (∀ X : Ω, (¬ P X)) := by")#linebreak()#text("intro hx")#linebreak()#text("intro X")#linebreak()#text("have hX : ¬ P X := by")#linebreak()#text("intro hX")#linebreak()#text("have hx2 : ∃ x : Ω, P x := ⟨X, hX⟩")#linebreak()#text("exact absurd hx2 hx")#linebreak()#text("exact hX")#linebreak()#text("have hxX2 : (¬ (¬ (∃ x : Ω, P x))) ∨ (∀ X : Ω, (¬ P X)) := not_or_of_imp’ hxX")#linebreak()#text("have hXX : (∀ X : Ω, (¬ P X)) → (¬ (∃ X : Ω, P X)) := by")#linebreak()#text("intro hX")#linebreak()#text("have hX2 : ¬ (∃ X : Ω, P X) := forall_not_not_exists hX")#linebreak()#text("exact hX2")#linebreak()#text("have hxX3 : (¬ (∃ x : Ω, P x)) ↔ (∀ X : Ω, (¬ P X)) := Iff.intro hxX hXX")#linebreak()#text("exact hxX3")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699429")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.6")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 9. THIS ONE IS SHORTER.")

#text("— We are given ¬ (∃ X : Ω, (P(X) ∧ Q(X))), ∀ X : Ω, (R(X) → P(X)).")#linebreak()#text("— We wish to prove ¬ (∃ X : Ω, (R(X) ∧ Q(X))).")#linebreak()#text("— Introduce ∃ X : Ω, (R(X) ∧ Q(X)):")#linebreak()#text("— Since ∃ X : Ω, (R(X) ∧ Q(X)), fix X : Ω with R(X) ∧ Q(X).")#linebreak()#text("— From ∀ X : Ω, (R(X) → P(X)), X we deduce R(X) → P(X) (universal instantiation (specialization)).")#linebreak()#text("— From R(X) ∧ Q(X), R(X) → P(X) we deduce P(X) ∧ Q(X) (the lemma And.imp_left’).")#linebreak()#text("— From P(X) ∧ Q(X), X we deduce ∃ x : Ω, (P(x) ∧ Q(x)) (existential introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (∃ X : Ω, (R(X) ∧ Q(X))).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.8 (And.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_left’ (hAB : A ∧ B) (hAC : A → C) : C ∧ B := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hCB : C ∧ B := And.intro hC hB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hnpq : ¬ (∃ X : Ω, (P X ∧ Q X))) (hRP : ∀ X : Ω, (R X → P X)) : ¬ (∃ X : Ω, (R X ∧ Q X)) := by")#linebreak()#text("have hXX : ¬ (∃ X : Ω, (R X ∧ Q X)) := by")#linebreak()#text("intro hXX")#linebreak()#text("have hXX3 := hXX")#linebreak()#text("obtain ⟨X, hXX2⟩ := hXX3")#linebreak()#text("have hXX3 : R X → P X := hRP X")#linebreak()#text("have hXX4 : P X ∧ Q X := And.imp_left’ hXX2 hXX3")#linebreak()#text("have hxx : ∃ x : Ω, (P x ∧ Q x) := ⟨X, hXX4⟩")#linebreak()#text("exact absurd hxx hnpq")#linebreak()#text("exact hXX")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699430")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.7")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 4 moves. The shortest proof the game knows takes 7. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → Q(X)), ∃ X : Ω, (R(X) ∧ P(X)).")#linebreak()#text("— We wish to prove ∃ X : Ω, (R(X) ∧ Q(X)).")#linebreak()#text("— Since ∃ X : Ω, (R(X) ∧ P(X)), fix X : Ω with R(X) ∧ P(X).")#linebreak()#text("— From ∀ X : Ω, (P(X) → Q(X)), X we deduce P(X) → Q(X) (universal instantiation (specialization)).")#linebreak()#text("— From R(X) ∧ P(X), P(X) → Q(X) we deduce R(X) ∧ Q(X) (the lemma And.imp_right’).")#linebreak()#text("— From R(X) ∧ Q(X), X we deduce ∃ x : Ω, (R(x) ∧ Q(x)) (existential introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.9 (And.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_right’ (hAB : A ∧ B) (hBC : B → C) : A ∧ C := by")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ P X)) : ∃ X : Ω, (R X ∧ Q X) := by")#linebreak()#text("have hXX2 := hex")#linebreak()#text("obtain ⟨X, hXX⟩ := hXX2")#linebreak()#text("have hXX2 : P X → Q X := hPQ X")#linebreak()#text("have hXX3 : R X ∧ Q X := And.imp_right’ hXX hXX2")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ Q x) := ⟨X, hXX3⟩")#linebreak()#text("exact hxx")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699431")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.15")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → Q(X)), ∃ X : Ω, (R(X) ∧ (¬ Q(X))).")#linebreak()#text("— We wish to prove ∃ X : Ω, (R(X) ∧ (¬ P(X))).")#linebreak()#text("— Since ∃ X : Ω, (R(X) ∧ (¬ Q(X))), fix X : Ω with R(X) ∧ (¬ Q(X)).")#linebreak()#text("— From ∀ X : Ω, (P(X) → Q(X)), X we deduce P(X) → Q(X) (universal instantiation (specialization)).")#linebreak()#text("— From P(X) → Q(X) we deduce (¬ Q(X)) → (¬ P(X)) (the lemma mt’).")#linebreak()#text("— From R(X) ∧ (¬ Q(X)), (¬ Q(X)) → (¬ P(X)) we deduce R(X) ∧ (¬ P(X)) (the lemma And.imp_right’).")#linebreak()#text("— From R(X) ∧ (¬ P(X)), X we deduce ∃ x : Ω, (R(x) ∧ (¬ P(x))) (existential introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 5.9 (And.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_right’ (hAB : A ∧ B) (hBC : B → C) : A ∧ C := by")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ (¬ Q X))) : ∃ X : Ω, (R X ∧ (¬ P X)) := by")#linebreak()#text("have hXX2 := hex")#linebreak()#text("obtain ⟨X, hXX⟩ := hXX2")#linebreak()#text("have hXX2 : P X → Q X := hPQ X")#linebreak()#text("have hXX3 : (¬ Q X) → (¬ P X) := mt’ hXX2")#linebreak()#text("have hXX4 : R X ∧ (¬ P X) := And.imp_right’ hXX hXX3")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ (¬ P x)) := ⟨X, hXX4⟩")#linebreak()#text("exact hxx")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699432")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.16")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 4 moves. The shortest proof the game knows takes 7. THIS ONE IS SHORTER.")

#text("— We are given ∃ X : Ω, (P(X) ∧ (¬ Q(X))), ∀ X : Ω, (P(X) → R(X)).")#linebreak()#text("— We wish to prove ∃ X : Ω, (R(X) ∧ (¬ Q(X))).")#linebreak()#text("— Since ∃ X : Ω, (P(X) ∧ (¬ Q(X))), fix X : Ω with P(X) ∧ (¬ Q(X)).")#linebreak()#text("— From ∀ X : Ω, (P(X) → R(X)), X we deduce P(X) → R(X) (universal instantiation (specialization)).")#linebreak()#text("— From P(X) ∧ (¬ Q(X)), P(X) → R(X) we deduce R(X) ∧ (¬ Q(X)) (the lemma And.imp_left’).")#linebreak()#text("— From R(X) ∧ (¬ Q(X)), X we deduce ∃ x : Ω, (R(x) ∧ (¬ Q(x))) (existential introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.8 (And.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_left’ (hAB : A ∧ B) (hAC : A → C) : C ∧ B := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hCB : C ∧ B := And.intro hC hB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hex : ∃ X : Ω, (P X ∧ (¬ Q X))) (hPR : ∀ X : Ω, (P X → R X)) : ∃ X : Ω, (R X ∧ (¬ Q X)) := by")#linebreak()#text("have hXX2 := hex")#linebreak()#text("obtain ⟨X, hXX⟩ := hXX2")#linebreak()#text("have hXX2 : P X → R X := hPR X")#linebreak()#text("have hXX3 : R X ∧ (¬ Q X) := And.imp_left’ hXX hXX2")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ (¬ Q x)) := ⟨X, hXX3⟩")#linebreak()#text("exact hxx")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699433")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("In Exercise 16.1, trying to introduce X : Set, it instead introduces X : \\Omega, so following the hints gets you to a wrong solution")

#emph[#text("[Now fixed, hopefully – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699439")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 7.4 (Iff.refl’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We wish to prove A ↔ A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From A → A, A → A we deduce A ↔ A (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem Iff.refl’ : A ↔ A := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAA2 : A ↔ A := Iff.intro hAA hAA")#linebreak()#text("exact hAA2")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699450")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2026")])]

#text("If this is going to be hosted, perhaps it could automatically accept and integrate shorter proofs for exercises, since they can be verified? Adding them manually will not scale well. (Perhaps it could also record multiple known proofs of various lengths and say if they’re known to it – though that’s getting into territory where you’d an agent to try to decide if it was really “new” for anything that isn’t super short)")

#emph[#text("[The game is not hosted right now (to avoid various security/privacy/cost issues), but I have implemented a streamlining of the reporting process -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96cd159cba9b8645acb676fd46ad3f5324a0d34780dfd4efaeb11538bbe5264a-1253958c83b482d3d0fdf4c302c8b082789c9abd8a4a85078f0ce09b2efee4a8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ram Anvesh Reddy")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699454")[#strong[#text("Ram Anvesh Reddy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2026")])]

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("Two shorter proofs.")

#text("— Lean Grimoire — exercise 12.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → R(X)), ∀ X : Ω, (S(X) → P(X)).")#linebreak()#text("— We wish to prove ∀ X : Ω, (S(X) → R(X)).")#linebreak()#text("— Introduce an arbitrary X : Ω:")#linebreak()#text("— From ∀ X : Ω, (S(X) → P(X)), X we deduce S(X) → P(X) (universal instantiation (specialization)).")#linebreak()#text("— From ∀ X : Ω, (P(X) → R(X)), X we deduce P(X) → R(X) (universal instantiation (specialization)).")#linebreak()#text("— From S(X) → P(X), P(X) → R(X) we deduce S(X) → R(X) (the lemma implies_trans).")#linebreak()#text("— Discharging, we obtain ∀ X : Ω, (S(X) → R(X)).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")#linebreak()#text("variable {S : Ω → Prop}")

#text("example (hpr : ∀ X : Ω, (P X → R X)) (hsp : ∀ X : Ω, (S X → P X)) : ∀ X : Ω, (S X → R X) := by")#linebreak()#text("have hXX : ∀ X : Ω, (S X → R X) := by")#linebreak()#text("intro X")#linebreak()#text("have hXX : S X → P X := hsp X")#linebreak()#text("have hXX2 : P X → R X := hpr X")#linebreak()#text("have hXX3 : S X → R X := implies_trans hXX hXX2")#linebreak()#text("exact hXX3")#linebreak()#text("exact hXX")

#text("— Lean Grimoire — exercise 9.2 (not_not_elim)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 7 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ¬ (¬ A).")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From ¬ A, ¬ (¬ A), A we deduce A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ A) → A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From A → A, (¬ A) → A we deduce (A ∨ (¬ A)) → A (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ (¬ A)) → A, A ∨ (¬ A) we deduce A (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : A → A := Impl.idem")#linebreak()#text("have hAAA : (A ∨ (¬ A)) → A := fun h => Or.elim h hAA3 hAA2")#linebreak()#text("have hA : A := hAAA hAA")#linebreak()#text("exact hA")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#enum(start: 1, 
[#text("Thank you for the nice game. For me it proved to be quite addictive. There are a couple of bugs in the Lean Gimoire in the later levels.")]
)

#text("In Exercise 16.1 if one introduces X : Set, it actually introduces X : Omega, which breaks things. I was able to patch it on the JavaScript console using the following snippet (LLM generated):")

#text("(() => {")#linebreak()#text("const game = window.__grimoire;")#linebreak()#text("const original = game.G.openVariable;")

#text("game.G.openVariable = (env, v) => {")#linebreak()#text("const term = game.state.terms.find(")#linebreak()#text("t => t.tag === “var” && t.name === v.name")#linebreak()#text(");")

#raw("return original(env, {\n  ...v,\n  sort: term?.sort ?? v.sort\n});\n", block: true)

#text("};")

#text("console.log(“Variable sort bug patched!”);")#linebreak()#text("})();")

#emph[#text("[Now fixed, hopefully – T.]")]

#text("2. In Exercise 17.3, I got “unexpected character “*”” when entering f(c) * c on the term bench. Apparently the Lean Grimoire expects the Unicode symbol ∗ (U+2217), not the ordinary asterisk * (U+002A).")

#emph[#text("[Now fixed, hopefully – T.]")]

#text("3. When solving Exercise 18.9, I managed to slow down Firefox to a crawl. My solution was apparently far from optimal, but it did work in Chromium. (Not sure where the problem is, but this affect other people as well.)")

#emph[#text("[This may possibly be due to the savefile bug, so the fix implemented below may also address this issue – T.]")]

#text("4. The saved progress got somehow messed up for me. It forgot to record some solutions. I had a look at the data in Local Storage under the key grimoire.v2. The stored json string is 5.1 Mbyte for me, which seems large. The biggest junk of the data is apparently the progress stored for Exercise 6.13. Maybe I did something stupid there, maybe it got corrupted during an update.")#linebreak()#text("(Not sure where the problem is, but this affect other people as well.)")

#emph[#text("[The save file format was excessively bloated. This should now be fixed. – T.]")]

#text("5. Suppose one unlocks all problems, selects an unsolved problem and makes a bit of progress. If one then reloads the page, for me it jumps back to Exercise 1.1 and the problems are locked again. This does not seem like the intuitive/expected behaviour.")

#emph[#text("[Unlock is now persistent – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c44df296f4245adf3d3caeb19f2749a1d210cafa2769aff6f0ec6bd2d21c4341-3c12c69ecb80d93a22eea9bf7410efc77094096e0a2354c6e071b51ead8d9bbe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex P")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699468")[#strong[#text("Alex P")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("To be honest, I don’t really follow the interface at a glance. Maybe I’m missing something obvious. I think it needs to hold my hand a bit more.")

#text("I also find the fantasy mode distracting and would prefer it was not the default.")

#text("I would say the audience for this is not people who completely new to logic or programs such as these, but someone more advanced.")

#text("There needs to be a lot more hand holding for someone coming from a less familiar background such as mine.")

#text("ex: Starting with very first principles, interactively, and introducing components of the UI/UX and their effects one step at a time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699472")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 6.13 (or_and_left_rev)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 15 moves. The shortest proof the game knows takes 18. THIS ONE IS SHORTER.")

#text("— We are given (A ∨ B) ∧ (A ∨ C).")#linebreak()#text("— We wish to prove A ∨ (B ∧ C).")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ B (conjunction elimination (left)).")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ C (conjunction elimination (right)).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∧ C we deduce A ∨ (B ∧ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∧ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— Introduce C:")#linebreak()#text("— From B, C we deduce B ∧ C (conjunction introduction).")#linebreak()#text("— From B ∧ C, A we deduce A ∨ (B ∧ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∧ C)).")#linebreak()#text("— From A → (A ∨ (B ∧ C)), C → (A ∨ (B ∧ C)) we deduce (A ∨ C) → (A ∨ (B ∧ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ C) → (A ∨ (B ∧ C)), A ∨ C we deduce A ∨ (B ∧ C) (modus ponens).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∧ C)).")#linebreak()#text("— From A → (A ∨ (B ∧ C)), B → (A ∨ (B ∧ C)) we deduce (A ∨ B) → (A ∨ (B ∧ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∧ C)), A ∨ B we deduce A ∨ (B ∧ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem or_and_left_rev (hABC : (A ∨ B) ∧ (A ∨ C)) : A ∨ (B ∧ C) := by")#linebreak()#text("have hAB : A ∨ B := And.left hABC")#linebreak()#text("have hAC : A ∨ C := And.right hABC")#linebreak()#text("have hAABC : A → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.inl hA")#linebreak()#text("exact hABC2")#linebreak()#text("have hBABC : B → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("have hCABC : C → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hC")#linebreak()#text("have hBC : B ∧ C := And.intro hB hC")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hACABC : (A ∨ C) → (A ∨ (B ∧ C)) := fun h => Or.elim h hAABC hCABC")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := hACABC hAC")#linebreak()#text("exact hABC2")#linebreak()#text("have hABABC : (A ∨ B) → (A ∨ (B ∧ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := hABABC hAB")#linebreak()#text("exact hABC2")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699473")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 7.4 (Iff.refl’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We wish to prove A ↔ A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From A → A, A → A we deduce A ↔ A (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem Iff.refl’ : A ↔ A := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAA2 : A ↔ A := Iff.intro hAA hAA")#linebreak()#text("exact hAA2")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699474")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 7.6 (Or.congr_left’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 4 moves. The shortest proof the game knows takes 9. THIS ONE IS SHORTER.")

#text("— We are given A ∨ B, A ↔ C.")#linebreak()#text("— We wish to prove C ∨ B.")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A ↔ C, A we deduce C (iff elimination (forward)).")#linebreak()#text("— Discharging, we obtain A → C.")#linebreak()#text("— From A ∨ B, A → C we deduce C ∨ B (the lemma Or.imp_left’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 3 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem Or.congr_left’ (hAB : A ∨ B) (hAC : A ↔ C) : C ∨ B := by")#linebreak()#text("have hAC2 : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC.mp hA")#linebreak()#text("exact hC")#linebreak()#text("have hCB : C ∨ B := Or.imp_left’ hAB hAC2")#linebreak()#text("exact hCB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699475")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.8 (not_or_intro’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 9 moves. The shortest proof the game knows takes 11. THIS ONE IS SHORTER.")

#text("— We are given (¬ A) ∧ (¬ B).")#linebreak()#text("— We wish to prove ¬ (A ∨ B).")#linebreak()#text("— From (¬ A) ∧ (¬ B) we deduce ¬ A (conjunction elimination (left)).")#linebreak()#text("— From (¬ A) ∧ (¬ B) we deduce ¬ B (conjunction elimination (right)).")#linebreak()#text("— Introduce A ∨ B:")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, ¬ B, A we deduce A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain B → A.")#linebreak()#text("— From A ∨ B, B → A we deduce A ∨ A (the lemma Or.imp_right’).")#linebreak()#text("— From A ∨ A we deduce A (the lemma or_self_elim’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (A ∨ B).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_or_intro’ (hnAnB : (¬ A) ∧ (¬ B)) : ¬ (A ∨ B) := by")#linebreak()#text("have hA : ¬ A := And.left hnAnB")#linebreak()#text("have hB : ¬ B := And.right hnAnB")#linebreak()#text("have hAB : ¬ (A ∨ B) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hBA : B → A := by")#linebreak()#text("intro hB2")#linebreak()#text("have hA2 : A := absurd hB2 hB")#linebreak()#text("exact hA2")#linebreak()#text("have hAA : A ∨ A := Or.imp_right’ hAB hBA")#linebreak()#text("have hA2 : A := or_self_elim’ hAA")#linebreak()#text("exact absurd hA2 hA")#linebreak()#text("exact hAB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699476")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.9 (not_and_of_not_or’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 9 moves. The shortest proof the game knows takes 11. THIS ONE IS SHORTER.")

#text("— We are given (¬ A) ∨ (¬ B).")#linebreak()#text("— We wish to prove ¬ (A ∧ B).")#linebreak()#text("— Introduce A ∧ B:")#linebreak()#text("— From A ∧ B we deduce A (conjunction elimination (left)).")#linebreak()#text("— From A ∧ B we deduce B (conjunction elimination (right)).")#linebreak()#text("— Introduce ¬ B:")#linebreak()#text("— From B, ¬ B, ¬ A we deduce ¬ A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ B) → (¬ A).")#linebreak()#text("— From (¬ A) ∨ (¬ B), (¬ B) → (¬ A) we deduce (¬ A) ∨ (¬ A) (the lemma Or.imp_right’).")#linebreak()#text("— From (¬ A) ∨ (¬ A) we deduce ¬ A (the lemma or_self_elim’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (A ∧ B).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_and_of_not_or’ (hnAonB : (¬ A) ∨ (¬ B)) : ¬ (A ∧ B) := by")#linebreak()#text("have hAB : ¬ (A ∧ B) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB2")#linebreak()#text("have hA2 : ¬ A := absurd hB hB2")#linebreak()#text("exact hA2")#linebreak()#text("have hAA : (¬ A) ∨ (¬ A) := Or.imp_right’ hnAonB hBA")#linebreak()#text("have hA2 : ¬ A := or_self_elim’ hAA")#linebreak()#text("exact absurd hA hA2")#linebreak()#text("exact hAB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699477")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.13 (not_of_imp_not’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We are given A → (¬ B), B.")#linebreak()#text("— We wish to prove ¬ A.")#linebreak()#text("— From B we deduce ¬ (¬ B) (the lemma not_not_intro’).")#linebreak()#text("— From A → (¬ B), ¬ (¬ B) we deduce ¬ A (the lemma mt_apply’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 3 of them, each as you proved it, deepest first.")

#text("— 8.3 (not_not_intro’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_intro’ (hA : A) : ¬ (¬ A) := by")#linebreak()#text("have hA2 : ¬ (¬ A) := by")#linebreak()#text("intro hA2")#linebreak()#text("exact absurd hA hA2")#linebreak()#text("exact hA2")#linebreak()#text("end")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 8.11 (mt_apply’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt_apply’ (hAB : A → B) (hnB : ¬ B) : ¬ A := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := mt’ hAB")#linebreak()#text("have hA : ¬ A := hBA hnB")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_of_imp_not’ (hAnB : A → (¬ B)) (hB : B) : ¬ A := by")#linebreak()#text("have hB2 : ¬ (¬ B) := not_not_intro’ hB")#linebreak()#text("have hA : ¬ A := mt_apply’ hAnB hB2")#linebreak()#text("exact hA")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699478")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.15 (not_iff_imp_false)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 10 moves. The shortest proof the game knows takes 11. THIS ONE IS SHORTER.")

#text("— We wish to prove (¬ A) ↔ (A → False).")#linebreak()#text("— Introduce ¬ A, then A:")#linebreak()#text("— From A, ¬ A, False we deduce False (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ A) → (A → False).")#linebreak()#text("— Introduce A → False:")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A → False, A we deduce False (modus ponens).")#linebreak()#text("— This is a contradiction, so we conclude ¬ A.")#linebreak()#text("— Discharging, we obtain (A → False) → (¬ A).")#linebreak()#text("— From (¬ A) → (A → False), (A → False) → (¬ A) we deduce (¬ A) ↔ (A → False) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A : Prop}")

#text("theorem not_iff_imp_false : (¬ A) ↔ (A → False) := by")#linebreak()#text("have hAA : (¬ A) → (A → False) := by")#linebreak()#text("intro hA")#linebreak()#text("intro hA2")#linebreak()#text("have h : False := absurd hA2 hA")#linebreak()#text("exact h")#linebreak()#text("have hAA2 : (A → False) → (¬ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : ¬ A := by")#linebreak()#text("intro hA2")#linebreak()#text("have h : False := hA hA2")#linebreak()#text("exact h")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : (¬ A) ↔ (A → False) := Iff.intro hAA hAA2")#linebreak()#text("exact hAA3")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699479")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 9.2 (not_not_elim)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ¬ (¬ A).")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From ¬ A, ¬ (¬ A), A we deduce A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ A) → A.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), (¬ A) → A we deduce A ∨ A (the lemma Or.imp_right’).")#linebreak()#text("— From A ∨ A we deduce A (the lemma or_self_elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA2 : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA3 : A ∨ A := Or.imp_right’ hAA2 hAA")#linebreak()#text("have hA : A := or_self_elim’ hAA3")#linebreak()#text("exact hA")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699480")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 9.3 (by_cases’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We are given A → B, (¬ A) → B.")#linebreak()#text("— We wish to prove B.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), A → B, (¬ A) → B we deduce B (the lemma Or.elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem by_cases’ (hAB : A → B) (hnAB : (¬ A) → B) : B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hB : B := Or.elim’ hAA hAB hnAB")#linebreak()#text("exact hB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699493")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 9.6 (not_and_or’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 7 moves. The shortest proof the game knows takes 10. THIS ONE IS SHORTER.")

#text("— We are given ¬ (A ∧ B).")#linebreak()#text("— We wish to prove (¬ A) ∨ (¬ B).")#linebreak()#text("— Introduce B:")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B we deduce A ∧ B (conjunction introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ A.")#linebreak()#text("— Discharging, we obtain B → (¬ A).")#linebreak()#text("— From B we deduce B ∨ (¬ B) (the law of the excluded middle).")#linebreak()#text("— From B ∨ (¬ B), B → (¬ A) we deduce (¬ A) ∨ (¬ B) (the lemma Or.imp_left’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 3 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_and_or’ (hnAB : ¬ (A ∧ B)) : (¬ A) ∨ (¬ B) := by")#linebreak()#text("have hBA : B → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("exact absurd hAB hnAB")#linebreak()#text("exact hA")#linebreak()#text("have hBB : B ∨ (¬ B) := Classical.em (B)")#linebreak()#text("have hAB : (¬ A) ∨ (¬ B) := Or.imp_left’ hBB hBA")#linebreak()#text("exact hAB")

#text("— grimoire-replay v1 9.6 W1siYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5pbnRybyIsWyJoQSIsImhCIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbIm4iLCJoQUIiLCJobkFCIl0sWyJkIiwiaEEiLDFdLFsiYyIsIkNsYXNzaWNhbC5lbSIsW3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmltcF9sZWZ0JyIsWyJoQkIiLCJoQkEiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699494")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 9.10 (peirce_law’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given (A → B) → A.")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From (A → B) → A, ¬ A we deduce ¬ (A → B) (the lemma mt_apply’).")#linebreak()#text("— From ¬ A, B we deduce (¬ A) ∨ B (disjunction introduction (left)).")#linebreak()#text("— From (¬ A) ∨ B we deduce A → B (the lemma imp_of_not_or’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (¬ A).")#linebreak()#text("— From ¬ (¬ A) we deduce A (the lemma not_not_elim).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 9 of them, each as you proved it, deepest first.")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 8.11 (mt_apply’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt_apply’ (hAB : A → B) (hnB : ¬ B) : ¬ A := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := mt’ hAB")#linebreak()#text("have hA : ¬ A := hBA hnB")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 8.10 (imp_of_not_or’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem imp_of_not_or’ (hnAB : (¬ A) ∨ B) : A → B := by")#linebreak()#text("have hAB : A → B := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : (¬ A) → B := by")#linebreak()#text("intro hA2")#linebreak()#text("have hB : B := absurd hA hA2")#linebreak()#text("exact hB")#linebreak()#text("have hBB : B ∨ B := Or.imp_left’ hnAB hAB")#linebreak()#text("have hB : B := or_self_elim’ hBB")#linebreak()#text("exact hB")#linebreak()#text("exact hAB")#linebreak()#text("end")

#text("— 9.2 (not_not_elim)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA3 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem peirce_law’ (hPA : (A → B) → A) : A := by")#linebreak()#text("have hA : ¬ (¬ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : ¬ (A → B) := mt_apply’ hPA hA")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.inl hA")#linebreak()#text("have hAB3 : A → B := imp_of_not_or’ hAB2")#linebreak()#text("exact absurd hAB3 hAB")#linebreak()#text("have hA2 : A := not_not_elim hA")#linebreak()#text("exact hA2")

#text("— grimoire-replay v1 9.10 W1siYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJtdF9hcHBseSciLFsiaFBBIiwiaEEiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IklNUExJRVMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5sIixbImhBIix7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJpbXBfb2Zfbm90X29yJyIsWyJoQUIyIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJuIiwiaEFCMyIsImhBQiJdLFsiYyIsIm5vdF9ub3RfZWxpbSIsWyJoQSJdLHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699495")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 9.10 (peirce_law’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given (A → B) → A.")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From (A → B) → A, ¬ A we deduce ¬ (A → B) (the lemma mt_apply’).")#linebreak()#text("— From ¬ A, B we deduce (¬ A) ∨ B (disjunction introduction (left)).")#linebreak()#text("— From (¬ A) ∨ B we deduce A → B (the lemma imp_of_not_or’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (¬ A).")#linebreak()#text("— From ¬ (¬ A) we deduce A (the lemma not_not_elim).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 9 of them, each as you proved it, deepest first.")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 8.11 (mt_apply’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt_apply’ (hAB : A → B) (hnB : ¬ B) : ¬ A := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := mt’ hAB")#linebreak()#text("have hA : ¬ A := hBA hnB")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 8.10 (imp_of_not_or’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem imp_of_not_or’ (hnAB : (¬ A) ∨ B) : A → B := by")#linebreak()#text("have hAB : A → B := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : (¬ A) → B := by")#linebreak()#text("intro hA2")#linebreak()#text("have hB : B := absurd hA hA2")#linebreak()#text("exact hB")#linebreak()#text("have hBB : B ∨ B := Or.imp_left’ hnAB hAB")#linebreak()#text("have hB : B := or_self_elim’ hBB")#linebreak()#text("exact hB")#linebreak()#text("exact hAB")#linebreak()#text("end")

#text("— 9.2 (not_not_elim)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA3 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem peirce_law’ (hPA : (A → B) → A) : A := by")#linebreak()#text("have hA : ¬ (¬ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : ¬ (A → B) := mt_apply’ hPA hA")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.inl hA")#linebreak()#text("have hAB3 : A → B := imp_of_not_or’ hAB2")#linebreak()#text("exact absurd hAB3 hAB")#linebreak()#text("have hA2 : A := not_not_elim hA")#linebreak()#text("exact hA2")

#text("— grimoire-replay v1 9.10 W1siYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJtdF9hcHBseSciLFsiaFBBIiwiaEEiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IklNUExJRVMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5sIixbImhBIix7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJpbXBfb2Zfbm90X29yJyIsWyJoQUIyIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJuIiwiaEFCMyIsImhBQiJdLFsiYyIsIm5vdF9ub3RfZWxpbSIsWyJoQSJdLHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699496")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 10.5 (false_or’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 11 moves. The shortest proof the game knows takes 13. THIS ONE IS SHORTER.")

#text("— We wish to prove A ↔ (False ∨ A).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, False we deduce False ∨ A (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain A → (False ∨ A).")#linebreak()#text("— Introduce False ∨ A:")#linebreak()#text("— Introduce False:")#linebreak()#text("— From False, A we deduce A (from falsehood, anything (ex falso)).")#linebreak()#text("— Discharging, we obtain False → A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From False ∨ A, False → A, A → A we deduce A (the lemma Or.elim’).")#linebreak()#text("— Discharging, we obtain (False ∨ A) → A.")#linebreak()#text("— From A → (False ∨ A), (False ∨ A) → A we deduce A ↔ (False ∨ A) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem false_or’ : A ↔ (False ∨ A) := by")#linebreak()#text("have hAA : A → (False ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : False ∨ A := Or.inr hA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA2 : (False ∨ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : False → A := by")#linebreak()#text("intro h")#linebreak()#text("have hA2 : A := False.elim h")#linebreak()#text("exact hA2")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA3 : A := Or.elim’ hA hA2 hAA2")#linebreak()#text("exact hA3")#linebreak()#text("have hAA3 : A ↔ (False ∨ A) := Iff.intro hAA hAA2")#linebreak()#text("exact hAA3")

#text("— grimoire-replay v1 10.5 W1siYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmluciIsWyJoQSIseyJ0YWciOiJhcHAiLCJzeW0iOiJGQUxTRSIsImFyZ3MiOltdLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiRkFMU0UiLCJhcmdzIjpbXSwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiZCIsImhBMiIsMV0sWyJhIix7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiRkFMU0UiLCJhcmdzIjpbXSwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJGQUxTRSIsImFyZ3MiOltdLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJGYWxzZS5lbGltIixbImgiLHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sWyJkIiwiaEEyIiwxXSxbImMiLCJJbXBsLmlkZW0iLFt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuZWxpbSciLFsiaEEiLCJoQTIiLCJoQUEyIl0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiZCIsImhBMyIsMV0sWyJjIiwiSWZmLmludHJvIixbImhBQSIsImhBQTIiXSx7InRhZyI6ImFwcCIsInN5bSI6IklGRiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiRkFMU0UiLCJhcmdzIjpbXSwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699497")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 11.4")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove (∀ X : Ω, (∀ Y : Ω, Q(X, Y))) → (∀ X : Ω, (∀ Y : Ω, Q(X, Y))).")#linebreak()#text("— From ∀ X : Ω, (∀ Y : Ω, Q(X, Y)) we deduce (∀ X : Ω, (∀ Y : Ω, Q(X, Y))) → (∀ X : Ω, (∀ Y : Ω, Q(X, Y))) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {Q : Ω → Ω → Prop}")

#text("example : (∀ X : Ω, (∀ Y : Ω, Q X Y)) → (∀ X : Ω, (∀ Y : Ω, Q X Y)) := by")#linebreak()#text("have hXYXY : (∀ X : Ω, (∀ Y : Ω, Q X Y)) → (∀ X : Ω, (∀ Y : Ω, Q X Y)) := Impl.idem")#linebreak()#text("exact hXYXY")

#text("— grimoire-replay v1 11.4 W1siYyIsIkltcGwuaWRlbSIsW3sidGFnIjoiYmluZGVyIiwicSI6ImZvcmFsbCIsInYiOnsibmFtZSI6IlgiLCJzb3J0IjoizqkifSwiYm9keSI6eyJ0YWciOiJiaW5kZXIiLCJxIjoiZm9yYWxsIiwidiI6eyJuYW1lIjoiWSIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IlEiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9LHsidGFnIjoidmFyIiwibmFtZSI6IlkiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6ImJpbmRlciIsInEiOiJmb3JhbGwiLCJ2Ijp7Im5hbWUiOiJYIiwic29ydCI6Is6pIn0sImJvZHkiOnsidGFnIjoiYmluZGVyIiwicSI6ImZvcmFsbCIsInYiOnsibmFtZSI6IlkiLCJzb3J0IjoizqkifSwiYm9keSI6eyJ0YWciOiJhcHAiLCJzeW0iOiJRIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifSx7InRhZyI6InZhciIsIm5hbWUiOiJZIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9LCJzb3J0IjoiUHJvcCJ9LCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYmluZGVyIiwicSI6ImZvcmFsbCIsInYiOnsibmFtZSI6IlgiLCJzb3J0IjoizqkifSwiYm9keSI6eyJ0YWciOiJiaW5kZXIiLCJxIjoiZm9yYWxsIiwidiI6eyJuYW1lIjoiWSIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IlEiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9LHsidGFnIjoidmFyIiwibmFtZSI6IlkiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]
