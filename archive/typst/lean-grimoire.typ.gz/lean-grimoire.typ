// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/11/lean-grimoire/
// Converted to Typst by tao2typ: "2026-11-25T17:28:40.779619+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lean Grimoire", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lean Grimoire")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-25 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Back in July, I ")#link("https://terrytao.wordpress.com/tag/applets/")[#text("started experimenting")]#text(" with using modern coding agents to build a number of mathematical visualization applets. With the extremely hectic events of the last few months, I had to set those projects aside; but I recently found a bit of time to work on one such project that I had started back then, which was to modernize a ")#link("https://teorth.github.io/QED/")[#text("Javascript interactive textbook I had made back in 2018")]#text(", entitled “QED”, and ")#link("https://terrytao.wordpress.com/2018/08/18/qed-version-2-0-an-interactive-text-in-first-order-logic/")[#text("announced previously on this blog")]#text(". The purpose of that textbook was to teach propositional and first-order logic in the form of a “crafting game”, where one applied various rules of logic to reach a desired conclusion from a given set of hypotheses.")

#text("With a coding agent, I ")#link("https://teorth.github.io/tao-web/apps/grimoire.html")[#text("rebuilt the game")]#text(" (which I have given the working title of “Lean Grimoire”) with a number of new features, for instance giving the option to show an in-progress Lean proof of one’s game state. Just for fun, I also added an option to play in a “fantasy mode” in which various game elements are depicted using fantasy-themed flavor text (for instance, mathematical statements become “potions”, mathematical expressions become “scrolls”, and so forth). Here is a typical screenshot, in which one has nearly completed the proof of the assertion ")#mi("A \\implies A \\wedge B")#text(" given ")#mi("A \\implies B")#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/11/image.png")[#image("../assets/bd433c29948de0dce562a92747f23674ed6033562b5d6a9bc1e8bd30aaf4e639-04c4fb70831fb4f411b60b7482e30b6e05c03c69c80f2adab32da7dc498a792f.png", width: 90%)]
]

#text("I would be interested in having some playtesting of this app to make it more useful as a means to teach logical proofs and/or Lean.")

#heading(level: 1)[#text("Comments (89)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699498")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 12.7 (forall_imp_comm’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 13 moves. The shortest proof the game knows takes 16. THIS ONE IS SHORTER.")

#text("— We wish to prove (A → (∀ X : Ω, P(X))) ↔ (∀ X : Ω, (A → P(X))).")#linebreak()#text("— Introduce ∀ X : Ω, (A → P(X)), then A, then an arbitrary X : Ω:")#linebreak()#text("— From ∀ X : Ω, (A → P(X)), X we deduce A → P(X) (universal instantiation (specialization)).")#linebreak()#text("— From A → P(X), A we deduce P(X) (modus ponens).")#linebreak()#text("— Discharging, we obtain (∀ X : Ω, (A → P(X))) → (A → (∀ X : Ω, P(X))).")#linebreak()#text("— Introduce A → (∀ X : Ω, P(X)), then an arbitrary X : Ω, then A:")#linebreak()#text("— From A → (∀ X : Ω, P(X)), A we deduce ∀ X : Ω, P(X) (modus ponens).")#linebreak()#text("— From ∀ X : Ω, P(X), X we deduce P(X) (universal instantiation (specialization)).")#linebreak()#text("— Discharging, we obtain (A → (∀ X : Ω, P(X))) → (∀ X : Ω, (A → P(X))).")#linebreak()#text("— From (A → (∀ X : Ω, P(X))) → (∀ X : Ω, (A → P(X))), (∀ X : Ω, (A → P(X))) → (A → (∀ X : Ω, P(X))) we deduce (A → (∀ X : Ω, P(X))) ↔ (∀ X : Ω, (A → P(X))) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {Ω}")#linebreak()#text("variable {A : Prop}")#linebreak()#text("variable {P : Ω → Prop}")

#text("theorem forall_imp_comm’ : (A → (∀ X : Ω, P X)) ↔ (∀ X : Ω, (A → P X)) := by")#linebreak()#text("have hAXAX : (∀ X : Ω, (A → P X)) → (A → (∀ X : Ω, P X)) := by")#linebreak()#text("intro hAX")#linebreak()#text("intro hA")#linebreak()#text("intro X")#linebreak()#text("have hAX2 : A → P X := hAX X")#linebreak()#text("have hX : P X := hAX2 hA")#linebreak()#text("exact hX")#linebreak()#text("have hAXAX2 : (A → (∀ X : Ω, P X)) → (∀ X : Ω, (A → P X)) := by")#linebreak()#text("intro hAX")#linebreak()#text("intro X")#linebreak()#text("intro hA")#linebreak()#text("have hX : ∀ X : Ω, P X := hAX hA")#linebreak()#text("have hX2 : P X := hX X")#linebreak()#text("exact hX2")#linebreak()#text("have hAXAX3 : (A → (∀ X : Ω, P X)) ↔ (∀ X : Ω, (A → P X)) := Iff.intro hAXAX2 hAXAX")#linebreak()#text("exact hAXAX3")

#text("— grimoire-replay v1 12.7 W1siYSIseyJ0YWciOiJiaW5kZXIiLCJxIjoiZm9yYWxsIiwidiI6eyJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IklNUExJRVMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LCJzb3J0IjoiUHJvcCJ9XSxbImEiLHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSxbInYiLCJYIiwizqkiXSxbImMiLCJ1bml2ZXJzYWxfaW5zdGFudGlhdGlvbiIsWyJoQVgiLHsidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwibW9kdXNfcG9uZW5zIixbImhBWDIiLCJoQSJdLHsidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImQiLCJoWCIsM10sWyJhIix7InRhZyI6ImFwcCIsInN5bSI6IklNUExJRVMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJiaW5kZXIiLCJxIjoiZm9yYWxsIiwidiI6eyJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsidiIsIlgiLCLOqSJdLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIm1vZHVzX3BvbmVucyIsWyJoQVgiLCJoQSJdLHsidGFnIjoiYmluZGVyIiwicSI6ImZvcmFsbCIsInYiOnsibmFtZSI6IlgiLCJzb3J0IjoizqkifSwiYm9keSI6eyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLFsiYyIsInVuaXZlcnNhbF9pbnN0YW50aWF0aW9uIixbImhYIix7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImQiLCJoWDIiLDNdLFsiYyIsIklmZi5pbnRybyIsWyJoQVhBWDIiLCJoQVhBWCJdLHsidGFnIjoiYXBwIiwic3ltIjoiSUZGIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6ImJpbmRlciIsInEiOiJmb3JhbGwiLCJ2Ijp7Im5hbWUiOiJYIiwic29ydCI6Is6pIn0sImJvZHkiOnsidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9LCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImJpbmRlciIsInEiOiJmb3JhbGwiLCJ2Ijp7Im5hbWUiOiJYIiwic29ydCI6Is6pIn0sImJvZHkiOnsidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699499")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 15.10")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 11 moves. The shortest proof the game knows takes 12. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → (¬ Q(X))), ∀ X : Ω, ((¬ Q(X)) → R(X)), ¬ (∃ X : Ω, (R(X) ∧ S(X))).")#linebreak()#text("— We wish to prove ∀ X : Ω, (P(X) → (¬ S(X))).")#linebreak()#text("— Introduce an arbitrary X : Ω, then P(X):")#linebreak()#text("— From ∀ X : Ω, (P(X) → (¬ Q(X))), X we deduce P(X) → (¬ Q(X)) (universal instantiation (specialization)).")#linebreak()#text("— From ∀ X : Ω, ((¬ Q(X)) → R(X)), X we deduce (¬ Q(X)) → R(X) (universal instantiation (specialization)).")#linebreak()#text("— From P(X) → (¬ Q(X)), (¬ Q(X)) → R(X) we deduce P(X) → R(X) (the lemma implies_trans).")#linebreak()#text("— From P(X) → R(X), P(X) we deduce R(X) (modus ponens).")#linebreak()#text("— Introduce S(X):")#linebreak()#text("— From R(X), S(X) we deduce R(X) ∧ S(X) (conjunction introduction).")#linebreak()#text("— From R(X) ∧ S(X), X we deduce ∃ x : Ω, (R(x) ∧ S(x)) (existential introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ S(X).")#linebreak()#text("— Discharging, we obtain ∀ X : Ω, (P(X) → (¬ S(X))).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")#linebreak()#text("variable {S : Ω → Prop}")

#text("example (hPnQ : ∀ X : Ω, (P X → (¬ Q X))) (hnQR : ∀ X : Ω, ((¬ Q X) → R X)) (hnrs : ¬ (∃ X : Ω, (R X ∧ S X))) : ∀ X : Ω, (P X → (¬ S X)) := by")#linebreak()#text("have hXX : ∀ X : Ω, (P X → (¬ S X)) := by")#linebreak()#text("intro X")#linebreak()#text("have hXX : P X → (¬ Q X) := hPnQ X")#linebreak()#text("have hXX2 : (¬ Q X) → R X := hnQR X")#linebreak()#text("have hXX3 : P X → R X := implies_trans hXX hXX2")#linebreak()#text("intro hX")#linebreak()#text("have hX2 : R X := hXX3 hX")#linebreak()#text("have hX3 : ¬ S X := by")#linebreak()#text("intro hX3")#linebreak()#text("have hXX4 : R X ∧ S X := And.intro hX2 hX3")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ S x) := ⟨X, hXX4⟩")#linebreak()#text("exact absurd hxx hnrs")#linebreak()#text("exact hX3")#linebreak()#text("exact hXX")

#text("— grimoire-replay v1 15.10 W1sidiIsIlgiLCLOqSJdLFsiYyIsInVuaXZlcnNhbF9pbnN0YW50aWF0aW9uIixbImhQblEiLHsidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUSIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsInVuaXZlcnNhbF9pbnN0YW50aWF0aW9uIixbImhuUVIiLHsidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUSIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlIiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsImltcGxpZXNfdHJhbnMiLFsiaFhYIiwiaFhYMiJdLHsidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlIiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIm1vZHVzX3BvbmVucyIsWyJoWFgzIiwiaFgiXSx7InRhZyI6ImFwcCIsInN5bSI6IlIiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sWyJhIix7InRhZyI6ImFwcCIsInN5bSI6IlMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiQW5kLmludHJvIixbImhYMiIsImhYMyJdLHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiUyIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJYIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiRXhpc3RzLmludHJvIixbImhYWDQiLHsidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifV0seyJ0YWciOiJiaW5kZXIiLCJxIjoiZXhpc3RzIiwidiI6eyJuYW1lIjoieCIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IlIiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoieCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoieCIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLFsibiIsImh4eCIsImhucnMiXSxbImQiLCJoWDMiLDJdXQ==")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699500")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 18.7 (Eq.congr_iff’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given α = β.")#linebreak()#text("— We wish to prove P(α) ↔ P(β).")#linebreak()#text("— Introduce P(α):")#linebreak()#text("— Discharging, we obtain P(α) → P(α).")#linebreak()#text("— From P(α) → P(α), α = β we deduce P(α) → P(β) (rewrite along an equation).")#linebreak()#text("— From P(α) → P(α), α = β we deduce P(β) → P(α) (rewrite along an equation).")#linebreak()#text("— From P(α) → P(β), P(β) → P(α) we deduce P(α) ↔ P(β) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")

#text("theorem Eq.congr_iff’ (α : Ω) (β : Ω) (hab : α = β) : P α ↔ P β := by")#linebreak()#text("have hαα : P α → P α := by")#linebreak()#text("intro hα")#linebreak()#text("exact hα")#linebreak()#text("have hαβ : P α → P β := Eq.subst (motive := fun x => P α → P x) hab hαα")#linebreak()#text("have hβα : P β → P α := Eq.subst (motive := fun x => P x → P α) hab hαα")#linebreak()#text("have hαβ2 : P α ↔ P β := Iff.intro hαβ hβα")#linebreak()#text("exact hαβ2")

#text("— grimoire-replay v1 18.7 W1siYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImQiLCJozrEiLDFdLFsiYyIsInJ3IixbImjOsc6xIiwiaGFiIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiUCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiLOsSIsInNvcnQiOiLOqSJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrIiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJydyIsWyJozrHOsSIsImhhYiJdLHsidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrIiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiSWZmLmludHJvIixbImjOsc6yIiwiaM6yzrEiXSx7InRhZyI6ImFwcCIsInN5bSI6IklGRiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IlAiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrEiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJQIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6Is6yIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV1d")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699506")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("Really enjoyed the game!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb877f83f1a046ce2e62a5bc1cb974918e1dd30b66b9b68f834be33de02caf1-b2fe0f4c9e754bfc0c459babc8c487c187448796456dc9557efcc3a2eae032f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petrov")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699510")[#strong[#text("petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("Sorry, formatting came out wrong on previous comment and forgot to mention the problem above was 8.9. Surprinsingly addicting game! Here’s an 8 move solution to 8.9:")

#text("variable {A B : Prop}")

#text("theorem not_and_of_not_or’ (hnAonB : (¬ A) ∨ (¬ B)) : ¬ (A ∧ B) := by")

#text("have hAB : ¬ (A ∧ B) := by")

#text("intro hAB")

#text("have hA : A := And.left hAB")

#text("have hB : B := And.right hAB")

#text("have hA2 : ¬ (¬ A) := not_not_intro’ hA")

#text("have hB2 : ¬ (¬ B) := not_not_intro’ hB")

#text("have hAB2 : (¬ (¬ A)) ∧ (¬ (¬ B)) := And.intro hA2 hB2")

#text("have hAB3 : ¬ ((¬ A) ∨ (¬ B)) := not_or_intro’ hAB2")

#text("exact absurd hnAonB hAB3")

#text("exact hAB")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699511")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("Chrome slows down to a crawl and sometimes crashes on 18.8 and successive exercises. The RAM usage is huge (greater than the usual big usage of Chrome), like 3.5GB. Trying to do any action takes ages.")

#emph[#text("[There was an unnecessary exponential time search in the code which has now been removed and which should hopefully fix the problem. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699513")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("— Lean Grimoire — exercise 6.13 (or_and_left_rev)– ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/--")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/–")]#text(" Proved in 13 moves. The shortest proof the game knows takes 15, found by qwq zty on 16 November 2026. THIS ONE IS SHORTER.—- We are given (A ∨ B) ∧ (A ∨ C).– We wish to prove A ∨ (B ∧ C).– From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ B (conjunction elimination (left)).– From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ C (conjunction elimination (right)).– Introduce A:– From A, B ∧ C we deduce A ∨ (B ∧ C) (disjunction introduction (left)).– Discharging, we obtain A → (A ∨ (B ∧ C)).– Introduce B:– Introduce C:– From B, C we deduce B ∧ C (conjunction introduction).– From B ∧ C, A we deduce A ∨ (B ∧ C) (disjunction introduction (right)).– Discharging, we obtain C → (A ∨ (B ∧ C)).– From A ∨ C, A → (A ∨ (B ∧ C)), C → (A ∨ (B ∧ C)) we deduce A ∨ (B ∧ C) (the lemma Or.elim’).– Discharging, we obtain B → (A ∨ (B ∧ C)).– From A ∨ B, A → (A ∨ (B ∧ C)), B → (A ∨ (B ∧ C)) we deduce A ∨ (B ∧ C) (the lemma Or.elim’).– This is what we wished to prove. ∎– Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with– it. 1 of them, each as you proved it, deepest first.– 6.4 (Or.elim’)sectionvariable {A B C : Prop}theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC have hC : C := hABC hAB exact hCend– and the proof itself:variable {A B C : Prop}theorem or_and_left_rev (hABC : (A ∨ B) ∧ (A ∨ C)) : A ∨ (B ∧ C) := by have hAB : A ∨ B := And.left hABC have hAC : A ∨ C := And.right hABC have hAABC : A → (A ∨ (B ∧ C)) := by intro hA have hABC2 : A ∨ (B ∧ C) := Or.inl hA exact hABC2 have hBABC : B → (A ∨ (B ∧ C)) := by intro hB have hCABC : C → (A ∨ (B ∧ C)) := by intro hC have hBC : B ∧ C := And.intro hB hC have hABC2 : A ∨ (B ∧ C) := Or.inr hBC exact hABC2 have hABC2 : A ∨ (B ∧ C) := Or.elim’ hAC hAABC hCABC exact hABC2 have hABC2 : A ∨ (B ∧ C) := Or.elim’ hAB hAABC hBABC exact hABC2– grimoire-replay v1 6.13 W1siYyIsIkFuZC5sZWZ0IixbImhBQkMiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiQW5kLnJpZ2h0IixbImhBQkMiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJhIix7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5sIixbImhBIix7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJkIiwiaEFCQzIiLDFdLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5pbnRybyIsWyJoQiIsImhDIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJPci5pbnIiLFsiaEJDIix7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImQiLCJoQUJDMiIsMV0sWyJjIiwiT3IuZWxpbSciLFsiaEFDIiwiaEFBQkMiLCJoQ0FCQyJdLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJkIiwiaEFCQzIiLDFdLFsiYyIsIk9yLmVsaW0nIixbImhBQiIsImhBQUJDIiwiaEJBQkMiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dXQ==")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d8743ae0fe0c9a25f7a64cc22f010e4d6e7284961c7cd41c6bef0c04b0afdd-99b1fdce4cbf1d63453450780711acdac96e460d2707765fc440a052f7f99a20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kantian")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699520")[#strong[#text("Kantian")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("A batch of shorter proofs I found (some may have already been found, I didn’t check). I stopped at exercice 18.8 because Firefox has crashed during the proof (maybe a time-space complexity problem with the aglorithm).")

#text("#5.9 (3 moves instead of 4)")

#raw("variable {A B C : Prop}\n\ntheorem And.imp_right' (hAB : A ∧ B) (hBC : B → C) : A ∧ C := by\n  have hBA : B ∧ A := And.comm' hAB\n  have hCA : C ∧ A := And.imp_left' hBA hBC\n  have hAC : A ∧ C := And.comm' hCA\n  exact hAC", block: true)

#text("#6.5 (9 moves instead of 10)")

#raw("variable {A B C D : Prop}\n\ntheorem Or.imp' (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by\n  have hACD : A → (C ∨ D) := by\n    intro hA\n    have hC : C := hAC hA\n    have hCD : C ∨ D := Or.inl hC\n    exact hCD\n  have hBCD : B → (C ∨ D) := by\n    intro hB\n    have hD : D := hBD hB\n    have hCD : C ∨ D := Or.inr hD\n    exact hCD\n  have hCD : C ∨ D := Or.elim' hAB hACD hBCD\n  exact hCD", block: true)

#text("#6.10 (13 instead of 14)")

#raw("variable {A B C : Prop}\n\ntheorem or_and_left' (hABC : A ∨ (B ∧ C)) : (A ∨ B) ∧ (A ∨ C) := by\n  have hAABAC : A → ((A ∨ B) ∧ (A ∨ C)) := by\n    intro hA\n    have hAB : A ∨ B := Or.inl hA\n    have hAC : A ∨ C := Or.inl hA\n    have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC\n    exact hABAC\n  have hBCABAC : (B ∧ C) → ((A ∨ B) ∧ (A ∨ C)) := by\n    intro hBC\n    have hB : B := And.left hBC\n    have hC : C := And.right hBC\n    have hAB : A ∨ B := Or.inr hB\n    have hAC : A ∨ C := Or.inr hC\n    have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC\n    exact hABAC\n  have hABAC : (A ∨ B) ∧ (A ∨ C) := Or.elim' hABC hAABAC hBCABAC\n  exact hABAC", block: true)

#text("#6.11 (11 moves instead of 12)")

#raw("variable {A B C : Prop}\n\ntheorem and_or_left' (hABC : A ∧ (B ∨ C)) : (A ∧ B) ∨ (A ∧ C) := by\n  have hA : A := And.left hABC\n  have hBABAC : B → ((A ∧ B) ∨ (A ∧ C)) := by\n    intro hB\n    have hAB : A ∧ B := And.intro hA hB\n    have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.inl hAB\n    exact hABAC\n  have hCABAC : C → ((A ∧ B) ∨ (A ∧ C)) := by\n    intro hC\n    have hAC : A ∧ C := And.intro hA hC\n    have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.inr hAC\n    exact hABAC\n  have hBC : B ∨ C := And.right hABC\n  have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.elim' hBC hBABAC hCABAC\n  exact hABAC", block: true)

#text("#6.12 (13 moves instead of 14)")

#raw("theorem and_or_left_rev (hABC : (A ∧ B) ∨ (A ∧ C)) : A ∧ (B ∨ C) := by\n  have hABABC : (A ∧ B) → (A ∧ (B ∨ C)) := by\n    intro hAB\n    have hA : A := And.left hAB\n    have hB : B := And.right hAB\n    have hBC : B ∨ C := Or.inl hB\n    have hABC2 : A ∧ (B ∨ C) := And.intro hA hBC\n    exact hABC2\n  have hACABC : (A ∧ C) → (A ∧ (B ∨ C)) := by\n    intro hAC\n    have hA : A := And.left hAC\n    have hC : C := And.right hAC\n    have hBC : B ∨ C := Or.inr hC\n    have hABC2 : A ∧ (B ∨ C) := And.intro hA hBC\n    exact hABC2\n  have hABC2 : A ∧ (B ∨ C) := Or.elim' hABC hABABC hACABC\n  exact hABC2", block: true)

#text("#6.13 (13 moves instead of 18)")

#raw("variable {A B C : Prop}\n\ntheorem or_and_left_rev (hABC : (A ∨ B) ∧ (A ∨ C)) : A ∨ (B ∧ C) := by\n  have hAB : A ∨ B := And.left hABC\n  have hAC : A ∨ C := And.right hABC\n  have hAABC : A → (A ∨ (B ∧ C)) := by\n    intro hA\n    have hABC2 : A ∨ (B ∧ C) := Or.inl hA\n    exact hABC2\n  have hBABC : B → (A ∨ (B ∧ C)) := by\n    intro hB\n    have hCABC : C → (A ∨ (B ∧ C)) := by\n      intro hC\n      have hBC : B ∧ C := And.intro hB hC\n      have hABC2 : A ∨ (B ∧ C) := Or.inr hBC\n      exact hABC2\n    have hABC2 : A ∨ (B ∧ C) := Or.elim' hAC hAABC hCABC\n    exact hABC2\n  have hABC2 : A ∨ (B ∧ C) := Or.elim' hAB hAABC hBABC\n  exact hABC2", block: true)

#text("#7.4 (2 moves instead of 3)")

#raw("variable {A : Prop}\n\ntheorem Iff.refl' : A ↔ A := by\n  have hAA : A → A := Impl.idem\n  have hAA2 : A ↔ A := Iff.intro hAA hAA\n  exact hAA2", block: true)

#text("#7.6 (8 moves instead of 9)")

#raw("variable {A B C : Prop}\n\ntheorem Or.congr_left' (hAB : A ∨ B) (hAC : A ↔ C) : C ∨ B := by\n  have hACB : A → (C ∨ B) := by\n    intro hA\n    have hC : C := hAC.mp hA\n    have hCB : C ∨ B := Or.inl hC\n    exact hCB\n  have hBCB : B → (C ∨ B) := by\n    intro hB\n    have hCB : C ∨ B := Or.inr hB\n    exact hCB\n  have hCB : C ∨ B := Or.elim' hAB hACB hBCB\n  exact hCB", block: true)

#text("#7.13 (6 moves instead of 7)")

#raw("variable {A : Prop}\n\ntheorem or_self_iff' : A ↔ (A ∨ A) := by\n  have hAAA : A → (A ∨ A) := by\n    intro hA\n    have hAA : A ∨ A := Or.idem hA\n    exact hAA\n  have hAA : A → A := Impl.idem\n  have hAAA2 : (A ∨ A) → A := fun h => Or.elim h hAA hAA\n  have hAAA3 : A ↔ (A ∨ A) := Iff.intro hAAA hAAA2\n  exact hAAA3", block: true)

#text("#8.8 (9 moves instead of 11)")

#raw("variable {A B : Prop}\n\ntheorem not_or_intro' (hnAnB : (¬ A) ∧ (¬ B)) : ¬ (A ∨ B) := by\n  have hA : ¬ A := And.left hnAnB\n  have hB : ¬ B := And.right hnAnB\n  have hAB : ¬ (A ∨ B) := by\n    intro hAB\n    have hAB2 : A → B := by\n      intro hA2\n      have hB2 : B := absurd hA2 hA\n      exact hB2\n    have hBB : B → B := Impl.idem\n    have hB2 : B := Or.elim' hAB hAB2 hBB\n    exact absurd hB2 hB\n  exact hAB", block: true)

#text("#8.9 (9 moves instead of 11)")

#raw("variable {A B : Prop}\n\ntheorem not_and_of_not_or' (hnAonB : (¬ A) ∨ (¬ B)) : ¬ (A ∧ B) := by\n  have hAB : ¬ (A ∧ B) := by\n    intro hAB\n    have hAB2 : (¬ A) → (¬ B) := by\n      intro hA\n      have hA2 : A := And.left hAB\n      have hB : ¬ B := absurd hA2 hA\n      exact hB\n    have hBB : (¬ B) → (¬ B) := Impl.idem\n    have hB : ¬ B := Or.elim' hnAonB hAB2 hBB\n    have hB2 : B := And.right hAB\n    exact absurd hB2 hB\n  exact hAB", block: true)

#text("#8.15 (10 moves instead of 11)")

#raw("variable {A : Prop}\n\ntheorem not_iff_imp_false : (¬ A) ↔ (A → False) := by\n  have hAA : (A → False) → (¬ A) := by\n    intro hA\n    have hA2 : ¬ A := by\n      intro hA2\n      have h : False := hA hA2\n      exact h\n    exact hA2\n  have hAA2 : (¬ A) → (A → False) := by\n    intro hA\n    intro hA2\n    have h : False := absurd hA2 hA\n    exact h\n  have hAA3 : (¬ A) ↔ (A → False) := Iff.intro hAA2 hAA\n  exact hAA3", block: true)

#text("#9.2 (6 moves instead of 8)")

#raw("variable {A : Prop}\n\ntheorem not_not_elim (hnnA : ¬ (¬ A)) : A := by\n  have hAA : A ∨ (¬ A) := Classical.em (A)\n  have hAA2 : A → A := Impl.idem\n  have hAA3 : (¬ A) → A := by\n    intro hA\n    have hA2 : A := absurd hA hnnA\n    exact hA2\n  have hA : A := Or.elim' hAA hAA2 hAA3\n  exact hA", block: true)

#text("#9.3 (2 moves instead of 3)")

#raw("variable {A B : Prop}\n\ntheorem by_cases' (hAB : A → B) (hnAB : (¬ A) → B) : B := by\n  have hAA : A ∨ (¬ A) := Classical.em (A)\n  have hB : B := Or.elim' hAA hAB hnAB\n  exact hB", block: true)

#text("#9.6 (8 moves instead of 10)")

#raw("variable {A B : Prop}\n\ntheorem not_and_or' (hnAB : ¬ (A ∧ B)) : (¬ A) ∨ (¬ B) := by\n  have hAA : A ∨ (¬ A) := Classical.em (A)\n  have hAB : A → (¬ B) := by\n    intro hA\n    have hB : ¬ B := by\n      intro hB\n      have hAB : A ∧ B := And.intro hA hB\n      exact absurd hAB hnAB\n    exact hB\n  have hAA2 : (¬ A) ∨ A := Or.comm' hAA\n  have hAB2 : (¬ A) ∨ (¬ B) := Or.imp_right' hAA2 hAB\n  exact hAB2", block: true)

#text("#10.5 (9 moves instead of 13)")

#raw("variable {A : Prop}\n\ntheorem false_or' : A ↔ (False ∨ A) := by\n  have hAA : A → (False ∨ A) := by\n    intro hA\n    have hA2 : False ∨ A := Or.inr hA\n    exact hA2\n  have hA : False → A := by\n    intro h\n    have hA : A := False.elim h\n    exact hA\n  have hAA2 : A → A := Impl.idem\n  have hAA3 : (False ∨ A) → A := fun h => Or.elim h hA hAA2\n  have hAA4 : A ↔ (False ∨ A) := Iff.intro hAA hAA3\n  exact hAA4", block: true)

#text("#11.4 (1 move instead of 2)")

#raw("variable {Ω}\nvariable {Q : Ω → Ω → Prop}\n\nexample : (∀ X : Ω, (∀ Y : Ω, Q X Y)) → (∀ X : Ω, (∀ Y : Ω, Q X Y)) := by\n  have hXYXY : (∀ X : Ω, (∀ Y : Ω, Q X Y)) → (∀ X : Ω, (∀ Y : Ω, Q X Y)) := Impl.idem\n  exact hXYXY", block: true)

#text("#12.3 (5 moves instead of 8)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {R : Ω → Prop}\nvariable {S : Ω → Prop}\n\nexample (hpr : ∀ X : Ω, (P X → R X)) (hsp : ∀ X : Ω, (S X → P X)) : ∀ X : Ω, (S X → R X) := by\n  have hXX : ∀ X : Ω, (S X → R X) := by\n    intro X\n    intro hX\n    have hX2 : P X := barbara X hsp hX\n    have hX3 : R X := barbara X hpr hX2\n    exact hX3\n  exact hXX", block: true)

#text("#12.7 (13 moves instead of 16)")

#raw("variable {Ω}\nvariable {A : Prop}\nvariable {P : Ω → Prop}\n\ntheorem forall_imp_comm' : (A → (∀ X : Ω, P X)) ↔ (∀ X : Ω, (A → P X)) := by\n  have hAXAX : (A → (∀ X : Ω, P X)) → (∀ X : Ω, (A → P X)) := by\n    intro hAX\n    intro X\n    intro hA\n    have hX : ∀ X : Ω, P X := hAX hA\n    have hX2 : P X := hX X\n    exact hX2\n  have hAXAX2 : (∀ X : Ω, (A → P X)) → (A → (∀ X : Ω, P X)) := by\n    intro hAX\n    intro hA\n    intro X\n    have hAX2 : A → P X := hAX X\n    have hX : P X := hAX2 hA\n    exact hX\n  have hAXAX3 : (A → (∀ X : Ω, P X)) ↔ (∀ X : Ω, (A → P X)) := Iff.intro hAXAX hAXAX2\n  exact hAXAX3", block: true)

#text("#15.5 (10 moves instead of 14)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\n\nexample : (¬ (∃ X : Ω, P X)) ↔ (∀ X : Ω, (¬ P X)) := by\n  have hxX : (¬ (∃ x : Ω, P x)) → (∀ X : Ω, (¬ P X)) := by\n    intro hx\n    intro X\n    have hX : ¬ P X := by\n      intro hX\n      have hx2 : ∃ x : Ω, P x := ⟨X, hX⟩\n      exact absurd hx2 hx\n    exact hX\n  have hxX2 : (∀ x : Ω, (¬ P x)) → (¬ (∃ X : Ω, P X)) := by\n    intro hx\n    have hX : ¬ (∃ X : Ω, P X) := forall_not_not_exists hx\n    exact hX\n  have hxX3 : (¬ (∃ x : Ω, P x)) ↔ (∀ X : Ω, (¬ P X)) := Iff.intro hxX hxX2\n  exact hxX3", block: true)

#text("#15.6 (6 moves instead of 9)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hnpq : ¬ (∃ X : Ω, (P X ∧ Q X))) (hRP : ∀ X : Ω, (R X → P X)) : ¬ (∃ X : Ω, (R X ∧ Q X)) := by\n  have hxx : ¬ (∃ x : Ω, (R x ∧ Q x)) := by\n    intro hxx\n    have hxx2 := hxx\n    obtain ⟨X, hXX⟩ := hxx2\n    have hXX2 : R X → P X := hRP X\n    have hXX3 : P X ∧ Q X := And.imp_left' hXX hXX2\n    have hxx2 : ∃ x : Ω, (P x ∧ Q x) := ⟨X, hXX3⟩\n    exact absurd hxx2 hnpq\n  exact hxx", block: true)

#text("#15.7 (4 moves instead of 7)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ P X)) : ∃ X : Ω, (R X ∧ Q X) := by\n  have hXX2 := hex\n  obtain ⟨X, hXX⟩ := hXX2\n  have hXX2 : P X → Q X := hPQ X\n  have hXX3 : R X ∧ Q X := And.imp_right' hXX hXX2\n  have hxx : ∃ x : Ω, (R x ∧ Q x) := ⟨X, hXX3⟩\n  exact hxx", block: true)

#text("#15.10 (9 moves instead of 12)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\nvariable {S : Ω → Prop}\n\nexample (hPnQ : ∀ X : Ω, (P X → (¬ Q X))) (hnQR : ∀ X : Ω, ((¬ Q X) → R X)) (hnrs : ¬ (∃ X : Ω, (R X ∧ S X))) : ∀ X : Ω, (P X → (¬ S X)) := by\n  have hXX : ∀ X : Ω, (P X → (¬ S X)) := by\n    intro X\n    intro hX\n    have hX2 : ¬ Q X := barbara X hPnQ hX\n    have hX3 : R X := barbara X hnQR hX2\n    have hX4 : ¬ S X := by\n      intro hX4\n      have hXX : R X ∧ S X := And.intro hX3 hX4\n      have hxx : ∃ x : Ω, (R x ∧ S x) := ⟨X, hXX⟩\n      exact absurd hxx hnrs\n    exact hX4\n  exact hXX", block: true)

#text("#15.15 (5 moves instead of 8)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ (¬ Q X))) : ∃ X : Ω, (R X ∧ (¬ P X)) := by\n  have hXX2 := hex\n  obtain ⟨X, hXX⟩ := hXX2\n  have hXX2 : P X → Q X := hPQ X\n  have hXX3 : (¬ Q X) → (¬ P X) := mt' hXX2\n  have hXX4 : R X ∧ (¬ P X) := And.imp_right' hXX hXX3\n  have hxx : ∃ x : Ω, (R x ∧ (¬ P x)) := ⟨X, hXX4⟩\n  exact hxx", block: true)

#text("#15.16 (4 moves instead of 7)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hex : ∃ X : Ω, (P X ∧ (¬ Q X))) (hPR : ∀ X : Ω, (P X → R X)) : ∃ X : Ω, (R X ∧ (¬ Q X)) := by\n  have hXX2 := hex\n  obtain ⟨X, hXX⟩ := hXX2\n  have hXX2 : P X → R X := hPR X\n  have hXX3 : R X ∧ (¬ Q X) := And.imp_left' hXX hXX2\n  have hxx : ∃ x : Ω, (R x ∧ (¬ Q x)) := ⟨X, hXX3⟩\n  exact hxx", block: true)

#text("#15.17 (8 moves instead of 9)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hnpq : ¬ (∃ X : Ω, (P X ∧ Q X))) (hRP : ∀ X : Ω, (R X → P X)) (hex : ∃ X : Ω, R X) : ∃ X : Ω, (R X ∧ (¬ Q X)) := by\n  have hX2 := hex\n  obtain ⟨X, hX⟩ := hX2\n  have hX2 : P X := barbara X hRP hX\n  have hX3 : ¬ Q X := by\n    intro hX3\n    have hXX : P X ∧ Q X := And.intro hX2 hX3\n    have hxx : ∃ x : Ω, (P x ∧ Q x) := ⟨X, hXX⟩\n    exact absurd hxx hnpq\n  have hXX : R X ∧ (¬ Q X) := And.intro hX hX3\n  have hxx : ∃ x : Ω, (R x ∧ (¬ Q x)) := ⟨X, hXX⟩\n  exact hxx", block: true)

#text("#15.18 (8 moves instead of 9)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hPQ : ∀ X : Ω, (P X → Q X)) (hnrq : ¬ (∃ X : Ω, (R X ∧ Q X))) (hex : ∃ X : Ω, R X) : ∃ X : Ω, (R X ∧ (¬ P X)) := by\n  have hX2 := hex\n  obtain ⟨X, hX⟩ := hX2\n  have hX2 : ¬ P X := by\n    intro hX2\n    have hX3 : Q X := barbara X hPQ hX2\n    have hXX : R X ∧ Q X := And.intro hX hX3\n    have hxx : ∃ x : Ω, (R x ∧ Q x) := ⟨X, hXX⟩\n    exact absurd hxx hnrq\n  have hXX : R X ∧ (¬ P X) := And.intro hX hX2\n  have hxx : ∃ x : Ω, (R x ∧ (¬ P x)) := ⟨X, hXX⟩\n  exact hxx", block: true)

#text("#15.19 (8 moves instead of 9)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hnpq : ¬ (∃ X : Ω, (P X ∧ Q X))) (hPR : ∀ X : Ω, (P X → R X)) (hex : ∃ X : Ω, P X) : ∃ X : Ω, (R X ∧ (¬ Q X)) := by\n  have hX2 := hex\n  obtain ⟨X, hX⟩ := hX2\n  have hX2 : R X := barbara X hPR hX\n  have hX3 : ¬ Q X := by\n    intro hX3\n    have hXX : P X ∧ Q X := And.intro hX hX3\n    have hxx : ∃ x : Ω, (P x ∧ Q x) := ⟨X, hXX⟩\n    exact absurd hxx hnpq\n  have hXX : R X ∧ (¬ Q X) := And.intro hX2 hX3\n  have hxx : ∃ x : Ω, (R x ∧ (¬ Q x)) := ⟨X, hXX⟩\n  exact hxx", block: true)

#text("#15.20 (5 moves instead of 7)")

#raw("variable {Ω}\nvariable {P : Ω → Prop}\nvariable {Q : Ω → Prop}\nvariable {R : Ω → Prop}\n\nexample (hPQ : ∀ X : Ω, (P X → Q X)) (hPR : ∀ X : Ω, (P X → R X)) (hex : ∃ X : Ω, P X) : ∃ X : Ω, (R X ∧ Q X) := by\n  have hX2 := hex\n  obtain ⟨X, hX⟩ := hX2\n  have hX2 : Q X := barbara X hPQ hX\n  have hX3 : R X := barbara X hPR hX\n  have hXX : R X ∧ Q X := And.intro hX3 hX2\n  have hxx : ∃ x : Ω, (R x ∧ Q x) := ⟨X, hXX⟩\n  exact hxx", block: true)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36a873420220b8f7587cbdb263783d10825545c4c39b3886ff52c44b8d27c39a-2d59e429fb1e34e7041f8e854197363cf7478294ddcc4a7b886431a225723798.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ericnbrown")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699526")[#strong[#text("ericnbrown")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("This was an 8 move proof of game 9.6 (not_and_or’). It can probably be altered slightly to make it 7 moves. Not sure though (I’ve never used lean before today.)")

#text("— Lean Grimoire — exercise 9.6 (not_and_or’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 8 moves. The shortest proof the game knows takes 10. THIS ONE IS SHORTER.")

#text("— We are given ¬ (A ∧ B).")#linebreak()#text("— We wish to prove (¬ A) ∨ (¬ B).")#linebreak()#text("— Introduce A:")#linebreak()#text("— Introduce B:")#linebreak()#text("— From A, B we deduce A ∧ B (conjunction introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ B.")#linebreak()#text("— Discharging, we obtain A → (¬ B).")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), A → (¬ B) we deduce (¬ B) ∨ (¬ A) (the lemma Or.imp_left’).")#linebreak()#text("— From (¬ B) ∨ (¬ A) we deduce (¬ A) ∨ (¬ B) (the lemma Or.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : (A ∨ B) → (B ∨ A) := by")#linebreak()#text("have hABA : A → (B ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → (B ∨ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_and_or’ (hnAB : ¬ (A ∧ B)) : (¬ A) ∨ (¬ B) := by")#linebreak()#text("have hAB : A → (¬ B) := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : ¬ B := by")#linebreak()#text("intro hB")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("exact absurd hAB hnAB")#linebreak()#text("exact hB")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hBA : (¬ B) ∨ (¬ A) := Or.imp_left’ hAA hAB")#linebreak()#text("have hAB2 : (¬ A) ∨ (¬ B) := Or.comm’ hBA")#linebreak()#text("exact hAB2")

#text("— grimoire-replay v1 9.6 W1siYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5pbnRybyIsWyJoQSIsImhCIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbIm4iLCJoQUIiLCJobkFCIl0sWyJkIiwiaEIiLDFdLFsiYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJhYiIsMV0sWyJjIiwiQ2xhc3NpY2FsLmVtIixbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW1wX2xlZnQnIixbImhBQSIsImhBQiJdLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmNvbW0nIixbImhCQSJdLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dXQ==")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36a873420220b8f7587cbdb263783d10825545c4c39b3886ff52c44b8d27c39a-2d59e429fb1e34e7041f8e854197363cf7478294ddcc4a7b886431a225723798.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ericnbrown")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699527")[#strong[#text("ericnbrown")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2026")])]

#text("Oops, sorry it looks like Leaving Leaves found this same solution yesterday. Sorry for the duplicate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699531")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2026")])]

#text("I have discovered a shorter proof of 18.10, which this blog post is too narrow to contain.")

#text("(Fermat slander aside, truly when I try to copy paste the solution here, it tells me that I cannot post a message that long)")

#emph[#text("[You can post the solution in an alternate format, and my coding agent should be able to reconstruct it. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2026")])]

#text("— Lean Grimoire — exercise 19.4 (inv_inv’)– ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/--")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/–")]#text(" Proved in 5 moves. The shortest proof the game knows takes 12. THIS ONE IS SHORTER.—- We wish to prove inv(inv(α)) = α.– From ∀ x : G, ((x · inv(x)) = 1), inv(α) we deduce (inv(α) · inv(inv(α))) = 1 (universal instantiation (specialization)).– From ∀ x : G, ((inv(x) · x) = 1), α we deduce (inv(α) · α) = 1 (universal instantiation (specialization)).– From inv(α) · α, 1, (inv(α) · α) = 1 we deduce 1 = (inv(α) · α) (the lemma Eq.symm’).– From (inv(α) · inv(inv(α))) = 1, 1 = (inv(α) · α) we deduce (inv(α) · inv(inv(α))) = (inv(α) · α) (rewrite along an equation).– From inv(α), inv(inv(α)), α, (inv(α) · inv(inv(α))) = (inv(α) · α) we deduce inv(inv(α)) = α (the lemma mul_left_cancel’).– This is what we wished to prove. ∎– Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with– it. 2 of them, each as you proved it, deepest first.– 18.5 (Eq.symm’)sectionvariable {Ω}theorem Eq.symm’ (α : Ω) (β : Ω) (hab : α = β) : β = α := by have hαα : α = α := Eq.refl α have hβα : β = α := Eq.subst (motive := fun x => x = α) hab hαα exact hβαend– 19.3 (mul_left_cancel’)sectionvariable {G}variable (one : G)variable (mul : G → G → G)variable (inv : G → G)variable (one_mul : ∀ x : G, mul one x = x)variable (mul_one : ∀ x : G, mul x one = x)variable (mul_assoc : ∀ x : G, ∀ y : G, ∀ z : G, mul (mul x y) z = mul x (mul y z))variable (inv_mul : ∀ x : G, mul (inv x) x = one)variable (mul_inv : ∀ x : G, mul x (inv x) = one)include one mul inv one_mul mul_one mul_assoc inv_mul mul_inv intheorem mul_left_cancel’ (α : G) (β : G) (γ : G) (h : mul α β = mul α γ) : β = γ := by have hββ : mul one β = β := one_mul β have hαα : mul (inv α) α = one := inv_mul α have hγγ : mul one γ = γ := one_mul γ have hββ2 : β = mul one β := Eq.symm’ (mul one β) β hββ have hγγ2 : γ = mul one γ := Eq.symm’ (mul one γ) γ hγγ have hαα2 : one = mul (inv α) α := Eq.symm’ (mul (inv α) α) one hαα have hβααβ : β = mul (mul (inv α) α) β := Eq.subst (motive := fun x => β = mul x β) hαα2 hββ2 have hγααγ : γ = mul (mul (inv α) α) γ := Eq.subst (motive := fun x => γ = mul x γ) hαα2 hγγ2 have hαyzαyz : ∀ y : G, (∀ z : G, (mul (mul (inv α) y) z = mul (inv α) (mul y z))) := mul_assoc (inv α) have hααzααz : ∀ z : G, (mul (mul (inv α) α) z = mul (inv α) (mul α z)) := hαyzαyz α have hααβααβ : mul (mul (inv α) α) β = mul (inv α) (mul α β) := hααzααz β have hααγααγ : mul (mul (inv α) α) γ = mul (inv α) (mul α γ) := hααzααz γ have hβααβ2 : β = mul (inv α) (mul α β) := Eq.subst (motive := fun x => β = x) hααβααβ hβααβ have hγααγ2 : γ = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => γ = x) hααγααγ hγααγ have hβααγ : β = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => β = mul (inv α) x) h hβααβ2 have hααγγ : mul (inv α) (mul α γ) = γ := Eq.symm’ γ (mul (inv α) (mul α γ)) hγααγ2 have hβγ : β = γ := Eq.subst (motive := fun x => β = x) hααγγ hβααγ exact hβγend– and the proof itself:variable {G}variable (one : G)variable (mul : G → G → G)variable (inv : G → G)variable (one_mul : ∀ x : G, mul one x = x)variable (mul_one : ∀ x : G, mul x one = x)variable (mul_assoc : ∀ x : G, ∀ y : G, ∀ z : G, mul (mul x y) z = mul x (mul y z))variable (inv_mul : ∀ x : G, mul (inv x) x = one)variable (mul_inv : ∀ x : G, mul x (inv x) = one)include one mul inv one_mul mul_one mul_assoc inv_mul mul_inv intheorem inv_inv’ (α : G) : inv (inv α) = α := by have hαα : mul (inv α) (inv (inv α)) = one := mul_inv (inv α) have hαα2 : mul (inv α) α = one := inv_mul α have hαα3 : one = mul (inv α) α := Eq.symm’ (mul (inv α) α) one hαα2 have hαααα : mul (inv α) (inv (inv α)) = mul (inv α) α := Eq.subst (motive := fun x => mul (inv α) (inv (inv α)) = x) hαα3 hαα have hαα4 : inv (inv α) = α := mul_left_cancel’ one mul inv one_mul mul_one mul_assoc inv_mul mul_inv (inv α) (inv (inv α)) α hαααα exact hαα4– grimoire-replay v1 19.4 W1siYyIsInVuaXZlcnNhbF9pbnN0YW50aWF0aW9uIixbIm11bF9pbnYiLHsidGFnIjoiYXBwIiwic3ltIjoiaW52IiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6IkcifV0sInNvcnQiOiJHIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiRVEiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJtdWwiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJpbnYiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrEiLCJzb3J0IjoiRyJ9XSwic29ydCI6IkcifSx7InRhZyI6ImFwcCIsInN5bSI6ImludiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6ImludiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiLOsSIsInNvcnQiOiJHIn1dLCJzb3J0IjoiRyJ9XSwic29ydCI6IkcifV0sInNvcnQiOiJHIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJvbmUiLCJhcmdzIjpbXSwic29ydCI6IkcifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsInVuaXZlcnNhbF9pbnN0YW50aWF0aW9uIixbIm11bF9pbnYiLHsidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6IkcifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJFUSIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Im11bCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiLOsSIsInNvcnQiOiJHIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJpbnYiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrEiLCJzb3J0IjoiRyJ9XSwic29ydCI6IkcifV0sInNvcnQiOiJHIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJvbmUiLCJhcmdzIjpbXSwic29ydCI6IkcifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsInVuaXZlcnNhbF9pbnN0YW50aWF0aW9uIixbImludl9tdWwiLHsidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6IkcifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJFUSIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Im11bCIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6ImludiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiLOsSIsInNvcnQiOiJHIn1dLCJzb3J0IjoiRyJ9LHsidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6IkcifV0sInNvcnQiOiJHIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJvbmUiLCJhcmdzIjpbXSwic29ydCI6IkcifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIkVxLnN5bW0nIixbeyJ0YWciOiJhcHAiLCJzeW0iOiJtdWwiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJpbnYiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrEiLCJzb3J0IjoiRyJ9XSwic29ydCI6IkcifSx7InRhZyI6InZhciIsIm5hbWUiOiLOsSIsInNvcnQiOiJHIn1dLCJzb3J0IjoiRyJ9LHsidGFnIjoiYXBwIiwic3ltIjoib25lIiwiYXJncyI6W10sInNvcnQiOiJHIn0sImjOsc6xMiJdLHsidGFnIjoiYXBwIiwic3ltIjoiRVEiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJvbmUiLCJhcmdzIjpbXSwic29ydCI6IkcifSx7InRhZyI6ImFwcCIsInN5bSI6Im11bCIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6ImludiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiLOsSIsInNvcnQiOiJHIn1dLCJzb3J0IjoiRyJ9LHsidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6IkcifV0sInNvcnQiOiJHIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJydyIsWyJozrHOsSIsImjOsc6xMyJdLHsidGFnIjoiYXBwIiwic3ltIjoiRVEiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJtdWwiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJpbnYiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrEiLCJzb3J0IjoiRyJ9XSwic29ydCI6IkcifSx7InRhZyI6ImFwcCIsInN5bSI6ImludiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6ImludiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiLOsSIsInNvcnQiOiJHIn1dLCJzb3J0IjoiRyJ9XSwic29ydCI6IkcifV0sInNvcnQiOiJHIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJtdWwiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJpbnYiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrEiLCJzb3J0IjoiRyJ9XSwic29ydCI6IkcifSx7InRhZyI6InZhciIsIm5hbWUiOiLOsSIsInNvcnQiOiJHIn1dLCJzb3J0IjoiRyJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwibXVsX2xlZnRfY2FuY2VsJyIsW3sidGFnIjoiYXBwIiwic3ltIjoiaW52IiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6IkcifV0sInNvcnQiOiJHIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJpbnYiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJpbnYiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoizrEiLCJzb3J0IjoiRyJ9XSwic29ydCI6IkcifV0sInNvcnQiOiJHIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoizrEiLCJzb3J0IjoiRyJ9LCJozrHOsc6xzrEiXSx7InRhZyI6ImFwcCIsInN5bSI6IkVRIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiaW52IiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiaW52IiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6IkcifV0sInNvcnQiOiJHIn1dLCJzb3J0IjoiRyJ9LHsidGFnIjoidmFyIiwibmFtZSI6Is6xIiwic29ydCI6IkcifV0sInNvcnQiOiJQcm9wIn1dXQ==")

#emph[#text("[Solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699544")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("I have now reached 20.3, and I need to use 20.2 to go on, but I cannot find a way to call succ_add’ without re-proving it from scratch. In fact, i also needed 20.1 but I could not call it, so I crafted it again.")

#text("How do you call a result that starts with \\forall a … ?")

#emph[#text("[These should now be accessible – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699545")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("Moreover, in exercise 20.4 when one tries to create the gem “c”, it returns a “c : M” instead of a “c : Nat” so it is not possible to conclude the exercise")

#emph[#text("[Parser now modified to use the ambient sort. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d86f250503ee44fe4aaba137c5b99c115bb9e8261a4dbb68bb2555233400eca-f87f4d94c9b4b6f2722d41e10d42f636e9e37d6082cf564493cfbf05caac9ccf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Elstein")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699559")[#strong[#text("Daniel Elstein")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("This is a great resource – I would definitely consider using this if I ever get to teach natural deduction again. One suggestion: it might be better to have the informal version of the spellbook as the default rather than the Lean version, so that you can engage with the game before knowing the Lean syntax (but I would just tell a student to switch that setting, so not a big deal). Anyway, thank you!")

#text("I did find a few shorter proofs, but they’ve been noted upthread already.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699895")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("I’ve now set the default to be a hybrid spellbook in which the informal versions are provided as comments to the Lean version.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b54bf761d3a0ea44309610ace20ff24a58d05d620799e76e1eeb744d1a79ae-47e732c3efe5bdef016d81a5f8aec8a82619619a38e615d0a230fd9e74c3197b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jackchemla")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699565")[#strong[#text("jackchemla")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2026")])]

#text("— Lean Grimoire — exercise 5.9 (And.imp_right’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 4. THIS ONE IS SHORTER.")

#text("— We are given A ∧ B, B → C.")#linebreak()#text("— We wish to prove A ∧ C.")#linebreak()#text("— From A ∧ B we deduce B ∧ A (the lemma And.comm’).")#linebreak()#text("— From B ∧ A, B → C we deduce C ∧ A (the lemma And.imp_left’).")#linebreak()#text("— From C ∧ A we deduce A ∧ C (the lemma And.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 5.8 (And.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_left’ (hAB : A ∧ B) (hAC : A → C) : C ∧ B := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCB : C ∧ B := And.intro hC hB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem And.imp_right’ (hAB : A ∧ B) (hBC : B → C) : A ∧ C := by")#linebreak()#text("have hBA : B ∧ A := And.comm’ hAB")#linebreak()#text("have hCA : C ∧ A := And.imp_left’ hBA hBC")#linebreak()#text("have hAC : A ∧ C := And.comm’ hCA")#linebreak()#text("exact hAC")

#text("— grimoire-replay v1 5.9 W1siYyIsIkFuZC5jb21tJyIsWyJoQUIiXSx7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5pbXBfbGVmdCciLFsiaEJBIiwiaEJDIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJBbmQuY29tbSciLFsiaENBIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b54bf761d3a0ea44309610ace20ff24a58d05d620799e76e1eeb744d1a79ae-47e732c3efe5bdef016d81a5f8aec8a82619619a38e615d0a230fd9e74c3197b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Chemla")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699722")[#strong[#text("Jacques Chemla")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2026")])]

#text("— Lean Grimoire — exercise 5.7 (implies_and_self’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 4. THIS ONE IS SHORTER.")

#text("— We are given A → B.")#linebreak()#text("— We wish to prove A → (B ∧ A).")#linebreak()#text("— From A → B we deduce A → (A ∧ B) (the lemma implies_and_self).")#linebreak()#text("— From A, B we deduce (A ∧ B) → (B ∧ A) (the lemma And.symm’).")#linebreak()#text("— From A → (A ∧ B), (A ∧ B) → (B ∧ A) we deduce A → (B ∧ A) (the lemma implies_trans).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 4 of them, each as you proved it, deepest first.")

#text("— 5.6 (implies_and_self)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem implies_and_self (hAB : A → B) : A → (A ∧ B) := by")#linebreak()#text("have hAAB : A → (A ∧ B) := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hAB2 : A ∧ B := And.intro hA hB")#linebreak()#text("exact hAB2")#linebreak()#text("exact hAAB")#linebreak()#text("end")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 4.8 (And.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.symm’ : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("have hABBA : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hBA : B ∧ A := And.comm’ hAB")#linebreak()#text("exact hBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem implies_and_self’ (hAB : A → B) : A → (B ∧ A) := by")#linebreak()#text("have hAAB : A → (A ∧ B) := implies_and_self hAB")#linebreak()#text("have hABBA : (A ∧ B) → (B ∧ A) := And.symm’")#linebreak()#text("have hABA : A → (B ∧ A) := implies_trans hAAB hABBA")#linebreak()#text("exact hABA")

#text("— grimoire-replay v1 5.7 W1siYyIsImltcGxpZXNfYW5kX3NlbGYiLFsiaEFCIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5zeW1tJyIsW3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6ImFwcCIsInN5bSI6IklNUExJRVMiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsImltcGxpZXNfdHJhbnMiLFsiaEFBQiIsImhBQkJBIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dXQ==")

#emph[#text("[Solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b54bf761d3a0ea44309610ace20ff24a58d05d620799e76e1eeb744d1a79ae-47e732c3efe5bdef016d81a5f8aec8a82619619a38e615d0a230fd9e74c3197b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Chemla")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699857")[#strong[#text("Jacques Chemla")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("— Lean Grimoire — exercise 6.10 (or_and_left’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 13 moves. The shortest proof the game knows takes 14. THIS ONE IS SHORTER.")

#text("— We are given A ∨ (B ∧ C).")#linebreak()#text("— We wish to prove (A ∨ B) ∧ (A ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B we deduce A ∨ B (disjunction introduction (left)).")#linebreak()#text("— From A, C we deduce A ∨ C (disjunction introduction (left)).")#linebreak()#text("— From A ∨ B, A ∨ C we deduce (A ∨ B) ∧ (A ∨ C) (conjunction introduction).")#linebreak()#text("— Discharging, we obtain A → ((A ∨ B) ∧ (A ∨ C)).")#linebreak()#text("— Introduce B ∧ C:")#linebreak()#text("— From B ∧ C we deduce B (conjunction elimination (left)).")#linebreak()#text("— From B, A we deduce A ∨ B (disjunction introduction (right)).")#linebreak()#text("— From B ∧ C we deduce C (conjunction elimination (right)).")#linebreak()#text("— From C, A we deduce A ∨ C (disjunction introduction (right)).")#linebreak()#text("— From A ∨ B, A ∨ C we deduce (A ∨ B) ∧ (A ∨ C) (conjunction introduction).")#linebreak()#text("— Discharging, we obtain (B ∧ C) → ((A ∨ B) ∧ (A ∨ C)).")#linebreak()#text("— From A ∨ (B ∧ C), A → ((A ∨ B) ∧ (A ∨ C)), (B ∧ C) → ((A ∨ B) ∧ (A ∨ C)) we deduce (A ∨ B) ∧ (A ∨ C) (the lemma Or.elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem or_and_left’ (hABC : A ∨ (B ∧ C)) : (A ∨ B) ∧ (A ∨ C) := by")#linebreak()#text("have hAABAC : A → ((A ∨ B) ∧ (A ∨ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : A ∨ B := Or.inl hA")#linebreak()#text("have hAC : A ∨ C := Or.inl hA")#linebreak()#text("have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC")#linebreak()#text("exact hABAC")#linebreak()#text("have hBCABAC : (B ∧ C) → ((A ∨ B) ∧ (A ∨ C)) := by")#linebreak()#text("intro hBC")#linebreak()#text("have hB : B := And.left hBC")#linebreak()#text("have hAB : A ∨ B := Or.inr hB")#linebreak()#text("have hC : C := And.right hBC")#linebreak()#text("have hAC : A ∨ C := Or.inr hC")#linebreak()#text("have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC")#linebreak()#text("exact hABAC")#linebreak()#text("have hABAC : (A ∨ B) ∧ (A ∨ C) := Or.elim’ hABC hAABAC hBCABAC")#linebreak()#text("exact hABAC")

#text("— grimoire-replay v1 6.10 W1siYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmlubCIsWyJoQSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJPci5pbmwiLFsiaEEiLHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiQW5kLmludHJvIixbImhBQiIsImhBQyJdLHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJkIiwiaEFCQUMiLDFdLFsiYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJBbmQubGVmdCIsWyJoQkMiXSx7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5yIixbImhCIix7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5yaWdodCIsWyJoQkMiXSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5yIixbImhDIix7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5pbnRybyIsWyJoQUIiLCJoQUMiXSx7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiZCIsImhBQkFDIiwxXSxbImMiLCJPci5lbGltJyIsWyJoQUJDIiwiaEFBQkFDIiwiaEJDQUJBQyJdLHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV1d")

#emph[#text("[Proof added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b54bf761d3a0ea44309610ace20ff24a58d05d620799e76e1eeb744d1a79ae-47e732c3efe5bdef016d81a5f8aec8a82619619a38e615d0a230fd9e74c3197b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Chemla")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699861")[#strong[#text("Jacques Chemla")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("— Lean Grimoire — exercise 6.8 (Or.assoc_left)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 13 moves. The shortest proof the game knows takes 14, found by an anonymous reader on 12 November 2026, and independently by Kantian. THIS ONE IS SHORTER.")

#text("— We are given (A ∨ B) ∨ C.")#linebreak()#text("— We wish to prove A ∨ (B ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∨ C we deduce A ∨ (B ∨ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, C we deduce B ∨ C (disjunction introduction (left)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∨ C)).")#linebreak()#text("— From A → (A ∨ (B ∨ C)), B → (A ∨ (B ∨ C)) we deduce (A ∨ B) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From C, B we deduce B ∨ C (disjunction introduction (right)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∨ C)).")#linebreak()#text("— From (A ∨ B) ∨ C, (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce A ∨ (B ∨ C) (the lemma Or.elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by")#linebreak()#text("have hAABC : A → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inl hA")#linebreak()#text("exact hABC2")#linebreak()#text("have hBABC : B → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBC : B ∨ C := Or.inl hB")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text("have hCABC : C → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hC")#linebreak()#text("have hBC : B ∨ C := Or.inr hC")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.elim’ hABC hABABC hCABC")#linebreak()#text("exact hABC2")

#text("— grimoire-replay v1 6.8 W1siYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmlubCIsWyJoQSIseyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImQiLCJoQUJDMiIsMV0sWyJhIix7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5sIixbImhCIix7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmluciIsWyJoQkMiLHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJkIiwiaEFCQzIiLDFdLFsiYyIsImNhc2VfYW5hbHlzaXMiLFsiaEFBQkMiLCJoQkFCQyJdLHsidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmluciIsWyJoQyIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJPci5pbnIiLFsiaEJDIix7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiZCIsImhBQkMyIiwxXSxbImMiLCJPci5lbGltJyIsWyJoQUJDIiwiaEFCQUJDIiwiaENBQkMiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV1d")

#emph[#text("[Proof added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b54bf761d3a0ea44309610ace20ff24a58d05d620799e76e1eeb744d1a79ae-47e732c3efe5bdef016d81a5f8aec8a82619619a38e615d0a230fd9e74c3197b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Chemla")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699862")[#strong[#text("Jacques Chemla")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("— Lean Grimoire — exercise 6.5 (Or.imp’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 9 moves. The shortest proof the game knows takes 10. THIS ONE IS SHORTER.")

#text("— We are given A ∨ B, A → C, B → D.")#linebreak()#text("— We wish to prove C ∨ D.")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A → C, A we deduce C (modus ponens).")#linebreak()#text("— From C, D we deduce C ∨ D (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (C ∨ D).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B → D, B we deduce D (modus ponens).")#linebreak()#text("— From D, C we deduce C ∨ D (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (C ∨ D).")#linebreak()#text("— From A ∨ B, A → (C ∨ D), B → (C ∨ D) we deduce C ∨ D (the lemma Or.elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hCD : C ∨ D := Or.elim’ hAB hACD hBCD")#linebreak()#text("exact hCD")

#text("— grimoire-replay v1 6.5 W1siYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIm1vZHVzX3BvbmVucyIsWyJoQUMiLCJoQSJdLHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJPci5pbmwiLFsiaEMiLHsidGFnIjoidmFyIiwibmFtZSI6IkQiLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkQiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJkIiwiaENEIiwxXSxbImEiLHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJtb2R1c19wb25lbnMiLFsiaEJEIiwiaEIiXSx7InRhZyI6InZhciIsIm5hbWUiOiJEIiwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5yIixbImhEIix7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJEIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiZCIsImhDRCIsMV0sWyJjIiwiT3IuZWxpbSciLFsiaEFCIiwiaEFDRCIsImhCQ0QiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkQiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV1d")

#emph[#text("[Proof added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b54bf761d3a0ea44309610ace20ff24a58d05d620799e76e1eeb744d1a79ae-47e732c3efe5bdef016d81a5f8aec8a82619619a38e615d0a230fd9e74c3197b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Chemla")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699865")[#strong[#text("Jacques Chemla")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("— Lean Grimoire — exercise 6.11 (and_or_left’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 11 moves. The shortest proof the game knows takes 12. THIS ONE IS SHORTER.")

#text("— We are given A ∧ (B ∨ C).")#linebreak()#text("— We wish to prove (A ∧ B) ∨ (A ∧ C).")#linebreak()#text("— From A ∧ (B ∨ C) we deduce A (conjunction elimination (left)).")#linebreak()#text("— From A ∧ (B ∨ C) we deduce B ∨ C (conjunction elimination (right)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From A, B we deduce A ∧ B (conjunction introduction).")#linebreak()#text("— From A ∧ B, A ∧ C we deduce (A ∧ B) ∨ (A ∧ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain B → ((A ∧ B) ∨ (A ∧ C)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From A, C we deduce A ∧ C (conjunction introduction).")#linebreak()#text("— From A ∧ C, A ∧ B we deduce (A ∧ B) ∨ (A ∧ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → ((A ∧ B) ∨ (A ∧ C)).")#linebreak()#text("— From B ∨ C, B → ((A ∧ B) ∨ (A ∧ C)), C → ((A ∧ B) ∨ (A ∧ C)) we deduce (A ∧ B) ∨ (A ∧ C) (the lemma Or.elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem and_or_left’ (hABC : A ∧ (B ∨ C)) : (A ∧ B) ∨ (A ∧ C) := by")#linebreak()#text("have hA : A := And.left hABC")#linebreak()#text("have hBC : B ∨ C := And.right hABC")#linebreak()#text("have hBABAC : B → ((A ∧ B) ∨ (A ∧ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.inl hAB")#linebreak()#text("exact hABAC")#linebreak()#text("have hCABAC : C → ((A ∧ B) ∨ (A ∧ C)) := by")#linebreak()#text("intro hC")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.inr hAC")#linebreak()#text("exact hABAC")#linebreak()#text("have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.elim’ hBC hBABAC hCABAC")#linebreak()#text("exact hABAC")

#text("— grimoire-replay v1 6.11 W1siYyIsIkFuZC5sZWZ0IixbImhBQkMiXSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sWyJjIiwiQW5kLnJpZ2h0IixbImhBQkMiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJhIix7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0sWyJjIiwiQW5kLmludHJvIixbImhBIiwiaEIiXSx7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmlubCIsWyJoQUIiLHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJkIiwiaEFCQUMiLDFdLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5pbnRybyIsWyJoQSIsImhDIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQyIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJPci5pbnIiLFsiaEFDIix7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiT1IiLCJhcmdzIjpbeyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkMiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiZCIsImhBQkFDIiwxXSxbImMiLCJPci5lbGltJyIsWyJoQkMiLCJoQkFCQUMiLCJoQ0FCQUMiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiQU5EIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6IkFORCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJDIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Proof added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699896")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("— Lean Grimoire — exercise 6.10 (or_and_left’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 9 moves. The shortest proof the game knows takes 13, found by Kantian on 18 November 2026. THIS ONE IS SHORTER.")

#text("— We are given A ∨ B ∧ C.")#linebreak()#text("— We wish to prove (A ∨ B) ∧ (A ∨ C).")#linebreak()#text("— Introduce B ∧ C:")#linebreak()#text("— From B ∧ C we deduce B (conjunction elimination (left)).")#linebreak()#text("— Discharging, we obtain B ∧ C → B.")#linebreak()#text("— From A ∨ B ∧ C, B ∧ C → B we deduce A ∨ B (the lemma Or.imp_right’).")#linebreak()#text("— Introduce B ∧ C:")#linebreak()#text("— From B ∧ C we deduce C (conjunction elimination (right)).")#linebreak()#text("— Discharging, we obtain B ∧ C → C.")#linebreak()#text("— From A ∨ B ∧ C, B ∧ C → C we deduce A ∨ C (the lemma Or.imp_right’).")#linebreak()#text("— From A ∨ B, A ∨ C we deduce (A ∨ B) ∧ (A ∨ C) (conjunction introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 7 of them, each as you proved it, deepest first.")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : A ∨ B → B ∨ A := by")#linebreak()#text("have hABA : A → B ∨ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → B ∨ A := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : A ∨ B → B ∨ A := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : A ∨ B → B ∨ A := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hCCD : C → C ∨ D := by")#linebreak()#text("intro hC")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hACD : A → C ∨ D := implies_trans hAC hCCD")#linebreak()#text("have hDCD : D → C ∨ D := by")#linebreak()#text("intro hD")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → C ∨ D := implies_trans hBD hDCD")#linebreak()#text("have hABCD : A ∨ B → C ∨ D := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hBA : B ∨ A := Or.comm’ hAB")#linebreak()#text("have hCA : C ∨ A := Or.imp_left’ hBA hBC")#linebreak()#text("have hAC : A ∨ C := Or.comm’ hCA")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem or_and_left’ (hABC : A ∨ B ∧ C) : (A ∨ B) ∧ (A ∨ C) := by")#linebreak()#text("have hBCB : B ∧ C → B := by")#linebreak()#text("intro hBC")#linebreak()#text("have hB : B := And.left hBC")#linebreak()#text("exact hB")#linebreak()#text("have hAB : A ∨ B := Or.imp_right’ hABC hBCB")#linebreak()#text("have hBCC : B ∧ C → C := by")#linebreak()#text("intro hBC")#linebreak()#text("have hC : C := And.right hBC")#linebreak()#text("exact hC")#linebreak()#text("have hAC : A ∨ C := Or.imp_right’ hABC hBCC")#linebreak()#text("have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC")#linebreak()#text("exact hABAC")

#emph[#text("[Added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699897")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("— Lean Grimoire — exercise 6.11 (and_or_left’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 9 moves. The shortest proof the game knows takes 11, found by Kantian on 18 November 2026. THIS ONE IS SHORTER.")

#text("— We are given A ∧ (B ∨ C).")#linebreak()#text("— We wish to prove A ∧ B ∨ A ∧ C.")#linebreak()#text("— From A ∧ (B ∨ C) we deduce A (conjunction elimination (left)).")#linebreak()#text("— From A ∧ (B ∨ C) we deduce B ∨ C (conjunction elimination (right)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From A, B we deduce A ∧ B (conjunction introduction).")#linebreak()#text("— Discharging, we obtain B → A ∧ B.")#linebreak()#text("— Introduce C:")#linebreak()#text("— From A, C we deduce A ∧ C (conjunction introduction).")#linebreak()#text("— Discharging, we obtain C → A ∧ C.")#linebreak()#text("— From B ∨ C, B → A ∧ B, C → A ∧ C we deduce A ∧ B ∨ A ∧ C (the lemma Or.imp’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hCCD : C → C ∨ D := by")#linebreak()#text("intro hC")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hACD : A → C ∨ D := implies_trans hAC hCCD")#linebreak()#text("have hDCD : D → C ∨ D := by")#linebreak()#text("intro hD")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → C ∨ D := implies_trans hBD hDCD")#linebreak()#text("have hABCD : A ∨ B → C ∨ D := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem and_or_left’ (hABC : A ∧ (B ∨ C)) : A ∧ B ∨ A ∧ C := by")#linebreak()#text("have hA : A := And.left hABC")#linebreak()#text("have hBC : B ∨ C := And.right hABC")#linebreak()#text("have hBAB : B → A ∧ B := by")#linebreak()#text("intro hB")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("exact hAB")#linebreak()#text("have hCAC : C → A ∧ C := by")#linebreak()#text("intro hC")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("have hABAC : A ∧ B ∨ A ∧ C := Or.imp’ hBC hBAB hCAC")#linebreak()#text("exact hABAC")

#emph[#text("[Added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699898")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("— Lean Grimoire — exercise 9.2 (not_not_elim)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 6, found by qwq zty on 16 November 2026, and independently by Kantian. THIS ONE IS SHORTER.")

#text("— We are given ¬ ¬ A.")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— From A we deduce A ∨ ¬ A (the law of the excluded middle).")#linebreak()#text("— From A ∨ ¬ A we deduce ¬ A ∨ A (the lemma Or.comm’).")#linebreak()#text("— From ¬ ¬ A, A we deduce ¬ ¬ A ∨ A (disjunction introduction (left)).")#linebreak()#text("— From ¬ A ∨ A, ¬ ¬ A ∨ A we deduce A ∨ A (the lemma resolution’).")#linebreak()#text("— From A ∨ A we deduce A (the lemma or_self_elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 13 of them, each as you proved it, deepest first.")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : A ∨ B → B ∨ A := by")#linebreak()#text("have hABA : A → B ∨ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → B ∨ A := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : A ∨ B → B ∨ A := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : A ∨ B → B ∨ A := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hCCD : C → C ∨ D := by")#linebreak()#text("intro hC")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hACD : A → C ∨ D := implies_trans hAC hCCD")#linebreak()#text("have hDCD : D → C ∨ D := by")#linebreak()#text("intro hD")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → C ∨ D := implies_trans hBD hDCD")#linebreak()#text("have hABCD : A ∨ B → C ∨ D := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.11 (and_or_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem and_or_left’ (hABC : A ∧ (B ∨ C)) : A ∧ B ∨ A ∧ C := by")#linebreak()#text("have hA : A := And.left hABC")#linebreak()#text("have hBC : B ∨ C := And.right hABC")#linebreak()#text("have hBAB : B → A ∧ B := by")#linebreak()#text("intro hB")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("exact hAB")#linebreak()#text("have hCAC : C → A ∧ C := by")#linebreak()#text("intro hC")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("have hABAC : A ∧ B ∨ A ∧ C := Or.imp’ hBC hBAB hCAC")#linebreak()#text("exact hABAC")#linebreak()#text("end")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : A ∨ B → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hBA : B ∨ A := Or.comm’ hAB")#linebreak()#text("have hCA : C ∨ A := Or.imp_left’ hBA hBC")#linebreak()#text("have hAC : A ∨ C := Or.comm’ hCA")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.10 (or_and_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem or_and_left’ (hABC : A ∨ B ∧ C) : (A ∨ B) ∧ (A ∨ C) := by")#linebreak()#text("have hBCB : B ∧ C → B := by")#linebreak()#text("intro hBC")#linebreak()#text("have hB : B := And.left hBC")#linebreak()#text("exact hB")#linebreak()#text("have hAB : A ∨ B := Or.imp_right’ hABC hBCB")#linebreak()#text("have hBCC : B ∧ C → C := by")#linebreak()#text("intro hBC")#linebreak()#text("have hC : C := And.right hBC")#linebreak()#text("exact hC")#linebreak()#text("have hAC : A ∨ C := Or.imp_right’ hABC hBCC")#linebreak()#text("have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC")#linebreak()#text("exact hABAC")#linebreak()#text("end")

#text("— 8.14 (resolution’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem resolution’ (hAB : A ∨ B) (hnAC : ¬ A ∨ C) : C ∨ B := by")#linebreak()#text("have hABAC : (A ∨ B) ∧ (¬ A ∨ C) := And.intro hAB hnAC")#linebreak()#text("have hABAABC : (A ∨ B) ∧ ¬ A ∨ (A ∨ B) ∧ C := and_or_left’ hABAC")#linebreak()#text("have hABAB : (A ∨ B) ∧ ¬ A → B := by")#linebreak()#text("intro hABA")#linebreak()#text("have hA : ¬ A := And.right hABA")#linebreak()#text("have hAB2 : A → B := by")#linebreak()#text("intro hA2")#linebreak()#text("have hB : B := absurd hA2 hA")#linebreak()#text("exact hB")#linebreak()#text("have hBB : B ∨ B := Or.imp_left’ hAB hAB2")#linebreak()#text("have hB : B := or_self_elim’ hBB")#linebreak()#text("exact hB")#linebreak()#text("have hBABC : B ∨ (A ∨ B) ∧ C := Or.imp_left’ hABAABC hABAB")#linebreak()#text("have hABCCAB : (A ∨ B) ∧ C → C ∧ (A ∨ B) := by")#linebreak()#text("intro hABC")#linebreak()#text("have hCAB : C ∧ (A ∨ B) := And.comm’ hABC")#linebreak()#text("exact hCAB")#linebreak()#text("have hBCAB : B ∨ C ∧ (A ∨ B) := Or.imp_right’ hBABC hABCCAB")#linebreak()#text("have hBCBAB : (B ∨ C) ∧ (B ∨ A ∨ B) := or_and_left’ hBCAB")#linebreak()#text("have hBC : B ∨ C := And.left hBCBAB")#linebreak()#text("have hCB : C ∨ B := Or.comm’ hBC")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ ¬ A) : A := by")#linebreak()#text("have hAA : A ∨ ¬ A := Classical.em (A)")#linebreak()#text("have hAA2 : ¬ A ∨ A := Or.comm’ hAA")#linebreak()#text("have hAA3 : ¬ ¬ A ∨ A := Or.inl hnnA")#linebreak()#text("have hAA4 : A ∨ A := resolution’ hAA2 hAA3")#linebreak()#text("have hA : A := or_self_elim’ hAA4")#linebreak()#text("exact hA")

#emph[#text("[Added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-699955")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("— Lean Grimoire — 6.11 in 9 moves (the shortest it knows takes 11)– grimoire-replay v2 6.11 c And.left hABC = (v A Prop) ; c And.right hABC = (a OR (v B Prop) (v C Prop)) ; a (v B Prop) ; c And.intro hA hB = (a AND (v A Prop) (v B Prop)) ; d hAB 1 ; a (v C Prop) ; c And.intro hA hC = (a AND (v A Prop) (v C Prop)) ; d hAC 1 ; c Or.imp’ hBC hBAB hCAC = (a OR (a AND (v A Prop) (v B Prop)) (a AND (v A Prop) (v C Prop)))")

#emph[#text("[Added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-700049")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("Another batch of shorter proofs.")

#text("#6.8 (9 moves instead of 13)")

#raw("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by\n  -- Introduce B:\n  have hBBC : B → (B ∨ C) := by\n    intro hB\n    \n    -- From B, C we deduce B ∨ C  (disjunction introduction (left)).\n    have hBC : B ∨ C := Or.inl hB\n    -- Discharging, we obtain B → (B ∨ C).\n    exact hBC\n  -- From B → (B ∨ C), A we deduce (A ∨ B) → (A ∨ (B ∨ C))  (the lemma Or.mono_right').\n  have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := Or.mono_right' hBBC\n  -- Introduce C:\n  have hCABC : C → (A ∨ (B ∨ C)) := by\n    intro hC\n    -- From C, B we deduce B ∨ C  (disjunction introduction (right)).\n    have hBC : B ∨ C := Or.inr hC\n    -- From B ∨ C, A we deduce A ∨ (B ∨ C)  (disjunction introduction (right)).\n    have hABC2 : A ∨ (B ∨ C) := Or.inr hBC\n    -- Discharging, we obtain C → (A ∨ (B ∨ C)).\n    exact hABC2\n  -- From (A ∨ B) ∨ C, (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce A ∨ (B ∨ C)  (the lemma Or.elim').\n  have hABC2 : A ∨ (B ∨ C) := Or.elim' hABC hABABC hCABC\n  -- This is what we wished to prove.  ∎\n  exact hABC2", block: true)

#text("#8.9 (6 moves instead of 8)")

#raw("-- We are given (¬ A) ∨ (¬ B).\n-- We wish to prove ¬ (A ∧ B).\ntheorem not_and_of_not_or' (hnAonB : (¬ A) ∨ (¬ B)) : ¬ (A ∧ B) := by\n  -- From (¬ A) ∨ (¬ B) we deduce A → (¬ B)  (the lemma imp_of_not_or').\n  have hAB : A → (¬ B) := imp_of_not_or' hnAonB\n  -- Introduce A ∧ B:\n  have hAB2 : ¬ (A ∧ B) := by\n    intro hAB2\n    -- From A ∧ B, A → (¬ B) we deduce (¬ B) ∧ B  (the lemma And.imp_left').\n    have hBB : (¬ B) ∧ B := And.imp_left' hAB2 hAB\n    -- From (¬ B) ∧ B we deduce ¬ B  (conjunction elimination (left)).\n    have hB : ¬ B := And.left hBB\n    -- From (¬ B) ∧ B we deduce B  (conjunction elimination (right)).\n    have hB2 : B := And.right hBB\n    -- This is a contradiction, so we conclude ¬ (A ∧ B).\n    exact absurd hB2 hB\n  -- This is what we wished to prove.  ∎\n  exact hAB2", block: true)

#text("#18.7 (4 moves instead of 5)")

#raw("-- We are given α = β.\n-- We wish to prove P(α) ↔ P(β).\ntheorem Eq.congr_iff' (α : Ω) (β : Ω) (hab : α = β) : P α ↔ P β := by\n  -- From P(α) we deduce P(α) → P(α)  (the lemma Impl.idem).\n  have hαα : P α → P α := Impl.idem\n  -- From P(α) → P(α), α = β we deduce P(α) → P(β)  (rewrite along an equation).\n  have hαβ : P α → P β := Eq.subst (motive := fun x => P α → P x) hab hαα\n  -- From P(α) → P(α), α = β we deduce P(β) → P(α)  (rewrite along an equation).\n  have hβα : P β → P α := Eq.subst (motive := fun x => P x → P α) hab hαα\n  -- From P(α) → P(β), P(β) → P(α) we deduce P(α) ↔ P(β)  (iff introduction).\n  have hαβ2 : P α ↔ P β := Iff.intro hαβ hβα\n  -- This is what we wished to prove.  ∎\n  exact hαβ2", block: true)

#text("#18.8 (16 moves instead of 17)")

#raw("-- We wish to prove (a ∪ b) = (b ∪ a).\ninclude mem union inter mem_union mem_inter ext in\ntheorem union_comm' (a : Set) (b : Set) : union a b = union b a := by\n  -- Introduce an arbitrary x : Set:\n  have hxabxba : ∀ x : Set, (mem x (union a b) ↔ mem x (union b a)) := by\n    intro x\n    -- From x ∈ a, x ∈ b we deduce ((x ∈ a) ∨ (x ∈ b)) → ((x ∈ b) ∨ (x ∈ a))  (the lemma Or.symm').\n    have hxaxbxbxa : (mem x a ∨ mem x b) → (mem x b ∨ mem x a) := Or.symm'\n    -- From x ∈ b, x ∈ a we deduce ((x ∈ b) ∨ (x ∈ a)) → ((x ∈ a) ∨ (x ∈ b))  (the lemma Or.symm').\n    have hxbxaxaxb : (mem x b ∨ mem x a) → (mem x a ∨ mem x b) := Or.symm'\n    -- From ((x ∈ a) ∨ (x ∈ b)) → ((x ∈ b) ∨ (x ∈ a)), ((x ∈ b) ∨ (x ∈ a)) → ((x ∈ a) ∨ (x ∈ b)) we deduce ((x ∈ a) ∨ (x ∈ b)) ↔ ((x ∈ b) ∨ (x ∈ a))  (iff introduction).\n    have hxaxbxbxa2 : (mem x a ∨ mem x b) ↔ (mem x b ∨ mem x a) := Iff.intro hxaxbxbxa hxbxaxaxb\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b))) := mem_union x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b)) := hxabxaxb a\n    -- From ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))), b we deduce (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb3 : mem x (union a b) ↔ (mem x a ∨ mem x b) := hxabxaxb2 b\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), b we deduce ∀ b'1296 : Set, ((x ∈ (b ∪ b'1296)) ↔ ((x ∈ b) ∨ (x ∈ b'1296)))  (universal instantiation (specialization)).\n    have hxbb'1296xbxb'1296 : ∀ b'1296 : Set, (mem x (union b b'1296) ↔ (mem x b ∨ mem x b'1296)) := hxabxaxb b\n    -- From ∀ b'1296 : Set, ((x ∈ (b ∪ b'1296)) ↔ ((x ∈ b) ∨ (x ∈ b'1296))), a we deduce (x ∈ (b ∪ a)) ↔ ((x ∈ b) ∨ (x ∈ a))  (universal instantiation (specialization)).\n    have hxbaxbxa : mem x (union b a) ↔ (mem x b ∨ mem x a) := hxbb'1296xbxb'1296 a\n    -- From (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)), ((x ∈ a) ∨ (x ∈ b)) ↔ ((x ∈ b) ∨ (x ∈ a)) we deduce (x ∈ (a ∪ b)) ↔ ((x ∈ b) ∨ (x ∈ a))  (the lemma Iff.trans').\n    have hxabxbxa : mem x (union a b) ↔ (mem x b ∨ mem x a) := Iff.trans' hxabxaxb3 hxaxbxbxa2\n    -- From (x ∈ (b ∪ a)) ↔ ((x ∈ b) ∨ (x ∈ a)) we deduce ((x ∈ b) ∨ (x ∈ a)) ↔ (x ∈ (b ∪ a))  (the lemma Iff.symm').\n    have hxbxaxba : (mem x b ∨ mem x a) ↔ mem x (union b a) := Iff.symm' hxbaxbxa\n    -- From (x ∈ (a ∪ b)) ↔ ((x ∈ b) ∨ (x ∈ a)), ((x ∈ b) ∨ (x ∈ a)) ↔ (x ∈ (b ∪ a)) we deduce (x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a))  (the lemma Iff.trans').\n    have hxabxba : mem x (union a b) ↔ mem x (union b a) := Iff.trans' hxabxbxa hxbxaxba\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a))).\n    exact hxabxba\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), a ∪ b we deduce ∀ b'3091 : Set, ((∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ b'3091))) → ((a ∪ b) = b'3091))  (universal instantiation (specialization)).\n  have hxabxb'3091abb'3091 : ∀ b'3091 : Set, ((∀ x : Set, (mem x (union a b) ↔ mem x b'3091)) → (union a b = b'3091)) := ext (union a b)\n  -- From ∀ b'3091 : Set, ((∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ b'3091))) → ((a ∪ b) = b'3091)), b ∪ a we deduce (∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a)))) → ((a ∪ b) = (b ∪ a))  (universal instantiation (specialization)).\n  have hxabxbaabba : (∀ x : Set, (mem x (union a b) ↔ mem x (union b a))) → (union a b = union b a) := hxabxb'3091abb'3091 (union b a)\n  -- From (∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a)))) → ((a ∪ b) = (b ∪ a)), ∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a))) we deduce (a ∪ b) = (b ∪ a)  (modus ponens).\n  have habba : union a b = union b a := hxabxbaabba hxabxba\n  -- This is what we wished to prove.  ∎\n  exact habba", block: true)

#text("#18.9 (16 moves instead of 17)")

#raw("-- We wish to prove (a ∩ b) = (b ∩ a).\ninclude mem union inter mem_union mem_inter ext in\ntheorem inter_comm' (a : Set) (b : Set) : inter a b = inter b a := by\n  -- Introduce an arbitrary x : Set:\n  have hxabxba : ∀ x : Set, (mem x (inter a b) ↔ mem x (inter b a)) := by\n    intro x\n    -- From x ∈ a, x ∈ b we deduce ((x ∈ a) ∧ (x ∈ b)) → ((x ∈ b) ∧ (x ∈ a))  (the lemma And.symm').\n    have hxaxbxbxa : (mem x a ∧ mem x b) → (mem x b ∧ mem x a) := And.symm'\n    -- From x ∈ b, x ∈ a we deduce ((x ∈ b) ∧ (x ∈ a)) → ((x ∈ a) ∧ (x ∈ b))  (the lemma And.symm').\n    have hxbxaxaxb : (mem x b ∧ mem x a) → (mem x a ∧ mem x b) := And.symm'\n    -- From ((x ∈ a) ∧ (x ∈ b)) → ((x ∈ b) ∧ (x ∈ a)), ((x ∈ b) ∧ (x ∈ a)) → ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ↔ ((x ∈ b) ∧ (x ∈ a))  (iff introduction).\n    have hxaxbxbxa2 : (mem x a ∧ mem x b) ↔ (mem x b ∧ mem x a) := Iff.intro hxaxbxbxa hxbxaxaxb\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b))) := mem_inter x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b)) := hxabxaxb a\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b we deduce (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb3 : mem x (inter a b) ↔ (mem x a ∧ mem x b) := hxabxaxb2 b\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), b we deduce ∀ b'5463 : Set, ((x ∈ (b ∩ b'5463)) ↔ ((x ∈ b) ∧ (x ∈ b'5463)))  (universal instantiation (specialization)).\n    have hxbb'5463xbxb'5463 : ∀ b'5463 : Set, (mem x (inter b b'5463) ↔ (mem x b ∧ mem x b'5463)) := hxabxaxb b\n    -- From ∀ b'5463 : Set, ((x ∈ (b ∩ b'5463)) ↔ ((x ∈ b) ∧ (x ∈ b'5463))), a we deduce (x ∈ (b ∩ a)) ↔ ((x ∈ b) ∧ (x ∈ a))  (universal instantiation (specialization)).\n    have hxbaxbxa : mem x (inter b a) ↔ (mem x b ∧ mem x a) := hxbb'5463xbxb'5463 a\n    -- From (x ∈ (b ∩ a)) ↔ ((x ∈ b) ∧ (x ∈ a)) we deduce ((x ∈ b) ∧ (x ∈ a)) ↔ (x ∈ (b ∩ a))  (the lemma Iff.symm').\n    have hxbxaxba : (mem x b ∧ mem x a) ↔ mem x (inter b a) := Iff.symm' hxbaxbxa\n    -- From (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)), ((x ∈ a) ∧ (x ∈ b)) ↔ ((x ∈ b) ∧ (x ∈ a)) we deduce (x ∈ (a ∩ b)) ↔ ((x ∈ b) ∧ (x ∈ a))  (the lemma Iff.trans').\n    have hxabxbxa : mem x (inter a b) ↔ (mem x b ∧ mem x a) := Iff.trans' hxabxaxb3 hxaxbxbxa2\n    -- From (x ∈ (a ∩ b)) ↔ ((x ∈ b) ∧ (x ∈ a)), ((x ∈ b) ∧ (x ∈ a)) ↔ (x ∈ (b ∩ a)) we deduce (x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a))  (the lemma Iff.trans').\n    have hxabxba : mem x (inter a b) ↔ mem x (inter b a) := Iff.trans' hxabxbxa hxbxaxba\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a))).\n    exact hxabxba\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), a ∩ b we deduce ∀ b'6435 : Set, ((∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ b'6435))) → ((a ∩ b) = b'6435))  (universal instantiation (specialization)).\n  have hxabxb'6435abb'6435 : ∀ b'6435 : Set, ((∀ x : Set, (mem x (inter a b) ↔ mem x b'6435)) → (inter a b = b'6435)) := ext (inter a b)\n  -- From ∀ b'6435 : Set, ((∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ b'6435))) → ((a ∩ b) = b'6435)), b ∩ a we deduce (∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a)))) → ((a ∩ b) = (b ∩ a))  (universal instantiation (specialization)).\n  have hxabxbaabba : (∀ x : Set, (mem x (inter a b) ↔ mem x (inter b a))) → (inter a b = inter b a) := hxabxb'6435abb'6435 (inter b a)\n  -- From (∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a)))) → ((a ∩ b) = (b ∩ a)), ∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a))) we deduce (a ∩ b) = (b ∩ a)  (modus ponens).\n  have habba : inter a b = inter b a := hxabxbaabba hxabxba\n  -- This is what we wished to prove.  ∎\n  exact habba", block: true)

#text("#18.10 (35 moves instead of 48)")

#raw("-- We wish to prove (a ∩ (b ∪ c)) = ((a ∩ b) ∪ (a ∩ c)).\ninclude mem union inter mem_union mem_inter ext in\ntheorem inter_union_distrib' (a : Set) (b : Set) (c : Set) : inter a (union b c) = union (inter a b) (inter a c) := by\n  -- Introduce an arbitrary x : Set:\n  have hxabcxabac : ∀ x : Set, (mem x (inter a (union b c)) ↔ mem x (union (inter a b) (inter a c))) := by\n    intro x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b))) := mem_union x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ a : Set, (∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b))) := mem_inter x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb3 : ∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b)) := hxabxaxb2 a\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b ∪ c we deduce (x ∈ (a ∩ (b ∪ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∪ c)))  (universal instantiation (specialization)).\n    have hxabcxaxbc : mem x (inter a (union b c)) ↔ (mem x a ∧ mem x (union b c)) := hxabxaxb3 (union b c)\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b we deduce (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb4 : mem x (inter a b) ↔ (mem x a ∧ mem x b) := hxabxaxb3 b\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), c we deduce (x ∈ (a ∩ c)) ↔ ((x ∈ a) ∧ (x ∈ c))  (universal instantiation (specialization)).\n    have hxacxaxc : mem x (inter a c) ↔ (mem x a ∧ mem x c) := hxabxaxb3 c\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), b we deduce ∀ b'1 : Set, ((x ∈ (b ∪ b'1)) ↔ ((x ∈ b) ∨ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxbb'1xbxb'1 : ∀ b'1 : Set, (mem x (union b b'1) ↔ (mem x b ∨ mem x b'1)) := hxabxaxb b\n    -- From ∀ b'1 : Set, ((x ∈ (b ∪ b'1)) ↔ ((x ∈ b) ∨ (x ∈ b'1))), c we deduce (x ∈ (b ∪ c)) ↔ ((x ∈ b) ∨ (x ∈ c))  (universal instantiation (specialization)).\n    have hxbcxbxc : mem x (union b c) ↔ (mem x b ∨ mem x c) := hxbb'1xbxb'1 c\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), a ∩ b we deduce ∀ b'1 : Set, ((x ∈ ((a ∩ b) ∪ b'1)) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxabb'1xabxb'1 : ∀ b'1 : Set, (mem x (union (inter a b) b'1) ↔ (mem x (inter a b) ∨ mem x b'1)) := hxabxaxb (inter a b)\n    -- From ∀ b'1 : Set, ((x ∈ ((a ∩ b) ∪ b'1)) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ b'1))), a ∩ c we deduce (x ∈ ((a ∩ b) ∪ (a ∩ c))) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c)))  (universal instantiation (specialization)).\n    have hxabacxabxac : mem x (union (inter a b) (inter a c)) ↔ (mem x (inter a b) ∨ mem x (inter a c)) := hxabb'1xabxb'1 (inter a c)\n    -- Introduce x ∈ (a ∩ (b ∪ c)):\n    have hxabcxabac : mem x (inter a (union b c)) → mem x (union (inter a b) (inter a c)) := by\n      intro hxabc\n      -- From (x ∈ (a ∩ (b ∪ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∪ c))), x ∈ (a ∩ (b ∪ c)) we deduce (x ∈ a) ∧ (x ∈ (b ∪ c))  (iff elimination (forward)).\n      have hxaxbc : mem x a ∧ mem x (union b c) := hxabcxaxbc.mp hxabc\n      -- From (x ∈ a) ∧ (x ∈ (b ∪ c)), (x ∈ (b ∪ c)) ↔ ((x ∈ b) ∨ (x ∈ c)) we deduce (x ∈ a) ∧ ((x ∈ b) ∨ (x ∈ c))  (the lemma And.congr_right').\n      have hxaxbxc : mem x a ∧ (mem x b ∨ mem x c) := And.congr_right' hxaxbc hxbcxbxc\n      -- From (x ∈ a) ∧ ((x ∈ b) ∨ (x ∈ c)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∨ ((x ∈ a) ∧ (x ∈ c))  (the lemma and_or_left').\n      have hxaxbxaxc : (mem x a ∧ mem x b) ∨ (mem x a ∧ mem x c) := and_or_left' hxaxbxc\n      -- From (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ↔ (x ∈ (a ∩ b))  (the lemma Iff.symm').\n      have hxaxbxab : (mem x a ∧ mem x b) ↔ mem x (inter a b) := Iff.symm' hxabxaxb4\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∨ ((x ∈ a) ∧ (x ∈ c)), ((x ∈ a) ∧ (x ∈ b)) ↔ (x ∈ (a ∩ b)) we deduce (x ∈ (a ∩ b)) ∨ ((x ∈ a) ∧ (x ∈ c))  (the lemma Or.congr_left').\n      have hxabxaxc : mem x (inter a b) ∨ (mem x a ∧ mem x c) := Or.congr_left' hxaxbxaxc hxaxbxab\n      -- From (x ∈ (a ∩ c)) ↔ ((x ∈ a) ∧ (x ∈ c)) we deduce ((x ∈ a) ∧ (x ∈ c)) ↔ (x ∈ (a ∩ c))  (the lemma Iff.symm').\n      have hxaxcxac : (mem x a ∧ mem x c) ↔ mem x (inter a c) := Iff.symm' hxacxaxc\n      -- From (x ∈ (a ∩ b)) ∨ ((x ∈ a) ∧ (x ∈ c)), ((x ∈ a) ∧ (x ∈ c)) ↔ (x ∈ (a ∩ c)) we deduce (x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c))  (the lemma Or.congr_right').\n      have hxabxac : mem x (inter a b) ∨ mem x (inter a c) := Or.congr_right' hxabxaxc hxaxcxac\n      -- From (x ∈ ((a ∩ b) ∪ (a ∩ c))) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c))), (x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c)) we deduce x ∈ ((a ∩ b) ∪ (a ∩ c))  (iff elimination (backward)).\n      have hxabac : mem x (union (inter a b) (inter a c)) := hxabacxabxac.mpr hxabxac\n      -- Discharging, we obtain (x ∈ (a ∩ (b ∪ c))) → (x ∈ ((a ∩ b) ∪ (a ∩ c))).\n      exact hxabac\n    -- Introduce x ∈ ((a ∩ b) ∪ (a ∩ c)):\n    have hxabacxabc : mem x (union (inter a b) (inter a c)) → mem x (inter a (union b c)) := by\n      intro hxabac\n      -- From (x ∈ ((a ∩ b) ∪ (a ∩ c))) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c))), x ∈ ((a ∩ b) ∪ (a ∩ c)) we deduce (x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c))  (iff elimination (forward)).\n      have hxabxac : mem x (inter a b) ∨ mem x (inter a c) := hxabacxabxac.mp hxabac\n      -- From (x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c)), (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∨ (x ∈ (a ∩ c))  (the lemma Or.congr_left').\n      have hxaxbxac : (mem x a ∧ mem x b) ∨ mem x (inter a c) := Or.congr_left' hxabxac hxabxaxb4\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∨ (x ∈ (a ∩ c)), (x ∈ (a ∩ c)) ↔ ((x ∈ a) ∧ (x ∈ c)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∨ ((x ∈ a) ∧ (x ∈ c))  (the lemma Or.congr_right').\n      have hxaxbxaxc : (mem x a ∧ mem x b) ∨ (mem x a ∧ mem x c) := Or.congr_right' hxaxbxac hxacxaxc\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∨ ((x ∈ a) ∧ (x ∈ c)) we deduce (x ∈ a) ∧ ((x ∈ b) ∨ (x ∈ c))  (the lemma and_or_left_rev).\n      have hxaxbxc : mem x a ∧ (mem x b ∨ mem x c) := and_or_left_rev hxaxbxaxc\n      -- From (x ∈ (b ∪ c)) ↔ ((x ∈ b) ∨ (x ∈ c)) we deduce ((x ∈ b) ∨ (x ∈ c)) ↔ (x ∈ (b ∪ c))  (the lemma Iff.symm').\n      have hxbxcxbc : (mem x b ∨ mem x c) ↔ mem x (union b c) := Iff.symm' hxbcxbxc\n      -- From (x ∈ a) ∧ ((x ∈ b) ∨ (x ∈ c)), ((x ∈ b) ∨ (x ∈ c)) ↔ (x ∈ (b ∪ c)) we deduce (x ∈ a) ∧ (x ∈ (b ∪ c))  (the lemma And.congr_right').\n      have hxaxbc : mem x a ∧ mem x (union b c) := And.congr_right' hxaxbxc hxbxcxbc\n      -- From (x ∈ (a ∩ (b ∪ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∪ c))), (x ∈ a) ∧ (x ∈ (b ∪ c)) we deduce x ∈ (a ∩ (b ∪ c))  (iff elimination (backward)).\n      have hxabc : mem x (inter a (union b c)) := hxabcxaxbc.mpr hxaxbc\n      -- Discharging, we obtain (x ∈ ((a ∩ b) ∪ (a ∩ c))) → (x ∈ (a ∩ (b ∪ c))).\n      exact hxabc\n    -- From (x ∈ (a ∩ (b ∪ c))) → (x ∈ ((a ∩ b) ∪ (a ∩ c))), (x ∈ ((a ∩ b) ∪ (a ∩ c))) → (x ∈ (a ∩ (b ∪ c))) we deduce (x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c)))  (iff introduction).\n    have hxabcxabac2 : mem x (inter a (union b c)) ↔ mem x (union (inter a b) (inter a c)) := Iff.intro hxabcxabac hxabacxabc\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c)))).\n    exact hxabcxabac2\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), a ∩ (b ∪ c) we deduce ∀ b'1 : Set, ((∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ b'1))) → ((a ∩ (b ∪ c)) = b'1))  (universal instantiation (specialization)).\n  have hxabcxb'1abcb'1 : ∀ b'1 : Set, ((∀ x : Set, (mem x (inter a (union b c)) ↔ mem x b'1)) → (inter a (union b c) = b'1)) := ext (inter a (union b c))\n  -- From ∀ b'1 : Set, ((∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ b'1))) → ((a ∩ (b ∪ c)) = b'1)), (a ∩ b) ∪ (a ∩ c) we deduce (∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c))))) → ((a ∩ (b ∪ c)) = ((a ∩ b) ∪ (a ∩ c)))  (universal instantiation (specialization)).\n  have hxabcxabacabcabac : (∀ x : Set, (mem x (inter a (union b c)) ↔ mem x (union (inter a b) (inter a c)))) → (inter a (union b c) = union (inter a b) (inter a c)) := hxabcxb'1abcb'1 (union (inter a b) (inter a c))\n  -- From (∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c))))) → ((a ∩ (b ∪ c)) = ((a ∩ b) ∪ (a ∩ c))), ∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c)))) we deduce (a ∩ (b ∪ c)) = ((a ∩ b) ∪ (a ∩ c))  (modus ponens).\n  have habcabac : inter a (union b c) = union (inter a b) (inter a c) := hxabcxabacabcabac hxabcxabac\n  -- This is what we wished to prove.  ∎\n  exact habcabac", block: true)

#text("#18.12 (30 moves instead of 34)")

#raw("-- We wish to prove ((a ∩ b) ∩ c) = (a ∩ (b ∩ c)).\ninclude mem union inter mem_union mem_inter ext in\ntheorem inter_assoc' (a : Set) (b : Set) (c : Set) : inter (inter a b) c = inter a (inter b c) := by\n  -- Introduce an arbitrary x : Set:\n  have hxabcxabc : ∀ x : Set, (mem x (inter (inter a b) c) ↔ mem x (inter a (inter b c))) := by\n    intro x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b))) := mem_inter x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b)) := hxabxaxb a\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b we deduce (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb3 : mem x (inter a b) ↔ (mem x a ∧ mem x b) := hxabxaxb2 b\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b ∩ c we deduce (x ∈ (a ∩ (b ∩ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∩ c)))  (universal instantiation (specialization)).\n    have hxabcxaxbc : mem x (inter a (inter b c)) ↔ (mem x a ∧ mem x (inter b c)) := hxabxaxb2 (inter b c)\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a ∩ b we deduce ∀ b'1 : Set, ((x ∈ ((a ∩ b) ∩ b'1)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxabb'1xabxb'1 : ∀ b'1 : Set, (mem x (inter (inter a b) b'1) ↔ (mem x (inter a b) ∧ mem x b'1)) := hxabxaxb (inter a b)\n    -- From ∀ b'1 : Set, ((x ∈ ((a ∩ b) ∩ b'1)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ b'1))), c we deduce (x ∈ ((a ∩ b) ∩ c)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ c))  (universal instantiation (specialization)).\n    have hxabcxabxc : mem x (inter (inter a b) c) ↔ (mem x (inter a b) ∧ mem x c) := hxabb'1xabxb'1 c\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), b we deduce ∀ b'1 : Set, ((x ∈ (b ∩ b'1)) ↔ ((x ∈ b) ∧ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxbb'1xbxb'1 : ∀ b'1 : Set, (mem x (inter b b'1) ↔ (mem x b ∧ mem x b'1)) := hxabxaxb b\n    -- From ∀ b'1 : Set, ((x ∈ (b ∩ b'1)) ↔ ((x ∈ b) ∧ (x ∈ b'1))), c we deduce (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c))  (universal instantiation (specialization)).\n    have hxbcxbxc : mem x (inter b c) ↔ (mem x b ∧ mem x c) := hxbb'1xbxb'1 c\n    -- Introduce x ∈ ((a ∩ b) ∩ c):\n    have hxabcxabc : mem x (inter (inter a b) c) → mem x (inter a (inter b c)) := by\n      intro hxabc\n      -- From (x ∈ ((a ∩ b) ∩ c)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ c)), x ∈ ((a ∩ b) ∩ c) we deduce (x ∈ (a ∩ b)) ∧ (x ∈ c)  (iff elimination (forward)).\n      have hxabxc : mem x (inter a b) ∧ mem x c := hxabcxabxc.mp hxabc\n      -- From (x ∈ (a ∩ b)) ∧ (x ∈ c), (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∧ (x ∈ c)  (the lemma And.congr_left').\n      have hxaxbxc : (mem x a ∧ mem x b) ∧ mem x c := And.congr_left' hxabxc hxabxaxb3\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∧ (x ∈ c) we deduce (x ∈ a) ∧ ((x ∈ b) ∧ (x ∈ c))  (the lemma And.assoc_left).\n      have hxaxbxc2 : mem x a ∧ (mem x b ∧ mem x c) := And.assoc_left hxaxbxc\n      -- From (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c)) we deduce ((x ∈ b) ∧ (x ∈ c)) ↔ (x ∈ (b ∩ c))  (the lemma Iff.symm').\n      have hxbxcxbc : (mem x b ∧ mem x c) ↔ mem x (inter b c) := Iff.symm' hxbcxbxc\n      -- From (x ∈ a) ∧ ((x ∈ b) ∧ (x ∈ c)), ((x ∈ b) ∧ (x ∈ c)) ↔ (x ∈ (b ∩ c)) we deduce (x ∈ a) ∧ (x ∈ (b ∩ c))  (the lemma And.congr_right').\n      have hxaxbc : mem x a ∧ mem x (inter b c) := And.congr_right' hxaxbxc2 hxbxcxbc\n      -- From (x ∈ (a ∩ (b ∩ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∩ c))), (x ∈ a) ∧ (x ∈ (b ∩ c)) we deduce x ∈ (a ∩ (b ∩ c))  (iff elimination (backward)).\n      have hxabc2 : mem x (inter a (inter b c)) := hxabcxaxbc.mpr hxaxbc\n      -- Discharging, we obtain (x ∈ ((a ∩ b) ∩ c)) → (x ∈ (a ∩ (b ∩ c))).\n      exact hxabc2\n    -- Introduce x ∈ (a ∩ (b ∩ c)):\n    have hxabcxabc2 : mem x (inter a (inter b c)) → mem x (inter (inter a b) c) := by\n      intro hxabc\n      -- From (x ∈ (a ∩ (b ∩ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∩ c))), x ∈ (a ∩ (b ∩ c)) we deduce (x ∈ a) ∧ (x ∈ (b ∩ c))  (iff elimination (forward)).\n      have hxaxbc : mem x a ∧ mem x (inter b c) := hxabcxaxbc.mp hxabc\n      -- From (x ∈ a) ∧ (x ∈ (b ∩ c)), (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c)) we deduce (x ∈ a) ∧ ((x ∈ b) ∧ (x ∈ c))  (the lemma And.congr_right').\n      have hxaxbxc : mem x a ∧ (mem x b ∧ mem x c) := And.congr_right' hxaxbc hxbcxbxc\n      -- From (x ∈ a) ∧ ((x ∈ b) ∧ (x ∈ c)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∧ (x ∈ c)  (the lemma And.assoc_right).\n      have hxaxbxc2 : (mem x a ∧ mem x b) ∧ mem x c := And.assoc_right hxaxbxc\n      -- From (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ↔ (x ∈ (a ∩ b))  (the lemma Iff.symm').\n      have hxaxbxab : (mem x a ∧ mem x b) ↔ mem x (inter a b) := Iff.symm' hxabxaxb3\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∧ (x ∈ c), ((x ∈ a) ∧ (x ∈ b)) ↔ (x ∈ (a ∩ b)) we deduce (x ∈ (a ∩ b)) ∧ (x ∈ c)  (the lemma And.congr_left').\n      have hxabxc : mem x (inter a b) ∧ mem x c := And.congr_left' hxaxbxc2 hxaxbxab\n      -- From (x ∈ ((a ∩ b) ∩ c)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ c)), (x ∈ (a ∩ b)) ∧ (x ∈ c) we deduce x ∈ ((a ∩ b) ∩ c)  (iff elimination (backward)).\n      have hxabc2 : mem x (inter (inter a b) c) := hxabcxabxc.mpr hxabxc\n      -- Discharging, we obtain (x ∈ (a ∩ (b ∩ c))) → (x ∈ ((a ∩ b) ∩ c)).\n      exact hxabc2\n    -- From (x ∈ ((a ∩ b) ∩ c)) → (x ∈ (a ∩ (b ∩ c))), (x ∈ (a ∩ (b ∩ c))) → (x ∈ ((a ∩ b) ∩ c)) we deduce (x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c)))  (iff introduction).\n    have hxabcxabc3 : mem x (inter (inter a b) c) ↔ mem x (inter a (inter b c)) := Iff.intro hxabcxabc hxabcxabc2\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c)))).\n    exact hxabcxabc3\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), (a ∩ b) ∩ c we deduce ∀ b'1 : Set, ((∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ b'1))) → (((a ∩ b) ∩ c) = b'1))  (universal instantiation (specialization)).\n  have hxabcxb'1abcb'1 : ∀ b'1 : Set, ((∀ x : Set, (mem x (inter (inter a b) c) ↔ mem x b'1)) → (inter (inter a b) c = b'1)) := ext (inter (inter a b) c)\n  -- From ∀ b'1 : Set, ((∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ b'1))) → (((a ∩ b) ∩ c) = b'1)), a ∩ (b ∩ c) we deduce (∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c))))) → (((a ∩ b) ∩ c) = (a ∩ (b ∩ c)))  (universal instantiation (specialization)).\n  have hxabcxabcabcabc : (∀ x : Set, (mem x (inter (inter a b) c) ↔ mem x (inter a (inter b c)))) → (inter (inter a b) c = inter a (inter b c)) := hxabcxb'1abcb'1 (inter a (inter b c))\n  -- From (∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c))))) → (((a ∩ b) ∩ c) = (a ∩ (b ∩ c))), ∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c)))) we deduce ((a ∩ b) ∩ c) = (a ∩ (b ∩ c))  (modus ponens).\n  have habcabc : inter (inter a b) c = inter a (inter b c) := hxabcxabcabcabc hxabcxabc\n  -- This is what we wished to prove.  ∎\n  exact habcabc", block: true)

#text("#18.13 (35 moves instead of 40)")

#raw("-- We wish to prove (a ∪ (b ∩ c)) = ((a ∪ b) ∩ (a ∪ c)).\ninclude mem union inter mem_union mem_inter ext in\ntheorem union_inter_distrib' (a : Set) (b : Set) (c : Set) : union a (inter b c) = inter (union a b) (union a c) := by\n  -- Introduce an arbitrary x : Set:\n  have hxabcxabac : ∀ x : Set, (mem x (union a (inter b c)) ↔ mem x (inter (union a b) (union a c))) := by\n    intro x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b))) := mem_union x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ a : Set, (∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b))) := mem_inter x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb3 : ∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b)) := hxabxaxb a\n    -- From ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))), b we deduce (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb4 : mem x (union a b) ↔ (mem x a ∨ mem x b) := hxabxaxb3 b\n    -- From ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))), c we deduce (x ∈ (a ∪ c)) ↔ ((x ∈ a) ∨ (x ∈ c))  (universal instantiation (specialization)).\n    have hxacxaxc : mem x (union a c) ↔ (mem x a ∨ mem x c) := hxabxaxb3 c\n    -- From ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))), b ∩ c we deduce (x ∈ (a ∪ (b ∩ c))) ↔ ((x ∈ a) ∨ (x ∈ (b ∩ c)))  (universal instantiation (specialization)).\n    have hxabcxaxbc : mem x (union a (inter b c)) ↔ (mem x a ∨ mem x (inter b c)) := hxabxaxb3 (inter b c)\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), b we deduce ∀ b'1 : Set, ((x ∈ (b ∩ b'1)) ↔ ((x ∈ b) ∧ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxbb'1xbxb'1 : ∀ b'1 : Set, (mem x (inter b b'1) ↔ (mem x b ∧ mem x b'1)) := hxabxaxb2 b\n    -- From ∀ b'1 : Set, ((x ∈ (b ∩ b'1)) ↔ ((x ∈ b) ∧ (x ∈ b'1))), c we deduce (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c))  (universal instantiation (specialization)).\n    have hxbcxbxc : mem x (inter b c) ↔ (mem x b ∧ mem x c) := hxbb'1xbxb'1 c\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a ∪ b we deduce ∀ b'1 : Set, ((x ∈ ((a ∪ b) ∩ b'1)) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxabb'1xabxb'1 : ∀ b'1 : Set, (mem x (inter (union a b) b'1) ↔ (mem x (union a b) ∧ mem x b'1)) := hxabxaxb2 (union a b)\n    -- From ∀ b'1 : Set, ((x ∈ ((a ∪ b) ∩ b'1)) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ b'1))), a ∪ c we deduce (x ∈ ((a ∪ b) ∩ (a ∪ c))) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c)))  (universal instantiation (specialization)).\n    have hxabacxabxac : mem x (inter (union a b) (union a c)) ↔ (mem x (union a b) ∧ mem x (union a c)) := hxabb'1xabxb'1 (union a c)\n    -- Introduce x ∈ (a ∪ (b ∩ c)):\n    have hxabcxabac : mem x (union a (inter b c)) → mem x (inter (union a b) (union a c)) := by\n      intro hxabc\n      -- From (x ∈ (a ∪ (b ∩ c))) ↔ ((x ∈ a) ∨ (x ∈ (b ∩ c))), x ∈ (a ∪ (b ∩ c)) we deduce (x ∈ a) ∨ (x ∈ (b ∩ c))  (iff elimination (forward)).\n      have hxaxbc : mem x a ∨ mem x (inter b c) := hxabcxaxbc.mp hxabc\n      -- From (x ∈ a) ∨ (x ∈ (b ∩ c)), (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c)) we deduce (x ∈ a) ∨ ((x ∈ b) ∧ (x ∈ c))  (the lemma Or.congr_right').\n      have hxaxbxc : mem x a ∨ (mem x b ∧ mem x c) := Or.congr_right' hxaxbc hxbcxbxc\n      -- From (x ∈ a) ∨ ((x ∈ b) ∧ (x ∈ c)) we deduce ((x ∈ a) ∨ (x ∈ b)) ∧ ((x ∈ a) ∨ (x ∈ c))  (the lemma or_and_left').\n      have hxaxbxaxc : (mem x a ∨ mem x b) ∧ (mem x a ∨ mem x c) := or_and_left' hxaxbxc\n      -- From (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)) we deduce ((x ∈ a) ∨ (x ∈ b)) ↔ (x ∈ (a ∪ b))  (the lemma Iff.symm').\n      have hxaxbxab : (mem x a ∨ mem x b) ↔ mem x (union a b) := Iff.symm' hxabxaxb4\n      -- From ((x ∈ a) ∨ (x ∈ b)) ∧ ((x ∈ a) ∨ (x ∈ c)), ((x ∈ a) ∨ (x ∈ b)) ↔ (x ∈ (a ∪ b)) we deduce (x ∈ (a ∪ b)) ∧ ((x ∈ a) ∨ (x ∈ c))  (the lemma And.congr_left').\n      have hxabxaxc : mem x (union a b) ∧ (mem x a ∨ mem x c) := And.congr_left' hxaxbxaxc hxaxbxab\n      -- From (x ∈ (a ∪ c)) ↔ ((x ∈ a) ∨ (x ∈ c)) we deduce ((x ∈ a) ∨ (x ∈ c)) ↔ (x ∈ (a ∪ c))  (the lemma Iff.symm').\n      have hxaxcxac : (mem x a ∨ mem x c) ↔ mem x (union a c) := Iff.symm' hxacxaxc\n      -- From (x ∈ (a ∪ b)) ∧ ((x ∈ a) ∨ (x ∈ c)), ((x ∈ a) ∨ (x ∈ c)) ↔ (x ∈ (a ∪ c)) we deduce (x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c))  (the lemma And.congr_right').\n      have hxabxac : mem x (union a b) ∧ mem x (union a c) := And.congr_right' hxabxaxc hxaxcxac\n      -- From (x ∈ ((a ∪ b) ∩ (a ∪ c))) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c))), (x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c)) we deduce x ∈ ((a ∪ b) ∩ (a ∪ c))  (iff elimination (backward)).\n      have hxabac : mem x (inter (union a b) (union a c)) := hxabacxabxac.mpr hxabxac\n      -- Discharging, we obtain (x ∈ (a ∪ (b ∩ c))) → (x ∈ ((a ∪ b) ∩ (a ∪ c))).\n      exact hxabac\n    -- Introduce x ∈ ((a ∪ b) ∩ (a ∪ c)):\n    have hxabacxabc : mem x (inter (union a b) (union a c)) → mem x (union a (inter b c)) := by\n      intro hxabac\n      -- From (x ∈ ((a ∪ b) ∩ (a ∪ c))) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c))), x ∈ ((a ∪ b) ∩ (a ∪ c)) we deduce (x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c))  (iff elimination (forward)).\n      have hxabxac : mem x (union a b) ∧ mem x (union a c) := hxabacxabxac.mp hxabac\n      -- From (x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c)), (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)) we deduce ((x ∈ a) ∨ (x ∈ b)) ∧ (x ∈ (a ∪ c))  (the lemma And.congr_left').\n      have hxaxbxac : (mem x a ∨ mem x b) ∧ mem x (union a c) := And.congr_left' hxabxac hxabxaxb4\n      -- From ((x ∈ a) ∨ (x ∈ b)) ∧ (x ∈ (a ∪ c)), (x ∈ (a ∪ c)) ↔ ((x ∈ a) ∨ (x ∈ c)) we deduce ((x ∈ a) ∨ (x ∈ b)) ∧ ((x ∈ a) ∨ (x ∈ c))  (the lemma And.congr_right').\n      have hxaxbxaxc : (mem x a ∨ mem x b) ∧ (mem x a ∨ mem x c) := And.congr_right' hxaxbxac hxacxaxc\n      -- From ((x ∈ a) ∨ (x ∈ b)) ∧ ((x ∈ a) ∨ (x ∈ c)) we deduce (x ∈ a) ∨ ((x ∈ b) ∧ (x ∈ c))  (the lemma or_and_left_rev).\n      have hxaxbxc : mem x a ∨ (mem x b ∧ mem x c) := or_and_left_rev hxaxbxaxc\n      -- From (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c)) we deduce ((x ∈ b) ∧ (x ∈ c)) ↔ (x ∈ (b ∩ c))  (the lemma Iff.symm').\n      have hxbxcxbc : (mem x b ∧ mem x c) ↔ mem x (inter b c) := Iff.symm' hxbcxbxc\n      -- From (x ∈ a) ∨ ((x ∈ b) ∧ (x ∈ c)), ((x ∈ b) ∧ (x ∈ c)) ↔ (x ∈ (b ∩ c)) we deduce (x ∈ a) ∨ (x ∈ (b ∩ c))  (the lemma Or.congr_right').\n      have hxaxbc : mem x a ∨ mem x (inter b c) := Or.congr_right' hxaxbxc hxbxcxbc\n      -- From (x ∈ (a ∪ (b ∩ c))) ↔ ((x ∈ a) ∨ (x ∈ (b ∩ c))), (x ∈ a) ∨ (x ∈ (b ∩ c)) we deduce x ∈ (a ∪ (b ∩ c))  (iff elimination (backward)).\n      have hxabc : mem x (union a (inter b c)) := hxabcxaxbc.mpr hxaxbc\n      -- Discharging, we obtain (x ∈ ((a ∪ b) ∩ (a ∪ c))) → (x ∈ (a ∪ (b ∩ c))).\n      exact hxabc\n    -- From (x ∈ (a ∪ (b ∩ c))) → (x ∈ ((a ∪ b) ∩ (a ∪ c))), (x ∈ ((a ∪ b) ∩ (a ∪ c))) → (x ∈ (a ∪ (b ∩ c))) we deduce (x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c)))  (iff introduction).\n    have hxabcxabac2 : mem x (union a (inter b c)) ↔ mem x (inter (union a b) (union a c)) := Iff.intro hxabcxabac hxabacxabc\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c)))).\n    exact hxabcxabac2\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), a ∪ (b ∩ c) we deduce ∀ b'1 : Set, ((∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ b'1))) → ((a ∪ (b ∩ c)) = b'1))  (universal instantiation (specialization)).\n  have hxabcxb'1abcb'1 : ∀ b'1 : Set, ((∀ x : Set, (mem x (union a (inter b c)) ↔ mem x b'1)) → (union a (inter b c) = b'1)) := ext (union a (inter b c))\n  -- From ∀ b'1 : Set, ((∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ b'1))) → ((a ∪ (b ∩ c)) = b'1)), (a ∪ b) ∩ (a ∪ c) we deduce (∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c))))) → ((a ∪ (b ∩ c)) = ((a ∪ b) ∩ (a ∪ c)))  (universal instantiation (specialization)).\n  have hxabcxabacabcabac : (∀ x : Set, (mem x (union a (inter b c)) ↔ mem x (inter (union a b) (union a c)))) → (union a (inter b c) = inter (union a b) (union a c)) := hxabcxb'1abcb'1 (inter (union a b) (union a c))\n  -- From (∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c))))) → ((a ∪ (b ∩ c)) = ((a ∪ b) ∩ (a ∪ c))), ∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c)))) we deduce (a ∪ (b ∩ c)) = ((a ∪ b) ∩ (a ∪ c))  (modus ponens).\n  have habcabac : union a (inter b c) = inter (union a b) (union a c) := hxabcxabacabcabac hxabcxabac\n  -- This is what we wished to prove.  ∎\n  exact habcabac", block: true)

#text("#19.3 (13 moves instead of 18)")

#raw("-- We are given (α · β) = (α · γ).\n-- We wish to prove β = γ.\ninclude one mul inv one_mul mul_one mul_assoc inv_mul mul_inv in\ntheorem mul_left_cancel' (α : G) (β : G) (γ : G) (h : mul α β = mul α γ) : β = γ := by\n  -- From ∀ x : G, (∀ y : G, (∀ z : G, (((x · y) · z) = (x · (y · z))))), inv(α) we deduce ∀ y : G, (∀ z : G, (((inv(α) · y) · z) = (inv(α) · (y · z))))  (universal instantiation (specialization)).\n  have hαyzαyz : ∀ y : G, (∀ z : G, (mul (mul (inv α) y) z = mul (inv α) (mul y z))) := mul_assoc (inv α)\n  -- From ∀ y : G, (∀ z : G, (((inv(α) · y) · z) = (inv(α) · (y · z)))), α we deduce ∀ z : G, (((inv(α) · α) · z) = (inv(α) · (α · z)))  (universal instantiation (specialization)).\n  have hααzααz : ∀ z : G, (mul (mul (inv α) α) z = mul (inv α) (mul α z)) := hαyzαyz α\n  -- From ∀ z : G, (((inv(α) · α) · z) = (inv(α) · (α · z))), β we deduce ((inv(α) · α) · β) = (inv(α) · (α · β))  (universal instantiation (specialization)).\n  have hααβααβ : mul (mul (inv α) α) β = mul (inv α) (mul α β) := hααzααz β\n  -- From ((inv(α) · α) · β) = (inv(α) · (α · β)), (α · β) = (α · γ) we deduce ((inv(α) · α) · β) = (inv(α) · (α · γ))  (rewrite along an equation).\n  have hααβααγ : mul (mul (inv α) α) β = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => mul (mul (inv α) α) β = mul (inv α) x) h hααβααβ\n  -- From ∀ x : G, ((inv(x) · x) = 1), α we deduce (inv(α) · α) = 1  (universal instantiation (specialization)).\n  have hαα : mul (inv α) α = one := inv_mul α\n  -- From ((inv(α) · α) · β) = (inv(α) · (α · γ)), (inv(α) · α) = 1 we deduce (1 · β) = (inv(α) · (α · γ))  (rewrite along an equation).\n  have hβααγ : mul one β = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => mul x β = mul (inv α) (mul α γ)) hαα hααβααγ\n  -- From ∀ z : G, (((inv(α) · α) · z) = (inv(α) · (α · z))), γ we deduce ((inv(α) · α) · γ) = (inv(α) · (α · γ))  (universal instantiation (specialization)).\n  have hααγααγ : mul (mul (inv α) α) γ = mul (inv α) (mul α γ) := hααzααz γ\n  -- From ((inv(α) · α) · γ) = (inv(α) · (α · γ)), (inv(α) · α) = 1 we deduce (1 · γ) = (inv(α) · (α · γ))  (rewrite along an equation).\n  have hγααγ : mul one γ = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => mul x γ = mul (inv α) (mul α γ)) hαα hααγααγ\n  -- From ∀ x : G, ((1 · x) = x), γ we deduce (1 · γ) = γ  (universal instantiation (specialization)).\n  have hγγ : mul one γ = γ := one_mul γ\n  -- From (1 · γ) = γ, (1 · γ) = (inv(α) · (α · γ)) we deduce (inv(α) · (α · γ)) = γ  (rewrite along an equation).\n  have hααγγ : mul (inv α) (mul α γ) = γ := Eq.subst (motive := fun x => x = γ) hγααγ hγγ\n  -- From ∀ x : G, ((1 · x) = x), β we deduce (1 · β) = β  (universal instantiation (specialization)).\n  have hββ : mul one β = β := one_mul β\n  -- From (1 · β) = (inv(α) · (α · γ)), (1 · β) = β we deduce β = (inv(α) · (α · γ))  (rewrite along an equation).\n  have hβααγ2 : β = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => x = mul (inv α) (mul α γ)) hββ hβααγ\n  -- From β = (inv(α) · (α · γ)), (inv(α) · (α · γ)) = γ we deduce β = γ  (rewrite along an equation).\n  have hβγ : β = γ := Eq.subst (motive := fun x => β = x) hααγγ hβααγ2\n  -- This is what we wished to prove.  ∎\n  exact hβγ", block: true)

#text("#19.5 (17 moves instead of 18)")

#raw("-- We wish to prove inv((α · β)) = (inv(β) · inv(α)).\ninclude one mul inv one_mul mul_one mul_assoc inv_mul mul_inv in\ntheorem mul_inv_rev' (α : G) (β : G) : inv (mul α β) = mul (inv β) (inv α) := by\n  -- From ∀ x : G, (∀ y : G, (∀ z : G, (((x · y) · z) = (x · (y · z))))), β we deduce ∀ y : G, (∀ z : G, (((β · y) · z) = (β · (y · z))))  (universal instantiation (specialization)).\n  have hβyzβyz : ∀ y : G, (∀ z : G, (mul (mul β y) z = mul β (mul y z))) := mul_assoc β\n  -- From ∀ y : G, (∀ z : G, (((β · y) · z) = (β · (y · z)))), inv(β) we deduce ∀ z : G, (((β · inv(β)) · z) = (β · (inv(β) · z)))  (universal instantiation (specialization)).\n  have hββzββz : ∀ z : G, (mul (mul β (inv β)) z = mul β (mul (inv β) z)) := hβyzβyz (inv β)\n  -- From ∀ z : G, (((β · inv(β)) · z) = (β · (inv(β) · z))), inv(α) we deduce ((β · inv(β)) · inv(α)) = (β · (inv(β) · inv(α)))  (universal instantiation (specialization)).\n  have hββαββα : mul (mul β (inv β)) (inv α) = mul β (mul (inv β) (inv α)) := hββzββz (inv α)\n  -- From ∀ x : G, ((x · inv(x)) = 1), β we deduce (β · inv(β)) = 1  (universal instantiation (specialization)).\n  have hββ : mul β (inv β) = one := mul_inv β\n  -- From ((β · inv(β)) · inv(α)) = (β · (inv(β) · inv(α))), (β · inv(β)) = 1 we deduce (1 · inv(α)) = (β · (inv(β) · inv(α)))  (rewrite along an equation).\n  have hαββα : mul one (inv α) = mul β (mul (inv β) (inv α)) := Eq.subst (motive := fun x => mul x (inv α) = mul β (mul (inv β) (inv α))) hββ hββαββα\n  -- From ∀ x : G, ((1 · x) = x), inv(α) we deduce (1 · inv(α)) = inv(α)  (universal instantiation (specialization)).\n  have hαα : mul one (inv α) = inv α := one_mul (inv α)\n  -- From (1 · inv(α)) = (β · (inv(β) · inv(α))), (1 · inv(α)) = inv(α) we deduce inv(α) = (β · (inv(β) · inv(α)))  (rewrite along an equation).\n  have hαββα2 : inv α = mul β (mul (inv β) (inv α)) := Eq.subst (motive := fun x => x = mul β (mul (inv β) (inv α))) hαα hαββα\n  -- From ∀ x : G, ((x · inv(x)) = 1), α we deduce (α · inv(α)) = 1  (universal instantiation (specialization)).\n  have hαα2 : mul α (inv α) = one := mul_inv α\n  -- From (α · inv(α)) = 1, inv(α) = (β · (inv(β) · inv(α))) we deduce (α · (β · (inv(β) · inv(α)))) = 1  (rewrite along an equation).\n  have hαββα3 : mul α (mul β (mul (inv β) (inv α))) = one := Eq.subst (motive := fun x => mul α x = one) hαββα2 hαα2\n  -- From ∀ x : G, (∀ y : G, (∀ z : G, (((x · y) · z) = (x · (y · z))))), α we deduce ∀ y : G, (∀ z : G, (((α · y) · z) = (α · (y · z))))  (universal instantiation (specialization)).\n  have hαyzαyz : ∀ y : G, (∀ z : G, (mul (mul α y) z = mul α (mul y z))) := mul_assoc α\n  -- From ∀ y : G, (∀ z : G, (((α · y) · z) = (α · (y · z)))), β we deduce ∀ z : G, (((α · β) · z) = (α · (β · z)))  (universal instantiation (specialization)).\n  have hαβzαβz : ∀ z : G, (mul (mul α β) z = mul α (mul β z)) := hαyzαyz β\n  -- From ∀ z : G, (((α · β) · z) = (α · (β · z))), inv(β) · inv(α) we deduce ((α · β) · (inv(β) · inv(α))) = (α · (β · (inv(β) · inv(α))))  (universal instantiation (specialization)).\n  have hαββααββα : mul (mul α β) (mul (inv β) (inv α)) = mul α (mul β (mul (inv β) (inv α))) := hαβzαβz (mul (inv β) (inv α))\n  -- From ((α · β) · (inv(β) · inv(α))) = (α · (β · (inv(β) · inv(α)))), (α · (β · (inv(β) · inv(α)))) = 1 we deduce ((α · β) · (inv(β) · inv(α))) = 1  (rewrite along an equation).\n  have hαββα4 : mul (mul α β) (mul (inv β) (inv α)) = one := Eq.subst (motive := fun x => mul (mul α β) (mul (inv β) (inv α)) = x) hαββα3 hαββααββα\n  -- From ∀ x : G, ((x · inv(x)) = 1), α · β we deduce ((α · β) · inv((α · β))) = 1  (universal instantiation (specialization)).\n  have hαβαβ : mul (mul α β) (inv (mul α β)) = one := mul_inv (mul α β)\n  -- From (α · β) · (inv(β) · inv(α)), 1, ((α · β) · (inv(β) · inv(α))) = 1 we deduce 1 = ((α · β) · (inv(β) · inv(α)))  (the lemma Eq.symm').\n  have hαββα5 : one = mul (mul α β) (mul (inv β) (inv α)) := Eq.symm' (mul (mul α β) (mul (inv β) (inv α))) one hαββα4\n  -- From ((α · β) · inv((α · β))) = 1, 1 = ((α · β) · (inv(β) · inv(α))) we deduce ((α · β) · inv((α · β))) = ((α · β) · (inv(β) · inv(α)))  (rewrite along an equation).\n  have hαβαβαββα : mul (mul α β) (inv (mul α β)) = mul (mul α β) (mul (inv β) (inv α)) := Eq.subst (motive := fun x => mul (mul α β) (inv (mul α β)) = x) hαββα5 hαβαβ\n  -- From α · β, inv((α · β)), inv(β) · inv(α), ((α · β) · inv((α · β))) = ((α · β) · (inv(β) · inv(α))) we deduce inv((α · β)) = (inv(β) · inv(α))  (the lemma mul_left_cancel').\n  have hαββα6 : inv (mul α β) = mul (inv β) (inv α) := mul_left_cancel' one mul inv one_mul mul_one mul_assoc inv_mul mul_inv (mul α β) (inv (mul α β)) (mul (inv β) (inv α)) hαβαβαββα\n  -- This is what we wished to prove.  ∎\n  exact hαββα6", block: true)

#text("#20.6 (18 moves instead of 19)")

#raw("-- We are given a ≤ b, b ≤ c.\n-- We wish to prove a ≤ c.\ntheorem le_trans' (a : Nat') (b : Nat') (c : Nat') (hab : le a b) (hbc : le b c) : le a c := by\n  -- From ∀ a : Nat, (∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b)))), a we deduce ∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b)))  (universal instantiation (specialization)).\n  have habakb : ∀ b : Nat', (le a b ↔ (∃ k : Nat', (add a k = b))) := le_def a\n  -- From ∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b))), b we deduce (a ≤ b) ↔ (∃ k : Nat, ((a + k) = b))  (universal instantiation (specialization)).\n  have habakb2 : le a b ↔ (∃ k : Nat', (add a k = b)) := habakb b\n  -- From ∀ a : Nat, (∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b)))), b we deduce ∀ b'1 : Nat, ((b ≤ b'1) ↔ (∃ k : Nat, ((b + k) = b'1)))  (universal instantiation (specialization)).\n  have hbb'1bkb'1 : ∀ b'1 : Nat', (le b b'1 ↔ (∃ k : Nat', (add b k = b'1))) := le_def b\n  -- From ∀ b'1 : Nat, ((b ≤ b'1) ↔ (∃ k : Nat, ((b + k) = b'1))), c we deduce (b ≤ c) ↔ (∃ k : Nat, ((b + k) = c))  (universal instantiation (specialization)).\n  have hbcbkc : le b c ↔ (∃ k : Nat', (add b k = c)) := hbb'1bkb'1 c\n  -- From ∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b))), c we deduce (a ≤ c) ↔ (∃ k : Nat, ((a + k) = c))  (universal instantiation (specialization)).\n  have hacakc : le a c ↔ (∃ k : Nat', (add a k = c)) := habakb c\n  -- From (a ≤ b) ↔ (∃ k : Nat, ((a + k) = b)), a ≤ b we deduce ∃ k : Nat, ((a + k) = b)  (iff elimination (forward)).\n  have hakb : ∃ k : Nat', (add a k = b) := habakb2.mp hab\n  -- From (b ≤ c) ↔ (∃ k : Nat, ((b + k) = c)), b ≤ c we deduce ∃ k : Nat, ((b + k) = c)  (iff elimination (forward)).\n  have hbkc : ∃ k : Nat', (add b k = c) := hbcbkc.mp hbc\n  -- Since ∃ k : Nat, ((a + k) = b), fix k : Nat with (a + k) = b.\n  have hakb3 := hakb\n  obtain ⟨k, hakb2⟩ := hakb3\n  -- Since ∃ k : Nat, ((b + k) = c), fix j : Nat with (b + j) = c.\n  have hbkc2 := hbkc\n  obtain ⟨j, hbjc⟩ := hbkc2\n  -- From a + k, b, (a + k) = b we deduce b = (a + k)  (the lemma Eq.symm').\n  have hbak : b = add a k := Eq.symm' (add a k) b hakb2\n  -- From (b + j) = c, b = (a + k) we deduce ((a + k) + j) = c  (rewrite along an equation).\n  have hakjc : add (add a k) j = c := Eq.subst (motive := fun x => add x j = c) hbak hbjc\n  -- From  we deduce ∀ a : Nat, (∀ b : Nat, (∀ c : Nat, (((a + b) + c) = (a + (b + c)))))  (the lemma add_assoc').\n  have habcabc : ∀ a : Nat', (∀ b : Nat', (∀ c : Nat', (add (add a b) c = add a (add b c)))) := add_assoc'\n  -- From ∀ a : Nat, (∀ b : Nat, (∀ c : Nat, (((a + b) + c) = (a + (b + c))))), a we deduce ∀ b : Nat, (∀ c : Nat, (((a + b) + c) = (a + (b + c))))  (universal instantiation (specialization)).\n  have habcabc2 : ∀ b : Nat', (∀ c : Nat', (add (add a b) c = add a (add b c))) := habcabc a\n  -- From ∀ b : Nat, (∀ c : Nat, (((a + b) + c) = (a + (b + c)))), k we deduce ∀ c : Nat, (((a + k) + c) = (a + (k + c)))  (universal instantiation (specialization)).\n  have hakcakc : ∀ c : Nat', (add (add a k) c = add a (add k c)) := habcabc2 k\n  -- From ∀ c : Nat, (((a + k) + c) = (a + (k + c))), j we deduce ((a + k) + j) = (a + (k + j))  (universal instantiation (specialization)).\n  have hakjakj : add (add a k) j = add a (add k j) := hakcakc j\n  -- From ((a + k) + j) = c, ((a + k) + j) = (a + (k + j)) we deduce (a + (k + j)) = c  (rewrite along an equation).\n  have hakjc2 : add a (add k j) = c := Eq.subst (motive := fun x => x = c) hakjakj hakjc\n  -- From (a + (k + j)) = c, k + j we deduce ∃ x : Nat, ((a + x) = c)  (existential introduction).\n  have haxc : ∃ x : Nat', (add a x = c) := ⟨add k j, hakjc2⟩\n  -- From (a ≤ c) ↔ (∃ k : Nat, ((a + k) = c)), ∃ x : Nat, ((a + x) = c) we deduce a ≤ c  (iff elimination (backward)).\n  have hac : le a c := hacakc.mpr haxc\n  -- This is what we wished to prove.  ∎\n  exact hac", block: true)

#emph[#text("[Added -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d8743ae0fe0c9a25f7a64cc22f010e4d6e7284961c7cd41c6bef0c04b0afdd-99b1fdce4cbf1d63453450780711acdac96e460d2707765fc440a052f7f99a20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kantian")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-700050")[#strong[#text("Kantian")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("Another batch of shorter proofs.")

#text("#6.8 (9 moves instead of 13)")

#raw("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by\n  -- Introduce B:\n  have hBBC : B → (B ∨ C) := by\n    intro hB\n    \n    -- From B, C we deduce B ∨ C  (disjunction introduction (left)).\n    have hBC : B ∨ C := Or.inl hB\n    -- Discharging, we obtain B → (B ∨ C).\n    exact hBC\n  -- From B → (B ∨ C), A we deduce (A ∨ B) → (A ∨ (B ∨ C))  (the lemma Or.mono_right').\n  have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := Or.mono_right' hBBC\n  -- Introduce C:\n  have hCABC : C → (A ∨ (B ∨ C)) := by\n    intro hC\n    -- From C, B we deduce B ∨ C  (disjunction introduction (right)).\n    have hBC : B ∨ C := Or.inr hC\n    -- From B ∨ C, A we deduce A ∨ (B ∨ C)  (disjunction introduction (right)).\n    have hABC2 : A ∨ (B ∨ C) := Or.inr hBC\n    -- Discharging, we obtain C → (A ∨ (B ∨ C)).\n    exact hABC2\n  -- From (A ∨ B) ∨ C, (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce A ∨ (B ∨ C)  (the lemma Or.elim').\n  have hABC2 : A ∨ (B ∨ C) := Or.elim' hABC hABABC hCABC\n  -- This is what we wished to prove.  ∎\n  exact hABC2", block: true)

#text("#8.9 (6 moves instead of 8)")

#raw("-- We are given (¬ A) ∨ (¬ B).\n-- We wish to prove ¬ (A ∧ B).\ntheorem not_and_of_not_or' (hnAonB : (¬ A) ∨ (¬ B)) : ¬ (A ∧ B) := by\n  -- From (¬ A) ∨ (¬ B) we deduce A → (¬ B)  (the lemma imp_of_not_or').\n  have hAB : A → (¬ B) := imp_of_not_or' hnAonB\n  -- Introduce A ∧ B:\n  have hAB2 : ¬ (A ∧ B) := by\n    intro hAB2\n    -- From A ∧ B, A → (¬ B) we deduce (¬ B) ∧ B  (the lemma And.imp_left').\n    have hBB : (¬ B) ∧ B := And.imp_left' hAB2 hAB\n    -- From (¬ B) ∧ B we deduce ¬ B  (conjunction elimination (left)).\n    have hB : ¬ B := And.left hBB\n    -- From (¬ B) ∧ B we deduce B  (conjunction elimination (right)).\n    have hB2 : B := And.right hBB\n    -- This is a contradiction, so we conclude ¬ (A ∧ B).\n    exact absurd hB2 hB\n  -- This is what we wished to prove.  ∎\n  exact hAB2", block: true)

#text("#18.7 (4 moves instead of 5)")

#raw("-- We are given α = β.\n-- We wish to prove P(α) ↔ P(β).\ntheorem Eq.congr_iff' (α : Ω) (β : Ω) (hab : α = β) : P α ↔ P β := by\n  -- From P(α) we deduce P(α) → P(α)  (the lemma Impl.idem).\n  have hαα : P α → P α := Impl.idem\n  -- From P(α) → P(α), α = β we deduce P(α) → P(β)  (rewrite along an equation).\n  have hαβ : P α → P β := Eq.subst (motive := fun x => P α → P x) hab hαα\n  -- From P(α) → P(α), α = β we deduce P(β) → P(α)  (rewrite along an equation).\n  have hβα : P β → P α := Eq.subst (motive := fun x => P x → P α) hab hαα\n  -- From P(α) → P(β), P(β) → P(α) we deduce P(α) ↔ P(β)  (iff introduction).\n  have hαβ2 : P α ↔ P β := Iff.intro hαβ hβα\n  -- This is what we wished to prove.  ∎\n  exact hαβ2", block: true)

#text("#18.8 (16 moves instead of 17)")

#raw("-- We wish to prove (a ∪ b) = (b ∪ a).\ninclude mem union inter mem_union mem_inter ext in\ntheorem union_comm' (a : Set) (b : Set) : union a b = union b a := by\n  -- Introduce an arbitrary x : Set:\n  have hxabxba : ∀ x : Set, (mem x (union a b) ↔ mem x (union b a)) := by\n    intro x\n    -- From x ∈ a, x ∈ b we deduce ((x ∈ a) ∨ (x ∈ b)) → ((x ∈ b) ∨ (x ∈ a))  (the lemma Or.symm').\n    have hxaxbxbxa : (mem x a ∨ mem x b) → (mem x b ∨ mem x a) := Or.symm'\n    -- From x ∈ b, x ∈ a we deduce ((x ∈ b) ∨ (x ∈ a)) → ((x ∈ a) ∨ (x ∈ b))  (the lemma Or.symm').\n    have hxbxaxaxb : (mem x b ∨ mem x a) → (mem x a ∨ mem x b) := Or.symm'\n    -- From ((x ∈ a) ∨ (x ∈ b)) → ((x ∈ b) ∨ (x ∈ a)), ((x ∈ b) ∨ (x ∈ a)) → ((x ∈ a) ∨ (x ∈ b)) we deduce ((x ∈ a) ∨ (x ∈ b)) ↔ ((x ∈ b) ∨ (x ∈ a))  (iff introduction).\n    have hxaxbxbxa2 : (mem x a ∨ mem x b) ↔ (mem x b ∨ mem x a) := Iff.intro hxaxbxbxa hxbxaxaxb\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b))) := mem_union x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b)) := hxabxaxb a\n    -- From ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))), b we deduce (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb3 : mem x (union a b) ↔ (mem x a ∨ mem x b) := hxabxaxb2 b\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), b we deduce ∀ b'1296 : Set, ((x ∈ (b ∪ b'1296)) ↔ ((x ∈ b) ∨ (x ∈ b'1296)))  (universal instantiation (specialization)).\n    have hxbb'1296xbxb'1296 : ∀ b'1296 : Set, (mem x (union b b'1296) ↔ (mem x b ∨ mem x b'1296)) := hxabxaxb b\n    -- From ∀ b'1296 : Set, ((x ∈ (b ∪ b'1296)) ↔ ((x ∈ b) ∨ (x ∈ b'1296))), a we deduce (x ∈ (b ∪ a)) ↔ ((x ∈ b) ∨ (x ∈ a))  (universal instantiation (specialization)).\n    have hxbaxbxa : mem x (union b a) ↔ (mem x b ∨ mem x a) := hxbb'1296xbxb'1296 a\n    -- From (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)), ((x ∈ a) ∨ (x ∈ b)) ↔ ((x ∈ b) ∨ (x ∈ a)) we deduce (x ∈ (a ∪ b)) ↔ ((x ∈ b) ∨ (x ∈ a))  (the lemma Iff.trans').\n    have hxabxbxa : mem x (union a b) ↔ (mem x b ∨ mem x a) := Iff.trans' hxabxaxb3 hxaxbxbxa2\n    -- From (x ∈ (b ∪ a)) ↔ ((x ∈ b) ∨ (x ∈ a)) we deduce ((x ∈ b) ∨ (x ∈ a)) ↔ (x ∈ (b ∪ a))  (the lemma Iff.symm').\n    have hxbxaxba : (mem x b ∨ mem x a) ↔ mem x (union b a) := Iff.symm' hxbaxbxa\n    -- From (x ∈ (a ∪ b)) ↔ ((x ∈ b) ∨ (x ∈ a)), ((x ∈ b) ∨ (x ∈ a)) ↔ (x ∈ (b ∪ a)) we deduce (x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a))  (the lemma Iff.trans').\n    have hxabxba : mem x (union a b) ↔ mem x (union b a) := Iff.trans' hxabxbxa hxbxaxba\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a))).\n    exact hxabxba\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), a ∪ b we deduce ∀ b'3091 : Set, ((∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ b'3091))) → ((a ∪ b) = b'3091))  (universal instantiation (specialization)).\n  have hxabxb'3091abb'3091 : ∀ b'3091 : Set, ((∀ x : Set, (mem x (union a b) ↔ mem x b'3091)) → (union a b = b'3091)) := ext (union a b)\n  -- From ∀ b'3091 : Set, ((∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ b'3091))) → ((a ∪ b) = b'3091)), b ∪ a we deduce (∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a)))) → ((a ∪ b) = (b ∪ a))  (universal instantiation (specialization)).\n  have hxabxbaabba : (∀ x : Set, (mem x (union a b) ↔ mem x (union b a))) → (union a b = union b a) := hxabxb'3091abb'3091 (union b a)\n  -- From (∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a)))) → ((a ∪ b) = (b ∪ a)), ∀ x : Set, ((x ∈ (a ∪ b)) ↔ (x ∈ (b ∪ a))) we deduce (a ∪ b) = (b ∪ a)  (modus ponens).\n  have habba : union a b = union b a := hxabxbaabba hxabxba\n  -- This is what we wished to prove.  ∎\n  exact habba", block: true)

#text("#18.9 (16 moves instead of 17)")

#raw("-- We wish to prove (a ∩ b) = (b ∩ a).\ninclude mem union inter mem_union mem_inter ext in\ntheorem inter_comm' (a : Set) (b : Set) : inter a b = inter b a := by\n  -- Introduce an arbitrary x : Set:\n  have hxabxba : ∀ x : Set, (mem x (inter a b) ↔ mem x (inter b a)) := by\n    intro x\n    -- From x ∈ a, x ∈ b we deduce ((x ∈ a) ∧ (x ∈ b)) → ((x ∈ b) ∧ (x ∈ a))  (the lemma And.symm').\n    have hxaxbxbxa : (mem x a ∧ mem x b) → (mem x b ∧ mem x a) := And.symm'\n    -- From x ∈ b, x ∈ a we deduce ((x ∈ b) ∧ (x ∈ a)) → ((x ∈ a) ∧ (x ∈ b))  (the lemma And.symm').\n    have hxbxaxaxb : (mem x b ∧ mem x a) → (mem x a ∧ mem x b) := And.symm'\n    -- From ((x ∈ a) ∧ (x ∈ b)) → ((x ∈ b) ∧ (x ∈ a)), ((x ∈ b) ∧ (x ∈ a)) → ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ↔ ((x ∈ b) ∧ (x ∈ a))  (iff introduction).\n    have hxaxbxbxa2 : (mem x a ∧ mem x b) ↔ (mem x b ∧ mem x a) := Iff.intro hxaxbxbxa hxbxaxaxb\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b))) := mem_inter x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b)) := hxabxaxb a\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b we deduce (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb3 : mem x (inter a b) ↔ (mem x a ∧ mem x b) := hxabxaxb2 b\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), b we deduce ∀ b'5463 : Set, ((x ∈ (b ∩ b'5463)) ↔ ((x ∈ b) ∧ (x ∈ b'5463)))  (universal instantiation (specialization)).\n    have hxbb'5463xbxb'5463 : ∀ b'5463 : Set, (mem x (inter b b'5463) ↔ (mem x b ∧ mem x b'5463)) := hxabxaxb b\n    -- From ∀ b'5463 : Set, ((x ∈ (b ∩ b'5463)) ↔ ((x ∈ b) ∧ (x ∈ b'5463))), a we deduce (x ∈ (b ∩ a)) ↔ ((x ∈ b) ∧ (x ∈ a))  (universal instantiation (specialization)).\n    have hxbaxbxa : mem x (inter b a) ↔ (mem x b ∧ mem x a) := hxbb'5463xbxb'5463 a\n    -- From (x ∈ (b ∩ a)) ↔ ((x ∈ b) ∧ (x ∈ a)) we deduce ((x ∈ b) ∧ (x ∈ a)) ↔ (x ∈ (b ∩ a))  (the lemma Iff.symm').\n    have hxbxaxba : (mem x b ∧ mem x a) ↔ mem x (inter b a) := Iff.symm' hxbaxbxa\n    -- From (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)), ((x ∈ a) ∧ (x ∈ b)) ↔ ((x ∈ b) ∧ (x ∈ a)) we deduce (x ∈ (a ∩ b)) ↔ ((x ∈ b) ∧ (x ∈ a))  (the lemma Iff.trans').\n    have hxabxbxa : mem x (inter a b) ↔ (mem x b ∧ mem x a) := Iff.trans' hxabxaxb3 hxaxbxbxa2\n    -- From (x ∈ (a ∩ b)) ↔ ((x ∈ b) ∧ (x ∈ a)), ((x ∈ b) ∧ (x ∈ a)) ↔ (x ∈ (b ∩ a)) we deduce (x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a))  (the lemma Iff.trans').\n    have hxabxba : mem x (inter a b) ↔ mem x (inter b a) := Iff.trans' hxabxbxa hxbxaxba\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a))).\n    exact hxabxba\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), a ∩ b we deduce ∀ b'6435 : Set, ((∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ b'6435))) → ((a ∩ b) = b'6435))  (universal instantiation (specialization)).\n  have hxabxb'6435abb'6435 : ∀ b'6435 : Set, ((∀ x : Set, (mem x (inter a b) ↔ mem x b'6435)) → (inter a b = b'6435)) := ext (inter a b)\n  -- From ∀ b'6435 : Set, ((∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ b'6435))) → ((a ∩ b) = b'6435)), b ∩ a we deduce (∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a)))) → ((a ∩ b) = (b ∩ a))  (universal instantiation (specialization)).\n  have hxabxbaabba : (∀ x : Set, (mem x (inter a b) ↔ mem x (inter b a))) → (inter a b = inter b a) := hxabxb'6435abb'6435 (inter b a)\n  -- From (∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a)))) → ((a ∩ b) = (b ∩ a)), ∀ x : Set, ((x ∈ (a ∩ b)) ↔ (x ∈ (b ∩ a))) we deduce (a ∩ b) = (b ∩ a)  (modus ponens).\n  have habba : inter a b = inter b a := hxabxbaabba hxabxba\n  -- This is what we wished to prove.  ∎\n  exact habba", block: true)

#text("#18.10 (35 moves instead of 48)")

#raw("-- We wish to prove (a ∩ (b ∪ c)) = ((a ∩ b) ∪ (a ∩ c)).\ninclude mem union inter mem_union mem_inter ext in\ntheorem inter_union_distrib' (a : Set) (b : Set) (c : Set) : inter a (union b c) = union (inter a b) (inter a c) := by\n  -- Introduce an arbitrary x : Set:\n  have hxabcxabac : ∀ x : Set, (mem x (inter a (union b c)) ↔ mem x (union (inter a b) (inter a c))) := by\n    intro x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b))) := mem_union x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ a : Set, (∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b))) := mem_inter x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb3 : ∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b)) := hxabxaxb2 a\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b ∪ c we deduce (x ∈ (a ∩ (b ∪ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∪ c)))  (universal instantiation (specialization)).\n    have hxabcxaxbc : mem x (inter a (union b c)) ↔ (mem x a ∧ mem x (union b c)) := hxabxaxb3 (union b c)\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b we deduce (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb4 : mem x (inter a b) ↔ (mem x a ∧ mem x b) := hxabxaxb3 b\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), c we deduce (x ∈ (a ∩ c)) ↔ ((x ∈ a) ∧ (x ∈ c))  (universal instantiation (specialization)).\n    have hxacxaxc : mem x (inter a c) ↔ (mem x a ∧ mem x c) := hxabxaxb3 c\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), b we deduce ∀ b'1 : Set, ((x ∈ (b ∪ b'1)) ↔ ((x ∈ b) ∨ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxbb'1xbxb'1 : ∀ b'1 : Set, (mem x (union b b'1) ↔ (mem x b ∨ mem x b'1)) := hxabxaxb b\n    -- From ∀ b'1 : Set, ((x ∈ (b ∪ b'1)) ↔ ((x ∈ b) ∨ (x ∈ b'1))), c we deduce (x ∈ (b ∪ c)) ↔ ((x ∈ b) ∨ (x ∈ c))  (universal instantiation (specialization)).\n    have hxbcxbxc : mem x (union b c) ↔ (mem x b ∨ mem x c) := hxbb'1xbxb'1 c\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), a ∩ b we deduce ∀ b'1 : Set, ((x ∈ ((a ∩ b) ∪ b'1)) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxabb'1xabxb'1 : ∀ b'1 : Set, (mem x (union (inter a b) b'1) ↔ (mem x (inter a b) ∨ mem x b'1)) := hxabxaxb (inter a b)\n    -- From ∀ b'1 : Set, ((x ∈ ((a ∩ b) ∪ b'1)) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ b'1))), a ∩ c we deduce (x ∈ ((a ∩ b) ∪ (a ∩ c))) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c)))  (universal instantiation (specialization)).\n    have hxabacxabxac : mem x (union (inter a b) (inter a c)) ↔ (mem x (inter a b) ∨ mem x (inter a c)) := hxabb'1xabxb'1 (inter a c)\n    -- Introduce x ∈ (a ∩ (b ∪ c)):\n    have hxabcxabac : mem x (inter a (union b c)) → mem x (union (inter a b) (inter a c)) := by\n      intro hxabc\n      -- From (x ∈ (a ∩ (b ∪ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∪ c))), x ∈ (a ∩ (b ∪ c)) we deduce (x ∈ a) ∧ (x ∈ (b ∪ c))  (iff elimination (forward)).\n      have hxaxbc : mem x a ∧ mem x (union b c) := hxabcxaxbc.mp hxabc\n      -- From (x ∈ a) ∧ (x ∈ (b ∪ c)), (x ∈ (b ∪ c)) ↔ ((x ∈ b) ∨ (x ∈ c)) we deduce (x ∈ a) ∧ ((x ∈ b) ∨ (x ∈ c))  (the lemma And.congr_right').\n      have hxaxbxc : mem x a ∧ (mem x b ∨ mem x c) := And.congr_right' hxaxbc hxbcxbxc\n      -- From (x ∈ a) ∧ ((x ∈ b) ∨ (x ∈ c)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∨ ((x ∈ a) ∧ (x ∈ c))  (the lemma and_or_left').\n      have hxaxbxaxc : (mem x a ∧ mem x b) ∨ (mem x a ∧ mem x c) := and_or_left' hxaxbxc\n      -- From (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ↔ (x ∈ (a ∩ b))  (the lemma Iff.symm').\n      have hxaxbxab : (mem x a ∧ mem x b) ↔ mem x (inter a b) := Iff.symm' hxabxaxb4\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∨ ((x ∈ a) ∧ (x ∈ c)), ((x ∈ a) ∧ (x ∈ b)) ↔ (x ∈ (a ∩ b)) we deduce (x ∈ (a ∩ b)) ∨ ((x ∈ a) ∧ (x ∈ c))  (the lemma Or.congr_left').\n      have hxabxaxc : mem x (inter a b) ∨ (mem x a ∧ mem x c) := Or.congr_left' hxaxbxaxc hxaxbxab\n      -- From (x ∈ (a ∩ c)) ↔ ((x ∈ a) ∧ (x ∈ c)) we deduce ((x ∈ a) ∧ (x ∈ c)) ↔ (x ∈ (a ∩ c))  (the lemma Iff.symm').\n      have hxaxcxac : (mem x a ∧ mem x c) ↔ mem x (inter a c) := Iff.symm' hxacxaxc\n      -- From (x ∈ (a ∩ b)) ∨ ((x ∈ a) ∧ (x ∈ c)), ((x ∈ a) ∧ (x ∈ c)) ↔ (x ∈ (a ∩ c)) we deduce (x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c))  (the lemma Or.congr_right').\n      have hxabxac : mem x (inter a b) ∨ mem x (inter a c) := Or.congr_right' hxabxaxc hxaxcxac\n      -- From (x ∈ ((a ∩ b) ∪ (a ∩ c))) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c))), (x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c)) we deduce x ∈ ((a ∩ b) ∪ (a ∩ c))  (iff elimination (backward)).\n      have hxabac : mem x (union (inter a b) (inter a c)) := hxabacxabxac.mpr hxabxac\n      -- Discharging, we obtain (x ∈ (a ∩ (b ∪ c))) → (x ∈ ((a ∩ b) ∪ (a ∩ c))).\n      exact hxabac\n    -- Introduce x ∈ ((a ∩ b) ∪ (a ∩ c)):\n    have hxabacxabc : mem x (union (inter a b) (inter a c)) → mem x (inter a (union b c)) := by\n      intro hxabac\n      -- From (x ∈ ((a ∩ b) ∪ (a ∩ c))) ↔ ((x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c))), x ∈ ((a ∩ b) ∪ (a ∩ c)) we deduce (x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c))  (iff elimination (forward)).\n      have hxabxac : mem x (inter a b) ∨ mem x (inter a c) := hxabacxabxac.mp hxabac\n      -- From (x ∈ (a ∩ b)) ∨ (x ∈ (a ∩ c)), (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∨ (x ∈ (a ∩ c))  (the lemma Or.congr_left').\n      have hxaxbxac : (mem x a ∧ mem x b) ∨ mem x (inter a c) := Or.congr_left' hxabxac hxabxaxb4\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∨ (x ∈ (a ∩ c)), (x ∈ (a ∩ c)) ↔ ((x ∈ a) ∧ (x ∈ c)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∨ ((x ∈ a) ∧ (x ∈ c))  (the lemma Or.congr_right').\n      have hxaxbxaxc : (mem x a ∧ mem x b) ∨ (mem x a ∧ mem x c) := Or.congr_right' hxaxbxac hxacxaxc\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∨ ((x ∈ a) ∧ (x ∈ c)) we deduce (x ∈ a) ∧ ((x ∈ b) ∨ (x ∈ c))  (the lemma and_or_left_rev).\n      have hxaxbxc : mem x a ∧ (mem x b ∨ mem x c) := and_or_left_rev hxaxbxaxc\n      -- From (x ∈ (b ∪ c)) ↔ ((x ∈ b) ∨ (x ∈ c)) we deduce ((x ∈ b) ∨ (x ∈ c)) ↔ (x ∈ (b ∪ c))  (the lemma Iff.symm').\n      have hxbxcxbc : (mem x b ∨ mem x c) ↔ mem x (union b c) := Iff.symm' hxbcxbxc\n      -- From (x ∈ a) ∧ ((x ∈ b) ∨ (x ∈ c)), ((x ∈ b) ∨ (x ∈ c)) ↔ (x ∈ (b ∪ c)) we deduce (x ∈ a) ∧ (x ∈ (b ∪ c))  (the lemma And.congr_right').\n      have hxaxbc : mem x a ∧ mem x (union b c) := And.congr_right' hxaxbxc hxbxcxbc\n      -- From (x ∈ (a ∩ (b ∪ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∪ c))), (x ∈ a) ∧ (x ∈ (b ∪ c)) we deduce x ∈ (a ∩ (b ∪ c))  (iff elimination (backward)).\n      have hxabc : mem x (inter a (union b c)) := hxabcxaxbc.mpr hxaxbc\n      -- Discharging, we obtain (x ∈ ((a ∩ b) ∪ (a ∩ c))) → (x ∈ (a ∩ (b ∪ c))).\n      exact hxabc\n    -- From (x ∈ (a ∩ (b ∪ c))) → (x ∈ ((a ∩ b) ∪ (a ∩ c))), (x ∈ ((a ∩ b) ∪ (a ∩ c))) → (x ∈ (a ∩ (b ∪ c))) we deduce (x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c)))  (iff introduction).\n    have hxabcxabac2 : mem x (inter a (union b c)) ↔ mem x (union (inter a b) (inter a c)) := Iff.intro hxabcxabac hxabacxabc\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c)))).\n    exact hxabcxabac2\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), a ∩ (b ∪ c) we deduce ∀ b'1 : Set, ((∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ b'1))) → ((a ∩ (b ∪ c)) = b'1))  (universal instantiation (specialization)).\n  have hxabcxb'1abcb'1 : ∀ b'1 : Set, ((∀ x : Set, (mem x (inter a (union b c)) ↔ mem x b'1)) → (inter a (union b c) = b'1)) := ext (inter a (union b c))\n  -- From ∀ b'1 : Set, ((∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ b'1))) → ((a ∩ (b ∪ c)) = b'1)), (a ∩ b) ∪ (a ∩ c) we deduce (∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c))))) → ((a ∩ (b ∪ c)) = ((a ∩ b) ∪ (a ∩ c)))  (universal instantiation (specialization)).\n  have hxabcxabacabcabac : (∀ x : Set, (mem x (inter a (union b c)) ↔ mem x (union (inter a b) (inter a c)))) → (inter a (union b c) = union (inter a b) (inter a c)) := hxabcxb'1abcb'1 (union (inter a b) (inter a c))\n  -- From (∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c))))) → ((a ∩ (b ∪ c)) = ((a ∩ b) ∪ (a ∩ c))), ∀ x : Set, ((x ∈ (a ∩ (b ∪ c))) ↔ (x ∈ ((a ∩ b) ∪ (a ∩ c)))) we deduce (a ∩ (b ∪ c)) = ((a ∩ b) ∪ (a ∩ c))  (modus ponens).\n  have habcabac : inter a (union b c) = union (inter a b) (inter a c) := hxabcxabacabcabac hxabcxabac\n  -- This is what we wished to prove.  ∎\n  exact habcabac", block: true)

#text("#18.12 (30 moves instead of 34)")

#raw("-- We wish to prove ((a ∩ b) ∩ c) = (a ∩ (b ∩ c)).\ninclude mem union inter mem_union mem_inter ext in\ntheorem inter_assoc' (a : Set) (b : Set) (c : Set) : inter (inter a b) c = inter a (inter b c) := by\n  -- Introduce an arbitrary x : Set:\n  have hxabcxabc : ∀ x : Set, (mem x (inter (inter a b) c) ↔ mem x (inter a (inter b c))) := by\n    intro x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b))) := mem_inter x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b)) := hxabxaxb a\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b we deduce (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb3 : mem x (inter a b) ↔ (mem x a ∧ mem x b) := hxabxaxb2 b\n    -- From ∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))), b ∩ c we deduce (x ∈ (a ∩ (b ∩ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∩ c)))  (universal instantiation (specialization)).\n    have hxabcxaxbc : mem x (inter a (inter b c)) ↔ (mem x a ∧ mem x (inter b c)) := hxabxaxb2 (inter b c)\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a ∩ b we deduce ∀ b'1 : Set, ((x ∈ ((a ∩ b) ∩ b'1)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxabb'1xabxb'1 : ∀ b'1 : Set, (mem x (inter (inter a b) b'1) ↔ (mem x (inter a b) ∧ mem x b'1)) := hxabxaxb (inter a b)\n    -- From ∀ b'1 : Set, ((x ∈ ((a ∩ b) ∩ b'1)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ b'1))), c we deduce (x ∈ ((a ∩ b) ∩ c)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ c))  (universal instantiation (specialization)).\n    have hxabcxabxc : mem x (inter (inter a b) c) ↔ (mem x (inter a b) ∧ mem x c) := hxabb'1xabxb'1 c\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), b we deduce ∀ b'1 : Set, ((x ∈ (b ∩ b'1)) ↔ ((x ∈ b) ∧ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxbb'1xbxb'1 : ∀ b'1 : Set, (mem x (inter b b'1) ↔ (mem x b ∧ mem x b'1)) := hxabxaxb b\n    -- From ∀ b'1 : Set, ((x ∈ (b ∩ b'1)) ↔ ((x ∈ b) ∧ (x ∈ b'1))), c we deduce (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c))  (universal instantiation (specialization)).\n    have hxbcxbxc : mem x (inter b c) ↔ (mem x b ∧ mem x c) := hxbb'1xbxb'1 c\n    -- Introduce x ∈ ((a ∩ b) ∩ c):\n    have hxabcxabc : mem x (inter (inter a b) c) → mem x (inter a (inter b c)) := by\n      intro hxabc\n      -- From (x ∈ ((a ∩ b) ∩ c)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ c)), x ∈ ((a ∩ b) ∩ c) we deduce (x ∈ (a ∩ b)) ∧ (x ∈ c)  (iff elimination (forward)).\n      have hxabxc : mem x (inter a b) ∧ mem x c := hxabcxabxc.mp hxabc\n      -- From (x ∈ (a ∩ b)) ∧ (x ∈ c), (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∧ (x ∈ c)  (the lemma And.congr_left').\n      have hxaxbxc : (mem x a ∧ mem x b) ∧ mem x c := And.congr_left' hxabxc hxabxaxb3\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∧ (x ∈ c) we deduce (x ∈ a) ∧ ((x ∈ b) ∧ (x ∈ c))  (the lemma And.assoc_left).\n      have hxaxbxc2 : mem x a ∧ (mem x b ∧ mem x c) := And.assoc_left hxaxbxc\n      -- From (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c)) we deduce ((x ∈ b) ∧ (x ∈ c)) ↔ (x ∈ (b ∩ c))  (the lemma Iff.symm').\n      have hxbxcxbc : (mem x b ∧ mem x c) ↔ mem x (inter b c) := Iff.symm' hxbcxbxc\n      -- From (x ∈ a) ∧ ((x ∈ b) ∧ (x ∈ c)), ((x ∈ b) ∧ (x ∈ c)) ↔ (x ∈ (b ∩ c)) we deduce (x ∈ a) ∧ (x ∈ (b ∩ c))  (the lemma And.congr_right').\n      have hxaxbc : mem x a ∧ mem x (inter b c) := And.congr_right' hxaxbxc2 hxbxcxbc\n      -- From (x ∈ (a ∩ (b ∩ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∩ c))), (x ∈ a) ∧ (x ∈ (b ∩ c)) we deduce x ∈ (a ∩ (b ∩ c))  (iff elimination (backward)).\n      have hxabc2 : mem x (inter a (inter b c)) := hxabcxaxbc.mpr hxaxbc\n      -- Discharging, we obtain (x ∈ ((a ∩ b) ∩ c)) → (x ∈ (a ∩ (b ∩ c))).\n      exact hxabc2\n    -- Introduce x ∈ (a ∩ (b ∩ c)):\n    have hxabcxabc2 : mem x (inter a (inter b c)) → mem x (inter (inter a b) c) := by\n      intro hxabc\n      -- From (x ∈ (a ∩ (b ∩ c))) ↔ ((x ∈ a) ∧ (x ∈ (b ∩ c))), x ∈ (a ∩ (b ∩ c)) we deduce (x ∈ a) ∧ (x ∈ (b ∩ c))  (iff elimination (forward)).\n      have hxaxbc : mem x a ∧ mem x (inter b c) := hxabcxaxbc.mp hxabc\n      -- From (x ∈ a) ∧ (x ∈ (b ∩ c)), (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c)) we deduce (x ∈ a) ∧ ((x ∈ b) ∧ (x ∈ c))  (the lemma And.congr_right').\n      have hxaxbxc : mem x a ∧ (mem x b ∧ mem x c) := And.congr_right' hxaxbc hxbcxbxc\n      -- From (x ∈ a) ∧ ((x ∈ b) ∧ (x ∈ c)) we deduce ((x ∈ a) ∧ (x ∈ b)) ∧ (x ∈ c)  (the lemma And.assoc_right).\n      have hxaxbxc2 : (mem x a ∧ mem x b) ∧ mem x c := And.assoc_right hxaxbxc\n      -- From (x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)) we deduce ((x ∈ a) ∧ (x ∈ b)) ↔ (x ∈ (a ∩ b))  (the lemma Iff.symm').\n      have hxaxbxab : (mem x a ∧ mem x b) ↔ mem x (inter a b) := Iff.symm' hxabxaxb3\n      -- From ((x ∈ a) ∧ (x ∈ b)) ∧ (x ∈ c), ((x ∈ a) ∧ (x ∈ b)) ↔ (x ∈ (a ∩ b)) we deduce (x ∈ (a ∩ b)) ∧ (x ∈ c)  (the lemma And.congr_left').\n      have hxabxc : mem x (inter a b) ∧ mem x c := And.congr_left' hxaxbxc2 hxaxbxab\n      -- From (x ∈ ((a ∩ b) ∩ c)) ↔ ((x ∈ (a ∩ b)) ∧ (x ∈ c)), (x ∈ (a ∩ b)) ∧ (x ∈ c) we deduce x ∈ ((a ∩ b) ∩ c)  (iff elimination (backward)).\n      have hxabc2 : mem x (inter (inter a b) c) := hxabcxabxc.mpr hxabxc\n      -- Discharging, we obtain (x ∈ (a ∩ (b ∩ c))) → (x ∈ ((a ∩ b) ∩ c)).\n      exact hxabc2\n    -- From (x ∈ ((a ∩ b) ∩ c)) → (x ∈ (a ∩ (b ∩ c))), (x ∈ (a ∩ (b ∩ c))) → (x ∈ ((a ∩ b) ∩ c)) we deduce (x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c)))  (iff introduction).\n    have hxabcxabc3 : mem x (inter (inter a b) c) ↔ mem x (inter a (inter b c)) := Iff.intro hxabcxabc hxabcxabc2\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c)))).\n    exact hxabcxabc3\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), (a ∩ b) ∩ c we deduce ∀ b'1 : Set, ((∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ b'1))) → (((a ∩ b) ∩ c) = b'1))  (universal instantiation (specialization)).\n  have hxabcxb'1abcb'1 : ∀ b'1 : Set, ((∀ x : Set, (mem x (inter (inter a b) c) ↔ mem x b'1)) → (inter (inter a b) c = b'1)) := ext (inter (inter a b) c)\n  -- From ∀ b'1 : Set, ((∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ b'1))) → (((a ∩ b) ∩ c) = b'1)), a ∩ (b ∩ c) we deduce (∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c))))) → (((a ∩ b) ∩ c) = (a ∩ (b ∩ c)))  (universal instantiation (specialization)).\n  have hxabcxabcabcabc : (∀ x : Set, (mem x (inter (inter a b) c) ↔ mem x (inter a (inter b c)))) → (inter (inter a b) c = inter a (inter b c)) := hxabcxb'1abcb'1 (inter a (inter b c))\n  -- From (∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c))))) → (((a ∩ b) ∩ c) = (a ∩ (b ∩ c))), ∀ x : Set, ((x ∈ ((a ∩ b) ∩ c)) ↔ (x ∈ (a ∩ (b ∩ c)))) we deduce ((a ∩ b) ∩ c) = (a ∩ (b ∩ c))  (modus ponens).\n  have habcabc : inter (inter a b) c = inter a (inter b c) := hxabcxabcabcabc hxabcxabc\n  -- This is what we wished to prove.  ∎\n  exact habcabc", block: true)

#text("#18.13 (35 moves instead of 40)")

#raw("-- We wish to prove (a ∪ (b ∩ c)) = ((a ∪ b) ∩ (a ∪ c)).\ninclude mem union inter mem_union mem_inter ext in\ntheorem union_inter_distrib' (a : Set) (b : Set) (c : Set) : union a (inter b c) = inter (union a b) (union a c) := by\n  -- Introduce an arbitrary x : Set:\n  have hxabcxabac : ∀ x : Set, (mem x (union a (inter b c)) ↔ mem x (inter (union a b) (union a c))) := by\n    intro x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb : ∀ a : Set, (∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b))) := mem_union x\n    -- From ∀ x : Set, (∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))), x we deduce ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b))))  (universal instantiation (specialization)).\n    have hxabxaxb2 : ∀ a : Set, (∀ b : Set, (mem x (inter a b) ↔ (mem x a ∧ mem x b))) := mem_inter x\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))), a we deduce ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)))  (universal instantiation (specialization)).\n    have hxabxaxb3 : ∀ b : Set, (mem x (union a b) ↔ (mem x a ∨ mem x b)) := hxabxaxb a\n    -- From ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))), b we deduce (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))  (universal instantiation (specialization)).\n    have hxabxaxb4 : mem x (union a b) ↔ (mem x a ∨ mem x b) := hxabxaxb3 b\n    -- From ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))), c we deduce (x ∈ (a ∪ c)) ↔ ((x ∈ a) ∨ (x ∈ c))  (universal instantiation (specialization)).\n    have hxacxaxc : mem x (union a c) ↔ (mem x a ∨ mem x c) := hxabxaxb3 c\n    -- From ∀ b : Set, ((x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b))), b ∩ c we deduce (x ∈ (a ∪ (b ∩ c))) ↔ ((x ∈ a) ∨ (x ∈ (b ∩ c)))  (universal instantiation (specialization)).\n    have hxabcxaxbc : mem x (union a (inter b c)) ↔ (mem x a ∨ mem x (inter b c)) := hxabxaxb3 (inter b c)\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), b we deduce ∀ b'1 : Set, ((x ∈ (b ∩ b'1)) ↔ ((x ∈ b) ∧ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxbb'1xbxb'1 : ∀ b'1 : Set, (mem x (inter b b'1) ↔ (mem x b ∧ mem x b'1)) := hxabxaxb2 b\n    -- From ∀ b'1 : Set, ((x ∈ (b ∩ b'1)) ↔ ((x ∈ b) ∧ (x ∈ b'1))), c we deduce (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c))  (universal instantiation (specialization)).\n    have hxbcxbxc : mem x (inter b c) ↔ (mem x b ∧ mem x c) := hxbb'1xbxb'1 c\n    -- From ∀ a : Set, (∀ b : Set, ((x ∈ (a ∩ b)) ↔ ((x ∈ a) ∧ (x ∈ b)))), a ∪ b we deduce ∀ b'1 : Set, ((x ∈ ((a ∪ b) ∩ b'1)) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ b'1)))  (universal instantiation (specialization)).\n    have hxabb'1xabxb'1 : ∀ b'1 : Set, (mem x (inter (union a b) b'1) ↔ (mem x (union a b) ∧ mem x b'1)) := hxabxaxb2 (union a b)\n    -- From ∀ b'1 : Set, ((x ∈ ((a ∪ b) ∩ b'1)) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ b'1))), a ∪ c we deduce (x ∈ ((a ∪ b) ∩ (a ∪ c))) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c)))  (universal instantiation (specialization)).\n    have hxabacxabxac : mem x (inter (union a b) (union a c)) ↔ (mem x (union a b) ∧ mem x (union a c)) := hxabb'1xabxb'1 (union a c)\n    -- Introduce x ∈ (a ∪ (b ∩ c)):\n    have hxabcxabac : mem x (union a (inter b c)) → mem x (inter (union a b) (union a c)) := by\n      intro hxabc\n      -- From (x ∈ (a ∪ (b ∩ c))) ↔ ((x ∈ a) ∨ (x ∈ (b ∩ c))), x ∈ (a ∪ (b ∩ c)) we deduce (x ∈ a) ∨ (x ∈ (b ∩ c))  (iff elimination (forward)).\n      have hxaxbc : mem x a ∨ mem x (inter b c) := hxabcxaxbc.mp hxabc\n      -- From (x ∈ a) ∨ (x ∈ (b ∩ c)), (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c)) we deduce (x ∈ a) ∨ ((x ∈ b) ∧ (x ∈ c))  (the lemma Or.congr_right').\n      have hxaxbxc : mem x a ∨ (mem x b ∧ mem x c) := Or.congr_right' hxaxbc hxbcxbxc\n      -- From (x ∈ a) ∨ ((x ∈ b) ∧ (x ∈ c)) we deduce ((x ∈ a) ∨ (x ∈ b)) ∧ ((x ∈ a) ∨ (x ∈ c))  (the lemma or_and_left').\n      have hxaxbxaxc : (mem x a ∨ mem x b) ∧ (mem x a ∨ mem x c) := or_and_left' hxaxbxc\n      -- From (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)) we deduce ((x ∈ a) ∨ (x ∈ b)) ↔ (x ∈ (a ∪ b))  (the lemma Iff.symm').\n      have hxaxbxab : (mem x a ∨ mem x b) ↔ mem x (union a b) := Iff.symm' hxabxaxb4\n      -- From ((x ∈ a) ∨ (x ∈ b)) ∧ ((x ∈ a) ∨ (x ∈ c)), ((x ∈ a) ∨ (x ∈ b)) ↔ (x ∈ (a ∪ b)) we deduce (x ∈ (a ∪ b)) ∧ ((x ∈ a) ∨ (x ∈ c))  (the lemma And.congr_left').\n      have hxabxaxc : mem x (union a b) ∧ (mem x a ∨ mem x c) := And.congr_left' hxaxbxaxc hxaxbxab\n      -- From (x ∈ (a ∪ c)) ↔ ((x ∈ a) ∨ (x ∈ c)) we deduce ((x ∈ a) ∨ (x ∈ c)) ↔ (x ∈ (a ∪ c))  (the lemma Iff.symm').\n      have hxaxcxac : (mem x a ∨ mem x c) ↔ mem x (union a c) := Iff.symm' hxacxaxc\n      -- From (x ∈ (a ∪ b)) ∧ ((x ∈ a) ∨ (x ∈ c)), ((x ∈ a) ∨ (x ∈ c)) ↔ (x ∈ (a ∪ c)) we deduce (x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c))  (the lemma And.congr_right').\n      have hxabxac : mem x (union a b) ∧ mem x (union a c) := And.congr_right' hxabxaxc hxaxcxac\n      -- From (x ∈ ((a ∪ b) ∩ (a ∪ c))) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c))), (x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c)) we deduce x ∈ ((a ∪ b) ∩ (a ∪ c))  (iff elimination (backward)).\n      have hxabac : mem x (inter (union a b) (union a c)) := hxabacxabxac.mpr hxabxac\n      -- Discharging, we obtain (x ∈ (a ∪ (b ∩ c))) → (x ∈ ((a ∪ b) ∩ (a ∪ c))).\n      exact hxabac\n    -- Introduce x ∈ ((a ∪ b) ∩ (a ∪ c)):\n    have hxabacxabc : mem x (inter (union a b) (union a c)) → mem x (union a (inter b c)) := by\n      intro hxabac\n      -- From (x ∈ ((a ∪ b) ∩ (a ∪ c))) ↔ ((x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c))), x ∈ ((a ∪ b) ∩ (a ∪ c)) we deduce (x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c))  (iff elimination (forward)).\n      have hxabxac : mem x (union a b) ∧ mem x (union a c) := hxabacxabxac.mp hxabac\n      -- From (x ∈ (a ∪ b)) ∧ (x ∈ (a ∪ c)), (x ∈ (a ∪ b)) ↔ ((x ∈ a) ∨ (x ∈ b)) we deduce ((x ∈ a) ∨ (x ∈ b)) ∧ (x ∈ (a ∪ c))  (the lemma And.congr_left').\n      have hxaxbxac : (mem x a ∨ mem x b) ∧ mem x (union a c) := And.congr_left' hxabxac hxabxaxb4\n      -- From ((x ∈ a) ∨ (x ∈ b)) ∧ (x ∈ (a ∪ c)), (x ∈ (a ∪ c)) ↔ ((x ∈ a) ∨ (x ∈ c)) we deduce ((x ∈ a) ∨ (x ∈ b)) ∧ ((x ∈ a) ∨ (x ∈ c))  (the lemma And.congr_right').\n      have hxaxbxaxc : (mem x a ∨ mem x b) ∧ (mem x a ∨ mem x c) := And.congr_right' hxaxbxac hxacxaxc\n      -- From ((x ∈ a) ∨ (x ∈ b)) ∧ ((x ∈ a) ∨ (x ∈ c)) we deduce (x ∈ a) ∨ ((x ∈ b) ∧ (x ∈ c))  (the lemma or_and_left_rev).\n      have hxaxbxc : mem x a ∨ (mem x b ∧ mem x c) := or_and_left_rev hxaxbxaxc\n      -- From (x ∈ (b ∩ c)) ↔ ((x ∈ b) ∧ (x ∈ c)) we deduce ((x ∈ b) ∧ (x ∈ c)) ↔ (x ∈ (b ∩ c))  (the lemma Iff.symm').\n      have hxbxcxbc : (mem x b ∧ mem x c) ↔ mem x (inter b c) := Iff.symm' hxbcxbxc\n      -- From (x ∈ a) ∨ ((x ∈ b) ∧ (x ∈ c)), ((x ∈ b) ∧ (x ∈ c)) ↔ (x ∈ (b ∩ c)) we deduce (x ∈ a) ∨ (x ∈ (b ∩ c))  (the lemma Or.congr_right').\n      have hxaxbc : mem x a ∨ mem x (inter b c) := Or.congr_right' hxaxbxc hxbxcxbc\n      -- From (x ∈ (a ∪ (b ∩ c))) ↔ ((x ∈ a) ∨ (x ∈ (b ∩ c))), (x ∈ a) ∨ (x ∈ (b ∩ c)) we deduce x ∈ (a ∪ (b ∩ c))  (iff elimination (backward)).\n      have hxabc : mem x (union a (inter b c)) := hxabcxaxbc.mpr hxaxbc\n      -- Discharging, we obtain (x ∈ ((a ∪ b) ∩ (a ∪ c))) → (x ∈ (a ∪ (b ∩ c))).\n      exact hxabc\n    -- From (x ∈ (a ∪ (b ∩ c))) → (x ∈ ((a ∪ b) ∩ (a ∪ c))), (x ∈ ((a ∪ b) ∩ (a ∪ c))) → (x ∈ (a ∪ (b ∩ c))) we deduce (x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c)))  (iff introduction).\n    have hxabcxabac2 : mem x (union a (inter b c)) ↔ mem x (inter (union a b) (union a c)) := Iff.intro hxabcxabac hxabacxabc\n    -- Discharging, we obtain ∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c)))).\n    exact hxabcxabac2\n  -- From ∀ a : Set, (∀ b : Set, ((∀ x : Set, ((x ∈ a) ↔ (x ∈ b))) → (a = b))), a ∪ (b ∩ c) we deduce ∀ b'1 : Set, ((∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ b'1))) → ((a ∪ (b ∩ c)) = b'1))  (universal instantiation (specialization)).\n  have hxabcxb'1abcb'1 : ∀ b'1 : Set, ((∀ x : Set, (mem x (union a (inter b c)) ↔ mem x b'1)) → (union a (inter b c) = b'1)) := ext (union a (inter b c))\n  -- From ∀ b'1 : Set, ((∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ b'1))) → ((a ∪ (b ∩ c)) = b'1)), (a ∪ b) ∩ (a ∪ c) we deduce (∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c))))) → ((a ∪ (b ∩ c)) = ((a ∪ b) ∩ (a ∪ c)))  (universal instantiation (specialization)).\n  have hxabcxabacabcabac : (∀ x : Set, (mem x (union a (inter b c)) ↔ mem x (inter (union a b) (union a c)))) → (union a (inter b c) = inter (union a b) (union a c)) := hxabcxb'1abcb'1 (inter (union a b) (union a c))\n  -- From (∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c))))) → ((a ∪ (b ∩ c)) = ((a ∪ b) ∩ (a ∪ c))), ∀ x : Set, ((x ∈ (a ∪ (b ∩ c))) ↔ (x ∈ ((a ∪ b) ∩ (a ∪ c)))) we deduce (a ∪ (b ∩ c)) = ((a ∪ b) ∩ (a ∪ c))  (modus ponens).\n  have habcabac : union a (inter b c) = inter (union a b) (union a c) := hxabcxabacabcabac hxabcxabac\n  -- This is what we wished to prove.  ∎\n  exact habcabac", block: true)

#text("#19.3 (13 moves instead of 18)")

#raw("-- We are given (α · β) = (α · γ).\n-- We wish to prove β = γ.\ninclude one mul inv one_mul mul_one mul_assoc inv_mul mul_inv in\ntheorem mul_left_cancel' (α : G) (β : G) (γ : G) (h : mul α β = mul α γ) : β = γ := by\n  -- From ∀ x : G, (∀ y : G, (∀ z : G, (((x · y) · z) = (x · (y · z))))), inv(α) we deduce ∀ y : G, (∀ z : G, (((inv(α) · y) · z) = (inv(α) · (y · z))))  (universal instantiation (specialization)).\n  have hαyzαyz : ∀ y : G, (∀ z : G, (mul (mul (inv α) y) z = mul (inv α) (mul y z))) := mul_assoc (inv α)\n  -- From ∀ y : G, (∀ z : G, (((inv(α) · y) · z) = (inv(α) · (y · z)))), α we deduce ∀ z : G, (((inv(α) · α) · z) = (inv(α) · (α · z)))  (universal instantiation (specialization)).\n  have hααzααz : ∀ z : G, (mul (mul (inv α) α) z = mul (inv α) (mul α z)) := hαyzαyz α\n  -- From ∀ z : G, (((inv(α) · α) · z) = (inv(α) · (α · z))), β we deduce ((inv(α) · α) · β) = (inv(α) · (α · β))  (universal instantiation (specialization)).\n  have hααβααβ : mul (mul (inv α) α) β = mul (inv α) (mul α β) := hααzααz β\n  -- From ((inv(α) · α) · β) = (inv(α) · (α · β)), (α · β) = (α · γ) we deduce ((inv(α) · α) · β) = (inv(α) · (α · γ))  (rewrite along an equation).\n  have hααβααγ : mul (mul (inv α) α) β = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => mul (mul (inv α) α) β = mul (inv α) x) h hααβααβ\n  -- From ∀ x : G, ((inv(x) · x) = 1), α we deduce (inv(α) · α) = 1  (universal instantiation (specialization)).\n  have hαα : mul (inv α) α = one := inv_mul α\n  -- From ((inv(α) · α) · β) = (inv(α) · (α · γ)), (inv(α) · α) = 1 we deduce (1 · β) = (inv(α) · (α · γ))  (rewrite along an equation).\n  have hβααγ : mul one β = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => mul x β = mul (inv α) (mul α γ)) hαα hααβααγ\n  -- From ∀ z : G, (((inv(α) · α) · z) = (inv(α) · (α · z))), γ we deduce ((inv(α) · α) · γ) = (inv(α) · (α · γ))  (universal instantiation (specialization)).\n  have hααγααγ : mul (mul (inv α) α) γ = mul (inv α) (mul α γ) := hααzααz γ\n  -- From ((inv(α) · α) · γ) = (inv(α) · (α · γ)), (inv(α) · α) = 1 we deduce (1 · γ) = (inv(α) · (α · γ))  (rewrite along an equation).\n  have hγααγ : mul one γ = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => mul x γ = mul (inv α) (mul α γ)) hαα hααγααγ\n  -- From ∀ x : G, ((1 · x) = x), γ we deduce (1 · γ) = γ  (universal instantiation (specialization)).\n  have hγγ : mul one γ = γ := one_mul γ\n  -- From (1 · γ) = γ, (1 · γ) = (inv(α) · (α · γ)) we deduce (inv(α) · (α · γ)) = γ  (rewrite along an equation).\n  have hααγγ : mul (inv α) (mul α γ) = γ := Eq.subst (motive := fun x => x = γ) hγααγ hγγ\n  -- From ∀ x : G, ((1 · x) = x), β we deduce (1 · β) = β  (universal instantiation (specialization)).\n  have hββ : mul one β = β := one_mul β\n  -- From (1 · β) = (inv(α) · (α · γ)), (1 · β) = β we deduce β = (inv(α) · (α · γ))  (rewrite along an equation).\n  have hβααγ2 : β = mul (inv α) (mul α γ) := Eq.subst (motive := fun x => x = mul (inv α) (mul α γ)) hββ hβααγ\n  -- From β = (inv(α) · (α · γ)), (inv(α) · (α · γ)) = γ we deduce β = γ  (rewrite along an equation).\n  have hβγ : β = γ := Eq.subst (motive := fun x => β = x) hααγγ hβααγ2\n  -- This is what we wished to prove.  ∎\n  exact hβγ", block: true)

#text("#19.5 (17 moves instead of 18)")

#raw("-- We wish to prove inv((α · β)) = (inv(β) · inv(α)).\ninclude one mul inv one_mul mul_one mul_assoc inv_mul mul_inv in\ntheorem mul_inv_rev' (α : G) (β : G) : inv (mul α β) = mul (inv β) (inv α) := by\n  -- From ∀ x : G, (∀ y : G, (∀ z : G, (((x · y) · z) = (x · (y · z))))), β we deduce ∀ y : G, (∀ z : G, (((β · y) · z) = (β · (y · z))))  (universal instantiation (specialization)).\n  have hβyzβyz : ∀ y : G, (∀ z : G, (mul (mul β y) z = mul β (mul y z))) := mul_assoc β\n  -- From ∀ y : G, (∀ z : G, (((β · y) · z) = (β · (y · z)))), inv(β) we deduce ∀ z : G, (((β · inv(β)) · z) = (β · (inv(β) · z)))  (universal instantiation (specialization)).\n  have hββzββz : ∀ z : G, (mul (mul β (inv β)) z = mul β (mul (inv β) z)) := hβyzβyz (inv β)\n  -- From ∀ z : G, (((β · inv(β)) · z) = (β · (inv(β) · z))), inv(α) we deduce ((β · inv(β)) · inv(α)) = (β · (inv(β) · inv(α)))  (universal instantiation (specialization)).\n  have hββαββα : mul (mul β (inv β)) (inv α) = mul β (mul (inv β) (inv α)) := hββzββz (inv α)\n  -- From ∀ x : G, ((x · inv(x)) = 1), β we deduce (β · inv(β)) = 1  (universal instantiation (specialization)).\n  have hββ : mul β (inv β) = one := mul_inv β\n  -- From ((β · inv(β)) · inv(α)) = (β · (inv(β) · inv(α))), (β · inv(β)) = 1 we deduce (1 · inv(α)) = (β · (inv(β) · inv(α)))  (rewrite along an equation).\n  have hαββα : mul one (inv α) = mul β (mul (inv β) (inv α)) := Eq.subst (motive := fun x => mul x (inv α) = mul β (mul (inv β) (inv α))) hββ hββαββα\n  -- From ∀ x : G, ((1 · x) = x), inv(α) we deduce (1 · inv(α)) = inv(α)  (universal instantiation (specialization)).\n  have hαα : mul one (inv α) = inv α := one_mul (inv α)\n  -- From (1 · inv(α)) = (β · (inv(β) · inv(α))), (1 · inv(α)) = inv(α) we deduce inv(α) = (β · (inv(β) · inv(α)))  (rewrite along an equation).\n  have hαββα2 : inv α = mul β (mul (inv β) (inv α)) := Eq.subst (motive := fun x => x = mul β (mul (inv β) (inv α))) hαα hαββα\n  -- From ∀ x : G, ((x · inv(x)) = 1), α we deduce (α · inv(α)) = 1  (universal instantiation (specialization)).\n  have hαα2 : mul α (inv α) = one := mul_inv α\n  -- From (α · inv(α)) = 1, inv(α) = (β · (inv(β) · inv(α))) we deduce (α · (β · (inv(β) · inv(α)))) = 1  (rewrite along an equation).\n  have hαββα3 : mul α (mul β (mul (inv β) (inv α))) = one := Eq.subst (motive := fun x => mul α x = one) hαββα2 hαα2\n  -- From ∀ x : G, (∀ y : G, (∀ z : G, (((x · y) · z) = (x · (y · z))))), α we deduce ∀ y : G, (∀ z : G, (((α · y) · z) = (α · (y · z))))  (universal instantiation (specialization)).\n  have hαyzαyz : ∀ y : G, (∀ z : G, (mul (mul α y) z = mul α (mul y z))) := mul_assoc α\n  -- From ∀ y : G, (∀ z : G, (((α · y) · z) = (α · (y · z)))), β we deduce ∀ z : G, (((α · β) · z) = (α · (β · z)))  (universal instantiation (specialization)).\n  have hαβzαβz : ∀ z : G, (mul (mul α β) z = mul α (mul β z)) := hαyzαyz β\n  -- From ∀ z : G, (((α · β) · z) = (α · (β · z))), inv(β) · inv(α) we deduce ((α · β) · (inv(β) · inv(α))) = (α · (β · (inv(β) · inv(α))))  (universal instantiation (specialization)).\n  have hαββααββα : mul (mul α β) (mul (inv β) (inv α)) = mul α (mul β (mul (inv β) (inv α))) := hαβzαβz (mul (inv β) (inv α))\n  -- From ((α · β) · (inv(β) · inv(α))) = (α · (β · (inv(β) · inv(α)))), (α · (β · (inv(β) · inv(α)))) = 1 we deduce ((α · β) · (inv(β) · inv(α))) = 1  (rewrite along an equation).\n  have hαββα4 : mul (mul α β) (mul (inv β) (inv α)) = one := Eq.subst (motive := fun x => mul (mul α β) (mul (inv β) (inv α)) = x) hαββα3 hαββααββα\n  -- From ∀ x : G, ((x · inv(x)) = 1), α · β we deduce ((α · β) · inv((α · β))) = 1  (universal instantiation (specialization)).\n  have hαβαβ : mul (mul α β) (inv (mul α β)) = one := mul_inv (mul α β)\n  -- From (α · β) · (inv(β) · inv(α)), 1, ((α · β) · (inv(β) · inv(α))) = 1 we deduce 1 = ((α · β) · (inv(β) · inv(α)))  (the lemma Eq.symm').\n  have hαββα5 : one = mul (mul α β) (mul (inv β) (inv α)) := Eq.symm' (mul (mul α β) (mul (inv β) (inv α))) one hαββα4\n  -- From ((α · β) · inv((α · β))) = 1, 1 = ((α · β) · (inv(β) · inv(α))) we deduce ((α · β) · inv((α · β))) = ((α · β) · (inv(β) · inv(α)))  (rewrite along an equation).\n  have hαβαβαββα : mul (mul α β) (inv (mul α β)) = mul (mul α β) (mul (inv β) (inv α)) := Eq.subst (motive := fun x => mul (mul α β) (inv (mul α β)) = x) hαββα5 hαβαβ\n  -- From α · β, inv((α · β)), inv(β) · inv(α), ((α · β) · inv((α · β))) = ((α · β) · (inv(β) · inv(α))) we deduce inv((α · β)) = (inv(β) · inv(α))  (the lemma mul_left_cancel').\n  have hαββα6 : inv (mul α β) = mul (inv β) (inv α) := mul_left_cancel' one mul inv one_mul mul_one mul_assoc inv_mul mul_inv (mul α β) (inv (mul α β)) (mul (inv β) (inv α)) hαβαβαββα\n  -- This is what we wished to prove.  ∎\n  exact hαββα6", block: true)

#text("#20.6 (18 moves instead of 19)")

#raw("-- We are given a ≤ b, b ≤ c.\n-- We wish to prove a ≤ c.\ntheorem le_trans' (a : Nat') (b : Nat') (c : Nat') (hab : le a b) (hbc : le b c) : le a c := by\n  -- From ∀ a : Nat, (∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b)))), a we deduce ∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b)))  (universal instantiation (specialization)).\n  have habakb : ∀ b : Nat', (le a b ↔ (∃ k : Nat', (add a k = b))) := le_def a\n  -- From ∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b))), b we deduce (a ≤ b) ↔ (∃ k : Nat, ((a + k) = b))  (universal instantiation (specialization)).\n  have habakb2 : le a b ↔ (∃ k : Nat', (add a k = b)) := habakb b\n  -- From ∀ a : Nat, (∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b)))), b we deduce ∀ b'1 : Nat, ((b ≤ b'1) ↔ (∃ k : Nat, ((b + k) = b'1)))  (universal instantiation (specialization)).\n  have hbb'1bkb'1 : ∀ b'1 : Nat', (le b b'1 ↔ (∃ k : Nat', (add b k = b'1))) := le_def b\n  -- From ∀ b'1 : Nat, ((b ≤ b'1) ↔ (∃ k : Nat, ((b + k) = b'1))), c we deduce (b ≤ c) ↔ (∃ k : Nat, ((b + k) = c))  (universal instantiation (specialization)).\n  have hbcbkc : le b c ↔ (∃ k : Nat', (add b k = c)) := hbb'1bkb'1 c\n  -- From ∀ b : Nat, ((a ≤ b) ↔ (∃ k : Nat, ((a + k) = b))), c we deduce (a ≤ c) ↔ (∃ k : Nat, ((a + k) = c))  (universal instantiation (specialization)).\n  have hacakc : le a c ↔ (∃ k : Nat', (add a k = c)) := habakb c\n  -- From (a ≤ b) ↔ (∃ k : Nat, ((a + k) = b)), a ≤ b we deduce ∃ k : Nat, ((a + k) = b)  (iff elimination (forward)).\n  have hakb : ∃ k : Nat', (add a k = b) := habakb2.mp hab\n  -- From (b ≤ c) ↔ (∃ k : Nat, ((b + k) = c)), b ≤ c we deduce ∃ k : Nat, ((b + k) = c)  (iff elimination (forward)).\n  have hbkc : ∃ k : Nat', (add b k = c) := hbcbkc.mp hbc\n  -- Since ∃ k : Nat, ((a + k) = b), fix k : Nat with (a + k) = b.\n  have hakb3 := hakb\n  obtain ⟨k, hakb2⟩ := hakb3\n  -- Since ∃ k : Nat, ((b + k) = c), fix j : Nat with (b + j) = c.\n  have hbkc2 := hbkc\n  obtain ⟨j, hbjc⟩ := hbkc2\n  -- From a + k, b, (a + k) = b we deduce b = (a + k)  (the lemma Eq.symm').\n  have hbak : b = add a k := Eq.symm' (add a k) b hakb2\n  -- From (b + j) = c, b = (a + k) we deduce ((a + k) + j) = c  (rewrite along an equation).\n  have hakjc : add (add a k) j = c := Eq.subst (motive := fun x => add x j = c) hbak hbjc\n  -- From  we deduce ∀ a : Nat, (∀ b : Nat, (∀ c : Nat, (((a + b) + c) = (a + (b + c)))))  (the lemma add_assoc').\n  have habcabc : ∀ a : Nat', (∀ b : Nat', (∀ c : Nat', (add (add a b) c = add a (add b c)))) := add_assoc'\n  -- From ∀ a : Nat, (∀ b : Nat, (∀ c : Nat, (((a + b) + c) = (a + (b + c))))), a we deduce ∀ b : Nat, (∀ c : Nat, (((a + b) + c) = (a + (b + c))))  (universal instantiation (specialization)).\n  have habcabc2 : ∀ b : Nat', (∀ c : Nat', (add (add a b) c = add a (add b c))) := habcabc a\n  -- From ∀ b : Nat, (∀ c : Nat, (((a + b) + c) = (a + (b + c)))), k we deduce ∀ c : Nat, (((a + k) + c) = (a + (k + c)))  (universal instantiation (specialization)).\n  have hakcakc : ∀ c : Nat', (add (add a k) c = add a (add k c)) := habcabc2 k\n  -- From ∀ c : Nat, (((a + k) + c) = (a + (k + c))), j we deduce ((a + k) + j) = (a + (k + j))  (universal instantiation (specialization)).\n  have hakjakj : add (add a k) j = add a (add k j) := hakcakc j\n  -- From ((a + k) + j) = c, ((a + k) + j) = (a + (k + j)) we deduce (a + (k + j)) = c  (rewrite along an equation).\n  have hakjc2 : add a (add k j) = c := Eq.subst (motive := fun x => x = c) hakjakj hakjc\n  -- From (a + (k + j)) = c, k + j we deduce ∃ x : Nat, ((a + x) = c)  (existential introduction).\n  have haxc : ∃ x : Nat', (add a x = c) := ⟨add k j, hakjc2⟩\n  -- From (a ≤ c) ↔ (∃ k : Nat, ((a + k) = c)), ∃ x : Nat, ((a + x) = c) we deduce a ≤ c  (iff elimination (backward)).\n  have hac : le a c := hacakc.mpr haxc\n  -- This is what we wished to prove.  ∎\n  exact hac", block: true)

#emph[#text("[Added -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d8743ae0fe0c9a25f7a64cc22f010e4d6e7284961c7cd41c6bef0c04b0afdd-99b1fdce4cbf1d63453450780711acdac96e460d2707765fc440a052f7f99a20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kantian")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-700051")[#strong[#text("Kantian")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("For a reason I don’t understand, I only have this exercice on my smartphone but not with Firefox on my laptop.")

#raw("-- Lean Grimoire — 18.11 in 32 moves (the shortest it knows takes 34)-- grimoire-replay v2 18.11 v x Set ; c universal_instantiation mem_union (v x Set) = (b forall a Set (b forall b Set (a IFF (a MEM (v x Set) (a union (v a Set) (v b Set))) (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (v b Set)))))) ; c universal_instantiation hxabxaxb (a union (v a Set) (v b Set)) = (b forall b'1 Set (a IFF (a MEM (v x Set) (a union (a union (v a Set) (v b Set)) (v b'1 Set))) (a OR (a MEM (v x Set) (a union (v a Set) (v b Set))) (a MEM (v x Set) (v b'1 Set))))) ; c universal_instantiation hxabb'1xabxb'1 (v c Set) = (a IFF (a MEM (v x Set) (a union (a union (v a Set) (v b Set)) (v c Set))) (a OR (a MEM (v x Set) (a union (v a Set) (v b Set))) (a MEM (v x Set) (v c Set)))) ; c universal_instantiation hxabxaxb (v a Set) = (b forall b Set (a IFF (a MEM (v x Set) (a union (v a Set) (v b Set))) (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (v b Set))))) ; c universal_instantiation hxabxaxb2 (v b Set) = (a IFF (a MEM (v x Set) (a union (v a Set) (v b Set))) (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (v b Set)))) ; c universal_instantiation hxabxaxb2 (a union (v b Set) (v c Set)) = (a IFF (a MEM (v x Set) (a union (v a Set) (a union (v b Set) (v c Set)))) (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (a union (v b Set) (v c Set))))) ; c universal_instantiation hxabxaxb (v b Set) = (b forall b'1 Set (a IFF (a MEM (v x Set) (a union (v b Set) (v b'1 Set))) (a OR (a MEM (v x Set) (v b Set)) (a MEM (v x Set) (v b'1 Set))))) ; c universal_instantiation hxbb'1xbxb'1 (v c Set) = (a IFF (a MEM (v x Set) (a union (v b Set) (v c Set))) (a OR (a MEM (v x Set) (v b Set)) (a MEM (v x Set) (v c Set)))) ; a (a MEM (v x Set) (a union (a union (v a Set) (v b Set)) (v c Set))) ; c Iff.mp hxabcxabxc hxabc = (a OR (a MEM (v x Set) (a union (v a Set) (v b Set))) (a MEM (v x Set) (v c Set))) ; c Or.congr_left' hxabxc hxabxaxb3 = (a OR (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (v b Set))) (a MEM (v x Set) (v c Set))) ; c Or.assoc_left hxaxbxc = (a OR (a MEM (v x Set) (v a Set)) (a OR (a MEM (v x Set) (v b Set)) (a MEM (v x Set) (v c Set)))) ; c Iff.symm' hxbcxbxc = (a IFF (a OR (a MEM (v x Set) (v b Set)) (a MEM (v x Set) (v c Set))) (a MEM (v x Set) (a union (v b Set) (v c Set)))) ; c Or.congr_right' hxaxbxc2 hxbxcxbc = (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (a union (v b Set) (v c Set)))) ; c Iff.symm' hxabcxaxbc = (a IFF (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (a union (v b Set) (v c Set)))) (a MEM (v x Set) (a union (v a Set) (a union (v b Set) (v c Set))))) ; c Iff.mp hxaxbcxabc hxaxbc = (a MEM (v x Set) (a union (v a Set) (a union (v b Set) (v c Set)))) ; d hxabc2 1 ; a (a MEM (v x Set) (a union (v a Set) (a union (v b Set) (v c Set)))) ; c Iff.mp hxabcxaxbc hxabc = (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (a union (v b Set) (v c Set)))) ; c Or.congr_right' hxaxbc hxbcxbxc = (a OR (a MEM (v x Set) (v a Set)) (a OR (a MEM (v x Set) (v b Set)) (a MEM (v x Set) (v c Set)))) ; c Or.assoc_right hxaxbxc = (a OR (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (v b Set))) (a MEM (v x Set) (v c Set))) ; c Iff.symm' hxabxaxb3 = (a IFF (a OR (a MEM (v x Set) (v a Set)) (a MEM (v x Set) (v b Set))) (a MEM (v x Set) (a union (v a Set) (v b Set)))) ; c Or.congr_left' hxaxbxc2 hxaxbxab = (a OR (a MEM (v x Set) (a union (v a Set) (v b Set))) (a MEM (v x Set) (v c Set))) ; c Iff.symm' hxabcxabxc = (a IFF (a OR (a MEM (v x Set) (a union (v a Set) (v b Set))) (a MEM (v x Set) (v c Set))) (a MEM (v x Set) (a union (a union (v a Set) (v b Set)) (v c Set)))) ; c Iff.mp hxabxcxabc hxabxc = (a MEM (v x Set) (a union (a union (v a Set) (v b Set)) (v c Set))) ; d hxabc2 1 ; c Iff.intro hxabcxabc hxabcxabc2 = (a IFF (a MEM (v x Set) (a union (a union (v a Set) (v b Set)) (v c Set))) (a MEM (v x Set) (a union (v a Set) (a union (v b Set) (v c Set))))) ; d hxabcxabc3 1 ; c universal_instantiation ext (a union (a union (v a Set) (v b Set)) (v c Set)) = (b forall b'1 Set (a IMPLIES (b forall x Set (a IFF (a MEM (v x Set) (a union (a union (v a Set) (v b Set)) (v c Set))) (a MEM (v x Set) (v b'1 Set)))) (a EQ (a union (a union (v a Set) (v b Set)) (v c Set)) (v b'1 Set)))) ; c universal_instantiation hxabcxb'1abcb'1 (a union (v a Set) (a union (v b Set) (v c Set))) = (a IMPLIES (b forall x Set (a IFF (a MEM (v x Set) (a union (a union (v a Set) (v b Set)) (v c Set))) (a MEM (v x Set) (a union (v a Set) (a union (v b Set) (v c Set)))))) (a EQ (a union (a union (v a Set) (v b Set)) (v c Set)) (a union (v a Set) (a union (v b Set) (v c Set))))) ; c modus_ponens hxabcxabcabcabc hxabcxabc = (a EQ (a union (a union (v a Set) (v b Set)) (v c Set)) (a union (v a Set) (a union (v b Set) (v c Set))))")

#emph[#text("[Added -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-700057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("— Lean Grimoire — exercise 6.13 (or_and_left_rev)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 12 moves. The shortest proof the game knows takes 13, found by an anonymous reader on 18 November 2026, and independently by Kantian. THIS ONE IS SHORTER.")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hCCD : C → (C ∨ D) := by")#linebreak()#text("intro hC")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hDCD : D → (C ∨ D) := by")#linebreak()#text("intro hD")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hACD : A → (C ∨ D) := implies_trans hAC hCCD")#linebreak()#text("have hBCD : B → (C ∨ D) := implies_trans hBD hDCD")#linebreak()#text("have hCD : C ∨ D := Or.elim’ hAB hACD hBCD")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("— We are given (A ∨ B) ∧ (A ∨ C).")#linebreak()#text("— We wish to prove A ∨ (B ∧ C).")#linebreak()#text("theorem or_and_left_rev (hABC : (A ∨ B) ∧ (A ∨ C)) : A ∨ (B ∧ C) := by")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ B (conjunction elimination (left)).")#linebreak()#text("have hAB : A ∨ B := And.left hABC")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ C (conjunction elimination (right)).")#linebreak()#text("have hAC : A ∨ C := And.right hABC")#linebreak()#text("— Introduce A:")#linebreak()#text("have hAABC : A → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("— From A, B ∧ C we deduce A ∨ (B ∧ C) (disjunction introduction (left)).")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.inl hA")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∧ C)).")#linebreak()#text("exact hABC2")#linebreak()#text("— Introduce B:")#linebreak()#text("have hBABC : B → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("— Introduce C:")#linebreak()#text("have hCBC : C → (B ∧ C) := by")#linebreak()#text("intro hC")#linebreak()#text("— From B, C we deduce B ∧ C (conjunction introduction).")#linebreak()#text("have hBC : B ∧ C := And.intro hB hC")#linebreak()#text("— Discharging, we obtain C → (B ∧ C).")#linebreak()#text("exact hBC")#linebreak()#text("— From A ∨ C, C → (B ∧ C) we deduce A ∨ (B ∧ C) (the lemma Or.imp_right’).")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.imp_right’ hAC hCBC")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∧ C)).")#linebreak()#text("exact hABC2")#linebreak()#text("— From A ∨ B, A → (A ∨ (B ∧ C)), B → (A ∨ (B ∧ C)) we deduce A ∨ (B ∧ C) (the lemma Or.elim’).")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.elim’ hAB hAABC hBABC")#linebreak()#text("— This is what we wished to prove. ∎")#linebreak()#text("exact hABC2")

#text("— grimoire-replay v2 6.13 c And.left hABC = (a OR (v A Prop) (v B Prop)) ; c And.right hABC = (a OR (v A Prop) (v C Prop)) ; a (v A Prop) ; c Or.inl hA (a AND (v B Prop) (v C Prop)) = (a OR (v A Prop) (a AND (v B Prop) (v C Prop))) ; d hABC2 1 ; a (v B Prop) ; a (v C Prop) ; c And.intro hB hC = (a AND (v B Prop) (v C Prop)) ; d hBC 1 ; c Or.imp_right’ hAC hCBC = (a OR (v A Prop) (a AND (v B Prop) (v C Prop))) ; d hABC2 1 ; c Or.elim’ hAB hAABC hBABC = (a OR (v A Prop) (a AND (v B Prop) (v C Prop)))")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9799ef704215dee457c53836d615565a879201c1df2d8a161feb5db907c04c0-f1001679f071e7e78d68e67cd3f476f0da12943fdacf49ee4d1be95555fe60e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coco")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-2/#comment-700058")[#strong[#text("coco")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("— Lean Grimoire — exercise 6.13 (or_and_left_rev)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 12 moves. The shortest proof the game knows takes 13, found by an anonymous reader on 18 November 2026, and independently by Kantian. THIS ONE IS SHORTER.")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hCCD : C → (C ∨ D) := by")#linebreak()#text("intro hC")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hDCD : D → (C ∨ D) := by")#linebreak()#text("intro hD")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hACD : A → (C ∨ D) := implies_trans hAC hCCD")#linebreak()#text("have hBCD : B → (C ∨ D) := implies_trans hBD hDCD")#linebreak()#text("have hCD : C ∨ D := Or.elim’ hAB hACD hBCD")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("— We are given (A ∨ B) ∧ (A ∨ C).")#linebreak()#text("— We wish to prove A ∨ (B ∧ C).")#linebreak()#text("theorem or_and_left_rev (hABC : (A ∨ B) ∧ (A ∨ C)) : A ∨ (B ∧ C) := by")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ B (conjunction elimination (left)).")#linebreak()#text("have hAB : A ∨ B := And.left hABC")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ C (conjunction elimination (right)).")#linebreak()#text("have hAC : A ∨ C := And.right hABC")#linebreak()#text("— Introduce A:")#linebreak()#text("have hAABC : A → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("— From A, B ∧ C we deduce A ∨ (B ∧ C) (disjunction introduction (left)).")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.inl hA")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∧ C)).")#linebreak()#text("exact hABC2")#linebreak()#text("— Introduce B:")#linebreak()#text("have hBABC : B → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("— Introduce C:")#linebreak()#text("have hCBC : C → (B ∧ C) := by")#linebreak()#text("intro hC")#linebreak()#text("— From B, C we deduce B ∧ C (conjunction introduction).")#linebreak()#text("have hBC : B ∧ C := And.intro hB hC")#linebreak()#text("— Discharging, we obtain C → (B ∧ C).")#linebreak()#text("exact hBC")#linebreak()#text("— From A ∨ C, C → (B ∧ C) we deduce A ∨ (B ∧ C) (the lemma Or.imp_right’).")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.imp_right’ hAC hCBC")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∧ C)).")#linebreak()#text("exact hABC2")#linebreak()#text("— From A ∨ B, A → (A ∨ (B ∧ C)), B → (A ∨ (B ∧ C)) we deduce A ∨ (B ∧ C) (the lemma Or.elim’).")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.elim’ hAB hAABC hBABC")#linebreak()#text("— This is what we wished to prove. ∎")#linebreak()#text("exact hABC2")

#text("— grimoire-replay v2 6.13 c And.left hABC = (a OR (v A Prop) (v B Prop)) ; c And.right hABC = (a OR (v A Prop) (v C Prop)) ; a (v A Prop) ; c Or.inl hA (a AND (v B Prop) (v C Prop)) = (a OR (v A Prop) (a AND (v B Prop) (v C Prop))) ; d hABC2 1 ; a (v B Prop) ; a (v C Prop) ; c And.intro hB hC = (a AND (v B Prop) (v C Prop)) ; d hBC 1 ; c Or.imp_right’ hAC hCBC = (a OR (v A Prop) (a AND (v B Prop) (v C Prop))) ; d hABC2 1 ; c Or.elim’ hAB hAABC hBABC = (a OR (v A Prop) (a AND (v B Prop) (v C Prop)))")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699349")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A question for clarification: By “game” you mean “deterministic 1-player game”? In that case it might also be called “crafting puzzle” to avoid confusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("A implies A and B?")

#emph[#text("[Oops, forgot to mention that ")#mi("A \\implies B")#text(" is given as a hypothesis for this particular level -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699352")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I played several of the levels. I think the intro tactic is confusing for players who are just being introduced to it as a game, without prior exposure to this sort of tactic in a theorem prover.")

#text("In my opinion, if you want to make it engaging and understandable for people who don’t already understand the material on some level, I would really lean into the visualization. Things should fit together and break apart in a visual/animated way. I am thinking of something like Opus Magnum, if you have seen that game.")

#text("I might treat implications as “recipes”, when you start an intro tactic, it zooms into a scroll depicting a world with the introduced variables added. Then when you are done it zooms back out to show that scroll existing in the real world as an implication. You could show this zoom in and out recursively.")

#text("Just my two cents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699354")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("Thanks for the feedback! I had been following reasonably closely the interface of my previously (manually coded) interactive textbook, which was limited by my ability to work with complex graphics, but I am now realizing that with modern coding agents I can indeed implement more sophisticated animations. I got my agent to create a mockup of how one might animate a level that involves ")#raw("intro")#text(", such as ")#mi("A \\implies A \\wedge A")#text(", by creating a “scroll” one zooms into and out of as you suggest: ")#link("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")[#text("https://claude.ai/artifact/8etb33pyK7MFbX4vPsKDMw")]#text(" . If this seems like a significantly more conceptual type of interface to navigate, I can try to develop it further.")

#text("p.s. my agent also pointed me to the game “")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” that has a similar “zoom in / zoom out” mechanic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699359")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("“")#link("https://www.patricksparabox.com/")[#text("Patrick’s Parabox")]#text("” is interesting. It reminds me of “Sokoban”. there is complexity analysis (NP-hard; PSpace-complete) back in the late 1990s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/161ebc022821268b1c80f6715fa7acfa514968bc9066623550ba9f9edc7055ca-50459a384a3c566d54cd879c52a49550d995fa421d4e8360dd59349761953378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of enchantingsecretlyfc1dc3c400")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699367")[#strong[#text("enchantingsecretlyfc1dc3c400")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Sokoban! Great game")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/161ebc022821268b1c80f6715fa7acfa514968bc9066623550ba9f9edc7055ca-50459a384a3c566d54cd879c52a49550d995fa421d4e8360dd59349761953378.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shawn Hood")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699353")[#strong[#text("Shawn Hood")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I’m not familiar with Lean myself, but have been armchair following some various discussions in mathematical discipline due to the LLM action of late. My son and I would love to play test the Fantasy version and happy to share feedback")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a190384e2d1962e7bf8a57e87c41fdae71e8488202eb4f0c1d8732b6fa7bedb0-8579eeaa773bd1662be7cd243dd9e7d6da105934c6a5acea8eaa1627ea766af2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neunhoef")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699355")[#strong[#text("neunhoef")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("I would recommend to switch on “Explicit Parantheses” by default in the beginning, because then one does not have to know that conjunction binds right associatively in Lean. I got confused for a moment by this.")

#emph[#text("[Now implemented – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52582ede8a5998612e024b8d9b2d998c2df38c0556b73e6e5f4e7e379e0ef205-e01020e5c2c5ba180b5dbbd6559399cfd4ac3050527395cfca30cf59e487d019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699360")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("I love the idea, but perhaps the logic notation (A ^ B) needs more expansion than the logic terms (hypothesis, statements)? The informal presentation of the steps is excellent, and if you had similarly informal ways of expressing the goal and the steps you could take to get there you might connect with a more general audience of players (and from there tempt them into learning the more technical notation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699376")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Thanks for the suggestion! There is now a “Plain English” version for the logical expressions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd8bf3c8c75562ac54bebde0a10d320060702c3d66248d9aae05ff0288669b1-db6a5199b74e557e6890b959866d30c559ceb23327c55ad5dc74eb77f141a626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Daly")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699361")[#strong[#text("Timothy Daly")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("You might want to look at Patrick Massot’s graph of the LEAN theorems.")

#text("I show those that need to be proven. Your game might be an interesting")

#text("student guidance project, especially if they use an LLM to help. The")

#text("students could be proving real theorems while learning")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Check out the comments on Hacker News: ")#link("https://news.ycombinator.com/item?id=50462375")[#text("https://news.ycombinator.com/item?id=50462375")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699363")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Maybe add a “Hint” system? Even knowing istintively why a proposition is true, it is not easy to translate it into Lean procedures.")

#text("On the other hand, you can run an agent and add for each problem what is the minimum possible number of steps for any given problem given the available resources/recipes at the moment. This would add to the challenge for already experienced users that are not satisfied with longer solutions.")

#text("It has always been a dream of mine programming an actual videogame on math, but I barely can scrape time for anything, and not having access to any agent makes it borderline infeasible")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Thanks for the suggestions! Hints have now been added for each level, as well as an explicit count of steps compared against the shortest known solution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699364")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and I just noticed 7.12 is used in previous ones like 7.2")

#emph[#text("[Now re-ordered. Hopefully this should not impact existing saved game states. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699379")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and also I don’t see how to do 13.4 without knowing Pick that is explained later in 14.1")

#emph[#text("[Hint updated on this – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa7002f980bc9f3adff257e08ba0aa57205ecd6048d18584d87e6d4ee2228437-52285627566ef753cc59cb85ca6f216fb6631b1fde677af2e4157bdd39668a8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lovinged57041eed")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699371")[#strong[#text("lovinged57041eed")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Hello Terence.Thank you for sharing your conceptual scheme for “Lean Grimoire”. The name resonates right away.Initial thoughts and observations:- having a conformal analog, a locally “familiar” model,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("This is a very nice idea! Also, all good games for developing visualization, better logical reasoning (like finding reasoning flaws, for example), detecting patterns etc are all very welcome!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699378")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Something that I was telling my students that they have to battle when writing by hand, but they won’t face in the game, is malformed expressions. In the game they could combine recipes and get the wrong goal due to, say parentheses in places that are not those of the real goal. However, I didn’t see a way to obtain malformed expressions.")

#text("Maybe there could be a version of the grimoire that was scribbled over by a wizard apprentice and some recipes are malformed, perhaps deceptively close to other recipes that are well formed. The user still has to use the right ones. Or perhaps, both get to the goal and delete the malformed recipes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699484")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("Thinking about this, I think that *Lean* itself is the correct environment for this “hard mode” version of the game. To this end, I (through my coding agent) have now implemented a “playground” button that takes the current Lean “spellbook” and takes you to the Lean playground, where you can then complete the proof yourself using the full expressive power of Lean. (Of course, many of the exercises can be one-shotted using powerful Lean tactics such as ")#raw("grind")#text(", but presumably a serious student wanting to learn proof technique would eschew such tactics.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Shorter proof for 4.8:")

#text("— Lean Grimoire — exercise 4.8 (And.symm’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 5. THIS ONE IS SHORTER.")

#text("— We wish to prove (A ∧ B) → (B ∧ A).")#linebreak()#text("— Introduce A ∧ B:")#linebreak()#text("— From A ∧ B we deduce B ∧ A (the lemma And.comm’).")#linebreak()#text("— Discharging, we obtain (A ∧ B) → (B ∧ A).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem And.symm’ : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("have hABBA : (A ∧ B) → (B ∧ A) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hBA : B ∧ A := And.comm’ hAB")#linebreak()#text("exact hBA")#linebreak()#text("exact hABBA")

#text("Also, there is a somewhat similar game if anyone is interested:")

#link("https://adam.math.hhu.de/#/g/leanprover-community/nng4")[#text("https://adam.math.hhu.de/#/g/leanprover-community/nng4")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699391")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("That works! I’ve updated the game to record this new proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699385")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("and it would also be very helpful to know how to write statements with forall and exists in the scrolls…. it does not accept \\exists or ∃ or any other variant that I can think of")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("Can you make a linear logic dlc?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/280e4053f2c99fc48d025d37b8e5c097fb942ffddaabc8d3c3e49a32ee0c8073-b8161083f39fb5f211b74368ffde5e9c1646c2c8479436b18b93401eb8ae9012.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PistachioCake")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699392")[#strong[#text("PistachioCake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("A shorter proof for Exercise 2.3!")

#raw("-- Lean Grimoire — exercise 2.3  (And.assoc_right)\n-- https://terrytao.wordpress.com/2026/11/11/lean-grimoire/\n-- Proved in 5 moves.  The shortest proof the game knows takes 6.  THIS ONE IS SHORTER.\n--\n-- We are given A ∧ (B ∧ C).\n-- We wish to prove (A ∧ B) ∧ C.\n-- From A ∧ (B ∧ C) we deduce (B ∧ C) ∧ A  (the lemma And.comm').\n-- From (B ∧ C) ∧ A we deduce B ∧ (C ∧ A)  (the lemma And.assoc_left).\n-- From B ∧ (C ∧ A) we deduce (C ∧ A) ∧ B  (the lemma And.comm').\n-- From (C ∧ A) ∧ B we deduce C ∧ (A ∧ B)  (the lemma And.assoc_left).\n-- From C ∧ (A ∧ B) we deduce (A ∧ B) ∧ C  (the lemma And.comm').\n-- This is what we wished to prove.  ∎\n\n-- Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with\n-- it. 2 of them, each as you proved it, deepest first.\n\n-- 2.1  (And.comm')\nsection\nvariable {A B : Prop}\n\ntheorem And.comm' (hAB : A ∧ B) : B ∧ A := by\n  have hA : A := And.left hAB\n  have hB : B := And.right hAB\n  have hBA : B ∧ A := And.intro hB hA\n  exact hBA\nend\n\n-- 2.2  (And.assoc_left)\nsection\nvariable {A B C : Prop}\n\ntheorem And.assoc_left (hABC : (A ∧ B) ∧ C) : A ∧ (B ∧ C) := by\n  have hAB : A ∧ B := And.left hABC\n  have hA : A := And.left hAB\n  have hB : B := And.right hAB\n  have hC : C := And.right hABC\n  have hBC : B ∧ C := And.intro hB hC\n  have hABC2 : A ∧ (B ∧ C) := And.intro hA hBC\n  exact hABC2\nend\n\n-- and the proof itself:\n\nvariable {A B C : Prop}\n\ntheorem And.assoc_right (hABC : A ∧ (B ∧ C)) : (A ∧ B) ∧ C := by\n  have hBCA : (B ∧ C) ∧ A := And.comm' hABC\n  have hBCA2 : B ∧ (C ∧ A) := And.assoc_left hBCA\n  have hCAB : (C ∧ A) ∧ B := And.comm' hBCA2\n  have hCAB2 : C ∧ (A ∧ B) := And.assoc_left hCAB\n  have hABC2 : (A ∧ B) ∧ C := And.comm' hCAB2\n  exact hABC2\n", block: true)

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("one step proof for Exercise 4.3:")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("— Lean Grimoire — exercise 6.8 (Or.assoc_left)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 14 moves. The shortest proof the game knows takes 17. THIS ONE IS SHORTER.")

#text("— We are given (A ∨ B) ∨ C.")#linebreak()#text("— We wish to prove A ∨ (B ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∨ C we deduce A ∨ (B ∨ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, C we deduce B ∨ C (disjunction introduction (left)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From C, B we deduce B ∨ C (disjunction introduction (right)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∨ C)).")#linebreak()#text("— From A → (A ∨ (B ∨ C)), B → (A ∨ (B ∨ C)) we deduce (A ∨ B) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)), (A ∨ B) ∨ C we deduce A ∨ (B ∨ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by")#linebreak()#text("have hAABC : A → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inl hA")#linebreak()#text("exact hABC2")#linebreak()#text("have hBABC : B → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBC : B ∨ C := Or.inl hB")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hCABC : C → (A ∨ (B ∨ C)) := by")#linebreak()#text("intro hC")#linebreak()#text("have hBC : B ∨ C := Or.inr hC")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text("have hABCABC : ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) := fun h => Or.elim h hABABC hCABC")#linebreak()#text("have hABC2 : A ∨ (B ∨ C) := hABCABC hABC")#linebreak()#text("exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699396")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2026")])]

#text("— Lean Grimoire — exercise 9.7 (not_or_of_imp’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 3 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given A → B.")#linebreak()#text("— We wish to prove (¬ A) ∨ B.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), A → B we deduce B ∨ (¬ A) (the lemma Or.imp_left’).")#linebreak()#text("— From B ∨ (¬ A) we deduce (¬ A) ∨ B (the lemma Or.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : (A ∨ B) → (B ∨ A) := by")#linebreak()#text("have hABA : A → (B ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → (B ∨ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_or_of_imp’ (hAB : A → B) : (¬ A) ∨ B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hBA : B ∨ (¬ A) := Or.imp_left’ hAA hAB")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.comm’ hBA")#linebreak()#text("exact hAB2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efab1854848648e6c4948288f69a4c59799a16b6404b128267d77781fe5736dd-a2561b2000fbb44883fc1cc8398d7ab85870aff1df22756714c8c156b46caf8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699399")[#strong[#text("Jacob")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Shorter proof for 4.3:")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6de08af996f1b13b848c07305d34e8876f7bc6b7a77eb42047dcdc8ac5900725-85b0d5b83f7030bb5c34eb01a958aa331cef9d7e5909f3d107a929253025af54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dario Bajo")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699401")[#strong[#text("Dario Bajo")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Exercise 4.3")

#strong[#text("QED!")]#text(" You brewed ")#emph[#text("((A ∧ B) ∨ C) → ((A ∧ B) ∨ C)")]#text(" in 1 move.🏆 ")#strong[#text("A new record.")]#text(" The shortest proof this game knows takes 2 moves, so you have found something it does not. Please tell me about it: ")#strong[#text("Copy")]#text(" or ")#strong[#text("Save")]#text(" the proof below and leave it in the comments on ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("the blog post")]#text(".")

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("Shorter proof for 2.3 :D")#linebreak()#text("(Tried commenting this earlier, but it didn’t show up… If there’s a duplicate, sorry!)")

#text("— Lean Grimoire — exercise 2.3 (And.assoc_right)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 6. THIS ONE IS SHORTER.")

#text("— We are given A ∧ (B ∧ C).")#linebreak()#text("— We wish to prove (A ∧ B) ∧ C.")#linebreak()#text("— From A ∧ (B ∧ C) we deduce (B ∧ C) ∧ A (the lemma And.comm’).")#linebreak()#text("— From (B ∧ C) ∧ A we deduce B ∧ (C ∧ A) (the lemma And.assoc_left).")#linebreak()#text("— From B ∧ (C ∧ A) we deduce (C ∧ A) ∧ B (the lemma And.comm’).")#linebreak()#text("— From (C ∧ A) ∧ B we deduce C ∧ (A ∧ B) (the lemma And.assoc_left).")#linebreak()#text("— From C ∧ (A ∧ B) we deduce (A ∧ B) ∧ C (the lemma And.comm’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 2.2 (And.assoc_left)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.assoc_left (hABC : (A ∧ B) ∧ C) : A ∧ (B ∧ C) := by")#linebreak()#text("have hC : C := And.right hABC")#linebreak()#text("have hAB : A ∧ B := And.left hABC")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBC : B ∧ C := And.intro hB hC")#linebreak()#text("have hABC2 : A ∧ (B ∧ C) := And.intro hA hBC")#linebreak()#text("exact hABC2")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem And.assoc_right (hABC : A ∧ (B ∧ C)) : (A ∧ B) ∧ C := by")#linebreak()#text("have hBCA : (B ∧ C) ∧ A := And.comm’ hABC")#linebreak()#text("have hBCA2 : B ∧ (C ∧ A) := And.assoc_left hBCA")#linebreak()#text("have hCAB : (C ∧ A) ∧ B := And.comm’ hBCA2")#linebreak()#text("have hCAB2 : C ∧ (A ∧ B) := And.assoc_left hCAB")#linebreak()#text("have hABC2 : (A ∧ B) ∧ C := And.comm’ hCAB2")#linebreak()#text("exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d8743ae0fe0c9a25f7a64cc22f010e4d6e7284961c7cd41c6bef0c04b0afdd-99b1fdce4cbf1d63453450780711acdac96e460d2707765fc440a052f7f99a20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kantian")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699406")[#strong[#text("Kantian")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2026")])]

#text("You advise to post shorter proof if we find one, so here is one")

#text("— Lean Grimoire — exercise 6.8 (Or.assoc_left)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 14 moves. The shortest proof the game knows takes 17. THIS ONE IS SHORTER.")#linebreak()#text("—")#linebreak()#text("— We are given (A ∨ B) ∨ C.")#linebreak()#text("— We wish to prove A ∨ (B ∨ C).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∨ C we deduce A ∨ (B ∨ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∨ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, C we deduce B ∨ C (disjunction introduction (left)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∨ C)).")#linebreak()#text("— From A → (A ∨ (B ∨ C)), B → (A ∨ (B ∨ C)) we deduce (A ∨ B) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— Introduce C:")#linebreak()#text("— From C, B we deduce B ∨ C (disjunction introduction (right)).")#linebreak()#text("— From B ∨ C, A we deduce A ∨ (B ∨ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∨ C)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∨ C)), C → (A ∨ (B ∨ C)) we deduce ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)), (A ∨ B) ∨ C we deduce A ∨ (B ∨ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem Or.assoc_left (hABC : (A ∨ B) ∨ C) : A ∨ (B ∨ C) := by")#linebreak()#text(" have hAABC : A → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hA")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inl hA")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hBABC : B → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hB")#linebreak()#text(" have hBC : B ∨ C := Or.inl hB")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hABABC : (A ∨ B) → (A ∨ (B ∨ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text(" have hCABC : C → (A ∨ (B ∨ C)) := by")#linebreak()#text(" intro hC")#linebreak()#text(" have hBC : B ∨ C := Or.inr hC")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := Or.inr hBC")#linebreak()#text(" exact hABC2")#linebreak()#text(" have hABCABC : ((A ∨ B) ∨ C) → (A ∨ (B ∨ C)) := fun h => Or.elim h hABABC hCABC")#linebreak()#text(" have hABC2 : A ∨ (B ∨ C) := hABCABC hABC")#linebreak()#text(" exact hABC2")

#emph[#text("[Proofs added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699428")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.5")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 11 moves. The shortest proof the game knows takes 14. THIS ONE IS SHORTER.")

#text("— We wish to prove (¬ (∃ X : Ω, P(X))) ↔ (∀ X : Ω, (¬ P(X))).")#linebreak()#text("— Introduce ¬ (∃ x : Ω, P(x)), then an arbitrary X : Ω:")#linebreak()#text("— Introduce P(X):")#linebreak()#text("— From P(X), X we deduce ∃ x : Ω, P(x) (existential introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ P(X).")#linebreak()#text("— Discharging, we obtain (¬ (∃ x : Ω, P(x))) → (∀ X : Ω, (¬ P(X))).")#linebreak()#text("— From (¬ (∃ x : Ω, P(x))) → (∀ X : Ω, (¬ P(X))) we deduce (¬ (¬ (∃ x : Ω, P(x)))) ∨ (∀ X : Ω, (¬ P(X))) (the lemma not_or_of_imp’).")#linebreak()#text("— Introduce ∀ X : Ω, (¬ P(X)):")#linebreak()#text("— From ∀ X : Ω, (¬ P(X)) we deduce ¬ (∃ X : Ω, P(X)) (the lemma forall_not_not_exists).")#linebreak()#text("— Discharging, we obtain (∀ X : Ω, (¬ P(X))) → (¬ (∃ X : Ω, P(X))).")#linebreak()#text("— From (¬ (∃ x : Ω, P(x))) → (∀ X : Ω, (¬ P(X))), (∀ X : Ω, (¬ P(X))) → (¬ (∃ X : Ω, P(X))) we deduce (¬ (∃ x : Ω, P(x))) ↔ (∀ X : Ω, (¬ P(X))) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 16 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hCCD : C → (C ∨ D) := by")#linebreak()#text("intro hC")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hACD : A → (C ∨ D) := implies_trans hAC hCCD")#linebreak()#text("have hDCD : D → (C ∨ D) := by")#linebreak()#text("intro hD")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := implies_trans hBD hDCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.2 (Or.symm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.symm’ : (A ∨ B) → (B ∨ A) := by")#linebreak()#text("have hABA : A → (B ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hBA : B ∨ A := Or.inr hA")#linebreak()#text("exact hBA")#linebreak()#text("have hBBA : B → (B ∨ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hBA : B ∨ A := Or.inl hB")#linebreak()#text("exact hBA")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := fun h => Or.elim h hABA hBBA")#linebreak()#text("exact hABBA")#linebreak()#text("end")

#text("— 6.3 (Or.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem Or.comm’ (hAB : A ∨ B) : B ∨ A := by")#linebreak()#text("have hABBA : (A ∨ B) → (B ∨ A) := Or.symm’")#linebreak()#text("have hBA : B ∨ A := hABBA hAB")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 9.7 (not_or_of_imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem not_or_of_imp’ (hAB : A → B) : (¬ A) ∨ B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hBA : B ∨ (¬ A) := Or.imp_left’ hAA hAB")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.comm’ hBA")#linebreak()#text("exact hAB2")#linebreak()#text("end")

#text("— 6.11 (and_or_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem and_or_left’ (hABC : A ∧ (B ∨ C)) : (A ∧ B) ∨ (A ∧ C) := by")#linebreak()#text("have hA : A := And.left hABC")#linebreak()#text("have hBC : B ∨ C := And.right hABC")#linebreak()#text("have hBAB : B → (A ∧ B) := by")#linebreak()#text("intro hB")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("exact hAB")#linebreak()#text("have hCAC : C → (A ∧ C) := by")#linebreak()#text("intro hC")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("have hABAC : (A ∧ B) ∨ (A ∧ C) := Or.imp’ hBC hBAB hCAC")#linebreak()#text("exact hABAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 2.1 (And.comm’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem And.comm’ (hAB : A ∧ B) : B ∧ A := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : B ∧ A := And.intro hB hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hBA : B ∨ A := Or.comm’ hAB")#linebreak()#text("have hCA : C ∨ A := Or.imp_left’ hBA hBC")#linebreak()#text("have hAC : A ∨ C := Or.comm’ hCA")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.10 (or_and_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem or_and_left’ (hABC : A ∨ (B ∧ C)) : (A ∨ B) ∧ (A ∨ C) := by")#linebreak()#text("have hBCB : (B ∧ C) → B := by")#linebreak()#text("intro hBC")#linebreak()#text("have hB : B := And.left hBC")#linebreak()#text("exact hB")#linebreak()#text("have hAB : A ∨ B := Or.imp_right’ hABC hBCB")#linebreak()#text("have hBCC : (B ∧ C) → C := by")#linebreak()#text("intro hBC")#linebreak()#text("have hC : C := And.right hBC")#linebreak()#text("exact hC")#linebreak()#text("have hAC : A ∨ C := Or.imp_right’ hABC hBCC")#linebreak()#text("have hABAC : (A ∨ B) ∧ (A ∨ C) := And.intro hAB hAC")#linebreak()#text("exact hABAC")#linebreak()#text("end")

#text("— 8.14 (resolution’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem resolution’ (hAB : A ∨ B) (hnAC : (¬ A) ∨ C) : C ∨ B := by")#linebreak()#text("have hABAC : (A ∨ B) ∧ ((¬ A) ∨ C) := And.intro hAB hnAC")#linebreak()#text("have hABAABC : ((A ∨ B) ∧ (¬ A)) ∨ ((A ∨ B) ∧ C) := and_or_left’ hABAC")#linebreak()#text("have hABAB : ((A ∨ B) ∧ (¬ A)) → B := by")#linebreak()#text("intro hABA")#linebreak()#text("have hA : ¬ A := And.right hABA")#linebreak()#text("have hAB2 : A → B := by")#linebreak()#text("intro hA2")#linebreak()#text("have hB : B := absurd hA2 hA")#linebreak()#text("exact hB")#linebreak()#text("have hBB : B ∨ B := Or.imp_left’ hAB hAB2")#linebreak()#text("have hB : B := or_self_elim’ hBB")#linebreak()#text("exact hB")#linebreak()#text("have hBABC : B ∨ ((A ∨ B) ∧ C) := Or.imp_left’ hABAABC hABAB")#linebreak()#text("have hABCCAB : ((A ∨ B) ∧ C) → (C ∧ (A ∨ B)) := by")#linebreak()#text("intro hABC")#linebreak()#text("have hCAB : C ∧ (A ∨ B) := And.comm’ hABC")#linebreak()#text("exact hCAB")#linebreak()#text("have hBCAB : B ∨ (C ∧ (A ∨ B)) := Or.imp_right’ hBABC hABCCAB")#linebreak()#text("have hBCBAB : (B ∨ C) ∧ (B ∨ (A ∨ B)) := or_and_left’ hBCAB")#linebreak()#text("have hBC : B ∨ C := And.left hBCBAB")#linebreak()#text("have hCB : C ∨ B := Or.comm’ hBC")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 9.2 (not_not_elim)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) ∨ A := Or.comm’ hAA")#linebreak()#text("have hAA3 : (¬ (¬ A)) ∨ A := Or.inl hnnA")#linebreak()#text("have hAA4 : A ∨ A := resolution’ hAA2 hAA3")#linebreak()#text("have hA : A := or_self_elim’ hAA4")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 13.4 (forall_not_not_exists)")#linebreak()#text("section")#linebreak()#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")

#text("theorem forall_not_not_exists (hfn : ∀ X : Ω, (¬ P X)) : ¬ (∃ X : Ω, P X) := by")#linebreak()#text("have X : Ω := Classical.choice inferInstance")#linebreak()#text("have hX : ¬ P X := hfn X")#linebreak()#text("have hx : ¬ (¬ (¬ (∃ x : Ω, P x))) := by")#linebreak()#text("intro hx")#linebreak()#text("have hx2 : ∃ x : Ω, P x := not_not_elim hx")#linebreak()#text("have hx3 := hx2")#linebreak()#text("obtain ⟨a, ha⟩ := hx3")#linebreak()#text("have ha2 : ¬ P a := hfn a")#linebreak()#text("exact absurd ha ha2")#linebreak()#text("have hx2 : ¬ (∃ x : Ω, P x) := not_not_elim hx")#linebreak()#text("exact hx2")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")

#text("example : (¬ (∃ X : Ω, P X)) ↔ (∀ X : Ω, (¬ P X)) := by")#linebreak()#text("have hxX : (¬ (∃ x : Ω, P x)) → (∀ X : Ω, (¬ P X)) := by")#linebreak()#text("intro hx")#linebreak()#text("intro X")#linebreak()#text("have hX : ¬ P X := by")#linebreak()#text("intro hX")#linebreak()#text("have hx2 : ∃ x : Ω, P x := ⟨X, hX⟩")#linebreak()#text("exact absurd hx2 hx")#linebreak()#text("exact hX")#linebreak()#text("have hxX2 : (¬ (¬ (∃ x : Ω, P x))) ∨ (∀ X : Ω, (¬ P X)) := not_or_of_imp’ hxX")#linebreak()#text("have hXX : (∀ X : Ω, (¬ P X)) → (¬ (∃ X : Ω, P X)) := by")#linebreak()#text("intro hX")#linebreak()#text("have hX2 : ¬ (∃ X : Ω, P X) := forall_not_not_exists hX")#linebreak()#text("exact hX2")#linebreak()#text("have hxX3 : (¬ (∃ x : Ω, P x)) ↔ (∀ X : Ω, (¬ P X)) := Iff.intro hxX hXX")#linebreak()#text("exact hxX3")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699429")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.6")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 9. THIS ONE IS SHORTER.")

#text("— We are given ¬ (∃ X : Ω, (P(X) ∧ Q(X))), ∀ X : Ω, (R(X) → P(X)).")#linebreak()#text("— We wish to prove ¬ (∃ X : Ω, (R(X) ∧ Q(X))).")#linebreak()#text("— Introduce ∃ X : Ω, (R(X) ∧ Q(X)):")#linebreak()#text("— Since ∃ X : Ω, (R(X) ∧ Q(X)), fix X : Ω with R(X) ∧ Q(X).")#linebreak()#text("— From ∀ X : Ω, (R(X) → P(X)), X we deduce R(X) → P(X) (universal instantiation (specialization)).")#linebreak()#text("— From R(X) ∧ Q(X), R(X) → P(X) we deduce P(X) ∧ Q(X) (the lemma And.imp_left’).")#linebreak()#text("— From P(X) ∧ Q(X), X we deduce ∃ x : Ω, (P(x) ∧ Q(x)) (existential introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (∃ X : Ω, (R(X) ∧ Q(X))).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.8 (And.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_left’ (hAB : A ∧ B) (hAC : A → C) : C ∧ B := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hCB : C ∧ B := And.intro hC hB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hnpq : ¬ (∃ X : Ω, (P X ∧ Q X))) (hRP : ∀ X : Ω, (R X → P X)) : ¬ (∃ X : Ω, (R X ∧ Q X)) := by")#linebreak()#text("have hXX : ¬ (∃ X : Ω, (R X ∧ Q X)) := by")#linebreak()#text("intro hXX")#linebreak()#text("have hXX3 := hXX")#linebreak()#text("obtain ⟨X, hXX2⟩ := hXX3")#linebreak()#text("have hXX3 : R X → P X := hRP X")#linebreak()#text("have hXX4 : P X ∧ Q X := And.imp_left’ hXX2 hXX3")#linebreak()#text("have hxx : ∃ x : Ω, (P x ∧ Q x) := ⟨X, hXX4⟩")#linebreak()#text("exact absurd hxx hnpq")#linebreak()#text("exact hXX")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699430")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.7")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 4 moves. The shortest proof the game knows takes 7. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → Q(X)), ∃ X : Ω, (R(X) ∧ P(X)).")#linebreak()#text("— We wish to prove ∃ X : Ω, (R(X) ∧ Q(X)).")#linebreak()#text("— Since ∃ X : Ω, (R(X) ∧ P(X)), fix X : Ω with R(X) ∧ P(X).")#linebreak()#text("— From ∀ X : Ω, (P(X) → Q(X)), X we deduce P(X) → Q(X) (universal instantiation (specialization)).")#linebreak()#text("— From R(X) ∧ P(X), P(X) → Q(X) we deduce R(X) ∧ Q(X) (the lemma And.imp_right’).")#linebreak()#text("— From R(X) ∧ Q(X), X we deduce ∃ x : Ω, (R(x) ∧ Q(x)) (existential introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.9 (And.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_right’ (hAB : A ∧ B) (hBC : B → C) : A ∧ C := by")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ P X)) : ∃ X : Ω, (R X ∧ Q X) := by")#linebreak()#text("have hXX2 := hex")#linebreak()#text("obtain ⟨X, hXX⟩ := hXX2")#linebreak()#text("have hXX2 : P X → Q X := hPQ X")#linebreak()#text("have hXX3 : R X ∧ Q X := And.imp_right’ hXX hXX2")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ Q x) := ⟨X, hXX3⟩")#linebreak()#text("exact hxx")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699431")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.15")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → Q(X)), ∃ X : Ω, (R(X) ∧ (¬ Q(X))).")#linebreak()#text("— We wish to prove ∃ X : Ω, (R(X) ∧ (¬ P(X))).")#linebreak()#text("— Since ∃ X : Ω, (R(X) ∧ (¬ Q(X))), fix X : Ω with R(X) ∧ (¬ Q(X)).")#linebreak()#text("— From ∀ X : Ω, (P(X) → Q(X)), X we deduce P(X) → Q(X) (universal instantiation (specialization)).")#linebreak()#text("— From P(X) → Q(X) we deduce (¬ Q(X)) → (¬ P(X)) (the lemma mt’).")#linebreak()#text("— From R(X) ∧ (¬ Q(X)), (¬ Q(X)) → (¬ P(X)) we deduce R(X) ∧ (¬ P(X)) (the lemma And.imp_right’).")#linebreak()#text("— From R(X) ∧ (¬ P(X)), X we deduce ∃ x : Ω, (R(x) ∧ (¬ P(x))) (existential introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 5.9 (And.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_right’ (hAB : A ∧ B) (hBC : B → C) : A ∧ C := by")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("have hAC : A ∧ C := And.intro hA hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hPQ : ∀ X : Ω, (P X → Q X)) (hex : ∃ X : Ω, (R X ∧ (¬ Q X))) : ∃ X : Ω, (R X ∧ (¬ P X)) := by")#linebreak()#text("have hXX2 := hex")#linebreak()#text("obtain ⟨X, hXX⟩ := hXX2")#linebreak()#text("have hXX2 : P X → Q X := hPQ X")#linebreak()#text("have hXX3 : (¬ Q X) → (¬ P X) := mt’ hXX2")#linebreak()#text("have hXX4 : R X ∧ (¬ P X) := And.imp_right’ hXX hXX3")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ (¬ P x)) := ⟨X, hXX4⟩")#linebreak()#text("exact hxx")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699432")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 15.16")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 4 moves. The shortest proof the game knows takes 7. THIS ONE IS SHORTER.")

#text("— We are given ∃ X : Ω, (P(X) ∧ (¬ Q(X))), ∀ X : Ω, (P(X) → R(X)).")#linebreak()#text("— We wish to prove ∃ X : Ω, (R(X) ∧ (¬ Q(X))).")#linebreak()#text("— Since ∃ X : Ω, (P(X) ∧ (¬ Q(X))), fix X : Ω with P(X) ∧ (¬ Q(X)).")#linebreak()#text("— From ∀ X : Ω, (P(X) → R(X)), X we deduce P(X) → R(X) (universal instantiation (specialization)).")#linebreak()#text("— From P(X) ∧ (¬ Q(X)), P(X) → R(X) we deduce R(X) ∧ (¬ Q(X)) (the lemma And.imp_left’).")#linebreak()#text("— From R(X) ∧ (¬ Q(X)), X we deduce ∃ x : Ω, (R(x) ∧ (¬ Q(x))) (existential introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.8 (And.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem And.imp_left’ (hAB : A ∧ B) (hAC : A → C) : C ∧ B := by")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hCB : C ∧ B := And.intro hC hB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {Q : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")

#text("example (hex : ∃ X : Ω, (P X ∧ (¬ Q X))) (hPR : ∀ X : Ω, (P X → R X)) : ∃ X : Ω, (R X ∧ (¬ Q X)) := by")#linebreak()#text("have hXX2 := hex")#linebreak()#text("obtain ⟨X, hXX⟩ := hXX2")#linebreak()#text("have hXX2 : P X → R X := hPR X")#linebreak()#text("have hXX3 : R X ∧ (¬ Q X) := And.imp_left’ hXX hXX2")#linebreak()#text("have hxx : ∃ x : Ω, (R x ∧ (¬ Q x)) := ⟨X, hXX3⟩")#linebreak()#text("exact hxx")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e372460a3a26757281057a395c7e66456f038010351f4e2a1ceb1198493c1ed1-ba931ad95242b0cb0d487d259c2875efe8bc2044b8e573b6a288e46eeaf0f055.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Barbarino")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699433")[#strong[#text("Giovanni Barbarino")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("In Exercise 16.1, trying to introduce X : Set, it instead introduces X : \\Omega, so following the hints gets you to a wrong solution")

#emph[#text("[Now fixed, hopefully – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699439")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2026")])]

#text("— Lean Grimoire — exercise 7.4 (Iff.refl’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We wish to prove A ↔ A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From A → A, A → A we deduce A ↔ A (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem Iff.refl’ : A ↔ A := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAA2 : A ↔ A := Iff.intro hAA hAA")#linebreak()#text("exact hAA2")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699450")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2026")])]

#text("If this is going to be hosted, perhaps it could automatically accept and integrate shorter proofs for exercises, since they can be verified? Adding them manually will not scale well. (Perhaps it could also record multiple known proofs of various lengths and say if they’re known to it – though that’s getting into territory where you’d an agent to try to decide if it was really “new” for anything that isn’t super short)")

#emph[#text("[The game is not hosted right now (to avoid various security/privacy/cost issues), but I have implemented a streamlining of the reporting process -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96cd159cba9b8645acb676fd46ad3f5324a0d34780dfd4efaeb11538bbe5264a-1253958c83b482d3d0fdf4c302c8b082789c9abd8a4a85078f0ce09b2efee4a8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ram Anvesh Reddy")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699454")[#strong[#text("Ram Anvesh Reddy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2026")])]

#text("— Lean Grimoire — exercise 4.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C).")#linebreak()#text("— From (A ∧ B) ∨ C we deduce ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("example : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := by")#linebreak()#text("have hABCABC : ((A ∧ B) ∨ C) → ((A ∧ B) ∨ C) := Impl.idem")#linebreak()#text("exact hABCABC")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("Two shorter proofs.")

#text("— Lean Grimoire — exercise 12.3")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 5 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ∀ X : Ω, (P(X) → R(X)), ∀ X : Ω, (S(X) → P(X)).")#linebreak()#text("— We wish to prove ∀ X : Ω, (S(X) → R(X)).")#linebreak()#text("— Introduce an arbitrary X : Ω:")#linebreak()#text("— From ∀ X : Ω, (S(X) → P(X)), X we deduce S(X) → P(X) (universal instantiation (specialization)).")#linebreak()#text("— From ∀ X : Ω, (P(X) → R(X)), X we deduce P(X) → R(X) (universal instantiation (specialization)).")#linebreak()#text("— From S(X) → P(X), P(X) → R(X) we deduce S(X) → R(X) (the lemma implies_trans).")#linebreak()#text("— Discharging, we obtain ∀ X : Ω, (S(X) → R(X)).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 5.2 (implies_trans)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem implies_trans (hAB : A → B) (hBC : B → C) : A → C := by")#linebreak()#text("have hAC : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hB : B := hAB hA")#linebreak()#text("have hC : C := hBC hB")#linebreak()#text("exact hC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {P : Ω → Prop}")#linebreak()#text("variable {R : Ω → Prop}")#linebreak()#text("variable {S : Ω → Prop}")

#text("example (hpr : ∀ X : Ω, (P X → R X)) (hsp : ∀ X : Ω, (S X → P X)) : ∀ X : Ω, (S X → R X) := by")#linebreak()#text("have hXX : ∀ X : Ω, (S X → R X) := by")#linebreak()#text("intro X")#linebreak()#text("have hXX : S X → P X := hsp X")#linebreak()#text("have hXX2 : P X → R X := hpr X")#linebreak()#text("have hXX3 : S X → R X := implies_trans hXX hXX2")#linebreak()#text("exact hXX3")#linebreak()#text("exact hXX")

#text("— Lean Grimoire — exercise 9.2 (not_not_elim)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 7 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ¬ (¬ A).")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From ¬ A, ¬ (¬ A), A we deduce A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ A) → A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From A → A, (¬ A) → A we deduce (A ∨ (¬ A)) → A (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ (¬ A)) → A, A ∨ (¬ A) we deduce A (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : A → A := Impl.idem")#linebreak()#text("have hAAA : (A ∨ (¬ A)) → A := fun h => Or.elim h hAA3 hAA2")#linebreak()#text("have hA : A := hAAA hAA")#linebreak()#text("exact hA")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#enum(start: 1, 
[#text("Thank you for the nice game. For me it proved to be quite addictive. There are a couple of bugs in the Lean Gimoire in the later levels.")]
)

#text("In Exercise 16.1 if one introduces X : Set, it actually introduces X : Omega, which breaks things. I was able to patch it on the JavaScript console using the following snippet (LLM generated):")

#text("(() => {")#linebreak()#text("const game = window.__grimoire;")#linebreak()#text("const original = game.G.openVariable;")

#text("game.G.openVariable = (env, v) => {")#linebreak()#text("const term = game.state.terms.find(")#linebreak()#text("t => t.tag === “var” && t.name === v.name")#linebreak()#text(");")

#raw("return original(env, {\n  ...v,\n  sort: term?.sort ?? v.sort\n});\n", block: true)

#text("};")

#text("console.log(“Variable sort bug patched!”);")#linebreak()#text("})();")

#emph[#text("[Now fixed, hopefully – T.]")]

#text("2. In Exercise 17.3, I got “unexpected character “*”” when entering f(c) * c on the term bench. Apparently the Lean Grimoire expects the Unicode symbol ∗ (U+2217), not the ordinary asterisk * (U+002A).")

#emph[#text("[Now fixed, hopefully – T.]")]

#text("3. When solving Exercise 18.9, I managed to slow down Firefox to a crawl. My solution was apparently far from optimal, but it did work in Chromium. (Not sure where the problem is, but this affect other people as well.)")

#emph[#text("[This may possibly be due to the savefile bug, so the fix implemented below may also address this issue – T.]")]

#text("4. The saved progress got somehow messed up for me. It forgot to record some solutions. I had a look at the data in Local Storage under the key grimoire.v2. The stored json string is 5.1 Mbyte for me, which seems large. The biggest junk of the data is apparently the progress stored for Exercise 6.13. Maybe I did something stupid there, maybe it got corrupted during an update.")#linebreak()#text("(Not sure where the problem is, but this affect other people as well.)")

#emph[#text("[The save file format was excessively bloated. This should now be fixed. – T.]")]

#text("5. Suppose one unlocks all problems, selects an unsolved problem and makes a bit of progress. If one then reloads the page, for me it jumps back to Exercise 1.1 and the problems are locked again. This does not seem like the intuitive/expected behaviour.")

#emph[#text("[Unlock is now persistent – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c44df296f4245adf3d3caeb19f2749a1d210cafa2769aff6f0ec6bd2d21c4341-3c12c69ecb80d93a22eea9bf7410efc77094096e0a2354c6e071b51ead8d9bbe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex P")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699468")[#strong[#text("Alex P")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("To be honest, I don’t really follow the interface at a glance. Maybe I’m missing something obvious. I think it needs to hold my hand a bit more.")

#text("I also find the fantasy mode distracting and would prefer it was not the default.")

#text("I would say the audience for this is not people who completely new to logic or programs such as these, but someone more advanced.")

#text("There needs to be a lot more hand holding for someone coming from a less familiar background such as mine.")

#text("ex: Starting with very first principles, interactively, and introducing components of the UI/UX and their effects one step at a time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699472")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 6.13 (or_and_left_rev)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 15 moves. The shortest proof the game knows takes 18. THIS ONE IS SHORTER.")

#text("— We are given (A ∨ B) ∧ (A ∨ C).")#linebreak()#text("— We wish to prove A ∨ (B ∧ C).")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ B (conjunction elimination (left)).")#linebreak()#text("— From (A ∨ B) ∧ (A ∨ C) we deduce A ∨ C (conjunction elimination (right)).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B ∧ C we deduce A ∨ (B ∧ C) (disjunction introduction (left)).")#linebreak()#text("— Discharging, we obtain A → (A ∨ (B ∧ C)).")#linebreak()#text("— Introduce B:")#linebreak()#text("— Introduce C:")#linebreak()#text("— From B, C we deduce B ∧ C (conjunction introduction).")#linebreak()#text("— From B ∧ C, A we deduce A ∨ (B ∧ C) (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain C → (A ∨ (B ∧ C)).")#linebreak()#text("— From A → (A ∨ (B ∧ C)), C → (A ∨ (B ∧ C)) we deduce (A ∨ C) → (A ∨ (B ∧ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ C) → (A ∨ (B ∧ C)), A ∨ C we deduce A ∨ (B ∧ C) (modus ponens).")#linebreak()#text("— Discharging, we obtain B → (A ∨ (B ∧ C)).")#linebreak()#text("— From A → (A ∨ (B ∧ C)), B → (A ∨ (B ∧ C)) we deduce (A ∨ B) → (A ∨ (B ∧ C)) (case analysis (disjunction elimination)).")#linebreak()#text("— From (A ∨ B) → (A ∨ (B ∧ C)), A ∨ B we deduce A ∨ (B ∧ C) (modus ponens).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A B C : Prop}")

#text("theorem or_and_left_rev (hABC : (A ∨ B) ∧ (A ∨ C)) : A ∨ (B ∧ C) := by")#linebreak()#text("have hAB : A ∨ B := And.left hABC")#linebreak()#text("have hAC : A ∨ C := And.right hABC")#linebreak()#text("have hAABC : A → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hA")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.inl hA")#linebreak()#text("exact hABC2")#linebreak()#text("have hBABC : B → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hB")#linebreak()#text("have hCABC : C → (A ∨ (B ∧ C)) := by")#linebreak()#text("intro hC")#linebreak()#text("have hBC : B ∧ C := And.intro hB hC")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := Or.inr hBC")#linebreak()#text("exact hABC2")#linebreak()#text("have hACABC : (A ∨ C) → (A ∨ (B ∧ C)) := fun h => Or.elim h hAABC hCABC")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := hACABC hAC")#linebreak()#text("exact hABC2")#linebreak()#text("have hABABC : (A ∨ B) → (A ∨ (B ∧ C)) := fun h => Or.elim h hAABC hBABC")#linebreak()#text("have hABC2 : A ∨ (B ∧ C) := hABABC hAB")#linebreak()#text("exact hABC2")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699473")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 7.4 (Iff.refl’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We wish to prove A ↔ A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From A → A, A → A we deduce A ↔ A (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem Iff.refl’ : A ↔ A := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAA2 : A ↔ A := Iff.intro hAA hAA")#linebreak()#text("exact hAA2")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699474")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 7.6 (Or.congr_left’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 4 moves. The shortest proof the game knows takes 9. THIS ONE IS SHORTER.")

#text("— We are given A ∨ B, A ↔ C.")#linebreak()#text("— We wish to prove C ∨ B.")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A ↔ C, A we deduce C (iff elimination (forward)).")#linebreak()#text("— Discharging, we obtain A → C.")#linebreak()#text("— From A ∨ B, A → C we deduce C ∨ B (the lemma Or.imp_left’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 3 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B C : Prop}")

#text("theorem Or.congr_left’ (hAB : A ∨ B) (hAC : A ↔ C) : C ∨ B := by")#linebreak()#text("have hAC2 : A → C := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC.mp hA")#linebreak()#text("exact hC")#linebreak()#text("have hCB : C ∨ B := Or.imp_left’ hAB hAC2")#linebreak()#text("exact hCB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699475")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.8 (not_or_intro’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 9 moves. The shortest proof the game knows takes 11. THIS ONE IS SHORTER.")

#text("— We are given (¬ A) ∧ (¬ B).")#linebreak()#text("— We wish to prove ¬ (A ∨ B).")#linebreak()#text("— From (¬ A) ∧ (¬ B) we deduce ¬ A (conjunction elimination (left)).")#linebreak()#text("— From (¬ A) ∧ (¬ B) we deduce ¬ B (conjunction elimination (right)).")#linebreak()#text("— Introduce A ∨ B:")#linebreak()#text("— Introduce B:")#linebreak()#text("— From B, ¬ B, A we deduce A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain B → A.")#linebreak()#text("— From A ∨ B, B → A we deduce A ∨ A (the lemma Or.imp_right’).")#linebreak()#text("— From A ∨ A we deduce A (the lemma or_self_elim’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (A ∨ B).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_or_intro’ (hnAnB : (¬ A) ∧ (¬ B)) : ¬ (A ∨ B) := by")#linebreak()#text("have hA : ¬ A := And.left hnAnB")#linebreak()#text("have hB : ¬ B := And.right hnAnB")#linebreak()#text("have hAB : ¬ (A ∨ B) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hBA : B → A := by")#linebreak()#text("intro hB2")#linebreak()#text("have hA2 : A := absurd hB2 hB")#linebreak()#text("exact hA2")#linebreak()#text("have hAA : A ∨ A := Or.imp_right’ hAB hBA")#linebreak()#text("have hA2 : A := or_self_elim’ hAA")#linebreak()#text("exact absurd hA2 hA")#linebreak()#text("exact hAB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699476")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.9 (not_and_of_not_or’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 9 moves. The shortest proof the game knows takes 11. THIS ONE IS SHORTER.")

#text("— We are given (¬ A) ∨ (¬ B).")#linebreak()#text("— We wish to prove ¬ (A ∧ B).")#linebreak()#text("— Introduce A ∧ B:")#linebreak()#text("— From A ∧ B we deduce A (conjunction elimination (left)).")#linebreak()#text("— From A ∧ B we deduce B (conjunction elimination (right)).")#linebreak()#text("— Introduce ¬ B:")#linebreak()#text("— From B, ¬ B, ¬ A we deduce ¬ A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ B) → (¬ A).")#linebreak()#text("— From (¬ A) ∨ (¬ B), (¬ B) → (¬ A) we deduce (¬ A) ∨ (¬ A) (the lemma Or.imp_right’).")#linebreak()#text("— From (¬ A) ∨ (¬ A) we deduce ¬ A (the lemma or_self_elim’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (A ∧ B).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_and_of_not_or’ (hnAonB : (¬ A) ∨ (¬ B)) : ¬ (A ∧ B) := by")#linebreak()#text("have hAB : ¬ (A ∧ B) := by")#linebreak()#text("intro hAB")#linebreak()#text("have hA : A := And.left hAB")#linebreak()#text("have hB : B := And.right hAB")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB2")#linebreak()#text("have hA2 : ¬ A := absurd hB hB2")#linebreak()#text("exact hA2")#linebreak()#text("have hAA : (¬ A) ∨ (¬ A) := Or.imp_right’ hnAonB hBA")#linebreak()#text("have hA2 : ¬ A := or_self_elim’ hAA")#linebreak()#text("exact absurd hA hA2")#linebreak()#text("exact hAB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699477")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.13 (not_of_imp_not’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We are given A → (¬ B), B.")#linebreak()#text("— We wish to prove ¬ A.")#linebreak()#text("— From B we deduce ¬ (¬ B) (the lemma not_not_intro’).")#linebreak()#text("— From A → (¬ B), ¬ (¬ B) we deduce ¬ A (the lemma mt_apply’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 3 of them, each as you proved it, deepest first.")

#text("— 8.3 (not_not_intro’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_intro’ (hA : A) : ¬ (¬ A) := by")#linebreak()#text("have hA2 : ¬ (¬ A) := by")#linebreak()#text("intro hA2")#linebreak()#text("exact absurd hA hA2")#linebreak()#text("exact hA2")#linebreak()#text("end")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 8.11 (mt_apply’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt_apply’ (hAB : A → B) (hnB : ¬ B) : ¬ A := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := mt’ hAB")#linebreak()#text("have hA : ¬ A := hBA hnB")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_of_imp_not’ (hAnB : A → (¬ B)) (hB : B) : ¬ A := by")#linebreak()#text("have hB2 : ¬ (¬ B) := not_not_intro’ hB")#linebreak()#text("have hA : ¬ A := mt_apply’ hAnB hB2")#linebreak()#text("exact hA")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699478")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 8.15 (not_iff_imp_false)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 10 moves. The shortest proof the game knows takes 11. THIS ONE IS SHORTER.")

#text("— We wish to prove (¬ A) ↔ (A → False).")#linebreak()#text("— Introduce ¬ A, then A:")#linebreak()#text("— From A, ¬ A, False we deduce False (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ A) → (A → False).")#linebreak()#text("— Introduce A → False:")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A → False, A we deduce False (modus ponens).")#linebreak()#text("— This is a contradiction, so we conclude ¬ A.")#linebreak()#text("— Discharging, we obtain (A → False) → (¬ A).")#linebreak()#text("— From (¬ A) → (A → False), (A → False) → (¬ A) we deduce (¬ A) ↔ (A → False) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("variable {A : Prop}")

#text("theorem not_iff_imp_false : (¬ A) ↔ (A → False) := by")#linebreak()#text("have hAA : (¬ A) → (A → False) := by")#linebreak()#text("intro hA")#linebreak()#text("intro hA2")#linebreak()#text("have h : False := absurd hA2 hA")#linebreak()#text("exact h")#linebreak()#text("have hAA2 : (A → False) → (¬ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : ¬ A := by")#linebreak()#text("intro hA2")#linebreak()#text("have h : False := hA hA2")#linebreak()#text("exact h")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : (¬ A) ↔ (A → False) := Iff.intro hAA hAA2")#linebreak()#text("exact hAA3")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699479")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 9.2 (not_not_elim)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given ¬ (¬ A).")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From ¬ A, ¬ (¬ A), A we deduce A (from a contradiction, anything).")#linebreak()#text("— Discharging, we obtain (¬ A) → A.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), (¬ A) → A we deduce A ∨ A (the lemma Or.imp_right’).")#linebreak()#text("— From A ∨ A we deduce A (the lemma or_self_elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 5 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.7 (Or.imp_right’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_right’ (hAB : A ∨ B) (hBC : B → C) : A ∨ C := by")#linebreak()#text("have hAA : A → A := Impl.idem")#linebreak()#text("have hAC : A ∨ C := Or.imp’ hAB hAA hBC")#linebreak()#text("exact hAC")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA2 : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA3 : A ∨ A := Or.imp_right’ hAA2 hAA")#linebreak()#text("have hA : A := or_self_elim’ hAA3")#linebreak()#text("exact hA")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe13968684a0b9066f3e3ca03b9b06ba6b33200ba5a296fc44986bd1d72a3d45-b57d64c71a6a981570ad92425876967d7ed9894c1b5ab9695122ffeaa3c4aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwq zty")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699480")[#strong[#text("qwq zty")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2026")])]

#text("— Lean Grimoire — exercise 9.3 (by_cases’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 2 moves. The shortest proof the game knows takes 3. THIS ONE IS SHORTER.")

#text("— We are given A → B, (¬ A) → B.")#linebreak()#text("— We wish to prove B.")#linebreak()#text("— From A we deduce A ∨ (¬ A) (the law of the excluded middle).")#linebreak()#text("— From A ∨ (¬ A), A → B, (¬ A) → B we deduce B (the lemma Or.elim’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem by_cases’ (hAB : A → B) (hnAB : (¬ A) → B) : B := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hB : B := Or.elim’ hAA hAB hnAB")#linebreak()#text("exact hB")

#emph[#text("[New solution added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699493")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 9.6 (not_and_or’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 7 moves. The shortest proof the game knows takes 10. THIS ONE IS SHORTER.")

#text("— We are given ¬ (A ∧ B).")#linebreak()#text("— We wish to prove (¬ A) ∨ (¬ B).")#linebreak()#text("— Introduce B:")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, B we deduce A ∧ B (conjunction introduction).")#linebreak()#text("— This is a contradiction, so we conclude ¬ A.")#linebreak()#text("— Discharging, we obtain B → (¬ A).")#linebreak()#text("— From B we deduce B ∨ (¬ B) (the law of the excluded middle).")#linebreak()#text("— From B ∨ (¬ B), B → (¬ A) we deduce (¬ A) ∨ (¬ B) (the lemma Or.imp_left’).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 3 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem not_and_or’ (hnAB : ¬ (A ∧ B)) : (¬ A) ∨ (¬ B) := by")#linebreak()#text("have hBA : B → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : A ∧ B := And.intro hA hB")#linebreak()#text("exact absurd hAB hnAB")#linebreak()#text("exact hA")#linebreak()#text("have hBB : B ∨ (¬ B) := Classical.em (B)")#linebreak()#text("have hAB : (¬ A) ∨ (¬ B) := Or.imp_left’ hBB hBA")#linebreak()#text("exact hAB")

#text("— grimoire-replay v1 9.6 W1siYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIkFuZC5pbnRybyIsWyJoQSIsImhCIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJBTkQiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbIm4iLCJoQUIiLCJobkFCIl0sWyJkIiwiaEEiLDFdLFsiYyIsIkNsYXNzaWNhbC5lbSIsW3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmltcF9sZWZ0JyIsWyJoQkIiLCJoQkEiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiTk9UIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699494")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 9.10 (peirce_law’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given (A → B) → A.")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From (A → B) → A, ¬ A we deduce ¬ (A → B) (the lemma mt_apply’).")#linebreak()#text("— From ¬ A, B we deduce (¬ A) ∨ B (disjunction introduction (left)).")#linebreak()#text("— From (¬ A) ∨ B we deduce A → B (the lemma imp_of_not_or’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (¬ A).")#linebreak()#text("— From ¬ (¬ A) we deduce A (the lemma not_not_elim).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 9 of them, each as you proved it, deepest first.")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 8.11 (mt_apply’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt_apply’ (hAB : A → B) (hnB : ¬ B) : ¬ A := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := mt’ hAB")#linebreak()#text("have hA : ¬ A := hBA hnB")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 8.10 (imp_of_not_or’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem imp_of_not_or’ (hnAB : (¬ A) ∨ B) : A → B := by")#linebreak()#text("have hAB : A → B := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : (¬ A) → B := by")#linebreak()#text("intro hA2")#linebreak()#text("have hB : B := absurd hA hA2")#linebreak()#text("exact hB")#linebreak()#text("have hBB : B ∨ B := Or.imp_left’ hnAB hAB")#linebreak()#text("have hB : B := or_self_elim’ hBB")#linebreak()#text("exact hB")#linebreak()#text("exact hAB")#linebreak()#text("end")

#text("— 9.2 (not_not_elim)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA3 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem peirce_law’ (hPA : (A → B) → A) : A := by")#linebreak()#text("have hA : ¬ (¬ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : ¬ (A → B) := mt_apply’ hPA hA")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.inl hA")#linebreak()#text("have hAB3 : A → B := imp_of_not_or’ hAB2")#linebreak()#text("exact absurd hAB3 hAB")#linebreak()#text("have hA2 : A := not_not_elim hA")#linebreak()#text("exact hA2")

#text("— grimoire-replay v1 9.10 W1siYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJtdF9hcHBseSciLFsiaFBBIiwiaEEiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IklNUExJRVMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5sIixbImhBIix7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJpbXBfb2Zfbm90X29yJyIsWyJoQUIyIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJuIiwiaEFCMyIsImhBQiJdLFsiYyIsIm5vdF9ub3RfZWxpbSIsWyJoQSJdLHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699495")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 9.10 (peirce_law’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 6 moves. The shortest proof the game knows takes 8. THIS ONE IS SHORTER.")

#text("— We are given (A → B) → A.")#linebreak()#text("— We wish to prove A.")#linebreak()#text("— Introduce ¬ A:")#linebreak()#text("— From (A → B) → A, ¬ A we deduce ¬ (A → B) (the lemma mt_apply’).")#linebreak()#text("— From ¬ A, B we deduce (¬ A) ∨ B (disjunction introduction (left)).")#linebreak()#text("— From (¬ A) ∨ B we deduce A → B (the lemma imp_of_not_or’).")#linebreak()#text("— This is a contradiction, so we conclude ¬ (¬ A).")#linebreak()#text("— From ¬ (¬ A) we deduce A (the lemma not_not_elim).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 9 of them, each as you proved it, deepest first.")

#text("— 8.4 (mt’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt’ (hAB : A → B) : (¬ B) → (¬ A) := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := by")#linebreak()#text("intro hB")#linebreak()#text("have hA : ¬ A := by")#linebreak()#text("intro hA")#linebreak()#text("have hB2 : B := hAB hA")#linebreak()#text("exact absurd hB2 hB")#linebreak()#text("exact hA")#linebreak()#text("exact hBA")#linebreak()#text("end")

#text("— 8.11 (mt_apply’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem mt_apply’ (hAB : A → B) (hnB : ¬ B) : ¬ A := by")#linebreak()#text("have hBA : (¬ B) → (¬ A) := mt’ hAB")#linebreak()#text("have hA : ¬ A := hBA hnB")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.5 (Or.imp’)")#linebreak()#text("section")#linebreak()#text("variable {A B C D : Prop}")

#text("theorem Or.imp’ (hAB : A ∨ B) (hAC : A → C) (hBD : B → D) : C ∨ D := by")#linebreak()#text("have hACD : A → (C ∨ D) := by")#linebreak()#text("intro hA")#linebreak()#text("have hC : C := hAC hA")#linebreak()#text("have hCD : C ∨ D := Or.inl hC")#linebreak()#text("exact hCD")#linebreak()#text("have hBCD : B → (C ∨ D) := by")#linebreak()#text("intro hB")#linebreak()#text("have hD : D := hBD hB")#linebreak()#text("have hCD : C ∨ D := Or.inr hD")#linebreak()#text("exact hCD")#linebreak()#text("have hABCD : (A ∨ B) → (C ∨ D) := fun h => Or.elim h hACD hBCD")#linebreak()#text("have hCD : C ∨ D := hABCD hAB")#linebreak()#text("exact hCD")#linebreak()#text("end")

#text("— 6.6 (Or.imp_left’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.imp_left’ (hAB : A ∨ B) (hAC : A → C) : C ∨ B := by")#linebreak()#text("have hBB : B → B := Impl.idem")#linebreak()#text("have hCB : C ∨ B := Or.imp’ hAB hAC hBB")#linebreak()#text("exact hCB")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— 6.14 (or_self_elim’)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem or_self_elim’ (hAA : A ∨ A) : A := by")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA2 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— 8.10 (imp_of_not_or’)")#linebreak()#text("section")#linebreak()#text("variable {A B : Prop}")

#text("theorem imp_of_not_or’ (hnAB : (¬ A) ∨ B) : A → B := by")#linebreak()#text("have hAB : A → B := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : (¬ A) → B := by")#linebreak()#text("intro hA2")#linebreak()#text("have hB : B := absurd hA hA2")#linebreak()#text("exact hB")#linebreak()#text("have hBB : B ∨ B := Or.imp_left’ hnAB hAB")#linebreak()#text("have hB : B := or_self_elim’ hBB")#linebreak()#text("exact hB")#linebreak()#text("exact hAB")#linebreak()#text("end")

#text("— 9.2 (not_not_elim)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem not_not_elim (hnnA : ¬ (¬ A)) : A := by")#linebreak()#text("have hAA : A ∨ (¬ A) := Classical.em (A)")#linebreak()#text("have hAA2 : (¬ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : A := absurd hA hnnA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA3 : A → A := Impl.idem")#linebreak()#text("have hA : A := Or.elim’ hAA hAA3 hAA2")#linebreak()#text("exact hA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A B : Prop}")

#text("theorem peirce_law’ (hPA : (A → B) → A) : A := by")#linebreak()#text("have hA : ¬ (¬ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hAB : ¬ (A → B) := mt_apply’ hPA hA")#linebreak()#text("have hAB2 : (¬ A) ∨ B := Or.inl hA")#linebreak()#text("have hAB3 : A → B := imp_of_not_or’ hAB2")#linebreak()#text("exact absurd hAB3 hAB")#linebreak()#text("have hA2 : A := not_not_elim hA")#linebreak()#text("exact hA2")

#text("— grimoire-replay v1 9.10 W1siYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJOT1QiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJtdF9hcHBseSciLFsiaFBBIiwiaEEiXSx7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6IklNUExJRVMiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuaW5sIixbImhBIix7InRhZyI6InZhciIsIm5hbWUiOiJCIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJPUiIsImFyZ3MiOlt7InRhZyI6ImFwcCIsInN5bSI6Ik5PVCIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQiIsInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJpbXBfb2Zfbm90X29yJyIsWyJoQUIyIl0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkIiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJuIiwiaEFCMyIsImhBQiJdLFsiYyIsIm5vdF9ub3RfZWxpbSIsWyJoQSJdLHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699496")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 10.5 (false_or’)")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 11 moves. The shortest proof the game knows takes 13. THIS ONE IS SHORTER.")

#text("— We wish to prove A ↔ (False ∨ A).")#linebreak()#text("— Introduce A:")#linebreak()#text("— From A, False we deduce False ∨ A (disjunction introduction (right)).")#linebreak()#text("— Discharging, we obtain A → (False ∨ A).")#linebreak()#text("— Introduce False ∨ A:")#linebreak()#text("— Introduce False:")#linebreak()#text("— From False, A we deduce A (from falsehood, anything (ex falso)).")#linebreak()#text("— Discharging, we obtain False → A.")#linebreak()#text("— From A we deduce A → A (the lemma Impl.idem).")#linebreak()#text("— From False ∨ A, False → A, A → A we deduce A (the lemma Or.elim’).")#linebreak()#text("— Discharging, we obtain (False ∨ A) → A.")#linebreak()#text("— From A → (False ∨ A), (False ∨ A) → A we deduce A ↔ (False ∨ A) (iff introduction).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 2 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— 6.4 (Or.elim’)")#linebreak()#text("section")#linebreak()#text("variable {A B C : Prop}")

#text("theorem Or.elim’ (hAB : A ∨ B) (hAC : A → C) (hBC : B → C) : C := by")#linebreak()#text("have hABC : (A ∨ B) → C := fun h => Or.elim h hAC hBC")#linebreak()#text("have hC : C := hABC hAB")#linebreak()#text("exact hC")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {A : Prop}")

#text("theorem false_or’ : A ↔ (False ∨ A) := by")#linebreak()#text("have hAA : A → (False ∨ A) := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : False ∨ A := Or.inr hA")#linebreak()#text("exact hA2")#linebreak()#text("have hAA2 : (False ∨ A) → A := by")#linebreak()#text("intro hA")#linebreak()#text("have hA2 : False → A := by")#linebreak()#text("intro h")#linebreak()#text("have hA2 : A := False.elim h")#linebreak()#text("exact hA2")#linebreak()#text("have hAA2 : A → A := Impl.idem")#linebreak()#text("have hA3 : A := Or.elim’ hA hA2 hAA2")#linebreak()#text("exact hA3")#linebreak()#text("have hAA3 : A ↔ (False ∨ A) := Iff.intro hAA hAA2")#linebreak()#text("exact hAA3")

#text("— grimoire-replay v1 10.5 W1siYSIseyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiYyIsIk9yLmluciIsWyJoQSIseyJ0YWciOiJhcHAiLCJzeW0iOiJGQUxTRSIsImFyZ3MiOltdLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiRkFMU0UiLCJhcmdzIjpbXSwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiZCIsImhBMiIsMV0sWyJhIix7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiRkFMU0UiLCJhcmdzIjpbXSwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLFsiYSIseyJ0YWciOiJhcHAiLCJzeW0iOiJGQUxTRSIsImFyZ3MiOltdLCJzb3J0IjoiUHJvcCJ9XSxbImMiLCJGYWxzZS5lbGltIixbImgiLHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sWyJkIiwiaEEyIiwxXSxbImMiLCJJbXBsLmlkZW0iLFt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0seyJ0YWciOiJhcHAiLCJzeW0iOiJJTVBMSUVTIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoidmFyIiwibmFtZSI6IkEiLCJzb3J0IjoiUHJvcCJ9XSwic29ydCI6IlByb3AifV0sWyJjIiwiT3IuZWxpbSciLFsiaEEiLCJoQTIiLCJoQUEyIl0seyJ0YWciOiJ2YXIiLCJuYW1lIjoiQSIsInNvcnQiOiJQcm9wIn1dLFsiZCIsImhBMyIsMV0sWyJjIiwiSWZmLmludHJvIixbImhBQSIsImhBQTIiXSx7InRhZyI6ImFwcCIsInN5bSI6IklGRiIsImFyZ3MiOlt7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifSx7InRhZyI6ImFwcCIsInN5bSI6Ik9SIiwiYXJncyI6W3sidGFnIjoiYXBwIiwic3ltIjoiRkFMU0UiLCJhcmdzIjpbXSwic29ydCI6IlByb3AifSx7InRhZyI6InZhciIsIm5hbWUiOiJBIiwic29ydCI6IlByb3AifV0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bf4f05fbd07cb11b932dc9cfd4e3ccc53be2b811aa62a60f3854489ef5d712b-28c28805964098a38de7610e7d9912419d7ecd18e65313d3abf13f3ec24d042c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leaving Leaves")]], [#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/comment-page-1/#comment-699497")[#strong[#text("Leaving Leaves")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2026")])]

#text("— Lean Grimoire — exercise 11.4")#linebreak()#text("— ")#link("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")[#text("https://terrytao.wordpress.com/2026/11/11/lean-grimoire/")]#linebreak()#text("— Proved in 1 move. The shortest proof the game knows takes 2. THIS ONE IS SHORTER.")

#text("— We wish to prove (∀ X : Ω, (∀ Y : Ω, Q(X, Y))) → (∀ X : Ω, (∀ Y : Ω, Q(X, Y))).")#linebreak()#text("— From ∀ X : Ω, (∀ Y : Ω, Q(X, Y)) we deduce (∀ X : Ω, (∀ Y : Ω, Q(X, Y))) → (∀ X : Ω, (∀ Y : Ω, Q(X, Y))) (the lemma Impl.idem).")#linebreak()#text("— This is what we wished to prove. ∎")

#text("— Solving a lemma mints it as a recipe, so a proof that uses one needs that proof with")#linebreak()#text("— it. 1 of them, each as you proved it, deepest first.")

#text("— 4.1 (Impl.idem)")#linebreak()#text("section")#linebreak()#text("variable {A : Prop}")

#text("theorem Impl.idem : A → A := by")#linebreak()#text("have hAA : A → A := by")#linebreak()#text("intro hA")#linebreak()#text("exact hA")#linebreak()#text("exact hAA")#linebreak()#text("end")

#text("— and the proof itself:")

#text("variable {Ω}")#linebreak()#text("variable {Q : Ω → Ω → Prop}")

#text("example : (∀ X : Ω, (∀ Y : Ω, Q X Y)) → (∀ X : Ω, (∀ Y : Ω, Q X Y)) := by")#linebreak()#text("have hXYXY : (∀ X : Ω, (∀ Y : Ω, Q X Y)) → (∀ X : Ω, (∀ Y : Ω, Q X Y)) := Impl.idem")#linebreak()#text("exact hXYXY")

#text("— grimoire-replay v1 11.4 W1siYyIsIkltcGwuaWRlbSIsW3sidGFnIjoiYmluZGVyIiwicSI6ImZvcmFsbCIsInYiOnsibmFtZSI6IlgiLCJzb3J0IjoizqkifSwiYm9keSI6eyJ0YWciOiJiaW5kZXIiLCJxIjoiZm9yYWxsIiwidiI6eyJuYW1lIjoiWSIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IlEiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9LHsidGFnIjoidmFyIiwibmFtZSI6IlkiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLHsidGFnIjoiYXBwIiwic3ltIjoiSU1QTElFUyIsImFyZ3MiOlt7InRhZyI6ImJpbmRlciIsInEiOiJmb3JhbGwiLCJ2Ijp7Im5hbWUiOiJYIiwic29ydCI6Is6pIn0sImJvZHkiOnsidGFnIjoiYmluZGVyIiwicSI6ImZvcmFsbCIsInYiOnsibmFtZSI6IlkiLCJzb3J0IjoizqkifSwiYm9keSI6eyJ0YWciOiJhcHAiLCJzeW0iOiJRIiwiYXJncyI6W3sidGFnIjoidmFyIiwibmFtZSI6IlgiLCJzb3J0IjoizqkifSx7InRhZyI6InZhciIsIm5hbWUiOiJZIiwic29ydCI6Is6pIn1dLCJzb3J0IjoiUHJvcCJ9LCJzb3J0IjoiUHJvcCJ9LCJzb3J0IjoiUHJvcCJ9LHsidGFnIjoiYmluZGVyIiwicSI6ImZvcmFsbCIsInYiOnsibmFtZSI6IlgiLCJzb3J0IjoizqkifSwiYm9keSI6eyJ0YWciOiJiaW5kZXIiLCJxIjoiZm9yYWxsIiwidiI6eyJuYW1lIjoiWSIsInNvcnQiOiLOqSJ9LCJib2R5Ijp7InRhZyI6ImFwcCIsInN5bSI6IlEiLCJhcmdzIjpbeyJ0YWciOiJ2YXIiLCJuYW1lIjoiWCIsInNvcnQiOiLOqSJ9LHsidGFnIjoidmFyIiwibmFtZSI6IlkiLCJzb3J0IjoizqkifV0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn0sInNvcnQiOiJQcm9wIn1dLCJzb3J0IjoiUHJvcCJ9XV0=")

#emph[#text("[Added, thanks – T.]")]
]
