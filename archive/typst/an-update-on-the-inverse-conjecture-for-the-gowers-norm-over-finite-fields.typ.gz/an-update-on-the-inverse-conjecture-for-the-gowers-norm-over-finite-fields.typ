// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/
// Converted to Typst by tao2typ: "2026-10-14T10:05:58.539533+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An update on the inverse conjecture for the Gowers norm over finite fields", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An update on the inverse conjecture for the Gowers norm over finite fields")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 November 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/")[#text("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/")[#text("Recently, I had tentatively announced")]#text(" a forthcoming result with ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" establishing the “Gowers inverse conjecture” (or more accurately, the “inverse conjecture for the Gowers uniformity norm”) for vector spaces ")#mi("{\\Bbb F}_p^n")#text(" over a finite field ")#mi("{\\Bbb F}_p")#text(", in the special case when p=2 and when the function ")#mi("f: {\\Bbb F}_p^n \\to {\\Bbb C}")#text(" for which the inverse conjecture is to be applied is assumed to be a polynomial phase of bounded degree (thus ")#tao-math("f= e^{2\\pi i P/\\left|{\\Bbb F}\\right|}", block: false)#text(", where ")#mi("P: {\\Bbb F}_p^n \\to {\\Bbb F}_p")#text(" is a polynomial of some degree ")#mi("d=O(1)")#text("). See ")#link("http://arxiv.org/abs/0707.4269")[#text("my FOCS article")]#text(" for some further discussion of this conjecture, which has applications to both polynomiality testing and to various structural decompositions involving the Gowers norm.")

#text("This conjecture can be informally stated as follows. By iterating the obvious fact that the derivative of a polynomial of degree at most d is a polynomial of degree at most d-1, we see that a function ")#mi("P: {\\Bbb F}_p^n \\to {\\Bbb F}_p")#text(" is a polynomial of degree at most d if and only if")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\omega_1,\\ldots,\\omega_{d+1} \\in \\{0,1\\}} (-1)^{\\omega_1+\\ldots+\\omega_{d+1}} P(x +\\omega_1 h_1 + \\ldots + \\omega_{d+1} h_{d+1}) = 0")]]

#text("for all ")#mi("x,h_1,\\ldots,h_{d+1} \\in {\\Bbb F}_p^n")#text(". From this one can deduce that a function ")#mi("f: {\\Bbb F}_p^n \\to {\\Bbb C}")#text(" bounded in magnitude by 1 is a polynomial phase of degree at most d if and only if the ")#emph[#text("Gowers norm")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^{d+1}({\\Bbb F}_p^n)} := \\bigl( {\\Bbb E}_{x,h_1,\\ldots,h_{d+1} \\in {\\Bbb F}_p^n} \\prod_{\\omega_1,\\ldots,\\omega_{d+1} \\in \\{0,1\\}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("{\\mathcal C}^{\\omega_1+\\ldots+\\omega_{d+1}} f(x + \\omega_1 h_1 + \\ldots + \\omega_{d+1} h_{d+1}) \\bigr)^{1/2^{d+1}}")]]

#text("is equal to its maximal value of 1. The inverse conjecture for the Gowers norm, in its usual formulation, says that, more generally, if a function ")#mi("f: {\\Bbb F}_p^n \\to {\\Bbb C}")#text(" bounded in magnitude by 1 has large Gowers norm (e.g. ")#tao-math("\\left\\|f\\right\\|_{U^{d+1}} \\geq \\varepsilon", block: false)#text(") then f has some non-trivial correlation with some polynomial phase g (e.g. ")#mi("\\langle f, g \\rangle > c(\\varepsilon)")#text(" for some ")#mi("c(\\varepsilon) > 0")#text("). Informally, this conjecture asserts that if a function has biased ")#mi("(d+1)^{th}")#text(" derivatives, then one should be able to “integrate” this bias and conclude that the function is biased relative to a polynomial of degree d. The conjecture has already been proven for ")#mi("d \\leq 2")#text(". There are analogues of this conjecture for cyclic groups which are of relevance to ")#link("http://scholarpedia.org/article/Szemer%C3%A9di's_Theorem")[#text("Szemerédi’s theorem")]#text(" and to counting linear patterns in primes, but I will not discuss those here.")

#text("At the time of the announcement, our paper had not quite been fully written up. This turned out to be a little unfortunate, because soon afterwards we discovered that our arguments at one point had to go through a version of ")#link("http://mathworld.wolfram.com/NewtonsDividedDifferenceInterpolationFormula.html")[#text("Newton’s interpolation formula")]#text(", which involves a factor of d! in the denominator and so is only valid when the characteristic p of the field exceeds the degree. So our arguments in fact are only valid in the range ")#mi("p > d")#text(", and in particular are rather trivial in the important case ")#mi("p=2")#text("; my previous announcement should thus be amended accordingly.")

#metadata(none) <tao-43fd83512e8809799821>#text("On investigating this further, we found that the conjecture as stated above is in fact false in the characteristic 2 case: specifically, the symmetric quartic polynomial ")#mi("S_4: {\\Bbb F}_2^n \\to {\\Bbb F}_2")#text(" defined by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("S_4(x_1,\\ldots,x_n) := \\sum_{1 \\leq i < j < k < l \\leq n} x_i x_j x_k x_l")]]

#text("has no significant correlation with any cubic polynomial, but nevertheless exhibits “pseudocubic” behaviour in the sense that its fourth derivative")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("S_4(x+a+b+c+d)-S_4(x+a+b+c)-\\ldots - S_4(x+d) + S_4(x)")]]

#text("(there are 16 terms in this alternating sum) is biased to be 0 (in fact, it is 0 about 9/16 of the time), basically because the above expression can be factorised as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("B(a,b) B(c,d) + B(a,d) B(b,c) + B(a,c) B(b,d)")]]

#text("where B is the symmetric bilinear form")

#align(center)[#mi("B(a,b) := \\sum_{1 \\leq i < j \\leq n} a_i b_j + a_j b_i")#text(".")]

#text("This same example had also been discovered shortly beforehand by ")#link("http://www.wisdom.weizmann.ac.il/~shalov/")[#text("Lovett")]#text(", ")#link("http://www.math.technion.ac.il/people/meshulam/")[#text("Meshulam")]#text(", and ")#link("http://www.cs.huji.ac.il/~salex/")[#text("Samorodnitsky")]#text(" (private communication), who are now in the process of generalising this example to higher characteristics and higher degrees, and obtaining strong bounds on the discorrelation of these examples with lower degree polynomial phases. (On the other hand, for characteristics higher than the degree, this phenomenon does not occur; our forthcoming paper will show, for instance, that every pseudocubic quartic correlates with a genuine cubic in characteristic 5 and higher.)")

#text("It seems intuitively obvious that the quartic ")#mi("S_4")#text(" does not correlate with any lower degree polynomials, but sometimes there are non-obvious correlations. For instance, the first three symmetric functions")

#tao-aligned(keep: true)[


#tao-math("S_1(x_1,\\ldots,x_n)  & := \\sum_{1 \\leq i \\leq n} x_i", block: true)



#tao-math("S_2(x_1,\\ldots,x_n)  & := \\sum_{1 \\leq i < j \\leq n} x_i x_j", block: true)



#tao-math("S_3(x_1,\\ldots,x_n)  & := \\sum_{1 \\leq i < j < k \\leq n} x_i x_j x_k", block: true)
]

#text("do not seem to be obviously related, but over ")#mi("{\\Bbb F}_2")#text(", they turn out to obey the relationship")

#align(center)[#tao-fit-display[#mitex("S_3 = S_1 S_2")]]

#text("and as a consequence, the cubic function ")#mi("S_3")#text(" correlates with the linear function ")#mi("S_1")#text(" and the quadratic function ")#mi("S_2")#text(". Indeed, if ")#tao-math("\\left|x\\right|", block: false)#text(" denotes the number of indices i for which ")#mi("x_i=1")#text(", we see that ")#mi("S_1, S_2, S_3")#text(" are equal to 1 if and only if ")#tao-math("\\left|x\\right| \\text{ mod } 4", block: false)#text(" lies in ")#mi("\\{1,3\\}")#text(", ")#mi("\\{2,3\\}")#text(", and ")#mi("\\{3\\}")#text(" respectively.")

#text("In contrast, ")#mi("S_4")#text(" is equal to 1 if and only if ")#tao-math("\\left|x\\right| \\text{ mod } 8", block: false)#text(" lies in ")#mi("\\{4,5,6,7\\}")#text(". (The pattern continues using ")#link("http://en.wikipedia.org/wiki/Pascal%27s_triangle")[#text("Pascal’s triangle")]#text(" modulo 2, or equivalently the infinite ")#link("http://en.wikipedia.org/wiki/Sierpinski_Triangle")[#text("Sierpinski gasket")]#text(".) So it is clear that ")#mi("S_4")#text(" cannot be expressed in terms of ")#mi("S_1, S_2, S_3")#text("; but this does not yet rule out the possibility that ")#mi("S_4")#text(" instead correlates with some other linear, quadratic, or cubic polynomials.")

#text("The forthcoming paper of Lovett, Meshulam, and Samorodnitsky will establish quite a strong discorrelation estimate on ")#mi("S_4")#text(", indeed they show that")

#align(center)[#tao-fit-display[#mitex("\\langle (-1)^{S_4}, (-1)^{Q} \\rangle = O( 2^{-cn} )")]]

#text("for all cubic polynomials ")#mi("Q: {\\Bbb F}_2^n \\to {\\Bbb F}_2")#text(", where c is some positive absolute constant and ")#mi("\\langle, \\rangle")#text(" is the usual normalised inner product on ")#mi("{\\Bbb F}_2^n")#text(". I will not present that argument here (though it is fairly short); instead, I would like to discuss a very pretty argument ")#link("http://www.math.tau.ac.il/~nogaa/PDFS/beigel6.pdf")[#text("of Alon and Beigel")]#text(" which uses ")#link("http://en.wikipedia.org/wiki/Ramsey_theory")[#text("Ramsey theory")]#text(" to give the weaker estimate")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\langle (-1)^{S_4}, (-1)^{Q} \\rangle = o(1)")]]

#text("(actually, if one plugs in the best known bounds for ")#link("http://en.wikipedia.org/wiki/Ramsey%27s_theorem")[#text("Ramsey’s theorem")]#text(", one gets the more precise bound of ")#mi("O( 1 / \\log n )")#text(" for some c > 0). [We thank ")#link("http://projectamericano.com/adib/")[#text("Andrej Bogdanov")]#text(" and ")#link("http://www1.cs.columbia.edu/~viola/")[#text("Emanuele Viola")]#text(" for drawing the Alon-Beigel argument to our attention; we had an earlier argument, using, of all things, a ")#link("http://www.ams.org/mathscinet-getitem?mr=2145566")[#text("finite field analogue of the multidimensional Szemerédi theorem")]#text(", which gave inferior bounds.]")#linebreak()#text(" The key idea is to use Ramsey theory to symmetrise the polynomial Q. Indeed, if the cubic polynomial Q was completely symmetric with respect to permutations of the coefficients ")#mi("x_1,\\ldots,x_n")#text(", then it is a linear combination of ")#mi("S_1, S_2, S_3")#text(", and then by explicit computation using the previously mentioned relationships between ")#mi("S_1(x), S_2(x), S_3(x), S_4(x)")#text(" and |x|, we can verify by hand that (2) holds in these cases (in fact from the theory of random walks one soon establishes an exponential decay bound).")

#text("Now suppose that Q is symmetric modulo a linear error, thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("Q(x) = Q_s(x) + \\sum_{i \\in A} x_i")]]

#text("for some symmetric cubic ")#mi("Q_s")#text(" and some collection of indices ")#mi("A \\subset \\{1,\\ldots,n\\}")#text(". Then we can symmetrise the error ")#mi("\\sum_{i \\in A} x_i")#text(" by the simple expedient of the ")#link("http://en.wikipedia.org/wiki/Pigeonhole_principle")[#text("pigeonhole principle")]#text(": either the set A contains at least ")#mi("m := \\lfloor n/2 \\rfloor")#text(" indices, or its complement contains at least m indices. Suppose for sake of argument that A contains at least m indices, and specifically the indices ")#mi("\\{1,\\ldots,m\\}")#text(". Then the point is that while the linear polynomial ")#mi("\\sum_{i \\in A} x_i")#text(" is not symmetric with respect to interchange of all coordinates ")#mi("x_1,\\ldots,x_n")#text(", it is at least symmetric with respect to interchange of the coordinates ")#mi("x_1,\\ldots,x_m")#text(". If we then ")#link("http://en.wikipedia.org/wiki/Foliation")[#text("foliate")]#text(" the domain ")#mi("{\\Bbb F}_2^n")#text(" into translates of the smaller domain ")#mi("{\\Bbb F}_2^m")#text(" (by freezing the coordinates ")#mi("x_{m+1},\\ldots,x_n")#text("), using the previous results towards (4) to obtain a correlation o(1) on each of these translates, and then averaging everything together using the triangle inequality to obtain (4) in the case (5).")

#text("Now consider the case when Q is symmetric modulo quadratic errors, thus")

#align(center)[#tao-fit-display[#mitex("Q(x) = Q_s(x) + \\sum_{\\{i,j\\} \\in E} x_i x_j + L(x)")]]

#text("where ")#mi("Q_s")#text(" is symmetric, E is a set of pairs or “edges” in ")#mi("\\{1,\\ldots,n\\}")#text(", and L is some linear polynomial. The quadratic ")#mi("\\sum_{\\{i,j\\} \\in E} x_i x_j")#text(" is not symmetric in general, but it can be symmetrised on medium-sized subspaces by an appeal to ")#link("http://en.wikipedia.org/wiki/Ramsey%27s_theorem")[#text("Ramsey’s theorem")]#text(". If we view E as the edges of a graph G, this theorem says that for some integer m growing slowly with n (we can take ")#mi("m \\sim \\log n")#text(", in fact), the graph G either contains a ")#link("http://en.wikipedia.org/wiki/Clique_%28graph_theory%29")[#text("clique")]#text(" of size m, or an ")#link("http://en.wikipedia.org/wiki/Independent_set")[#text("independent set")]#text(" of size m. Let’s say it contains a clique of size m, which without loss of generality we can take to be ")#mi("\\{1,\\ldots,m\\}")#text(". Then the quadratic ")#mi("\\sum_{\\{i,j\\} \\in E} x_i x_j")#text(" can be expressed as the sum of ")#mi("\\sum_{1 \\leq i < j \\leq m} x_i x_j")#text(", which is symmetric with respect to permutations of ")#mi("x_1,\\ldots,x_m")#text(", plus a remainder which is at most linear in ")#mi("x_1,\\ldots,x_m")#text(". So if we once again foliate ")#mi("{\\Bbb F}_2^n")#text(" into translates of ")#mi("{\\Bbb F}_2^m")#text(" and use the previous results, we again recover the discorrelation estimate (4) for these polynomials. (Note that the o(1) notation for ")#mi("n \\to \\infty")#text(" and the o(1) notation for ")#mi("m \\to \\infty")#text(" are interchangeable, because m goes to infinity as n goes to infinity.)")

#text("Finally, we consider the general case when Q is an arbitrary cubic, thus")

#align(center)[#tao-fit-display[#mitex("Q(x) = \\sum_{\\{i,j,k\\} \\in E} x_i x_j x_k + \\text{ quadratic error}")]]

#text("for some collection E of unordered triples in ")#mi("\\{1,\\ldots,n\\}")#text(". One can view E as the edges of a (3-uniform) ")#link("http://en.wikipedia.org/wiki/Hypergraph")[#text("hypergraph")]#text(" on n vertices. It turns out that Ramsey’s theorem also extends to hypergraphs (it’s the same proof, iterated a few more times), and so once again we can locate medium-sized subspaces on which the cubic ")#mi("\\sum_{\\{i,j,k\\} \\in E} x_i x_j x_k")#text(" becomes symmetric, and so by appeal to the previous results we obtain (4) in full generality.")

#text("[A note for the experts: the above iterated use of Ramsey’s theorem was inefficient. It is possible to use just a single application of the 3-uniform hypergraph Ramsey theorem (and no application of the graph Ramsey theorem) to eventually end up with a correlation bound of ")#mi("O( 1 / \\log n )")#text("; details will be provided in our forthcoming paper. Of course, this is still significantly inferior to the exponential bounds that will be obtained by Lovett, Meshulam, and Samorodnitsky.]")

#text("Despite the above example, I personally believe that some form of the inverse conjecture of the Gowers norm persists. One particularly promising candidate is to replace the notion of a global polynomial by a local one (as is discussed in ")#link("http://front.math.ucdavis.edu/math.NT/0503014")[#text("one of my papers with Ben")]#text("). For instance, while ")#mi("S_4")#text(" is not a globally cubic polynomial, it turns out that it is “locally cubic” on the quadratic surface ")#mi("\\{ x: S_2(x) = 0\\}")#text(", in the sense that the fourth derivative (2) of ")#mi("S_4")#text(" vanishes when all sixteen points ")#mi("x, x+a, x+b, \\ldots, x+a+b+c+d")#text(" of the relevant parallelopiped lies on that quadratic surface. This is basically due to the identity that equates (2) and (3). So it seems there is still much to be investigated regarding this conjecture over finite fields…")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of undergrad")]], [#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/#comment-13904")[#strong[#text("undergrad")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2007")])]

#text("this is so high level… i can’t understand most of it.")

#text("terry, any way you can write some articles which could be understood by 1-st, 2-nd year undergrads?")

#text("sincerely,")#linebreak()#text(" jane")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/#comment-13959")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2007")])]

#text("Dear Jane,")

#text("You can find my non-technical articles at")

#link("https://terrytao.wordpress.com/category/non-technical/")[#text("https://terrytao.wordpress.com/category/non-technical/")]

#text("In the immediate future, I expect the next few articles to continue to be graduate level, but I plan to write some more non-technical articles in due course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tauber")]], [#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/#comment-14075")[#strong[#text("Tauber")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2007")])]

#text("Dear undergrad,")#linebreak()#text(" Serious mathematics is not easily understood. If you want to")#linebreak()#text(" write articles at the calculus level, you first need to put some")#linebreak()#text(" effort in setting up a problem interesting to a wide audience.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5652dfa8237a1f2b289ca2f10481df512257433d85ebcc2d907d0a7fc7771238-b526a1c8f6c0909518c172f26d1dd1e8dbe332348636de46e96d1f7704dfc856.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luca")]], [#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/#comment-14077")[#strong[#text("Luca")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2007")])]

#text("Hi Terry,")

#text("is a weak “local” version of the Gowers inverse conjecture known in vector spaces over a prime field? Something like for every $d,\\epsilon$, there is $c(d,\\epsilon)$ such that if $f : F^n \\rightarrow C$is bounded and $||f||_{U^d} \\geq \\epsilon$ then there is a subspace $V$ of $F^n$ of dimension at least $c(d,\\epsilon) n$, or maybe $n^{c(d,\\epsilon)}$ and a degree $d-1$ polynomial phase function $p$ such that $f$ and $p$ are correlated over $V$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/#comment-14107")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2007")])]

#text("Luca,")

#text("I don’t believe we have such a result yet for d greater than or equal to 4 even when the characteristic of F is large. It is also possible that another ‘weak’ version of the IG conjecture is true, even in characteristic 2: If ||f||_{U^d} is large then f correlates with a polynomial of degree O_d(1). The recent examples of Lovett, Meshulam and Samorodnitsky and Terry and I show that one cannot take this O_d(1) to be d-1 in general.")

#text("I’m not sure we know how to prove that even if we already know that f is a polynomial phase of some very large degree. That is, if f is a polynomial phase of degree 1000 with large Gowers U^4 norm, does it correlate with a polynomial of degree 10 (or maybe even of degree 4)?")

#text("This characteristic 2 theory is turning out to be kind of intruiging.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of polynomials over finite fields, with applications to the Gowers norms « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/#comment-16543")[#strong[#text("The distribution of polynomials over finite fields, with applications to the Gowers norms « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2007")])]

#text("[…] This paper, which we first announced at the recent FOCS meeting, and then gave an update on two weeks ago on this blog, is now in final form. It is being made available simultaneously with a closely related paper of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The correspondence principle and finitary ergodic theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/#comment-32349")[#strong[#text("The correspondence principle and finitary ergodic theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2008")])]

#text("[…] established, which by the correspondence principle alluded to above, implies Theorem 14. (See my previous blog post for some discussion of Theorem 14, which had been conjectured for a few years. Interestingly, as […]")
]
