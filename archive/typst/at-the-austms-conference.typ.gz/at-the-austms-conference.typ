// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/
// Converted to Typst by tao2typ: "2026-10-14T15:17:27.681304+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "At the AustMS conference", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("At the AustMS conference")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/")[#text("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week I was in my home town of Adelaide, Australia, for the ")#link("http://www.unisa.edu.au/austms2009/")[#text("2009 annual meeting of the Australian Mathematical Society")]#text(". This was a fairly large meeting (almost 500 participants). One of the highlights of such a large meeting is the ability to listen to plenary lectures in fields adjacent to one’s own, in which speakers can give high-level overviews of a subject without getting too bogged down in the technical details. From the talks here I learned a number of basic things which were well known to experts in that field, but which I had not fully appreciated, and so I wanted to share them here.")

#text("The first instance of this was from a plenary lecture by ")#link("http://www.its.caltech.edu/~dannyc/")[#text("Danny Calegari")]#text(" entitled “faces of the stable commutator length (scl) ball”. One thing I learned from this talk is that in ")#link("http://en.wikipedia.org/wiki/Homotopy_theory")[#text("homotopy theory")]#text(", there is a very close relationship between topological spaces (such as manifolds) on one hand, and groups (and generalisations of groups) on the other, so that homotopy-theoretic questions about the former can often be converted to purely algebraic questions about the latter, and vice versa; indeed, it seems that homotopy theorists almost think of topological spaces and groups as being essentially the same concept, despite looking very different at first glance. To get from a space ")#mi("{X}")#text(" to a group, one looks at ")#link("http://en.wikipedia.org/wiki/Homotopy_group")[#text("homotopy groups")]#text(" ")#mi("{\\pi_n(X)}")#text(" of that space, and in particular the ")#link("http://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(" ")#mi("{\\pi_1(X)}")#text("; conversely, to get from a group ")#mi("{G}")#text(" back to a topological space one can use the ")#link("http://en.wikipedia.org/wiki/Eilenberg%E2%88%92MacLane_space")[#text("Eilenberg-Maclane")]#text(" spaces ")#mi("{K(G,n)}")#text(" associated to that group (and more generally, a ")#link("http://en.wikipedia.org/wiki/Postnikov_system")[#text("Postnikov tower")]#text(" associated to a sequence of such groups, together with additional data). In Danny’s talk, he gave the following specific example: the problem of finding the least complicated embedded surface with prescribed (and homologically trivial) boundary in a space ")#mi("{X}")#text(", where “least complicated” is measured by ")#link("http://en.wikipedia.org/wiki/Genus_%28mathematics%29")[#text("genus")]#text(" (or more precisely, the negative component of ")#link("http://en.wikipedia.org/wiki/Euler_characteristic")[#text("Euler characteristic")]#text("), is essentially equivalent to computing the ")#emph[#text("commutator length")]#text(" of the element in the fundamental group ")#mi("{\\pi(X)}")#text(" corresponding to that boundary (i.e. the least number of commutators one is required to multiply together to express the element); and the stable version of this problem (where one allows the surface to wrap around the boundary ")#mi("{n}")#text(" times for some large ")#mi("{n}")#text(", and one computes the asymptotic ratio between the Euler characteristic and ")#mi("{n}")#text(") is similarly equivalent to computing the ")#emph[#text("stable commutator length")]#text(" of that group element. (Incidentally, there is a simple combinatorial open problem regarding commutator length in the free group, which ")#link("http://michaelnielsen.org/polymath1/index.php?title=Other_proposed_projects#Stable_commutator_length_in_the_free_group")[#text("I have placed on the polymath wiki")]#text(".)")

#text("This theme was reinforced by another plenary lecture by ")#link("http://www.math.northwestern.edu/~getzler/")[#text("Ezra Getzler")]#text(" entitled “")#mi("{n}")#text("-groups”, in which he showed how sequences of groups (such as the first ")#mi("{n}")#text(" homotopy groups ")#mi("{\\pi_1(X),\\ldots,\\pi_n(X)}")#text(") can be enhanced into a more powerful structure known as an ")#link("http://en.wikipedia.org/wiki/N-group")[#mi("{n}")#text("-group")]#text(", which is more complicated to define, requiring the machinery of ")#link("http://en.wikipedia.org/wiki/Simplicial_complex")[#text("simplicial complexes")]#text(", ")#link("http://en.wikipedia.org/wiki/Sheaf_%28mathematics%29")[#text("sheaves")]#text(", and ")#link("http://en.wikipedia.org/wiki/Nerve_%28category_theory%29")[#text("nerves")]#text(". Nevertheless, this gives a very topological and geometric interpretation of the concept of a group and its generalisations, which are of use in ")#link("http://en.wikipedia.org/wiki/Topological_quantum_field_theory")[#text("topological quantum field theory")]#text(", among other things.")

#text("Mohammed Abuzaid gave a plenary lecture entitled “Functoriality in homological mirror symmetry”. One thing I learned from this talk was that the (partially conjectural) phenomenon of ")#link("http://en.wikipedia.org/wiki/Homological_mirror_symmetry")[#text("(homological) mirror symmetry")]#text(" is one of several types of duality, in which the behaviour of maps into one mathematical object ")#mi("{X}")#text(" (e.g. immersed or embedded curves, surfaces, etc.) are closely tied to the behaviour of maps ")#emph[#text("out of")]#text(" a dual mathematical object ")#mi("{\\hat X}")#text(" (e.g. functionals, vector fields, forms, sections, bundles, etc.). A familiar example of this is in linear algebra: by taking adjoints, a linear map into a vector space ")#mi("{X}")#text(" can be related to an adjoint linear map mapping out of the dual space ")#mi("{X^*}")#text(". Here, the behaviour of curves in a two-dimensional symplectic manifold (or more generally, ")#link("http://en.wikipedia.org/wiki/Lagrangian_submanifold")[#text("Lagrangian submanifolds")]#text(" in a higher-dimensional symplectic manifold), is tied to the behaviour of holomorphic sections on bundles over a dual algebraic variety, where the precise definition of “behaviour” is category-theoretic, involving some rather complicated gadgets such as the ")#link("http://en.wikipedia.org/wiki/Floer_homology")[#text("Fukaya category")]#text(" of a symplectic manifold. As with many other applications of category theory, it is not just the individual pairings between an object and its dual which are of interest, but also the ")#emph[#text("relationships")]#text(" between these pairings, as formalised by various functors between categories (and natural transformations between functors). (One approach to mirror symmetry was discussed by Shing-Tung Yau at a distinguished lecture at UCLA, as ")#link("https://terrytao.wordpress.com/2007/05/17/distinguished-lecture-series-ii-shing-tung-yau-the-basic-tools-to-construct-geometric-structures/")[#text("transcribed in this previous post")]#text(".)")

#text("There was a related theme in a talk by Dennis Gaitsgory entitled “The geometric Langlands program”. From my (very superficial) understanding of the Langlands program, the behaviour of specific maps into a ")#link("http://en.wikipedia.org/wiki/Reductive_group")[#text("reductive")]#text(" Lie group ")#mi("{G}")#text(", such as representations in ")#mi("{G}")#text(" of a fundamental group, étale fundamental group, class group, or Galois group of a global field, is conjecturally tied to specific maps out of a dual reductive Lie group ")#mi("{\\hat G}")#text(", such as irreducible automorphic representations of ")#mi("{\\hat G}")#text(", or of various structures (such as derived categories) attached to vector bundles on ")#mi("{\\hat G}")#text(". There are apparently some tentatively conjectured links (due to Witten?) between Langlands duality and mirror symmetry, but they seem at present to be fairly distinct phenomena (one is topological and geometric, the other is more algebraic and arithmetic). For abelian groups, Langlands duality is closely connected to the much more classical ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin duality")]#text(" in Fourier analysis. (There is an analogue of Fourier analysis for nonabelian groups, namely representation theory, but the link from this to the Langlands program is somewhat murky, at least to me.)")

#text("Related also to this was a plenary talk by ")#link("http://math.stanford.edu/~akshay/")[#text("Akshay Venkatesh")]#text(", entitled “The Cohen-Lenstra heuristics over global fields”. Here, the question concerned the conjectural behaviour of ")#link("http://en.wikipedia.org/wiki/Class_group")[#text("class groups")]#text(" of quadratic fields, and in particular to explain the numerically observed phenomenon that about ")#mi("{75.4\\%}")#text(" of all quadratic fields ")#mi("{{\\Bbb Q}[\\sqrt{d}]}")#text(" (with ")#mi("d")#text(" prime) enjoy unique factorisation (i.e. have trivial class group). (Class groups, as I learned in these two talks, are arithmetic analogues of the (abelianised) fundamental groups in topology, with Galois groups serving as the analogue of the full fundamental group.) One thing I learned here was that there was a canonical way to randomly generate a (profinite) abelian group, by taking the product of randomly generated finite abelian ")#link("http://en.wikipedia.org/wiki/P-group")[#mi("{p}")#text("-groups")]#text(" for each prime ")#mi("{p}")#text(". The way to canonically randomly generate a finite abelian ")#mi("{p}")#text("-group is to take large integers ")#mi("{n, D}")#text(", and look at the ")#link("http://en.wikipedia.org/wiki/Cokernel")[#text("cokernel")]#text(" of a random homomorphism from ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(" to ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(". In the limit ")#mi("{n,d \\rightarrow \\infty}")#text(" (or by replacing ")#mi("{{\\mathbb Z}/p^n{\\mathbb Z}}")#text(" with the ")#mi("{p}")#text("-adics and just sending ")#mi("{d \\rightarrow \\infty}")#text("), this stabilises and generates any given ")#mi("{p}")#text("-group ")#mi("{G}")#text(" with probability ")#metadata(none) <tao-549ce58984289d8f0391>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\frac{1}{\\left|\\text{Aut}(G)\\right|} \\prod_{j=1}^\\infty (1 - \\frac{1}{p^j}),", block: true)]]

#text("where ")#mi("{\\text{Aut}(G)}")#text(" is the group of automorphisms of ")#mi("{G}")#text(". In particular this leads to the strange identity ")#metadata(none) <tao-b4c5ae2ae961fe88d128>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_G \\frac{1}{\\left|\\text{Aut}(G)\\right|} = \\prod_{j=1}^\\infty (1 - \\frac{1}{p^j})^{-1}", block: true)]]

#text("where ")#mi("{G}")#text(" ranges over all ")#mi("{p}")#text("-groups; I do not know how to prove this identity other than via the above probability computation, the proof of which I give below the fold.")

#text("Based on the heuristic that the class group should behave “randomly” subject to some “obvious” constraints, it is expected that a randomly chosen real quadratic field ")#mi("{{\\Bbb Q}[\\sqrt{d}]}")#text(" has unique factorisation (i.e. the class group has trivial ")#mi("{p}")#text("-group component for every ")#mi("{p}")#text(") with probability")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\text{ odd}} \\prod_{j=2}^\\infty (1 - \\frac{1}{p^j}) \\approx 0.754,")]]

#text("whereas a randomly chosen imaginary quadratic field ")#mi("{{\\Bbb Q}[\\sqrt{-d}]}")#text(" has unique factorisation with probability")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\text{ odd}} \\prod_{j=1}^\\infty (1 - \\frac{1}{p^j}) = 0.")]]

#text("The former claim is conjectural, whereas the latter claim follows from (for instance) Siegel’s theorem on the size of the class group, as discussed in ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("this previous post")]#text(". Ellenberg, Venkatesh, and Westerland have recently established some partial results towards the function field analogues of these heuristics.")

#metadata(none) <tao-92008c854008720786da>

#heading(level: 1)[#strong[#text(" — 1. ")#mi("{p}")#text("-groups — ")]]

#text("Henceforth the prime ")#mi("{p}")#text(" will be fixed. We will abbreviate “finite abelian ")#mi("{p}")#text("-group” as “")#mi("{p}")#text("-group” for brevity. Thanks to the ")#link("http://en.wikipedia.org/wiki/Finitely_generated_abelian_group")[#text("classification of finite abelian groups")]#text(", the ")#mi("{p}")#text("-groups are all isomorphic to the products")

#align(center)[#tao-fit-display[#mitex("({\\mathbb Z}/p^{n_1}{\\mathbb Z}) \\times \\ldots \\times ({\\mathbb Z}/p^{n_d}{\\mathbb Z})")]]

#text("of cyclic ")#mi("{p}")#text("-groups.")

#text("The cokernel of a random homomorphism from ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(" to ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(" can be written as the quotient of the ")#mi("{p}")#text("-group ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(" by the subgroup generated by ")#mi("{d}")#text(" randomly chosen elements ")#mi("{x_1,\\ldots,x_d}")#text(" from that ")#mi("{p}")#text("-group. One can view this quotient as a ")#mi("{d}")#text("-fold iterative process, in which one starts with the ")#mi("{p}")#text("-group ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(", and then one iterates ")#mi("{d}")#text(" times the process of starting with a ")#mi("{p}")#text("-group ")#mi("{G}")#text(", and quotienting out by a randomly chosen element ")#mi("{x}")#text(" of that group ")#mi("{G}")#text(". From induction, one sees that at the ")#mi("{j^{th}}")#text(" stage of this process (")#mi("{0 \\leq j \\leq d}")#text("), one ends up with a ")#mi("{p}")#text("-group isomorphic to ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^{d-j} \\times G_j}")#text(" for some ")#mi("{p}")#text("-group ")#mi("{G_j}")#text(".")

#text("Let’s see how the group ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^{d-j} \\times G_j}")#text(" transforms to the next group ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^{d-j-1} \\times G_{j+1}}")#text(". We write a random element of ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^{d-j} \\times G_j}")#text(" as ")#mi("{(x,y)}")#text(", where ")#mi("{x \\in ({\\mathbb Z}/p^n{\\mathbb Z})^{d-j}}")#text(" and ")#mi("{y \\in G_j}")#text(". Observe that for any ")#mi("{0 \\leq i < n}")#text(", ")#mi("{x}")#text(" is a multiple of ")#mi("{p^i}")#text(" (but not ")#mi("{p^{i+1}}")#text(") with probability ")#mi("{(1-p^{-(d-j)}) p^{-i(d-j)}}")#text(". (The remaining possibility is that ")#mi("{x}")#text(" is zero, but this event will have negligible probability in the limit ")#mi("{n \\rightarrow \\infty}")#text(".) If ")#mi("{x}")#text(" is indeed divisible by ")#mi("{p^i}")#text(" but not ")#mi("{p^{i+1}}")#text(", and ")#mi("{i}")#text(" is not too close to ")#mi("{n}")#text(", a little thought will then reveal that ")#tao-math("{\\left|G_{j+1}\\right| = p^i \\left|G_j\\right|}", block: false)#text(". Thus the size of the ")#mi("{p}")#text("-groups ")#mi("{G_j}")#text(" only grow as ")#mi("{j}")#text(" increases. (Things go wrong when ")#mi("{i}")#text(" gets close to ")#mi("{n}")#text(", e.g. ")#tao-math("{p^i \\geq p^n / \\left|G_j\\right|}", block: false)#text(", but the total size of this event as ")#mi("{j}")#text(" ranges from ")#mi("{0}")#text(" to ")#mi("{d}")#text(" sums to be ")#mi("{o(1)}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" (uniformly in ")#mi("{d}")#text("), by using the tightness bounds on ")#tao-math("{\\left|G_j\\right|}", block: false)#text(" mentioned below. Alternatively, one can avoid a lot of technicalities by taking the limit ")#mi("{n \\rightarrow \\infty}")#text(" before taking the limit ")#mi("{d \\rightarrow \\infty}")#text(" (instead of studying the double limit ")#mi("{n,d \\rightarrow \\infty}")#text("), or equivalently by replacing the cyclic group ")#mi("{{\\mathbb Z}/p^n {\\mathbb Z}}")#text(" with the ")#mi("{p}")#text("-adics ")#mi("{{\\mathbb Z}_p}")#text(".)")

#text("The exponentially decreasing nature of the probability ")#mi("{(1-p^{-(d-j)}) p^{-i(d-j)}}")#text(" in ")#mi("{i}")#text(" (and in ")#mi("{d-j}")#text(") furthermore implies that the distribution of ")#tao-math("{\\left|G_j\\right|}", block: false)#text(" forms a ")#emph[#text("tight sequence")]#text(" in ")#mi("{n, j, d}")#text(": for every ")#mi("{\\epsilon > 0}")#text(", one has an ")#mi("{R > 0}")#text(" such that the probability that ")#tao-math("{\\left|G_j\\right| \\geq R}", block: false)#text(" is less than ")#mi("{\\epsilon}")#text(" for all choices of ")#mi("{n,j,d}")#text(". (This tightness is necessary to prove the equality in ")#link(<tao-b4c5ae2ae961fe88d128>)[#text("(2)")]#text(" rather than just an inequality (from Fatou’s lemma).) Indeed, the probability that ")#tao-math("{\\left|G_j\\right| = p^m}", block: false)#text(" converges as ")#mi("{n,d \\rightarrow \\infty}")#text(" to the ")#mi("{t^m}")#text(" coefficient in the generating function ")#metadata(none) <tao-a45e2df6b898e7c4fb89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\prod_{k=1}^\\infty \\sum_{i=0}^\\infty t^i (1-p^{-k}) p^{-ik} = \\prod_{k=1}^\\infty \\frac{1-p^{-k}}{1 - t p^{-k}}.")]]

#text("In particular, this claim is true for the final cokernel ")#mi("{G_d}")#text(". Note that this (and the geometric series formula) already yields ")#link(<tao-549ce58984289d8f0391>)[#text("(1)")]#text(" in the case of the trivial group ")#mi("{G = \\{0\\}}")#text(" and the order ")#mi("{p}")#text(" group ")#mi("{G = {\\mathbb Z}/p{\\mathbb Z}}")#text(" (note that ")#mi("{\\text{Aut}(G)}")#text(" has order ")#mi("{1}")#text(" and ")#mi("{p}")#text(" in these respective cases). But it is not enough to deal with higher groups. For instance, up to isomorphism there are two ")#mi("{p}")#text("-groups of order ")#mi("{p^2}")#text(", namely ")#mi("{{\\mathbb Z}/p^2{\\mathbb Z}}")#text(" and ")#mi("{({\\mathbb Z}/p{\\mathbb Z})^2}")#text(", whose automorphism group has order ")#mi("{p^2-p}")#text(" and ")#mi("{(p^2-1)(p^2-p)}")#text(" respectively. Summing up the corresponding two expressions ")#link(<tao-549ce58984289d8f0391>)[#text("(1)")]#text(" one can observe that this matches the ")#mi("{t^2}")#text(" coefficient of ")#link(<tao-a45e2df6b898e7c4fb89>)[#text("(3)")]#text(" (after some applications of the geometric series formula). Thus we see that ")#link(<tao-a45e2df6b898e7c4fb89>)[#text("(3)")]#text(" is consistent with the claim ")#link(<tao-549ce58984289d8f0391>)[#text("(1)")]#text(", but does not fully imply that claim.")

#text("To get the full asymptotic ")#link(<tao-549ce58984289d8f0391>)[#text("(1)")]#text(" we try a slightly different tack. Fix a ")#mi("{p}")#text("-group ")#mi("{G}")#text(", and consider the event that the cokernel of a random map ")#mi("{T: ({\\mathbb Z}/p^n{\\mathbb Z})^d \\rightarrow ({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(" is isomorphic to ")#mi("{G}")#text(". We assume ")#mi("{n}")#text(" so large that all elements in ")#mi("{G}")#text(" have order at most ")#mi("{p^n}")#text(". If this is the case, then there must be a surjective homomorphism ")#mi("{\\phi: ({\\mathbb Z}/p^n {\\mathbb Z})^d \\rightarrow G}")#text(" such that the range of ")#mi("{T}")#text(" is equal to the kernel of ")#mi("{\\phi}")#text(". The number of homomorphisms from ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(" to ")#mi("{G}")#text(" is ")#tao-math("{\\left|G\\right|^d}", block: false)#text(" (one has to pick ")#mi("{d}")#text(" generators in ")#mi("{G}")#text("). If ")#mi("{d}")#text(" is large, it is easy to see that most of these homomorphisms are surjective (the proportion of such homomorphisms is ")#mi("{1-o(1)}")#text(" as ")#mi("{d \\rightarrow \\infty}")#text("). On the other hand, there is some multiplicity; the range of ")#mi("{T}")#text(" can emerge as the kernel of ")#mi("{\\phi}")#text(" in ")#tao-math("{\\left|\\text{Aut}(G)\\right|}", block: false)#text(" different ways (since any two surjective homomorphisms ")#mi("{\\phi, \\phi^{\\prime}: ({\\mathbb Z}/p^n {\\mathbb Z})^d \\rightarrow G}")#text(" with the same kernel arise from an automorphism of ")#mi("{G}")#text("). So to prove ")#link(<tao-549ce58984289d8f0391>)[#text("(1)")]#text(", it suffices to show that for any surjective homomorphism ")#mi("{\\phi: ({\\mathbb Z}/p^n{\\mathbb Z})^d \\rightarrow G}")#text(", the probability that the range of ")#mi("{T}")#text(" equals the kernel of ")#mi("{\\phi}")#text(" is")

#align(center)[#tao-fit-display[#tao-math("(1+o(1)) \\left|G\\right|^{-d} \\prod_{j=1}^\\infty (1 - \\frac{1}{p^j}).", block: true)]]

#text("The range of ")#mi("{T}")#text(" is the same thing as the subgroup of ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(" generated by ")#mi("{d}")#text(" random elements ")#mi("{x_1,\\ldots,x_d}")#text(" of that group. The kernel of ")#mi("{\\phi}")#text(" has index ")#tao-math("{\\left|G\\right|}", block: false)#text(" inside ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(", so the probability that all of those random elements lie in the kernel of ")#mi("{\\phi}")#text(" is ")#tao-math("{\\left|G\\right|^{-d}}", block: false)#text(". So it suffices to prove the following claim: if ")#mi("{\\phi}")#text(" is a fixed surjective homomorphism from ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(" to ")#mi("{G}")#text(", and ")#mi("{x_1,\\ldots,x_d}")#text(" are chosen randomly from the kernel of ")#mi("{\\phi}")#text(", then ")#mi("{x_1,\\ldots,x_d}")#text(" will generate that kernel with probability ")#metadata(none) <tao-da30e45705f79aa7555b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(1+o(1)) \\prod_{j=1}^\\infty (1 - \\frac{1}{p^j}).")]]

#text("But from the classification of ")#mi("{p}")#text("-groups, the kernel of ")#mi("{\\phi}")#text(" (which has bounded index inside ")#mi("{({\\mathbb Z}/p^n{\\mathbb Z})^d}")#text(") is isomorphic to ")#metadata(none) <tao-e0e4548df88a35d5854d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("({\\mathbb Z}/p^{n-O(1)}{\\mathbb Z}) \\times \\ldots \\times ({\\mathbb Z}/p^{n-O(1)}{\\mathbb Z})")]]

#text("where ")#mi("{O(1)}")#text(" means “bounded uniformly in ")#mi("{n}")#text("“, and there are ")#mi("{d}")#text(" factors here. As in the previous argument, one can now imagine starting with the group ")#link(<tao-e0e4548df88a35d5854d>)[#text("(5)")]#text(", and then iterating ")#mi("{d}")#text(" times the operation of quotienting out by the group generated by a randomly chosen element; our task is to compute the probability that one ends up with the trivial group by applying this process.")

#text("As before, at the ")#mi("{j^{th}}")#text(" stage of the iteration, one ends up with a group of the form ")#metadata(none) <tao-06efe37f5e983469e860>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("({\\mathbb Z}/p^{n-O(1)}{\\mathbb Z}) \\times \\ldots \\times ({\\mathbb Z}/p^{n-O(1)}{\\mathbb Z}) \\times G_j")]]

#text("where there are ")#mi("{d-j}")#text(" factors of ")#mi("{({\\mathbb Z}/p^{n-O(1)}{\\mathbb Z})}")#text(". The group ")#mi("{G_j}")#text(" is increasing in size, so the only way in which one ends up with the trivial group is if all the ")#mi("{G_j}")#text(" are trivial. But if ")#mi("{G_j}")#text(" is trivial, the only way that ")#mi("{G_{j+1}}")#text(" is trivial is if the randomly chosen element from ")#link(<tao-06efe37f5e983469e860>)[#text("(6)")]#text(" has a ")#mi("{({\\mathbb Z}/p^{n-O(1)}{\\mathbb Z}) \\times \\ldots \\times ({\\mathbb Z}/p^{n-O(1)}{\\mathbb Z})}")#text(" component which is invertible (i.e. not a multiple of ")#mi("{p}")#text("), which occurs with probability ")#mi("{1 - p^{-(d-j)}}")#text(" (assuming ")#mi("{n}")#text(" is large enough). Multiplying all these probabilities together gives ")#link(<tao-da30e45705f79aa7555b>)[#text("(4)")]#text(".")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41675")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2009")])]

#emph[#text("indeed, it seems that homotopy theorists almost think of topological spaces and groups as being essentially the same concept, despite looking very different at first glance")]

#text("Well, not always. When people study spaces with a trivial or tightly controlled fundamental group, then (in interesting cases) no serious connection arises between manifolds and group theory. For instance, the study of simply-connected smooth 4-manifolds. However, when a space has a complicated fundamental group, then there is already lots to study if you simplify the space to the classifying space of its fundamental group. Indeed, many interesting spaces, for instance hyperbolic manifolds, already are classifying spaces.")

#text("In 3-manifold topology, you never step all that far away from classifying spaces of the fundamental groups that can arise. They aren’t exactly the same in all cases, but close. On the other hand, this is a phenomenon that only holds up to dimension 3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41676")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2009")])]

#text("Sorry, you meant your comment in the more general sense of all of the homotopy groups of a space rather than just the fundamental group; and in the weaker sense of homotopy type rather than (say) diffeomorphism type.")

#text("In this case, yes, there is a classic construction, called a Postnikov tower, that models all of the homotopy information of any cell complex in terms of homotopy groups. The motivation is fairly simple. Suppose that X and Y are two cell complexes and you are trying to compute the homotopy types of maps from X to Y. If you freeze the (n-1)-skeleton of the map, then the different things that the n-cells can do are described by homotopy groups. You can then climb up the skeleta of X by induction.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41677")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2009")])]

#text("I think that this claim “If x is indeed divisible by p^i but not p^{i+1}, a little thought will then reveal that |G_{j+1}| = p^i |G_j|” does not quite work.")

#text("Let G_j be Z/p^2, let y generate G_j and let x be divisible by p^{n-1} but not p^n. Then G_{j+1} has order p^n, not p^{n+1} as your formula would give.")

#text("This sort of issue is negligible as n goes to infinity. I can show that there is no problem if we send n to infinity first, and then send d to infinity. (In which case, one can just think about random maps from Z_p^d to itself, where Z_p is the p-adics.) But it seems to me to be not completely obvious if d goes to infinity first.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41682")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2009")])]

#text("Hmm, fair point. One can still control everything by slapping quantitative bounds on how large the G_j get most of the time (there’s a lot of exponential decay around the place that prevents the G_j from getting anywhere close to ")#mi("p^n")#text(" in size, and which then means that it’s only the incredibly rare large i that cause difficulty), but it begins to get a bit icky, and I suppose the simplest solution is indeed to retreat to the p-adics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec2f78ceb57d9bd64b34cc4b78429f1c5eac54c83816135c602986374a75021-e038760ba298b6b7b263cacae9f591e1977f4216ef31f5659d7913e113c583d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41689")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2009")])]

#text("Thanks for writing up your summaries of key points in these plenary lectures. I attended the Calegari and Venkatesh talks, but missed the Getzler, Abuzaid and Gaitsgory talks, due to a combination of illness and having to work on my MASCOS talk. You certainly got more out of these talks than I did. I’ll have a bit of work when I get back to my office in looking up all the references to Hatcher’s book – being a rank beginner in algebraic topology myself. I wonder if the rest of the plenary audiences were as on-the-ball as you were?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20d797b53d730fce1ebcc039214349c7753246b819222d94aac892705e0f787e-d3861ee35a6ed7ec1e214d271e83aebfde315447c65c354e04e5b45e75e8fa70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41698")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2009")])]

#text("Dear Terry,")

#text("When considering real quadratic fields of class number one, you should probably restrict to fields ")#mi("\\mathbb{Q}(\\sqrt{d})")#text(" with ")#mi("d = \\ell")#text(" prime. (When ")#mi("d")#text(" has at least three divisors, the class group always has even order.) ")#emph[#text("[Corrected, thanks! Akshay mentioned this in passing during the lecture, but I forgot to mention it here. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80ed17b0a9ca583b1105e476b6af80dd8f244fcc9a23ade804810bf73d37f0b-01a28f9cc6b908126320c63a0dcd0e26b95be19c987a15b8c7f6a7991f3abce6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41700")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2009")])]

#text("I wonder if you could tell us about your sense of the ")#link("http://golem.ph.utexas.edu/category/2007/04/the_two_cultures_of_mathematic.html")[#text("Two Cultures")]#text(" divide when you attend talks such as those you describe from the other side.")

#text("Recently I came across a ")#link("http://www.math.harvard.edu/~elkies/M259.02/intro.pdf")[#text("course introduction")]#text(" by Noam Elkies in which he says:")

#text("“The Harvard math curriculum leans heavily towards the systematic, theory-building style; analytic number theory as usually practiced falls in the problem-solving camp. This is probably why, despite its illustrious history (Euclid, Euler, Riemann, Selberg, … ) and present-day vitality, analytic number theory has rarely been taught here. … Now we shall see that there is more to analytic number theory than a bag of unrelated ad-hoc tricks, but it is true that partisans of contravariant functors, adelic tangent sheaves, and etale cohomology will not find them in the present course. Still, even ardent structuralists can benefit from this course. … An ambitious theory-builder should regard the absence thus far of a Grand Unified Theory of analytic number theory not as an insult but as a challenge. Both machinery- and problem-motivated mathematicians should note that some of the more exciting recent work in number theory depends critically on symbiosis between the two styles of mathematics.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41708")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2009")])]

#text("Actually, I found the plenary talks at this conference remarkably accessible – there was a strong emphasis on basic examples, motivation, and intuition rather than definitions and proofs. But it helped that I already had familiarity with some of the concepts being discussed (e.g. connections, simplicial homology, schemes, Lagrangian submanifolds, number fields, Picard variety, etc.).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80ed17b0a9ca583b1105e476b6af80dd8f244fcc9a23ade804810bf73d37f0b-01a28f9cc6b908126320c63a0dcd0e26b95be19c987a15b8c7f6a7991f3abce6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41799")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2009")])]

#text("I suppose what really interests me is how you see your structure/pseudorandomness dichotomy relate to work on the ‘theory-building’ side. The latter seem to be aiming for a huge web of categorified dualities, possibly to be seen as a form of ")#link("http://ncatlab.org/nlab/show/space+and+quantity")[#text("space-quantity")]#text(" duality.")

#text("Do you see this work as an exploration of the ‘structure’ part of your dichotomy, so that pseudorandomness will escape their grasp, or is it better not to conflate your ‘structure’ and their ‘structure’?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41804")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2009")])]

#text("Hmm. It does seem that categorification and similar theoretical frameworks are currently better for manipulating the type of exact mathematical properties (identities, exact symmetries, etc.) that show up in structured objects than the fuzzier type of properties (correlation, approximation, independence, etc.) that show up in pseudorandom objects, but this may well be just a reflection of the state of the art than of some fundamental restriction. For instance, in my work on the Gowers uniformity norms, there are hints of some sort of “noisy additive cohomology” beginning to emerge – for instance, one may have some sort of function which is “approximately linear” in the sense that its second “derivative” is “mostly negligible”, and one wants to show that it in fact differs from a genuinely linear function by some “small” error; this strongly feels like a cohomological question, but we do not yet have the abstract theoretical machinery to place it in the classical cohomology framework (except perhaps in the ergodic theory limit of these problems, where there does seem to be a reasonable interpretation of these informal concepts). Similarly, when considering inverse theorems in additive combinatorics, a lot of what we do has the feel of “noisy group theory”, and we can already develop noisy analogues of some primitive group theory concepts (e.g. quotient groups, group extensions, the homomorphism theorems, etc.), but we are nowhere near the level of sophistication (and categorification, etc.) with noisy algebra that exact algebra enjoys right now. But perhaps that will change in the future.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80ed17b0a9ca583b1105e476b6af80dd8f244fcc9a23ade804810bf73d37f0b-01a28f9cc6b908126320c63a0dcd0e26b95be19c987a15b8c7f6a7991f3abce6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41824")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2009")])]

#text("Fascinating, thanks for this. When you finally write the book called ‘Noisy Group Theory’ it will be interesting to see in which sections the bookshops mistakenly place it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TooMuchCoffeeMan")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41828")[#strong[#text("TooMuchCoffeeMan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2009")])]

#text("At the risk of talking at cross-purposes, or being facile, there are simpler (but still quite hard and interesting, for some of us at least) versions of some of the questions Terry mentions: see")

#text("MR0928525 (89h:46072) Johnson, B. E. Approximately multiplicative maps between Banach algebras. J. London Math. Soc. (2) 37 (1988), no. 2, 294–316.")

#text("MR0864452 (87k:46105) Johnson, B. E. Approximately multiplicative functionals. J. London Math. Soc. (2) 34 (1986), no. 3, 489–510.")

#text("MR0701524 (85f:28006)")#linebreak()#text(" Kalton, N. J.(1-MO); Roberts, James W.(1-SC)")#linebreak()#text(" Uniformly exhaustive submeasures and nearly additive set functions.")#linebreak()#text(" Trans. Amer. Math. Soc. 278 (1983), no. 2, 803–816.")

#text("The last of these is related (I think) to certain questions about the cohomology of a certain Banach algebra, namely the l^1-completion of the polynomial algebra in countably many variables – although I have never quite wrung the full details out of the person who assured me of this. I’d be very interested to know if it fits into the circle of ideas concerning decomposition into structured and pseudorandom parts.")

#text("On reflection, all of the articles I mention are imposing quite strong global conditions on the “approximate cocycle”, and this might not be what you want – the notion of small second derivative is still quite a local condition and may not fit into the approaches I’ve referred to.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john mangual")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41756")[#strong[#text("john mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("I am not denying that measure you give on p-groups is very interesting, but why not naively pick random sequences of integers ")#mi("n_i")#text(" and choose your group to be ")#mi("\\mathbb{Z}_{n_1} \\times \\dots \\times \\mathbb{Z}_{n_k}")#text(" ? Is there something special about this particular measure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Unfortunately, there is no canonical choice of probability measure on the integers to use here (also, one needs to somehow pick the integer k), so the notion of “random sequences of integers” is not well defined.")

#text("The idea of building a random p-group by placing a large number of random relations on a large number of generators is broadly analogous to (a commutative, torsion version of) Gromov’s notion of a random group, which is of importance in geometric group theory. And, of course, there is the intriguing connection to number theory as mentioned in the post, somewhat analogous to the (still not well understood) connection between the eigenvalue spacing statistics of GUE random matrices and the spacing statistics of zeroes of the Riemann zeta function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41763")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Dear Terry,")

#text("Do you tend to take notes at conferences? Or do you think that this is a bad practice?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41767")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("I used to take notes fairly frequently when I was a graduate student, but nowadays I find it is generally more effective to try to understand the talk in real time, and try to catch up afterwards if necessary by asking questions of the speaker, and/or obtaining and reading the slides and source references. In many cases, my main objective is just to get a flavour of the subject, rather than the details, and notes are not particularly useful for that task.")

#text("The main exception is for talks which I intend to transcribe in full to this blog, such as the distinguished lecture series at UCLA, in which I do indeed take plenty of notes.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grothendieck’s definition of a group « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-41890")[#strong[#text("Grothendieck’s definition of a group « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("[…] a recent talk by Ezra Getzler, I learned a more sophisticated perspective on a group, somewhat analogous to Thurston’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avila, Bhargava, Hairer, Mirzakhani | What's new")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-404904")[#strong[#text("Avila, Bhargava, Hairer, Mirzakhani | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2014")])]

#text("[…] a certain random -adic matrix, very much in the spirit of the Cohen-Lenstra heuristics discussed in this previous post). But what is even more impressive is that Manjul and his coauthors have been able to verify […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-446940")[#strong[#text("Galois Groups vs. Fundamental Groups | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2014")]

#text("[…] a recent blog post Terry Tao mentions in passing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Counting objects up to isomorphism: groupoid cardinality | What's new")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-479819")[#strong[#text("Counting objects up to isomorphism: groupoid cardinality | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#text("[…] groups in number theory and combinatorics, such as the class groups of random quadratic fields; see this previous blog post for more discussion. I’ve been told that this notion of cardinality up to isomorphism is also […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95e37936aa19bf81642721da9ef8691f25090f7fa288a6af7dd7b3d22f679e95-3a048da3b918f1896dd24815747ae5c62caec541eb403ac29500d77c4e250675.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charlie O'Mara")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-552542")[#strong[#text("Charlie O'Mara")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("why are the products taken over all odd primes, and don’t include p=2 when making the probability calculations? I feel like i’m missing something rather fundamental.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-552560")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("I’m not an expert in algebraic number theory, but I think this has to do with Gauss’s genus theory which constrains the 2-torsion component of the class group for both real and imaginary quadratic fields. ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=887792")[#text("This paper of Gerth")]#text(" may be able to give more detail, but I currently do not have access to it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95e37936aa19bf81642721da9ef8691f25090f7fa288a6af7dd7b3d22f679e95-3a048da3b918f1896dd24815747ae5c62caec541eb403ac29500d77c4e250675.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charlie O'Mara")]], [#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/#comment-552573")[#strong[#text("Charlie O'Mara")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Yes, thank you. Xuejun Guo gives a nice writeup. ")#link("http://maths.nju.edu.cn/~guoxj/articles/2009Gauss.pdf")[#text("http://maths.nju.edu.cn/~guoxj/articles/2009Gauss.pdf")]
]
]
]
