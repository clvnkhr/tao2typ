// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:19:38.637079+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Decoupling and the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Decoupling and the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 December 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/")[#text("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given any finite collection of elements ")#mi("{(f_i)_{i \\in I}}")#text(" in some Banach space ")#mi("{X}")#text(", the triangle inequality tells us that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i \\in I} f_i \\right\\|_X \\leq \\sum_{i \\in I} \\left\\|f_i\\right\\|_X.", block: true)]]

#text("However, when the ")#mi("{f_i}")#text(" all “oscillate in different ways”, one expects to improve substantially upon the triangle inequality. For instance, if ")#mi("{X}")#text(" is a Hilbert space and the ")#mi("{f_i}")#text(" are mutually orthogonal, we have the Pythagorean theorem")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i \\in I} f_i \\right\\|_X = (\\sum_{i \\in I} \\left\\|f_i\\right\\|_X^2)^{1/2}.", block: true)]]

#text("For sake of comparison, from the triangle inequality and Cauchy-Schwarz one has the general inequality ")#metadata(none) <tao-5f2b1d6f5492140fa7b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\sum_{i \\in I} f_i \\right\\|_X \\leq (\\# I)^{1/2} (\\sum_{i \\in I} \\left\\|f_i\\right\\|_X^2)^{1/2}", block: true)]]



#text(" for any finite collection ")#mi("{(f_i)_{i \\in I}}")#text(" in any Banach space ")#mi("{X}")#text(", where ")#mi("{\\# I}")#text(" denotes the cardinality of ")#mi("{I}")#text(". Thus orthogonality in a Hilbert space yields “square root cancellation”, saving a factor of ")#mi("{(\\# I)^{1/2}}")#text(" or so over the trivial bound coming from the triangle inequality.")

#text("More generally, let us somewhat informally say that a collection ")#mi("{(f_i)_{i \\in I}}")#text(" exhibits ")#emph[#text("decoupling in ")#mi("{X}")]#text(" if one has the Pythagorean-like inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i \\in I} f_i \\right\\|_X \\ll_\\varepsilon (\\# I)^\\varepsilon (\\sum_{i \\in I} \\left\\|f_i\\right\\|_X^2)^{1/2}", block: true)]]

#text("for any ")#mi("{\\varepsilon>0}")#text(", thus one obtains almost the full square root cancellation in the ")#mi("{X}")#text(" norm. The theory of ")#emph[#text("almost orthogonality")]#text(" can then be viewed as the theory of decoupling in Hilbert spaces such as ")#mi("{L^2({\\bf R}^n)}")#text(". In ")#mi("{L^p}")#text(" spaces for ")#mi("{p < 2}")#text(" one usually does not expect this sort of decoupling; for instance, if the ")#mi("{f_i}")#text(" are disjointly supported one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i \\in I} f_i \\right\\|_{L^p} = (\\sum_{i \\in I} \\left\\|f_i\\right\\|_{L^p}^p)^{1/p}", block: true)]]

#text("and the right-hand side can be much larger than ")#tao-math("{(\\sum_{i \\in I} \\left\\|f_i\\right\\|_{L^p}^2)^{1/2}}", block: false)#text(" when ")#mi("{p < 2}")#text(". At the opposite extreme, one usually does not expect to get decoupling in ")#mi("{L^\\infty}")#text(", since one could conceivably align the ")#mi("{f_i}")#text(" to all attain a maximum magnitude at the same location with the same phase, at which point the triangle inequality in ")#mi("{L^\\infty}")#text(" becomes sharp.")

#text("However, in some cases one can get decoupling for certain ")#mi("{2 < p < \\infty}")#text(". For instance, suppose we are in ")#mi("{L^4}")#text(", and that ")#mi("{f_1,\\dots,f_N}")#text(" are ")#emph[#text("bi-orthogonal")]#text(" in the sense that the products ")#mi("{f_i f_j}")#text(" for ")#mi("{1 \\leq i < j \\leq N}")#text(" are pairwise orthogonal in ")#mi("{L^2}")#text(". Then we have")

#tao-aligned(keep: false)[


#tao-math("\\left\\| \\sum_{i = 1}^N f_i \\right\\|_{L^4}^2  & = \\left\\| (\\sum_{i=1}^N f_i)^2 \\right\\|_{L^2}", block: true)



#tao-math(" & = \\left\\| \\sum_{1 \\leq i,j \\leq N} f_i f_j \\right\\|_{L^2}", block: true)



#tao-math(" & \\ll (\\sum_{1 \\leq i,j \\leq N} \\left\\|f_i f_j \\right\\|_{L^2}^2)^{1/2}", block: true)



#tao-math(" & = \\left\\| (\\sum_{1 \\leq i,j \\leq N} \\left|f_i f_j\\right|^2)^{1/2} \\right\\|_{L^2}", block: true)



#tao-math(" & = \\left\\| \\sum_{i=1}^N \\left|f_i\\right|^2 \\right\\|_{L^2}", block: true)



#tao-math(" & \\leq \\sum_{i=1}^N \\left\\| \\left|f_i\\right|^2 \\right\\|_{L^2}", block: true)



#tao-math(" & = \\sum_{i=1}^N \\left\\|f_i\\right\\|_{L^4}^2", block: true)
]

#text("giving decoupling in ")#mi("{L^4}")#text(". (Similarly if each of the ")#mi("{f_i f_j}")#text(" is orthogonal to all but ")#mi("{O_\\varepsilon( N^\\varepsilon )}")#text(" of the other ")#mi("{f_{i^{\\prime}} f_{j^{\\prime}}}")#text(".) A similar argument also gives ")#mi("{L^6}")#text(" decoupling when one has tri-orthogonality (with the ")#mi("{f_i f_j f_k}")#text(" mostly orthogonal to each other), and so forth. As a slight variant, ")#link("https://en.wikipedia.org/wiki/Khintchine_inequality")[#text("Khintchine’s inequality")]#text(" also indicates that decoupling should occur for any fixed ")#mi("{2 < p < \\infty}")#text(" if one multiplies each of the ")#mi("{f_i}")#text(" by an independent random sign ")#mi("{\\epsilon_i \\in \\{-1,+1\\}}")#text(".")

#text("In recent years, Bourgain and Demeter have been establishing ")#emph[#text("decoupling theorems")]#text(" in ")#mi("{L^p({\\bf R}^n)}")#text(" spaces for various key exponents of ")#mi("{2 < p < \\infty}")#text(", in the “restriction theory” setting in which the ")#mi("{f_i}")#text(" are Fourier transforms of measures supported on different portions of a given surface or curve; this builds upon the earlier decoupling theorems ")#link("http://www.ams.org/mathscinet-getitem?mr=1800068")[#text("of Wolff")]#text(". ")#link("http://arxiv.org/abs/1512.01565")[#text("In a recent paper with Guth")]#text(", they established the following decoupling theorem for the curve ")#mi("{\\gamma({\\bf R}) \\subset {\\bf R}^n}")#text(" parameterised by the polynomial curve")

#align(center)[#tao-fit-display[#mitex("\\gamma: t \\mapsto (t, t^2, \\dots, t^n).")]]

#text("For any ball ")#mi("{B = B(x_0,r)}")#text(" in ")#mi("{{\\bf R}^n}")#text(", let ")#mi("{w_B: {\\bf R}^n \\rightarrow {\\bf R}^+}")#text(" denote the weight")

#align(center)[#tao-fit-display[#tao-math("w_B(x) := \\frac{1}{(1 + \\frac{\\left|x-x_0\\right|}{r})^{100n}},", block: true)]]

#text("which should be viewed as a smoothed out version of the indicator function ")#mi("{1_B}")#text(" of ")#mi("{B}")#text(". In particular, the space ")#mi("{L^p(w_B) = L^p({\\bf R}^n, w_B(x)\\ dx)}")#text(" can be viewed as a smoothed out version of the space ")#mi("{L^p(B)}")#text(". For future reference we observe a fundamental self-similarity of the curve ")#mi("{\\gamma({\\bf R})}")#text(": any arc ")#mi("{\\gamma(I)}")#text(" in this curve, with ")#mi("{I}")#text(" a compact interval, is affinely equivalent to the standard arc ")#mi("{\\gamma([0,1])}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Decoupling theorem)")]#text(" ")#metadata(none) <tao-e7502c799b8f76fbed07>#text(" Let ")#mi("{n \\geq 1}")#text(". Subdivide the unit interval ")#mi("{[0,1]}")#text(" into ")#mi("{N}")#text(" equal subintervals ")#mi("{I_i}")#text(" of length ")#mi("{1/N}")#text(", and for each such ")#mi("{I_i}")#text(", let ")#mi("{f_i: {\\bf R}^n \\rightarrow {\\bf R}}")#text(" be the Fourier transform")

#align(center)[#tao-fit-display[#mitex("f_i(x) = \\int_{\\gamma(I_i)} e(x \\cdot \\xi)\\ d\\mu_i(\\xi)")]]

#text("of a finite Borel measure ")#mi("{\\mu_i}")#text(" on the arc ")#mi("{\\gamma(I_i)}")#text(", where ")#mi("{e(\\theta) := e^{2\\pi i \\theta}}")#text(". Then the ")#mi("{f_i}")#text(" exhibit decoupling in ")#mi("{L^{n(n+1)}(w_B)}")#text(" for any ball ")#mi("{B}")#text(" of radius ")#mi("{N^n}")#text(".")
]

#text("Orthogonality gives the ")#mi("{n=1}")#text(" case of this theorem. The bi-orthogonality type arguments sketched earlier only give decoupling in ")#mi("{L^p}")#text(" up to the range ")#mi("{2 \\leq p \\leq 2n}")#text("; the point here is that we can now get a much larger value of ")#mi("{n}")#text(". The ")#mi("{n=2}")#text(" case of this theorem was previously established ")#link("http://arxiv.org/abs/1403.5335")[#text("by Bourgain and Demeter")]#text(" (who obtained in fact an analogous theorem for any curved hypersurface). The exponent ")#mi("{n(n+1)}")#text(" (and the radius ")#mi("{N^n}")#text(") is best possible, as can be seen by the following basic example. If")

#align(center)[#tao-fit-display[#mitex("f_i(x) := \\int_{I_i} e(x \\cdot \\gamma(\\xi)) g_i(\\xi)\\ d\\xi")]]

#text("where ")#mi("{g_i}")#text(" is a bump function adapted to ")#mi("{I_i}")#text(", then standard Fourier-analytic computations show that ")#mi("{f_i}")#text(" will be comparable to ")#mi("{1/N}")#text(" on a rectangular box of dimensions ")#mi("{N \\times N^2 \\times \\dots \\times N^n}")#text(" (and thus volume ")#mi("{N^{n(n+1)/2}}")#text(") centred at the origin, and exhibit decay away from this box, with ")#tao-math("{\\left\\|f_i\\right\\|_{L^{n(n+1)}(w_B)}}", block: false)#text(" comparable to")

#align(center)[#tao-fit-display[#mitex("1/N \\times (N^{n(n+1)/2})^{1/(n(n+1))} = 1/\\sqrt{N}.")]]

#text("On the other hand, ")#mi("{\\sum_{i=1}^N f_i}")#text(" is comparable to ")#mi("{1}")#text(" on a ball of radius comparable to ")#mi("{1}")#text(" centred at the origin, so ")#tao-math("{\\left\\|\\sum_{i=1}^N f_i\\right\\|_{L^{n(n+1)}(w_B)}}", block: false)#text(" is ")#mi("{\\gg 1}")#text(", which is just barely consistent with decoupling. This calculation shows that decoupling will fail if ")#mi("{n(n+1)}")#text(" is replaced by any larger exponent, and also if the radius of the ball ")#mi("{B}")#text(" is reduced to be significantly smaller than ")#mi("{N^n}")#text(".")

#text("This theorem has the following consequence of importance in analytic number theory:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2 (Vinogradov main conjecture)")]#text(" Let ")#mi("{s, n, N \\geq 1}")#text(" be integers, and let ")#mi("{\\varepsilon > 0}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\int_{[0,1]^n} \\left|\\sum_{j=1}^N e( j x_1 + j^2 x_2 + \\dots + j^n x_n)\\right|^{2s}\\ dx_1 \\dots dx_n", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll_{\\varepsilon,s,n} N^{s+\\varepsilon} + N^{2s - \\frac{n(n+1)}{2}+\\varepsilon}.")]]
]

#emph[#text("Proof:")]#text(" By the Hölder inequality (and the trivial bound of ")#mi("{N}")#text(" for the exponential sum), it suffices to treat the critical case ")#mi("{s = n(n+1)/2}")#text(", that is to say to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_{[0,1]^n} \\left|\\sum_{j=1}^N e( j x_1 + j^2 x_2 + \\dots + j^n x_n)\\right|^{n(n+1)}\\ dx_1 \\dots dx_n \\ll_{\\varepsilon,n} N^{\\frac{n(n+1)}{2}+\\varepsilon}.", block: true)]]

#text("We can rescale this as")

#align(center)[#tao-fit-display[#tao-math("\\int_{[0,N] \\times [0,N^2] \\times \\dots \\times [0,N^n]} \\left|\\sum_{j=1}^N e( x \\cdot \\gamma(j/N) )\\right|^{n(n+1)}\\ dx \\ll_{\\varepsilon,n} N^{n(n+1)+\\varepsilon}.", block: true)]]

#text("As the integrand is periodic along the lattice ")#mi("{N{\\bf Z} \\times N^2 {\\bf Z} \\times \\dots \\times N^n {\\bf Z}}")#text(", this is equivalent to")

#align(center)[#tao-fit-display[#tao-math("\\int_{[0,N^n]^n} \\left|\\sum_{j=1}^N e( x \\cdot \\gamma(j/N) )\\right|^{n(n+1)}\\ dx \\ll_{\\varepsilon,n} N^{\\frac{n(n+1)}{2}+n^2+\\varepsilon}.", block: true)]]

#text("The left-hand side may be bounded by ")#tao-math("{\\ll \\left\\| \\sum_{j=1}^N f_j \\right\\|_{L^{n(n+1)}(w_B)}^{n(n+1)}}", block: false)#text(", where ")#mi("{B := B(0,N^n)}")#text(" and ")#mi("{f_j(x) := e(x \\cdot \\gamma(j/N))}")#text(". Since")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_j \\right\\|_{L^{n(n+1)}(w_B)} \\ll (N^{n^2})^{\\frac{1}{n(n+1)}},", block: true)]]

#text("the claim now follows from the decoupling theorem and a brief calculation. ")#mi("\\Box")

#text("Using the Plancherel formula, one may equivalently (when ")#mi("{s}")#text(" is an integer) write the Vinogradov main conjecture in terms of solutions ")#mi("{j_1,\\dots,j_s,k_1,\\dots,k_s \\in \\{1,\\dots,N\\}}")#text(" to the system of equations")

#align(center)[#tao-fit-display[#mitex("j_1^i + \\dots + j_s^i = k_1^i + \\dots + k_s^i \\forall i=1,\\dots,n,")]]

#text("but we will not use this formulation here.")

#text("A history of the Vinogradov main conjecture may be found in ")#link("http://arxiv.org/pdf/1404.3508v1.pdf")[#text("this survey of Wooley")]#text("; prior to the Bourgain-Demeter-Guth theorem, the conjecture was solved completely for ")#mi("{n \\leq 3}")#text(", or for ")#mi("{n > 3}")#text(" and ")#mi("{s}")#text(" either below ")#mi("{n(n+1)/2 - n/3 + O(n^{2/3})}")#text(" or above ")#mi("{n(n-1)}")#text(", with the bulk of recent progress coming from the ")#emph[#text("efficient congruencing")]#text(" technique of Wooley. It has numerous applications to exponential sums, Waring’s problem, and the zeta function; to give just one application, the main conjecture implies the predicted asymptotic for the number of ways to express a large number as the sum of ")#mi("{23}")#text(" fifth powers (the previous best result required ")#mi("{28}")#text(" fifth powers). The Bourgain-Demeter-Guth approach to the Vinogradov main conjecture, based on decoupling, is ostensibly very different from the efficient congruencing technique, which relies heavily on the arithmetic structure of the program, but it appears (as I have been told from second-hand sources) that the two methods are actually closely related, with the former being a sort of “Archimedean” version of the latter (with the intervals ")#mi("{I_i}")#text(" in the decoupling theorem being analogous to congruence classes in the efficient congruencing method); hopefully there will be some future work making this connection more precise. One advantage of the decoupling approach is that it generalises to non-arithmetic settings in which the set ")#mi("{\\{1,\\dots,N\\}}")#text(" that ")#mi("{j}")#text(" is drawn from is replaced by some other similarly separated set of real numbers. (A random thought – could this allow the Vinogradov-Korobov bounds on the zeta function to extend to Beurling zeta functions?)")

#text("Below the fold we sketch the Bourgain-Demeter-Guth argument proving Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(".")

#text("I thank Jean Bourgain and Andrew Granville for helpful discussions.")

#metadata(none) <tao-e135b85dcb25f32c0c6e>

#heading(level: 1)[#strong[#text(" — 1. Initial reductions — ")]]

#text("The claim will proceed by an induction on dimension, thus we assume henceforth that ")#mi("{n \\geq 2}")#text(" (the ")#mi("{n=1}")#text(" case being immediate from the Pythagorean theorem) and that Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(" has already been proven for smaller values of ")#mi("{n}")#text(". This has the following nice consequence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Lower dimensional decoupling)")]#text(" ")#metadata(none) <tao-2cfb1daa7c84a5a8fbd3>#text(" Let the notation be as in Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(". Suppose also that ")#mi("{n \\geq 2}")#text(", and that Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(" has already been proven for all smaller values of ")#mi("{n}")#text(". Then for any ")#mi("{1 \\leq k < n}")#text(", the ")#mi("{f_i}")#text(" exhibits decoupling in ")#mi("{L^{k(k+1)}(w_B)}")#text(" for any ball ")#mi("{B}")#text(" of radius ")#mi("{N^k}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) We slice the ball ")#mi("{B}")#text(" into ")#mi("{k}")#text("-dimensional slices parallel to the first ")#mi("{k}")#text(" coordinate directions. On each slice, the ")#mi("{f_i}")#text(" can be interpreted as functions on ")#mi("{{\\bf R}^n}")#text(" whose Fourier transform lie on the curve ")#mi("{\\gamma_k(I) \\subset {\\bf R}^k}")#text(", where ")#mi("{\\gamma_k(t) := (t,\\dots,t^k)}")#text(". Applying Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(" with ")#mi("{n}")#text(" replaced by ")#mi("{k}")#text(", and then integrating over all slices using Fubini’s theorem and Minkowski’s inequality (to interchange the ")#mi("{L^{k(k+1)}}")#text(" norm and the square function), we obtain the claim. ")#mi("\\Box")

#text("The first step, needed for technical inductive purposes, is to work at an exponent slightly below ")#mi("{n(n+1)}")#text(". More precisely, given any ")#mi("{2 < p < \\infty}")#text(" and ")#mi("{\\eta > 0}")#text(", let ")#mi("{P(p,\\eta)}")#text(" denote the assertion that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i=1}^N f_i \\right\\|_{L^p(w_B)} \\ll_{\\varepsilon,p,n} N^{\\eta+\\varepsilon} (\\sum_{i=1}^N \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2}", block: true)]]

#text("whenever ")#mi("{\\varepsilon>0}")#text(", ")#mi("{N \\geq 1}")#text(", ")#mi("{B}")#text(" and ")#mi("{f_1,\\dots,f_N}")#text(" are as in Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(". Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(" is then clearly equivalent to the claim ")#mi("{P(n(n+1),\\eta)}")#text(" holding for all ")#mi("{\\eta>0}")#text(". This turns out to be equivalent to the following variant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-5f751e08c9cb40a3e239>#text(" Let ")#mi("{n \\geq 2}")#text(", and assume Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(" has been established for all smaller values of ")#mi("{n}")#text(". If ")#mi("{p < n(n+1)}")#text(" is sufficiently close to ")#mi("{n(n+1)}")#text(", then ")#mi("{P(p,\\eta)}")#text(" holds for all ")#mi("{\\eta > 0}")#text(".")
]

#text("The reason for this is that the functions ")#mi("{f_i}")#text(" and ")#mi("{\\sum_{i=1}^N f_i}")#text(" all have Fourier transform supported on a ball of radius ")#mi("{O(1)}")#text(", and so there is a Bernstein-type inequality that lets one replace the ")#mi("{L^p(w_B)}")#text(" norm of either function by the ")#mi("{L^{n(n+1)}(w_B)}")#text(" norm, losing a power of ")#mi("{N}")#text(" that goes to zero as ")#mi("{p}")#text(" goes to ")#mi("{n(n+1)}")#text(". (See Corollary 6.2 and Lemma 8.2 of ")#link("http://arxiv.org/abs/1512.01565")[#text("the Bourgain-Demeter-Guth paper")]#text(" for more details of this.)")

#text("Using the trivial bound ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(1)")]#text(" we see that ")#mi("{P(p,\\eta)}")#text(" holds for large ")#mi("{\\eta}")#text(" (e.g. ")#mi("{\\eta \\geq 1/2}")#text("). To reduce ")#mi("{\\eta}")#text(", it suffices to prove the following inductive claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Inductive claim)")]#text(" ")#metadata(none) <tao-abecdf3503635c0be9ec>#text(" Let ")#mi("{n \\geq 2}")#text(", and assume Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(" has been established for all smaller values of ")#mi("{n}")#text(". If ")#mi("{p < n(n+1)}")#text(" is sufficiently close to ")#mi("{n(n+1)}")#text(", and ")#mi("{P(p,\\eta)}")#text(" holds for some ")#mi("{\\eta > 0}")#text(", then ")#mi("{P(p,\\eta^{\\prime})}")#text(" holds for some ")#mi("{0 < \\eta^{\\prime} < \\eta}")#text(".")
]

#text("Since the set of ")#mi("{\\eta \\geq 0}")#text(" for which ")#mi("{P(p,\\eta)}")#text(" holds is clearly a closed half-infinite interval, Proposition ")#link(<tao-abecdf3503635c0be9ec>)[#text("5")]#text(" implies Proposition ")#link(<tao-5f751e08c9cb40a3e239>)[#text("4")]#text(" and hence Theorem ")#link(<tao-e7502c799b8f76fbed07>)[#text("1")]#text(".")

#text("Henceforth we fix ")#mi("{n,p,\\eta}")#text(" as in Proposition ")#link(<tao-abecdf3503635c0be9ec>)[#text("5")]#text(". We fix ")#mi("{n,p,\\eta}")#text(" and use ")#mi("{o(1)}")#text(" to denote any quantity that goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(", keeping ")#mi("{n,p,\\eta}")#text(" fixed. Then the ")#mi("{P(p,\\eta)}")#text(" hypothesis reads")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i=1}^N f_i \\right\\|_{L^p(w_B)} \\ll N^{\\eta+o(1)} (\\sum_{i=1}^N \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2}", block: true)]]

#text("and our task is to show that ")#metadata(none) <tao-11618a00f039995c82ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| \\sum_{i=1}^N f_i \\right\\|_{L^p(w_B)} \\ll N^{\\eta^{\\prime}+o(1)} (\\sum_{i=1}^N \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2}", block: true)]]



#text(" for some ")#mi("{0 < \\eta^{\\prime} < \\eta}")#text(".")

#text("The next step is to reduce matters to a “multilinear” version of the above estimate, in order to exploit a multilinear Kakeya estimate at a later stage of the argument. Let ")#mi("{M}")#text(" be a large integer depending only on ")#mi("{n}")#text(" (actually Bourgain, Demeter, and Guth choose ")#mi("{M := n!}")#text("). It turns out that it will suffice to prove the multilinear version ")#metadata(none) <tao-1e8e957d3800c0bfe002>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| \\text{geom} \\left|\\sum_{i \\in {\\mathcal I}_j} f_i\\right|\\right\\|_{L^p(w_B)} \\ll N^{\\eta^{\\prime}+o(1)} \\text{geom} (\\sum_{i \\in {\\mathcal I}_j} \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2}", block: true)]]



#text(" whenever ")#mi("{{\\mathcal I}_1,\\dots,{\\mathcal I}_M}")#text(" are families of disjoint subintervals on ")#mi("{[0,1]}")#text(" of length ")#mi("{1/N}")#text(" that are separated from each other by a distance of ")#mi("{\\gg 1}")#text(", and where ")#mi("{\\text{geom} = \\text{geom}_{j=1,\\dots,M}}")#text(" denotes the geometric mean")

#align(center)[#tao-fit-display[#mitex("\\text{geom} x_j := (x_1 \\dots x_M)^{1/M}.")]]

#text("We have the following nice equivalence (essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=2860188")[#text("due to Bourgain and Guth")]#text(", building upon an earlier “bilinear equivalence” result ")#link("http://www.ams.org/mathscinet-getitem?mr=1625056")[#text("of Vargas, Vega, and myself")]#text(", and discussed in ")#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/")[#text("this previous blog post")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Multilinear equivalence)")]#text(" ")#metadata(none) <tao-5ce977ed5726c6c55533>#text(" For any ")#mi("{\\eta^{\\prime}>0}")#text(", the estimates ")#link(<tao-11618a00f039995c82ba>)[#text("(2)")]#text(" and ")#link(<tao-1e8e957d3800c0bfe002>)[#text("(3)")]#text(" are equivalent.")
]

#emph[#text("Proof:")]#text(" The derivation of ")#link(<tao-1e8e957d3800c0bfe002>)[#text("(3)")]#text(" from ")#link(<tao-11618a00f039995c82ba>)[#text("(2)")]#text(" is immediate from Hölder’s inequality. To obtain the converse implication, let ")#mi("{A(N)}")#text(" denote the best constant in ")#link(<tao-11618a00f039995c82ba>)[#text("(2)")]#text(", thus ")#mi("{A(N)}")#text(" is the smallest constant such that ")#metadata(none) <tao-ea325d761f98c6b73320>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| \\sum_{i=1}^N f_i \\right\\|_{L^p(w_B)} \\leq A(N) (\\sum_{i=1}^N \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2}.", block: true)]]



#text(" The idea is to prove an inequality of the form")

#align(center)[#tao-fit-display[#mitex("A(N) \\ll A(N/K) + O_K( N^{\\eta^{\\prime} + o(1)} )")]]

#text("for any fixed integer ")#mi("{K>2M}")#text(" (with the implied constant in the ")#mi("{\\ll}")#text(" notation independent of ")#mi("{K}")#text("); by choosing ")#mi("{K}")#text(" large enough one can then prove ")#mi("{A(N) \\ll N^{\\eta^{\\prime}+o(1)}}")#text(" by an inductive argument.")

#text("We partition the ")#mi("{N}")#text(" intervals in ")#link(<tao-11618a00f039995c82ba>)[#text("(2)")]#text(" into ")#mi("{K}")#text(" classes ")#mi("{{\\mathcal I}_1,\\dots, {\\mathcal I}_K}")#text(" of ")#mi("{\\sim N/K}")#text(" consecutive intervals, so that ")#mi("{\\sum_{i=1}^N f_i}")#text(" can be expressed as ")#mi("{\\sum_{k=1}^K F_k}")#text(" where ")#mi("{F_k := \\sum_{i \\in {\\mathcal I}_k} f_i}")#text(". Observe that for any ")#mi("{x}")#text(", one either has")

#align(center)[#tao-fit-display[#tao-math("\\left|F_k(x)\\right| \\gg \\sum_{k=1}^K \\left|F_k(x)\\right|", block: true)]]

#text("for some ")#mi("{k=1,\\dots,K}")#text(" (i.e. one of the ")#tao-math("{\\left|F_k(x)\\right|}", block: false)#text(" dominates the sum), or else one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^K \\left|F_k(x)\\right| \\ll_K \\text{geom} \\left|F_{k_j}(x)\\right|", block: true)]]

#text("for some ")#mi("{k_1 < \\dots < k_M}")#text(" with the transversality condition ")#mi("{k_{j+1} - k_j > 1}")#text(". This leads to the pointwise inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^K \\left|F_k(x)\\right| \\ll \\sup_k \\left|F_k(x)\\right| + O_K( \\sum_{k_1 < \\dots < k_M, \\text{ transverse}} \\text{geom} \\left|F_{k_j}(x)\\right| ).", block: true)]]

#text("Bounding the supremum ")#tao-math("{\\sup_k \\left|F_k(x)\\right|}", block: false)#text(" by ")#tao-math("{(\\sum_{k=1}^K \\left|F_k(x)\\right|^p)^{1/p}}", block: false)#text(" and then taking ")#mi("{L^p}")#text(" norms and using ")#link(<tao-1e8e957d3800c0bfe002>)[#text("(3)")]#text(", we conclude that")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\sum_{i=1}^N f_i\\right\\|_{L^p(w_B)}  & \\ll (\\sum_{k=1}^K \\left\\| \\sum_{i \\in {\\mathcal I}_k} f_i \\right\\|_{L^p(w_B)}^p)^{1/p}", block: true)



#tao-math(" & + O_K( N^{\\eta^{\\prime}+o(1)} (\\sum_{i=1}^n \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2} ).", block: true)
]

#text("On the other hand, applying an affine rescaling to ")#link(<tao-ea325d761f98c6b73320>)[#text("(4)")]#text(" one sees that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i \\in {\\mathcal I}_k} f_i \\right\\|_{L^p(w_B)} \\leq A(N/K) (\\sum_{i \\in {\\mathcal I}_k} \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2},", block: true)]]

#text("and the claim follows. (A more detailed version of this argument may be found in Theorem 4.1 of ")#link("http://arxiv.org/abs/1409.1634")[#text("this paper of Bourgain and Demeter")]#text(".) ")#mi("\\Box")

#text("It thus suffices to show ")#link(<tao-1e8e957d3800c0bfe002>)[#text("(3)")]#text(".")

#text("The next step is to set up some intermediate scales between ")#mi("{1}")#text(" and ")#mi("{N}")#text(", in order to run an “induction on scales” argument. For any scale ")#mi("{r > 0}")#text(", any exponent ")#mi("{1 < t < \\infty}")#text(", and any function ")#mi("{f \\in L^t({\\bf R}^n)}")#text(", let ")#mi("{\\text{Avg}_{t,r} f \\in L^p({\\bf R}^n)}")#text(" denote the local ")#mi("{L^p}")#text(" average")

#align(center)[#tao-fit-display[#tao-math("\\text{Avg}_{t,r} f(x) := ( \\frac{1}{\\left|B(x,r)\\right|} \\int_{{\\bf R}^n} \\left|f(y)\\right|^t w_{B(x,r)}(y)\\ dy)^{1/t}", block: true)]]

#text("where ")#tao-math("{\\left|B(x,r)\\right|}", block: false)#text(" denotes the volume of ")#mi("{B(x,r)}")#text(" (one could also use the equivalent quantity ")#mi("{\\int_{{\\bf R}^n} w_{B(x,r)}(y)\\ dy}")#text(" here if desired). For any exponents ")#mi("{2 \\leq t < \\infty}")#text(", ")#mi("{0 \\leq q \\leq 1}")#text(", and ")#mi("{q \\leq s \\leq n}")#text(" (independent of ")#mi("{N}")#text("), let ")#mi("{a_t(q,s)}")#text(" denote the least exponent for which one has the local decoupling inequality ")#metadata(none) <tao-f5e19ad9fb2c307d5790>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left|\\text{Avg}_{t,N^s} f_{I}\\right|^2)^{1/2}\\right\\|_{L^p(w_B)}", block: true)]]





#align(center)[#tao-fit-display[#tao-math("\\ll N^{a_t(q,s)+o(1)} \\text{geom} (\\sum_{i \\in {\\mathcal I}_j} \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2}", block: true)]]

#text("for ")#mi("{f_i, B, {\\mathcal I}_j}")#text(" as in ")#link(<tao-1e8e957d3800c0bfe002>)[#text("(3)")]#text(", where the ")#mi("{1/N}")#text("-length intervals in ")#mi("{{\\mathcal I}_j}")#text(" have been covered by a family ")#mi("{{\\mathcal I}_{j,q}}")#text(" of finitely overlapping intervals of length ")#mi("{1/N^q}")#text(", and ")#mi("{f_I := \\sum_{i: I_i \\subset I} f_i}")#text(". It is then not difficult to see that the estimate ")#link(<tao-1e8e957d3800c0bfe002>)[#text("(3)")]#text(" is equivalent to the inequality")

#align(center)[#tao-fit-display[#mitex("a_2(0,0) \\leq \\eta^{\\prime}")]]

#text("(basically because when ")#mi("{q=0}")#text(", there is essentially only one ")#mi("{I}")#text(" for each ")#mi("{j}")#text(", and ")#mi("{f_I}")#text(" is basically ")#mi("{\\sum_{i \\in {\\mathcal I}_j} f_i}")#text("; also; the averaging ")#mi("{\\text{Avg}_{t,N^s}}")#text(" is essentially the identity when ")#mi("{s=0}")#text(" since all the ")#mi("{f_i}")#text(" and ")#mi("{f_I}")#text(" here have Fourier support on a ball of radius ")#mi("{O(1)}")#text("). To put it another way, our task is now to show that ")#metadata(none) <tao-4e1195df020de59e0d65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("a_2(0,0) < \\eta^{\\prime}")]]





#text("On the other hand, one can establish the following inequalities concerning the quantities ")#mi("{a_t(q,s)}")#text(", arranged roughly in increasing order of difficulty to prove.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Inequalities on ")#mi("{a_t(q,s)}")#text(")")]#text(" ")#metadata(none) <tao-525d7e6d7c831446d1d9>#text(" Throughout this proposition it is understood that ")#mi("{2 \\leq t < \\infty}")#text(", ")#mi("{0 \\leq q \\leq 1}")#text(", and ")#mi("{q \\leq s \\leq n}")#text(".")

#list(
[#text("(i) (Hölder) The quantity ")#mi("{a_t(q,s)}")#text(" is convex in ")#mi("{1/t}")#text(", and monotone nondecreasing in ")#mi("{t}")#text(".")],
[#text("(ii) (Minkowski) If ")#mi("{t=p}")#text(", then ")#mi("{a_t(q,s)}")#text(" is monotone non-decreasing in ")#mi("{s}")#text(".")],
[#text("(iii) (Stability) One has ")#mi("{a_2(q,s) = a_2(0,0) + O( q + s )}")#text(". (In fact, ")#mi("{a_t(q,s)}")#text(" is Lipschitz in ")#mi("{q,s}")#text(" uniformly in ")#mi("{t}")#text(", but we will not need this.)")],
[#text("(iv) (Rescaled decoupling hypothesis) If ")#mi("{t=p}")#text(" and ")#mi("{s=n}")#text(", then one has ")#mi("{a_t(q,s) \\leq (1-q) \\eta}")#text(".")],
[#text("(v) (Lower dimensional decoupling) If ")#mi("{1 \\leq k \\leq n-1}")#text(" and ")#mi("{q \\leq \\frac{s}{k}}")#text(", then ")#mi("{a_{k(k+1)}(q,s) \\leq a_{k(k+1)}(\\frac{s}{k},s)}")#text(".")],
[#text("(vi) (Multilinear Kakeya) If ")#mi("{1 \\leq k \\leq n-1}")#text(" and ")#mi("{(k+1)q \\leq n}")#text(", then ")#mi("{a_{kp/n}(q,kq) \\leq a_{kp/n}(q,(k+1)q)}")#text(".")]
)
]

#text("We sketch the proof of the various parts of this proposition in later sections. For now, let us show how these properties imply the claim ")#link(<tao-4e1195df020de59e0d65>)[#text("(6)")]#text(". In the paper of Bourgain, Demeter, and Guth, the above properties were iterated along a certain “tree” of parameters ")#mi("{(t,q,s)}")#text(", relying in (v) to increase the ")#mi("{q}")#text(" parameter (which measures the amount of decoupling) and (vi) to “inflate” or increase the ")#mi("{s}")#text(" parameter (which measures the spatial scale at which decoupling has been obtained), and (i) to reconcile the different choices of ")#mi("{t}")#text(" appearing in (v) and (vi), with the remaining properties (ii), (iii), (iv) used to control various “boundary terms” arising from this tree iteration. Here, we will present an essentially equivalent “Bellman function” formulation of the argument which replaces this iteration by a carefully (but rather unmotivatedly) chosen inductive claim. More precisely, let ")#mi("{\\varepsilon > 0}")#text(" be a small quantity (depending only on ")#mi("{p}")#text(" and ")#mi("{n}")#text(") to be chosen later. For any ")#mi("{W>0}")#text(", let ")#mi("{Q(W) = Q_\\eta(W)}")#text(" denote the claim that for every ")#mi("{k=2,\\dots,n}")#text(", and for all sufficiently small ")#mi("{u > 0}")#text(", one has the inequality ")#metadata(none) <tao-aaee9dc21d0a986d8001>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("a_t(u, ku) \\leq (1 - 2 Wu (n-k+1)")]]





#align(center)[#tao-fit-display[#mitex("+ (1-\\varepsilon) W u (k-1) k (n+1) (\\frac{1}{(k-1)k} - \\frac{1}{t} ) ) \\eta")]]

#text("for all ")#metadata(none) <tao-0b7f8f61f2c0f3904923>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("(k-1) k \\leq t \\leq \\frac{kp}{n},")]]



#text(" and also ")#metadata(none) <tao-4b7e94c5c3305a0d3645>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("a_t(u,u) \\leq (1 - Wu(n-1)) \\eta")]]



#text(" for ")#mi("{2 \\leq t \\leq p/n}")#text(".")

#text("From Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text(" (i), (ii), (iv), we see that ")#mi("{Q(W)}")#text(" holds for some small ")#mi("{W>0}")#text(". We will shortly establish the implication ")#metadata(none) <tao-ced2128f3bc92a5720f7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("Q(W) \\implies Q( (1+\\delta) W )")]]



#text(" for some ")#mi("{\\delta>0}")#text(" independent of ")#mi("{W}")#text("; this implies upon iteration that ")#mi("{Q(W)}")#text(" holds for arbitrarily large values of ")#mi("{W}")#text(". Applying ")#link(<tao-4b7e94c5c3305a0d3645>)[#text("(9)")]#text(" with ")#mi("{t=2}")#text(" for a sufficiently large ")#mi("{W}")#text(" and a sufficiently small ")#mi("{u}")#text(", and combining with Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text("(iii), we obtain the claim ")#link(<tao-4e1195df020de59e0d65>)[#text("(6)")]#text(".")

#text("We now prove the implication ")#link(<tao-ced2128f3bc92a5720f7>)[#text("(10)")]#text(". Thus we assume ")#link(<tao-aaee9dc21d0a986d8001>)[#text("(7)")]#text(" holds for ")#mi("{2 \\leq k \\leq n}")#text(", sufficiently small ")#mi("{u > 0}")#text(", and ")#mi("{t}")#text(" obeying ")#link(<tao-0b7f8f61f2c0f3904923>)[#text("(8)")]#text(", and also ")#link(<tao-4b7e94c5c3305a0d3645>)[#text("(9)")]#text(" for ")#mi("{2 \\leq t \\leq p/n}")#text(" and we wish to improve this to ")#metadata(none) <tao-adca8ff011e301acc8ef>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("a_t(u, ku) \\leq (1 - 2 (1+\\delta)Wu (n-k+1)")]]





#align(center)[#tao-fit-display[#mitex("+ (1-\\varepsilon) (1+\\delta) W u (k-1) k (n+1) (\\frac{1}{(k-1)k} - \\frac{1}{t} ) ) \\eta")]]

#text("for the same range of ")#mi("{k, t}")#text(" and for sufficiently small ")#mi("{u}")#text(", and also ")#metadata(none) <tao-5c50ac71ed5c68d8b480>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("a_t(u,u) \\leq (1 - (1+\\delta)Wu(n-1)) \\eta")]]



#text(" for ")#mi("{2 \\leq t \\leq p/n}")#text(".")

#text("By Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text("(i) it suffices to show this for the extreme values of ")#mi("{t}")#text(", thus we wish to show that ")#metadata(none) <tao-f24d62080b1faabdab3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("a_{kp/n}(u, ku) \\leq (1 - 2 (1+\\delta)Wu (n-k+1)")]]





#align(center)[#tao-fit-display[#mitex("+ (1-\\varepsilon) (1+\\delta) W u (k-1) k (n+1) (\\frac{1}{(k-1)k} - \\frac{n}{pk} ) ) \\eta")]]

#text("for ")#mi("{k=2,\\dots,n}")#text(", ")#metadata(none) <tao-b03b552166e3999c728b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("a_{(k-1)k}(u, ku) \\leq (1 - 2 (1+\\delta)Wu (n-k+1) ) \\eta")]]



#text(" for ")#mi("{k=2,\\dots,n}")#text(", and ")#metadata(none) <tao-c0a9e874307e35d49c76>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("a_2(u, u), a_{p/n}(u,u) \\leq (1 - (1+\\delta)Wu (n-1) ) \\eta.")]]



#text(" We begin with ")#link(<tao-f24d62080b1faabdab3a>)[#text("(13)")]#text(". The ")#mi("{k=n}")#text(" case of this estimate is ")#metadata(none) <tao-a1d9890884c1b4b960c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("a_p(u,nu) \\leq (1 - 2 (1+\\delta) Wu")]]





#align(center)[#tao-fit-display[#mitex("+ (1-\\varepsilon) (1+\\delta) W (n-1) n (n+1) (\\frac{1}{(n-1)n} - \\frac{1}{p}) ) \\eta.")]]

#text("But since ")#mi("{p < n(n+1)}")#text(", we see that ")#mi("{(1-\\varepsilon) (n-1) n (n+1) (\\frac{1}{(n-1)n} - \\frac{1}{p}) > 2}")#text(" if ")#mi("{\\varepsilon}")#text(" is small enough, so the right-hand side of ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(16)")]#text(" is greater than ")#mi("{\\eta}")#text(" and the claim follows from Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text("(iv) (with a little bit of room to spare). Now we look at the ")#mi("{k=2,\\dots,n-1}")#text(" cases of ")#link(<tao-f24d62080b1faabdab3a>)[#text("(13)")]#text(". By Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text("(vi), we have")

#align(center)[#tao-fit-display[#mitex("a_{kp/n}(u, ku) \\leq a_{kp/n}(u,(k+1)u).")]]

#text("For ")#mi("{p}")#text(" close to ")#mi("{n(n+1)}")#text(", ")#mi("{kp/n}")#text(" lies between ")#mi("{\\max(2,k(k+1))}")#text(" and ")#mi("{\\frac{(k+1)p}{n}}")#text(", so from ")#link(<tao-aaee9dc21d0a986d8001>)[#text("(7)")]#text(" one has")

#tao-aligned(keep: true)[


#tao-math("a_{kp/n}(u,(k+1)u)  & \\leq (1 - 2 Wu (n-k)", block: true)



#tao-math(" & + (1-\\varepsilon) W u k (k+1) (n+1) (\\frac{1}{k(k+1)} - \\frac{n}{pk} ) ) \\eta.", block: true)
]

#text("Since ")#mi("{p < n(n+1)}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("-2(n-k) + (1-\\varepsilon) k(k+1) (n+1) (\\frac{1}{k(k+1)} - \\frac{n}{pk})")]]

#align(center)[#tao-fit-display[#mitex("< -2(n-k+1) + (1-\\varepsilon) (k-1) k (n+1) (\\frac{1}{(k-1)k} - \\frac{n}{pk} )")]]

#text("for ")#mi("{\\varepsilon}")#text(" small enough depending on ")#mi("{p}")#text(", and ")#link(<tao-f24d62080b1faabdab3a>)[#text("(13)")]#text(" follows (if ")#mi("{\\delta}")#text(" is small enough depending on ")#mi("{\\varepsilon,p}")#text(" but not on ")#mi("{W}")#text(").")

#text("The same argument applied with ")#mi("{k=1}")#text(" gives")

#tao-aligned(keep: true)[


#tao-math("a_{p/n}(u,u)  & \\leq (1 - 2Wu(n-1)", block: true)



#tao-math(" & + (1-\\varepsilon) 2W u (n+1) (\\frac{1}{2} - \\frac{n}{2p} ) ) \\eta.", block: true)
]

#text("Since ")#mi("{p < n(n+1)}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("a_{p/n}(u,u) \\leq (1 - (1+\\delta) Wu(n-1) ) \\eta")]]

#text("if ")#mi("{\\varepsilon,\\delta}")#text(" are sufficiently small depending on ")#mi("{p}")#text(" (but not on ")#mi("{W}")#text("). This, together with Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text("(i), gives ")#link(<tao-c0a9e874307e35d49c76>)[#text("(15)")]#text(".")

#text("Finally, we establish ")#link(<tao-b03b552166e3999c728b>)[#text("(14)")]#text(". From Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text("(v) (with ")#mi("{k}")#text(" replaced by ")#mi("{k-1}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("a_{(k-1)k}(u, ku) \\leq a_{(k-1)k}( \\frac{k}{k-1} u, ku ).")]]

#text("In the ")#mi("{k=2}")#text(" case, this gives")

#align(center)[#tao-fit-display[#mitex("a_{(k-1)k}(u,ku) \\leq a_2( 2u, 2u )")]]

#text("and the claim ")#link(<tao-b03b552166e3999c728b>)[#text("(14)")]#text(" follows from ")#link(<tao-c0a9e874307e35d49c76>)[#text("(15)")]#text(" in this case. Now suppose ")#mi("{2 < k \\leq n}")#text(". Since ")#mi("{p}")#text(" is close to ")#mi("{n(n+1)}")#text(", ")#mi("{(k-1)k}")#text(" lies between ")#mi("{(k-2)(k-1)}")#text(" and ")#mi("{\\frac{(k-1)p}{n}}")#text(", and so we may apply ")#link(<tao-aaee9dc21d0a986d8001>)[#text("(7)")]#text(" to conclude that")

#tao-aligned(keep: true)[


#tao-math("a_{(k-1)k}( \\frac{k}{k-1} u, ku )  & \\leq (1 - 2 W \\frac{k}{k-1} u (n-k+2)", block: true)



#tao-math(" & + (1-\\varepsilon) W \\frac{k}{k-1} u(k-1) (k-2) (n+1) (\\frac{1}{(k-2)(k-1)} - \\frac{1}{(k-1)k} ) ) \\eta", block: true)
]

#text("and hence (after simplifying)")

#align(center)[#tao-fit-display[#mitex("a_{(k-1)k}(u, ku) \\leq (1 - 2W u (n-k+1) (1 + \\frac{\\varepsilon (n+1)}{(n-k+1)(k-1)} )) \\eta,")]]

#text("which gives ")#link(<tao-b03b552166e3999c728b>)[#text("(14)")]#text(" for ")#mi("{\\delta}")#text(" small enough (depending on ")#mi("{\\varepsilon,k,n}")#text(", but not on ")#mi("{W}")#text(").")

#heading(level: 1)[#strong[#text(" — 2. Rescaled decoupling — ")]]

#text("The claims (i), (ii), (iii) of Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text(" are routine applications of the Hölder and Minkowski inequalities (and also the Bernstein inequality, in the case of (iii)); we will focus on the more interesting claims (iv), (v), (vi).")

#text("Here we establish (iv). The main geometric point exploited here is that any segment of the curve ")#mi("{\\gamma([0,1])}")#text(" is affinely equivalent to ")#mi("{\\gamma([0,1])}")#text(" itself, with the key factor of ")#mi("{1-q}")#text(" in the bound ")#mi("{a_t(q,s) \\leq (1-q) \\eta}")#text(" coming from this affine rescaling.")

#text("Using the definition ")#link(<tao-f5e19ad9fb2c307d5790>)[#text("(5)")]#text(" of ")#mi("{a_t(q,s)}")#text(", we see that we need to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left|\\text{Avg}_{p,N^n} f_{I}\\right|^2)^{1/2}\\right\\|_{L^p(w_B)}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{(1-q)\\eta+o(1)} \\text{geom} (\\sum_{i \\in {\\mathcal I}_j} \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2}", block: true)]]

#text("for balls ")#mi("{B}")#text(" of radius ")#mi("{N^n}")#text(". By Hölder’s inequality, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left|\\text{Avg}_{p,N^n} f_{I}\\right|^2)^{1/2}\\right\\|_{L^p(w_B)} \\ll N^{(1-q)\\eta+o(1)} (\\sum_{i \\in {\\mathcal I}_j} \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2}", block: true)]]

#text("for each ")#mi("{j}")#text(". By Minkowski’s inequality (and the fact that ")#mi("{p>2}")#text("), the left-hand side is at most")

#align(center)[#tao-fit-display[#tao-math("( \\sum_{I \\in {\\mathcal I}_{j,q}} \\left\\| \\text{Avg}_{p,N^n} f_{I}\\right\\|_{L^p(w_B)}^2)^{1/2}", block: true)]]

#text("so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{Avg}_{p,N^n} f_{I} \\right\\|_{L^p(w_B)} \\ll N^{(1-q)\\eta+o(1)} (\\sum_{i: I_i \\subset I} \\left\\|f_i\\right\\|_{L^p(w_B)})^{1/2}", block: true)]]

#text("for each ")#mi("{I \\in {\\mathcal I}_{j,q}}")#text(". From Fubini’s theorem one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{Avg}_{p,N^n} f_{I} \\right\\|_{L^p(w_B)} \\ll_{n,p} \\left\\| f_{I} \\right\\|_{L^p(w_B)}", block: true)]]

#text("so we reduce to showing that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_{I} \\right\\|_{L^p(w_B)} \\ll N^{(1-q)\\eta+o(1)} (\\sum_{i: I_i \\subset I} \\left\\|f_i\\right\\|_{L^p(w_B)}^2)^{1/2}.", block: true)]]

#text("But this follows by applying an affine rescaling to map ")#mi("{\\gamma(I)}")#text(" to ")#mi("{\\gamma([0,1])}")#text(", and then using the hypothesis ")#mi("{P(p,\\eta)}")#text(" with ")#mi("{N}")#text(" replaced by ")#mi("{N^{1-q}}")#text(". (The ball ")#mi("{B}")#text(" gets distorted into an ellipsoid, but one can check that this ellipsoid can be covered efficiently by finitely overlapping balls of radius ")#mi("{N^{1-q}}")#text(", and so one can close the argument using the triangle inequality.)")

#heading(level: 1)[#strong[#text(" — 3. Lower dimensional decoupling — ")]]

#text("Now we establish (v). Here, the geometric point is the one implicitly used in Proposition ")#link(<tao-2cfb1daa7c84a5a8fbd3>)[#text("3")]#text(", namely that the ")#mi("{n}")#text("-dimensional curve ")#mi("{\\gamma([0,1])}")#text(" projects down to the ")#mi("{k}")#text("-dimensional curve ")#mi("{\\gamma_k([0,1])}")#text(" for any ")#mi("{1 \\leq k < n}")#text(".")

#text("Let ")#mi("{k,q,s}")#text(" be as in Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text("(v). From ")#link(<tao-f5e19ad9fb2c307d5790>)[#text("(5)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left|\\text{Avg}_{k(k+1),N^s} f_{I}\\right|^2)^{1/2}\\right\\|_{L^p(w_B)}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{o(1)} \\left\\| \\text{geom} (\\sum_{J \\in {\\mathcal I}_{j,s/k}} \\left|\\text{Avg}_{k(k+1),N^s} f_{J}\\right|^2)^{1/2}\\right\\|_{L^p(w_B)}", block: true)]]

#text("for balls ")#mi("{B}")#text(" of radius ")#mi("{N^n}")#text(". It will suffice to show the pointwise estimate")

#align(center)[#tao-fit-display[#tao-math("\\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left|\\text{Avg}_{k(k+1),N^s} f_{I}(x_0)\\right|^2)^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{o(1)} \\text{geom} (\\sum_{J \\in {\\mathcal I}_{j,s/k}} \\left|\\text{Avg}_{k(k+1),N^s} f_{J}(x_0)\\right|^2)^{1/2}", block: true)]]

#text("for any ")#mi("{x_0 \\in {\\bf R}^n}")#text(", or equivalently that")

#align(center)[#tao-fit-display[#tao-math("\\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left\\| f_I \\right\\|_{L^{k(k+1)}(w_{B^{\\prime}})}^2)^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{o(1)} \\text{geom} (\\sum_{J \\in {\\mathcal I}_{j,s/k}} \\left\\| f_J \\right\\|_{L^{k(k+1)}(w_{B^{\\prime}})}^2)^{1/2}", block: true)]]

#text("where ")#mi("{B^{\\prime} := B(x_0,N^s)}")#text(". Clearly this will follow if we have")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{I \\in {\\mathcal I}_{j,q}} \\left\\| f_I \\right\\|_{L^{k(k+1)}(w_{B^{\\prime}})}^2)^{1/2} \\ll N^{o(1)} (\\sum_{J \\in {\\mathcal I}_{j,s/k}} \\left\\| f_J \\right\\|_{L^{k(k+1)}(w_{B^{\\prime}})}^2)^{1/2}", block: true)]]

#text("for each ")#mi("{j}")#text(". Covering the intervals in ")#mi("{{\\mathcal I}_{j,s/k}}")#text(" by those in ")#mi("{{\\mathcal I}_{j,q}}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_I \\right\\|_{L^{k(k+1)}(w_{B^{\\prime}})} \\ll N^{o(1)} (\\sum_{J: J \\subset I} \\left\\| f_J \\right\\|_{L^{k(k+1)}(w_{B^{\\prime}})}^2)^{1/2}", block: true)]]

#text("for each ")#mi("{I \\in {\\mathcal I}_{j,q}}")#text(". But this follows from Proposition ")#link(<tao-2cfb1daa7c84a5a8fbd3>)[#text("3")]#text(".")

#heading(level: 1)[#strong[#text(" — 4. Multidimensional Kakeya — ")]]

#text("Finally, we establish (vi), which is the most substantial component of Proposition ")#link(<tao-525d7e6d7c831446d1d9>)[#text("7")]#text(", and the only component which truly takes advantage of the reduction to the multilinear setting. Let ")#mi("{1 \\leq k \\leq n-1}")#text(" and ")#mi("{q}")#text(" be such that ")#mi("{(k+1)q \\leq n}")#text(". From ")#link(<tao-f5e19ad9fb2c307d5790>)[#text("(5)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left|\\text{Avg}_{kp/n, N^{kq}} f_{I}\\right|^2)^{1/2}\\right\\|_{L^p(w_B)}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{o(1)} \\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left|\\text{Avg}_{kp/n, N^{(k+1)q}} f_{I}\\right|^2)^{1/2}\\right\\|_{L^p(w_B)}", block: true)]]

#text("for balls ")#mi("{B}")#text(" of radius ")#mi("{N^n}")#text(". By averaging, it suffices to establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left|\\text{Avg}_{kp/n, N^{kq}} f_{I}\\right|^2)^{1/2}\\right\\|_{L^p(w_{B^{\\prime}})}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{o(1)} \\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} \\left|\\text{Avg}_{kp/n, N^{(k+1)q}} f_{I}\\right|^2)^{1/2}\\right\\|_{L^p(w_{B^{\\prime}})}", block: true)]]

#text("for balls ")#mi("{B^{\\prime}}")#text(" of radius ")#mi("{N^{(k+1)q}}")#text(". If we write ")#mi("{F_I := (\\text{Avg}_{kp/n, N^{kq}} f_{I})^{kp/n}}")#text(", the right-hand side simplifies to")

#align(center)[#tao-fit-display[#tao-math("N^{o(1)} \\left|B^{\\prime}\\right|^{1/p} \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} (\\frac{1}{\\left|B^{\\prime}\\right|} \\int F_I w_{B^{\\prime}})^{2n/kp})^{1/2}", block: true)]]

#text("so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|B^{\\prime}\\right|^{-1/p} \\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} F_I^{2n/kp})^{1/2}\\right\\|_{L^p(w_{B^{\\prime}})}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{o(1)} \\text{geom} (\\sum_{I \\in {\\mathcal I}_{j,q}} (\\frac{1}{\\left|B^{\\prime}\\right|} \\int F_I w_{B^{\\prime}})^{2n/kp})^{1/2}.", block: true)]]

#text("At this point it is convenient to perform a dyadic pigeonholing (giving up a factor of ")#mi("{N^{o(1)}}")#text(") to normalise, for each ")#mi("{j}")#text(", all of the quantities ")#tao-math("{\\frac{1}{\\left|B^{\\prime}\\right|} \\int F_I w_{B^{\\prime}}}", block: false)#text(" to be of comparable size, after reducing the sets ")#mi("{{\\mathcal I}_{j,q}}")#text(" so some appropriate subset ")#mi("{{\\mathcal I}^{\\prime}_{j,q}}")#text(". (The contribution of those ")#mi("{I}")#text(" for which this quantity is less than, say, ")#mi("{N^{-100n^2}}")#text(" of the maximal value, can be safely discarded by trivial estimates.) By homogeneity we may then normalise")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|B^{\\prime}\\right|} \\int F_I w_{B^{\\prime}} \\sim 1", block: true)]]

#text("for all surviving ")#mi("{I}")#text(", so the estimate now becomes")

#align(center)[#tao-fit-display[#tao-math("\\left|B^{\\prime}\\right|^{-1/p} \\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}^{\\prime}_{j,q}} F_I^{2n/kp})^{1/2}\\right\\|_{L^p(w_{B^{\\prime}})} \\ll N^{o(1)} \\text{geom} (\\# {\\mathcal I}^{\\prime}_{j,q})^{1/2}.", block: true)]]

#text("Since ")#mi("{p}")#text(" is close to ")#mi("{n(n+1)}")#text(", ")#mi("{2n/kp}")#text(" is less than ")#mi("{1}")#text(", so we can estimate")

#align(center)[#tao-fit-display[#mitex("(\\sum_{I \\in {\\mathcal I}^{\\prime}_{j,q}} F_I^{2n/kp})^{1/2} \\leq (\\# {\\mathcal I}^{\\prime}_{j,q})^{1/2 - n/kp} (\\sum_{I \\in {\\mathcal I}^{\\prime}_{j,q}} F_I)^{n/kp}")]]

#text("and so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|B^{\\prime}\\right|^{-1/p} \\left\\| \\text{geom} (\\sum_{I \\in {\\mathcal I}^{\\prime}_{j,q}} F_I)^{n/kp}\\right\\|_{L^p(w_{B^{\\prime}})} \\ll N^{o(1)} \\text{geom} (\\# {\\mathcal I}^{\\prime}_{j,q})^{n/kp},", block: true)]]

#text("or, on raising to the power ")#mi("{pk/n}")#text(",")

#align(center)[#tao-fit-display[#tao-math("\\left|B^{\\prime}\\right|^{-k/n} \\left\\| \\text{geom} \\sum_{I \\in {\\mathcal I}^{\\prime}_{j,q}} F_I\\right\\|_{L^{n/k}(w_{B^{\\prime}})} \\ll N^{o(1)} \\text{geom} (\\# {\\mathcal I}^{\\prime}_{j,q}).", block: true)]]

#text("Localising to balls ")#mi("{B^{\\prime}}")#text(" of radius ")#mi("{N^{(k+1)q}}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|B^{\\prime}\\right|^{-k/n} \\left\\| \\text{geom} \\sum_{I \\in {\\mathcal I}^{\\prime}_{j,q}} F_I\\right\\|_{L^{n/k}(B^{\\prime})} \\ll N^{o(1)} \\text{geom} \\sum_{I \\in {\\mathcal I}^{\\prime}_{j,q}} \\left|B^{\\prime}\\right|^{-1} \\left\\| F_I \\right\\|_{L^1(B^{\\prime})}.", block: true)]]

#text("The arc ")#mi("{\\gamma(I)}")#text(" is contained in a box of dimensions roughly ")#mi("{N^{-q} \\times N^{-2q} \\times \\dots \\times N^{-nq}}")#text(", so by the uncertainty principle ")#mi("{f_I}")#text(" is essentially constant along boxes of dimensions ")#mi("{N^q \\times N^{2q} \\times \\dots \\times N^{nq}}")#text(" (this can be made precise by standard methods, see e.g. the discussion in the proof of Theorem 5.6 of ")#link("http://arxiv.org/abs/1512.01565")[#text("Bourgain-Demeter-Guth")]#text(", or my general discussion on the uncertainty principle in ")#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("this previous blog post")]#text("). This implies that ")#mi("{F_I}")#text(", when restricted to ")#mi("{B^{\\prime}}")#text(", is essentially constant on “plates”, defined as the intersection of ")#mi("{B^{\\prime}}")#text(" with slabs that have ")#mi("{k}")#text(" dimensions of length ")#mi("{N^{kq}}")#text(" and the remaining ")#mi("{n-k}")#text(" dimensions infinite (and thus restricted to be of length about ")#mi("{N^{(k+1)q}}")#text(" after restriction to ")#mi("{B^{\\prime}}")#text("). Furthermore, as ")#mi("{j}")#text(" varies (and ")#mi("{I}")#text(" is constrained to be in ")#mi("{{\\mathcal I}^{\\prime}_{j,q}}")#text(", the orientation of these slabs varies in a suitably “transverse” fashion (the precise definition of this is a little technical, but can be verified for ")#mi("{M=n!}")#text("; see the BDG paper for details). After rescaling, the claim then follows from the following proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8 (Multilinear Kakeya)")]#text(" For ")#mi("{j=1,\\dots,M}")#text(", let ")#mi("{{\\mathcal P}_j}")#text(" be a collection of “plates” that have ")#mi("{k}")#text(" dimensions of length ")#mi("{1}")#text(", and ")#mi("{n-k}")#text(" dimensions that are infinite, and for each ")#mi("{P \\in {\\mathcal P}_j}")#text(" let ")#mi("{c_P}")#text(" be a non-negative number. Assume that the families of plates ")#mi("{{\\mathcal P}_j}")#text(" obey a suitable transversality condition. Then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{geom} \\sum_{P \\in {\\mathcal P}_j} c_P 1_P \\right\\|_{L^{n/k}(B)} \\ll N^{o(1)} \\text{geom} \\sum_{P \\in {\\mathcal P}_j} c_P", block: true)]]

#text("for any ball ")#mi("{B}")#text(" of radius ")#mi("{N}")#text(".")
]

#text("The exponent ")#mi("{n/k}")#text(" here is natural, as can be seen by considering the example where each ")#mi("{{\\mathcal P}_j}")#text(" consists of about ")#mi("{N^k}")#text(" parallel disjoint plates passing through ")#mi("{B}")#text(", with ")#mi("{c_P=1}")#text(" for all such plates.")

#text("For ")#mi("{k = n-1}")#text(" (where the plates now become tubes), this result was first obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("by Bennett, Carbery, and myself")]#text(" using heat kernel methods, with a rather different proof (also capturing the endpoint case) later given using algebraic topological methods ")#link("http://arxiv.org/abs/0811.2251")[#text("by Guth")]#text(" (as discussed in ")#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("this previous post")]#text(". More recently, a very short and elementary proof of this theorem was given ")#link("http://arxiv.org/abs/1409.4683")[#text("by Guth")]#text(", which was initially given for ")#mi("{k=n-1}")#text(" but extends to general ")#mi("{k}")#text(". The scheme of the proof can be described as follows.")

#list(
[#text("When all the plates ")#mi("{P}")#text(" in a each family ")#mi("{{\\mathcal P}_j}")#text(" are parallel, the claim follows from the Loomis-Whitney inequality (when ")#mi("{k=n-1}")#text(") or a more general ")#link("http://arxiv.org/abs/math/0505065")[#text("Brascamp-Lieb inequality of Bennett, Carbery, Christ, and myself")]#text(" (for general ")#mi("{k}")#text("). These inequalities can be proven by a repeated applications of the Hölder inequality and Fubini’s theorem.")],
[#text("Perturbing this, we can obtain the proposition with a loss of ")#mi("{N^\\varepsilon}")#text(" for any ")#mi("{N>0}")#text(" and ")#mi("{\\varepsilon>0}")#text(", provided that the plates in each ")#mi("{{\\mathcal P}_j}")#text(" are within ")#mi("{\\delta}")#text(" of being parallel, and ")#mi("{\\delta}")#text(" is sufficiently small depending on ")#mi("{N}")#text(" and ")#mi("{\\varepsilon}")#text(". (For the case of general ")#mi("{k}")#text(", this requires some uniformity in the result of Bennett, Carbery, Christ, and myself, which can be obtained by hand in the specific case of interest here, but was recently established in general ")#link("http://arxiv.org/abs/1508.07502")[#text("by Bennett, Bez, Flock, and Lee")]#text(".")],
[#text("A standard “induction on scales” argument shows that if the proposition is true at scale ")#mi("{N}")#text(" with some loss ")#mi("{K(N)}")#text(", then it is also true at scale ")#mi("{N^2}")#text(" with loss ")#mi("{O( K(N)^2 )}")#text(". Iterating this, we see that we can obtain the proposition with a loss of ")#mi("{O_\\varepsilon(N^\\varepsilon)}")#text(" uniformly for ")#emph[#text("all")]#text(" ")#mi("{N>0}")#text(", provided that the plates are within ")#mi("{\\delta}")#text(" of being parallel and ")#mi("{\\delta}")#text(" is sufficiently small depending now only on ")#mi("{\\varepsilon}")#text(" (and not on ")#mi("{N}")#text(").")],
[#text("A finite partition of unity then suffices to remove the restriction of the plates being within ")#mi("{\\delta}")#text(" of each other, and then sending ")#mi("{\\varepsilon}")#text(" to zero we obtain the claim.")]
)

#text("The proof of the decoupling theorem (and thus the Vinogradov main conjecture) are now complete.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" The above arguments extend to give decoupling for the curve ")#mi("{\\gamma([0,1])}")#text(" in ")#mi("{L^p}")#text(" for every ")#mi("{n^2 \\leq p \\leq n(n+1)}")#text(". As it turns out (Bourgain, private communication), a variant of the argument also handles the range ")#mi("{n(n-1) \\leq p \\leq n^2}")#text(", and the range ")#mi("{2 \\leq p \\leq n(n-1)}")#text(" can be covered from an induction on dimension (using the argument used to establish Proposition ")#link(<tao-2cfb1daa7c84a5a8fbd3>)[#text("3")]#text(").")
]

#heading(level: 1)[#text("Comments (59)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463396")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2015")])]

#text("Dear Terry,")

#text("Following the strengthening of the triangle inequality you consider at the beginning of this post and which involves the square root of the cardinality of a set, can the optimal error term in the prime number theorem, which is a classical reformulation of RH, be interpreted as some kind of orthogonality of basis vectors coming from prime numbers in some Hilbert space? If so, is there any link with Selberg’s orthogonality conjecture for the Selberg class where primitive elements thereof replace prime numbers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2015")])]

#text("In theorem 1, which properties are needed for the measure ")#mi("\\mu_i")#text(" (e.g. positiveness, absolute continuity wrt the arc length measure, etc.) ?")

#emph[#text("[The measure needs to be finite Borel, this has now been added. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463403")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2015")])]

#text("The way w_B is defined it looks more like a smoothed out dirac measure of x_0 rather than a smoothed out indicator function of B. Can someone explain?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463405")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2015")])]

#text("The function is normalised to have a sup norm comparable to 1 (like that of an indicator function) rather than to have total mass comparable to 1 (like that of a delta function).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2015")])]

#text("In addition of being measurable and having sup norm comparable to 1, are there more properties needed for ")#mi("w_B")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463429")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("As I said in the post, one should think of ")#mi("w_B")#text(" as being a smoothed out version of ")#mi("1_B")#text(", which is localised to ")#mi("B")#text(" and has the local constancy property ")#mi("w_B(x) \\sim w_B(y)")#text(" when ")#tao-math("\\left|x-y\\right| \\leq r", block: false)#text(" (")#mi("r")#text(" being the radius of ")#mi("B")#text(").")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("The word immediately before (1) is “inequailty”, and between (9) and (10) there is “\\eqreF{impl}” which I think should be rendered as a link to (9).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The two-dimensional case of the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463463")[#strong[#text("The two-dimensional case of the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("[…] this blog post, I would like to specialise the arguments of Bourgain, Demeter, and Guth from the previous post to the two-dimensional case of the Vinogradov main conjecture, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21142316488f0c7afddbb243e6a509ef1d1642628a9f5ef6996b764dee5af841-4eed840c674617f4da6095ab1017156c47a2143cc2d663552e30ae8b9c3aa22c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463800")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("A very small correction: when you state the existing bounds due to Wooley you use k instead of n in a couple of equations.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463820")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("The ")#mi("f_i")#text(" defined in Theorem 1 are defined as an integral over ")#mi("I_i")#text(" yet immediately afterwards, the ")#mi("\\mu_i")#text(" are measures on ")#mi("\\gamma(I_i)")#text(", so shouldn’t the integral definition of ")#mi("f_i")#text(" be over ")#mi("\\gamma(I_i)")#text(" instead?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463895")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("Why the exponent ")#mi("100 n")#text(" in the definition of ")#mi("w_B")#text(" is chosen so large? What seems to be its minimal possible value?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463901")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("As the text explains, $w_B$ is meant to be a smoothed replacement of $1_B$, so if you want to be completely rigorous, the exponent in the definition should be a variable, and in the end you should take a limit where that variable goes to infinity. So I don’t think that a question about the “minimal possible value” of the exponent makes any sense, actually.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("It is not clear why ")#mi("100 n")#text(" was chosen? (if e.g. ")#mi("10 n")#text(" is sufficient ) and which constraints for this exponent are really needed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463908")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("Basically one wants ")#mi("w_B")#text(", as well as any of the fractional powers of ")#mi("w_B")#text(" which may arise in various invocations of Holder’s inequality, to be absolutely integrable. One can certainly dig through the proof to see exactly which fractional powers of ")#mi("w_B")#text(" show up and thence work out the minimal exponent here, but this value is not terribly important to the rest of the argument and so it is generally preferable to just set this exponent to a conservatively large value of no particular significance, such as ")#mi("100n")#text(". (In general, whenever nice round numbers such as ")#mi("10")#text(", ")#mi("100")#text(", or ")#mi("1000")#text(" appear in an analysis argument, they are probably used as a convenient choice of a large constant whose exact value is of little importance to the rest of the argument, so long as it is large enough.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2015")])]

#text("Are you sure that the application of Holder in the first sentence of the proof of Corollary 2 is correct? It seems that if I use the trivial bound on the exponential sum and the case of ")#mi("s = n(n + 1)/2")#text(", we have ")#tao-math("\\left\\|\\sum\\right\\|_{2s} \\leq N\\left\\|\\sum\\right\\|_{n(n+ 1)} \\leq N^{\\frac{3}{2} + \\frac{2}{n(n + 1)}}", block: false)#text(" and so the ")#mi("L^{2s}")#text(" norm is ")#mi("N^{3s + \\frac{4s}{n(n + 1)}}")#text(" which is worse than either term in the statement of Corollary 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464104")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2015")])]

#text("Holder’s inequality gives ")#tao-math("\\left\\| \\sum \\right\\|_{2s}^{2s} \\leq N^{2s - n(n+1)} \\left\\| \\sum \\right\\|_{n(n+1)}^{n(n+1)}", block: false)#text(", rather than the first inequality asserted in your comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15e52111258bc45f32e2631196fcbf888ea70303b84c8e82c1f7b20e415d8b69-34efb35fb5abb67e9c429e49ab5ddff5960f0f67131e81663425ff727f2a51da.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of benjdewantara")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464065")[#strong[#text("benjdewantara")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2015")])]

#text("Reblogged this on ")#link("https://benjdewantara.wordpress.com/2015/12/20/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/")[#text("benjdewantara")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2015")])]

#text("Dear Tao, reading the prepring in Arxiv, in Lemma 7.2, instead of ")#mi("V_{p,k-1}(R^{-\\frac{1}{k-1}})")#text(" I get ")#mi("V_{p,k-1}(\\sigma^{-1}R^{-\\frac{1}{k-1}})")#text(", that seems better. The ")#mi("\\sigma")#text(" factor appears when I rescale like in Lemma 6.3. Am I misunderstanding something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464172")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2015")])]

#text("I should say, I am rescaling the lower dimensional curve, not the original one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2015")])]

#text("I think the ")#mi("\\sigma")#text(" factor is simply discarded by Bourgain-Guth-Demeter as it is not needed for their argument (in lower dimensions it ends up that the scale parameter just gets raised to the power ")#mi("\\varepsilon")#text(", so it really doesn’t matter too much exactly what it is.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2015")])]

#text("Can you say a bit more about the derivation of (2) from (3) in the proof of Proposition 6? What are you taking the ")#mi("\\mathcal{I}_{j}")#text(" to be when you try to prove (2)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464365")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2015")])]

#text("See the second paragraph after (4). If ")#mi("N")#text(" is a multiple of ")#mi("K")#text(", one can take ")#mi("{\\mathcal I}_j")#text(" to be the intervals ")#mi("I_{(j-1)N/K+1}, \\dots, I_{jN/K}")#text("; when ")#mi("N")#text(" is not a multiple of ")#mi("K")#text(", one can round the endpoints of this string of consecutive intervals to the nearest integer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464376")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2015")])]

#text("There seems to be a typo in the first sentence of the proof of Proposition 6, (2) and (3) should be swapped then. However, I do not see how Holder’s inequality can show (3) from (2) since it seems that (3) is true for any collection of subintervals.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2015")])]

#text("By Holder’s inequality, the left hand side of (3) is ")#tao-math("\\leq \\mathrm{geom}\\left\\|\\sum_{i \\in \\mathcal{I}_j}f_i\\right\\|_{L^{p}(w_B)}", block: false)#text(", and so to prove (3), one needs (2) with the ")#mi("\\sum_{i = 1}^{N}")#text(" replaced by ")#mi("\\sum_{i \\in \\mathcal{I}_j}")#text(". Is this still true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464410")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2015")])]

#text("Yes. If the intervals in ")#mi("{\\mathcal I}_j")#text(" are of the form ")#mi("[(a-1)/N, a/N]")#text(" for a natural number value of ")#mi("a")#text(", then ")#mi("{\\mathcal I}_j")#text(" is a subset of the ")#mi("N")#text(" intervals considered in Theorem 1, and one can simply add some “dummy” ")#mi("f_i")#text(" (that are equal to zero when the interval ")#mi("[(i-1)/N,i/N]")#text(" is not of the form considered in Theorem 1) to conclude.")

#text("If the intervals ")#mi("{\\mathcal I}_j")#text(" are not all of the above form (or equivalently, if some of the ")#mi("a")#text(" are non-integer reals), one can use the intervals in Theorem 1 to cut each of the ")#mi("{\\mathcal I}_j")#text(" into at most two subintervals, and each ")#mi("f_i")#text(" then gets split into at most two pieces, each of which has an ")#mi("L^p")#text(" norm controlled by the ")#mi("L^p")#text(" norm of the original function ")#mi("f_i")#text(" by the ")#mi("L^p")#text(" boundedness of the Hilbert transform. Each interval in Theorem 1 is now associated to at most two of these pieces, and so ")#mi("\\sum_{i \\in {\\mathcal I}_j} f_i")#text(" can be broken up into at most two sums, each of which can be controlled adequately by (2) and the boundedness of the Hilbert transform.")

#text("(Another approach, avoiding the use of the boundedness of the Hilbert transform, uses the “1/3 translation trick”, which I believe is originally due to Michael Christ: every interval of side length ")#mi("1/N")#text(" can be covered by an interval of the form ")#mi("[3j/N, 3(j+1)/N]")#text(" or by ")#mi("[3j/N + 1/N, 3(j+1)/N + 1/N]")#text(" for some integer ")#mi("j")#text(". Using this trick and the triangle inequality, one can often reduce questions about intervals of a given length to intervals with (three times) the given length, and whose endpoints are integer multiples of that length (after exploiting some translation invariance to get rid of the shift).")

#text("In any event, this direction of the implication in Proposition 6 is not actually used in the proof of the decoupling conjecture, and is only present to give some context to the relative strength of the linear and multilinear formulations of the decoupling theorem.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464447")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2015")])]

#text("Which properties of the integrand in corollary 2 are needed (and used) by the decoupling method, and is there a more general family of similar multidimentional integrals which (potentially) can be estimated by this new method ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464458")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2015")])]

#text("The decoupling argument would apply to any curve ")#mi("\\gamma")#text(" that was maximally curved in the sense that at any point of the curve, the first ")#mi("n")#text(" derivatives of the curve parameterisation ")#mi("\\gamma")#text(" were linearly independent. (For curves in three dimensions, this amounts to the curvature and torsion being both non-zero throughout the curve.) To get estimates of the form in Corollary 2, though, one needs some integrality properties of the frequency points being sampled, since one has to exploit some periodicity in the proof of the corollary. Jean Bourgain has informed me (private communication) that the method used to reprove Corollary 2 can be modified for instance to prove a ")#link("https://en.wikipedia.org/wiki/Hua%27s_lemma")[#text("classical inequality of Hua")]#text(".")

#text("Also, you are indeed correct that Corollary 2 extends to the case where ")#mi("s")#text(" is non-integer.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464451")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2015")])]

#text("In the formulation of corollary 2, is it really necessary of ")#mi("s")#text(" to be an integer?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464481")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2015")])]

#text("Very first word of the post: “\\iGiven” –> “Given”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-465064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2016")])]

#text("Is it possible to combine the B-D-G decoupling technique with the (apparently very different but still closely related) efficient congruencing technique of Wooley?")

#emph[#text("[I believe people are looking at this right now, but I do not know of any publicly available work connecting the two thus far. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-465408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2016")])]

#text("Dear Terry,")#linebreak()#text(" Is the Theorem 5.5 of the Bourdain-Demeter-Guth paper directly follows from Prop. 5.2 , Lemma 5.3 and Prop. 5.4 in the same section ? It seems to me that conditions of 5.5 just ensure that the previous three propositions apply. But I do not understand that why we have an extra factor R^{\\epsilon} in (7) since we are only dealing with parallel plates in each family. In the")#linebreak()#text(" one-sentence “proof”, the authors said that this is proved in Guth [14]. Do they mean that we also need to apply Guth’s arguments with 5.2 , 5.3 and 5.4 to get Theorem 5.5?")

#text("Maybe I am totally wrong here. Can you he me to clarify this a little bit? Many thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-465612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2016")])]

#text("Yes, one needs to apply the arguments from [14] with Prop 5.2, Lemma 5.3, and Prop 5.4 inserted in those arguments in the appropriate places. Guth’s argument, based on an induction on scales, loses the ")#mi("R^\\varepsilon")#text(" factor. I would recommend reading through the argument in [14] (which treats the k=n-1 case) first, as it should become clearer after doing so how the argument is to be modified.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f074afbdaafdd30363c361caea1239569c0f1b9fe040338446bd56a8a96307c-4397bb1b047cca21cc3ed06af3d10a98f84cd2a97cdab1be9277045995e5be7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Church")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-465728")[#strong[#text("Tom Church")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2016")])]

#text("You credit Bourgain and Demeter for Theorem 1, but shouldn’t it be Bourgain-Demeter-Guth? Currently Guth’s name doesn’t appear anywhere until much farther down the post. (Perhaps just a typo, since you link to the BDG paper.)")

#emph[#text("[Corrected, thanks. Bourgain and Demeter have an earlier series of papers on decoupling that precede the BDG paper. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-465744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2016")])]

#text("In corollary 2, is it possible to give an effective estimate for the ")#mi("N^{\\epsilon}")#text(" loss in terms of ")#mi("N, s, n")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-465752")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2016")])]

#text("In principle, the arguments are effective, but the dependence of the implied constants on ")#mi("\\varepsilon")#text(" are somewhat poor (in particular, it does not seem that these results immediately imply any substantial improvement on the Vinogradov-Korobov zero-free region).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-465776")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2016")])]

#text("What seems to be (in terms of fixed ")#mi("s, n")#text(" and large ")#mi("N")#text(") ")#mi("\\inf_{\\epsilon >0}")#text(" taken over the RHS in corollary 2 ?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-465870")[#strong[#text("Polymath10-post 4: Back to the drawing board? | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2016")]

#text("[…] Bourgain, Ciprian Demeter, Larry Guth of Vinogradov’s main conjecture. You can read about it here and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40a55b2bdf7460bef2741e323b48b3d4ab81343aa413e9a9c061c66ab71bc565-e8cb420ebb06a5321640635ca351fae9cb6f195833ca8e185653c0eff5cbef8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-466395")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2016")])]

#text("It seems that there is a small misprint in the chain of inequalities for the biorthogonal decoupling in L^4. The power 1/2 in the last three lines should not be there. Otherwise the inequalities don’t scale properly.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-472166")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2016")])]

#text("Could you elaborate on your comment immediately following Theorem 1 regarding orthogonality? I think I am missing something.")

#emph[#text("[Can you elaborate on your request for elaboration? -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-472167")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2016")])]

#text("Also, in Corollary 2, immediately following “We can rescale as” the exponent of ")#mi("3 {n \\choose 2}")#text(" should be ")#mi("n(n+1)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-472189")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2016")])]

#text("I am not sure how to show the ")#mi("f_j")#text(" are orthogonal (or almost orthogonal)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-472191")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2016")])]

#text("One has to compare the weight ")#mi("w_B")#text(" with a weight ")#mi("\\eta_B")#text(" that has a compactly supported Fourier transform (actually it is convenient to ensure that it is ")#mi("\\sqrt{\\eta_B}")#text(" that has compactly supported Fourier transform, so that the ")#mi("f_j \\sqrt{\\eta_B}")#text(" remain orthogonal in ")#mi("L^2({\\bf R}^n)")#text("). See for instance Proposition 6.1 of ")#link("http://arxiv.org/abs/1604.06032")[#text("http://arxiv.org/abs/1604.06032")]#text(" . (Note that the lower bound in that proposition is not quite correct as stated; I think the notes will be revised soon to address this small issue.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-479506")[#strong[#text("El triunfo del análisis. Conjetura de Vinogradov – Blog del Instituto de Matemáticas de la Universidad de Sevilla")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2017")]

#text("[…] Blog de Terry Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-480393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2017")])]

#text("Dear Prof. Tao,")

#text("in the most recent paper ")#link("https://arxiv.org/abs/1604.06032")[#text("https://arxiv.org/abs/1604.06032")]#text(" (let’s call it paper A) by Bourgain and Demeter on decoupling the authors write that this paper should serve as a “warm up” for unterstanding the proof of the Vinogradov conjecture by presenting a more streamlined proof of their ")#mi("l^2")#text(" decoupling theorem from ")#link("https://arxiv.org/pdf/1403.5335.pdf")[#text("https://arxiv.org/pdf/1403.5335.pdf")]#text(" (paper B). But to me it looks like the result in paper A is much weaker (and actually different) than the result in paper B.")

#text("In paper A the authors establish a decoupling theorem for functions of the form ")#mi("\\widehat{g d\\sigma}")#text(" where ")#mi("d\\sigma")#text(" is the lift of the Lebesgue measure from ")#mi("[0,1]^{n-1}")#text(" to the paraboloid in the exponent range ")#mi("2\\leq p \\leq \\frac{2(n+1)}{n-1}")#text(". Whereas in paper B the authors prove a decoupling theorem for any Schwartz function whose Fourier transform has support in a certain neighborhood of the paraboloid for exponents ")#mi("p\\geq \\frac{2(n+1)}{n-1}")#text(".")

#text("How can the result in paper A be seen as the same as or being comparable to the result in paper B?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-480495")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2017")])]

#text("The decoupling estimate in Paper B for ")#mi("p \\geq 2(n+1)/n-1")#text(" implies a decoupling estimate for ")#mi("2 \\leq p \\leq 2(n+1)/(n-1)")#text(" also (see equation (3) of that paper). If one can decouple Schwartz functions Fourier supported in a neighbourhood of the paraboloid, one can then decouple non-Schwartz functions Fourier supported exactly on the paraboloid by using approximations to the identity and a limiting argument. (One can also use uncertainty principle type arguments to go in the reverse direction, if the thickness of the neighbourhood is comparable to the scale at which the uncertainty principle applies.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-480505")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2017")])]

#text("Thank you for your answer!")#linebreak()#text(" If I understand correctly, theorem 5.1 in paper A says that the result proven in paper A is essentially equivalent to the decoupling theorem in paper B in the case of the paraboloid. (Ignoring the fact that in Thm. 5.1 one deals with weighted ")#mi("L^p")#text(" spaces. But I guess the weights can be omitted if one deals with Schwartz functions.) Is this correct?")#linebreak()#text(" Furthermore, is it possible to prove the decoupling theorem as stated in paper B for ")#mi("p>\\frac{2(n+1)}{n-1}")#text(" by using the machinery developed in paper A (maybe by running a similar iteration scheme as in section 10 of paper A but with a different value for ")#mi("\\kappa_p")#text(")? Or does the usage of the multilinear Kakeya inequality rather than the multilinear restriction theorem limit oneself to the case ")#mi("2\\leq p\\leq \\frac{2(n+1)}{n-1}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5ee03d4752d7163246d382722ac208bba836d1ecc5f524eb9da918fab51ddb3-39b24343ae316accccc1021947c5e43e5e7bc704a977e672bfc023a43d63a040.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zane Li")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-480653")[#strong[#text("Zane Li")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2017")])]

#text("I can try to answer both your questions:")#linebreak()#text(" 1. Yes, Theorem 5.1 basically says that if I know how big decoupling constant is in paper A, then I know how big the decoupling constant is in paper B. Remark 5.2 in paper B remarks on the equivalence of various decoupling constants. Note that the ")#mi("w_B")#text(" in paper A are slightly different from the ones in paper B.")

#text("2. I imagine it could be possible, since multilinear Kakeya is used only in the proof of ball inflation (Theorem 9.2 of paper A) and only imposes the requirement that ")#mi("p \\geq 2n/(n - 1)")#text(". However, note that the argument relies on that ")#mi("2(1 - \\kappa_{p}) > 1")#text(" (equation (50) in paper A) and as I get closer to ")#mi("2(n + 1)/(n - 1)")#text(", ")#mi("2(1 - \\kappa_p)")#text(" gets closer to 1. So you may need to rearrange the argument a bit.")

#text("I think the standard argument to get the decoupling constant in the range ")#mi("p > 2(n + 1)/(n - 1)")#text(" is to first prove it for the critical ")#mi("p = 2(n + 1)/(n - 1)")#text(" and then interpolate (via Holder) with the trivial ")#mi("L^{\\infty}")#text(" bound which comes just from Cauchy-Schwarz. Finally, use the uncertainty principle at the end to relate the ")#mi("\\ell^2")#text(" sums of the ")#tao-math("\\left\\|f_{\\theta}\\right\\|_{L^{\\infty}}", block: false)#text(" and ")#tao-math("\\left\\|f_{\\theta}\\right\\|_{L^2}", block: false)#text(" pieces to the ")#mi("\\ell^2")#text(" sum of the ")#tao-math("\\left\\|f_{\\theta}\\right\\|_{L^p}", block: false)#text(" piece. (See proposition 10 in Jonathan Hickman’s notes: ")#link("http://math.uchicago.edu/~j.e.hickman/Decoupling%20notes%205.pdf")[#text("http://math.uchicago.edu/~j.e.hickman/Decoupling%20notes%205.pdf")]#text(")")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-482325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2017")])]

#text("Dear Prof. Tao,")

#text("may I ask you to elaborate on how the dyadic pigeonhole argument in the proof of (vi) in Prop. 7 works?")

#text("In particular, I do not understand what the required estimates are to justify that one can discard the contribution of those ")#mi("I")#text(" for which the quantities ")#tao-math("\\frac{1}{\\left|B^{\\prime}\\right|}\\int F_I w_{B^{\\prime}}", block: false)#text(" are less than ")#mi("N^{-100 n^2}")#text(" of the maximum value. In addition, I don’t quite understand how one comes up with the factor ")#mi("N^{o(1)}")#text(" when one normalises the above quantities to be of comparable size.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-483055")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2017")])]

#text("Let’s normalise the maximum value of ")#tao-math("\\frac{1}{\\left|B^{\\prime}\\right|} \\int F_I w_{B^{\\prime}}", block: false)#text(" for ")#mi("I \\in {\\mathcal I}_{j,q}")#text(" to equal ")#mi("1")#text(" for each ")#mi("j")#text(", so the RHS is at least 1. Suppose we have some ")#mi("j_0")#text(" and some ")#mi("I_0 \\in {\\mathcal I}_{j_0,q}")#text(" for which ")#tao-math("\\frac{1}{\\left|B^{\\prime}\\right|} \\int F_{I_0} w_{B^{\\prime}} \\leq N^{-100 n^2}", block: false)#text(". This implies a pointwise estimate of the form ")#mi("F_{I_0} w_{B^{\\prime}} \\ll N^{-100n^2 + 10n}")#text(" (say). Meanwhile, for all other ")#mi("j")#text(" and all other ")#mi("I \\in {\\mathcal I}_{j,q}")#text(" we similarly have ")#mi("F_{I} w_{B^{\\prime}} \\ll N^{10n}")#text(", and this is enough to make the contribution of all such ")#mi("I_0")#text(" to the LHS to be negligible.")

#text("After the quantities ")#tao-math("\\frac{1}{\\left|B^{\\prime}\\right|} \\int_{B^{\\prime}} F_I w_{B^{\\prime}}", block: false)#text(" have been restricted to lie between ")#mi("1")#text(" and ")#mi("N^{-100 n^2}")#text(", there are only ")#mi("\\log N^{-100 n^2} = N^{o(1)}")#text(" dyadic ranges that they could lie in, so by decomposing into these ranges and using the triangle inequality one can restrict to a single dyadic range for each ")#mi("j")#text(" (giving up a factor of ")#mi("N^{o(1)}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-483262")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2017")])]

#text("Dear Prof. Tao,")

#text("I’m currently studying the latest paper of Bourgain and Demeter on decoupling (")#link("https://arxiv.org/abs/1604.06032")[#text("https://arxiv.org/abs/1604.06032")]#text("), but there is one issue I just don’t understand. In the proof of Prop. 8.4 in order to apply Thm. 5.1 the authors claim that the Fourier transform of the function ")#mi("(x,z)\\mapsto E_{S_L}g(x,y,z)")#text(" (let’s call this function ")#mi("E_{S_L,y}g)")#text(" for fixed ")#mi("y")#text(" is supported in the ")#mi("O(K^{-1})")#text(" neighborhood of the parabola ")#mi("\\eta=\\xi^2+1")#text(". But for Thm. 5.1 I need that the Fourier support lies in the smaller set ")#mi("N_{C/R}([0,1])")#text(" for some constant ")#mi("C>0")#text(".")

#text("My question is the following: How is the Fourier transform of ")#mi("E_{S_L,y}g")#text(" defined in order to give the author’s claim above any sense? Since ")#mi("E_{S_L,y}g")#text(" does not lie in any ")#mi("L^p")#text(" space, the usual definition does not make sense, does it?")

#text("If I consider ")#mi("E_{S_L,y}g")#text(" as a distribution, then I’m able to conclude that it has Fourier support (in the distributional sense) in ")#mi("N_{C/R}([0,1])")#text(". But that doesn’t seem to help me when I want to apply Thm. 5.1.")

#text("May I ask you to elaborate on this issue and explain how equation (21) in the above paper can be derived?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fdf28788bd854dc8b2e1841d291f38f6231db3eb68e75aacb0c3aa022605aa6-9371ef0d925bcade8212d5780d81ec05bc70db2690b0d3f5ea439c1c307e0818.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitrii Zhelezov")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-485315")[#strong[#text("Dmitrii Zhelezov")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2017")])]

#text("Dear Terence,")

#text("I wonder if some of the decoupling techniques may be applicable in the finite field setting (it’s more of a blind guess rather than suggestion)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-485318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2017")])]

#text("A key input of decoupling is the ability to induct on multiple scales, and we don’t seem to have an analogue of this in finite fields (where there are basically only two scales, the scale of a single point, and the scale of the entire field), except possibly in those situations where the finite field has a number of non-trivial subfields. On the other hand, Wooley has a recent preprint at ")#link("https://arxiv.org/abs/1708.01220")[#text("https://arxiv.org/abs/1708.01220")]#text(" where he develops a nested efficient congruencing method that is in some sense a “p-adic analogue” of decoupling (and in particular provides a second proof of the Vinogradov main conjecture) and which can be applied relatively easily to function field settings.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-485364")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2017")])]

#text("Is it possible to combine both methods (to a possibly stronger method)?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DZ")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-493929")[#strong[#text("DZ")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2018")])]

#text("In the proof of Proposition 6, should ‘for some ")#mi("k_1 < \\dots < k_K")#text("' be read for some ")#mi("k_1 < \\dots < k_M")#text(" ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-510045")[#strong[#text("L’impatto matematico di Jean Bourgain | Maddmaths!")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")]

#text("[…] La stima della quantità (J_{s,k}(N)), introdotta da Vinogradov, è importante in problemi analitici e combinatorici della teoria dei numeri (problema di Waring, somme di Weyl, etc.). La congettura di Vinogradov dice che, fissati (k,,s), per ogni (epsilon>0) si ha [J_{s,k}(N)ll N^{s+epsilon}+N^{2s-n(n+1)/2+epsilon}] as (Ntoinfty). Risultati parziali era conosciuti, e Wooley aveva risolto i casi (k=1,2,3) e certi intervalli di valori (s) e (k). La soluzione completa è stata ottenuta da Bourgain, in collaborazione con Demeter e Guth. A differenza della dimostrazione di Wooley, basata sul cosiddetto metodo di fare congruenze efficentemente, la loro dimostrazione è basata su nuovi strumenti di analisi armonica. In particolare, in un lavoro precedente con Demeter su Annals del 2015, Bourgain ha dimostrato delle proprietà di disaccoppiamento in (L^{n(n+1)}) (una specie di proprietà di ortogonalità debole, molto più flessibile della classica ortogonalità in (L^2)) per la famiglia di trasformate di Fourier [f_i(x)=int_{gamma(J_i)}e(xcdot xi),dsigma(xi)qquadhbox{with}qquad J_i=gamma([frac{(i-1)} N, frac iN])]associate alle curve di potenza (gamma(t)=(t,t^2,ldots,t^n)), (tin [0,1]). Questa è la nuova idea chiave nella dimostrazione della congettura di Vinogradov. Una descrizione più estesa la potete trovare nel blog di Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abstracting induction on scales arguments | What's new")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-517384")[#strong[#text("Abstracting induction on scales arguments | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("[…] It was shown by Bourgain, Demeter, and Guth that is of subpolynomial size for all in the optimal range , which among other things implies the Vinogradov main conjecture (as discussed in this previous post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-541379")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2020")])]

#text("The answer to your question “A random thought – could this allow the Vinogradov-Korobov bounds on the zeta function to extend to Beurling zeta functions?” is no, see this paper")

#text("Diamond, Harold G.(1-IL); Montgomery, Hugh L.(1-MI); Vorhauer, Ulrike M. A.(1-KNTS) Beurling primes with large oscillation.")

#text("in which they show that 1 – c / \\log t is the best zero-free region one can get in the case of Beurling primes (one can construct sets of Beurling primes with zeros beyond this region).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-541531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2020")])]

#text("It’s true that this technically answers the question in the negative, but one could still hope that if one imposes stronger conditions on the Beurling primes (for instance, some uniform spacing between Beurling integers) then one could use decoupling methods to improve upon the classical zero free region. I haven’t looked into this carefully, though. [Admittedly, the uniform spacing hypothesis is extremely strong and it may well be that it excludes all examples that aren’t essentially arithmetic in nature, but still it would emphasise the point that the Vinogradov zero free region is not inherently arithmetic in nature.]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-552322")[#strong[#text("Adicional 1: Otras introducciones a la teoría de desacople – Restricción y Desacople (Lic) – Teoría de Restricción y Desacople (Doc)")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2020")]

#text("[…] ")#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vino&#8230")[#text("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vino&#8230")]#text("; […]")
]
