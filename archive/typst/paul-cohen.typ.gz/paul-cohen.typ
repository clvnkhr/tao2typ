// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/03/25/paul-cohen/
// Converted to Typst by tao2typ: "2026-10-13T06:05:06.014577+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Paul Cohen", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set par(justify: true, leading: 0.65em, spacing: 0.9em)
#set heading(numbering: none)
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#text(size: 23pt, weight: "semibold")[#text("Paul Cohen")]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 March 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/03/25/paul-cohen/")[#text("https://terrytao.wordpress.com/2007/03/25/paul-cohen/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-13 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am very saddened to find out (first via Wikipedia, then by several independent confirmations) that ")#link("http://en.wikipedia.org/wiki/Paul_Cohen_(mathematician)")[#text("Paul Cohen")]#text(" ")#link("http://www.cs.nyu.edu/pipermail/fom/2007-March/011482.html")[#text("died on Friday, aged 72")]#text(".")

#text("Paul Cohen is of course best known in mathematics for ")#link("http://www.ams.org/mathscinet-getitem?mr=232676")[#text("his Fields Medal-winning proof")]#text(" of the undecidability of the ")#link("http://en.wikipedia.org/wiki/Continuum_hypothesis")[#text("continuum hypothesis")]#text(" within the ")#link("http://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory")[#text("standard Zermelo-Frankel-Choice (ZFC) axioms of set theory")]#text(", by introducing the now standard method of ")#link("http://en.wikipedia.org/wiki/Forcing_%28mathematics%29")[#text("forcing")]#text(" in model theory. (More precisely, assuming ZFC is consistent, Cohen proved that models of ZFC exist in which the continuum hypothesis fails; Gödel had previously shown under the same assumption that models exist in which the continuum hypothesis is true.) Cohen’s method also showed that the axiom of choice was independent of ZF. The friendliest introduction to forcing is perhaps still ")#link("http://www-math.mit.edu/~tchow/")[#text("Timothy Chow")]#text("‘s “")#link("http://www-math.mit.edu/~tchow/mathstuff/forcingdum")[#text("Forcing for dummies")]#text("“, though I should warn that Tim has a rather stringent definition of “dummy”.")

#text("But Cohen was also a noted analyst. For instance, the ")#link("http://www.ams.org/mathscinet-getitem?mr=133397")[#text("Cohen idempotent theorem")]#text(" in harmonic analysis classifies the idempotent measures ")#mi("\\mu")#text(" in a locally compact abelian group G (i.e. the finite regular measures for which ")#mi("\\mu * \\mu = \\mu")#text("); specifically, a finite regular measure ")#mi("\\mu")#text(" is idempotent if and only if the Fourier transform ")#mi("\\hat \\mu")#text(" of the measure only takes values 0 and 1, and furthermore can be expressed as a finite linear combination of indicator functions of cosets of open subgroups of the Pontryagin dual ")#mi("\\hat G")#text(" of G. (Earlier results in this direction were obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=58027")[#text("by Helson")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=105593")[#text("by Rudin")]#text("; a non-commutative version was subsequently given ")#link("http://www.ams.org/mathscinet-getitem?mr=860817")[#text("by Host")]#text(". These results play an important role in abstract harmonic analysis.) Recently, ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" and ")#link("http://www.dpmms.cam.ac.uk/~tws22/")[#text("Tom Sanders")]#text(" ")#link("http://arxiv.org/abs/math/0611286")[#text("connected this classical result")]#text(" to the very recent work on Freiman-type theorems in additive combinatorics, using the latter to create a quantitative version of the former, which in particular is suitable for use in finite abelian groups.")

#text("Paul Cohen’s legacy also includes the advisorship of outstanding mathematicians such as the number theorist and analyst ")#link("http://en.wikipedia.org/wiki/Peter_Sarnak")[#text("Peter Sarnak")]#text(" (who, incidentally, taught me analytic number theory when I was a graduate student). Cohen was in fact my “uncle”; his advisor, ")#link("http://en.wikipedia.org/wiki/Antoni_Zygmund")[#text("Antoni Zygmund")]#text(", was the advisor of my own advisor ")#link("http://en.wikipedia.org/wiki/Elias_M._Stein")[#text("Elias Stein")]#text(".")

#text("It is a great loss for the world of mathematics.")

#text("[")#emph[#text("Update")]#text(", Mar 25: Added the hypothesis that ZFC is consistent to the description of Cohen’s result. Several other minor edits also.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/25/paul-cohen/#comment-167")[#strong[#text("Paul Cohen « What’s new « cow_gone_mad")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2007")

#text("[…] « What’s new Posted in Uncategorized by cowgonemad on the March 25th, 2007 Okay, over at Paul Cohen « What’s new, I learnt that Paul Cohen has recently died. The only thing about him I know personally, that I […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/25/paul-cohen/#comment-168")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2007")

#text("Cohen’s proofs (like virtually all set theoretic independence proofs) are relative consistency proofs. He proved that if ZFC is consistent, then ZFC is consistent with the failure of the continuum hypothesis. The power of Cohen’s technique is hard to underestimate – it is essentially the only known way to enlarge a model of set theory. (There are lots of ways to shrink them.) Cohen also showed that the axiom of choice is independent of the other axioms using a variation of this technique.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/25/paul-cohen/#comment-31343")[#strong[#text("Timothy Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2008")

#text("I recently developed “Forcing for dummies” into a full-length article called ")#link("http://arxiv.org/abs/0712.1320")[#text("A beginner’s guide to forcing")]#text(". Some readers may prefer it to my original article.")
]
