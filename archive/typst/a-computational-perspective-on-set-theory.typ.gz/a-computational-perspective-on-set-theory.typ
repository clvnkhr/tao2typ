// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/
// Converted to Typst by tao2typ: "2026-10-14T08:55:27.810761+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A computational perspective on set theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A computational perspective on set theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 March 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/")[#text("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The standard modern foundation of mathematics is constructed using ")#link("http://en.wikipedia.org/wiki/Set_theory")[#text("set theory")]#text(". With these foundations, the mathematical universe of objects one studies contains not only the “primitive” mathematical objects such as numbers and points, but also sets of these objects, sets of sets of objects, and so forth. (In a ")#emph[#text("pure")]#text(" set theory, the primitive objects would themselves be sets as well; this is useful for studying the foundations of mathematics, but for most mathematical purposes it is more convenient, and less conceptually confusing, to refrain from modeling primitive objects as sets.) One has to carefully impose a suitable collection of axioms on these sets, in order to avoid paradoxes such as ")#link("http://en.wikipedia.org/wiki/Russell%27s_paradox")[#text("Russell’s paradox")]#text("; but with a standard axiom system such as ")#link("http://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory")[#text("Zermelo-Fraenkel-Choice")]#text(" (ZFC), all actual paradoxes that we know of are eliminated. Still, one might be somewhat unnerved by the presence in set theory of statements which, while not genuinely paradoxical in a strict sense, are still highly unintuitive; ")#link("http://en.wikipedia.org/wiki/Cantor%27s_theorem")[#text("Cantor’s theorem on the uncountability of the reals")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Banach-Tarski_paradox")[#text("Banach-Tarski paradox")]#text(", are perhaps the two most familiar examples of this.")

#text("One may suspect that the reason for this unintuitive behaviour is the presence of infinite sets in one’s mathematical universe. After all, if one deals solely with finite sets, then there is no need to distinguish between countable and uncountable infinities, and Banach-Tarski type paradoxes cannot occur.")

#text("On the other hand, many statements in infinitary mathematics can be reformulated into equivalent statements in finitary mathematics (involving only finitely many points or numbers, etc.); I have explored this theme ")#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/")[#text("in a")]#text(" ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("number")]#text(" ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("of previous")]#text(" ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("blog")]#text(" ")#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/")[#text("posts")]#text(". So, one may ask: what is the finitary analogue of statements such as Cantor’s theorem or the Banach-Tarski paradox?")

#text("The finitary analogue of Cantor’s theorem is well-known: it is the assertion that ")#mi("{2^n > n}")#text(" for every natural number ")#mi("{n}")#text(", or equivalently that the power set of a finite set ")#mi("{A}")#text(" of ")#mi("{n}")#text(" elements cannot be enumerated by ")#mi("{A}")#text(" itself. Though this is not quite the end of the story; after all, one also has ")#mi("{n+1 > n}")#text(" for every natural number ")#mi("{n}")#text(", or equivalently that the union ")#mi("{A \\cup \\{a\\}}")#text(" of a finite set ")#mi("{A}")#text(" and an additional element ")#mi("{a}")#text(" cannot be enumerated by ")#mi("{A}")#text(" itself, but the former statement extends to the infinite case, while the latter one does not. What causes these two outcomes to be distinct?")

#text("On the other hand, it is less obvious what the finitary version of the Banach-Tarski paradox is. Note that this paradox is available only in three and higher dimensions, but not in one or two dimensions; so presumably a finitary analogue of this paradox should also make the same distinction between low and high dimensions.")

#text("I therefore set myself the exercise of trying to phrase Cantor’s theorem and the Banach-Tarski paradox in a more “finitary” language. It seems that the easiest way to accomplish this is to avoid the use of set theory, and replace sets by some other concept. Taking inspiration from theoretical computer science, I decided to replace concepts such as functions and sets by the concepts of ")#link("http://en.wikipedia.org/wiki/Algorithm")[#text("algorithms")]#text(" and ")#link("http://en.wikipedia.org/wiki/Oracle_machine")[#text("oracles")]#text(" instead, with various constructions in set theory being replaced instead by computer language ")#link("http://en.wikipedia.org/wiki/Pseudocode")[#text("pseudocode")]#text(". The point of doing this is that one can now add a new parameter to the universe, namely the amount of computational resources one is willing to allow one’s algorithms to use. At one extreme, one can enforce a “strict ")#link("http://en.wikipedia.org/wiki/Finitism")[#text("finitist")]#text("” viewpoint where the total computational resources available (time and memory) are bounded by some numerical constant, such as ")#mi("{10^{100}}")#text("; roughly speaking, this causes any mathematical construction to break down once its complexity exceeds this number. Or one can take the slightly more permissive “finitist” or “")#link("http://en.wikipedia.org/wiki/Constructivism_(mathematics)")[#text("constructivist")]#text("” viewpoint, where any finite amount of computational resource is permitted; or one can then move up to allowing any construction indexed by a countable ")#link("http://en.wikipedia.org/wiki/Ordinal_number")[#text("ordinal")]#text(", or the storage of any array of countable size. Finally one can allow constructions indexed by arbitrary ordinals (i.e. ")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("transfinite induction")]#text(") and arrays of arbitrary infinite size, at which point the theory becomes more or less indistinguishable from standard set theory.")

#text("I describe this viewpoint, and how statements such as Cantor’s theorem and Banach-Tarski are interpreted with this viewpoint, below the fold. I should caution that this is a conceptual exercise rather than a rigorous one; I have not attempted to formalise these notions to the same extent that set theory is formalised. Thus, for instance, I have no explicit system of axioms that algorithms and oracles are supposed to obey. Of course, these formal issues have been explored in great depth by logicians over the past century or so, but I do not wish to focus on these topics in this post.")

#text("A second caveat is that the actual semantic content of this post is going to be extremely low. I am not going to provide any genuinely new proof of Cantor’s theorem, or give a new construction of Banach-Tarski type; instead, I will be reformulating the standard proofs and constructions in a different language. Nevertheless I believe this viewpoint is somewhat clarifying as to the nature of these paradoxes, and as to how they are not as fundamentally tied to the nature of sets or the nature of infinity as one might first expect.")

#metadata(none) <tao-cea05b234808f4deed7d>

#heading(level: 1)[#strong[#text(" — 1. A computational perspective on mathematics — ")]]

#text("The great advantage of using set theory in mathematics is that all objects in a given set (e.g. all numbers in the real line ")#mi("{{\\bf R}}")#text(") are available to you at all times; one can take one, many, or all objects in a set and manipulate them as one wishes (cf. the ")#link("http://en.wikipedia.org/wiki/Axiom_schema_of_replacement")[#text("axiom schema of replacement")]#text("); similarly, one can assign a truth value to a statement that quantifies over an arbitrary number of objects. If one removes sets from the picture, then one no longer has immediate access to arbitrary elements of a set, and one can no longer perform operations ")#emph[#text("en masse")]#text(" on all the elements of a set at once; instead, one must use some (possibly more restrictive) protocol for manipulating objects in a class, or verifying whether a given statement is true or false. (In more philosophical terms, we are focusing more on an epistemological approach to mathematics, based on what we can measure and query, as opposed to an ontological approach, based on what we believe to exist.)")

#text("For this, it is convenient to use the conceptual framework that is familiar to us through modern computer languages, such as ")#link("http://en.wikipedia.org/wiki/C_(programming_language)")[#text("C")]#text(". In this paradigm, when dealing with a class of objects (e.g. integers), we do not get access to the entire set ")#mi("{{\\bf Z}}")#text(" of integers directly. Instead, we have to declare a integer variable, such as ")#mi("{n}")#text(", and set it equal to some value, e.g. ")#mi("{n := 57}")#text("; or, if one is creating a routine that takes input, ")#mi("{n}")#text(" might be initialised to one of the unspecified inputs of that routine. Later on, we can use existing variables to define new ones, or to redefine existing ones, e.g. one might define ")#mi("{m}")#text(" to equal ")#mi("{n * n}")#text(", or perhaps one can increment ")#mi("{n}")#text(" to ")#mi("{n+1}")#text(". One can then set up various loops and iterations to explore more of the parameter space; for instance, if countably infinite loops are permitted as a computational resource, then one can exhaust the positive integers by starting at ")#mi("{n=1}")#text(" and incrementing ")#mi("{n}")#text(" by ")#mi("{1}")#text(" indefinitely; one can similarly exhaust the negative integers, and by alternating between the two (and also passing through ")#mi("{0}")#text(") one can exhaust the entire integers by a countably infinite loop. This of course is just the standard demonstration that the integers are countable.")

#text("Real-world computers, of course, have finite limits of precision; they cannot represent arbitrarily large integers, but only integers up to a certain size (e.g. ")#mi("{2^{16}-1}")#text(" or ")#mi("{2^{32}-1}")#text("). One could think about computational models with such a strict finitary limitation, but let us assume that we are in a more idealised setting in which there are no limitations on how large an integer one can store. Let us then make the even more idealised assumption that we can also store real numbers with unlimited precision; our computer never makes any roundoff errors. (Note that there are indeed ")#link("http://en.wikipedia.org/wiki/Arbitrary-precision_arithmetic")[#text("arbitrary precision models of computation")]#text(" that can do this, though the catch is that speed of computation depends heavily on how complicated it is to describe any given number.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" A technical point: it may be that the computational model of the real numbers is different from the standard real line ")#mi("{{\\bf R}}")#text("; for instance, perhaps the computer only implements “constructible” real numbers, which is for instance the case in physical arbitrary precision computers. We will touch upon this point again later.")
]

#text("Note that if one were to expand out a given real number, say ")#mi("{\\pi}")#text(", as a decimal expansion, then one would obtain an infinite string of digits. But, just as we do not have direct access to the set ")#mi("{{\\bf Z}}")#text(" of all integers, we will not have direct access to the entire decimal expansion of ")#mi("{\\pi}")#text(". If we have a natural number ")#mi("{n}")#text(", we are allowed to inspect the ")#mi("{n^{th}}")#text(" digit of ")#mi("{\\pi}")#text(" by making a suitable function call (e.g. ")#mi("{\\text{digit}(\\pi,n)}")#text("), and if we are allowed to set up an infinite loop in which ")#mi("{n}")#text(" starts at ")#mi("{1}")#text(" and increments indefinitely, one can exhaust all the digits of ")#mi("{\\pi}")#text(", which is good enough for most “practical” mathematical purposes. (For instance, if one were allowed to run programs of countable length using real arithmetic, one could make a program that determined whether ")#mi("{\\pi}")#text(" was ")#link("http://en.wikipedia.org/wiki/Normal_number")[#text("normal")]#text(" or not, or to determine the truth of the Riemann hypothesis, or more generally to compute the truth-value of any ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("first-order sentence")]#text(" in the theory of the real line.)")

#text("We assume that the usual arithmetic operations can be performed on real numbers in reasonable amounts of time. For instance, given two real numbers ")#mi("{x, y}")#text(", one can determine whether they are equal or not in finite time (consulting some sort of “equality oracle” for the reals if necessary). Note that equality can be a subtle issue; if one thinks of real numbers as infinite strings of digits, their equality can only be verified directly by using a countable amount of computing power. But we will sidestep the issue of how exactly the reals are implemented by simply assuming that enough oracles exist to perform real arithmetic at an acceptable computational cost.")

#text("As already hinted at in the above discussion, we are assuming that our computer has access to a certain amount of computing resources (e.g. time, memory, random number generation, oracles). We will be rather vague on exactly how to formalise the concept of a resource, but basically the standard definitions used in computer science would be a good approximation here, at least when the resources are finite. But one can consider allowing for certain computational resources to be infinite in some carefully controlled manner; for instance, one could consider a situation in which countably infinite loops are permitted (provided that all variables in the loop that one wants to retain “converge” in some sense at the end of the loop), but for which uncountable loops are not allowed. We will not formalise such concepts here (but roughly speaking, they correspond to allowing transfinite induction up to some specified ordinal, and no further).")

#text("We will not be using sets or set-theoretic functions in this computer language. However, we will use as a substitute the concept of an ")#link("http://en.wikipedia.org/wiki/Oracle_machine")[#text("oracle")]#text(" – a “black box” routine ")#mi("{f()}")#text(" that takes zero or more variables of a given class as input, and returns zero or more variables in various classes as output (usually we will have just a single output, but it will be convenient to allow multiple outputs). Being a black box, we do not know how the oracle obtains the output from the input, but we are able to use the oracle anyway. Let us assume that each invocation of an oracle takes some acceptable amount of time (e.g. bounded time when the computational resources are finite, or countably infinite time if countable time resources are allowed, etc.). All our oracles are ")#emph[#text("consistent")]#text(" in the sense that they always produce the same output for a fixed choice of input; thus, if one calls the oracle again at some later time with the same input, then the oracle will return the same output as it did before. It is important to note that consistency is a subtly weaker assumption than requiring the oracle is ")#emph[#text("non-adaptive")]#text("; we allow the oracle to “remember” previous queries, and to use that memory to formulate answers to later queries, as long as it does not contradict the outputs it gave previously.")

#text("We will be concerned primarily with ")#emph[#text("membership oracles")]#text(" – an oracle ")#mi("{E()}")#text(" that takes a variable ")#mi("{x}")#text(" in a given class and returns an answer ")#mi("{E(x)}")#text(" that is either “Yes” or “No”. Informally, the oracle ")#mi("{E}")#text(" is describing some subset of this class, and is answering questions regarding whether any given variable ")#mi("{x}")#text(" lies in this set or not. Note, however, that this set only exists in a “virtual” or “potential” sense; if the oracle is adaptive, the set of inputs that will give a “Yes” answer may not yet be fixed, but could depend on future queries to the oracle. If the class can be exhausted within the computational resources permitted (e.g. if the parameter space can be countably enumerated by the computer, and countably infinite loops are permitted), then one can query the oracle for every single element and thus pin down the set completely (though one may not be able to ")#emph[#text("store")]#text(" this set if one does not have sufficient memory resources!), but if the parameter space is too large to be exhausted with the available resources, then the set that the oracle is describing will never be completely described.")

#text("To illustrate this, let us briefly return to the traditional language of set theory and recall the following textbook example of a non-measurable subset ")#mi("{E}")#text(" of the reals ")#mi("{{\\bf R}}")#text(". This set is constructed by partitioning ")#mi("{{\\bf R}}")#text(" into cosets ")#mi("{x+{\\bf Q}}")#text(" of the rationals ")#mi("{{\\bf Q}}")#text(", and then using the axiom of choice to selecting a single representative of each coset; the set ")#mi("{E}")#text(" is the collection of all such representatives. Thus the rational translates ")#mi("{E+q}")#text(", ")#mi("{q \\in {\\bf Q}}")#text(" partition ")#mi("{{\\bf R}}")#text(", and it is not hard to then deduce (using the properties of ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(") that ")#mi("{E}")#text(" cannot be Lebesgue measurable.")

#text("We can simulate this non-measurable set by an ")#emph[#text("adaptive")]#text(" oracle ")#mi("{E()}")#text(", which remembers all prior queries to itself, and works as follows:")

#list(
[#mi("{E()}")#text(" takes a real number ")#mi("{x}")#text(" as input.")],
[#text("If ")#mi("{E()}")#text(" has previously answered the question ")#mi("{E(x)}")#text(" of whether ")#mi("{x}")#text(" lies in ")#mi("{E}")#text(", repeat whatever answer was given previously.")],
[#text("If ")#mi("{x}")#text(" has not been queried before, and if furthermore no rational translate ")#mi("{x+q}")#text(" of ")#mi("{x}")#text(" has been queried before either (i.e. ")#mi("{x}")#text(" differs from all previous queries by an irrational number), then answer ")#mi("{E(x)}")#text(" with “yes”.")],
[#text("Finally, if ")#mi("{x}")#text(" has not been queried before, but ")#mi("{x+q}")#text(" has been queried before for some rational ")#mi("{q}")#text(", then answer ")#mi("{E(x)}")#text(" with “no”.")],
[#text("Store ")#mi("{x}")#text(" (and ")#mi("{E(x)}")#text(") in memory for use in future queries.")]
)

#text("Assuming one has a rationality oracle ")#mi("{{\\bf Q}()}")#text(" that can tell (in bounded time) whether a given real number ")#mi("{x}")#text(" is rational or not, then ")#mi("{E}")#text(" is a perfectly programmable oracle, which will run in finite time whenever one asks only a finite number of queries of it. (After querying the oracle an infinite number of times, though, it will require an infinite search loop in order to make sure that any subsequent answer it gives is consistent with all previous answers, unless one is allowed to use an infinite amount of memory, e.g. an array indexed by the quotient space ")#mi("{{\\bf R}/{\\bf Q}}")#text(".) It is even completely deterministic – it requries no arbitrary choices on the part of the oracle. If one had the patience to query this oracle for every single real number ")#mi("{x}")#text(" (which would, of course, require an uncountable number of queries), the oracle would eventually describe completely the non-measurable set ")#mi("{E}")#text(". But if one is only permitted a finite or countable number of queries, then the non-measurable set only exists in some “virtual” sense.")

#text("More generally, non-adaptive oracles tend to generate measurable sets, while adaptive oracles are likely to generate non-measurable sets. So we see that non-measurability does not have to be viewed as a quirk arising from the nature of infinity, or from the axiom of choice; it can be viewed instead as the freedom to adapt to previous queries to membership of the set, which is a concept that makes sense even in a strictly finitist setting.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can think of an non-adaptive oracle as being like a truthful observer, reporting on some objective set that exists independently of the queries, while an adaptive oracle is more like a pathological liar, inventing a previously non-existent set on the fly as needed in order to consistently answer the questions posed of it. It is then not so surprising that the set thus invented is likely to be non-measurable. We thus see that the ability of oracles to adapt is somewhat analogous to the role the axiom of choice plays in traditional set theory.")
]

#text("We will discuss measurability and non-measurability in more detail a little later in this post.")

#text("We have seen that membership oracles are sort of like “virtual” sets. Many set operations can be simulated for membership oracles. For instance, given two membership oracles ")#mi("{E(), F()}")#text(" that apply to variables ")#mi("{x}")#text(" in some class (e.g. the real numbers), one can form the union oracle ")#mi("{(E \\cup F)()}")#text(", which works by querying both ")#mi("{E(x)}")#text(" and ")#mi("{F(x)}")#text(" and returning “Yes” if at least one of ")#mi("{E(x)}")#text(" and ")#mi("{F(x)}")#text(" was “Yes”, and “No” otherwise. More generally, any finite boolean operation of membership oracles gives another membership oracle, and (if countable computational resources are available) the same is true for countable boolean operations also. As one increases the amount of computational resources available, more and more set-theoretic operations become available, and when one allows unlimited resources (or more precisely, transfinite induction up to any ordinal, and storage of arbitrarily sized infinite sets), then all the standard operations in set theory (e.g. invocations of the ")#link("http://en.wikipedia.org/wiki/Axiom_schema_of_replacement")[#text("axiom schema of replacement")]#text(", the ")#link("http://en.wikipedia.org/wiki/Power_set_axiom")[#text("power set axiom")]#text(", the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(", etc.) become available.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Membership oracles ")#mi("{E()}")#text(" only describe a raw, unstructured set. If one wants to place additional structure on a set (e.g. measure structure, topological structure, smooth structure, etc.) then additional oracles would be needed. Of course, the same is true in traditional set theory; for instance, to place a topology on a set ")#mi("{E}")#text(" one also needs to specify a collection ")#mi("{{\\mathcal F}}")#text(" of open sets on ")#mi("{E}")#text(" obeying the axioms of a topology, and similarly for other structures one can place on sets. We will see an example of these additional oracles later in this post, when we revisit the concept of measurability.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Membership oracles are weaker than sets in many ways. One of these comes from a breakdown of the law of the excluded middle. In set theory, a statement about a set ")#mi("{E}")#text(" is either true or false; for instance, ")#mi("{E}")#text(" is either finite or infinite. If one is instead given an adaptive membership oracle ")#mi("{E()}")#text(", questions such as whether ")#mi("{E()}")#text(" describes a finite set or not are undecidable if one only has finite computational resources. However, one can imagine strengthening the membership oracle ")#mi("{E()}")#text(" to a oracle that, in addition to answering questions about membership of individual elements, will also answer more general questions about ")#mi("{E}")#text(" (such as whether ")#mi("{E}")#text(" is finite), in such a fashion that all the answers given are consistent with each other. In such a way, the law of the excluded middle can be restored; but then programming an adaptive oracle in a way that keeps all the answers consistent becomes quite a challenge. (Note though that the Gödel completeness theorem asserts, in some sense, that this is always possible, provided that one’s initial constraints on ")#mi("{E}")#text(" are originally consistent.)")
]

#heading(level: 1)[#strong[#text(" — 2. Cantor’s theorem — ")]]

#link("http://en.wikipedia.org/wiki/Cantor%27s_theorem")[#text("Cantor’s theorem")]#text(" (and its proof) transfers easily enough from sets to oracles. The analogue of a (proposed) enumeration of the real numbers is an “enumeration oracle” ")#mi("{f()}")#text(" that takes a natural number ")#mi("{n}")#text(" as input, and returns a real number ")#mi("{f(n)}")#text(" as output; we allow repetitions. The Cantor diagonal argument shows that given any such putative enumeration ")#mi("{f}")#text(", and given access to a countable amount of computing resources, one can construct a real number ")#mi("{x}")#text(" which is guaranteed not to be covered by the enumeration oracle; for instance, one can construct ")#mi("{x}")#text(" to be a string of decimals ")#mi("{0.x_1 x_2 \\ldots = \\sum_{j=1}^\\infty \\frac{x_j}{10^j}}")#text(", with ")#mi("{x_1}")#text(" chosen to be the first digit in ")#mi("{\\{1,\\ldots,8\\}}")#text(" (say) not equal to the first digit of ")#mi("{f(1)}")#text(", ")#mi("{x_2}")#text(" chosen to be the first digit of ")#mi("{\\{1,\\ldots,8\\}}")#text(" not equal to the second digit of ")#mi("{f(2)}")#text(", and so forth. (I exclude the digits ")#mi("{0}")#text(" and ")#mi("{9}")#text(" to avoid the technical and irrelevant ")#mi("{0.999\\ldots = 1.000\\ldots}")#text(" issue.)")

#text("This is of course virtually identical to the usual proof of Cantor’s theorem. But the proof highlights that in order to exhibit a counterexample to the claim that ")#mi("{f}")#text(" enumerates the reals, one needs a countably infinite amount of computational resources. And indeed if one works in a finitary computational model in which one is only allowed to run programs that are guaranteed to halt, and if one limits one’s real number system to the “finitely constructible” reals – those reals that can be generated by halting programs – then one can indeed enumerate the “real numbers” in this system, by enumerating all the possible programs to generate real numbers as ")#mi("{P_1, P_2, \\ldots}")#text(", and computing ")#mi("{f(n)}")#text(" to be the output of ")#mi("{P_m}")#text(", where ")#mi("{1 \\leq m \\leq n}")#text(" is the first integer such that ")#mi("{P_m}")#text(" halts in less than ")#mi("{n}")#text(" steps, while outputting a number different from ")#mi("{f(1),\\ldots,f(n-1)}")#text(" (setting ")#mi("{f(n)=0}")#text(" if no such integer exists). In this model, the real number ")#mi("{x}")#text(" given by Cantor’s argument is not finitely constructible, but only countably constructible. It is only because one has access to countably infinite computational resources (in particular, the ability to sum convergent infinite series such as ")#mi("{\\sum_{j=1}^\\infty \\frac{x_j}{10^j}}")#text("), that the reals are no longer countable.")

#text("Let us now consider a slightly different version of Cantor’s theorem, which in the language of set theory asserts that for a given set ")#mi("{A}")#text(" (e.g. the natural numbers ")#mi("{{\\bf N}}")#text("), that one cannot enumerate the power set ")#mi("{2^A}")#text(" by ")#mi("{A}")#text(" itself. In order to phrase this using the language of oracles rather than sets, one needs to be able to treat oracles themselves as variables; note that many modern computer languages (particularly functional languages such as ")#link("http://en.wikipedia.org/wiki/Lisp_(programming_language)")[#text("Lisp")]#text(" and ")#link("http://en.wikipedia.org/wiki/Haskell_(programming_language)")[#text("Haskell")]#text(") already do this. In particular, we allow for the existence of oracles that generate further oracles as output, or themselves take oracles as input.")

#text("A proposed enumeration of the power set of the natural numbers (say) by the natural numbers themselves can then be viewed as an enumeration oracle ")#mi("{f()}")#text(" which takes a natural number ")#mi("{n}")#text(" as input, and returns a membership oracle ")#mi("{f(n)()}")#text(" in the natural numbers as output; thus ")#mi("{f(n)}")#text(" itself is able to accept a natural number ")#mi("{m}")#text(" as input and return a yes-or-no answer ")#mi("{f(n)(m)}")#text(" as output.")

#text("Cantor’s diagonal argument then asserts that given any proposed enumeration oracle ")#mi("{f()}")#text(" of the above form, one can always find a membership oracle ")#mi("{E()}")#text(" which is not enumerated by ")#mi("{f}")#text(". Indeed, one simply sets ")#mi("{E(n)}")#text(" to be the negation of ")#mi("{f(n)(n)}")#text(" for any given natural number input ")#mi("{n}")#text(".")

#text("With this version of Cantor’s argument, we no longer need a countably infinite amount of computational resources; the above argument is valid even in the finitary computational model. In that model, the argument shows that the class of oracles that terminate in finite time cannot itself be enumerated by an oracle that terminates in finite time; this is essentially ")#link("http://en.wikipedia.org/wiki/Halting_problem")[#text("Turing’s halting theorem")]#text(". Thus we see that Turing’s theorem and Cantor’s theorem are simply different cases of a single general theorem, the former in the case of finitary computational resources and the latter in the case of unlimited computational resources. (See also ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("my previous blog post")]#text(" for further discussion of these “no self-defeating object” arguments.)")

#text("Also observe that this version of Cantor’s argument works if the natural numbers are replaced by any other class of variable; for instance, in the finite class of integers between ")#mi("{1}")#text(" and ")#mi("{n}")#text(", the argument demonstrates that the membership oracles in this class cannot be enumerated by the numbers from ")#mi("{1}")#text(" to ")#mi("{n}")#text(" itself, thus ")#mi("{2^n > n}")#text(".")

#text("Let us now discuss the analogous situation with the inequality ")#mi("{n+1>n}")#text(". The claim is now that if ")#mi("{A}")#text(" is a finite class, and ")#mi("{A^{\\prime}}")#text(" is a strictly larger class (containing at least one additional element ")#mi("{a}")#text(" outside of ")#mi("{A}")#text("), and one is given an enumeration oracle ")#mi("{f()}")#text(" that takes an variable ")#mi("{x}")#text(" in ")#mi("{A}")#text(" as input and returns a variable ")#mi("{f(x)}")#text(" in ")#mi("{A^{\\prime}}")#text(" as output, then one should be able to find a variable ")#mi("{y}")#text(" in ")#mi("{A^{\\prime}}")#text(" or equal to ")#mi("{a}")#text(" which is not covered by the enumeration oracle.")

#text("One way to find such a ")#mi("{y}")#text(" is by the following algorithm, which is just a painfully disguised version of the proof that ")#mi("{n+1>n}")#text(" using induction. Let ")#mi("{a}")#text(" be an element in ")#mi("{A^{\\prime}}")#text(" that is not in ")#mi("{A}")#text(". We first search through all the elements ")#mi("{x}")#text(" of ")#mi("{A}")#text(" to see if there is a solution to the equation ")#mi("{f(x)=a}")#text(". If no solution exists, then we are done; we can just take ")#mi("{y=a}")#text(". So suppose instead that we have some found some ")#mi("{x_0}")#text(" for which ")#mi("{f(x_0)=a}")#text(". Then we can delete ")#mi("{x_0}")#text(", and all other solutions to ")#mi("{f(x)=a}")#text(", from the domain ")#mi("{A}")#text(" of the oracle ")#mi("{f}")#text(", and also delete ")#mi("{a}")#text(" from the output ")#mi("{A^{\\prime}}")#text(" of the oracle, giving rise to a modified oracle ")#mi("{f^{\\prime}}")#text(" which takes as input a variable ")#mi("{x}")#text(" with ")#mi("{f(x) \\neq a}")#text(", and returns the output ")#mi("{f^{\\prime}(x) := f(x)}")#text(". Note that if we ever find a variable ")#mi("{y}")#text(" in the range of ")#mi("{f^{\\prime}}")#text(" that is not enumerated by ")#mi("{f^{\\prime}}")#text(", then ")#mi("{y}")#text(" will not be enumerated by ")#mi("{f}")#text(" either. So we can descend from ")#mi("{f}")#text(" to the oracle ")#mi("{f^{\\prime}}")#text(", which has a smaller domain and range. Also note that the range remains strictly larger than the domain, as ")#mi("{x_0}")#text(" lies in the range but not in the domain. We can thus keep iterating this procedure; since we cannot have an ")#link("http://en.wikipedia.org/wiki/Infinite_descent")[#text("infinite descent")]#text(", the algorithm must eventually terminate. Unpacking the termination condition, we have indeed produced an element ")#mi("{y}")#text(" in the range of ")#mi("{f}")#text(" which was not enumerated by ")#mi("{f}")#text(".")

#text("We observe that this algorithm only halts due to the principle of infinite descent, which is only valid when the initial class one starts with was finite. For infinite classes, which admit infinite descents, one can of course find surjective enumerations between such classes and strictly larger classes; for instance, the enumeration oracle that sends a natural number ")#mi("{n}")#text(" to ")#mi("{n-1}")#text(" is an enumeration of ")#mi("{{\\bf N} \\cup \\{-1\\}}")#text(" by ")#mi("{{\\bf N}}")#text(". In contrast, the proof of Cantor’s theorem does not rely on facts specific to finite classes, such as the principle of infinite descent, and is thus valid in arbitrary classes.")

#heading(level: 1)[#strong[#text(" — 3. Measurability revisited — ")]]

#text("In a previous section, we gave an example of a membership oracle ")#mi("{E}")#text(" in the real line which was non-measurable, in the sense that the set that it was (virtually) describing necessarily failed to be Lebesgue measurable. But the concept of Lebesgue measurability was still defined in the context of set theory, and not in a purely oracle-theoretic language. It is then natural to ask whether one can define Lebesgue measurability purely in the context of computational models, and in particular whether one can discuss this concept in a finitary computational model.")

#text("For simplicity let us now work in a bounded subset of ")#mi("{{\\bf R}}")#text(", such as the unit interval ")#mi("{[0,1]}")#text(", so that we can work with a finite measure rather than a ")#mi("{\\sigma}")#text("-finite measure.")

#text("From classical measure theory, we recall the following characterisation of Lebesgue measurability: a subset ")#mi("{E}")#text(" of the unit interval is Lebesgue measurable if for every ")#mi("{\\epsilon > 0}")#text(", one can find an elementary subset ")#mi("{E_\\epsilon}")#text(" of the unit interval (i.e. a finite union of open intervals) whose set-theoretic difference ")#mi("{E \\Delta E_\\epsilon}")#text(" with ")#mi("{E}")#text(" has ")#link("http://en.wikipedia.org/wiki/Outer_measure")[#text("outer measure")]#text(" less than ")#mi("{\\epsilon}")#text(", or equivalently that it can be covered by a countable collection of intervals ")#mi("{I_{\\epsilon,1}, I_{\\epsilon,2}, \\ldots}")#text(" whose length adds up to less than ")#mi("{\\epsilon}")#text(".")

#text("Thus, if one wants a membership oracle ")#mi("{E()}")#text(" to “certify” its measurability, one way to do so is to provide an additional “measurability oracle” ")#mi("{M()}")#text(", which takes a positive real number ")#mi("{\\epsilon > 0}")#text(" as input, and returns three outputs:")

#list(
[#text("A description of an elementary set ")#mi("{E_\\epsilon}")#text(" (which can be done in a finite amount of time and space, by specifying the number of intervals used to form ")#mi("{E_\\epsilon}")#text(", together with their endpoints);")],
[#text("An interval oracle ")#mi("{I()}")#text(", that for each natural number input ")#mi("{n}")#text(" returns an interval ")#mi("{I_{\\epsilon,n}}")#text(";")],
[#text("A covering oracle ")#mi("{N()}")#text(", which for each real number ")#mi("{x}")#text(" in ")#mi("{E \\Delta E_\\epsilon}")#text(", returns a natural number ")#mi("{n}")#text(" for which ")#mi("{x \\in I_{\\epsilon,n}}")#text(". (Actually, this oracle is redundant, as it can be simulated from the previous two outputs by a finite brute force search.)")]
)

#text("With these oracles, one can then verify the measurability of ")#mi("{E}")#text(" by selecting an ")#mi("{\\epsilon > 0}")#text(", and verifying firstly that after selecting any natural number ")#mi("{N}")#text(", the sum of the lengths of ")#mi("{I_{\\epsilon,1},\\ldots,1_{\\epsilon,N}}")#text(" remains less than ")#mi("{\\epsilon}")#text(", and secondly that after selecting any real number ")#mi("{x}")#text(", that if ")#mi("{x}")#text(" lies in ")#mi("{E}")#text(" but not in ")#mi("{E_\\epsilon}")#text(" or vice versa, that ")#mi("{x}")#text(" indeed lies in ")#mi("{I_{\\epsilon,N(x)}}")#text(". In principle, if one performed this verification procedure an uncountable number of times (once for each choice of ")#mi("{\\epsilon, N, x}")#text(") one would fully demonstrate the measurability of ")#mi("{E}")#text("; but if one instead only had access to finite or countable computational resources, then one could only verify measurability on an “as needed” basis.")

#text("So, in the oracle model, a measurable set is not simply a membership oracle ")#mi("{E()}")#text("; it must also be supplemented with an additional measurability oracle ")#mi("{M()}")#text(" that “witnesses” the measurability. This is analogous to how sets must be augmented with (say) topological structure if one wants to perform topology on that set, or algebraic structure if one wants to perform algebra on that set, etc.")

#text("If one possesses a measurability oracle ")#mi("{M()}")#text(" for a set ")#mi("{E}")#text(" (or more precisely, a membership oracle ")#mi("{E()}")#text("), then can estimate the Lebesgue measure of ")#mi("{E}")#text(" to within accuracy ")#mi("{\\epsilon}")#text(" by calling ")#mi("{M(\\epsilon)}")#text(" to obtain an approximant ")#mi("{E_\\epsilon}")#text(", and then computing the measure ")#tao-math("{\\left|E_\\epsilon\\right|}", block: false)#text(" of ")#mi("{E_\\epsilon}")#text(" (which can be done in a finite amount of time, as ")#mi("{E_\\epsilon}")#text(" is simply a finite union of intervals). A key fact (which, not coincidentally, is crucial in the standard construction of Lebesgue measure) is that these approximations to the Lebesgue measure of ")#mi("{E}")#text(" are compatible with each other in the following sense: if one calls one measurability oracle ")#mi("{M(\\epsilon)}")#text(" for ")#mi("{E()}")#text(" at accuracy ")#mi("{\\epsilon > 0}")#text(" to get one estimate ")#tao-math("{\\left|E_\\epsilon\\right|}", block: false)#text(" for the Lebesgue measure of ")#mi("{E()}")#text(", and if one then calls another (possibly different) measurability oracle ")#mi("{M^{\\prime}(\\epsilon^{\\prime})}")#text(" for the same set ")#mi("{E()}")#text(" at another accuracy ")#mi("{\\epsilon^{\\prime} > 0}")#text(" to get another estimate ")#tao-math("{\\left|E^{\\prime}_{\\epsilon^{\\prime}}\\right|}", block: false)#text(" for ")#mi("{E()}")#text(", then these two estimates can only differ by at most ")#mi("{\\epsilon+\\epsilon^{\\prime}}")#text("; in particular, sending ")#mi("{\\epsilon \\rightarrow 0}")#text(", one obtains a Cauchy sequence and (after a countable number of operations) one can then compute the Lebesgue measure of ")#mi("{E}")#text(" to infinite precision.")

#text("This key fact boils down (after some standard manipulations) to the fact that an interval such as ")#mi("{[a,b]}")#text(" has outer measure at least ")#mi("{b-a}")#text("; in our oracle based model, this means that if one is given an interval oracle ")#mi("{I()}")#text(" that generates open intervals ")#mi("{I(n)}")#text(" for each natural number ")#mi("{n}")#text(", in such a way that the total length ")#tao-math("{\\sum_n \\left|I(n)\\right|}", block: false)#text(" of these intervals is less than ")#mi("{b-a}")#text(", then one can find a point in ")#mi("{[a,b]}")#text(" which is not covered by any of the ")#mi("{I(n)}")#text(".")

#text("This can be done using a countable amount of computational power (basically, the ability to run a single infinite loop; this is roughly equivalent to ")#link("http://en.wikipedia.org/wiki/Reverse_mathematics#The_base_system_RCA0")[#text("the theory ")#mi("{RCA_0}")#text(" in reverse mathematics")]#text("). The point is that for each finite ")#mi("{N}")#text(", the set ")#mi("{S_N := [a,b] \\backslash \\bigcup_{n=1}^N I(n)}")#text(" is a computable non-empty finite union of closed intervals in ")#mi("{[a,b]}")#text(", which decreases in ")#mi("{N}")#text(". The infimum ")#mi("{\\inf(S_N)}")#text(" can be computed infinite time for each ")#mi("{N}")#text(", and increases in ")#mi("{N}")#text("; the limit ")#mi("{\\lim_{N \\rightarrow \\infty} \\inf(S_N)}")#text(" is then an element in ")#mi("{\\bigcap_N S_N}")#text(" that lies in ")#mi("{[a,b]}")#text(" but is outside all of the ")#mi("{I(n)}")#text(". Thus, given a countable amount of computational power, one can consistently define Lebesgue measure of a measurable set, and verify its basic properties.")

#text("It is instructive to apply the above discussion to the non-measurable membership oracle ")#mi("{E()}")#text(" given in previous sections (trivially modified to lie in ")#mi("{[0,1]}")#text(" rather than in ")#mi("{{\\bf R}}")#text("). If one is given a purported measurability oracle ")#mi("{M()}")#text(" for this oracle ")#mi("{E()}")#text(", one can eventually show that this oracle ")#mi("{M()}")#text(" does not actually certify the measurability of ")#mi("{E()}")#text(" as claimed, but this requires a countably infinite amount of computation to establish. (Basically, there are two cases, based on whether ")#mi("{M()}")#text(" asserts that ")#mi("{E()}")#text(" has positive Lebesgue measure or not (which can be decided after a countable amount of computation). If it has positive measure, then by invoking ")#mi("{M(\\epsilon)}")#text(" with ")#mi("{\\epsilon}")#text(" less than half this measure, one can soon find an interval ")#mi("{I}")#text(" in which ")#mi("{E()}")#text(" has density greater than ")#mi("{1/2}")#text(" (or more precisely, the complement of ")#mi("{E}")#text(" in ")#mi("{I}")#text(" has outer measure strictly less than ")#tao-math("{\\left|I\\right|/2}", block: false)#text(") and then one can run a variant of the above Bolzano-Weierstrass argument to find two points ")#mi("{x, y}")#text(" in ")#mi("{E()}")#text(" and in ")#mi("{I}")#text(" which differ by a rational, contradicting the construction of ")#mi("{E}")#text(". If instead ")#mi("{M()}")#text(" asserts that ")#mi("{E()}")#text(" has zero measure, then ")#mi("{M()}")#text(" can cover ")#mi("{E()}")#text(" by intervals of arbitrarily small total measure, and then ")#mi("{M()}")#text(" can do the same for the union of all the rational shifts of ")#mi("{E()}")#text(", and one can then find an element ")#mi("{x \\in [0,1]}")#text(" such that no rational shift ")#mi("{x+q}")#text(" of ")#mi("{x}")#text(" lies in ")#mi("{E}")#text(".)")

#text("On the other hand, if one is only allowed to query ")#mi("{E()}")#text(" and ")#mi("{M()}")#text(" finitely many times, then one can show that one can adaptively build ")#mi("{M()}")#text(" and ")#mi("{E()}")#text(" in response in these queries in such a way that one never obtains a contradiction, while retaining the properties that the shifts of ")#mi("{E()}")#text(" by the rationals partition ")#mi("{{\\bf R}}")#text(". So a pathological liar can build a non-measurable set but claim that it is measurable; the deception can sustain any finite number of queries about the set and its measurability, but given a countable amount of queries one can eventually demonstrate that there is an inconsistency (at least for non-measurable sets coming from the coset partition of ")#mi("{{\\bf R}}")#text(" by the rationals).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Interestingly, the type of adaptive oracles one uses to create non-measurable sets are not compatible with random number generation. If one has access to a source of random real numbers (say in ")#mi("{[0,1]}")#text("), then in principle one can (almost surely) compute the Lebesgue measure in countable time of any subset ")#mi("{E}")#text(" of ")#mi("{[0,1]}")#text(" accessed through a random oracle ")#mi("{E()}")#text(" by the ")#link("http://en.wikipedia.org/wiki/Monte_Carlo_integration")[#text("Monte Carlo method")]#text(": randomly sampling ")#mi("{N}")#text(" points in ")#mi("{[0,1]}")#text(", counting the proportion that lie in ")#mi("{E}")#text(", and then sending ")#mi("{N \\rightarrow \\infty}")#text(". However this only works properly if the oracle ")#mi("{E()}")#text(" does not adapt to the various random inputs it is given, and is instead independent of these inputs. (For instance, if one were to use Monte Carlo methods to measure the non-measurable set ")#mi("{E}")#text(" described above, one would almost surely get that ")#mi("{E}")#text(" has measure ")#mi("{1}")#text(", as each random number is almost certain to lie in a different coset of ")#mi("{{\\bf Q}}")#text("!.)")
]

#heading(level: 1)[#strong[#text(" — 4. The Banach-Tarski paradox — ")]]

#text("We now turn to the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Tarski_paradox")[#text("Banach-Tarski paradox")]#text(". The usual formulation of this paradox involves a partition of the unit ball into pieces that can be rearranged (after rotations and translation) to form two copies of the ball. To avoid some minor technicalities, we will work instead on the unit sphere ")#mi("{S^2}")#text(" with an explicit countable set ")#mi("{\\Sigma}")#text(" removed, and establish the following version of the paradox:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Banach-Tarski paradox, reduced version)")]#text(" ")#metadata(none) <tao-340e570c1e78a3d0ad80>#text(" There exists a countable subset ")#mi("{\\Sigma}")#text(" of ")#mi("{S^2}")#text(" and partition of ")#mi("{S^2 \\backslash \\Sigma}")#text(" into four disjoint pieces ")#mi("{E_1 \\cup E_2 \\cup E_3 \\cup E_4}")#text(", such that ")#mi("{E_1}")#text(" and ")#mi("{E_2}")#text(" can be rotated to cover ")#mi("{S^2 \\backslash \\Sigma}")#text(", and ")#mi("{E_3}")#text(" and ")#mi("{E_4}")#text(" can also be rotated to cover ")#mi("{S^2 \\backslash \\Sigma}")#text(".")
]

#text("Of course, from the rotation-invariant nature of Lebesgue measure on the sphere, such a partition can only occur if at least one of ")#mi("{E_1,E_2,E_3,E_4}")#text(" are not Lebesgue measurable.")

#text("We return briefly to set theory and give the standard proof of this proposition. The first step is to locate two rotations ")#mi("{a, b}")#text(" in the orthogonal group ")#mi("{SO(3)}")#text(" which generate the free group ")#mi("{\\langle a,b\\rangle}")#text(". This can be done explicitly; for instance one can take")

#align(center)[#tao-fit-display[#mitex("a := \\begin{pmatrix} 3/5 & 4/5 & 0 \\\\ -4/5 & 3/5 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}; \\quad b := \\begin{pmatrix} 1 & 0 & 0 \\\\ 0 & 3/5 & -4/5 \\\\ 0 & 4/5 & 3/5 \\end{pmatrix}.")]]

#text("(See for instance ")#link("http://sbseminar.wordpress.com/2007/09/17/that-trick-where-you-embed-the-free-group-into-a-lie-group/")[#text("this post from the Secret Blogging Seminar")]#text(" for more discussion of this example.) Each rotation in ")#mi("{\\langle a,b \\rangle}")#text(" has two fixed antipodal points in ")#mi("{S^2}")#text("; we let ")#mi("{\\Sigma}")#text(" be the union of all these points. Then the group ")#mi("{\\langle a,b \\rangle}")#text(" acts freely on the remainder ")#mi("{S^2 \\backslash \\Sigma}")#text(".")

#text("Using the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(", we can then build a (non-measurable) subset ")#mi("{E}")#text(" of ")#mi("{S^2 \\backslash \\Sigma}")#text(" which consists of a single point from each orbit of ")#mi("{\\langle a,b \\rangle}")#text(". For each ")#mi("{i=1,2,3,4}")#text(", we then define ")#mi("{E_i}")#text(" to be the set of all points of the form ")#mi("{w x}")#text(", where ")#mi("{x \\in E}")#text(" and ")#mi("{w \\in \\langle a,b\\rangle}")#text(" is a word such that")

#list(
[#mi("{w}")#text(" is the identity, or begins with ")#mi("{a}")#text(" (if ")#mi("{i=1}")#text(");")],
[#mi("{w}")#text(" begins with ")#mi("{a^{-1}}")#text(" (if ")#mi("{i=2}")#text(");")],
[#mi("{w}")#text(" begins with ")#mi("{b}")#text(" (if ")#mi("{i=3}")#text(");")],
[#mi("{w}")#text(" begins with ")#mi("{b^{-1}}")#text(" (if ")#mi("{i=4}")#text(").")]
)

#text("It is then clear that ")#mi("{E_1, E_2, E_3, E_4}")#text(" partition ")#mi("{S^2 \\backslash \\Sigma}")#text(", while ")#mi("{a^{-1} E_1 \\cup a E_2}")#text(" and ")#mi("{b^{-1} E_3 \\cup b E_4}")#text(" both cover ")#mi("{S^2 \\backslash \\Sigma}")#text(", as claimed.")

#text("Now let us interpret this example using oracles. The free group ")#mi("{\\langle a, b \\rangle}")#text(" is countably enumerable, and so with a countable amount of time and memory, one can construct and store ")#mi("{\\Sigma}")#text(" without difficulty. A membership oracle ")#mi("{E()}")#text(" for ")#mi("{E}")#text(" can then be constructed by an adaptive oracle much as in the previous sections; ")#mi("{E(x)}")#text(" returns yes if ")#mi("{x}")#text(" is the first point in its orbit that is queried, and returns no otherwise. The oracles ")#mi("{E_i(x)}")#text(" can then be defined by querying ")#mi("{E}")#text(" for all the points in ")#mi("{x}")#text("‘s orbit in some arbitrary order until one finds the point ")#mi("{w^{-1} x}")#text(" which lies in ")#mi("{E}")#text(", and then deciding membership in ")#mi("{E_i(x)}")#text(" depending on the first symbol of ")#mi("{w}")#text(". (For instance, if ")#mi("{x}")#text("‘s orbit has not been queried before, the first point in the orbit that one queries ")#mi("{E()}")#text(" for will lie in ")#mi("{E}")#text("; thus one sees that the order in which one decides to search through the orbit will in fact influence quite strongly what ")#mi("{E}")#text(" and the ")#mi("{E_i}")#text(" will look like.)")

#text("It is then not hard to show that ")#mi("{E_1(), E_2(), E_3(), E_4()}")#text(" do indeed partition ")#mi("{S^2 \\backslash \\Sigma}")#text(" in the sense that for each ")#mi("{x \\in S^2 \\backslash \\Sigma}")#text(", exactly one of ")#mi("{E_1(x), E_2(x), E_3(x), E_4(x)}")#text(" will return “yes”. Also, for any ")#mi("{x \\in S^2 \\backslash \\Sigma}")#text(", at least one of ")#mi("{E_1(ax), E_2(a^{-1} x)}")#text(" will return “yes”, and at least one of ")#mi("{E_3(bx), E_4(b^{-1} x)}")#text(" will return “yes”. Thus, after performing an uncountable number of queries to fully complete all of these sets, we obtain sets obeying the properties in Proposition ")#link(<tao-340e570c1e78a3d0ad80>)[#text("1")]#text("; but the oracles that do this are perfectly deterministic, and run in only a countable amount of time, at least for the first few queries (and one can probably even trim it down to a finite amount of time, if one has an efficient way of deciding whether two points lie in the same orbit of ")#mi("{\\langle a,b\\rangle}")#text(").")

#text("Now we discuss how a Banach-Tarski type construction does not work in one or two dimensions. Let us just consider the one-dimensional case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" There does not exist a decomposition of the unit interval ")#mi("{[0,1)}")#text(" into finitely many sets ")#mi("{E_1,\\ldots,E_k}")#text(" such that some translates ")#mi("{E_1+x_1,\\ldots,E_k+x_k}")#text(" of these sets cover ")#mi("{[0,2)}")#text(".")
]

#text("We briefly review the proof of this proposition. Suppose for contradiction that we have such a decomposition. We can colour the lattice ")#mi("{{\\bf Z}^k}")#text(" in ")#mi("{k}")#text(" colours ")#mi("{1,\\ldots,k}")#text(", by giving each ")#mi("{k}")#text("-tuple ")#mi("{(n_1,\\ldots,n_k)}")#text(" the colour ")#mi("{i}")#text(" if ")#mi("{n_1 x_1 + \\ldots + n_k x_k \\text{ mod } 1 \\in E_i}")#text(". This is clearly a ")#mi("{k}")#text("-colouring of ")#mi("{{\\bf Z}^k}")#text(". Furthermore, for every ")#mi("{k}")#text("-tuple ")#mi("{\\vec n}")#text(", we see that at ")#mi("{\\vec n - e_i}")#text(" has colour ")#mi("{i}")#text(" for at least two values of ")#mi("{i=1,\\ldots,k}")#text(", where ")#mi("{e_1,\\ldots,e_k}")#text(" is the standard basis for ")#mi("{{\\bf Z}^k}")#text(". If one then uses ")#link("http://en.wikipedia.org/wiki/Double_counting_(proof_technique)")[#text("double-counting")]#text(" to get two different estimates for the number of coloured points in a box ")#mi("{\\{1,\\ldots,N\\}^k}")#text(" for a large enough ")#mi("{N}")#text(", one obtains a contradiction.")

#text("Note that this proof is quite finitary; given some real numbers ")#mi("{x_1,\\ldots,x_k}")#text(" and some membership oracles ")#mi("{E_1(),\\ldots,E_k()}")#text(", one could convert the above argument into an algorithm that would be able to demonstrate in finite time that either the oracles ")#mi("{E_1(),\\ldots,E_k()}")#text(" fail to partition ")#mi("{[0,1)}")#text(", or that the translates ")#mi("{E_1()+x_1,\\ldots,E_k()+x_k}")#text(" fail to cover ")#mi("{[0,2)}")#text("; we leave this as an exercise to the reader.")

#text("(The key distinction here between the low and high dimensional cases is that the free group ")#mi("{\\langle a,b \\rangle}")#text(" is not ")#link("http://en.wikipedia.org/wiki/Amenable_group")[#text("amenable")]#text(", whereas ")#mi("{{\\bf Z}^k}")#text(" is amenable. See ")#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/")[#text("these previous")]#text(" ")#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")[#text("blog posts")]#text(" for further discussion.)")

#heading(level: 1)[#strong[#text(" — 5. Summary — ")]]

#text("The above discussion suggests that it is possible to retain much of the essential mathematical content of set theory without the need for explicitly dealing with large sets (such as uncountable sets), but there is a significant price to pay in doing so, namely that one has to deal with sets on a “virtual” or “incomplete” basis, rather than with the “completed infinities” that one is accustomed to in the standard modern framework of mathematics. Conceptually, this marks quite a different approach to mathematical objects, and assertions about such objects; such assertions are not simply true or false, but instead require a certain computational cost to be paid before their truth can be ascertained. This approach makes the mathematical reasoning process look rather strange compared to how it is usually presented, but I believe it is still a worthwhile exercise to try to translate mathematical arguments into this computational framework, as it illustrates how some parts of mathematics are in some sense “more infinitary” than others, in that they require a more infinite amount of computational power in order to model in this fashion. It also illustrates why we adopt the conveniences of infinite set theory in the first place; while it is technically possible to do mathematics without infinite sets, it can be significantly more tedious and painful to do so.")

#strong[#text("Update, Mar 21: Several edits and additions, including a summary.")]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (44)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43947")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2010")])]

#text("Very enlightening! As you say, one way to distinguish Cantor’s theorem from other set-theoretic statements is by just how few of the properties of Set you need to prove it. In fact, a Cantor-like statement makes sense in any ")#link("http://en.wikipedia.org/wiki/Cartesian_closed_category")[#text("Cartesian closed category")]#text(". First, recall that in a category with a terminal object ")#mi("1")#text(", a point of an object ")#mi("A")#text(" is a map ")#mi("1 \\to A")#text(".")

#strong[#text("Theorem (Lawvere and Schanuel, ")#emph[#text("Conceptual Mathematics")]#text(", p. 316):")]#text(" Suppose ")#mi("Y")#text(" is an object in a Cartesian closed category such that there exists an object ")#mi("T")#text(" and a map ")#mi("f : T \\to Y^T")#text(" with the property that for every map ")#mi("g : T \\to Y")#text(" there exists a point ")#mi("t")#text(" of ")#mi("T")#text(" such that ")#mi("ft")#text(" names ")#mi("g")#text(". Then every map ")#mi("T \\to T")#text(" has a fixed point.")

#text("To recover the usual statement of Cantor’s theorem one takes ")#mi("T = 2")#text(" in Set. From this perspective, Cantor’s theorem should be thought of as a statement about typed lambda calculus.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d08234f97311997ba051bcc1e08e7aef9a7eea7f69a2900d33e6e0a9804e23c-fdb632cf7d7d17b8fcd4d48cded88e8274f7bd70015530c870a11be50cf91bde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Cohen")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43955")[#strong[#text("Martin Cohen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2010")])]

#text("Two comments:")

#text("On a somewhat facetious note, in sci.math, Archimedes Plutonium has been describing his reconstruction of mathematics where the maximum integer is 10^500.")

#text("The discussion of n+1 > n reminds me of some work I did in the 1970’s as part of a group at USC’s ISI doing program verification using Pascal. I constructed two versions of routines that implemented the pigeon-hole principle in the form if f maps 0 to n (integer args and results) into 1 to n, then there are two distinct values i and j such that f(i) = f(j). The first version had nested loops on i and j and stopped when f(i) = f(j). The second version, to avoid the O(n^2) time of the first, stored f(0 to i) in an array and stopped when f(i) matched a previous value (the traditional time-space tradeoff). As I recall, I managed to prove the two routines were correct, but it was surprisingly difficult.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43959")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2010")])]

#text("First of all, thanks for yet another great post!")

#text("About finding an element in ")#mi("[a,b]")#text(" not covered by ")#mi("\\cup I_n")#text(", where the lengths of the intervals sums to less that ")#mi("b-a")#text(":")#linebreak()#text(" “This can be done, but it requires a nontrivial amount of computational power – basically the ability to run a double infinite loop (indexed by the ordinal ")#mi("{\\omega^2})")#text(".”")#linebreak()#text(" Why doesn’t the following work: For each n, approximate the smallest element in ")#mi("S_n")#text(" (as defined in the post) with n bits precision. For each n, this can be done in finite time, so after ")#mi("\\omega")#text("-step we have a real number contained in ")#mi("\\bigcap_{n\\in\\mathbb{N}}S_n")#text(".")

#text("Do anyone know some good references about infinite computations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43960")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2010")])]

#text("Hmm, that’s a good point. I was misled by the fact that the Heine-Borel theorem is known to be equivalent (in the reverse-mathematics sense) to the (weak) Konig lemma, which requires omega^2 worth of computational resources to prove; but you are indeed right that one can show that the intersection of nested closed elementary sets is non-empty using only omega worth of computation (reverse mathematics says that this is an RCA_0 result rather than a WKL_0 result). Somehow the point is that a “lim sup” or “lim inf” usually requires two infinite operations (an inf of a sup, or a sup of an inf) but when dealing with elementary sets rather than arbitrary closed sets, the first infinite operation can in fact be done in finite time, saving one power of omega. I’ve rewritten this portion of the post to reflect the simplification.")

#text("I don’t know of good references for the computational point of view, though it is perhaps implicit in the reverse mathematics literature. (But their use of ordinals to measure the strength of a logical system is slightly different from the use here to measure the computational power, though there is clearly a relationship between the two.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43dd7a3a0aa801d74b8a44fdefc6caefe690d220397eb473bb159b6b9da4928e-12c10826ee2b3fe2c268ec35bedb94b1854f4102fda2841c431943fc7764b5b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asdf")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-44070")[#strong[#text("asdf")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2010")])]

#text("Sune, you might look at the papers about “infinite time Turing machines” by Joel David Hamkins. They are Turing machines whose steps are indexed by potentially transfinite ordinals. If I remember correctly they can decide all arithmetic statements and maybe some analytic ones. See: ")#link("http://jdh.hamkins.org/Publications")[#text("http://jdh.hamkins.org/Publications")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43963")[#strong[#text("Top Posts — WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2010")]

#text("[…] A computational perspective on set theory The standard modern foundation of mathematics is constructed using set theory. With these foundations, the […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b13c86a438b923c8fefb838ae8f382aa6d01885ee17814f9e6ba347daf17e9c-a8e18bec4def3d05efcdcf6c517507ddeb1979fc79e35e46d6712a03dd154c5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of guest")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43967")[#strong[#text("guest")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2010")])]

#text("Professor Tao’s “computational” framework may well have some merit from an ultrafinitist point of view, but it otherwise seems fairly involved and counterintuitive. It’s well known that mathematics can be interpreted in a constructivist framework, and that Cantor’s diagonal argument carries through to a proof that the set of computable real numbers is itself uncomputable (See e.g. ")#link("http://math.andrej.com/2008/02/06/representations-of-uncomputable-and-uncountable-sets/")[#text("this post on the Math. and Computation weblog")]#text("). Nevertheless, most constructivist mathematicians use foundations other than Zermelo Fraenkel set theory or its constructive equivalents. (one issue with set theoretical foundations for constructive mathematics is that they treat sets, functions and quotient sets as extensional, whereas extensional equality of such objects may not even be algorithmically decidable.)")

#text("A speculative question is whether constructivist foundations of mathematics can be built which represent computations of bounded computational complexity. The field of ")#link("http://en.wikipedia.org/wiki/descriptive_complexity")[#text("descriptive complexity")]#text(" may be of some help here. Alternately, a well-known isomorphism between algorithms and constructive proofs allows us to use formal systems based on ")#link("http://citeseer.ist.psu.edu/687292.html")[#text("linear logic")]#text(" to encode algorithms with polynomial-time complexity; other systems exists which can encode different complexity classes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cec932675f1d585fea64745949521214f2fc18ffe25416b50c7fbb960847404f-9e9aed81972834f15c8ea1f31985032deee99fcaa6a44d8a65436e93e6c8ec04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of András Salamon")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43995")[#strong[#text("András Salamon")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2010")])]

#text("Bounded computational resources have so far been used for specific applications, such as game theory. I like your vision of applying this perspective to the foundations of mathematics. Starting with bounded computation seems quite distinct from constructivism.")

#text("In your comments on Cantor’s Theorem, did you perhaps mean to use the ")#mi("i")#text("-th digit of ")#mi("f(i)")#text("?")

#text("Also, are you sure that in an oracle set theory, the difference between ")#mi("0.999\\ldots")#text(" and 1 is necessarily irrelevant? Identifying the equivalent strings seems to require access to the global overview that oracle set theory can’t take for granted.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-44003")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2010")])]

#text("Thanks for the correction!")

#text("If one assumes that one is able to apply the comparison operators <, > to real numbers in finite time, then one can extract out each digit of a real number in finite time (or, in the case that there are two different representations, both possible digits can be extracted).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e748c18a233db12bef5f120de898159dfe1cf409635ca788059f1b3666901331-9f587257f12360c36fb689ae37f7466e78cfb30b8d8d551673ffeba33cbd69dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tibor Földes")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43997")[#strong[#text("Tibor Földes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2010")])]

#text("For a reliable framework in this directions see:")

#text("Alexander Stepanov and Paul McJones (2009).")#linebreak()#text(" Elements of Programming. Addison-Wesley. ISBN 978-0-321-63537-2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/519811cf3a10e10eaaa9a42c7ae007c75abbb6dc53fadeeb221ef1db9e90eddd-0d42d042726092d711dfd93969603b236fc09dd87818bb167a482f77ab7e65c8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of András Salamon")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43998")[#strong[#text("András Salamon")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2010")])]

#text("I don’t understand how this relates to Terry’s post? There is a single reference to the concept “set” in the index of the book. Chapter 2 appears to be exactly what I would expect in a programming language text with some of the links to algebra made slightly more explicit than is usual. What am I missing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e748c18a233db12bef5f120de898159dfe1cf409635ca788059f1b3666901331-9f587257f12360c36fb689ae37f7466e78cfb30b8d8d551673ffeba33cbd69dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tibor Földes")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-43999")[#strong[#text("Tibor Földes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2010")])]

#text("IMHO this is not a programming language text with some references to algebra but it is algebra . This is a demonstration of the possibility of a pure algorithmic build up of algebra. Its Templates and Concepts ( like Terry’s algorithms and oracles) make algebraic structures programmable without too much concerns about the infiniteness of the domain on they work. This is maybe an example how could be realized a net of such adapting and non-adapting oracles.")#linebreak()#text(" Its ground idea is a net of Concepts with minimal dependencies among each other and with the Domain on they are applicable.")

#text("It is worthy to skim through the book.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-44000")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2010")])]

#text("“At one extreme, one can enforce a “strict finitist” viewpoint where the total computational resources available (time and memory) are bounded by some numerical constant, such as 10^100; roughly speaking, this causes any mathematical construction to break down once its complexity exceeds this number”.")

#text("I think frequently about how to obtain such a constant in a natural way so that computational complexity which is now a purely formal tool transforms into a tool which can be applied to natural sciences. I think about a ressource measure so that no matter how much additional ressource your natural system has beyond this it would not achieve much more. For instance the number of units packed in the most compact physical way that can broadcast a message in a given time (i.e. a milisecond second). If your genes in the cell takes more than this time to comunicate and react, you can not survive in any environment. If the cells in your brain takes more than this time, you can not perceive.")

#text("With such a natural constant, the P versus NP question for scientific problems will not be relevant, since nobody will worry about asymptotics (Big O) nor if the algorithm is polynomial or exponential. Just substitute the n by the constant and see which one is faster. I´ve always considered weird and unsatisfactory in computational complexity the fact that you can always increase the value of the degree of the polynomial. It would be nice if we could bound it in any natural way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-44015")[#strong[#text("The definition of a function « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2010")]

#text("[…] this way, and it won’t always be done this way. For example, consider Terence Tao’s recent blog post where he replaces sets and functions with oracles and algorithms. There’s no reason to expect […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df7fa6a76a5c91fac28dee298c4e5719db787724fb58d8a8471b063a3ec32b90-9a1ce6f403fa5b5de72039cd76de8507a617724e83fe2b4abd1cc9676b94e27f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cosmonut")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-44195")[#strong[#text("Cosmonut")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2010")])]

#text("The above discussion suggests that it is possible to retain much of the essential mathematical content of set theory without the need for explicitly dealing with large sets (such as uncountable sets), but there is a significant price to pay in doing so, namely that one has to deal with sets on a “virtual” or “incomplete” basis, rather than with the “completed infinities” that one is accustomed to in the standard modern framework of mathematics")#linebreak()#text(" ………………………………")

#text("This reminds me of the ancient Greek idea of ‘potential infinities’ versus ‘actual infinities’.")

#text("Great post !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Is there a countable certificate for connectedness? « What’s new")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-44196")[#strong[#text("Is there a countable certificate for connectedness? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2010")])]

#text("[…] somehow be “verified in countable time” in a suitable oracle model, as discussed in my previous post, though I have not tried to make this vague specification more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3bb15eb20684436186c7b6e2e018bc2ab71393dff7ba4fbeb494f0ffe43306c2-7d0f6025d2293137cb5eca8f20396495cf04e53bc828cbd7cbd9bfbe63b6f4cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chad Groft")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-44234")[#strong[#text("Chad Groft")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2010")])]

#text("This article reminds me a bit of the way Paul Cohen described forcing, in some of his last lectures. Consider that a theory ")#emph[#text("T")]#text(" is consistent (in the normal logical sense) iff there is a consistent oracle ")#emph[#text("E")]#text(" (consistent in the article’s sense) which responds “yes” or “no” to inputs, and")

#text("* always responds “yes” to sentences in ")#emph[#text("T")]#text(";")#linebreak()#text(" * follows the rules of logic, ")#emph[#text("e.g.")]#text(", if _E_ has already said “yes” to φ and ψ then it must say “yes” to φ ∧ ψ, and ")#emph[#text("vice versa")]#text("; and in particular")#linebreak()#text(" * always responds “no” to contradictions.")

#text("Cohen’s idea essentially was that ")#emph[#text("E")]#text(" could be adaptive.")

#text("Let’s say you want to pretend that there is a set ")#emph[#text("G")]#text(" of natural numbers which is not constructable. If somebody asks the oracle “Is 5 ∈ ")#emph[#text("G")]#text("?”, then ")#emph[#text("E")]#text(" must come up with (and remember) the answer. After finitely many such queries, ")#emph[#text("E")]#text(" remembers a finite amount of information.")

#text("There are more complicated queries, such as “Is ")#emph[#text("G")]#text(" = ")#emph[#text("X")]#text("?” (where ")#emph[#text("X")]#text(" is some actual set), or “Is the complement of ")#emph[#text("G")]#text(" finite?”, or “Is the smallest element of ")#emph[#text("G")]#text(" prime?”. The oracle ")#emph[#text("E")]#text(" can handle these by looking “ahead” to larger amounts of information, determining how simpler queries would be answered, and answering the complex query “now” in a way which creates the least amount of trouble. The first two queries above would be answered “no” with no extra memorization, the first because it determines every element of ")#emph[#text("G")]#text(", the second because it fixes a cofinite (if indeterminate) amount of information. For the third, ")#emph[#text("E")]#text(" would first fix enough information that it could tell what the smallest element ")#emph[#text("n")]#text(" of ")#emph[#text("G")]#text(" is, then answer truthfully whether ")#emph[#text("n")]#text(" is prime or not.")

#text("When this is done correctly, considering all the sets which can be named with ")#emph[#text("G")]#text(" and actual sets as parameters and how they would relate, and carefully defining how queries should be decomposed as smaller queries, it happens that ")#emph[#text("E")]#text(" is a consistent oracle which always says “yes” to sentences in ZFC + “there is a nonconstructible subset of ω”.")

#text("More complicated math, usually involving the combinatorics of partial orders, is required for other results, but this is the basic idea. I wish I knew of a good written source for this perspective; most introductions to forcing, even Cohen’s own works, talk about countable transitive models instead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/340b02c273c5b762ff2704091fce6f317819b3440b136110b95ea352717e322c-46821a9b29edbf3b5aa0be1b839f1a6b362cca6dae8eb473253ecab327ad0209.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rgrig")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-48180")[#strong[#text("rgrig")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2010")])]

#text("In Section 2, there is a bug in the algorithm that generates all finitely constructible reals.")

#text("I’m repeating here how I understood the problem, because it might be my misunderstanding rather than a bug. We are given procedures ")#mi("P_0")#text(", ")#mi("P_1")#text(", ")#mi("P_2")#text(", ")#mi("\\ldots\\,")#text(". Some of them output a real in finite time, others keep running. The task is to find an algorithm ")#mi("f")#text(", such that if ")#mi("x")#text(" is the output of some ")#mi("P_k")#text(", then ")#mi("f(n)=x")#text(" for some ")#mi("n")#text(".")

#text("Now assume that ")#mi("P_m")#text(" and ")#mi("P_n")#text(" with ")#mi("m<n")#text(" run in ")#mi("n+1")#text(" time steps. The output of ")#mi("P_m")#text(" is skipped.")

#text("The simplest algorithm I could thing of works as follows. Enumerate the points ")#mi("(x,y)")#text(" with non-negative coordinates. If ")#mi("P_x")#text(" takes ")#emph[#text("exactly")]#text(" ")#mi("y")#text(" steps then output its result, otherwise output ")#mi("0")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470292")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2016")])]

#text("An infinite number of non-trivial zeros of the Riemann zeta function is a countable set. They all lie in the open interval (0,1). Can you give more information about these non-trivial zeros than Cantor diagonal method?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470307")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#text("Can you say something significant about the structure of ")#mi("(0,1)\\setminus \\mathbb{N}")#text("? It would be nice if we could prove the existence of a closed interval.")#mi("[z,z+j]: z>0, j>0")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470320")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#text("Could you tell me where the error? Thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470310")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#text("I’m not exactly sure. I think that the Cantor method converts two-dimensional Euclidean space ")#mi("\\Omega ^{2}")#text(" in a one-dimensional ")#mi("\\Omega ^{1}")#text(".Again I am assuming that the open interval ")#mi("(0,1)")#text(" may be represented as a Euclidean space ")#mi("\\Omega ^{\\infty }")#text(".Consider the Euclidean space of the third dimension ")#mi("\\Omega ^{3}")#text(" for example. Now we use the method of Cantor. Instead of lines ")#mi("\\Omega ^{1}")#text(", we will hold the plane ")#mi("\\Omega ^{2}")#text(".We have transformed the three-dimensional space into a two-dimensional (using an advanced method of Cantor). In fact, we unpacked the three-dimensional space. Now apply the inversion. That is, we will continue to pack up to infinity, but it will be impossible to unpack. To unpack the need to limit any dimension (")#mi("\\Omega ^{A}")#text(" – where A is a constant) or a finite number of points in each dimension. Since we have a limited ")#mi("\\Omega ^{\\infty }")#text(", we have ")#mi("[z,z+j]: z>0,j>0")#text(".")

#text("P.S. I do not know how best to explain. It uses an enhanced version of Cantor’s method for the n-dimensional Euclidean space. But this method is used only in the reverse direction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470321")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#text("Instead of the Euclidean space, I mean a countable infinite set. Excuse me. I cannot express their thoughts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470322")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#text("Again I missed. Here I mean that there is an infinite countable space is n-dimensional. If we let n tend to infinity, then it will be infinitely uncountable. But most importantly, that the latter can be viewed as an open interval (0,1).Probably all.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470763")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("Good day! From ")#link("https://www.quora.com/It-is-said-that-infinitely-many-zeroes-of-the-Riemann-zeta-function-lie-on-the-critical-line-What-sort-of-infinity-is-it")[#text("https://www.quora.com/It-is-said-that-infinitely-many-zeroes-of-the-Riemann-zeta-function-lie-on-the-critical-line-What-sort-of-infinity-is-it")]#text(" or ")#link("http://math.stackexchange.com/questions/1491324/are-the-nontrivial-zeroes-of-the-riemann-zeta-function-countable")[#text("http://math.stackexchange.com/questions/1491324/are-the-nontrivial-zeroes-of-the-riemann-zeta-function-countable")]#text(", you can see that an infinite number of non-trivial zeros of the Riemann zeta function is countable. ")#tao-math("\\left|Z\\right|=\\left|\\mathbb{N}\\right|", block: false)#text(". The elements of the set ")#mi("Z")#text(" may be ")#mi("3/4+i\\gamma_{n}")#text(", ")#mi("43/100+i\\gamma_{n}")#text(" and so forth. Whether it is a subset of ")#mi("D\\subseteq (0,1)")#text(" (3/4, 43/100 and so on) dense in ")#mi("(0,1)")#text("? Yes, if ")#mi("D")#text(" is the set of rational numbers in the interval ")#mi("(0,1)")#text(". Let ")#mi("N_{0}(t)")#text(" the number of non-trivial zeros of the Riemann zeta function at 1/2. Suppose ")#mi("N_{0}(t)\\sim N(t)")#text(", where ")#mi("N(t)")#text(" nontrivial zeros in the interval ")#mi("(0,1)")#text(". Does it follow from this asymptotic equality that ")#mi("D")#text(" is nowhere dense set in ")#mi("(0,1)")#text("? As I hope implying zero border ")#mi("1-C")#text(" (C – constant).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470771")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("As I think “Natural density 0” (")#link("https://en.wikipedia.org/wiki/Natural_density")[#text("https://en.wikipedia.org/wiki/Natural_density")]#text(") implies “Nowhere dense set” (")#link("https://en.wikipedia.org/wiki/Nowhere_dense_set")[#text("https://en.wikipedia.org/wiki/Nowhere_dense_set")]#text("). But I’m not sure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470985")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2016")])]

#text("From ")#tao-math("\\left|Z\\right|=\\left|\\mathbb{N}\\right|", block: false)#text(" we have:")#linebreak()#text(" ")#mi("a_{n}+i\\gamma _{z}")#linebreak()#text(" ")#mi("\\displaystyle A=\\left \\{ a_{n} \\right \\}_{n=1}^{\\infty };n\\in \\mathbb{N}")#linebreak()#text(" ")#mi("A")#text(" – countable infinity set")#linebreak()#text(" If the following conditions are satisfied:")#linebreak()#text(" ")#tao-math("\\displaystyle \\lim_{n\\rightarrow \\infty }\\frac{\\left|A(n)\\right|}{\\left|B(n)\\right|}<\\infty", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\lim_{n\\rightarrow \\infty }\\left|A(n)\\right|-\\left|B(n)\\right|=C", block: false)#linebreak()#text(" ")#mi("\\displaystyle C=\\left \\{ b_{d} \\right \\}_{d}^{\\infty }")#linebreak()#text(" For \"natural density 0\" I now know that this implies \"nowhere dense set\".")#linebreak()#text(" ")#mi("\\displaystyle C=\\left \\{ b_{d} \\right \\}_{d}^{\\infty }")#text(" – nowhere dense set in ")#mi("A")#text(" and ")#mi("(0,1)")#text("?")

#text("Now I see what I missed. You can set ")#mi("A")#text(" represented as ")#mi("\\left \\{ a_{1} < a_{2} < ... < a_{n} \\right \\}")#text("?")

#text("P.S. Thank you :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470996")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2016")])]

#text("We must take ")#tao-math("\\displaystyle \\lim_{n\\rightarrow \\infty }\\frac{\\left|A(n)\\right|}{\\left|B(n)\\right|}=1;\\left|A(n)\\right|=N(n);\\left|B(n)\\right|=N_{0}(n)", block: false)#text(" instead.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-470998")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2016")])]

#text("Also: ")#mi("A\\cap (0,1)")#linebreak()#text(" As I think you can take a cantor method for rational numbers in ")#mi("(0,1)")#text(", then sort them in ascending at each step, and so on to infinity. Then the set ")#mi("A")#text(" will be ")#mi("\\left \\{ a_{1}<a_{2}<...<a_{n} \\right \\}")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471008")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2016")])]

#text("It turns out that the question is not as easy as I thought. (Can I sorting countably infinite set?) If there is a positive answer to this question then all converge.At the moment, all that I found on this subject ")#link("https://www.irif.univ-paris-diderot.fr/~carton/Publications/Linear/Kleene/Scattered/jcss.pdf")[#text("https://www.irif.univ-paris-diderot.fr/~carton/Publications/Linear/Kleene/Scattered/jcss.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471019")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2016")])]

#link("http://mathoverflow.net/questions/143454/sorting-of-countabe-set")[#text("http://mathoverflow.net/questions/143454/sorting-of-countabe-set")]#linebreak()#text(" Look at the last comment Joel David Hawkins. I think it makes sense.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471056")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2016")])]

#mi("A")#text(" – any dense set in ")#mi("(0,1)")#text("; ")#mi("A\\cap (0,1)")#linebreak()#text(" Unfortunately only if we apply the axiom of choice can be said ")#mi("A")#text("-is well-ordered.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471087")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")])]

#mi("\\mathbb{M}")#text(" – any countable, dense set in (0,1). ")#mi("(0,1)\\cap \\mathbb{R}")#linebreak()#text(" ")#mi("\\mathbb{M}\\sim \\mathbb{P}")#text(" – (not sure how to write, but by intuition as the asymptotic behavior)")#linebreak()#text(" ")#mi("\\mathbb{M}\\setminus \\mathbb{P}=\\mathbb{L}")#text(", where ")#mi("\\mathbb{P}")#text(" – subset of ")#mi("\\mathbb{M}")#text("; ")#mi("\\mathbb{L}")#text(" – infinite set consist of as much as possible elements but with save condition ")#mi("\\mathbb{M}\\sim \\mathbb{P}")#text(".")#linebreak()#text(" Applying the axiom of choice ")#mi("\\mathbb{M}")#text(" set is well-ordered; we can imagine ")#mi("\\mathbb{M}")#text(" as ")#mi("\\left \\{ a_{0}<a_{1}<a_{2}<... \\right \\}")#text(".")#linebreak()#text(" After ")#mi("\\mathbb{L}\\cap (0,1)")#text(". Is there open interval ")#mi("(a,1)")#text(", ")#mi("a<1")#text("?")#linebreak()#text(" At the moment, I have no proof, but there is an approach that I hope will lead to it:")

#text("Consider ")#mi("\\mathbb{M}\\setminus \\mathbb{P}=\\mathbb{G}")#text(", where ")#mi("\\mathbb{G}")#text(" – finite set. It is easy to see that from it follows existence open interval ")#mi("(a,1)")#text(". I believe communication ")#mi("\\sim")#text(" at the end (limit to infinity) for the sets ")#mi("\\mathbb{G}")#text(" and ")#mi("\\mathbb{L}")#text(" is the same.")#linebreak()#text(" That is, for ")#mi("\\mathbb{L}")#text(" also exists an open interval ")#mi("(a,1)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471094")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")])]

#text("I just want to write where it leads. This method can be applied to a large class of holomorphic functions, not only for ")#mi("\\zeta (s)")#text(". For example for ")#mi("\\zeta (s)")#text(": if we know that the number of non-trivial zeros ")#mi("N(T)=\\frac{T}{2\\pi }log\\frac{T}{2\\pi }+o(\\frac{T}{2\\pi }log\\frac{T}{2\\pi })")#text(" lies on ")#mi("\\frac{1}{2}")#text(". We can say that there are no zeros on ")#mi("1-C")#text(",where C-constant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471095")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")])]

#text("Of course if the set of non-trivial zeros of the Riemann zeta function ")#mi("Z")#text(" is countable infinite set. ")#tao-math("\\left|Z\\right|=\\left|\\mathbb{N}\\right|", block: false)
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471098")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2016")])]

#text("I’m not exactly sure. If we consider the asymptotic behavior, as the probability of occurrence of an element ")#mi("a")#text(" at every step. Sending to infinity, the probability is zero. Here is an example from the natural numbers, what I mean: ")#mi("\\lim_{n\\rightarrow \\infty }\\frac{C}{n}=0")#text(" At each step, ")#mi("n")#text(" the probability of occurrence of the element is reduced. ")#mi("\\lim_{n\\rightarrow \\infty }\\frac{f(n)}{n} =0")#text(" Here the probability is also reduced, but at a different speed. But at the end for this two expressions we have a ")#mi("0")#text(".")#linebreak()#text(" I do not know how to rewrite in mathematical language. But it could prove the open interval ")#mi("(a,1)")#text(" exist for ")#mi("\\mathbb{L}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471243")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2016")])]

#text("Instead of the axiom of choice you can use Axiom of determinacy ")#link("https://en.wikipedia.org/wiki/Axiom_of_determinacy")[#text("https://en.wikipedia.org/wiki/Axiom_of_determinacy")]#text(". This means that we can be well ordered countable infinite set, but an uncountable set can not, for example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471246")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2016")])]

#text("Now I am considering Axiom of countable choice ")#link("https://en.wikipedia.org/wiki/Axiom_of_countable_choice")[#text("https://en.wikipedia.org/wiki/Axiom_of_countable_choice")]#text(" as a substitute Axiom of determinacy. Because the half-closed interval ")#mi("[1/2,1)")#text(", taking any countable infinite set ")#mi("\\mathbb{G} \\cap [1/2,1)")#text(" in this interval, it ")#mi("\\mathbb{G}")#text(" must contain an accumulation point ")#mi("1/2")#text(". But i don’t know.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471322")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2016")])]

#text("Question came with the axiom of choice. What is the “existence”? I called this “quantum existence”.I do not know how well I can explain, but I’ll try.I believe that this condition has long been used in mathematics. For example point have quantum existence. Of course I believe that the axiom of choice have quantum existence, but not yet fully. Take a countable infinite set ")#mi("\\mathbb{A}=(1,2)\\cap \\mathbb{Q}")#text(",")#mi("\\mathbb{A}=\\left \\{ a_{n} \\right \\}_{n=0}^{\\infty }, n\\in  \\mathbb{N}")#text(". Take one element from this set ")#mi("a_{i}")#text(", we do not know where he is. Let the probability of occurrence of this element tends to zero. ")#tao-math("\\lim_{n \\to \\infty }\\frac{\\left|a_{i}\\right|}{n}=0", block: false)#text(",")#linebreak()#text(" it follows that there is an interval ")#mi("2-C")#text(", where (C-constant).But if we try to define this constant we have nothing.This is the essence of quantum existence.That is, we want it to be determined by a Turing machine.But the existence of this interval is of the nature of quantum Turing machine.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471395")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2016")])]

#text("I do not know whether this is true. If we construct any Turing machine with the help of classical mechanics.And try to determine the point size for example.As I think we have nothing.Based on Bell’s theorem (")#link("https://en.wikipedia.org/wiki/Bell%27s_theorem")[#text("https://en.wikipedia.org/wiki/Bell%27s_theorem")]#text("), we can assume that the definition of the size of the point lies in the quantum mechanics.That’s why I call it a “quantum existence”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-471525")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2016")])]

#text("This does not apply to the problem.But I believe that the future of mathematics is a quantum mathematics.When we think intuitively we use Turing machine built with the help of classical or quantum mechanics.But somehow, we project it on a Turing machine built with the help of classical mechanics.I think if we start on the project and the Turing machine built with the help of quantum mechanics, most of the paradoxes disappear, and perhaps all.I think so and appear paradoxes.The main question that there is, in my opinion, how can it be proved by logic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72789d03a67fbeab81ef3d17c0c0745c84a6e801efb0957f79431ed2aad8ce39-a74f271550fdfa5bed81dd507db77663cbf69c670e907b5517af6ae425b0fafd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dr anil pedgaonkar")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-486801")[#strong[#text("dr anil pedgaonkar")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2017")])]

#text("extremely fine sir. in set theory one uses replacement and separation axiom schema . these depend on propositions . how about a different path. axiom cartesian product of two sets exist. one can of course define orderred pair previously by axioms.then one can define mapping.given two sets A and B and a mapping h from cartesian product to {0, 1), there exists a subset of A such that h(x, y) =1 when x in A. we avoid the notoon of properry proposition which ae external. ys we can assert existence of (0, 1) by an axiom")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97acb246754ffed91a38e0e8d32d9fa81e63b4673939476dcc1ee74e392385f7-8159b69823afbbe26e8629ca6e205de195ddb2cf25f9f4eefbce48439f9fd608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Hertzlinger")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-518006")[#strong[#text("Joseph Hertzlinger")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2019")])]

#text("One reason the Monte Carlo method would not always give an estimate of Lebesgue measure is that not every sequence of 0s and 1s has an asymptotic density of 1s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea390ed643e08540d9b03d9c49d6d1edb8ae5890984a5ecfd07f44d26d19012f-222ead67d85d84e8afd594d857927780b6d79a2f537d71a65761b1ee5b334b78.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jormakilpi")]], [#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/#comment-697711")[#strong[#text("jormakilpi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Consider the set of all possible partitions of a finite set ")#mi("\\Omega_n")#text(" with ")#mi("n")#text(" elements ")#mi("x_1,\\ldots,x_n")#text(". If I want to write a non-adaptive ‘valid partition’ membership oracle for any partition ")#mi("A_1,\\ldots, A_k")#text(", then I would need non-adaptive membership oracles for all subsets ")#mi("A\\subset\\Omega_n")#text(", since I do not know beforehand which ")#mi("k")#text(" subsets will be in the partition. Thus, I would need ")#mi("2^n")#text(" non-adaptive membership ")#mi("x\\in A(?)")#text(" oracles, one for each ")#mi("A\\subset\\Omega_n")#text(", in order to have a non-adaptive ‘valid partition’ membership oracle? What happens (asymptotically) if I use adaptive membership queries? I am just curious, no need to answer.")
]
