// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T16:36:46.623892+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Continued fractions, Bohr sets, and the Littlewood conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Continued fractions, Bohr sets, and the Littlewood conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 January 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/")[#text("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{\\alpha \\in {\\bf R}/{\\bf Z}}")#text(" be an element of the unit circle, let ")#mi("{N \\geq 1}")#text(", and let ")#mi("{\\rho > 0}")#text(". We define the (rank one) ")#emph[#text("Bohr set")]#text(" ")#mi("{B_N(\\alpha;\\rho)}")#text(" to be the set")

#align(center)[#tao-fit-display[#tao-math("B_N(\\alpha;\\rho) := \\{ n \\in {\\bf Z}: -N \\leq n \\leq N; \\left\\|n\\alpha\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\rho \\}", block: true)]]

#text("where ")#tao-math("{\\left\\|x\\right\\|_{{\\bf R}/{\\bf Z}}}", block: false)#text(" is the distance to the origin in the unit circle (or equivalently, the distance to the nearest integer, after lifting up to ")#mi("{{\\bf R}}")#text("). These sets play an important role in additive combinatorics and in additive number theory. For instance, they arise naturally when applying the circle method, because Bohr sets describe the oscillation of exponential phases such as ")#mi("{n \\mapsto e^{2\\pi i n \\alpha}}")#text(".")

#text("Observe that Bohr sets enjoy the doubling property")

#align(center)[#tao-fit-display[#mitex("B_N(\\alpha;\\rho) + B_N(\\alpha;\\rho) \\subset B_{2N}(\\alpha;2\\rho),")]]

#text("thus doubling the Bohr set doubles both the length parameter ")#mi("{N}")#text(" and the radius parameter ")#mi("{\\rho}")#text(". As such, these Bohr sets resemble two-dimensional balls (or boxes). Indeed, one can view ")#mi("{B_N(\\alpha;\\rho)}")#text(" as the preimage of the two-dimensional box ")#mi("{[-1,1] \\times [-\\rho,\\rho] \\subset {\\bf R} \\times {\\bf R}/{\\bf Z}}")#text(" under the homomorphism ")#mi("{n \\mapsto (n/N, \\alpha n \\text{ mod } 1)}")#text(".")

#text("Another class of finite set with two-dimensional behaviour is the class of (rank two) ")#emph[#text("generalised arithmetic progressions")]

#align(center)[#tao-fit-display[#tao-math("P( a_1,a_2; N_1,N_2 ) := \\{ n_1 a_1 + n_2 a_2: n_1,n_2 \\in {\\bf Z}; \\left|n_1\\right| \\leq N_1, \\left|n_2\\right| \\leq N_2 \\}", block: true)]]

#text("with ")#mi("{a_1,a_2 \\in {\\bf Z}}")#text(" and ")#mi("{N_1,N_2 > 0}")#text(" Indeed, we have")

#align(center)[#tao-fit-display[#mitex("P( a_1,a_2; N_1,N_2 ) + P( a_1,a_2; N_1,N_2 ) \\subset P( a_1,a_2; 2N_1, 2N_2 )")]]

#text("and so we see, as with the Bohr set, that doubling the generalised arithmetic progressions doubles the two defining parameters of that progression.")

#text("More generally, there is an analogy between rank ")#mi("{r}")#text(" Bohr sets")

#tao-aligned(keep: true)[


#tao-math("B_N(\\alpha_1,\\ldots,\\alpha_r; \\rho_1,\\ldots,\\rho_r)  & := \\{ n \\in {\\bf Z}: -N \\leq n \\leq N; \\left\\|n\\alpha_i\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\rho_i", block: true)



#tao-math("\\text{ for all } 1  & \\leq i \\leq r \\}", block: true)
]

#text("and the rank ")#mi("{r+1}")#text(" generalised arithmetic progressions")

#tao-aligned(keep: true)[


#tao-math("P( a_1,\\ldots,a_{r+1}; N_1,\\ldots,N_{r+1} )  & := \\{ n_1 a_1 + \\ldots + n_{r+1} a_{r+1}:", block: true)



#tao-math("n_1,\\ldots,n_{r+1}  & \\in {\\bf Z}; \\left|n_i\\right| \\leq N_i \\text{ for all } 1 \\leq i \\leq r+1 \\}.", block: true)
]

#text("One of the aims of additive combinatorics is to formalise analogies such as the one given above. By using some arguments from the geometry of numbers, for instance, one can show that for any rank ")#mi("{r}")#text(" Bohr set ")#mi("{B_N(\\alpha_1,\\ldots,\\alpha_r;\\rho_1,\\ldots,\\rho_r)}")#text(", there is a rank ")#mi("{r+1}")#text(" generalised arithmetic progression ")#mi("{P(a_1,\\ldots,a_{r+1}; N_1,\\ldots,N_{r+1})}")#text(" for which one has the containments")

#tao-aligned(keep: true)[


#tao-math("B_N(\\alpha_1,\\ldots,\\alpha_r;\\epsilon \\rho_1,\\ldots,\\epsilon \\rho_r)  & \\subset P(a_1,\\ldots,a_{r+1}; N_1,\\ldots,N_{r+1})", block: true)



#tao-math(" & \\subset B_N(\\alpha_1,\\ldots,\\alpha_r;\\rho_1,\\ldots,\\rho_r)", block: true)
]

#text("for some explicit ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{r}")#text(" (in fact one can take ")#mi("{\\epsilon = (r+1)^{-2(r+1)}}")#text("); this is (a slight modification of) Lemma 4.22 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2289012")[#text("my book with Van Vu")]#text(".")

#text("In the special case when ")#mi("{r=1}")#text(", one can make a significantly more detailed description of the link between rank one Bohr sets and rank two generalised arithmetic progressions, by using the classical theory of ")#link("http://en.wikipedia.org/wiki/Continued_fraction")[#text("continued fractions")]#text(", which among other things gives a fairly precise formula for the generators ")#mi("{a_1,a_2}")#text(" and lengths ")#mi("{N_1,N_2}")#text(" of the generalised arithmetic progression associated to a rank one Bohr set ")#mi("{B_N(\\alpha;\\rho)}")#text(". While this connection is already implicit in the continued fraction literature (for instance, in the classic text of ")#link("http://www.ams.org/mathscinet-getitem?mr=2445243")[#text("Hardy and Wright")]#text("), I thought it would be a good exercise to work it out explicitly and write it up, which I will do below the fold.")

#text("It is unfortunate that the theory of continued fractions is restricted to the rank one setting (it relies very heavily on the total ordering of one-dimensional sets such as ")#mi("{{\\bf Z}}")#text(" or ")#mi("{{\\bf R}}")#text("). A higher rank version of the theory could potentially help with questions such as the ")#link("http://en.wikipedia.org/wiki/Littlewood_conjecture")[#text("Littlewood conjecture")]#text(", which remains open despite a substantial amount of effort and partial progress on the problem. At the end of this post I discuss how one can use the rank one theory to rephrase the Littlewood conjecture as a conjecture about a doubly indexed family of rank four progressions, which can be used to heuristically justify why this conjecture should be true, but does not otherwise seem to shed much light on the problem.")

#metadata(none) <tao-22de2aa188181786a0a4>

#heading(level: 1)[#strong[#text(" — 1. Continued fractions — ")]]

#text("One can present the theory of continued fractions in a number of ways. The classical approach is simply to work out the algebraic identities relating the various partial fractions of the continued fraction expansion. A more modern approach is to rewrite everything in terms of the action of the special linear group ")#mi("{SL_2({\\bf Z})}")#text(", either on the Euclidean plane ")#mi("{{\\bf R}^2}")#text(", the projective line ")#mi("{{\\bf RP}^1}")#text(", or the hyperbolic plane ")#mi("{{\\bf H}^2}")#text(". Here, I will split the difference and adopt a geometric perspective, interpreting continued fractions in terms of the geometry of a ray and a lattice in a plane; thus the continued fraction itself will not be the fundamental object of study, but only emerge as a derived quantity from the underlying geometry.")

#text("More specifically, we consider the lattice ")#mi("{{\\bf Z}^2}")#text(" in ")#mi("{{\\bf R}^2}")#text(". We have the standard basis ")#mi("{e_1 := (1,0), e_2 := (0,1)}")#text(" for this lattice. More generally, any two lattice elements ")#mi("{v_1 = (p_1,q_1), v_2 = (p_2,q_2)}")#text(" with ")#mi("{v_1 \\wedge v_2 := p_1 q_2 - p_2 q_1}")#text(" equal to ")#mi("{1}")#text(" forms an (oriented) basis, thanks to Cramer’s rule. (One can of course identify the pair ")#mi("{(v_1,v_2)}")#text(" with an element of ")#mi("{SL_2({\\bf Z})}")#text(", and indeed this would be an appropriate and modern way of thinking about these pairs; but for some mostly idiosyncratic reasons I will eschew this sort of language in this presentation.)")

#text("Given a basis ")#mi("{(v_1,v_2)}")#text(" for ")#mi("{{\\bf Z}^2}")#text(", we can define the associated cone ")#mi("{C(v_1,v_2) := \\{ t_1 v_1 + t_2 v_2: t_1,t_2 \\geq 0 \\}}")#text(". Note that if ")#mi("{(v_1,v_2)}")#text(" is a basis, then so are ")#mi("{(v_1+v_2,v_2)}")#text(" and ")#mi("{(v_1,v_1+v_2)}")#text("; we will call these pairs the ")#emph[#text("upward shift")]#text(" and ")#emph[#text("rightward shift")]#text(" of ")#mi("{(v_1,v_2)}")#text(" respectively. Furthermore, the cones of the two shifted bases essentially partition the cone of the original basis. More precisely, we have")

#align(center)[#tao-fit-display[#mitex("C(v_1,v_2) = C(v_1+v_2,v_2) \\cup C(v_1,v_1+v_2)")]]

#text("and ")#mi("{C(v_1+v_2,v_2) \\cap C(v_1,v_1+v_2)}")#text(" consists of a single ray with rational slope.")

#text("Now let ")#mi("{\\alpha}")#text(" be a positive real number, which we will take to be irrational to avoid some minor notational issues involving termination of the continued fraction process. The ray ")#mi("{\\ell := \\{ (t,t\\alpha): t \\geq 0 \\}}")#text(" then lies in the cone ")#mi("{C(e_1,e_2)}")#text(", and avoids all the lattice points in ")#mi("{{\\bf Z}^2}")#text(" except for the origin. By the preceding discussion, if ")#mi("{(v_1,v_2)}")#text(" is a basis of ")#mi("{{\\bf Z}^2}")#text(" whose cone ")#mi("{C(v_1,v_2)}")#text(" contains ")#mi("{\\ell}")#text(", then exactly one of the two shifted bases ")#mi("{(v_1,v_1+v_2)}")#text(", ")#mi("{(v_1+v_2,v_2)}")#text(" has their cone containing ")#mi("{\\ell}")#text(".")

#text("We can then iterate this process, starting with the basis ")#mi("{(e_1,e_2)}")#text(" and continually narrowing the cone of the basis around ")#mi("{\\ell}")#text(" to create a sequence of bases ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(" for ")#mi("{k=0,1,2,\\ldots}")#text(", with ")#mi("{(v_1^{(0)},v_2^{(0)}) = (e_1,e_2)}")#text(", and ")#mi("{(v_1^{(k+1)},v_2^{(k+1)})}")#text(" equal to either the rightward shift ")#mi("{(v_1^{(k)},v_1^{(k)}+v_2^{(k)})}")#text(" or upward shift ")#mi("{(v_1^{(k)}+v_2^{(k)}, v_2^{(k)})}")#text(" of ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(", and the cones ")#mi("{C(v_1^{(k)}, v_2^{(k)})}")#text(" decreasing to ")#mi("{\\ell}")#text(". We will call the ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(" the ")#emph[#text("semiconvergent basis sequence")]#text(" of ")#mi("{\\alpha}")#text(".")

#text("We can write the semiconvergent basis sequence ")#mi("{(v_1^{(k)},v_2^{(k)})}")#text(" in coordinates as ")#mi("{v_1^{(k)} = (q_1^{(k)}, p_1^{(k)})}")#text(" and ")#mi("{v_2^{(k)} = (q_2^{(k)}, p_2^{(k)})}")#text(", then the ")#mi("{p_1^{(k)}, p_2^{(k)}, q_1^{(k)}, q_2^{(k)}}")#text(" are monotone non-decreasing sequences of natural numbers that increase to infinity. The slopes ")#mi("{\\frac{p_1^{(k)}}{q_1^{(k)}}, \\frac{p_2^{(k)}}{q_2^{(k)}}}")#text(" of ")#mi("{v_1^{(k)}, v_2^{(k)}}")#text(" thus converge to ")#mi("{\\alpha}")#text(" from below and above respectively, and are known as the ")#emph[#text("best lower rational approximants")]#text(" and ")#emph[#text("best upper rational approximants")]#text(" of ")#mi("{\\alpha}")#text(", for reasons that we shall explain shortly.")

#text("We can track the dynamics of the subconvergent basis sequence by using ")#mi("{(1,\\alpha)}")#text(" and ")#mi("{e_2}")#text(" as a basis for ")#mi("{{\\bf R}^2}")#text(", thus measuring the extent to which ")#mi("{v_1^{(k)}}")#text(" and ")#mi("{v_2^{(k)}}")#text(" fall below and above the ray ")#mi("{\\ell}")#text(" respectively. Indeed, if we write")

#align(center)[#tao-fit-display[#mitex("v_1^{(k)} = q_1^{(k)} (1,\\alpha) - \\epsilon_1^{(k)} e_2")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("v_2^{(k)} = q_2^{(k)} (1,\\alpha) + \\epsilon_2^{(k)} e_2")]]

#text("then the residual errors ")#mi("{\\epsilon_1^{(k)}, \\epsilon_2^{(k)}}")#text(" are positive reals, which initially take the values")

#align(center)[#tao-fit-display[#mitex("\\epsilon_1^{(0)} = \\alpha; \\epsilon_2^{(0)} = 1")]]

#text("and evolve according to the recursion")

#align(center)[#tao-fit-display[#mitex("\\epsilon_1^{(k+1)} = \\epsilon_1^{(k)}; \\epsilon_2^{(k+1)} = \\epsilon_2^{(k)} - \\epsilon_1^{(k)}")]]

#text("when ")#mi("{\\epsilon_2^{(k)} > \\epsilon_1^{(k)}}")#text(" (rightward shift case), or")

#align(center)[#tao-fit-display[#mitex("\\epsilon_1^{(k+1)} = \\epsilon_1^{(k)}-\\epsilon_2^{(k)}; \\epsilon_2^{(k+1)} = \\epsilon_2^{(k)}")]]

#text("when ")#mi("{\\epsilon_2^{(k)} < \\epsilon_1^{(k)}}")#text(" (upward shift case). (Note that the border case ")#mi("{\\epsilon_1^{(k)}=\\epsilon_2^{(k)}}")#text(" does not occur when ")#mi("{\\alpha}")#text(" is irrational.) In particular we see that the ")#mi("{\\epsilon_1^{(k)}}")#text(" and ")#mi("{\\epsilon_2^{(k)}}")#text(" decrease monotonically to zero.")

#text("We may now justify the terminology of best rational approximation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Best rational approximation)")]#text("Let ")#mi("{N > 0}")#text(", and let ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(" be the last basis in the semiconvergent basis sequence for which ")#mi("{q_1^{(k)}, q_2^{(k)} \\leq N}")#text(". Then for any natural numbers ")#mi("{0 < q \\leq N}")#text(" and ")#mi("{p \\geq 0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("p - q \\alpha \\geq p_2^{(k)} - q_2^{(k)} \\alpha = \\epsilon_2^{(k)}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{p}{q} \\geq \\frac{p_2^{(k)}}{q_2^{(k)}} > \\alpha")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("p - q \\alpha \\leq p_1^{(k)} - q_1^{(k)} \\alpha = -\\epsilon_1^{(k)}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{p}{q} \\leq \\frac{p_1^{(k)}}{p_1^{(k)}} < \\alpha.")]]
]

#emph[#text("Proof:")]#text(" As ")#mi("{v_1^{(k)}, v_2^{(k)}}")#text(" form a basis for ")#mi("{{\\bf Z}^2}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("(q,p) = a v_1^{(k)} + b v_2^{(k)}")]]

#text("for some integers ")#mi("{a, b}")#text("; in particular,")

#align(center)[#tao-fit-display[#mitex("p - q \\alpha = a \\epsilon_2^{(k)} - b \\epsilon_1^{(k)}")]]

#text("This already gives the claim when ")#mi("{a > 0}")#text(" and ")#mi("{b \\leq 0}")#text(", or when ")#mi("{a \\leq 0}")#text(" and ")#mi("{b > 0}")#text(". The case ")#mi("{a,b \\leq 0}")#text(" cannot occur since this would make ")#mi("{q \\leq 0}")#text(", so we are left with the case ")#mi("{a,b > 0}")#text(". But in this case, we have ")#mi("{q \\geq q_1^{(k)} + q_2^{(k)}}")#text(", and hence ")#mi("{q > N}")#text(" by construction, again a contradiction. ")#mi("\\Box")

#text("We can also track the dynamics of the semiconvergent basis sequence by introducing the ")#emph[#text("relative slope")]#text(" ")#mi("{\\alpha^{(k)} \\in (0,+\\infty)}")#text(" of ")#mi("{\\ell}")#text(" with respect to the cone ")#mi("{C(v_1^{(k)}, v_2^{(k)})}")#text(", defined as the unique positive real number such that")

#align(center)[#tao-fit-display[#mitex("\\ell = \\{ t ( v_1^{(k)} + \\alpha^{(k)} v_2^{(k)}) \\}.")]]

#text("As ")#mi("{\\alpha}")#text(" is irrational, the ")#mi("{\\alpha^{(k)}}")#text(" are all irrational. It is not difficult to see that the ")#mi("{\\alpha^{(k)}}")#text(" are defined by the following recursion: ")#mi("{\\alpha^{(0)} = \\alpha}")#text(", and one has ")#mi("{\\alpha^{(k+1)} = \\alpha^{(k)}-1}")#text(" when ")#mi("{\\alpha^{(k)}>1}")#text(", and ")#mi("{\\frac{1}{\\alpha^{(k+1)}} = \\frac{1}{\\alpha^{(k)}}-1}")#text(" when ")#mi("{\\alpha^{(k)} < 1}")#text(". Also, the former case arises when ")#mi("{(v_1^{(k+1)}, v_2^{(k+1)})}")#text(" is the upward shift of ")#mi("{(v_1^{(k)},v_2^{(k)})}")#text(", and the latter case arises when we have a rightward shift instead.")

#text("The semiconvergent basis sequence ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(" can be viewed as a sequence of ")#mi("{a_0}")#text(" upward shifts for some non-negative integer ")#mi("{a_0}")#text(", followed by ")#mi("{a_1}")#text(" rightward shifts for some positive integer ")#mi("{a_1}")#text(", then ")#mi("{a_2}")#text(" upward shifts for some positive integer ")#mi("{a_2}")#text(", and so forth. By tracking what happens to the relative slope ")#mi("{\\alpha^{(k)}}")#text(" and its reciprocal ")#mi("{1/\\alpha^{(k)}}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\alpha = a_0 + \\frac{1}{\\alpha_1}")]]

#text("for some ")#mi("{\\alpha_1 > 1}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\alpha_1 = a_1 + \\frac{1}{\\alpha_2}")]]

#text("for some ")#mi("{\\alpha_2 > 0}")#text(", and so forth, leading to the familiar continued fraction expansion")

#align(center)[#tao-fit-display[#mitex("\\alpha = a_0 + \\frac{1}{a_1 + \\frac{1}{a_2 + \\ldots}}.")]]

#text("We recursively define the sequence ")#mi("{w_{-2}, w_{-1}, w_0, \\ldots}")#text(" of lattice vectors by the formulae")

#align(center)[#tao-fit-display[#mitex("w_{-2} = e_1; w_{-1} := e_2")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("w_n = a_n w_{n-1} + w_{n-2}")]]

#text("for ")#mi("{n \\geq 0}")#text(", thus")

#tao-aligned(keep: true)[


#tao-math("w_{-2}  & = (1,0)", block: true)



#tao-math("w_{-1}  & = (0,1)", block: true)



#tao-math("w_0  & = (1, a_0)", block: true)



#tao-math("w_1  & = (a_1, a_0 a_1 + 1)", block: true)



#tao-math("w_2  & = (1 + a_1 a_2, a_0 + a_0 a_1 a_2 + a_2)", block: true)
]

#text("etc. We may then describe the bases ")#mi("{(v_1^{(k)},v_2^{(k)})}")#text(" in terms of the ")#mi("{w_n}")#text(" as follows: if")

#align(center)[#tao-fit-display[#mitex("k = a_0 + \\ldots + a_{n-1} + j")]]

#text("for some ")#mi("{0 \\leq j \\leq a_n}")#text(" and ")#mi("{n \\geq 0}")#text(", then one has")

#align(center)[#tao-fit-display[#mitex("(v_1^{(k)}, v_2^{(k)}) = (w_{n-1}, w_{n-2}+jw_{n-1})")]]

#text("if ")#mi("{n}")#text(" is even, and")

#align(center)[#tao-fit-display[#mitex("(v_1^{(k)}, v_2^{(k)}) = (w_{n-2}+jw_{n-1}, w_{n-1})")]]

#text("if ")#mi("{n}")#text(" is odd. In particular, the sequence ")#mi("{(v_1^{(k)},v_2^{(k)})}")#text(" of bases contains the sequence")

#align(center)[#tao-fit-display[#mitex("(w_{-2}, w_{-1}), (w_{0}, w_{-1}), (w_0, w_1), (w_2, w_1), \\ldots")]]

#text("as a subsequence, representing the places is the sequence in which one changes from a rightward shift to an upward shift or vice versa. In particular, if ")#mi("{w_n =: (q_n, p_n)}")#text(", then the slopes ")#mi("{p_n/q_n}")#text(" (known as ")#emph[#text("successive convergents")]#text(" to ")#mi("{\\alpha}")#text(") converge to ")#mi("{\\alpha}")#text(" from below when ")#mi("{n}")#text(" is even, and from above when ")#mi("{n}")#text(" is odd. As bases have determinant ")#mi("{+1}")#text(", we also see that ")#metadata(none) <tao-047a9fbf25f56d7d7d77>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("p_n q_{n+1} - p_{n+1} q_n = (-1)^n.")]]



#text("By construction, we have the recurrences")

#align(center)[#tao-fit-display[#mitex("p_n = a_n p_{n-1} + p_{n-2}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("q_n = a_n q_{n-1} + q_{n-2}")]]

#text("with initial conditions ")#mi("{(q_{-2}, p_{-2}) = (1,0)}")#text(" and ")#mi("{(q_{-1}, p_{-1}) = (0,1)}")#text(", thus")

#tao-aligned(keep: true)[


#tao-math("\\frac{p_{-2}}{q_{-2}}  & = \\frac{0}{1} = 0", block: true)



#tao-math("\\frac{p_{-1}}{q_{-1}}  & = \\frac{1}{0} = \\infty", block: true)



#tao-math("\\frac{p_0}{q_0}  & = \\frac{a_0}{1} = a_0", block: true)



#tao-math("\\frac{p_1}{q_1}  & = \\frac{a_0 a_1 + 1}{a_1} = a_0 + \\frac{1}{a_1}", block: true)



#tao-math("\\frac{p_2}{q_2}  & = \\frac{a_0+a_0a_1a_2+a_2}{1+a_1a_2} = a_0 + \\frac{1}{a_1+\\frac{1}{a_2}}", block: true)
]

#text("etc. From an induction we see that the ")#mi("{p_n, q_n}")#text(" are a monotonically increasing sequence of natural numbers. Indeed, they must increase at least as fast as the Fibonacci sequence ")#mi("{F_0 =F_1 = 1, F_2 = 2, F_3 = 3, F_4 = 5, \\ldots}")#text("; from an easy induction we see that ")#mi("{p_{n+k} \\geq F_k p_n}")#text(", ")#mi("{q_{n+k} \\geq F_k q_n}")#text(" for all ")#mi("{n,k \\geq 0}")#text(". In particular, the ")#mi("{p_n,q_n}")#text(" must grow at least exponentially fast in ")#mi("{n}")#text(".")

#text("As with the basis sequence ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(", we can express the ")#mi("{w_n}")#text(" in the ")#mi("{(1,\\alpha), e_2}")#text(" basis:")

#align(center)[#tao-fit-display[#mitex("w_n = q_n (1,\\alpha) - (-1)^n \\epsilon_n e_2")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("p_n = \\alpha q_n - (-1)^n \\epsilon_n.")]]

#text("Then the ")#mi("{\\epsilon_n}")#text(" are positive reals, with ")#mi("{\\epsilon_{-2} = \\alpha}")#text(", ")#mi("{\\epsilon_{-1} = 1}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\epsilon_n = \\epsilon_{n-2} - a_n \\epsilon_{n-1}.")]]

#text("By construction, we see that the ")#mi("{\\epsilon_n}")#text(" are monotone decreasing in ")#mi("{n}")#text(" for ")#mi("{n \\geq 0}")#text("; indeed, we see that ")#mi("{\\epsilon_n}")#text(" are essentially the output of the ")#link("http://en.wikipedia.org/wiki/Euclidean_algorithm")[#text("Euclidean algorithm")]#text(" applied to the real numbers ")#mi("{\\alpha,1}")#text(". From ")#link(<tao-047a9fbf25f56d7d7d77>)[#text("(1)")]#text("we see that")

#align(center)[#tao-fit-display[#mitex("\\epsilon_n q_{n+1} + \\epsilon_{n+1} q_n = 1.")]]

#text("Since ")#mi("{\\epsilon_n \\geq \\epsilon_{n+1}}")#text(" and ")#mi("{q_{n+1} \\geq q_n}")#text(" for ")#mi("{n \\geq 0}")#text(", we see in particular that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2q_{n+1}} \\leq \\epsilon_n \\leq \\frac{1}{q_{n+1}}.")]]

#text("In particular we have a fairly precise description of how well the convergents ")#mi("{p_n/q_n}")#text(" approximate ")#mi("{\\alpha}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2q_nq_{n+1}} \\leq \\left|\\alpha - \\frac{p_n}{q_n}\\right| \\leq \\frac{1}{q_n q_{n+1}}.", block: true)]]

#text("In particular, we have ")#metadata(none) <tao-97e38e1b2d7735fb875c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\frac{1}{2q_{n+1}} \\leq \\left\\| q_n \\alpha \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\frac{1}{q_{n+1}}.", block: true)]]





#text("As the ")#mi("{p_n/q_n}")#text(" are best rational approximants, we thus also have ")#metadata(none) <tao-3d42efcd2b8b6aa4eed0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| q \\alpha \\right\\|_{{\\bf R}/{\\bf Z}} \\geq \\frac{1}{2q_{n+1}}", block: true)]]



#text(" whenever ")#mi("{1 \\leq q \\leq q_n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" From the above inequalities one can easily establish the ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(" and the (one-dimensional) ")#link("http://en.wikipedia.org/wiki/Kronecker%27s_theorem#A_result_in_diophantine_approximation")[#text("Kronecker approximation theorem")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Bohr sets — ")]]

#text("Now we compare rank one Bohr sets ")#mi("{B_N(\\alpha;\\rho)}")#text(" to rank two progressions ")#mi("{P(a_1,a_2; N_1,N_2)}")#text(". It turns out that the best progressions to use here come from using the denominators ")#mi("{q_1^{(k)}, q_2^{(k)}}")#text(" of a semiconvergent basis ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(" as the generators. Indeed, if")

#align(center)[#tao-fit-display[#mitex("q \\in P( q_1^{(k)}, q_2^{(k)}; N_1, N_2 )")]]

#text("then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q \\alpha \\right\\|_{{\\bf R}/{\\bf Z}} \\leq N_1 \\left\\|q_1^{(k)} \\alpha \\right\\|_{{\\bf R}/{\\bf Z}} + N_2 \\left\\| q_2^{(k)} \\alpha \\right\\|_{{\\bf R}/{\\bf Z}} \\leq N_1 \\epsilon^{(k)}_1 + N_2 \\epsilon^{(k)}_2", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|q\\right| \\leq N_1 q_1^{(k)} + N_2 q_2^{(k)}.", block: true)]]

#text("Thus we have")

#align(center)[#tao-fit-display[#mitex("P( q_1^{(k)}, q_2^{(k)}; N_1, N_2 ) \\subset B_N(\\alpha;\\rho)")]]

#text("whenever")

#align(center)[#tao-fit-display[#mitex("N_1 q_1^{(k)} + N_2 q_2^{(k)} \\leq N \\text{ and } N_1 \\epsilon^{(k)}_1 + N_2 \\epsilon^{(k)}_2 \\leq \\rho.")]]

#text("In the converse direction, suppose that ")#mi("{q \\in B_N(\\alpha;\\rho)}")#text(", thus ")#tao-math("{\\left|q\\right| \\leq N}", block: false)#text(" and one has ")#tao-math("{\\left|p-q\\alpha\\right| \\leq \\rho}", block: false)#text(" for some integer ")#mi("{p}")#text(". As ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(" is a basis for ")#mi("{{\\bf Z}^2}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("(q,p) = a v_1^{(k)} + b v_2^{(k)}")]]

#text("for some integers ")#mi("{a, b}")#text(". Taking wedge products, we see that")

#align(center)[#tao-fit-display[#mitex("a = (q,p) \\wedge v_2^{(k)}; \\quad b = - (q,p) \\wedge v_1^{(k)}.")]]

#text("We write ")#mi("{(q,p) = q (1,\\alpha) + \\epsilon e_2}")#text(" for some ")#tao-math("{\\left|\\epsilon\\right| \\leq \\rho}", block: false)#text(", and similarly write ")#mi("{v_i^{(k)} = q_i^{(k)} (1,\\alpha) \\pm \\epsilon_i^{(k)} e_2}")#text(" for ")#mi("{i=1,2}")#text(", to conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|a\\right| \\leq \\left|q\\right| \\epsilon_2^{(k)} + \\left|\\epsilon\\right| q_2^{(k)} \\leq N \\epsilon_2^{(k)} + \\rho q_2^{(k)}", block: true)]]

#text("and similarly")

#align(center)[#tao-fit-display[#tao-math("\\left|b\\right| \\leq N \\epsilon_1^{(k)} + \\rho q_1^{(k)}.", block: true)]]

#text("We conclude that")

#align(center)[#tao-fit-display[#mitex("B_N(\\alpha;\\rho) \\subset P( q_1^{(k)}, q_2^{(k)}; N_1, N_2 )")]]

#text("whenever")

#align(center)[#tao-fit-display[#mitex("N \\epsilon_2^{(k)} + \\rho q_2^{(k)} \\leq N_1 \\text{ and } N \\epsilon_1^{(k)} + \\rho q_1^{(k)} \\leq N_2.")]]

#text("It is now a routine matter to optimise the parameters ")#mi("{k, N_1, N_2}")#text(" to obtain a good fit. Suppose for instance that ")#metadata(none) <tao-45390165fce0bae9bf04>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{N}{2 q_1^{(k)} q_2^{(k)}} \\leq \\rho \\leq \\frac{N}{q_1^{(k)} q_2^{(k)}}")]]



#text(" for some ")#mi("{k \\geq 0}")#text(". If we then set")

#align(center)[#tao-fit-display[#mitex("N_1 := \\frac{1}{2} q_2^{(k)} \\rho; \\quad N_2 := \\frac{1}{2} q_1^{(k)} \\rho,")]]

#text("then we have")

#align(center)[#tao-fit-display[#mitex("N_1 q_1^{(k)} + N_2 q_2^{(k)} = q_1^{(k)} q_2^{(k)} \\rho \\leq N.")]]

#text("Also, since ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(" is a basis, we have ")#mi("{v_1^{(k)} \\wedge v_2^{(k)} = 1}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("q_1^{(k)} \\epsilon^{(k)}_2 + q_2^{(k)} \\epsilon^{(k)}_1 = 1.")]]

#text("In particular,")

#tao-aligned(keep: true)[


#tao-math("N_1 \\epsilon^{(k)}_1 + N_2 \\epsilon^{(k)}_2  & \\leq \\frac{N_1}{q_2^{(k)}} + \\frac{N_2}{q_1^{(k)}}", block: true)



#tao-math(" & \\leq \\rho.", block: true)
]

#text("We thus conclude from the preceding discussion that")

#align(center)[#tao-fit-display[#mitex("P( q_1^{(k)}, q_2^{(k)}; N_1, N_2 ) \\subset B_N(\\alpha;\\rho).")]]

#text("On the other hand, we have")

#tao-aligned(keep: true)[


#tao-math("N \\epsilon_2^{(k)} + \\rho q_2^{(k)}  & \\leq \\frac{N}{q_1^{(k)}} + 2 N_1", block: true)



#tao-math(" & \\leq 4N_1 + 2N_1 = 6 N_1", block: true)
]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("N \\epsilon_1^{(k)} + \\rho q_1^{(k)} \\leq 6N_2")]]

#text("and thus by the preceding discussion")

#align(center)[#tao-fit-display[#mitex("B_N(\\alpha;\\rho) \\subset P( q_1^{(k)}, q_2^{(k)}; 6N_1, 6N_2 )")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("B_{N/6}(\\alpha;\\rho/6) \\subset P( q_1^{(k)}, q_2^{(k)}; N_1, N_2 ).")]]

#text("Thus, in this case, the rank one Bohr set ")#mi("{B_N(\\alpha;\\rho)}")#text(" is morally the same object (up to constants) as the rank two progression ")#mi("{P( q_1^{(k)}, q_2^{(k)}; N_1, N_2 )}")#text(".")

#text("Things are a bit more complicated in the regime ")#metadata(none) <tao-f3864d85c88c0c7e9382>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{N}{q_1^{(k+1)} q_2^{(k+1)}} < \\rho < \\frac{N}{2 q_1^{(k)} q_2^{(k)}}.")]]



#text(" For sake of discussion, let us suppose that ")#mi("{(v_1^{(k+1)}, v_2^{(k+1)})}")#text(" is an upward shift of ")#mi("{(v_1^{(k)}, v_2^{(k)})}")#text(", so that ")#mi("{q_1^{(k+1}) = q_1^{(k)} + q_2^{(k)}}")#text(" and ")#mi("{q_2^{(k+1}) = q_2^{(k)}}")#text(". From ")#link(<tao-f3864d85c88c0c7e9382>)[#text("(5)")]#text(" we see that ")#mi("{q_1^{(k+1)} > 2 q_1^{(k)}}")#text(" and hence ")#mi("{q_1^{(k)} < q_2^{(k)}}")#text(". Also, we have ")#mi("{\\epsilon_1^{(k+1)} = \\epsilon_1^{(k)} - \\epsilon_2^{(k)}}")#text(", so in particular, ")#mi("{\\epsilon_2^{(k)} \\leq \\epsilon_1^{(k)} \\leq \\frac{1}{q_2^{(k)}}}")#text(". If we now set")

#align(center)[#tao-fit-display[#mitex("N_1 := \\frac{1}{2} \\rho q_2^{(k)}; N_2 := \\frac{N}{4q_2^{(k)}}")]]

#text("then we have")

#align(center)[#tao-fit-display[#mitex("N_1 q_1^{(k)} + N_2 q_2^{(k)} \\leq \\frac{1}{4} N + \\frac{1}{4} N \\leq N")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("N_1 \\epsilon^{(k)}_1 + N_2 \\epsilon^{(k)}_2  & \\leq \\frac{1}{2} \\rho + \\frac{1}{4} \\frac{N}{(q_2^{(k)})^2}", block: true)



#tao-math(" & \\leq \\frac{1}{2} \\rho + \\frac{1}{2} \\frac{N}{q_1^{(k+1)} q_2^{(k+1)}}", block: true)



#tao-math(" & \\leq \\rho", block: true)
]

#text("and so")

#align(center)[#tao-fit-display[#mitex("P( q_1^{(k)}, q_2^{(k)}; N_1, N_2 ) \\subset B_N(\\alpha;\\rho).")]]

#text("Conversely, we have")

#tao-aligned(keep: true)[


#tao-math("N \\epsilon_2^{(k)} + \\rho q_2^{(k)}  & \\leq \\frac{N}{q_2^{(k)}} + 2 N_1", block: true)



#tao-math(" & \\leq 2 \\frac{N}{q_1^{(k+1)} q_2^{(k+1)}} q_2^{(k)} + 2N_1", block: true)



#tao-math(" & \\leq 4 N_1 + 2N_1 = 6N_1", block: true)
]

#text("while")

#tao-aligned(keep: true)[


#tao-math("N \\epsilon_1^{(k)} + \\rho q_1^{(k)}  & \\leq \\frac{N}{q_2^{(k)}} + \\frac{N}{2q_2^{(k)}}", block: true)



#tao-math(" & = 6 N_2", block: true)
]

#text("and so once again we have")

#align(center)[#tao-fit-display[#mitex("B_N(\\alpha;\\rho) \\subset P( q_1^{(k)}, q_2^{(k)}; 6N_1, 6N_2 )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B_{N/6}(\\alpha;\\rho/6) \\subset P( q_1^{(k)}, q_2^{(k)}; N_1, N_2 ).")]]

#text("Thus again we see that in this case ")#mi("{B_N(\\alpha;\\rho)}")#text(" is morally the same object as ")#mi("{P(q_1^{(k)}, q_2^{(k)}; N_1, N_2)}")#text(".")

#text("Note that as ")#mi("{\\rho}")#text(" shrinks, the lengths ")#mi("{N_1,N_2}")#text(" shrink also, though every so often there is a discontinuity when ")#mi("{k}")#text(" is incremented, thus shearing the generators ")#mi("{q_1^{(k)}, q_2^{(k)}}")#text(" as well as the lengths ")#mi("{N_1,N_2}")#text(". (Technically, there is also a discontinuity when one passes from ")#link(<tao-45390165fce0bae9bf04>)[#text("(4)")]#text(" to ")#link(<tao-f3864d85c88c0c7e9382>)[#text("(5)")]#text(", but this is an artificial discontinuity and can be eliminated by performing a smoother interpolation between these two regimes which we omit.) Among other things, the above relationships give a rough description of the cardinality of the Bohr set ")#mi("{B_N(\\alpha;\\rho)}")#text("; one has")

#align(center)[#tao-fit-display[#tao-math("\\left|B_N(\\alpha;\\rho)\\right| \\sim (1+N_1) (1+N_2)", block: true)]]

#text("and thus (by unifying all the cases) one has")

#align(center)[#tao-fit-display[#tao-math("\\left|B_N(\\alpha;\\rho)\\right| \\sim 1 + N \\rho + \\rho (q_1^{(k)}+q_2^{(k)})", block: true)]]

#text("whenever")

#align(center)[#tao-fit-display[#mitex("\\frac{N}{q_1^{(k+1)} q_2^{(k+1)}} \\leq \\rho \\leq \\frac{N}{q_1^{(k)} q_2^{(k)}}.")]]

#text("It is a shame that there is no similarly precise formula known for the size of a rank two Bohr set ")#tao-math("{\\left|B_N(\\alpha_1,\\alpha_2; \\rho_1,\\rho_2)\\right|}", block: false)#text(", as this would likely lead (among other things) to a resolution of the Littlewood conjecture.")

#heading(level: 1)[#strong[#text(" — 3. A reformulation of the Littlewood conjecture — ")]]

#text("The ")#link("http://en.wikipedia.org/wiki/Littlewood_conjecture")[#text("Littlewood conjecture")]#text(" asserts that for any two real numbers ")#mi("{\\alpha,\\beta}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\lim \\inf_{n \\rightarrow \\infty} n \\left\\|n\\alpha\\right\\|_{{\\bf R}/{\\bf Z}} \\left\\|n\\beta\\right\\|_{{\\bf R}/{\\bf Z}} = 0.", block: true)]]

#text("The conjecture remains open, although there are some highly non-trivial partial results, such as the ")#link("http://www.ams.org/mathscinet-getitem?mr=2247967")[#text("result of Einsiedler, Katok, and Lindenstrauss")]#text(" that the set of pairs ")#mi("{(\\alpha,\\beta)}")#text(" for which the Littlewood conjecture fails is so small that it has Hausdorff dimension zero.")

#text("If a pair ")#mi("{(\\alpha,\\beta)}")#text(" was a counterexample to the Littlewood conjecture, then")

#align(center)[#tao-fit-display[#tao-math("n \\left\\|n\\alpha\\right\\|_{{\\bf R}/{\\bf Z}} \\left\\|n\\beta\\right\\|_{{\\bf R}/{\\bf Z}} \\gg 1", block: true)]]

#text("for all positive integers ")#mi("{n}")#text(". In particular, one has")

#align(center)[#tao-fit-display[#tao-math("n \\left\\|n\\alpha\\right\\|_{{\\bf R}/{\\bf Z}} \\gg 1", block: true)]]

#text("for all ")#mi("{n}")#text(" (in other words, ")#mi("{\\alpha}")#text(" is ")#emph[#text("badly approximable")]#text(" by rationals, and is in particular irrational). Applying ")#link(<tao-97e38e1b2d7735fb875c>)[#text("(2)")]#text(", we conclude that ")#mi("{q_{n+1} \\ll q_n}")#text(" for all ")#mi("{n}")#text(", or equivalently that the coefficients ")#mi("{a_n}")#text(" of the continued fraction expansion of ")#mi("{\\alpha}")#text(" are bounded. (Conversely, using ")#link(<tao-97e38e1b2d7735fb875c>)[#text("(2)")]#text(" and ")#link(<tao-3d42efcd2b8b6aa4eed0>)[#text("(3)")]#text(" we see that if ")#mi("{\\alpha}")#text(" is irrational with bounded continued fraction coefficients, then it is badly approximable by rationals.) Similarly for ")#mi("{\\beta}")#text(". This is already enough to establish without much additional work that the Littlewood conjecture is true for almost all ")#mi("{\\alpha,\\beta}")#text(" (in the sense of Lebesgue measure), although it does not come close to the stronger result of Einseidler, Katok, and Lindenstrauss mentioned above (it is known that the set of badly approximable numbers has Hausdorff dimension one).")

#text("One can reformulate the Littlewood conjecture in terms of the denominators ")#mi("{q_1,q_2,\\ldots}")#text(" of the convergents to ")#mi("{\\alpha}")#text(", and the denominators ")#mi("{r_1,r_2,\\ldots}")#text(" of the convergents to ")#mi("{\\beta}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" Let ")#mi("{\\alpha,\\beta}")#text(" be two real numbers. Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{\\alpha,\\beta}")#text(" form a counterexample to the Littlewood conjecture.")],
[#text("(ii) ")#mi("{\\alpha,\\beta}")#text(" are badly approximable, and there is an ")#mi("{\\epsilon>0}")#text(" such that the rank four progressions")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("P( q_n, q_{n+1}, r_m, r_{m+1}; \\epsilon q_n^{-1/3} r_m^{2/3}, \\epsilon q_n^{-1/3} r_m^{2/3},")]]

#align(center)[#tao-fit-display[#mitex("\\epsilon q_m^{2/3} r_m^{-1/3}, \\epsilon q_n^{2/3} r_m^{-1/3})")]]

#text("are proper for all ")#mi("{n,m \\geq 0}")#text(".")]
)
]

#text("Recall that a progression ")#mi("{P(a_1,\\ldots,a_r;N_1,\\ldots,N_r)}")#text(" is said to be proper if all of the elements ")#mi("{a_1 n_1 + \\ldots + a_r n_r}")#text(", ")#tao-math("{\\left|n_i\\right| \\leq N_i}", block: false)#text(" of the progression are distinct.")

#emph[#text("Proof:")]#text(" Let us first show that (i) implies (ii). Let ")#mi("{\\alpha,\\beta}")#text(" be a counterexample to the Littlewood conjecture, thus ")#metadata(none) <tao-c6194eb92ed46a0996c1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|N\\right| \\left\\|N\\alpha\\right\\|_{{\\bf R}/{\\bf Z}} \\left\\|N\\beta\\right\\|_{{\\bf R}/{\\bf Z}} \\gg 1", block: true)]]



#text(" for all non-zero integers ")#mi("{n}")#text(". We have already seen that ")#mi("{\\alpha,\\beta}")#text(" are badly approximable (so in particular ")#mi("{q_{n+1} \\ll q_n}")#text(" and ")#mi("{r_{m+1} \\ll r_n}")#text(". Now let ")#mi("{\\epsilon > 0}")#text(" be a sufficiently small number, and suppose that the progression ")#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#pqm")[#text("(6)")]#text(" is not proper for some ")#mi("{n,m}")#text(". Then there is a non-trivial solution to the equation ")#metadata(none) <tao-9b2d5b4678781e53038e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("a q_n + a^{\\prime} q_{n+1} = b r_m + b^{\\prime} r_{m+1}")]]



#text(" for some integers ")#mi("{a,a^{\\prime},b,b^{\\prime}}")#text(", not all zero, with ")#mi("{a,a^{\\prime} = O(\\epsilon q_n^{-1/3} r_m^{2/3})}")#text(" and ")#mi("{b,b^{\\prime} = O(\\epsilon q_n^{2/3} r_m^{1/3})}")#text(". Let ")#mi("{N}")#text(" be the integer in ")#link(<tao-9b2d5b4678781e53038e>)[#text("(8)")]#text(", then ")#mi("{N}")#text(" is non-zero and ")#mi("{N = O( \\epsilon q_n^{2/3} r_m^{2/3} )}")#text(". Also, from ")#link(<tao-97e38e1b2d7735fb875c>)[#text("(2)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| N \\alpha \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\frac{\\left|a\\right|}{q_{n+1}} + \\frac{\\left|a^{\\prime}\\right|}{q_{n+2}} = O( \\epsilon q_n^{-4/3} r_m^{2/3} )", block: true)]]

#text("and similarly")

#align(center)[#tao-fit-display[#tao-math("\\left\\| N \\beta \\right\\|_{{\\bf R}/{\\bf Z}} = O( \\epsilon q_n^{2/3} r_m^{-4/3} )", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|N\\right| \\left\\|N\\alpha\\right\\|_{{\\bf R}/{\\bf Z}} \\left\\| N \\beta \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\epsilon^3.", block: true)]]

#text("Setting ")#mi("{\\epsilon}")#text(" small enough, we contradict ")#link(<tao-c6194eb92ed46a0996c1>)[#text("(7)")]#text(".")

#text("Now we show that (ii) implies (i). Let ")#mi("{\\alpha,\\beta,\\epsilon}")#text(" be as in (ii). Suppose for contradiction that (i) fails, thus we can find a sequence ")#mi("{N = N_i}")#text(" of integers going off to infinity such that")

#align(center)[#tao-fit-display[#tao-math("\\left|N\\right| \\left\\|N\\alpha\\right\\|_{{\\bf R}/{\\bf Z}} \\left\\|N\\beta\\right\\|_{{\\bf R}/{\\bf Z}} = o(1),", block: true)]]

#text("where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{N}")#text(" (or ")#mi("{i}")#text(") goes to infinity. In particular, one can find ")#mi("{q,r \\geq 1}")#text(" (depending on ")#mi("{N}")#text(") such that")

#tao-aligned(keep: true)[


#tao-math("N  & = o( q^{2/3} r^{2/3} )", block: true)



#tao-math("\\left\\|N\\alpha \\right\\|_{{\\bf R}/{\\bf Z}}  & = o( q^{-4/3} r^{2/3} )", block: true)



#tao-math("\\left\\|N\\beta\\right\\|_{{\\bf R}/{\\bf Z}}  & = o( q^{2/3} r^{-4/3} ).", block: true)
]

#text("(Indeed, one can pick ")#mi("{q}")#text(" to be ")#tao-math("{(N / \\left\\|N\\alpha\\right\\|_{{\\bf R}/{\\bf Z}})^{1/2}}", block: false)#text(" and ")#mi("{r}")#text(" to be ")#tao-math("{(N/\\left\\|N\\beta\\right\\|_{{\\bf R}/{\\bf Z}})^{1/2}}", block: false)#text(".) As the ")#mi("{q_n}")#text(" increase in a lacunary fashion (thanks to the bad approximability of ")#mi("{\\alpha}")#text("), we can find ")#mi("{n}")#text(" such that ")#mi("{q_n \\sim q}")#text("; similarly we may find ")#mi("{m}")#text(" such that ")#mi("{r_m \\sim r}")#text(", thus")

#tao-aligned(keep: true)[


#tao-math("N  & = o( q_n^{2/3} r_m^{2/3} )", block: true)



#tao-math("\\left\\|N\\alpha \\right\\|_{{\\bf R}/{\\bf Z}}  & = o( q_n^{-4/3} r_m^{2/3} )", block: true)



#tao-math("\\left\\|N\\beta\\right\\|_{{\\bf R}/{\\bf Z}}  & = o( q_n^{2/3} r_m^{-4/3} ).", block: true)
]

#text("Thus ")#mi("{N}")#text(" lies in the Bohr sets")

#align(center)[#tao-fit-display[#mitex("B_{o(q_n^{2/3} r_m^{2/3} )}( \\alpha; o( q_n^{-4/3} r_m^{2/3} ) )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B_{o(q_n^{2/3} r_m^{2/3} )}( \\beta; o( q_n^{2/3} r_m^{-4/3} ) ).")]]

#text("Applying the analysis of the preceding section, we conclude that ")#mi("{N}")#text(" lies in the rank two progressions")

#align(center)[#tao-fit-display[#mitex("P( q_n, q_{n+1}; o( q_n^{-1/3} r_m^{2/3} ), o( q_n^{-1/3} r_m^{2/3} ) )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P( r_m, r_{m+1}; o( q_n^{2/3} r_m^{-1/3} ), o( q_n^{2/3} r_m^{-1/3} ) )")]]

#text("and is non-zero, and so the rank four progression")

#align(center)[#tao-fit-display[#mitex("P( q_n, q_{n+1}, r_m, r_{m+1}; o( q_n^{-1/3} r_m^{2/3} ), o( q_n^{-1/3} r_m^{2/3} ), o( q_n^{2/3} r_m^{-1/3} ), o( q_n^{2/3} r_m^{-1/3} ) )")]]

#text("is not proper. But this contradicts (ii) for ")#mi("{N}")#text(" large enough. ")#mi("\\Box")

#text("We can now give a heuristic explanation as to why there should not be any counterexample ")#mi("{\\alpha,\\beta}")#text(" to the Littlewood conjecture. Such a counterexample can be completely described by the continued fraction coefficients ")#mi("{a_0,a_1,a_2,\\ldots}")#text(" for ")#mi("{\\alpha}")#text(", and the continued fraction coefficients ")#mi("{b_0,b_1,b_2,\\ldots}")#text(" for ")#mi("{\\beta}")#text(". These sequences need to be bounded by the bad approximability property; let us suppose that they are both bounded by some bound ")#mi("{M}")#text(". Thus, for any ")#mi("{n_0,m_0}")#text(", the number of choices for ")#mi("{a_0,a_1,\\ldots,a_{n_0}}")#text(" and ")#mi("{b_0,\\ldots,b_{m_0}}")#text(" grows at most exponentially in ")#mi("{n_0,m_0}")#text(" (it is about ")#mi("{M^{n_0+m_0}}")#text("). Of course, these coefficients then determine the denominators ")#mi("{q_1,\\ldots,q_{n_0}}")#text(" and ")#mi("{r_1,\\ldots,r_{m_0}}")#text(" by the recurrences given previously.")

#text("On the other hand, by the above proposition, there needs to be an ")#mi("{\\epsilon > 0}")#text(" such that for each ")#mi("{n \\leq n_0}")#text(" and ")#mi("{m \\leq m_0}")#text(", the progression ")#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#pqm")[#text("(6)")]#text(" is proper. We can heuristically gauge how likely this occurs by the following numerology. For fixed ")#mi("{n,m}")#text(" (and making the non-degeneracy assumptions that ")#mi("{q_n^{-1/3} r_m^{2/3}, q_n^{2/3} r_m^{-1/3} \\gg 1}")#text("), there are about ")#mi("{\\epsilon^4 q_n^{2/3} r_m^{2/3}}")#text(" different ways to form a sum of the form")

#align(center)[#tao-fit-display[#mitex("a q_n + a^{\\prime} q_{n+1} + b r_m + b^{\\prime} r_{m+1}")]]

#text("with ")#mi("{a,a^{\\prime} = O(\\epsilon q_n^{-1/3} r_m^{2/3})}")#text(" and ")#mi("{b,b^{\\prime} = O(\\epsilon q_n^{2/3} r_m^{-1/3})}")#text(". These sums have magnitude about ")#mi("{O( \\epsilon q_n^{2/3} r_m^{2/3} )}")#text(". Thus, we expect that the probability that all non-trivial sums avoid zero (which is basically what is needed for ")#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#pqm")[#text("(6)")]#text(" to be proper) to be at most ")#mi("{1-\\delta}")#text(" for some ")#mi("{\\delta>0}")#text(" depending only on ")#mi("{\\epsilon}")#text(".")

#text("On the other hand, the number of eligible pairs ")#mi("{(n,m)}")#text(" for which the progression ")#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#pqm")[#text("(6)")]#text(" is non-degenerate enough to have a chance of being proper grows ")#emph[#text("quadratically")]#text(" in ")#mi("{n_0,m_0}")#text(". Due to the exponential growth of ")#mi("{q_n}")#text(" and ")#mi("{r_m}")#text(", it is reasonable to suppose that the properness of each of the progressions ")#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#pqm")[#text("(6)")]#text(" behave like independent (or at least very weakly coupled) events as ")#mi("{n,m}")#text(" vary (viewing ")#mi("{a_0,\\ldots,a_{n_0}}")#text(" and ")#mi("{b_0,\\ldots,b_{m_0}}")#text(" as being drawn uniformly from all sequences bounded by ")#mi("{M}")#text("). If we assume that this independence is so strong as to be like joint independence (and here is where we really make a serious leap of faith), then we therefore expect the probability that a randomly chosen choice of coefficients has all of the ")#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#pqm")[#text("(6)")]#text(" proper should decay quadratic-exponentially in ")#mi("{n_0,m_0}")#text(" (i.e. it should be something like ")#mi("{(1-\\delta)^{n_0 m_0}}")#text(", particularly if we choose ")#mi("{n_0}")#text(" and ")#mi("{m_0}")#text(" to be comparable in magnitude). As this beats the entropy of ")#mi("{M^{n_0+m_0}}")#text(" for ")#mi("{n_0,m_0}")#text(" large enough, we thus expect that for any given ")#mi("{M, \\epsilon}")#text(", there should not in fact be any counterexamples to (ii) (and hence to the Littlewood conjecture) with this choice of parameters.")

#text("This heuristic derivation of the Littlewood conjecture uses a common (but highly nonrigorous) probabilistic argument, in which one argues that there are so many ways in which a candidate can fail to be a counterexample to the conjecture that no counterexample actually exists. This type of heuristic is common in number theory, for instance justifying the even Goldbach conjecture (for sufficiently large even numbers, at least). Unfortunately, we do not know how to rule out the existence of some bizarre “conspiracy” between the coefficients ")#mi("{a_n}")#text(" and ")#mi("{b_m}")#text(" that manage to align all the possible (and supposedly independent) failure events in such a way that an extremely lucky and exceptional choice of coefficients manages to evade all of these events and end up as a counterexample to the conjecture. But the best we can do with current technology is to show that such conspiracies, if they exist at all, are very rare (with the aforementioned result of Einsiedler, Katok, and Lindenstrauss being the strongest result currently known of this type).")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of US.Alkalinewater@yahoo.com")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-120594")[#strong[#text("US.Alkalinewater@yahoo.com")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2012")])]

#text("The heuristic derivation of the Littlewood conjecture seems quite probable to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca8cb3fc006a87e3510003de66bc0a49dc17c88a801df0c73a56af6cf4681b3-3dc434dc68d2dd3cd8eb368c031cae8ae95230747b0aecb4fe2f33b72e6a6256.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-121439")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2012")])]

#text("Small typo in section 1 (")#mi("\\frac{0}{1}=\\infty")#text(", ")#mi("\\frac{1}{0}=1")#text(").")#linebreak()#text(" Many thanks for the heuristic derivation. The EKL paper is difficult to get through without a background in the subject.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-121491")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2012")])]

#text("In case anyone is interested in coverage of continued fractions accessible to the layperson, Manfred Schroeder covers some interesting aspects of the topic in two books, “Fractals, Chaos, Power Laws,” (Dover) and “Number Theory in Science and Communication,” (Springer).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e49dd7bf8033446e18b5c6e4bb96f7aacd98973beca1a835bc252500d32afde-b8772ff2473b943215acd280c1dc57df2185a72026807ab5ca1a26d0d346b017.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathfromhell")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-121527")[#strong[#text("mathfromhell")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2012")])]

#text("I am going to have to research this topic….thanks for the detailed discourse…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1075172adc0367bf2fc3f936f14cfdebf9a30115b7d1f71f5e22adf8ac8789b1-9bb77dd3968d49dcba8fb6871d4cadb994c433318002c62bb267211aa6dbff3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of windfarmmusic")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-124774")[#strong[#text("windfarmmusic")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2012")])]

#text("Fantastic! I was hoping to find just such a discussion of continued fractions which starts from the geometrical viewpoint.")

#text("Do you have any insight on how the analysis might change if instead of Bohr sets as you’ve defined them, one considered an ‘inhomogenous’ version")

#tao-math("\\{ n \\in \\mathbf{Z} : -N \\le n \\le N; \\left|\\left|n\\alpha + \\beta\\right|\\right|_{\\mathbf{R}/\\mathbf{Z}} \\le \\rho \\}", block: false)

#text("with an additional parameter ")#mi("\\beta \\in \\mathbf{R}")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f35f775fb25fc19939035571836cf394561d9afd23eec046cf99dd55cffc7004-124aac956a3ac6995106ea7f44016f46fc6b70d9c3bff5e0903c6e3347f7f94c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Chow")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-479447")[#strong[#text("Sam Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2017")])]

#text("I discuss this in arXiv:1703.07016.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-132552")[#strong[#text("Ułamki łańcuchowe – cz 3. Moja macierzowa reprezentacja « FIKSACJE")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2012")]

#text("[…] ( po szczegóły odsyłam czytelnika do wcześniejszego wpisu – oraz polecam niedawny wpis na blogu Terrence Tao – w którym przedstawiono w abstrakcyjnej profesjonalnej notacji wyniki opublikowane – chyba […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35c1c0b8ecf1f8e26fde963351d36af846622f063831c196d16dde3e65a06958-c8422f7cdc929d7ea493e8085d5fa90c83c3eb9e463e20966813ca5c460c210e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kazekkurz")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-133615")[#strong[#text("kazekkurz")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2012")])]

#text("I was playing with continued fractions and obtain probably interesting algebraic representation of it, and interesting algebraic structure within. maybe some of You will be interested…")

#text("Here are the citation:")

#text("“In this workbook I will show matrix representation of continued fractions (CF) different from typical one. In typical representation, two matrix L, and R are used. On the Stern-Brocot tree ( SBTree) representation of CF, matrix R decodes move to the right child and L move to the left child of given SBTree node. We may call it RL representation of CF.")

#text("Representation below gives other, complementary picture, where matrix S means “reverse direction” whilst matrix T means “go step forward”.I will call it S(ST) representation for the reasons which will be explained below. ”")

#text("It seems that these two ways of decoding walk on tree, exhaust the all the simple, canonical, natural, I do not know how to name it, ways to decode every possible walks on binary tree. Only the first, RL representation I have found in literature of the subject. Maybe this second one is only a curiosity, but maybe it would be interesting for someone.")

#text("For x- real number, represented as continued fraction with continuant matrix 2×2 – M (similar to returned in Pari/GP by contfracpnqn([a0,a1…an]) function) I have obtain interesting formula:")

#mi("x = [a_{0},a_{1},a_{2},...a_{n}] =  - \\frac{1}{2} \\frac{Tr \\left( M(S- L) \\right) }{Tr \\left(  M(S-T) \\right) }")

#text("Where matrices S, T and L are defined in sage workbook below. requirement det(M) = +-1 is represented as equation for quadratic curve in certain ring over rational numbers. Please find details below.")

#text("Here is a page on my blog with links to Sage notebook with explanations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://fiksacie.wordpress.com/2012/03/17/ulamki-lancuchowe-nonstandard-matrix-representation-of-continued-fractions-cz-5/")[#text(" Ułamki łańcuchowe – Nonstandard matrix representation of continued fractions – cz 5")]
]

#text("Here is worksheet itself on sagenb server: ")#link("http://sagenb.com/home/pub/4535/")[#text("http://sagenb.com/home/pub/4535/")]

#text("Sorry for the spam…")#linebreak()#text(" I have hope I am not terribly wrong…")#linebreak()#text(" Best regards")#linebreak()#text(" Kazimierz Kurz")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35c1c0b8ecf1f8e26fde963351d36af846622f063831c196d16dde3e65a06958-c8422f7cdc929d7ea493e8085d5fa90c83c3eb9e463e20966813ca5c460c210e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kazekkurz")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-133763")[#strong[#text("kazekkurz")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2012")])]

#text("One additional remark – interesting part of the formula above is that it is independent from the basis choice ( because of trace cyclic property, You may use any base system by linear similarity transformation and then change matrices S,T,L and M within it ) and then function from continuant matrices to continued fractions space is interesting. If You look at t closer You wil find that both nominator ( tr(M(S-L)) and denominator ( tr(M(S-T)) are just continuant polynomials – but in closed form – you may differentiate them, add, multiply etc. In Graham, Knuth Patashnik You may find a section about continuant polynomials, and they obeys many recurrence equations – any of them is a consequence of “noncommutativity” of product which appears in M definition M = S*prod(S*(ST)^{a_i}). As far as I know – no such formula is described in literature of the subject – I check a lot of articles and books looking for something similar. Please note, that in decomposed form (M = a*I+b*S+c*T+d*L – You may find definition of this objects in Sage workbook) this formula is also linear in a,b,c,d – so it may be interesting from numerical point of view…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0517203ec02b286af9a2493ae53e894d656dfc0a13cf122634d3a9a41b90e69-58a4459b29b91ad533d1f7324df817dae0a6a6cd9e222140cf037a82526d5eb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peteg")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-138071")[#strong[#text("peteg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2012")])]

#text("I think there’s a typo in the Continued Fraction section, in the expression for ")#mi("{\\alpha^{(k+1)}}")#text(" when ")#mi("{\\alpha^{(k)} > 1}")#text(". It should be ")#mi("{\\frac{1}{\\alpha^{(k+1)}} = \\frac{1}{\\alpha^{(k)}} - 1}")#text(".")

#emph[#text("[Corrected, thanks. (I presume you mean ")#mi("\\alpha^{(k)} < 1")#text(" instead of ")#mi("\\alpha^{(k)} > 1")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Reich")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-138180")[#strong[#text("Ryan Reich")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2012")])]

#text("In the proof of Proposition 1, I think you want to consider ")#mi("(q, p)")#text(" and not ")#mi("(p, q)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0517203ec02b286af9a2493ae53e894d656dfc0a13cf122634d3a9a41b90e69-58a4459b29b91ad533d1f7324df817dae0a6a6cd9e222140cf037a82526d5eb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peteg")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-139757")[#strong[#text("peteg")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2012")])]

#text("I think there’s a typo in the 4’th element of the sequence of pairs of ")#mi("w")#text("‘s . It should be ")#mi("(w_2, w_1)")#text(" not ")#mi("(w_2,w_0)")#text(". ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-143561")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2012")])]

#text("Dear Professor Tao,")#linebreak()#text(" I’m truly intrigued by your Proposition 2.1 and your probabilistic argument")#linebreak()#text(" for the Littlewood conjecture. Using $M$ and $\\epsilon$ as in your")#linebreak()#text(" heuristic argument, I’ve been wondering if it’s conceivable that the")#linebreak()#text(" probabilistic argument could be “extended” in some sense to give")#linebreak()#text(" an order of magnitude estimate (based on heuristics, probabilistic")#linebreak()#text(" assumptions) for the (smallest) positive integer $N(M, \\epsilon)$ having")#linebreak()#text(" the property: for all $\\alpha$, $\\beta$ in $R/Z$,")#linebreak()#text(" min_{1 <= n <= $N(M, \\epsilon)$ } n || n $\\alpha$ || || n $\\beta$ || < $\\epsilon$ , given the fixed parameter values $M$ and $\\epsilon$ .")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-143564")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2012")])]

#text("[edit: added latex keyword …]")

#text("Dear Professor Tao,")#linebreak()#text(" I’m truly intrigued by your Proposition 2.1 and your probabilistic argument")#linebreak()#text(" for the Littlewood conjecture. Using $latexM$ and $latex\\epsilon$ as in your")#linebreak()#text(" heuristic argument, I’ve been wondering if it’s conceivable that the")#linebreak()#text(" probabilistic argument could be “extended” in some sense to give")#linebreak()#text(" an order of magnitude estimate (based on heuristics, probabilistic")#linebreak()#text(" assumptions) for the (smallest) positive integer $latexN(M, \\epsilon)$ having")#linebreak()#text(" the property: for all $latex\\alpha$, $latex\\beta$ in $latexR/Z$,")#linebreak()#text(" min_{1 leq n leq $latexN(M, \\epsilon)$ } n || n $latex\\alpha$ || || n $latex\\beta$ || lt $latex\\epsilon$ , given the fixed parameter values $latexM$ and $latex\\epsilon$ .")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/#comment-453610")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] sharper estimates here by using the classical theory of continued fractions and Bohr sets, as in this previous blog post, but we will not need these refinements […]")
]
