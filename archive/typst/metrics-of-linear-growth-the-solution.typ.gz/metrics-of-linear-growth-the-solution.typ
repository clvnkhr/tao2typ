// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/
// Converted to Typst by tao2typ: "2026-10-14T10:43:56.607885+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Metrics of linear growth – the solution", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Metrics of linear growth – the solution")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 December 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/")[#text("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the tradition of “")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("Polymath projects")]#text("“, the problem posed in the ")#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/")[#text("previous")]#text(" two blog posts has now been solved, thanks to the cumulative effect of many small contributions by many participants (including, but not limited to, Sean Eberhard, Tobias Fritz, Siddharta Gadgil, Tobias Hartnick, Chris Jerdonek, Apoorva Khare, Antonio Machiavelo, Pace Nielsen, Andy Putman, Will Sawin, Alexander Shamov, Lior Silberman, and David Speyer). In this post I’ll write down a streamlined resolution, eliding a number of important but ultimately removable partial steps and insights made by the above contributors en route to the solution.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{G = (G,\\cdot)}")#text(" be a group. Suppose one has a “seminorm” function ")#mi("{\\| \\|: G \\rightarrow [0,+\\infty)}")#text(" which obeys the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|xy \\right\\| \\leq \\left\\|x\\right\\| + \\left\\|y\\right\\|", block: true)]]

#text("for all ")#mi("{x,y \\in G}")#text(", with equality whenever ")#mi("{x=y}")#text(". Then the seminorm factors through the abelianisation map ")#mi("{G \\mapsto G/[G,G]}")#text(".")
]

#emph[#text("Proof:")]#text(" By the triangle inequality, it suffices to show that ")#tao-math("{\\left\\| [x,y]\\right\\| = 0}", block: false)#text(" for all ")#mi("{x,y \\in G}")#text(", where ")#mi("{[x,y] := xyx^{-1}y^{-1}}")#text(" is the commutator.")

#text("We first establish some basic facts. Firstly, by hypothesis we have ")#tao-math("{\\left\\|x^2\\right\\| = 2 \\left\\|x\\right\\|}", block: false)#text(", and hence ")#tao-math("{\\left\\|x^n \\right\\| = n \\left\\|x\\right\\|}", block: false)#text(" whenever ")#mi("{n}")#text(" is a power of two. On the other hand, by the triangle inequality we have ")#tao-math("{\\left\\|x^n \\right\\| \\leq n\\left\\|x\\right\\|}", block: false)#text(" for all positive ")#mi("{n}")#text(", and hence by the triangle inequality again we also have the matching lower bound, thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\|x^n \\right\\| = n \\left\\|x\\right\\|", block: true)]]

#text("for all ")#mi("{n > 0}")#text(". The claim is also true for ")#mi("{n=0}")#text(" (apply the preceding bound with ")#mi("{x=1}")#text(" and ")#mi("{n=2}")#text("). By replacing ")#tao-math("{\\left\\|x\\right\\|}", block: false)#text(" with ")#tao-math("{\\max(\\left\\|x\\right\\|, \\left\\|x^{-1}\\right\\|)}", block: false)#text(" if necessary we may now also assume without loss of generality that ")#tao-math("{\\left\\|x^{-1} \\right\\| = \\left\\|x\\right\\|}", block: false)#text(", thus ")#metadata(none) <tao-ce48278629c48935b8a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|x^n \\right\\| = \\left|n\\right| \\left\\|x\\right\\|", block: true)]]



#text(" for all integers ")#mi("{n}")#text(".")

#text("Next, for any ")#mi("{x,y \\in G}")#text(", and any natural number ")#mi("{n}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\|yxy^{-1} \\right\\|  & = \\frac{1}{n} \\left\\| (yxy^{-1})^n \\right\\|", block: true)



#tao-math(" & = \\frac{1}{n} \\left\\| y x^n y^{-1} \\right\\|", block: true)



#tao-math(" & \\leq \\frac{1}{n} ( \\left\\|y\\right\\| + n \\left\\|x\\right\\| + \\left\\|y\\right\\|^{-1} )", block: true)
]

#text("so on taking limits as ")#mi("{n \\rightarrow \\infty}")#text(" we have ")#tao-math("{\\left\\|yxy^{-1} \\right\\| \\leq \\left\\|x\\right\\|}", block: false)#text(". Replacing ")#mi("{x,y}")#text(" by ")#mi("{yxy^{-1},y^{-1}}")#text(" gives the matching lower bound, thus we have the conjugation invariance ")#metadata(none) <tao-d1a73570aa079cee4251>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|yxy^{-1} \\right\\| = \\left\\|x\\right\\|.", block: true)]]





#text("Next, we observe that if ")#mi("{x,y,z,w}")#text(" are such that ")#mi("{x}")#text(" is conjugate to both ")#mi("{wy}")#text(" and ")#mi("{zw^{-1}}")#text(", then one has the inequality ")#metadata(none) <tao-50b8d2c3973594d74271>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\|x\\right\\| \\leq \\frac{1}{2} ( \\left\\|y \\right\\| + \\left\\| z \\right\\| ).", block: true)]]



#text(" Indeed, if we write ")#mi("{x = swys^{-1} = t zw^{-1} t^{-1}}")#text(" for some ")#mi("{s,t \\in G}")#text(", then for any natural number ")#mi("{n}")#text(" one has")

#tao-aligned(keep: true)[


#tao-math("\\left\\|x\\right\\|  & = \\frac{1}{2n} \\left\\| x^n x^n \\right\\|", block: true)



#tao-math(" & = \\frac{1}{2n} \\left\\| swy \\dots wy s^{-1}t zw^{-1} \\dots zw^{-1} t^{-1} \\right\\|", block: true)
]

#text("where the ")#mi("{wy}")#text(" and ")#mi("{zw^{-1}}")#text(" terms each appear ")#mi("{n}")#text(" times. From ")#link(<tao-d1a73570aa079cee4251>)[#text("(2)")]#text(" we see that conjugation by ")#mi("{w}")#text(" does not affect the norm. Using this and the triangle inequality several times, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|x\\right\\| \\leq \\frac{1}{2n} ( \\left\\|s\\right\\| + n \\left\\|y\\right\\| + \\left\\| s^{-1} t\\right\\| + n \\left\\|z\\right\\| + \\left\\|t^{-1} \\right\\| ),", block: true)]]

#text("and the claim ")#link(<tao-50b8d2c3973594d74271>)[#text("(3)")]#text(" follows by sending ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("The following special case of ")#link(<tao-50b8d2c3973594d74271>)[#text("(3)")]#text(" will be of particular interest. Let ")#mi("{x,y \\in G}")#text(", and for any integers ")#mi("{m,k}")#text(", define the quantity")

#align(center)[#tao-fit-display[#tao-math("f(m,k) := \\left\\| x^m [x,y]^k \\right\\|.", block: true)]]

#text("Observe that ")#mi("{x^m [x,y]^k}")#text(" is conjugate to both ")#mi("{x (x^{m-1} [x,y]^k)}")#text(" and to ")#mi("{(y^{-1} x^m [x,y]^{k-1} xy) x^{-1}}")#text(", hence by ")#link(<tao-50b8d2c3973594d74271>)[#text("(3)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| x^m [x,y]^k \\right\\| \\leq \\frac{1}{2} ( \\left\\| x^{m-1} [x,y]^k \\right\\| + \\left\\| y^{-1} x^{m} [x,y]^{k-1} xy \\right\\|)", block: true)]]

#text("which by ")#link(<tao-d1a73570aa079cee4251>)[#text("(2)")]#text(" leads to the recursive inequality")

#align(center)[#tao-fit-display[#mitex("f(m,k) \\leq \\frac{1}{2} (f(m-1,k) + f(m+1,k-1)).")]]

#text("We can write this in probabilistic notation as")

#align(center)[#tao-fit-display[#mitex("f(m,k) \\leq {\\bf E} f( (m,k) + X )")]]

#text("where ")#mi("{X}")#text(" is a random vector that takes the values ")#mi("{(-1,0)}")#text(" and ")#mi("{(1,-1)}")#text(" with probability ")#mi("{1/2}")#text(" each. Iterating this, we conclude in particular that for any large natural number ")#mi("{n}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("f(0,n) \\leq {\\bf E} f( Z )")]]

#text("where ")#mi("{Z := (0,n) + X_1 + \\dots + X_{2n}}")#text(" and ")#mi("{X_1,\\dots,X_{2n}}")#text(" are iid copies of ")#mi("{X}")#text(". We can write ")#mi("{Z = (1,-1/2) (Y_1 + \\dots + Y_{2n})}")#text(" where ")#mi("Y_1,\\dots,Y_{2n} = \\pm 1")#text(" are iid signs. By the triangle inequality, we thus have")

#align(center)[#tao-fit-display[#tao-math("f( Z ) \\leq \\left|Y_1+\\dots+Y_{2n}\\right| (\\left\\|x\\right\\| + \\frac{1}{2} \\left\\| [x,y] \\right\\|),", block: true)]]

#text("noting that ")#mi("Y_1+\\dots+Y_{2n}")#text(" is an even integer. On the other hand, ")#mi("Y_1+\\dots+Y_{2n}")#text(" has mean zero and variance ")#mi("2n")#text(", hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#tao-math("f(0,n) \\leq \\sqrt{2n}( \\left\\|x\\right\\| + \\frac{1}{2} \\left\\| [x,y] \\right\\|).", block: true)]]

#text("But by ")#link(<tao-ce48278629c48935b8a6>)[#text("(1)")]#text(", the left-hand side is equal to ")#tao-math("{n \\left\\| [x,y]\\right\\|}", block: false)#text(". Dividing by ")#mi("{n}")#text(" and then sending ")#mi("{n \\rightarrow \\infty}")#text(", we obtain the claim. ")#mi("\\Box")

#text("The above theorem reduces such seminorms to abelian groups. It is easy to see from ")#link(<tao-ce48278629c48935b8a6>)[#text("(1)")]#text(" that any torsion element of such groups has zero seminorm, so we can in fact restrict to torsion-free groups, which we now write using additive notation ")#mi("{G = (G,+)}")#text(", thus for instance ")#tao-math("{\\left\\| nx \\right\\| = \\left|n\\right| \\left\\|x\\right\\|}", block: false)#text(" for ")#mi("{n \\in {\\bf Z}}")#text(". We think of ")#mi("{G}")#text(" as a ")#mi("{{\\bf Z}}")#text("-module. One can then extend the seminorm to the associated ")#mi("{{\\bf Q}}")#text("-vector space ")#mi("{G \\otimes_{\\bf Z} {\\bf Q}}")#text(" by the formula ")#tao-math("{\\left\\|\\frac{a}{b} x\\right\\| := \\frac{a}{b} \\left\\|x\\right\\|}", block: false)#text(", and then to the associated ")#mi("{{\\bf R}}")#text("-vector space ")#mi("{G \\otimes_{\\bf Z} {\\bf R}}")#text(" by continuity, at which point it becomes a genuine seminorm (provided we have ensured the symmetry condition ")#tao-math("{\\left\\|x\\right\\| = \\left\\|x^{-1}\\right\\|}", block: false)#text("). Conversely, any seminorm on ")#mi("{G \\otimes_{\\bf Z} {\\bf R}}")#text(" induces a seminorm on ")#mi("{G}")#text(". (These arguments also appear in ")#link("https://arxiv.org/abs/1610.03037")[#text("this paper of Khare and Rajaratnam")]#text(".)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (141)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490581")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Thanks to everyone who participated! The project ended up being a ")#emph[#text("de facto")]#text(" Polymath project, and played out much as other successful such projects have – with a large number of small observations that, despite some corrections and backtracking, did cause the project to ultimately converge towards a final solution, and in a manner much faster than if just a handful of us were working on the problem.")

#text("The result looks interesting enough (and non-trivial enough) to publish, possibly under the usual “D.H.J. Polymath” pseudonym. (Our tradition in that case is for participants to report their name, affiliation, and (if applicable) grant support) on the corresponding wiki page, rather than being listed in the published paper.); let me know what you all think about this. One should of course look to see if there are any applications or generalisations for the result… maybe Apoorva can tell us a bit more about the motivation for the problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490596")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I just got back from a family gathering to see the problem was finished up.")#linebreak()#text(" Great job everyone, and thanks Terry and Apoorva for giving us this problem to think about!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490622")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("It would be great to have it published, and I’d be happy to help with the writing to the best of my abilities as a member of D.H.J. Polymath.")

#text("(Technically I should be working on things that could please hiring committees. But then again I don’t want to adapt my work to that.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490637")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("I also support publishing, naturally under the psedonym. Tobias: I’m not sure about the exact etiquette, and Terry has more experience, but I’m fairly certain you may include this paper in your list of publications.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490638")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("I include the Polymath papers I was involved in my own “unofficial” list of publications, but my institution doesn’t formally accept them as publications under my name. However, they can still be entered in as “other work”. Also I think it is completely appropriate to list yourself as a contributor to the project in talks, research statements, citations in other papers, etc..")

#text("I’ll start a skeleton draft of a paper on a Dropbox folder later today and share it with you all soon.")

#text("Three unrelated retrospective comments about this project. Firstly, as with Polymath8 (bounded gaps between primes), it seemed to be quite helpful to have a quantitative way of measuring progress. In Polymath8, it was the bound on gaps between primes; here, it was the bound on ")#tao-math("\\left\\|[a,b]\\right\\|", block: false)#text(". Because of this scorekeeping mechanism, it became easier to identify the most promising techniques and focus attention on them.")

#text("Secondly, again as with some previous Polymath projects, computer assistance was quite important, even if the final proof is not visibly computer-assisted in any way. In particular, the crucial “inward repetition” technique (now formalised in the proof of the inequality (3) above) was discovered by deconstructing some inequalities that were computer generated. We’re still some way off from the dream of computers routinely generating large chunks of proofs and/or conjectures for us, but nevertheless they are playing an increasingly essential role in mathematics.")

#text("Finally, I just wanted to observe that the proof techniques here are implicitly using (a variant of) the “")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text("“, which is one of my favourite techniques in analysis, particularly with regards to how it can “magically” eliminate lower order error terms from one’s bounds by taking the tensor power limit ")#mi("n \\to \\infty")#text(".")

#text("For posterity, it might be nice for other participants to record any impressions they had on the project (particularly with regards to any suggestions on how to improve future projects of this type).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490642")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("These are three very informative observations, Terry!")

#text("Speaking of the Wiki page for this Polymath, can it be found on the main Polymath page:")

#link("http://www.michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("http://www.michaelnielsen.org/polymath1/index.php?title=Main_Page")]

#text("or should I be looking somewhere else?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490643")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Yes — on the main Polymath wiki page look for the last item in the section “Polymath-like projects”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490645")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Terry: would you consider trying a source control system (e.g Subversion) instead of dropbox? Our department has a server so I can host the project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490649")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("I think this particular project is simple enough (the paper is likely to just be six or seven pages) that we won’t need more advanced version control, but this is certainly something to consider in the future. (Usually for polymath projects we have a separate planning thread running concurrently with the research in which these things can be worked out, but this particular project started and ended too quickly to set all this up.)")

#text("From my experience, though, while almost all participants are willing to use Dropbox, there are some who are not as keen on using version control such as Subversion (and if one switches to even more sophisticated control systems such as git, then the enthusiasm can dip even lower). Dropbox seems “good enough” for small and medium sized writing projects, particularly if one breaks up files into pieces to help avoid edit conflicts. I certainly agree though that more advanced version control would be desirable if one had a more complicated project (e.g. a monograph).")

#text("Of course, if the other editors of the paper prefer Subversion (or some other platform) over Dropbox, it would be relatively easy to transfer over at this stage.")

#text("EDIT: one thing about Dropbox: it helps if people announce on this blog if they are going to perform substantial edits on a section of the paper, and then to also announce when they are done editing. However, quick minor edits can usually be done without any such announcement (provided that nobody else is claiming a “lock” on the relevant section). This is of course the price one pays for not having more sophisticated version control in place…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490715")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("Firstly, this experience has been truly enjoyable – thanks to everyone for this.")

#text("An observation: one useful feature here was an “adversarial approach” – trying to construct semi-norms positive on commutators, while trying to rule these out. While this is normal in mathematics, it may be easier in polymath projects as it needs fewer mental switches, and also we have a range of attacks based on the ways of thinking of the participants.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490588")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("This solution seems to be from “the Book” !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490591")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Looks like this elegant proof gives a quantitative refinement (applicable in particular to quasi-morphisms) where we replace the triangle inequality by")

#tao-math("\\left\\| xy\\right\\| \\leq \\left\\| x\\right\\| + \\left\\| y \\right\\| + c", block: false)

#text("where we have ")#tao-math("c < \\epsilon min(\\left\\| a\\right\\|, \\left\\| b\\right\\|)", block: false)

#text("If this holds, it is a curious rigidity phenomenon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8461e0132a14b601b9e759b29e8bf55ab18c2e8319bea84c92705f045afceb-2355733f005069d29ef94b3b79978270f4125505ecbb25a228ec7a4084166b3e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490613")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("That was too hopeful, but it looks like the norm of the commutator is bounded by ")#mi("2c")#text(", which for actual semi-norms gives the result.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490610")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Erratum: in the probabilistic inequality no need to take norm of ")#mi("f((0,n)+X_1+\\cdots)")#text(", while in the next sentence it’s ")#mi("\\vert\\cdot\\vert")#text(" that is the Euclidean norm in the plane.")

#emph[#text("[Corrected, thanks -T.]")]

#text("Finally, in the probabilistic context this usage of Cauchy–Schwarz is often called Chebycheff’s inequality, but it’s a matter of taste.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490611")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Sorry — I’m wrong about the name of the inequality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490674")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("I’m still a bit confused about the Cauchy-Schwarz inequality there. How exactly does that work? It’s clear by Jensen’s inequality and the concavity of the square root,")

#tao-math("\\mathbf{E}\\left|Z\\right| = \\mathbf{E}\\sqrt{Z^2} \\leq \\sqrt{\\mathbf{E}Z^2} = \\sqrt{2n},", block: false)

#text("but I don’t see how to do it with Cauchy-Schwarz. Can anyone clear this up?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490680")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("It is simply applied to ")#mi("1 Z")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490614")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Just before the last display in the proof of Theorem 1, you refer to the random variable ")#mi("(0,n)+X_1+\\cdots+X_{2n}")#text(" (call it ")#mi("X")#text(") as having variance ")#mi("\\tfrac{5}{4}n")#text(". But ")#mi("X")#text(" is two-dimensional, so I’m not sure what this means exactly – and in fact, its covariance matrix is not even diagonal. However, by a simple calculation ")#tao-math("\\mathbb E\\left|X\\right|^2=\\tfrac{5}{2}n", block: false)#text(", yielding the (slightly weaker but still sufficient) estimate ")#tao-math("f(0,n)\\leq \\sqrt{\\frac{5n}{4}}(\\left\\|x\\right\\|+\\left\\|[x,y]\\right\\|)", block: false)#text(". Perhaps this was what was intended all along?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("It also seems clearer to call ")#mi("X")#text(" “random vector” (instead of “random variable”)")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Since the random vector is degenerate (its covariance matrix has rank 1), it seems clearer to represent it by")#linebreak()#text(" ")#mi("X = (-1,0) (1/2 +Y) + (1,1) (1/2 - Y) = (0, -1/2) + (-2, 1)Y")#linebreak()#text(" where ")#mi("Y")#text(" is a random variable, taking the values ")#mi("1/2, -1/2")#text(" with probability ")#mi("1/2")#text(" each. Hence")#linebreak()#text(" ")#mi("Z = (-2, 1) (Y_1 + ... + Y_{2 n})")#text(" which implies")#linebreak()#text(" ")#tao-math("f(Z) \\leq (2\\left|\\left|x\\right|\\right| + \\left|\\left|[x,y]\\right|\\right|) \\left|y_1 + ... + y_{2 n}\\right|", block: false)#linebreak()#text(" whose expectation is ")#mi("O(n^{1/2})")#text(".")

#emph[#text("[Suggestion implemented, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490623")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("To get the optimal bound that follows from that method, we could also use the fact that ")#mi("Z=(0,n)+X_1+\\ldots+X_n")#text(" is supported on a one-dimensional subspace, apply the central limit theorem there, and use the known expectation value of the ")#link("https://en.wikipedia.org/wiki/Half-normal_distribution")[#text("half-normal distribution")]#text(". I don’t have time to do this now, but I could do it later.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490633")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("But of course, optimizing the constant is completely pointless, since what we’re showing is that ")#mi("f(0,n)=0")#text(" anyway.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490626")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("First, I am delighted that the problem was solved so fast! I will be happy to make this into a paper, and both options are fine by me: DHJ Polymath with actual names on the Wiki, or all author names in the paper (in the spirit of AIM workshops, say). I am glad to go along with Terry’s preference for a DHJ Polymath paper.")

#text("As Terry wrote above, we should look for (and I think are discussing already on the blog) possible applications, related results, and generalizations. Together with Siddhartha Gadgil (who is also my colleague at IISc), I have collected these “related questions” in my next comment below, and mostly they are solved by now. We may want to include some/all of them in the paper.")

#text("But first, I mention a few remarks re: my motivations. If our result has other applications, say in geometric group theory, I would be very happy to hear about them as well.")

#strong[#text("(1)")]#text(" My motivation comes from a collection of joint works with Bala Rajaratnam, in which we explore stochastic inequalities. For example, in a paper in ")#link("http://dx.doi.org/10.1214/16-AOP1160")[#text("Annals of Probability 2017")]#text(", also available on ")#link("http://arxiv.org/abs/1610.02324")[#text("arXiv")]#text(", we show that the Hoffmann-Jorgensen inequality, which can be stated using only a semigroup operation and a metric, can also be ")#emph[#text("proved")]#text(" using just these tools. (In particular, it holds not only for Banach spaces but also for e.g. ")#emph[#text("non-abelian")]#text(" compact Lie groups.)")

#text("In ")#link("http://arxiv.org/abs/1610.03037")[#text("our preprint")]#text(" Terry cited above, we tackle similarly the Khinchin-Kahane inequality, this time over any abelian metric group. When the group is also “normed” (i.e., the metric has linear growth), we obtain the same sharp constants as in the Banach space case. As it turns out, this is because every normed metric group (or semigroup, monoid…) that is ")#emph[#text("abelian")]#text(", can be isometrically embedded in a Banach space. (There are several consequences of this, including defining expectations of random variables taking values in normed abelian ")#emph[#text("semigroups")]#text("; categorical constructions of these covers, etc.) The proof of this set of embeddings is precisely what Terry has sketched above.")

#text("Now one can ask: what happens if “abelian” is replaced by “non-abelian”, as in the first paragraph? In this case the precursor to any embedding question is existence… and this was not known in general, until this Polymath. (A special case was known: ")#link("http://www.sciencedirect.com/science/article/pii/S0001870876800023")[#text("work of Milnor")]#text(" showed that connected non-abelian Lie groups with linear norms don’t exist.)")

#strong[#text("(2)")]#text(" These embedding questions for abelian (semi)groups into Banach spaces are also connected to nearly additive mappings and separation theorems in functional analysis. See work of ")#link("https://www.impan.pl/en/publishing-house/journals-and-series/dissertationes-mathematicae/all/404")[#text("Cabello Sanchez and Castillo")]#text(", and ")#link("http://pldml.icm.edu.pl/pldml/element/bwmeta1.element.bwnjournal-article-smv100i1p25bwm")[#text("Gajda and Kominek")]#text(", which identify when (linearly) normed abelian groups embed isometrically into Banach spaces.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490629")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Now for the “related problems” involving linear seminorms, which I have compiled together with Siddhartha Gadgil. It turns out that a majority of these are fairly simple observations to make, so we just mention a few remarks.")

#strong[#text("(1)")]#text(" The first involves the “main question”. There are two variants:")

#strong[#text("(a)")]#text(" Does there exist a non-abelian group G with a linear norm (i.e., that is positive outside the identity)?")

#strong[#text("(b)")]#text(" Does every linear seminorm of a group G factor through its (torsion-free) abelianization?")

#text("Note that (a) and (b) are equivalent, as the norm-zero elements form a normal subgroup of G. However, (a) and (b) are not equivalent when restricted to a specific group G. The main theorem above resolves these questions for every group G.")

#text("—-")

#strong[#text("(2)")]#text(" The original theorem was a “rigidity” result (see (1)(b)). However, if we weaken any of the conditions, then either examples exist or the condition turns out to be equivalent to the original problem:")

#strong[#text("(a)")]#text(" If we replace “groups” by “monoids”, then examples indeed exist. Consider [via Robert Young] the free monoid on any alphabet, with the (edit) distance between strings v,w being the least number of single generator insertions and deletions to get from v to w. The triangle inequality and positivity are standard; linearity is trivial; and the bi-invariance ")#mi("d(gxh,gyh) = d(x,y)")#text(" follows by considering ")#mi("\\{g,h\\} =")#text(" {generator, identity}.")

#strong[#text("(b)")]#text(" If we replace “linear growth” by “almost linear growth”, then ")#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490428")[#text("Tobias Hartnick’s two comments")]#text(" show existence.")

#strong[#text("(c)")]#text(" The other case of “almost linear” was ")#tao-math("\\left\\| x^n \\right\\| / n \\to \\left\\| x \\right\\|", block: false)#text(" for all ")#mi("x \\in G")#text(" — but this is clearly linear, by ")#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490458")[#text("Sean Eberhard")]#text(".")

#strong[#text("(d)")]#text(" David Speyer asked ")#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490507")[#text("a different question")]#text(", about which Sean Eberhard has some thoughts. Can this be answered?")

#strong[#text("(e)")]#text(" Although there is no linear norm on a non-abeliam group, it can indeed be defined on finite diameter balls in ")#mi("F_2")#text(". See the discussion/comments following ")#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490403")[#text("this analysis by Terry")]#text(".")

#strong[#text("(f)")]#text(" The final case is when “seminorm” is replaced by “quasi-seminorm with additive constant c” — as ")#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490591")[#text("asked by Siddhartha Gadhil")]#text(". He mentioned to me that he will post more details on this variant, and has done so just a few minutes ago (following this post).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9fe37471f7a934331c4386edf57b5e65a3052f8c3f71b87ae875149b94be71b-20c43104ab6bcb2bd1fdac2268f5abe6c570abc709b9f0b4116fc5b9f2464213.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SH")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490646")[#strong[#text("SH")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Your motivation sounds like the Ribe program for metric groups.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490656")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490627")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("As I mentioned before, a natural extension is to consider linear quasi-semi-norms, i.e., with")

#tao-math("\\left|xy\\right| \\leq \\left|x\\right| +\\left|y\\right| + c", block: false)#text(" for all ")#mi("x, y")

#text("for a fixed constant ")#mi("c")#text(". Examples that do not vanish on the commutator are obtained by taking the norm of a homgeneous quasi-morphism.")

#text("It is easy to see that in this case, the above argument shows that for all elements ")#mi("x, y")#text(" in the group, the commutator ")#mi("[x, y]")#text(" has norm at most ")#mi("2c")#text(". Essentially each application of the triangle inequality gives an extra ")#mi("+ c")#text(" term, so taking the sum of the ")#mi("2n")#text(" random variables gives an extra ")#mi("2nc")#text(" term in the bound of ")#mi("f(0, n)")#text(". Note that this is uniform over all commutators (even commutators of very large elements).")

#text("The above examples show this refinement is essentially sharp.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490630")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("I think you might be a little off: it seems to me that inequality (3) should also have a ")#mi("c")#text(", so you’d lose ")#mi("4nc")#text(" overall.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490636")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Wow!This is really gift for Christmas holiday.Terry,thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490647")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("I’ve started a dropbox folder for the paper at")

#link("https://www.dropbox.com/sh/wg4y7ptahwq3xo1/AABreDLrXH3hniz1jiFTtvska?dl=0")[#text("https://www.dropbox.com/sh/wg4y7ptahwq3xo1/AABreDLrXH3hniz1jiFTtvska?dl=0")]

#text("with the current draft being available as linear.pdf. I have the proof of the main argument (allowing for a loss of ")#mi("c")#text(" in the triangle inequality – I ended up with a net loss of ")#mi("9c")#text(", but perhaps this could be improved). One needs to fill in an introduction and a remarks section – perhaps Apoorva would be willing to start with that?")

#text("If anyone else wishes to help with the editing, send me an email (at ")#link("mailto:tao@math.ucla.edu")[#text("tao@math.ucla.edu")]#text(") and I will be able to give edit privileges to the dropbox folder. (Of course one would need to have dropbox installed on one’s own computer for this.)")

#text("Also, if all contributors could add their name, affiliation, and any grant information to ")#link("http://michaelnielsen.org/polymath1/index.php?title=Linear_norm_grant_acknowledgments")[#text("http://michaelnielsen.org/polymath1/index.php?title=Linear_norm_grant_acknowledgments")]#text(" , that would be great.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490648")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("I’m glad to work on the introduction today morning my time. For now, let me add the contents of my second comment on the latest blogpost, to the remarks file, before I retire. And I’ll add a couple of small edits in blue, to the linear.tex file. As always, people can modify in the next version. I should be done in at most an hour’s time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490650")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Sorry, it took a little more time. I am now done, the latest files are on Dropbox, and my edits are in blue. Please edit the files as you see fit — especially the various results in “related settings”, which are added to the “remarks.tex” file.")

#text("I will add to the Introduction file tomorrow, and hopefully the Abstract goes last of all.")

#text("By the way, I don’t know how we want to work this out – should the next person write a different version number for each file they edit? E.g. remarks-v2.tex, etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490651")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("PS> As you can see in Sections 2,3 –> I refer to an as-yet-unstated theorem from the Introduction. I’m currently inclined for us to state the theorem proved on the blog in the Introduction, and then say that we’ll show the more general quantitative estimate for “quasinorms of commutators” in the next section, before exploring variants in Section 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490652")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("Thanks for this! Dropbox has the ability to view and restore older versions of files, and I doubt there will be many controversial edits to the paper, so I think it won’t be necessary to manually insert version numbers for now.")

#text("I also agree with stating a c=0 version of the main theorem in the introduction and say at some point that we actually prove a more robust version.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490669")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("Thank you for sharing the draft! I don’t have Dropbox installed, and in previous collaborations I have always downloaded and uploaded manually. If this turns out to be a problem, then I’ll be happy to install it.")

#text("As far as I know, the standard term for a “norm” on a group (satisfying the triangle inequality, symmetry ")#tao-math("\\left\\|x^{-1}\\right\\| = \\left\\|x\\right\\|", block: false)#text(" and non-degeneracy is ")#emph[#text("length function")]#text(", so I’ve switched to this in the title, abstract, and introduction. The downside is that this standard term misleadingly suggests a relation to word length. Let me know what you think; I’ll be happy to revert it if you all don’t like it.")

#text("I’m now going through the main text. One thing that I find curious is that we’re not making the symmetry assumption ")#tao-math("\\left\\|x^{-1}\\right\\| = \\left\\|x\\right\\|", block: false)#text(" in Theorem 2.1. As I go along, I will carefully check whether we really don’t need it.")

#text("By the way, is this the right place to discuss the draft or should we do this somewhere else?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490673")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("I am tempted to “initialize git” in the Dropbox folder – those who don’t use git can simply ignore this as if no change was made, but it does help workflow for those of us who do. Is this fine?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490676")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("I am fine with initializing git.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490678")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("I have initialized git, with the understanding that it is used in a way that it can be completely ignored by those who do not want to use it. I")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490682")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("Ah. that’s a nice compromise! Sure, go ahead and do this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490683")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("OK, it should be fine if you upload (or email to one of us) your edits manually, or Siddharta can give you git access if you use that. This post is certainly the best place to discuss the writing of the paper, since the research aspect seems to be largely wrapped up at this point.")

#text("Length functions: sure, if this is the standard term in the literature then we can switch. What I’ll do now is make a macro, say \\norm{x}, for \\ell(x), so if we ever decide later to change notation again then we just need to change that one macro and not the whole text.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490684")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("I’ve now switched the notation over to length functions, and am working on stating a main theorem.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("I am now done editing for now. I changed “linear growth” to “homogeneous”, because of the fact that there are certainly non-abelian length functions (e.g. word metric on free group) in which the length of ")#mi("x^n")#text(" grows linearly with ")#mi("n")#text(", but is not homogeneous.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490657")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2017")])]

#text("To complete the perturbed case , i.e., for quasi-seminorms, (following an earlier idea of Tobia Fritz) it is an immediate consequence of the bound ")#tao-math("\\left\\|[g, h]\\right\\| \\leq 9c", block: false)#text(" for all ")#mi("g, h")#text(" that if ")#mi("l(g)")#text(" denotes the commutator length of ")#mi("g")#text(", i.e., the length of the shortest expression of ")#mi("g")#text(" as a product of commutators, then ")#tao-math("\\left\\|g\\right\\| \\leq 10c l(g)", block: false)#text(".")

#text("Conversely, let ")#mi("x, y")#text(" be the generators and ")#mi("a(g), b(g)")#text(" the corresponding homomorphisms onto ")#mi("\\mathbb{Z}")#text(". We define")

#mi("\\lambda(g) = l(g x^{-a(g)}y^{-b(g)})")

#text("which we see is a quasi-norm. We homogenize this and define")

#mi("\\mu(g) = \\inf(\\lambda(g^n)/n)")

#text("Finally, for a real number ")#mi("c")#text(", we define")

#tao-math("\\left\\|g\\right\\| = c\\mu(g) + \\left|a(g)\\right| + \\left|b(g)\\right|", block: false)#text(".")

#text("What we seem to get is that every quasi-seminorm is essentially bounded by this. Topologically this is nice as it is essentially a Gromov norm (genus of a bounding surface) after making a chain into a cycle using a specific section.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490685")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("Once Terry is done with his edits (which he is carrying out), and since Tobias Fritz and Siddhartha Gadgil have earlier added their edits, I would like to go next (as it is nighttime here and I will soon stop). I’ll quickly work on the “non-Intro” files first, and put them up and report here; and then work at length on the Intro file.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490689")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("The main theorem looks very nice! Also, I am done with my edits for now (as it is late here), and have uploaded the files back to Dropbox. I couldn’t get to adding to the Introduction and then to the Abstract, but should be able to do so on Sunday.")

#text("I also found a possibly incomplete argument on page 7. Finally, I was also thinking of alluding to (Naor’s survey of) the Ribe program in the introduction; if anyone can say more about this, please consider revising the file after my edits tomorrow.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490690")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("I clarified the argument on page 7: the point is that the abstract construction ")#mi("G \\otimes_{\\bf Z} {\\bf R}")#text(" of a vector space containing ")#mi("G")#text(" may not necessarily be compatible with any pre-existing embedding of ")#mi("G")#text(" into a vector space. In particular, if ")#mi("G = \\langle 1, \\pi \\rangle \\subset {\\bf R}")#text(", then ")#mi("G \\otimes_{\\bf Z} {\\bf R}")#text(" is not embedded into ")#mi("{\\bf R}")#text(", in fact it is a two-dimensional space. In particular, in ")#mi("G \\otimes_{\\bf Z} {\\bf R}")#text(", the two generators ")#mi("1,\\pi")#text(" of ")#mi("G")#text(" are linearly independent over ")#mi("{\\bf R}")#text(", even though they were not linearly independent in the pre-existing embedding.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490691")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("Great! After uploading the files, it occurred to me to simply use the triangle inequality and reduce the question to the real-span of a single element, for which it follows from homogeneity in a one-dimensional Banach space. Anyway – your footnote-2 captures and clarifies the key point very well.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490695")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2017")])]

#text("I made a picture of the curves x, y, z and w in the iterated cancellation lemma, which is at ")#link("https://github.com/siddhartha-gadgil/Superficial/blob/master/xywz.jpg")[#text("https://github.com/siddhartha-gadgil/Superficial/blob/master/xywz.jpg")]#text(" and also in the Dropbox folder.")

#text("The curves are on a 2-holed Klein bottle, obtained by identifying the two boundary components labelled x.")

#text("It is not clear to me if this picture illuminates anything but (like the computer calculations) smarter people may be able to get something from it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490709")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("I have written the quasi version, and am stopping for now. I am using git locally, so I am editing in parallel but will ensure that I do not mess up with parallel editing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490718")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("Following the edits of Tobias and Siddhartha, I made a few minor edits and re-uploaded the various TeX files. I will work on the introduction tomorrow morning my time (i.e. today evening US time).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490731")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("I started editing the files about an hour back, and finished all but the Introduction, on which I will work now. That said, all five files are re-uploaded to Dropbox. Apart from editing small typos (like yesterday), I added a global macro \\free to use in place of free groups – thus far we only use \\free{2}.")

#text("Here is a further question: in Corollary 1.2, we show that if a group has a homogeneous length function, then it is abelian and torsion-free, and by the main theorem, it embeds isometrically inside a Banach space. The converse is immediate. Now I’m wondering: which (abelian, torsion-free) groups admit homogeneous length functions? If G is finitely generated then it is free, hence we are good; and if G has Prufer rank 1 then I think it embeds inside ")#mi("\\mathbb{Q}")#text(". What happens more generally? E.g. there’s an old paper by Baer in [")#link("https://doi.org/10.1215%2FS0012-7094-37-00308-9")[#text("Duke 1937")]#text("], but I am not an expert in this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490733")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("I think every abelian torsion-free group admits a homogeneous length function; the arguments in the paper already embed such a group in a real vector space, and an easy application of Zorn’s lemma shows that every vector space admits at least one norm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490734")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2017")])]

#text("Aha, a very satisfying conclusion! Let me add that as well to the Introduction, as I continue editing. (I assume we will soon run out of additions, at which point someone – Terry perhaps? – could go through the paper, and reorganize, polish, and make the writing style “homogeneous” (sorry for the choice of word).)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490745")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("I am now done adding to the Introduction and also some minor edits to the files. This ends my additions to all files (for now). Please feel free to reword/condense/polish/remove etc.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490741")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Just wanted to point out that it seems Proposition 2.1 (the “key proposition”) in the dropbox file can be recast as an inequality for arbitrary non-negative functions ")#mi("\\ell")#text(" on a group ")#mi("G")#text(":")#linebreak()#text(" ")#mi("\\sup_{x,y\\in G}\\ell([x,y])\\leq 9\\max\\{\\inf_{x,y\\in G}\\ell(xy)-\\ell(x)-\\ell(y),\\inf_{x\\in G}2\\ell(x)-\\ell(x^2),0\\}")#text(". Also, a careful inspection of the proof could yield local versions of this inequality – one could start by bounding ")#mi("\\ell([x,y])")#text(" for specific ")#mi("x,y\\in G")#text(" by the corresponding quanties where the infima are taken over the subgroup generated by ")#mi("x,y")#text(" rather than all of ")#mi("G")#text(", for instance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490747")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Very nice! Also, shouldn’t the local version follow then as the special case ")#mi("G = \\langle x,y \\rangle")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490755")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Does the result extend to groupoids? Of course the doubling condition doesn’t make sense, but one could require instead, in addition to conjugacy invariance, that for all ")#mi("x")#text(", there exists ")#mi("y")#text(" such that ")#mi("l(xy) = l(x)+l(y)")#text(". Does it work for groups already? (maybe trivially not)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490760")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Well, if ")#mi("\\ell(e)=0")#text(" then there always exists a ")#mi("y")#text(", just take ")#mi("y=e")#text(". Or, if one insists on ")#mi("y")#text(" the same length as ")#mi("x")#text(", one can take the usual word length on the free group on two generators, then for every ")#mi("x")#text(" there will be a ")#mi("y")#text(" of the same length such that ")#mi("\\ell(xy) = 2 \\ell(x)")#text(".")

#text("In Section 4.1 of the draft there is an observation that the edit distance on free monoids is a non-trivial homogeneous length function, so the ability to take inverses is crucial in the main theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490761")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Ah right, ")#mi("y")#text(" should not be the identity indeed. But the word metric isn’t bi invariant or am I confused?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490763")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("To clarify the (maybe stupid) intuition for the above relaxed doubling condition, I was thinking of a generalization of the following form:")

#text("Consider a length space with a transitive isometric action such that each point has trivial stabilizer. Assume also that any minimal geodesic can be extended infinitely while remaining minimal. Is the group necessarily commutative?")

#text("I think this is more or less equivalent to the relaxed condition above.")#linebreak()#text(" Perhaps this generalization is obviously false or useless, but I was feeling that since the original question had a geometric flavor, maybe it made sense to formulate a more geometric version.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490764")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("by minimal geodesic I mean a geodesic that realizes the distance. Maybe minimizing geodesic is better")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490765")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("ok this is stupid, conditions are too weak, a tree would work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb0a71765196659e162d8c30dfac03b19ec39db75b7a7ee8f5d6f82b5856de5-2c3f53f192e2e259a7800115331de63b1b5a17d334c7847e4b3d14828985e947.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrey")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490766")[#strong[#text("Andrey")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Do you think a version of this theorem could hold for stably unbounded quasi-norms on F_2 in the sense of Burago-Ivanov-Polterovich?")

#link("https://arxiv.org/abs/0710.1412")[#text("https://arxiv.org/abs/0710.1412")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490769")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("If you send the two generators to two generic symmetric matrices, you get a linear representation of ")#mi("F_2")#text(". Now the logarithm of the condition number pulls back to a quasi-norm. Generically, all obtained matrices have at least two eigenvalues, implying that the quasi-norm is stably unbounded (unless I’m mistaken).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490772")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Just got done with some minor edits. For instance: at the very end of the proof of the splitting lemma, I changed ")#mi("2n-1")#text(" to ")#mi("2n+1")#text(" to account for the two extra ")#mi("c")#text("‘s coming from splitting off the ")#mi("s, t^{-1}")#text(" at the beginning and ending of ")#mi("x")#text(". (Someone want to double-check I got that right?)")

#text("I also made it so the equation numbering and theorem numbering was sequential. I personally like this, to make it easier to find numbered equations, but if anyone is opposed to this change, it can easily be changed back.")

#text("I think everything else was minor and non-controversial.")

#text("As I was reading through the paper I didn’t understand the paragraph starting “To rectify the situation…” Perhaps someone could clarify this paragraph a bit more.")

#text("There is a reference to [5, Theorem B]. There doesn’t appear to be a Theorem B in that paper. Was that supposed to be 8?")

#text("In the bounds on Proposition 4.5 (under the new numbering): Shouldn’t the constant c show up on the RHS (in both inequalities)?")

#text("Finally, at the end of the paper, it appears that additive and multiplicative notations are being used simultaneously.")

#text("[If there is a better place to put these comments than on the blog–say somewhere in the dropbox folder–please feel free to move them there.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490773")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("@Pace:")#linebreak()#text(" Thank you for the edits and finding these polishings! I added the paragraph “To rectify the situation…” in order to mention various attempts that were made to attack the problem, consulting Siddhartha Gadgil to some extent. But of course I am not an expert and my language is subject to much improvement, I’m sure. So please feel free (applies to others as well) to rephrase / do major edits / etc. Ditto for the remainder of Section 1.")

#text("Also, I verified your calculation and it seems correct to me.")

#text("I’m fine with either mode of equation numbering, so will leave what you have done as is. (I used to prefer this scheme as well.)")

#text("I can correct the additive notation at the end of the paper.")

#text("Finally, the reference to [5, Theorem B] should be to [7, Theorem B]. I will make these edits (and also a few more I had located as I re-read through the paper), in about 3-4 hours when it is safe to assume it’s late in the US.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490791")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("@Apoorva: Thanks for making those changes!")

#text("—————-")

#text("@All: In Proposition 4.5, shouldn’t the first inequality read ")#mi("\\ell(g)\\leq (10\\,{\\rm cl}(g)-1)c")#text("? [To take into account the extra ")#mi("c")#text("‘s coming from breaking apart the product of commutators, in order to apply Proposition 2.1.] If so, similar changes would need to be made to the second inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490798")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("Fixing that now. (Also made a number of other minor edits, mostly with regards to harmonising notation.)")

#text("I’m trying to verify the claim after Prop 4.5 in which it is asserted that all conjugacy invariant length functions obey ")#tao-math("\\ell([a^k,b^m]) \\leq \\min( \\left|k\\right| \\ell(a), \\left|m\\right| \\ell(b) )", block: false)#text(", and that this is best possible. I can only get the upper bound of ")#tao-math("2\\min( \\left|k\\right| \\ell(a), \\left|m\\right| \\ell(b) )", block: false)#text(", and I am not sure how to establish the matching lower bound. Anyone have any thoughts on this?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490932")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("I have written details. A reference is arXiv:0809.3110 (but I have not cited this).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("Great! I’ve added the citation and corrected some small typos.")

#text("One consequence of our argument is that for ")#mi("\\ell")#text(" the minimal deficiency as constructed in your text, the quantity ")#mi("2 \\ell(x) - \\ell(x^2)")#text(" must be unbounded, however I cannot think off-hand of a simple example of a sequence of words ")#mi("x")#text(" that exhibit this unboundedness. This can be extracted eventually from the proof of our main theorem, but I wonder if there is a simple example. I was at least able to find a short instance of non-homogeneity: ")#mi("[a,b]")#text(" has minimal deficiency 2, but ")#mi("[a,b]^3")#text(" has minimal deficiency 4 (indeed, this latter fact is implicitly why we have our very first bound ")#mi("\\ell([a,b]) \\leq 4/3")#text(" for homogeneous length functions).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490967")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2017")])]

#text("Ah, I think I have the explicit demonstration of unboundedness of ")#mi("2\\ell(x)-\\ell(x^2)")#text(": I believe the word ")#mi("[a^n,b^n]^2")#text(" has minimal deficiency ")#mi("4n")#text(", but ")#mi("[a^n,b^n]^4")#text(" has minimal deficiency ")#mi("6n")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490784")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("I uploaded a revised version, small edits as promised. [And I am done for now.] In particular, for now I changed “To rectify the situation” to “In attempting to construct homogeneous length functions on F_2”. But of course, please feel free to still “majorly revise” if it improves the exposition.")

#text("Also, I took a look at the additive notation being used for \\varphi at the end of the paper, and I think it is fine, since it takes values in the abelianization of G. Is there a problem here or (is additive notation being used) somewhere else?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0d29e4f48d8dd05f338094104105691334d1c176d2ddf7fca700a2c7735ab26-f4060364402c5368976e45c14a55302a5a7ba371f9cfb19d1d59d19a7e058216.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E. Ben-David")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490810")[#strong[#text("E. Ben-David")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("A simple observation: In Proposition 1.6. there is no need to assume that ")#mi("G")#text(" is a topological group and the map ")#mi("\\| \\|")#text(" is continuous. Both these are immediate from (a)-(c). The proof follows from the fact that ")#mi("d(x, y)=d(x^{-1}, y^{-1})")#text(" and the triangle inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490811")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("Thanks Emanuel! Indeed I had written “(topological)” in the very next line after the Proposition, for the reason that you mention. I’ll tell my co-author Bala of your comment, and change it in our paper [5] (and here as well).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490812")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("I made some more edits – am done for now. Notably, the Main Proposition does not require assuming that the constant ")#mi("c")#text(" is non-negative, since this can be deduced from the hypotheses, see Remark 2.13. (But moreover, is this fact actually used in the proof?) I have added this and a “local” version of the Proposition, in Remark 2.13.")

#text("Other changes:")#linebreak()#text(" * Changed \\backslash to \\setminus globally.")#linebreak()#text(" * Removed “topological” to reword Proposition 1.6 and the subsequent sentence.")#linebreak()#text(" * Minor edit to the text after “Inserting this”, in the proof of the Splitting lemma, to clarify Pace’s recent observation.")#linebreak()#text(" * In defining ")#mi("G \\otimes_{\\mathbb{Z}} \\mathbb{Q}")#text(", corrected a couple of typos. I also added a footnote to perhaps clarify the (abundance of) notation in the paragraph; we can decide to remove it, retain it, or integrate it into the text; and of course, reword it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490814")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("PS> Suppose ")#mi("G = \\langle a,b \\rangle")#text(" is non-abelian, and we want a bound on ")#mi("\\ell([a,b])")#text(" as in the Main Proposition. Would it be (somewhat) related to consider how close one can get to the number 9 in the Proposition, for various classes of functions ")#mi("\\ell")#text("? Stated via Remark 2.13, for length functions we get 0 instead of 9; and for homogeneous quasi-morphisms we get 3 (Section 4.2).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490831")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("I’ve made some further edits to the draft. Let me also list the most significant ones, so that somebody else can take a look at this summary and double-check my edits if necessary.")

#text("* I’ve uniformized the notation of Proposition 1.6 with the rest of the paper.")#linebreak()#text(" * Added some explanation of what ‘Kobayashi-type construction’ means (after consultation with Apoorva).")#linebreak()#text(" * Mention of the Ribe program is now at the very end of Sec 1.2.")#linebreak()#text(" * In Remark 2.13, I’ve removed the additional display giving the bound on ")#mi("\\ell([x,y])")#text(" in terms of the subgroup ")#mi("\\langle x,y\\rangle")#text(", since it was verbatim almost the same equation, and only expressed the idea in words.")#linebreak()#text(" * In the first paragraph of Section 4, I’ve required ")#mi("m")#text(" to be positive, since the argument that we make there would not work for negative ")#mi("m")#text(".")#linebreak()#text(" * In the final paragraph of Section 4.2, I’ve replaced ‘linear growth’ by homogeneous, and also rephrased the final sentence.")#linebreak()#text(" * In the second item after Proposition 4.5, I’ve added the factor of 2 that Terry ")#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490798")[#text("was missing")]#text(", and also included symmetry as another assumption.")#linebreak()#text(" * I’ve streamlined the argument in the last few paragraphs a bit and tried to clarify what we do there.")

#text("There’s one remaining \\todo after Proposition 4.5, where (as Terry pointed out) we haven’t explained how to achieve the bound. My guess is word length with respect to conjugates of generators, but I haven’t thought hard about how to prove it. Does anyone know how to do this?")

#text("Otherwise, I’m personally quite happy with the paper now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490832")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("Here’s a more abstract perspective on Theorem 1.2 that I’d like to mention in case that somebody else finds this enlightening as well. Consider ")#mi("MetGrp")#text(", the category of groups equipped with a pseudo-length function, where the morphisms are length-nonincreasing homomorphisms; and let ")#mi("Ban")#text(" be the category of Banach spaces with linear maps of norm at most 1. Then the forgetful functor ")#mi("Ban\\to MetGrp")#text(" has a left adjoint that sends every group ")#mi("G")#text(" to the completion ")#mi("\\overline{G/[G,G]\\otimes\\mathbb{R}}")#text(" with respect to the pseudonorm induced from the pseudo-length function on ")#mi("G")#text(".")#linebreak()#text(" What we’ve shown is that the unit of the adjunction ")#mi("G \\to\\overline{G/[G,G]\\otimes\\mathbb{R}}")#text(" is an isometric embedding if and only if the pseudo-length function on ")#mi("G")#text(" is homogeneous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490838")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("This is a nice observation – and thanks also to Tobias for making the above changes.")

#text("I just now made 2-3 small changes, and also made the bibliography alphabetical. (I am done for now.) Once the remaining pending to-do is resolved — likely over the weekend — I am also happy with the paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8461e0132a14b601b9e759b29e8bf55ab18c2e8319bea84c92705f045afceb-2355733f005069d29ef94b3b79978270f4125505ecbb25a228ec7a4084166b3e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sgadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490878")[#strong[#text("sgadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2017")])]

#text("I should clarify that by essentially sharp I meant up to constant, I believe 9 in this case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490929")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("Sorry for staying out of the editing; getting dropbox to work on my idiosyncratic set-up would have been too much work. I really like the writing; a couple of remarks in case someone wants to put them in.")

#text("– Footnote 1: I think the word “length metric” should appear here somewhere.")

#text("– Remark 2.8: I wouldn’t say the observation is “superseded” by Theorem 1.2, since it is a component of its proof.")

#text("I’m thinking about “todo” example for Prop 4.5.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490926")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("I’ve gone through the paper a final time. Except for the last issue of actually constructing a length function on the free group which is large on ")#mi("[a^k,b^m]")#text(", I think we are basically ready to submit and put on the arXiv.")

#text("We haven’t yet discussed what journal to send the article to. A group theory journal might be appropriate, and the obvious one here would be the Journal of Group Theory. (The Journal of Algebra is Elsevier, which I am still boycotting.) I note that two of our references come from L’Enseignement")#linebreak()#text(" Math\\’ematique (albeit from 20+ years ago); this journal does seem to have a somewhat geometric group theory nature to it, so it might also be a possibility. Somewhat more ambitious would be Algebra and Number Theory, but this journal is fairly selective. Anyone else have any suggestions or preferences?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490931")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("A couple of Journals where Geometric Group theory stuff appears are “Algebraic and Geometric Topology” (e.g. Peter Scott as corresponding editor) and “Geometria Dedicata”. Another is “Journal of Topology and Analysis”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490938")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("It is obviously up to those involved, but I find it a bit odd that people boycotting Elsevier seem relatively happy to submit to De Gruyter, who have long been no strangers to price-gouging, well-before the era of blogs.")

#text("Why not support one of the new-ish diamond-OA journals? Or something from the MSP stable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490940")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("Algebra & Number theory, which was another of my suggestions, is MSP. I did notice that J. Group Theory is de Gruyter, and this journal wasn’t my top choice, but it was the journal whose subject area most closely aligned with this specific paper, so I felt it should be mentioned as an option.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490930")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("I have written the final “todo” example and copied to Dropbox and thanks to everyone for the elegant writing (including greatly improving what I had written earlier).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490933")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("My apologies for being out of action for 4 days (especially not clarifying the todo example) – I was travelling without a laptop, and with spotty internet. Thanks again all for the elegant writing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490936")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("I’ve just completed a few minor edits (and am done for now), including adding journal/page-references to the recently added citation. The paper looks good now.")#linebreak()#text(" A quick question: can we make the font 11pt instead of 12pt unless people feel strongly for 12pt? (This would bring the pagecount down to 14, in case this matters for making the change or not.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490939")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("Sure, this is fine with me, though it may well be moot if the journal we end up submitting to has a house style.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490941")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("Thank you – I have now changed the font size, and globally changed := to \\coloneqq in all files (and spell-checked them too). Also: point taken journal house styles (though e.g. AMS journals have 11pt).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-490945")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2017")])]

#text("And I’ve just removed the two drafting packages, showkeys and todo.")

#text("I can’t comment much on the journals discussion due to lack of knowledge of journals in this area.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491008")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2018")])]

#text("I gave the preprint another read-through and will make some minor typographical changes tonight, but had a few questions in the meantime.")

#text("1. Is there a reason we haven’t used the classification # 20F65? It seems like a good fit for our paper.")

#text("2. Is there a quick reference to the identity claimed in Example 1.4 for nilpotency class 2 groups? I am personally unfamiliar with this fact, and couldn’t find a proof by a quick google search. Or is it just really easy to prove and I just haven’t seen it yet?")

#text("3. Would people be okay with replacing the paragraph starting “In attempting to construct…” at the end of subsection 1.1 with something much shorter like: “Our initial attempts to construct homogeneous length functions on F_2 all failed in light of our main result. However, many of these methods work under minor weakenings of the hypotheses, such as working with monoids rather than groups, or weakening homogeneity. Results in these cases are discussed further in Section 4.”")

#text("4. In Remark 2.13 it says, parenthetically, “Equality is attained for Banach spaces.” I didn’t understand this sentence, as I haven’t seen any argument that the constant 9 has been optimized. Does this sentence need to be removed/modified?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491011")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2018")])]

#text("I am fine with both #1 and #3 either way (although I am not an expert in GGT, and hence will defer to more expert opinions).")

#text("Re: #4, I put that clause in to point out: here is an inequality, and if the reader is wondering whether it’s always strict, the answer is: no. I would have put in such a parenthetical remark even if the 9 was replaced by a better constant… because we present an inequality, and hence say whether or not it is strict. How would you propose to update this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491012")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2018")])]

#text("@Apoorva: Re #4: I think I see now what you were trying to say there, and the sentence is fine as it stands! However, we could instead say something like “If ")#mi("\\ell")#text(" is a homogeneous pseudo-length function, then both sides are zero, so equality can hold.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491014")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2018")])]

#text("Ah, did not know about 20F65! Sure, we can add that to the classification. #3 is also fine with me.")

#text("For #2, this follows from the fact that the commutator map ")#mi("(g,h) \\mapsto [g,h]")#text(" is a bihomorphism from ")#mi("G \\times G")#text(" to ")#mi("[G,G]")#text(" for nilpotent groups of nilpotency class two (see e.g. ")#link("https://math.stackexchange.com/questions/1970022/commutator-in-nilpotent-group-of-class-2-is-bilinear")[#text("https://math.stackexchange.com/questions/1970022/commutator-in-nilpotent-group-of-class-2-is-bilinear")]#text(" , I do not know of a more formal reference but presumably it would likely be in any basic group theory text). The way I think of it is that every time one tries to interchange ")#mi("g")#text(" and ")#mi("h")#text(" one creates a factor of ")#mi("[g,h]")#text(" somewhere, so if one wishes to interchange ")#mi("g_1 g_2")#text(" with ")#mi("h")#text(" one creates factors of ")#mi("[g_1,h]")#text(" and ")#mi("[g_2,h]")#text(". These factors are in different locations (leading to the identity ")#mi("[g_1 g_2,h] = [g_2,h]^{g_1} [g_1,h]")#text(" in general) but in the nilpotency class 2 case, all commutators are central and so we conclude that ")#mi("g \\mapsto [g,h]")#text(" is a homomorphism. It’s also instructive to work things out explicitly in the case of the Heisenberg group.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491029")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2018")])]

#text("A few edits from me (and I’m done for now). The following additions might probably benefit from a little polishing, please check:")

#text("* Page 2: I added one line about the bihomomorphism to the Heisenberg group remark.")

#text("* Page 10: Added one sentence preceding Remark 3.1.")

#text("* Page 7: Added a sentence at the end. Essentially, our main proposition is in terms of a constant ")#mi("c")#text(", and I think we should observe (here in this Remark — or earlier? Or both?) that the only way to get ")#mi("c=0")#text(" is for Banach spaces. [I also slightly updated the sentence “(Both sides are…)”.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491038")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2018")])]

#text("Looks good to me, except for the new sentence on p.7 (at the end of Remark 2.13), which had the minor issue that embedding the torsion-free abelianization of ")#mi("G")#text(" into a Banach space will only yield those ")#mi("\\ell")#text(" that are strictly positive on nontrivial elements of that torsion-free abelianization. So I’ve rephrased this in terms of group homomorphisms to Banach spaces. (If somebody can think of a better formulation, please go ahead.)")

#text("I’ve also removed most of our comments in the source code in order to prepare for arXiv upload.")

#text("I really like how the new sentence before Remark 3.1 is phrased: those readers who know enough category theory will understand it immediately as a precise statement with formal meaning, while those readers who don’t will instead take it as a vague intuitive explanation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491053")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2018")])]

#text("Here’s a quick question, possibly regarding that pesky factor 9: since we’re going to work with asymptotic multiples anyways, what if we replace our “super-additivity” in the main Proposition (see Equation (2.3)) by")

#text("\\ell(x^k) \\geq k \\ell(x) – c")

#text("for a larger value of k than 2? Recall by e.g. our reference [9] (or maybe [6] as well) that for c=0 this is also equivalent to the case k=2 for any length function; and hence guarantees homogeneity.")

#text("Thus, I think the proof of the Main Proposition should still go through with the changed assumption above (but it is 3:45am here), and I am wondering if we would get a smaller factor f(k), where f(2)=9? Or do things actually get worse…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491054")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2018")])]

#text("PS. A slight quantitative refinement: why not consider in fuller generality, the inequality")

#mi("\\ell(x^k) \\geq k\\ell(x) - c^{\\prime}")

#text("instead of using the same constant ")#mi("c")#text(", and with general ")#mi("k \\geq 2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491057")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2018")])]

#text("I think the use of ")#mi("c^{\\prime}")#text(" is fine, but the inequality for ")#mi("k>2")#text(" is too strong/rigid/tight as is… Replacing ")#mi("c^{\\prime}")#text(" by ")#mi("k \\cdot c^{\\prime}")#text(" might be better. So perhaps my broader question is, what is the “correct regime” for the lower bound on ")#mi("\\ell(x^k) - k \\ell(x)")#text(". I didn’t verify, but offhand it appears to be linear in ")#mi("k")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8461e0132a14b601b9e759b29e8bf55ab18c2e8319bea84c92705f045afceb-2355733f005069d29ef94b3b79978270f4125505ecbb25a228ec7a4084166b3e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sgadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491058")[#strong[#text("sgadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2018")])]

#text("As in the original case (c=0), induction gives a condition for powers of 2, given the condition for squares. Also, by the triangle inequality (which is coarse in this case), a bound for ")#mi("m")#text(" gives one for ")#mi("n<m")#text(".. Hence we get a bound for all ")#mi("n")#text(" given the square condition.")

#text("From an expository point of view, I feel we should stick to square. Also a constant such as 9 I feel is inevitable given the quantifiers, we should just make sure there is no statement that suggests this constant is 1.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491059")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2018")])]

#text("For exposition etc., I am perfectly happy to stick to square. My explorations were in order to understand just how much “additive leeway” our length function is allowed, and still yield the desired bound for ")#mi("c=0")#text(". And of course, to check where else length functions with just so much leeway occur.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491118")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2018")])]

#text("I made a few changes. The most notable change is that given the “morally separate” bounds for sub-additivity and doubling of the length function, there is no reason to use the same bound ")#mi("c")#text(" in Equations (2.2) and (2.3). So I reworked the entire proof using two different constants. It wasn’t difficult to redo, but it would be nice if someone could double-check this section for completeness.")

#text("A couple of other points: first, in (what is now) Remark 2.14, I had written expressions like ")#mi("2 \\ell(e) - \\ell(e^2)")#text(", where ")#mi("e")#text(" denotes the identity in ")#mi("G")#text(". But then ")#mi("e^2 = e")#text("! So I have updated that slightly. Please feel free to reword or trim.")

#text("Second, I introduced Remark 2.13 to address the question I’d raised earlier, after discussing it with Siddhartha Gadgil. The point is that we don’t gain anything compared to the ")#mi("k=2")#text(" case.")

#text("Finally, I didn’t update the (final) Section 4 in light of the ")#mi("c,c^{\\prime}")#text(" update – I think most of the section remains unchanged, but Proposition 4.5 needs updating of course. So please can someone do the needful, thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491120")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2018")])]

#text("I quickly double-checked it and it looked good to me.")

#text("I would recommend changing both instances of ")#mi("\\forall")#text(" to the words “for each”. (In general, in a paper, one should use the words rather than the symbols, especially in inline text.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491121")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2018")])]

#text("That sounds good to me, @Pace. When someone edits the last subsection, please can you make these two changes as well, thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491125")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2018")])]

#text("I’ve made the changes and also updated the remarks section with the new constants (e.g. the commutator bound for quasimorphisms now has a bound of 4 rather than 9, getting closer to Bavard’s bound of 3).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491128")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2018")])]

#text("Great! In that case, perhaps a”pre-baby step” might be to check if our proof can be slightly upgraded to reduce our 4 to 3 as well (maybe also assuming that the defect of ")#mi("\\ell")#text(" is bounded?). My guess being that if we combine some of the intermediate lemmas, we may be able to get closer to 3. (Of course, I’ll add that I am happy to stop at the present point as well.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491123")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2018")])]

#text("Here’s one more question one might want to ponder: are the constants 4,5 in the “Main Proposition” optimal? Of course for the given “length” problem this doesn’t matter, but it does for “quasi-lengths”. In this case, a baby step is to first ask if the “Approximate conjugation invariance” = Lemma 2.7 has sharp constants ")#mi("c+c^{\\prime}")#text(". One checks explicitly in its proof that")

#mi("\\ell(y x y^{-1}) \\leqslant \\ell(x) + c + c^{\\prime} + \\frac{\\ell(y) + \\ell(y^{-1}) + c - c^{\\prime}}{n}, \\ \\ \\forall n \\geqslant 1")#text(".")

#text("So the question here is: for each integer ")#mi("n \\geqslant 1")#text(", can one find a group and a function ")#mi("\\ell")#text(" that satisfies this inequality with equality, where ")#mi("c,c^{\\prime}")#text(" are precisely the suprema in Equation (2.15) ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491163")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2018")])]

#text("Also, are there any connections to ")#link("https://en.wikipedia.org/wiki/Cancellative_semigroup")[#text("cancellative semigroups")]#text(" that we may want to elaborate upon? E.g., note that the free monoid on two generators (with the bi-invariant homogeneous metric that we mention) is cancellative. Can we show that it does not embed into any group?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491164")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2018")])]

#text("The free monoid on two generators embeds naturally into the free group on two generators (sending generators to generators). Perhaps I’m misunderstanding your question?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491165")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2018")])]

#text("Ah that’s right, and I see that’s all that is required for the cancellation property. Somehow, I thought of that but was seeking a metric on F_2 for which we get an *isometric* embedding. But of course, that’s a separate question than the embedding problem for cancellative semigroups.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491167")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2018")])]

#text("Or rather, it’s the embedding question in a smaller category: that of cancellative *metric* semigroups. The point is that the free monoid on any set with at least two elements…")

#text("* does embed in the category of (cancellative semigroups + semigroup maps as morphisms) — into the free group on the same generating set (as Pace said); and")

#text("* does not embed into any object, in the category of (cancellative metric semigroups with bi- invariant metrics + isometric semigroup maps as morphisms).")

#text("Now since I was talking about embedding the semigroup, I thought to not touch the morphism part, and only change the category to the intermediate one: cancellative metric semigroups. Hence my question.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491168")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2018")])]

#text("PS. Again, oops. I meant *homogeneous length functions* when I said “bi-invariant metrics” in the “does not embed” part. But then, perhaps my question does have an answer? Namely, is it true that the bi-invariant metric on FreeGroup(X) (= smallest length in terms of X, their inverses, and *all their* conjugates) extends the metric on FreeMonoid(X) that we mention?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491196")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2018")])]

#text("Following some discussions with Tobias, I’ve added “footnote 4” on page 11 (and am done for now). Of course, I am not an expert on quasi-morphims, so if someone could please improve (and perhaps relocate) it, that would be great.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491197")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2018")])]

#text("I’m not an expert on quasi-morphisms either, but it looks good to me!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491198")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2018")])]

#text("I heard from both Tobias and Siddhartha about my footnote 4 being fine. Siddhartha also explained to me the solution to my question about the bi-invariant metrics in the free monoid vs. free group. So I now plan to add a few remarks, and share with everyone.")

#text("If someone is editing the file, please let me know at khare @ iisc.ac.in and I can not even start editing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491200")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2018")])]

#text("I have now completed my edits – they are in blue on pages 10, 11, 12, 14, including the footnote previously added “today”. As Siddhartha explained, the non-crossing matchings and minimal deficiency show up in the proof of Proposition 4.1 now, which is before their previous location; thus I moved that exposition up (this explains the edits on page 14). To conclude, here’s my standard disclaimer: please feel free to reword, relocate, or even undo these edits if the new additions are felt to be removable. [And yes: once these edits are incorporated, I am – once more! – happy with the paper.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491201")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2018")])]

#text("Sorry, I am now done, after making a couple of small edits.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491221")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2018")])]

#text("After inputs from Siddhartha Gadgil, I added reference [3] by de Bruijn and Erdos, which is cited on page 12 (in blue, just after Equation (4.2)) and on page 15, also in blue. The point is that if the length is sub-additive, then ")#mi("\\lim_n \\ell(g^n)/n")#text(" exists for all ")#mi("g \\in G")#text(". Else, one may need to take ")#mi("\\lim\\inf_n \\ell(g^n)/n")#text(" if there is an additive error in the length — which is indeed the case on pages 12 and 15. However, this can be bypassed if the error is not too large, as shown by de Bruijn and Erdos in the added reference.")

#text("I also updated the blue text slightly, since the ")#mi("\\ell(a), \\ell(b)")#text(" analysis in the free group ")#mi("F_2")#text(" is not needed in the proof of Proposition 4.1, and hence I moved it to page 14. And I made a few more edits in the blue text.")

#text("Once again, I am done (for now). Siddhartha was also fine with the text, so if someone wants to further edit it, please can you remove the blue during the polishing, thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491258")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("I am reading the draft of the paper. Certainly Equation (2.3) should be crucial to establish Proposition 2.1. But in the paper it is not clear where it’s been used. I don’t think it is required for either Lemma 2.9 (Splitting lemma) or Corollary 2.11. It’d be helpful to clarify this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491259")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("Thanks – I think it is used to derive Equation (2.6), which is used in proving Lemma 2.7, which gets used in the Splitting lemma as well as Corollary 2.11. (And (2.6) is also used in the final proof.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491264")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("Sorry I didn’t respond for a while, I am travelling currently. It’s looking like the writing process has neared its conclusion. If I don’t hear for any more major changes, I will upload the paper to the arXiv tomorrow. (There will of course still be a chance to revise the arXiv version should the need arise.)")

#text("We didn’t reach much of a conclusion for journals. One suggestion made to me was the Proceedings of the AMS, which is a good generalist journal publishing shortish papers like ours. Presumably Pham Huu Tiep would the editor closest to the paper topic. (He’s also an editor at Algebra & Number Theory, but presumably if he thinks that journal would be even more suitable he would tell us.) What does everyone think about this choice? We can submit somewhat after the arXiv preprint goes up, of course.")

#text("p.s. in preparation for arXiv’ing, I have combined all the working .tex files for the paper into a single file (linear.tex).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491265")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("I like Terry’s idea of asking Pham Huu Tiep whether A&NT or Proc. AMS would be a reasonable match.")

#text("Also, to be extremely pedantic, a couple of minutes ago in “introduction.tex”, I changed a string in Proposition 1.7(2) from ")#mi("\\ell(x y^{-1})")#text(" to ")#mi("\\ell(x^{-1} y)")#text(" — since this is the convention in Section 1 paragraph 1. I didn’t realize Terry was editing, so perhaps he could make this change in linear.tex before uploading to arXiv. Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("OK, I’ll do that after arXiving the paper tomorrow if nobody objects. I’m done editing the paper, so feel free to make the last final edits.")

#text("Best,")

#text("Terry")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("Due to spotty internet access (I’m travelling right now) I’ve asked Apoorva to handle the arXiv submission. In other news, I talked with Tim Gowers and Gil Kalai and they are happy to have our project retroactively designated as Polymath13 (which presumably will not be “unlucky” for us :).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15fdd26260b7494ddff8ae819232b8672e2244d264a794710238bd87a2460350-bf33e1a619ddefa0ea9c77e08888cfca229a3c54d92f5aa63c15cd9e70570d84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicodean")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491298")[#strong[#text("nicodean")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("I thought the Intransitive dice-project was polymath13?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491324")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("Good point – for some reason a wiki page was never created for that project. I’ve put one in now, and renumbered this project as Polymath14.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491319")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("The project on intransitive dice has already been sometimes designated “Polymath 13” — see for example ")#link("https://polymathprojects.org/2017/08/22/polymath-13-a-success/")[#text("Gil’s post")]#text(" on the polymath blog.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491269")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("I also agree with Terry’s idea. I’d favor A&NT first if that agrees with the editor’s thoughts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491270")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("Seconded, @Pace. Also, I am now done with my “final edits”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491286")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("Second posting to the arXiv now. I’m happy with either journal (or any other).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491295")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("As Terry said, I will submit to arXiv later tonight. I took a look at the math categories at ")#link("https://arxiv.org/archive/math")[#text("this link")]#text(" and wonder if the following cross-listings are fine:")#linebreak()#text(" ")#strong[#text("1. Primary:")]#text(" Metric Geometry")#linebreak()#text(" ")#strong[#text("2. Secondary:")]#text(" Group Theory, Functional Analysis (since Banach spaces feature).")#linebreak()#text(" ")#strong[#text("3.")]#text(" I debated between which of MG and GT should be primary and which should be secondary. If anyone wants to reverse the order or suggest other changes, please let me know.")#linebreak()#text(" ")#strong[#text("4.")]#text(" I wasn’t planning to cross-list to Probability or Category Theory, even though a motivation and the final step are probabilistic… Again, if people prefer I should change this (or add any other categories), please let me know. We still have a few hours before tomorrow’s cutoff.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8461e0132a14b601b9e759b29e8bf55ab18c2e8319bea84c92705f045afceb-2355733f005069d29ef94b3b79978270f4125505ecbb25a228ec7a4084166b3e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sgadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491296")[#strong[#text("sgadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("As far as I know (I searched a little to check), combinatorial group theory papers are usually posted in math.GR with math.GT (GT = Geometric Topology) as secondary for those that have a geometric flavour – those that are really geometric group theory may reverse the order. Metric geometry is generally secondary.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491297")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("Ah ok, a typo by me: I meant to say GR and not GT.")

#text("Ok so primary = GR, secondary = MG, FA. Do we also add GT, which I hadn’t even suggested? (I’m assuming Prob or Category Theory are a “no” as per Siddhartha.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8461e0132a14b601b9e759b29e8bf55ab18c2e8319bea84c92705f045afceb-2355733f005069d29ef94b3b79978270f4125505ecbb25a228ec7a4084166b3e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sgadgil")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491302")[#strong[#text("sgadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("I would say yes to GT – the tradition is that this is a very broad category to which a lot of people subscribe and group theory with a non-trivial ggt flavour gets cross-listed here")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491306")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("Sounds great, thank you!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491305")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("My apologies for the multiple comments here: I just realized we don’t have keywords! I’m going to add the following keywords, say in about half an hour; and as Terry said, if updates are needed then we can make those in the next version.")

#text("* homogeneous length function")#linebreak()#text(" * pseudo-length function")#linebreak()#text(" * quasi-morphism")#linebreak()#text(" * Banach space embedding")

#text("Also, I am not adding “commutator length” as a keyword for now. I also won’t add a date, in keeping with previous Polymath preprints on the arXiv. If people have edits to suggest then please let me know.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491320")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("One more typo: in the proof of Thm 4.3, we pull back to the ")#emph[#text("free group")]#text(" generated two symbols, not to a ")#link("https://en.wikipedia.org/wiki/Formal_group")[#text("formal group")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8cef8929eebc2411ddcc535177f1c242763bbc7d6bf3294ebb86c065d3945b-948059c9bd91c560798b6862a14de08974112bbee36ace128267c106fb4f68cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491326")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("The Polymath14 paper is now up on the arXiv, at ")#link("https://arxiv.org/abs/1801.03908")[#text("1801.03908")]#text(". Also, I made the change that Lior suggested, in the latest version on Dropbox. This version can be used for submission, and eventually we’ll update the arXiv version too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Homogeneous length functions on groups | What's new")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491329")[#strong[#text("Homogeneous length functions on groups | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("[…] good bounds on quantities such as , until one can show that such norms have to vanish. See the previous post for a full proof. The result is robust in that it allows for some loss in the triangle inequality […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spontaneous Polymath 14 – A success! | The polymath blog")]], [#link("https://terrytao.wordpress.com/2017/12/21/metrics-of-linear-growth-the-solution/#comment-491784")[#strong[#text("Spontaneous Polymath 14 – A success! | The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("[…] problem was posed by Apoorva Khare was presented and discussed and openly and collectively solved. (And the […]")
]
