// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/
// Converted to Typst by tao2typ: "2026-10-14T16:34:55.615001+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series I: Shou-wu Zhang, “Overview of rational points on curves”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series I: Shou-wu Zhang, “Overview of rational points on curves”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 May 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/")[#text("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("[This lecture is also doubling as this week’s “open problem of the week”, as it discusses the ")#link("http://en.wikipedia.org/wiki/Birch_and_Swinnerton-Dyer_conjecture")[#text("Birch and Swinnerton-Dyer conjecture")]#text(" and the effective Mordell conjecture.]")

#text("Like many other maths departments, UCLA has a distinguished lecture series for eminent mathematicians to present recent developments in a field of mathematics, both to a broad audience and to specialists. Unlike most departments, though, our lecture series goes by the descriptive (but unimaginative) name of “")#link("http://www.math.ucla.edu/dls/index.html")[#text("Distinguished Lecture Series")]#text("“, supported by the ")#link("http://www.gillfoundation.org/")[#text("Gill Foundation")]#text(". This week the lecture series ")#link("http://www.math.ucla.edu/dls/2007/zhang.html")[#text("is given by")]#text(" ")#link("http://en.wikipedia.org/wiki/Shouwu_Zhang")[#text("Shou-wu Zhang")]#text(" from Columbia, and revolves around the topic of rational points on curves, a key subject of interest in arithmetic geometry and number theory. The first of three talks, which was on Tuesday, was a very accessible and enjoyable overview talk, which I am reproducing here (to use this opportunity to learn this stuff myself, and also to continue the diversification of subject matter here on this blog). As before, I do not vouch for 100% accuracy, and all errors are my responsibility rather than Shou-wu’s.")

#metadata(none) <tao-08bceebd861dcc41ba28>

#text("Shou-wu’s chosen topic involves a major and venerable component of number theory, namely the problem of solving ")#link("http://en.wikipedia.org/wiki/Diophantine_equation")[#text("Diophantine equations")]#text("; this field is variously known as “Diophantine geometry” or “Diophantine analysis”, and indeed a major theme of Shou-wu’s talk was that this field, which for most of its history was viewed primarily as a collection of “puzzles”, has now matured (particularly in the last century) to become a field rich in analytic, algebraic, and geometric structure and technique, and highly connected with other areas of mathematics. The definition of what a Diophantine equation is, and what it means to “solve” it, various from context to context, but for this talk it meant the study of solutions to polynomial equations ")#mi("F(x_1,\\ldots,x_n) = 0")#text(" where F is a polynomial with integer coefficients, and ")#mi("x_1,\\ldots,x_n")#text(" lie either in the integers ")#mi("{\\Bbb Z}")#text(" or the rationals ")#mi("{\\Bbb Q}")#text(" (and most of the talk eventually focused on the rationals). In the modern (geometric) approach to the subject, one views F as describing a hypersurface (or a scheme) on which one seeks to find integer points or rational points (or more generally, points over other commutative rings or fields). The three fundamental questions, for any given such Diophantine equation, are")

#enum(start: 1, 
[#emph[#text("Existence")]#text(". Does there exist at least one integer point or rational point?")],
[#emph[#text("Structure")]#text(". What structures (e.g. group structure, or other algebraic structure) does the space of all such points have?")],
[#emph[#text("Effectiveness")]#text(". Are there effective bounds on the number of points, or the size (height) of points? Are there effective algorithms to locate these points?")]
)

#text("These questions are, in general, very hard. For instance, the famous ")#link("http://en.wikipedia.org/wiki/Matiyasevich%27s_theorem")[#text("theorem of Matiyasevich")]#text(" answers one version of ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_tenth_problem")[#text("Hilbert’s tenth problem")]#text(" by demonstrating (among other things) the existence of a Diophantine equation of several variables, whose solvability over the integers is undecidable. (It is still open whether a similar result holds true over the rationals.) However, for specific types of Diophantine equations, much more is known. For instance, two very classical (and “genus 0”) examples, both known to Euclid, include")

#list(
[#text("The ")#emph[#text("line")]#text(" ")#mi("\\{ (x_1,x_2): a x_1 + b x_2 - c = 0 \\}")#text(", which contains integer points precisely when c is divisible by the greatest common divisor of a and b (and whose solutions can be enumerated effectively via the ")#link("http://en.wikipedia.org/wiki/Euclidean_algorithm")[#text("Euclidean algorithm")]#text("; and")],
[#text("The ")#emph[#text("unit circle")]#text(" ")#mi("\\{(x_1,x_2): x_1^2 + x_2^2 - 1 = 0 \\}")#text(", whose rational points are essentially equivalent to reduced ")#link("http://en.wikipedia.org/wiki/Pythagorean_triple")[#text("Pythagorean triples")]#text(" ")#mi("a^2 + b^2 = c^2")#text(", and can be enumerated explicitly as ")#mi("(x_1,x_2) = (\\frac{m^2-n^2}{m^2+n^2}, \\frac{2mn}{m^2+n^2})")#text(" where m, n are integers that are not both zero.")]
)

#text("Moving on to some more difficult “higher genus” or “higher dimensional” examples, we have")

#list(
[#text("The ")#emph[#text("Fermat curve")]#text(" ")#mi("\\{ (x_1,x_2): x_1^n + x_2^n - 1 = 0\\}")#text(", which was famously ")#link("http://en.wikipedia.org/wiki/Fermat%27s_last_theorem")[#text("proven by Wiles ")]#text("to have no non-trivial rational points for any ")#mi("n \\geq 3")#text("; and")],
[#emph[#text("Euler’s hypersurface")]#text(" ")#mi("\\{ (x_1,\\ldots,x_{n-1}): x_1^n + \\ldots + x_{n-1}^n - 1 = 0\\}")#text(" (an example, by the way, of a ")#link("http://en.wikipedia.org/wiki/Calabi-Yau")[#text("Calabi-Yau manifold")]#text("), which was ")#link("http://en.wikipedia.org/wiki/Euler%27s_conjecture")[#text("conjectured by Euler")]#text(" to have no non-trivial rational points for any ")#mi("n \\geq 3")#text(", but which was disproven for n=5 by Lander and Parkin and n=4 by Elkies. While these counterexamples are ")#link("http://en.wikipedia.org/wiki/Euler%27s_conjecture")[#text("completely explicit")]#text(", they were found by geometric means; for instance, Elkies’ example was found by first locating ")#link("http://en.wikipedia.org/wiki/Heegner_point")[#text("Heegner points ")]#text("of an elliptic curve on the Euler surface, which turns out to be a ")#link("http://en.wikipedia.org/wiki/K3_surface")[#text("K3 surface")]#text(".")]
)

#text("Given that these problems are so hard in general, it has been more profitable to focus on special types of hypersurfaces, such as")

#list(
[#emph[#text("Curves")]#text(" ")#mi("C := \\{ (x_1,x_2): F(x_1,x_2) = 0\\}")#text(", with F irreducible for simplicity;")],
[#link("http://en.wikipedia.org/wiki/Abelian_variety")[#text("Abelian varieties")]#text(" (connected to curves via ")#link("http://en.wikipedia.org/wiki/Motivic_cohomology")[#text("motivic cohomology")]#text("); and")],
[#link("http://en.wikipedia.org/wiki/Moduli_space")[#text("Moduli spaces")]#text(" (closely related to ")#link("http://en.wikipedia.org/wiki/Shimura_variety")[#text("Shimura varieties")]#text(").")]
)

#text("Shou-wu’s lectures are focused on curves, and specifically on finding rational (rather than integer) points on such curves. Such a curve C can be viewed in many ways:")

#list(
[#text("as an ")#link("http://en.wikipedia.org/wiki/Affine_variety")[#text("affine variety")]#text(" C;")],
[#text("as a ")#link("http://en.wikipedia.org/wiki/Projective_variety")[#text("projective variety")]#text(";")],
[#text("as an abstract ring (the ")#link("http://en.wikipedia.org/wiki/Coordinate_ring")[#text("coordinate ring")]#text(" of C);")],
[#text("as a ")#link("http://en.wikipedia.org/wiki/Riemann_surface")[#text("Riemann surface")]#text(" ")#mi("C({\\Bbb C}) := \\{ (z_1,z_2) \\in {\\Bbb C}^2: F(z_1,z_2) = 0 \\}")#text(" (after compactifying and blowing up all singularities) of some ")#link("http://en.wikipedia.org/wiki/Genus_%28mathematics%29")[#text("genus")]#text(" g;")],
[#text("as a set of points ")#mi("C({\\Bbb F}_p) := \\{ (x_1,x_2) \\in {\\Bbb F}_p^2: F(x_1,x_2) = 0 \\}")#text(" over a finite field ")#mi("{\\Bbb F}_p")#text(" (working projectively, and dealing with primes of bad reduction in standard ways);")],
[#text("as a set of points ")#mi("C({\\Bbb Q}) := \\{ (x_1,x_2) \\in {\\Bbb Q}^2: F(x_1,x_2) = 0 \\}")#text(" over the rationals;")],
[#text("etc.")]
)

#text("Thanks to the great work of ")#link("http://en.wikipedia.org/wiki/Grothendieck")[#text("Grothendieck")]#text(", we know that all of these different viewpoints are best interpreted through the unified perspective of ")#link("http://en.wikipedia.org/wiki/Scheme_%28mathematics%29")[#text("schemes")]#text(". For instance, if one is interested in rational points, one takes the associated ring of integers (in this case, just ")#mi("{\\Bbb Z}")#text("), and views the ")#link("http://en.wikipedia.org/wiki/Spectrum_of_a_ring")[#text("spectrum")]#text(" ")#mi("\\text{Spec}({\\Bbb Z})")#text(" as a new dimension in which to vary the curve C, thus converting the one dimensional object C to what is basically a two-dimensional “arithmetic surface”, the scheme ")#mi("X = X_C")#text(" associated to C. In this specific case, the spectrum consists just of the primes ")#mi("p = 2,3,5,\\ldots")#text(" (though in practice one should compactify and throw in ")#mi("\\infty")#text(" as well), and the scheme sits over the spectrum as a kind of bundle, with the fibre over p just being (essentially) the finite curve ")#mi("C({\\Bbb F}_p)")#text(", and the fibre over ")#mi("\\infty")#text(" being (essentially) the Riemann surface ")#mi("C({\\Bbb C})")#text(". A rational point ")#mi("(x_1,x_2)")#text(" in ")#mi("C({\\Bbb Q})")#text(" can then be viewed as a special type of section of this bundle, whose value over p is just the mod p projection to ")#mi("C({\\Bbb F}_p)")#text(" and whose value over ")#mi("\\infty")#text(" is formed simply by interpreting ")#mi("x_1,x_2")#text(" as complex numbers rather than integers. (If p divides the denominator of ")#mi("x_1")#text(" or ")#mi("x_2")#text(" then the section might have a pole at p, but these are easily dealt with by working projectively, compactifying, and blowing up singularities.) With this viewpoint, the problem of finding rational points in curves transforms now to one of finding special sections of bundles, which brings the subject much closer to many other “mainstream” areas of mathematics, and in particular to modern analysis, geometry, algebra, and topology.")

#text("The scheme-theoretic perspective can be unintuitive at first glance, especially to those mathematicians (such as myself) who are more used to analysis than to algebra. To explain this viewpoint better, Shou-wu described the ")#emph[#text("function field model")]#text(", in which the “arithmetic” ring of integers ")#mi("{\\Bbb Z}")#text(" are replaced by the “analytic” ring of complex polynomials ")#mi("{\\Bbb C}[t]")#text(" of one variable t, and the field of rational numbers ")#mi("{\\Bbb Q}")#text(" then replaced by the field of ")#link("http://en.wikipedia.org/wiki/Rational_function")[#text("rational functions")]#text(" ")#mi("{\\Bbb C}(t)")#text(". The spectrum ")#mi("\\text{Spec}({\\Bbb C}[t])")#text(" here is identifiable with the complex line ")#mi("{\\Bbb C}")#text(", since every complex number z gives rise to a ")#link("http://en.wikipedia.org/wiki/Prime_ideal")[#text("prime ideal")]#text(" ")#mi("\\{ f(t) \\in {\\Bbb C}[t]: f(z) = 0 \\}")#text(", and these are all the prime ideals. (Conversely, ")#mi("{\\Bbb C}[t]")#text(" is the ")#link("http://en.wikipedia.org/wiki/Function_field_of_an_algebraic_variety")[#text("function field")]#text(" of its spectrum ")#mi("\\text{Spec}({\\Bbb C}[t]) \\equiv {\\Bbb C}")#text(", viewed as an algebraic variety). If one is interested in, say, finding all “rational” points ")#mi("x(t), y(t) \\in {\\Bbb C}(t)")#text(" to the Fermat curve ")#mi("C := \\{ (x,y): x^n + y^n - 1 = 0 \\}")#text(" (i.e. all rational functions ")#mi("x(t), y(t)")#text(" such that ")#mi("x(t)^n + y(t)^n")#text(" is identically equal to 1), one can replace the curve C by the surface ")#mi("X := \\{ (x,y,z) \\in {\\Bbb C}^2 \\times {\\Bbb C}: x^n + y^n - 1 = 0 \\}")#text(", which one should think of as a bundle of curves over the spectrum, i.e. the complex line. (In this case, the curve turns out to be independent of the base point z; in more general examples of schemes, this is unlikely to be true.) A rational point ")#mi("(x(t),y(t))")#text(" on the Fermat curve then corresponds to a rational (in particular, meromorphic) section of the surface X. Thus we see that by introducing the spectral parameter z we have introduced some more ")#emph[#text("geometry")]#text(" into the problem; in this case, some complex geometry.")

#text("To illustrate how we can use this additional geometric structure, Shou-wu recalled the classic proof of “Fermat’s last theorem for polynomials”, namely that when ")#mi("n \\geq 3")#text(", the only rational points ")#mi("(x(t),y(t))")#text(" on the Fermat curve are the constant points (where ")#mi("x(t), y(t)")#text(" are independent of t). If for contradiction we had a non-trivial rational point, which we write in reduced fraction form as ")#mi("(f(t)/h(t), g(t)/h(t))")#text(", with f(t), g(t), h(t) coprime, then by evaluating at the spectral parameter z we have")

#align(center)[#tao-fit-display[#mitex("f(z)^n + g(z)^n = h(z)^n")]]

#text("for all complex z. Now the complex structure implies in particular that both sides here are complex differentiable in z, so we can differentiate and obtain")

#align(center)[#mi("n f(z)^{n-1} f^{\\prime}(z) + n g(z)^{n-1} g^{\\prime}(z) = n h(z)^{n-1} h^{\\prime}(z)")#text(";")]

#text("combining this with the previous equation and using some algebra, one eventually obtains")

#align(center)[#mi("f(z)^{n-1} (f^{\\prime}(z) h(z) - f(z) h^{\\prime}(z)) + g(z)^{n-1} (g^{\\prime}(z) h(z) - g(z) h^{\\prime}(z)) = 0")#text(".")]

#text("Since f and g are coprime, we thus see that ")#mi("f^{n-1}")#text(" divides ")#mi("g^{\\prime}h-gh^{\\prime}")#text(" and ")#mi("g^{n-1}")#text(" divides ")#mi("f^{\\prime}h-fh^{\\prime}")#text(", and by considering the degrees of f,g,h we quickly obtain a contradiction for ")#mi("n \\geq 3")#text(" unless f,g,h are all constant.")

#text("Returning to the ordinary rationals and integers, Shou-wu noted that the “arithmetic geometry” of the primes ")#mi("\\text{Spec}({\\Bbb Z})")#text(" does not have the type of differential geometric structure that the function field model had; nobody has succeeded, for instance, in proving Fermat’s last theorem by taking an integer solution ")#mi("a^n + b^n = c^n")#text(" modulo each prime p, and then “differentiating with respect to p” in analogy to the above argument. Nevertheless there are other analytic methods one can use to exploit the arithmetic geometry in this situation. Shou-wu then listed the two major analytic methods in the subject:")

#enum(start: 1, 
[#text("The ")#link("http://en.wikipedia.org/wiki/Infinite_descent")[#text("method of infinite descent")]#text(", which was first used to great effect in this subject by Fermat (though arguably the Euclidean algorithm already implicitly appeals to this method); in the modern theory, this method has developed into the theory of ")#link("http://en.wikipedia.org/wiki/N%C3%A9ron%E2%80%93Tate_height")[#text("heights")]#text(" (which measure the complexity of equations and their solutions), and thence to ")#emph[#text("Arakelov theory")]#text(", which Shou-wu interpreted as the intersection theory of certain types of ")#link("http://en.wikipedia.org/wiki/Chern_class")[#text("Chern classes")]#text(", which can be viewed as invariants of the arithmetic surface ")#mi("X_C")#text("; and")],
[#text("The method of ")#link("http://en.wikipedia.org/wiki/Hasse-Weil_L-function")[#text("L-functions")]#text(", which creates a single and very rich analytic invariant – the L-function – associated to the arithmetic surface – rather than studying a lot of “smaller” invariants.")]
)

#text("Despite looking completely different, in recent years it has been realised that these two methods are connected in several ways (to be discussed in later lectures). For this lecture, Shou-wu focused on the L-function approach. The philosophy here is that the arithmetic surface ")#mi("X_C")#text(" is easily studied over any given prime p (where it is just an algebraic curve); to quote ")#link("http://en.wikipedia.org/wiki/Max_N%C3%B6ther")[#text("Max Noether")]#text(", “algebraic curves are created by God, but algebraic surfaces are created by the Devil”. To implement this philosophy, one collects all of this “local” information and place it into a convenient analytic object, the ")#emph[#text("Hasse-Weil L-function")]

#align(center)[#tao-fit-display[#mitex("L(X,s) := \\prod_p \\prod_{i=1}^{2g} (1 - \\lambda_{i,p} p^{-s})^{-1} = \\sum_{n=1}^\\infty \\frac{a_n}{n^s}")]]

#text("where ")#mi("a_n")#text(" is a multiplicative sequence that measures a kind of correction term for the behaviour of the curve at the place n and ")#mi("\\lambda_{i,p}")#text(" are the Frobenius eigenvalues in ")#mi("H^1(X)")#text("; the individual factors in the product over primes are the ")#link("http://en.wikipedia.org/wiki/Local_zeta-function")[#text("local zeta-functions")]#text(" of the curve, and relate to the number of points over ")#mi("{\\Bbb F}_{p^k}")#text(" for integer k. In particular, the number of points ")#mi("N_p = \\# {\\Bbb C}({\\Bbb F}_p)")#text(" at p is given by the formula ")#mi("N_p = p+1-\\sum_{i=1}^{2g} \\lambda_{i,p}")#text(" ")#strike[#text("(this identity apparently relates to the ")#link("http://en.wikipedia.org/wiki/Lefschetz_principle#The_Lefschetz_principle")[#text("Lefschetz principle")]#text(", though I didn’t understand this point)")]#text("; this identity is also a special case of the Grothendieck-Lefschetz fixed point formula. Weil (building on earlier work of Hasse) famously proved the ")#emph[#text("Riemann hypothesis for function fields")]#text(", which among other things demonstrated that all the eigenvalues ")#mi("\\lambda_{i,p}")#text(" all have magnitude at most ")#mi("\\sqrt{p}")#text(", which thus implies that ")#tao-math("\\left|N_p - p - 1\\right| \\leq 2g\\sqrt{p}", block: false)#text(". (An equivalent formulation of this fact is that all the local zeta-functions have all the zeroes on the critical line, thus explaining the terminology “Riemann hypothesis”.) In particular we see that ")#mi("N_p")#text(" is non-zero for all sufficiently large p.")

#text("Now, in order for C to have any rational points at all, it is necessary for all the ")#mi("N_p")#text(" to be non-zero (otherwise there is a local obstruction at p, similar to what I discussed in ")#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/")[#text("my first Simons lecture")]#text("). Hasse formed his famous ")#emph[#text("local-to-global principle")]#text(", which is the heuristic that the converse should be true, namely if there are no local obstructions at any prime p then there should be at least one rational point. This principle turns out to not always be true, but nevertheless seems to be an excellent first approximation.")

#text("Shou-wu closed by quickly sketching the state of the art for the theory of rational points on curves for various values of the genus g, which is the decisive parameter in the theory (and is roughly related to the degree of F via the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text("):")

#list(
[#text("For genus 0 curves (in particular, lines and conics, i.e. the case when F has degree at most 2), we have a satisfactory and effective theory. The ")#link("http://en.wikipedia.org/wiki/Hasse%E2%80%93Minkowski_theorem")[#text("Hasse-Minkowski theorem")]#text(" asserts that the local-to-global principle is true in this case; a rational point exists if and only if a point exists over each ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#text("p-adic field")]#text(", which (in non-singular cases) is equivalent to the existence of a point in ")#mi("{\\Bbb F}_p")#text(". The latter can be computed easily using ")#link("http://en.wikipedia.org/wiki/Quadratic_reciprocity")[#text("quadratic reciprocity")]#text(". As for describing the structure of all rational points, there is an extremely classical observation of ")#link("http://en.wikipedia.org/wiki/Diophantus")[#text("Diophantus")]#text(" himself, which in modern language states that once one rational point of a genus zero curve is found, the space of all rational points can be identified with the ")#link("http://en.wikipedia.org/wiki/Projective_space")[#text("projective line ")]#mi("{\\Bbb P}^1/{\\Bbb Q}")#text(" over the rationals, essentially by ")#link("http://en.wikipedia.org/wiki/Stereographic_projection")[#text("stereographic projection")]#text(" from the given rational point.")],
[#text("For genus 1 curves (which happens when F has degree 3), we have a partially satisfactory theory. The local-to-global principle does not quite work; for instance, the curve ")#mi("3 x_1^3 + 4x_2^3 - 5 = 0")#text(" has a point over every ")#mi("{\\Bbb F}_p")#text(", but has no rational points. Nevertheless the obstruction to this principle can be quantified as follows. If one marks a rational point P on a genus 1 curve C to serve as a group identity then the resulting pair (C,P) is an ")#link("http://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curve")]#text(" E. Given a genus 1 curve C, there is an abstract elliptic curve E (the ")#link("http://en.wikipedia.org/wiki/Jacobian_variety")[#text("Jacobian")]#text(" of C) one can canonically assign to C, by quotienting out the space ")#mi("\\text{Div}^0(C)")#text(" of ")#link("http://en.wikipedia.org/wiki/Divisor_%28algebraic_geometry%29")[#text("divisors ")]#text("of C (formal integer sums of points in C in which the weights sum to zero) by the principal divisors (which in this case are generated by ")#mi("P_1 + P_2 + P_3 - Q_1 - Q_2 - Q_3")#text(" whenever ")#mi("P_1,P_2,P_3")#text(" and ")#mi("Q_1,Q_2,Q_3")#text(" are collinear triples of points in C; note that an elliptic curve intersects any line in three points (in an algebraically complete field, of course)). The fibre of curves C which give the same abstract elliptic curves E is the ")#link("http://en.wikipedia.org/wiki/Principal_homogeneous_space")[#text("principal homogeneous space")]#text(" of E, and can be given the structure of a group: the ")#link("http://en.wikipedia.org/wiki/Tate-Shafarevich_group")[#text("Tate-Shafarevich group")]#text(" of E. [")#emph[#text("Update")]#text(", May 2: actually, the Tate-Shafarevich group is a bit smaller than this; as we do not want to see local obstructions, we restrict attention to curves which have points over all completions of the underlying field, which in the case of ")#mi("{\\Bbb Q}")#text(" is roughly like asking the curves to have a point over ")#mi("{\\Bbb F}_p")#text(" for every p.] This group controls the number of rational points on C (and whether they exist at all), after accounting for local obstructions, but it is not fully understood at present. As is well known, the rational points ")#mi("C({\\Bbb Q})")#text(" of C is itself an abelian group; a ")#link("http://en.wikipedia.org/wiki/Mordell%E2%80%93Weil_theorem")[#text("famous theorem of Mordell and Weil")]#text(" asserts that this is isomorphic to a finitely generated subgroup of the two-torus ")#mi("{\\Bbb R}^2/{\\Bbb Z}^2")#text(" (which is in turn isomorphic to ")#mi("C({\\Bbb C})")#text(", from the classical ")#link("http://en.wikipedia.org/wiki/Weierstrass's_elliptic_functions")[#text("work of Weierstrass")]#text("). The dominant feature of this subgroup is the rank; the remaining bit, the torsion group, is known by a deep theorem of Mazur to be quite small, and more precisely to have order at most 16. Computing the rank of this group is in fact an extremely important problem in the subject; the famous ")#link("http://en.wikipedia.org/wiki/Birch_and_Swinnerton-Dyer_conjecture")[#text("Birch and Swinnerton-Dyer conjecture")]#text(" asserts (among other things) that the rank of ")#mi("C({\\Bbb Q})")#text(" is always equal to the order of vanishing of the L-function ")#mi("L(s,X)")#text(" at s=1. (It also asserts that the Tate-Shafarevich group is always finite.) This conjecture can be formulated without explicit reference to the L-function as the assertion that the product ")#mi("\\prod_{p < x} \\frac{N_p}{p}")#text(" diverges like ")#mi("(\\log X)^{\\text{rank}(C({\\Bbb Q}))}")#text(", which can be viewed as a more analytical version of the local-to-global principle (relating the number (or more precisely rank) of rational points to the number of points over ")#mi("{\\Bbb F}_p")#text("). The BSD conjecture is supported by much numerical evidence and an array of partial results and special cases, but is still far from complete resolution. In addition to BSD, there are a number of other conjectures (including one of Lang) which assert that various characteristics of ")#mi("C({\\Bbb Q})")#text(" are controlled in terms of the height of the discriminant; these conjectures, if true, would enable one to describe the rational points fairly effectively.")],
[#text("For higher genus curves ")#mi("g \\geq 2")#text(" (which is the typical situation when F has degree 4 or higher), we are quite far from a satisfactory theory, in large part because there is little group structure (or group-like structure) to exploit here. The celebrated ")#link("http://en.wikipedia.org/wiki/Falting%27s_theorem")[#text("proof by Faltings")]#text(" of the Mordell conjecture shows that the number of rational points is necessarily finite in this case, but as the proof proceeds by comparing rational points to each other, rather than to an external reference point, there is no effective bound known on the height of these points (though one can get a weak but effective bound on the ")#emph[#text("number")]#text(" of points in terms of the rank of the ")#link("http://en.wikipedia.org/wiki/Jacobian_variety")[#text("Jacobian")]#text(", which is in turn controlled by a “weak Mordell-Weil conjecture”). It would be a substantial breakthrough to get this effective bound. In particular there are the ")#emph[#text("effective Mordell conjectures")]#text(", one (rather naive) version of which can be stated as follows: given any curve C of genus ")#mi("g \\geq 2")#text(", one should have ")#mi("h(x_1,x_2) \\ll_g h(C)")#text(" for all rational points ")#mi("(x_1,x_2)")#text(" in C, where the height ")#mi("h(x_1,x_2)")#text(" of the rational point is the maximum of the logarithms of the numerators and denominators of ")#mi("x_1,x_2")#text(", and the height ")#mi("h(C)")#text(" of the curve C is (say) 1 plus the logarithm of the largest coefficient in the defining polynomial F. This conjecture is already so strong that it implies the ")#link("http://en.wikipedia.org/wiki/Abc_conjecture")[#text("abc conjecture")]#text(". It is in turn implied by an even stronger bound which was motivated from the function field model (i.e. complex surfaces rather than arithmetic ones) as an analogy. More precisely, since the well-known Bogomolov-Miyaoka-Yau inequality ")#mi("c_1(X)^2 \\leq 3 c_2(X)")#text(" for complex surfaces controls the self-intersection of the first ")#link("http://en.wikipedia.org/wiki/Chern_class")[#text("Chern class")]#text(" of the canonical complex line bundle of X by the second Chern class; one can conjecture an arithmetic analogue of this inequality in which the self-intersection of a “relative canonical bundle” from Arakelov theory (a substitute for the canonical line bundle, which is not available due to the lack of differential structure in ")#mi("\\text{Spec}({\\Bbb Z})")#text(") would be controlled by the logarithm of some sort of discriminant (plus some other correction terms), times a factor depending on the genus; I didn’t fully understand the statement here, but apparently it implies the effective Mordell conjecture.")]
)

#text("[")#emph[#text("Update")]#text(", May 2: Corrected the reference to the Grothendieck-Lefschetz fixed point formula, as pointed out by Emmanuel Kowalski, and corrected the definition of the Tate-Shafarevich group, as pointed out by bb.]")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-776")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2007")])]

#text("The “Lefschetz principle” is presumably a reference to the Grothendieck-Lefschetz")#linebreak()#text(" trace formula, which states that the number of points on an algebraic variety ")#mi("U")#linebreak()#text(" defined over a finite field ")#mi("\\mathbf{F}_q")#text(" with ")#mi("q")#text(" elements is the alternating")#linebreak()#text(" sum of traces of the “global” Frobenius automorphism acting on some finite-dimensional")#linebreak()#text(" vector spaces, the index ")#mi("j")#text(" ranging from 0 to ")#mi("2d")#text(", where ")#mi("d")#text(" is the dimension.")#linebreak()#text(" For a smooth irreducible projective curve, ")#mi("d=1")#text(", the first trace (")#mi("j=0")#text(") is ")#mi("1")#text(" (trivial action on a one-dimensional space), the last trace (")#mi("j=2")#text(") is ")#mi("q")#text(" (multiplication by ")#mi("q")#text(" on a")#linebreak()#text(" one-dimensional space) and the middle (interesting) trace (")#mi("j=1")#text(") is the trace on")#linebreak()#text(" a vector space of dimension ")#mi("2g")#text(" (analogue of the classical first (co)homology group of a Riemann surface), written as sum of eigenvalues ")#mi("\\lambda_{i}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b58c65d149a92464bc601f85ffd91135f257a5b5a4482b59a26d97c816f303d1-c7dbf2229f6f54efc6398fb3ec711b35609f773b8f16b007a93bbdb5bb43c55d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bb")]], [#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-779")[#strong[#text("bb")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2007")])]

#text("I’d just like to point out a tiny mistake in the definition of the Tate-Shafarevich group (Sha, for short). What you’ve defined (the set of genus 1 curves over a field k with jacobian E, upto isomorphism) is actually the cohomology group H^1(k,E) (this can also be defined as the set of curves over k with a free and transitive E-action defined over k). In order to get Sha, we must account for local obstructions as we’re trying to capture the failure of the Hasse principle. So over a number field k, we define Sha(E,k) to be the subgroup of H^1(k,E) consisting of curves which have points over all completions of k. This is the group that’s conjectured to be finite — the H^1(k,E) could very well be infinite.")

#text("Also, as perhaps an interesting aside, I believe that in the function field case the truth of BSD conjecture is now equivalent to the finiteness of Sha which, in turn, follows from the 2-dimensional case of the remarkable conjecture of Artin that any smooth projective variety over a finite field (in fact, any proper scheme over Spec(Z) works!) has a finite Brauer group (Morita equivalence classes of central simple algebras).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-780")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2007")])]

#text("Dear Emmanuel and bb,")

#text("Thanks very much for the corrections; they are especially helpful for me as I am trying to learn this subject properly. (I sort of absorbed bits and pieces of this through osmosis while a graduate student at Princeton – I was there when Wiles proved his theorem, in particular – but it’s only now that I think I’m getting a bit of a handle on things.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series II: Shou-wu Zhang, “Gross-Zagier formula and Birch and Swinnerton-Dyer conjecture ” « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-786")[#strong[#text("Distinguished Lecture Series II: Shou-wu Zhang, “Gross-Zagier formula and Birch and Swinnerton-Dyer conjecture ” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2007")])]

#text("[…] In the previous lecture, Shou-wu defined an elliptic curve E as a genus 1 curve with a marked point P (which will eventually become the group identity element). It is traditional to move this point P to the point at infinity and view the curve affinely, in which case the curve can be placed via an affine transformation in the normal form […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series III: Shou-wu Zhang, “Triple L-series and effective Mordell conjecture” « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-796")[#strong[#text("Distinguished Lecture Series III: Shou-wu Zhang, “Triple L-series and effective Mordell conjecture” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2007")])]

#text("[…] discussed in the first lecture, one of the landmark achievements in the higher genus theory is Faltings’ theorem (proving […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-814")[#strong[#text("Not Even Wrong » Blog Archive » All Sorts of Stuff")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2007")]

#text("[…] continues to come up with amazingly good blog entries. His latest is a series of three postings (here, here and here), reporting on my colleague Shouwu Zhang’s lectures at UCLA on the topic of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-1004")[#strong[#text("Ars Mathematica » Blog Archive » Tao on Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2007")]

#text("[…] Overview of rational points on curves […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dyadic models « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-5158")[#strong[#text("Dyadic models « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2007")])]

#text("[…] factorisation of large numbers) are surprisingly easy to solve in the dyadic world (see e.g. Zhang’s talk for the dyadic version of FLT), but nobody knows how to convert the dyadic arguments to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-29867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2008")])]

#text("Very deep lecture.")

#mi("\\alpha+\\beta=\\gamma")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/650b7c8b1a2ea5fbe7f86fc75c75b138fbed3aa0e70922a2ea3d25f5ff6e5fe9-e07bb92e3452285aa4787e1e7a3904351d0fdc59936ebd227e52373545dc7259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/#comment-47172")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2010")])]

#text("Please let me add something on bb’s comment. What would be the exact consequences of the finiteness of Sha for an elliptic curve defined over the field of rational numbers? Would it be enough to prove BSD conjecture, or would one also need to build new connections with the function field case?")
]
