// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/03/07/the-asymptotic-distribution-of-a-single-eigenvalue-gap-of-a-wigner-matrix/
// Converted to Typst by tao2typ: "2026-10-14T09:24:24.250567+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The asymptotic distribution of a single eigenvalue gap of a Wigner matrix", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The asymptotic distribution of a single eigenvalue gap of a Wigner matrix")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 March 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/03/07/the-asymptotic-distribution-of-a-single-eigenvalue-gap-of-a-wigner-matrix/")[#text("https://terrytao.wordpress.com/2012/03/07/the-asymptotic-distribution-of-a-single-eigenvalue-gap-of-a-wigner-matrix/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper ")#link("http://arxiv.org/abs/1203.1605")[#text("The asymptotic distribution of a single eigenvalue gap of a Wigner matrix")]#text(", submitted to ")#link("http://www.springer.com/mathematics/probability/journal/440")[#text("Probability Theory and Related Fields")]#text(". This paper (like several of my previous papers) is concerned with the asymptotic distribution of the eigenvalues ")#mi("{\\lambda_1(M_n) \\leq \\ldots \\leq \\lambda_n(M_n)}")#text(" of a random Wigner matrix ")#mi("{M_n}")#text(" in the limit ")#mi("{n \\rightarrow \\infty}")#text(", with a particular focus on matrices drawn from the ")#link("http://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian Unitary Ensemble")]#text(" (GUE). This paper is focused on the ")#emph[#text("bulk")]#text(" of the spectrum, i.e. to eigenvalues ")#mi("{\\lambda_i(M_n)}")#text(" with ")#mi("{\\delta n \\leq i \\leq (1-\\delta) n}")#text(" for some fixed ")#mi("{\\delta>0}")#text(".")

#text("The location of an individual eigenvalue ")#mi("{\\lambda_i(M_n)}")#text(" is by now quite well understood. If we normalise the entries of the matrix ")#mi("{M_n}")#text(" to have mean zero and variance ")#mi("{1}")#text(", then in the asymptotic limit ")#mi("{n \\rightarrow \\infty}")#text(", the ")#link("http://en.wikipedia.org/wiki/Wigner_semicircle_distribution")[#text("Wigner semicircle law")]#text(" tells us that with probability ")#mi("{1-o(1)}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\lambda_i(M_n) =\\sqrt{n} u + o(\\sqrt{n})")]]

#text("where the ")#emph[#text("classical location")]#text(" ")#mi("{u = u_{i/n} \\in [-2,2]}")#text(" of the eigenvalue is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_{-2}^{u} \\rho_{sc}(x)\\ dx = \\frac{i}{n}")]]

#text("and the semicircular distribution ")#mi("{\\rho_{sc}(x)\\ dx}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\rho_{sc}(x) := \\frac{1}{2\\pi} (4-x^2)_+^{1/2}.")]]

#text("Actually, one can improve the error term here from ")#mi("{o(\\sqrt{n})}")#text(" to ")#mi("{O( \\log^{1/2+\\epsilon} n)}")#text(" for any ")#mi("{\\epsilon>0}")#text(" (see this previous ")#link("https://terrytao.wordpress.com/2012/01/24/random-matrices-sharp-concentration-of-eigenvalues/")[#text("recent paper of Van and myself")]#text(" for more discussion of these sorts of estimates, sometimes known as ")#emph[#text("eigenvalue rigidity")]#text(" estimates).")

#text("From the semicircle law (and the fundamental theorem of calculus), one expects the ")#mi("{i^{th}}")#text(" eigenvalue spacing ")#mi("{\\lambda_{i+1}(M_n)-\\lambda_i(M_n)}")#text(" to have an average size of ")#mi("{\\frac{1}{\\sqrt{n} \\rho_{sc}(u)}}")#text(". It is thus natural to introduce the normalised eigenvalue spacing")

#align(center)[#tao-fit-display[#mitex("X_i := \\frac{\\lambda_{i+1}(M_n) - \\lambda_i(M_n)}{1/\\sqrt{n} \\rho_{sc}(u)}")]]

#text("and ask what the distribution of ")#mi("{X_i}")#text(" is.")

#text("As mentioned previously, we will focus on the bulk case ")#mi("{\\delta n \\leq i\\leq (1-\\delta)n}")#text(", and begin with the model case when ")#mi("{M_n}")#text(" is drawn from GUE. (In the edge case when ")#mi("{i}")#text(" is close to ")#mi("{1}")#text(" or to ")#mi("{n}")#text(", the distribution is given by the famous ")#link("http://www.ams.org/mathscinet-getitem?mr=1385083")[#text("Tracy-Widom law")]#text(".) Here, the distribution was almost (but as we shall see, not quite) worked out by Gaudin and Mehta. By using the theory of determinantal processes, they were able to compute a quantity closely related to ")#mi("{X_i}")#text(", namely the probability ")#metadata(none) <tao-17057013652043f03365>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf P}( N_{[\\sqrt{n} u + \\frac{x}{\\sqrt{n} \\rho_{sc}(u)}, \\sqrt{n} u + \\frac{y}{\\sqrt{n} \\rho_{sc}(u)}]} = 0)")]]



#text(" that an interval ")#mi("{[\\sqrt{n} u + \\frac{x}{\\sqrt{n} \\rho_{sc}(u)}, \\sqrt{n} u + \\frac{y}{\\sqrt{n} \\rho_{sc}(u)}]}")#text(" near ")#mi("{\\sqrt{n} u}")#text(" of length comparable to the expected eigenvalue spacing ")#mi("{1/\\sqrt{n} \\rho_{sc}(u)}")#text(" is devoid of eigenvalues. For ")#mi("{u}")#text(" in the bulk and fixed ")#mi("{x,y}")#text(", they showed that this probability is equal to")

#align(center)[#tao-fit-display[#mitex("\\det( 1 - 1_{[x,y]} P 1_{[x,y]} ) + o(1),")]]

#text("where ")#mi("{P}")#text(" is the Dyson projection")

#align(center)[#tao-fit-display[#mitex("P f(x) = \\int_{\\bf R} \\frac{\\sin(\\pi(x-y))}{\\pi(x-y)} f(y)\\ dy")]]

#text("to Fourier modes in ")#mi("{[-1/2,1/2]}")#text(", and ")#mi("{\\det}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Fredholm_determinant")[#text("Fredholm determinant")]#text(". As shown ")#link("http://www.ams.org/mathscinet-getitem?mr=573370")[#text("by Jimbo, Miwa, Tetsuji, Mori, and Sato")]#text(", this determinant can also be expressed in terms of a solution to a Painleve V ODE, though we will not need this fact here. In view of this asymptotic and some standard integration by parts manipulations, it becomes plausible to propose that ")#mi("{X_i}")#text(" will be asymptotically distributed according to the ")#emph[#text("Gaudin-Mehta distribution")]#text(" ")#mi("{p(x)\\ dx}")#text(", where")

#align(center)[#tao-fit-display[#mitex("p(x) := \\frac{d^2}{dx^2} \\det( 1 - 1_{[0,x]} P 1_{[0,x]} ).")]]

#text("A reasonably accurate approximation for ")#mi("{p}")#text(" is given by the ")#emph[#text("Wigner surmise")]#text(" ")#mi("{p(x) \\approx \\frac{1}{2} \\pi x e^{-\\pi x^2/4}}")#text(" [EDIT: as pointed out in comments, in this GUE setting the correct surmise is ")#mi("{p(x) \\approx \\frac{3^2}{\\pi^2} x^2 e^{-4 x^2/\\pi}}")#text("], which was presciently proposed by Wigner as early as 1957; it is exact for ")#mi("{n=2}")#text(" but not in the asymptotic limit ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("Unfortunately, when one tries to make this argument rigorous, one finds that the asymptotic for ")#link(<tao-17057013652043f03365>)[#text("(1)")]#text(" does not control a single gap ")#mi("{X_i}")#text(", but rather an ensemble of gaps ")#mi("{X_i}")#text(", where ")#mi("{i}")#text(" is drawn from an interval ")#mi("{[i_0 - L, i_0 + L]}")#text(" of some moderate size ")#mi("{L}")#text(" (e.g. ")#mi("{L = \\log n}")#text("); see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1702716")[#text("this paper of Deift, Kriecherbauer, McLaughlin, Venakides, and Zhou")]#text(" for a more precise formalisation of this statement (which is phrased slightly differently, in which one samples all gaps inside a fixed window of spectrum, rather than inside a fixed range of eigenvalue indices ")#mi("{i}")#text("). (This result is stated for GUE, but can be extended to other Wigner ensembles by the Four Moment Theorem, at least if one assumes a moment matching condition; see ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("this previous paper with Van Vu")]#text(" for details. The moment condition can in fact be removed, as was done in ")#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/")[#text("this subsequent paper with Erdos, Ramirez, Schlein, Vu, and Yau")]#text(".)")

#text("The problem is that when one specifies a given window of spectrum such as ")#mi("{[\\sqrt{n} u + \\frac{x}{\\sqrt{n} \\rho_{sc}(u)}, \\sqrt{n} u + \\frac{y}{\\sqrt{n} \\rho_{sc}(u)}]}")#text(", one cannot quite pin down in advance which eigenvalues ")#mi("{\\lambda_i(M_n)}")#text(" are going to lie to the left or right of this window; even with the strongest eigenvalue rigidity results available, there is a natural uncertainty of ")#mi("{\\sqrt{\\log n}}")#text(" or so in the ")#mi("{i}")#text(" index (as can be quantified quite precisely by ")#link("http://www.ams.org/mathscinet-getitem?mr=2124079")[#text("this central limit theorem of Gustavsson")]#text(").")

#text("The main difficulty here is that there could potentially be some strange coupling between the event ")#link(<tao-17057013652043f03365>)[#text("(1)")]#text(" of an interval being devoid of eigenvalues, and the number ")#mi("{N_{(-\\infty,\\sqrt{n} u + \\frac{x}{\\sqrt{n} \\rho_{sc}(u)})}(M_n)}")#text(" of eigenvalues to the left of that interval. For instance, one could conceive of a possible scenario in which the interval in ")#link(<tao-17057013652043f03365>)[#text("(1)")]#text(" tends to have many eigenvalues when ")#mi("{N_{(-\\infty,\\sqrt{n} u + \\frac{x}{\\sqrt{n} \\rho_{sc}(u)})}(M_n)}")#text(" is even, but very few when ")#mi("{N_{(-\\infty,\\sqrt{n} u + \\frac{x}{\\sqrt{n} \\rho_{sc}(u)})}(M_n)}")#text(" is odd. In this sort of situation, the gaps ")#mi("{X_i}")#text(" may have different behaviour for even ")#mi("{i}")#text(" than for odd ")#mi("{i}")#text(", and such anomalies would not be picked up in the averaged statistics in which ")#mi("{i}")#text(" is allowed to range over some moderately large interval.")

#text("The main result of the current paper is that these anomalies do not actually occur, and that all of the eigenvalue gaps ")#mi("{X_i}")#text(" in the bulk are asymptotically governed by the Gaudin-Mehta law without the need for averaging in the ")#mi("{i}")#text(" parameter. Again, this is shown first for GUE, and then extended to other Wigner matrices obeying a matching moment condition using the Four Moment Theorem. (It is likely that the moment matching condition can be removed here, but I was unable to achieve this, despite all the recent advances in establishing universality of local spectral statistics for Wigner matrices, mainly because the universality results in the literature are more focused on specific energy levels ")#mi("{u}")#text(" than on specific eigenvalue indices ")#mi("{i}")#text(". To make matters worse, in some cases universality is currently known only after an additional averaging in the energy parameter.)")

#text("The main task in the proof is to show that the random variable ")#mi("{N_{(-\\infty,\\sqrt{n} u + \\frac{x}{\\sqrt{n} \\rho_{sc}(u)})}(M_n)}")#text(" is largely decoupled from the event in ")#link(<tao-17057013652043f03365>)[#text("(1)")]#text(" when ")#mi("{M_n}")#text(" is drawn from GUE. To do this we use some of the theory of ")#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")[#text("determinantal processes")]#text(", and in particular the nice fact that when one conditions a determinantal process to the event that a certain spatial region (such as an interval) contains no points of the process, then one obtains a new determinantal process (with a kernel that is closely related to the original kernel). The main task is then to obtain a sufficiently good control on the distance between the new determinantal kernel and the old one, which we do by some functional-analytic considerations involving the manipulation of norms of operators (and specifically, ")#link("http://en.wikipedia.org/wiki/Operator_norm")[#text("the operator norm")]#text(", ")#link("http://en.wikipedia.org/wiki/Hilbert%E2%80%93Schmidt_operator")[#text("Hilbert-Schmidt norm")]#text(", and ")#link("http://en.wikipedia.org/wiki/Schatten_norm")[#text("nuclear norm")]#text("). Amusingly, the ")#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/")[#text("Fredholm alternative")]#text(" makes a key appearance, as I end up having to invert a compact perturbation of the identity at one point (specifically, I need to invert ")#mi("{1 - 1_{[x,y]}P1_{[x,y]}}")#text(", where ")#mi("{P}")#text(" is the Dyson projection and ")#mi("{[x,y]}")#text(" is an interval). As such, the bounds in my paper become ineffective, though I am sure that with more work one can invert this particular perturbation of the identity by hand, without the need to invoke the Fredholm alternative.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a0b10aff2cf7875bfcfe44b88c9ec8d5b9d91f1061b909b7789f8ec9024b1e8-63662168c63421adb75efd9e1dfce4710a34284aafc6a513b41e3618bd3bde25.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carnegie")]], [#link("https://terrytao.wordpress.com/2012/03/07/the-asymptotic-distribution-of-a-single-eigenvalue-gap-of-a-wigner-matrix/#comment-133096")[#strong[#text("carnegie")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2012")])]

#text("Does your work allow you to say anything about asymptotics for the Painleve equation governing the Gaudin-Mehta determinant, or about the analytic behaviour of ")#mi("\\tau")#text("-functions more generally?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/03/07/the-asymptotic-distribution-of-a-single-eigenvalue-gap-of-a-wigner-matrix/#comment-133097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2012")])]

#text("Probably not, unfortunately; the way that I show that the distribution of a single eigenvalue gap converges to the Gaudin distribution is to show that the single eigenvalue gap has asymptotically the same distribution as an averaged ensemble of eigenvalue gaps, which was already known by previous work to converge to the Gaudin distribution. If there was an alternate way to control eigenvalue gaps, this might lead to a way to analyse the Gaudin distribution without having to directly solve a Painleve equation or otherwise work out the Gaudin-Mehta determinant, but it seems that eigenvalue gaps are inherently a more complicated object of study than the Gaudin distribution, and so an analysis of the former is unlikely to lead to more understanding of the latter (instead, understanding will probably flow in the other direction – facts about the Gaudin distribution can be used to say something about eigenvalue gaps).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50aed26dacb4ed29006c0ed9d0fd0238372e408dab6ef9876abf16fcd5a2a4b3-f638c5846f4034c0890b16e11a98cfe1b86a534caf668fb05fc10abc67b8ac23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tamás F. Görbe")]], [#link("https://terrytao.wordpress.com/2012/03/07/the-asymptotic-distribution-of-a-single-eigenvalue-gap-of-a-wigner-matrix/#comment-455580")[#strong[#text("Tamás F. Görbe")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2015")])]

#text("I think there’s an extra $i$ in the ‘definition’ of the bulk.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/664ff39d5bdf6dc36fa58870a921907c4206eba6addef8410dfe4da8daf90517-582e96ec977db021cec1acfb6cd452ae4bb8bdde4ef8f1b9cdc9305695e74954.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marc Potters")]], [#link("https://terrytao.wordpress.com/2012/03/07/the-asymptotic-distribution-of-a-single-eigenvalue-gap-of-a-wigner-matrix/#comment-542076")[#strong[#text("Marc Potters")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2020")])]

#text("Dear Terry,")

#text("I think that you used the wrong Wigner surmise. You consider the GUE case while the classical Wigner surmise is for GOE. The x in front of the Gaussian weight should have the same exponent beta as in as in the Vandermonde. The correct “surmise” for beta=2 is")#linebreak()#text(" ")#mi("p(x)=32/\\pi^2 x^2 \\exp(-4 x^2/\\pi)")#text(" see for example ")#link("https://www.researchgate.net/publication/227036476_Level-spacing_distributions_beyond_the_Wigner_surmise")[#text("https://www.researchgate.net/publication/227036476_Level-spacing_distributions_beyond_the_Wigner_surmise")]

#text("Regards,")

#text("Marc")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the distribution of eigenvalues of GUE and its minors at fixed index | What's new")]], [#link("https://terrytao.wordpress.com/2012/03/07/the-asymptotic-distribution-of-a-single-eigenvalue-gap-of-a-wigner-matrix/#comment-686918")[#strong[#text("On the distribution of eigenvalues of GUE and its minors at fixed index | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2024")])]

#text("[…] or “averaged index” settings; the “fixed index” case was only achieved by myself as recently as 2013, where I showed that each such gap in fact asymptotically had the expected distribution of the […]")
]
