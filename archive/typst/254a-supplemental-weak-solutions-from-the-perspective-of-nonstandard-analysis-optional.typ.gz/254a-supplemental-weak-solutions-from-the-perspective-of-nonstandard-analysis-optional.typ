// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/12/09/254a-supplemental-weak-solutions-from-the-perspective-of-nonstandard-analysis-optional/
// Converted to Typst by tao2typ: "2026-10-14T16:38:29.357225+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 December 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/12/09/254a-supplemental-weak-solutions-from-the-perspective-of-nonstandard-analysis-optional/")[#text("https://terrytao.wordpress.com/2018/12/09/254a-supplemental-weak-solutions-from-the-perspective-of-nonstandard-analysis-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Note: this post is not required reading for this course, or for the sequel course in the winter quarter.")#linebreak()#text(" In a ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("Notes 2")]#text(", we reviewed the classical construction of Leray of global weak solutions to the Navier-Stokes equations. We did not quite follow Leray’s original proof, in that the notes relied more heavily on the machinery of Littlewood-Paley projections, which have become increasingly common tools in modern PDE. On the other hand, we did use the same “exploiting compactness to pass to weakly convergent subsequence” strategy that is the standard one in the PDE literature used to construct weak solutions.")#linebreak()#text(" As I ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("discussed in a previous post")]#text(", the manipulation of sequences and their limits is analogous to a “cheap” version of nonstandard analysis in which one uses the ")#link("https://en.wikipedia.org/wiki/Fr%C3%A9chet_filter")[#text("Fréchet filter")]#text(" rather than an ultrafilter to construct the nonstandard universe. (The manipulation of ")#link("https://en.wikipedia.org/wiki/Colombeau_algebra")[#text("generalised functions of Columbeau-type")]#text(" can also be comfortably interpreted within this sort of cheap nonstandard analysis.) Augmenting the manipulation of sequences with the right to pass to subsequences whenever convenient is then analogous to a sort of “lazy” nonstandard analysis, in which the implied ultrafilter is never actually constructed as a “")#link("https://en.wikipedia.org/wiki/Actual_infinity")[#text("completed object")]#text("“, but is instead ")#link("https://en.wikipedia.org/wiki/Lazy_evaluation")[#text("lazily evaluated")]#text(", in the sense that whenever membership of a given subsequence of the natural numbers in the ultrafilter needs to be determined, one either passes to that subsequence (thus placing it in the ultrafilter) or the complement of the sequence (placing it out of the ultrafilter). This process can be viewed as the initial portion of the transfinite induction that one usually uses to construct ultrafilters (as discussed using a voting metaphor in ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this post")]#text("), except that there is generally no need in any given application to perform the induction for any uncountable ordinal (or indeed for most of the countable ordinals also).")#linebreak()#text(" On the other hand, it is also possible to work directly in the orthodox framework of nonstandard analysis when constructing weak solutions. This leads to an approach to the subject which is largely equivalent to the usual subsequence-based approach, though there are some minor technical differences (for instance, the subsequence approach occasionally requires one to work with separable function spaces, whereas in the ultrafilter approach the reliance on separability is largely eliminated, particularly if one imposes a strong notion of saturation on the nonstandard universe). The subject acquires a more “algebraic” flavour, as the quintessential analysis operation of taking a limit is replaced with the “standard part” operation, which is an algebra homomorphism. The notion of a sequence is replaced by the distinction between standard and nonstandard objects, and the need to pass to subsequences disappears entirely. Also, the distinction between “bounded sequences” and “convergent sequences” is largely eradicated, particularly when the space that the sequences ranged in enjoys some compactness properties on bounded sets. Also, in this framework, the notorious non-uniqueness features of weak solutions can be “blamed” on the non-uniqueness of the nonstandard extension of the standard universe (as well as on the multiple possible ways to construct nonstandard mollifications of the original standard PDE). However, many of these changes are largely cosmetic; switching from a subsequence-based theory to a nonstandard analysis-based theory does ")#emph[#text("not")]#text(" seem to bring one significantly closer for instance to the global regularity problem for Navier-Stokes, but it could have been an alternate path for the historical development and presentation of the subject.")#linebreak()#text(" In any case, I would like to present below the fold this nonstandard analysis perspective, quickly translating the relevant components of real analysis, functional analysis, and distributional theory that we need to this perspective, and then use it to re-prove Leray’s theorem on existence of global weak solutions to Navier-Stokes.")#linebreak()#text(" ")#metadata(none) <tao-8a611c1dfb8d4a82eb58>

#heading(level: 1)[#strong[#text(" — 1. Quick review of nonstandard analysis — ")]]

#text("In this section we quickly review the aspects of nonstandard analysis that we need. Let ")#mi("{{\\mathfrak U}}")#text(" denote the “standard” universe of “standard” mathematical objects; this includes what one might think of as “primitive” standard objects such as (standard) numbers and (standard) points, but also sets of standard objects (such as the set ")#mi("{{\\bf R}}")#text(" of real numbers, or the Euclidean space ")#mi("{{\\bf R}^d}")#text("), or functions ")#mi("{f: X \\rightarrow Y}")#text(" from one standard space to another, or function spaces such as ")#mi("{L^p({\\bf R}^d \\rightarrow {\\bf R})}")#text(" of such functions (possibly quotiented out by almost everywhere equivalence), and so forth. In short, ")#mi("{{\\mathfrak U}}")#text(" should contain all the standard objects that one generally works with in analysis. One can require that this universe obey various axioms (e.g. the Zermelo-Fraenkel-Choice axioms of set theory), but we will not be particularly concerned with the precise properties of this universe (we won’t even need to know whether ")#mi("{{\\mathfrak U}}")#text(" is a set or a ")#link("https://en.wikipedia.org/wiki/Class_(set_theory)")[#text("proper class")]#text(").")#linebreak()#text(" What nonstandard analysis does is take this standard universe ")#mi("{{\\mathfrak U}}")#text(" of standard objects and embed it in a larger ")#emph[#text("nonstandard universe")]#text(" ")#mi("{{}^* {\\mathfrak U}}")#text(" of nonstandard objects which has similar properties to the standard one, but also some additional properties. As discussed in ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("this previous post")]#text(", the relationship between the standard universe ")#mi("{{\\mathfrak U}}")#text(" and the nonstandard universe ")#mi("{{}^* {\\mathfrak U}}")#text(" is somewhat analogous to that between the rationals ")#mi("{{\\bf Q}}")#text(" and its metric completion ")#mi("{{\\bf R}}")#text("; most of the algebraic properties of ")#mi("{{\\bf Q}}")#text(" carry over to ")#mi("{{\\bf R}}")#text(", but ")#mi("{{\\bf R}}")#text(" also has some additional completeness and (local) compactness properties that ")#mi("{{\\bf Q}}")#text(" lacks. Also, one should think of ")#mi("{{}^* {\\mathfrak U}}")#text(" as being far “larger” than ")#mi("{{\\mathfrak U}}")#text(", in much the same way that ")#mi("{{\\bf R}}")#text(" is larger than ")#mi("{{\\bf Q}}")#text(" in various senses, for instance in the sense of cardinality.")#linebreak()#text(" There is one important subtlety concerning the nonstandard universe ")#mi("{{}^* {\\mathfrak U}}")#text(": it comes with a more restrictive notion of subset (or of function) than the “external” notion of subset or function that one has if one views ")#mi("{{}^* {\\mathfrak U}}")#text(" from some external metatheory (e.g., if one places both ")#mi("{{\\mathfrak U}}")#text(" and ")#mi("{{}^* {\\mathfrak U}}")#text(" inside a very large model of ZFC). Thus, for instance, an externally defined subset of the nonstandard reals ")#mi("{{}^* {\\bf R}}")#text(" may or may not be an internal subset of these reals (in particular, the embedded copy of the standard reals ")#mi("{{\\bf R}}")#text(" is ")#emph[#text("not")]#text(" an internal subset of ")#mi("{{}^* {\\bf R}}")#text(", being merely an external subset instead); similarly, an externally defined function from ")#mi("{{}^* {\\bf R}}")#text(" to ")#mi("{{}^* {\\bf R}}")#text(" need not be an internal function (for instance, the standard part function ")#mi("{\\mathrm{st}}")#text(" will be external rather than internal). The relationship between internal sets/functions and external sets/functions in nonstandard analysis is somewhat analogous to the relationship between measurable sets/functions and arbitrary sets/functions in measure theory.")#linebreak()#text(" The reals ")#mi("{{\\bf R}}")#text(" can be constructed from the rationals ")#mi("{{\\bf Q}}")#text(" in a number of ways, such as by forming Cauchy sequences in ")#mi("{{\\bf Q}}")#text(" and quotienting out by the sequences that converge to zero; similarly, the nonstandard universe ")#mi("{{}^* {\\mathfrak U}}")#text(" can be formed from the standard one ")#mi("{{\\mathfrak U}}")#text(" in a number of ways, such as by forming arbitrary sequences in ")#mi("{{\\mathfrak U}}")#text(" and quotienting out by a non-principal ultrafiter. See for instance ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this previous post")]#text(" for details. However, much as the precise construction of the reals ")#mi("{{\\bf R}}")#text(" is often of little direct importance in applications, we will not need to care too much about how the nonstandard universe is constructed. Rather, the following properties of this universe will be used:")

#list(
[#text("(i) (Embedding) Every standard object, space, operation, or function ")#mi("{x}")#text(" in ")#mi("{{\\mathfrak U}}")#text(" has a nonstandard counterpart ")#mi("{{}^* x}")#text(" in ")#mi("{{}^* {\\mathfrak U}}")#text(". For instance, if ")#mi("{x}")#text(" is a real number in the set ")#mi("{{\\bf R}}")#text(" of standard reals, then ")#mi("{{}^* x}")#text(" will be an element of the set ")#mi("{{}^* {\\bf R}}")#text(" of nonstandard reals; if ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" is a standard function, then ")#mi("{{}^* f: {}^*({\\bf R}^d) \\rightarrow {}^* {\\bf R}}")#text(" is a nonstandard function from the nonstandard Euclidean space ")#mi("{{}^*({\\bf R}^d)}")#text(" to the nonstandard reals ")#mi("{{}^* {\\bf R}}")#text(". The standard addition operation ")#mi("{+: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" on the standard reals ")#mi("{{\\bf R}}")#text(" induces a nonstandard addition operation ")#mi("{{}^* +: {}^* {\\bf R} \\times {}^* {\\bf R} \\rightarrow {}^* {\\bf R}}")#text(" on the nonstandard reals, though to avoid notational clutter we will write ")#mi("{{}^* +}")#text(" as ")#mi("{+}")#text(", and similarly for other basic mathematical operations. Similarly, the norm function ")#mi("{\\|\\|: L^p({\\bf R}^d \\rightarrow {\\bf R}) \\rightarrow [0,+\\infty)}")#text(" has a nonstandard counterpart ")#mi("{{}^* \\| \\|: {}^* L^p({\\bf R}^d \\rightarrow {\\bf R}) \\rightarrow {}^* [0,+\\infty)}")#text(" that assigns a nonstandard non-negative real ")#tao-math("{{}^* \\left\\| f \\right\\| \\in {}^* [0,+\\infty)}", block: false)#text(" to any nonstandard ")#mi("{L^p({\\bf R}^d \\rightarrow {\\bf R})}")#text(" function ")#mi("{f \\in {}^* {\\bf R}^d}")#text(". (To avoid notational clutter, we will often abuse notation by identifying ")#mi("{x}")#text(" with ")#mi("{{}^* x}")#text(" for various “primitive” mathematical objects ")#mi("{x}")#text(" such as real numbers, arithmetic operations such as ")#mi("{+}")#text(", or functions such as ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(", unless we have a pressing need to carefully distinguish a standard object ")#mi("{x}")#text(" from its representative ")#mi("{{}^* x}")#text(" in the nonstandard universe.)")],
[#text("(ii) (")#link("https://en.wikipedia.org/wiki/Transfer_principle")[#text("Transfer")]#text(") If ")#mi("{P(x_1,\\dots,x_k)}")#text(" is a standard predicate in first order logic involving some finite number of standard objects ")#mi("{x_1,\\dots,x_k}")#text(" (with ")#mi("{k}")#text(" a fixed standard natural number), and possibly some quantification over standard sets, and ")#mi("{{}^* P}")#text(" is the nonstandard version of the predicate in which one quantifies over nonstandard sets, then ")#mi("{P(x_1,\\dots,x_k)}")#text(" is true if and only if ")#mi("{{}^* P( {}^* x_1, \\dots, {}^* x_k)}")#text(" is true. Important caveat: the predicate ")#mi("{P}")#text(" needs to be ")#emph[#text("internal")]#text(" to the mathematical language used internally to both ")#mi("{{\\mathfrak U}}")#text(" and ")#mi("{{}^* {\\mathfrak U}}")#text(" separately; it is not allowed to use ")#emph[#text("external")]#text(" concepts dependent on the way in which ")#mi("{{\\mathfrak U}}")#text(" embeds into ")#mi("{{}^* {\\mathfrak U}}")#text(", or how either universe embeds into an external metatheory.")],
[#text("(iii) (")#mi("{\\aleph_1}")#text("–")#link("https://en.wikipedia.org/wiki/Saturated_model")[#text("saturation")]#text(") Let ")#mi("{k,l}")#text(" be standard natural numbers, and suppose that for each standard natural number ")#mi("{n}")#text(", ")#mi("{{}^* P_n(x_1,\\dots,x_k,c_1,\\dots,c_l)}")#text(" is a nonstandard predicate on ")#mi("{k}")#text(" nonstandard variables ")#mi("{x_1,\\dots,x_k}")#text(" and nonstandard constants ")#mi("{c_1,\\dots,c_l}")#text(". If any finite collection of the predicates ")#mi("{{}^* P_n}")#text(" are simultaneously satisfiable (thus, for each standard ")#mi("{N}")#text(", there exist nonstandard objects ")#mi("{x_1^{(N)},\\dots,x_k^{(N)}}")#text(" such that ")#mi("{{}^* P_n(x_1^{(N)},\\dots,x_k^{(N)},c_1,\\dots,c_l)}")#text(" holds for all ")#mi("{1 \\leq n \\leq N}")#text("), then the entire collection ")#mi("{{}^* P_n}")#text(" is simultaneously satisfiable (thus there exists nonstandard objects ")#mi("{x_1,\\dots,x_k}")#text(" such that ")#mi("{{}^* P_n(x_1,\\dots,x_k,c_1,\\dots,c_l)}")#text(" holds for all ")#mi("{n \\in {\\bf N}}")#text(").")]
)

#text("The ")#mi("{\\aleph_1}")#text("-saturation property (also informally referred to as ")#emph[#text("countable saturation")]#text(", though this is technically a slight misnomer) resembles the ")#link("https://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(" that characterises compactness of topological spaces (and can thus be viewed as somewhat analogous to the local compactness property for the reals ")#mi("{{\\bf R}}")#text("), except that the finite intersection property involves arbitrary families of (closed) sets, whereas the ")#mi("{\\aleph_1}")#text("-saturation property requires the collection of predicates involved to be countable. It is possible to construct nonstandard models with a higher degree of saturation (where one can use more predicates ")#mi("{P_n}")#text(", as long as the total number does not exceed some cardinal ")#mi("{\\kappa}")#text(" which relates to the size of the nonstandard universe ")#mi("{{}^* {\\mathfrak U}}")#text("), for instance by replacing the sequences used to construct the nonstandard universe with tuples ranging over a larger cardinality set. This may potentially be useful for certain types of analysis, for instance ones involving non-separable spaces, or Frechet spaces involving an uncountable number of seminorms.")#linebreak()#text(" Let us take for granted the existence of a nonstandard universe obeying the embedding, transfer, and saturation properties, and see what we can do with them. Firstly, transfer shows that the map ")#mi("{x \\mapsto {}^* x}")#text(" is injective: ")#mi("{x = y}")#text(" if and only if ")#mi("{{}^* x = {}^* y}")#text(". The field axioms of the standard reals ")#mi("{{\\bf R}}")#text(" can be phrased in the language of first-order logic, and hence by transfer the nonstandard reals ")#mi("{{}^* {\\bf R}}")#text(" also form a field. For instance, the assertion “For every non-zero standard real ")#mi("{x}")#text(", there exists a standard real ")#mi("{y}")#text(" such that ")#mi("{xy=1}")#text("” transfers over to “For every non-zero nonstandard real ")#mi("{x}")#text(", there exists a nonstandard real ")#mi("{y}")#text(" such that ")#mi("{xy=1}")#text("“. If ")#mi("{d}")#text(" is a standard natural numer, one can transfer the statement “")#mi("{(x_1,\\dots,x_d) = (y_1,\\dots,y_d)}")#text(" if and only if ")#mi("{x_1=y_1, \\dots, x_d=y_d}")#text("” from standard tuples to nonstandard tuples; among other things, this gives the nice identification ")#mi("{{}^* ({\\bf R}^d) = ({}^* {\\bf R})^d}")#text(" when ")#mi("{d}")#text(" is a standard natural number. (The situation is more subtle when ")#mi("{d}")#text(" is a nonstandard natural number, but in most PDE applications one works in a fixed dimension ")#mi("{d}")#text(" and will not need to deal with this subtlety.) As one final example, “If ")#mi("{f \\in L^p({\\bf R}^d)}")#text(", then ")#tao-math("{\\left\\|f\\right\\|_{L^p({\\bf R}^d \\rightarrow {\\bf R})}=0}", block: false)#text(" holds if and only if ")#mi("{f=0}")#text("” transfers to “If ")#mi("{f \\in {}^* L^p({\\bf R}^d)}")#text(", then ")#tao-math("{{}^* \\left\\|f\\right\\|_{{}^* L^p({\\bf R}^d \\rightarrow {\\bf R})}=0}", block: false)#text(" holds if and only if ")#mi("{f=0}")#text("“. More generally, basic inequalities such as Hölder’s inequality, Sobolev embedding, or the Bernstein inequalities transfer over to the nonstandard setting without difficulty.")#linebreak()#text(" As a basic example of saturation, for each standard natural number ")#mi("{n}")#text(" let ")#mi("{P_n}")#text(" denote the statement “There exists a nonstandard real ")#mi("{x}")#text(" such that ")#mi("{x>n}")#text("“. These statements are finitely satisfable, hence by ")#mi("{\\aleph_1}")#text("-saturation they are jointly satisfiable, thus there exists a nonstandard real ")#mi("{x}")#text(" which is ")#emph[#text("unbounded")]#text(" in the sense that it is larger than every standard natural number (and hence also by every standard real number, by the ")#link("https://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean property of the reals")]#text("). Similarly, there exist nonstandard real numbers ")#mi("{x}")#text(" which are non-zero but still ")#emph[#text("infinitesimal")]#text(" in the sense that ")#tao-math("{\\left|x\\right| \\leq \\varepsilon}", block: false)#text(" for every standard real ")#mi("{\\varepsilon>0}")#text(".")#linebreak()#text(" On the other hand, one cannot apply the saturation property to the statements “There exists a nonstandard real ")#mi("{x}")#text(" such that ")#mi("{x \\in {\\bf R}}")#text(" and ")#mi("{x>n}")#text("“, since ")#mi("{{\\bf R}}")#text(" is not known to be an internal subset of the nonstandard universe ")#mi("{{}^* {\\mathfrak U}}")#text(" and so cannot be used as a constant for the purposes of saturation. (Indeed, since this sequence of statements is finitely satisfiable but not jointly satisfiable, this is a proof that ")#mi("{{\\bf R}}")#text(" is ")#emph[#text("not")]#text(" an internal subset of ")#mi("{{}^* {\\bf R}}")#text(", and must instead be viewed only as an external subset.)")#linebreak()#text(" Now we develop analogues of the sequential-based theory of limits in nonstandard analysis. The following dictionary may be helpful to keep in mind when comparing the two:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Standard real ")#mi("{x}")],
table.cell(colspan: 1, rowspan: 1)[#text("A real number ")#mi("{x}")],
table.cell(colspan: 1, rowspan: 1)[#text("Nonstandard reals ")#mi("{x}")],
table.cell(colspan: 1, rowspan: 1)[#text("A sequence ")#mi("{x_n}")#text(" of reals")],
table.cell(colspan: 1, rowspan: 1)[#text("Embedding ")#mi("{{}^* x}")#text(" of standard real ")#mi("{x}")],
table.cell(colspan: 1, rowspan: 1)[#text("A constant sequence ")#mi("{x_n = x}")#text(" of reals")],
table.cell(colspan: 1, rowspan: 1)[#text("Internal set ")#mi("{A}")#text(" of nonstandard reals")],
table.cell(colspan: 1, rowspan: 1)[#text("A sequence ")#mi("{A_n}")#text(" of subsets of reals")],
table.cell(colspan: 1, rowspan: 1)[#text("Embedding ")#mi("{{}^* A}")#text(" of standard set ")#mi("{A}")#text(" of reals")],
table.cell(colspan: 1, rowspan: 1)[#text("A constant sequence ")#mi("{A_n=A}")#text(" of subsets of reals")],
table.cell(colspan: 1, rowspan: 1)[#text("External set ")#mi("{A \\subset {}^* {\\bf R}}")],
table.cell(colspan: 1, rowspan: 1)[#text("A collection of sequences of reals")],
table.cell(colspan: 1, rowspan: 1)[#text("Internal function ")#mi("{f: {}^* {\\bf R}^d \\rightarrow {}^* {\\bf R}}")],
table.cell(colspan: 1, rowspan: 1)[#text("A sequence ")#mi("{f_n: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" of functions")],
table.cell(colspan: 1, rowspan: 1)[#text("Embedding ")#mi("{{}^*}")#text(" of a standard function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")],
table.cell(colspan: 1, rowspan: 1)[#text("A constant sequence ")#mi("{f_n = f}")#text(" of functions")],
table.cell(colspan: 1, rowspan: 1)[#text("External function ")#mi("{f: {}^* {\\bf R}^d \\rightarrow {}^* {\\bf R}}")],
table.cell(colspan: 1, rowspan: 1)[#text("A map from sequences of vectors to sequences of reals")],
table.cell(colspan: 1, rowspan: 1)[#text("Equality ")#mi("{x=y}")#text(" of nonstandard reals")],
table.cell(colspan: 1, rowspan: 1)[#text("After passing to a subsequence, ")#mi("{x_n=y_n}")#text(" for all ")#mi("{n}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{x = O(1)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{x_n}")#text(" is bounded")],
table.cell(colspan: 1, rowspan: 1)[#mi("{x = o(1)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{x_n}")#text(" converges to zero (possibly after passing to subsequence)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{O({\\bf R})}")],
table.cell(colspan: 1, rowspan: 1)[#text("Bounded sequences")],
table.cell(colspan: 1, rowspan: 1)[#mi("{o({\\bf R})}")],
table.cell(colspan: 1, rowspan: 1)[#text("Sequences converging to zero (possibly after passing to subsequence)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{{\\bf R} \\oplus o({\\bf R})}")],
table.cell(colspan: 1, rowspan: 1)[#text("Convergent sequences (possibly after passing to subsequence)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{O({\\bf R}) = {\\bf R} \\oplus o({\\bf R})}")],
table.cell(colspan: 1, rowspan: 1)[#text("Bolzano-Weierstrass theorem")],
table.cell(colspan: 1, rowspan: 1)[#text("Standard part ")#mi("{\\mathrm{st}(x)}")#text(" of bounded real ")#mi("{x}")],
table.cell(colspan: 1, rowspan: 1)[#text("Limit ")#mi("{\\lim_{n \\rightarrow\\infty} x_n}")#text(" of bounded sequence ")#mi("{x_n}")#text(" (possibly after passing to subsequence)")]
)

#text("Note in particular that in the nonstandard analysis formalism there is no need to repeatedly pass to subsequences, as is often the case in sequential-based analysis.")#linebreak()#text(" A nonstandard real ")#mi("{x}")#text(" is said to be ")#emph[#text("bounded")]#text(" if one has ")#tao-math("{\\left|x\\right| \\leq C}", block: false)#text(" for some standard ")#mi("{C > 0}")#text(". In this case, we write ")#mi("{x=O(1)}")#text(", and let ")#mi("{O({\\bf R})}")#text(" denote the set of all bounded reals. It is an external subring of ")#mi("{{}^*{\\bf R}}")#text(" that in turn contains ")#mi("{{\\bf R}}")#text(" as a external subring.")#linebreak()#text(" A nonstandard real ")#mi("{x}")#text(" is said to be ")#emph[#text("infinitesimal")]#text(" if one has ")#tao-math("{\\left|x\\right| \\leq \\varepsilon}", block: false)#text(" for all standard ")#mi("{\\varepsilon>0}")#text(". In this case, we write ")#mi("{x=o(1)}")#text(", and let ")#mi("{o({\\bf R})}")#text(" denote the set of all infinitesimal reals. This is another external subring (in fact, an ideal) of ")#mi("{O({\\bf R})}")#text(", and ")#mi("{O({\\bf R}), o({\\bf R}), {\\bf R}}")#text(" can be viewed as external vector spaces over ")#mi("{{\\bf R}}")#text(".")#linebreak()#text(" The ")#link("https://en.wikipedia.org/wiki/Bolzano%E2%80%93Weierstrass_theorem")[#text("Bolzano-Weierstrass theorem")]#text(" is fundamental to orthodox real analysis. Its counterpart in nonstandard analysis is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Nonstandard version of Bolzano-Weierstrass)")]#text(" As external vector spaces over ")#mi("{{\\bf R}}")#text(", we have the decomposition ")#mi("{O({\\bf R}) = {\\bf R} \\oplus o({\\bf R})}")#text(".")
]

#emph[#text("Proof:")]#text(" The only real which is simultaneously standard and infinitesimal is zero, so ")#mi("{{\\bf R} \\cap o({\\bf R}) = \\{0\\}}")#text(". It thus suffices to show that every bounded real ")#mi("{x}")#text(" can be written in the form ")#mi("{x = \\alpha + o(1)}")#text(" for some standard ")#mi("{\\alpha}")#text(". But the set ")#mi("{\\{ y \\in {\\bf R}: y \\leq x \\}}")#text(" is a Dedekind cut; setting ")#mi("{\\alpha \\in{\\bf R}}")#text(" to be the supremum of this cut, we have ")#mi("{\\alpha - 1/n \\leq x \\leq \\alpha + 1/n}")#text(" for all standard natural numbers ")#mi("{n}")#text(", hence ")#mi("{x=\\alpha+o(1)}")#text(" as desired. ")#mi("\\Box")#linebreak()#text(" If ")#mi("{x \\in O({\\bf R})}")#text(" and ")#mi("{x = \\alpha + o(1)}")#text(" for some standard real ")#mi("{\\alpha}")#text(", we call ")#mi("{\\alpha}")#text(" the ")#emph[#text("standard part")]#text(" of ")#mi("{x}")#text(" and denote it by ")#mi("{\\mathrm{st}(x)}")#text(": thus ")#mi("{\\mathrm{st}: O({\\bf R}) \\rightarrow {\\bf R}}")#text(" is the linear projection from ")#mi("{O({\\bf R})}")#text(" to ")#mi("{{\\bf R}}")#text(" with kernel ")#mi("{o({\\bf R})}")#text(". It is an algebra homomorphism (this is the analogue of the usual limit laws in real analysis).")#linebreak()#text(" In real analysis, we know that continuous functions on a compact set that are pointwise bounded are automatically uniformly bounded. There is a handy analogue of this fact in nonstandard analysis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Pointwise bounded/infinitesimal internal functions are uniformly bounded/infinitesimal)")]#text(" ")#metadata(none) <tao-05c0b1fd8151136d27f9>#text(" Let ")#mi("{f: A \\rightarrow {}^*{\\bf R}}")#text(" be an internal function.")

#list(
[#text("(i) If ")#mi("{f(x) = O(1)}")#text(" for all ")#mi("{x \\in A}")#text(", then there is a standard ")#mi("{C>0}")#text(" such that ")#tao-math("{\\left|f(x)\\right| \\leq C}", block: false)#text(" for all ")#mi("{x \\in A}")#text(".")],
[#text("(ii) If ")#mi("{f(x) = o(1)}")#text(" for all ")#mi("{x \\in A}")#text(", then there is an infinitesimal ")#mi("{\\varepsilon>0}")#text(" such that ")#tao-math("{\\left|f(x)\\right| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{x \\in A}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Suppose (i) were not the case, then the predicates “")#mi("{x \\in A}")#text(" and ")#tao-math("{\\left|f(x)\\right| \\geq n}", block: false)#text("” would be finitely satisfiable, hence jointly satisfiable by ")#mi("{\\aleph_1}")#text("-saturation. But then there would exist ")#mi("{x \\in A}")#text(" such that ")#tao-math("{\\left|f(x)\\right| \\geq n}", block: false)#text(" for all ")#mi("{n}")#text(", contradicting the hypothesis that ")#mi("{f(x) = O(1)}")#text(".")#linebreak()#text(" For (ii), observe that the predicates “")#mi("{0 < \\varepsilon \\leq 1/n}")#text(" is a nonstandard real such that ")#mi("{|f(x) \\leq \\varepsilon}")#text(" for all ")#mi("{x \\in A}")#text("” are finitely satisfiable, hence jointly satisfiable by ")#mi("{\\aleph_1}")#text("-saturation, giving the claim. ")#mi("\\Box")#linebreak()#text(" Because the rationals are dense in the reals, we see (from saturation) that every standard real number can be expressed as the standard part of a bounded rational, thus ")#mi("{R \\equiv O({\\bf Q})/o({\\bf Q})}")#text(". This can in fact be viewed as a way to ")#emph[#text("construct")]#text(" the reals; it is a minor variant of the standard construction of the reals as the space of Cauchy sequences of rationals, quotiented out by Cauchy equivalence.")#linebreak()#text(" Closely related to Lemma ")#link(<tao-05c0b1fd8151136d27f9>)[#text("2")]#text(" is the ")#link("https://en.wikipedia.org/wiki/Overspill")[#text("overspill")]#text(" (or underspill) principle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-5fb6a47e368e12e5d8b1>#text(" Let ")#mi("{P(x)}")#text(" be an internal predicate of a nonnegative nonstandard real number ")#mi("{x}")#text(".")

#list(
[#text("(i) (Overspill) If ")#mi("{P(x)}")#text(" is true for arbitrarily large standard ")#mi("{x}")#text(", then it is also true for at least one unbounded ")#mi("{x}")#text(".")],
[#text("(ii) (Underspill) If ")#mi("{P(x)}")#text(" is true for arbitrarily small standard ")#mi("{x>0}")#text(", then it is also true for at least one infinitesimal ")#mi("{x}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" To prove (i), observe that the predicates “")#mi("{P(x)}")#text(" and ")#mi("{x \\geq n}")#text("” for ")#mi("{n=1,2,\\dots}")#text(" a standard natural number are finitely satisfiable, hence jointly satisfiable by ")#mi("{\\aleph_1}")#text("-saturation, and the claim follows. The claim (ii) is proven similarly, using ")#mi("{0 < x < 1/n}")#text(" instead of ")#mi("{x \\geq n}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(" ")#metadata(none) <tao-e07e7aa6a214275c2404>#text(" Let ")#mi("{f: {}^* {\\bf R} \\rightarrow {}^* {\\bf R}}")#text(" be an internal function. If ")#mi("{f(x) = o(1)}")#text(" for all standard ")#mi("{x > 0}")#text(", then one has ")#mi("{f(x) = o(1)}")#text(" for at least one unbounded ")#mi("{x>0}")#text(".")
]

#emph[#text("Proof:")]#text(" Apply Lemma ")#link(<tao-5fb6a47e368e12e5d8b1>)[#text("3")]#text(" to the predicate ")#tao-math("{\\left|f(x)\\right| \\leq 1/x}", block: false)#text(". ")#mi("\\Box")#linebreak()#text(" The overspill principle and its analogues correspond, roughly speaking, to the “diagonalisation” arguments that are common in sequential analysis, for instance in the proof of the Arzelá-Ascoli theorem.")

#heading(level: 1)[#strong[#text(" — 2. Some nonstandard functional analysis — ")]]

#text("In the discussion of the previous section, the real numbers ")#mi("{{\\bf R}}")#text(" could be replaced by the complex numbers ")#mi("{{\\bf C}}")#text(" or finite-dimensional vector spaces ")#mi("{{\\bf R}^d}")#text(" (with ")#mi("{d}")#text(" a standard natural number) with essentially no change in theory. However the situation becomes a bit more subtle when one works with infinite dimensional spaces, such as the functional spaces that are commonly used in PDE.")#linebreak()#text(" Let ")#mi("{X}")#text(" be a standard normed vector space with norm ")#mi("{\\| \\|_X}")#text(", then we can form the nonstandard function space ")#mi("{{}^* X}")#text(" with a nonstandard (or internal) norm ")#mi("{{}^* \\| \\|_{{}^* X}: {}^* X \\rightarrow {}^*[0,+\\infty)}")#text(". This is not quite a normed vector space when viewed externally, because the nonstandard norm ")#mi("{{}^* \\| \\|_{{}^* X}}")#text(" takes values in the nonstandard nonnegative reals to ")#mi("{{}^*[0,+\\infty)}")#text(" rather than the standard nonnegative reals ")#mi("{[0,+\\infty)}")#text(". However, we can form the subspace ")#mi("{O(X)}")#text(" of ")#mi("{{}^* X}")#text(" consisting of those vectors ")#mi("{x \\in {}^* X}")#text(" which are ")#emph[#text("strongly bounded")]#text(" in the sense that ")#tao-math("{{}^* \\left\\|x\\right\\|_{{}^* X} = O(1)}", block: false)#text(". This is an external real subspace of ")#mi("{{}^* X}")#text(" that contains ")#mi("{X}")#text(". It comes with a seminorm ")#mi("{\\| \\|_X: O(X) \\rightarrow [0,+\\infty)}")#text(" defined by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| x \\right\\|_X := \\mathrm{st} {}^* \\left\\| x\\right\\|_{{}^* X}.", block: true)]]

#text("It is easy to see that this is a seminorm. The null space of this seminorm is the subspace ")#mi("{o(X)}")#text(" of ")#mi("{{}^* X}")#text(" consisting of those vectors ")#mi("{x \\in {}^* X}")#text(" which are ")#emph[#text("strongly infinitesimal")]#text(" (in ")#mi("{X}")#text(") in the sense that ")#tao-math("{{}^* \\left\\|x\\right\\|_{{}^* X} = o(1)}", block: false)#text("; we say two elements of ")#mi("{{}^* X}")#text(" are ")#emph[#text("strongly equivalent")]#text(" (in ")#mi("{X}")#text(") if their difference is strongly infinitesimal. In infinite dimensions, ")#mi("{X}")#text(" is no longer locally compact, and the Bolzano-Weierstrass theorem now only gives an inclusion:")

#align(center)[#tao-fit-display[#mitex("X \\oplus o(X) \\subset O(X).")]]

#text("In general we expect ")#mi("{O(X)}")#text(" to be significantly larger than ")#mi("{X}")#text(" (this is the nonstandard analogue of the sequential analysis phenomenon that most bounded sequences in ")#mi("{X}")#text(" will fail to have convergent subsequences). For instance if ")#mi("{H}")#text(" is a standard Hilbert space with an orthonormal system ")#mi("{e_n, n \\in {\\bf N}}")#text(", and ")#mi("{N}")#text(" is an unbounded natural number, one can check that ")#mi("{e_N}")#text(" lies in ")#mi("{O(X)}")#text(" but is not in ")#mi("{X \\oplus o(X)}")#text(". The quotient space ")#mi("{O(X)/o(X)}")#text(" is a normed vector space that contains ")#mi("{X}")#text(" as an isometric subspace and is known as the ")#emph[#text("nonstandard hull")]#text(" of ")#mi("{X}")#text(", but we will not explicitly use this space much in these notes.")#linebreak()#text(" In functional analysis one often has an embedding ")#mi("{X \\subset Y}")#text(" of standard function spaces ")#mi("{X,Y}")#text(", with an inequality of the form ")#tao-math("{\\left\\| f \\right\\|_Y \\leq C \\left\\|f\\right\\|_X}", block: false)#text(" for all ")#mi("{f \\in X}")#text(" and some constant ")#mi("{C>0}")#text(". For instance, one has the Sobolev embeddings ")#mi("{H^1({\\bf R}^d \\rightarrow {\\bf R}) \\subset L^p({\\bf R}^d \\rightarrow {\\bf R})}")#text(" whenever ")#mi("{2 \\leq p \\leq \\infty}")#text(", ")#mi("{\\frac{1}{p} \\geq \\frac{1}{2}-\\frac{1}{d}}")#text(", and ")#mi("{(d,p) \\neq (2,\\infty)}")#text(". One easily sees that such an embedding ")#mi("{X \\subset Y}")#text(" induces also embeddings ")#mi("{O(X) \\subset O(Y)}")#text(" and ")#mi("{o(X) \\subset o(Y)}")#text(".")#linebreak()#text(" If the embedding ")#mi("{X \\subset Y}")#text(" is ")#link("https://en.wikipedia.org/wiki/Compact_operator")[#text("compact")]#text(" – so that bounded subsets in ")#mi("{X}")#text(" are precompact in ")#mi("{Y}")#text(" – then we can partially recover the missing inclusion in the Bolzano-Weierstrass theorem. This follows from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Compactness)")]#text(" ")#metadata(none) <tao-659eee59f002e69bf905>#text(" Let ")#mi("{K}")#text(" be a standard compact subset (in the strong topology) of a standard normed vector space ")#mi("{X}")#text(". Then one has the inclusion")

#align(center)[#tao-fit-display[#mitex("{}^* K \\subset K \\oplus o(X),")]]

#text("that is to say every ")#mi("{f \\in {}^* K}")#text(" can be decomposed (uniquely) as ")#mi("{f = g+h}")#text(" with ")#mi("{g \\in K}")#text(" and ")#mi("{h \\in o(X)}")#text(".")
]

#text("This is the nonstandard analysis analogue of the assertion that compact subsets of a normed metric space are sequentially compact.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" Uniqueness is clear (since non-zero standard elements of ")#mi("{X}")#text(" have non-zero standard, hence non-infinitesimal, nonstandard norm), so we turn to existence. If this failed for some ")#mi("{f \\in {}^* K}")#text(", then for every ")#mi("{g \\in K}")#text(", there exists a standard ")#mi("{\\varepsilon_g>0}")#text(" such that ")#tao-math("{{}^* \\left\\|f - g \\right\\|_{X} \\geq \\varepsilon_g}", block: false)#text(". Hence, by compactness of")#mi("{K}")#text(", one can find a standard natural number ")#mi("{k}")#text(" and standard ")#mi("{g_1,\\dots,g_k \\in K}")#text(" such that for all ")#mi("{F \\in K}")#text(", one has ")#tao-math("{\\left\\|F-g_i \\right\\|_X < \\varepsilon_{g_i}}", block: false)#text(" for some ")#mi("{i=1,\\dots,k}")#text(". By transfer, (viewing ")#mi("{g_1,\\dots,g_k}")#text(" as constants), this implies that for all ")#mi("{F \\in {}^* K}")#text(", one has ")#tao-math("{\\left\\|F-g_i \\right\\|_X < \\varepsilon_{g_i}}", block: false)#text(" for some ")#mi("{i=1,\\dots,k}")#text(". Applying this with ")#mi("{F=f}")#text(", we obtain a contradiction. ")#mi("\\Box")#linebreak()#text(" We also note an easy converse inclusion: if ")#mi("{U}")#text(" is a standard open subset of a standard normed vector space ")#mi("{X}")#text(", then")

#align(center)[#tao-fit-display[#mitex("U \\oplus o(X) \\subset {}^* U.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Suppose that the standard normed vector space ")#mi("{X}")#text(" is separable. Establish the converse implications, that a standard subset ")#mi("{K}")#text(" of ")#mi("{X}")#text(" is compact whenever ")#mi("{{}^* K \\subset K \\oplus o(X)}")#text(", and a standard subset ")#mi("{U}")#text(" is open whenever ")#mi("{U \\oplus o(X) \\subset {}^* U}")#text(". (The hypothesis of separability can be relaxed if one imposes stronger saturation properties on the nonstandard universe than ")#mi("{\\aleph_1}")#text("-saturation.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{f: K \\rightarrow {\\bf R}}")#text(" be a standard function on a standard subset ")#mi("{K}")#text(" of a normed vector space ")#mi("{X}")#text(", and let ")#mi("{{}^* f: {}^* K \\rightarrow {}^* {\\bf R}}")#text(" be the nonstandard counterpart.")

#list(
[#text("(i) Show that ")#mi("{f}")#text(" is bounded if and only if ")#mi("{{}^* f(x) = O(1)}")#text(" for all ")#mi("{x \\in {}^* K}")#text(".")],
[#text("(ii) Show that ")#mi("{f}")#text(" is continuous (in the strong topology) if and only if ")#mi("{{}^* f(y) = f(x) + o(1)}")#text(" whenever ")#mi("{x \\in K}")#text(", ")#mi("{y \\in {}^* K}")#text(" are such that ")#mi("{y}")#text(" is strongly equivalent to ")#mi("{x}")#text(".")],
[#text("(iii) Show that ")#mi("{f}")#text(" is uniformly continuous (in the strong topology) if and only if ")#mi("{{}^* f(y) = {}^* f(x) + o(1)}")#text(" whenever ")#mi("{x, y \\in {}^* K}")#text(" are such that ")#mi("{y}")#text(" is strongly equivalent to ")#mi("{X}")#text(".")],
[#text("(iv) If ")#mi("{K}")#text(" is compact, show that ")#mi("{K = \\mathrm{st}({}^* K)}")#text(". Conclude the well-known fact that a standard continuous function on a compact set ")#mi("{K}")#text(" is uniformly continuous and bounded.")]
)
]

#text("Now we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Compact embeddings)")]#text(" ")#metadata(none) <tao-b6b54201f23d00f5b719>#text(" If ")#mi("{X \\subset Y}")#text(" is a compact embedding of standard normed vector spaces ")#mi("{X,Y}")#text(", then")

#align(center)[#tao-fit-display[#mitex("O(X) \\subset Y \\oplus o(Y).")]]

#text("If furthermore the closed unit ball of ")#mi("{X}")#text(" is compact (not just precompact) in ")#mi("{Y}")#text(", we can sharpen this to")

#align(center)[#tao-fit-display[#mitex("O(X) \\subset X \\oplus o(Y).")]]
]

#text("This is the analogue of Proposition 3 of ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("Notes 2")]#text(".")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" Since ")#mi("{X \\cap o(Y) \\subset Y \\cap o(Y) = \\{0\\}}")#text(", it suffices to show that every ")#mi("{f \\in O(X)}")#text(" can be written as ")#mi("{f = g + h}")#text(" with ")#mi("{g \\in X}")#text(" and ")#mi("{h \\in o(Y)}")#text(". But this is immediate from Lemma ")#link(<tao-659eee59f002e69bf905>)[#text("5")]#text(" (applied to the closure in ")#mi("{Y}")#text(" of a closed unit ball in ")#mi("{X}")#text("). ")#mi("\\Box")#linebreak()#text(" From the above theorem and the Arzelá-Ascoli theorem, we see for instance that a nonstandard Lipschitz function from ")#mi("{[0,1]}")#text(" to ")#mi("{{\\bf R}}")#text(" with bounded nonstandard Lipschitz norm can be expressed as the sum of a standard Lipschitz function and a function which is infinitesimal in the uniform norm. Here is a more general version of this latter assertion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Nonstandard version of Arzelá-Ascoli)")]#text(" ")#metadata(none) <tao-fdd33982464b25638709>#text(" Let ")#mi("{U \\subset {\\bf R}^d}")#text(" be a standard open set, and let ")#mi("{f: {}^* U \\rightarrow {}^* {\\bf R}}")#text(" be a nonstandard function obeying the following axioms:")

#list(
[#text("(i) (Pointwise boundedness) For all ")#mi("{x \\in U}")#text(", we have ")#mi("{f(x) = O(1)}")#text(".")],
[#text("(ii) (Pointwise equicontinuity) For all ")#mi("{x \\in U}")#text(", we have ")#mi("{f(y) = f(x) + o(1)}")#text(" whenever ")#mi("{y \\in {}^* U}")#text(" and ")#mi("{y = x + o(1)}")#text(".")]
)

#text("Let ")#mi("{\\mathrm{st} f: U \\rightarrow {\\bf R}}")#text(" denote the function")

#align(center)[#tao-fit-display[#mitex("(\\mathrm{st} f)(x) := \\mathrm{st}(f(x))")]]

#text("(this is well-defined by pointwise boundedness). Then ")#mi("{\\mathrm{st} f: U \\rightarrow {\\bf R}}")#text(" is continuous, and its nonstandard representative ")#mi("{{}^* (\\mathrm{st}(f)): {}^* U \\rightarrow {}^* {\\bf R}}")#text(" is locally infinitesimally close to ")#mi("{f}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("f(x) = ({}^* (\\mathrm{st} f))(x) + o(1)")]]

#text("whenever ")#mi("{x \\in U + o(1)}")#text(". Conclude in particular that for every standard compact ")#mi("{K \\subset X}")#text(" there exists an infinitesimal ")#mi("{\\varepsilon_K = o(1)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x) - ({}^* (\\mathrm{st} f))(x)\\right| \\leq \\varepsilon_K", block: true)]]

#text("for all ")#mi("{x \\in {}^* K}")#text(".")
]

#text("We remark that the above discussion for normed vector spaces also extends without difficulty to Frechet spaces ")#mi("{X}")#text(" that have at most countably many seminorms ")#mi("{\\| \\|_\\alpha, \\alpha \\in A}")#text(", with ")#mi("{O(X)}")#text(" now consisting of those ")#mi("{f \\in {}^* X}")#text(" with ")#tao-math("{{}^* \\left\\|f\\right\\|_\\alpha = O(1)}", block: false)#text(" for all ")#mi("{\\alpha \\in A}")#text(", and ")#mi("{o(X)}")#text(" now consisting of those ")#mi("{f \\in {}^* X}")#text(" with ")#tao-math("{{}^* \\left\\|f\\right\\|_\\alpha = o(1)}", block: false)#text(" for all ")#mi("{\\alpha \\in A}")#text(".")#linebreak()#text(" Now suppose we work with the dual space ")#mi("{X^*}")#text(" of a normed vector space ")#mi("{X}")#text(". (Here unfortunately we have a clash of notation, as the asterisk will now be used both to denote nonstandard representative and dual; hopefully the mathematics will still be unambiguous.) A nonstandard element ")#mi("{\\lambda}")#text(" of ")#mi("{{}^*(X^*)}")#text(" (thus, a nonstandardly continuous linear functional ")#mi("{\\lambda: {}^* X \\rightarrow {}^* {\\bf R}}")#text(") is said to be ")#emph[#text("weak*-bounded")]#text(" if ")#mi("{\\lambda(f) = O(1)}")#text(" for all ")#mi("{f \\in X}")#text(", and ")#emph[#text("weak*-infinitesimal")]#text(" if ")#mi("{\\lambda(f) = o(1)}")#text(". The space of weak*-bounded elements of ")#mi("{{}^*(X^*)}")#text(" will be denoted ")#mi("{O_{w^*}(X^*)}")#text(", and the space of weak*-infinitesimal elements denoted ")#mi("{o_{w^*}(X^*)}")#text(". These are related to the strong counterparts ")#mi("{O(X^*), o(X^*)}")#text(" of these spaces by the inclusions")

#align(center)[#tao-fit-display[#mitex("O(X^*) \\subset O_{w^*}(X^*); \\quad o(X^*) \\subset o_{w^*}(X^*);")]]

#text("we also have the inclusion")

#align(center)[#tao-fit-display[#mitex("X \\oplus o_{w^*}(X^*) \\subset O_{w^*}(X_*).")]]

#text("For instance, if ")#mi("{H = H^*}")#text(" is a standard Hilbert space with orthonormal system ")#mi("{e_n, n \\in {\\bf N}}")#text(", and ")#mi("{N}")#text(" is an unbounded natural number, then ")#mi("{e_N}")#text(" lies in ")#mi("{o_{w^*}(H)}")#text(" (and hence also in ")#mi("{O_{w^*}(H)}")#text(") and in ")#mi("{O(H)}")#text(" but not in ")#mi("{o(H)}")#text(". For a more subtle example, if we form the nonstandard universe ")#mi("{{\\mathfrak U}}")#text(" by taking an ultrapower with respect to an ultrafilter that deems all sets of density zero to be negligible, and one takes ")#mi("{N}")#text(" to be the ultralimit of the sequence ")#mi("{(n)_{n \\in {\\bf N}}}")#text(", then ")#mi("{N^{1/2} e_N}")#text(" also lies in ")#mi("{o_{w^*}(H)}")#text(" (and hence also in ")#mi("{O_{w^*}(H)}")#text(") but not in ")#mi("{O(H)}")#text(" or ")#mi("{o(H)}")#text(", basically because for any ")#mi("{f \\in H}")#text(", the inner products ")#mi("{\\langle f, N^{1/2} e_N \\rangle}")#text(" converge to zero in density. (Thus we see a slight difference here between the classical notion of weakly bounded sequences, which on Banach spaces are equivalent to bounded sequences by the Banach-Steinhaus theorem.)")#linebreak()#text(" (One could also develop similar notations in which one uses weak topologies instead of the weak* topology, but we will not need the weak topology in these notes.)")#linebreak()#text(" We have the following nonstandard version of the Banach-Alaoglu theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Nonstandard version of Banach-Alaoglu)")]#text(" ")#metadata(none) <tao-f62a71dd25849a1fdde9>#text(" If ")#mi("{X}")#text(" is a normed vector space with dual ")#mi("{X^*}")#text(", then we have the inclusion")

#align(center)[#tao-fit-display[#mitex("O(X^*) \\subset X^* \\oplus o_{w^*}(X^*).")]]
]

#emph[#text("Proof:")]#text(" Since ")#mi("{X^* \\cap o_{w^*}(X^*)}")#text(", it suffices to show that every ")#mi("{\\lambda \\in O(X^*)}")#text(" can be decomposed as ")#mi("{\\lambda = \\xi + \\eta}")#text(" for some ")#mi("{\\xi \\in X^*}")#text(" and ")#mi("{\\eta \\in o_{w^*}(X^*)}")#text(".")#linebreak()#text(" Let ")#mi("{\\lambda \\in O(X^*)}")#text(", thus there is a standard ")#mi("{C}")#text(" such that ")#tao-math("{\\left|\\lambda(x)\\right| \\leq C {}^* \\left\\|x\\right\\|_{{}^* X}}", block: false)#text(" for all ")#mi("{x \\in {}^* X}")#text(". In particular, if we define ")#mi("{\\xi(f) := \\mathrm{st} \\lambda(f)}")#text(" for ")#mi("{f \\in X}")#text(", then ")#mi("{\\xi}")#text(" depends linearly on ")#mi("{X}")#text(" and ")#tao-math("{\\left|\\xi(f)\\right| \\leq C \\left\\|f\\right\\|_X}", block: false)#text(" for all ")#mi("{f \\in X}")#text("; thus ")#mi("{\\xi}")#text(" is an element of ")#mi("{X^*}")#text(". Setting ")#mi("{\\eta := \\lambda - \\xi}")#text(", we see from construction that ")#mi("{\\lambda(f) = o(1)}")#text(" for all ")#mi("{f \\in X}")#text(", giving the claim. ")#mi("\\Box")#linebreak()#text(" Theorem ")#link(<tao-f62a71dd25849a1fdde9>)[#text("10")]#text(" can be compared with Proposition 2 of ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("Notes 2")]#text(", except in this nonstandard analysis setting, no separability is required on the predual space ")#mi("{X}")#text(".")#linebreak()#text(" If ")#mi("{T: X \\rightarrow Y}")#text(" is a standard bounded linear operator between normed vector spaces, then one has a nonstandard linear operator ")#mi("{{}^* T: {}^* X \\rightarrow {}^* Y}")#text(". It is easy to see that this operator maps ")#mi("{O(X)}")#text(" to ")#mi("{O(Y)}")#text(" and ")#mi("{o(X)}")#text(" to ")#mi("{o(Y)}")#text(". The adjoint operator ")#mi("{T^*: Y^* \\rightarrow X^*}")#text(" similarly maps ")#mi("{O(Y^*)}")#text(" to ")#mi("{O(X^*)}")#text(" and ")#mi("{o(Y^*)}")#text(" to ")#mi("{o(X^*)}")#text(", but also takes ")#mi("{O_{w^*}(Y^*)}")#text(" to ")#mi("{O_{w^*}(X^*)}")#text(" and ")#mi("{o_{w^*}(Y^*)}")#text(" to ")#mi("{o_{w^*}(X^*)}")#text(".")#linebreak()#text(" A (nonstandard) linear operator ")#mi("{P: O(X^*) \\rightarrow O(X^*)}")#text(" will be said to be an ")#emph[#text("approximate identity")]#text(" on ")#mi("{O(X^*)}")#text(" if ")#mi("{I-P}")#text(" maps ")#mi("{O(X^*)}")#text(" to ")#mi("{o_{w^*}(X^*)}")#text(". Here are two basic and useful examples of such approximate identities:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" (Frequency and spatial localisation as approximate identities)")

#list(
[#text("(i) For standard ")#mi("{1 < p \\leq \\infty}")#text(" and unbounded ")#mi("{N > 0}")#text(", show that the nonstandard Littlewood-Paley projection ")#mi("{P_{\\leq N}}")#text(" is an approximate identity on ")#mi("{O(L^p({\\bf R}^d))}")#text(", and more generally on the Sobolev spaces ")#mi("{O(W^{p,k}({\\bf R}^d))}")#text(" for any standard natural number ")#mi("{k}")#text(".")],
[#text("(ii) For standard ")#mi("{1 < p < \\infty}")#text(" and unbounded ")#mi("{R>0}")#text(", and a standard test function ")#mi("{\\psi \\in C^\\infty_c({\\bf R}^d)}")#text(" that equals ")#mi("{1}")#text(" near the origin, show that the nonstandard spatial truncation opertor ")#mi("{f(\\cdot) \\mapsto \\psi(\\cdot/{\\bf R}) f(\\cdot)}")#text(" is an approximate identity on ")#mi("{O(L^p({\\bf R}^d))}")#text(", and more generally on the Sobolev spaces ")#mi("{O(W^{p,k}({\\bf R}^d))}")#text(" for any standard natural number ")#mi("{k}")#text(". What happens at ")#mi("{p=\\infty}")#text("?")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Nonstandard analysis and distributions — ")]]

#text("Let ")#mi("{U \\subset {\\bf R}^d}")#text(" be a standard open set. The dual of the standard space ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(" of test functions on ")#mi("{U}")#text(" is the standard space ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})^*}")#text(" of distributions. Like any other standard space, it has a nonstandard counterpart ")#mi("{*(C^\\infty_c(U \\rightarrow {\\bf R})^*)}")#text(", whose elements are the nonstandard distributions.")#linebreak()#text(" A nonstandard distribution ")#mi("{\\lambda \\in {}^*(C^\\infty_c(U \\rightarrow {\\bf R})^*)}")#text(" will be said to be ")#emph[#text("weakly bounded")]#text(" if, for any standard compact set ")#mi("{K \\subset U}")#text(", there is a standard natural number ")#mi("{k}")#text(" and standard ")#mi("{C>0}")#text(" such that one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\lambda(f)\\right| \\leq C \\left\\| f \\right\\|_{C^k(K \\rightarrow {\\bf R})}", block: true)]]

#text("for all standard ")#mi("{f\\in C^k(K \\rightarrow {\\bf R})}")#text(". (It would be slightly more accurate to use the terminology “weak-* bounded” instead of “weakly bounded”, but we will omit the asterisk here to make the notation a little less clunky. Similarly for the related concepts below) Thus for instance any standard distribution is weakly bounded, and if ")#mi("{X}")#text(" is any normed vector space structure on ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(" that is continuous in the test function topology, and ")#mi("{\\lambda \\in O(X^*)}")#text(", then ")#mi("{\\lambda}")#text(" will be weakly bounded. We say that a nonstandard distribution ")#mi("{\\lambda}")#text(" is ")#emph[#text("weakly infinitesimal")]#text(" if one has ")#mi("{\\lambda(f) = o(1)}")#text(" for all standard ")#mi("{f \\in C^\\infty_c(U \\rightarrow {\\bf R})}")#text(". For instance, if ")#mi("{X}")#text(" is any normed vector space structure on ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(" and ")#mi("{\\lambda = o(X^*)}")#text(", then ")#mi("{\\lambda}")#text(" will be weakly infinitesimal. We say that two nonstandard distributions ")#mi("{\\lambda, \\lambda^{\\prime}}")#text(" are ")#emph[#text("weakly equivalent")]#text(", and write ")#mi("{\\lambda \\sim \\lambda^{\\prime}}")#text(", if they differ by a weakly infinitesimal distribution, thus")

#align(center)[#tao-fit-display[#mitex("\\lambda(f) = \\lambda^{\\prime}(f) + o(1)")]]

#text("for all standard test functions ")#mi("{f \\in C^\\infty_c(U \\rightarrow {\\bf R})}")#text(".")#linebreak()#text(" If ")#mi("{\\lambda}")#text(" is a weakly bounded distribution, we can define the ")#emph[#text("weakly standard part")]#text(" ")#mi("{\\mathrm{st}_w(\\lambda) \\in C^\\infty_c(U \\rightarrow {\\bf R})^*}")#text(" to be the distribution defined by the formula")

#align(center)[#tao-fit-display[#mitex("(\\mathrm{st}_w(\\lambda))(f) := \\mathrm{st}(\\lambda(f)).")]]

#text("This is the unique standard distribution that is weakly equivalent to ")#mi("{\\lambda}")#text(". As such, it must be compatible with the other decompositions of the preceding section. For instance, if ")#mi("{X}")#text(" is a normed vector space structure on ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(" and ")#mi("{\\lambda \\in O(X^*)}")#text(", then the decomposition ")#mi("{\\lambda = \\mathrm{st}_w(\\lambda) + (\\lambda - \\mathrm{st}_w(\\lambda) )}")#text(" must agree with the one in Theorem ")#link(<tao-f62a71dd25849a1fdde9>)[#text("10")]#text(", thus ")#mi("{\\mathrm{st}_w(\\lambda) \\in X^*}")#text(" and ")#mi("{\\lambda - \\mathrm{st}_w(\\lambda) = o_{w^*}(X^*)}")#text(". In particular, if ")#mi("{X^*}")#text(" embeds compactly into a normed vector space ")#mi("{Y}")#text(", we also have ")#mi("{\\lambda - \\mathrm{st}_w(\\lambda) = o(Y)}")#text(", thus weak equivalence in ")#mi("{O(X^*)}")#text(" implies strong equivalence in ")#mi("{O(Y)}")#text(". By the definition of the dual norm we also conclude the Fatou-type inequality ")#metadata(none) <tao-fee9c0a0cd6b109ede4b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\mathrm{st}_w(\\lambda) \\right\\|_{X^*} \\leq \\mathrm{st} \\left\\| \\lambda \\right\\|_{{}^* X^*}", block: true)]]

#text("whenever ")#mi("{\\lambda \\in O(X^*)}")#text(".")#linebreak()#text(" Informally, ")#mi("{\\mathrm{st}_w(\\lambda)}")#text(" represents the portion of ")#mi("{\\lambda}")#text(" that one can “observe” at standard physical scales and standard frequency scales, ignoring all components of ")#mi("{\\lambda}")#text(" that are at unbounded or infinitesimal physical or frequency scales. The following examples may help illustrate this point:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 12")]#text(" Let ")#mi("{N}")#text(" be an unbounded natural number, and on ")#mi("{{\\bf R}}")#text(" let ")#mi("{\\lambda}")#text(" be the nonstandard distribution ")#mi("{\\lambda(x) := \\sin(Nx)}")#text(". Then ")#mi("{\\lambda}")#text(" is weakly infinitesimal, so ")#mi("{\\mathrm{st}_w(\\lambda) = 0}")#text(". This is in contrast to the pointwise standard part ")#mi("{\\mathrm{st} \\lambda(x) = \\mathrm{st}(Nx)}")#text(", which is a rather wild (and almost certainly non-measurable) function from ")#mi("{{\\bf R}}")#text(" to ")#mi("{[-1,1]}")#text(". The nonstandard distribution ")#mi("{N \\sin(Nx)}")#text(" is not even pointwise bounded in general, so does not have a pointwise standard part, but is still weakly infinitesimal and so ")#mi("{\\mathrm{st}_w(\\lambda)=0}")#text(". Similarly if one replaces ")#mi("{\\sin(Nx)}")#text(" by ")#mi("{\\psi(x-N)}")#text(" for some standard bump function ")#mi("{\\psi \\in C^\\infty_c({\\bf R})}")#text(".")
]

#text("The following table gives the analogy between these nonstandard analysis concepts, and the more familiar ones from sequential weak compactness theory:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Standard distribution ")#mi("{\\lambda}")],
table.cell(colspan: 1, rowspan: 1)[#text("Distribution ")#mi("{\\lambda}")],
table.cell(colspan: 1, rowspan: 1)[#text("Nonstandard distribution ")#mi("{\\lambda}")],
table.cell(colspan: 1, rowspan: 1)[#text("Sequence of distributions ")#mi("{\\lambda_n}")],
table.cell(colspan: 1, rowspan: 1)[#text("Embedding ")#mi("{{}^*\\lambda}")#text(" of standard distribution ")#mi("{\\lambda}")],
table.cell(colspan: 1, rowspan: 1)[#text("Constant sequence ")#mi("{\\lambda_n = \\lambda}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda = O(X)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda_n}")#text(" is bounded in ")#mi("{X}")#text(" norm")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda = o(X)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda_n}")#text(" converges strongly to zero in ")#mi("{X}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda \\in X +o(X)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda_n}")#text(" converges in ")#mi("{X}")#text(" norm (possibly after passing to subsequence)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda = O_{w^*}(X^*)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda_n}")#text(" is weak-* bounded in ")#mi("{X^*}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda = o_{w^*}(X^*)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda_n}")#text(" converges weak-* to zero in ")#mi("{X^*}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda}")#text(" is weakly infinitesimal")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\lambda_n}")#text(" converges to zero in distribution")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\mathrm{st}_w(\\lambda)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Weak limit of ")#mi("{\\lambda_n}")#text(" (possibly after passing to subsequence)")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{f \\in O( L^2( U \\rightarrow {\\bf R}) )}")#text(", establish the Pythagorean identity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^2(U \\rightarrow {\\bf R})}^2 = \\left\\| \\mathrm{st}(f) \\right\\|_{L^2(U \\rightarrow {\\bf R})}^2 + \\left\\| f - \\mathrm{st}(f) \\right\\|_{L^2(U \\rightarrow {\\bf R})}^2.", block: true)]]

#text("This identity can be used as a starting point for the theory of concentration compactness, as discussed in ")#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition")[#text("these notes")]#text(". What happens in other ")#mi("{L^p}")#text(" spaces?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that every standard distribution ")#mi("{\\lambda \\in C^\\infty_c(U \\rightarrow {\\bf R})^*}")#text(" is the weakly standard part of some weakly bounded nonstandard test function ")#mi("{f: {}^* {\\bf C}^\\infty_c(U \\rightarrow {\\bf R})}")#text(". (")#emph[#text("Hint:")]#text(" When ")#mi("{U}")#text(" is ")#mi("{{\\bf R}^d}")#text(", one can convolve with a nonstandard approximation to the identity and also apply a nonstandard spatial cutoff. When ")#mi("{U}")#text(" is a proper subset of ")#mi("{{\\bf R}^d}")#text(" one also has to smoothly cut off outside an infinitesimal neighbourhood of the boundary of ")#mi("{U}")#text(" if one wants to make the convolution well defined.) This result can be viewed as analogous to the previous observation that every standard real is the standard part of a bounded rational. This also provides an alternate way to construct distributions, as weakly bounded nonstandard test functions up to weak equivalence.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Arzela-Ascoli, nonstandard distributional form)")]#text(" ")#metadata(none) <tao-8760d12e729567e54d6e>#text(" If ")#mi("{f \\in {}^* C(U \\rightarrow {\\bf R})}")#text(" is a nonstandard continuous function obeying the pointwise boundedness and pointwise equicontinuity axioms from Exercise ")#link(<tao-fdd33982464b25638709>)[#text("9")]#text(". Show that ")#mi("{f}")#text(" is also a weakly bounded distribution and that the weakly standard part of ")#mi("{f}")#text(" agrees with the pointwise standard part: ")#mi("{\\mathrm{st}_w f = \\mathrm{st} f}")#text(". In particular, if ")#mi("{f}")#text(" is also weakly infinitesimal, conclude that ")#tao-math("{\\left\\| f \\right\\|_{{}^* C(K)} = o(1)}", block: false)#text(" for every standard compact set ")#mi("{K \\subset {\\bf R}}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. Leray-Hopf solutions to Navier-Stokes — ")]]

#text("For ")#mi("{u_0 \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" that is divergence-free, recall that a ")#emph[#text("Leray-Hopf solution")]#text(" to the Navier-Stokes equations on ")#mi("{[0,+\\infty) \\times {\\bf R}^d}")#text(" is a distribution ")#mi("{u \\in L^\\infty_t L^2_x( {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}^d )}")#text(" vanishing outside of ")#mi("{[0,+\\infty) \\times {\\bf R}^d}")#text(" that has the additional regularity")

#align(center)[#tao-fit-display[#mitex("\\nabla u \\in L^2_t L^\\infty_x({\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2})")]]

#text("obeying the energy inequality ")#metadata(none) <tao-7fbae73ee235aad04aa3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\frac{1}{2} \\int_{{\\bf R}^d} \\left|u(T,x)\\right|^2\\ dx + \\nu \\int_0^T \\int_{{\\bf R}^d} \\left|\\nabla u(t,x)\\right|^2\\ dx dt \\leq \\frac{1}{2} \\int_{{\\bf R}^d} \\left|u_0(x)\\right|^2\\ dx", block: true)]]

#text("for almost all ")#mi("{T \\in [0,+\\infty)}")#text(", and solves the equation ")#metadata(none) <tao-c1c2174d29233673fea2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial_t u + \\partial_j \\mathbb{P} (u_j u) = \\nu \\Delta u + \\delta(t) u_0(x)")]]

#text("in the sense of distributions. We now give a nonstandard interpretation of this concept:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 16 (Nonstandard interpretation of Leray-Hopf solution)")]#text(" ")#metadata(none) <tao-b7b88b0c808ffb92f58d>#text(" Let ")#mi("{u_0 \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" be divergence-free. Let ")#mi("{u: {}^* ([0,+\\infty) \\times {\\bf R}^d) \\rightarrow {}^* {\\bf R}^d}")#text(" be a nonstandard smooth function obeying the following properties:")

#list(
[#text("(i) (Energy inequality) For all nonstandard ")#mi("{T \\in {}^*[0,+\\infty)}")#text(", one has the nonstandard energy inequality")

#metadata(none) <tao-58925ceba237648814f1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\frac{1}{2} \\int_{{}^* {\\bf R}^d} \\left|u(T,x)\\right|^2\\ dx + \\nu \\int_{{}^* [0,T]} \\int_{{}^* {\\bf R}^d} \\left|\\nabla u(t,x)\\right|^2\\ dx", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\frac{1}{2} \\int_{{}^* {\\bf R}^d} \\left|u_0(x)\\right|^2\\ dx + o(1).", block: true)]]

#text("Here of course we use the nonstandard version of the Lebesgue integral, and extend ")#mi("{u_0}")#text(" to ")#mi("{{}^* {\\bf R}^d}")#text(" in the usual fashion (i.e., we identify ")#mi("{u_0}")#text(" with ")#mi("{{}^* u_0}")#text(").")],
[#text("(ii) (Initial data) We have ")#mi("{u(0,\\cdot) \\sim u_0(x)}")#text(".")],
[#text("(iii) (Weak time regularity) For any standard ")#mi("{N,T>0}")#text(", ")#mi("{P_{\\leq N} \\partial_t u \\in O( L^2_t L^\\infty_x( [0,T] \\times {\\bf R}^d) )}")#text(".")],
[#text("(iv) (Navier-Stokes) On ")#mi("{{}*^( [0,+\\infty) \\times {\\bf R}^d )}")#text(", one has the nonstandard (classical) forced Navier-Stokes equation")

#metadata(none) <tao-545ea538461003efdc8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\partial_t u + \\partial_j \\mathbb{P} (u_j u) = \\nu \\Delta u + F")]]

#text("where the forcing term ")#mi("{F}")#text(", after extending by zero to ")#mi("{{}^*({\\bf R} \\times {\\bf R}^d)}")#text(", is weakly infinitesimal.")]
)

#text("Then after extending ")#mi("{u}")#text(" by zero to ")#mi("{{}^*({\\bf R} \\times {\\bf R}^d)}")#text(", ")#mi("{u}")#text(" is weakly bounded and ")#mi("{\\mathrm{st}_w u}")#text(" is a Leray-Hopf solution to Navier-Stokes. Conversely, every such Leray-Hopf solution arises in this fashion.")
]

#text("Thus, roughly speaking, Leray-Hopf solutions arise from nonstandard strong solutions to Navier-Stokes in which one permits weakly infinitesimal changes to the initial data and forcing term, which are arbitrary save for the constraint that these changes do not add more than an infinitesimal amount of energy to the system, and which also obey a technical but weak condition on the time derivative. Thus, for instance, one can insert a nonstandard frequency mollification at an unbounded frequency cutoff ")#mi("{N}")#text(", or a spatial truncation at an unbounded spatial scale ")#mi("{R}")#text(", without difficulty (so long as one checks that such modifications do not introduce more than an infinitesimal amount of energy into the system), which can be used to recover the standard construction of Leray-Hopf solutions.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" First suppose that ")#mi("{u}")#text(" obeys all the axioms (i)-(iv). We now repeat the arguments used to prove Theorem 14 of ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("Notes 2")]#text(", but translated to the language of nonstandard analysis. (All the key inputs are still basically the same; the changes are almost all entirely in the surrounding formalism.)")#linebreak()#text(" From (i) we see that")

#align(center)[#tao-fit-display[#mitex("u \\in O( L^\\infty_t L^2_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\nabla u \\in O( L^2_t L^2_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2}))")]]

#text("which implies that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{st}_w u \\in L^\\infty_t L^2_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\nabla \\mathrm{st}_w u \\in L^2_t L^2_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2}).")]]

#text("Also, for every standard ")#mi("{0 < T < \\infty}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("u \\in O( L^2_t H^1_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d))")]]

#text("and hence by Sobolev embedding")

#align(center)[#tao-fit-display[#mitex("u \\in O( L^2_t L^p_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d))")]]

#text("for ")#mi("{p>2}")#text(" sufficiently close to ")#mi("{2}")#text(". From Hölder this gives")

#align(center)[#tao-fit-display[#mitex("u_j u \\in O( L^1_t L^{p/2}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d))")]]

#text("and then by the boundedness of the Leray projector")

#align(center)[#tao-fit-display[#mitex("\\mathbb{P}( u_j u ) \\in O( L^1_t L^{p/2}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)).")]]

#text("We have")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + \\partial_j \\mathbb{P}(u_j u) = \\nu \\Delta u + F + \\delta(t) u(0,x)")]]

#text("in the sense of nonstandard distributions. Taking weakly standard part, we will obtain a weak solution to the Navier-Stokes equations as long as")

#align(center)[#tao-fit-display[#mitex("\\mathrm{st}_w \\mathbb{P}(u_j u) = \\mathbb{P}(\\mathrm{st}_w u_j \\mathrm{st}_w u).")]]

#text("Both sides lie in ")#mi("{L^1_t L^{p/2}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", but the equality requires some care. Applying a standard test function ")#mi("{\\phi \\in C^\\infty_c( {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R} )}")#text(", it suffices to show that ")#metadata(none) <tao-1143da2bc54c495c4be3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_{{}^*([0,T] \\times {\\bf R}^d)} u_j u \\cdot \\mathbb{P} \\phi\\ dx dt = \\int_{[0,T] \\times {\\bf R}^d} \\mathrm{st}_w u_j \\mathrm{st}_w u \\cdot \\mathbb{P} \\phi\\ dx dt + o(1)")]]

#text("for all such ")#mi("{\\phi}")#text(", which we can assume to be supported in ")#mi("{[0,T] \\times {\\bf R}^d}")#text(". One can check that ")#mi("{\\mathbb{P} \\phi}")#text(" lies in ")#mi("{L^\\infty_t L^{(p/2)^{\\prime}}([0,T] \\times {\\bf R}^d)}")#text(". If we can show that for every standard compact set ")#mi("{K \\subset {\\bf R}^d}")#text(" that")

#align(center)[#tao-fit-display[#mitex("\\int_{{}^*([0,T] \\times K)} u_j u \\cdot \\mathbb{P} \\phi\\ dx dt = \\int_{[0,T] \\times K} \\mathrm{st}_w u_j \\mathrm{st}_w u \\cdot \\mathbb{P} \\phi\\ dx dt + o(1)")]]

#text("hence by Corollary ")#link(<tao-e07e7aa6a214275c2404>)[#text("4")]#text(" the same claim is true for some unbounded ")#mi("{R}")#text("; however, the nonstandard ")#mi("{L^\\infty_t L^{(p/2)^{\\prime}}_x}")#text(" norm of ")#mi("{\\mathbb{P} \\phi}")#text(" outside of an unbounded ball ")#mi("{B(0,R)}")#text(" is infinitesimal, and we then conclude ")#link(<tao-1143da2bc54c495c4be3>)[#text("(6)")]#text(".")#linebreak()#text(" Fix ")#mi("{K}")#text(". By Hölder’s inequality, it now suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u_j u - \\mathrm{st}_w u_j \\mathrm{st}_w u \\right\\|_{L^1_t L^{p/2}_x( {}^* ([0,T] \\times K ) )} = o(1),", block: true)]]

#text("that is to say ")#mi("{u_j u}")#text(" is strongly equivalent to ")#mi("{\\mathrm{st}_w u_j \\mathrm{st}_w u}")#text(" in ")#mi("{L^1_t L^{p/2}_x([0,T] \\times K)}")#text(". By another application of Hölder, it suffices to show that ")#mi("{u}")#text(" is strongly equivalent to ")#mi("{\\mathrm{st}_w u}")#text(" in ")#mi("{L^2_t L^p_x([0,T] \\times K)}")#text(".")#linebreak()#text(" For unbounded ")#mi("{N}")#text(", ")#mi("{P_{\\leq N} \\mathrm{st}_w u}")#text(" is strongly equivalent to ")#mi("{\\mathrm{st}_w u}")#text(" in ")#mi("{L^2_t L^p_x([0,T] \\times K)}")#text("; since ")#mi("{u}")#text(" is bounded in ")#mi("{L^2_t H^1_x([0,T] \\times {\\bf R}^d)}")#text(", we also see from Bernstein’s theorem and the triangle inequality that ")#mi("{P_{\\leq N} u}")#text(" is strongly equivalent to ")#mi("{u}")#text(" in ")#mi("{L^2_t L^p_x([0,T] \\times K)}")#text(". Thus it suffices to show that for at least one unbounded ")#mi("{N}")#text(", that ")#mi("{P_{\\leq N} u}")#text(" is strongly equivalent to ")#mi("{P_{\\leq N} \\mathrm{st}_w u}")#text(" in ")#mi("{L^2_t L^p_x([0,T] \\times K)}")#text(". By overspill, it suffices to do this for arbitarily large standard ")#mi("{N}")#text(". But by Bernstein’s inequality, the difference ")#mi("{P_{\\leq N} u - P_{\\leq N} \\mathrm{st}_w u}")#text(" is bounded in ")#mi("{L^\\infty_t L^\\infty_x}")#text(", has space derivative bounded in ")#mi("{L^\\infty_t L^\\infty_x}")#text(", and time derivative bounded in ")#mi("{L^2_t L^\\infty_x}")#text(" on ")#mi("{{}^*( [0,T] \\times {\\bf R}^d )}")#text(" by hypothesis, hence is equicontinuous from the fundamental theorem of calculus and Cauchy-Schwarz; by Exercise ")#link(<tao-8760d12e729567e54d6e>)[#text("15")]#text(" we conclude that ")#mi("{P_{\\leq N} u - P_{\\leq N} \\mathrm{st}_w u}")#text(" is strongly infinitesimal in ")#mi("{L^\\infty_t L^\\infty_x([0,T] \\times K)}")#text(", and hence also in ")#mi("{L^2_t L^p_x([0,T] \\times K)}")#text(" as required.")#linebreak()#text(" To show the energy inequality for ")#mi("{\\mathrm{st}_w u}")#text(", we again repeat the arguments from ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("Notes 2")]#text(". If ")#mi("{0 < T < \\infty}")#text(" is standard and ")#mi("{\\eta_\\varepsilon \\in C^\\infty_c({\\bf R} \\rightarrow {\\bf R})}")#text(" is a standard non-negative test function supported on ")#mi("{[T,T+\\varepsilon]}")#text(" of total mass one for some small standard ")#mi("{\\varepsilon>0}")#text(", then from averaging ")#link(<tao-58925ceba237648814f1>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{T}^{T+\\varepsilon} \\int_{{}^* {\\bf R}^d} \\eta_\\varepsilon(t) \\left|u(t,x)\\right|^2\\ dx dt + \\nu \\int_{{}^* [0,T]} \\int_{{}^* {\\bf R}^d} \\left|\\nabla u(t,x)\\right|^2\\ dx", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\frac{1}{2} \\int_{{}^* {\\bf R}^d} \\left|u_0(x)\\right|^2\\ dx + o(1).", block: true)]]

#text("Taking weakly standard parts using ")#link(<tao-fee9c0a0cd6b109ede4b>)[#text("(1)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{T}^{T+\\varepsilon} \\int_{{\\bf R}^d} \\eta_\\varepsilon(t) \\left|\\mathrm{st}_w u(t,x)\\right|^2\\ dx dt + \\nu \\int_{[0,T]} \\int_{{\\bf R}^d} \\left|\\nabla \\mathrm{st}_w u(t,x)\\right|^2\\ dx", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\frac{1}{2} \\int_{{\\bf R}^d} \\left|u_0(x)\\right|^2\\ dx.", block: true)]]

#text("The energy inequality ")#link(<tao-7fbae73ee235aad04aa3>)[#text("(2)")]#text(" then follows from the Lebesgue differentiation theorem (which, incidentally, can also be translated into a nonstandard analysis framework, as discussed to some extent in ")#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/")[#text("this previous post")]#text(").")#linebreak()#text(" Now we establish the converse direction. Let ")#mi("{v}")#text(" be a Leray-Hopf solution, then from Sobolev and Hölder we have")

#align(center)[#tao-fit-display[#mitex("v_j v \\in L^2_t L^{q}_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)")]]

#text("for some ")#mi("{q>1}")#text(" sufficiently close to ")#mi("{1}")#text(", and hence from the weak Navier-Stokes equation and Bernstein’s inequality we have ")#metadata(none) <tao-d0e5afb7268111e26cc2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\partial_t P_{\\leq N} v \\in L^2_t L^\\infty_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)")]]

#text("for every standard ")#mi("{N}")#text(" (but without claiming the bound to be uniform in ")#mi("{N}")#text(").")#linebreak()#text(" Now let ")#mi("{\\varepsilon>0}")#text(" be infinitesimal and ")#mi("{N_1>0}")#text(" be unbounded, let ")#mi("{\\phi \\in C^\\infty_c({\\bf R} \\rightarrow {\\bf R})}")#text(" be a standard non-negative test function of total mass ")#mi("{1}")#text(" supported on ")#mi("{[0,1]}")#text(", and let ")#mi("{u}")#text(" be the nonstandard function")

#align(center)[#tao-fit-display[#mitex("u(t,x) := \\int_{{}^*[0,1]} \\phi(s) P_{\\leq N_1} v(t + \\varepsilon s, x )\\ ds")]]

#text("arising from performing a frequency truncation in space and a smooth averaging in time. This is a nonstandard smooth function. From Minkowski’s inequality, ")#link(<tao-7fbae73ee235aad04aa3>)[#text("(2)")]#text(", and the non-expansive nature of ")#mi("{P_{\\leq N}}")#text(" on ")#mi("{L^2}")#text(" we see that we have the energy inequality ")#link(<tao-58925ceba237648814f1>)[#text("(4)")]#text(" (in fact we do not even need the ")#mi("{o(1)}")#text(" error here). From Exercise 19 of ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("Notes 2")]#text(", we know that ")#mi("{v(t)}")#text(" converges strongly in ")#mi("{L^2}")#text(" to ")#mi("{u_0}")#text(" as ")#mi("{t \\rightarrow 0}")#text(", and hence ")#mi("{P_{\\leq N} v(\\varepsilon s, x)}")#text(" is strongly equivalent to ")#mi("{u_0}")#text(" in ")#mi("{L^2}")#text(" for all ")#mi("{s \\in {}^* [0,1]}")#text(", and hence ")#mi("{u(0)}")#text(" is also. From ")#link(<tao-d0e5afb7268111e26cc2>)[#text("(7)")]#text(" and Minkowski’s inequality we also conclude property (iii) of the proposition.")#linebreak()#text(" The only remaining thing to verify is property (iv), which we will do assuming that ")#mi("{\\varepsilon}")#text(" is sufficiently small depending on ")#mi("{N_1}")#text(". From ")#link(<tao-c1c2174d29233673fea2>)[#text("(3)")]#text(" we see that on ")#mi("{{}^* ([0,+\\infty) \\times {\\bf R}^d)}")#text(", we have (in the classical sense) that")

#align(center)[#tao-fit-display[#mitex("\\partial_t u(t,x) - \\nu \\Delta u(t,x) = - \\int_{{}^*[0,1]} \\phi(s) P_{\\leq N_1} {\\mathbb P}( v_j v )(t + \\varepsilon s, x )\\ ds")]]

#text("and so ")#link(<tao-545ea538461003efdc8c>)[#text("(5)")]#text(" holds with forcing term")

#tao-aligned(keep: true)[


#tao-math("F  & = \\partial_j \\int_{{}^*[0,1]} \\int_{{}^*[0,1]} \\phi(s) \\phi(s^{\\prime}) {\\mathbb P}( P_{\\leq N_1} v_j(t+\\varepsilon s) P_{\\leq N_1} v(t+\\varepsilon s^{\\prime}) )(x )\\ ds ds^{\\prime}", block: true)



#tao-math(" & - \\int_{{}^*[0,1]} \\phi(s) P_{\\leq N_1} {\\mathbb P}( v_j v )(t + \\varepsilon s, x )\\ ds.", block: true)
]

#text("To show that ")#mi("{F}")#text(" is weakly infinitesimal, it suffices as before to show that")

#tao-aligned(keep: true)[


#tao-math("G_j  & := \\int_{{}^*[0,1]} \\int_{{}^*[0,1]} \\phi(s) \\phi(s^{\\prime}) P_{\\leq N_1} v_j(t+\\varepsilon s) P_{\\leq N_1} v(t+\\varepsilon s^{\\prime}) )(x )\\ ds ds^{\\prime}", block: true)



#tao-math(" & - \\int_{{}^*[0,1]} \\phi(s) P_{\\leq N_1}( v_j v )(t + \\varepsilon s, x )\\ ds", block: true)
]

#text("is strongly infinitesimal in ")#mi("{L^1_t L^{p/2}([0,T] \\times K)}")#text(" for every standard ")#mi("{T}")#text(" and compact ")#mi("{K}")#text(". But from ")#link(<tao-d0e5afb7268111e26cc2>)[#text("(7)")]#text(" we know that ")#mi("{P_{\\leq N} v(t+\\varepsilon s,x) = P_{\\leq N} v(t,x) + o(1)}")#text(" for all ")#mi("{s \\in {}^* [0,1]}")#text(", ")#mi("{t \\in {}^* [0,T]}")#text(", and ")#mi("{x \\in {}^* {\\bf R}^d}")#text(", and hence by overspill one has")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N_1} v(t+\\varepsilon s,x) = P_{\\leq N_1} v(t,x) + o(1)")]]

#text("for the same range of ")#mi("{s,t,x}")#text(" if ")#mi("{\\varepsilon}")#text(" is sufficiently small depending on ")#mi("{N_1}")#text(". Thus ")#mi("{G_j}")#text(" is strongly equivalent in ")#mi("{L^\\infty_t L^\\infty_x([0,T] \\times K)}")#text(" (and hence in ")#mi("{L^1_t L^{p/2}([0,T] \\times K)}")#text(" to the commutator type expression")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N_1} v_j P_{\\leq N_1} v - P_{\\leq N_1}(v_j v).")]]

#text("But from Bernstein’s inequality and the ")#mi("{L^2_t H^1_x}")#text(" boundedness of ")#mi("{v}")#text(", we know that ")#mi("{P_{\\leq N_1} v}")#text(" is strongly equivalent to ")#mi("{v}")#text(" in ")#mi("{L^2_t L^p_x([0,T] \\times {\\bf R}^d)}")#text(", so by Hölder it suffices to show that ")#mi("{P_{>N_1}(v_j v)}")#text(" is strongly infinitesimal in ")#mi("{L^1_t L^{p/2}([0,T] \\times K)}")#text(". But this follows from the fact that ")#mi("{v}")#text(" is strongly equivalent to ")#mi("{P_{\\leq N_1/4} v}")#text(" in ")#mi("{L^2_t L^{p/2}}")#text(", and that ")#mi("{P_{>N_1}( P_{\\leq N_1/4} v_j P_{\\leq N_1/4} v)}")#text(" vanishes. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" ")#text(" The above proof shows that we can in fact demand stronger regularity on the time derivative ")#mi("{\\partial_t u}")#text(" than is required in Proposition ")#link(<tao-b7b88b0c808ffb92f58d>)[#text("16")]#text("(iii) if desired; for instance, one can place ")#mi("{\\partial_t u}")#text(" in ")#mi("{L^2_t H^{-1}_x + L^1_t L^{p/2}_x}")#text(" for ")#mi("{p>2}")#text(" close enough to ")#mi("{p}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" State and prove a more traditional analogue of this proposition that asserts (roughly speaking) that any weak limit of a sequence of smooth solutions to Navier-Stokes with changes in initial data and forcing term that converge weakly to zero, which asymptotically obeys the energy inequality, and which has some weak uniform control on the time derivative, will produce a Leray-Hopf solution, and conversely that every Leray-Hopf solution arises in this fashion.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Translate the proof of weak-strong uniqueness from Proposition 20 of ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("Notes 2")]#text(" to nonstandard analysis, by first using Proposition ")#link(<tao-b7b88b0c808ffb92f58d>)[#text("16")]#text(" to interpret the weak solution as the weakly standard part of a strong nonstandard approximate solution. (One will need the improved control on ")#mi("{\\partial_t u}")#text(" mentioned in Remark ")#link(<tao-1143da2bc54c495c4be3>)[#text("6")]#text(".)")
]

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/09/254a-supplemental-weak-solutions-from-the-perspective-of-nonstandard-analysis-optional/#comment-508611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2018")])]

#text("Is there a simple characterization of the cases in which it is simpler to work with nonstandard analysis ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/09/254a-supplemental-weak-solutions-from-the-perspective-of-nonstandard-analysis-optional/#comment-508639")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2018")])]

#text("Well, as I see it nonstandard analysis offers two main advantages: (a) it cleans up a lot of the “")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("epsilon management")]#text("“, in that one has to keep less track of whether (say) epsilon depends on delta or vice versa, and (b) it ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("allows one to directly apply")]#text(" continuous or infinitary mathematics (e.g., ergodic theory, topological group theory, algebraic geometry) to discrete or finitary mathematics (e.g., combinatorics). (As mentioned here, one also has (c) less reliance on any sort of “countability” or “separability” hypothesis on the spaces being considered, though this is a more minor advantage, for instance it can be largely duplicated in sequential analysis by switching from sequences to nets.)")#linebreak()#text(" So a good candidate for a problem which could be simplified by a nonstandard approach would be a discrete problem in which the traditional attack on the problem (a) contains plenty of epsilon type parameters ")#mi("\\varepsilon")#text(" (or even worse, growth function type parameters ")#mi("F()")#text(", as is the case for instance with modern regularity lemmas), and (b) is “trying” to use some poorly developed discrete analogue of an existing continuous mathematical theory (e.g., “approximate ergodic theory”, “approximate topological group theory”, etc.). For instance ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("my work with Breuillard and Green")]#text(" (building on earlier work of Hrushovski) on classifying approximate subgroups in discrete groups by using the theory of Hilbert’s fifth problem in topological group theory is a good example of such a problem (indeed currently there is no proof of this classification that does not go through nonstandard analysis or something closely related to it).")

#text("In the case of PDE, several of the epsilons and deltas can already be concealed using the machinery of sequences converging in various strong or weak topologies (though, as I mentioned in ")#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/")[#text("a different post")]#text(", this machinery struggles a bit more with more advanced notions such as concentration compactness), and of course PDE are already continuous instead of discrete. So admittedly the advantages of a nonstandard formalism here are rather slight (basically one is only left with (c), and also one no longer needs to keep passing to subsequences all the time). But I found it an interesting exercise to perform the translation anyway, as it led to some ways of thinking about real numbers, distributions and weak solutions that I had not fully appreciated before. Namely, in the nonstandard formalism, real numbers are the standard part of bounded nonstandard rationals, distributions are the weakly standard part of weakly bounded nonstandard test functions, and weak solutions are similarly the weakly standard part of strong approximate nonstandard solutions (with weakly infinitesimal errors) that obey some low-regularity bounds. Back in the usual sequential approach to mathematics, I knew of the analogous principles for the first two assertions (namely, reals are the limits of sequences of rationals, and distributions are the weak limits of sequences of test functions), but was a bit hazy on the third (namely, that weak solutions are always the weak limit of sequences of strong approximate solutions with errors that go weakly to zero).")

#text("Finally, as mentioned in the post, this exercise gave me a glimpse into a possible “alternate history” of the development of mathematics, in which analysis was largely formulated around nonstandard concepts such as infinitesimals instead of the orthodox approach using epsilons, deltas, and limits of sequences. In this particular case it seems this alternate foundation is largely equivalent to the one we actually have, though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/296292555065a0d437bc6ad2d8e6daeed2b04892eb79da4880fb9cc13f41a0d6-36afb27b0d6e60c0f3df1325f0960733a488dcca486547da22f78d1305b0f5d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Warren")]], [#link("https://terrytao.wordpress.com/2018/12/09/254a-supplemental-weak-solutions-from-the-perspective-of-nonstandard-analysis-optional/#comment-508705")[#strong[#text("Andrew Warren")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2018")])]

#text("Dear Terry,")

#text("You may already have run across this, but there is a rather nice monograph in this vein by Capinski and Cutland called “Nonstandard methods in stochastic fluid mechanics”. As the title suggests, they make good use of the Loeb space formulation of Browian motion/Ito calculus/etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/09/254a-supplemental-weak-solutions-from-the-perspective-of-nonstandard-analysis-optional/#comment-508834")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2018")])]

#text("Dear Terry,")#linebreak()#text(" If Sarnak and Chowla conjecture is proved completely 100% on time this Christmas holiday.How great it is! I am expecting from your big Noel gift(a gift for math")#linebreak()#text(" community not only for me)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed14a7981aeeed94016e1f80949b9e397076da0dca40bc0b6666ef8e3381c31f-c3d476b637f537e334d38f708196404590c60331f6de0a194a387747b87c2bd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GWCurvatureFlow")]], [#link("https://terrytao.wordpress.com/2018/12/09/254a-supplemental-weak-solutions-from-the-perspective-of-nonstandard-analysis-optional/#comment-508970")[#strong[#text("GWCurvatureFlow")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2018")])]

#text("Dear Terry,")

#text("Just a quick question — do you know of any reference (perhaps have done it already yourself somewhere?) to prove well-posedness for nonlinear elliptic and/or parabolic PDE with nonstandard analysis?")

#text("Would be interesting to have a nonstandard treatment!")

#text("Best,")#linebreak()#text(" Glen")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Go 2 It")]], [#link("https://terrytao.wordpress.com/2018/12/09/254a-supplemental-weak-solutions-from-the-perspective-of-nonstandard-analysis-optional/#comment-615197")[#strong[#text("Go 2 It")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("1. I wasn’t able to verify the claim, stated following Exercise 9, that for a standard Hilbert space ")#mi("H")#text(" with basis ")#mi("(e_n)")#text(" and an unbounded natural number ")#mi("N")#text(", the vector ")#mi("N e_N")#text(" lies in ")#mi("O_{w^*}(H)")#text(". Let ")#mi("f \\in H")#text(" be defined by ")#mi("f = \\sum a_n e_n")#text(", where ")#mi("a_n")#text(" vanishes ")#mi("n")#text(" is a power of two, in which case ")#mi("a_n = 1 / \\log n")#text(", so that ")#tao-math("\\sum \\left|a_n\\right|^2", block: false)#text(" is finite. Take for ")#mi("N")#text(" an unbounded power of two. Then ")#mi("\\langle f, N e_N \\rangle = N / \\log N")#text(" is unbounded. More generally, it seems that Banach–Steinhaus gives ")#mi("O_{w^*}(X^*) = O(X^*)")#text(" for a standard Banach space ")#mi("X")#text(", and in particular ")#mi("O_{w^*}(H) = O(H)")#text(" for a standard Hilbert space ")#mi("H")#text(". Did I miss something?")

#text("Typo in the same paragraph: “weak*-bounded elements of ")#mi("X^*")#text("” should presumably be “weak*-bounded elements of ")#mi("{}^*(X^*)")#text(".”")

#emph[#text("[Typo and example corrected. Interestingly, the analogue of the Banach-Steinhaus theorem in this nonstandard setting appears to be false! -T]")]

#text("2. In Exercise 13, it seems that ")#mi("o(1)")#text(" is missing, as we could otherwise take ")#mi("(1 + t)")#text(" times the characteristic function of a standard compact set of unit volume, with ")#mi("t")#text(" a nonzero infinitesimal.")

#emph[#text("[Here we are using the seminorm that is the standard part of the nonstandard norm – see the first display of Section 2. -T]")]
]
