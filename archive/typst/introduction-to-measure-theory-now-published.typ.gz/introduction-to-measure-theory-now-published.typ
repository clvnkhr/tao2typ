// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/09/15/introduction-to-measure-theory-now-published/
// Converted to Typst by tao2typ: "2026-10-14T15:18:13.397002+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "“Introduction to measure theory” now published", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("“Introduction to measure theory” now published")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 September 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/09/15/introduction-to-measure-theory-now-published/")[#text("https://terrytao.wordpress.com/2011/09/15/introduction-to-measure-theory-now-published/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("My ")#link("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")[#text("graduate text on measure theory")]#text(" (based on ")#link("https://terrytao.wordpress.com/category/teaching/245a-real-analysis/")[#text("these lecture notes")]#text(") is now ")#link("http://www.ams.org/bookstore-getitem/item=GSM-126")[#text("published by the AMS")]#text(" as part of the ")#link("http://www.ams.org/bookstore/gsmseries")[#text("Graduate Studies in Mathematics series")]#text(". (See also ")#link("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")[#text("my own blog page for this book")]#text(", which among other things contains a ")#link("https://terrytao.wordpress.com/wp-content/uploads/2012/12/gsm-126-tao5-measure-book.pdf")[#text("draft copy of the book")]#text(" in PDF format.)")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anony.")]], [#link("https://terrytao.wordpress.com/2011/09/15/introduction-to-measure-theory-now-published/#comment-84554")[#strong[#text("Anony.")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2011")])]

#text("First is Radamacher, but then Rademacher. Best")

#emph[#text("[I was unable to locate this typo. Could you provide a page number please? Thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df59056c5129bb17b05a2a44bd477674313ba53e2d13e0b3acbd0fe38f620a7e-a4c668b7b8a3023ce57a190d14816ef38c3007e17f6ed494dc36628f12188534.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S.V.")]], [#link("https://terrytao.wordpress.com/2011/09/15/introduction-to-measure-theory-now-published/#comment-88945")[#strong[#text("S.V.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2011")])]

#text("Page 228 – Rademacher (2x)")#linebreak()#text(" (btw I am not the Anony that posted the previous message.)")

#emph[#text("[Ah, got it. It turns out that this error was already corrected in the published version, which is why I couldn’t find it. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82d26bddf8f798d9503416f87e5a0249f5d7137653560d4ec9834ca5fcbfc24a-21335a55bc95cf37da351896f659fd4ef8b0ecf3f0dec3897cedd5d999ae80d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Barter")]], [#link("https://terrytao.wordpress.com/2011/09/15/introduction-to-measure-theory-now-published/#comment-139497")[#strong[#text("Daniel Barter")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2012")])]

#text("Hi Terry,")

#text("I am not sure if this has been fixed in the actual book, but exercise 1.6.13 in the draft is not true. I think it should ask you to prove that the inequality in exercise 1.6.12 is an equality.")

#emph[#text("[Thanks for the correction – T.]")]
]
