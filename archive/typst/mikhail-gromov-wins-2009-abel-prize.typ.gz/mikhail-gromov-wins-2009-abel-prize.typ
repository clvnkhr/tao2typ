// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/
// Converted to Typst by tao2typ: "2026-10-14T15:17:07.403694+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mikhail Gromov wins 2009 Abel prize", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mikhail Gromov wins 2009 Abel prize")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/")[#text("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The 2009 Abel prize ")#link("http://www.abelprisen.no/en/prisvinnere/2009/")[#text("has been awarded")]#text(" to ")#link("http://en.wikipedia.org/wiki/Mikhail_Gromov")[#text("Mikhail Gromov")]#text(", for his contributions to numerous areas of geometry, including Riemannian geometry, symplectic geometry, and geometric group theory.")

#text("The prize is, of course, richly deserved. I have mentioned some of Gromov’s work here on this blog, including the ")#link("http://en.wikipedia.org/wiki/Bishop%E2%80%93Gromov_inequality")[#text("Bishop-Gromov inequality")]#text(" in Riemannian geometry (which (together with its parabolic counterpart, the monotonicity of Perelman reduced volume) ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("plays an important role")]#text(" in Perelman’s proof of the Poincaré conjecture), the concept of ")#link("http://en.wikipedia.org/wiki/Gromov%E2%80%93Hausdorff_convergence")[#text("Gromov-Hausdorff convergence")]#text(" (a version of which")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text(" is also key")]#text(" in the proof of the Poincaré conjecture), and ")#link("http://en.wikipedia.org/wiki/Gromov%27s_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s celebrated theorem on groups of polynomial growth")]#text(", which I ")#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/")[#text("discussed in this post")]#text(".")

#text("Another well-known result of Gromov that I am quite fond of is his ")#link("http://www.ams.org/mathscinet-getitem?mr=809718")[#text("nonsqueezing theorem")]#text(" in ")#link("http://en.wikipedia.org/wiki/Symplectic_geometry")[#text("symplectic geometry")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamiltonian mechanics")]#text("). In its original form, the theorem states that a ball ")#mi("B_R^{2n}")#text(" of radius R in a symplectic vector space ")#mi("{\\Bbb R}^{2n}")#text(" (with the usual symplectic structure ")#mi("\\omega")#text(") cannot be mapped by a symplectomorphism into any cylinder ")#mi("B_r^2 \\times {\\Bbb R}^{2n-2}")#text(" which is narrower than the ball (i.e. ")#mi("r < R")#text("). This result, which was one of the foundational results in the modern theory of symplectic invariants, is sometimes referred to as the “principle of the symplectic camel”, as it has the amusing corollary that a large “camel” (or more precisely, a 2n-dimensional ball of radius R in phase space) cannot be deformed via ")#link("http://en.wikipedia.org/wiki/Canonical_transformation")[#text("canonical transformations")]#text(" to pass through a small “needle” (or more precisely through a 2n-1-dimensional ball of radius less than R in a hyperplane). It shows that ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(Hamiltonian)")[#text("Liouville’s theorem")]#text(" on the volume preservation of symplectomorphisms is not the only obstruction to mapping one object symplectically to another.")

#text("I can sketch Gromov’s original proof of the non-squeezing theorem here. The symplectic space ")#mi("{\\Bbb R}^{2n}")#text(" can be identified with the complex space ")#mi("{\\Bbb C}^n")#text(", and in particular gives an ")#link("http://en.wikipedia.org/wiki/Almost_complex_manifold")[#text("almost complex structure")]#text(" J on the ball ")#mi("B_R^{2n}")#text(" (roughly speaking, J allows one to multiply tangent vectors v by complex numbers, and in particular Jv can be viewed as v multiplied by the unit imaginary i). This almost complex structure J is compatible with the symplectic form ")#mi("\\omega")#text("; in particular J is ")#emph[#text("tamed")]#text(" by ")#mi("\\omega")#text(", which basically means that ")#mi("\\omega( v, Jv ) > 0")#text(" for all non-zero tangent vectors v.")

#text("Now suppose for contradiction that there is a symplectic embedding ")#mi("\\Phi: B_{R}^{2n} \\to B_r^2 \\times {\\Bbb R}^{2n-2}")#text(" from the ball to a smaller cylinder. Then we can push forward the almost complex structure J on the ball to give an almost complex structure ")#mi("\\Phi_* J")#text(" on the image ")#mi("\\Phi(B_R^{2n})")#text(". This new structure is still tamed by the symplectic form ")#mi("\\omega = \\Phi_* \\omega")#text(" on this image.")

#text("Just as complex structures can be used to define holomorphic functions, almost complex structures can be used to define ")#link("http://en.wikipedia.org/wiki/Pseudoholomorphic_curve")[#emph[#text("pseudo-holomorphic")]]#text(" or ")#emph[#text("J-holomorphic")]#text(" curves. These are curves of one complex dimension (i.e. two real dimensions, that is to say a surface) which obey the analogue of the Cauchy-Riemann equations in the almost complex setting (i.e. the tangent space of the curve is preserved by J). The theory of such curves was pioneered by Gromov in ")#link("http://www.ams.org/mathscinet-getitem?mr=809718")[#text("the paper where the nonsqueezing theorem was proved")]#text(". When J is the standard almost complex structure on ")#mi("{\\Bbb R}^{2n} \\equiv {\\Bbb C}^n")#text(", pseudoholomorphic curves coincide with holomorphic curves. Among other things, such curves are ")#link("http://en.wikipedia.org/wiki/Minimal_surface")[#text("minimal surfaces")]#text(" (for much the same reason that holomorphic functions are harmonic), and their symplectic areas and surface areas coincide.")

#text("Now, the point ")#mi("\\Phi(0)")#text(" lies in the cylinder ")#mi("B_r^2 \\times {\\Bbb R}^{2n-2}")#text(" and in particular lies in a disk of symplectic area ")#mi("\\pi r^2")#text(" spanning this cylinder. This disk will not be pseudo-holomorphic in general, but it turns out that it can be deformed to obtain a pseudo-holomorphic disk spanning ")#mi("\\Phi(B_R^{2n})")#text(" passing through ")#mi("\\Phi(0)")#text(" of symplectic area at most ")#mi("\\pi r^2")#text(". Pulling this back by ")#mi("\\Phi")#text(", we obtain a minimal surface spanning ")#mi("B_R^{2n}")#text(" passing through the origin that has surface area at most ")#mi("\\pi r^2")#text(". However, any minimal surface spanning ")#mi("B_R^{2n}")#text(" and passing through the origin is known to have area at least ")#mi("\\pi R^2")#text(", giving the desired contradiction. [This latter fact, incidentally, is quite a fun fact to prove; the key point is to first show that any closed loop of length strictly less than ")#mi("2 \\pi")#text(" in the sphere ")#mi("S^{2n-1}")#text(" must lie inside an open hemisphere, and so cannot be the boundary of any minimal surface spanning the unit ball and containing the origin. Thus, the symplectic camel theorem ultimately comes down to the fact that one cannot pass a unit ball through a loop of string of length less than ")#mi("2\\pi")#text(".]")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8ac10e76ba6efc8bf04050ed550db82a0eda91ba54ff2845c723e6ab1742bd0-f3c92350ff4ec849d2e12b1b78b92cc5275d73e735c18ed3a75cad6d54ea1738.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37509")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("Your blog lets me know there are many brilliant modern mathematicians in the world.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ZH")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37518")[#strong[#text("ZH")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("In the first to last paragraph, it appears that you did not provide the link for the mentioned paper of Gromov. ")#emph[#text("[Fixed – T.]")]

#text("Great post! (as usual)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37563")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e60v1")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")]

#text("[…] Another coveted prize noted as well here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0930071c858295d85a4a2a16bbaf723b3ea8dccbfba4665e49b37e6d25e10ccb-0ffddfa63ed1fb53c6f8c0d7b1a91e30280f488946db5e46ff2ea16565d336ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 张灿")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37565")[#strong[#text("张灿")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("your blog is very rich!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37619")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")]

#text("[…] Mikhail Gromov wins 2009 Abel prize The 2009 Abel prize has been awarded to Mikhail Gromov, for his contributions to numerous areas of geometry, including […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37778")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("[…] Mikhail Gromov wins 2009 Abel prize […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37785")[#strong[#text("Sujit")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("Hey Terry,")

#text("Is there any link between uncertainty principle and symplectic non squeezing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c99be9b51ffeaba0488ac5a820c66cff4fdd345c5530de317391471ca037a7-29d397b384d569338a539952d844eefa912edd9b18155a8cd25717ef3d5cce86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Academic Career Links")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37840")[#strong[#text("Academic Career Links")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("Some further information about Mikhail Gromov (including e.g. links to his biography and CV) can be found ")#link("http://www.ihes.fr/jsp/site/Portal.jsp?document_id=1834&portlet_id=1")[#text("here")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37870")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("Dear Sujit,")

#text("This is an interesting question! It is possible to view quantum mechanics (informally, at least) as sort of a “fuzzy” version of classical (Hamiltonian) mechanics, in which particles do not inhabit a single point in phase space but are instead smeared out in both position and momentum space. The time evolution of such particles is governed classically by canonical transformations, and as a first approximation (known as the ")#emph[#text("semi-classical")]#text(" approximation) one can assume that the quantum distribution of the particle is propagated by the same transformation.")

#text("Liouville’s theorem (which states that canonical transformations preserve volume) then suggests that there should be a lower bound on the volume of phase space occupied by a quantum particle; roughly speaking, this would correspond to a lower bound on ")#mi("\\Delta x_1 \\ldots \\Delta x_n \\Delta p_1 \\ldots \\Delta p_n")#text(", where n is the number of spatial dimensions. The non-squeezing theorem, in contrast, does suggest that one also gets a lower bound on ")#mi("\\Delta x_i \\Delta p_i")#text(" for each i, which is closer to the usual formulation of the Heisenberg uncertainty principle. So the two results do seem to be compatible with each other, although I do not know how to formalise the above intuition to rigorously derive the uncertainty principle from these symplectic geometry results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-37876")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("Dear Sujit and Terry,")

#text("the similarity beween Gromov’s result and quantum uncertainty is indeed intriguing, and has been noted many times before.")

#text("Unfortunately it is not so easy to work out: it’s been done only for linear Hamiltonians; already for slightly more general yet simple systems (integrable ones with compact fibers) it’s not a closed subject, not to mention non-integrable systems. See this paper ")#link("http://arxiv.org/PS_cache/math-ph/pdf/0602/0602055v1.pdf")[#text("http://arxiv.org/PS_cache/math-ph/pdf/0602/0602055v1.pdf")]#text(" by de Gosson for instance (I haven’t checked whether or not there are more recent results though).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-38084")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2009")])]

#text("These are very interesting comments on relations between Gromov’s non-squeezing theorems and quantum measurement, and I would like to offer a perspective from the viewpoint of modern quantum system engineering.")

#text("When we wish to simulate a large-scale open (noisy or measured) quantum system, it is very convenient to proceed in three stages: (1) start with the orthodox linear superoperator acting on the quantum density matrix, then (2) unravel that superoperator in terms of equivalent operations of Hamiltonian dynamics plus measurement-and-control (with all noise replaced by equivalent measurement plus control), then (3) project those operations onto a low-dimension algebraic Kahler manifold.")

#text("In this fashion all quantum systems can be systematically described by integral curves of (possibly stochastic) algebraic potentials on algebraic Kahler manifolds.")

#text("This point of view—informatic algebraic geometry—proves very congenial to writing efficient quantum simulation codes. In fact, these ideas are so powerful, and so general, that pretty much all existing large-scale quantum simulation codes ")#emph[#text("already use these ideas")]#text(" … and in fact have used them for many decades.")

#text("What is new in recent years is a growing appreciation that abstract mathematics has a great deal to teach us practical code-writers. For example, we now appreciate the fundamental reason that our codes conserve energy (in the absence of measurement processes), regardless of the dimensionality of our state-space or the details of the algebraic representation, of our reduced-order state-spaces. It’s very simple: all our reduced-order state-spaces are symplectic manifolds on which trajectories are integral curves of Hamiltonian potentials.")

#text("On a higher level of abstraction, we engineers understand Gromov’s non-squeezing theorem as a reflection of the sectional curvature properties of algebraic quantum state-spaces. In fact, we have the strong theorem (on algebraic quantum state-spaces) that on every point of the state-space, there is a over-complete set of basis vectors {U_i}, such that for any vector V and any basis vector U_i, the sectional curvatures S(U_i,V) and S(U_i,JV) are ")#emph[#text("both")]#text(" nonpositive (which is a strictly stronger result that the usual holomorphic bisectional curvature theorem).")

#text("At first sight, ergodic theorems in general, and Gromov’s nonsqueezing theorem in particular, would seem to suggest that the above results have little practical utility. Because, what mathematical justification is there for compressing quantum trajectories to a low-dimension state-space? After all, Gromov’s nonsqueezing theorem would seem to preclude the existence of any dynamical mechanism for accomplishing this compression, even on non-flat reduced-order state-spaces.")

#text("The answer lies in the algebraic potentials that describe measurement-and-control processes. As far as we engineers can tell (and as our ")#link("http://faculty.washington.edu/sidles/QSEPACK/")[#text("simulation codes")]#text(" document) the non-stochastic members of this class of potentials are associated with measures that are not invariant under dynamical flow, but rather are positive yet non-increasing, and thus act to dynamically compress trajectories onto low order state-spaces.")

#text("These practical considerations motivate me to ask this forum: is there a branch of mathematics, similar to ergodic theory, but differing in focusing upon positive measures that are not invariant under dynamical flow, but rather are non-increasing?")

#text("In practical quantum simulations, these “litotic” systems are far more commonly encountered than ergodic systems, and it is becoming apparent that they have central importance across broad sectors of engineering and molecular medicine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-38236")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("A recent application of Gromov’s theorem has been given by Maurice de Gosson: see the New Scientist paper:")

#link("http://www.newscientist.com/article/mg20126973.900-how-camels-could-explain-quantum-uncertainty.html")[#text("http://www.newscientist.com/article/mg20126973.900-how-camels-could-explain-quantum-uncertainty.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c26d59753dd4fa87fe03849912c59ac7d45fa4473f6f20f4ceb157602586baff-1794ebd3117c00c8df15aef8bd71eb2641b28073af6b831fb812506a0ecc0eda.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rathan Haran")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-39139")[#strong[#text("Rathan Haran")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2009")])]

#text("Great to see NYU Math Department continue to be recognized as the top program that they are!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-111238")[#strong[#text("Quantum Theory Talks in Asia and Australia « Azimuth")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")]

#text("[…] ‘symplectic camel’, in case you’re wondering, is an allusion to Mikhail Gromov’s result on classical mechanics limiting our ability to squeeze a region of phase space into a long and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-141019")[#strong[#text("不可挤压定理和伪全纯曲线 « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2012")]

#text("[…] 此外，Tao在Gromov获得09年Abel奖后也简要介绍了他的不可挤压定理。 Share this:FacebookLike this:LikeBe the first to like this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbc18fa1121b8fa9882913bae34c8ee95f5625eeca6286b1a2ad23ba28677eac-4b48c0ccfb856201ce86b093cbda2eddf8c25a173a1979df1f1fa74ff2800c19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observer")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-453473")[#strong[#text("observer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2015")])]

#link("http://www.ams.org/news?news_id=2621")[#text("http://www.ams.org/news?news_id=2621")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-512650")[#strong[#text("Symplectic Geometry, Quantization, and Quantum Noise | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2019")]

#text("[…] A sketch of a proof of Gromov’s non squeezing theorem is in this post by Terry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b786319088fe7466a262eb656676b297f7dd89b8ef4a019dc5292f7857d78bed-ec5c69374c3a6c4c53e4063b7199cf03f3929d87eb340e9dc4a52b20d62fa469.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Salem")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-548426")[#strong[#text("Salem")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("does the theorem imply that the projection of the image of a ball of radius r onto the plane (x1, p1) has area bigger that pi r^2 or just that you cannot pass it through a whole of radius less than r.")

#text("The first does not imply the second. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-548446")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("Hmm, good question! The standard formulation of the theorem is the former, but the result is often interpreted as the latter, but now that I look at the literature there isn’t a precise justification for the latter formulation. I’ve posted a question about it on MathOverflow: ")#link("https://mathoverflow.net/questions/355808/is-a-symplectic-camel-actually-prohibited-from-passing-through-the-eye-of-a-need")[#text("https://mathoverflow.net/questions/355808/is-a-symplectic-camel-actually-prohibited-from-passing-through-the-eye-of-a-need")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b786319088fe7466a262eb656676b297f7dd89b8ef4a019dc5292f7857d78bed-ec5c69374c3a6c4c53e4063b7199cf03f3929d87eb340e9dc4a52b20d62fa469.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Salem")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-548452")[#strong[#text("Salem")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("Thanks for the reply. What about the possibility that the area of the projection is less than pi r^2 but the projection is still not embedded in a circle. For example a thin ellipse with major axis greater than r.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-548610")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("In two dimensions I believe any region homeomorphic to a disk of the same area can be continuously deformed to that disk by (oriented) area-preserving maps, which in two-dimensions are also symplectimorphisms. Lifting this up to higher dimensions, a non-squeezing result for a disk automatically implies the same for other two-dimensional punctures of the same area.")

#text("Incidentally, the mathOverflow question now has an answer: it is possible to modify the pseudoholomorphic curve proof of the original nonsqueezing theorem to also prove the “symplectic camel” theorem.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b786319088fe7466a262eb656676b297f7dd89b8ef4a019dc5292f7857d78bed-ec5c69374c3a6c4c53e4063b7199cf03f3929d87eb340e9dc4a52b20d62fa469.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Salem")]], [#link("https://terrytao.wordpress.com/2009/03/29/mikhail-gromov-wins-2009-abel-prize/#comment-548947")[#strong[#text("Salem")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("Thanks!!")
]
]
]
]
]
