// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/
// Converted to Typst by tao2typ: "2026-10-14T15:16:28.169962+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM “deleted scene”: Wave maps", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM “deleted scene”: Wave maps")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 August 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/")[#text("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("For the past several years, my good friend and fellow Medalist ")#link("http://en.wikipedia.org/wiki/Timothy_Gowers")[#text("Timothy Gowers")]#text(" has been devoting an enormous amount of effort towards editing (with the help of ")#link("http://www.mathematics.open.ac.uk/People/j.e.barrow-green")[#text("June Barrow-Green")]#text(" and ")#link("http://en.wikipedia.org/wiki/Imre_Leader")[#text("Imre Leader")]#text(") a forthcoming book, the ")#link("http://press.princeton.edu/titles/8350.html")[#text("Princeton Companion to Mathematics")]#text(". This immense project is somewhat difficult to explain succinctly; a zeroth order approximation would be that it is an “Encyclopedia of mathematics”, but the aim is not to be a comprehensive technical reference, nor is it a repository of key mathematical definitions and theorems; it is neither ")#link("http://www.scholarpedia.org/")[#text("Scholarpedia")]#text(" nor ")#link("http://en.wikipedia.org/wiki/Main_Page")[#text("Wikipedia")]#text(". Instead, the idea is to give a flavour of a subject or mathematical concept by means of motivating examples, questions, and so forth, somewhat analogous to the “")#link("http://www.google.com/custom?q=what+is&cof=S%3Ahttp%3A%2F%2Fwww.ams.org%2Fnotices%3BGL%3A0%3BVLC%3A%23004080%3BAH%3Aleft%3BBGC%3A%23ffffff%3BLH%3A55%3BLC%3A%0D%0A%23004080%3BL%3Ahttp%3A%2F%2Fwww.ams.org%2Fimages%2Fnotices-search-banner.jpg%3BALC%3A%23ff2b2b%3BLW%3A1200%3BT%3A%23000000%3BAWFID%3A39742761a368da0f%3B&sitesearch=www.ams.org%2Fnotices&sa.x=0&sa.y=0&sa=go")[#text("What is a …?")]#text("” series in the ")#link("http://www.ams.org/notices/200708/")[#text("Notices of the AMS")]#text(". Ideally, any interested reader with a basic mathematics undergraduate education could use this book to get a rough handle on what (say) Ricci flow is and why it is useful, or what questions mathematicians are trying to answer about (say) harmonic analysis, without getting into the technical details (which are abundantly available elsewhere). There are contributions from many, many mathematicians on a wide range of topics, from symplectic geometry to modular forms to the history and influence of mathematics; I myself have contributed or been otherwise involved in about a dozen articles.")

#text("If all goes well, the Companion should be finalised later this year and available around March 2008. As a sort of “advertising campaign” for this project (and with Tim’s approval), I plan to gradually release to this blog (at the rate of one or two a month) the various articles I contributed for the project over the last few years. [As part of this advertising, I might add that the Companion can already be ")#link("http://www.amazon.com/Princeton-Companion-Mathematics-Timothy-Gowers/dp/0691118809")[#text("pre-ordered on Amazon")]#text(".]")

#text("I’ll inaugurate ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("this series")]#text(" with my ")#link("http://www.math.ucla.edu/~tao/preprints/wavemaps.pdf")[#text("article on “wave maps”")]#text(". This describes, in general terms, what a ")#link("http://tosio.math.toronto.edu/wiki/index.php/Wave_maps")[#text("wave map")]#text(" is (it is a mathematical model for a vibrating membrane in a manifold), and its relationship with other concepts such as ")#link("http://en.wikipedia.org/wiki/Harmonic_map")[#text("harmonic maps")]#text(" and ")#link("http://en.wikipedia.org/wiki/General_relativity")[#text("general relativity")]#text(". As it turns out, for editing reasons various articles solicited for the Companion had to be removed from the print edition (but possibly may survive in the on-line version of the Companion, though details are unclear at this point); Tim and I agreed that as wave maps were not the most crucial geometric PDE that needed to be covered for the Companion (there are other articles on the ")#link("http://en.wikipedia.org/wiki/Einstein_equations")[#text("Einstein equations")]#text(" and ")#link("http://en.wikipedia.org/wiki/Ricci_flow")[#text("Ricci flow")]#text(", for instance), that this particular article would end up being one of the “deleted scenes”. As such, it seems like a logical choice for the first article to release here.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of locke")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8195")[#strong[#text("locke")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2007")])]

#text("Terry, I think you may underestimate the value of the companion to research mathematicians. In particular, if the articles are similar in scope and spirit to yours on wave maps, then I can see this being a fantastic resource for getting snapshots into other (many times impenetrable without significant effort) fields.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8224")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2007")])]

#text("Hi Mr Tao,")

#text("Thanks for posting this article on wave maps. It looks within reach of my single-semester PDE knowledge (especially the KE/PE technique and limits of influence), yet describes open areas of research. I’ll look forward to further deleted scenes.")

#text("I’ve read Mr Gowers’ articles on his discussions page, and his articles on analysis really struck a chord with my experience those types of classes. Most importantly, his ideas from the “defining a definition” make him seem like just the person to edit this sort of text (at least from this undergrad’s POV).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6bb99cef8a690e2dc9417ed596bfb813757854202b29473fbc31d9ac483a13-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sgrajeev")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8241")[#strong[#text("sgrajeev")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2007")])]

#text("The wave map looks like what we call a `non-linear sigma model’ (awkward terminology for sure) in physics. Is it the same thing?")

#text("If the target is SU(2) =S^3 this is the equation for the Goldstone bosons of the chiral model, which are the pi mesons. They were first described (Gell-Mann) by the linear sigma-model in which the field took values in R^4, the fourth direction being called sigma. Then it was found (Gursey) that a better description was to get rid of a degree of freedom by restricting to the sphere, which came to be called the non-linear sigma model.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8262")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2007")])]

#text("Dear sgrajeev,")

#text("That is correct; wave maps (at least into targets such as SU(2)) are what mathematicians call the (classical) nonlinear sigma model; as far as I know, the mathematicians who study wave maps have not attempted to look at the corresponding QFT (which would be a much more complicated version of the ")#mi("\\phi^4")#text(" model, which is the quantum version of what mathematicians call the cubic nonlinear wave equation). I think the renaming of this equation was designed to deliberately invoke the analogy with harmonic maps. (And nowadays there are also “Schrodinger maps”, which are to the free Schrodinger equation as wave maps are to the free wave equation, or harmonic maps are to Laplace’s equation.) Also, we are interested in more general targets than the sphere, for instance hyperbolic space is particularly interesting for its connections to general relativity and also because this is likely to be the first non-flat target for which we will be able to establish a large data global regularity result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d52a651d26e1280ac1d8ed7335af48b9b6f33f740d9f3472f0addd44d46c2f7d-b79636e80c29bca8a79018cf53f61fd57a2d15275011202eae3e8ef4ac6b4408.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pavel Krapivsky")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8299")[#strong[#text("Pavel Krapivsky")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2007")])]

#text("Dear Terry,")

#text("It is late and I may be missing something, but it looks as the 1st displaced equation in your “wave maps” article contains a typo (u appears twice on the right-hand side); analogous misprint is in equation (2).")

#text("Best wishes for the weekend, Paul")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8347")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2007")])]

#text("Are there results in the opposite direction? i.e., that smooth data will evolve into singularities when the target is positively curved.")

#text("Physically, its is clear that a Skyrme soliton (winding number one map S^3–>S^3) will evolve as a wave map into a point-like singularity.")#linebreak()#text(" (Follows from scaling). Is it interesting to prove rigorously that such singularities develop for `large’ data? Or, perhaps it is too obvious.–Rajeev")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8352")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2007")])]

#text("Dear Terry,")

#text("By the more complicated version of the \\Phi^4 model, do you mean")#linebreak()#text(" the famous 1964 Higgs field theory for electroweak unification? Another")#linebreak()#text(" new supercollider is being built, at CERN, to find a particle it predicts,")#linebreak()#text(" the Higgs boson, also referred to as “God’s particle” by some scientific")#linebreak()#text(" magazines. E. Witten wrote about this in a recent BAMS article.")#linebreak()#text(" This may be the last frontier of experimentally verifiable serious")#linebreak()#text(" theoretical physics.")

#text("Cheers,")#linebreak()#text(" Adam")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8363")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2007")])]

#text("The article was an enjoyable read – though in addition to those typos previously pointed out, on page 5 it should be (R x R^n) instead of (R -> R^n), and “at a distance further than ct0 from x0” instead of “t0 from x0”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2007")])]

#text("Dear Pavel and Anon: thank you for the corrections!")

#text("Dear Anonymous: There are two recent papers (by Rodnianski-Sterbenz and Krieger-Schlag-Tataru) that establish singularity formation for certain large data for wave maps into the sphere:")

#link("http://arxiv.org/abs/math/0605023")[#text("http://arxiv.org/abs/math/0605023")]#linebreak()#text(" ")#link("http://arxiv.org/abs/math/0610248")[#text("http://arxiv.org/abs/math/0610248")]

#text("The two results are slightly different; the RS paper gives a stable blowup but does not have precise asymptotics, whereas the KST paper allows one to prescribe the asymptotics to some extent, but is a very unstable blowup (the initial data has to be extremely special).")

#text("Dear Adam: I am not so familiar with the Higgs model, but I believe it is slightly different, more analogous to coupling a scalar field to a Yang-Mills model than to the wave maps model (which does not involve a scalar field, but instead involves a field that takes values in a target manifold). There are broad similarities between all of these equations, though. For instance, there is a gauge symmetry in the wave maps equation (coming from a selection of an orthonormal frame on the tangent bundle of the target, or more precisely the pullback of that bundle by the wave map) which is very analogous to the gauge symmetry of a Yang-Mills model.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aef5952340bb6bff3731f98d2d3c1dd9678b3cf7a31e8adaa413d5a449849a63-2282b8795059a7dc66cca6eef5758b61dc6bc6914983ed58ca5a96044d3d7376.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of McGuigan")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-8591")[#strong[#text("McGuigan")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("Thanks for sharing your interesting article on wave maps.")#linebreak()#text(" General relativity itself has a formulation in terms of wave maps from R^3 to R x SL(3,R)/SO(3) described by DeWitt in")#linebreak()#text(" ")#link("http://prola.aps.org/abstract/PR/v160/i5/p1113_1")[#text("http://prola.aps.org/abstract/PR/v160/i5/p1113_1")]

#text("where he says:")#linebreak()#text(" “Einstein’s equations are revealed as geodesic equations in the manifold of 3-geometries, modified by the presence of a “force term.” The classical phenomenon of gravitational collapse shows that the force term is not powerful enough to prevent the trajectory of space-time from running into the frontier.”")

#text("These type of wave maps form singularities which are the same as those that occur in Einstein’s equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-9624")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2007")])]

#text("Hi Terence,")

#text("I have been thinking about this phrase in this post ‘PCM “deleted scene”: Wave maps‘:")

#text("“… on what (say) Ricci flow is and why it is useful …”")

#text("and from the post ‘Simons Lecture III: Structure and randomness in PDE’")

#text("“The most famous recent example of the use of parabolic flows to establish geometric structure from topological objects is, of course, Perelman’s use of the Ricci flow applied to compact 3-manifolds with arbitrary Riemannian metrics …”")

#text("Questions:")

#text("If the parabolic flow is also in motion, then may the flow be a parabolic catenary?")

#text("If the flow is catenary in motion, then perhaps there exists an equivalent helix flow?")

#text("If the flow is helical in motion, then perhaps these may be geodesic trajectories?")

#text("Reasons for this speculation:")

#text("1 – At Strings 07, Urs Wiedemann [CERN] ‘Jet quenching in string theory and heavy ion collisions’ commented: “Our task: find catenary” in slide 38 of 38 [last line].")

#link("http://gesalerico.ft.uam.es/strings07/040_scientific07_contents/transparences/wiedemann.pdf")[#text("Click to access wiedemann.pdf")]

#text("[These could be elliptic or hyperbolic rather than the more common parabolic catenary.]")

#text("2 – Rolling parabolic curves are catenaries.")

#text("3 – The catenoid and helicoid are in isometry, so there is probably an equivalent helix for each catenary.")

#text("4 – The helix is associated with trajectories.")

#text("a – Gun barrel rifling.")

#text("b – David Hestenes, ‘The Kinematic Origin of Complex Wave Functions’ discusses “Zitterbewegun interactions” and “helical lightlke [electromagnetic?] trajectory”")

#link("http://modelingnts.la.asu.edu/pdf/Kinematic.pdf")[#text("Click to access Kinematic.pdf")]

#text("c – “Unseen curled-up dimensions” [or equivalent wording] of:")#linebreak()#text(" i – Lisa Randall, Raman Sundrum, ’A Large Mass Hierarchy from a Small Extra Dimension’.")

#text("ii – Nima Arkani-Hamed, Savas Dimopoulos, Gia Dvali. ’The Hierarchy Problem and New Dimensions at a Millimeter’.")

#text("d -Tamar Basar, Geert Jan Olsder, ‘Dynamic Noncooperative Game Theory’, chapter 8.")

#text("e – A possible link between continuous motion and the concept of continuous transformations of Sophus Lie.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-9626")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2007")])]

#text("Dear Doug,")

#text("The term “parabolic” when applied to PDEs has a rather technical meaning which is only indirectly connected to the parabola as a curve. Because the equations ")#mi("ax^2 + by^2 = c")#text(", ")#mi("a x + by^2 = c")#text(", and ")#mi("a x^2 - by^2 = c")#text(" describe an ellipse, parabola, and hyperbola respectively, the three PDE ")#mi("(a \\partial_x^2 + b \\partial_y^2) u = f")#text(", ")#mi("(a\\partial x + b \\partial_y^2) u = f")#text(", and ")#mi("(a \\partial x^2 - b \\partial_y^2) u = f")#text(" were labeled elliptic, parabolic, and hyperbolic PDE respectively. Later on, this classification of PDE was generalised to situations in which no ellipse, parabola, or hyperbola is visible at all.")

#text("Solutions to parabolic flows tend to become smoother and gradually flatter over time. For instance, the fundamental solution to the heat equation ")#mi("\\partial_t u = \\Delta_x u")#text(" on ")#mi("{\\Bbb R}^+ \\times {\\Bbb R}^n")#text(" – which is the most basic of all the parabolic equations – is given by ")#tao-math("u(t,x) = \\frac{1}{(4\\pi t)^{n/2}} e^{-\\left|x\\right|^2/4t}", block: false)#text(", thus at each time t, the solution is a Gaussian, whose amplitude decreases (and whose width increases) over time. There are some faint connections with parabolae (for instance, the level sets of the phase ")#tao-math("\\left|x\\right|^2/4t", block: false)#text(" are parabolae) but I would in general caution against reading too much into the term “parabolic”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-9935")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2007")])]

#text("Hi Terence,")

#text("I think that I understand your comment about the term parabola encompassing more than a single curve in the context of PDE.")

#text("It is somewhat similar to there being more than one catenary:")#linebreak()#text(" – parabolic catenary [usually referred to as simply catenary]")#linebreak()#text(" – elliptic catenary")#linebreak()#text(" – hyperbolic catenary")#linebreak()#text(" – and")#linebreak()#text(" – perhaps other as yet unclassified catenaries.")

#text("However, I think that Urs Wiedemann and the others listed above may not realize the possibly significant relation of catenary and helix [as a geodesic]:")#linebreak()#text(" 1 – on Earth, generally squirrels oppose gravity by climbing the cylindrical tree trunk in a helical manner – moving from one unfixed point to another.")#linebreak()#text(" 2 – planets appear to revolve around a moving sun in a helical trajectory about a virtual cylinder – moving from one unfixed point to another – although often the sun is visualized as stationary and the planetary orbits as ellipses.")#linebreak()#text(" 3 – bridges on earth tend to form a catenary between to two fixed points.")

#text("Thus there may be a gravity relation with both catenary and helix.")

#text("The ubiquity of the helix at so many different scales [gauges] seems to suggest the conveyance of information in many different forms.")

#text("Mathematical music example:")#linebreak()#text(" Pitch space of music [and probably radio waves and electromagnetic {EM}waves in general] have been described as both linear and helical.")#linebreak()#text(" “M.W. Drobisch (1855) was the first to suggest a helix (i.e. the spiral of fifths) to represent octave equivalence and reoccurrence (Lerdahl, 2001), and hence to give a model of pitch space.”")#linebreak()#text(" “… Euler (1739), Hermann von Helmholtz (1863/1885), Arthur von Oettingen (1866), Hugo Riemann (who should not be confused with the famous mathematician Bernhard Riemann), and Christopher Longuet-Higgins (1978) have modeled pitch relationships using two-dimensional (or higher-dimensional) lattices …”")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Pitch_space")[#text("http://en.wikipedia.org/wiki/Pitch_space")]

#text("I do recognize that I may be wrong [by over-generalizing], but the helix is also involved transmitting information in nucleic acids and proteins and in EM solenoids.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-11549")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2007")])]

#text("Hi Terence,")

#text("RE: Einstein … “the Einstein equations” and “general relativity”")

#text("This question is more about the special relativity E=mc^2.")

#text("Most of us have been taught that c is a constant.")

#text("What if c is a constant extrema [maximum]?")

#text("Is this subtle difference signifcant in both mathematics and physics?")

#text("Example: E=m*(MAX(a)), where MAX(a)=c^2")

#text("This would seem to imply that")#linebreak()#text(" E=(1/2)*m*(MAX(v))^2, where MAX(v)=c*2^(1/2)")

#text("I raise this question due to my interest in game theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Global regularity of wave maps III. Large energy from R^{1+2} to hyperbolic spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-30172")[#strong[#text("Global regularity of wave maps III. Large energy from R^{1+2} to hyperbolic spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("[…] the last nine years or so, I have been working on and off on the global regularity problem for wave maps . The wave map equation is a nonlinear generalisation of the wave equation in which the unknown […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Global regularity of wave maps IV. Absence of stationary or self-similar solutions in the energy class « What’s new")]], [#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/#comment-30658")[#strong[#text("Global regularity of wave maps IV. Absence of stationary or self-similar solutions in the energy class « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2008")])]

#text("[…] In the first installment of this project, I was able to establish the global existence of smooth wave maps from 2+1-dimensional spacetime to hyperbolic space from arbitrary smooth initial data, […]")
]
