// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/
// Converted to Typst by tao2typ: "2026-10-14T16:37:06.721011+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Bounding short exponential sums on smooth moduli via Weyl differencing", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Bounding short exponential sums on smooth moduli via Weyl differencing")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")[#text("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As in previous posts, we use the following asymptotic notation: ")#mi("{x}")#text(" is a parameter going off to infinity, and all quantities may depend on ")#mi("{x}")#text(" unless explicitly declared to be “fixed”. The asymptotic notation ")#mi("{O(), o(), \\ll}")#text(" is then defined relative to this parameter. A quantity ")#mi("{q}")#text(" is said to be ")#emph[#text("of polynomial size")]#text(" if one has ")#mi("{q = O(x^{O(1)})}")#text(", and said to be ")#emph[#text("bounded")]#text(" if ")#mi("{q=O(1)}")#text(". Another convenient notation: we write ")#mi("{X \\lessapprox Y}")#text(" for ")#mi("{X \\ll x^{o(1)} Y}")#text(". Thus for instance the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(" asserts that if ")#mi("{q}")#text(" has polynomial size, then the number of divisors of ")#mi("{q}")#text(" is ")#mi("{\\lessapprox 1}")#text(".")

#text("This post is intended to highlight a phenomenon unearthed in the ongoing ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("polymath8 project")]#text(" (and is in fact a key component of ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s proof")]#text(" that there are bounded gaps between primes infinitely often), namely that one can get quite good bounds on relatively short exponential sums when the modulus ")#mi("{q}")#text(" is smooth, through the basic technique of ")#emph[#text("Weyl differencing")]#text(" (ultimately based on the Cauchy-Schwarz inequality, and also related to the van der Corput lemma in equidistribution theory). Improvements in the case of smooth moduli have appeared before in the literature (e.g. in this ")#link("http://www.ams.org/mathscinet-getitem?mr=485727")[#text("paper of Heath-Brown")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1084186")[#text("paper of Graham and Ringrose")]#text(", this ")#link("http://www.ams.org/mathscinet-getitem?mr=2753656")[#text("later paper of Heath-Brown")]#text(", this ")#link("http://arxiv.org/abs/1201.0299")[#text("paper of Chang")]#text(", or this ")#link("http://www.ams.org/mathscinet-getitem?mr=2730358")[#text("paper of Goldmakher")]#text("); the arguments here are particularly close to that of the first paper of Heath-Brown. It now also appears that further optimisation of this Weyl differencing trick could lead to noticeable improvements in the numerology for the polymath8 project, so I am devoting this post to explaining this trick further.")

#text("To illustrate the method, let us begin with the classical problem in analytic number theory of estimating an ")#emph[#text("incomplete character sum")]

#align(center)[#tao-fit-display[#mitex("\\sum_{M+1 \\leq n \\leq M+N} \\chi(n)")]]

#text("where ")#mi("{\\chi}")#text(" is a primitive ")#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" of some conductor ")#mi("{q}")#text(", ")#mi("{M}")#text(" is an integer, and ")#mi("{N}")#text(" is some quantity between ")#mi("{1}")#text(" and ")#mi("{q}")#text(". Clearly we have the trivial bound ")#metadata(none) <tao-4beeb72de58b9de8213c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\sum_{M+1 \\leq n \\leq M+N} \\chi(n)\\right| \\leq N;", block: true)]]

#text("we also have the classical ")#link("http://en.wikipedia.org/wiki/Polya-Vinogradov_inequality")[#text("Pólya-Vinogradov inequality")]#text(" ")#metadata(none) <tao-666d83a02126d9259841>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\sum_{M+1 \\leq n \\leq M+N} \\chi(n)\\right| \\ll q^{1/2} \\log q.", block: true)]]

#text("This latter inequality gives improvements over the trivial bound when ")#mi("{N}")#text(" is much larger than ")#mi("{q^{1/2}}")#text(", but not for ")#mi("{N}")#text(" much smaller than ")#mi("{q^{1/2}}")#text(". The Pólya-Vinogradov inequality can be deduced via a little Fourier analysis from the completed exponential sum bound")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{n \\in {\\bf Z}/q{\\bf Z}} \\chi(n) e_q( an )\\right| \\ll q^{1/2}", block: true)]]

#text("for any ")#mi("{a \\in {\\bf Z}/q{\\bf Z}}")#text(", where ")#mi("{e_q(n) :=e^{2\\pi i n/q}}")#text(". (In fact, from the classical theory of ")#link("http://en.wikipedia.org/wiki/Gaussian_sum")[#text("Gauss sums")]#text(", this exponential sum is equal to ")#mi("{\\tau(\\chi) \\overline{\\chi(a)}}")#text(" for some complex number ")#mi("{\\tau(\\chi)}")#text(" of norm ")#mi("{\\sqrt{q}}")#text(".)")

#text("In the case when ")#mi("{q}")#text(" is a prime, improving upon the above two inequalities is an important but difficult problem, with only partially satisfactory results so far. To give just one indication of the difficulty, the seemingly modest improvement")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{M+1 \\leq n \\leq M+N} \\chi(n)\\right| \\ll p^{1/2} \\log \\log p", block: true)]]

#text("to the Pólya-Vinogradov inequality when ")#mi("{q=p}")#text(" was a prime required a ")#link("http://www.ams.org/mathscinet-getitem?mr=457371")[#text("14-page paper in Inventiones by Montgomery and Vaughan")]#text(" to prove, and even then it was only conditional on the generalised Riemann hypothesis! See also this more ")#link("http://www.ams.org/mathscinet-getitem?mr=2276774")[#text("recent paper of Granville and Soundararajan")]#text(" for an unconditional variant of this result in the case that ")#mi("{\\chi}")#text(" has odd order.")

#text("Another important improvement is the ")#link("http://www.ams.org/mathscinet-getitem?mr=148626")[#text("Burgess bound")]#text(", which in our notation asserts that ")#metadata(none) <tao-8f329750b4b75fc98c88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\sum_{M+1 \\leq n \\leq M+N} \\chi(n)\\right| \\lessapprox N^{1-1/r} q^{\\frac{r+1}{4r^2}}", block: true)]]

#text("for any fixed integer ")#mi("{r \\geq 2}")#text(", assuming that ")#mi("{q}")#text(" is square-free (for simplicity) and of polynomial size; see ")#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/")[#text("this previous post")]#text(" for a discussion of the Burgess argument. This is non-trivial for ")#mi("{N}")#text(" as small as ")#mi("{q^{1/4+o(1)}}")#text(".")

#text("In the case when ")#mi("{q}")#text(" is prime, there has been very little improvement to the Burgess bound (or its Fourier dual, which can give bounds for ")#mi("{N}")#text(" as large as ")#mi("{q^{3/4-o(1)}}")#text(") in the last fifty years; an improvement to the exponents in ")#link(<tao-8f329750b4b75fc98c88>)[#text("(3)")]#text(" in this case (particularly anything that gave a power saving for ")#mi("{N}")#text(" below ")#mi("{q^{1/4}}")#text(") would in fact be rather significant news in analytic number theory.")

#text("However, in the opposite case when ")#mi("{q}")#text(" is ")#emph[#text("smooth")]#text(" – that is to say, all of its factors are much smaller than ")#mi("{q}")#text(" – then one can do better than the Burgess bound in some regimes. This fact has been observed in several places in the literature (in particular, in the papers of ")#link("http://www.ams.org/mathscinet-getitem?mr=485727")[#text("Heath-Brown")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1084186")[#text("Graham-Ringrose")]#text(", ")#link("http://arxiv.org/abs/1201.0299")[#text("Chang")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=2730358")[#text("Goldmakher")]#text(" mentioned previously), but also turns out to (implicitly) be a key insight in Zhang’s paper on bounded prime gaps. In the case of character sums, one such improved estimate (closely related to Theorem 2 of the ")#link("http://www.ams.org/mathscinet-getitem?mr=485727")[#text("Heath-Brown paper")]#text(") is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" ")#metadata(none) <tao-2ab698dc4b2a66395886>#text(" Let ")#mi("{q}")#text(" be square-free with a factorisation ")#mi("{q = q_1 q_2}")#text(" and of polynomial size, and let ")#mi("{M,N}")#text(" be integers with ")#mi("{1 \\leq N \\leq q}")#text(". Then for any primitive character ")#mi("{\\chi}")#text(" with conductor ")#mi("{q}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{M+1 \\leq n \\leq M+N} \\chi(n) \\right| \\lessapprox N^{1/2} q_1^{1/2} + N^{1/2} q_2^{1/4}.", block: true)]]
]

#text("This proposition is particularly powerful when ")#mi("{q}")#text(" is smooth, as this gives many factorisations ")#mi("{q = q_1 q_2}")#text(" with the ability to specify ")#mi("{q_1,q_2}")#text(" with a fair amount of accuracy. For instance, if ")#mi("{q}")#text(" is ")#mi("{y}")#text("-smooth (i.e. all prime factors are at most ")#mi("{y}")#text("), then by the greedy algorithm one can find a divisor ")#mi("{q_1}")#text(" of ")#mi("{q}")#text(" with ")#mi("{y^{-2/3} q^{1/3} \\leq q_1 \\leq y^{1/3} q^{1/3}}")#text("; if we set ")#mi("{q_2 := q/q_1}")#text(", then ")#mi("{y^{-1/3} q^{2/3} \\leq q_2 \\leq y^{2/3} q^{2/3}}")#text(", and the above proposition then gives")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{M+1 \\leq n \\leq M+N} \\chi(n) \\right| \\lessapprox y^{1/6} N^{1/2} q^{1/6}", block: true)]]

#text("which can improve upon the Burgess bound when ")#mi("{y}")#text(" is small. For instance, if ")#mi("{N = q^{1/2}}")#text(", then this bound becomes ")#mi("{\\lessapprox y^{1/6} q^{5/12}}")#text("; in contrast the Burgess bound only gives ")#mi("{\\lessapprox q^{7/16}}")#text(" for this value of ")#mi("{N}")#text(" (using the optimal choice ")#mi("{r=2}")#text(" for ")#mi("{r}")#text("), which is inferior for ")#mi("{y < q^{1/8}}")#text(".")

#text("The hypothesis that ")#mi("{q}")#text(" be squarefree may be relaxed, but for applications to the Polymath8 project, it is only the squarefree moduli that are relevant.")

#emph[#text("Proof:")]#text(" If ")#mi("{N \\ll q_1}")#text(" then the claim follows from the trivial bound ")#link(<tao-4beeb72de58b9de8213c>)[#text("(1)")]#text(", while for ")#mi("{N \\gg q_2}")#text(" the claim follows from ")#link(<tao-666d83a02126d9259841>)[#text("(2)")]#text(". Hence we may assume that")

#align(center)[#tao-fit-display[#mitex("q_1 < N < q_2.")]]

#text("We use the method of Weyl differencing, the key point being to difference in multiples of ")#mi("{q_1}")#text(".")

#text("Let ")#mi("{K := \\lfloor N/q_1 \\rfloor}")#text(", thus ")#mi("{K \\geq 1}")#text(". For any ")#mi("{1 \\leq k \\leq K}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{M+1 \\leq n \\leq M+N} \\chi(n) = \\sum_n 1_{[M+1,M+N]}(n+kq_1) \\chi(n+kq_1)")]]

#text("and thus on averaging ")#metadata(none) <tao-46b1f9f988f2e0ace80a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{M+1 \\leq n \\leq M+N} \\chi(n) = \\frac{1}{K} \\sum_n \\sum_{k=1}^K 1_{[M+1,M+N]}(n+kq_1) \\chi(n+kq_1).")]]

#text("By the Chinese remainder theorem, we may factor")

#align(center)[#tao-fit-display[#mitex("\\chi(n) = \\chi_1(n) \\chi_2(n)")]]

#text("where ")#mi("{\\chi_1,\\chi_2}")#text(" are primitive characters of conductor ")#mi("{q_1,q_2}")#text(" respectively. As ")#mi("{\\chi_1}")#text(" is periodic of period ")#mi("{q_1}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\chi(n+kq_1) = \\chi_1(n) \\chi_2(n+kq_2)")]]

#text("and so we can take ")#mi("{\\chi_1}")#text(" out of the inner summation of the right-hand side of ")#link(<tao-46b1f9f988f2e0ace80a>)[#text("(4)")]#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\sum_{M+1 \\leq n \\leq M+N} \\chi(n) = \\frac{1}{K} \\sum_n \\chi_1(n) \\sum_{k=1}^K 1_{[M+1,M+N]}(n+kq_1) \\chi_2(n+kq_1)")]]

#text("and hence by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{M+1 \\leq n \\leq M+N} \\chi(n)\\right| \\leq \\frac{1}{K} \\sum_n |\\sum_{k=1}^K 1_{[M+1,M+N]}(n+kq_1) \\chi_2(n+kq_1)|.", block: true)]]

#text("Note how the characters on the right-hand side only have period ")#mi("{q_2}")#text(" rather than ")#mi("{q=q_1 q_2}")#text(". This reduction in the period is ultimately the source of the saving over the Pólya-Vinogradov inequality.")

#text("Note that the inner sum vanishes unless ")#mi("{n \\in [M+1-Kq_1,M+N]}")#text(", which is an interval of length ")#mi("{O(N)}")#text(" by choice of ")#mi("{K}")#text(". Thus by Cauchy-Schwarz one has")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{M+1 \\leq n \\leq M+N} \\chi(n) \\right| \\ll", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\frac{N^{1/2}}{K} (\\sum_n \\left|\\sum_{k=1}^K 1_{[M+1,M+N]}(n+kq_1) \\chi_2(n+kq_1)\\right|^2)^{1/2}.", block: true)]]

#text("We expand the right-hand side as")

#align(center)[#tao-fit-display[#mitex("\\frac{N^{1/2}}{K} |\\sum_{1 \\leq k,k^{\\prime} \\leq K} \\sum_n")]]

#align(center)[#tao-fit-display[#mitex("1_{[M+1,M+N]}(n+kq_1) 1_{[M+1,M+N]}(n+k^{\\prime}q_1) \\chi_2(n+kq_1) \\overline{\\chi_2(n+k^{\\prime}q_1)}|^{1/2}.")]]

#text("We first consider the diagonal contribution ")#mi("{k=k^{\\prime}}")#text(". In this case we use the trivial bound ")#mi("{O(N)}")#text(" for the inner summation, and we soon see that the total contribution here is ")#mi("{O( K^{-1/2} N ) = O( N^{1/2}q_1^{1/2} )}")#text(".")

#text("Now we consider the off-diagonal case; by symmetry we can take ")#mi("{k < k^{\\prime}}")#text(". Then the indicator functions ")#mi("{1_{[M+1,M+N]}(n+kq_1) 1_{[M+1,M+N]}(n+k^{\\prime}q_1)}")#text(" restrict ")#mi("{n}")#text(" to the interval ")#mi("{[M+1-kq_1, M+N-k^{\\prime}q_1]}")#text(". On the other hand, as a consequence of the ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text(" for curves one can show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/q_2{\\bf Z}} \\chi_2(n+kq_1) \\overline{\\chi_2(n+k^{\\prime}q_1)} e_{q_2}(an)\\right| \\lessapprox q_2^{1/2} (k-k^{\\prime},q_2)^{1/2}", block: true)]]

#text("for any ")#mi("{a \\in {\\bf Z}/q_2{\\bf Z}}")#text("; indeed one can use the Chinese remainder theorem and the square-free nature of ")#mi("{q_2}")#text(" to reduce to the case when ")#mi("{q_2}")#text(" is prime, in which case one can apply (for instance) the ")#link("http://www.ams.org/mathscinet-getitem?mr=27006")[#text("original paper of Weil")]#text(" to establish this bound, noting also that ")#mi("{q_1}")#text(" and ")#mi("{q_2}")#text(" are coprime since ")#mi("{q}")#text(" is squarefree. Applying the method of completion of sums (or the Parseval formula), this shows that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n 1_{[M+1,M+N]}(n+kq_1) 1_{[M+1,M+N]}(n+k^{\\prime}q_1) \\chi_2(n+kq_1) \\overline{\\chi_2(n+k^{\\prime}q_1)}\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox q_2^{1/2} (k-k^{\\prime},q_2)^{1/2}.")]]

#text("Summing in ")#mi("{k,k^{\\prime}}")#text(" (using Lemma 5 from ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(") we see that the total contribution to the off-diagonal case is")

#align(center)[#tao-fit-display[#mitex("\\lessapprox \\frac{N^{1/2}}{K} ( K^2 q_2^{1/2} )^{1/2}")]]

#text("which simplifies to ")#mi("{\\lessapprox N^{1/2} q_2^{1/4}}")#text(". The claim follows. ")#mi("\\Box")

#text("A modification of the above argument (using more complicated versions of the Weil conjectures) allows one to replace the summand ")#mi("{\\chi(n)}")#text(" by more complicated summands such as ")#mi("{\\chi(f(n)) e_q(g(n))}")#text(" for some polynomials or rational functions ")#mi("{f,g}")#text(" of bounded degree and obeying a suitable non-degeneracy condition (after restricting of course to those ")#mi("{n}")#text(" for which the arguments ")#mi("{f(n),g(n)}")#text(" are well-defined). We will not detail this here, but instead turn to the question of estimating slightly longer exponential sums, such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq n \\leq N} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} )")]]

#text("where ")#mi("{N}")#text(" should be thought of as a little bit larger than ")#mi("{(d_1d_2)^{1/2}}")#text(".")

#metadata(none) <tao-fd8be8a5ff98e024c7f7>

#text("It will be convenient to introduce a little bit of formal algebraic notation. For the narrow task of establishing a new estimate on an incomplete Kloosterman-type sum of the type used in Zhang’s paper, one does not really need all this formalism, but it may be useful to have this formalism around for future generalisations and strengthenings of this estimate (e.g. when trying to set up a Burgess-style argument).")

#text("Define an ")#emph[#text("integral rational function")]#text(" to be a formal rational function ")#mi("{f(t) = \\frac{P(t)}{Q(t)}}")#text(" in a formal indeterminate ")#mi("{t}")#text(" where ")#mi("{P,Q \\in {\\bf Z}[t]}")#text(" are polynomials with integer coefficients, and ")#mi("{Q}")#text(" is monic; in particular any polynomial ")#mi("{P(t) \\in {\\bf Z}[t]}")#text(" can be identified with the integral rational function ")#mi("{P(t) \\equiv \\frac{P(t)}{1}}")#text(". For minor technical reasons we do ")#emph[#text("not")]#text(" equate integral rational functions under cancelling, thus for instance we consider ")#mi("{\\frac{P(t)R(t)}{Q(t)R(t)}}")#text(" to be distinct from ")#mi("{\\frac{P(t)}{Q(t)}}")#text("; we need to do this because the domain of definition of these two functions is a little different (the former is not defined when ")#mi("{R(t)=0}")#text(", but the latter can still be defined here). Because we refuse to cancel, we have to be a little careful how we define algebraic operations: specifically, we define")

#tao-aligned(keep: true)[


#tao-math("\\frac{P_1(t)}{Q_1(t)} + \\frac{P_2(t)}{Q_2(t)}  & := \\frac{P_1(t) Q_2(t) + P_2(t) Q_1(t)}{Q_1(t) Q_2(t)}", block: true)



#tao-math("\\frac{P_1(t)}{Q_1(t)} - \\frac{P_2(t)}{Q_2(t)}  & := \\frac{P_1(t) Q_2(t) - P_2(t) Q_1(t)}{Q_1(t) Q_2(t)}", block: true)



#tao-math("\\frac{P_1(t)}{Q_1(t)} \\cdot \\frac{P_2(t)}{Q_2(t)}  & := \\frac{P_1(t) P_2(t)}{Q_1(t) Q_2(t)}", block: true)



#tao-math("(\\frac{P(t)}{Q(t)})^{\\prime}  & := \\frac{P^{\\prime}(t) Q(t) - P(t) Q^{\\prime}(t)}{Q(t)^2}.", block: true)
]

#text("Note that the denominator always remains monic with respect to these operations. This is not quite a ring with a derivation (the subtraction operation does not quite cancel the addition operation due to the inability to cancel) but this will not bother us in practice. (On the other hand, addition and multiplication remain associative, and the latter continues to distribute over the former, and differentiation obeys the usual sum and product rules.)")

#text("In applications to bounded gaps between primes, we will deal with integral rational functions of the explicit form")

#align(center)[#tao-fit-display[#mitex("f(t) := \\frac{a}{t} + \\frac{b}{t+l} + ct")]]

#text("for various integers ")#mi("{a,b,c,l}")#text(", but much of the theory below extends without much difficulty to more general integral rational functions, so we shall state it in that level of generality.")

#text("Note that if ")#mi("{f(t) = \\frac{P(t)}{Q(t)}}")#text(" is an integral rational function, we can localise it modulo ")#mi("{q}")#text(" for any modulus ")#mi("{q}")#text(" to obtain a rational function ")#mi("{f(t)\\ (q) := \\frac{P(t)\\ (q)}{Q(t)\\ (q)}}")#text(" that is the ratio of two polynomials ")#mi("{P\\ (q), Q\\ (q)}")#text(" in ")#mi("{({\\bf Z}/q{\\bf Z})[t]}")#text(", with the denominator monic and hence non-vanishing. We can define the algebraic operations of addition, subtraction, multiplication, and differentiation on integral rational functions modulo ")#mi("{q}")#text(" by the same formulae as above, and we observe that these operations are completely compatible with their counterparts over ")#mi("{{\\bf Z}}")#text(" (even without the ability to cancel), thus for instance ")#mi("{(f+g)\\ (q) = (f\\ (q)) + (g\\ (q))}")#text(". We say that ")#mi("{f}")#text(" is ")#emph[#text("divisible")]#text(" by ")#mi("{q}")#text(", and write ")#mi("{q|f}")#text(", if the numerator ")#mi("{P(t)}")#text(" of ")#mi("{f(t)}")#text(" has all coefficients divisible by ")#mi("{q}")#text(".")

#text("If ")#mi("{f}")#text(" is an integral rational function and ")#mi("{n \\in {\\bf Z}/q{\\bf Z}}")#text(", then ")#mi("{f(n)}")#text(" is well defined as an element of ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" except when ")#mi("{Q(n)}")#text(" is a zero divisor in ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(". We adopt the convention that ")#mi("{e_q(f(n)) = 0}")#text(" when ")#mi("{Q(n)}")#text(" is a zero divisor in ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(", thus ")#mi("{e_q(f(n))}")#text(" is really shorthand for ")#mi("{1_{(Q(n),q)=1} e_q(f(n))}")#text("; by abuse of notation we view ")#mi("{n \\mapsto e_q(f(n))}")#text(" both as a function on ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" and as a ")#mi("{q}")#text("-periodic function on ")#mi("{{\\bf Z}}")#text(". Thus for instance")

#align(center)[#tao-fit-display[#mitex("e_q( \\frac{0}{n} ) = 1_{(n,q)=1}.")]]

#text("Note that if ")#mi("{q|f}")#text(", then ")#mi("{f(n)=0\\ (q)}")#text(" for all ")#mi("{n \\in {\\bf Z}/q{\\bf Z}}")#text(" for which ")#mi("{f(n)}")#text(" is well defined. We define ")#mi("{(f,q)}")#text(" to be the largest factor ")#mi("{q^{\\prime}}")#text(" of ")#mi("{q}")#text(" for which ")#mi("{q^{\\prime}|f}")#text("; in particular, if ")#mi("{q}")#text(" is square-free, we have")

#align(center)[#tao-fit-display[#mitex("(f,q) = \\prod_{p|q: p|f} p.")]]

#text("We recall the following Chinese remainder theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Chinese remainder theorem)")]#text(" ")#metadata(none) <tao-793ff64f83b41b5d467a>#text(" Let ")#mi("{q = q_1 q_2}")#text(" with ")#mi("{q_1,q_2}")#text(" coprime positive integers. If ")#mi("{f}")#text(" is a rational function, then")

#align(center)[#tao-fit-display[#mitex("e_q( f(n) ) = e_{q_1}( \\bar{q_2} f(n) ) e_{q_2} ( \\bar{q_1} f(n) )")]]

#text("for all integers ")#mi("{n}")#text(", where ")#mi("{\\bar{q_2}}")#text(" is the inverse of ")#mi("{q_2}")#text(" in ")#mi("{{\\bf Z}/q_1{\\bf Z}}")#text(" and similarly for ")#mi("{\\bar{q_1}}")#text(".")
]

#text("When there is no chance of confusion we will write ")#mi("{e_{q_1} ( \\frac{1}{q_2} f(n) )}")#text(" for ")#mi("{e_{q_1}( \\bar{q_2} f(n) )}")#text(" (though note that ")#mi("{\\frac{1}{q_2}}")#text(" does not qualify as an integral rational function since the constant ")#mi("{q_2}")#text(" is not monic).")

#emph[#text("Proof:")]#text(" See Lemma 7 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(". ")#mi("\\Box")

#text("We need the following algebraic version of the fundamental theorem of calculus:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Fundamental theorem of calculus)")]#text(" ")#metadata(none) <tao-639f78fb7729d09dc606>#text(" Let ")#mi("{f(t) = \\frac{P(t)}{Q(t)}}")#text(" be a rational function, and let ")#mi("{q}")#text(" be a positive integer. If ")#mi("{q|f^{\\prime}}")#text(" and all prime factors of ")#mi("{q}")#text(" are sufficiently large depending on the degrees of ")#mi("{P,Q}")#text(", then there exists ")#mi("{c \\in {\\bf Z}/q{\\bf Z}}")#text(" such that ")#mi("{q|f-c}")#text(".")
]

#emph[#text("Proof:")]#text(" By definition, the constraint ")#mi("{q|f^{\\prime}}")#text(" may be rewritten as")

#align(center)[#tao-fit-display[#mitex("P^{\\prime}(t) Q(t) - P(t) Q^{\\prime}(t) = 0\\ (q).")]]

#text("By abuse of notation, we view ")#mi("{P,Q}")#text(" as polynomials over ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" (i.e. all occurrences of ")#mi("{P,Q}")#text(" in what follows should actually be ")#mi("{P\\ (q), Q\\ (q)}")#text(" if we did not abuse notation). If ")#mi("{P}")#text(" has degree larger than ")#mi("{Q}")#text(", then by inspecting the ")#mi("{t^{\\text{deg}(P)+\\text{deg}(Q)-1}}")#text(" coefficient of this equation we obtain a contradiction if all prime factors of ")#mi("{q}")#text(" are large enough. Thus we may assume that ")#mi("{\\text{deg}(P) \\leq \\text{deg}(Q)}")#text("; since ")#mi("{Q}")#text(" is monic, this implies that ")#mi("{P = cQ + R}")#text(" for some ")#mi("{R \\in {\\bf Z}/q{\\bf Z}[t]}")#text(" with ")#mi("{\\text{deg}(R) < \\text{deg}(Q)}")#text(". We can then rewrite the previous constraint as")

#align(center)[#tao-fit-display[#mitex("R^{\\prime}(t) Q(t) - R(t) Q^{\\prime}(t) = 0\\ (q).")]]

#text("If ")#mi("{R}")#text(" is non-zero, then inspecting the ")#mi("{t^{\\text{deg}(R)+\\text{deg}(Q)-1}}")#text(" coefficient of this equation leads to a contradiction if all prime factors of ")#mi("{q}")#text(" are large enough. Thus ")#mi("{R}")#text(" is zero, and so ")#mi("{q|f-c}")#text(" as required. ")#mi("\\Box")

#text("Now we give an estimate for complete exponential sums, which combines both Ramanujan sum bounds with Weil conjecture bounds.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Ramanujan-Weil bounds)")]#text(" ")#metadata(none) <tao-740fc4991133b1523bc4>#text(" Let ")#mi("{q}")#text(" be a positive square-free integer of polynomial size, and let ")#mi("{f(t) = \\frac{P(t)}{Q(t)}}")#text(" be an integral rational function with ")#mi("{P,Q}")#text(" of bounded degree. Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q( f(n) )\\right| \\lessapprox q^{1/2} \\frac{(f^{\\prime},q)}{(f^{\\prime\\prime},q)^{1/2}}.", block: true)]]
]

#text("For instance, if we set ")#mi("{f(t) := \\frac{0}{t} + bt}")#text(" for some integer ")#mi("{b}")#text(", we obtain the familiar Ramanujan sum bound ")#metadata(none) <tao-4d5725dcb64a0c04fb04>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q( b n) 1_{(n,q)=1}\\right| \\lessapprox (b,q).", block: true)]]

#text("More generally, if we set ")#mi("{f(t) := \\frac{a}{t} + bt}")#text(" for some integers ")#mi("{a,b}")#text(", we obtain Weil’s Kloosterman sum bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q( \\frac{a}{n} + bn ) 1_{(n,q)=1}\\right| \\lessapprox q^{1/2} \\frac{(a,b,q)}{(a,q)^{1/2}},", block: true)]]

#text("and so forth.")

#text("The bound in Proposition ")#link(<tao-740fc4991133b1523bc4>)[#text("4")]#text(" is quite sharp, with one exception of relevance to the polymath8 project, namely the estimation of the degenerate Kloosterman-type sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q( \\frac{a}{n+l} )")]]

#text("with ")#mi("{a, l}")#text(" integers. Proposition ")#link(<tao-740fc4991133b1523bc4>)[#text("4")]#text(" gives a bound of ")#mi("{\\ll q^{1/2} (a,q)^{1/2}}")#text(" in this case, but one can do better by performing the change of variables ")#mi("{m = \\frac{1}{n+l}}")#text(" that transforms this sum into a Ramanujan sum, yielding the superior bound ")#metadata(none) <tao-65ec920cb42d205741f8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q( \\frac{a}{n+l} )\\right| \\ll (a,q).", block: true)]]

#text("One could try to modify the argument below to incorporate this improvement, but it leads to a significantly more complicated right-hand side for the estimate, so we will not do so here.")

#emph[#text("Proof:")]#text(" By the Chinese remainder theorem and the divisor bound, it suffices to verify this when ")#mi("{q=p}")#text(" is a single prime and with ")#mi("{\\lessapprox}")#text(" replaced by ")#mi("{\\ll}")#text(", thus we wish to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/p{\\bf Z}} e_p(f(n))\\right| \\ll p", block: true)]]

#text("when ")#mi("{p|f^{\\prime}}")#text(" (which implies ")#mi("{p|f^{\\prime\\prime}}")#text("), ")#metadata(none) <tao-a631f4488a457da27b4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\sum_{n \\in {\\bf Z}/p{\\bf Z}} e_p(f(n))\\right| \\ll 1", block: true)]]

#text("when ")#mi("{p|f^{\\prime\\prime}}")#text(" but ")#mi("{p \\not | f^{\\prime}}")#text(", and ")#metadata(none) <tao-79bdb0739da467a5782f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left|\\sum_{n \\in {\\bf Z}/p{\\bf Z}} e_p(f(n))\\right| \\ll \\sqrt{p}", block: true)]]

#text("otherwise. We may assume that ")#mi("{p}")#text(" is sufficiently large depending on the degrees of ")#mi("{P,Q}")#text(" as the claim is trivial otherwise.")

#text("The first bound trivially follows from the triangle inequality, so we turn to the second bound. Since ")#mi("{p|f^{\\prime\\prime}}")#text(", we conclude from Lemma ")#link(<tao-639f78fb7729d09dc606>)[#text("3")]#text(" that there is ")#mi("{c \\in {\\bf Z}/p{\\bf Z}}")#text(" such that ")#mi("{p|f^{\\prime}-c}")#text("; since ")#mi("{p \\not | f^{\\prime}}")#text(", ")#mi("{c}")#text(" must be non-zero. Since ")#mi("{f^{\\prime}-c = (f-ct)^{\\prime}}")#text(", another application of Lemma ")#link(<tao-639f78fb7729d09dc606>)[#text("3")]#text(" shows that there is ")#mi("{d \\in {\\bf Z}/p{\\bf Z}}")#text(" such that ")#mi("{p|f-ct-d}")#text(". Thus ")#mi("{f(n) = cn+d\\ (p)}")#text(" whenever ")#mi("{f(n)}")#text(" is well-defined. Since the denominator ")#mi("{Q(n)}")#text(" of ")#mi("{f(n)}")#text(" has only bounded number of zeroes, we conclude that ")#mi("{e_p(f(n)) = e_p(cn+d)}")#text(" for all but a bounded number of ")#mi("{n \\in {\\bf Z}/p{\\bf Z}}")#text(". The claim then follows ")#link(<tao-a631f4488a457da27b4a>)[#text("(7)")]#text(" from the Fourier identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in{\\bf Z}/p{\\bf Z}} e_p( cn+d) = 0.")]]

#text("Now we prove ")#link(<tao-79bdb0739da467a5782f>)[#text("(8)")]#text(". By abuse of notation, we view ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" as polynomials over the field ")#mi("{{\\bf F}_p[t]}")#text(" rather than over the integers. Let ")#mi("{R := (P,Q)}")#text(" be the (monic) greatest common divisor, thus ")#mi("{P = R \\tilde P}")#text(" and ")#mi("{Q = R \\tilde Q}")#text(" with ")#mi("{\\tilde P, \\tilde Q \\in {\\bf F}_p[t]}")#text(" coprime and of bounded degree with ")#mi("{\\tilde Q}")#text(" monic. As in the previous paragraph, we have ")#mi("{e_p(f(n)) = e_p( \\frac{\\tilde P(n)}{\\tilde Q(n)} )}")#text(" for all but a bounded number of ")#mi("{n}")#text(". So it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/p{\\bf Z}} 1_{\\tilde Q(n) \\neq 0} e_p(\\frac{\\tilde P(n)}{\\tilde Q(n)})\\right| \\ll \\sqrt{p}.", block: true)]]

#text("We now use the Weil bound for exponentials of rational functions over a field of prime order, as stated for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=241424")[#text("this paper of Perelmuter")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=2195926")[#text("this paper of Cochrane and Pinner")]#text(" (in the case when ")#mi("{f}")#text(" is polynomial, one can also use the ")#link("http://www.ams.org/mathscinet-getitem?mr=27006")[#text("original paper of Weil")]#text(", who also treats the important case of Kloosterman sums when ")#mi("{f}")#text(" is a fractional linear transformation). We remark that the Cochrane-Pinner paper uses Stepanov’s method and is thus essentially elementary in nature, whereas the other papers use more sophisticated tools from arithmetic geometry (such as ")#mi("{\\ell}")#text("-adic cohomology). In any event, the results in these papers give the required bound except when the rational function ")#mi("{\\tilde P / \\tilde Q}")#text(" has the form ")#metadata(none) <tao-f738b25f945986f56647>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{\\tilde P}{\\tilde Q} = g^p - g + c")]]

#text("in the field ")#mi("{{\\bf F}_p(t)}")#text(" of rational functions over ")#mi("{{\\bf F}_p}")#text(" for some ")#mi("{g \\in {\\bf F}_p(t)}")#text(" and ")#mi("{c \\in {\\bf F}_p}")#text(". (The presence of the ")#mi("{g^p-g}")#text(" factor arises because of elements of ")#mi("{{\\bf F}_p}")#text(" are all roots of ")#mi("{x^p-x}")#text(".)")

#text("Suppose that ")#link(<tao-f738b25f945986f56647>)[#text("(9)")]#text(" holds. Writing ")#mi("{g = R/S}")#text(" for some coprime polynomials ")#mi("{R,S \\in {\\bf F}_p[t]}")#text(" with ")#mi("{S}")#text(" monic, we conclude on multiplying everything out that")

#align(center)[#tao-fit-display[#mitex("\\tilde P S^p = \\tilde Q R^p - \\tilde Q R S^{p-1} + c \\tilde Q S^p")]]

#text("in the polynomial ring ")#mi("{{\\bf F}_p[t]}")#text(". By unique factorisation, this forces ")#mi("{S^{p-1}}")#text(" to divide ")#mi("{\\tilde Q}")#text(", which for ")#mi("{p}")#text(" large enough forces ")#mi("{S}")#text(" to have degree zero, thus ")#mi("{S=1}")#text(" as ")#mi("{S}")#text(" is monic. We thus have")

#align(center)[#tao-fit-display[#mitex("\\tilde P = \\tilde Q R^p - \\tilde Q R + c \\tilde Q.")]]

#text("Inspecting the ")#mi("{\\text{deg}(\\tilde Q) + p \\text{deg}(R)}")#text(" coefficient of this equation, we obtain (for ")#mi("{p}")#text(" large enough) a contradiction unless ")#mi("{R}")#text(" has degree zero, thus ")#mi("{R}")#text(" is constant. In particular ")#mi("{R^p - R = 0}")#text(" and so ")#mi("{\\tilde P}")#text(" is a scalar multiple of ")#mi("{\\tilde Q}")#text(", hence ")#mi("{P}")#text(" is a scalar multiple of ")#mi("{Q}")#text(" and so ")#mi("{p | f^{\\prime}}")#text(", contradicting the hypothesis. This covers all cases and we are done. ")#mi("\\Box")

#text("Now we obtain a bound for incomplete exponential sums to smooth moduli. We will focus attention here on the specific sum we need to bound for the Polymath8 project, namely a sum of the form")

#align(center)[#tao-fit-display[#mitex("S := \\sum_n \\psi_N(n) e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} )")]]

#text("where ")#mi("{d_1,d_2}")#text(" are square-free numbers (not necessarily coprime), ")#mi("{c_1,c_2,l}")#text(" are integers, ")#mi("{N \\gg 1}")#text(", and ")#mi("{\\psi_N: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a function supported on an interval ")#mi("{I}")#text(" of length ")#mi("{O(N)}")#text(" that obeys the smoothness bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\psi^{(j)}_N(t)\\right| \\lessapprox N^{-j}", block: true)]]

#text("for any fixed ")#mi("{j \\geq 0}")#text(". The arguments below also apply to more general exponential sums as these, but the specific sum ")#mi("{S}")#text(" benefits from the additional cancellation ")#link(<tao-65ec920cb42d205741f8>)[#text("(6)")]#text(" that is not available for more general sums.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" Let ")#mi("{S}")#text(" be as above. Write ")#mi("{d^{\\prime}_1 := d_1/(d_1,d_2)}")#text(" and ")#mi("{d^{\\prime}_2 := d_2/(d_1,d_2)}")#text(".")

#list(
[#text("(i) (Trivial bound) We have")

#metadata(none) <tao-6d4c9cf5e022a07ea801>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|S\\right| \\lessapprox N.", block: true)]]],
[#text("(ii) (Standard bound) We have")

#metadata(none) <tao-15f3b852d2465ae56ff5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|S\\right| \\lessapprox [d_1,d_2]^{1/2} + \\frac{N}{d_1 d_2} (d_1,d_2)^2 (c_1,d^{\\prime}_1) (c_2,d^{\\prime}_2).", block: true)]]],
[#text("(iii) (Improved bound) We have")

#metadata(none) <tao-eeea394806ada3056899>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left|S\\right| \\lessapprox N^{1/2} (d^{\\prime}_1)^{1/4} + N^{1/2} d_2^{1/2} + \\frac{(c_1,d^{\\prime}_1)^{1/4}}{(d^{\\prime}_1)^{1/4}} N.", block: true)]]]
)
]

#text("The estimate (ii) is a slightly improved version of Lemma 11 of ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s paper")]#text(" (which is a key estimate to treat the Type I/II sums); one can also write the second term ")#mi("{\\frac{N}{d_1 d_2} (d_1,d_2)^2 (c_1,d^{\\prime}_1) (c_2,d^{\\prime}_2)}")#text(" on the right-hand side more suggestively as ")#mi("{\\frac{(c_1,d^{\\prime}_1)}{d^{\\prime}_1} \\frac{(c_2,d^{\\prime}_2)}{d^{\\prime}_2} N}")#text(". But it is the estimate (iii) which is a more substantial improvement, as for the medium-sized values of ")#mi("{N}")#text(" that come up in Zhang’s argument, the first two terms ")#mi("{N^{1/2} (d^{\\prime}_1)^{1/4}, N^{1/2} d_2^{1/2}}")#text(" that appear in ")#link(<tao-eeea394806ada3056899>)[#text("(12)")]#text(" are superior to the main term ")#mi("{[d_1,d_2]^{1/2}}")#text(" in ")#link(<tao-15f3b852d2465ae56ff5>)[#text("(11)")]#text(". (Admittedly, the final term in ")#link(<tao-eeea394806ada3056899>)[#text("(12)")]#text(" is worse than the final term in ")#link(<tao-15f3b852d2465ae56ff5>)[#text("(11)")]#text(", but in practice these terms are not dominant.) The improved bound ")#link(<tao-eeea394806ada3056899>)[#text("(12)")]#text(" leads to significantly better values of ")#mi("{\\varpi}")#text(" and ")#mi("{\\delta}")#text(" for the assertion ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" that we need for bounded gaps between primes; this is sketched in this previous comment and will be detailed in a subsequent post.")

#emph[#text("Proof:")]#text(" The trivial bound ")#link(<tao-6d4c9cf5e022a07ea801>)[#text("(10)")]#text(" is immediate from the triangle inequality and the bounds and support of ")#mi("{\\psi_N}")#text(", so we turn now to the standard bound ")#link(<tao-15f3b852d2465ae56ff5>)[#text("(11)")]#text(". We can write")

#align(center)[#tao-fit-display[#mitex("e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} ) = e_q( f(n) )")]]

#text("where ")#mi("{q := [d_1,d_2] = d_1 d^{\\prime}_2 = d^{\\prime}_1 d_2}")#text(" and ")#mi("{f}")#text(" is the integral rational function ")#metadata(none) <tao-b1c4d1f75430b6a185ee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("f(t) := \\frac{c_1 d^{\\prime}_2}{t} + \\frac{c_2 d^{\\prime}_1}{t+l}.")]]

#text("By Fourier inversion and the ")#mi("{q}")#text("-periodicity of ")#mi("{e_q(f)}")#text(", one can rewrite ")#mi("{S}")#text(" as ")#metadata(none) <tao-dfbfcd6f5474f6d4ab08>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("S = \\frac{1}{q} \\sum_{h \\in {\\bf Z}/q{\\bf Z}} \\hat \\psi_N(\\frac{h}{q}) \\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n) + hn)")]]

#text("where ")#mi("{\\hat \\psi_N: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("\\hat \\psi_N(\\theta) := \\sum_{n \\in {\\bf Z}} \\psi_N(n) e^{-2\\pi i n \\theta}.")]]

#text("From the Poisson summation formula and integration by parts, we have the standard bounds ")#metadata(none) <tao-04c56ad9992309bfa39f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\hat \\psi_N(\\theta)\\right| \\lessapprox N (N \\left|\\theta\\right|)^{-j}", block: true)]]

#text("for all ")#mi("{\\theta \\in [-1/2,1/2)}")#text(" (which, by abuse of notation, we identify with ")#mi("{{\\bf R}/{\\bf Z}}")#text(") and any fixed ")#mi("{j \\geq 0}")#text(".")

#text("Consider first the ")#mi("{h=0}")#text(" term in ")#link(<tao-dfbfcd6f5474f6d4ab08>)[#text("(14)")]#text(". By the Chinese remainder theorem, we may factor ")#mi("{\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n))}")#text(" as")

#align(center)[#tao-fit-display[#mitex("(\\sum_{n \\in {\\bf Z}/d^{\\prime}_1 {\\bf Z}} e_{d^{\\prime}_1}( \\frac{c_1}{n (d_1,d_2)} )) (\\sum_{n \\in {\\bf Z}/d^{\\prime}_2 {\\bf Z}} e_{d^{\\prime}_2}( \\frac{c_2}{n (d_1,d_2)} ))")]]

#align(center)[#tao-fit-display[#mitex("(\\sum_{n \\in {\\bf Z}/(d_1,d_2){\\bf Z}} e_{(d_1,d_2)}( \\frac{c_1}{nd^{\\prime}_1} + \\frac{c_2}{(n+l)d^{\\prime}_2} )).")]]

#text("Applying ")#link(<tao-65ec920cb42d205741f8>)[#text("(6)")]#text(" to the first two factors and the trivial bound of ")#mi("{(d_1,d_2)}")#text(" to the second factor, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n))\\right| \\lessapprox (c_1,d^{\\prime}_1) (c_2,d^{\\prime}_2) (d_1,d_2)", block: true)]]

#text("and so the contribution of the ")#mi("{h=0}")#text(" term is acceptable. It remains to establish that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{q}\\sum_{h \\in {\\bf Z}/q{\\bf Z} \\backslash \\{0\\}} \\left|\\hat \\psi_N(\\frac{h}{q})\\right| \\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n) + hn)\\right| \\lessapprox q^{1/2}.", block: true)]]

#text("Let ")#mi("{\\epsilon > 0}")#text(" be fixed. For ")#tao-math("{\\left|h\\right| \\geq x^\\epsilon q / N}", block: false)#text(" the bound is trivial from ")#link(<tao-04c56ad9992309bfa39f>)[#text("(15)")]#text(" (for ")#mi("{j}")#text(" large enough), so by overspill it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{q} \\sum_{1 \\leq \\left|h\\right| \\leq x^\\epsilon q/N} \\left|\\hat \\psi_N(\\frac{h}{q})\\right| \\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n) + hn)\\right| \\lessapprox x^{\\epsilon} q^{1/2}.", block: true)]]

#text("By Proposition ")#link(<tao-740fc4991133b1523bc4>)[#text("4")]#text(" and ")#link(<tao-04c56ad9992309bfa39f>)[#text("(15)")]#text(", the left-hand side is")

#align(center)[#tao-fit-display[#tao-math("\\lessapprox \\frac{1}{q} \\sum_{1 \\leq \\left|h\\right| \\leq x^\\epsilon q/N} N q^{1/2} \\frac{(f^{\\prime}+h,q)}{(f^{\\prime\\prime},q)^{1/2}}.", block: true)]]

#text("Writing ")#mi("{(f^{\\prime}+h,q) \\leq \\sum_{d|q} d 1_{d|f^{\\prime}+h}}")#text(", we may bound the previous expression by")

#align(center)[#tao-fit-display[#tao-math("\\lessapprox \\frac{N}{q^{1/2} (f^{\\prime\\prime},q)^{1/2}} \\sum_{d|q} d \\sum_{1 \\leq \\left|h\\right| \\leq x^\\epsilon q/N: d|f^{\\prime}+h} 1.", block: true)]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(t) = - \\frac{c_1 d^{\\prime}_2}{t^2} - \\frac{c_2 d^{\\prime}_1}{(t+l)^2}")]]

#text("vanishes at infinity, we see that ")#mi("{d|f^{\\prime}+h}")#text(" implies ")#mi("{d|h}")#text(". Thus")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq \\left|h\\right| \\leq x^\\epsilon q/N: d|f^{\\prime}+h} 1 \\ll \\frac{x^\\epsilon q/N}{d}", block: true)]]

#text("and hence by the divisor bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d|q} d \\sum_{1 \\leq \\left|h\\right| \\leq x^\\epsilon q/N: d|f^{\\prime}+h} 1 \\lessapprox x^\\epsilon q/N", block: true)]]

#text("and the claim follows.")

#text("Now we prove ")#link(<tao-eeea394806ada3056899>)[#text("(12)")]#text(". We first observe that if ")#mi("{N < d_2}")#text(", then ")#mi("{N < N^{1/2} d_2^{1/2}}")#text(" and the claim ")#link(<tao-eeea394806ada3056899>)[#text("(12)")]#text(" follows already from the trivial bound ")#link(<tao-6d4c9cf5e022a07ea801>)[#text("(10)")]#text(". Similarly, if ")#mi("{N > d^{\\prime}_1}")#text(", then ")#mi("{N^{1/2} d_2^{1/2} > [d_1,d_2]^{1/2}}")#text(" and also")

#align(center)[#tao-fit-display[#mitex("\\frac{(c_1,d^{\\prime}_1)^{1/4}}{(d^{\\prime}_1)^{1/4}} N \\geq N \\frac{(c_1,d^{\\prime}_1)}{d^{\\prime}_1} \\geq \\frac{N}{d_1 d_2} (d_1,d_2)^2 (c_1,d^{\\prime}_1) (c_2,d^{\\prime}_2)")]]

#text("so ")#link(<tao-eeea394806ada3056899>)[#text("(12)")]#text(" follows from ")#link(<tao-15f3b852d2465ae56ff5>)[#text("(11)")]#text(" in this case. Thus we may restrict attention to the regime")

#align(center)[#tao-fit-display[#mitex("d_2 \\leq N \\leq d^{\\prime}_1.")]]

#text("As before, we can rewrite ")#mi("{\\sum_n \\psi_N(n) e_q(f(n))}")#text(" as ")#link(<tao-dfbfcd6f5474f6d4ab08>)[#text("(14)")]#text(". Now set ")#metadata(none) <tao-d183d9f6cdb5ab064a1e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("K := \\lfloor \\frac{d^{\\prime}_1}{N} \\rfloor,")]]

#text("so ")#mi("{K \\geq 1}")#text(". Shifting ")#mi("{h}")#text(" by ")#mi("{d_2k}")#text(" for ")#mi("{k=1,\\ldots,K}")#text(" and averaging, we may then rewrite ")#link(<tao-dfbfcd6f5474f6d4ab08>)[#text("(14)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{qK} \\sum_{h \\in {\\bf Z}/q{\\bf Z}} \\sum_{k=1}^K \\hat \\psi_N(\\frac{h+d_2k}{q}) \\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n) + hn + knd_2).")]]

#text("From Lemma ")#link(<tao-793ff64f83b41b5d467a>)[#text("2")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n) + hn + knd_2) = (\\sum_{n_1 \\in {\\bf Z}/d_2{\\bf Z}} e_{d_2}(f(n_1)/d^{\\prime}_1 + hn_1/d^{\\prime}_1))")]]

#align(center)[#tao-fit-display[#mitex("(\\sum_{n_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}} e_{d^{\\prime}_1}(f(n_2)/d_2 + hn_2/d_2 + kn_2))")]]

#text("and so we may bound ")#tao-math("{\\left|\\sum_n \\psi_N(n) e_q(f(n))\\right|}", block: false)#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{qK} \\sum_{h \\in {\\bf Z}/q{\\bf Z}} \\left|\\sum_{n_1 \\in {\\bf Z}/d_2{\\bf Z}} e_{d_2}(f(n_1)/d^{\\prime}_1 + hn_1/d^{\\prime}_1)\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{k=1}^K \\hat \\psi_N(\\frac{h+d_2k}{q}) \\sum_{n_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}} e_{d^{\\prime}_1}(f(n_2)/d_2 + hn_2/d_2 + kn_2)\\right|.", block: true)]]

#text("By Proposition ")#link(<tao-740fc4991133b1523bc4>)[#text("4")]#text(" (and the coprimality of ")#mi("{d_2,d^{\\prime}_1}")#text("), we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n_1 \\in {\\bf Z}/d_2{\\bf Z}} e_{d_2}(f(n_1)/d^{\\prime}_1 + hn_1/d^{\\prime}_1)\\right| \\lessapprox d_2^{1/2} (f^{\\prime}+h,d_2) (f^{\\prime\\prime},d_2)^{-1/2}.", block: true)]]

#text("Thus we may bound the previous expression by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox \\frac{1}{d_2^{1/2} (f^{\\prime\\prime},d_2)^{1/2} d^{\\prime}_1 K} \\sum_{h \\in{\\bf Z}/q{\\bf Z}} (f^{\\prime}+h,d_2)")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{k=1}^K \\hat \\psi_N(\\frac{h+d_2k}{q}) \\sum_{n_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}} e_{d^{\\prime}_1}(f(n_2)/d_2 + hn_2/d_2 + kn_2)\\right|.", block: true)]]

#text("Next, let ")#mi("{\\epsilon>0}")#text(" be a small fixed quantity. By ")#link(<tao-04c56ad9992309bfa39f>)[#text("(15)")]#text(" as before, the contribution of those ")#mi("{h}")#text(" outside of the interval ")#mi("{[-x^\\epsilon q/N, x^\\epsilon q/N]}")#text(" is negligible, so it will suffice to show that ")#metadata(none) <tao-6558a6a3379db4f31039>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\frac{1}{d_2^{1/2} (f^{\\prime\\prime},d_2)^{1/2} d^{\\prime}_1 K} \\sum_{\\left|h\\right| \\leq x^\\epsilon q/N} (f^{\\prime}+h,d_2)", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{k=1}^K \\hat \\psi_N(\\frac{h+d_2k}{q}) \\sum_{n_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}} e_{d^{\\prime}_1}(f(n_2)/d_2 + hn_2/d_2 + kn_2)\\right| \\lessapprox", block: true)]]

#align(center)[#tao-fit-display[#mitex("x^{\\epsilon} (N^{1/2} (d^{\\prime}_1)^{1/4} + N^{1/2} d_2^{1/2} + \\frac{(c_1,d^{\\prime}_1)^{1/4}}{(d^{\\prime}_1)^{1/4}} N).")]]

#text("Now let us consider the sum ")#metadata(none) <tao-69e2f43a69ef0a193839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\sum_{\\left|h\\right| \\leq x^\\epsilon q/N} (f^{\\prime}+h,d_2)^2.", block: true)]]

#text("Bounding ")#mi("{(f^{\\prime}+h,d_2)^2 \\leq \\sum_{d|d_2} d^2 1_{d|f^{\\prime}+h}}")#text(", we may bound this sum by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\sum_{d|d_2} d^2 \\sum_{\\left|h\\right| \\leq x^\\epsilon q/N: d|f^{\\prime}+h} 1.", block: true)]]

#text("The inner sum is only non-vanishing when ")#mi("{d | (f^{\\prime\\prime},d_2)}")#text(", and in that case we have a bound of ")#mi("{O( \\frac{x^\\epsilon q/N}{d} + 1 )}")#text(" as in the proof of ")#link(<tao-15f3b852d2465ae56ff5>)[#text("(11)")]#text("; note that")

#align(center)[#tao-fit-display[#mitex("\\frac{x^\\epsilon q/N}{d} \\geq \\frac{q}{N d_2} \\geq \\frac{[d_1,d_2]}{d^{\\prime}_1 d_2} = 1,")]]

#text("so we may replace ")#mi("{O( \\frac{x^\\epsilon q/N}{d} + 1 )}")#text(" by ")#mi("{O( \\frac{x^\\epsilon q/N}{d} )}")#text(". By the divisor bound we may thus bound ")#link(<tao-69e2f43a69ef0a193839>)[#text("(18)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox x^\\epsilon (f^{\\prime\\prime},d_2) \\frac{q}{N}.")]]

#text("By Cauchy-Schwarz, we may thus bound the left-hand side of ")#link(<tao-6558a6a3379db4f31039>)[#text("(17)")]#text(" by ")#metadata(none) <tao-cabd786ac52d8cfc81b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\lessapprox x^\\epsilon \\frac{1}{(d^{\\prime}_1)^{1/2} N^{1/2} K} \\left|X\\right|^{1/2}", block: true)]]

#text("where ")#mi("{X}")#text(" is the quantity")

#align(center)[#tao-fit-display[#tao-math("X := \\sum_{h \\in {\\bf Z}/q{\\bf Z}} \\left|\\sum_{k=1}^K \\hat \\psi_N(\\frac{h+d_2k}{q}) \\sum_{n_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}} e_{d^{\\prime}_1}(f(n_2)/d_2 + hn_2/d_2 + kn_2)\\right|^2.", block: true)]]

#text("We may square ")#mi("{X}")#text(" out as")

#align(center)[#tao-fit-display[#mitex("X = \\sum_{1 \\leq k, k^{\\prime} \\leq K} \\sum_{n,n^{\\prime}} \\psi_N(n) \\overline{\\psi_N(n^{\\prime})} \\sum_{n_2,n^{\\prime}_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}} \\sum_{h \\in{\\bf Z}/q{\\bf Z}}")]]

#align(center)[#tao-fit-display[#mitex("e_{d^{\\prime}_1}(f(n_2)/d_2 + hn_2/d_2 + kn_2 - f(n^{\\prime}_2)/d_2 - hn^{\\prime}_2/d_2 - k^{\\prime}n^{\\prime}_2)")]]

#align(center)[#tao-fit-display[#mitex("e_q( h n^{\\prime} - h n ) e_{d^{\\prime}_1}(k^{\\prime}n^{\\prime} - kn).")]]

#text("Now observe from Fourier analysis that the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{h \\in {\\bf Z}/q{\\bf Z}} e_{d^{\\prime}_1}( hn_2/d_2 - hn^{\\prime}_2/d_2 ) e_q(hn^{\\prime} - hn)")]]

#text("equals ")#mi("{q}")#text(" when ")#mi("{n=n^{\\prime}\\ (d_2)}")#text(" and ")#mi("{n-n^{\\prime} = n_2-n^{\\prime}_2\\ (d^{\\prime}_1)}")#text(", and vanishes otherwise. Thus we may simplify the above expression as")

#align(center)[#tao-fit-display[#mitex("X = q\\sum_{1 \\leq k. k^{\\prime} \\leq K} \\sum_{n,n^{\\prime}: n=n^{\\prime}\\ (d_2)} \\psi_N(n) \\overline{\\psi_N(n^{\\prime})} e_{d^{\\prime}_1}(k^{\\prime}n^{\\prime} - kn)")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_2,n^{\\prime}_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}: n^{\\prime}_2-n_2 = n^{\\prime}-n\\ (d^{\\prime}_1)} e_{d^{\\prime}_1}(f(n_2)/d_2 + kn_2 - f(n^{\\prime}_2)/d_2 - k^{\\prime}n^{\\prime}_2).")]]

#text("Substituting ")#mi("{n^{\\prime}_2 = n_2 + n^{\\prime}-n}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("X = q\\sum_{1 \\leq k, k^{\\prime} \\leq K} \\sum_{n,n^{\\prime}: n=n^{\\prime}\\ (d_2)} \\psi_N(n) \\overline{\\psi_N(n^{\\prime})} e_{d^{\\prime}_1}((k^{\\prime}-k)n)")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}} e_{d^{\\prime}_1}(f(n_2)/d_2 + (k-k^{\\prime})n_2 - f(n_2+n^{\\prime}-n)/d_2 ).")]]

#text("As ")#mi("{\\psi_N}")#text(" is supported in an interval ")#mi("{I}")#text(" of length ")#mi("{O(N)}")#text(", we obtain the bound")

#align(center)[#tao-fit-display[#mitex("X \\lessapprox q\\sum_{1 \\leq k, k^{\\prime} \\leq K} \\sum_{n,n^{\\prime} \\in I: n=n^{\\prime}\\ (d_2)} |\\sum_{n_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}} e_{d^{\\prime}_1}(f(n_2)/d_2 + (k-k^{\\prime})n_2 - f(n_2+n^{\\prime}-n)/d_2)|.")]]

#text("We first isolate the diagonal terms ")#mi("{n^{\\prime}=n}")#text(". In this case the inner sum is a Ramanujan sum, so by ")#link(<tao-4d5725dcb64a0c04fb04>)[#text("(5)")]#text(" the diagonal contribution is bounded by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox q \\sum_{1 \\leq k,k^{\\prime} \\leq K} N (k-k^{\\prime},d^{\\prime}_1).")]]

#text("Summing in ")#mi("{k,k^{\\prime}}")#text(" using Lemma 5 from ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(", this is bounded by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox q N (K^2 + K d^{\\prime}_1) \\lessapprox qN K d^{\\prime}_1.")]]

#text("Now we handle the non-diagonal terms ")#mi("{n \\neq n^{\\prime}}")#text(". By Proposition ")#link(<tao-740fc4991133b1523bc4>)[#text("4")]#text(", this contribution to ")#mi("{X}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\lessapprox q\\sum_{1 \\leq k, k^{\\prime} \\leq K} \\sum_{n,n^{\\prime} \\in I: n=n^{\\prime}\\ (d_2); n \\neq n^{\\prime}} (d^{\\prime}_1)^{1/2} (f^{\\prime} - f^{\\prime}(\\cdot+n^{\\prime}-n) + (k-k^{\\prime})d_2, d^{\\prime}_1) (f^{\\prime\\prime} - f^{\\prime\\prime}(\\cdot+n^{\\prime}-n),d^{\\prime}_1)^{-1/2}.")]]

#text("Bounding")

#align(center)[#tao-fit-display[#mitex("(f^{\\prime} - f^{\\prime}(\\cdot+n^{\\prime}-n) + (k-k^{\\prime})d_2, d^{\\prime}_1) \\leq \\sum_{d|d^{\\prime}_1} d 1_{d| f^{\\prime} - f^{\\prime}(\\cdot+n^{\\prime}-n) + (k-k^{\\prime})d_2}")]]

#text("we can bound the preceding expression by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox q(d^{\\prime}_1)^{1/2} \\sum_{n,n^{\\prime} \\in I: n=n^{\\prime}\\ (d_2); n \\neq n^{\\prime}} (f^{\\prime\\prime} - f^{\\prime\\prime}(\\cdot+n^{\\prime}-n),d^{\\prime}_1)^{-1/2} \\sum_{d|d^{\\prime}_1} d \\sum_{1 \\leq k,k^{\\prime} \\leq K} 1_{d|f^{\\prime}-f^{\\prime}(\\cdot+n^{\\prime}-n)+(k-k^{\\prime})d_2}.")]]

#text("The inner sum vanishes unless ")#mi("{d | (f^{\\prime\\prime} - f^{\\prime\\prime}(\\cdot+n^{\\prime}-n),d^{\\prime}_1)}")#text(". In that case, ")#mi("{k-k^{\\prime}}")#text(" is restricted to a single residue class modulo ")#mi("{d}")#text(", and so the inner sum is ")#mi("{O( K^2/d + K )}")#text(". From the divisor bound we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d|d^{\\prime}_1} d \\sum_{1 \\leq k,k^{\\prime} \\leq K} 1_{d|f^{\\prime}-f^{\\prime}(\\cdot+n^{\\prime}-n)+(k-k^{\\prime})d_2} \\lessapprox K^2 + K (f^{\\prime\\prime} - f^{\\prime\\prime}(\\cdot+n^{\\prime}-n),d^{\\prime}_1)")]]

#text("and thus this contribution to ")#mi("{X}")#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox q(d^{\\prime}_1)^{1/2} \\sum_{n,n^{\\prime} \\in I: n=n^{\\prime}\\ (d_2); n \\neq n^{\\prime}} (K^2 (f^{\\prime\\prime} - f^{\\prime\\prime}(\\cdot+n^{\\prime}-n),d^{\\prime}_1)^{-1/2}")]]

#align(center)[#tao-fit-display[#mitex("+ K (f^{\\prime\\prime} - f^{\\prime\\prime}(\\cdot+n^{\\prime}-n),d^{\\prime}_1)^{1/2} ).")]]

#text("From the explicit formula ")#link(<tao-b1c4d1f75430b6a185ee>)[#text("(13)")]#text(" we see that if ")#mi("{p | d^{\\prime}_1}")#text(", then ")#mi("{p | f^{\\prime\\prime} - f^{\\prime\\prime}(\\cdot + n^{\\prime}-n)}")#text(" if and only if")

#align(center)[#tao-fit-display[#mitex("p | \\frac{2c_1}{t^3} - \\frac{2c_1}{(t+n^{\\prime}-n)^3}.")]]

#text("For ")#mi("{p}")#text(" large enough, this only happens if ")#mi("{p | c_1}")#text(" or ")#mi("{p | n^{\\prime}-n}")#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("(f^{\\prime\\prime} - f^{\\prime\\prime}(\\cdot+n^{\\prime}-n),d^{\\prime}_1) \\ll (c_1,d^{\\prime}_1) (n^{\\prime}-n, d^{\\prime}_1)")]]

#text("and thus this contribution to ")#mi("{X}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\lessapprox q(d^{\\prime}_1)^{1/2} (K^2 N^2 / d_2 + K (c_1,d^{\\prime}_1)^{1/2} \\sum_{n,n^{\\prime} \\in I: n=n^{\\prime}\\ (d_2); n \\neq n^{\\prime}} (n^{\\prime}-n, d^{\\prime}_1)^{1/2} ).")]]

#text("If we estimate")

#align(center)[#tao-fit-display[#mitex("(n^{\\prime}-n, d^{\\prime}_1)^{1/2} \\leq \\sum_{d|d^{\\prime}_1} d^{1/2} 1_{d|n^{\\prime}-n}")]]

#text("we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n,n^{\\prime} \\in I: n=n^{\\prime}\\ (d_2)} (n^{\\prime}-n, d^{\\prime}_1)^{1/2}  & \\leq \\sum_{d|d^{\\prime}_1} d^{1/2} \\sum_{n,n^{\\prime} \\in I: n-n^{\\prime}\\ (dd_2); n \\neq n^{\\prime}} 1", block: true)



#tao-math(" & \\ll \\sum_{d|d^{\\prime}_1} d^{1/2} \\frac{N^2}{dd_2}\\", block: true)
]

#align(center)[#tao-fit-display[#mitex("\\lessapprox N^2 d_2^{-1}.")]]

#text("This contribution to ")#mi("{X}")#text(" is thus")

#align(center)[#tao-fit-display[#mitex("\\lessapprox q(d^{\\prime}_1)^{1/2} K^2 N^2 d_2^{-1} + qK (d^{\\prime}_1)^{1/2} (c_1,d^{\\prime}_1)^{1/2} N^2 d_2^{-1}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("X \\lessapprox qNKd^{\\prime}_1 + q(d^{\\prime}_1)^{1/2} K^2 N^2 d_2^{-1} + qK (d^{\\prime}_1)^{1/2} (c_1,d^{\\prime}_1)^{1/2} N^2 d_2^{-1}.")]]

#text("Inserting this back into ")#link(<tao-cabd786ac52d8cfc81b0>)[#text("(19)")]#text(" gives the desired bound ")#link(<tao-6558a6a3379db4f31039>)[#text("(17)")]#text(". This completes the proof of ")#link(<tao-eeea394806ada3056899>)[#text("(12)")]#text(". ")#mi("\\Box")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235760")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("“(In fact, from the classical theory of Gauss sums, this exponential sum is equal to {\\tau(\\chi) \\chi(a)} for some complex number {\\tau(\\chi)} of norm one.”")

#text("I think ")#mi("\\tau(\\chi)")#text(" has norm ")#mi("\\sqrt {q}")#text(". Maybe I do not understand.")

#emph[#text("[Oops, that was a typo, fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8639d6f9d683df1a6413b70b2104fcb45b576c9e793fdc79f22e15364f7a560-53bd9ce026c9d6d4591048cd40e4e6030c11e450da6d2a9055674781be1e23f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Young")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235827")[#strong[#text("Matt Young")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Proposition 1 looks to be related to a result of Heath-Brown: Hybrid bounds for Dirichlet L-functions. Invent. Math. 47 (1978), no. 2, 149–170. Specifically, compare with Heath-Brown’s Theorem 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235829")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Thanks for the reference! I was surprised that I was not able to locate this argument before in the literature, given how simple it was. Indeed Theorem 2 of Heath-Brown is essentially the same result with the same proof (except that he considers the Dirichlet series of a character rather than a character sum). I’ve updated the post to reflect this. I wonder why this trick (with Heath-Brown calls “a q-analogue of van der Corput”) is not used more often in the literature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235831")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Terry, one place it is used is in Heath-Brown’s 2009 preprint on cubic weyl sums ")#link("http://arxiv.org/pdf/0905.1869.pdf")[#text("http://arxiv.org/pdf/0905.1869.pdf")]

#text("Roger says in that paper that some credit must go to C. Ringrose, whose 1985 PhD thesis (written under Heath-Brown’s supervision) is in fact entitled “The q-analogue of van der Corput’s method”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235842")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Thanks for the reference! I was aware of ")#link("http://link.springer.com/content/pdf/10.1007%2F978-1-4612-3464-7_18.pdf")[#text("a paper of Graham and Ringrose")]#text(" on the topic but did not realise until now that this paper is indeed based in part on the earlier paper of Heath-Brown. (The main theorem, Theorem 5, of Graham-Ringrose looked weaker to me than what is in this post or in Heath-Brown, but on closer inspection I now see that the k=0 case of that theorem is basically what is given here (although this was not obvious at a first glance)).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235841")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Just a note that might be relevant: recently Djordje Milićević developed a powerful theory of p-adic exponential pairs in his manuscript “Sub-Weyl subconvexity for Dirichlet L-functions to prime power moduli”. A related paper is his joint work with Valentin Blomer, “p-adic analytic twists and strong subconvexity”. These papers are not public yet, but will appear soon (I think). Abstract of a very recent talk by Valentin: ")#link("http://www.cirm.univ-mrs.fr/RepRenc/746/abstracts746.pdf")[#text("http://www.cirm.univ-mrs.fr/RepRenc/746/abstracts746.pdf")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("I’m recording here some minor reductions that make the proof of Proposition 5 marginally simpler, though not by much:")

#text("* We can assume that ")#mi("(c_1,d^{\\prime}_1)=1")#text(", since otherwise we can cancel the common factor from both ")#mi("c_1")#text(" and ")#mi("d^{\\prime}_1")#text(". (Actually one has to dispose of the condition ")#mi("(n,(c_1,d^{\\prime}_1))=1")#text(" to do this, but this can be done by a routine Mobius inversion argument.) Similarly we may assume that ")#mi("(c_2,d^{\\prime}_2)=1")#text(".")

#text("* By partitioning the integers into residue classes modulo ")#mi("(d_1,d_2)")#text(", and making the change of variables ")#mi("n = (d_1,d_2) n^{\\prime} + b")#text(" for each such residue class and summing using the triangle inequality, we may reduce to the case when ")#mi("(d_1,d_2)=1")#text(" (so that ")#mi("d^{\\prime}_1=d_1")#text(" and ")#mi("d^{\\prime}_2=d_2")#text(").")

#text("* Once we have reduced to ")#mi("(d_1,d_2)=1")#text(", we can translate ")#mi("n")#text(" using the Chinese remainder theorem to reduce to the case ")#mi("l=0")#text(". The phase ")#mi("e_{d_1}(c_1/n) e_{d_2}(c_2/(n+l))")#text(" then simplifies to a single phase ")#mi("e_{d_1 d_2}(c/n)")#text(" for some ")#mi("c")#text(" coprime to ")#mi("d_1 d_2")#text(".")

#text("When we are working in the case ")#mi("(c_1,d_1)=(c_2,d_2)=(d_1,d_2)=1")#text(" and ")#mi("l=0")#text(" (which we can essentially reduce to from the above discussion), then Proposition 5(iii) gives")

#tao-math("\\left|S\\right| \\lessapprox N^{1/2} d_1^{1/4} + N^{1/2} d_2^{1/2} + N d_1^{-1/4}.", block: false)

#text("Actually, in view of the above reductions, I think the same argument actually gives")

#tao-math("\\left|S\\right| \\lessapprox N^{1/2} q_1^{1/4} + N^{1/2} q_2^{1/2} + N q_1^{-1/4}.", block: false)

#text("for any other factorisation ")#mi("d_1d_2 = q_1 q_2")#text(". Given how smooth (or at least how densely divisible) all the moduli we are working with are, this could lead to some further optimisation of this exponential sum estimate which would lead to further improvement in the Type I/II estimates. But it will lead to some technical complications on the GPY sieving side: we may need to strengthen the notion of “")#mi("x^\\delta")#text("-densely divisible” to something like being “doubly ")#mi("x^\\delta")#text("-densely divisible, namely that any modulus can be factored into two factors in specified intervals of multiplicative width ")#mi("x^\\delta")#text(", such that each factor is itself ")#mi("x^\\delta")#text("-densely divisible. I might experiment with this in a few days to see if it really does give any significant improvement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235911")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Kowalski says that the work in the paper can be done without the Weyl-type shifts, here:")

#link("http://blogs.ethz.ch/kowalski/2013/06/22/bounded-gaps-between-primes-the-dawn-of-some-enlightenment/")[#text("http://blogs.ethz.ch/kowalski/2013/06/22/bounded-gaps-between-primes-the-dawn-of-some-enlightenment/")]

#text("and that they get exponent of distribution 4/7 ” for the ternary divisor function with nicely factorable moduli” (does that give us ")#mi("\\varpi = (4/7 - 1/2)/2 = 1/28")#text("? Or am I getting some quantities confused? I’m only following this story with half an eye)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("The relationship is more complicated than this because the ternary divisor function is a reduced component of the Type III sums but is not the entire Type III sum (and in any event the Type III estimates have to be balanced against the Type I/II estimates). I computed the numerology against an older version of the Type I/II sums in ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235226")[#text("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235226")]#text(" . Redoing the numerology, it appears that if we assumed the 4/7 level of distribution for the ternary divisor function as a black box and ignored ")#mi("\\delta")#text(", we would have to balance ")#mi("\\sigma > 1/12 + 7 \\varpi/3")#text(" (and also ")#mi("\\sigma > 1/10")#text(", but this turns out to be weaker) against ")#mi("\\sigma < 1/6 - 20 \\varpi/3")#text(", which would get us to the value of ")#mi("\\varpi=1/108")#text(". With this new numerology it appears that it would still be worthwhile to improve the 4/7=0.5714 a little further; if one could get to 26/45=0.5778 for ternary divisor function then ")#mi("\\varpi")#text(" would hit the nice round value of ")#mi("1/100")#text(", and then further improvements in Type III bounds do not gain anything unless one also improves on the Type I sums (or else starts dealing with Type IV and Type V sums related to the fourth and fifth order divisor functions…).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235921")[#strong[#text("The distribution of primes in densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("[…] new input that was not present in the previous Type I analysis. Applying Proposition 5(iii) from this previous post, and noting that are coprime, we can bound the left-hand side of (51) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236033")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("I just realised that Proposition 5(iii) can be proven without as much recourse to the Fourier transform, because the main terms on the RHS have a factor of ")#mi("N^{1/2}")#text(" and are thus morally invariant with respect to Fourier transforming/Poisson summation (it’s like bounding an L-function on the critical line ")#mi("s=1/2")#text(", it shouldn’t help to apply the functional equation). Because of this, I think I can improve the final term in (iii) to get")

#tao-math("\\left|S\\right| \\lessapprox N^{1/2} ((d^{\\prime}_1)^{1/4} + d_2^{1/2}) + \\frac{(c_1,d^{\\prime}_1)}{d^{\\prime}_1} \\frac{(c_2,d^{\\prime}_2)}{d^{\\prime}_2} N", block: false)#text(".")

#text("This doesn’t directly improve the exponents, but it does make the estimation of certain secondary terms in the analysis easier.")

#text("I sketch the proof as follows. By the reductions mentioned in ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-235877")[#text("my previous comment")]#text(", we may assume that ")#mi("(c_1,d_1)=(c_2,d_2)=(d_1,d_2)=1")#text(". (One may also assume ")#mi("l=0")#text(" but this does not simplify the analysis.) As in the main post we may also take ")#mi("d_2 \\leq N \\leq d_1")#text(" otherwise the standard bound (ii) is superior. It then suffices to show that")

#tao-math("\\left|\\sum_n \\psi_N(n) e_{d_1}(\\frac{c_1}{n+l}) e_{d_2}(\\frac{c_2}{n})\\right| \\lessapprox N^{1/2} d_1^{1/4}  + N^{1/2} d_2^{1/2}", block: false)#text(".")

#text("This can be proven by an argument very similar to the proof of Proposition 1. Namely, we perform Weyl differencing, replacing ")#mi("n")#text(" by ")#mi("n+kd_2")#text(" for ")#mi("1 \\leq k \\leq K")#text(", where ")#mi("K := \\lfloor N/d_2\\rfloor")#text(". This transforms the above sum to")

#tao-math("\\left|\\sum_n e_{d_2}(\\frac{c_2}{n+l}) \\sum_{k=1}^K \\psi_N(n+kd_2) e_{d_1}(\\frac{c_1}{n+kd_2}) \\right| \\lessapprox K N^{1/2} (d_1^{1/4}  + d_2^{1/2})", block: false)#text(".")

#text("The ")#mi("n")#text(" variable is localised to an interval of length ")#mi("O(N)")#text(", so by Cauchy-Schwarz it suffices to show that")

#tao-math("\\sum_n \\left|\\sum_{k=1}^K \\psi_N(n+kd_2) e_{d_1}(\\frac{c_1}{n+kd_2}) \\right|^2 \\lessapprox K^2 (d_1^{1/2}  + d_2)", block: false)#text(".")

#text("The left-hand side expands as the sum of a diagonal term of ")#mi("O(NK) = O(K^2 d^2)")#text(" and the off-diagonal terms")

#mi("\\sum_{1 \\leq k,k^{\\prime} \\leq K: k \\neq k^{\\prime}} \\sum_n \\psi_N(n+kd_2) \\psi_N(n+k^{\\prime}d_2) e_{d_1}(\\frac{c_1}{n+kd_2} - \\frac{c_1}{n+k^{\\prime}d_2}).")

#text("By completion of sums, the inner sum may be bounded by ")#mi("\\lessapprox d_1^{1/2} + d_1^{-1/2} (k-k^{\\prime},d_1)^{1/2} N")#text("; summing in ")#mi("k,k^{\\prime}")#text(" this gives a bound of ")#mi("\\lessapprox K^2 (d_1^{1/2} + d_1^{-1/2} N) \\lessapprox K^2 d^{1/2}")#text(" by the hypothesis ")#mi("N \\leq d_1")#text(", and the claim follows.")

#text("—")

#text("One further comment. Until recently, when one needed to bound the sum")

#mi("S = \\sum_n \\psi_N(n) e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} ),")

#text("the quantity ")#mi("N")#text(" was a bit larger than ")#mi("(d_1d_2)^{1/2}")#text(" and so, given a choice between the trivial bound (i) and the standard bound (ii), the standard bound was superior (and was what was used in Zhang’s paper). But with the latest critical numerology, ")#mi("N")#text(" has fallen below ")#mi("(d_1 d_2)^{1/2}")#text(", and in fact it appears that the shorter we can make ")#mi("N")#text(" (relative to ")#mi("d_1 d_2")#text(") and still get an improvement on the trivial bound, the better the Type I analysis becomes. The new bound (iii) gets us down to ")#mi("N = (d_1 d_2)^{1/3}")#text(" if we have dense divisibility in ")#mi("d_1 d_2")#text(" (and if ")#mi("(c_1,d_1), (c_2,d_2)")#text(" are negligible, which they usually are in practice). So now we are in the realm where we want to start applying Burgess-type arguments in combination with the Weyl differencing (aka the q-analogue of van der Corput). Here it seems that the Graham-Ringrose paper ")#link("http://www.ams.org/mathscinet-getitem?mr=1084186")[#text("http://www.ams.org/mathscinet-getitem?mr=1084186")]#text(" will be relevant, because they do exactly this (but for character sums instead of Kloosterman sums). Basically the idea seems to be to perform Weyl differencing more than once – probably in our context twice is all we will need (and any further Weyl differencing presumably becomes counterproductive).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236035")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("Oh, I begin to see what’s going on. The first Weyl differencing replaces a sum such as S with a sum of the form")

#mi("\\sum_n \\psi_N( n + k d_1) \\psi_N( n + k^{\\prime} d_1) e_{d_1}( \\frac{c_1}{n+kd_1} - \\frac{c_1}{n+k^{\\prime}d_1} )")

#text("and the latter was then dealt with by the standard estimate coming from completion of sums. But there is nothing stopping us from iterating the procedure, factoring ")#mi("d_1")#text(" in a well-chosen fashion into, say, ")#mi("d_1 = d_3 d_4")#text(" and performing Weyl differencing again (the rational functions in the phase become increasingly complicated when one does this, but that’s OK I think, the Weil conjectures can bound all of the completed exponential sums that arise). In principle one can get non-trivial bounds for ")#mi("N")#text(" as small a power of ")#mi("d_1 d_2")#text(" as we please (but we make increasing reliance on the dense divisibility by doing so, and the gain becomes exponentially smaller as we shrink ")#mi("N")#text("). This is all consistent with Graham-Ringrose (who refer to this Weyl differencing procedure as the “q-analogue of the van der Corput A-process”. Hmm – it occurs to me that the Fourier transform/Poisson summation is the q-analogue of the van der Corput B-process, so in principle all the van der Corput exponent pairs are available for use here…).")

#text("I have to work out the details, but it is likely that this is going to give another significant improvement to the numerology (beyond what we have tentatively worked out just through optimising the first Weyl differencing through refactoring). Basically, in the Type I analysis, one only has to gain a factor of ")#mi("H^2 \\approx x^{4\\varpi}")#text(" over the trivial bound for ")#mi("S")#text(" in order to win (one has to overcome a previous loss of ")#mi("H")#text(" coming from completion of sums, amplified to ")#mi("H^2")#text(" coming from a previous use of Cauchy-Schwarz). While ")#mi("\\varpi")#text(" is beginning to get large enough that this ")#mi("x^{4\\varpi}")#text(" factor is beginning to get noticeable, I don’t think that it is dominating the analysis yet, and enlarging the range of ")#mi("N")#text(" for which non-trivial bounds on ")#mi("S")#text(" are available should still be the better win. The numerology is that ")#mi("N \\approx x^{1/2-\\sigma}")#text(" and ")#mi("d_1 d_2 \\approx Q^3 R \\approx x^{1/2+2\\sigma+4\\varpi}")#text("; making ")#mi("N")#text(" as small a power of ")#mi("Q^3 R")#text(" as possible would allow us to raise ")#mi("\\sigma")#text(" as high as possible, which is good because of the lower bounds on ")#mi("\\sigma")#text(" coming from the Type III analysis (and also from the combinatorial constraint ")#mi("\\sigma>1/10")#text(", although this is not yet dominant).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236039")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("Let’s try blindly plugging in the numerology from Theorem 5 of ")#link("http://link.springer.com/content/pdf/10.1007%2F978-1-4612-3464-7_18.pdf")[#text("Graham-Ringrose")]#text(" to get a rough idea of what to expect. For smooth squarefree moduli q, this theorem is basically asserting that")

#tao-math("\\left|\\sum_{M \\leq n \\leq N+M} \\chi(n)\\right| \\lessapprox M^{1-\\frac{k+3}{8K-2}} q^{\\frac{1}{8K-2}}", block: false)

#text("for ")#mi("k \\geq 0")#text(", where ")#mi("K = 2^k")#text(" and ")#mi("N \\leq M")#text(". By analogy (and ignoring delta), we would expect")

#tao-math("\\left|S\\right| \\lessapprox N^{1-\\frac{k+3}{8K-2}} (d_1 d_2)^{\\frac{1}{8K-2}}.", block: false)

#text("(Although since Kloosterman sums do not have mean zero like character sums, there should also be a lower order term that is linear in N that we will ignore here.)")

#text("For k=0 this becomes")

#tao-math("\\left|S\\right| \\lessapprox N^{1/2} (d_1 d_2)^{1/6}", block: false)

#text("which basically is our current estimate (iii) after optimising the factorisation, and gives non-trivial bounds for ")#mi("N \\gg (d_1 d_2)^{1/3}")#text(". The k=1 version is")

#tao-math("\\left|S\\right| \\lessapprox N^{1-2/7} (d_1 d_2)^{1/14}", block: false)

#text("which is non-trivial for ")#mi("N \\gg (d_1 d_2)^{1/4}")#text(". Roughly speaking, to win using this estimate we would need")

#mi("N^{1-2/7} (Q^3 R)^{1/14} \\ll x^{-4\\varpi} N")

#text("which rearranges to")

#mi("4\\varpi + \\frac{1}{14} ( \\frac{1}{2}+2\\sigma+4\\varpi ) < \\frac{2}{7} (\\frac{1}{2} - \\sigma)")

#text("which (I think) simplifies to")

#mi("40 \\varpi + 4 \\sigma < 1")#text(".")

#text("Balancing this against ")#mi("\\sigma > \\frac{1}{10} + \\frac{16}{5} \\varpi")#text(" gives (I think)")

#mi("\\varpi < 1/88")

#text("(so the critical numerology is now ")#mi("\\varpi=1/88")#text(", ")#mi("\\sigma=3/22")#text("). So in principle we have gained a bit over the previous estimate.")

#text("Let’s push our luck and try k=2:")

#tao-math("\\left|S\\right| \\lessapprox N^{1-1/6} (d_1 d_2)^{1/30}", block: false)

#text("which is non-trivial for ")#mi("N \\gg (d_1 d_2)^{1/5}")#text(". We now win if")

#mi("4\\varpi + \\frac{1}{30} ( \\frac{1}{2}+2\\sigma+4\\varpi ) < \\frac{1}{6} (\\frac{1}{2} - \\sigma)")

#text("which is")

#mi("124 \\varpi + 7 \\sigma < 2;")

#text("balancing against ")#mi("\\sigma > \\frac{1}{10} + \\frac{16}{5} \\varpi")#text(" seems to give")

#mi("\\varpi < \\frac{13}{1464}")

#text("so we are no longer winning (the gains in the ")#mi("\\sigma")#text(" aspect are finally being overwhelmed by the exponentially growing losses in the ")#mi("\\varpi")#text(" aspect). So the method seems to max out at ")#mi("\\varpi = 1/88")#text(", although one should do a bit better if we plug in the ")#mi("4/7")#text(" level of distribution for d_3 announced by FKM which replaces ")#mi("\\sigma > \\frac{1}{10} + \\frac{16}{5} \\varpi")#text(" with ")#mi("\\sigma > \\frac{1}{12} + \\frac{7\\varpi}{3}")#text(" and ")#mi("\\sigma > \\frac{1}{10}")#text(", which by my rough calculation should get us to ")#mi("\\varpi = 1/74")#text(".")

#text("LOTS of details to check before this is fleshed out properly though…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236070")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("Incidentally, the Type II analysis (which until now has not been a dominant source of constraints) currently has a barrier at ")#mi("\\varpi = 1/96")#text(" (or more precisely, the current Type II arguments only work when ")#mi("48 \\varpi + 7 \\delta < 1/2")#text(") but I am sure this can be lowered using the improved exponential sum estimates discussed here (and also perhaps by exploiting generic coprimality of ")#mi("c_2")#text(" and ")#mi("d_2")#text(", something which has thus far been unexploited as it previously only affected non-dominant terms).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/352abab2ec212883b4ee61cf3dc3c234ffb41a8828d272f0b9b890f6d4b34695-c4b57ed19849c12edaf3ec37c105f223029747bb987d24bf9a3862d363b0d3bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Enrique Trevino")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236162")[#strong[#text("Enrique Trevino")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("If ")#mi("w = 1/96")#text(" (the type 3 barrier) then the best one could get for ")#mi("k_0")#text(" is ")#mi("k_0 = 751")#text(" which yields ")#mi("H = 5670")#text(".")

#text("If ")#mi("w = 1/88")#text(" then the best possible ")#mi("k_0")#text(" is ")#mi("k_0 = 656")#text(" which yields ")#mi("H = 4870")#text(".")

#text("If ")#mi("w = 1/74")#text(" the best ")#mi("k_0")#text(" is ")#mi("k_0 = 502")#text(" yielding ")#mi("H = 3612")#text(".")

#text("The values for ")#mi("H")#text(" are according to the Engelsma and Sutherland lists. The ")#mi("k_0")#text(" comes from checking ")#mi("1 + 4\\omega > \\frac{j_{k_0-2}}{k_0(k_0 - 1)}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236219")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("Thanks for the calculations! A fair bit of work will need to be done before we can claim these numbers (or some reasonably close values to these numbers) as confirmed, but it gives us some idea of what to expect we can get by pushing the ideas we currently have…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236228")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("I’m recording some more rigorous bounds on exponential sums ")#mi("S = S_{f}(N, d)")#text(" of the form")

#mi("S_f(N,d) := \\sum_n \\psi_N(n) e_d( f(n) )")

#text("where ")#mi("d, N \\gg 1")#text(" are of polynomial size, ")#mi("d")#text(" is square-free, ")#mi("\\psi_N")#text(" is a smooth function on an interval of length ")#mi("\\sim N")#text(", and ")#mi("f")#text(" is an integral rational function. Strictly speaking, ")#mi("S_f(N,d)")#text(" depends not just on ")#mi("N")#text(", but on the choice of smooth function ")#mi("\\psi_N")#text(", but I will abuse notation by suppressing this latter dependence. For technical reasons we will restrict attention to rational functions ")#mi("f(t) = P(t)/Q(t)")#text(" which ")#emph[#text("vanish at infinity")]#text(" in the sense that ")#mi("\\text{deg}(P) < \\text{deg}(Q)")#text("; certainly Kloosterman type phases (e.g. ")#mi("f(t) = \\frac{c_1}{t} + \\frac{c_2}{t+l}")#text(") fall into this category, and any linear combination of functions that vanish at infinity, or their derivatives and translates, will also vanish at infinity.")

#text("For minor technical reasons (to avoid low characteristic issues) it is also convenient to assume that ")#mi("d")#text(" has no prime factor smaller than ")#mi("w")#text(", where ")#mi("w \\to \\infty")#text("; fortunately for our applications this is automatic.")

#text("We have the trivial bound")

#tao-math("\\left|S_f(N,d)\\right| \\lessapprox N.", block: false)#text(" (1)")

#text("I now claim the following van der Corput bounds:")

#strong[#text("Van der Corput bound")]#text(" Let ")#mi("k \\geq 1")#text(" be fixed, and let ")#mi("d = d_1 \\ldots d_k")#text(". Then")

#tao-math("\\left|S_f(N,d)\\right| \\lessapprox \\sum_{i=1}^{k-1} N^{1-1/2^i} (d^{\\prime}_i)^{1/2^i} + N^{1-1/2^{k-1}} (d^{\\prime}_k)^{1/2^k}", block: false)

#mi("+ 1_{N \\geq d^{\\prime}} \\frac{N}{(d^{\\prime})^{1/2}}")

#text("where ")#mi("d^{\\prime} := d / (f^{\\prime},d)")#text(" and ")#mi("d^{\\prime}_i := d_i / (f^{\\prime},d_i)")#text(".")

#text("Thus, for instance, the k=1 bound is")

#tao-math("\\left|S_f(N,d)\\right| \\lessapprox (d^{\\prime})^{1/2} + 1_{N \\geq d^{\\prime}} N / (d^{\\prime})^{1/2}", block: false)

#text("the k=2 bound is")

#tao-math("\\left|S_f(N,d)\\right| \\lessapprox N^{1/2} (d^{\\prime}_1)^{1/2} + N^{1/2} (d^{\\prime}_2)^{1/4} + 1_{N \\geq d^{\\prime}} N / (d^{\\prime})^{1/2}", block: false)

#text("when ")#mi("d = d_1 d_2")#text(", and the k=3 bound is")

#tao-math("\\left|S_f(N,d)\\right| \\lessapprox N^{1/2} (d^{\\prime}_1)^{1/2} + N^{3/4} (d^{\\prime}_2)^{1/4} + N^{3/4} (d^{\\prime}_3)^{1/8} + 1_{N \\geq d^{\\prime}} N / (d^{\\prime})^{1/2}", block: false)

#text("when ")#mi("d = d_1 d_2 d_3")#text(". As mentioned earlier, I believe that k=3 is the optimal value of k for the polymath8 project; any further increase in k looks to be counterproductive.")

#text("The van der Corput bound is proven by induction on k, so fix k and assume that the claim has already been proven for smaller values of k.")

#text("We first observe that we can reduce to the case ")#mi("(f^{\\prime},d)=1")#text(", because any common factor between ")#mi("d")#text(" and ")#mi("f^{\\prime}")#text(" is also a common factor between ")#mi("d")#text(" and ")#mi("f")#text(" (here we use the vanishing of ")#mi("f")#text(" at infinity, as well as the absence of small primes) and can thus be factored out of the phase ")#mi("e_d(f(n))")#text(" by reducing ")#mi("d")#text(" appropriately. (This leaves behind a residual constraint that the denominator ")#mi("Q(n)")#text(" of ")#mi("f(n)")#text(" be coprime to ")#mi("(f^{\\prime},d)")#text(", but this constraint can be dealt with by Mobius inversion or else carried throughout the arguments below.) So henceforth we assume ")#mi("(f^{\\prime},d)=1")#text(", so that ")#mi("d=d^{\\prime}")#text(" and ")#mi("d_i = d^{\\prime}_i")#text(". Note that this also implies that ")#mi("(f^{\\prime\\prime},d)=1")#text(", because any prime that divides ")#mi("f^{\\prime\\prime}")#text(" will also divide ")#mi("f^{\\prime}")#text(" by the fundamental theorem of calculus and the vanishing at infinity.")

#text("Now we prove the k=1 case. It suffices to show that")

#tao-math("\\left|S_f(N,d)\\right| \\lessapprox d^{1/2} + N / d^{1/2}", block: false)

#text("since the second term dominates only when ")#mi("N \\geq d")#text(". By chopping up ")#mi("\\psi_N")#text(" into shorter pieces we may assume that ")#mi("N \\ll d")#text(". By completion of sums we can bound the LHS by")

#mi("\\lessapprox \\frac{N}{d} \\sum_{h = O( d/N )}  |\\sum_{n \\in {\\bf Z}/d{\\bf Z}} e_d(f(n) + hn) )|")#text(".")

#text("By the Weil conjectures , this is")

#mi("\\lessapprox \\frac{N}{d^{1/2}} \\sum_{h = O( d/N )} (f^{\\prime} + h, d)^{1/2}")

#text("and the summation is ")#mi("O(d/N)")#text(", giving the claim.")

#text("Now assume that ")#mi("k \\geq 2")#text(" and that the k-1 case has already been proven. If ")#mi("N \\geq d_k")#text(" then the claim follows from the induction hypothesis (concatenating ")#mi("d_{k-1}, d_k")#text(" into a single ")#mi("\\tilde d_{k-1}")#text("), since ")#mi("N^{1-1/2^{k-1}} d_{k-1}^{1/2^{k-1}} \\geq N^{1-1/2^{k-2}} \\tilde d_{k-1}^{1/2^{k-2}}")#text(" in this case. So we may assume that ")#mi("N \\leq d_k")#text(". We may also assume that ")#mi("N \\geq d_1")#text(", since otherwise ")#mi("N^{1/2} d_1^{1/2} \\geq N")#text(" and the claim already follows from the trivial bound.")

#text("We perform Weyl differencing, shifting ")#mi("n")#text(" to ")#mi("n+hd_1")#text(" for ")#mi("1 \\leq h \\leq H")#text(", where ")#mi("H := \\lfloor N/d_1 \\rfloor")#text(". This lets us write ")#mi("S_f(N,d)")#text(" as")

#mi("\\frac{1}{H} \\sum_n \\sum_{h=1}^H \\psi_N(n+hd_1) e_d(f(n+hd_1)).")

#text("We can factor")

#mi("e_d(f(n+hd_1)) = e_{d_1}( f(n) / (d_2 \\ldots d_k) ) e_{d_2 \\ldots d_k} (f(n+hd_1) / d_1 )")

#text("so that ")#tao-math("\\left|S_f(N,d)\\right|", block: false)#text(" is bounded by")

#mi("\\frac{1}{H} \\sum_n |\\sum_{h=1}^H \\psi_N(n+hd_1) e_{d_2 \\ldots d_k} (f(n+hd_1)/d_1)|.")

#text("By Cauchy-Schwarz we may bound this by")

#tao-math("\\ll \\frac{N^{1/2}}{H}  ( \\sum_n \\left|\\sum_{h=1}^H \\psi_N(n+hd_1) e_{d_2 \\ldots d_k} (f(n+hd_1)/d_1)\\right| )^{1/2}.", block: false)

#text("The expression inside parentheses is expanded as")

#mi("\\sum_{1 \\leq h,h^{\\prime} \\leq H} \\sum_n \\psi_N(n+hd_1) \\overline{\\psi_N}(n+h^{\\prime}d_1) e_{d_2 \\ldots d_k}( (f_{hd_1} - f_{h^{\\prime}d_1}) / d_1 )")#text(" (**)")

#text("where ")#mi("f_h(n) := f(n+h)")#text(". This is an expression of the form")

#mi("\\sum_{1 \\leq h,h^{\\prime} \\leq H} S_{(f_{hd_1} - f_{h^{\\prime}d_1}) / d_1}(N, d_2 \\ldots d_k ).")

#text("The diagonal terms ")#mi("h=h^{\\prime}")#text(" contribute a final factor of ")#mi("\\frac{N^{1/2}}{H} ( H N )^{1/2} \\ll N d_1^{1/2}")#text(" using the trivial bound, and this is acceptable. For the non-diagonal terms ")#mi("h \\neq h^{\\prime}")#text(" we use the induction hypothesis to bound this by")

#mi("\\lessapprox \\sum_{1 \\leq h,h^{\\prime} \\leq H: h \\neq h^{\\prime}} (\\sum_{i=1}^{k-2} N^{1-1/2^i} d_{i+1}^{1/2^i} + N^{1-1/2^{k-2}} d_k^{1/2^{k-1}}")

#mi("+ 1_{N \\geq \\tilde d^{\\prime}} N / (\\tilde d^{\\prime})^{1/2})")

#text("where")

#mi("\\tilde d^{\\prime} := d_2 \\ldots d_k / ( (f^{\\prime}_{hd_1} - f^{\\prime}_{h^{\\prime}d_1})/d_1, d_2 \\ldots d_k  )")#text(".")

#text("All the terms except for the last term")

#mi("\\sum_{1 \\leq h,h^{\\prime} \\leq H: h \\neq h^{\\prime}} 1_{N \\geq \\tilde d^{\\prime}} N / (\\tilde d^{\\prime})^{1/2})")#text(" (***)")

#text("give an acceptable contribution. To control this last term we need to understand")

#mi("( (f^{\\prime}_{hd_1} - f^{\\prime}_{h^{\\prime}d_1})/d_1, d_2 \\ldots d_k) = (f^{\\prime}_{hd_1} - f^{\\prime}_{h^{\\prime}d_1}, d_2 \\ldots d_k)")#text(" (****).")

#text("Suppose that a (large) prime p divides ")#mi("f^{\\prime}_{hd_1} - f^{\\prime}_{h^{\\prime}d_1}")#text(". If p does not divide ")#mi("hd_1 - h^{\\prime}d_1")#text(", this implies on translation and telescoping that ")#mi("p")#text(" divides ")#mi("f^{\\prime}_h-f^{\\prime}")#text(" for every ")#mi("h")#text(", which makes ")#mi("f^{\\prime}")#text(" constant and thus zero modulo p. Conversely, if ")#mi("p")#text(" divides ")#mi("f^{\\prime}")#text(" then it certainly divides ")#mi("f^{\\prime}_{hd_1} - f^{\\prime}_{h^{\\prime}d_1}")#text(". We conclude that (****) is equal to ")#mi("(h-h^{\\prime}, d_2 \\ldots d_k)")#text(", and (***) is then equal to")

#mi("\\frac{N}{(d_2 \\ldots d_k)^{1/2}} \\sum_{1 \\leq h,h^{\\prime} \\leq H: h \\neq h^{\\prime}}  (h-h^{\\prime},d_2\\ldots d_k)^{1/2} 1_{(h-h^{\\prime},d_2\\ldots d_k) \\geq \\frac{d_2 \\ldots d_k}{N}}.")

#text("This sums to")

#mi("\\lessapprox H^2 \\frac{N^{3/2}}{d_2 \\ldots d_k}")

#text("which is dominated by the term ")#mi("H^2 N^{1-1/2^{k-2}} d_k^{1/2^{k-1}}")#text(" since ")#mi("N \\leq d_k")#text(". Since that term was already under control, we see that this term is also acceptable. This proves the bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236229")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("By the way, it looks like one can improve these estimates further by taking advantage of more averaging. Indeed, note that to bound a single sum ")#mi("S_f(N,d)")#text(", one only needs to control the Weyl-differenced sums ")#mi("S_{(f_{hd_1}-f_{h^{\\prime}d_1})/d_1}(N,d_2 \\ldots d_k)")#text(" ")#emph[#text("on average")]#text(" in ")#mi("h,h^{\\prime}")#text(" (and furthermore that the absolute values lie ")#emph[#text("outside")]#text(" the ")#mi("h,h^{\\prime}")#text(" summation). This suggests that one should carry the ")#mi("h,h^{\\prime}")#text(" averaging with us in the iteration, and perform Weyl differencing in those parameters as well. This should reduce the influence of the diagonal terms ")#mi("h=h^{\\prime}")#text(" that show up (much as they did in the Type III analysis) and should lead to further improvements. Also when these exponential sums are used in the Type I/II analysis there is a similar averaging (again over parameters named h,h’) which could conceivably also be exploited. This could get a bit messy though, I will probably return to explore this point further once the non-averaged exponential sum estimates above are written up properly (and one also has to figure out the right notion of “double dense divisibility” in order to be able to get good triple factorisations ")#mi("d = d_1 d_2 d_3")#text(", currently our dense divisibility hypothesis only gives us factorisations of the form ")#mi("d = d_1 d_2")#text(", but this is a secondary issue as it only impacts ")#mi("\\delta")#text(" which we now expect to be almost negligible).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236381")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("Minor question: two displays before (4), it doesn’t seem to me like the cases ")#mi("N \\ll q_1")#text(", ")#mi("q_1 < N < q_2")#text(", and ")#mi("q_2 \\gg N")#text(" cover all possibilities. For instance, take ")#mi("q_1=1_{2\\mathbb{Z}}")#text(", ")#mi("N=2\\cdot 1_{2\\mathbb{Z}+1}")#text(", and ")#mi("q_2=q_1+1")#text(". Are you implicitly passing to a subsequence here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236385")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("Yes, one can pass to a subsequence to recover the law of the excluded middle in this sort of “cheap nonstandard analysis” (as I discussed in ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("this previous post")]#text("). Another option is to go the full nonstandard analysis route and install an ultrafilter in the ")#mi("x")#text(" parameter to decide when statements depending on ")#mi("x")#text(" are true or false (personally this is my favorite option, but I understand that many people prefer not to see ultrafilters present when they aren’t strictly necessary to an argument). Or one could turn off the asymptotic notation and have lots of ")#mi("C")#text("‘s and quantifiers instead, but this ends up cluttering the arguments with a lot of distracting technicalities.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounded gaps between primes (Polymath8) – a progress report | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236884")[#strong[#text("Bounded gaps between primes (Polymath8) – a progress report | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("[…] have been obtained by using more refined estimates on incomplete Kloosterman sums (first discussed here); to date we have managed to (provisionally) replace the above constraint […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in doubly densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-237794")[#strong[#text("The distribution of primes in doubly densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2013")])]

#text("[…] Proof: See Proposition 4 of this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-237902")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Some minor corrections and suggestions (sorry if they are slightly obsolete now):")

#text("1. In the endgame of the proof of (11), you remark that ")#mi("d|(f^{\\prime}+h,q)")#text(" implies ")#mi("d|(f^{\\prime\\prime},q)")#text(". This is certainly true, but not necessary for the proof of (11). We use ")#mi("d|h")#text(" here, but not ")#mi("d|(f^{\\prime\\prime},q)")#text(", I think.")

#text("2. Four lines above (19), you remark that ")#mi("\\frac{x^\\epsilon q/N}{d} \\geq \\frac{q}{N d^{\\prime}_1} \\geq 1")#text(". I don’t see this, but we don’t need it either. We can bound the ")#mi("h=0")#text(" term in (14) as in the proof of (11), and then use ")#tao-math("\\sum_{1 \\leq \\left|h\\right| \\leq x^\\epsilon q/N: d|f^{\\prime}+h} 1 \\ll \\frac{x^\\epsilon q/N}{d}", block: false)#text(" as in the same proof.")

#text("3. In the second, fourth, and fifth display below (19), a factor ")#mi("e_{d_1^{\\prime}}( k^{\\prime} n^{\\prime} - k n )")#text(" is missing. This does not affect the subsequent argument.")

#text("4. The Gauss sum equals ")#mi("\\tau(\\chi)\\overline\\chi(a)")#text(" instead of ")#mi("\\tau(\\chi)\\chi(a)")#text(".")

#text("5. In the proof of Lemma 3, ")#mi("t^{\\text{deg}(P)+\\text{deg}(Q)}")#text(" should be ")#mi("t^{\\text{deg}(P)+\\text{deg}(Q)-1}")#text(", ")#mi("t^{\\text{deg}(R)+\\text{deg}(Q)}")#text(" should be ")#mi("t^{\\text{deg}(R)+\\text{deg}(Q)-1}")#text(", and ")#mi("R^{\\prime}(t) Q(t) - P(t) R^{\\prime}(t)")#text(" should be ")#mi("R^{\\prime}(t) Q(t) - R(t) Q^{\\prime}(t)")#text(".")

#text("6. In (5) and in the next display, ")#mi("\\ll")#text(" should be ")#mi("\\lessapprox")#text(".")

#text("7. In the proof of Proposition 4, “")#mi("f")#text(" is well-defined” should be “")#mi("f(n)")#text(" is well-defined”.")

#text("8. In the third display below (15), ")#mi("\\ll")#text(" should be ")#mi("\\lessapprox")#text(".")

#text("9. Six lines above (16), the inequality ")#mi("N^{1/2} d_2^{1/2} < [d_1,d_2]^{1/2}")#text(" should be reversed. In the next line, both inequalities should be reversed.")

#text("10. Below (18), the text \"We may rearrange this as\" should be deleted.")

#text("11. In the fifth display below (19), the condition ")#mi("n^{\\prime}_2-n_2 = n^{\\prime}-n\\ (d^{\\prime}_1)")#text(" should be deleted, since ")#mi("n^{\\prime}_2")#text(" is eliminated at this point. In the next line, the comment \"we may use (15)\" seems irrelevant and should be deleted.")

#text("12. \"by (7) the diagonal contribution\" should be \"by (5) the diagonal contribution\".")

#text("13. In the last two displays, ")#mi("K (d^{\\prime}_1)^{1/2} (c_1,d^{\\prime}_1)^{1/2} N^2 d_2^{-1}")#text(" should be multiplied by ")#mi("q")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-237999")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("Dear Terry, just two small comments regarding these corrections:")

#text("3. For the sake of the reader I would write the fifth display below (19) as")

#mi("X = q\\sum_{1 \\leq k, k^{\\prime} \\leq K} \\sum_{n,n^{\\prime}: n=n^{\\prime}\\ (d_2)} \\psi_N(n) \\overline{\\psi_N(n^{\\prime})} e_{d^{\\prime}_1}((k^{\\prime}-k)n)")

#mi("\\sum_{n_2 \\in {\\bf Z}/d^{\\prime}_1{\\bf Z}}\\displaystyle e_{d^{\\prime}_1}(f(n_2)/d_2 + (k-k^{\\prime})n_2 - f(n_2+n^{\\prime}-n)/d_2 )")#text(".")

#text("5. The last point has not been implemented: ")#mi("R^{\\prime}(t) Q(t) - P(t) R^{\\prime}(t)")#text(" should be ")#mi("R^{\\prime}(t) Q(t) - R(t) Q^{\\prime}(t)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]
