// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/
// Converted to Typst by tao2typ: "2026-10-14T16:35:17.110211+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the permanent of a random Bernoulli matrix", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the permanent of a random Bernoulli matrix")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/")[#text("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://www.math.rutgers.edu/%7Evanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the arXiv our preprint “")#link("http://arxiv.org/abs/0804.2362")[#text("On the permanent of random Bernoulli matrices")]#text("“, submitted to ")#link("http://www.elsevier.com/wps/find/journaldescription.cws_home/622779/description")[#text("Adv. Math.")]#text(" This paper establishes analogues of some recent results on the determinant of random ")#mi("n \\times n")#text(" Bernoulli matrices (matrices in which all entries are either +1 or -1, with equal probability of each), in which the determinant is replaced by the ")#link("http://en.wikipedia.org/wiki/Permanent")[#text("permanent")]#text(".")

#text("More precisely, let M be a random ")#mi("n \\times n")#text(" Bernoulli matrix, with n large. Since every row of this matrix has magnitude ")#mi("n^{1/2}")#text(", it is easy to see (by interpreting the determinant as the signed volume of a parallelopiped) that ")#tao-math("\\left|\\det(M)\\right|", block: false)#text(" is at most ")#mi("n^{n/2}")#text(", with equality being satisfied exactly when M is a ")#link("http://en.wikipedia.org/wiki/Hadamard_matrix")[#text("Hadamard matrix")]#text(". In fact, it is known that the determinant ")#mi("\\det(M)")#text(" has magnitude ")#mi("n^{(1/2 - o(1)) n}")#text(" with probability ")#mi("1-o(1)")#text("; for a more precise result, see my ")#link("http://front.math.ucdavis.edu/math.CO/0411095")[#text("earlier paper with Van")]#text(". (There is in fact believed to be a central limit theorem for ")#tao-math("\\log \\left|\\det(M)\\right|", block: false)#text("; see this ")#link("http://www.ams.org/mathscinet-getitem?mr=1453330")[#text("paper of Girko")]#text(" for details.) These results are based upon the elementary “base times height” formula for the volume of a parallelopiped; the main difficulty is to understand what the distance is from one row of M to a subspace spanned by several other rows of M.")

#text("The permanent ")#mi("\\text{per}(M)")#text(" looks formally very similar to the determinant, but does not have a geometric interpretation as a signed volume of a parallelopiped and so can only be analysed combinatorially; the main difficulty is to understand the cancellation that can arise from the various signs in the matrix. It can be somewhat larger than the determinant; for instance, the maximum value of ")#mi("\\text{per}(M)")#text(" for a Bernoulli matrix M is ")#mi("n! = n^{(1 - o(1)) n}")#text(", attaned when M consists entirely of +1’s. Nevertheless, it is not hard to see that ")#mi("\\text{per}(M)")#text(" has the same mean and standard deviation as ")#mi("\\det(M)")#text(", namely 0 and ")#mi("\\sqrt{n!}")#text(" respectively, which shows that ")#tao-math("\\left|\\text{per}(M)\\right|", block: false)#text(" is at ")#emph[#text("most")]#text(" ")#mi("n^{(1/2-o(1))n}")#text(" with probability 1-o(1). Our main result is to show that one also has that ")#tao-math("\\left|\\text{per}(M)\\right|", block: false)#text(" is at ")#emph[#text("least ")]#mi("n^{(1/2-o(1))n}")#text(" with probability 1-o(1), thus obtaining the analogue of the previously mentioned result for the determinant (though our o(1) bounds are significantly weaker).")

#text("In particular, this shows that the probability that the permanent vanishes completely is o(1) (in fact, we get a bound of ")#mi("O(n^{-c})")#text(" for some absolute constant ")#mi("c > 0")#text("). This result appears to be new (although there is a cute observation of Alon (see e.g. this ")#link("http://www.ams.org/mathscinet-getitem?mr=2162064")[#text("paper of Wanless")]#text(" for a proof) that if ")#mi("n=2^m-1")#text(" is one less than a power of 2, then ")#emph[#text("every")]#text(" Bernoulli matrix has non-zero permanent). In contrast, the probability that the determinant vanishes completely is conjectured to equal ")#mi("(1/2 + o(1))^n")#text(" (which is easily seen to be a lower bound), but the best known upper bound for this probability is ")#mi("(1/\\sqrt{2 }+ o(1))^n")#text(", due to Bourgain, Vu, and Wood.")

#metadata(none) <tao-2275335bba0aaff7d14f>

#text("Roughly speaking, the strategy is to view the permanent of a ")#mi("n \\times n")#text(" Bernoulli matrix recursively as a random signed combination of the permanent of its ")#mi("n-1 \\times n-1")#text(" minors formed from its first n-1 rows, which one can view as the “parents” of the original matrix. The idea is then to take a sort of “genetic” or “evolutionary” viewpoint, and ask how likely the trait of having a large permanent is of being passed from parents to children. The key point is that this trait is “dominant” rather than “recessive”: as long as just one of the parents has a large permanent, it is likely that the child will have large permanent as well (and if many of the parents have large permanent, the child is likely to have an even larger permanent). Our main tool for doing this is a classical inequality of Littlewood-Offord type, due to ")#link("http://www.ams.org/mathscinet-getitem?mr=14608")[#text("Erdős")]#text(".")

#text("However, there is still a non-negligible chance that there is enough cancellation that a child, even one with many parents with large permanent, may end up having unexpectedly small or vanishing permanent. To avoid these failure probabilities adding up to overwhelm the analysis, we have to exploit some independence. For instance, if ")#mi("1 \\leq k < n")#text(", a ")#mi("k \\times k")#text(" minor with large permanent will have ")#mi("n-k")#text(" ")#mi("(k+1) \\times (k+1)")#text(" minors as children. Each child has at least a 1/2 chance of having a permanent as large as that of its parent (if a certain entry of the ")#mi("(k+1)^{th}")#text(" row has a favourable sign). These events are sufficiently independent (in a certain martingale sense) that the probability that none of these children have large permanent is exponentially small – at most ")#mi("(1/2)^{n-k}")#text(". (The main technical tool we use to prove bounds such as this is ")#link("http://en.wikipedia.org/wiki/Azuma%27s_inequality")[#text("Azuma’s inequality")]#text(".)")

#text("Just by using the above observations (and crude probabilistic tools such as the union bound and the first moment method), it is already fairly straightforward to show that there exist many ")#mi("k \\times k")#text(" minors with large permanent (of size about ")#mi("n^{k/2 - o(n)}")#text(") as long as ")#mi("k \\leq (1-\\varepsilon) n")#text(" for some ")#mi("\\varepsilon > 0")#text(". The trickiest part is to manage the last few generations of the evolution, in which we need to get a large number of ")#mi("(n-1) \\times (n-1)")#text(" minors with large permanent (this will imply that the full ")#mi("n \\times n")#text(" matrix has large permanent with high probability, thanks to Erdős’ Littlewood-Offord inequality). The main difficulty is that there is a loss of independence which prevents one from obtaining the exponentially small failure probabilities one enjoyed in previous generations. The main idea to overcome this is to locate several “disjoint lineages” of ")#mi("k \\times k")#text(" minors with large permanent, so that each of which has a fairly independent probability of eventually generating a ")#mi("(n-1) \\times (n-1)")#text(" minor with large permanent. Again, Azuma’s inequality and Erdős’ Littlewood-Offord inequality are our main tools here.")

#text("Because we were trying to optimise the strength of our result (both in getting the lower bound for the magnitude of the permanent, and getting a reasonable bound on the failure probability), the actual arguments get slightly technical at times. I have uploaded here a ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/04/permanent.pdf")[#text("very early draft of our paper")]#text(", in which we prove the weaker result that ")#mi("\\text{per}(M) \\neq 0")#text(" with probability 1-o(1); the argument here is only a few pages long but already captures many of the key ideas. (This draft was mostly written by myself; Van then improved the bounds and results significantly, leading to the version that is on the arXiv.)")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/841a3b79dbf4c44e4671107c4007a57a768dd7d20d8a04797990cb283fe20457-e66a41292cfb1eba4c16ba341e34ec8460fec308ea9218be317207aac2881291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nobody")]], [#link("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/#comment-29080")[#strong[#text("nobody")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("Dear Professor Tao,")

#text("Another fantastic post – the genetic ideas are beautifully imaginative! Are such inheritance methods common in probabalistic combinatorics?")

#text("As for a geometric interpretation of the permanent, we can think of the determinant of a vector space ")#mi("\\mathbb{R}^n")#text(" (which is just a vector bundle over a point) as a section of the top (n-th) exterior power of that vector bundle; equally we can regard the permanent as a section of the n-th symmetric tensor bundle – and given a Young diagram, we can play the same sort of game for any immanant (the notion of which was completely new to me!). Of course, whether this is actually more ‘geometrical’ is a matter of debate but at least it uses the right words :-)")

#text("BTW there is a slight omission in your post – you need to specify a distribution for the 1s and -1s above – in your paper they are i.i.d. with equal probability. Have you investigated other distributions – in particular, allowing more values than 1 and -1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/#comment-29081")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("Dear nobody,")

#text("Thanks for the comments. Our arguments extend to fairly general distributions as long as all the entries are independent, but we did not seek the most general formulation for which our arguments work. There is some literature (cited in the paper) for the case when all entries are non-negative, in which the situation is much better understood (there is substantially less cancellation). For instance, the case of permanents of random 0/1 matrices is more or less equivalent to counting Hamiltonian cycles in a random directed graph, which has been well studied. Once the coefficients are bounded away from zero, there are even some central limit theorems known for the permanent.")

#text("You are right that the permanent does have some sort of geometric interpretation in terms of the top symmetric power, though I am not sure how to exploit it (there is no analogue of the base times height formula in that setting, for instance). Our methods rely purely on cofactor expansions instead, though there may be other properties of the permanent (e.g. symmetry and multilinearity) which could eventually be useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R.A.")]], [#link("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/#comment-29085")[#strong[#text("R.A.")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("Dear Professor Tao,")

#text("speaking about literature, there is a typo in the bibliography, in [10] the author should be Wesolowski or Weso{\\l}owski if you want to use special Polish characters.")

#text("Thanks for a nice post")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/#comment-29087")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("Thanks for the correction! I’ll pass it on to my co-author Van, who has the master copy of this paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nobody")]], [#link("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/#comment-32208")[#strong[#text("nobody")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2008")])]

#text("Dear Prof. Tao,")

#text("do you know good descriptions or formulas for E(det X)^2, if X is a symmetric random Bernoulli (+1,-1) matrix? I have found")#linebreak()#text(" ")#mi("\\mathbf{E}((\\det X)^2)=\\sum\\limits_{(b_1,\\ldots,b_n), \\sum\\limits_{i=1}^n ib_i=n }\\frac{n!}{b_1!\\cdots b_n! 1^{b_1}\\cdots n^{b_n}}\\cdot 2^{b_3+\\ldots+b_n-b_2}\\cdot \\frac{(2b_2)!}{b_2 !}")#text(" which is rather complicated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/#comment-32223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2008")])]

#text("Dear nobody,")

#text("I do not know of a simple closed form for this expression. You might try putting the reduced numerator and denominator of the first few elements of this sequence into the OEIS,")

#link("http://www.research.att.com/~njas/sequences/")[#text("http://www.research.att.com/~njas/sequences/")]

#text("and try your luck (or to add these sequences, if they are not already there).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/#comment-50934")[#strong[#text("Valiant’s Permanent Contributions « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2011")]

#text("[…] Terry Tao and Van Vu have just proved some anti-concentration theorems—see their paper here for the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/16/on-the-permanent-of-a-random-bernoulli-matrix/#comment-512062")[#strong[#text("Konstantin Tikhomrov: The Probability that a Bernoulli Matrix is Singular | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2019")]

#text("[…] Here are related posts on Tao’s blog What’s New. A post on Tao’s Milliman’s lecture on the additive combinatorics and random matrices; On the permamnent of random Bernoulli matrix; […]")
]
