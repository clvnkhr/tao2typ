// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/
// Converted to Typst by tao2typ: "2026-10-14T15:20:30.848308+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "247B, Notes 4: almost everywhere convergence of Fourier series", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("247B, Notes 4: almost everywhere convergence of Fourier series")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 May 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/")[#text("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This set of notes discusses aspects of one of the oldest questions in Fourier analysis, namely the nature of convergence of Fourier series.")

#text("If ")#mi("{f: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" is an absolutely integrable function, its Fourier coefficients ")#mi("{\\hat f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" are defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\hat f(n) := \\int_{{\\bf R}/{\\bf Z}} f(x) e^{-2\\pi i nx}\\ dx.")]]

#text("If ")#mi("{f}")#text(" is smooth, then the Fourier coefficients ")#mi("{\\hat f}")#text(" are absolutely summable, and we have the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("f(x) = \\sum_{n \\in {\\bf Z}} \\hat f(n) e^{2\\pi i nx}")]]

#text("where the series here is uniformly convergent. In particular, if we define the partial summation operators")

#align(center)[#tao-fit-display[#tao-math("S_N f(x) := \\sum_{\\left|n\\right| \\leq N} \\hat f(n) e^{2\\pi i nx}", block: true)]]

#text("then ")#mi("{S_N f}")#text(" converges uniformly to ")#mi("{f}")#text(" when ")#mi("{f}")#text(" is smooth.")

#text("What if ")#mi("{f}")#text(" is not smooth, but merely lies in an ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(" class for some ")#mi("{1 \\leq p \\leq \\infty}")#text("? The Fourier coefficients ")#mi("{\\hat f}")#text(" remain well-defined, as do the partial summation operators ")#mi("{S_N}")#text(". The question of convergence in norm is relatively easy to settle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]

#list(
[#text("(i) If ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(", show that ")#mi("{S_N f}")#text(" converges in ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(" norm to ")#mi("{f}")#text(". (")#emph[#text("Hint:")]#text(" first use the boundedness of the Hilbert transform to show that ")#mi("{S_N}")#text(" is bounded in ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(" uniformly in ")#mi("{N}")#text(".)")],
[#text("(ii) If ")#mi("{p=1}")#text(" or ")#mi("{p=\\infty}")#text(", show that there exists ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(" such that the sequence ")#mi("{S_N f}")#text(" is unbounded in ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(" (so in particular it certainly does not converge in ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(" norm to ")#mi("{f}")#text(". (")#emph[#text("Hint:")]#text(" first show that ")#mi("{S_N}")#text(" is not bounded in ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(" uniformly in ")#mi("{N}")#text(", then apply the uniform boundedness principle in the contrapositive.)")]
)
]

#text("The question of pointwise almost everywhere convergence turned out to be a ")#link("https://en.wikipedia.org/wiki/Convergence_of_Fourier_series")[#text("significantly harder problem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Pointwise almost everywhere convergence)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>

#list(
[#text("(i) (Kolmogorov, 1923) There exists ")#mi("{f \\in L^1({\\bf R}/{\\bf Z})}")#text(" such that ")#mi("{S_N f(x)}")#text(" is unbounded in ")#mi("{N}")#text(" for almost every ")#mi("{x}")#text(".")],
[#text("(ii) (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=199631")[#text("Carleson")]#text(", 1966; conjectured by Lusin, 1913) For every ")#mi("{f \\in L^2({\\bf R}/{\\bf Z})}")#text(", ")#mi("{S_N f(x)}")#text(" converges to ")#mi("{f(x)}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(" for almost every ")#mi("{x}")#text(".")],
[#text("(iii) (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=238019")[#text("Hunt")]#text(", 1967) For every ")#mi("{1 < p \\leq \\infty}")#text(" and ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(", ")#mi("{S_N f(x)}")#text(" converges to ")#mi("{f(x)}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(" for almost every ")#mi("{x}")#text(".")]
)
]

#text("Note from Hölder’s inequality that ")#mi("{L^2({\\bf R}/{\\bf Z})}")#text(" contains ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(" for all ")#mi("{p\\geq 2}")#text(", so Carleson’s theorem covers the ")#mi("{p \\geq 2}")#text(" case of Hunt’s theorem. We remark that the precise threshold near ")#mi("{L^1}")#text(" between Kolmogorov-type divergence results and Carleson-Hunt pointwise convergence results, in the category of Orlicz spaces, is still an active area of research; see ")#link("https://arxiv.org/abs/1408.4783")[#text("this paper of Lie")]#text(" for further discussion.")

#text("Carleson’s theorem in particular was a surprisingly difficult result, lying just out of reach of classical methods (as we shall see later, the result is much easier if we smooth either the function ")#mi("{f}")#text(" or the summation method ")#mi("{S_N}")#text(" by a tiny bit). Nowadays we realise that the reason for this is that Carleson’s theorem essentially contains a ")#emph[#text("frequency modulation symmetry")]#text(" in addition to the more familiar translation symmetry and dilation symmetry. This basically rules out the possibility of attacking Carleson’s theorem with tools such as Calderón-Zygmund theory or Littlewood-Paley theory, which respect the latter two symmetries but not the former. Instead, tools from “time-frequency analysis” that essentially respect all three symmetries should be employed. We will illustrate this by giving a relatively short proof of Carleson’s theorem due to ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1783613")[#text("Lacey and Thiele")]#text(". (There are other proofs of Carleson’s theorem, including Carleson’s original proof, its modification by Hunt, and a later ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=340926")[#text("time-frequency proof by Fefferman")]#text("; see Remark ")#link(<tao-d9298a10d1b0735837dc>)[#text("18")]#text(" below.)")

#metadata(none) <tao-cc16076ab89b8175108f>

#heading(level: 1)[#strong[#text(" — 1. Equivalent forms of almost everywhere convergence of Fourier series — ")]]

#text("A standard technique to prove almost everywhere convergence results is by first establishing a weak-type estimate of an associated maximal function. For instance, the ")#link("https://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(" is usually established with the assistance of the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_maximal_function")[#text("Hardy-Littlewood maximal inequality")]#text("; see for instance ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("this previous blog post")]#text(". A remarkable observation ")#link("http://www.ams.org/mathscinet-getitem?mr=125392")[#text("of Stein")]#text(", known as ")#link("https://terrytao.wordpress.com/2011/05/12/steins-maximal-principle/")[#text("Stein’s maximal principle")]#text(", allows one to reverse this implication in certain cases by exploiting a symmetry of the problem. Here is the principle specialised to the application of pointwise convergence of Fourier series, and also combined with a transference principle ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=583403")[#text("of Kenig and Tomas")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Equivalent forms of almost everywhere convergence)")]#text(" ")#metadata(none) <tao-35c20f9d8dfbd47ae538>#text(" Let ")#mi("{1 \\leq p \\leq 2}")#text(". Then the following statements are equivalent:")

#list(
[#text("(i) For every ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(", one has ")#mi("{\\lim_{N \\rightarrow \\infty} S_N f(x) = f(x)}")#text(" for almost every ")#mi("{x \\in {\\bf R}/{\\bf Z}}")#text(".")],
[#text("(ii) There does not exist ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(" such that ")#tao-math("{\\sup_{N \\geq 0} \\left|S_N f(x)\\right| = +\\infty}", block: false)#text(" for almost every ")#mi("{x \\in {\\bf R}/{\\bf Z}}")#text(".")],
[#text("(iii) One has the maximal inequality")

#metadata(none) <tao-8f3c56908f47fbc950a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\sup_{N \\geq 0} \\left|S_N f\\right| \\right\\|_{L^{p,\\infty}({\\bf R}/{\\bf Z})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}", block: true)]]

#text("for all smooth ")#mi("{f: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(", where the weak ")#mi("{L^{p,\\infty}}")#text(" norm is defined as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F \\right\\|_{L^{p,\\infty}({\\bf R}/{\\bf Z})} := \\sup_{\\lambda > 0} \\lambda \\left|\\{ x \\in {\\bf R}/{\\bf Z}: \\left|F(x)\\right| \\geq \\lambda \\}\\right|^{1/p}", block: true)]]

#text("and ")#tao-math("{\\left|E\\right|}", block: false)#text(" denotes the Lebesgue measure of a set ")#mi("{E}")#text(" (which in this setting is a subset of the unit circle).")],
[#text("(iv) One has the maximal inequality")

#metadata(none) <tao-0bfed882badbcd236047>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| \\sup_{N \\in {\\bf Z}} \\left|P_N f\\right| \\right\\|_{L^{p,\\infty}({\\bf R}/{\\bf Z})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}", block: true)]]

#text("for all smooth ")#mi("{f: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(", where ")#mi("{P_N f}")#text(" denotes the partial Fourier series")

#align(center)[#tao-fit-display[#mitex("P_N f(x) = \\sum_{n \\leq N} \\hat f(n) e^{2\\pi i nx}.")]]],
[#text("(v) One has the maximal inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{N \\in {\\bf R}} \\left|1_{D \\leq N} f\\right| \\right\\|_{L^{p,\\infty}({\\bf R})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R})}", block: true)]]

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", where ")#mi("{1_{D \\leq N}}")#text(" denotes the Fourier multiplier operator")

#align(center)[#tao-fit-display[#mitex("(1_{D \\leq N} f)^\\wedge(\\xi) := 1_{\\xi \\leq N} \\hat f(\\xi).")]]]
)
]

#text("Among other things, this proposition equates the qualitative property (i) of almost everywhere convergence to the quantitative property (iii) of a maximal inequality. This equivalence (first observed by Calderón) is similar in spirit to the uniform boundedness principle (see e.g. Corollary 1 of ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("this previous blog post")]#text("). The restriction ")#mi("{p \\leq 2}")#text(" is needed for just one implication (from (ii) to (iii)) in the arguments below, and arises due to the use of Khintchine’s inequality at one point. The equivalence of (iv) and (v) is part of a more general principle of ")#emph[#text("transference")]#text(" that allows one to pass back and forth between periodic domains such as ")#mi("{{\\bf R}/{\\bf Z}}")#text(" with non-periodic domains such as ")#mi("{{\\bf R}}")#text(" (or, on the Fourier side, between discrete domains ")#mi("{{\\bf Z}}")#text(" and continuous domains ")#mi("{{\\bf R}}")#text(") if the estimates in question enjoy suitable scaling symmetries. We will use the formulation (v), as it enjoys the most symmetries.")

#emph[#text("Proof:")]#text(" We first show that (iii) implies (i). If ")#link(<tao-8f3c56908f47fbc950a7>)[#text("(1)")]#text(" holds for all smooth ")#mi("{f}")#text(", then certainly for all finite ")#mi("{N_0}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{0 \\leq N \\leq N_0} \\left|S_N f\\right| \\right\\|_{L^{p,\\infty}({\\bf R}/{\\bf Z})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}", block: true)]]

#text("for all smooth ")#mi("{f}")#text(", and hence for all ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(" by a standard limiting argument. Taking limits as ")#mi("{N_0 \\rightarrow \\infty}")#text(" (using variants of Fatou’s lemma) we conclude that ")#link(<tao-8f3c56908f47fbc950a7>)[#text("(1)")]#text(" holds for all ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(". This implies in particular from the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\limsup_{N \\rightarrow \\infty} \\left|S_N f-f\\right| \\right\\|_{L^{p,\\infty}({\\bf R}/{\\bf Z})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}", block: true)]]

#text("for all ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(". On the other hand, the left-hand side vanishes whenever ")#mi("{f}")#text(" is smooth, since Fourier series converge uniformly in this case. Since smooth functions are dense in ")#mi("{L^p({\\bf R}/{\\bf Z})}")#text(", we conclude from standard limiting arguments that the left-hand side in fact vanishes for all ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(", giving the claim (i).")

#text("Clearly (i) implies (ii). Now we assume that (iii) fails and use this to show that (ii) fails as well. From the failure of (iii) and monotone convergence, for any ")#mi("{A>0}")#text(" one can find ")#mi("{f \\in C^\\infty({\\bf R}/{\\bf Z})}")#text(", a measurable subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}/{\\bf Z}}")#text(", a finite ")#mi("{N_0}")#text(", and ")#mi("{\\lambda > 0}")#text(" such that ")#metadata(none) <tao-eafa9770a6a281e2964e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sup_{0 \\leq N \\leq N_0} \\left|S_N f(x)\\right| \\geq \\lambda \\text{ for all } x \\in E", block: true)]]

#text(" ")#text(" and such that")

#metadata(none) <tao-9493c6c8d0e02d959cb8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\lambda \\left|E\\right|^{1/p} > A \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}.", block: true)]]

#text("In particular, ")#mi("{E}")#text(" has positive measure. By homogeneity we may normalise ")#mi("{\\lambda=1}")#text(". At this stage, nothing prevents the measure of ")#mi("{E}")#text(" from being much smaller than ")#mi("{1}")#text("; but we can exploit translation invariance to increase the measure of ")#mi("{E}")#text(" to be comparable to ")#mi("{1}")#text(" as follows. Let ")#mi("{n \\geq 1}")#text(" be the integer part of ")#tao-math("{1/\\left|E\\right|}", block: false)#text(". We claim that there exist translations ")#mi("{E+x_1,\\dots,E+x_n}")#text(" of ")#mi("{E}")#text(" whose union has measure comparable to ")#mi("{1}")#text(":")

#metadata(none) <tao-dec8530634613c5c2d2d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left| \\bigcup_{i=1}^n E + x_i\\right| \\sim 1.", block: true)]]

#text("This is easiest to establish by the ")#link("https://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text(" (which in this context we might call the ")#emph[#text("random translation")]#text(" method). If we select ")#mi("{x_1,\\dots,x_n}")#text(" uniformly and independently at random we see that every point ")#mi("{x \\in {\\bf R}/{\\bf Z}}")#text(" will lie in a given translate ")#mi("{E + x_i}")#text(" (or equivalently, that ")#mi("{x_i}")#text(" lies in ")#mi("{x-E}")#text(") with probability ")#tao-math("{\\left|E\\right|}", block: false)#text(", hence")

#align(center)[#tao-fit-display[#tao-math("{\\mathbf P}( x \\in \\bigcup_{i=1}^n E + x_i ) = 1 - (1 - \\left|E\\right|)^n.", block: true)]]

#text("Integrating in ")#mi("{x}")#text(" and using the Fubini-Tonelli theorem, we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\mathbf E}( \\left|\\bigcup_{i=1}^n E + x_i\\right| ) = 1 - (1 - \\left|E\\right|)^n", block: true)]]

#text("and hence there exists deterministic choices of ")#mi("{x_1,\\dots,x_n}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{i=1}^n E + x_i\\right| \\geq 1 - (1 - \\left|E\\right|)^n.", block: true)]]

#text("By definition of ")#mi("{n}")#text(" the RHS is comparable to ")#mi("{1}")#text(", giving the claim (clearly the left-hand side cannot exceed ")#mi("{1}")#text(").")

#text("Now consider the randomised linear combination")

#align(center)[#tao-fit-display[#mitex("\\tilde f(x) := \\sum_{i=1}^n \\epsilon_i f(x-x_i)")]]

#text("of translates of ")#mi("{f}")#text(", where ")#mi("{\\epsilon_1,\\dots,\\epsilon_n}")#text(" are random Bernoulli signs. From Khintchine’s inequality and the hypothesis ")#mi("{1 \\leq p \\leq 2}")#text(" we have")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} \\left\\| \\tilde f \\right\\|_{L^p({\\bf R}/{\\bf Z})}^p  & \\sim_p \\left\\| (\\sum_{i=1}^n \\left|f(\\cdot-x_i)\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}/{\\bf Z})}^p", block: true)



#tao-math(" & \\leq \\left\\| (\\sum_{i=1}^n \\left|f(\\cdot-x_i)\\right|^p)^{1/p} \\right\\|_{L^p({\\bf R}/{\\bf Z})}^p", block: true)



#tao-math(" & = \\sum_{i=1}^n \\left\\|f(\\cdot-x_i)\\right\\|_{L^p({\\bf R}/{\\bf Z})}^p", block: true)



#tao-math(" & = n \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}^p", block: true)
]

#text("hence by construction of ")#mi("{n}")#text(" and ")#link(<tao-9493c6c8d0e02d959cb8>)[#text("(4)")]

#metadata(none) <tao-688ea5716030930f47d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("{\\bf E} \\left\\| \\tilde f \\right\\|_{L^p({\\bf R}/{\\bf Z})}^p \\lesssim_p A^{-p}.", block: true)]]

#text("Now we study the behaviour of ")#tao-math("{\\sup_{0 \\leq N \\leq N_0} \\left|S_N \\tilde f(x)\\right|}", block: false)#text(" when ")#mi("{x \\in \\bigcup_{i=1}^n E + x_i}")#text(". Since ")#mi("{S_N}")#text(" is a convolution operator, it commutes with translations, and hence ")#metadata(none) <tao-f7e42c5ac1b5be746f95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("S_N \\tilde f(x) = \\sum_{i=1}^n \\epsilon_i S_N f(x-x_i)")]]

#text(" ")#text(" for each ")#mi("{i}")#text(". On the other hand, from ")#link(<tao-eafa9770a6a281e2964e>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq i \\leq n; 0 \\leq N \\leq N_0} \\left|S_N f(x-x_i)\\right| \\geq 1", block: true)]]

#text("and hence there exists ")#mi("{0 \\leq N_x \\leq N_0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq i \\leq n} \\left|S_{N_x} f(x-x_i)\\right| \\geq 1.", block: true)]]

#text("In particular, the square function")

#align(center)[#tao-fit-display[#tao-math("Q_x := (\\sum_{i=1}^n \\left|S_{N_x} f(x-x_i)\\right|^2)^{1/2}", block: true)]]

#text("is at least ")#mi("{1}")#text(". Meanwhile, from Khintchine’s inequality and ")#link(<tao-f7e42c5ac1b5be746f95>)[#text("(7)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("({\\bf E} \\left|S_{N_x} \\tilde f(x)\\right|^q)^{1/q} \\sim_q Q_x", block: true)]]

#text("for all ")#mi("{0 < q < \\infty}")#text(". Applying ")#link("https://en.wikipedia.org/wiki/Paley%E2%80%93Zygmund_inequality")[#text("the Paley-Zygmund inequality")]#text(" (setting ")#mi("{q=1,2}")#text(", for instance) we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{N_x} \\tilde f(x)\\right| \\gtrsim Q_x ) \\gtrsim 1", block: true)]]

#text("(for suitable choices of implied constants), so in particular")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\sup_{0 \\leq N \\leq N_0} \\left|S_N \\tilde f(x)\\right| \\gtrsim 1 ) \\gtrsim 1", block: true)]]

#text("Integrating in ")#mi("{x}")#text(" using ")#link(<tao-dec8530634613c5c2d2d>)[#text("(5)")]#text(", and applying the Fubini-Tonelli theorem, we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\{ \\sup_{0 \\leq N \\leq N_0} \\left|S_N \\tilde f(x)\\right| \\gtrsim 1 \\}\\right| \\gtrsim 1", block: true)]]

#text("hence by ")#link(<tao-688ea5716030930f47d2>)[#text("(6)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\{ \\sup_{0 \\leq N \\leq N_0} \\left|S_N \\tilde f(x)\\right| \\gtrsim 1 \\}\\right| \\gtrsim_p 1 + A^p {\\bf E} \\left\\| \\tilde f \\right\\|_{L^p({\\bf R}/{\\bf Z})}^p.", block: true)]]

#text("In particular, there exists a deterministic choice of signs ")#mi("{\\epsilon_i}")#text(" (and hence of ")#mi("{\\tilde f}")#text(") for which")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ \\sup_{0 \\leq N \\leq N_0} \\left|S_N \\tilde f(x)\\right| \\gtrsim 1 \\}\\right| \\gtrsim_p 1 + A^p \\left\\| \\tilde f \\right\\|_{L^p({\\bf R}/{\\bf Z})}^p.", block: true)]]

#text("On the other hand, the left-hand side is at most ")#mi("{1}")#text(". We conclude that for every ")#mi("{A>0}")#text(", we can find a smooth function ")#mi("{f_A}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_A \\right\\|_{L^p({\\bf R}/{\\bf Z})} \\lesssim_p \\frac{1}{A}", block: true)]]

#text("and a finite ")#mi("{N_A}")#text(", as well as a set ")#mi("{E_A \\subset {\\bf R}/{\\bf Z}}")#text(" of measure ")#tao-math("{\\left|E_A\\right| \\sim_p 1}", block: false)#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{0 \\leq N \\leq N_A} \\left|S_N f_A(x)\\right| \\gtrsim 1", block: true)]]

#text("for all ")#mi("{x \\in E_A}")#text(".")

#text("Applying this fact iteratively (each time choosing ")#mi("{A}")#text(" to be sufficiently large depending on all previous choices), we can construct a sequence of smooth functions ")#mi("{f^{(m)}: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(", finite ")#mi("{N^{(m)}}")#text(", and sets ")#mi("{E^{(m)}}")#text(" for ")#mi("{m=1,2,\\dots}")#text(" such that")

#list(
[#text("(a) ")#tao-math("{\\left\\|f^{(m)}\\right\\|_{L^p({\\bf R}/{\\bf Z})} \\leq \\frac{1}{2^m}}", block: false)#text(" for all ")#mi("{m \\geq 1}")#text(".")],
[#text("(b) ")#tao-math("{\\left|E^{(m)}\\right| \\gtrsim_p 1}", block: false)#text(" for all ")#mi("{m \\geq 1}")#text(".")],
[#text("(c) One has")

#align(center)[#tao-fit-display[#tao-math("\\sup_{0 \\leq N \\leq N^{(m)}} \\left|S_N f^{(m)}(x)\\right| \\geq m + \\sum_{m^{\\prime} < m} \\sup_{N \\geq 0} \\left\\|S_N f^{(m^{\\prime})}\\right\\|_{L^\\infty({\\bf R}/{\\bf Z})}", block: true)]]

#text("for all ")#mi("{m\\geq 1}")#text(" and ")#mi("{x \\in E^{(m)}}")#text(" (note that the right-hand side is finite since the ")#mi("{f^{(m^{\\prime})}}")#text(" are smooth for ")#mi("{m^{\\prime} < m}")#text(").")],
[#text("(d) ")#tao-math("{\\sup_{0 \\leq N \\leq N^{(m^{\\prime})}} \\left\\|S_N f^{(m)}\\right\\|_{L^\\infty({\\bf R}/{\\bf Z})} \\leq \\frac{1}{2^m}}", block: false)#text(" for all ")#mi("{1 \\leq m^{\\prime} < m}")#text(" (note that the left-hand side is bounded by ")#tao-math("{O_{N^{(m^{\\prime})}}( \\left\\|f^{(m)}\\right\\|_{L^p({\\bf R}/{\\bf Z})} )}", block: false)#text(").")]
)

#text("By randomly translating the ")#mi("{E^{(m)}}")#text(" (and ")#mi("{f^{(m)}}")#text("), and using the Borel-Cantelli lemma, we may assume without loss of generality that almost every ")#mi("{x \\in {\\bf R}/{\\bf Z}}")#text(" lies in infinitely many of the ")#mi("{E^{(m)}}")#text(". If one then sets")

#align(center)[#tao-fit-display[#mitex("f := \\sum_{m=1}^\\infty f^{(m)}")]]

#text("we see that ")#mi("{f \\in L^p({\\bf R}/{\\bf Z})}")#text(", and from the triangle inequality we see that for almost every ")#mi("{x \\in {\\bf R}/{\\bf Z}}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{0 \\leq N \\leq N^{(m)}} \\left|S_N f(x)\\right| \\geq m - \\sum_{\\tilde m > m} \\frac{1}{2^{\\tilde m}}", block: true)]]

#text("for infinitely many ")#mi("{m}")#text(", which implies in particular that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{N \\geq 0} \\left|S_N f(x)\\right| = +\\infty", block: true)]]

#text("for almost all ")#mi("{x}")#text(". This shows that (ii) must fail, as required.")

#text("From the identity ")#metadata(none) <tao-1810aa3327e90c4a916a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("S_N = P_N - P_{-N-1}")]]

#text(" ")#text(" and the triangle inequality we see that (iv) implies (iii). Conversely, suppose that (iii) holds. We will take a limit using frequency modulations. For any smooth ")#mi("{f}")#text(", we apply (iii) to the modulated function ")#mi("{e_{M} f}")#text(", where ")#mi("{M}")#text(" is a natural number and ")#mi("{e_{M}(x) := e^{2\\pi i Mx}}")#text(", to get")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{N \\geq 0} \\left|P_N(e_{M} f) - P_{-N-1}(e_{M} f)\\right| \\right\\|_{L^{p,\\infty}({\\bf R}/{\\bf Z})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}.", block: true)]]

#text("Since ")#mi("{P_N(e_{M} f) = e_{M} P_{N-M} f}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{N \\geq 0} \\left|P_{N-M} f - P_{-N-M-1} f\\right| \\right\\|_{L^{p,\\infty}({\\bf R}/{\\bf Z})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}", block: true)]]

#text("restricting to the range ")#mi("{M-N_0 \\leq N \\leq M+N_0}")#text(" for some given natural number ")#mi("{N_0}")#text(", we conclude for ")#mi("{M > N_0}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{-N_0 \\leq N \\leq N_0} \\left|P_{N} f - P_{-N-2M-1} f\\right| \\right\\|_{L^{p,\\infty}({\\bf R}/{\\bf Z})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}.", block: true)]]

#text("Since ")#mi("{f}")#text(" is smooth, it has rapidly decreasing Fourier coefficients, which implies that ")#mi("{\\sup_{-N_0 \\leq N \\leq N_0} P_{-N-2M-1} f}")#text(" converges uniformly to zero as ")#mi("{M \\rightarrow \\infty}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{-N_0 \\leq N \\leq N_0} \\left|P_{N} f\\right| \\right\\|_{L^{p,\\infty}({\\bf R}/{\\bf Z})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}", block: true)]]

#text("and then we obtain (iv) by monotone convergence.")

#text("Now we assume (iv) and work to establish (v). The idea here is to use a rescaling argument, viewing ")#mi("{{\\bf R}}")#text(" as the limit as ")#mi("{K \\rightarrow \\infty}")#text(" of the large circle ")#mi("{{\\bf R}/K{\\bf Z}}")#text(" (in physical space) or the fine lattice ")#mi("{K^{-1}{\\bf Z}}")#text(" (in frequency space).")

#text("By limiting arguments we may assume that ")#mi("{f}")#text(" is compactly supported on some interval ")#mi("{[-A,A]}")#text(". Let ")#mi("{K>0}")#text(" be a large scaling parameter, and consider the periodic function ")#mi("{f_K: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("f_K(x \\text{ mod } 1) := \\sum_{n \\in {\\bf Z}} f(K(x-n)).")]]

#text("For ")#mi("{K}")#text(" large enough, this function is smooth and supported on the interval ")#mi("{[-A/K, A/K] \\text{ mod } 1}")#text(", with ")#mi("{L^p}")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_K \\right\\|_{L^p({\\bf R}/{\\bf Z})} = K^{-1/p} \\left\\| f\\right\\|_{L^p({\\bf R})}.", block: true)]]

#text("The Fourier coefficients of ")#mi("{f_K}")#text(" is given as")

#align(center)[#tao-fit-display[#mitex("\\hat{f_K}(n) = K^{-1} \\hat f(K^{-1} n)")]]

#text("so that")

#align(center)[#tao-fit-display[#mitex("P_N f_K(x) = K^{-1} \\sum_{n \\leq N} \\hat f(K^{-1} n) e^{2\\pi i n x}.")]]

#text("Applying (iv), we see that for any ")#mi("{\\lambda > 0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ x \\in [-1/2,1/2]: \\sup_{N \\in {\\bf Z}} K^{-1} \\left|\\sum_{n \\leq N} \\hat f(K^{-1} n) e^{2\\pi i n x}\\right| \\geq \\lambda \\} \\right| \\lesssim_p \\lambda^{-p} K^{-1} \\left\\|f\\right\\|_{L^p({\\bf R})}^p.", block: true)]]

#text("Rescaling ")#mi("{x}")#text(" by ")#mi("{K}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ x \\in [-K/2,K/2]: \\sup_{N \\in {\\bf Z}} K^{-1} \\left|\\sum_{n \\leq N} \\hat f(K^{-1} n) e^{2\\pi i K^{-1} n x}\\right| \\geq \\lambda \\} \\right| \\lesssim_p \\lambda^{-p} \\left\\|f\\right\\|_{L^p({\\bf R})}^p.", block: true)]]

#text("We can let ")#mi("{N}")#text(" range over the reals rather than the integers as this does not affect the constraint ")#mi("{n \\leq N}")#text(". Rescaling ")#mi("{N}")#text(" by ")#mi("{K}")#text(", we see that for any compact intervals ")#mi("{I,J}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ x \\in I: \\sup_{N \\in J} K^{-1} \\left|\\sum_{\\xi \\in K^{-1} {\\bf Z}: \\xi \\leq N} \\hat f(\\xi) e^{2\\pi i \\xi x}\\right| \\geq \\lambda \\} \\right| \\lesssim_p \\lambda^{-p} \\left\\|f\\right\\|_{L^p({\\bf R})}^p.", block: true)]]

#text("By uniform Riemann integrability and the rapid decrease of ")#mi("{\\hat f}")

#align(center)[#tao-fit-display[#mitex("\\lim_{K \\rightarrow \\infty} K^{-1} \\sum_{\\xi \\in K^{-1} {\\bf Z}: \\xi \\leq N} \\hat f(\\xi) e^{2\\pi i \\xi x} = \\int_{-\\infty}^N \\hat f(\\xi) e^{2\\pi i \\xi x}\\ d\\xi = 1_{D \\leq N} f(x)")]]

#text("uniformly for ")#mi("{x \\in I}")#text(", ")#mi("{N \\in J}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ x \\in I: \\sup_{N \\in J} \\left|1_{D \\leq N} f(x)\\right| > \\lambda \\} \\right| \\lesssim_p \\lambda^{-p} \\left\\|f\\right\\|_{L^p({\\bf R})}^p.", block: true)]]

#text("By monotone convergence we may replace ")#mi("{I,J}")#text(" with ")#mi("{{\\bf R}}")#text(", and we then obtain (v).")

#text("Finally, we assume (v) and establish (iv). By a limiting argument it suffices to establish (iv) for trigonometric polynomials ")#mi("{f}")#text(", that is to say periodic functions whose Fourier coefficients are supported in ")#mi("{\\{-A,\\dots,A\\}}")#text(" for some natural number ")#mi("{A}")#text(". Let ")#mi("{\\eta \\in {\\mathcal S}({\\bf R})}")#text(" be a non-zero Schwartz function with ")#mi("{\\hat \\eta}")#text(" supported in ")#mi("{[-1,1]}")#text(", and for a given scaling parameter ")#mi("{R>0}")#text(" let ")#mi("{f_R: {\\bf R} \\rightarrow {\\bf C}}")#text(" denote the Schwartz function")

#align(center)[#tao-fit-display[#mitex("f_R(x) := f(x \\text{ mod } 1) \\eta(x/R).")]]

#text("For ")#mi("{R}")#text(" sufficiently large one easily checks that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_R\\right\\|_{L^p({\\bf R})} \\sim_{p,\\eta} R^{1/p} \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}.", block: true)]]

#text("The Fourier transform of ")#mi("{f_R}")#text(" can be calculated as")

#align(center)[#tao-fit-display[#mitex("\\hat f_R(\\xi) = R \\sum_{n=-A}^A \\hat f(n) \\hat \\eta( R(\\xi-n) )")]]

#text("hence (for ")#mi("{R}")#text(" large enough)")

#tao-aligned(keep: true)[


#tao-math("1_{D \\leq N+1/2}(D) f_R(x)  & = \\sum_{n \\leq N} \\hat f(n) \\eta(x/R) e^{2\\pi i nx}", block: true)



#tao-math(" & = \\eta(x/R) P_N f( x \\text{ mod } 1)", block: true)
]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\eta(x/R) \\sup_{N \\in {\\bf Z}} \\left|P_N f( x \\text{ mod } 1)\\right| \\leq \\sup_{N^{\\prime} \\in {\\bf R}} \\left|1_{D \\leq N^{\\prime}}(D) f_R(x)\\right|.", block: true)]]

#text("From (v) we conclude that for any ")#mi("{\\lambda}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ x \\in {\\bf R}: \\eta(x/R) \\sup_{N \\in {\\bf Z}} \\left|P_N f( x \\text{ mod } 1)\\right| \\geq \\lambda \\} \\right| \\lesssim_{p,\\eta} \\lambda^{-p} R \\left\\|f\\right\\|_{L^p({\\bf R}/{\\bf Z})}^p.", block: true)]]

#text("For ")#mi("{R}")#text(" large enough, the left-hand side is")

#align(center)[#tao-fit-display[#tao-math("\\gtrsim_\\eta R \\left|\\{ x \\in {\\bf R}/{\\bf Z}: \\sup_{N \\in {\\bf Z}} \\left|P_N f( x )\\right| \\geq c_\\eta \\lambda \\} \\right|", block: true)]]

#text("for some ")#mi("{c_\\eta>0}")#text(" depending on ")#mi("{\\eta}")#text(". Dividing by ")#mi("{R}")#text(" and replacing ")#mi("{\\lambda}")#text(" by ")#mi("{\\lambda/c_\\eta}")#text(", we obtain the claim (iv). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" For ")#mi("{N \\geq 1}")#text(", let ")#mi("{F_N}")#text(" denote the Fejér summation operators")

#align(center)[#tao-fit-display[#mitex("F_N := \\frac{1}{N+1} \\sum_{N^{\\prime}=0}^N S_{N^{\\prime}}.")]]

#list(
[#text("(i) For any ")#mi("{f \\in L^1({\\bf R}/{\\bf Z})}")#text(", establish the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\sup_{N \\geq 1} \\left|F_N f(x)\\right| \\lesssim Mf(x)", block: true)]]

#text("where ")#mi("{M}")#text(" is the Hardy-Littlewood maximal function")

#align(center)[#tao-fit-display[#mitex("Mf(x \\text{ mod } 1) := \\sup_{r>0} \\frac{1}{2r} \\int_{x-r}^{x+r} |f(y \\text{ mod } 1)|\\ dy.")]]],
[#text("(ii) Show that for ")#mi("{f \\in L^1({\\bf R}/{\\bf Z})}")#text(", one has ")#mi("{\\lim_{N \\rightarrow \\infty} F_N f(x) = f(x)}")#text(" for almost all ")#mi("{x \\in {\\bf R}/{\\bf Z}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Pointwise convergence of Fourier integrals)")]#text(" Let ")#mi("{1 < p < \\infty}")#text(" be such that the conclusion of Theorem ")#link(<tao-35c20f9d8dfbd47ae538>)[#text("3")]#text("(v) holds. Show that for any ")#mi("{f \\in L^p({\\bf R})}")#text(", one has ")#tao-math("{\\lim_{N \\rightarrow \\infty} 1_{\\left|D\\right| \\leq N} f(x) = f(x)}", block: false)#text(" for almost all ")#mi("{x \\in {\\bf R}}")#text(", where ")#tao-math("{1_{\\left|D\\right| \\leq N} f}", block: false)#text(" is defined for Schwartz functions ")#mi("{f}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("1_{\\left|D\\right| \\leq N} f(x) := \\int_{-N}^N \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi", block: true)]]

#text("and then extended to ")#mi("{f \\in L^p({\\bf R})}")#text(" by density.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Let ")#mi("{d \\geq 2}")#text(". Suppose that ")#mi("{1 \\leq p \\leq 2}")#text(" is such that one has the restriction estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^1(S^{d-1}, d\\sigma)} \\lesssim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all Schwartz functions ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(", where ")#mi("{d\\sigma}")#text(" denotes the surface measure on the sphere ")#mi("{S^{d-1}}")#text(". Conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f \\right\\|_{L^{p,\\infty}(S^{d-1},d\\sigma)} \\lesssim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all Schwartz functions ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(". (This observation is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1097257")[#text("due to Bourgain")]#text(".) In particular, by Marcinkiewicz interpolation, ")#mi("{R_{S^{d-1}}(p \\rightarrow 1)}")#text(" implies ")#mi("{R_{S^{d-1}}(p \\rightarrow q)}")#text(" for all ")#mi("{1 \\leq q < p}")#text(". (")#emph[#text("Hint:")]#text(" adapt some parts of the argument used to get from (iii) to (i) in Proposition ")#link(<tao-35c20f9d8dfbd47ae538>)[#text("3")]#text(", using rotation invariance as a substitute for translation invariance. (But the translational symmetry of the restriction problem – more precisely, the ability to translate a function ")#mi("{f}")#text(" in physical space without changing the absolute value of its Fourier transform – will also be useful.))")
]

#text("We are now ready to establish Kolmogorov’s theorem (Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("2")]#text("(i)); our arguments are loosely based on the original construction of Kolmogorov (though he was not in possession at the time of the Stein maximal principle). In view of the equivalence between (ii) and (v) in Theorem ")#link(<tao-35c20f9d8dfbd47ae538>)[#text("3")]#text(", it suffices to show that the maximal operator")

#align(center)[#tao-fit-display[#tao-math("f\\mapsto \\sup_{N \\in {\\bf R}} \\left|1_{D \\leq N} f\\right|", block: true)]]

#text("fails to be of weak-type ")#mi("{(1,1)}")#text(" on Schwartz functions. Recalling that the Hilbert transform")

#align(center)[#tao-fit-display[#mitex("Hf(x) := p.v. \\int_{\\bf R} \\frac{f(y)}{x-y}\\ dy")]]

#text("is also a Fourier multiplier operator")

#align(center)[#tao-fit-display[#mitex("H = -\\pi i \\mathrm{sgn}(D)")]]

#text("some routine calculations then show that")

#align(center)[#tao-fit-display[#mitex("1_{D \\leq N} f(x) = \\frac{1}{2} f(x) + \\frac{1}{2\\pi i} p.v. \\int_{\\bf R} \\frac{f(y)}{x-y} e^{2\\pi i N(x-y)}\\ dy")]]

#text("for any Schwartz function ")#mi("{f}")#text(". By the triangle inequality, it then suffices to show that the maximal operator")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal C} f(x) := \\sup_{N \\in {\\bf R}} \\left|p.v. \\int_{\\bf R} \\frac{f(y)}{x-y} e^{2\\pi i N(x-y)}\\ dy\\right|", block: true)]]

#text("fails to be of weak type ")#mi("{(1,1)}")#text(" on Schwartz functions.")

#text("To motivate the construction, note from a naive application of the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal C} f(x) \\leq \\int_{\\bf R} \\frac{\\left|f(y)\\right|}{\\left|x-y\\right|}\\ dy.", block: true)]]

#text("If the function ")#tao-math("{x \\mapsto \\frac{1}{\\left|x\\right|}}", block: false)#text(" was absolutely integrable, then by Young’s inequality we would conclude that the maximal operator ")#mi("{{\\mathcal C}}")#text(" was strong type ")#mi("{(1,1)}")#text(", and hence also weak type ")#mi("{(1,1)}")#text(". Thus any counterexample must somehow exploit the logarithmic divergence of the integral of ")#tao-math("{\\frac{1}{\\left|x\\right|}}", block: false)#text(". However, there are two potential sources of cancellation that could ameliorate this divergence: the sign ")#mi("{\\mathrm{sgn}(x-y)}")#text(" of the Hilbert kernel ")#mi("{\\frac{1}{x-y}}")#text(", and the phase ")#mi("{e^{2\\pi i N(x-y)}}")#text(". But because of the supremum in ")#mi("{N}")#text(", we can select the frequency parameter ")#mi("{N}")#text(" as we please, as long as it depends only on ")#mi("{x}")#text(" and not on ")#mi("{y}")#text(". The idea is then to choose ")#mi("{N}")#text(" (and the support of ")#mi("{f}")#text(") to remove both sources of cancellation as much as possible.")

#text("We turn to the details. Let ")#mi("{n}")#text(" be a large natural number, and then select ")#mi("{n}")#text(" widely separated frequency scales")

#align(center)[#tao-fit-display[#mitex("1 < N_1 < \\dots < N_n.")]]

#text("In order to assist with removing cancellation in the phases ")#mi("{e^{2\\pi i N(x-y)}}")#text(" later, we will require these scales ")#mi("{N_1,\\dots,N_n}")#text(" to be integers. The precise choice of scales is not too important as long as they are widely separated and integer valued, but for sake of concreteness one could for instance set ")#mi("{N_j := 100^{j}}")#text(". Let ")#mi("{\\varphi \\in C^\\infty_c({\\bf R})}")#text(" be a bump function of total mass ")#mi("{1}")#text(" supported on ")#mi("{[-1,1]}")#text(", and let ")#mi("{f}")#text(" be the Schwartz function")

#metadata(none) <tao-52c5db335401f9c37b11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("f(x) := \\sum_{j=1}^n N_j \\varphi( N_j(x-j) ),")]]

#text("thus ")#mi("{f}")#text(" is an approximation (in a weak sense) to the sum of Dirac masses ")#mi("{\\sum_{j=1}^n \\delta_j}")#text(", with the frequency scale of the approximation to ")#mi("{\\delta_j}")#text(" increasing rapidly in ")#mi("{j}")#text(". We easily compute the ")#mi("{L^1}")#text(" norm of ")#mi("{f}")#text(":")

#metadata(none) <tao-887539ae032b612757c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\|f\\right\\|_{L^1({\\bf R})} = \\sum_{j=1}^n 1 = n.", block: true)]]

#text("Now we estimate ")#mi("{{\\mathcal C}f(x)}")#text(" for ")#mi("{x}")#text(" in the interval ")#mi("{[j_0+0.1, j_0+0.9]}")#text(" for some natural number ")#mi("{n/3 \\leq j_0 \\leq 2n/3}")#text("; note the set of all such ")#mi("{x}")#text(" has measure ")#mi("{\\sim n}")#text(". In this range we will test the maximal operator at the frequency cutoff ")#mi("{N = N_{j_0}}")#text(":")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal C} f(x) \\geq \\left|p.v. \\int_{\\bf R} \\frac{f(y)}{x-y} e^{2\\pi i N_{j_0}(x-y)}\\ dy\\right|.", block: true)]]

#text("As ")#mi("{f}")#text(" is supported in ")#mi("{\\bigcup_{j=1}^n [j-N_j^{-1}, j+N_j^{-1}]}")#text(", we see (for ")#mi("{n}")#text(" large enough) that ")#mi("{x}")#text(" avoids the support of ")#mi("{f}")#text(" and we can replace the principal value integral with the ordinary integral. Substituting ")#link(<tao-52c5db335401f9c37b11>)[#text("(9)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal C} f(x) \\geq \\left|\\sum_{j=1}^n \\int_{{\\bf R}} \\frac{\\varphi(t)}{x-j-N_j^{-1} t} e^{2\\pi i N_{j_0}(x-j-N_j^{-1} t)}\\ dt\\right|.", block: true)]]

#text("As ")#mi("{N_{j_0}}")#text(" is an integer, the phase ")#mi("{e^{-2\\pi i N_{j_0} j}}")#text(" is equal to ")#mi("{1}")#text(". We also cancel out the phase ")#mi("{e^{2\\pi i N_{j_0} x}}")#text(" as being independent of ")#mi("{j}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal C} f(x) \\geq \\left|\\sum_{j=1}^n \\int_{{\\bf R}} \\frac{\\varphi(t)}{x-j-N_j^{-1} t} e^{2\\pi i \\frac{N_{j_0}}{N_j} t}\\ dt\\right|.", block: true)]]

#text("For ")#mi("{j \\leq j_0}")#text(", we exploit the oscillatory nature of the phase ")#mi("{e^{2\\pi i \\frac{N_{j_0}}{N_j} t}}")#text(" through an integration by parts, leading to the bound")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\frac{\\varphi(t)}{x-j-N_j^{-1} t} e^{2\\pi i \\frac{N_{j_0}}{N_j} t}\\ dt \\lesssim_\\varphi \\frac{N_j}{N_{j_0}}")]]

#text("(one could even gain a factor of ")#mi("{\\frac{1}{\\langle j-j_0 \\rangle}}")#text(" here if desired, but we will not need it). Summing, we have")

#metadata(none) <tao-146e6ea2abd81ca17f9c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{j=1}^{j_0} \\int_{\\bf R} \\frac{\\varphi(t)}{x-j-N_j^{-1} t} e^{2\\pi i \\frac{N_{j_0}}{N_j} t}\\ dt \\lesssim_\\varphi 1.")]]

#text("For ")#mi("{j > j_0}")#text(", we instead exploit the near-constant nature of the phase ")#mi("{e^{2\\pi i \\frac{N_{j_0}}{N_j} t}}")#text(" by writing")

#align(center)[#tao-fit-display[#mitex("e^{2\\pi i \\frac{N_{j_0}}{N_j} t} = 1 + O( \\frac{N_{j_0}}{N_j} )")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x-j-N_j^{-1} t} = \\frac{1}{x-j} + O( \\frac{1}{(j-j_0)^2})")]]

#text("to conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\frac{\\varphi(t)}{x-j-N_j^{-1} t} e^{2\\pi i \\frac{N_{j_0}}{N_j} t}\\ dt = \\frac{1}{j-j_0} + O( \\frac{1}{(j-j_0)^2} + \\frac{N_{j_0}}{N_j} ).")]]

#text("Summing and combining with ")#link(<tao-146e6ea2abd81ca17f9c>)[#text("(11)")]#text(", we conclude (from the rapidly increasing nature of the ")#mi("{N_j}")#text(") that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n \\int_{\\bf R} \\frac{\\varphi(t)}{x-j-N_j^{-1} t} e^{2\\pi i \\frac{N_{j_0}}{N_j} t}\\ dt = \\log n + O_\\varphi( 1 ),")]]

#text("and thus (for ")#mi("{n}")#text(" large)")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x: {\\mathcal C} f(x) \\geq \\frac{1}{2} \\log n \\}\\right| \\gtrsim n.", block: true)]]

#text("Comparing this with ")#link(<tao-887539ae032b612757c3>)[#text("(10)")]#text(" we contradict the conclusion of Theorem ")#link(<tao-35c20f9d8dfbd47ae538>)[#text("3")]#text("(iv), giving the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" In 1926, Kolmogorov refined his construction to obtain a function ")#mi("{f \\in L^1({\\bf R}/{\\bf Z})}")#text(" whose Fourier sums ")#mi("{S_N f(x)}")#text(" diverged everywhere (not just almost everywhere).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Rademacher-Menshov theorem)")]#text(" ")#metadata(none) <tao-ea683f93480bef5651ec>

#list(
[#text("(i) Let ")#mi("{f_1,\\dots,f_n \\in L^2(X,\\mu)}")#text(" be some square-integrable functions on a probability space ")#mi("{(X,\\mu)}")#text(", with ")#mi("{n=2^K}")#text(" a power of two. By performing a suitable Whitney type decomposition (similar to that used in Section 3 of ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text("), establish the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\sup_{0 \\leq N < n} \\left|\\sum_{1 \\leq j \\leq N} f_j(x)\\right| \\lesssim \\sum_{0 \\leq k < K} (\\sum_{J: \\left|J\\right|=2^k} \\left|\\sum_{j \\in J} f(x)\\right|^2)^{1/2}", block: true)]]

#text("where for each ")#mi("{k=0,\\dots,K}")#text(", ")#mi("{J}")#text(" ranges over dyadic intervals of the form ")#mi("{J = [j2^k+1, (j+1)2^k)}")#text(" with ")#mi("{0 \\leq j < 2^{K-k}}")#text(". If furthermore the ")#mi("{f_1,\\dots,f_n}")#text(" are orthogonal to each other, establish the maximal inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{0 \\leq N \\leq n} \\left|\\sum_{1 \\leq j \\leq N} f_j\\right| \\right\\|_{L^2(X,\\mu)} \\lesssim (\\log n) (\\sum_{j=1}^n \\left\\|f_j\\right\\|_{L^2(X,\\mu)}^2)^{1/2}.", block: true)]]],
[#text("(ii) If ")#mi("{f \\in L^2({\\bf R}/{\\bf Z})}")#text(" is a trigonometric polynomial with at most ")#mi("{n}")#text(" non-zero coefficients for some ")#mi("{n \\geq 1}")#text(", use part (i) to establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{N \\in {\\bf Z}} \\left|P_N f\\right| \\right\\|_{L^2({\\bf R}/{\\bf Z})} \\lesssim (\\log n) \\left\\|f\\right\\|_{L^2({\\bf R}/{\\bf Z})}.", block: true)]]],
[#text("(iii) If ")#mi("{f \\in L^2({\\bf R}/{\\bf Z})}")#text(" lies in the Sobolev space")

#align(center)[#tao-fit-display[#tao-math("H^s({\\bf R}/{\\bf Z}) := \\{ f \\in L^2({\\bf R}/{\\bf Z}): \\sum_{j \\in {\\bf Z}} \\langle j \\rangle^{2s} \\left|\\hat f(j)\\right|^2 < \\infty \\}", block: true)]]

#text("for some ")#mi("{s>0}")#text(", use (ii) to show that ")#mi("{\\lim_{N \\rightarrow \\infty} S_N f(x) = f(x)}")#text(" for almost every ")#mi("{x \\in {\\bf R}}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 2. Carleson’s theorem — ")]]

#text("We now begin the proof of Carleson’s theorem (Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("2")]#text("(ii)), loosely following the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1783613")[#text("arguments of Lacey and Thiele")]#text(" (we briefly comment on other approaches at the end of these notes). In view of Proposition ")#link(<tao-35c20f9d8dfbd47ae538>)[#text("3")]#text(", it suffices to establish the weak-type ")#mi("{(2,2)}")#text(" bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{N \\in {\\bf R}} \\left|1_{D \\leq N} f\\right| \\right\\|_{L^{2,\\infty}({\\bf R})} \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})}", block: true)]]

#text("for Schwartz functions ")#mi("{f}")#text(". Because of the supremum, the expression ")#tao-math("{\\sup_{N \\in {\\bf R}} \\left|1_{D \\leq N} f\\right|}", block: false)#text(" depends sublinearly on ")#mi("{f}")#text(" rather than linearly; however there is a trick to reduce matters to considering linear estimates. By selecting, for each ")#mi("{x}")#text(", ")#mi("{N(x)}")#text(" to be a frequency which attains (or nearly attains) the supremal value of ")#tao-math("{\\left|1_{D \\leq N(x)} f(x)\\right|}", block: false)#text(", it suffices to establish the linearised estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_{D \\leq N(X)} f \\right\\|_{L^{2,\\infty}({\\bf R})} \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})}", block: true)]]

#text("uniformly for all measurable functions ")#mi("{N: {\\bf R} \\rightarrow {\\bf R}}")#text(", where ")#mi("{1_{D \\leq N(X)}}")#text(" is the operator")

#align(center)[#tao-fit-display[#mitex("1_{D \\leq N(X)} f(x) = \\int_{\\bf R} 1_{\\xi \\leq N(x)} \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi.")]]

#text("One can think of this operator ")#mi("{1_{D \\leq N(X)}}")#text(" as the (Kohn-Nirenberg) quantisation of the rough symbol ")#mi("{(x,\\xi) \\mapsto 1_{\\xi \\leq N(x)}}")#text(". Unfortunately this symbol is far too rough for us to be able to use pseudodifferential operator tools from the ")#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/")[#text("previous set of notes")]#text(". Nevertheless, the “time-frequency analysis” mindset of trying to efficiently decompose phase space into rectangles consistent with the uncertainty principle will remain very useful.")

#text("The next step is to dualise the weak ")#mi("{L^{2,\\infty}}")#text(" norm to linearise the dependence on ")#mi("{f}")#text(" even further:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{1 < p < \\infty}")#text(", let ")#mi("{(X,\\mu)}")#text(" be a ")#mi("{\\sigma}")#text("-finite measure space, let ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be a measurable function, and let ")#mi("{A>0}")#text(". Show that the following claims are equivalent (up to changes in the implied constants in the asymptotic notation):")

#list(
[#text("(i) One has ")#tao-math("{\\left\\| f\\right\\|_{L^{p,\\infty}({\\bf R})} \\lesssim_p A}", block: false)#text(".")],
[#text("(ii) For every subset ")#mi("{E}")#text(" of ")#mi("{X}")#text(" of finite measure, the function ")#mi("{f}")#text(" is absolutely integrable on ")#mi("{E}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\int_E f(x)\\ d\\mu(x) \\lesssim_p A \\mu(E)^{1/p^{\\prime}}.")]]]
)
]

#text("In view of this exercise, we see that it suffices to obtain the bound ")#metadata(none) <tao-b6cf348bc9b1a71d9db0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\int_{\\bf R} 1_E(X) 1_{D \\leq N(X)} f\\ dx \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}", block: true)]]

#text(" ")#text(" for all Schwartz ")#mi("{f}")#text(", all sets ")#mi("{E \\subset {\\bf R}}")#text(" of finite measure, and all measurable functions ")#mi("{N: {\\bf R} \\rightarrow {\\bf R}}")#text(". Actually only the restriction of ")#mi("{N}")#text(" to ")#mi("{E}")#text(" is relevant here, so one can view ")#mi("{N}")#text(" as a function just on ")#mi("{E}")#text(" if desired. The operator ")#mi("{1_E(X) 1_{D \\leq N(X)}}")#text(" can be viewed as the quantisation of the (very rough) symbol ")#mi("{(x,\\xi) \\mapsto 1_E(x) 1_{\\xi \\leq N(x)}}")#text(", that is to say the indicator function of the region lying underneath the graph ")#mi("{\\{ (x,N(x)): x \\in E \\}}")#text(" of ")#mi("{N}")#text(":")

#align(center)[#tao-fit-display[#mitex("1_E(X) 1_{D \\leq N(X)} f(x) = \\int_{\\bf R} 1_E(x) 1_{\\xi \\leq N(x)} \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi.")]]

#text("A notable feature of the estimate ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" is that it enjoys ")#emph[#text("three")]#text(" different symmetries (or near-symmetries), each of which is “non-compact” in the sense that it is parameterised by a parameter taking values in a non-compact space such as ")#mi("{{\\bf R}}")#text(" or ")#mi("{(0,+\\infty)}")#text(":")

#list(
[#text("(i) (Translation symmetry) For any spatial shift ")#mi("{x_0 \\in {\\bf R}}")#text(", both sides of ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" remain unchanged if we replace ")#mi("{f(x)}")#text(" by ")#mi("{\\mathrm{Trans}_{x_0} f(x) := f(x-x_0)}")#text(", the set ")#mi("{E}")#text(" by the translate ")#mi("{E+x_0}")#text(", and the function ")#mi("{N}")#text(" by ")#mi("{x \\mapsto N(x-x_0)}")#text(".")],
[#text("(ii) (Dilation symmetry) For any scaling factor ")#mi("{\\lambda \\in (0,+\\infty)}")#text(", both sides of ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" become multiplied by the same scaling factor ")#mi("{\\lambda^{1/2}}")#text(" if we replace ")#mi("{f}")#text(" by ")#mi("{\\mathrm{Dil}_\\lambda f(x) := \\lambda^{-1/2} f(x/\\lambda)}")#text(", ")#mi("{E}")#text(" by the dilate ")#mi("{\\lambda \\cdot E := \\{ \\lambda x: x \\in E \\}}")#text(", and the function ")#mi("{N}")#text(" by ")#mi("{x \\mapsto \\lambda^{-1} N(x/\\lambda)}")#text(".")],
[#text("(iii) (Modulation symmetry) For any frequency shift ")#mi("{\\xi_0 \\in {\\bf R}}")#text(", both sides of ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" remain (almost) unchanged if we replace ")#mi("{f(x)}")#text(" by ")#mi("{\\mathrm{Mod}_{\\xi_0} f(x) := e^{2\\pi i x \\xi_0} f(x)}")#text(", do not modify the set ")#mi("{E}")#text(", and replace the function ")#mi("{N}")#text(" by ")#mi("{x \\mapsto N(x)+\\xi_0}")#text(". (Technically the left-hand side changes because of an additional factor of ")#mi("{e^{2\\pi i x \\xi_0}}")#text(", but this factor can be handled for instance by generalising the indicator function cutoff ")#mi("{1_E}")#text(" to a subindicator function cutoff ")#mi("{\\chi_E}")#text(" that has the pointwise bound ")#tao-math("{\\left|\\chi_E\\right| \\leq 1_E}", block: false)#text("; we will ignore this very minor issue here.)")]
)

#text("Each of these symmetries corresponds to a different symmetry of phase space ")#mi("{{\\bf R} \\times {\\bf R} = \\{ (x,\\xi): x,\\xi \\in {\\bf R}\\}}")#text(", namely spatial translation ")#mi("{(x,\\xi) \\mapsto (x+x_0,\\xi)}")#text(", dilation ")#mi("{(x,\\xi) \\mapsto (\\lambda x, \\lambda^{-1} \\xi)}")#text(", and frequency translation ")#mi("{(x,\\xi) \\mapsto (x,\\xi+\\xi_0)}")#text(" respectively. As a general rule of thumb, if one wants to prove a delicate estimate such as ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" that is invariant with respect to one or more non-compact symmetries, then one should use tools that are similarly invariant (or approximately invariant) with respect to these symmetries. Thus for instance Littlewood-Paley theory or Calderón-Zygmund theory would not be suitable tools to use here, as they are only invariant with respect to translation and dilation symmetry but absolutely fail to have any modulation symmetry properties (these theories prescribe a privileged role to the frequency origin, or equivalently they isolate functions of mean zero as playing a particularly important role).")

#text("Besides the need to respect the symmetries of the problem, one of the main difficulties in establishing ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" is that the expression ")#mi("{1_{\\xi \\leq N(x)} \\hat f(\\xi)}")#text(", couples together the function ")#mi("{N}")#text(" with the function ")#mi("{f}")#text(" in a rather complicated way (via the frequency variable ")#mi("{\\xi}")#text("). We would like to try to decouple this interaction by making ")#mi("{N}")#text(" and ")#mi("{f}")#text(" instead interact with simpler objects (such as “wave packets”), rather than being coupled directly to each other. To motivate the decomposition to use, we begin with a heuristic discussion. The first main idea is to temporarily work in the (non-invertible) coordinate system ")#mi("{(N(x),\\xi)}")#text(" of phase space rather than ")#mi("{(x,\\xi)}")#text(" in order to simplify the constraint ")#mi("{1_{\\xi \\leq N(x)}}")#text(" to the simple geometric region of a half-plane (this coordinate system is of course a terrible choice for most of the other parts of the argument, but is the right system to use for the frequency decompositions we will now employ). In analogy to the Whitney type decompositions used in ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text(", one can split ")#metadata(none) <tao-4379c213eecddd8b2d89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("1_{\\xi \\leq N(x)} = \\sum_{\\omega_- \\sim \\omega_+} 1_{\\omega_-}(\\xi) 1_{\\omega_+}(N(x))")]]

#text(" ")#text(" for almost all choices of ")#mi("{\\xi}")#text(" and ")#mi("{N(x)}")#text(" (at least if ")#mi("{\\xi, N(x)}")#text(" have the same sign), where ")#mi("{\\omega_-,\\omega_+}")#text(" range over pairs of dyadic intervals that are “close” in the sense that ")#tao-math("{\\left|\\omega_-\\right|=\\left|\\omega_+\\right|}", block: false)#text(" and that ")#mi("{\\omega_-}")#text(" and ")#mi("{\\omega_+}")#text(" are not adjacent, but their parents are adjacent, and with ")#mi("{\\omega_-}")#text(" to the left of ")#mi("{\\omega_+}")#text(". (Here it is convenient to work with half-open dyadic intervals ")#mi("{[j/2^k, (j+1)2^k)}")#text(", to avoid issues with overlap.) If one ignores the caveats and blindly substitutes in the decomposition ")#link(<tao-4379c213eecddd8b2d89>)[#text("(13)")]#text(", the expression in the left of ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\omega_- \\sim \\omega_+} \\int_{\\bf R} 1_E(x) 1_{\\omega_+}(N(x)) 1_{\\omega_-}(D) f(x)\\ dx.")]]

#text("To decouple further, we will try to decompose ")#mi("{1_{\\omega_-}(D)}")#text(" into “rank one” operators. More precisely, we manipulate")

#tao-aligned(keep: true)[


#tao-math("1_{\\omega_-}(D) f(x)  & = 1_{\\omega_-}(D) 1_{\\omega_-}(D)^* f(x)", block: true)



#tao-math(" & = (f * \\widetilde{1^\\vee_{\\omega_-}}) * 1^\\vee_{\\omega-}(x)", block: true)



#tao-math(" & = \\int_{\\bf R} (\\int_{\\bf R} f(z) \\overline{1^\\vee_{\\omega_-}(z-y)}\\ dz) 1^\\vee_{\\omega-}(x-y)\\ dy", block: true)



#tao-math(" & = \\int_{\\bf R} \\langle f, \\mathrm{Trans}_y 1^\\vee_{\\omega_-} \\rangle \\mathrm{Trans}_y 1^\\vee_{\\omega_-}(x)\\ dy", block: true)
]

#text("where we use the notation ")#mi("{\\tilde g(x) := \\overline{g(-x)}}")#text(". It will be convenient to try to discretise this integral average. From the uncertainty principle, modifying ")#mi("{y}")#text(" by ")#tao-math("{O(1/\\left|\\omega_-\\right|)}", block: false)#text(" should only modify ")#mi("{\\mathrm{Trans}_y 1^\\vee_{\\omega_-}(x)}")#text(" approximately by a phase, so the integral here is roughly constant at spatial scales ")#tao-math("{O(1/\\left|\\omega_-\\right|)}", block: false)#text(". So we heuristically have")

#align(center)[#tao-fit-display[#tao-math("1_{\\omega-}(D) f(x) \\approx \\frac{1}{\\left|\\omega_-\\right|} \\sum_{y \\in \\frac{1}{\\left|\\omega_-\\right|} {\\bf Z}}  \\langle f, \\mathrm{Trans}_y 1^\\vee_{\\omega_-} \\rangle \\mathrm{Trans}_y 1^\\vee_{\\omega_-}(x).", block: true)]]

#text("If we now define a ")#emph[#text("tile")]#text(" to be a rectangle ")#mi("{P}")#text(" in phase space of the form")

#align(center)[#tao-fit-display[#mitex("P = I_P \\times \\omega_P")]]

#text("where ")#mi("{\\omega_P, I_P}")#text(" are dyadic intervals and with unit area ")#tao-math("{\\left|P\\right| = \\left|I_P\\right| \\left|\\omega_P\\right| = 1}", block: false)#text(", we see that every ")#mi("{y}")#text(" in the above sum is associated to a tile ")#tao-math("{P_- = [y,y+\\frac{1}{\\left|\\omega_-\\right|}] \\times \\omega_-}", block: false)#text(". The interval ")#mi("{\\omega_+}")#text(" is then similarly assocated to a nearby tile ")#tao-math("{P_+ = [y,y+\\frac{1}{\\left|\\omega_-\\right|}] \\times \\omega_+}", block: false)#text(", and we write ")#mi("{P_- \\sim P_+}")#text(" to indicate the relationship between the two tiles (they share the same spatial interval ")#mi("{I_{P_-} = I_{P_+}}")#text(", but ")#mi("{P_+}")#text(" lies just above ")#mi("{P_-}")#text("). We can then approximately write the left-hand side of ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" as")

#metadata(none) <tao-895f7dcdf72d7dd427df>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{P_- \\sim P_+} \\langle f, \\varphi_{P_-} \\rangle \\langle \\varphi_{P_-} 1_{\\omega_{P_+}}(N), 1_E \\rangle")]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("\\varphi_{P_-}(x) := \\left|I_{P_-}\\right|^{1/2} 1^\\vee_{\\omega_{P_-}}(x - y)", block: true)]]

#text("is an ")#mi("{L^2}")#text("-normalised “wave packet” that is roughly localised to ")#mi("{P_-}")#text(" in phase space. This approximate form of ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" has achieved the goal of decoupling the function ")#mi("{f}")#text(" from the data ")#mi("{E,N}")#text(", as they both now interact with the tile pair ")#mi("{P_-, P_+}")#text(" rather than through each other. Note also that the set of tiles ")#mi("{P}")#text(" obeys an approximate version of the three symmetries that ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" does. Firstly, the set of tiles is invariant under dilations ")#mi("{(x,\\xi) \\mapsto (\\lambda x, \\lambda^{-1} \\xi)}")#text(" if ")#mi("{\\lambda}")#text(" is a power of two; secondly, once one fixes the scales ")#tao-math("{\\left|I_P\\right|, \\left|\\omega_P\\right|}", block: false)#text(" of the tiles, the remaining set of tiles is invariant under spatial translations by integer multiples of the spatial scale ")#tao-math("{\\left|I_P\\right|}", block: false)#text(", and under frequency translations by integer multiples of ")#tao-math("{\\left|\\omega_P\\right|}", block: false)#text(". (We will need the discrete and nested nature of the tiles ")#mi("{P}")#text(" for some subsequent combinatorial arguments, and it turns out to be worthwhile to accept a slightly degraded form of the three basic symmetries of the problem in return for such a discretisation.)")

#text("We now make the above heuristic decomposition rigorous. For any dyadic interval ")#tao-math("{\\omega = [\\inf \\omega, \\inf \\omega + \\left|\\omega\\right|)}", block: false)#text(", let ")#tao-math("{\\omega_- := [\\inf \\omega, \\inf \\omega + \\left|\\omega\\right|/2)}", block: false)#text(" denote the left child interval, and ")#tao-math("{\\omega_+ := [\\inf \\omega + \\left|\\omega\\right|/2, \\inf \\omega + \\left|\\omega\\right|)}", block: false)#text(" the right child interval. We fix a bump function ")#mi("{\\eta}")#text(" supported on ")#mi("{[0.1, 0.2]}")#text(" normalised to have ")#mi("{L^2}")#text(" norm ")#mi("{1}")#text("; henceforth we permit all implied constants in the asymptotic notation to depend on ")#mi("{\\eta}")#text(". For each interval ")#mi("{\\omega}")#text(" let ")#mi("{\\eta_\\omega}")#text(" denote the rescaled function")

#align(center)[#tao-fit-display[#tao-math("\\eta_\\omega(\\xi) := \\eta( \\frac{\\xi - \\inf \\omega}{\\left|\\omega\\right|} ),", block: true)]]

#text("noting that this is a bump function supported on ")#mi("{\\omega_-}")#text(". We will establish the estimate")

#metadata(none) <tao-5537fad5dc5e3efc5e50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\sum_{\\omega} \\left|\\int_{\\bf R} 1_E(X) 1_{\\omega_+}(N(X)) \\left|\\eta_\\omega\\right|^2(D) f\\ dx\\right| \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}", block: true)]]

#text("where ")#mi("{\\omega}")#text(" ranges over all dyadic intervals. We assume ")#link(<tao-5537fad5dc5e3efc5e50>)[#text("(15)")]#text(" for now and see why it implies ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(". The left-hand side of ")#link(<tao-5537fad5dc5e3efc5e50>)[#text("(15)")]#text(" is not quite dilation or frequency modulation invariant, but we can fix this by an averaging argument as follows. Applying the modulation invariance, we see for any ")#mi("{\\xi_0 \\in {\\bf R}}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\omega} \\left|\\int_{\\bf R} 1_E(X) 1_{\\omega_+}(N(X)+\\xi_0) \\left|\\eta_\\omega\\right|^2(D) \\mathrm{Mod}_{\\xi_0} f\\ dx\\right| \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2};", block: true)]]

#text("since")

#align(center)[#tao-fit-display[#tao-math("\\left|\\eta_\\omega\\right|^2(D) \\mathrm{Mod}_{\\xi_0} = \\mathrm{Mod}_{\\xi_0} \\left|\\eta_{\\omega-\\xi_0}\\right|^2(D)", block: true)]]

#text("we thus have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\omega} \\left|\\int_{\\bf R} 1_E(X) 1_{\\omega_+-\\xi_0}(N(X)) \\left|\\eta_{\\omega-\\xi_0}\\right|^2(D) f\\ dx\\right| \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}.", block: true)]]

#text("We temporarily truncate to a finite range of scales, and use the triangle inequality, to obtain")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=-K}^K \\sum_{\\omega: \\left|\\omega\\right| = 2^{-k}} \\int_{\\bf R} 1_E(X) 1_{\\omega_+-\\xi_0}(N(X)) \\left|\\eta_{\\omega-\\xi_0}\\right|^2(D) f\\ dx \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}", block: true)]]

#text("for any finite ")#mi("{K}")#text(". For fixed ")#mi("{k}")#text(", the expression")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\omega: \\left|\\omega\\right| = 2^{-k}} \\int_{\\bf R} 1_E(X) 1_{\\omega_+-\\xi_0}(N(X)) \\left|\\eta_{\\omega-\\xi_0}\\right|^2(D) f\\ dx", block: true)]]

#text("is periodic in ")#mi("{\\xi_0}")#text(" with period ")#mi("{2^{-k}}")#text(", with average equal to")

#align(center)[#tao-fit-display[#tao-math("2^k \\int_{\\bf R} \\int_{\\bf R} 1_E(X) 1_{[\\zeta+2^{-k-1}, \\zeta+2^{-k}]}(N(X)) \\left|\\eta_{[\\zeta, \\zeta+2^{-k}]}\\right|^2(D) f\\ dx\\ d\\zeta", block: true)]]

#text("which we can rewrite as")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\int_{\\bf R} 1_E(x) (2^k \\int_{\\bf R} 1_{[\\zeta+2^{-k-1}, \\zeta+2^{-k}]}(N(x)) \\left|\\eta(2^k(\\xi-\\zeta))\\right|^2\\ d\\zeta) \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi dx", block: true)]]

#text("which one can rewrite further (using the change of variables ")#mi("{\\zeta = N(x) - 2^{-k} t}")#text(") as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} 1_E(x) \\Psi( 2^k (N(x)-\\xi) ) \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi dx")]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("\\Psi(\\xi) := \\int_{1/2}^1 \\left|\\eta( t - \\xi )\\right|^2\\ dt.", block: true)]]

#text("Hence if we average over all ")#mi("{\\xi_0}")#text(" in (say) ")#mi("{[0,2^K]}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=-K}^K \\int_{\\bf R} \\int_{\\bf R} 1_E(x) \\Psi( 2^k (N(x)-\\xi) ) \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi dx \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}", block: true)]]

#text("and hence on sending ")#mi("{K}")#text(" to infinity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k \\in {\\bf Z}} \\int_{\\bf R} \\int_{\\bf R} 1_E(x) \\Psi( 2^k (N(x)-\\xi) ) \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi dx \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}", block: true)]]

#text("Using dilation symmetry, we also see that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k \\in {\\bf Z}} \\int_{\\bf R} \\int_{\\bf R} 1_E(x) \\Psi( \\lambda 2^k (N(x)-\\xi) ) \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi dx \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}", block: true)]]

#text("for any ")#mi("{\\lambda > 0}")#text(". Averaging this for ")#mi("{\\lambda \\in [1,2]}")#text(" with Haar measure ")#mi("{d\\lambda/\\lambda}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\int_{\\bf R} 1_E(x) \\sum_{k \\in {\\bf Z}} \\int_1^2 \\Psi( \\lambda 2^k (N(x)-\\xi) ) \\frac{d\\lambda}{\\lambda} \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi dx \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}.", block: true)]]

#text("But as ")#mi("{\\Psi}")#text(" is a bump function supported in ")#mi("{(0,+\\infty)}")#text(", one has")

#tao-aligned(keep: true)[


#tao-math("\\sum_{k \\in {\\bf Z}} \\int_1^2 \\Psi( \\lambda 2^k (N(x)-\\xi) ) \\frac{d\\lambda}{\\lambda}  & = \\sum_{k \\in {\\bf Z}} \\int_{2^k}^{2^{k+1}} \\Psi( \\lambda (N(x)-\\xi) ) \\frac{d\\lambda}{\\lambda}", block: true)



#tao-math(" & = 1_{\\xi \\leq N(x)} \\int_0^\\infty \\Psi(\\lambda) \\frac{d\\lambda}{\\lambda}.", block: true)
]

#text("The quantity ")#mi("{\\int_0^\\infty \\Psi(\\lambda) \\frac{d\\lambda}{\\lambda}}")#text(" is a non-zero constant, hence")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\int_{\\bf R} 1_E(x) 1_{\\xi \\leq N(x)} \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi dx \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}", block: true)]]

#text("which is ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(".")

#text("It remains to prove ")#link(<tao-5537fad5dc5e3efc5e50>)[#text("(15)")]#text(". As in the heuristic discussion, we approximately decompose the convolution ")#tao-math("{\\left|\\eta_\\omega\\right|^2(D) f}", block: false)#text(" into a sum over tiles. We have")

#tao-aligned(keep: true)[


#tao-math("\\left|\\eta_\\omega\\right|^2(D) f(x)  & = f * \\tilde \\eta_\\omega^\\vee * \\eta_\\omega^\\vee(x)", block: true)



#tao-math(" & = \\int_{\\bf R} (\\int_{\\bf R} f(z) \\overline{\\eta_\\omega^\\vee}(z-y)\\ dz) \\eta_\\omega^\\vee(x-y)\\ dy", block: true)

#metadata(none) <tao-c278ec5a69c34aace427>

#tao-math(" & = \\int_{\\bf R} \\langle f, \\mathrm{Trans}_y \\eta_\\omega^\\vee \\rangle \\mathrm{Trans}_y \\eta_\\omega^\\vee\\ dy.", block: true, numbering: n => [#text("(16)")])
]

#text("Motivated by this, we define as before a ")#emph[#text("tile")]#text(" ")#mi("{P}")#text(" to be a rectangle ")#mi("{I_P \\times \\omega_P}")#text(" with ")#mi("{I_P, \\omega_P}")#text(" dyadic intervals with ")#tao-math("{\\left|I_P\\right| \\left|\\omega_P\\right| = 1}", block: false)#text("; we also split each such tile into an upper half ")#mi("{P_+ := I_P \\times (\\omega_P)_+}")#text(" and a lower half ")#mi("{P_- := I_P \\times (\\omega_P)_-}")#text(". We refer to ")#tao-math("{\\left|I_P\\right|}", block: false)#text(" as the ")#emph[#text("spatial scale")]#text(" of the tile, and the reciprocal ")#tao-math("{\\left|\\omega_P\\right| = \\left|I_P\\right|^{-1}}", block: false)#text(" as the ")#emph[#text("frequency scale")]#text(". For each tile ")#mi("{P}")#text(" define the wave packet")

#align(center)[#tao-fit-display[#tao-math("\\phi_P := \\left|I_P\\right|^{1/2} \\mathrm{Trans}_{\\inf I_P} \\eta_{\\omega_P}^\\vee,", block: true)]]

#text("which is a Schwartz function with Fourier support in ")#mi("{(\\omega_P)_-}")#text(" (in fact it is supported in ")#tao-math("{[\\inf \\omega_P + 0.1 \\left|\\omega_P\\right|, \\inf \\omega_P + 0.2 \\left|\\omega_P\\right|]}", block: false)#text(") that is normalised to have ")#mi("{L^2}")#text(" norm ")#mi("{1}")#text(" and is localised spatially near ")#mi("{I_P}")#text(", so morally it has “phase space support in ")#mi("{P_-}")#text("“. We will later establish the estimate")

#metadata(none) <tao-d35b0f2ea9b55552c988>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\sum_P \\left|\\langle f, \\phi_P \\rangle \\langle \\phi_P 1_{(\\omega_P)_+}(N), 1_E \\rangle\\right| \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}", block: true)]]

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(" and sets ")#mi("{E}")#text(" of finite measure (cf. ")#link(<tao-895f7dcdf72d7dd427df>)[#text("(14)")]#text("), where ")#mi("{P}")#text(" ranges over the set of all tiles. For now, we show why this estimate implies ")#link(<tao-5537fad5dc5e3efc5e50>)[#text("(15)")]#text(" and hence ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(". Just as ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(" was obtained from ")#link(<tao-5537fad5dc5e3efc5e50>)[#text("(15)")]#text(" by averaging over dilation and frequency modulations, we shall recover ")#link(<tao-5537fad5dc5e3efc5e50>)[#text("(15)")]#text(" from ")#link(<tao-d35b0f2ea9b55552c988>)[#text("(17)")]#text(" by averaging over spatial translations. As before, we first temporarily restrict the size range of ")#mi("{\\omega_P}")#text(" and use the triangle inequality to obtain")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=-K}^K \\sum_{\\left|\\omega\\right| = 2^{-k}} \\left|\\sum_{P: \\omega_P = \\omega} \\langle f, \\phi_P \\rangle \\langle \\phi_P 1_{\\omega_+}(N), 1_E \\rangle\\right| \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}.", block: true)]]

#text("Applying translation symmetry, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=-K}^K \\sum_{\\left|\\omega\\right| = 2^{-k}} \\left|\\sum_{P: \\omega_P = \\omega} \\langle \\mathrm{Trans}_{x_0} f, \\phi_P \\rangle \\langle \\phi_P 1_{\\omega_+}(N(\\cdot - x_0)), 1_{E+x_0} \\rangle\\right| \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}", block: true)]]

#text("for any ")#mi("{x_0 \\in {\\bf R}}")#text(". The left-hand side may be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=-K}^K \\sum_{\\left|\\omega\\right| = 2^{-k}} \\left|\\sum_{P: \\omega_P = \\omega} \\langle f, \\phi_{P+(x_0,0)} \\rangle \\langle \\phi_{P+(x_0,0)} 1_{\\omega_+}(N(\\cdot)), 1_{E} \\rangle\\right|", block: true)]]

#text("where we extend the definition of ")#mi("{\\phi_P}")#text(" to translated tiles ")#mi("{P + (x_0,0)}")#text(" in the obvious fashion. The expression inside the absolute values is periodic in ")#mi("{x_0}")#text(" with period ")#mi("{2^k}")#text(", and averages to")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\langle f, \\mathrm{Trans}_y \\eta_\\omega^\\vee \\rangle \\langle \\mathrm{Trans}_y \\eta_\\omega^\\vee 1_{\\omega_+}(N(\\cdot)), 1_{E} \\rangle\\ dy")]]

#text("which by ")#link(<tao-c278ec5a69c34aace427>)[#text("(16)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#tao-math("\\langle \\left|\\eta_\\omega\\right|^2(D) f 1_{\\omega_+}(N(\\cdot)), 1_{E} \\rangle", block: true)]]

#text("and so on averaging in ")#mi("{x_0}")#text(" and then sending ")#mi("{K}")#text(" to infinity we recover ")#link(<tao-5537fad5dc5e3efc5e50>)[#text("(15)")]#text(".")

#text("It remains to establish ")#link(<tao-d35b0f2ea9b55552c988>)[#text("(17)")]#text(". It is convenient to introduce the sets")

#align(center)[#tao-fit-display[#mitex("E_P^+ := \\{ x \\in E: N(x) \\in (\\omega_P)_+ \\}")]]

#text("so that the target estimate ")#link(<tao-d35b0f2ea9b55552c988>)[#text("(17)")]#text(" simplifies slightly to")

#metadata(none) <tao-a282a4bcf207e0379c1d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\sum_{P} \\left|\\langle f, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle\\right| \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}.", block: true)]]

#text("As advertised, we have now decoupled the influences of ")#mi("{f}")#text(" and the influences of ")#mi("{E,N}")#text(" (which determine the sets ")#mi("{E_P^+}")#text("), as these quantities now only directly interact with the wave packets ")#mi("{\\phi_P}")#text(", rather than with each other. Moreover, ")#mi("{f}")#text(" in some sense only interacts with the lower half ")#mi("{P_-}")#text(" of the tile (as this is where ")#mi("{\\phi_P}")#text(" is concentrated), while ")#mi("{E}")#text(" and ")#mi("{N}")#text(" only interact with the upper half ")#mi("{P_+}")#text(" of the tile.")

#text("One advantage of this “model” formulation of the problem is that one can naturally build up to the full problem by trying to establish estimates of the form ")#metadata(none) <tao-d961fcc9d3802a6736eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\sum_{P \\in {\\mathcal P}} \\left|\\langle f, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle\\right| \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}.", block: true)]]

#text(" ")#text(" where ")#mi("{{\\mathcal P}}")#text(" is some smaller set of tiles. For instance, if we can prove ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" for all finite collections ")#mi("{{\\mathcal P}}")#text(" of tiles, then by monotone convergence we recover the required estimate.")

#text("The key problem here is that tiles ")#mi("{P}")#text(" have three degrees of freedom: scale, spatial location, and frequency location, corresponding to the three symmetries of dilation, spatial translation, and frequency modulation of the original estimate ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(12)")]#text(". But one can warm up by looking at families of tiles that only exhibit two or fewer degrees of freedom, in a way that slowly builds up the various techniques we will need to apply to establish the general case:")

#strong[#text("The case of a single tile")]#text(" We begin with the simplest case of a single tile (so that there are zero degrees of freedom): ")#metadata(none) <tao-431721848396eb5d6590>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\langle f, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}.", block: true)]]

#text(" ")#text(" On the one hand, ")#mi("{\\phi_P}")#text(" is normalised in ")#mi("{L^2}")#text(", by Cauchy-Schwarz we have")

#metadata(none) <tao-3b8b91c75627bee566dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\langle f, \\phi_P \\rangle \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})}.", block: true)]]

#text("From the construction of ")#mi("{\\phi_P}")#text(" we see that we have the pointwise bounds")

#metadata(none) <tao-56486663a0524f94b141>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\phi_P(x) \\lesssim \\left|I_P\\right|^{-1/2} \\chi^{100}_{I_P}(x)", block: true)]]

#text("where we use ")#mi("{\\chi_I(x)}")#text(" to denote the following variant of the indicator function ")#mi("{1_I(x)}")#text(" that has a non-trivial tail:")

#align(center)[#tao-fit-display[#tao-math("\\chi_I(x) := \\langle \\frac{\\mathrm{dist}(x,I)}{\\left|I\\right|} \\rangle^{-1}.", block: true)]]

#text("In particular from Hölder’s inequality we have the bounds")

#metadata(none) <tao-169b5b823c62b64ca7e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\langle \\phi_P, 1_{E_P^+} \\rangle \\lesssim \\left\\| \\phi_P \\right\\|_{L^1({\\bf R})} \\lesssim \\left|I_P\\right|^{1/2}", block: true)]]

#text("and also")

#tao-aligned(keep: true)[


#tao-math("\\langle \\phi_P, 1_{E_P^+} \\rangle  & \\lesssim \\left\\| \\phi_P \\right\\|_{L^\\infty({\\bf R})} \\left|E_P^+\\right|", block: true)



#tao-math(" & \\lesssim \\left|I_P\\right|^{-1/2} \\left|E\\right|", block: true)
]

#text("thanks to the trivial bound ")#tao-math("{\\left|E_P^+\\right| \\leq \\left|E\\right|}", block: false)#text(", so on taking geometric means we have")

#align(center)[#tao-fit-display[#tao-math("\\langle \\phi_P, 1_{E_P^+} \\rangle \\lesssim \\left|E\\right|^{1/2}", block: true)]]

#text("and the claim ")#link(<tao-431721848396eb5d6590>)[#text("(20)")]#text(" follows.")

#strong[#text("The case of separated tiles of fixed scale")]#text(" Now we let ")#mi("{{\\mathcal P}}")#text(" be a collection of tiles all of a fixed spatial scale ")#tao-math("{\\left|I_P\\right| = 2^k}", block: false)#text(" (so that ")#tao-math("{\\left|\\omega_P\\right| = 2^{-k}}", block: false)#text(" (so that we have the two parameters of spatial and frequency location, but not the scale parameter). Among other things, this makes the tiles ")#mi("{P}")#text(" in ")#mi("{{\\mathcal P}}")#text(" essentially disjoint (i.e., disjoint ignoring sets of measure zero). This disjointness manifests itself in two useful ways. Firstly, we claim that we can improve the trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\langle \\phi_P, 1_{E_P^+} \\rangle \\lesssim \\left|I_P\\right|^{-1/2} \\left|E\\right|", block: true)]]

#text("obtained previously to the “mass estimate”")

#metadata(none) <tao-f64551fcd6f07823cb87>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\sum_{P \\in {\\mathcal P}} \\left|I_P\\right|^{1/2} \\left|\\langle \\phi_P, 1_{E_P^+} \\rangle\\right| \\lesssim \\left|E\\right|;", block: true)]]

#text("secondly, we claim that we can improve the Cauchy-Schwarz bound ")#link(<tao-3b8b91c75627bee566dc>)[#text("(21)")]#text(" to the “energy estimate”")

#metadata(none) <tao-3946ca64ff78d93ca610>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\sum_{P \\in {\\mathcal P}} \\left|\\langle f, \\phi_P \\rangle\\right|^2 \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})}^2.", block: true)]]

#text("(Here we informally use “mass” to refer to expressions and estimates of ")#mi("{L^1}")#text(" type involving the set ")#mi("{E}")#text(" and graph ")#mi("{N}")#text(", and “energy” to refer to expressions and estimates of ")#mi("{L^2}")#text(" type involving the function ")#mi("{f}")#text(".) If we assume ")#link(<tao-f64551fcd6f07823cb87>)[#text("(24)")]#text(", ")#link(<tao-3946ca64ff78d93ca610>)[#text("(25)")]#text(" for now, then by combining ")#link(<tao-f64551fcd6f07823cb87>)[#text("(24)")]#text(" with ")#link(<tao-169b5b823c62b64ca7e5>)[#text("(23)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in {\\mathcal P}} \\left|\\langle \\phi_P, 1_{E_P^+} \\rangle\\right|^2 \\lesssim \\left|E\\right|,", block: true)]]

#text("and then from ")#link(<tao-3946ca64ff78d93ca610>)[#text("(25)")]#text(" and Cauchy-Schwarz we obtain the required bound ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" in this case.")

#text("Now let us see why ")#link(<tao-f64551fcd6f07823cb87>)[#text("(24)")]#text(" is true. To motivate the argument, suppose that ")#mi("{\\phi_P}")#text(" had no tail outside of ")#mi("{I_P}")#text(", so that one could replace ")#mi("{\\chi_{I_P}^{100}}")#text(" to ")#mi("{1_{I_P}}")#text(" in ")#link(<tao-56486663a0524f94b141>)[#text("(22)")]#text(". Then would have")

#align(center)[#tao-fit-display[#tao-math("\\left|I_P\\right|^{1/2} \\langle \\phi_P, 1_{E_P^+} \\rangle \\lesssim \\left|\\{ x \\in E: (x,N(x)) \\in P_+ \\}\\right|,", block: true)]]

#text("and as the tiles ")#mi("{P_+}")#text(" are all essentially disjoint the claim ")#link(<tao-f64551fcd6f07823cb87>)[#text("(24)")]#text(" would then follow from summing in ")#mi("{P}")#text(", since each ")#mi("{x \\in E}")#text(" contributes to at most one of the sets ")#mi("{\\{ x \\in E: (x,N(x)) \\in P_+ \\}}")#text(". Now we have to deal with the contribution of the tails. We can bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in {\\mathcal P}} \\left|I_P\\right|^{1/2} \\left|\\langle \\phi_P, 1_{E_P^+} \\rangle\\right| \\leq \\int_E \\left|I_P\\right|^{1/2} \\sum_{P \\in {\\mathcal P}: N(x) \\in (\\omega_P)_+} |\\phi_P(x)|\\ dx.", block: true)]]

#text("For each ")#mi("{x \\in E}")#text(", there is at most one dyadic interval ")#mi("{\\omega}")#text(" of the fixed length ")#mi("{2^{-k}}")#text(" such that ")#mi("{N(x) \\in \\omega_+}")#text(". Thus in the above sum ")#mi("{\\omega_P}")#text(" is fixed, and only ")#mi("{I_P}")#text(" can vary; from ")#link(<tao-56486663a0524f94b141>)[#text("(22)")]#text(" we then see that ")#tao-math("{\\left|I_P\\right|^{1/2} \\sum_{P \\in {\\mathcal P}: N(x) \\in (\\omega_P)_+} |\\phi_P(x)|\\ dx \\lesssim 1}", block: false)#text(", giving ")#link(<tao-f64551fcd6f07823cb87>)[#text("(24)")]#text(".")

#text("Now we prove ")#link(<tao-3946ca64ff78d93ca610>)[#text("(25)")]#text(". The intuition here is that the essential disjointness of the tiles ")#mi("{P}")#text(" make the ")#mi("{\\phi_P}")#text(" approximately orthogonal, so that ")#link(<tao-3946ca64ff78d93ca610>)[#text("(25)")]#text(" should be a variant of Bessel’s inequality. We exploit this approximate orthogonality by a ")#mi("{TT^*}")#text(" method, which we perform here explicitly. By duality we have")

#tao-aligned(keep: true)[


#tao-math("(\\sum_{P \\in {\\mathcal P}} \\left|\\langle f, \\phi_P \\rangle\\right|^2)^{1/2}  & = \\sum_{P \\in {\\mathcal P}} \\overline{c_P} \\langle f, \\phi_P \\rangle", block: true)



#tao-math(" & = \\langle f, \\sum_{P \\in {\\mathcal P}} c_P \\phi_P \\rangle", block: true)
]

#text("for some coefficients ")#mi("{c_P}")#text(" with ")#tao-math("{\\sum_{P \\in {\\mathcal P}} \\left|c_P\\right|^2 = 1}", block: false)#text(", so by Cauchy-Schwarz it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{P \\in {\\mathcal P}} c_P \\phi_P \\right\\|_{L^2({\\bf R})}^2 \\lesssim 1.", block: true)]]

#text("The left-hand side expands as")

#metadata(none) <tao-e8d0d04fea35d6890558>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{P, P^{\\prime} \\in {\\mathcal P}} c_P \\overline{c_{P^{\\prime}}} \\langle \\phi_P, \\phi_{P^{\\prime}} \\rangle.")]]

#text("From the Fourier support of ")#mi("{\\phi_P, \\phi_{P^{\\prime}}}")#text(" we see that the inner product ")#mi("{\\langle \\phi_P, \\phi_{P^{\\prime}} \\rangle}")#text(" vanishes unless the intervals ")#mi("{(\\omega_P)_-, (\\omega_{P^{\\prime}})_-}")#text(" overlap which by the equal sizes of ")#mi("{\\omega_P, \\omega_{P^{\\prime}}}")#text(" force ")#mi("{\\omega_P = \\omega_{P^{\\prime}}}")#text(". In this case we can use ")#link(<tao-56486663a0524f94b141>)[#text("(22)")]#text(" to bound the inner product by")

#align(center)[#tao-fit-display[#tao-math("\\langle \\phi_P, \\phi_{P^{\\prime}} \\rangle \\lesssim \\langle \\frac{\\mathrm{dist}(I_P, I_{P^{\\prime}})}{\\left|I_P\\right|} \\rangle^{-100}", block: true)]]

#text("and then a routine application of Schur’s test gives ")#link(<tao-e8d0d04fea35d6890558>)[#text("(26)")]#text(". This establishes ")#link(<tao-3946ca64ff78d93ca610>)[#text("(25)")]#text(", giving ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" in the case of tiles of equal dimensions.")

#strong[#text("The case of a regular ")#mi("{-}")#text("-tree")]

#text("Now we attack some cases where the tiles ")#mi("{P}")#text(" can vary in scale. In phase space, a key geometric difficulty now arises from the fact that tiles may start partially overlapping each other, in contrast to the previous case in which the essential disjointness of the tile set was crucial in establishing the key estimates ")#link(<tao-f64551fcd6f07823cb87>)[#text("(24)")]#text(", ")#link(<tao-3946ca64ff78d93ca610>)[#text("(25)")]#text(". However, because we took care to restrict the intervals ")#mi("{I_P, \\omega_P}")#text(" of the tiles to be dyadic, there are only a limited number of ways in which two tiles can overlap. Given two rectangles ")#mi("{R = I_R \\times \\omega_R}")#text(" and ")#mi("{R^{\\prime} = I_{R^{\\prime}} \\times \\omega_{R^{\\prime}}}")#text(", we define the relation ")#mi("{R \\leq R^{\\prime}}")#text(" if ")#mi("{I_R \\subset I_{R^{\\prime}}}")#text(" and ")#mi("{\\omega_R \\supset \\omega_{R^{\\prime}}}")#text("; this is clearly a partial order on rectangles. The key observation is as follows: if two tiles ")#mi("{P, P^{\\prime}}")#text(" overlap, then either ")#mi("{P \\leq P^{\\prime}}")#text(" or ")#mi("{P \\geq P^{\\prime}}")#text(". Similarly if ")#mi("{P, P^{\\prime}}")#text(" are replaced by their upper tiles ")#mi("{P_+, P^{\\prime}_+}")#text(" or by their lower tiles ")#mi("{P_-, P^{\\prime}_-}")#text(". Note that if ")#mi("{P, P^{\\prime}}")#text(" are tiles with ")#mi("{P \\leq P^{\\prime}}")#text(", then one of ")#mi("{P_+ \\leq P^{\\prime}_+}")#text(" or ")#mi("{P_- \\leq P^{\\prime}_-}")#text(" holds (and the only way both inequalities can hold simultaneously is if ")#mi("{P=P^{\\prime}}")#text(").")

#text("As was first observed by Fefferman, a key configuration of tiles that needs to be understood for these sorts of problems is that of a ")#emph[#text("tree")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10")]#text(" Let ")#mi("{P_T}")#text(" be a tile. A ")#emph[#text("tree with top ")#mi("{P_T}")]#text(" is a collection ")#mi("{T}")#text(" of tiles ")#mi("{P}")#text(" with the property that ")#mi("{P \\leq P_T}")#text(" for all ")#mi("{P \\in T}")#text(". (For minor technical reasons it is convenient to not require the top ")#mi("{P_T}")#text(" to actually lie in the tree ")#mi("{T}")#text(", though this is often the case.) We write ")#mi("{I_T = I_{P_T}}")#text(" for the spatial support of the tree, and ")#mi("{\\omega_T = \\omega_{P_T}}")#text(" for the frequency support of the tree top. If we in fact have ")#mi("{P_+ \\leq (P_T)_+}")#text(" for all ")#mi("{P \\in T}")#text(", we say that ")#mi("{T}")#text(" is a ")#mi("{+}")#text("-tree; similarly if ")#mi("{P_- \\leq (P_T)_-}")#text(" for all ")#mi("{P \\in T}")#text(", we say that ")#mi("{T}")#text(" is a ")#mi("{-}")#text("-tree. (Thus every tree can be partitioned into a ")#mi("{+}")#text("-tree and a ")#mi("{-}")#text("-tree with the same top as the original tree.)")
]

#text("The tiles in a tree can vary in scale and in spatial location, but once these two parameters are given, the frequency location is fixed, so a tree can again be viewed as a “two-parameter” subfamily of the three-parameter family of tiles.")

#text("We now prove ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" in the case when ")#mi("{{\\mathcal P}}")#text(" is a ")#mi("{-}")#text("-tree ")#mi("{T}")#text(", thus ")#mi("{P_- \\leq (P_T)_-}")#text(" for all ")#mi("{P \\in T}")#text(". Here, the ")#mi("{\\langle f, \\phi_P \\rangle}")#text(" factors will all “collide” with each other and there will be no orthogonality to exploit here; on the other hand, there will be a lot of “disjointness” in the ")#mi("{E_P^+}")#text(" that can be exploited instead.")

#text("To illustrate the key ideas (and to help motivate the arguments for the general case) we will also make the following “regularity” hypotheses: there exists two quantities ")#mi("{\\varepsilon, \\mu > 0}")#text(" (which we will refer to as the ")#emph[#text("energy")]#text(" and ")#emph[#text("mass")]#text(" of the tree respectively) for which we have the upper bounds ")#metadata(none) <tao-30fae0c325abaf0d2461>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("\\left|I_P\\right|^{-1/2} \\langle f, \\phi_P \\rangle \\lesssim \\varepsilon", block: true)]]

#text(" ")#text(" and")

#metadata(none) <tao-b6ff3b277328011539a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\left|I_P\\right|^{-1} \\int_{\\bf R} 1_{E}(x) \\chi^{10}_{I_P}(x)\\ dx \\lesssim \\mu", block: true)]]

#text("for all ")#mi("{P \\in T}")#text("; informally, these estimates assert that ")#mi("{f}")#text(" is size ")#mi("{O(\\varepsilon)}")#text(" “on average” on the tiles in the tree, and similarly that ")#mi("{E}")#text(" has density ")#mi("{O(\\mu)}")#text(" on all tiles in the tree. (These are slightly oversimplified versions of the energy and mass concept; we will refine these notions later.) For technical reasons we also need to generalise ")#link(<tao-b6ff3b277328011539a2>)[#text("(28)")]#text(" to")

#metadata(none) <tao-44cdb0488d1296b95644>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\left|I_{P^{\\prime}}\\right|^{-1} \\int_{\\bf R} 1_{E}(x) \\chi^{10}_{I_{P^{\\prime}}}(x)\\ dx \\lesssim \\mu", block: true)]]

#text("for any tile ")#mi("{P^{\\prime}}")#text(" with ")#mi("{P^{\\prime} \\geq P}")#text(" for some ")#mi("{P \\in T}")#text(". (Informally, ")#link(<tao-44cdb0488d1296b95644>)[#text("(29)")]#text(" asserts that a sort of “Hardy-Littlewood maximal function” of ")#mi("{1_E}")#text(" is bounded by ")#mi("{O(\\mu)}")#text(" on the tree.)")

#text("We also assume that we have the reverse bounds for the tree top: ")#metadata(none) <tao-d1e75aca758154ee2147>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#tao-math("\\left|I_{T}\\right|^{-1/2} \\langle f, \\phi_{P_T} \\rangle \\gtrsim \\varepsilon", block: true)]]

#text(" ")#text(" and")

#metadata(none) <tao-78675cc176081372c43a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#tao-math("\\left|I_{T}\\right|^{-1} \\int_{\\bf R} 1_{E}(x) \\chi^{10}_{I_{T}}(x)\\ dx \\gtrsim \\mu.", block: true)]]

#text("It will be through a combination of both these lower and upper bounds that we can obtain a bound ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" that does not involve either ")#mi("{\\varepsilon}")#text(" or ")#mi("{\\mu}")#text(".")

#text("We will use ")#link(<tao-30fae0c325abaf0d2461>)[#text("(27)")]#text(", ")#link(<tao-b6ff3b277328011539a2>)[#text("(28)")]#text(", ")#link(<tao-44cdb0488d1296b95644>)[#text("(29)")]#text(" to establish the ")#emph[#text("tree estimate")]#text(" ")#metadata(none) <tao-dc9c5edb8b2d479e697b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#tao-math("\\sum_{P \\in T} \\left|\\langle f, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle\\right| \\lesssim \\varepsilon \\mu |I_T|.", block: true)]]



#text("Note from ")#link(<tao-d1e75aca758154ee2147>)[#text("(30)")]#text(" and Cauchy-Schwarz that")

#align(center)[#tao-fit-display[#tao-math("\\varepsilon \\lesssim \\left|I_T\\right|^{-1/2} \\left\\|f\\right\\|_{L^2}", block: true)]]

#text("and from ")#link(<tao-78675cc176081372c43a>)[#text("(31)")]#text(" and Cauchy-Schwarz one similarly has")

#align(center)[#tao-fit-display[#tao-math("\\mu \\lesssim \\left|I_T\\right|^{-1/2} \\left|E\\right|^{1/2}", block: true)]]

#text("and so ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(" recovers the desired estimate ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(".")

#text("It remains to establish the tree estimate ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(". It will be convenient to use the tree ")#mi("{T}")#text(" to partition the real line ")#mi("{{\\bf R}}")#text(" into dyadic intervals ")#mi("{J}")#text(" that are naturally “adapted to” the geometry of the tree (or more precisely to the spatial intervals ")#mi("{\\{ I_P: P \\in T\\}}")#text(" of the tree) in a certain way (in a manner reminiscent of a Whitney decomposition).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Whitney-type decomposition associated to a tree)")]#text(" ")#metadata(none) <tao-c9e949c0039a95d182a6>#text(" Let ")#mi("{T}")#text(" be a non-empty tree. Show that there exists a family ")#mi("{{\\mathcal J}}")#text(" of dyadic intervals with the following properties:")

#list(
[#text("(i) The intervals ")#mi("{J}")#text(" in ")#mi("{{\\mathcal J}}")#text(" form a partition of ")#mi("{{\\bf R}}")#text(" (up to sets of measure zero).")],
[#text("(ii) For each ")#mi("{J \\in {\\mathcal J}}")#text(" and any ")#mi("{P \\in T}")#text(" with ")#tao-math("{\\left|I_P\\right| < \\left|J\\right|}", block: false)#text(", we have ")#tao-math("{\\mathrm{dist}(I_P,J) \\gtrsim \\left|J\\right|}", block: false)#text(".")],
[#text("(iii) For each ")#mi("{J \\in {\\mathcal J}}")#text(", there exists ")#mi("{P \\in T}")#text(" with ")#tao-math("{\\left|I_P\\right| \\lesssim \\left|J\\right|}", block: false)#text(" and ")#tao-math("{\\mathrm{dist}(I_P,J) \\lesssim \\left|J\\right|}", block: false)#text(".")]
)

#text("(Hint: one can choose ")#mi("{{\\mathcal J}}")#text(" to be the collection of all dyadic intervals ")#mi("{J}")#text(" whose dilate ")#tao-math("{3J := [\\inf J - \\left|J\\right|, \\inf J + 2\\left|J\\right|)}", block: false)#text(" does not contain any ")#mi("{I_P, P \\in T}")#text(", and which is maximal with respect to set inclusion.)")
]

#text("We can of course assume that the tree ")#mi("{T}")#text(" is non-empty, since ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(" is trivial for empty sets of tiles. We apply the partition from Exercise ")#link(<tao-c9e949c0039a95d182a6>)[#text("11")]#text(". By the triangle inequality, we can bound the left hand side of ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\sum_{J \\in {\\mathcal J}} \\sum_{P \\in T} |\\langle f, \\phi_P \\rangle| \\int_J |\\phi_P| 1_{E_P^+}")]]

#text("which by ")#link(<tao-30fae0c325abaf0d2461>)[#text("(27)")]#text(", ")#link(<tao-56486663a0524f94b141>)[#text("(22)")]#text(" may be bounded by")

#align(center)[#tao-fit-display[#mitex("\\lesssim \\varepsilon \\sum_{J \\in {\\mathcal J}} \\sum_{P \\in T} \\int_J \\chi_{I_P}^{100} 1_{E_P^+}.")]]

#text("We first dispose of the narrow tiles ")#mi("{P}")#text(" in which ")#tao-math("{\\left|I_P\\right| < \\left|J\\right|}", block: false)#text(". By Exercise ")#link(<tao-c9e949c0039a95d182a6>)[#text("11")]#text("(ii) this forces ")#tao-math("{\\mathrm{dist}(I_P, J) \\gtrsim \\left|J\\right|}", block: false)#text(". From ")#link(<tao-b6ff3b277328011539a2>)[#text("(28)")]#text(" we have")

#tao-aligned(keep: true)[


#tao-math("\\int_J \\chi_{I_P}^{100} 1_{E_P^+}  & \\lesssim \\mu |J| (\\left|I_P\\right| / \\mathrm{dist}(I_P,J))^{20}", block: true)



#tao-math(" & \\lesssim \\mu |J| (\\left|I_P\\right|/\\left|J\\right|)^{10} (\\left|I_P\\right| / \\mathrm{dist}(I_P,J))^{10}", block: true)
]

#text("(say). For each fixed spatial scale ")#tao-math("{\\left|I_P\\right| = 2^k \\leq \\left|I_T\\right|}", block: false)#text(", the intervals ")#mi("{I_P}")#text(" in the tree ")#mi("{T}")#text(" are all essentially disjoint, so a routine calculation then shows")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P\\in T: \\left|I_P\\right| = 2^k} (\\left|I_P\\right| / \\mathrm{dist}(I_P,J))^{10} \\lesssim \\left|J\\right|/2^k", block: true)]]

#text("(say), so that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{P \\in T: \\left|I_P\\right| < \\left|J\\right|} \\int_J \\chi_{I_P}^{100} 1_{E_P^+}  & \\lesssim \\mu |J| \\sum_{2^k \\leq \\left|I_T\\right|, c\\left|J\\right|} (2^k/\\left|J\\right|)^{9}", block: true)



#tao-math(" & \\lesssim \\mu |J| \\min( 1, \\left|I_T\\right|/\\left|J\\right| )^{9}", block: true)
]

#text("which from Exercise ")#link(<tao-c9e949c0039a95d182a6>)[#text("11")]#text("(ii) implies that the contribution of the ")#tao-math("{\\left|I_P\\right| < \\left|J\\right|}", block: false)#text(" case to ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(" is acceptable.")

#text("Now we consider the wide tiles in which ")#tao-math("{\\left|I_P\\right| \\geq \\left|J\\right|}", block: false)#text(". From Exercise ")#link(<tao-c9e949c0039a95d182a6>)[#text("11")]#text("(ii) this case is only possible if ")#tao-math("{\\left|J\\right| \\leq \\left|I_T\\right|}", block: false)#text(" and ")#tao-math("{\\mathrm{dist}(J, I_T) \\lesssim \\left|I_T\\right|}", block: false)#text(". Thus the ")#mi("{J}")#text(" are now restricted to an interval of length ")#tao-math("{O(\\left|I_T\\right|)}", block: false)#text(", and it will suffice to establish the local estimate")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in T: \\left|I_P\\right| \\geq \\left|J\\right|} \\int_J \\chi_{I_P}^{100} 1_{E_P^+} \\lesssim \\mu \\left|J\\right|", block: true)]]

#text("for each ")#mi("{J}")#text(". Note that for each fixed spatial scale ")#mi("{2^k}")#text(", there is at most one choice ")#mi("{\\omega_k}")#text(" of frequency interval ")#mi("{\\omega_P}")#text(" with ")#mi("{P \\in T}")#text(" and ")#tao-math("{\\left|\\omega_P\\right| = 2^{-k}}", block: false)#text(", thus for fixed ")#mi("{k}")#text(" the set ")#mi("{E_P^+ = \\{ x \\in {\\bf R}: N(x) \\in \\omega_P^+\\} = \\{ x \\in {\\bf R}: N(x) \\in \\omega_k^+\\}}")#text(" is independent of ")#mi("{P}")#text(". We may then sum in ")#mi("{P}")#text(" for each such scale to conclude")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in T: \\left|I_P\\right| \\geq \\left|J\\right|} \\int_J \\chi_{I_P}^{100} 1_{E_P^+} \\lesssim \\sum_k \\int_J 1_{E_k^+}.", block: true)]]

#text("Now we make the crucial observation that in a ")#mi("{-}")#text("-tree ")#mi("{T}")#text(", the intervals ")#mi("{\\omega_k^+}")#text(" are all essentially disjoint, hence the ")#mi("{E_k^+}")#text(" are disjoint as well. As these sets are also contained in ")#mi("{E}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_k \\int_J 1_{E_k^+} \\lesssim \\int_J 1_E.")]]

#text("From Exercise ")#link(<tao-c9e949c0039a95d182a6>)[#text("11")]#text("(iii) and ")#link(<tao-44cdb0488d1296b95644>)[#text("(29)")]#text(" (choosing a tile ")#mi("{P^{\\prime}}")#text(" with spatial scale ")#tao-math("{\\sim \\left|J\\right|}", block: false)#text(" and within ")#tao-math("{O(\\left|J\\right|)}", block: false)#text(" of ")#mi("{J}")#text(", and with ")#mi("{P^{\\prime} \\geq P}")#text(" for the tile ")#mi("{P}")#text(" provided by Exercise ")#link(<tao-c9e949c0039a95d182a6>)[#text("11")]#text("(iii)) we have")

#align(center)[#tao-fit-display[#tao-math("\\int_J 1_E \\lesssim \\mu \\left|J\\right|", block: true)]]

#text("giving the claim.")

#strong[#text("The case of a regular ")#mi("{+}")#text("-tree")]

#text("We now complement the previous case by establishing ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" for (certain types of) ")#mi("{+}")#text("-trees ")#mi("{T}")#text(". The situation is now reversed: there is a lot of “collision” in the ")#mi("{E_P^+}")#text(", but on the other hand there is now some “orthogonality” in the ")#mi("{\\langle f, \\phi_P \\rangle}")#text(" that can be exploited.")

#text("As before we will assume some regularity on the ")#mi("{+}")#text("-tree ")#mi("{T}")#text(", namely that there exist ")#mi("{\\varepsilon,\\mu>0}")#text(" for which one has the upper bounds ")#metadata(none) <tao-6199aecf23aba7e87b2d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#tao-math("\\left|I_P\\right|^{-1/2} (\\sum_{P^{\\prime} \\in T: P^{\\prime} \\leq P} \\left|\\langle f, \\phi_{P^{\\prime}} \\rangle\\right|^2)^{1/2} \\lesssim \\varepsilon", block: true)]]

#text(" ")#text(" for all ")#mi("{P \\in T}")#text(" (note this is slightly stronger than ")#link(<tao-30fae0c325abaf0d2461>)[#text("(27)")]#text("), as well as the bound ")#link(<tao-44cdb0488d1296b95644>)[#text("(29)")]#text(" for any tile ")#mi("{P^{\\prime}}")#text(" with ")#mi("{P^{\\prime} \\geq P}")#text(" for some ")#mi("{P \\in T}")#text(". We complement this with the matching lower bounds")

#metadata(none) <tao-35b1aa3e15d252b6b21f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#tao-math("\\left|I_{T}\\right|^{-1/2} (\\sum_{P \\in T} \\left|\\langle f, \\phi_{P} \\rangle\\right|^2)^{1/2} \\gtrsim \\varepsilon", block: true)]]

#text("and ")#link(<tao-78675cc176081372c43a>)[#text("(31)")]#text(".")

#text("As before we will focus on establishing the tree estimate ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(". From ")#link(<tao-78675cc176081372c43a>)[#text("(31)")]#text(" and Cauchy-Schwarz as before we have")

#align(center)[#tao-fit-display[#tao-math("\\mu \\lesssim \\left|I_T\\right|^{-1/2} \\left|E\\right|^{1/2}.", block: true)]]

#text("As we now have a ")#mi("{+}")#text("-tree, the tiles ")#mi("{P_-, P \\in T}")#text(" become disjoint (up to null sets), and we can obtain an almost orthogonality estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Almost orthogonality)")]#text(" ")#metadata(none) <tao-2dd411308b37266d33c9>#text(" For any ")#mi("{+}")#text("-tree ")#mi("{T}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\sum_{P \\in T} c_P \\phi_P \\right\\|_{L^2({\\bf R})}^2 \\lesssim \\sum_{P \\in T} \\left|c_P\\right|^2", block: true)]]

#text("for all complex numbers ")#mi("{c_P}")#text(", and use this to deduce the Bessel-type inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in T} \\left|\\langle f, \\phi_{P} \\rangle\\right|^2 \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})}^2.", block: true)]]
]

#text("From this exercise and ")#link(<tao-35b1aa3e15d252b6b21f>)[#text("(34)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\varepsilon \\lesssim \\left|I_T\\right|^{-1/2} \\left\\|f\\right\\|_{L^2({\\bf R})}", block: true)]]

#text("and so the desired bound ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" will follow from the tree estimate ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(".")

#text("In this case it will be convenient to linearise the sum to remove the absolute value signs; more precisely, to show ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(" it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in T} \\epsilon_P \\langle f, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle \\lesssim \\varepsilon \\mu \\left|I_T\\right|", block: true)]]

#text("for any complex numbers ")#mi("{\\epsilon_P}")#text(" of magnitude ")#mi("{1}")#text(". Again we may assume that the tree ")#mi("{T}")#text(" is non-empty, and use the partition ")#mi("{{\\mathcal J}}")#text(" from Exercise ")#link(<tao-c9e949c0039a95d182a6>)[#text("11")]#text(", to split the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{J \\in {\\mathcal J}} \\int_J \\sum_{P \\in T} \\epsilon_P \\langle f, \\phi_P \\rangle \\phi_P 1_{E_P^+}.")]]

#text("The contribution of the narrow tiles ")#tao-math("{\\left|I_P\\right| < \\left|J\\right|}", block: false)#text(" can be disposed of as before without any additional difficulty, so we focus on estimating the contribution")

#align(center)[#tao-fit-display[#tao-math("\\sum_{J \\in {\\mathcal J}} \\int_J \\sum_{P \\in T: \\left|I_P\\right| \\geq \\left|J\\right|} \\epsilon_P \\langle f, \\phi_P \\rangle \\phi_P 1_{E_P^+}", block: true)]]

#text("of the wide tiles. As before, in order for this sum to be non-empty ")#mi("{J}")#text(" has to be contained in an ")#tao-math("{O(\\left|I_T\\right|)}", block: false)#text(" neighbourhood ")#mi("{CI_T}")#text(" of ")#mi("{I_T}")#text(".")

#text("The main difficulty here is the dependence of ")#mi("{E_P^+}")#text(" on ")#mi("{P}")#text(". We rewrite")

#align(center)[#tao-fit-display[#mitex("1_{E_P^+}(x) = 1_E(x) 1_{N(x) \\in \\omega_P^+}")]]

#text("so that the above expression can be written as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{J \\in {\\mathcal J}} \\int_{J \\cap E} \\sum_{P \\in T: \\left|I_P\\right| \\geq \\left|J\\right|; N(x) \\in \\omega_P^+} \\epsilon_P \\langle f, \\phi_P \\rangle \\phi_P(x)\\ dx.", block: true)]]

#text("Now for a key geometric observation: the intervals ")#mi("{\\omega_P^+}")#text(" are nested (and decrease when ")#tao-math("{\\left|I_P\\right|}", block: false)#text(" increases), so the condition ")#mi("{N(x) \\in \\omega_P^+}")#text(" is equivalent to a condition of the form ")#tao-math("{\\left|I_P\\right| \\leq R(x)}", block: false)#text(" for some scale ")#mi("{R(x)}")#text(" depending on ")#mi("{x}")#text(". Thus the above sum can be written as")

#metadata(none) <tao-6463114249a67dcdc990>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#tao-math("\\sum_{J \\in {\\mathcal J}} \\int_{J \\cap E} \\sum_{P \\in T: \\left|J\\right| \\leq \\left|I_P\\right| \\leq R(x)} \\epsilon_P \\langle f, \\phi_P \\rangle \\phi_P(x)\\ dx.", block: true)]]

#text("One can bound the integrand here by a “maximal Calderón-Zygmund operator”")

#align(center)[#tao-fit-display[#tao-math("\\sup_R \\left|\\sum_{P \\in T: \\left|J\\right| \\leq \\left|I_P\\right| \\leq R(x)} \\epsilon_P \\langle f, \\phi_P \\rangle \\phi_P(x)\\right|", block: true)]]

#text("which is basically a sup over truncations of the “(modulated) pseudodifferential operator”")

#align(center)[#tao-fit-display[#tao-math("f \\mapsto \\sum_{P \\in T: \\left|J\\right| \\leq \\left|I_P\\right|} \\epsilon_P \\langle f, \\phi_P \\rangle \\phi_P.", block: true)]]

#text("The point of this formulation is that the integrand can now be expressed as a sort of “Littlewood-Paley projection” of the function")

#align(center)[#tao-fit-display[#mitex("F(x) := \\sum_{P \\in T} \\epsilon_P \\langle f, \\phi_P \\rangle \\phi_P(x)")]]

#text("to the region of frequency space corresponding to those intervals ")#mi("{\\omega_P^+}")#text(" with ")#tao-math("{\\left|J\\right| \\leq \\left|I_P\\right| \\leq R}", block: false)#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Establish the pointwise estimate")

#align(center)[#tao-fit-display[#tao-math("\\sup_R \\left|\\sum_{P \\in T: \\left|J\\right| \\leq \\left|I_P\\right| \\leq R} \\epsilon_P \\langle f, \\phi_P \\rangle \\phi_P(x)\\right| \\lesssim \\sup_{I: I \\supset J} \\frac{1}{\\left|I\\right|} \\int_I \\left|F\\right|", block: true)]]

#text("for all ")#mi("{x \\in J}")#text(" where ")#mi("{I}")#text(" ranges over all intervals (not necessarily dyadic) containing ")#mi("{J}")#text(".")
]

#text("From ")#link(<tao-44cdb0488d1296b95644>)[#text("(29)")]#text(" and Exercise ")#link(<tao-c9e949c0039a95d182a6>)[#text("11")]#text("(iii) as before we have")

#align(center)[#tao-fit-display[#tao-math("\\left|J \\cap E\\right| \\lesssim \\mu \\left|J\\right|", block: true)]]

#text("and so we can bound the expression ")#link(<tao-6463114249a67dcdc990>)[#text("(35)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim \\sum_{J \\in {\\mathcal J}: J \\subset CI_T} \\mu |J| \\sup_{I: I \\supset J} \\frac{1}{\\left|I\\right|} \\int_I \\left|F\\right|", block: true)]]

#text("which one can bound in terms of the Hardy-Littlewood maximal function ")#mi("{MF}")#text(" of ")#mi("{F}")#text(", followed by Cauchy-Schwarz and the Hardy-Littlewood inequality, and finally Exercise ")#link(<tao-2dd411308b37266d33c9>)[#text("12")]#text(", as")

#tao-aligned(keep: true)[


#tao-math(" & \\lesssim \\sum_{J \\in {\\mathcal J}: J \\subset CI_T} \\mu \\int_J MF", block: true)



#tao-math(" & \\lesssim \\mu \\int_{CI_T} MF", block: true)



#tao-math(" & \\lesssim \\mu \\left|I_T\\right|^{1/2} \\left\\| MF \\right\\|_{L^2({\\bf R})}", block: true)



#tao-math(" & \\lesssim \\mu \\left|I_T\\right|^{1/2} \\left\\| F \\right\\|_{L^2({\\bf R})}", block: true)



#tao-math(" & \\lesssim \\mu \\left|I_T\\right|^{1/2} (\\sum_{P \\in T} \\left|\\langle f, \\phi_P \\rangle\\right|^2)^{1/2}.", block: true)
]

#text("On the other hand, from ")#link(<tao-6199aecf23aba7e87b2d>)[#text("(33)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in T: P \\leq P_*} \\left|\\langle f, \\phi_P \\rangle\\right|^2 \\leq \\varepsilon^2 \\left|I_{P_*}\\right|", block: true)]]

#text("for every ")#mi("{P_* \\in T}")#text(". By grouping the tiles in ")#mi("{T}")#text(" according to their maximal elements ")#mi("{P_*}")#text(" (which necessarily have essentially disjoint spatial intervals) and applying the above inequality to each such group and summing, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in T} \\left|\\langle f, \\phi_P \\rangle\\right|^2 \\leq \\varepsilon^2 \\left|I_T\\right|", block: true)]]

#text("and the tree estimate ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(" follows.")

#strong[#text("The general case")]

#text("We are now ready to handle the general case of an arbitrary finite collection ")#mi("{{\\mathcal P}}")#text(" of tiles. Motivated by the previous discussion, we define two quantities:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 14 (Energy and mass)")]#text(" For any non-empty finite collection ")#mi("{{\\mathcal P}}")#text(" of tiles, we define the ")#emph[#text("energy")]#text(" ")#mi("{\\mathrm{Energy}({\\mathcal P})}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Energy}({\\mathcal P}) := \\sup_T \\left|I_T\\right|^{-1/2} (\\sum_{P \\in T} \\left|\\langle f, \\phi_P \\rangle\\right|^2)^{1/2}", block: true)]]

#text("where ")#mi("{T}")#text(" ranges over all ")#mi("{+}")#text("-trees in ")#mi("{{\\mathcal P}}")#text(", and the ")#emph[#text("mass")]#text(" ")#mi("{\\mathrm{Mass}({\\mathcal P})}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Mass}({\\mathcal P}) := \\sup_{P \\in {\\mathcal P}} \\sup_{P^{\\prime} \\geq P} \\left|I_{P^{\\prime}}\\right|^{-1} \\int_{E_{P^{\\prime}}} \\chi_{I_{P^{\\prime}}}^{10}", block: true)]]

#text("where ")#mi("{E_{P^{\\prime}}}")#text(" is the set")

#align(center)[#tao-fit-display[#mitex("E_{P^{\\prime}} := \\{ x \\in E: N(x) \\in \\omega_{P^{\\prime}} \\}")]]

#text("(thus for instance ")#mi("{E_{P^{\\prime}}^+ \\subset E_{P^{\\prime}} \\subset E}")#text("). By convention, we declare the empty set of tiles to have energy and mass equal to zero.")
]

#text("Note here that the definition of mass has been modified slightly from previous arguments, in that we now use ")#mi("{E_{P^{\\prime}}}")#text(" instead of ")#mi("{E}")#text(". However, this turns out to be an acceptable modification, in the sense that we still continue to have the analogue of ")#link(<tao-dc9c5edb8b2d479e697b>)[#text("(32)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Tree estimate)")]#text(" ")#metadata(none) <tao-9e593335cc63428cfdab>#text(" If ")#mi("{T}")#text(" is a tree, show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in T} \\left|\\langle f, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle\\right| \\lesssim \\mathrm{Energy}(T) \\mathrm{Mass}(T) |I_T|.", block: true)]]
]

#text("Since ")#mi("{\\chi_{I_{P^{\\prime}}}^{10}}")#text(" has an ")#mi("{L^1}")#text(" norm of ")#tao-math("{O(\\left|I_{P^{\\prime}}\\right|)}", block: false)#text(", we also have the trivial bound")

#metadata(none) <tao-f651480a637e7b11f9d1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\mathrm{Mass}({\\mathcal P}) \\lesssim 1")]]

#text(" ")#text(" for any finite collection of tiles ")#mi("{{\\mathcal P}}")#text(".")

#text("The strategy is now to try to partition an arbitrary family ")#mi("{{\\mathcal P}}")#text(" of tiles into collections of disjoint trees ")#mi("{T}")#text(" (or “forests”, if you will) whose energy ")#mi("{\\mathrm{Energy}(T)}")#text(", mass ")#mi("{\\mathrm{Mass}(T)}")#text(", and spatial scale ")#tao-math("{\\left|I_T\\right|}", block: false)#text(" are all under control, apply Exercise ")#link(<tao-9e593335cc63428cfdab>)[#text("15")]#text(" to each tree, and sum. To do this we rely on two key selection results, which are vaguely reminiscent of the Calderón-Zygmund decomposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 16 (Energy selection)")]#text(" ")#metadata(none) <tao-c71340b2d4ae2596902b>#text(" Let ")#mi("{{\\mathcal P}}")#text(" be a finite collection of tiles with")

#metadata(none) <tao-14de40b705b5a6ca9b0f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\mathrm{Energy}({\\mathcal P}) \\leq \\varepsilon")]]

#text("for some ")#mi("{\\varepsilon > 0}")#text(". Then one can partition ")#mi("{{\\mathcal P}}")#text(" into a collection ")#mi("{{\\mathcal T}}")#text(" of disjoint trees ")#mi("{T}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T \\in {\\mathcal T}} \\left|I_T\\right| \\lesssim \\varepsilon^{-2} \\left\\|f\\right\\|_{L^2({\\bf R})}^2", block: true)]]

#text("together with a remainder set ")#mi("{{\\mathcal P}^{\\prime}}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Energy}({\\mathcal P}^{\\prime}) \\leq \\frac{1}{2} \\varepsilon.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 17 (Mass selection)")]#text(" ")#metadata(none) <tao-4e0f1af3fe9e53b6376b>#text(" Let ")#mi("{{\\mathcal P}}")#text(" be a finite collection of tiles with")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Mass}({\\mathcal P}) \\leq \\mu")]]

#text("for some ")#mi("{\\mu > 0}")#text(". Then one can partition ")#mi("{{\\mathcal P}}")#text(" into a collection ")#mi("{{\\mathcal T}}")#text(" of disjoint trees ")#mi("{T}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T \\in {\\mathcal T}} \\left|I_T\\right| \\lesssim \\mu^{-1} \\left|E\\right|", block: true)]]

#text("together with a remainder set ")#mi("{{\\mathcal P}^{\\prime}}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Mass}({\\mathcal P}^{\\prime}) \\leq \\frac{1}{2} \\mu.")]]
]

#text("(In these propositions, “disjoint” means that any given tile ")#mi("{P}")#text(" belongs to at most one of the trees ")#mi("{T}")#text(" in ")#mi("{{\\mathcal T}}")#text("; but the tiles in one tree are allowed to overlap the tiles in another tree.)")

#text("Let us assume these two propositions for now and see how these (together with Exercise ")#link(<tao-9e593335cc63428cfdab>)[#text("15")]#text(") establishes the required estimate ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" for an arbitrary collection ")#mi("{{\\mathcal P}}")#text(" of tiles. We may assume without loss of generality that ")#tao-math("{\\left\\|f\\right\\|_{L^2}}", block: false)#text(" and ")#tao-math("{\\left|E\\right|}", block: false)#text(" are non-zero. Rearranging the above two propositions slightly, we see that if ")#mi("{{\\mathcal P}_n}")#text(" is a finite collection of tiles such that ")#metadata(none) <tao-e55cffc81a5ad8cfe852>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#tao-math("\\mathrm{Energy}({\\mathcal P}_{n}) \\leq 2^{-n/2} \\left\\|f\\right\\|_{L^2({\\bf R})}; \\quad \\mathrm{Mass}({\\mathcal P}_n) \\leq 2^{-n} \\left|E\\right|", block: true)]]

#text(" ")#text(" for some integer ")#mi("{n}")#text(" then after applying Proposition ")#link(<tao-c71340b2d4ae2596902b>)[#text("16")]#text(" followed by Proposition ")#link(<tao-4e0f1af3fe9e53b6376b>)[#text("17")]#text(", we can partition ")#mi("{{\\mathcal P}_n}")#text(" into a disjoint collection ")#mi("{{\\mathcal T}_n}")#text(" of trees ")#mi("{T}")#text(" with")

#metadata(none) <tao-ff588964557fe4e661ce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#tao-math("\\sum_{T \\in {\\mathcal T}_n} \\left|I_T\\right| \\lesssim 2^n", block: true)]]

#text("together with a remainder ")#mi("{{\\mathcal P}_{n+1}}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Energy}({\\mathcal P}_{n+1}) \\leq 2^{-(n+1)/2} \\left\\|f\\right\\|_{L^2({\\bf R})}; \\quad \\mathrm{Mass}({\\mathcal P}_{n+1}) \\leq 2^{-(n+1)} |E|.", block: true)]]

#text("Note that any finite collection of tiles ")#mi("{{\\mathcal P}}")#text(" will obey ")#link(<tao-e55cffc81a5ad8cfe852>)[#text("(38)")]#text(" for some sufficiently large and negative ")#mi("{n}")#text(". Starting with this ")#mi("{n}")#text(" and then iterating indefinitely, and discarding any empty families, we can therefore partition any finite collection of tiles ")#mi("{{\\mathcal P}}")#text(" as")

#align(center)[#tao-fit-display[#mitex("{\\mathcal P} = \\bigcup_n \\bigcup_{T \\in {\\mathcal T}_n} T \\cup {\\mathcal P}_{-\\infty}")]]

#text("where ")#mi("{{\\mathcal T}_n}")#text(" are collections of trees (empty for all but finitely many ")#mi("{n}")#text(") such that")

#metadata(none) <tao-33951586364159d31f90>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#tao-math("\\mathrm{Energy}({\\mathcal T}_{n}) \\leq 2^{-n/2} \\left\\|f\\right\\|_{L^2({\\bf R})}; \\quad \\mathrm{Mass}({\\mathcal T}_n) \\leq 2^{-n} \\left|E\\right|", block: true)]]

#text("and ")#link(<tao-ff588964557fe4e661ce>)[#text("(39)")]#text(" holds, and ")#mi("{{\\mathcal P}_{-\\infty}}")#text(" is a residual collection of tiles with")

#metadata(none) <tao-8daa35fa358d20c80732>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\mathrm{Energy}({\\mathcal P}_{-\\infty}) = \\mathrm{Mass}({\\mathcal P}_{-\\infty}) = 0.")]]

#text("We can then bound the left-hand side of ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\sum_{T \\in {\\mathcal T}_n} \\sum_{P \\in T} \\left|\\langle f, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("+ \\sum_{P \\in {\\mathcal P}_{-\\infty}} |\\langle f, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle|.")]]

#text("From Exercise ")#link(<tao-9e593335cc63428cfdab>)[#text("15")]#text(" applied to individual tiles ")#mi("{P \\in {\\mathcal P}_{-\\infty}}")#text(" and ")#link(<tao-8daa35fa358d20c80732>)[#text("(41)")]#text(" we see that the second term in this expression vanishes. For the first term, we use Exercise ")#link(<tao-9e593335cc63428cfdab>)[#text("15")]#text(", ")#link(<tao-33951586364159d31f90>)[#text("(40)")]#text(", ")#link(<tao-f651480a637e7b11f9d1>)[#text("(36)")]#text(" to bound this sum by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim \\sum_n \\sum_{T \\in {\\mathcal T}_n} |I_T| (2^{-n/2} \\left\\|f\\right\\|_{L^2({\\bf R})}) \\min( 1, 2^{-n} \\left|E\\right| )", block: true)]]

#text("which by ")#link(<tao-ff588964557fe4e661ce>)[#text("(39)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\sum_n 2^{n/2} \\min( 1, 2^{-n} \\left|E\\right| )", block: true)]]

#text("which sums to ")#tao-math("{\\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})} \\left|E\\right|^{1/2}}", block: false)#text(" as required.")

#text("It remains to establish the energy and mass selection lemmas. We begin with the mass selection claim, Proposition ")#link(<tao-4e0f1af3fe9e53b6376b>)[#text("17")]#text(". Let ")#mi("{{\\mathcal P}_1}")#text(" denote the set of all tiles ")#mi("{P^{\\prime}}")#text(" with ")#mi("{P^{\\prime} \\geq P}")#text(" for some ")#mi("{P \\in {\\mathcal P}}")#text(" and such that ")#metadata(none) <tao-ca978112ca1bbdcafac2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#tao-math("\\left|I_{P^{\\prime}}\\right|^{-1} \\int_{E_{P^{\\prime}}} \\chi_{I_{P^{\\prime}}}^{10} > \\frac{1}{2} \\mu.", block: true)]]

#text(" ")#text(" Let ")#mi("{{\\mathcal P}_*}")#text(" denote the set of tiles in ")#mi("{{\\mathcal P}_1}")#text(" that are maximal with respect to the tile partial order. (Note that the left-hand side of ")#link(<tao-ca978112ca1bbdcafac2>)[#text("(42)")]#text(" is bounded by ")#tao-math("{O(\\left|E\\right|/\\left|I_{P^{\\prime}}\\right|)}", block: false)#text(", so there is an upper bound to the spatial scales of the tiles involved here.) Then every tile ")#mi("{P}")#text(" in ")#mi("{{\\mathcal P}}")#text(" is either less than or equal to a tile in ")#mi("{{\\mathcal P}_*}")#text(", or is such that")

#align(center)[#tao-fit-display[#tao-math("\\left|I_{P^{\\prime}}\\right|^{-1} \\int_{E_{P^{\\prime}}} \\chi_{I_{P^{\\prime}}}^{10} \\leq \\frac{1}{2} \\mu", block: true)]]

#text("for all ")#mi("{P^{\\prime} \\leq P}")#text(". Thus if we let ")#mi("{{\\mathcal P}^{\\prime}}")#text(" be the collection of tiles of the second form, and let ")#mi("{{\\mathcal T}}")#text(" be the collection of trees with tree top ")#mi("{P_*}")#text(" associated to each ")#mi("{P_* \\in {\\mathcal P}_*}")#text(" (selected greedily, and in arbitrary order, subject of course to the requirement that no tile belongs to more than one tree), we obtain the required partition")

#align(center)[#tao-fit-display[#mitex("{\\mathcal P} = \\biguplus_{T \\in {\\mathcal T}} T \\uplus {\\mathcal P}^{\\prime}")]]

#text("with")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Mass}({\\mathcal P}^{\\prime}) \\leq \\frac{1}{2} \\mu")]]

#text("and it remains to establish the bound")

#metadata(none) <tao-f45140f001d5fb767ec4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#tao-math("\\sum_{T \\in {\\mathcal T}} \\left|I_T\\right| \\lesssim \\mu^{-1} |E|.", block: true)]]

#text("This will be a (rather heavily disguised) variant of the Hardy-Littlewood maximal inequality. By construction, the tree tops ")#mi("{P_T, T \\in {\\mathcal T}}")#text(" are essentially disjoint, and one has")

#align(center)[#tao-fit-display[#tao-math("\\int_{E_{P_T}} \\chi_{I_T}^{10} > \\frac{1}{2} \\mu \\left|I_T\\right|", block: true)]]

#text("for all such tree tops. To motivate the argument, suppose for sake of discussion that we had the stronger estimate")

#metadata(none) <tao-f56865fef7726a425116>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("\\int_{E_{P_T}} 1_{I_T} > \\frac{1}{2} \\mu |I_T|.")]]

#text("By the essential disjointness of the ")#mi("{P_T}")#text(", the sets")

#align(center)[#tao-fit-display[#mitex("E_{P_T} \\cap I_T = \\{ x \\in E: (x,N(x)) \\in P_T) \\}")]]

#text("are also essentially disjoint subsets of ")#mi("{E}")#text(", hence")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T \\in {\\mathcal T}} \\int_{E_{P_T}} 1_{I_T} \\leq \\left|E\\right|", block: true)]]

#text("and the claim ")#link(<tao-f45140f001d5fb767ec4>)[#text("(43)")]#text(" would then follow. Now we do not quite have ")#link(<tao-f56865fef7726a425116>)[#text("(44)")]#text("; but from the pigeonhole principle we see that for each ")#mi("{T \\in {\\mathcal T}}")#text(" there is a natural number ")#mi("{m = m_T}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\int_{E_{P_T}} 1_{2^m I_T} \\gtrsim 2^{2m} \\mu \\left|I_T\\right|", block: true)]]

#text("(say), where ")#mi("{2^m I_T}")#text(" denotes the interval with the same center as ")#mi("{I_T}")#text(" but ")#mi("{2^m}")#text(" times the length (this is not quite a dyadic interval). We now restrict attention to those ")#mi("{T}")#text(" associated to a fixed choice of ")#mi("{m}")#text(". Let ")#mi("{2^m P_T := 2^m I_T \\times \\omega_{T}}")#text(" denote the corresponding dilated tiles, then we have")

#metadata(none) <tao-f056b8cae37dc3ed60ee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#tao-math("\\left|\\{ x \\in E: (x,N(x)) \\in 2^m P_T \\}\\right| \\gtrsim 2^{2m} \\mu \\left|I_T\\right|", block: true)]]

#text("for each ")#mi("{T}")#text(" with ")#mi("{m_T = m}")#text(".")

#text("Unfortunately, the ")#mi("{2^m P_T}")#text(" are no longer disjoint. However, by the greedy algorithm (repeatedly choosing maximal tiles (in the tile ordering)), we can find a collection ")#mi("{{\\mathcal T}_m \\subset {\\mathcal T}}")#text(" such that")

#list(
[#text("(i) All the dilated tree tops ")#mi("{2^m P_T, P_T \\in {\\mathcal T}_m}")#text(" are essentially disjoint.")],
[#text("(ii) For every ")#mi("{T \\in {\\mathcal T}}")#text(" with ")#mi("{m_T = m}")#text(", there is ")#mi("{T^{\\prime} \\in {\\mathcal T}_m}")#text(" such that ")#mi("{2^m P_T}")#text(" intersects ")#mi("{2^m P_{T^{\\prime}}}")#text(" and ")#tao-math("{\\left|I_T\\right| \\leq \\left|I_{T^{\\prime}}\\right|}", block: false)#text(".")]
)

#text("From property (i) and ")#link(<tao-f056b8cae37dc3ed60ee>)[#text("(45)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T^{\\prime} \\in {\\mathcal T}_m} 2^{2m} \\mu \\left|I_{T^{\\prime}}\\right| \\lesssim \\left|E\\right|.", block: true)]]

#text("On the other hand, from property (ii) we see that the sum of all the ")#tao-math("{\\left|I_T\\right|}", block: false)#text(" for all ")#mi("{T \\in {\\mathcal T}}")#text(" with ")#mi("{m_T = m}")#text(" associated to a single ")#mi("{T^{\\prime} \\in {\\mathcal T}_m}")#text(" is ")#tao-math("{O(2^m \\left|I_{T^{\\prime}}\\right|)}", block: false)#text(". Putting the two statements together we see that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T \\in {\\mathcal T}: m_T = m} \\left|I_T\\right| \\lesssim 2^{-m} \\mu^{-1} \\left|E\\right|", block: true)]]

#text("and on summing in ")#mi("{m}")#text(" we obtain the required claim ")#link(<tao-f45140f001d5fb767ec4>)[#text("(43)")]#text(".")

#text("Finally, we prove the energy selection claim, Proposition ")#link(<tao-c71340b2d4ae2596902b>)[#text("16")]#text(". The basic idea is to extract all the high-energy trees from ")#mi("{{\\mathcal P}}")#text(" in such a way that the ")#mi("{+}")#text("-tree component of those trees are sufficiently “disjoint” from each other that a useful Bessel inequality, generalising Exercise ")#link(<tao-2dd411308b37266d33c9>)[#text("12")]#text(", may be deployed. Implementing this strategy correctly turns out however to be slightly delicate. We perform the following iterative algorithm to generate a partition ")#metadata(none) <tao-37a680133bd09342f934>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("{\\mathcal P} = \\biguplus_{T \\in {\\mathcal T}} T \\uplus {\\mathcal P}^{\\prime}")]]

#text(" ")#text(" as well as a companion collection ")#mi("{{\\mathcal T}_+}")#text(" of ")#mi("{+}")#text("-trees as follows.")

#list(
[#text("Step 1. Initialise ")#mi("{{\\mathcal T}={\\mathcal T}_+ = \\emptyset}")#text(" and ")#mi("{{\\mathcal P}^{\\prime} = {\\mathcal P}}")#text(".")],
[#text("Step 2. If ")#mi("{\\mathrm{Energy}({\\mathcal P}^{\\prime}) \\leq \\frac{1}{2} \\varepsilon}")#text(" then STOP. Otherwise, go on to Step 3.")],
[#text("Step 3. Since we now have ")#mi("{\\mathrm{Energy}({\\mathcal P}^{\\prime}) > \\frac{1}{2} \\varepsilon}")#text(", ")#mi("{{\\mathcal P}^{\\prime}}")#text(" contains a ")#mi("{+}")#text("-tree ")#mi("{T_+}")#text(" for which")

#metadata(none) <tao-e31d7ce27125e7f42243>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#tao-math("\\sum_{P \\in T_+} \\left|\\langle f, \\phi_P \\rangle\\right|^2 > \\frac{1}{4} \\varepsilon^2 |I_{T_+}|.", block: true)]]

#text("Among all such ")#mi("{T_+}")#text(", choose one for which the midpoint ")#tao-math("{\\inf \\omega_{T_+} + \\frac{1}{2} \\left|\\omega_{T_+}\\right|}", block: false)#text(" of the frequency is ")#emph[#text("minimal")]#text(". (The reason for this rather strange choice will be made clearer shortly.)")],
[#text("Step 4. Add ")#mi("{T_+}")#text(" to ")#mi("{{\\mathcal T}_+}")#text(", add the larger tree ")#mi("{T := \\{ P \\in {\\mathcal P}^{\\prime}: P \\leq P_{T_+} \\}}")#text(" (with the same top ")#mi("{P_{T_+}}")#text(" as ")#mi("{T_+}")#text(") to ")#mi("{{\\mathcal T}}")#text(", then remove ")#mi("{T}")#text(" from ")#mi("{{\\mathcal P}^{\\prime}}")#text(". We also remove the adjacent trees ")#tao-math("{T_{right} = \\{ P \\in {\\mathcal P}^{\\prime}: P \\leq P_{T_+} + (\\left|I_{T_+}\\right|,0)\\}}", block: false)#text(" and ")#tao-math("{T_{left} = \\{ P \\in {\\mathcal P}^{\\prime}: P \\leq P_{T_+} - (\\left|I_{T_+}\\right|,0)\\}}", block: false)#text(" from ")#mi("{{\\mathcal P}^{\\prime}}")#text(" and also place them into ")#mi("{{\\mathcal T}}")#text(". Now return to Step 2.")]
)

#text("This procedure terminates in finite time to give a partition ")#link(<tao-37a680133bd09342f934>)[#text("(46)")]#text(" with ")#mi("{\\mathrm{Energy}({\\mathcal P}^{\\prime}) \\leq \\frac{1}{2} \\varepsilon}")#text(", and with the trees ")#mi("{{\\mathcal T}}")#text(" coming in triplets ")#mi("{T, T_{right}, T_{left}}")#text(" all associated to a ")#mi("{+}")#text("-tree ")#mi("{T_+}")#text(" in ")#mi("{{\\mathcal T}_+}")#text(" with the same spatial scale as ")#mi("{T}")#text(", with all the ")#mi("{+}")#text("-trees ")#mi("{T_+}")#text(" disjoint and obeying the estimates ")#metadata(none) <tao-60128728f26d3317e375>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#tao-math("\\sum_{P \\in T_+} \\left|\\langle f, \\phi_P \\rangle\\right|^2 \\sim \\varepsilon^2 \\left|I_{T_+}\\right|", block: true)]]

#text(" ")#text(" (both the upper and lower bounds will be important for this argument). It will then suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T_+ \\in {\\mathcal T}_+} \\left|I_{T_+}\\right| \\lesssim \\varepsilon^{-2} \\left\\|f\\right\\|_{L^2({\\bf R})}^2;", block: true)]]

#text("by ")#link(<tao-60128728f26d3317e375>)[#text("(48)")]#text(", it then suffices to show the Bessel type inequality")

#metadata(none) <tao-56cb302a529e1f7e4733>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#tao-math("\\sum_{P \\in \\bigcup_{T_+ \\in {\\mathcal T}_+} T_+} \\left|\\langle f, \\phi_P \\rangle\\right|^2 \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R})}^2.", block: true)]]

#text("Now we make a crucial observation: not only are the trees ")#mi("{T_+}")#text(" in ")#mi("{{\\mathcal T}_+}")#text(" disjoint (in the sense that no tile ")#mi("{P}")#text(" belongs to two of these trees), but the lower tiles ")#mi("{\\{ P_-: P \\in \\bigcup_{T_+ \\in {\\mathcal T}_+}\\}}")#text(" are also essentially disjoint. Indeed we claim an even stronger disjointness property: if ")#mi("{P \\in T_+ \\in {\\mathcal T}_+}")#text(", ")#mi("{P^{\\prime} \\in T^{\\prime}_+ \\in {\\mathcal T}_+}")#text(" are such that ")#mi("{\\omega_{P_-} \\subsetneq \\omega_{P^{\\prime}_-}}")#text(", then ")#mi("{I_{P^{\\prime}}}")#text(" is not only disjoint from the larger dyadic interval ")#mi("{I_P}")#text(", but is in fact disjoint from the even larger interval ")#mi("{3I_{T_+}}")#text(". To see this, suppose for contradiction that ")#mi("{\\omega_{P_-} \\subsetneq \\omega_{P^{\\prime}_-}}")#text(" and ")#mi("{I_{P^{\\prime}} \\subset 3I_{T_+}}")#text(". There are three possibilities to rule out:")

#list(
[#mi("{T^{\\prime}_+}")#text(" is equal to ")#mi("{T_+}")#text(". This can be ruled out because any two lower frequency intervals ")#mi("{\\omega_{Q_-}, Q \\in T_+}")#text(" associated to a ")#mi("{+}")#text("-tree are either equal or disjoint.")],
[#mi("{T^{\\prime}_+}")#text(" was selected after ")#mi("{T_+}")#text(" was. To rule this out, observe that ")#mi("{\\omega_{P^{\\prime}_-}}")#text(" contains the parent ")#mi("{\\omega_P}")#text(" of ")#mi("{\\omega_{P_-}}")#text(", and hence ")#mi("{P^{\\prime} \\leq P_{T_+}}")#text(", ")#tao-math("{P^{\\prime} \\leq P_{T_+} + (\\left|I_{T_+}\\right|,0)}", block: false)#text(", or ")#tao-math("{P^{\\prime} \\leq P_{T_+} - (\\left|I_{T_+}\\right|,0)}", block: false)#text(". Thus, when ")#mi("{T_+}")#text(" was selected, ")#mi("{P^{\\prime}}")#text(" should have been placed with one of the three trees ")#mi("{T_{left}, T, T_{right}}")#text(" associated to ")#mi("{T}")#text(" and would therefore not have been available for inclusion into ")#mi("{T^{\\prime}_+}")#text(", a contradiction.")],
[#mi("{T^{\\prime}_+}")#text(" was selected before ")#mi("{T_+}")#text(" was. If this case held, then the midpoint of ")#mi("{\\omega_{T_+}}")#text(" would have to be greater than or equal to that of ")#mi("{\\omega_{T^{\\prime}_+}}")#text(", otherwise ")#mi("{T^{\\prime}_+}")#text(" would not have a minimal midpoint at the time of its selection. But ")#mi("{\\omega_{T_+}}")#text(" is contained in ")#mi("{\\omega_P}")#text(", which is contained in ")#mi("{\\omega_{P^{\\prime}_-}}")#text(", which lies below ")#mi("{\\omega_{P^{\\prime}_+}}")#text(", which contains ")#mi("{(\\omega_{T^{\\prime}_+})_+}")#text(", which contains the midpoint of ")#mi("{\\omega_{T^{\\prime}_+}}")#text("; thus the midpoint of ")#mi("{\\omega_{T_+}}")#text(" lies strictly below that of ")#mi("{\\omega_{T^{\\prime}_+}}")#text(", a contradiction.")]
)

#text("If the ")#mi("{\\phi_P}")#text(" were perfectly orthogonal to each other, this disjointness would be more than enough to establish ")#link(<tao-56cb302a529e1f7e4733>)[#text("(49)")]#text(". Unfortunately we only have imperfect orthogonality, and we have to work a little harder. As usual, we turn to a ")#mi("{TT^*}")#text(" type argument. We can write the left-hand side of ")#link(<tao-56cb302a529e1f7e4733>)[#text("(49)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\langle \\sum_{P \\in \\bigcup_{T_+ \\in {\\mathcal T}_+} T_+} \\langle f, \\phi_P \\rangle \\phi_P, f \\rangle")]]

#text("so by Cauchy-Schwarz it suffices to show that")

#metadata(none) <tao-289a9c9cffb746ba9e0b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(50)")])
#tao-math("\\left\\| \\sum_{P \\in \\bigcup_{T_+ \\in {\\mathcal T}_+} T_+} \\langle f, \\phi_P \\rangle \\phi_P \\right\\|_{L^2({\\bf R})}^2 \\lesssim \\sum_{P \\in \\bigcup_{T_+ \\in {\\mathcal T}_+} T_+} \\left|\\langle f, \\phi_P \\rangle\\right|^2.", block: true)]]

#text("By the triangle inequality, the left-hand side may be bounded by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T_+, T^{\\prime}_+ \\in {\\mathcal T}_+} \\sum_{P \\in T_+, P^{\\prime} \\in T^{\\prime}_+} \\left|\\langle f, \\phi_P \\rangle\\right| \\left|\\langle f, \\phi_{P^{\\prime}} \\rangle\\right| |\\langle \\phi_P, \\phi_{P^{\\prime}} \\rangle|.", block: true)]]

#text("As ")#mi("{\\phi_P}")#text(" has Fourier support in ")#mi("{\\omega_{P_-}}")#text(", we see that ")#mi("{\\langle \\phi_P, \\phi_{P^{\\prime}} \\rangle}")#text(" vanishes unless ")#mi("{\\omega_{P_-}}")#text(" and ")#mi("{\\omega_{P^{\\prime}_+}}")#text(" overlap. By symmetry it suffices to consider the cases ")#mi("{\\omega_{P_-} = \\omega_{P^{\\prime}_-}}")#text(" and ")#mi("{\\omega_{P_-} \\subsetneq \\omega_{P^{\\prime}_-}}")#text(".")

#text("First let us consider the contribution of ")#mi("{\\omega_{P_-} = \\omega_{P^{\\prime}_-}}")#text(". Using Young’s inequality ")#mi("{ab \\leq \\frac{1}{2}(a^2+b^2)}")#text(" and symmetry, we may bound this contribution by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T_+, T^{\\prime}_+ \\in {\\mathcal T}_+} \\sum_{P \\in T_+, P^{\\prime} \\in T^{\\prime}_+: \\omega_{P_-} = \\omega_{P^{\\prime}_-}} \\left|\\langle f, \\phi_P \\rangle\\right|^2 |\\langle \\phi_P, \\phi_{P^{\\prime}} \\rangle|.", block: true)]]

#text("A direct calculation using ")#link(<tao-56486663a0524f94b141>)[#text("(22)")]#text(" reveals that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P^{\\prime}: \\omega_{P_-} = \\omega_{P^{\\prime}_-}} =\\left|\\langle \\phi_P, \\phi_{P^{\\prime}} \\rangle\\right| \\lesssim 1", block: true)]]

#text("so the contribution of this case is at most")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T_+} \\sum_{P \\in T_+} \\left|\\langle f, \\phi_P \\rangle\\right|^2", block: true)]]

#text("as desired.")

#text("Now we deal with the case when ")#mi("{\\omega_{P_-} \\subsetneq \\omega_{P^{\\prime}_-}}")#text(", which by the preceding discussion implies that ")#tao-math("{\\left|I_{P^{\\prime}}\\right| < \\left|I_P\\right|}", block: false)#text(" and ")#mi("{I_{P^{\\prime}}}")#text(" lies outside of ")#mi("{3I_T}")#text(". Here we use ")#link(<tao-14de40b705b5a6ca9b0f>)[#text("(37)")]#text(" to bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f, \\phi_{P} \\rangle\\right| \\leq \\varepsilon \\left|I_{P}\\right|^{1/2}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f, \\phi_{P^{\\prime}} \\rangle\\right| \\leq \\varepsilon \\left|I_{P^{\\prime}}\\right|^{1/2}", block: true)]]

#text("and then we can bound this contribution by")

#align(center)[#tao-fit-display[#tao-math("\\varepsilon^2 \\sum_{T_+ \\in {\\mathcal T}_+} \\sum_{P \\in T_+} \\left|I_P\\right|^{1/2} \\sum_{P^{\\prime}: \\left|I_{P^{\\prime}}\\right| < \\left|I_P\\right|, I_{P^{\\prime}} \\cap 3I_T = \\emptyset} \\left|I_{P^{\\prime}}\\right|^{1/2} |\\langle \\phi_P, \\phi_{P^{\\prime}}|.", block: true)]]

#text("Direct calculation using ")#link(<tao-56486663a0524f94b141>)[#text("(22)")]#text(" reveals that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P^{\\prime}: \\left|I_{P^{\\prime}}\\right| < \\left|I_P\\right|, I_{P^{\\prime}} \\cap 3I_T = \\emptyset} \\left|I_{P^{\\prime}}\\right|^{1/2} |\\langle \\phi_P, \\phi_{P^{\\prime}}| \\lesssim \\left|I_T\\right|^{1/2} (\\left|I_P\\right|/\\left|I_T\\right|)^{10}", block: true)]]

#text("(say), and also")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in T_+} \\left|I_P\\right|^{1/2} \\left|I_T\\right|^{1/2} (\\left|I_P\\right|/\\left|I_T\\right|)^{10} \\lesssim \\left|I_T\\right|", block: true)]]

#text("so we obtain a bound of")

#align(center)[#tao-fit-display[#tao-math("\\varepsilon^2 \\sum_{T_+ \\in {\\mathcal T}_+} \\left|I_T\\right|", block: true)]]

#text("which is acceptable by ")#link(<tao-60128728f26d3317e375>)[#text("(48)")]#text(". This finally finishes the proof of Proposition ")#link(<tao-c71340b2d4ae2596902b>)[#text("16")]#text(", which in turn completes the proof of Carleson’s theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" ")#metadata(none) <tao-d9298a10d1b0735837dc>#text(" The Lacey-Thiele proof of Carleson’s theorem given above relies on a decomposition of a tileset in a way that controls both energy and mass. The ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=199631")[#text("original proof of Carleson")]#text(" dispenses with mass (or with the function ")#mi("{N(x)}")#text("), and focuses on controlling maximal operators that (in our notation) are basically of the form")

#align(center)[#tao-fit-display[#tao-math("\\sup_N \\left| \\sum_{P \\in {\\mathcal P}: N \\in \\omega_{P_+}} \\langle f, \\phi_P \\rangle \\phi_P(x) \\right|.", block: true)]]

#text("To control such functions, one iterates a decomposition similar to Proposition ")#link(<tao-c71340b2d4ae2596902b>)[#text("16")]#text(" to partition ")#mi("{{\\mathcal P}}")#text(" into trees with good energy control, and establishes pointwise control of the contribution of each tree outside of an exceptional set. See Section 4 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3334208")[#text("this article of Demeter")]#text(" for an exposition in the simplified setting of Walsh-Fourier analysis. The ")#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/mathscinet-getitem?mr=340926")[#text("proof of Fefferman")]#text(" takes the opposite tack, dispensing with energy and focusing on bounding the operator norm of the linearised operator")

#align(center)[#tao-fit-display[#mitex("f \\mapsto \\sum_{P \\in {\\mathcal P}: N(x) \\in \\omega_{P_+}} \\langle f, \\phi_P \\rangle \\phi_P(x).")]]

#text("Roughly speaking, the strategy is to iterate a version of Proposition ")#link(<tao-c71340b2d4ae2596902b>)[#text("16")]#text(" for partition ")#mi("{{\\mathcal P}}")#text(" into “forests” of disjoint trees, though in Fefferman’s argument some additional work is invested into obtaining even better disjointness properties on these forests than is given here. See Section 5 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3334208")[#text("this article of Demeter")]#text(" for an exposition in the simplified setting of Walsh-Fourier analysis.")
]

#text("A modification of the above arguments used to establish the weak ")#mi("{(2,2)}")#text(" estimate can also establish restricted weak-type ")#mi("{(p,p)}")#text(" estimates for any ")#mi("{p>2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" For any sets ")#mi("{E,F \\subset {\\bf R}}")#text(" of finite measure, and any measurable function ")#mi("{N: {\\bf R} \\rightarrow {\\bf R}}")#text(", show that")

#metadata(none) <tao-ff4de4e9608bc19a36cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(51)")])
#tao-math("\\int_{\\bf R} 1_E(X) 1_{D \\leq N(X)} 1_F\\ dx \\lesssim_p \\left|F\\right|^{1/p} \\left|E\\right|^{1/p^{\\prime}}", block: true)]]

#text("for any ")#mi("{2 \\leq p < \\infty}")#text(". (")#emph[#text("Hint:")]#text(" repeat the previous analysis with ")#mi("{f=1_F}")#text(", but supplement it with an additional energy bound ")#mi("{\\mathrm{Energy}({\\mathcal P}) \\lesssim 1}")#text(" coming from a suitably localised version of Exercise ")#link(<tao-2dd411308b37266d33c9>)[#text("12")]#text(".)")
]

#text("The bound ")#link(<tao-ff4de4e9608bc19a36cf>)[#text("(51)")]#text(" is also true for ")#mi("{1 < p < 2}")#text(", yielding Hunt’s theorem, but this requires some additional arguments of Calderón-Zygmund type, involving the removal of an exceptional set ")#mi("{\\Omega}")#text(" defined using the Hardy-Littlewood maximal function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Hunt’s theorem)")]#text(" Let ")#mi("{E, F \\subset {\\bf R}}")#text(" be of finite non-zero measure, and let ")#mi("{N: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a measurable function. Let ")#mi("{\\Omega}")#text(" be the exceptional set")

#align(center)[#tao-fit-display[#tao-math("\\Omega := \\{ x \\in {\\bf R}: M 1_F \\geq C \\frac{\\left|F\\right|}{\\left|E\\right|} \\}", block: true)]]

#text("for a large absolute constant ")#mi("{C}")#text("; note from the Hardy-Littlewood inequality that ")#tao-math("{\\left|\\Omega\\right| \\leq \\frac{1}{2} \\left|E\\right|}", block: false)#text(" if ")#mi("{C}")#text(" is large enough.")

#list(
[#text("(i) If ")#mi("{{\\mathcal P}}")#text(" be a finite collection of tiles with ")#mi("{I_P \\subset \\Omega}")#text(" for all ")#mi("{P \\in {\\mathcal P}}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in {\\mathcal P}} \\left|\\langle 1_F, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle\\right| \\lesssim \\left|F\\right|.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" By using ")#link(<tao-56486663a0524f94b141>)[#text("(22)")]#text(" and the disjointness of the ")#mi("{E_P^+}")#text(" when ")#mi("{I_P}")#text(" is fixed, first establish the estimate")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in {\\mathcal P}: I_P = I} \\left|\\langle 1_F, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle\\right| \\lesssim 2^{-k} \\frac{\\left|F\\right|}{\\left|E\\right|} \\left|I\\right|", block: true)]]

#text("whenever ")#mi("{k}")#text(" is a natural number and ")#mi("{I}")#text(" is an interval with ")#mi("{2^k I \\subset \\Omega}")#text(" and ")#mi("{2^{k+1} I \\not \\subset \\Omega}")#text(".)")],
[#text("(ii) If ")#mi("{{\\mathcal P}}")#text(" be a finite collection of tiles with ")#mi("{I_P \\subsetneq \\Omega}")#text(" for all ")#mi("{P \\in {\\mathcal P}}")#text(", show that ")#tao-math("{\\mathrm{Energy}( {\\mathcal P} ) \\lesssim \\left|F\\right|/\\left|E\\right|}", block: false)#text(". (For a given tree ")#mi("{T}")#text(", one can introduce the dyadic intervals ")#mi("{J}")#text(" as in Exercise ")#link(<tao-c9e949c0039a95d182a6>)[#text("11")]#text(", then perform a Calderón-Zygmund type decomposition to ")#mi("{1_F}")#text(", splitting it into a “good” function bounded pointwise by ")#tao-math("{O(\\left|F\\right|/\\left|E\\right|)}", block: false)#text(", plus “bad functions” that are supported on the intervals ")#mi("{J}")#text(" and have mean zero. See ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2031458")[#text("this paper of Grafakos, Terwilleger, and myself")]#text(" for details.)")],
[#text("(iii) For any finite collection of tiles for all ")#mi("{P \\in {\\mathcal P}}")

#align(center)[#tao-fit-display[#tao-math("\\sum_{P \\in {\\mathcal P}} \\left|\\langle 1_F, \\phi_P \\rangle \\langle \\phi_P, 1_{E_P^+} \\rangle\\right| \\lesssim \\left|F\\right| \\log(2 + \\frac{\\left|E\\right|}{\\left|F\\right|}).", block: true)]]],
[#text("(iv) Show that ")#link(<tao-ff4de4e9608bc19a36cf>)[#text("(51)")]#text(" holds for all ")#mi("{1 < p < \\infty}")#text(", and conclude Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("2")]#text("(iii).")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" The methods of time-frequency analysis given here can handle several other operators that, like the Carleson operator, exhibit scaling, translation, and frequency modulation symmetries. One model example is the bilinear Hilbert transform")

#align(center)[#tao-fit-display[#mitex("B(f,g)(x) := p.v. \\int_{\\bf R} \\frac{f(x-t) g(x-2t)}{t}\\ dt")]]

#text("for ")#mi("{f,g \\in {\\mathcal S}({\\bf R})}")#text(". The methods in this set of notes were used ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1491450")[#text("by Lacey and Thiele")]#text(" to establish the estimates")

#align(center)[#tao-fit-display[#tao-math("\\left\\| B(f,g) \\right\\|_{L^{r^{\\prime}}({\\bf R})} \\lesssim_{p,q,r} \\left\\|f\\right\\|_{L^p({\\bf R})} \\left\\|g\\right\\|_{L^q({\\bf R})}", block: true)]]

#text("for ")#mi("{2 < p,q,r < \\infty}")#text(" with ")#mi("{1/p + 1/q + 1/r = 1}")#text(" (these estimates have since been strengthened and extended in a number of ways). We only give the briefest of sketches here. Much as how Carleson’s theorem can be reduced to a bound ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(", the above estimates can be reduced to the estimation of a model sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{(P_1,P_2,P_3) \\in {\\mathcal P}} \\langle f, \\phi_{P_1} \\rangle \\langle g, \\phi_{P_2} \\rangle \\langle h, \\phi_{P_3} \\rangle")]]

#text("where ")#mi("{{\\mathcal P}}")#text(" is a certain collection of triples ")#mi("{(P_1,P_2,P_3)}")#text(" of tiles ")#mi("{P_1,P_2,P_3}")#text(" with common spatial interval ")#mi("{I_{P_1} = I_{P_2} = I_{P_3}}")#text(" and frequency intervals ")#mi("{\\omega_{P_1}, \\omega_{P_2}, \\omega_{P_3}}")#text(" varying along a certain one-parameter family for each fixed choice of spatial interval. One then uses a variant of Proposition ")#link(<tao-c71340b2d4ae2596902b>)[#text("16")]#text(" to partition ")#mi("{{\\mathcal P}}")#text(" into “")#mi("{1}")#text("-trees”, “")#mi("{2}")#text("-trees”, and “")#mi("{3}")#text("-trees”, the contribution of each of which can be controlled by the energies of ")#mi("{f, g, h}")#text(" on such trees, times the length of the spatial support of the tree, in analogy with Exercise ")#link(<tao-9e593335cc63428cfdab>)[#text("15")]#text(". See for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3052499")[#text("the text of Muscalu and Schlag")]#text(" for more discussion and further results.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" The concepts of mass and energy can be abstracted into a framework of ")#mi("{L^p}")#text(" spaces associated to outer measures (as opposed to the classical setup of ")#mi("{L^p}")#text(" spaces associated to countably additive measures), in which the mass and energy selection propositions can be viewed as consequences of an abstract Carleson embedding theorem, and the calculations establishing estimates such as ")#link(<tao-d961fcc9d3802a6736eb>)[#text("(19)")]#text(" from such propositions and a tree estimate can be viewed as consequences of an “outer Hölder inequality”. See ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3312633")[#text("this paper of Do and Thiele")]#text(" for details.")
]

#heading(level: 1)[#text("Comments (111)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-564660")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("It seems like there is currently a glitch with this blog post. Instead of seeing the class notes when I load this page, I see a copy of ")#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/")[#text("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/")]

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-564873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2020")])]

#text("LHS(49) = ")#tao-math("\\sum\\left|\\langle f,\\phi_p\\rangle\\right|^2 = \\langle \\sum\\langle f,\\phi_p\\rangle\\bar{\\phi_p},f \\rangle", block: false)#text("?")#linebreak()#text(" My attempt:")#linebreak()#text(" ")#tao-math("\\sum\\left|\\langle f,\\phi_p\\rangle\\right|^2 = \\sum\\langle f,\\phi_p\\rangle\\bar{\\langle f,\\phi_p\\rangle}", block: false)

#emph[#text("[There was a misprint in the notes regarding a misplaced conjugation sign, which has now been fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-565044")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2020")])]

#text("For the tree estimate, you mentioned that the LHS is like the controlling the maximal Calderon Zygmund operator and maximal Hilbert transform. Could you elaborate on this? It wasn’t clear from the lecture.")

#emph[#text("[Added more comments to this effect – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d88ca9312d46889c9d53f6467b95c3a19e4427236264c7ab00c9751c21882e6-d81438542b2d559f0eb2faa4882dad237b66881382db3b188a7ff6566c8253b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xumin")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-568801")[#strong[#text("Xumin")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2020")])]

#text("Dear Prof. Tao, thank you for your nice notes on a.e. convergence of Fourier series. Recently, when my collaborators and I work on the almost uniform convergence (the noncommutative analogue of a.e. convergence) of noncommutative Fourier series, we are surprised to find some new results on the classical a.e. convergence of Fourier series.")

#text("We know that the symbols ")#mi("m_N")#text(" associated to Fejér Fourier multipliers ")#mi("F_N")#text(" on ")#mi("L_p(\\mathbf{R/Z})")#text(" are given by ")#tao-math("m_{2N+1}(k)=(1-\\frac{\\left|k\\right|}{2N+1})\\chi_{[-2N, 2N]}(k)=\\frac{\\chi_{K_N}*\\chi_{K_N}(k)}{\\left|K_N\\right|}", block: false)#text(" where ")#mi("K_N=[-N,N]\\cap\\mathbf{Z}")#text(". If we generalize this formula by setting ")#mi("m_{t}(\\xi)=\\frac{\\chi_{K_t}*\\chi_{K_t}(\\xi)}{\\mu(K_t)}")#text(" where ")#mi("K_t=tK")#text(" and ")#mi("K")#text(" is an arbitrary convex body in ")#mi("\\mathbf{R}^d")#text(", then this kind of Fourier multipliers may give a kind of generalized Fejér Fourier series for functions in ")#mi("L_p(\\mathbf{R}^d)")#text(". We find that the Fourier series ")#mi("T_{m_{2^j}}f(x)=\\int_{\\mathbf{R}^d} m_{2^j}(\\xi)\\hat{f}(\\xi)e^{2\\pi i \\langle x,\\xi\\rangle}")#text(" a.e. convergence to ")#mi("f")#text(" as ")#mi("j\\to \\infty")#text(" for any ")#mi("f\\in L_p(\\mathbf{R}^d)")#text(" with ")#mi("1<p<\\infty")#text(". Moreover, we find that for any sequence of positive (sending positive functions to positive functions) Fourier multipliers ")#mi("T_{m_N}")#text(" on ")#mi("L_p(\\mathbf{R}^d)")#text(" with ")#mi("m_N\\to 1")#text(" pointwisely, we can always find a subsequence ")#mi("(N_j)_j")#text(" such that ")#mi("T_{m_{N_j}}f")#text(" a.e. convergence to ")#mi("f")#text(" for any ")#mi("f \\in L_p(\\mathbf{R}^d)")#text(" with ")#mi("1<p<\\infty")#text(".")

#text("I would like to ask you if the above result is a new result or some mathematicians have already found some similar results before? Is such a result on a.e. convergence of Fourier series makes some new senses or not?")

#text("Thank you very much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-568953")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2020")])]

#text("When ")#mi("K")#text(" is smooth with nonvanishing curvature everywhere then the convolution kernel of these multipliers decays like ")#mi("\\langle x \\rangle^{-d-1}")#text(" and one can use standard convergence theorems for approximate identities (E.g. Stein-Weiss page 13). For more general convex bodies the decay is more anisotropic but there are still integrated bounds on these kernels (e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=328471")[#text("https://mathscinet.ams.org/mathscinet-getitem?mr=328471")]#text(" ) which may give results of this form. The multipliers are also very similar to Bochner-Riesz means adapted to convex bodies, for which there is a certain amount of literature, e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1827499")[#text("https://mathscinet.ams.org/mathscinet-getitem?mr=1827499")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-574355")[#strong[#text("Big Ideas in Applied Math: Smoothness and Degree of Approximation – Ethan Epperly")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2020")]

#text("[…] sense, meaning that , where is the truncated Fourier series and is norm .2One may show with considerable analysis that Fourier series converges in others senses, for example almost everywhere convergence. We also […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98f549c8f1f9fcbcecd3e5441d2c2e14ca1f8c235f7c96de3f513465daa3699e-4fbbd08c3e40ced37e4d079cdf94f7079289e0b638de10ceae46e8d6d39867f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tophythetoaster")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-576957")[#strong[#text("tophythetoaster")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2020")])]

#text("A one line solution to the blue-eyed islanders puzzle:")#linebreak()#text(" Noam Chomsky and Terence Tao walk into a bar.")

#text("-A. JK")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pointwise ergodic theorems for non-conventional bilinear polynomial averages | What's new")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-579459")[#strong[#text("Pointwise ergodic theorems for non-conventional bilinear polynomial averages | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2020")])]

#text("[…] on individual scales , and one can leverage this with a Rademacher-Menshov type argument (see e.g., this blog post) and some closer analysis of the bilinear Fourier symbol of to eventually handle all […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-688906")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2025")])]

#text("In the displayed equation above “If we now define a ")#emph[#text("tile")]#text(" to be a rectangle”, there is an integral sign that should not be there.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-688986")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2025")])]

#text("There is an extra langle in the displayed equation following “The point of this formulation is that the integrand can now be expressed…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-693352")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("I think the way you use (22) to bound the inner product is not true.I think the inner product should be bounded by ")#mi("<\\frac{dist(C_{P},C_{P^{^{\\prime}}})}{I_{P}}>")#text(",where ")#mi("C_{P}")#text(" is the center of ")#mi("I_{P}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-693353")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("As ")#mi("I_P")#text(" and ")#mi("I_{P^{\\prime}}")#text(" are the same size, the Japanese bracket of ")#tao-math("\\frac{\\mathrm{dist}(C_P, C_{P^{\\prime}})}{\\left|I_P\\right|} \\rangle", block: false)#text(" is comparable to that of ")#tao-math("\\frac{\\mathrm{dist}(I_P, I_{P^{\\prime}})}{\\left|I_P\\right|} \\rangle", block: false)#text(", so it does not matter for this argument which expression one uses.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a94b374c45f060bdfffc0cb232cb22b8112d45ecf3362a4615fc178258a4175e-5e41fc2e61e392d10a1edf085eb2f677cd0e82f8c495522410a37d8c76caa506.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yfhouag")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-693371")[#strong[#text("yfhouag")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Can we use the duality of the $l^2$ norm to bound the LHS of 6 rows above (26)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-693487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2026")])]

#text("How to use Schur’s test to obtain formula (26) specifically?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b53a3ebac3e161dbd5e040ea95c63bc9820f2be07f01b1929bb5f2252244e97-9d198ac79412f37790e2f6e79183b328a358ea2bf46610622487ded4d9370fdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M A")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-2/#comment-694209")[#strong[#text("M A")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2026")])]

#text("Can this method be adapted to prove pointwise almost everywhere convergence in even larger classes of functions, e.g. in ")#emph[#text("L")]#text(" log")#sub[#text("+")]#text("(")#emph[#text("L")]#text(") log")#sub[#text("+")]#text("log")#sub[#text("+")]#text("(")#emph[#text("L")]#text(")? (I think this was originally proven by Sjölin)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-559731")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("It is known that for each continuous periodic function, its Fourier series is")#linebreak()#text(" (everywhere) Cesaro summable to the function.")#linebreak()#text(" Is the Fourier series of any integrable function Cesaro summable almost everywhere to the function?")

#emph[#text("[Yes; see Exercise 4. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-559765")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("Is the Hunt`s theorem really valid for the essentially bounded functions even though in exercise 1 one is asked to prove that there isn`t even convergence in the norm?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-559799")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("Yes, because ")#mi("L^\\infty({\\bf R}/{\\bf Z}) \\subset L^p({\\bf R}/{\\bf Z})")#text(" for any finite ")#mi("p")#text("; thus for instance essentially bounded functions are already square-integrable, so Hunt’s theorem in this case follows from Carleson’s theorem. The sums ")#mi("S_N f")#text(" in this case need not stay uniformly bounded in ")#mi("L^\\infty")#text(", but would stay bounded in any finite ")#mi("L^p")#text(" space and converge in ")#mi("L^p")#text(" norm as well as pointwise almost everywhere.")

#text("For ")#mi("p \\leq 2")#text(" the Stein maximal principle applies and ensures that pointwise almost everywhere convergence implies weak (p,p) type of the maximal function, but there is no such principle for ")#mi("p>2")#text(", and in that regime it can happen that pointwise almost everywhere convergence holds even in the absence of other results that are typically considered weaker, such as norm convergence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/089d0cedccdbee32786c7e296994cf315ef1b3c6f13b880e696921e040d47aec-d939e5745c48f83ef6584b0b100445f6f5430f1060f2ee4de3f5348e174ac098.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of riderriju")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-559959")[#strong[#text("riderriju")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Hello respected professor. Can you give an article based on atiyah singner index theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcc8dd35fd3341bd1f47d9472063440b46e7b5f3ab73ea865fb54e45ee88722f-bb4be7f57e927f772a1e062ffc44ee78703e605f4e8c811c8e97971d91ad5d36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-559973")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Years ago I thought I’d write a book on the pointwise convergence of Fourier series, inspired by Carelson’s proof and Dirichlet’s 1823 proof, which appeared in a very early edition of Crelle. I got as far as translating the latter and putting an outline together. I just had a rummage around and I still have it!")

#link("http://djalbat.com/HotPCoFS.jpg")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/djalbat.com/HotPCoFS.jpg")[Original image]]]]

#text("The authors of the papers I tracked down are impressive. Looking at my outline, aside from the two aforementioned, I see du Bois-Reymond (1873), Féjér (1889), Kolmogorov (1922), Hunt (1968/78), Stein (1961), Zygmund (1969), etc. The dates are those of the papers I thought were landmarks in the history. I’ve spared the reader the titles. I also stumbled across Lacey and Thiele, they were to make it into the last section of the book…")

#text("Unsurprisingly I never got around to finishing this task!")

#text("Here is a picture of the outline, I’m sorry about the poor quality:")

#link("http://djalbat.com/HotPCoFS.jpg")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/djalbat.com/HotPCoFS.jpg")[Original image]]]]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-559990")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Thank you for these notes, it is really interesting. During my reading of the notes I did not find any solution to Exercise 6. Can you provide me with a hint? I tried to prove the contraposition but it did not work.")

#emph[#text("[Adapt the argument used to derive the failure of Proposition 3(ii) from the failure of Proposition 3(iii). The key point is that random rotations can be used to turn a small subset of the sphere into a large one. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560000")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Some of the latex in part (v) of the statement of proposition 3 is not parsing for me.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560011")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("In the same statement, it might be helpful to add a parenthesis in the definition of the Fourier multiplier operator. Otherwise it is not visibly clear that the widehat on the left includes the f under it. That is, \\widehat{(1_{D \\leq N} f)}(\\xi). This confused me for a moment.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560085")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Also, the multiplier is notated differently in the centered formula, for some reason.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560044")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("I have another question, related to Exercise 8 (i), is it correct that if I take ")#mi("K=2")#text(" then the required bound is ")#tao-math("\\leqslant C \\left|f_1+f_2+f_3+f_4\\right|+(\\left|f_1+f_2\\right|^2+\\left|f_2+f_3+f_4\\right|^2)^{1/2}", block: false)#text("? (I understood that ")#mi("\\{j \\in [2,4]\\}=\\{2,3,4\\}")#text(" and that ")#mi("k \\geqslant 1")#text(" thus there is no sums o). Then if I am not mistaken, it is not possible to bound the term ")#tao-math("\\left|f_1+f_2+f_3\\right|", block: false)#text(". Is it correct?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560092")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("This has now been corrected. For ")#mi("K=2")#text(", the required bound is ")#tao-math("\\left|f_1+f_2+f_3+f_4\\right| + (\\left|f_1+f_2\\right|^2 + \\left|f_3+f_4\\right|^2)^{1/2} + (\\left|f_1\\right|^2 + \\left|f_2\\right|^2 + \\left|f_3\\right|^2 + \\left|f_4\\right|^2)^{1/2}", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b552293faf977d93ae5ed706a9249ad5e789f8d9bff93f89da10b0f1472e70d8-d81138d2501078e642a558e2c947a61e332a701320f1ed496d0a515b0ccdfc7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560184")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2020")])]

#text("I started reading your exposition of the proof of Carleson’s theorem and I already have several questions related to this theorem.")

#text("(i) You say that Littlewood-Paley analysis or Calderon-Zygmund attempts will not work because these are tools which do not respect all the symmetries of the estimate. Is there however a weaker form of the Carleson theorem that is reachable by such means? In other words, what can do the classical tools (Calderon-Zygmund, Littlewood-Paley, Pseudodifferential operators, etc.) on this problem ? For example in your preceding set of notes, a “naive” Littlewood-Paley attempt for proving the Calderon-Vaillancourt allows one to prove a much weaker statement (namely the boundedness of the frequency localised operator, eq. (17) of your Notes 3).")

#text("(ii) In your roof of Carleson’s theorem, you bound the operator ")#tao-math("M_f(x):=\\sup_N \\left|1_{D \\leq N}f(x)\\right|", block: false)#text(" rather than the operator ")#mi("\\mathcal{C}")#text(" that you used in the construction of an almost everywhere divergent Fourier series. I found the latter very interesting and I am wondering: if one tries to run an analysis of the level sets ")#mi("\\{\\mathcal{C} f (x)\\ge \\lambda\\}")#text(" assuming this time that ")#mi("f \\in L^2")#text(", is there a way to convince ourselves that the construction of a counterexample in ")#mi("L^2")#text(" is not possible? Or a way to get the intuition of why the theorem must be true? For me it is not clear of where the ")#mi("L^2")#text(" assumption will help us much more than ")#mi("f \\in L^1")#text(" (at least my poor computations are not helping me). I am partly asking this question because Carleson is known for proving the theorem after years of trying to construct a counter example.")

#text("Thank you for your time, and all the notes that you realease!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560536")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2020")])]

#text("Roughly speaking, Calderon-Zygmund type techniques can control a restricted version of the Carleson theorem in which one only works with frequency cutoff ")#mi("N")#text(" is restricted to a lacunary set, such as the powers of ")#mi("2")#text(". In terms of the model operators appearing later in the paper, Calderon-Zygmund theory can basically handle the contribution of a single tree (particularly if one modulates frequency so that the tree is now based at the frequency origin).")

#text("The operator ")#mi("{\\mathcal C}")#text(" is almost the same as ")#mi("M_f")#text("; it has a slightly more convenient description in physical space, whereas ")#mi("M_f")#text(" has a more convenient description in frequency space, but they are essentially the same operator. By working in ")#mi("L^1")#text(" one gains access to approximations to Dirac delta masses that one can place at various spatial locations to influence the Carleson maximal operator in various ways. In ")#mi("L^2")#text(" such approximate Dirac masses are very expensive in terms of the ")#mi("L^2")#text(" norm and are no longer usable to generate counterexamples. (With regards to the proof of Carleson’s theorem, the ")#mi("L^2")#text(" bound manifests itself through the energy selection lemma, Proposition 16; Dirac spikes cost too much energy for their spatial extent.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b552293faf977d93ae5ed706a9249ad5e789f8d9bff93f89da10b0f1472e70d8-d81138d2501078e642a558e2c947a61e332a701320f1ed496d0a515b0ccdfc7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560548")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2020")])]

#text("Thank you a lot for the insights for the insights on the Calderon-Zygmund type techniques, it proves to be very helpful!")

#text("Let me ask one last question, which I do not how to address, but might be in fact simple to answer: as you explained, it is true that ")#mi("\\mathcal{C}")#text(" and ")#mi("M_f")#text(" are almost identical, but many results seem easier to prove with ")#mi("\\mathcal{C}")#text(" (at first glance). For example I wonder how the classical result (and very easy with ")#mi("\\mathcal{C}")#text(") that ")#mi("S_Nf=O(\\log N)")#text(" translates with ")#mi("M_f")#text(" instead? The classical proof only ises that the Dirichlet kernel has logarithmic divergence of its ")#mi("L^1")#text(" norm. In the first part of his article, Carleson improved this claims and proves, that ")#mi("S_Nf = O(\\log \\log N)")#text(" (for ")#mi("f\\in L^2")#text(" say) using a more simple interval selection process. Is it possible to write a simple proof of this ")#mi("\\log \\log N")#text(" bound using the discrete model given by the ")#mi("M_f")#text(" function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2020")])]

#text("As I said previously, it’s a matter of whether one wishes to exploit physical space arguments or frequency space arguments. The ")#mi("\\log N")#text(" bound uses the physical space structure of the kernel and the triangle inequality in physical space, so if one starts with ")#mi("M_f")#text(" one basically should write down the physical space representation which is essentially ")#mi("{\\mathcal C}")#text(" up to minor factors.")

#text("I am not so familiar with this preliminary argument of Carleson, but I would imagine that it can be translated to the discrete model. Certainly the full argument of Carleson can be translated in this fashion, see e.g., ")#link("https://arxiv.org/abs/1210.0886")[#text("https://arxiv.org/abs/1210.0886")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b552293faf977d93ae5ed706a9249ad5e789f8d9bff93f89da10b0f1472e70d8-d81138d2501078e642a558e2c947a61e332a701320f1ed496d0a515b0ccdfc7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560747")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2020")])]

#text("Thank you for the paper of Demeter, I’ll dig into it. I will also try to write a ")#mi("\\log \\log")#text(" bound using arguments presented in you lecture notes, and if I suceed I will put it here.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560224")[#strong[#text("Convergence of Fourier Series in Lp – Zeros and Ones")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2020")]

#text("[…] i.e., is it true that validity of (A) implies (B) itself? The answer is yes for due to Stein. See Tao’s notes on more details about almost everywhere […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca354f380cf6bceadef554945e8fa4278f6f859eca4f1ae5e34e2edb58cd6b0d-ce023afdc9ead2b89b577606f85acaedbe3a1ceb293cab5ec4037409b2444fa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiao-Chuan Liu")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560490")[#strong[#text("Xiao-Chuan Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2020")])]

#text("In the proof of Proposition 3, at the end of the third paragraph, it should be item (i) you want to establish.")

#text("For the part from (ii) to (iii), the final part of the proof, where you listed sequences of functions satisfying four conditions, in condition (3), do you require x to belong to ")#mi("E^{(m)}")#text(" and also ")#mi("m^{\\prime}<m")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560875")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2020")])]

#text("Is it possible that Carlson theorem holds for any complete system of continuous functions on any (fixed) real interval?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560878")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2020")])]

#text("I meant any orthonormal (wrt some continuous weight function) complete system of functions on a real interval.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560955")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2020")])]

#text("This fails in general; the first construction, for a bounded orthogonal system of sign functions, seems to be by Kolmogorov and Menshov in 1927 ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1544864")[#text("https://mathscinet.ams.org/mathscinet-getitem?mr=1544864")]#text(", there is also a counterexample for the permuted Fourier basis announced by Kolmogorov in 1926, but whose proof first appears in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=147833")[#text("https://mathscinet.ams.org/mathscinet-getitem?mr=147833")]#text(" . I found these references in this survey ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=710115")[#text("https://mathscinet.ams.org/mathscinet-getitem?mr=710115")]#text(" which discusses several further results of this type.")

#text("On the other hand, the Radamacher-Menshov type results (see Exercise 8) that has a logarithmic loss is available for any orthogonal system.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560901")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2020")])]

#text("In formula (7) in the proof of Prop 3 is written:")

#text("“Since ")#mi("{S_N}")#text(" is a convolution operator, it commutes with translations, and hence")

#mi("\\displaystyle  S_N \\tilde f(x) = \\sum_{i=1}^n \\epsilon_i S_N f(x-x_i) \\ \\ \\ \\ \\ (7)")

#text("for each ")#mi("{i}")#text(".”")

#text("Maybe some parentheses would be helpful here. The mention of translation-invariance suggests that this formula is meant to say")

#mi("\\displaystyle  S_N \\tilde f(x) = \\sum_{i=1}^n \\epsilon_i \\left( S_N f \\right)(x-x_i) \\ \\ \\ \\ \\ (A)")

#text("as opposed to")

#mi("\\displaystyle  S_N \\tilde f(x) = \\sum_{i=1}^n \\epsilon_i  S_N \\left( f (x-x_i) \\right) \\ \\ \\ \\ \\ (B)")

#text("since formula (B) would just follow by linearity and not require any translation-invariance. (Of course, the sentence ultimately asserts that (A) = (B) by translation-invariance.)")

#text("But where in the rest of the proof do we rely upon the formula (A)? That is, what breaks if we use (B) throughout and never connect it to (A) by asserting translation-invariance? Is it something with Khinchin?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560957")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2020")])]

#text("Strictly speaking, the interpretation (B) is not well-formed; ")#mi("f(x-x_i)")#text(" is a number, not a function, so ")#mi("S_N")#text(" does not apply to it. (One would write something like ")#mi("(S_N(f(\\cdot - x_i)))(x)")#text(" or ")#mi("S_N(x \\mapsto f(x-x_i))(x)")#text(" instead.)")

#text("The translation invariance is needed to ensure that the ")#mi("i^{th}")#text(" summand of (7) is large on ")#mi("E + x_i")#text(", which thanks to the random translations are approximately disjoint. Without the translation invariance one cannot push apart the sets of largeness to fill out a set of large measure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560960")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2020")])]

#text("I was sloppy with the notation, but what I meant in (B) is what you suggested: translate ")#mi("f")#text(" by ")#mi("x_i")#text(" first, and then apply ")#mi("S_N")#text(" to it.")

#text("So what you are saying is that, a priori, one does not know anything about the ")#mi("S_N")#text(" of a translated ")#mi("f")#text(", even if we already know that ")#mi("S_N f")#text(" has large values on a reasonably large set? In particular, it is not clear that ")#mi("S_N")#text(" of the translated thing has large values anywhere, until we observe that it is just a translation of ")#mi("S_N f")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-560967")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2020")])]

#text("Yes. In general, a translate of ")#mi("f")#text(" will be linearly independent of ")#mi("f")#text(", so if all that one knows about ")#mi("S_N")#text(" is that it is linear, then there is no relationship between ")#mi("S_N")#text(" applied to ")#mi("f")#text(" and ")#mi("S_N")#text(" applied to the translate of ")#mi("f")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561090")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2020")])]

#text("Dear Pro.Tao,")#linebreak()#text(" Tomorrow, 21stMay , I want you to be named with the big award of math.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2096eca3591d59013054a4ef23f298e458163c7fa6f65542fb02a4f5178f14c5-34632d1b2ccd6cf090e4e51f6059e4c612841237f4884d8efcdaec8793198d56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561100")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2020")])]

#text("Dear professor,")

#text("I am confused about the (ii) of Exercise 11. Indeed, if the spatial intervals ")#mi("I_P")#text(" in a tree ")#mi("T")#text(" are all dyadic intervals within the spatial support of the top ")#mi("I_T.")#text(" Let’s say ")#mi("I_T=[0,1]")#text(" and the collections of ")#mi("I_P")#text(" are of the form ")#mi("[m/2^k,(m+1)/2^k]")#text(" for ")#mi("k\\leq 1, m=0,1,\\cdots, 2^{k-1}")#text(". Then for any partition ")#mi("\\mathcal{J}")#text(", an element ")#mi("J")#text(" that intersects the interior of ")#mi("[0,1]")#text(", it contains infinitely many intervals ")#mi("I_P")#text(" of sizes strictly smaller than ")#tao-math("\\left|J\\right|", block: false)#text(". This contradicts to (ii) of Exercise 11.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561144")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2020")])]

#text("Oops, I forgot to add the requirement that trees are finite (this is one of the reasons why we restrict to a finite set of tiles earlier in the argument).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562289")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2020")])]

#text("Dear Pro Tao,")#linebreak()#text(" I really concern the Navier – Stokes problem very much. I would like to contribute my little idea (but infact it is very superior) . I think you do not wait a Turing machine – a fiction machine ( a dream machine) to check the time of flow up Navier -Stokes equation. I advice you to have a breakthrough in physics ( with your prestidge , you can visit the physics laboratory room which is the best in the world. If not all your efforts will be fallen down in the sea. Once you succeed, you have double of novelable medals at the same time.They are Nobel prize and Millenium award.")#linebreak()#text(" A genuine advice,")#linebreak()#text(" Best regard,")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca354f380cf6bceadef554945e8fa4278f6f859eca4f1ae5e34e2edb58cd6b0d-ce023afdc9ead2b89b577606f85acaedbe3a1ceb293cab5ec4037409b2444fa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiao-Chuan Liu")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561149")[#strong[#text("Xiao-Chuan Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2020")])]

#text("I guess the four integrals at the end of the proof of Kolmogorov theorem, (around formula (11)) are from -1 to 1, instead of over the whole R?")

#emph[#text("[It doesn’t matter, thanks to the support of ")#mi("\\phi")#text(", but I have changed them all to ")#mi("{\\bf R}")#text(" for consistency. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561160")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2020")])]

#text("In prop 3, going from (ii) to (iii), we have the formula towards the end:")

#tao-math("\\displaystyle \\sup_{0 \\leq N \\leq N^{(m)}} \\left|S_N f^{(m)}(x)\\right| \\geq m + \\sum_{m^{\\prime} 0} \\left\\|S_N f^{(m^{\\prime})}\\right\\|_{L^\\infty({\\bf R}/{\\bf Z})}", block: false)

#text("There seems to be a typo in the subscript of the sum. Also, what is the N of the S_N in the sum on the right running over? On the left, there is a sup, but there is no such thing on the right.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2020")])]

#text("Since Chebyshev polynomials ")#mi("T_n(x)")#text(" expansion of any square integrable function ")#mi("f(x)")#text(" (wrt to the weight function ")#mi("w(x) = (1-x^2)^{-1/2}")#text(") on ")#mi("(-1, 1)")#text(" is identical(!) with the Fourier expansion of the even function ")#mi("f(\\cos(\\theta))")#text(" on ")#mi("(-\\pi , \\pi)")#text(" under the pointwise correspondence ")#mi("x= \\cos (\\theta)")#text(" and ")#mi("T_n(x)= \\cos(n \\theta)")#text(", it follows that Carlson theorem holds also for Chebyshev polynomials expansions. So it seems reasonable to assume that Carlson theorem holds also for the other classical orthogonal polynomials.")#linebreak()#text(" In particular, if Carlson theorem is true also for Legendre polynomials expasions, is it possible that Carlson theorem holds also for the classical spherical harmonics expansions on the unit sphere ")#mi("S^2")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/089d0cedccdbee32786c7e296994cf315ef1b3c6f13b880e696921e040d47aec-d939e5745c48f83ef6584b0b100445f6f5430f1060f2ee4de3f5348e174ac098.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of riderriju")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561639")[#strong[#text("riderriju")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2020")])]

#text("Can it possible to write an article on hypercomplex function and spinors")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f980d6577ad89d8fbf230a07ec039cd73bb4780789a5e6ecc1ee29ea68935eb-ec0d7f981956e290d70cd9a4b90c0f7c67fdb08137bd1a040fda5acf7838520e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Leng")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561688")[#strong[#text("James Leng")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2020")])]

#text("I believe you have a typo in your presentation of K’s counterexample:")

#text("“Now we estimate {{\\mathcal C}f(x)} for {x} in the interval {[j_0+0.1, j_0+0.9]} for some natural number {n/3 \\leq j \\leq 2n/3}; note the set of all such {x} has measure {\\sim n}. In this range we will test the maximal operator at the frequency cutoff {N = N_{j_0}}:”")

#text("Should the j be a j_0? Otherwise, I don’t see how it’s possible that the measure of all such x is \\sim n.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561713")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2020")])]

#text("“we can select the frequency parameter N as we please, as long as it depends only on N and not on y” I think it should mean “only on x and not on y”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561741")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2020")])]

#text("In the beginning of the Carleson’s theorem, is the maximal operator 1_N(x) is actually a linear operator? i.e 1_N(x) (f+g) = 1_N(x)f + 1_N(x)g. This seems to fail since according to the definition of N(x), it seems that N might also depends on f?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562749")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("For each fixed choice of frequency function ")#mi("x \\mapsto N(x)")#text(", the operator ")#mi("1_{D \\leq N(x)} f")#text(" is linear in ")#mi("f")#text(". For the application to the maximal operator one does need to choose ")#mi("x \\mapsto N(x)")#text(" in a manner that depends on ")#mi("f")#text(", but as long as the estimates for each of the linearized operators is uniform in the choice of frequency function, this is not a problem. (To put it another way, the inherent nonlinearity in the problem has been moved away from the operator, and is now contained solely in the choice of a parameter, in this case the frequency function.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561791")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2020")])]

#text("I think the passage discussing modulation symmetry might be referring to the wrong formula. It refers to (12) and makes the remark")

#text("“(Technically the right-hand side changes because of an additional factor of {e^{2\\pi i x \\xi_0}}, but this factor can be handled for instance by generalising the indicator function cutoff {1_E} to a subindicator function cutoff {\\chi_E} that has the pointwise bound {|\\chi_E| \\leq 1_E}; we will ignore this very minor issue here.)”")

#text("But the right-hand side of (12) is an L^2 norm, so it should be invariant under multiplication with a Fourier character.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-561948")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2020")])]

#text("In the passage")

#text("“By selecting, for each {x}, {N(x)} to be a frequency which attains (or nearly attains) the supremal value of {|1_{D \\leq N(x)}| f(x)}, it suffices to establish the linearised estimate…”")

#text("Is the f(x) here supposed to be inside the absolute value?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562537")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2020")])]

#text("In the displayed equation following “The Fourier transform of f_R can be calculated as”, the f_R is missing a hat.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562748")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("Are we allowed to say that ")#mi("f(x) \\approx \\int f(x-t) g(t) \\, dt")#text(" where ")#mi("g(t) \\approx \\delta_0(t)")#text(" ? I think this was called a “good kernel” or “approximation to the identity” with several properties.")

#text("We could spread the ")#mi("L^1")#text(" error or ")#mi("L^2")#text(" over a bunch of (countably many) real numbers ")#mi("x_n \\in \\mathbb{R}/\\mathbb{Z}")#text(" such that ")#tao-math("\\sum \\left|a_n\\right| < \\epsilon", block: false)#text(" or ")#mi("\\sum a_n^2 < \\epsilon")#text(".")

#text("There are numerous theorems where the objective is to show ")#mi("f_n \\to f")#text(" in ")#mi("L^1")#text(" or ")#mi("L^2")#text(". We could try to draw the (failure of) pointwise convergence in the appropriate space.")

#text("I've never seen these quantitative convergence results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562768")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("In the passage")

#text("“To decouple further, we will try to decompose ")#mi("{1_{\\omega_-}(D)}")#text(" into “rank one” operators. More precisely, we manipulate")

#mi("\\displaystyle  1_{\\omega_-}(D) f(x) = 1_{\\omega_-}(D) 1_{\\omega_-}(D)^* f(x)")

#mi("\\displaystyle  = (f * \\widetilde{1^\\vee_{\\omega_-}}) * 1^\\vee_{\\omega-}(x)")

#mi("\\displaystyle  = \\int_{\\bf R} (\\int_{\\bf R} f(z) \\overline{1^\\vee_{\\omega_-}(z-y)}\\ dz) 1^\\vee_{\\omega-}(x-y)\\ dy")

#mi("\\displaystyle  = \\int_{\\bf R} \\langle f, \\mathrm{Trans}_y 1^\\vee_{\\omega_-} \\rangle \\mathrm{Trans}_y 1^\\vee_{\\omega_-}(x)\\ dy")

#text("where we use the notation ")#mi("{\\tilde g(x) := \\overline{g(-x)}}")#text(". It will be convenient to try ”")

#text("I believe you want (y – z) rather than (z – y) in the convolution here.")

#emph[#text("[I think it is correct as it stands – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563039")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("What does the ")#mi("\\ast")#text(" in ")#mi("{1_{\\omega_-}(D)}^\\ast")#text(" mean?")

#emph[#text("[Adjoint – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562770")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("Could you say more about the intuition behind this decomposition of ")#mi("{1_{\\omega_-}(D)}")#text(" into “rank one” operators? I find the explanation even about heuristics to be rather opaque. Maybe just more talking would help.")

#text("If I understand correctly, the ")#mi("\\mathrm{Trans}_y 1^\\vee_{\\omega_-}")#text(" are supposed to be translates of some model wave packet attuned to the Fourier interval ")#mi("\\omega_-")#text(". These translates are somehow supposed to form something like a basis for the subspace of L^2 consisting of f whose Fourier support lies entirely inside ")#mi("\\omega_-")#text("?")

#text("Anyway, that is my interpretation of the formula ")#mi("\\displaystyle = \\int_{\\bf R} \\langle f, \\mathrm{Trans}_y 1^\\vee_{\\omega_-} \\rangle \\mathrm{Trans}_y 1^\\vee_{\\omega_-}(x)\\ dy")

#text("What does “rank one” refer to anyway?")

#text("Right now I don’t see the overarching strategy behind the proof of Carleson’s theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562939")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("Rank refers to the dimension of the range of an operator: ")#link("https://en.wikipedia.org/wiki/Finite-rank_operator")[#text("https://en.wikipedia.org/wiki/Finite-rank_operator")]#text(" . In particular, operators of the form ")#mi("f \\mapsto \\langle f, \\phi \\rangle \\psi")#text(" are rank one operators.")

#text("There is a general heuristic that the “rank” of a pseudodifferential operator should be roughly equal to the area of the region in phase space that the symbol is supported in, although this statement is not literally true for several reasons, particularly the presence of “Schwartz tails” in either space or frequency (the claim is closer to literally true though for the “dyadic model” of Fourier analysis and pseudodifferential calculus provided by the Fourier-Walsh model, see e.g., ")#link("https://www.math.ucla.edu/~tao/254a.1.01w/notes5.dvi")[#text("https://www.math.ucla.edu/~tao/254a.1.01w/notes5.dvi")]#text(" ). In particular, the projection ")#mi("1_{\\omega_-}(D)")#text(" is projecting to a strip of infinite area and would thus be expected to be of infinite rank; partitioning into tiles would then be expected to give something like a rank one decomposition.")

#text("For continuous choices of parameter ")#mi("y")#text(", the functions ${\\mathrm Trans}_y 1_{\\omega_-}^\\check$ are an overcomplete basis, in particular the uncertainty principle predicts that these functions are essentially unchanged (up to multiplication by scalar phases) if ")#mi("y")#text(" is only adjusted at scales smaller than ")#tao-math("1 / \\left|\\omega_-\\right|", block: false)#text(". However, if one sparisifies the range of ")#mi("y")#text(" to a lattice of spacing ")#tao-math("1/\\left|\\omega_-\\right|", block: false)#text(", one expects to recover a basis (cf. the Shannon sampling theorem ")#link("https://en.wikipedia.org/wiki/Nyquist%E2%80%93Shannon_sampling_theorem")[#text("https://en.wikipedia.org/wiki/Nyquist%E2%80%93Shannon_sampling_theorem")]#text(" ).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563050")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("“From the uncertainty principle, modifying {y} by {O(1/|\\omega_-|)} should only modify {\\mathrm{Trans}_y 1^\\vee_{\\omega_-}(x)} approximately by a phase, so the integral here is roughly constant at spatial scales {O(1/|\\omega_-|)}.”")

#text("Could you elaborate on this? It is unclear to me how the uncertainty principle comes into play here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563230")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2020")])]

#text("Suppose first that ")#mi("\\omega_-")#text(" is supported near the origin, so ")#mi("1_{\\omega_-}")#text(" is supported in the region ")#tao-math("\\xi = O(\\left|\\omega_-\\right|)", block: false)#text(". Then the uncertainty principle predicts that the Fourier transform ")#mi("1_{\\omega_-}^\\vee(x) = \\int_{\\bf R} 1_{\\omega_-}(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")#text(" will not vary significantly at scales less than the reciprocal scale ")#tao-math("1/\\left|\\omega_-\\right|", block: false)#text(", since the phase ")#mi("x \\xi")#text(" does not change much under this modification. When ")#mi("\\omega_-")#text(" is centered at a different frequency ")#mi("\\xi_0")#text(" then one can perform a similar heuristic after removing a frequency modulation ")#mi("e^{2\\pi i x \\xi_0}")#text(". (See also ")#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")]#text(" for a more detailed discussion of the uncertainty principle heuristic.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563250")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2020")])]

#text("By “uncertainty principle” you are just referring to the informal phase heuristic from ")#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")]#text(" ?")

#text("The uncertainty principle I had in mind was something else, namely a lower bound on the product of the variances of f and \\hat{f} (from Stein and Shakarchi vol 1).")

#text("I would not have guessed that there was any close connection between these two things.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563446")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("Yes, I am referring to the general (but informal) uncertainty principle here, rather than the specific Heisenberg uncertainty principle you refer to, which is a manifestation of the general principle (namely: if a function has frequency standard deviation ")#mi("\\Delta \\xi")#text(", then it is roughly constant up to phase rotations at spatial scales ")#mi("1/\\Delta \\xi")#text(" and hence should hae spatial standard deviation ")#mi("\\gtrsim 1/\\Delta \\xi")#text(") but the latter is often too narrow to be of much use in applications (other than as support for the more general principle).")

#text("Note also that while the Heisenberg uncertainty principle is the most well known of the formalizations of the general uncertainty principle, it is certainly far from the only one available. For instance the ")#link("https://en.wikipedia.org/wiki/Uncertainty_principle#Hardy's_uncertainty_principle")[#text("Hardy uncertainty principle")]#text(" is also well known.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562918")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("The definition of P_{+} when in the sentence “The interval \\omega_{+} is then similarly….” is missing a right bracket.")

#text("A \\langle is missing in (14).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562930")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("Should we actually instead have ")#tao-math("1_{\\omega -}(D)f(x) \\approx \\left|\\omega_{-}\\right|^{-1}\\sum_{y \\in \\frac{1}{\\left|\\omega_{-}\\right|}\\mathbb{Z}}\\langle f\\cdots", block: false)#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562940")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("In the passage:")

#text("“From the uncertainty principle, modifying {y} by {O(1/|\\omega_-|)} should only modify {\\mathrm{Trans}_y 1^\\vee_{\\omega_-}(x)} approximately by a phase, so the integral here is roughly constant at spatial scales {O(1/|\\omega_-|)}. So we heuristically have")

#tao-math("\\displaystyle  1_{\\omega-}(D) f(x) \\approx \\left|\\omega_-\\right| \\sum_{y \\in \\frac{1}{\\left|\\omega_-\\right|} {\\bf Z}} \\int_{\\bf R} \\langle f, \\mathrm{Trans}_y 1^\\vee_{\\omega_-} \\rangle \\mathrm{Trans}_y 1^\\vee_{\\omega_-}(x).", block: false)

#text("If we now define a tile to be a rectangle {P} in phase space of the form”")

#text("I think there shouldn’t be an integral sign in this formula?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562942")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("For Exercise 9, I got a slightly different result. Here is my calculation:")#linebreak()#text(" ")#tao-math("\\int_E f(x) d\\mu(x) \\leq \\left|\\left|f\\right|\\right|_p\\left|\\left|\\mu(E)\\right|\\right|_{p^{\\prime}}", block: false)#text(" (holder),")#linebreak()#text(" $\\leq ||f||_{p,\\infinity}||\\mu(E)||_{p’}\\leq A||\\mu(E)||_{p’}$ since ")#mi("L^{p,\\infty}")#text(" norm is bigger than ")#mi("L^p")#text(" norm. But")#linebreak()#text(" ")#tao-math("\\left|\\left|\\mu(E)\\right|\\right|_{p^{\\prime}}\\neq \\mu(E)^1/p^{\\prime}", block: false)#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-562977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("You may have inadvertently used the constant function ")#mi("\\mu(E)")#text(" in place of the indicator function ")#mi("1_E")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563063")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("“We now make the above heuristic decomposition rigorous. For any dyadic interval {\\omega = [\\inf \\omega, \\inf \\omega + |\\omega|]}, let {\\omega_- := [\\inf \\omega, \\inf \\omega + |\\omega|/2]} denote the left child interval, and {\\omega_+ := [\\inf \\omega + |\\omega|/2, \\inf \\omega + |\\omega|]} the right parent interval. ”")

#text("I assume this should read “right child interval”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563094")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2020")])]

#text("“we thus have")

#text("\\displaystyle \\sum_{\\omega} |\\int_{\\bf R} 1_E(X) 1_{\\omega_+-\\xi_0}(N(X)) \\eta_{\\omega-\\xi_0}(D) f\\ dx| \\lesssim \\|f\\|_{L^2({\\bf R})} |E|^{1/2}.")

#text("We temporarily truncate to a finite range of scales, ”")

#text("Shouldn’t ")#mi("\\eta_{\\omega-\\xi_0}(D)")#text(" be ")#tao-math("\\left|\\eta_{\\omega-\\xi_0}(D)\\right|^2", block: false)#text(" here?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563257")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2020")])]

#text("“For fixed ")#mi("{k}")#text(", the expression")

#tao-math("\\displaystyle  \\sum_{\\omega: \\left|\\omega\\right| = 2^{-k}} \\int_{\\bf R} 1_E(X) 1_{\\omega_+-\\xi_0}(N(X)) \\left|\\eta_{\\omega-\\xi_0}\\right|^2(D) f\\ dx", block: false)

#text("is periodic in ")#mi("{\\xi_0}")#text(" with period ")#mi("{2^{-k}}")#text(", with average equal to")

#tao-math("\\displaystyle  2^k \\int_{\\bf R} \\int_{\\bf R} 1_E(X) 1_{[\\zeta+2^{-k-1}, \\zeta+2^{-k}]}(N(X)) \\left|\\eta_{[\\xi, \\xi+2^{-k}]}\\right|^2(D) f\\ dx\\ d\\zeta", block: false)

#text("which we can rewrite as”")

#text("The ")#mi("\\xi")#text(" in the subscripts should be ")#mi("\\zeta")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563466")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("(I mean in the second formula, not the first. Unless I’m mistaken)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("Which properties of the orthonormal basis functions ")#mi("e_n(x)")#text(" on ")#mi("(0, 1)")#text(" are used in the proof of Carleson theorem – which are sufficient to imply its truth for any other basis of orthonormal functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563476")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("Basically in order for the known proofs of Carleson’s theorem to work, there should be a strong enough manifestation of the uncertainty principle that one can recast the Carleson maximal operator in terms of sums over tiles in phase space. Most bounded orthonormal systems will not have such a strong uncertainty principle, and indeed the analog of Carleson’s theorem for such systems fails in general.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563414")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("In the heuristic discussion, how do you get the equality in")#linebreak()#text(" ")#mi("1_{\\omega-}(D)1_{\\omega-}(D)^*f(x)=(f\\ast\\tilde{1_{\\omega-}^{\\vee}})\\ast1_{\\omega-}^{\\vee}(x)")#text("?")#linebreak()#text(" We have products of 2 operators and 1 function. I know for three functions")#linebreak()#text(" ")#mi("f\\cdot g\\cdot h = (\\hat{f}\\ast\\hat{g}\\ast\\hat{h})^\\vee")#text(", shouldn’t ")#mi("f")#text(" be ")#mi("f^\\vee")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563463")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("The left-hand side is the inverse Fourier transform of ")#mi("1_{\\omega_-} \\overline{1_{\\omega_-}} \\hat f")#text(", and ")#mi("(\\hat f)^\\vee = f")#text(".")

#text("More generally, it is a good idea to mentally categorize some functions as “living in frequency space” (such as ")#mi("1_{\\omega_-}, 1_{\\omega_+}")#text("), and other functions as “living in physical space” (such as ")#mi("f")#text("). If one ends up trying to combine (via pointwise product or convolution) a function in physical space (such as ")#mi("\\widetilde{1_{\\omega_-}^\\vee}")#text(") with a function in Fourier space (such as ")#mi("f^\\vee")#text("), then something has gone wrong somewhere, and by inspecting previous steps in your reasoning and identifying which expressions are in physical space and which ones are in frequency space, one can quickly localize the error.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563468")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("Isn’t ")#mi("\\overline{1_{\\omega_-}}")#text(" the same as ")#mi("1_{\\omega_-}")#text("? We’re talking about complex conjugates of indicator functions here, aren’t we?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563471")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("Yes, they are equal, and similarly ")#mi("1_{\\omega_-}^\\vee")#text(" and ")#mi("\\widetilde{1_{\\omega_-}}^\\vee")#text(" are equal, but I am using different notation for these terms as they are playing slightly different roles (one term determines the range of the rank one operator, and the other determines the corange).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563474")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("and similarly ")#mi("1_{\\omega-}(D) = 1_{\\omega-}(D)^\\ast")#text("? (I was confused about this earlier)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563432")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("In “which by (31) simplifies to”, the (31) should be (16).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563462")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("In the case of separated tiles of fixed scale, it might be helpful to label the energy and mass estimates as such, to make the connection with later sections clear.")

#emph[#text("[Suggestion implemented -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563469")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("In fact, it would probably be helpful to introduce and discuss the informal physical analogy with mass and energy in this section.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563725")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2020")])]

#text("You should take notes and indicate this yourself.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563479")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("I think it was mentioned in lecture that pointwise convergence of Fourier series is not known for higher dimensional tori.")

#text("What is it about the current proof of Carleson’s theorem that fails to extend to higher dimensions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563751")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2020")])]

#text("The tree estimate (which, very roughly speaking, corresponds to a maximal disk multiplier over radii in a lacunary range such as ")#mi("\\{ 1 + 2^{-n}: n \\in {\\bf N}\\}")#text(") is not currently established. This may not be the only missing piece of the argument but my understanding is that it is the primary one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563512")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("Another thing that would be helpful to mention explicitly in the notes is the change of variables ")#mi("x \\mapsto N(x)")#text(" in order to transform the graph of ")#mi("N(x)")#text(" in the ")#mi("x-\\xi")#text(" plane to a simple triangle in the ")#mi("N(x)-\\xi")#text(" plane.")

#text("In particular, it would clarify things (for me, anyway) to spell out where this transformation fits into the overall strategy. That is, why trading off the irregular regions in the plane for regular rectangular ones by making an irregular change of variables helps the proof without possibly hurting in other ways.")

#emph[#text("[Added a sentence to this effect – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-563514")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2020")])]

#text("(That was bad notation. This should read ")#mi("(x,\\xi)")#text("-plane and ")#mi("(N(x),\\xi)")#text("-plane)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564097")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2020")])]

#text("When talking about ")#mi("(T, P_T)")#text(", say the -tree, the lower half are contained, and the upper half are disjoint. You mean the upper half of the tiles ")#mi("P")#text(" in the tree are disjoint from ")#mi("P_T")#text(", not disjoint from each other, right? Just want to clarify this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564181")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2020")])]

#text("Both assertions are true (and the latter is more relevant).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564127")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2020")])]

#text("Intuitively, why are the -tree and +tree estimates different? We are trying to prove equation (19) for different cases, but I thought the +tree should be the same as the -tree case, since they are symmetric (by flipping). Can we just prove one case, and say the other case follows by the same argument?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564187")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2020")])]

#text("The trees themselves have a symmetry, but the model operator does not; the lower tiles ")#mi("P_-")#text(" interact with ")#mi("f")#text(" and the upper tiles interact with ")#mi("E, N")#text(" in somewhat different ways (in particular requiring understanding “energy” in the former case and “mass” in the latter).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564143")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2020")])]

#text("For the proof of the energy estimate of fixed scale case, equation (25), you used TT* method to exploit approximate orthogonality. I am not familiar with the TT* method, and couldn’t find much info on line. Could you explain what it is? In particular, how do you get the equality:")#linebreak()#text(" ")#mi("(\\sum||^2)^{1/2} = \\sum\\bar{c_P}")#text(".")

#text("Also, is TT* method the standard way to exploit approximate orthogonality of finite dimensional vectors?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564235")[#strong[#text("MATH 247B: Modern Real-Variable Harmonic Analysis – Countable Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")]

#text("[…] Carleson’s Theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564264")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")])]

#text("” To motivate the argument, suppose that {\\phi_P} had no tail outside of {I_P}, so that one could replace {\\chi_{I_P}^{100}} to {1_{I_P}} in (22). Then would have")

#text("\\displaystyle |I_P|^{1/2} \\langle \\phi_P, 1_{E_P^+} \\rangle \\lesssim |\\{ x \\in E: (x,N(x)) \\in P_+ \\}|,")

#text("and as the tiles {P_+} are all essentially disjoint the claim (24) would then follow from summing in {P}, since each {x \\in E} contributes to at most one of the sets {\\{ x \\in E: (x,N(x)) \\in P_+ \\}}. ”")

#text("Is this the place where we need to use the fact that N(x) does not take dyadic values?")

#text("Can one also get around the boundary issues by declaring dyadic intervals to be half-open i.e. of the form ")#mi("[a,b)")#text("? This seems like it would be simpler than having to find an N(x) with non-dyadic values.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564353")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")])]

#text("[a,b) or [a,b] not important since we don’t care sets of measure zero. Dyadic values are easy to find and use, and have nice nesting properties, thus orthogonality which is used throughout the proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564369")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")])]

#text("Sets of measure zero can have inverse image of non-zero measure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564639")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("Fair enough, this is a simpler fix. I have reworded the text to use half-open dyadic intervals instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")])]

#text("For tiles P>P’, you mentioned the geometric observation that either ")#mi("P_{+}, P_{+}^{^{\\prime}}")#text(" are disjoint or ")#mi("P_{-}, P_{-}^{^{\\prime}}")#text(" are disjoint. What about the case where P and P’ cross each other in the middle, so both + and – side overlap? For example, let P=(1/2)*2 (short and fat), and P’=(1/4)*4 (long and thin). Why won’t this happen?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564640")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("For dyadic intervals it is not possible for a short dyadic interval to overlap both halves of a long dyadic interval. For instance if ")#mi("P = [0,1/2) \\times [0,2)")#text(" then the ")#mi("1/4 \\times 4")#text(" dyadic tiles that intersect ")#mi("P")#text(" are ")#mi("[0,1/4) \\times [0,4)")#text(" and ")#mi("[1/4,1/2) \\times [0,4)")#text(", one of which meets the upper half of ")#mi("P")#text(" and not the lower, and the other doing the reverse.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")])]

#text("Once we hypothesize the upper bounds of energy ")#mi("(\\epsilon)")#text(" and mass ")#mi("\\mu")#text(" of tiles P (eq. 27, 28), can we also assume the same lower bounds for the tree top ")#mi("P_T")#text(" (eq. 30,31)? The energy lower bounds seems reasonable for a tree top, but I am not sure about the mass lower bound since $\\mu$ is a bound of mass density, not the total mass.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564642")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("Not in general, but it turns out that the tree selection process used later in the argument will basically generate trees that obey lower bounds of this form (for at least one of the mass and energy, if not both). The lower bounds are not of essential importance in this argument; they are present mostly for pedagogical purposes to illustrate why the tree estimate is in some sense “stronger” than the ")#mi("L^2")#text(" estimate for a single tree.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564420")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")])]

#text("In the passage")

#text("“We also assume that we have the reverse bounds for the tree top:")

#text("\\displaystyle |I_{T}|^{-1/2} \\langle f, \\phi_{P_T} \\rangle \\gtrsim \\varepsilon \\ \\ \\ \\ \\ (30)")

#text("and")

#text("\\displaystyle |I_{T}|^{-1} \\int_{\\bf R} 1_{E}(x) \\chi^{10}_{I_{T}}(x)\\ dx \\gtrsim \\mu. \\ \\ \\ \\ \\ (31)")

#text("It will be through a combination of both these lower and upper bounds that we can obtain a bound (19) that does not involve either {\\varepsilon} or {\\mu}.”")

#text("What does the notation ")#mi("\\gtrsim")#text(" here mean? That the implicit constants should be uniform over all trees?")

#text("Otherwise, there is only one tree top, and it seems this bound would be vacuous if we allow ourselves to insert any constant we like.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("Implied constants are assumed to be absolute if not subscripted by parameters, so indeed in this case I am claiming a constant independent of the choice of tree.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564429")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")])]

#text("“From (29) and Exercise 11(iii) as before we have")

#text("\\displaystyle |J \\cap E| \\lesssim \\mu |J|")

#text("and so we can bound the expression \\eqerf{j-sum} by")

#text("\\displaystyle \\lesssim \\sum_{J \\in {\\mathcal J}: J \\subset CI_T} \\mu |J| \\sup_{I: I \\supset J} \\frac{1}{|I|} \\int_I |F|")

#text("which one can bound in terms of the Hardy-Littlewood maximal function”")

#text("\\eqerf{j-sum} isn’t parsing here")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564490")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("In the defining properties of Whitney decomposition in exercise 11, are the implicit constants in the inequalities supposed to be uniform over all trees (even though the decomposition depends on the tree)?")

#emph[#text("[Yes – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564559")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("The implicit constants should depend on each tree T, not uniform.")

#emph[#text("[This is incorrect -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("Can you say more about why ")#tao-math("\\sum_{J \\in \\mathcal{J}}|J|\\min(1, \\frac{\\left|I_T\\right|}{\\left|J\\right|})^{10} \\lesssim \\left|I_T\\right|", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-564651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("From the properties of the Whitney decomposition, every ")#mi("J")#text(" in the sum either is contained in ")#mi("C I_T")#text(" for some ")#mi("C=O(1)")#text(", or has size ")#tao-math("\\gtrsim \\left|I_T\\right|", block: false)#text(" and is at distance ")#tao-math("\\sim \\left|J\\right|", block: false)#text(" from ")#tao-math("\\left|I_T\\right|", block: false)#text(". In particular in the latter case there are only ")#mi("O(1)")#text(" intervals of any given size. This is enough information to bound the sum.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-566763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2020")])]

#text("Dear Pro.Tao,")#linebreak()#text(" Wake up ! Wake up! I find that you have slept deeply nearly half a year. I think only you understand me with this saying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/comment-page-1/#comment-568605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2020")])]

#text("Dear Pro.Tao,")#linebreak()#text(" By the way, I have some interesting facts about William Hodge mathematician. He was born on June, 17th, 1903 and died on July, 7th,1975.")#linebreak()#text(" What do you think about this? A random coincide? I mean this does not only end above facts. You are very smart , 100% you understand my idea.")
]
]
]
