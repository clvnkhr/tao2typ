// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/
// Converted to Typst by tao2typ: "2026-10-14T07:01:23.566824+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Timothy Chow) Out-of-print math books", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Timothy Chow) Out-of-print math books")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 July 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/")[#text("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("[")#emph[#text("This post is authored by ")#link("http://www-math.mit.edu/~tchow/")[#text("Timothy Chow")]#text(".")]#text("]")

#text("I recently had a frustrating experience with a certain out-of-print mathematics text that I was interested in. A couple of used copies were listed at over $150 a pop on ")#link("http://www.bookfinder.com/")[#text("Bookfinder.com")]#text(", but that was more than I was willing to pay. I wrote to the American Mathematical Society asking if they were interested in bringing the book back into print. To their credit, they took my request seriously, and solicited the opinions of some other mathematicians.")

#text("Unfortunately, these referees all said that the field in question was not active, and in any case there was a more recent text that was a better reference. So the AMS rejected my proposal. I have to say that I was surprised, because the referees did not back up their opinions with any facts, and I knew that in addition to the high price that the book commanded on the used-book market, there was some circumstantial evidence that it was in demand. A MathSciNet search confirmed my belief that, contrary to what the referees had said, the field was most definitely active. Plus, another text on the same subject that Dover had recently brought back into print had a fine Amazon sales rank (much higher than that of the recent text cited by the referees).")

#text("A colleague then suggested that maybe I should instead contact the author directly, asking him to regain the copyright from the publisher. The author could then make the book available on his website or pursue print-on-demand options, if conventional publishers were not interested. I tried this, but was again surprised to discover that the author thought it was not worth the trouble to get the copyright back, let alone to make the text available. Again the argument was that, allegedly, nobody was interested in the book.")

#text("In both cases I was frustrated because I did not know how to find other people who were interested in the same book, to prove to the AMS or the author that there were in fact many of us who wanted to see the book back in print.")

#text("Now for the good news. After hearing my story, Klaus Schmid promptly set up a prototype website at")

#link("http://outofprintmath.blogspot.com/")[#text("http://outofprintmath.blogspot.com")]

#text("Anyone can go to this site and suggest a book, or vote for books that others have suggested. This is precisely the kind of information that I believe would have greatly helped me argue my case. Of course, the site works only if people know about it, so if you like the idea, please spread the word to your friends and colleagues.")

#text("It might be that a better long-term solution than Schmid’s site is to convince a bookselling website to tally votes of this sort, because such a site will catch users “red-handed” searching for an out-of-print book. I have tried to contact some sites with this suggestion; so far, ")#link("http://www.booksprice.com/")[#text("Booksprice.com")]#text(" and ")#link("http://www.fetchbook.info/")[#text("Fetchbook.info")]#text(" have said that they like the idea and may eventually implement it. In the meantime, hopefully Schmid’s site will become a useful tool in its own right.")

#text("Let me conclude with a question. What else can we be doing to increase the availability of out-of-print books, especially those that are still copyrighted? Several people have told me that the solution is for authors to regain the copyrights to their out-of-print books and make their books available themselves, but authors are often too busy (if they are not deceased!). What can we do to help in such situations?")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31163")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Going forward, I think authors negotiating contracts with publishers should insist on the copyright reverting to them if the book remains out of print for a number of years. Since today’s books are typeset with TeX, it would be easy for the author to post the book online (on the arXiv, on a personal website) or pursue alternative publication methods.")

#text("As an aside, the root of the problem is that copyright lasts way too long. With a reasonable copyright period out-of-print books could simply be republished (or photocopied) by anyone and we would not be having this discussion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31165")[#strong[#text("Out-of-print books « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")]

#text("[…] rant was engendered by a post of Timothy Chow’s at What’s New (a.k.a. Terry Tao) about a new website, where one can […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/179ef3177efc1598d2f832835564f98bdccbe63a488de86164ce5d381f3272ad-6a8a09212a37275c38b8e6c1b4a2c77ed76008d840395407c37a6d6b2d5e7f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anirvan")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31169")[#strong[#text("Anirvan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Hi Tim. I read your blog post, and wanted to give some feedback. I’m with BookFinder.com, where we spend a lot of time thinking about out of print books. We publish an annual report of the most sought-after out of print titles in the United States (")#link("http://report.bookfinder.com/")[#text("http://report.bookfinder.com/")]#text("), and we’re in the middle of doing the data analysis to publish our sixth volume.")

#text("We’ve seen many in-demand out of print books come back into print, and we’re happy that our Report has helped convince publishers of the real market demand. Unfortunately, we don’t see a lot of demand for OOP math texts; my sense is that demand is low, and trends are statistically insignificant — certainly not enough to convince a wary publisher.")

#text("For what it’s worth, I’d consider talking to publishers about cheap or low-impact republishing options that could theoretically minimize their sunk costs, e.g. print on demand, ebooks. For whatever it’s worth, feel free to follow up with me by email.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31170")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Timothy,")

#text("I’ve had good luck in the past locating used math books using AbeBooks:")

#link("http://www.abebooks.com/")[#text("http://www.abebooks.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09adcbd06408b89d8078cdd908842450d55b21a89af8056ecb826161b5322fb3-cfe0df9f1837ec93be8a7a3f7c23848cefb55432b4bfe4a56ea0419ebed80b1e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arin")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31171")[#strong[#text("arin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Some books are worth their weight in gold: ")#link("http://tinyurl.com/6b63z6")[#text("http://tinyurl.com/6b63z6")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31174")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Have you tried eMule/aMule? I was able to find a lot of stuff there. If the publisher is not interested in doing another printing, then I have no qualms downloading the book (if available) from the internets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Legal option:")

#text("If the publisher doesn’t want to republish the book, then ask them if they’d be willing to get an account at something like lulu.com and publish the book that way. It’d be minimal work for them that would see nothing but profit.")

#text("“Illegal” option:")

#text("I’m with Paul. I have no problems downloading books off of the torrents when they are in the 12th printing yet still cost $150 or are out of print. If the publisher isn’t reasonable and/or isn’t willing to even attempt to allow me to give them money, then they don’t deserve it.")

#text("Quite frankly, I see this as a symptom of more fundamental problem, that of people wanting to gain a reputation. And of course, getting something published at “that famous publisher” is a way to get some notoriety. As a student I don’t care if the book was published by the Cambridge University Press nor Dover nor the local University. What I care about is that it’s a decent book to learn from (at least in tandem with the lectures), peer reviewed and reasonably priced. The only thing guaranteed from “those publishers” is peer review and the price is almost guaranteed to obscene.")

#text("Not only that, but more and more, the books published today have CDs to “enhance the students experience.” Yet rarely do those CDs ever enter a CD-ROM. They also typically have glossy pages (read: expensive) so the obscene number of those full colour figures (read: expensive waste of space) are really pretty. Yet it isn’t considered that the glare from those horrible overhead florescent lights at Universities makes those glossy pages unreadable nor is it considered that it isn’t necessary to have nearly as many figures, nor is it considered that a black and white figure will do just as well.")

#text("All in all, I have found that only rarely there is a good quality found in today’s Math books. In fact, all of the good Math books I have on my bookshelf were either published in the 60’s or 70’s, or are revisions of books that were published in the 60’s or 70’s that retain the same style.")

#text("What I’ve found is the more disturbing difference is that the older books actually assume that the student has a brain and is willing to work. Whereas the new books assume that the student has some learning disability and needs constant hand-holding and pretty pictures to entertain him/her along the way otherwise “they’ll be lost!”")

#text("At any rate, that’s enough of a rant for now. It’ll be interesting to see when the book publishers realise that they are no longer the sole distribution channel (and that’s actually now in the consumers hands) and when that happens, if they take the same ridiculous path as the MPAA/RIAA/etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2265d3131054ee83ce22cb7f77c8da1391dc9b960781e44779facc82ab1e110-d4d61fd903248e1d78236db441cb6ff5e4c58851d1b5e2725bf0a8312dacd308.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of would be author")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31180")[#strong[#text("would be author")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("In the past I would think that authors were happy to get their book published, and were resigned to the fact that price and long term availability were something out of their control at the time. I’m sure there are many authors who now have regrets that their books are unaffordable, and/or now unavailable.")

#text("These days it seems an author can self-publish and have a cheap available book, but what about peer review?")

#text("In other words, what currently are the options if a (professional mathematician) author wants to self-publish a research monograph (or textbook) which is cheap and available, which is refereed just like a journal paper, and MathReviewed, and generally recognized as a refereed publication by every entity that matters.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ff9bb5fdf9d552a2c6c48e386b52e606db76b08642752ff95c77d7a588ed4d6-22a4304e4a7936db982bb3a2f9ca8591cd34a84c637cba91b0232cbcf1afba53.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr. David Tselnik")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-207631")[#strong[#text("Dr. David Tselnik")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2012")])]

#text("I am Dr. David Tselnik, and I wrote mathematics research book entitled “Six Chapters on Series Expansions”, by D.S. Tselnik, and I published this book myself. I sent the book to Mathematical Reviews, asking to review the book, and to publish the review in Mathematical Reviews. However, the Executive Editor of Mathematical Reviews told me that MR does not review self-published books. So, there is information about this my books in “Books in Print,” and some information on “Google Books” online. However, there will be no review of the book in MR, and that will not allow Mathematical Community to learn about my book from Mathematical Reviews.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f364ff3d8ad4ffa6285548764930824a2c12cb0adb42045254980befe0b514ab-1d61b69cda2e3fa50f912f5a09f6dc23391bbdc76bc5ecb64de7b1fc2455b31d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Reformed Faith Weblog")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31198")[#strong[#text("The Reformed Faith Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("We had the same issue with music we created – in order to get your work published you have to give away your publishing rights – many times the creator of the work is considered like contract labor and the publishing company ends up with all control over anything you produce. The publishers don’t want their contract labor becoming their competition.")

#text("In order for you to gain back control a creator of a work would literally have to buy the publishing rights from them – a very expensive proposition and the more copies it has sold over a lifetime, the more expensive that proposition is… it’s all about the control and the money – whoever has the money has the control. If you’re into becoming a publisher/distributor (which is easier now than ever), then you could do that and go the print-on-demand route.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f7d8e0287d944df2a3e049c2c75d1baa9698255df95e18aa182d3e9fcb92149-520128d42c155d5550467f296fec60187bddc6d0d0ba90a270ac8e86223a6c0a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of realylife")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31200")[#strong[#text("realylife")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("nice Information . Can i learn more ???")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31209")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("to would-be-author:")

#text("One way to go is the ")#link("http://www.math.cornell.edu/~hatcher/#anchor1772800")[#text("Hatcher")]#text(" way: post the book on your website ")#emph[#text("before")]#text(" it’s submitted to a publisher. You then make sure that you have the right to keep the book on your website, where you make it clear that you expect people to buy the book if they can.")

#text("If you have the reputation of the ")#link("http://www.jmilne.org/math/Books/index.html")[#text("Milne")]#text(" caliber you can go the self-published route. He has even convinced publishers to allow him to post scans of his out-of-print books.")

#text("A third alternative is to use a small publisher, which will accept books which have been posted to the arXiv first. An example of this is ")#link("http://www.umpa.ens-lyon.fr/~yollivie/publs.html")[#text("Ollivier")]#text("‘s publishing of his survey on random groups through the Brazilian Mathematical Society. As an added bonus, he gets to post the book version, not only the preprint version, on his website.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("@would be author:")

#text("Send chapters of your book to colleagues and get them to review one or more of them. Then as a thank you, put somewhere in there that they refereed the book or which chapters they did referee. Make the same offer to them.")

#text("This way, not only is it obvious that the book was refereed, but who refereed what. Then, put a link to a place like lulu.com where people can buy the book and if you want, a free download as well.")

#text("The whole “recognised” thing is a social problem. Sure there will be people/institutions that will discard the self-publish notion as flawed. But, this will be because it is change and/or it takes the power out of the people/institutions that have enjoyed a monopoly on distribution for so very long.")

#text("What you have to do as a self-publisher is that you dot all your i’s and cross all you t’s. As in, make sure not only that it is clear that your work has been peer reviewed, but done so by respectable people. Also, you should make sure that it is available on your website (at least a “product page” linking to the book for purchase) which should be at the respectable institution that you work for. That and a link on the “product page” at the place where one would order the publication should make your credentials known.")

#text("The above is something that the publisher has taken care of for the author. Namely, to “talk you up.” Those who wish to self-publish need to do that themselves which means that your web page and product page needs to include that. It could be a publication list among other things. But, it needs to be there and well written to separate you from the crackpots.")

#text("Disclaimer: The above isn’t meant to be an exhaustive list of what needs to be done, but just some major points.")

#text("p.s. Expect a healthy dose of criticism. Early adopters usually get slammed in the beginning. But, those that come after you will be thankful. It might take some time for it to happen, but it certainly will. We’re having this discussion on a blog after all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Chow")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31249")[#strong[#text("Timothy Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2008")])]

#text("To would-be author: For research monographs and advanced textbooks, publishing with an organization such as the American Mathematical Society is a decent option. While the AMS does retain certain rights over the work, on the whole it is much more reasonable than commercial publishers are. Its prices are not exorbitant and it is committed to keeping its books available indefinitely. I ordered an old text from them once that was printed on demand for me, and the quality was excellent. And of course everything is fully refereed.")

#text("To Richard: Bookfinder is more powerful than Abebooks because it searches Abebooks as well as other sources simultaneously.")

#text("To Paul: I haven’t tried eMule/aMule but my guess is that many books I’m interested in aren’t available there either.")

#text("To Anirvan: I tried to email you, without success. Please email me (you can find my email address on my website).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31257")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2008")])]

#text("Anonymous (actual anonymous, not Timothy), sending a manuscript to a particular person and asking them to review is not peer review. Peer review needs to be anonymous and independent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31258")[#strong[#text("Csiszár and Körner — bring it back in print! « An Ergodic Walk")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2008")]

#text("[…] — bring it back in print! Posted by asarwate under Information Theory Via Timothy Chow blogging at Terence Tao’s blog, I learned about outofprintmath, a kind of survey site for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31264")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2008")])]

#text("@Jason Dyer:")

#text("That notion of peer review is dated.")

#text("Also, peer review is only “anonymous” when it comes to the author not knowing who reviewed the paper, and is NOT double blind which would be a requirement for calling something absolutely anonymous like you did. I’d say it is NOT required, but is only like that because that is the way the CURRENT system is set-up. Similarly for your “independent” comment.")

#text("What people seem to not realise is that the world has changed. People are no longer looking at the journals for publications, but rather pre-print servers like the ArXiv (ZERO peer review). More and more the journals are ignored because they are exceedingly slow, expensive and people who are even remotely competent in there respective fields will be able to tell whether something is solid work or not on a pre-print server. That isn’t me looking in a crystal-ball, but rather opening my eyes and seeing how people ARE working today.")

#text("Expect this to get more and more pervasive as time goes on and more and more of the “Google generation” enters the various fields of research. As in, you shouldn’t be saying what is or is not peer review, but rather attempt to make it work in this new reality. Not acknowledging that new reality is how we’ve ended up with the completely broken system that we have today.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31265")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2008")])]

#text("@Jason Dyer:")

#text("I should also point out that I didn’t say to send it to one person for review, but rather many. Or at least that is what I intended to get across. I also mentioned to put the name of people who reviewed it within the publication. This would mean that those people put there reputation on the line just like the author has done.")

#text("What I’m proposing is rather a cheap, efficient distributed model rather that an expensive, slow centralised one. It’s where the world is moving in many regards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31267")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2008")])]

#text("One thing to keep in mind is that, for most publishers, research-level")#linebreak()#text(" (or graduate level) mathematical books are mostly sold to (university) libraries. Books which are sold in majority to invididuals are, I think, quite rare. This certainly affects the way publishers deal with those books: they often have a certain number of sales which are guaranteed, and which are enough to recover their investment.")

#text("Also, I suspect most libraries will not (at least at the moment) get books which are self-published, or published through lulu.com (or similar services). In turn, this means that references to such literature will be seen as highly unreliable, especially with respect to long-term accessibility (who can be sure that lulu.com will still be available in 20 years?). Of course, one may believe that the book will always be at most one search query away, in some form or other, using whatever system will exist then, but librarians seem to be very conservative when it comes to such issues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Chow")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31300")[#strong[#text("Timothy Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2008")])]

#text("Regarding Anonymous’s comments about peer review: One must distinguish between what tenure committees look at versus what active researchers look at. If I am an active researcher then of course I will look at preprints and evaluate them myself. I don’t need a referee to tell me whether the paper is good. In contrast, if I am making hiring or promotion decisions, most likely I will not understand the person’s field well enough myself and will need to take someone else’s word for it. Anonymous evaluation is still very useful in such situations, even if it is only single-blind and not double-blind. This distinction has always held, and the web has not changed it one whit.")

#text("Not to say that the current system of peer review can’t be improved, of course. But some mechanism for anonymous reviews is still needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e510271c02c3261a77816bedda5d48a826205ba2435a5be453512ad3c3383060-3903d940d0fd14e9792224157252b50223a32bcbac2cc4f1b5fd507f7b7bf331.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hopefully Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31308")[#strong[#text("Hopefully Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2008")])]

#text("Timothy, I don’t think the criticism of peer review publications is so much with the single blind anonymous aspect as how slow some of them can be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Chow")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31324")[#strong[#text("Timothy Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2008")])]

#text("Jason Dyer and Anonymous were in fact debating the anonymity issue, if you go back and read their comments closely.")

#text("However, slowness is also a legitimate problem. But I don’t think that sending your papers to people you know will necessarily get them refereed any faster. One option that may be worth exploring is to pay referees. Referees in some other fields, e.g., in economics, are paid.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4e37a6808cc9a435a11796fd6744cd2d3facea8357102b8141c2bad1b07e413-97da1add1a9f55c32107b6020818cc5143b8ff3c56dad5bd8851fa516ba39f0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Misha")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31328")[#strong[#text("Misha")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2008")])]

#text("Lots of books are available via P2P, go to ")#link("http://isohunt.com/")[#text("http://isohunt.com/")]#text(" for example, and search.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31346")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2008")])]

#text("ArXiv is nice, but hardly a substitute for some sort of peer review process. Otherwise the Reimann Hypothesis would have been proved and disproved many times. There has always been a danger historically of false proofs in mathematics; jumping on ArXiv results as verified is a dangerous standpoint. (If you believe only high-profile preprints have fatal mistakes, you have much greater faith in the infallability of others than I.)")

#text("I’m willing to accept some sort of accelerated substitute for the usual process (I agree the system is dated), but just ‘send it to someone you know to look at’ smacks of cronyism. I do think it also possible to drop anonymity, but what should *not* be dropped is the authority made possible by ensuring the referee is independent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/084e5a5695c795142e04d2ea9939b421fd8eae5ca4931ee7b4d1cf4f708c7f0d-06f52676f3ec3bc804253a1bb9f07b408ac68e2170094e8d7332427864f2e18d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chilleddu Malevadau")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31510")[#strong[#text("Chilleddu Malevadau")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2008")])]

#text("Terence,")

#text("I have been also experiencing the same problem several times, and even though I do not have a solution for the problem, here are a few proposals/questions, some of which indecent:")#linebreak()#text(" 1) have you tried asking Dover how they publish “old” books, and to consider the ones you are interested in?")#linebreak()#text(" 2) If the author is not willing to bother with the process of regaining his copyright etc., wouldn’t it be possible to set up a small no-profit who does the job for the lazy authors?")#linebreak()#text(" 3) Is it possible to involve the few organizations that are (essentially) scanning old articles, and ask them whether they would consider scanning books? (e.g. NUMDAM)")#linebreak()#text(" 4) I agree with you that P2P is not a panacea, lots of books I am interested in are not available there either, and I have searched quite accurately. But I also know that specialized Russian web sites are far richer than the usual “western” ones. I’m pretty sure a Russian speaking colleague of yours could help a lot :)")#linebreak()#text(" 5) If nothing works, well… get the book from the library, ask someone to scan it for you on any decent xerox machine, and do not forget to post it on gigapedia or something similar ;)")#linebreak()#text(" Cheers,")

#text("Chilleddu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31532")[#strong[#text("Ars Mathematica » Blog Archive » Out of Print Math Books")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2008")]

#text("[…] Timothy Chow tells the story behind the site’s creation here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31589")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2008")])]

#text("Have you tried ABEBOOKS.COM ??")#linebreak()#text(" Brilliant for out of print items.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31614")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2008")])]

#text("Dover is very receptive to suggestions. They’ve picked up three books I’ve suggested in the last few years (Davis, “Applied Nonstandard Analysis”; Samuel, “Algebraic Theory of Numbers”; Mosher and Tangora, “Cohomology Operations”).")#linebreak()#text(" (But try to suggest books which have some prospect of selling. It doesn’t help them or the math community to push books of interest to only one or two people.)")#linebreak()#text(" Another thing to consider is to nudge publishers in the direction of books-on-demand. Springer is trying this with its Lecture Notes series.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31677")[#strong[#text("Back into print? « Theorema Egregium")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2008")]

#text("[…] [via Terence Tao’s blog, invited post by Timothy Chow]. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Chow")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-31888")[#strong[#text("Timothy Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("A colleague of mine has just alerted me to the fact that a ")#link("http://slashdot.org/firehose.pl?op=view&id=813057")[#text("blurb about Schmid’s site")]#text(" has just appeared on the Slashdot Firehose. If you’re a Slashdot subscriber, please consider clicking on the + sign above the blurb to increase the chances that the Slashdot editors will select it for publication.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43751ccfd28354d47cab588724e28a3b14497bc5ebcb07d8ecf60e62155efcfc-8d32eb6f3a3636e8bb022bcdc2df0c235cdc4209c684c0ba79e96178c498e041.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kieran")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-41715")[#strong[#text("kieran")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2009")])]

#text("Can you put them on the computer and then I will print them off")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7614a2c4691cdcfcd7b12d0ff115050a27f7dba3df90c51443dbb8fab68672c9-0c2aa5e669f13dca4e240098892a37c40183381a9f3b978580a99c8cfa52209b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Caldas")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-48893")[#strong[#text("André Caldas")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2010")])]

#text("Hi, Tim!")

#text("I don’t see a short term solution to this problem. But you can contribute to one side or another… Do you write, or plan to write books? Well, I guess you can set your books free before this kind of thing happens. If you write books, don’t let others lock it up.")

#text("Authors should build up a culture of not accepting every condition the editor imposes. I believe authors do not need to be so submissive anymore. Set your books free… convince your colleagues to do the same. :-)")

#text("If your personal believes about copyright do not allow you to agree with me, then try at least to set it as free as you think you could. Every restriction should be very well justified or it should not be there. Logical traps that would make a book locked up, like the one you just described, should be avoided. The less restrictions the less are the traps.")

#text("Don’t let good works die just because the remuneration is not worth the trouble to keep it alive!!!")

#text("Cheers,")#linebreak()#text(" André Caldas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4f71d4df67dfd8905cefae02de2f32d03eae1733047da92f7951063561c08d4-d5f0fdd37eed9658a8207db2a0aeb04f59a2109592e2ef74010d12f430206498.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-211526")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2012")])]

#text("“Several people have told me that the solution is for authors to regain the copyrights to their out-of-print books and make their books available themselves, but authors are often too busy (if they are not deceased!). What can we do to help in such situations?”")

#text("I have had to request the return of copyrights to three books that were out of print and in which the publisher no longer had an interest. In each case, a short letter to the publisher brought back a short letter confirming the return of those rights. Not that it mattered, because Google Books had already helped itself to my rights! (If we win the class action, I will probably walk away with $60.)")

#text("At any rate, I would suggest (a) drafting a letter for an untroubled author to sign, for forwarding to the publisher; (b) ask the publisher to write a transfer of any rights to you and then contact the publisher. But first check that Google Books hasn’t already been up to any mischief.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6bfd5a81c863e086c8af139d47afb23c61eeabc9315708ab0e234422f452d1-719d8f0007cb42b792b778e814dc707f42c7285868d8d08c62badf8fffd3c626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of $")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-231387")[#strong[#text("$")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")])]

#text("I stumbled upon this post, and it is interesting. It provides a useful object lesson in economics.")

#text("A couple years ago, after 25 years as a lawyer, I started corresponding with the chairman of a noted math department, who when I was a math major was friends with and mentored by my the Algebraist who mentored me, in essence. I started looking at math books after years away and was a bit surprised to see textbooks iin the price range of $150 to $200 for texts I wanted for my bookshelf.")

#text("I also have en economics degree and a great deal of fairly high level experience in that realm. (As an aside, I recommend for all readers an article in the New Yorker by William Baumol called “cost disease,” circa 1992 or so. Baumol is a famous economist. The article is easy to read.")

#text("When I stopped to think about thte issue a bit more, I realized it was I, not the booksellers, who was being unrealistic.")

#text("Adjusting for growth in GDP, a $30 book when I was a sophomore in college (a modestly priced math book) should cost about $160 now. A $40 book should cost about $215 now.")

#text("Adjusting for only inflation (I will explain the difference), the $30 book should cost between $90 and $100. The $40 book between $120 and $135.")

#text("Well, I can buy Weyl’s “The Concept of a Riemann Map” for $10 to $15 now. Herstein and Kaplansky books at not too steep a price.")

#text("Why did I (and probably you) have sticker shock? Publishing is, in economist lingo, a competitive industry. There are no “rents” to be extracted in general. So prices get driven down relative to the prices of otherr goods and services in the marketplace. As a share of one’s income, a $150 book is what a $30 book was in 1980. However, we have grown accusstomed to $20 to $30 books throughout publishing, and a novel in 1980 might cost not a lot less than that.")

#text("So we (mathematicians included) have been in a sense spoiled. We don’t havve to compile a fortran program with punch cards, as in 1980, to do a moddest calculation on a university mainframe. We can run mathematica on a home computer and do things impossible, or nearly so, in 1980 on virtually any computer.")

#text("We are not really paying for the content of the books, now, by and large, but the costs of producing or maintainng them. And for a highly niche market like mathematics, physics, and thte like, the books are quite reasonably priced at $150 ….")

#text("II see mathematicians (without economic training) (including some Fields medal winners) ranting about the costs of Journals and Journal publishing. Would they knew all my highly educated reporter friends, who are losing esteemed jobs at places like the Wall Street Journal and Washington Post. Why? Publishing — even when there is mass demand — is an industry in decline (like the very old song (“video killed the radio star”) and frankly they do not understand that they are lucky to have journals at all. One of the main publishers, Elvisier, which has non-academic businesses to help, has had a zero free cash flow in the last 7 years (meaning their business generated no cash; and from an economics standpoint, if one imputes a cost of capital, their economic profit has been quite negative.)")

#text("$150 books are not expensive; $300 laptops are extraordinarily cheap. This iis why all my donations to my undergraduate instuttution go to its math library.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6bfd5a81c863e086c8af139d47afb23c61eeabc9315708ab0e234422f452d1-719d8f0007cb42b792b778e814dc707f42c7285868d8d08c62badf8fffd3c626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-231389")[#strong[#text("Rob")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")])]

#text("Here is a link for relevant historical data by which to benchmark: ")#link("http://www.whitehouse.gov/sites/default/files/microsites/ERP_2012_App_B.pdf")[#text("http://www.whitehouse.gov/sites/default/files/microsites/ERP_2012_App_B.pdf")]

#text("One other point that draws upon law and economics…that is, the field that studies the intersection of the two fields. is a fairly well understood concept in contract law that bargaining with a service provider over the language of form contracts is a mistake. I see a lot of complaainst about signing rights away. (By the by, no publisher is oging to sue you for over a reprint of some frankly obscure journal article…. just not worth their time.) The distilled version is, bargain over price. Here, since they aren’t charging you too print the book or article (which I see as the most likely economic bargain given current incentives, and costs, I’d be pretty pleased that all they “charge” me is signing over the rights to a pretty obscure publication. If your demand for your piece were high enough, you wouldn’t be talking to an academic publisher in the first place.")

#text("In short, you have no bargaining power. If you can’t bargain over price, you certainly can’t bargain over theterms of a form contract.")

#text("A useful corollary to this concerns rental agreements in housing. Don’t try to fight the landlord over the terms of some rental contract. That’s not “economically efficient.” Instaed, bargain over things like the amount of depositt to be put down (which has a cost because if they withhold it you have to litigate) or over the monthly rent payments themselves. Richard Epstein, formerly of the Univer of Chicago and now at NYU law school is very good on this subject.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93e96e92814988f219c345834b8f68260488ff657fe3f9cd2769dd5c3acd3bbf-211925cbb7abc01f70ce3beaacb095d6de2519fb91a58901cb536872456e1f73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2008/07/16/timothy-chow-out-of-print-math-books/#comment-490019")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")])]

#text("It is surprising to me that this problem exists even for books published by the MAA, e.g. Excursions in Calculus: An Interplay of the Continuous and the Discrete (Dolciani Mathematical Expositions). As the MAA is funded by mathematicians couldn’t we demand that they put such books in the public domain?")
]
