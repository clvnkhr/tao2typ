// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/
// Converted to Typst by tao2typ: "2026-10-14T07:10:43.812345+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Poincaré’s legacies: pages from year two of a mathematical blog", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Poincaré’s legacies: pages from year two of a mathematical blog")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/")[#text("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I have recently finished a ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/01/whatsnew.pdf")[#text("draft version")]#text(" of my blog book “")#link("https://terrytao.wordpress.com/books/poincares-legacies-course-notes-expository-articles-and-lecture-series-from-a-mathematical-blog/")[#text("Poincaré’s legacies: pages from year two of a mathematical blog")]#text("“, which covers all the mathematical posts from my blog in 2008, excluding those posts which primarily originated from other authors or speakers.")

#link("https://terrytao.wordpress.com/wp-content/uploads/2009/01/whatsnew.pdf")[#text("The draft")]#text(" is much longer – 694 pages – than the ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/04/whatsnew_onlineversion1.pdf")[#text("analogous draft")]#text(" from 2007 (which was 374 pages using the same style files). This is largely because of the two series of course lecture notes which dominate the book (and inspired its title), namely ")#link("https://terrytao.wordpress.com/category/teaching/254a-ergodic-theory/")[#text("on ergodic theory")]#text(" and ")#link("https://terrytao.wordpress.com/category/teaching/285g-poincare-conjecture/")[#text("on the Poincaré conjecture")]#text(". I am talking with the AMS staff about the possibility of splitting the book into two volumes, one focusing on ergodic theory, number theory, and combinatorics, and the other focusing on geometry, topology, and PDE (though there will certainly be miscellaneous sections that will basically be divided arbitrarily amongst the two volumes).")

#link("https://terrytao.wordpress.com/wp-content/uploads/2009/01/whatsnew.pdf")[#text("The draft")]#text(" probably also needs an index, which I will attend to at some point before publication.")

#text("As in ")#link("https://terrytao.wordpress.com/books/whats-new-2007/")[#text("the previous book")]#text(", those comments and corrections from readers which were of a substantive and mathematical nature have been acknowledged in the text. In many cases, I was only able to refer to commenters by their internet handles; please email me if you wish to be attributed differently (or not to be attributed at all).")

#text("Any other suggestions, corrections, etc. are, of course welcome.")

#text("I learned some technical tricks for HTML to LaTeX conversion which made the process significantly faster than last year’s, although still rather tedious and time consuming; I thought I might share them below as they may be of use to anyone else contemplating a similar conversion.")

#metadata(none) <tao-3164c951aff8a4e714a3>#text("Last year, I converted each post to LaTeX separately, which resulted in a lot of redundant search-and-replaces. This time around, I first dumped all the posts (in HTML format) into a single massive text file (1.7 MB!). Then I moved linearly through the file, and every time I saw a conversion needed I executed a global search and replace (if the conversion could be automated), or at least a global search (if it required manual editing). (In the most obvious such searches, e.g. changing ")#mi("to")#text(", or <li> to \\item, there were literally thousands of such replacements; each one thus saved me many tedious minutes of work).")

#text("In some cases I had to do several passes to get the conversion done correctly. For instance, in the HTML many short mathematical expressions (e.g. a single symbol such as ")#mi("f")#text(", ")#mi("n")#text(", etc.) were often not marked up, so I would do a global search and replace to change, e.g. ” f ” to ” $f$ “. But this would occasionally mess up existing LaTeX expressions, such as $B( f , g )$, and I would then have to do a second pass, e.g. converting ” $f$ ,” back to ” f ,”. My rule of thumb was that such “false positives” were acceptable as long as their rate of occurrence was significantly less than 50%, so that the end result of the search and replace was closer to my goal than the start.")

#text("To mitigate the false positive problem, I went through the text linearly, and each section that was cleaned up and fully converted was moved into a separate text file, so that further global search-and-replaces did not mess up the portions of the text that had already been dealt with.")

#text("Perhaps the two most difficult conversion tasks, that could not be automated much at all, was the conversion of hypertext links to more traditional bibliographical citations, though I found that if a paper was cited multiple times, then a search-and-replace did cut down on the work required. Wikipedia links had to be largely abandoned, unfortunately, although I did adopt a convention that any technical term introduced with only a cursory definition would be italicised to indicate that more information about that term could be obtained from an external source, such as Wikipedia.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/#comment-35331")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2009")])]

#text("Surely the whole process could be automated.")

#text("You might consider using the LaTeXMathML script (")#link("http://math.etsu.edu/LaTeXMathML/")[#text("http://math.etsu.edu/LaTeXMathML/")]#text(") on your blog. Then you could write your posts in pure latex with no conversion required.")

#text("Another option would be to write your posts in LaTeX and then use tex4ht (")#link("http://www.cse.ohio-state.edu/~gurari/TeX4ht/")[#text("http://www.cse.ohio-state.edu/~gurari/TeX4ht/")]#text(") to convert them to html before posting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/#comment-35333")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2009")])]

#text("Terry,")

#text("Will this exhibit blowup in finite time? Having just taken delivery of the 2007 volume I can confirm that the initial data is fairly smooth, if that helps,")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/797b4d91cf8119211cd9368798285c98dbc1c4cadff0b98e72f2b17183d9a0d1-c17e9826217301c663a1d56992efb001e43a87b9a618d4e5e5ac1eeac02e7787.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rod Carvalho")]], [#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/#comment-35334")[#strong[#text("Rod Carvalho")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2009")])]

#text("Prof. Tao,")

#text("You might be interested in trying HTML-to-TeX converters. After a couple of minutes of googling, I came across a few, like this ")#link("http://www.iwriteiam.nl/html2tex.html")[#text("one")]#text(", or this ")#link("http://www.urz.uni-heidelberg.de/TeX/texmfdoc/guides/wp-conv/html2tex/html2tex_20.html")[#text("other one")]#text(". I haven’t used any of them yet, so I can’t comment on their merits / flaws. In any case, they should make the conversion process much more efficient! :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/#comment-35335")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2009")])]

#text("This looks and reads much better than I would expect from a first draft! There’s material in there that I’m interested in, and I’ll be first in line to buy this book.")

#text("I wonder what triggered the unusual automatically generated “possibly related posts” above. I hope that this isn’t an example of state of the art computer intelligence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heinrich")]], [#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/#comment-35336")[#strong[#text("Heinrich")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("Format conversions are much less tedious with support from automatic tools.")

#text("There is a small program called ")#link("http://johnmacfarlane.net/pandoc/")[#text("pandoc")]#text(" that is able to convert (subsets) of HTML to LaTeX and vice-versa.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e20efa13278069707a89d89ef4d79a73697e2570140e24f4e20115d759f0b31d-1a0ac188caf294cf09e0a3ac4bf97fe340103b5c575158a40b42b0afc37766f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/#comment-35341")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("The new book looks very nice indeed!")

#text("As for the conversion issues, I think that to be as close as possible to Terry’s situation the easiest way might be for Terry to write his posts in LaTeX first (duly marking each $f$ required) and then convert that to a text format suitable to be directly cut and pasted in the wordpress window for new posts (i.e. a conversion adding the extra \\latex bit where needed, dealing with URLs, etc.).")

#text("This conversion could be made by an easy-to-use custom perl script that would only require the filenames as input. I’ll try to see if I can cook one up (and will post a link to it after careful debugging).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/#comment-35344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("Thanks for the suggestions! Actually, it turns out that Luca Trevisan has already done something like this for his own LaTeX-intensive posts, and has kindly shared his code for me to “beta test”, which I should probably do next week. (The next one or two posts have already been largely written already, though, and won’t be in this new format.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/#comment-35470")[#strong[#text("Nielsen’s posts tagged Science2.0 | The Daily Clique")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2009")]

#text("[…] Poincaré’s legacies: pages from year two of a mathematical blog from Terry Tao’s blog: Tao announces a blog book based on all his mathematical posts from the past year. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/29/poincare%e2%80%99s-legacies-pages-from-year-two-of-a-mathematical-blog/#comment-41234")[#strong[#text("» Science 2.0: What Every Scientist Needs to Know About How the Web is Changing the Way They Work Information/Science")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")]

#text("[…] Nielsen opened his talk with a discussion of blogging in the sciences. In particular, he described the blog of Terrence Tao, a mathematician and Fields medalist. What makes Tao’s blog special is that it is a place for very high-level thinking and discussion. Tao writes blog posts outlining a mathematical problem he’s working on, along with his ideas for how they might be solved, or introducing a new way to think about them. The comments section is full of other mathmaticians offering advice, rebuttal, criticism, and discussion. It has, in essence, become a forum for mathematical thought that cannot be replicated in traditional journal-style publishing. The output of Tao’s blog is professional enough that it has been formally published in two volumes: “Structure and Randomness: pages from year one of a mathematical blog” and “Poincaré’s legacies: pages from year two of a mathematical blog“. […]")
]
