// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T10:48:43.389327+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the recently removed paper from the New York Journal of Mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the recently removed paper from the New York Journal of Mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 September 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/")[#text("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In the last week or so there has been some discussion on the internet about a paper (initially authored by Hill and Tabachnikov) that was initially accepted for publication in the ")#link("https://www.springer.com/mathematics/journal/283")[#text("Mathematical Intelligencer")]#text(", but with the editor-in-chief of that journal later deciding against publication; the paper, in significantly revised form (and now authored solely by Hill), was then quickly accepted by one of the editors in the ")#link("http://nyjm.albany.edu/nyjm.html")[#text("New York Journal of Mathematics")]#text(", but then was removed from publication after objections from several members on the editorial board of NYJM that the paper had not been properly refereed or was within the scope of the journal; see ")#link("https://www.math.uchicago.edu/~farb/statement")[#text("this statement by Benson Farb")]#text(", who at the time was on that board, for more details. Some further discussion of this incident may be found ")#link("https://gowers.wordpress.com/2018/09/09/has-an-uncomfortable-truth-been-suppressed/")[#text("on Tim Gowers’ blog")]#text("; the most recent version of the paper, as well as a number of prior revisions, are still available on the arXiv ")#link("https://arxiv.org/pdf/1703.04184.pdf")[#text("here")]#text(".")

#text("For whatever reason, some of the discussion online has focused on the role of ")#link("https://math.uchicago.edu/~wilkinso/")[#text("Amie Wilkinson")]#text(", a mathematician from the University of Chicago (and who, incidentally, was a ")#link("https://www.math.ucla.edu/dls/amie-wilkinson")[#text("recent speaker here at UCLA in our Distinguished Lecture Series")]#text("), who wrote an email to the editor-in-chief of the Intelligencer raising some concerns about the content of the paper and suggesting that it be published alongside commentary from other experts in the field. (This, by the way, is not uncommon practice when dealing with a potentially provocative publication in one field by authors coming from a different field; for instance, when Emmanuel Candès and I ")#link("https://projecteuclid.org/euclid.aos/1201012958")[#text("published a paper in the Annals of Statistics")]#text(" introducing what we called the “Dantzig selector”, the Annals solicited a ")#link("https://projecteuclid.org/euclid.aos/1201012955#toc")[#text("number of articles discussing the selector from prominent statisticians")]#text(", and then invited us to submit a ")#link("https://projecteuclid.org/euclid.aos/1201012965")[#text("rejoinder")]#text(".) It seems that the editors of the Intelligencer decided instead to reject the paper. The paper then had a complicated interaction with NYJM, but, ")#link("https://math.uchicago.edu/~wilkinso/Statement.html")[#text("as stated by Wilkinson in her recent statement on this matter")]#text(" as well as ")#link("https://www.math.uchicago.edu/~farb/statement")[#text("by Farb")]#text(", this was done without any involvement from Wilkinson. (It is true that Farb happens to also be Wilkinson’s husband, but I see no reason to doubt their statements on this matter.)")

#text("I have not interacted much with the Intelligencer, but I have published ")#link("http://nyjm.albany.edu/j/2001/7-10.html")[#text("a few")]#text(" ")#link("http://nyjm.albany.edu/j/2005/11-4.html")[#text("papers")]#text(" ")#link("http://nyjm.albany.edu/j/2009/15-14.html")[#text("with ")]#text("NYJM over the years; it is an early example of a quality “diamond open access” mathematics journal. It seems that this incident may have uncovered some issues with their editorial procedure for reviewing and accepting papers, but I am hopeful that they can be addressed to avoid this sort of event occurring again.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (247)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f5d4381d37a285311137905bbcc1286ed68d0b01bd42f29fd2c3d702d3bb3b3-760eab1dcce14c082ba856c69fa081b7438ca4b5261c40d8b74e7483629e9d9e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of erasmuse")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505473")[#strong[#text("erasmuse")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("I’ve written a long essay on the Hill affair, with lots of links and footnotes. Corrections welcomed. See")

#link("http://rasmusen.dreamhosters.com/b/2018/10/the-ted-hill-male-variability-paper-that-the-math-journals-suppressed")[#text("http://rasmusen.dreamhosters.com/b/2018/10/the-ted-hill-male-variability-paper-that-the-math-journals-suppressed")]

#text("–Eric Rasmusen, economist, Indiana University")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b831948beb823689ba0a647cc48c61e44a02a69d58264d3f22ab875de719c9c2-3ceb6cae4e3fdc833e2ff1813b1e98b7b52371a999d4a0fbca9aa161e936fb44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander SHEN")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505474")[#strong[#text("Alexander SHEN")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("Correction: “Nobody disputes that Hill’s model is mathematically correct” – technically speaking, this may be true, but “Hill’s model” is not really a model, he does not specify the assumptions about evolution, just an observation about distribution (correct, but trivial) and a lot of talk")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505477")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("Dear Professor Shen,")

#text("Forgive me for being confused, but having read your comment I just took the liberty of looking at Professor Hill’s paper on arxiv.org, and he does actually appear to define a mathematical model, complete with mathematical assumptions. Now, of course, I understand that for a mathematician of your caliber this may all appear trivial, but for me (and many people I talked to), there is a well-defined model in the paper, and an analysis thereof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b831948beb823689ba0a647cc48c61e44a02a69d58264d3f22ab875de719c9c2-3ceb6cae4e3fdc833e2ff1813b1e98b7b52371a999d4a0fbca9aa161e936fb44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander SHEN")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505486")[#strong[#text("Alexander SHEN")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("Not really. He speaks about selecting animals selecting animals of the opposite sex above some threshold, but does not specify the assumptions about what and how the selection parameter can be inherited. Several readers try later to reconstruct some model behind his talk – and suggested to consider that there is a gene that is responsible for the variance in the selection parameter (but no genes are responsible for the average of that parameter), but these assumptions (or some other assumptions that Hill had in mind) should be written explicitly before one can speak about a “model”. (Another option is that gene is in the chromosomes related to sex.) That said, I should add for clarity that IMHO the biological differences between sexes and their influence should be considered without any political bias, and the discussion above (from both sides) does not always satisfy this requirement, to say the least. (And, of course, that “unpublishing” a paper for whatever reason is completely unacceptable, much worse that a publication of a nonsense paper later retracted, or recommending a bad paper for political reasons, though both latter things are also regrettable)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505496")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#strong[#text("Step 1")]#text(" T. Hill rewrites the whole theory of Evolution mathematically (that’s the standard you are demanding) creates a mathematical model that explains how genes are inherited (this would be Nobel worthy btw)")

#strong[#text("Step 2")]#text(" After having revolutionised the study of Evolution, Biology, and Genetics with his new mathematical model. T. Hill publishes all of it on the ")#emph[#text("Mathematical Intelligencer")]#text(" . Hill")

#strong[#text("Step 3")]#text(" We all see how ")#emph[#text("Women for Mathematics")]#text(" and Wilkinson’s family embraces the scientific process.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505478")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("Many commenters here would doubtlessly be edified by Professor Anandkumar’s take on this discussion (posted with visibility set to “Public” on Facebook): ")#link("https://imgur.com/deX0Sxg")[#text("https://imgur.com/deX0Sxg")]#text(" It is interesting that she is calling for the censorship of opinions at variance with hers (though, presumably, not for the censorship of her comments describing those who disagree with her as misogynistic pigs).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505479")[#strong[#text("A follow-up to Hill’s paper or – is free speech dead in the West? – Deep thoughts on all subjects")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")]

#text("[…] three weeks after Ted Hill’s Quillette.com article, and much discussion in the various blogs (Tao’s, Gowers’ and others) an even bigger fight has broken out. Alessandro Strumia, a theoretical […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505497")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("Why is CERN doing a conference about Equality in Physics in the first place? Do they really have that much money to spare?")

#text("I am speechless. How far will this go? Does anyone remembers the Matt Taylor incident? NASA engineer that had to cry-apologised for wearing his favourite shirt")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505499")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("On his presentation Alessandro Strumia mentions Matt Taylor. He also mentions James Damore and the paper of T. Hill et ****")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("Another issue is the strange behavior of the NYJM of replacing the article by another article (of the same length) without(!) any prior notification to the author (Hill) of the original paper, and probably also to the author of the “replacing” paper – which is unethical for the authors of both papers and the potential readers. It seems that the journal still have to publish an apology to both authors and its readers about this unethical behavior!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d389d7d45f005475673c38e6d9a2a667daed782c01e3cc5cdd2222d1f69fa0-8471a5569595a75f405605b401c4cbb6ba645ce9fd92c68b6f3eebf0c607c0ce.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the recently removed paper from the New York Journal of Mathematics — What’s new – efeufuomaventure")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-505501")[#strong[#text("On the recently removed paper from the New York Journal of Mathematics — What’s new – efeufuomaventure")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("[…] via On the recently removed paper from the New York Journal of Mathematics — What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50ede3ebc4cc847a115c9e388be7d78199e606498365bfed9137118ae2bee1b7-8f846b28964b2adf31d0eeae71d16fcec0d1c6f1c820307174b9994b7b1b0067.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of God's Peace Plans/ Warning")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-506167")[#strong[#text("God's Peace Plans/ Warning")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2018")])]

#text("I am having difficulty getting my mathematical findings out, as well. Please review my site which proves, in repetition, that the Cosmos and it’s contents are positioned in a basic mathematical pattern based on a 360 degree compass. The story starts at Easter Island, which is 90 degrees south of the Dine’/Navajo Tribe center holy mountain…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-506168")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2018")])]

#text("Interesting comment. It goes straight to the point. Do you also realize that that the extinction of dinosaurs is due to fluctuations of Planck’s constant due to the expansion of the Universe?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50ede3ebc4cc847a115c9e388be7d78199e606498365bfed9137118ae2bee1b7-8f846b28964b2adf31d0eeae71d16fcec0d1c6f1c820307174b9994b7b1b0067.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of God's Peace Plans/ Warning")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-506215")[#strong[#text("God's Peace Plans/ Warning")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2018")])]

#text("No, please explain. Is there a similarity between that and God’s Mathematical Revelation ? Where, on a Mercator Projection map, The Giza Plateau and Pyramids are 22.5 degrees from Easter Island (called “Navel of the world). Also, on that line, is Holy Cross Of Rivers Of Macchu Picchu, And, then onto the Dead/Salt Sea ( whose shores are in a geometric pattern that point to the northern-most tip of the old wall of Jerusalem- this 4 degree line then wraps around the globe, passing-over Hawaii Big Island, and the southern-most point of the Euro-Asian landmass, and then to the Great Arrow valleys of Mount Everest) evidence keeps on going,and going. All landmarks and holy mountains and sites are connected in the same basic mathematical angles. The geological map of Earth also lines-up with the stars ( which are also arranged in the same mathematical pattern, that tells a story. Go to my website, see all the amazing things that are impossible to make-up or forge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6055603f403152b3f19d95501a9db861422bd463f5c4dab26f4deaf835f6d0e9-b83a6070e328051bd6eed9c96b9c19505ff4d6cf20a557ec00c1df5532972148.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carina")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-2/#comment-507877")[#strong[#text("Carina")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2018")])]

#text("Here is my recent email to Politico:")

#link("http://www.personal.psu.edu/cpc16/politico-email-29nov2018.pdf")[#text("Click to access politico-email-29nov2018.pdf")]

#text("following my repeated (and failed) attempts to reach out to Ted Hill and Quillette requesting corrections to the article, particularly with regard to the account of events at Penn State.")

#text("— Carina")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aac8d33b9992468c7aa37bf9e42d879f52394290757c965f5faf670279a823d3-7c9be481611ed5a9deb512431f80642927539d3a1350ed6935a7a35f65cf6702.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hardy Hulley")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504750")[#strong[#text("Hardy Hulley")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("Your account of what happened — and especially the conduct of Wilkinson, her husband and her father (!) — is at odds with the evidence provided by the Hill (the author of the article). In particular, you make no mention of the fact that Wilkinson apparently waged a Facebook campaign against the editors of the Mathematical Intelligencer and the NYJM (asking her followers to unfollow them). Your claim that you have no reason to doubt the statements by Wilkinson and Farb is astounding, given that his conflict of interest was so obvious. His behaviour strikes me as a clear case of ethical misconduct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f5d4381d37a285311137905bbcc1286ed68d0b01bd42f29fd2c3d702d3bb3b3-760eab1dcce14c082ba856c69fa081b7438ca4b5261c40d8b74e7483629e9d9e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of erasmuse")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505008")[#strong[#text("erasmuse")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Hill has now published many pages of documents–emails, mainly— which mostly support his side of the case (though it also becomes clear that the refereeing was very rapid).")

#link("https://www.dropbox.com/s/lnm3csfna4seavr/hill_redacted.pdf?dl=0")[#text("https://www.dropbox.com/s/lnm3csfna4seavr/hill_redacted.pdf?dl=0")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7bd79ccc17907103f59d86fb20316d47cd1b97b6e5da97c6784bb34597ecff0-0d4f3e22196665cd23c0b63eb88a1c5d6701288f8a5ee038d7b21ba2ca261e47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tell The Truth")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505030")[#strong[#text("Tell The Truth")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("I am not so sure they support any side.")

#text("Wilkinson’s critique of the paper was spot on. The model Hill proposes is too simple and has too many gaps to explain GV in humans.")

#text("Hill has reasons to be aggrieved here with both the Intelligencer and the NYJM.")

#text("However, Rivin should probably bare the brunt of the blame and HIll’s ire for what happened at NYJM as he clearly fast-tracked the paper for political reasons and in response to the actions of the Intelligencer.")

#text("The censorship claims, however, are greatly exaggerated. Anyone can find and cite the paper on arxiv.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("The censorship claims are probably (greatly?) exaggerated but nobody can deny the eventual results!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("The “concern” letter to the NSF (Sep 08, 2017) is really digusting!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c50325410d148ffe4b704cb2cc9c8cb9a485d69bbb5abe58968088bf82541c5e-984693a4fee51e69f2ff1e079f7ddff01187b463c217de547935d3f5e4b9804b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maxie Schmidt")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504751")[#strong[#text("Maxie Schmidt")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("On a somewhat unrelated note, I recently had Jeffrey Shallit reject an already accepted and revised version of one of my manuscripts from the Journal of Integer Sequences essentially for irritating him too much in the process. It was reviewed well (one of my proofs was called “elegant” by the referee) and was missing only one reference to an obsolete, and very much non-central, asymptotic bound of which I had only cited the classical version of from Hardy and Wright (an editorial oversight brought on only by his instsistence, mind you). My adviser finally told me to stay away from that “rag” and not pursue publication there again. Editorial games and BS are apparently part of the standard process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samuelfhopkins")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504753")[#strong[#text("samuelfhopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("As of now you can actually still see the article hosted on the NYJM website: ")#link("http://nyjm.albany.edu/j/2017/23-72v-orig.pdf")[#text("http://nyjm.albany.edu/j/2017/23-72v-orig.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504756")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("Even better, the journal’s page for the article now displays a completely different paper ")#link("http://www.emis.ams.org/journals/NYJM/j/2017/23-72.html")[#text("http://www.emis.ams.org/journals/NYJM/j/2017/23-72.html")]#text(" but the “view” leads to a PDF of Hill’s paper :))")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("Why not give a reference to Hill’s account of events? ")#link("https://quillette.com/2018/09/07/academic-activists-send-a-published-paper-down-the-memory-hole/")[#text("https://quillette.com/2018/09/07/academic-activists-send-a-published-paper-down-the-memory-hole/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c9b86135da7f82fc7af09e74e8e56c1332d997ad463a1a7ccbeacced8f52387-2b78717866a7029ca8aa6f6b8ce3c5ec5b5d1be3b2d9c06215a6a798cb0b1fc8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lubos Motl")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504760")[#strong[#text("Lubos Motl")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("Not to mention five other presentations that you may find in an article if you Google search for “Electronic tools make it easier for dishonest SJW terrorists to perform Stalinist purges”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504779")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Clearly written and very detailed account !")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504763")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Dear Terence, this is BS. This is really a case of censorship due to hysterical feminists. I understand you want to protect your “distinguished lecturer”, but is it really academically honest?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504921")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("It seems that courage is lacking in the field of mathematics. I suppose that is to be expected when one is not truly an independent scholar but gets a weekly paycheck and is afraid to lose their job.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504922")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("“Hysteria”? Really? Are you that threatened at losing your male privilege? Seriously, you need to learn something about the world.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John T")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504940")[#strong[#text("John T")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("There could be only two points of view on this matter – mine and the misogynistic one! Am I right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504950")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")])]

#text("No…you are engaging in a ")#link("https://en.wikipedia.org/wiki/Straw_man")[#text("https://en.wikipedia.org/wiki/Straw_man")]#text(" tactic.")

#text("I am simply observing that: dismissing women as “hysterical” is simply textbook misogyny.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02efdef524cad64369a37c6c558083a4b17f340f4f9bcc80e705833046916a93-df5e9e7e2e7db5f0f14b5688af3b87472857959e47d341f3b79893937d9ee595.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthias")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504765")[#strong[#text("Matthias")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("The paper itself is pretty bad to be honest. No idea why it was accepted in the first place. He made way too many assumptions and the math is not deep at all.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caaa122b6b19e620162907ea3abd2ed1d318a79f9b2e56be9b3bdf7456e9c8a3-d46d8e8e4716a12761a2c0a708d5d6df927d3cae3d483ac03d1a975b16094cef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504766")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Don’t worry if you have no idea why it was accepted, the referees have one, and it is sufficient for the purpose of the debate.")

#text("The question here is not about being accepted despite your very personal appreciation of what should be accepted or rejected but being rejected after having already been accepted due to severe lobbying. In short: is the behavior of Mrs Wilkinson (who called her daddy to censor the article she didn’t like) moral or not ?")

#text("As Hardy Hulley pointed out, this is “a clear case of ethical misconduct”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504769")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("@Anonymous:")

#text("1. “Dr. Wilkinson” or “Professor Wilkinson”, please.")#linebreak()#text(" 2. Please stop all of this misogyny … little is more distasteful than bigotry hiding behind indignant cries of “free speech”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504773")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Indignant laments from gender theorists are worse. And this is really an academic freedom issue. We are in presence of a blatant case of dishonesty, or worse, fraud.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504835")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("@Marshall Flax: I was total by a mathematician from U Chicago that they prefer being addressed by “Mr” or “Mrs”, not “Dr.” or “Prof.” something. The reason is that people are respected and honored by their knowledge, not a title.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504843")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("Isn’t it curious how male academics, who for centuries jealously guarded their titles, now eschew them … now that they would have to share those titles with women.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/644708a37ad48d1e5cbd2d36dedfa9c0ff955e0805dc868d5e897da67e7b7dc7-94d2ea3a8a07e14c36ae8110096e78c755a5494a0ae9d746642939e3495301d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of curious")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504844")[#strong[#text("curious")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("I too prefer my name and it has nothing to do with sexism. In reality people worship money and it is better to be in the veil of anonymity if you are poor than be known for some arcane knowledge but with struggling life. Your accomplishment is for yourself. Not for the world to see.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2409836028fe38b2e0ffc9a72f6f9573bc0be1a802a565166f492f3dae937b73-12f3ca89a63da3eff3ec2fe23ff22c43fb52ef61fc9c63d337c039da9b229ad8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#emph[#text("Don’t worry if you have no idea why it was accepted, the referees have one, and it is sufficient for the purpose of the debate.")]#emph[]

#text("That’s not sufficient. What’s emerged is that the editor who approved the piece rushed it through (3 weeks to publication!) and solicited referee reports from referees without relevant expertise. Indeed, if you look at the discussion on Gowers’s site, you’ll see a consensus among the actual mathematicians that the paper does not constitute research at the level appropriate for that journal (or even any research journal; “undergraduate applied math homework” is one commenter’s characterization).")

#text("Providing a check on abuses of the review process is an appropriate function of the editorial board, and as more evidence comes out, and more mathematicians examine the paper in question, it’s become clear that there was an abuse of the process in this case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504993")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Well, tell your husband and your daddy. We have to remove this unenlightened paper")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c9b86135da7f82fc7af09e74e8e56c1332d997ad463a1a7ccbeacced8f52387-2b78717866a7029ca8aa6f6b8ce3c5ec5b5d1be3b2d9c06215a6a798cb0b1fc8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lubos Motl")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504777")[#strong[#text("Lubos Motl")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("I have been thinking about the greater variance issues for decades and I was well aware of this explanation that Hill (and his removed co-author) made nearly rigorous. It’s obviously true. Let me rephrase it in plain English:")

#text("It’s assumed that women only pick the “best” – according to some quantity X percent of men as partners where X is (much) smaller than 50, let’s assume. On the contrary, men are OK to date women from the best Y percent where Y is above 50 or at least greater than X.")

#text("How will natural selection work? The mean value of the quantity determining how “good” the people are can’t be changed easily. What Nature may adapt is the variability of the quantity. Subpopulations of men and women may allow genes that make the variability greater or smaller. How will the male and female genes do it given the natural selection with the asymmetry described above?")

#text("Genes that increase the variability of men will be favored because in more variable male subpopulations, there is a greater chance to get the top 2% etc. man somewhere. So when comparing the success rate of a highly variable and less variable population of men, the higher variability subgroups of men will win because the lower-variability will generate near-average men which isn’t enough.")

#text("On the other hand, with my numbers, near-average women are enough to find men, and that’s why Nature will try to suppress the women’s variability. The subpopulations of women with “smaller variability” gene will win because they will have fewer losses – fewer women in the bottom 10%, for example.")

#text("It’s obvious that at the end, the comparison of the selectivity (demands) imposed by women and men will be inversely correlated with the standard deviations of the distribution. The less demanding (picky) sex will have a greater distribution, because the other sex (women) is more picky, and vice versa.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23971af69a0f9d9c5e96acce31af3b5eba6a9e6c0f49bb2e94d390488a2e91ca-bfb0a0d1d38974927544e56f985a09632551cee85b1d5296e6c70a2a923e7a1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504778")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Since men choose women “locally” from their subpopulations, 10% of women would be left-out locally, not from the global population. There is no global competition of women in this way. On the other hand, I could imagine that throughout history having Alexander the Great in your mix would be advantageous to the subpopulation when competing with other groups, even when the average is the same between groups.")

#text("Is the variability of a “gene” such a strong property that the quality of the gene can not be selected only “upward”? In other word, to gain at the top, do we have to accept gaining near the bottom?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b831948beb823689ba0a647cc48c61e44a02a69d58264d3f22ab875de719c9c2-3ceb6cae4e3fdc833e2ff1813b1e98b7b52371a999d4a0fbca9aa161e936fb44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander SHEN")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504786")[#strong[#text("Alexander SHEN")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Still IMHO it is far from obvious that there are genes that influence the variability but there is no gene that influence the average. This assumption should at least be formulated explicitly in the paper (and if there are some experimental evidence, ideally it should be discussed also)…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b294d8b015dc4407c52d2f9e6a9cf2ca43ed1db1a0a9cd78ad19b1233b99a028-70acecc961b464b3b206fc2527897f86e41bce0f183478ea6149a010f441ce9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504797")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Of course there are genes that influence the average! Does anyone seriously believe there is no genetic basis for intelligence (at this point, they have found actual genes).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b831948beb823689ba0a647cc48c61e44a02a69d58264d3f22ab875de719c9c2-3ceb6cae4e3fdc833e2ff1813b1e98b7b52371a999d4a0fbca9aa161e936fb44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander SHEN")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504819")[#strong[#text("Alexander SHEN")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("But then how this theory explains why the frequency of very unattractive individuals (as well as the fraction of very attractive ones) increases?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf57fcf110d761abda41e251121cc62f56d824d2cb0518451d6160b2f1f02494-50f0baebdaae8a6d0207c0124e8752a3dbbffbe6dabd7b970247de8e041b861f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("“they have found actual genes”")

#text("Actually they have not done so convincingly and the problem with GWAS studies has a very interesting mathematical angle. They tried to better with GCTA, but failed to address host of remaining mathematical problems and leaps in inference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/600cac6a2213e2ecd8e9369efa64822afd059fdab30624daf54ce9c4560a564f-0e4052fd77d9daba3f76579db15ef956ed7b921120d57ebd591286301b4a5c3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ALT RIGHT UILLEANN PIPER")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504910")[#strong[#text("ALT RIGHT UILLEANN PIPER")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("In a trivial sense, there is a genetic basis for intelligence:No genes….no brain. Genes are required for brains to exist. However, I think your larger point is that children should be given an IQ test….followed by an indelible stamp on their forehead. But what is the point of doing this?")

#text("Well, here is the answer:IQ tests function as a tracking system. A tracking system that sorts the US White Working Class into canon fodder for the Zionist-Neocon Empire=Greater Israel!!! IQ tests serve no other purpose than to provide Native Born White Working Class Youth canon fodder for the Israelie owned POTUS Hillary Clinton….POTUS Kamala Harris……or POTUS Donald Trump.")

#text("IQ test scores and correlations with genes research has this much scientific-theoretical depth:0. For the enthusiasts of this scientific sewage, it is purely a economic resource allocation problem:track the NATIVE BORN WHITE AMERICAN WORKING CLASS…..voted into a White Racial Foreigner-White Racial Minority within the borders of California by Professor Tao’s highly racialized Han People…….into the canon fodder occupation for OUR FRIEND ISRAEL!!!")

#text("This is an Alt Right perspective on this matter…..")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504822")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("@Alexander SHEN: you are beating a straw man. Nobody argues that “no gene influences the average.”")

#text("You probably mean “there are genes (or other inheritable structures) that influence the variability but not the average”. Though there might be OTHER genes that do influence the average.")

#text("A physical implementation of this feature is a different story. I ignore whether such an effect can be caused by a single gene. Seems to be well known that an effect can be caused by distribution of genes on chromosomes.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b831948beb823689ba0a647cc48c61e44a02a69d58264d3f22ab875de719c9c2-3ceb6cae4e3fdc833e2ff1813b1e98b7b52371a999d4a0fbca9aa161e936fb44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander SHEN")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504823")[#strong[#text("Alexander SHEN")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("If there are other genes that influence the average, the selection will also increase the frequency of them, so the effect that the conjecture claims to explainl (i.e., the prevalence of males at both ends of the spectrum) could disappear…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("> the selection will also increase the frequency of them, so the effect […] could disappear")

#text("Yep, it could disappear. Or it could not. It would depend on the physical implementation of the whole mechanism. You can imagine models (at least some *artificial* models) with both types of behavior. The authors focus on the situation where one factor is dominating and the others are negligible. Yes, they intentionally simplified the model to make visible one specific effect.")

#text("You claim that the model is too naive to be realistic. This is an arguable point. The rule of thumb is that in biology you can eventually find a supporting example for *any* conceivable model. (Though I am not saying that every model deserves to be studied; this is a matter of taste to a certain extent.)")

#text("But I am afraid, our thread of discussion is inappropriate here. This is a story about editorial boards and diversity committees, not about pistils and stamens.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504793")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Thanks for the summary, Lubos Assuming it’s a fair summary the paper does look non-deep, as I think the key idea could be explained to a typical 12 year old:-)")

#text("Then again maybe I’m missing something, as I don’t understand why the hypothesis allows Y to be “…above 50 *or at least greater than X*”; to me, the argument which follows looks invalid unless Y > 50.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33580c8f90bc8a2e73990113f8eb7733ab7c63dd855764dc0a968ffd307a6c12-283b0a938ffcea770e3fb257ef25a501ff385a7c010f64db75bdd08e6992a192.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wuanqi")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504799")[#strong[#text("wuanqi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("My understanding is that the genes of the offspring, rather than the parents, drive the change in distribution. The selection argument would therefore explain variance hypothesis only if at least one of the following holds:")#linebreak()#text(" 1. sons tend to inherit their father’s genes, whereas daughters tend to inherit their mother’s.")#linebreak()#text(" 2. average parents tend to have daughters whereas exceptional parents tend to have sons.")#linebreak()#text(" None of above conforms to our common sense. Am I missing something here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504818")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("Sex-linked expression.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504991")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("The original journal was not intended to be for trailblazing publications. Actually it pretty much was for cute toy models such as the one of T. Hill and co. but SJWs had to take it down because there’s only one point of view allow in academia.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504772")[#strong[#text("On the recently removed paper from the New York Journal of Mathematics - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")]

#text("[…] by /u/ReginaldJ [link] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/001285b92333340239a104e427924550a420acf5d064394650c5220328c739c2-ce664b615b465d4326e554bc2f60928cec7e16c8318c0b52d6d2eb640b74e646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jake")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504774")[#strong[#text("Jake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Igor Rivin, one of the editors involved, has some ideological skin in the game: ")#link("https://twitter.com/McLNeuro/status/1037175304811364352")[#text("https://twitter.com/McLNeuro/status/1037175304811364352")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e786ec97cadc0d311e6f03f8d67fc8f168281bba17724f6c1b0bd49d048f5d7e-be7a6dc897f921b5a935604d9969612a572e9a3da4ddcb02f11329ff6572da13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexsongahn")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504845")[#strong[#text("alexsongahn")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("Wow, I did not know this. This is an especially important piece of context, since Hill specifically credits Rivin as the editorial force behind his paper’s acceptance to NYJM.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504995")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("It shows Igor Rivin wants mathematician to do mathematics and doesn’t take kindly when leftist impose their ideology using women, minorities and immigrants as tools.")

#text("Go Rivin! GO!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("But ")#emph[#text("Women In Mathematics")]#text(" are not ideological. I think one of them has a conservative father (so tolerant). One of the complaints came from the Chair of Diversity and Climate. I’m sure ")#strong[#text("they")]#text(" are not ideological.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30a9f9b1621abd7b04ca420171aed30e91677989bb7de01be4c0c07125fda1aa-e9a2701704eead7eabed2961af49f1c84539a18fc9b0d03fa0dc12f18b164224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fausto di Biase")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504775")[#strong[#text("Fausto di Biase")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Some issues with the editorial procedure have also appeared recently when the Editors-in-Chief of EMS Surveys in Mathematical Sciences have resigned after a certain paper was published in 2017 (Volume 4, Issue 2). The editorial board issued the following unusual statement:")

#text("begin quote")

#text("It was a serious mistake to accept it for publication. Owing to an unfortunate error,")#linebreak()#text(" the entire processing of the paper, including the decision to accept it, took place without")#linebreak()#text(" the editorial board being aware of what was happening. The editorial board unanimously")#linebreak()#text(" dissociates itself from this decision. It is not representative of the very high level that we")#linebreak()#text(" expect to see in our journal, which can be assessed from all other papers that we have")#linebreak()#text(" published.")#linebreak()#text(" Both editors-in-chief have assumed responsibility for these mistakes and resigned from")#linebreak()#text(" their position. Having said that, we add that this journal would not exist without their")#linebreak()#text(" dedication and years of hard work, and we wish to register our thanks to them.")

#text("end quote")

#text("More details about it appear in retractionwatch.com and in ")#link("http://www.ems-ph.org")[#text("http://www.ems-ph.org")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("The editors were sent to the Gulag. Yet Gowers and Tao still don’t see a problem with this")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504783")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("It seems that this unpublished paper is getting now many more readers and citations than it would get if published.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f313d0f17717b99b6a826431212b5fc44263ef73d7c0ad29e00b7319d251b0a3-d8df5ab409b4110053d440c583406d149efea2ec8a287aff1caf3fc46faf917b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504787")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("This would be “ironic” if the goal, as whiners such as Hill or Lubos would have us believe, were to somehow suppress ideas.")

#text("The reality is simply that papers below the standard of a journal (or simply on a topic not within a journal’s scope) shouldn’t have the imprimatur of that journal. Nobody is trying to stop other modes of publication.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504788")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Why is ironic in quotes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504798")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("“Ironic” was in quotes because the common use of the word actually isn’t actually consistent with the dictionary definition — it’s just that there isn’t a better word. See ")#link("http://www.isitironic.com")[#text("http://www.isitironic.com")]

#text("However, this is all a tangent. What I see here are lots of men who only jump into conversations when there’s a challenge to their place in the current social order. Textbook misogyny, despite their protestations.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504924")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Why exactly should men protect female competitors? Why should they not react in that way? Competitors are not to be protected but destroyed. Women want to compete with men, so now they will be dealt with the same way that men deal with men – ruthlessly.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/579459e5491bb4abe3a1f5e37f39c2387a2b8e0fc575c5fe6ff896b5aa513b59-8b5d2c7a46ef7585041c3fafcf9509b483eb88d06b0c47f2337390a3ed02fb1b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Yeah, right.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb5ff0275c4db4a1cd180a94ab81fcba1b401b18c5513c44a48ecf38f437b2e-b2d5e43b4a163c0397eec996bf16ad79d3c95ef44958fdead3d86ada76bb621a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lysenko is smiling – posttenuretourettes")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504785")[#strong[#text("Lysenko is smiling – posttenuretourettes")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("[…] say alleged but I happen to have corroborating first-hand knowledge) in this Quillette piece. The fields medalists are on it, but I humbly posit that a crucial angle is still missing. Has anybody tried to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/579459e5491bb4abe3a1f5e37f39c2387a2b8e0fc575c5fe6ff896b5aa513b59-8b5d2c7a46ef7585041c3fafcf9509b483eb88d06b0c47f2337390a3ed02fb1b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("What a terrible write-up from one of my heroes. Just a 5 minute Google search showed me Hill has been the subject of the PC police. Not like EVERY paper in these journals would hold up to the scrutiny of a thousand angry mathematicians.")

#text("The notion that any scientific that is mildly controversial needs to be policed is deeply unscientific. The fact that Terry Tao isn’t bothered by what happened to Hill is very upsetting.")

#text("Just a terrible event overall, but Terry thinks business as usual, and does not upset friends, so all is well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/001285b92333340239a104e427924550a420acf5d064394650c5220328c739c2-ce664b615b465d4326e554bc2f60928cec7e16c8318c0b52d6d2eb640b74e646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jake")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504792")[#strong[#text("Jake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Have you taken a look at the other stuff that gets published in NYJM, here’s a sampler: ")#link("http://nyjm.albany.edu/currvol.htm")[#text("http://nyjm.albany.edu/currvol.htm")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("The publication on NYJM came ")#strong[#text("after censoring")]#text(" as a very humble ")#emph[#text("epur si muove")]#text(", but then the Distinguished Lecturer had a talk with her husband")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504925")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Tao may be a good mathematician but a coward.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505492")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("Oh brave Citra you are pure lemon.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/021a1e886726e5d52389dd1a9c2f948f18f9625ac83311bf636207b36d92fb51-5dd25727b5c6d368eb9f1dc6b9f8c55a1f71b3fd82e4d5c6619ec0b7d946609a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous reader")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504791")[#strong[#text("anonymous reader")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("I think Prof. Wilkinson did something very wrong. As an unaffiliated third party, she meddled in the editorial process and attempted to change the format of a paper by amending it with Wilkinson-approved commentary. A paper published, specifically, in a non-academic section of Mathematical Intelligencer intended for controversial opinion pieces.")

#text("If she had criticized the paper or wrote her email after the paper was published, or offered up her own rebuttal of the paper to be published in the same opinion column, I wouldn’t have a problem with her actions. But she did not do that: instead, she harshly criticized the journal for the decision to publish the paper and insisted they solicit a from “experts in the field” to be presented alongside the paper, as a sort of ideological disclaimer. She’s attempting to force the journal to present the paper as *shallow*/*bad* rather than letting readers form their own opinion (note: I agree the paper is shallow, this is irrelevant).")

#text("Whether she wanted the paper to be retracted or not is not the point here. Attempting to control, as an unaffiliated party, the way in which an author’s paper is presented *is* silencing, it’s dishonest, and it’s an attempt to control the dialogue. Imagine if a lobby of pseudo-scientists demanded that every paper in support of vaccination be published with a corresponding “commentary” by “experts in the field” criticizing the findings of the paper and forwarding their own ideology.")

#text("Tao brings up an example of his paper from the Annals supposedly to show that this is standard process, but the difference is obvious: the people involved in Tao’s case were the editorial board of the journal itself, not some ideologically motivated third party.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504927")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("We must thank Mrs Wilkinson for bringing all this mathematical Lysenkoism to light. A paper that very few owuld have read has become front a center as well as the rotten feminist worm in the core of the academic apple.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4676b1cdbfa100430e39d56d83435fc1486018133d727eabfdde1f20159c2e40-5806d194885ac7196b2b5becf7a32c5e916c1ca4b49ba2ef24fe5deb47cf4ec1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Barvinok")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504794")[#strong[#text("Alexander Barvinok")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Some time ago I sent the following letter to the AMS:")#linebreak()#text(" ——")#linebreak()#text(" Dear Colleagues,")

#text("I’d like to draw your attention to the article")

#link("https://quillette.com/2018/09/07/academic-activists-send-a-published-paper-down-the-memory-hole/")[#text("https://quillette.com/2018/09/07/academic-activists-send-a-published-paper-down-the-memory-hole/")]

#text("I suggest that the AMS check on the facts in this article. If the allegations of intimidation of the authors, bullying the editors and expunging an already published paper from the archive are true, a serious injury has been inflicted on the profession and we should all try to repair the damage.")

#text("Sincerely,")

#text("-Alexander Barvinok")

#text("University of Michigan, Ann Arbor")#linebreak()#text(" ——–")#linebreak()#text(" My apologies if you already saw this in Prof. Gowers’ blog. I still believe it is the right course of action and count on the support of fellow mathematicians.")

#text("Since I wrote that letter, there were a few other developments.")

#text("There is a lively discussion on the merits of the paper; while I think this is certainly important, I would rather have it after it was ascertained that the authors and editors were treated fairly. For the sake of argument, assume that the paper is not that great. Having written some not so great papers myself, I don’t remember ever been invited to present my results in 15 minutes, after which prepared statements will be read and a “friendly discussion” will ensue, as is described in Prof. Hill’s article.")

#text("There is an important discussion on the peculiarities of the editorial process in the two journals. I find it perhaps more important to understand under what circumstances Prof. Tabachnikov withdrew his name from the earlier version of the paper. As follows from Prof. Hill’s description, a certain “persuasion” was applied to him. Together with some of the commenters, I’d like to know what kind of a persuasion was that and also the names of the persuaders.")#linebreak()#text(" Again, I don’t remember ever been persuaded to withdraw my name from a paper, however imperfect.")

#text("I read the rebuttals of Prof. Wilkinson and Prof. Farb. I tend to agree with some of the commenters that by and large, they do not contradict Prof. Hill’s")#linebreak()#text(" story, although present a different side of it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67b2ae308707056ca3870a45b59bc3c953d8c1e8e936bd459c699661d14e5309-3c09ed99129eee0576816d2126038784c64865d16c94bd3ea7a6a62a1ca215b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bannon entropy")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504795")[#strong[#text("Bannon entropy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Stir, stir, stir!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aac8d33b9992468c7aa37bf9e42d879f52394290757c965f5faf670279a823d3-7c9be481611ed5a9deb512431f80642927539d3a1350ed6935a7a35f65cf6702.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hardy Hulley")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504796")[#strong[#text("Hardy Hulley")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("I absolutely support the sentiment expressed above. I too think it’s important for the AMS establish the facts of this case and to ascertain what pressure was applied to the authors and the journal editors. Moreover, I completely agree that it is inappropriate to debate the scientific merits of the paper while serious allegations misconduct hang in the air.")

#text("There is absolutely no crime in writing an imperfect applied mathematics paper and getting it published — it happens all the time. Whatever scientific objections one has to the paper, they do not constitute adequate grounds to rescind its publication, so I can only conclude that the unprecedented decision in this case was based on ideology and pressure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504841")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("I 100% agree with your post,")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504820")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("I think the question is this. Suppose that as an editor, you’ve accepted a math paper. Then some people convince you that this publication would be (in some way) harmful to society. I think that if I believed this harm was beyond some bar, I would also hastily withdraw the paper. Imho, the present case was nowhere near any bar, and Terry’s example of some further comments discussing the results would have been a perfect solution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504800")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("This has happened at least once before. See ")#link("https://www.emis.de/journals/SWJPAM/vol2-03.html")[#text("https://www.emis.de/journals/SWJPAM/vol2-03.html")]

#text("Notice that the paper by James Harris was “withdrawn”. Why? Did James Harris withdraw it? No. It passed the peer review process. The reason why it was withdrawn was because the usenet newsgroup sci.math pressured the editors of the journal to delete it after it was published electronically, just like it was deleted today in the case of Hill.")

#text("But the difference between this case and Hill’s case is that Harris was considered by mathematicians on usenet sci.math to be a “crank”, not an established mathematician like Hill, so they believed they were doing everyone a favor, saving everyone from having to read Harris’ long lost work. Nobody protested their activism except James Harris. His claim was that his paper passed the peer review process so they had no right to take it down.")

#text("If mathematicians on sci.math had vigorously defended James Harris in 2003 instead of continuously ostricizing and embarrassing him on sci.math, maybe editors of math journals would have got the hint that the practice of deleting published papers online is unacceptable.")

#text("I don’t know what ever became of James Harris, but I really hope he is laughing now at the fools in the math community who didn’t have the wisdom to defend him when they should have.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/001285b92333340239a104e427924550a420acf5d064394650c5220328c739c2-ce664b615b465d4326e554bc2f60928cec7e16c8318c0b52d6d2eb640b74e646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jake")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504858")[#strong[#text("Jake")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("James Harris was a crank tho. (He’s got a blog, one can find it with minimal effort, content doesn’t seem too different from what I remember from the usenet days).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504904")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2018")])]

#text("James Harris may have been a crank, but he was also more importantly a human being. Lessons from history are that if you start labeling people to justify treating them badly, then eventually people will start treating others badly even without labeling them, which is exactly what happened here.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John T")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504801")[#strong[#text("John T")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("The real issue is why would an editor in a math journal choose to not only publish, but even request this paper, which as everyone seems to attest has very little to no mathematical merit, besides in order to advance his clearly racist views? This is the real issue.")

#text("As we all know there was plenty of anti semitic “science” during the nazi regime, as there is plenty of anti black “science” and many kinds of racist views which masquerade as science.")#linebreak()#text(" The author could have published it on his blog and in the arxiv, but they wanted a seal of approval from the field so that the article would be taken more seriously by people who don’t read it, and would not read the responses to it, but could quote it as published in a serious refereed journal. He got it through an editor who seem to have wanted himself to promote the same racist views, and because the way math journals work, they are not set up to deal with editors who misuse their capacity to advance their racist views (or political views as people seem to refer to them).")

#text("How should have the journal, and the field of mathematicians, react to the use of a position as an editor to advance racist views which have little to do with what the journal publishes? They are not set up for this. (Now all journals should prepare for such eventualities.) Indeed, the thing to do would be for the journal to announce that the editor has been removed; to retract the paper; and clearly explain the situation why it was retracted, and how it was accepted in the first place. Given that the other editors are mathematicians who only want to do math and not deal with political turmoil they chose what seemed to them easier – to just remove the article.")

#text("The field of mathematics has some decisions as well. Given what seems as the obvious racism of the editor (why else would they desire to publish this paper as it is not for its mathematical merits), one may assume that the group of people he is racist against have not been treated the same way by him in the classroom, in decisions on grants, on publications, or any place where he had a position of power. Now that we know, should he still hold on to his power?")

#text("Wikipedia states that the editor is a fellow of the American Mathematical Society. Should he be removed from it? Should he be on committees in general given his apparent racism?")

#text("The editor, Igor Rivin, can explain himself. If it is not because of racism, what made him ask for this paper and have it published in a mathematical journal where, from most opinions here, it clearly doesn’t fit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b294d8b015dc4407c52d2f9e6a9cf2ca43ed1db1a0a9cd78ad19b1233b99a028-70acecc961b464b3b206fc2527897f86e41bce0f183478ea6149a010f441ce9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504803")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Oh, and also, anonymous trolls calling for lynch mobs on people they disagree with brings back not-so-good memories.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504998")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Prof. Rivin, Keep fighting the good fight!")#linebreak()#text(" These people want to declare any kind of disagreement illegal. I read the paper. It was ")#strong[#text("very decent")]#text(" for the math. intel. and feminist couldn’t allow other points of view to be “peer review” so they destroyed peer review entirely")

#text("#MathGate")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Amie is that you under a pseudonym or is it your father? Certainly with a bit of imagination anything could be labeled racist. Existence of men for example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504814")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("Misogyny is a serious problem, but I can’t help but laugh when someone posting as “Anonymous” questions the identity of another poster.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John T")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504836")[#strong[#text("John T")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("Real problem are those who think that intimidation and bullying is an acceptable form of debate in science.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504999")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("We are discussing the destruction of careers for disagreeing with SJWs. I think anonymity is warranted. At least until I become a ")#strong[#text("Distinguished Lecturer")]#text(" and I have my father and ")#strong[#text("husband")]#text(" in influencing places to cover my back")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b294d8b015dc4407c52d2f9e6a9cf2ca43ed1db1a0a9cd78ad19b1233b99a028-70acecc961b464b3b206fc2527897f86e41bce0f183478ea6149a010f441ce9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504802")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("This is complete gibberish. First, and foremost, women, as far as I know, are not a race, and neither are men. Secondly, Hill’s paper proposes a mathematical model to explain a plethora of existing data – an inherently non-political activity. Would you view a paper which attempted to explain why the average man is taller than an average woman as sexist (oops, I mean racist)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Igor gets called racist and responds by pointing out that women are not a race, and he gets many dislikes while the accuser of racism gets double the number of likes as dislikes? I thought mathematicians were smarter than this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("the ratio between the numbers of likes and dislikes is time-varying …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John T")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504807")[#strong[#text("John T")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("So your reply is that I should have said misogynist or biggot rather than racist?")

#text("If the paper should lead to a conclusion of men superiority, with almost no mathematical content, in a math journal, then yes.")#linebreak()#text(" And if the referees who reviewed the paper support the claim it should be published in a such a journal – they should come out publicly to explain their opinion, which seems strange to say the least to other mathematicians. Of course, as the editor, you chose them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aac8d33b9992468c7aa37bf9e42d879f52394290757c965f5faf670279a823d3-7c9be481611ed5a9deb512431f80642927539d3a1350ed6935a7a35f65cf6702.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hardy Hulley")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504809")[#strong[#text("Hardy Hulley")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("You’re jumping the shark, mate. The paper makes no claim about male superiority, or any such nonsense. All it does, in a very abstract setting, is try to identify a biological mechanism that could explain the empirical fact that males (in many species, not only H. sapiens) tend to exhibit greater variability in many traits — the so-called Greater Male Variability Hypothesis (GMVH). I call it an empirical fact, because it is has been widely reported across many different species and appears to be statistically robust. That’s all the paper does. Of course, you may not like their model (as a simple reduced form model, I don’t think it’s too bad — I’ve certainly seen worse in the published literature), but the empirical feature it attempts to explain is hard to deny. Of course (and this is where people get emotional), greater male variability also appears in things like standardised mathematics tests (several studies have documented it using the PISA data, for example). So, it could potentially explain some of the gender imbalance in mathematics departments, for example. But the significance of the empirical results in this case is less clear, so nobody is trying to say anything definitive. Nevertheless, there is no harm in somebody trying to develop an explanatory model for the GMVH.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e583ea2ae5d45f76ff997115dd55f0c5e7655abb2a110be352142545aaae7e2-d5f96231fa08bf46f054a85acbdc2cb2d5457927832c0e4a2bafc30337ac8c04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willard")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504824")[#strong[#text("Willard")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("Both Igor and Hardy have jumped over all the words where John stated at least one of the issues:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The real issue is why would an editor in a math journal choose to not only publish, but even request this paper, which as everyone seems to attest has very little to no mathematical merit, besides in order to advance his clearly […] views?")
]

#text("To that effect, Igor hasn’t provided any evidence of his claim that “Mark Steinberger, the NYJM’s editor-in-chief, was also very positive,” as Theodore reports in his hit piece at Claire’s.")

#text("Do we know who was picked to write the reports and who made the picks?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf57fcf110d761abda41e251121cc62f56d824d2cb0518451d6160b2f1f02494-50f0baebdaae8a6d0207c0124e8752a3dbbffbe6dabd7b970247de8e041b861f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("We don’t know who wrote the reports. Benson Farb in his rebuttal to the allegations states that editorial board was also deprived of their contents for an extended period of time.")

#text("As to who made the pick, Rivin indirectly admitted in a megathread over at Gower’s place that he solely handled the paper for NYJM.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504839")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("Such incidents show the necessity of establishing a “well-defined” universal comprehensive “code of ethics” for the editorial boards of all scientific journals!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e583ea2ae5d45f76ff997115dd55f0c5e7655abb2a110be352142545aaae7e2-d5f96231fa08bf46f054a85acbdc2cb2d5457927832c0e4a2bafc30337ac8c04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willard")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504808")[#strong[#text("Willard")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("> women, as far as I know, are not a race")

#text("Igor’s view on men and women relationships may deserve due diligence, e.g.:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("This is what you're dealing with here. ")#link("https://t.co/j2gxbHmQK6")[#text("https://t.co/j2gxbHmQK6")]

#text("— Lior Pachter (@lpachter) ")#link("https://twitter.com/lpachter/status/1037183463995072512?ref_src=twsrc%5Etfw")[#text("September 5, 2018")]
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504932")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Empowering women was the mistake of many former civilizations and symptomatic of their downfall. Once it starts it is irreversible and destroys the host culture. See JD Unwin “Sex and Culture.” And Glubb’s “Fate of Empires.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e583ea2ae5d45f76ff997115dd55f0c5e7655abb2a110be352142545aaae7e2-d5f96231fa08bf46f054a85acbdc2cb2d5457927832c0e4a2bafc30337ac8c04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willard")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504958")[#strong[#text("Willard")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")])]

#text("Res ipsa loquitur, Citra. It goes downhill since the Garden of Eden, or at the very least since Phil Collins replaced Peter Gabriel.")

#text("Please, do manspread your hypotheses at Lior’s:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://liorpachter.wordpress.com/2018/09/17/mathematics-matters/")[#text("Mathematics matters")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee221714b32d3fdc81ff8ec2f4048dc136db6eaa08603cb88d98cc4b317ae9cd-9dc6b732388bfca69d925a9ea33e37ea8cf8cd65a5dd45db303b767b0b452f39.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Konstantin")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505234")[#strong[#text("Konstantin")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("Dear professor Rivin,")

#text("I’m afraid the claim by the authors, and by yourself, that a paper “proposes a mathematical model” is simply untenable. A mathematical model is something that takes as an input some assumptions, and, via mathematical reasoning, draws conclusions that are not immediate from the assumptions without said reasoning. If the conclusions are immediate from the assumptions anyway, then there is no hope mathematics can contribute anything to our understanding of the problem.")

#text("In the paper, on defines one of two probability measures to be “more variable” if its proportion in any right tail (not containing their common median) is bigger than for the other measure. One calls the opposite sex “selective” if only the individuals in such a tail get to reproduce. And then one deduces (Proposition 7.2) that if the opposite sex is selective, then, in a more variable sub-population, a bigger proportion reproduces. This is an immediate logical consequence of two definitions; no mathematical reasoning whatsoever is needed to reach this conclusion.")

#text("We can conclude that what we have here is not a mathematical model at all, but rather a layman’s argument dressed in mathematical terms just to give it more credibility. This happens a lot in social sciences (see the recent Notices article “Does diversity trump ability?”), but I would expect any true mathematician to despise it as a fraud. The fact that you and professor Tabachnikov, who are both respected mathematicians, subscribed under an “application of mathematics” of this kind is simply beyond my understanding.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b294d8b015dc4407c52d2f9e6a9cf2ca43ed1db1a0a9cd78ad19b1233b99a028-70acecc961b464b3b206fc2527897f86e41bce0f183478ea6149a010f441ce9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505258")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("This blog post is especially cowardly. That it is anonymous is bad enough, but the commenter also implicitly accuses not only Hill of not being a “true mathematician” since he does not “despise [his own paper] as a fraud”, but it also implicitly accuses the two Editors-in-Chief who accepted it, one of whom, Mark Steinberger, just passed away a week ago. Tough for Mark to defend his decision.")

#text("In regards to the commenter’s argument that the paper in question is not a true mathematical model, here is how Ted Hill responded when I sent him the posting from Tao’s blog:")

#text("“The commenter is missing one key conclusion in the paper, a conclusion dealing with what is undoubtedly the single most important distribution in the social and biological sciences (and perhaps all of statistics) – the normal distribution.")

#text("The paper includes, as a special case, a proof that")

#text("If the distributions of the populations are Gaussian and the opposite sex is non-selective, then a sub-population with smaller standard deviation will have a bigger proportion reproduce.")

#text("Yes, the argument is simple, that is why the paper called it “elementary”, but if one thinks the argument follows “immediately from the assumptions”, please ask them to challenge their social science and biology friends (and perhaps algebraists who do not remember undergraduate probability) to provide a rigorous and complete proof. Perhaps the Gaussian example should have been emphasized more in the paper, since that appears to fit the commenter’s definition of a “mathematical model”. But it is a model that has already been welcomed by researchers in the field.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee221714b32d3fdc81ff8ec2f4048dc136db6eaa08603cb88d98cc4b317ae9cd-9dc6b732388bfca69d925a9ea33e37ea8cf8cd65a5dd45db303b767b0b452f39.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Konstantin")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505270")[#strong[#text("Konstantin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("Gaussian distributions plays no role for the conclusions of the paper. This is no surprise, since on page 4 the author concedes that: “The actual magnitudes of these desirability values are assumed to have no significance, and are used only to make comparisons between individuals.”")

#text("Thus, it is not even meaningful to talk about them having Gaussian or any other specific distribution.")

#text("I agree with Hill’s judgement about “social science and biology friends”; that actually was my point: for some readers, the technical content of the paper will be non-trivial, and because of that they might be misled to think that this maths plays some role in corroborating the conclusions of the paper.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#text("Your cote comes from a particular example. Very disingenuous. Also, let’s keep in mind that ")#strong[#text("almost all of climate science is compose of models such as this one.")]#text(" The issue are not the quality of the mathematics or the conclusions or the hypothesis. It is the exploration of alternative points of views!!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504810")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("It is scary to think that if you have a daughter in math that Igor Rivin would have an impact on her career.")#linebreak()#text(" He says he is on the editorial board of several journals. We deserve to hear from these journals if they are keeping him on their board.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504933")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Academia bends over backwards to facilitate females at the cost of male students.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60056590f059b00f9f42c9c1bf34ed4f8771eb624e77df9de9e6dd6d0aa6011b-78850c89d7b74cd5cd27061ecf21a6ed5f57b3513f40a85c231cc68842fb4cf6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robin Saunders")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504815")[#strong[#text("Robin Saunders")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("On the question of peer review and its (ab)uses, I’ve seen it argued that the entire system – even with open journals – is obsolete, and the process of validation itself needs to be open in order to be truly effective. See e.g.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://chorasimilarity.wordpress.com/2016/02/11/open-peer-review-is-something-others-should-do-open-science-is-something-you-could-do/")[#text("Open peer review is something others should do, Open science is something you could do")]
]

#text("and other related posts on that blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf57fcf110d761abda41e251121cc62f56d824d2cb0518451d6160b2f1f02494-50f0baebdaae8a6d0207c0124e8752a3dbbffbe6dabd7b970247de8e041b861f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("Also of note is that several areas of computer science already embraced such policies, and a choice of readily available software platforms exist, for example the ")#link("https://openreview.net/")[#text("https://openreview.net/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504851")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("Validation is something anybody can do, provided that the author gives the means (programs, data, experimental settings etc). It is not easy to validate or reproduce or check an author’s work. Nobody said science is easy. Nobody said that for each research work should be spent time and effort to validate it. However, validation is the main part of the scientific method, which works by selecting those research ideas which can be checked independently. The rest is (others) opinion(s), which may very valuable for all kinds of social or professional or economic goals, but not scientific, unless validation means are provided by those who express these opinions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504825")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("It would be interesting to have Dr. Tao add some comment. After all, he initiated this discussion!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f7a75de6ac8bc5fe5c2ef319e2bfce45ca0ccd07995a5d2bef5366997134f41e-b1ca483dce7e27fd9b99297ba72b09bf1d2524ca34174478df2f403de2f316fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John McAllison")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504834")[#strong[#text("John McAllison")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("I think the problems here are the perceived lack of impartiality from the author(s) and their venturing into the field of evolutionary human anthropology, despite not holding a relevant academic qualification in this area. To me, it’s very borderline whether the paper should have been published in Mathematical Intelligencer, given its aims:")

#text("“The Mathematical Intelligencer publishes articles about mathematics, about mathematicians, and about the history and culture of mathematics. Written in an engaging, informal style,* our pages inform and entertain a broad audience of mathematicians and the wider intellectual community.")

#text("We welcome expository articles on all kinds of mathematics, and articles that portray the diversity of mathematical communities and mathematical thought, emergent mathematical communities around the world, new interdisciplinary trends, and relations between mathematics and other areas of culture. Humor is welcome, as are puzzles, poetry, fiction, and art.”")

#text("The paper, assuming it’s based upon the one submitted to Arxiv, is already making claims in the title: “An Evolutionary Theory for the Variability Hypothesis”. Really? A mathematician can do this, despite having no formal training in this area? Straight away, It doesn’t appear to fit into the culture of the journal’s aims IMO and worse, is possibly making a crackpot claim.")

#text("The paper just appears out of place in the journal, given its aims, and that’s probably all there is to it. Yet some are making it into a crisis of censorship within the mathematical community, forgetting that every society has its rules regarding censorship and “free” expression.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f7a75de6ac8bc5fe5c2ef319e2bfce45ca0ccd07995a5d2bef5366997134f41e-b1ca483dce7e27fd9b99297ba72b09bf1d2524ca34174478df2f403de2f316fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John McAllison")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504900")[#strong[#text("John McAllison")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2018")])]

#text("Take a look at this video by an expert in the field of behavioural biology, Professor Sapolsky from Stanford University:")

#text("Gender and mathematical aptitude")#linebreak()

#text("It’s fascinating; he shows how the data implies that environment has far more of an effect than genetics on mathematical aptitude difference between the genders. I think this confirms my main point above, despite it being voted down by the majority, that the paper was probably rejected over its claim of providing an “evolutionary theory”, rather than a toy model showing how genetics can play a part.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505000")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#strong[#text(" The point itself is political")]#text(". It’s like writing a model to rebutte marxism and then complaining that the authors have a political bias. That is the issue. ")#strong[#text("Entire fields of academia have been politicised by leftist")]#text(" and when someone tries to start an actual academic conversation THEY ARE CENSORED")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505004")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Minimal standards for publication $\\neq$ censorship.")

#text("And to be fair, most of the comments on this thread unfortunately aren’t “academic conversation”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shamelessly anonimous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505009")[#strong[#text("Shamelessly anonimous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Because this is a political conversation not an academic one. Marxist professors are political. Having an alternatice point of view is perfectly legitimate")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ceb7cc9d05a91b6bbaf4a04dc533e4f45733b556fc8c88212e4fe161554a6d75-efee242069a28b60fdb871cba22cddfb2bc1b8f92895b17c106e416b81fad00f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of booboo")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504840")[#strong[#text("booboo")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("Is the Greater Male Variability Hypothesis established for number of blog comments? I see a lot of males.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504934")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("That is because there are LOT more males who are mathematicians than females. You didn’t know that?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of More Details")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504846")[#strong[#text("More Details")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("We now have Hill’s reply to the two statements mentioned in the post.")#linebreak()#text(" ")#link("http://www.tphill.net/DOCUMENTS/Hill_Statement.html")[#text("http://www.tphill.net/DOCUMENTS/Hill_Statement.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504849")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("I see that Dr. A. Wilkinson is becoming -quite deservedly!- famous.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf57fcf110d761abda41e251121cc62f56d824d2cb0518451d6160b2f1f02494-50f0baebdaae8a6d0207c0124e8752a3dbbffbe6dabd7b970247de8e041b861f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("Thenk you on the other hand for displaying why Leray had any reluctance towards you, why you don’t have any students, work at and odd place and emit stuff that is very hard to read, thankfully there doesn’t feel any need to do so any more.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504852")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("Interesting, where would you say in the world ranking of universities do the “odd” places start? Below top 10? or top 20? or?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf57fcf110d761abda41e251121cc62f56d824d2cb0518451d6160b2f1f02494-50f0baebdaae8a6d0207c0124e8752a3dbbffbe6dabd7b970247de8e041b861f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504853")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("Numerical analysis is not a match given his expertise. Despite being distinguished figure with large body of work in different fields he’s not even a member there, nor associate, but a “project-funded coworker”. This struck me many years ago already.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504854")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("Well, dear “anonymous” (I think I know who you are), the University of Vienna is not such an odd place. And Leray supported me immensely, he was not only a mentor but a friend.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf57fcf110d761abda41e251121cc62f56d824d2cb0518451d6160b2f1f02494-50f0baebdaae8a6d0207c0124e8752a3dbbffbe6dabd7b970247de8e041b861f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504857")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("Dear troubled Maurice, you can’t have any idea as I am from a very backwater, though neighbouring country. University of Vienna has a proper place for you in math department you curiously never were allowed to fill.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5570fffa6e38dc271183adfca46b8682e300c03bd7dba3df9bc6c6b3d524fbfc-aea91ccac64099717453275858aee1fc0532ca77e00bb0d0fbabe963a8c07b77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504948")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")])]

#text("Dear Anonymous, why do you have to attack MdG on such a low level? irrespective of your (and his) opinions on the matter, this is not how we should behave towards each other. The blog discussion ultimately revolves around the question of how we can reduce the amount of (verbal and other) violence and discrimination in our society — at least this should be our goal if we want to coexist happily. If we attack each other we damage this goal. The only way to achieve it is through empathy and respect towards everyone, even (and especially) towards people who hold different opinions than we do. Therefore, I would like to ask you to rethink your very personally insulting comments towards MdG — in my humble opinion they are nothing to be proud of.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25e793692152c602123194edf5011734f534b8f4d2f908e6e8b0411821b9c32-ac13efa8da07dd8e4277d7989a5c13986321140e63f30ca4cc4cb5b64941affc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Misha Shvartsman")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504855")[#strong[#text("Misha Shvartsman")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("that sounds harsh")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504935")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Very catty Mrs Wilkinson.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504856")[#strong[#text("Matematica pretestuosa - Ocasapiens - Blog - Repubblica.it")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")]

#text("[…] Dopo il tam tam sui social per amplificare gemiti e accuse di Hill, sono intervenuti matematici famosi. Terry Tao non entra nel merito del modello, ritiene false alcune delle accuse di Hill, e conclude: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504861")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("After reading Lubos Motl’s commentary on this, I have been thinking that this incident is a lot more serious than people realize. Suppose a professor was caught attempting to burn a book in a university library. Would Tao say, “I hope this problem can be addressed so it won’t happen anymore.”? Or would Gowers say, “I read that book and it was awful.”? I doubt it. But when the equivalent of an attempted book burning (or article burning) happened online, these were essentially their responses. These responses indicate to me that nothing is safe online, even arxiv.org.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9335fd4bcef2985981af47b0603b5feca94a106aede8b3e09e8ad9f2ee473c2-50779d79c5625973c133e2b4dbb9521d6f654926a5e0aed2c2a33fccd0f16d2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eli Rabett")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504865")[#strong[#text("Eli Rabett")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("Given that until recently most marriages were arranged by families and not driven by romance, beauty or compatibility of either party and certainly not on the romantic choices of women, this whole chain of assumptions seems a bit thick.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("So you want to claim that arranged marriages were mainstream for a substantial time on the evolutionary scale? And that arranged marriages are less selective towards men than the ones based on romantic choice?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1d906b79526997f4aaa517420d8693b049a3aa5a60d5d5125f1acb1327dee4-6b88e24bdc6e4a7f14047598235c736009293126c67a804338114f93909aece8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lol")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504877")[#strong[#text("Lol")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2018")])]

#text("What about claiming it was all rape? Do you want to claim rape was less selective towards rapists on geological scales?")

#text("Such claim clearly is not mathematics, and if “modeling” depends crucially on such then it isn’t either. It is laundering the claims with mathematics as “plausible” while just restating them without any corroboration from either mathematics or anything else but opinion.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504889")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2018")])]

#text("So you want to claim that using mathematics (i.e., deriving logical conclusions from given assumptions) in sciences is an act of laundering and should not be done?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1d906b79526997f4aaa517420d8693b049a3aa5a60d5d5125f1acb1327dee4-6b88e24bdc6e4a7f14047598235c736009293126c67a804338114f93909aece8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lol")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504909")[#strong[#text("Lol")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("You are making big leaps over what I said and qualified. We have applied mathematics fields built on consensus in the sciences, this said of mathematical biology. We have on the other hand fields like economics where mathematics just reflects the assumptions made. Notably there isn’t suitable field within applied mathematics for these, game theory graduating, or arguably having been pure from the start for example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504914")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("I would like to make your claim concise and precise. So you are saying that mathematical biology is not based on mathematics (i.e. making logical derivation from give assumptions) but instead on consensus (i.e. math symbols are used to express the consensus).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/625bcabf6bc7c1afb81fd07802123f6b2a15979bb9423196fae10ad7c65a39e2-04fb07b821adf0d2a1f099f4987923ed93db67c0d638c0400f758349dd33c4d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eli Rabett")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504884")[#strong[#text("Eli Rabett")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2018")])]

#text("Yes, and there is evidence for it.")

#link("https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0019066")[#text("https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0019066")]

#text("“Our phylogenetic results support a deep evolutionary history of limited polygyny and brideprice/service that stems back to early modern humans and, in the case of arranged marriage, to at least the early migrations of modern humans out of Africa. It is conceivable that marriage involved some level of arrangement, regulation, and reciprocal relationships from the very earliest inception of marriage-like cultural institutions. The presence of brideprice or brideservice as the ancestral human state may be interpreted as early critical components of regulated mate exchange. The very act of a male moving away from his kin and community (e.g., brideservice) is a tremendous leap from the insular patterns in other apes. It is an indication of negotiation between kin groups and the recognition of a continued set of obligations and reciprocal transactions (alliance) between the families. This, combined with the low prevalence of polygyny as the ancestral human state, suggests that there was a reasonable level of evenness to mate exchanges (low reproductive skew).”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504936")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Lot of bastardy went on.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504906")[#strong[#text("John McAndrew")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2018")]

#text("Craig, it depends upon the culture of the library, and the book and how compatible they are with one another. If the library was a children’s library and the book Lady Chatterley’s Lover; then the reactions of Terence and Tim would be appropriate IMO.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505001")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Mathematician, whether male or female, are not children. Despite what SJWs want us to believe. What you want to say is “if the book is conservative then yes burn it”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504990")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Agreed. It is worth reading T. Hill account of the facts on Quillette. He mention one of the activist was the Chair of Diversity and Climate. This to me seems that leftist have infiltrated academia and now being half conservative is enough to have your career ruined")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97d28670d589b1245e0d9f80c9f27be85522fa102ad805d781492987bcbe0f97-479fffa787999cfc4bb170095cfa126530e22a16aa674887f338fe46738b2e37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What we’ve got here is failure to communicate | Igor Pak's blog")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504866")[#strong[#text("What we’ve got here is failure to communicate | Igor Pak's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2018")])]

#text("[…] discussion on the very unfortunate Hill’s affair, which is much commented by Tim Gowers, Terry Tao and many others (see e.g. links and comments on their blog posts). While many seem to be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40ec03e55204b4c2ab9d280c49ee33b5afed0d0222e40f92c4460cdf1c7ac4f3-c9fe7e7b8951bcd4d57103bb3fdd368fbe86e749972e1c35f6bafe9533f925c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Just sayin")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504883")[#strong[#text("Just sayin")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2018")])]

#text("How comes nobody mentions that Hill’s erstwhile coauthor, SERGEI TABACHNIKOV, is an associate editor of Mathematical Intelligencer (see ")#link("https://www.springer.com/mathematics/journal/283")[#text("https://www.springer.com/mathematics/journal/283")]#text(")? That possibly sheds some insight to the initial acceptance of the paper in MI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504895")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2018")])]

#text("Here is the message I sent to a well-known US mathematician a moment ago, who seems -I emphasize: seems – not to have problems with Wilkinson affair: “Dear ***, you are a respected scholar, but you are beating around the bush, and I think you know it. It is true that you are an American, leaving in the US, and that you must be particularly careful not to risk reputation, so you have to be PC, and not contradict “the consensus”, Luckily enough, I am a European, and in Europe there is so much more freedom of speech and opinion than in the US… What we are talking about is a case of scientific and/or editorial practice, initiated by Dr. Wilkinson and her relatives. That’s all. Period. As an honest scientist, you should not defend the undefendable, unless you think certain political opinions prevail for the sake of the “greater good”. Of some people.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504896")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2018")])]

#text("Sorry for the typos….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cee7808c52d04db57f4745a1180915d00a2106c887395abdc3fc4bc50092e38-7f7adcc85b7f1df1784140381dd2726cc52a1a4c4f8f24ae8991ca63ee0b3faf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Citra")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504937")[#strong[#text("Citra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("Mathematical Lysenkoism.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504956")[#strong[#text("Mathematics matters | Bits of DNA")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")]

#text("[…] such as Timothy Gowers and Terence Tao are hosting discussions about evolutionary biology (see On the recently removed paper from the New York Journal of Mathematics, Has an uncomfortable truth been suppressed, Additional thoughts on the Ted Hill paper) because […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40ec03e55204b4c2ab9d280c49ee33b5afed0d0222e40f92c4460cdf1c7ac4f3-c9fe7e7b8951bcd4d57103bb3fdd368fbe86e749972e1c35f6bafe9533f925c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Just sayin")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504960")[#strong[#text("Just sayin")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")])]

#link("https://retractionwatch.com/2018/09/17/what-really-happened-when-two-mathematicians-tried-to-publish-a-paper-on-gender-differences-the-tale-of-the-emails/")[#text("https://retractionwatch.com/2018/09/17/what-really-happened-when-two-mathematicians-tried-to-publish-a-paper-on-gender-differences-the-tale-of-the-emails/")]#text(" gives the impression that Hill’s erstwhile coauthor, Sergei T, angered (perhaps legitimately) by what happened at Math Intelligencer (where he is an editor) complained to Igor Rivin, who then solicited the paper from Hill for New York Journal of Mathematics and then sent it to a referee who wrote a report that recommended the paper for publication first and foremost because it is important to not let things like what happened to Larry Summers and Climategate occur, and second because the Math is technically correct. The referee admits to not being a mathematical biologist and suggests that one should perhaps be consulted, which seems never to have been the case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504989")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#emph[#text("[the authors] complained to Igor Rivin, who then solicited the paper from Hill for New York Journal of Mathematic because it is important to not let things like what happened to Larry Summers and Climategate occur")]

#text("I agree with this. But it seems the Distinguished Lecturer couldn’t help but to start ")#strong[#text("MathGate")]#text(". I even saw a Spanish youtuber talking about it.")

#text("It’s making mathematicians look very bad….because it is very bad.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40ec03e55204b4c2ab9d280c49ee33b5afed0d0222e40f92c4460cdf1c7ac4f3-c9fe7e7b8951bcd4d57103bb3fdd368fbe86e749972e1c35f6bafe9533f925c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Just sayin")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504961")[#strong[#text("Just sayin")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")])]

#text("It is also strange the solicitation letter from Igor promises quick refereeing and says the editor-in-chief was very positive on it. The whole process was obviously rushed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504988")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#strong[#text("After")]#text(" being censored by the Distinguished Lecturer, the process was obviously rushed, so we have to censor it AGAIN. Because it’s not woke enough")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505153")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("So you are saying that in order to right a perceived wrong, a paper should be rushed? Or are you saying you don’t know how referee processes usually work but you are happy to take Rivin’s word for it because he is on the “right” side from your point of view?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505304")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#strong[#text("I’m saying a group of SJWs censored a paper in the Math. Intel. for political purposes")]#text(" That is the only thing that maters, and everything after that can be debated once we agree that 2+2=4.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505305")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#text("I think everybody (?) agrees with this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What I'm saying...")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505306")[#strong[#text("What I'm saying...")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#text("Why ")#strong[#text("So you are saying…")]#text(" is never followed by what was actually said?")#linebreak()#text(" I’m saying anyone questioning the math, the hypothesis, or the peer review process, or Igor, is cherry picking. You are sleeping while the house is on fire!! but everything is fine as long as the paper is not mathematically relevant. Anyway….the paper was rushed it should have never been publish in the first place.")

#strong[#text("They had a 15 min presentation to defend their paper!!")]#text(" THIS DOES NOT HAPPENS EVER. This is not how normal peer review happens. This was the first CENSURING…..it seems it won’t be the last one.")

#text("#MathGate")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44a79ad087f5c48180d243cca8a2fe157ae0b5f29bb2e17990f515bc34ac0c19-be1d8879498d30a55bccec2017d48ebf05c7acec5b9c02c510cc98d7a9a4917c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anima")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504962")[#strong[#text("Anima")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")])]

#text("I am hugely disappointed at the amount of time and energy that so-called brilliant minds are spending debating something that should be a non-starter. We look back at the racist and sexist theories of previous century measuring the brain size to intelligence and think we are more enlightened but the comments here and in your previous thread prove otherwise.")#linebreak()#text(" I know the hell that women have to go through to be a researcher in STEM and it has nothing to do with biology or genetics. If you really want to be an ally for women in STEM, please read Lior Pachter’s blog on this ")#link("https://liorpachter.wordpress.com/2018/09/17/mathematics-matters/")[#text("https://liorpachter.wordpress.com/2018/09/17/mathematics-matters/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504964")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("Dear Anima, indeed the discussions reveal (and perhaps were meant to reveal) an unpleasant reality. It happens (fortunately not too often) that a lot of time and effort are required to deal with claims of pseudoscientific nature. I share your view that Lior Pachter’s blog post is valuable.")

#text("Related to the general theme of women in mathematics let me mention a beautiful NYT article by Amie Wilkinson: ")#link("https://www.nytimes.com/2017/08/07/science/women-mathematicians-maryam-mirzakhani-marina-ratner.html?mcubz=3")[#text("With Snowflakes and Unicorns, Marina Ratner and Maryam Mirzakhani Explored a Universe in Motion.")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7395a5d4ff419ba231408b627550161e8a1bdc480321055fad2e2c50df9cedbc-b07b760a881980f439c46120857edad545ca60d795955adbe9bd5dde7cb6ef8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew D Cory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504976")[#strong[#text("Matthew D Cory")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("Boys are falling behind in high school but somehow excel at the math SAT. You guys make a lot of insulting and immature accusations for simple observations. Stop virtue signaling.")#linebreak()#text(" ")#link("http://www.aei.org/publication/2016-sat-test-results-confirm-pattern-thats-persisted-for-45-years-high-school-boys-are-better-at-math-than-girls/")[#text("http://www.aei.org/publication/2016-sat-test-results-confirm-pattern-thats-persisted-for-45-years-high-school-boys-are-better-at-math-than-girls/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44a79ad087f5c48180d243cca8a2fe157ae0b5f29bb2e17990f515bc34ac0c19-be1d8879498d30a55bccec2017d48ebf05c7acec5b9c02c510cc98d7a9a4917c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anima")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504977")[#strong[#text("Anima")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("you big bully.. u are the one who is immature. I have survived this terrible sexist culture and will continue to fight people like you. you make it terrible for all the women in the world")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505082")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("Yes, Anima’s life has been a living hell: ")#link("https://yourstory.com/2017/06/techie-tuesdays-anima-anandkumar/")[#text("https://yourstory.com/2017/06/techie-tuesdays-anima-anandkumar/")]#text(" supported by men all the way through. Makes me embarrassed to be a member of the same sex.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505125")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("After posting my previous comment, I thought I might have done Anima a grave injustice, and decided to ask around the machine learning community. Here is a comment from a mild-mannered ML expert:")

#text("She’s a psycho who pushes sloppy science and only cares about publication count, regardless of quality or if it means working her students to death. She of course doesn’t do any actual science—just directs.")

#text("ML is so desperate for women they’ll promote such mediocrities at breakneck pace. I predict she’ll turn on the people who promoted her soon enough. Unhinged psycho.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505130")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Elisabeth Batory: yes, it is OK to tell your sincere opinion, even if it not polite; and it is OK to quote the opinions of others, if these opinions are public, but reproducing rude comments of anonymous experts does not look like a great idea. Sorry to say this, but I hope you will agree now or later…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505134")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Dear Anonymous, you are obviously a very honorable person, and I hate to disagree with you, however, disagree I must. One can disagree without being rude or insulting (the vast majority of comments on this blog are very civil, and even the less civil ones refrain from calling people names). As for the anonymity of my source, as you can appreciate, since the person is not as brave as you, she will not want to risk a confrontation with Dr. Anandkumar (assuming her opinion is correct), and that goes for anyone commenting on the subject. On the other hand, the quote is directly on point – Anima claims to have been through hell, but it seems that, instead, she has been taken up the royal road to the pinnacle of professional recognition. Since I know women who have, indeed, suffered horrible injustices (of a physical sort), this just seems too unfair to let slide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505155")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Dear pseudonymous countess, I would be interested to see your survey methods. It couldn’t be the case that you are just reporting the first negative opinion that you happened to receive, without first fixing the sample size? Surely not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505160")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Dear Professor Choi,")

#text("Thank you for your insightful remarks. To answer your question, no, I did not post the first negative report. I posted the first report, and this from a person who I had no reason to believe had any opinion on the subject. Since her views agreed with the impression created by the subject’s rude posts here, and also with the cursory examination of the subject’s publication record (since I have some modest understanding of the field), I have felt (and still do) that this summarized the situation fairly.")

#text("Since you are, as you say elsewhere, a professional mathematician, I assume that you have read your share of recommendation letters. I suspect that your department would not have hired the subject of such a letter, and would not conduct a poll of everyone in the field, which is what you seem to suggest here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505169")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Elizabeth Batory: Not just Anima entire ML academic community is that way. Too much money floating around a few ideas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505170")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("This is the level publications are ")#link("https://www.quantamagazine.org/machine-learning-confronts-the-elephant-in-the-room-20180920/")[#text("https://www.quantamagazine.org/machine-learning-confronts-the-elephant-in-the-room-20180920/")]#text(". Put an elephant in the picture and gather an elephantine name in ML.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1307a71b1b2dcf1c4b2189e86616d09f3061fddc1b7b7a4d8ccdc8d9e6070fb7-0ec55a2bf86453e502c162312439f2939e0aaef4aee628df3bb5e266f55bb708.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Pachter")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504978")[#strong[#text("Lior Pachter")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("I have a question for you Matthew Cory. Last year the average math SAT score of boys in New York state was 535. The average math SAT score of girls in Wisconsin was 632. That’s a difference of almost 100 points in favor of girls. These averages are computed from scores of hundreds of thousands of children so the difference is (extremely) statistically significant. I’d appreciate it if you could respectfully explain these simple observations. Do you believe that girls in Wisconsin have evolved to be brilliant mathematicians while boys in New York have evolved in a way that positions them to be in the lower tail of math ability? Could the difference be due to gender differences during the Mesolithic period when girls in Wisconsin developed strong number theory skills counting fish in lakes?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac12bdb701952daa6c8af0b4522175200a7fa8bb644ef4b18260e8637530a761-34c0132da311683969929b458c37d1fcc1f8642a9414a80912a208850415f3ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504979")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("It is very simple: the SAT has a lower ceiling now, all potentially difficult math content has been removed, there is a lot of verbal nonsense. It hardly measures any mathematical ability. It is just designed so it measures things girls are better at, but hardly math so it doesn’t prove anything. I’m sure a test of basic arithmetic will show girls are better than boys by a wide margin. On the other hand, a future Einstein, Gauss, Newton, Perelman, Wiles, etc. will continue to be a boy with high probability.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44a79ad087f5c48180d243cca8a2fe157ae0b5f29bb2e17990f515bc34ac0c19-be1d8879498d30a55bccec2017d48ebf05c7acec5b9c02c510cc98d7a9a4917c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anima")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504980")[#strong[#text("Anima")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("Once you present these misogynistic pigs with hard facts they turn anonymous. No surprise that they are the ultimate cowards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e2c7190341fb2bb4e35f936ffa118d348bbaf572297898d8057f302c63038cb-5d4a4c320d83fc35e9732b3a672ccd556d402294bcfac75a1ece43bf5793f353.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wugga")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504983")[#strong[#text("Wugga")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("Lior Pachter: For 2017 high school graduates, 135,141 people took the SAT in New York state, while 1,780 people took it in Wisconsin. The state of New York has a population of about 19.8 million, while Wisconsin has about 5.8 million people. So a far smaller proportion of Wisconsinites took the exam. The ACT is more popular there. People taking the SAT tend to be looking at out of state universities and are generally stronger students.")

#text("You can pore through the relevant data at ")#link("https://reports.collegeboard.org/pdf/2017-wisconsin-sat-suite-assessments-annual-report.pdf")[#text("https://reports.collegeboard.org/pdf/2017-wisconsin-sat-suite-assessments-annual-report.pdf")]#text(" and ")#link("https://reports.collegeboard.org/pdf/2017-new-york-sat-suite-assessments-annual-report.pdf")[#text("https://reports.collegeboard.org/pdf/2017-new-york-sat-suite-assessments-annual-report.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95f817915d852118c2db29947edd1f0232e34af1da29fce284382b8d2c7693dd-c5b61708c0ddc7fbbb44307dda379ff58b8a251c9a58d151d7df61c10d12963d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jessica Cohen")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504984")[#strong[#text("Jessica Cohen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("Anima, may you please explain “the hell that women have to go through to be a researcher in STEM”? As a female wanting to go into STEM, I’m honestly very curious what you mean. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1307a71b1b2dcf1c4b2189e86616d09f3061fddc1b7b7a4d8ccdc8d9e6070fb7-0ec55a2bf86453e502c162312439f2939e0aaef4aee628df3bb5e266f55bb708.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Pachter")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505010")[#strong[#text("Lior Pachter")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Wugga- your answer is spot on. I was waiting for this point. Thank you. There are numerous explanations for the difference between Wisconsin girl scores and New York boy scores. Evolution is NOT the relevant one. I’ll add that there are also other reasons for the difference you left out: for example demographics are different between Wisconsin and New York, and there are large differences in SAT scores between, e.g., Asians and Caucasians (the former are consistently scoring higher in math than the latter). Demographic differences are in turn confounded by socioeconomic status, and and also, as you point out in different states there may be differences in the kinds of students who turn up for the test. Such differences may also associate with demography. In 1996 Wisconsin implemented the SAGE program which ran for many years and maybe that is part of the difference. And so forth and so on.")

#text("The relative influence of these various factors on test outcomes is not clear to me but one can certainly study them and experts do. These kinds of factors can lead to a ~100 point differential between scores in two different states. But if you are to follow the logic of misogyny, the (much smaller) differential between boys and girls nationally (a differential which is itself high variable between state) is biology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7395a5d4ff419ba231408b627550161e8a1bdc480321055fad2e2c50df9cedbc-b07b760a881980f439c46120857edad545ca60d795955adbe9bd5dde7cb6ef8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew D Cory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505012")[#strong[#text("Matthew D Cory")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("I won’t answer trolling. You are ignoring what I said. I said that boys are doing better despite doing poor in the classroom. How could women be discriminated against but get better grades? The evidence is completely contrary to what you imply and it’s true across the globe. Boys are dropping out.")#linebreak()#text(" ")#link("https://www.theatlantic.com/education/archive/2014/09/why-girls-get-better-grades-than-boys-do/380318/")[#text("https://www.theatlantic.com/education/archive/2014/09/why-girls-get-better-grades-than-boys-do/380318/")]

#text("While I’m inclined to think that there is a different pool of test takers and incentives in Wisconsin, maybe boys are discriminated against there. By your paranoid logic, that’s what you are suggesting. Selective paranoia?")

#text("“more gender-equal countries were more likely than less gender-equal countries to lose those girls from an academic STEM track who were most likely to choose it on the basis of personal academic strengths.”")#linebreak()#text(" ")#link("http://journals.sagepub.com/doi/10.1177/0956797617741719")[#text("http://journals.sagepub.com/doi/10.1177/0956797617741719")]

#text("Your immature sarcasm reveals your deep ignorance of biology. Male and female brains show a great deal of difference and especially in g-loaded areas.")

#text("“We report the largest single-sample study of structural and functional sex differences in the human brain (2750 female, 2466 male participants; mean age 61.7 years, range 44–77 years). Males had higher raw volumes, raw surface areas, and white matter fractional anisotropy; females had higher raw cortical thickness and higher white matter tract complexity. There was considerable distributional overlap between the sexes. Subregional differences were not fully attributable to differences in total volume, total surface area, mean cortical thickness, or height. There was generally greater male variance across the raw structural measures. Functional connectome organization showed stronger connectivity for males in unimodal sensorimotor cortices, and stronger connectivity for females in the default mode network.”")#linebreak()#text(" ")#link("https://academic.oup.com/cercor/article/28/8/2959/4996558")[#text("https://academic.oup.com/cercor/article/28/8/2959/4996558")]

#text("“Males showed greater dorsal stream activation in right intra-parietal sulcus areas important for numerical cognition, and angular gyrus regions of the default mode network that are typically deactivated during complex cognitive tasks, as well as greater ventral stream activation in the right lingual and parahippocampal gyri. VBM revealed an opposite pattern of gender differences – compared to males, females had greater regional density and greater regional volume in dorsal and ventral stream regions where males showed greater fMRI activation. There were no brain areas where females showed greater functional activation than males, and no brain areas where males showed greater structural density or volume than females. Our findings provide evidence for gender differences in the functional and structural organization of right hemisphere brain areas involved in mathematical cognition.”")#linebreak()#text(" ")#link("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2888277/")[#text("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2888277/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1307a71b1b2dcf1c4b2189e86616d09f3061fddc1b7b7a4d8ccdc8d9e6070fb7-0ec55a2bf86453e502c162312439f2939e0aaef4aee628df3bb5e266f55bb708.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Pachter")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505015")[#strong[#text("Lior Pachter")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Apropos girls vs. boys in math this data is also interesting: ")#link("https://www.nytimes.com/interactive/2018/06/13/upshot/boys-girls-math-reading-tests.html")[#text("https://www.nytimes.com/interactive/2018/06/13/upshot/boys-girls-math-reading-tests.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505087")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("I am very confused by Professor Pachter’s (PBUH) comment. On the one hand, he rails for pages about a paper which gives a simple model for the observed fact that the variance of test scores among males is higher than that among females (pseudo-science! sexism!), and yet he has no problem taking for granted the higher test scores of Asians vis-a-vis Caucasians (and I assume, of Caucasians vis-a-vis Blacks – both facts are documented). Since I am sure that he would view any paper proposing a model for the latter as racist, and yet views it as fact, umm, well, I repeat, I am just confused.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e2c7190341fb2bb4e35f936ffa118d348bbaf572297898d8057f302c63038cb-5d4a4c320d83fc35e9732b3a672ccd556d402294bcfac75a1ece43bf5793f353.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wugga")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505115")[#strong[#text("Wugga")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Lior Pachter: It is also true that there is consistently a small (20-30 point) difference between male and female SAT scores that holds for all ethnic groups and has persisted for decades. The difference has been remarkably consistent when one takes into account educational background, academic achievement and so on. Rather than just pronounce that evolution cannot have anything to do it and block opinions that say otherwise, wouldn’t it be more productive to refute studies that suggest the differences are evolutionary in nature? These opinions don’t go away if they are suppressed. On the contrary, as we have seen in this case, such opinions often end out getting more publicity than the authors could have dreamed of. Not to mention a scientific debate is a more professional approach.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505229")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2018")])]

#text("It is interesting, Professor Kalai, that you have chosen to bring up Marina Ratner. As some readers of this blog might know, Professor Ratner (who was, indeed, a very deep mathematician) was violently opposed to precisely the sort of condescension to women advocated by Professor Wilkinson, and for that reason was adamantly opposed to the promotion of Jenny Harrison at Berkeley. By a curious coincidence, Harrison was married to Professor Pugh, who was Professor Wilkinson’s advisor. Professor Ratner did it the hard (and the right) way, and I have never heard anyone, of any gender, speak in any but the most respectful manner of her. She is indeed an inspiration and an example. I would not venture to say the same of the others mentioned in this comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4878bd308ba7b08afbc7ccbb0b3b6ef20e566248a1fc3018d5fa6a6f40fdc7b7-b78a31e0c2a9b8967c03e733a4707adefd5b1df3881599146e93bd6a77fa896f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("Dear Anima,")

#text("I very much sympathize with the cause of supporting women in STEM and feel that there is a lot to be done. I also feel that trying to “explain” SAT scores in math (or whatever) by some pseudo scientific theories is counterproductive, to say the least.")

#text("However, I think that the way you write could be less aggressive. There are many men who are not “pigs” or “misogynistic” but who maybe have not yet thought hard about these issues and who would therefore like to have a rational discussion. By such aggressive formulations, such discussions are made impossible and I am wondering where such strong emotions come from.")

#text("I personally take offense at formulations like “the hell that women have to go through to be a researcher in STEM”, etc. There are some of us who have experienced true “hell” like surviving wars, being raped, being physically abused, ….It feels disrespectful if you put “women in STEM” into the same category.")

#text("Also, could you please describe this “hell” to us? What precisely is it? Note that, for a man, it is really not so easy to understand because we do not see (or pay attention, since everybody is, understandably, busy with his/her own career) to the subtle (or not so subtle) obstacles that you have to overcome. A serious discussion could start by you explaining all these obstacles to the people not aware of them.")

#text("Lastly, you have made a stellar career and I am sure that this is partly due to male senior people who supported you very much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505003")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("To begin with, as we see here, a women’s tone is policed far more aggressively than men’s tone typically ever is. It’s not the worst aspect, but one you (Anonymous) might reflect upon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505083")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("Would you care to point out where anyone but Amina called anyone a pig (or anything similarly obnoxious)? If not, nothing more aggressive about it.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505084")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("“Anonymous” wrote “However, I think that the way you write could be less aggressive.”")

#text("This is a textbook example of how people police women’s tone in a way they don’t criticize men’s tone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505086")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("No, that’s a textbook example of how people try to bring a rude person back in line.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505085")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("Read this, and tell me if she seems very oppressed to you. ")#link("https://yourstory.com/2017/06/techie-tuesdays-anima-anandkumar/")[#text("https://yourstory.com/2017/06/techie-tuesdays-anima-anandkumar/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/533617aaac3279a3706bce8b232b3e7168cea6ecf90a7864b282f7beba13d50c-364908b6b5ade121e285da038f4af02655919912310faeef8a50edbcbe8ec49f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DG")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505157")[#strong[#text("DG")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Here’s a good account of ‘not so subtle’ obstacles:")

#link("https://medium.com/@lupopolvuh/the-harm-of-harmless-jokes-3ac5c65ad5f5")[#text("View at Medium.com")]

#text("I expect whether it counts as ‘hellish’ depends on whether you’re a target.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0568e129f95829f1dfdf2d252558cee0f38a7873496a9d75c3fcdb3991d8ed89-fa36cd174d35c5e386c172f990c2dec7bef4a7a87e1ce7c8003568d4b7370dc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sue Generis")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505197")[#strong[#text("Sue Generis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("Apparently, opinions on this vary: ")#link("https://posttenuretourettes.wordpress.com/2018/07/22/whats-in-a-name-a-power-grab/")[#text("https://posttenuretourettes.wordpress.com/2018/07/22/whats-in-a-name-a-power-grab/")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505005")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Not only women have to go through hell in order to succeed. Look at Perelman or Yitang Zhang. They certainly gave everything they had. Then again, I doubt that Zhang complained much about it while working at subways.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505006")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("It seems that Perelman early retirement from mathematics is somehow related to his (over?) sensitivity for certain unethical incidents among mathematicians.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e936f6722ba71c08dd57debb3d26712aafbe3c698f36d1522f8a7dffb52427e2-4eca4bf190341f6d68a604d673cbb8ba137cd99a8c6b71d2eda9d84dde4f89b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("At the time of S-T Yau antics he was already indifferent after years of being mobbed at a toxic workplace, which was also markedly antisemitic at the time.")

#text("Also, Zgang did complain and the whole story includes tale of his abusive advisor. That’s why you know about the subway at all, because he told his story. Of course you are free not to call this any complaint, reserving that word only to storied told by women. Truth is mathematics has a great problem with toxic behaviors and everyone would benefit in tempering them.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4878bd308ba7b08afbc7ccbb0b3b6ef20e566248a1fc3018d5fa6a6f40fdc7b7-b78a31e0c2a9b8967c03e733a4707adefd5b1df3881599146e93bd6a77fa896f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505097")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("One can argue that Zhang did complain by telling his story (although he does not try to push a political agenda). But at least he has a story to complain about!")

#text("I guess you refer to Steklov as the toxic workplace? I was not aware of this.")

#text("Also mathematics does have a great problem with toxic behaviors, unfortunately. But then again this is true for the whole society which makes it even worse :(")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e936f6722ba71c08dd57debb3d26712aafbe3c698f36d1522f8a7dffb52427e2-4eca4bf190341f6d68a604d673cbb8ba137cd99a8c6b71d2eda9d84dde4f89b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505098")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Yeah, we can try to escape logic by changing qualifications all day. So it is now that he did in fact complain but women complaints are POLITICAL. Let me show how political his exaple is: in favour of social democracy, in favour of universal healthcare, in favour of state-subsidized research (which grant system already was, Vannevar Bush instituted it just to pour money evenly on everyone to fin funding race with Eastern Block, it had to be done this way because Constitution bars direct federal subsidy).")

#text("And no, problems with bullying among professional mathematicians within are not problems with society and can be fixed by said mathematicians, or other mathematicians if needs be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4878bd308ba7b08afbc7ccbb0b3b6ef20e566248a1fc3018d5fa6a6f40fdc7b7-b78a31e0c2a9b8967c03e733a4707adefd5b1df3881599146e93bd6a77fa896f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505099")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("I am sorry, I was maybe not being clear. I did not mean to say that women complaints are political. I was trying to say that Zhang told a story and complained, as opposed to complaining without telling a story. I am sure that there are many serious problems for many women who try to make a career in STEM.")

#text("I would wish that bulllying among professional mathematics were fixed and I agree that it is a big problem. But I think that the problem gets amplified by the way this discussion is lead. We should in fact all work together and try to understand each other’s concerns rather than attack each other. I also think that labeling the bulllying in mathematics as a gender problem is counterproductive and will help none of us.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505156")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Yes, two outlier data points are _really_ representative, sure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76fb247c81134e9626d34e28555aef5812c83efae5b508a87470bc0093d98365-725a6b60eef948f1326b210791b5384452f3d58f178f2beb86c46d39b77b1230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505162")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Trust me, there are (many) more data points, but speaking out about specific *active* mathematicians is dangerous. Mathematicians are overall conformists and align themselves in most contentious situations with the current power structure, regardless of the abuse it perpetrates. This is of course a human thing, but I think it is more pronounced overall among mathematicians because of our careful nature. In such an environment publicly pointing out abuse is often a loosing game.")

#text("A documented, but less well known case in point is the story of ")#link("https://en.wikipedia.org/wiki/Zoghman_Mebkhout")[#text("https://en.wikipedia.org/wiki/Zoghman_Mebkhout")]#text(" . You can read about it in “Recoltes and Semailles”. The latter book is frequently referred to as Grothendieck’s “sour grapes”. For me this is the outcome of the conformist forces that I mentioned earlier. Note that by the time “Recoltes and Semailles” became available Grothendieck had no longer any political power. I should also point out that I read that book, whereas most people who describe it as “sour grapes” have not, and simply repeat what they have heard from others.")

#text("Grothendieck frequently talks about the “degeneration” of the mathematical environment during his career. I always wondered if this was just due to a youthful naivete, since during his youth he was certainly shielded from the more abusive aspects of his environment, or if it really was due to the culture degenerating. If the latter was true it would be very interesting to know what caused the “degeneration”. From my own experience I can attest that there are notable differences in how young people are treated across different sub-fields of mathematics, so the hypothesis of a “degeneration” is not impossible. For instance I think it makes sense to believe that that two sub-fields which are mathematically in frequent contact also eventually inherit certain social practices. These are fascinating questions and I wish some sociologist eventually took up their study…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("Grothendieck certainly was fascinating both as a mathematician and as a person.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb5ff0275c4db4a1cd180a94ab81fcba1b401b18c5513c44a48ecf38f437b2e-b2d5e43b4a163c0397eec996bf16ad79d3c95ef44958fdead3d86ada76bb621a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What’s good for the goose – posttenuretourettes")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504963")[#strong[#text("What’s good for the goose – posttenuretourettes")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("[…] Lior Pachter has joined the fray, siding with Lysenko. He accuses the mathematical commentators on Tao’s and Gowers’s blogs of making illiterate pronouncements on biology. As we’ll shortly […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e848bb38dcdc8e5913f40729ef7c3e4926f5e46931f3f540030939b48e5996-56f63c64b5842bc5442b64a642e8a784da4158bd0f776cd90ca74d9544ca35b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504969")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("After reading the article, I was impressed to find that it contained even less actual biology than I had expected. I have to agree with ")#link("https://pandasthumb.org/archives/2018/09/hot-garbage.html")[#text("Reed Cartwright’s evaluation")]#text(", that it occupies the same substratum as creationists’ pseudo-mathematical “debunkings” of evolution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504986")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("The real issue is that ")#strong[#text("if you disagree with SJWs your career is in jeopardy and appearing conservative is unofficially illegal")]#text(". The second author was told to remove the reference to the grant that funds his usual research! This is a canary in the cold mine. And is not the first one. Stop ignoring the real issue!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("How long until this happens to a conservative student?")

#text("The issue here is that ")#strong[#text("ideologues have taken over academic institutions")]#text(" and this is what happens when you take their arguments at face value. but of course our Distinguished Lecturer would never do something like that. It was just T. Hill being a mean old white men")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505024")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("You are 100% right. But who will dare to acknowledge that in the Land of the “free”?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-504992")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("I think someone needs to mention Jordan Peterson. There is a trend of academics persecuted for conservative believes. This is another one of those.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505002")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("All we have here: trivial mathematics, amateurish pseudoscience, and loudly whiny usually-anonymous sexists with artfully developed persecution complexes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shamelessly anonimous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505007")[#strong[#text("Shamelessly anonimous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("We are talking about a censored paper (amateurish or not) so we are gonna keep the anonimity if you doesn’t mind")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95f817915d852118c2db29947edd1f0232e34af1da29fce284382b8d2c7693dd-c5b61708c0ddc7fbbb44307dda379ff58b8a251c9a58d151d7df61c10d12963d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Thomas")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505013")[#strong[#text("Frank Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Jordan Peterson is a complete idiot.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John T")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505025")[#strong[#text("John T")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("Welcome to the age of entitlement to be offended.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505108")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Great video!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac12bdb701952daa6c8af0b4522175200a7fa8bb644ef4b18260e8637530a761-34c0132da311683969929b458c37d1fcc1f8642a9414a80912a208850415f3ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505027")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("How would you know all of this? You are not a professional mathematician, you have no papers. Your childish defense of Ms Wilkinson, a spousal accommodation, is not convincing in the least so I wonder how you could distinguish between science and pseudo-science if you cannot even identify the multiple holes in your narrative.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505028")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("I see that we are now at the point in the discussion in which anonymous posters issue _ad hominem_ attacks. There’s nothing more to say once we get to this point.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac12bdb701952daa6c8af0b4522175200a7fa8bb644ef4b18260e8637530a761-34c0132da311683969929b458c37d1fcc1f8642a9414a80912a208850415f3ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505041")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2018")])]

#text("You complain about ad hominem attacks while you write: “loudly whiny usually-anonymous sexists with artfully developed persecution complexes.” Thanks for proving my point of not being being able to see the holes in your narrative. Also, if you knew a bit about mathematics(I do, I am a mathematician) you would understand that it is not an attack and it is very relevant, that is why referees for papers are chosen among mathematicians, not just random people. If you are one of these random people, your opinion on the quality of a mathematical paper has no weight and you should refrain from shamelessly bashing a scholar, not for his sake but to avoid embarrassment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505151")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Dear Anonymous, I *am* a mathematician and your previous comment is petulant and, if not technically ad hominem, foolishly extrapolating from your antagonist’s perceived credentials (or lack of them) to dismiss what they are saying. Given my 10+ years of experience of refereeing mathematics papers, for journals similar in scope if not in standing to the NYJM, I wonder why you bring the refereeing process up in your arguments with Marshall Flax.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aebb38d05831932174ea2879e51cc8a558e3e6268c08a232fef232d45e624426-17e8165501feb1a7ad1edd2f617483dbc710a6779b8a58aea19a0e5d9ee55718.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#text("Igor: Choi mentioned scope, but clearly he didn’t just mean that. Scope is not relevant to the discussion alone, and he also mentioned standing.")

#text("Now, no, your conclusion is incorrect, a paper cannot be rejected at JAMS based on his opinion according to, your own account on how refereeing works. First, Choi is not an editor of these journals, he is not senior in stature, and he is not a junior person that would be considered for the job(he is not a student or a postdoc of the big stature people you mention). In sum, no, what I say is correct and it is better to just wait until qualified people pronounce themselves on the matter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505317")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#text("Dear Anonymous: congratulations on achieving such marks of esteem early in your career. I make no pretence to be moving at similar levels to you. However, you may like to note the minor data point that I have actually been asked to referee an article for JAMS, which answered an open problem raised in the 1980s and 1990s by some people who may not meet your own personal levels of seniority but I personally regard quite highly (1997 Ostrowski Prize winner, ICM plenary 1998, if we are using these kinds of metrics).")

#text("Why I was I asked to referee the article given my own humble status? Presumably because it was on a rather technical question that cuts across certain boundaries in functional analysis, where not so many of the experts are active any more, and because the paper improves on a contribution I myself made several years ago, which itself was the only serious progress on the problem since the late 1990s. Could someone whom you respect more have been asked to referee it instead? Well, they would have had to take time away from being Important People Doing Their Important Maths to go and read about the history of the problem, learn why it is subtle or challenging, get a feel for its connections or lack of connections to topics of current high-level mathematical interest, and then check the actual mathematics to assess correctness, depth, novelty, etc. Instead in their infinite wisdom they asked a Bear of Little Brain like myself, as one of the handful of people that both know the history and have worked actively on the problem in the last 10-15 years, presumably because this would save them the time of nagging a Sufficiently Senior Mathematician to pay attention to the problem.")

#text("Now, suppose I had told JAMS “this paper is only a minor improvement on paper X” or “the paper is studying objects which no one cares about these days” or “this paper makes a subtle error in Section 3 which invalidates a crucial part of the case-by-case analysis in Section 4, and hence invalidates the main theorem”, and gave factual evidence such as quotations or references to the literature to back up my assessments. Are you *really* suggesting that my Lack Of Importance would invalidate my recommendation of rejection? This would seem an interesting way to treat academic publishing and general peer review, but whatever floats your boat. It is interesting to see the extent to which you judge people’s mathematical scholarship based on the name of the supervisor and the standing of the journals they publish in, rather than, say, actually asking me about functional analysis.")

#text("(Footnote: as it happens, I strongly recommended acceptance, on grounds of novelty and importance, but the editors did not agree — and that is fine, that is their call, based on their own readings of my report and the other report(s). All this seems rather consistent with what Prof. Rivin has said in his own reply to your comment. The paper subsequently appeared in a very good general journal — I hesitate to say “leading” in case it doesn’t meet your own rarefied standards.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b294d8b015dc4407c52d2f9e6a9cf2ca43ed1db1a0a9cd78ad19b1233b99a028-70acecc961b464b3b206fc2527897f86e41bce0f183478ea6149a010f441ce9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505319")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2018")])]

#text("Yemon, I advise you (OK, actually, this advice comes from F. Nietzsche) to do more controversial things, which will result in more baseless personal attacks, and, as a result, these attacks will stop making you upset. In the meantime, many of us know you and respect you as a Bear of Substantial Brain.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aebb38d05831932174ea2879e51cc8a558e3e6268c08a232fef232d45e624426-17e8165501feb1a7ad1edd2f617483dbc710a6779b8a58aea19a0e5d9ee55718.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505339")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2018")])]

#text("Choi: So you mention your work on functional analysis as an example of what? How does that qualify you to judge the paper of Hill? It seems you still don’t understand that you should let experts talk. Expertise in A doesn’t translate into expertise in B. Also, you write “functional analysis, where not so many of the experts are active any more” I wonder why…maybe because it’s not relevant anymore? Let your friend Rivin(another hallmark of relevance in nowadays math) defend you of these “baseless attacks”(Rivin’s logic has failed him on this too: for someone who doesn’t care, he surely spends a lot of time defending himself of his shady editorial handling). You both seem to be of the same caliber and of the same era. You will also probably soon follow into the footsteps of the past idol who proved the RH…math is a young man’s game.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aebb38d05831932174ea2879e51cc8a558e3e6268c08a232fef232d45e624426-17e8165501feb1a7ad1edd2f617483dbc710a6779b8a58aea19a0e5d9ee55718.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2018")])]

#text("…ah, in case I wasn’t clear, no, nobody would ask for the opinion of a nobody in a field to referee for a paper on JAMS. The argument given has nothing to do with my statement(which is still true), you just need to pay more attention. Also Mr. Rivin,what can I do to earn the respect of many of you as “a Bear of Substantial Brian”? It would mean the world to me. I guess by these many you mean the many left…left from the mezozoic era of math’s low hanging fruit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b294d8b015dc4407c52d2f9e6a9cf2ca43ed1db1a0a9cd78ad19b1233b99a028-70acecc961b464b3b206fc2527897f86e41bce0f183478ea6149a010f441ce9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505345")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2018")])]

#text("@Anonymous Congratulations, you win the cowardly idiot prize!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505365")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2018")])]

#text("Is Igor Rivin the same person who was ranting about women allegedly being second-class citizens in Iran (")#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/#comment-483843")[#text("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/#comment-483843")]#text(") but now is ok with treating a statistical measure that involves women as second-class? Academia employs some of the best people, I’ll tell ya! We’ve got the best people!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac12bdb701952daa6c8af0b4522175200a7fa8bb644ef4b18260e8637530a761-34c0132da311683969929b458c37d1fcc1f8642a9414a80912a208850415f3ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505199")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("Yemon Choi: you have refereed for journals similar in scope to NYJM for over 10 years? You must not be a very good one. I started refereeing for top journals during my first postdoc and one thing I know for sure is no one would be “foolishly” enough to reject a paper submitted to JAMS based on the opinion of Flax (or yourself). The refereeing process exists for a reason and we don’t take entitled white knight’s opinions, with no credentials, at face value.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505201")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("Anonymous: Professor Choi did say “similar in scope, if not in level”. Since NYJM is very eclectic, he could easily be describing JAMS.")

#text("Secondly, the way refereeing works for top level journals is that (a) the editor takes a look, and if s/he does not think the paper is interesting, it is rejected there and then. (b) the paper gets sent to a very senior (in stature, not necessarily in years) person for a “quick opinion”. If the quick opinion is not positive, the paper is rejected. (c) the senior person might want to referee the paper himself (not very common) or he can suggest a more junior person to read the paper in detail. The more junior person can ALSO claim the paper is not interesting, at which point the paper is rejected, or check over the details, and (usually) find gaps, which may or may not be fixable (there is a multi-year debate as to whether acceptance in the Annals is any guarantee of correctness – the Annals editors are quite firm that it does not). Only if these three hoops are jumped through is the paper finally accepted (in the case of JAMS or Annals, the acceptance has to be approved by the whole senior editorial board). This is a long-winded way of saying that certainly a paper can be rejected on the opinion of Professor Choi at JAMS. It probably will not be accepted on his opinion alone.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505029")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2018")])]

#text("‘I am the best’. ‘My tribe is the best’. ‘My class is the best’. My sex is the best. Can we attribute all this to some fundamental flaw in our nature?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505119")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("retraction Watch document: ")#link("https://retractionwatch.com/wp-content/uploads/2018/09/Hill_RetractionWatchAppendix_Sep14.pdf")[#text("https://retractionwatch.com/wp-content/uploads/2018/09/Hill_RetractionWatchAppendix_Sep14.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6c30ac9baf2735480811247397ab2ec364b0a265782946430bc58c0c6d1a1eb-8ea7f4b7ffacf4a7c703ea19ea2051decf344686e6f35e13d81ea871aeb1627c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("Reading this indeed leaves a very bad after-taste. If one leaves the academic and moral issues with the content of the paper aside, then two things are sticking out:")

#text("1. The major people involved in causing the paper being eventually rejected by the two journals all seem to belong to the same family! If there had been more (independent) parties involved, that would have been better…")

#text("2. While the tone of most emails was (more or less) polite, the email of Prof. Farb was not (he was the only one who resorted to use curse language). That’s a strange behavior of someone who is supposed to be not influenced by what happened before between his wife (and her father) with the Mathematical Intelligencer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505225")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2018")])]

#text("I read the retraction watch. I am glad I do not work in academia. The culture of academia today to me resembles the worst of the USSR – dysfunctional people at the top who have too much power, talented people having to answer to untalented people at the top that happen to be good at playing the game, having to watch what you say, plus lots of backstabbing. No thank you. It is a shame, because I really like math, but would rather apply it in an environment where people act like normal human beings.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505202")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("A little evidence of our gracious host’s judgment:")#linebreak()#text(" ")#link("https://www.single-cell-analysis.com/stephen-quake-responds-to-lior-pachter/")[#text("https://www.single-cell-analysis.com/stephen-quake-responds-to-lior-pachter/")]

#link("https://liorpachter.files.wordpress.com/2014/02/response_to_nonsense_blog_post.pdf")[#text("Click to access response_to_nonsense_blog_post.pdf")]

#text("This does not a priori mean that his post is wrong, of course, but should make us think twice (at least) about accepting Professor Pachter’s judgment at face value.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505209")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("Dear person with supposedly interesting bathing habits, who do you mean by “gracious host”, since last time I looked this is Terry Tao’s blog?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92b84d6e10e72634e7d5bf4a256b34781d0c68b03006d430ddf6c4e8f664a388-def232e43e7cd9c0bab9eb9b20add57f91f17ca06e141a56e7ff6e77d16ac56a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elizabeth Batory")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505211")[#strong[#text("Elizabeth Batory")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("Dear Professor Choi,")

#text("You are, as always, quite insightful. This post was intended for Professor Pachter’s blog, but since the two were open in adjacent tabs, it wound up in Professor Tao’s (it is also in Professor Pachter’s at this point) – wordpress seems to have no editing capability I am aware of. I suppose that if I were looking for a made up excuse, I would say that Professor Pachter has been far more active here than Professor Tao, so he is the guest host.")

#text("I hope this clarifies matters.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505213")[#strong[#text("A remark on Hill’s work on the Greater Male Variability Hypothesis | Deep thoughts on all subjects")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")]

#text("[…] has has caused a furore, and has been discussed at some length in a number of blogs, among them Terry Tao’s, (Sir) Tim Gowers’ in Mathematics, and also in some blogs by self-proclaimed experts in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b294d8b015dc4407c52d2f9e6a9cf2ca43ed1db1a0a9cd78ad19b1233b99a028-70acecc961b464b3b206fc2527897f86e41bce0f183478ea6149a010f441ce9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505333")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2018")])]

#link("https://www.the-scientist.com/news-opinion/a-twice-retracted-paper-on-sex-differences-ignites-debate-64873")[#text("https://www.the-scientist.com/news-opinion/a-twice-retracted-paper-on-sex-differences-ignites-debate-64873")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505334")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2018")])]

#text("In the text of the Scientist: “This paper is getting much more attention than it would have otherwise. I’ve read a version three times now and I would have never known that it existed otherwise.”")#linebreak()#text(" The same remark applies to Terence Tao’s “Distinguished Lecturer”!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f7a75de6ac8bc5fe5c2ef319e2bfce45ca0ccd07995a5d2bef5366997134f41e-b1ca483dce7e27fd9b99297ba72b09bf1d2524ca34174478df2f403de2f316fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John McAllison")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505335")[#strong[#text("John McAllison")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2018")])]

#text("The article confirms my view above, in particular where Senechal writes:")

#text("” But The Mathematical Intelligencer is not a research journal…”")

#text("Exactly. However, it doesn’t paint Professor Amie Wilkinson in an impartial light when she declined to be interviewed by the journal. It gives the increasing impression that the paper was censored because many found it too offensive. Rather like Psychology Today’s article on the relative attractiveness of ethnic groups and in particular Black women:")

#text("Psychology Today Apologizes for ‘Black Women Less Attractive’ Post")#linebreak()#text(" ")#link("https://www.theatlantic.com/technology/archive/2011/05/psychology-today-apologizes-black-women-less-attractive-article/351205/")[#text("https://www.theatlantic.com/technology/archive/2011/05/psychology-today-apologizes-black-women-less-attractive-article/351205/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505368")[#strong[#text("Controvertido trabajo matemático sobre variabilidad de los sexos | Coloquio Oleis")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2018")]

#text("[…] Dejando de lado el bizarro devenir editorial y social de este trabajo (para más detalles ver esta entrada del blog de Tao, el blog de Gowers, este comentario de Wilkinson, este comentario de Farb, este comentario de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Going back to basics")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505374")[#strong[#text("Going back to basics")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2018")])]

#text("Why is this model any worse than Malthus exponential growth or the Ideal Gas Law?")

#text("Everybody debating the worth of this paper (sigh Gowers) please get a grip on yourself.")

#text("This is a model that explain multiple data. It explain why there is less variance in Women (because men are non-selective) and why there is more variance in men (because women are selective). And it is simple enough for undergrads to understand and play with it. They can play with the discrete model, the gaussian mode.")

#text("This feels evil. There’s gonna be a Red Wave in November Prof. Tao.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b831948beb823689ba0a647cc48c61e44a02a69d58264d3f22ab875de719c9c2-3ceb6cae4e3fdc833e2ff1813b1e98b7b52371a999d4a0fbca9aa161e936fb44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander SHEN")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505376")[#strong[#text("Alexander SHEN")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2018")])]

#text("No idea about red waves, whatever this is, but to claim that the paper has “the model” is an overstatement, IMHO: one can imagine some models that author could have had in mind, but currently this is just one (simple and true) observation about variables with the same average and different variances, and a lot of talk around. But this does not mean that such a paper, or any paper at all, should be silently “unpublished”, I cannot imagine any grounds for such an action…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Going back to basics")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505460")[#strong[#text("Going back to basics")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2018")])]

#text("My point is that there are multiple papers in applications that have the same “quality level” that T. Hill")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b831948beb823689ba0a647cc48c61e44a02a69d58264d3f22ab875de719c9c2-3ceb6cae4e3fdc833e2ff1813b1e98b7b52371a999d4a0fbca9aa161e936fb44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander SHEN")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505465")[#strong[#text("Alexander SHEN")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("You mean papers published in NYJM (I hope not) or in general? (In general, indeed, you can find even complete nonsense, I agree.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Going back to basics")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505468")[#strong[#text("Going back to basics")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("Papers publish on the ")#emph[#text("Mathematical Intelligencer")]#text(" which was the original paper where it was accepted. The publication on NYJM came after censoring on the Mathematical Intelligencer")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505727")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2018")])]

#text("Every important idea is simple does not mean every simple idea is important.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b831948beb823689ba0a647cc48c61e44a02a69d58264d3f22ab875de719c9c2-3ceb6cae4e3fdc833e2ff1813b1e98b7b52371a999d4a0fbca9aa161e936fb44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander SHEN")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505469")[#strong[#text("Alexander SHEN")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("Yes, unfortunately I had to agree, MI even published ridiculous paper about grossone (and my critical reply in the next issue ")#link("https://link.springer.com/content/pdf/10.1007%2Fs00283-015-9599-9.pdf")[#text("https://link.springer.com/content/pdf/10.1007%2Fs00283-015-9599-9.pdf")]#text("). But MI did not “unpublish” anything, at least…")

#text("Diclosure: I’ve published several papers in MI and was a column editor there for a while. BTW, one of my letters had some (very limited) statistics that showed some difference between distributions in boys’ and girls’ achievements in some mathematical competitions/exams, ")#link("https://www.deepdyve.com/lp/springer-journals/letters-to-the-editors-VA0RygUg4r")[#text("https://www.deepdyve.com/lp/springer-journals/letters-to-the-editors-VA0RygUg4r")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505470")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("The right way would have been followup papers which prove by scientific and rigorous methods that the results in the paper cannot be demonstrated to be true within the operating rules of nature. This would have settled such a fruitless endeavor once and for all. Why delete a paper? This is the standard norm of scientific process that disproves past claims. if Andrew Wiles’ paper had been published in 1994 without identifying the bug before someone came along 10 years later (2004) and found the bug that Richard Taylor helped fix Wiles’ paper and perhaps the bug was fixed in 2014 then still Wiles’ orginal 1994 paper would not have been deleted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505471")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("This would have settled such a fruitless endeavor once and for all for all eternity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505481")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("Andrew Wiles’ is terrible example. However cold fusion is good Rousseau, D. L. (January–February 1992), “Case Studies in Pathological Science: How the Loss of Objectivity Led to False Conclusions in Studies of Polywater, Infinite Dilution and Cold Fusion”, American Scientist, 80 (1): 54–63, Bibcode:1992AmSci..80…54R.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505472")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("What makes me a little bit disappointed with this deluge of comments (some very interesting and thoughtful, indeed) is that most of them are beating around the bush: the issue is not how good or how bad, or how politically incorrect the Hill paper is. The issue is: what can we do to prevent Hill’s (and possibly other future papers of anyone) be censored in the name of politics, by some minority groups. This is more important than to discuss the merits or flaws of a single paper. Perhaps it would be salutary if someone initiated a new “Sokal-style hoax” ridiculizing these groups? If I had time, I would gladly do so…It is not so difficult, I think.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon. Trump Supporter")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505475")[#strong[#text("Anon. Trump Supporter")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("It seems to me that we will see a mathematician not getting published or facing unfair peer review process because he is conservative no matter the paper. The paper can be about PDEs or Algebraic Geometry or whatever, but the mathematician is a Trump supporter (which I am) he believes climate change has no scientific merit and it’s 90% political (this is what I believe) and at that point . . . what it’s left? Conservative Postdocs like me have reasons to distrust our Union, and other Departments, which have a clear bias (and they don’t even know. The Union Rep. Think they are objective and they are sending emails recomending to vote for democrats (!!!!))")

#text("And now we have to be careful within our own departments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon. Trump Supporter")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505476")[#strong[#text("Anon. Trump Supporter")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("In a more optimistic tone. I think we should all be proud that the AMS hasn’t taken a partisan position on Climate Change the way the APS did.")

#text("GOOD JOB AMS")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e936f6722ba71c08dd57debb3d26712aafbe3c698f36d1522f8a7dffb52427e2-4eca4bf190341f6d68a604d673cbb8ba137cd99a8c6b71d2eda9d84dde4f89b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("“I had time, I would gladly do so…It is not so difficult, I think.”")

#text("You are the perfect man for the job, since your books do read like a piece of Sokal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b294d8b015dc4407c52d2f9e6a9cf2ca43ed1db1a0a9cd78ad19b1233b99a028-70acecc961b464b3b206fc2527897f86e41bce0f183478ea6149a010f441ce9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505557")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("Something like what you suggest has been (just) done (and these people certainly have all of my respect): ")#link("https://areomagazine.com/2018/10/02/academic-grievance-studies-and-the-corruption-of-scholarship/")[#text("https://areomagazine.com/2018/10/02/academic-grievance-studies-and-the-corruption-of-scholarship/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2018/09/11/on-the-recently-removed-paper-from-the-new-york-journal-of-mathematics/comment-page-1/#comment-505560")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("Thank you for the great link! I will share it.")
]
]
]
