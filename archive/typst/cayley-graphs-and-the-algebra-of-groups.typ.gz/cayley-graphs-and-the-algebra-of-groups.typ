// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/
// Converted to Typst by tao2typ: "2026-10-14T09:26:02.680342+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Cayley graphs and the algebra of groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Cayley graphs and the algebra of groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 May 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/")[#text("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is a sequel to my previous blog post “")#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")[#text("Cayley graphs and the geometry of groups")]#text("“. In that post, the concept of a ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graph")]#text(" of a group ")#mi("{G}")#text(" was used to place some geometry on that group ")#mi("{G}")#text(". In this post, we explore a variant of that theme, in which (fragments of) a Cayley graph on ")#mi("{G}")#text(" is used to describe the basic algebraic structure of ")#mi("{G}")#text(", and in particular on elementary word identities in ")#mi("{G}")#text(". Readers who are familiar with either ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category theory")]#text(" or group ")#link("http://en.wikipedia.org/wiki/Group_cohomology#Group_homology")[#text("homology")]#text("/")#link("http://en.wikipedia.org/wiki/Group_cohomology")[#text("cohomology")]#text(" will recognise these concepts lurking not far beneath the surface; we wil remark briefly on these connections later in this post. However, no knowledge of categories or cohomology is needed for the main discussion, which is primarily focused on elementary group theory.")

#text("Throughout this post, we fix a single group ")#mi("{G = (G,\\cdot)}")#text(", which is allowed to be non-abelian and/or infinite. All our graphs will be directed, with loops and multiple edges permitted.")

#text("In the previous post, we drew the entire Cayley graph of a group ")#mi("{G}")#text(". Here, we will be working much more locally, and will only draw the portions of the Cayley graph that are relevant to the discussion. In this graph, the vertices are elements ")#mi("{x}")#text(" of the group ")#mi("{G}")#text(", and one draws a directed edge from ")#mi("{x}")#text(" to ")#mi("{xg}")#text(" labeled (or “coloured”) by the group element ")#mi("{g}")#text(" for any ")#mi("{x, g \\in G}")#text("; the graph consisting of all such vertices and edges will be denoted ")#mi("{Cay(G,G)}")#text(". Thus, a typical edge in ")#mi("{Cay(G,G)}")#text(" looks like this:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley1.png")[#image("../assets/849ea61a4af3fa6868469853c026cef30f749d4e5fceb6f2e3718e91194eeb72-f4374729ad43843030bdab4342a08d712e86b11560880ed0f4b26bde72ddca94.png", width: 90%)]

#align(center)[#text("Figure 1.")]

#text("One usually does not work with the complete Cayley graph ")#mi("{Cay(G,G)}")#text(". It is customary to instead work with smaller Cayley graphs ")#mi("{Cay(G,S)}")#text(", in which the edge colours ")#mi("{g}")#text(" are restricted to a smaller subset of ")#mi("{G}")#text(", such as a set of generators for ")#mi("{G}")#text(". As we will be working locally, we will in fact work with even smaller fragments of ")#mi("{Cay(G,G)}")#text(" at a time; in particular, we only use a handful of colours (no more than nine, in fact, for any given diagram), and we will not require these colours to generate the entire group (we do not care if the Cayley graph is connected or not, as this is a global property rather than a local one).")

#text("Cayley graphs are left-invariant: for any ")#mi("{a \\in G}")#text(", the left translation map ")#mi("{x \\mapsto ax}")#text(" is a graph isomorphism. To emphasise this left invariance, we will usually omit the vertex labels, and leave only the coloured directed edge, like so:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley2.png")[#image("../assets/97a61f70d61e293c65e998a5c789a832eed89656d194722984c6cc515faa6062-c2acbedb3cb1bdf8a8de0b442836f9757e204dde4f3760ae161a222d5f89f784.png", width: 90%)]

#align(center)[#text("Figure 2.")]

#text("This is analogous to how, in undergraduate mathematics and physics, vectors in Euclidean space are often depicted as arrows of a given magnitude and direction, with the initial and final points of this arrow being of secondary importance only. (Indeed, this depiction of vectors in a vector space can be viewed as an abelian special case of the more general depiction of group elements used in this post.)")

#text("Let us define a ")#emph[#text("diagram")]#text(" to be a finite directed graph ")#mi("{H = (V,E)}")#text(", with edges coloured by elements of ")#mi("{G}")#text(", which has at least one graph homomorphism into the complete Cayley graph ")#mi("{Cay(G,G)}")#text(" of ")#mi("{G}")#text("; thus there exists a map ")#mi("{\\phi: V \\rightarrow G}")#text(" (not necessarily injective) with the property that ")#mi("{\\phi(w) = \\phi(v) g}")#text(" whenever ")#mi("{(v,w)}")#text(" is a directed edge in ")#mi("{H}")#text(" coloured by a group element ")#mi("{g \\in G}")#text(". Informally, a diagram is a finite subgraph of a Cayley graph with the vertex labels omitted, and with distinct vertices permitted to represent the same group element. Thus, for instance, the single directed edge displayed in Figure 2 is a very simple example of a diagram. An even simpler example of a diagram would be a depiction of the identity element:")

#align(center)[#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley32.png")[#image("../assets/f1444f81bb1ce2c1fc1c40732ce9cbc038b877720c903cceaa59c2e33f4796d4-24061515c645da2e6960940fcbb49627026b154936834ef0fed06c6dbc1d2200.png", width: 90%)]#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley31.png")[#linebreak()#text(" ")]#text("Figure 3.")]

#text("We will however omit the identity loops in our diagrams in order to reduce clutter.")

#text("We make the obvious remark that any directed edge in a diagram can be coloured by at most one group element ")#mi("{g}")#text(", since ")#mi("{y=xg, y=xh}")#text(" implies ")#mi("{g=h}")#text(". This simple observation provides a way to prove group theoretic identities using diagrams: to show that two group elements ")#mi("{g, h}")#text(" are equal, it suffices to show that they connect together (with the same orientation) the same pair of vertices in a diagram.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can also interpret these diagrams as ")#link("http://en.wikipedia.org/wiki/Commutative_diagram")[#text("commutative diagrams")]#text(" in a category in which all the objects are copies of ")#mi("{G}")#text(", and the morphisms are right-translation maps. However, we will deviate somewhat from the ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category theoretic")]#text(" way of thinking here by focusing on the geometric arrangement and shape of these diagrams, rather than on their abstract combinatorial description. In particular, we view the arrows more as distorted analogues of vector arrows, than as the abstract arrows appearing in category theory.")
]

#text("Just as vector addition can be expressed via concatenation of arrows, group multiplication can be described by concatenation of directed edges. Indeed, for any ")#mi("{x,g,h \\in G}")#text(", the vertices ")#mi("{x, xg, xgh}")#text(" can be connected by the following triangular diagram:")

#align(center)[#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley4.png")[#image("../assets/d5599a203fb337cf5ce5137ec5a390074aa23b7c97ab0156bef9ee5f8a591588-5e598368a8ef7fefb48a0252900419078d5f7192ae566005ff0599d19b4ed7b9.png", width: 90%)]#text("Figure 4.")]

#text("In a similar spirit, inversion is described by the following diagram:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley5.png")[#image("../assets/3499967997b5762e1736fa15fd2f55b78ef0adee29d7763c987e4b402f531d76-8cc1a7116a8672ca89ab62ee0149da51273f5be1954374b94fdf0c794ec1fb8b.png", width: 90%)]

#align(center)[#text("Figure 5.")]

#text("We make the pedantic remark though that we do not consider a ")#mi("{g^{-1}}")#text(" edge to be the reversal of the ")#mi("{g}")#text(" edge, but rather as a distinct edge that just happens to have the same initial and final endpoints as the reversal of the ")#mi("{g}")#text(" edge. (This will be of minor importance later, when we start integrating “")#mi("{1}")#text("-forms” on such edges.)")

#text("A fundamental operation for us will be that of ")#emph[#text("gluing")]#text(" two diagrams together.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 ((Labeled) gluing)")]#text(" Let ")#mi("{D_1 = (V_1,E_1), D_2 = (V_2,E_2)}")#text(" be two diagrams of a given group ")#mi("{G}")#text(". Suppose that the intersection ")#mi("{D_1 \\cap D_2 := (V_1 \\cap V_2, E_1 \\cap E_2)}")#text(" of the two diagrams connects all of ")#mi("{V_1 \\cap V_2}")#text(" (i.e. any two elements of ")#mi("{V_1 \\cap V_2}")#text(" are joined by a path in ")#mi("{D_1 \\cap D_2}")#text("). Then the union ")#mi("{D_1 \\cup D_2 := (V_1 \\cup V_2, E_1 \\cup E_2)}")#text(" is also a diagram of ")#mi("{G}")#text(".")
]

#emph[#text("Proof:")]#text(" By hypothesis, we have graph homomorphisms ")#mi("{\\phi_1: D_1 \\rightarrow Cay(G,G)}")#text(", ")#mi("{\\phi_2: D_2 \\rightarrow Cay(G,G)}")#text(". If they agree on ")#mi("{D_1 \\cap D_2}")#text(" then one simply glues together the two homomorphisms to create a new graph homomorphism ")#mi("{\\phi: D_1 \\cup D_2 \\rightarrow Cay(G,G)}")#text(". If they do not agree, one can apply a left translation to either ")#mi("{\\phi_1}")#text(" or ")#mi("{\\phi_2}")#text(" to make the two diagrams agree on at least one vertex of ")#mi("{D_1 \\cap D_2}")#text("; then by the connected nature of ")#mi("{D_1 \\cap D_2}")#text(" we see that they now must agree on all vertices of ")#mi("{D_1 \\cap D_2}")#text(", and then we can form the glued graph homomorphism as before. ")#mi("\\Box")

#text("The above lemma required one to specify the label the vertices of ")#mi("{D_1,D_2}")#text(" (in order to form the intersection ")#mi("{D_1 \\cap D_2}")#text(" and union ")#mi("{D_1 \\cup D_2}")#text("). However, if one is presented with two diagrams ")#mi("{D_1, D_2}")#text(" with unlabeled vertices, one can identify some partial set of vertices of ")#mi("{D_1}")#text(" with a partial set of vertices of ")#mi("{D_2}")#text(" of matching cardinality. Provided that the subdiagram common to ")#mi("{D_1}")#text(" and ")#mi("{D_2}")#text(" after this identification connects all of the common vertices together, we may use the above lemma to create a glued diagram ")#mi("{D}")#text(".")

#text("For instance, if a diagram ")#mi("{D}")#text(" contains two of the three edges in the triangular diagram in Figure 4, one can “fill in” the triangle by gluing in the third edge:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley6.png")[#image("../assets/a5cc3d66bf9fc1b7fae187f78068dcde6f1a44597ec84e6395671c0b2e5d235a-19d7ed29cc2fad52dfe70c7f3587bac4fe88d043261488f683bbf1adf5592d55.png", width: 90%)]

#align(center)[#text("Figure 6.")]

#text("One can use glued diagrams to demonstrate various basic group-theoretic identities. For instance, by gluing together two copies of the triangular diagram in Figure 4 to create the glued diagram")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley7.png")[#image("../assets/acf99830d097b332341166862f8e964d9539733026177492faca5d9fa120929b-60086ba9a97bd4bb4b95872f4b0fd5603a87986e7f2d387d8ea0e9917b620857.png", width: 90%)]

#align(center)[#text("Figure 7.")]

#text("and then filling in two more triangles, we obtain a tetrahedral diagram that demonstrates the associative law ")#mi("{(gh)k = g(hk)}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley8.png")[#image("../assets/e03b5dc9008832455b73e23dac1e3d423d6c656207599d34f16618acf97376be-6a98a9f04d1492a84574a6029b441ea68572fa81ae8b9c7738438ff880a78202.png", width: 90%)]

#align(center)[#text("Figure 8.")]

#text("Similarly, by gluing together two copies of Figure 4 with three copies of Figure 5 in an appropriate order, we can demonstrate the Abel identity ")#mi("{(gh)^{-1} = h^{-1} g^{-1}}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley9.png")[#image("../assets/63053bcaa8db69ba2148445114e7df921235fc5ae675d61455ac43971555a531-2ee272a61f357283084ddb9972cd8584ecd5d77c218afedf089405df6b4aaae2.png", width: 90%)]

#align(center)[#text("Figure 9.")]

#text("In addition to gluing, we will also use the trivial operation of ")#emph[#text("erasing")]#text(": if ")#mi("{D}")#text(" is a diagram for a group ")#mi("{G}")#text(", then any subgraph of ")#mi("{D}")#text(" (formed by removing vertices and/or edges) is also a diagram of ")#mi("{G}")#text(". This operation is not strictly necessary for our applications, but serves to reduce clutter in the pictures.")

#text("If two group elements ")#mi("{g, h}")#text(" commute, then we obtain a parallelogram as a diagram, exactly as in the vector space case:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley10.png")[#image("../assets/0011f873bee26a4b6432b7ad3ad79bfed6bf3a0516798c98ec2fe0ceca63de76-ac084a442e20192fbe245b61bdc0b337d486cff10aba18a50ef1031e5dae6f4b.png", width: 90%)]

#align(center)[#text("Figure 10.")]

#text("In general, of course, two arbitrary group elements ")#mi("{g,h}")#text(" will fail to commute, and so this parallelogram is no longer available. However, various substitutes for this diagram exist. For instance, if we introduce the ")#link("http://en.wikipedia.org/wiki/Conjugation_(group_theory)")[#text("conjugate")]#text(" ")#mi("{g^h := h^{-1} g h}")#text(" of one group element ")#mi("{g}")#text(" by another, then we have the following slightly distorted parallelogram:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley11.png")[#image("../assets/0a4c9875d65085014ef62d94adf27b4e38f221b6599846ba831a902bfc6b3622-304991f11ff660540232c730b57963e76a73134255cadd772dd0a14aab3bbc73.png", width: 90%)]

#align(center)[#text("Figure 11.")]

#text("By appropriate gluing and filling, this can be used to demonstrate the homomorphism properties of a conjugation map ")#mi("{g \\mapsto g^h}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley12.png")[#image("../assets/b12c4f12c1465886ad57ad9c572619cad2fdf3eb7dd2bf40d78853031f0c14af-0c45013bc1a8f9922e35f6e5747f1cad268d1cb4f9a67b146f702daa7743847f.png", width: 90%)]

#align(center)[#text("Figure 12.")]

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley13.png")[#image("../assets/01984b0c17bb8483782fcf2b555c1b6ffccedc71b2b2f286133f7931b14566cf-0b8e6ba587703c1c70708b59e7cba4f91f21196b28eb33d25d8d0fce45cb3df4.png", width: 90%)]

#align(center)[#text("Figure 13.")]

#text("Another way to replace the parallelogram in Figure 10 is to introduce the ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("commutator")]#text(" ")#mi("{[g,h] := g^{-1}h^{-1}gh}")#text(" of two elements, in which case we can perturb the parallelogram into a pentagon:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley14.png")[#image("../assets/b4054c80013e21f87767f8841d8933780a1c6ecb54a210a09120f436a93f29b5-f4256bdd578c2fab3c9619c841ccb13d44c2c4e07ab9e196d3c1718ad5ea42df.png", width: 90%)]

#align(center)[#text("Figure 14.")]

#text("We will tend to depict commutator edges as being somewhat shorter than the edges generating that commutator, reflecting a “perturbative” or “nilpotent” philosophy. (Of course, to fully reflect a nilpotent perspective, one should orient commutator edges in a different dimension from their generating edges, but of course the diagrams drawn here do not have enough dimensions to display this perspective easily.) We will also be adopting a “Lie” perspective of interpreting groups as behaving like perturbations of vector spaces, in particular by trying to draw all edges of the same colour as being approximately (though not perfectly) parallel to each other (and with approximately the same length).")

#text("Gluing the above pentagon with the conjugation parallelogram and erasing some edges, we discover a “commutator-conjugate” triangle, describing the basic identity ")#mi("{g^h = g [g,h]}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley15.png")[#image("../assets/2bc420964cbd054caf01a9743fdbf2c3a85dcf1ff77432ee89c067c251ecf5ea-3d4b060d24d50cc7ebf7ac94ba705ef1bcdc7be5bb1dd5ca2b8203d0cd789be4.png", width: 90%)]

#align(center)[#text("Figure 15.")]

#text("Other gluings can also give the basic relations between commutators and conjugates. For instance, by gluing the pentagon in Figure 14 with its reflection, we see that ")#mi("{[g,h] = [h,g]^{-1}}")#text(". The following diagram, obtained by gluing together copies of Figures 11 and 15, demonstrates that ")#mi("{[h,g^{-1}] = [g,h]^{g^{-1}}}")#text(",")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley161.png")[#image("../assets/9208e8bedfdfae1af64975c76d48161642c9899904110aacbf2e6a36743229ff-e858319de693d7b6a86d65e569ba602b65c04021d27b214d69c1b2620ec96842.png", width: 90%)]

#align(center)[#text("Figure 16.")]

#text("while this figure demonstrates that ")#mi("{[g,hk] = [g,k] [g,h]^k}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley17.png")[#image("../assets/eb10ef850f270d015534d47d693887b0bae97fa7ce9d4e70b2b2e5dd80a47392-a394b792bf2acde14322e91fc9da6be5c805e27a2fffa9c98b4b35981608eeef.png", width: 90%)]

#align(center)[#text("Figure 17.")]

#text("Now we turn to a more sophisticated identity, the ")#link("http://en.wikipedia.org/wiki/Commutator#Identities")[#text("Hall-Witt identity")]

#align(center)[#tao-fit-display[#mitex("[[g,h],k^g] [[k,g],h^k] [[h,k],g^h] = 1,")]]

#text("which is the fully noncommutative version of the more well-known ")#link("http://en.wikipedia.org/wiki/Jacobi_identity")[#text("Jacobi identity")]#text(" for Lie algebras.")

#text("The full diagram for the Hall-Witt identity resembles a slightly truncated parallelopiped. Drawing this truncated paralleopiped in full would result in a rather complicated looking diagram, so I will instead display three components of this diagram separately, and leave it to the reader to mentally glue these three components back to form the full parallelopiped. The first component of the diagram is formed by gluing together three pentagons from Figure 14, and looks like this:")

#align(center)[#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley18.png")[#image("../assets/a889d087c5da5013cdc8ae67a9caa1bf32f0cee90edfb567157b8f7d3c4e4ec1-0bee415746255cc5aaf4a34d2a2066cd6972023510d11ce2721482f56a862c1d.png", width: 90%)]#text("Figure 18.")]

#text("This should be thought of as the “back” of the truncated parallelopiped needed to establish the Hall-Witt identity.")

#text("While it is not needed for proving the Hall-Witt identity, we also observe for future reference that we may also glue in some distorted parallelograms and obtain a slightly more complicated diagram:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley19.png")[#image("../assets/12a92c6d57e07b2ea8f19887bbc5ac82b36c16374b0f750d3c4593856fd1b72d-a1385be97491552b99ec2e6f4f5e04d61b91018f1f56d17bd2e676a15db5a6be.png", width: 90%)]

#align(center)[#text("Figure 19.")]

#text("To form the second component, let us now erase all interior components of Figure 18 or Figure 19:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley20.png")[#image("../assets/a6c8047363b093174b8d40ff6853d71e66a07aac1e80923c5a597bf1450f3506-4f3dc6ee9ab25a45096477b034fee87b4b9e975be975a129b3d32890d48c5e58.png", width: 90%)]

#align(center)[#text("Figure 20.")]

#text("Then we fill in three distorted parallelograms:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley21.png")[#image("../assets/3cf754f8be50715e8daee572710c9334a4e8eeaab05a4af92d34579004f5de49-e8ebdb830716bd49b5d8238aac989ef2d5a0d17d51a7013b0cd592cc1fe9e637.png", width: 90%)]

#align(center)[#text("Figure 21.")]

#text("This is the second component, and is the “front” of the truncated praallelopiped, minus the portions exposed by the truncation.")

#text("Finally, we turn to the third component. We begin by erasing the outer edges from the second component in Figure 21:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley22.png")[#image("../assets/3bf501cda4bef856576961b2139c713c22f24893fd5ac59aeab7dc2ef5a9a2aa-0f58aa27b53d12e3f7a13f262e011208d2f18dacf6c20b68b93b0091f5a1ef1c.png", width: 90%)]

#align(center)[#text("Figure 22.")]

#text("We glue in three copies of the commutator-conjugate triangle from Figure 15:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley23.png")[#image("../assets/367d7e26ead840a4c6794c98efaf51cc499b9e37b8a73b752cd086163cf1eb82-6e5baad8fc6808a61135e8b922209401f3b04e8f48619de5c624c1d2d377f08f.png", width: 90%)]

#align(center)[#text("Figure 23.")]

#text("But now we observe that we can fill in three pentagons, and obtain a small triangle with edges ")#mi("{[[g,h],k^g] [[k,g],h^k] [[h,k],g^h]}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/11/cayley24.png")[#image("../assets/4d2d1276992510d181a2b7f5b6b77f35ce5f73fd01ca32b338b95436f0114547-ab62ac6393de56f69c248efc2bafe697c8d6cac42afede281bee02f3762c7a18.png", width: 90%)]

#align(center)[#text("Figure 24.")]

#text("Erasing everything except this triangle gives the Hall-Witt identity. Alternatively, one can glue together Figures 18, 21, and 24 to obtain a truncated parallelopiped which one can view as a geometric representation of the ")#emph[#text("proof")]#text(" of the Hall-Witt identity.")

#text("Among other things, I found these diagrams to be useful to visualise group cohomology; I give a simple example of this below, developing an analogue of the Hall-Witt identity for ")#mi("{2}")#text("-cocycles.")

#metadata(none) <tao-a2bde8cf32ade496feb2>

#heading(level: 1)[#strong[#text(" — 1. A Hall-Witt identity for ")#mi("{2}")#text("-cocycles — ")]]

#text("It is instructive to start interpreting the basic building blocks of ")#link("http://en.wikipedia.org/wiki/Group_homology#Group_homology")[#text("group homology")]#text(" and ")#link("http://en.wikipedia.org/wiki/Group_cohomology")[#text("group cohomology")]#text(" in terms of these diagrams; among other things, this interpretation highlights the close relationship between group cohomology and other types of cohomology, such as ")#link("http://en.wikipedia.org/wiki/Simplicial_homology")[#text("simplicial cohomology")]#text(" and ")#link("http://en.wikipedia.org/wiki/De_Rham_cohomology")[#text("de Rham cohomology")]#text(". We will not do so systematically here, but present just a small fragment of group cohomology in this setting, to give the flavour of things.")

#text("To warm up, let’s begin with the easy theory of ")#mi("{1}")#text("-cohomology. Fix some coefficient ring ")#mi("{U}")#text(" (e.g. the integers ")#mi("{{\\bf Z}}")#text(", the reals ")#mi("{{\\bf R}}")#text(", or a cyclic group such as ")#mi("{{\\bf Z}/2{\\bf Z}}")#text("; for the elementary cohomology topics we will be presenting here, the exact choice of the coefficient ring ")#mi("{U}")#text(" will not be important). A ")#emph[#mi("{1}")#text("-cochain")]#text(" is just a map ")#mi("{f: G \\rightarrow U}")#text(". Using our diagram perspective, we can interpret a ")#mi("{1}")#text("-cochain in a “de Rham” way as a “")#mi("{1}")#text("-form” that assigns the element ")#mi("{\\int_e f := f(g)}")#text(" of ")#mi("{U}")#text(" to any oriented edge ")#mi("{e}")#text(" in a diagram that has colour ")#mi("{g}")#text(". By definition, we also define the integral ")#mi("{\\int_{-e} f}")#text(" along the reversal of an oriented edge ")#mi("{e}")#text(" in a diagram by ")#mi("{\\int_{-e} f := - \\int_e f}")#text(". Note though that the integral along a ")#mi("{g^{-1}}")#text(" edge is not necessarily the negation of the integral along a ")#mi("{g}")#text(" edge, since we may have ")#mi("{f(g^{-1}) \\neq -f(g)}")#text(". This explains the previous remark that we do not view a ")#mi("{g^{-1}}")#text(" edge as the reversal of a ")#mi("{g}")#text(" edge. Similarly, since ")#mi("{f(1)}")#text(" need not equal ")#mi("{0}")#text(", the integral of ")#mi("{f}")#text(" on a loop need not be non-zero. Thus one has to take a little bit of care with the analogy between group cohomology and de Rham cohomology. However, if the ")#mi("{1}")#text("-chain is normalised in the sense that ")#mi("{f(1)=0}")#text(" and ")#mi("{f(g^{-1})=-f(g)}")#text(" (which is for instance the case with the ")#mi("{1}")#text("-cocycles discussed below), then the analogy becomes more accurate.")

#text("Given any oriented path ")#mi("{\\gamma}")#text(" in a diagram consisting of a sequence ")#mi("{e_1,\\ldots,e_k}")#text(" of edges (which either are aligned with, or have the opposite orientation from, the edge in the diagram), we can then define the “ line integral” ")#mi("{\\int_\\gamma f}")#text(" of a ")#mi("{1}")#text("-cochain ")#mi("{f}")#text(" as the sum of the individual edge integrals ")#mi("{\\int_{e_1} f, \\ldots, \\int_{e_k} f}")#text(". A key point here is that of ")#emph[#text("translation invariance")]#text("; if two paths ")#mi("{\\gamma, \\gamma^{\\prime}}")#text(" are translates of each other, in the sense that they have the same length and the colours of their edges match, then they have the same line integral with respect to ")#mi("{f}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can of course more generally integrate ")#mi("{1}")#text("-cocycles against ")#emph[#mi("{1}")#text("-chains")]#text(", namely formal linear combinations of oriented edges with coefficients in ")#mi("{U}")#text(", which is the starting point for the diagrammatic interpretation of group homology, but we will not use this formalism here.")
]

#text("A ")#emph[#mi("{1}")#text("-cocycle")]#text(" is a ")#mi("{1}")#text("-cochain ")#mi("{f: G \\rightarrow U}")#text(" which obeys the identity")

#align(center)[#tao-fit-display[#mitex("f(g) - f(gh) + f(h) = 0")]]

#text("for all ")#mi("{g,h \\in G}")#text(". Of course, this equation is nothing more than the assertion that ")#mi("{f}")#text(" is a group homomorphism from ")#mi("{G}")#text(" to ")#mi("{U}")#text("; but let us pretend that we are unaware of this interpretation of ")#mi("{1}")#text("-cocycles, and instead interpret the ")#mi("{1}")#text("-cocycle condition diagramatically, as the fact that the line integral around any triangle (Figure 4) vanishes. Because any closed loop in a diagram can be triangulated (possibly after first filling in some more edges), we see more generally that a ")#mi("{1}")#text("-cocycle is nothing more than a ")#mi("{1}")#text("-cochain which is ")#link("http://en.wikipedia.org/wiki/Closed_and_exact_differential_forms")[#text("closed")]#text(" in the sense that its integral on any closed loop is zero. On the other hand, we also have translation invariance of the ")#mi("{1}")#text("-cocycle, which leads to some additional cancellations. For instance, by integrating a ")#mi("{1}")#text("-cocycle against the pentagon in Figure 14, the contribution of the edges of matching colour cancel each other out, leaving one with the conclusion that ")#metadata(none) <tao-36e0fd847d927d68475f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f([g,h]) = 0")]]



#text(" for all ")#mi("{g,h}")#text(" and any ")#mi("{1}")#text("-cocycle ")#mi("{f}")#text(". Of course, this fact was already obvious from the group homomorphism interpretation, but the point is that it can also be observed “geometrically” by inspection of a relevant diagram. Similarly, from Figure 11 we have ")#mi("{f(g) = f(g^h)}")#text(" for any ")#mi("{g,h \\in G}")#text(" and any ")#mi("{1}")#text("-cocycle ")#mi("{f}")#text(".")

#text("Next, we define a ")#emph[#mi("{2}")#text("-cochain")]#text(" to be a function ")#mi("{\\rho: G \\times G \\rightarrow U}")#text(". Just as ")#mi("{1}")#text("-cochains can be viewed as “")#mi("{1}")#text("-forms” that can be integrated on oriented edges and thus oriented paths, we can view ")#mi("{2}")#text("-cochains as “")#mi("{2}")#text("-forms” that can be integrated on oriented triangles and thus triangulated surfaces, though we make the technical restriction that our triangles must be of the form in Figure 4, i.e. not all arrows are oriented in the same direction. We can then interpret ")#mi("{\\rho(g,h)}")#text(" as the integral ")#mi("{\\int_\\Delta \\rho}")#text(" of ")#mi("{\\rho}")#text(" on the triangle in Figure 4, endowed with the clockwise orientation; reversing the orientation of this triangle leads to a negation of the integral. One can then integrate ")#mi("{\\rho}")#text(" on any oriented triangulated surface (or, more generally, ")#mi("{2}")#text("-chains, as mentioned previously) in a diagram in the obvious fashion, provided that in each triangle, the arrows are not all oriented in the same direction.")

#text("A ")#emph[#mi("{2}")#text("-cocycle")]#text(" is a ")#mi("{2}")#text("-cochain which obeys the identity ")#metadata(none) <tao-209505bfc9f4346c315f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\rho(g,h) - \\rho(g,hk) + \\rho(gh,k) - \\rho(h,k) = 0")]]



#text(" for all ")#mi("{g,h,k \\in G}")#text(". As we will recall later, ")#mi("{2}")#text("-cocycles can be viewed as coordinatisations of central ")#mi("{U}")#text("-extensions of ")#mi("{G}")#text(", but we will again pretend that we are unaware of this interpretation of ")#mi("{2}")#text("-cocycles, and instead take a diagrammatic interpretation (which has the advantage over the central extension interpretation that it extends much more readily to higher orders of cohomology than ")#mi("{2}")#text("-cohomology). The cocycle identity ")#link(<tao-209505bfc9f4346c315f>)[#text("(2)")]#text(" is then asserting that the integral of ")#mi("{\\rho}")#text(" on the tetrahedron in Figure 8 (or, in fact, any other tetrahedron) vanishes. Because any closed oriented triangulated ")#mi("{2}")#text("-surface on a diagram can be broken up into tetrahedra (again after filling in some edges if necessary), we conclude that a ")#mi("{2}")#text("-cocycle is nothing more than a ")#mi("{2}")#text("-cochain which is ")#emph[#text("closed")]#text(" in the sense that its integral on any closed triangulated ")#mi("{2}")#text("-surface vanishes. Among other things, this now allows one to define the integral ")#mi("{\\int_S \\rho}")#text(" of a ")#mi("{2}")#text("-cocycle on any oriented surface ")#mi("{S}")#text(" (not necessarily closed or triangulated) which is bordered by some closed loop ")#mi("{\\gamma}")#text(" in a diagram, by replacing ")#mi("{S}")#text(" by some triangulated oriented surface with the same oriented boundary ")#mi("{\\gamma}")#text(" as ")#mi("{S}")#text(". For instance, we can integrate a ")#mi("{2}")#text("-cocycle ")#mi("{\\rho}")#text(" on the pentagon ")#mi("{P}")#text(" in Figure 14 with the counterclockwise orientation to obtain an element ")#mi("{\\int_P \\rho}")#text(" of ")#mi("{\\rho}")#text("; by selecting a suitable triangulation of this pentagon, this integral can be expressed explicitly as ")#metadata(none) <tao-8427d18db3b0d6810af1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\int_P \\rho = \\rho(h,g) + \\rho(hg, [g,h]) - \\rho(g,h)")]]



#text(" but we can choose other triangulations to obtain other representations of the same integral, e.g.")

#align(center)[#tao-fit-display[#mitex("\\int_P \\rho = - \\rho(g, g^{-1} h) + \\rho(g^{-1} h, g) + \\rho(h^g, [g,h]).")]]

#text("Again, a key point is translation invariance: if two surfaces ")#mi("{S, S^{\\prime}}")#text(" are translates of each other in the sense that their boundaries are translates of each other, then their integrals against any ")#mi("{2}")#text("-cocycle ")#mi("{\\rho}")#text(" will agree.")

#text("A special case of a ")#mi("{2}")#text("-cocycle is a ")#emph[#mi("{2}")#text("-coboundary")]#text(", defined as a ")#mi("{2}")#text("-cochain ")#mi("{df}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("df(g,h) := f(g) - f(gh) + f(h)")]]

#text("for some ")#mi("{1}")#text("-cochain ")#mi("{f: G \\rightarrow U}")#text(". In other words, the integral of ")#mi("{df}")#text(" on any (oriented) triangle such as that in Figure 4 is equal to the integral of ")#mi("{f}")#text(" on the boundary of that triangle, and more generally we have the “Stokes theorem”")

#align(center)[#tao-fit-display[#mitex("\\int_S df = \\int_{\\partial S} f")]]

#text("for any oriented surface ")#mi("{S}")#text(" in a diagram with boundary ")#mi("{\\partial S}")#text(". One can quotient the space ")#mi("{Z^2(G,U)}")#text(" of all ")#mi("{2}")#text("-cocycles (which is a ")#mi("{U}")#text("-module) by the space of all ")#mi("{2}")#text("-coboundaries ")#mi("{B^2(G,U)}")#text(", leading to the ")#emph[#mi("{2}")#text("-cohomology group")]#text(" ")#mi("{H^2(G,U)}")#text(", which is then seen to be closely analogous to the ")#mi("{2}")#text("-cohomology group in either ")#link("http://en.wikipedia.org/wiki/Simplicial_homology")[#text("simplicial cohomology")]#text(" or ")#link("http://en.wikipedia.org/wiki/De_Rham_cohomology")[#text("de Rham cohomology")]#text(". (One can of course perform the same construction for any order. For instance, in the case of ")#mi("{1}")#text("-cohomology, the space of ")#mi("{1}")#text("-coboundaries turns out to be trivial in group cohomology, and so the first cohomology group ")#mi("{H^1(G,U)}")#text(" is isomorphic to the space ")#mi("{Z^1(G,U)}")#text(" of ")#mi("{1}")#text("-cocycles, or in other words the space ")#mi("{Hom(G,U)}")#text(" of homomorphisms from ")#mi("{G}")#text(" to ")#mi("{U}")#text(".)")

#text("We will need to integrate a ")#mi("{2}")#text("-cocycle ")#mi("{\\rho}")#text(" on triangles ")#mi("{\\Delta}")#text(" in which all arrows point in the same direction, such as in Figure 25:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley25.png")[#image("../assets/9364b7cd1acfbd25f7015f559b2d481b8f4b0f0a89e5b7776220eeefc62f7a11-8d165a7d3609aebe80ac4b77b49869395c9d97de12254f9c16becee7ed95be17.png", width: 90%)]

#align(center)[#text("Figure 25.")]

#text("This can be done by adding another point to decompose the triangle into one which we can already integrate:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2012/05/cayley261.png")[#image("../assets/7be4ac9bc1cfdf03850b16a77cb306c45bc5c6c4ebef38177cd88d411495fca9-9ab6f6299a706619096973962f21a3a8e76c3e6e4d80f174aa3edc0aba78d1df.png", width: 90%)]

#align(center)[#text("Figure 26.")]

#text("Thus we see (if we give ")#mi("{\\Delta}")#text(" the clockwise orientation) that ")#metadata(none) <tao-b136135d85d5275b202f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\int_\\Delta \\rho = \\rho(g,h) + \\rho(1,g) + \\rho(gh, (gh)^{-1});")]]



#text(" of course, other expressions for ")#mi("{\\int_\\Delta \\rho}")#text(" are possible by performing other oriented triangulations of Figure 25. In practice we can simplify these sorts of expressions by normalising the ")#mi("{2}")#text("-cocycle to the conditions ")#metadata(none) <tao-5a5000a3f3ff86860387>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\rho(1,g)=\\rho(g,1)=\\rho(g,g^{-1})=0")]]



#text(" by subtracting the coboundary ")#mi("{df}")#text(", where ")#mi("{f(g) := (\\rho(g,g^{-1}) + \\rho(1,1)) / 2}")#text("; a brief calculation using the cocycle equation ")#link(<tao-209505bfc9f4346c315f>)[#text("(2)")]#text(" reveals that any ")#mi("{2}")#text("-cocycle will obey ")#link(<tao-5a5000a3f3ff86860387>)[#text("(5)")]#text(" after subtracting off ")#mi("{df}")#text(". When one achieves this normalisation, then the integral of ")#mi("{\\rho}")#text(" on the triangle ")#mi("{\\Delta}")#text(" is simply ")#mi("{\\rho(g,h)}")#text("; also, the integral on triangles in which one of the edges is the identity is automatically zero, and the integral on the loop in Figure 5 is also zero. Thus, ")#mi("{2}")#text("-cocycles which are normalised by ")#link(<tao-5a5000a3f3ff86860387>)[#text("(5)")]#text(" can be viewed as being quite analogous to closed ")#mi("{2}")#text("-forms in de Rham cohomology.")

#text("Now we apply the above formalism to the truncated parallelopiped used to prove the Hall-Witt identity. We glue together Figures 18, 21, and 24 to obtain a closed ")#mi("{2}")#text("-surface. If ")#mi("{\\rho}")#text(" is a ")#mi("{2}")#text("-cocycle normalised by ")#link(<tao-5a5000a3f3ff86860387>)[#text("(5)")]#text(", the integral on this surface vanishes. On the other hand, we see that there is a lot of cancellation in this integral; in particular, all of the distorted parallelograms and triangles that appear in Figure 18, also appear (with the opposite orientation) in either Figure 21 or Figure 24. Cancelling out these faces, we are left with the three distorted parallelograms in Figure 24, together with the central triangle in Figure 24. Evaluating these integrals, we conclude the Hall-Witt identity for (normalised) ")#mi("{2}")#text("-cocycles:")

#align(center)[#tao-fit-display[#mitex("(\\rho(g^h,[h,k]) + \\rho(g^h [h,k], [[h,k],g^h]) - \\rho([h,k],g^h))")]]

#align(center)[#tao-fit-display[#mitex("+(\\rho(h^k,[k,g]) + \\rho(h^k [k,g], [[k,g],h^k]) - \\rho([k,g],h^k))")]]

#align(center)[#tao-fit-display[#mitex("+(\\rho(k^g,[g,h]) + \\rho(k^g [g,h], [[g,h],k^g]) - \\rho([g,h],k^g))")]]

#align(center)[#tao-fit-display[#mitex("-\\rho( [[h,k],g^h], [[k,g],h^k] )")]]

#align(center)[#tao-fit-display[#mitex("= 0.")]]

#text("Thus, for instance, if ")#mi("{g,h}")#text(" and ")#mi("{g,k}")#text(" commute (so that ")#mi("{g, [h,k]}")#text(" also commute), the Hall-Witt identity tells us that")

#align(center)[#tao-fit-display[#mitex("\\rho(g, [h,k]) = \\rho( [h,k], g ),")]]

#text("or in other words that the integral of ")#mi("{\\rho}")#text(" on any parallelogram with edges ")#mi("{g, [h,k]}")#text(" vanishes. This can also be seen by noting how the Hall-Witt truncated parallelopiped degenerates in the presence of so much commutativity.")

#text("The Hall-Witt identity for cocycles can also be derived from the group extension interpretation of a ")#mi("{2}")#text("-cocycle. Observe that if ")#mi("{\\rho: G \\times G \\rightarrow U}")#text(" is a ")#mi("{2}")#text("-cocycle, then we can form a new group ")#mi("{G^{\\prime}}")#text(" whose elements are pairs ")#mi("{(g,u)}")#text(" with ")#mi("{g \\in G}")#text(" and ")#mi("{u \\in U}")#text(", and whose group multiplication law is given by")

#align(center)[#tao-fit-display[#mitex("(g,u) (h,v) := (gh, u+v+\\rho(g,h));")]]

#text("one can easily verify that this law is associative when ")#mi("{\\rho}")#text(" is a ")#mi("{2}")#text("-cocycle, and defines a group structure on ")#mi("{G^{\\prime}}")#text(" with identity ")#mi("{(1,-\\rho(1,1))}")#text(" and inverse map")

#align(center)[#tao-fit-display[#mitex("(g,u)^{-1} := (g^{-1}, -u-\\rho(g,g^{-1})-\\rho(1,1)).")]]

#text("(If we normalise ")#mi("{\\rho}")#text(" to obey ")#link(<tao-5a5000a3f3ff86860387>)[#text("(5)")]#text(", then the identity simplifies to ")#mi("{(1,0)}")#text(", and the inverse operation simplifies to ")#mi("{(g,u)^{-1}=(g^{-1},-u)}")#text(".) The group ")#mi("{G^{\\prime}}")#text(" is then a ")#link("http://en.wikipedia.org/wiki/Group_extension#Central_extension")[#text("central group extension")]#text(" of ")#mi("{G}")#text(" by ")#mi("{U}")#text(", and indeed it is not difficult to see that all central group extensions of ")#mi("{G}")#text(" by ")#mi("{U}")#text(" arise in this manner (with the extensions being isomorphic relative to the base group ")#mi("{G}")#text(" if the underlying ")#mi("{2}")#text("-cocycles differ by a ")#mi("{2}")#text("-coboundary). One can then deduce the Hall-Witt identity for cocycles ")#mi("{\\rho \\in Z^2(G,U)}")#text(" by applying the ordinary Hall-Witt identity to the elements ")#mi("{(g,0), (h,0), (k,0)}")#text(" in the extended group ")#mi("{G^{\\prime}}")#text("; we omit the details. However, it appears that the group extension interpretation of ")#mi("{2}")#text("-cohomology does not easily extend to higher cohomology (unless perhaps one works with more general notions than groups, such as ")#link("http://en.wikipedia.org/wiki/N-group_(category_theory)")[#mi("{n}")#text("-groups")]#text("), whereas the simplicial approach given in this post has a more obvious extension to higher cohomology.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-142826")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2012")])]

#text("Figure 3 purports to show the identity element, but is labelled as g^[-1} ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-142828")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2012")])]

#text("On a more mathematical note, figure 18 looks like it should be related to some sort of polytope, similar to the associahedron, permutahedron and so forth. But this may just be a random guess.")

#text("The full Cayley graph Cay(G,G) is the graph underlying the action groupoid for the action of G on itself. This groupoid is equivalent to the trivial groupoid, but is actually very interesting as it is the basis for the construction of the universal G-bundle by Segal. Additionally, this groupoid can be given the structure of a strict 2-group, and hence Cay(G,G) itself has the structure of a group object in the category of directed graphs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9585c9e1f7a1a531f9621602366db9d2d1c4be47324a3794815d81f6a2289544-cd4debd26b498db2b5d51ff046491babbc9cc6c3a57a75ff5f078ae5adb73e37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Jiang")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-142843")[#strong[#text("John Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2012")])]

#text("This is the first time I understood higher order group cohomology. Thanks for the wonderful display of clarity!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-142886")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2012")])]

#text("Dear Tao,")

#text("Very entertaining post : it could not be clearer. I guess it helps comprehending Connes’ non commutative quantum theory (I mean as a good start with co-cycles and stuffs)")

#text("Best,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-142996")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("“one can glue together Figures 18, 21, and 24 to obtain a truncated parallelopiped which one can view as a geometric representation of the proof of the Hall-Witt identity”")

#text("Do you see a way of turning this statement into a rigorous one? You have a family of labelled graphs, together with rules of decorating/gluing/erasing, so is there any way to turn this into a notion of proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-143001")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("Yes, these diagrams form a proof system for verifying identities in the free group (which of course then also hold in any group). (Of course, such identities can also be easily verified by direct algebraic expansion, but then the underlying geometry and topology of the situation is lost.)")

#text("I think that with the obvious modifications, one could also make this into a proof system for verifying identities in a finitely presented group. On the other hand, showing that a given identity in such a group does NOT hold is known to be an undecidable problem, so there is no proof system in that case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Baroi")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-143162")[#strong[#text("Max Baroi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2012")])]

#text("Hey Dr. Tao.")

#text("Really cool post.")#linebreak()#text(" I just have a quick suggestion considering for providing motivation behind one of your definitions.")

#text("Someone with exposure to only a little to amount of graph and group might find the definiton, “connect x to y by arrow g if y=xg” somehwat arbitrary. Maybe just a clarifying sentence explaining that using right multiplication implies that travelling along the arrow “g”, then travelling along the arrow “h” is equivalent to travelling along the arrow “gh”, while using left multiplication it is equivalent to travelling along the arrow “hg.” The choice of definiton is logically arbitrary, but right multiplication is somewhat clearer to read in a language you read left to right.")

#text("If you already gave motivation, and I simply missed it. Apologize, and disregard my comment.")

#text("Cheers,")#linebreak()#text(" Max")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Baroi")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-143163")[#strong[#text("Max Baroi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2012")])]

#text("Of course in additon to left invariance. I feel a little bit dumb.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d0c9b6e3d598fc6819a9be70726912eb2945d73e74e961443995e631e7c3e4-e5a143bae28f525b55b430b325d4eaeb879ffbbbaf6aa4f7025a0bb4879843c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joerg Grande")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-143856")[#strong[#text("Joerg Grande")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2012")])]

#text("Lemma 1 has two minor issues: The explanation of “connects all of ")#mi("V_1\\cap V_2")#text("” in parentheses should begin with “i.e. any two elements of ")#mi("V_1\\cap V_2")#text("“. There is a typo in the definition of the union ")#mi("D_1\\cup D_2")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24654a73da055fa8e022f7633206bbb47e57ea5c7958b7ed73e0f86a3c836acd-96482a231c5a95f78cd7eabc35167a281c1a27745d3c2b38a68b6c8e6a40b2c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gary Mak")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-143978")[#strong[#text("Gary Mak")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2012")])]

#text("Hi Terry")#linebreak()#text(" A wonderful post – thank you. Just a quick question: is there anywhere a similar Cayley-graph-type exposition of the theory of group cohomology where you do not have trivial action of G on U?")#linebreak()#text(" Thanks!")#linebreak()#text(" Gary")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-144422")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2012")])]

#text("I think the main difference is that the translation invariance of the “k-forms” that model the k-cocycles has to be replaced by translation equivariance, thus each time one translates a simplex by some group element g, the value (in the G-module M that is taking as the space of coefficients) assigned to that simplex by a k-cocycle also gets rotated by g.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24654a73da055fa8e022f7633206bbb47e57ea5c7958b7ed73e0f86a3c836acd-96482a231c5a95f78cd7eabc35167a281c1a27745d3c2b38a68b6c8e6a40b2c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gary Mak")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-144783")[#strong[#text("Gary Mak")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2012")])]

#text("Thanks! I’ll get busy working out the details ….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e992c9d6bd69dd80732ca5390a35dcd2f41def765f7553ed62128e4fb9b21ecb-4768d42197c2c4f660569b64d7705d69c7ec4ef2e7e1cbee040f09e195407ee1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of conjugate glue « Peter's ruminations")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-165937")[#strong[#text("conjugate glue « Peter's ruminations")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2012")])]

#text("[…] Both From Terry Tao website […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3b72abf6bc67454cb4035209a70eb25354958c656f61e52c6aab007e8148cce-9973b46c725496e42fb67a0aa1781f632bf0351fcac763031251ecd7e71c89f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-195548")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2012")])]

#text("Unless I am misunderstanding something, it looks like the directions of the arrows on the central triangle in Figure 24 ought to be reversed to be consistent with the earlier definition of the commutator. I also suspect that the last term on line 3 of the Hall-Witt identity for 2-cocycles should be ")#mi("\\rho([g,h],k^g)")#text(". In the equation immediately following Equation (3), should the second term be ")#mi("\\rho(g^{-1}h,g)")#text("?")

#text("Finally, I may be laboring under some misconception about how the signs are determined, but I am puzzled about why the signs of the three terms on the right side of Equation (3) aren’t all the reverse of what is shown given that positive sign is associated with clockwise orientation. Likewise the three terms on the right side of the equation immediately following Equation (3). I’m also wondering about the sign of the term on line 4 of the Hall-Witt identity for 2-cocycles. (This query is related to my first question above about the direction of the arrows on the central triangle.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-195609")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2012")])]

#text("Thanks for the corrections! Hopefully they should all be fixed now (I reversed the orientation of the pentagon P relating to (3)).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3b72abf6bc67454cb4035209a70eb25354958c656f61e52c6aab007e8148cce-9973b46c725496e42fb67a0aa1781f632bf0351fcac763031251ecd7e71c89f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-197003")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2012")])]

#text("Figure 24 doesn’t look like it’s changed unless I click on it. When I do that I see an enlarged picture with the triangle arrows going the opposite way. At first I guessed that this was due to some weird caching effect that I couldn’t figure out how to get rid of, but I’ve now had the chance to view the page on a different computer at a different location and still see the same effect. I’m wondering whether it’s just me, or whether there is some issue with the new figure?")

#text("By the way, thanks for writing this article!")

#emph[#text("[Sorry, that was me trying to edit HTML by hand. Should be fixed now – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1df04b2a9b705b550113ba8a24511e5e54f1db9d998e03c86d20cab6bdf0dc6-dc3fc1efb9e6a9262e79008cfbb0099af0579e86f78df4dc0d3abd716dc89ba3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xaio-Gang Wen")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-220190")[#strong[#text("Xaio-Gang Wen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2013")])]

#text("Now, group cohomolgy theory become very useful in condensed matter physics, just group theory is very useful in physics.")#linebreak()#text(" (See ")#link("http://arxiv.org/abs/1106.4772")[#text("http://arxiv.org/abs/1106.4772")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02242c47c189bdeee6118d74b2f6d153f67b1257413b83486b2a8af92c31af13-2924c613ac702b4e69366a83b09c13ca5a2388f04ed910d1e729ca540e073d0d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cayley graphs and the geometry of groups | Math Online Tom Circle")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-459535")[#strong[#text("Cayley graphs and the geometry of groups | Math Online Tom Circle")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/")[#text("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fae4facb12a8999de9f86aa8e27adc345c15fa6dad59209b20947f966d0a3364-7670efd7ec6a679eb0529f4c6a35bd6a50ca5d3a71ca28c670690fa6e721ad41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suganya")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-471547")[#strong[#text("Suganya")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2016")])]

#text("I want how to draw Cayley coloured graph with step by step…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-472156")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2016")])]

#text("Would you please add the tag “cocycle” to this post?")

#emph[#text("[OK – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dcb7c57ed69d39b3fc15144d61d3015274aaefa69266ec8e68044a6dd417c8b-40a3ae40fb9ccf2cbb3300836f6c19c7a71bf60bcb41bc19d4fdcebeba27dff3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mulukmuluk")]], [#link("https://terrytao.wordpress.com/2012/05/11/cayley-graphs-and-the-algebra-of-groups/#comment-696285")[#strong[#text("mulukmuluk")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("I drew the Van Kampen diagram in Blender, you can look at it in a JavaScript visualizer I got from ChatGPT here ")#link("https://villesalo.com/kuluma/VanKampen/van-kampen-viewer.html")[#text("Van Kampen diagram viewer (default is Hall-Witt)")]#text(". Some (very little) additional info in ")#link("https://symbolicdynamicsandotherthings.wordpress.com/2026/09/24/van-kampen-viewer-hall-witt/")[#text("Van Kampen viewer, Hall-Witt – SHIFT HAPPENS")]#text(".")
]
