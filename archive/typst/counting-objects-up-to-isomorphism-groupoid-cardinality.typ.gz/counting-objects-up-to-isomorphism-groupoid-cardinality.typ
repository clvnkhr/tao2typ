// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/
// Converted to Typst by tao2typ: "2026-10-14T16:38:07.189245+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Counting objects up to isomorphism: groupoid cardinality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Counting objects up to isomorphism: groupoid cardinality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 April 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/")[#text("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("How many groups of order four are there? Technically, there are an enormous number, so much so, in fact, that the class of groups of order four is not even a set, but merely a ")#link("https://en.wikipedia.org/wiki/Class_(set_theory)")[#text("proper class")]#text(". This is because ")#emph[#text("any")]#text(" four objects ")#mi("{a,b,c,d}")#text(" can be turned into a group ")#mi("{\\{a,b,c,d\\}}")#text(" by designating one of the four objects, say ")#mi("{a}")#text(", to be the group identity, and imposing a suitable multiplication table (and inversion law) on the four elements in a manner that obeys the usual group axioms. Since all sets are themselves objects, the class of four-element groups is thus at least as large as the class of all sets, which by Russell’s paradox is known not to itself be a set (assuming the usual ZFC axioms of set theory).")

#text("A much better question is to ask how many groups of order four there are ")#emph[#text("up to isomorphism")]#text(", counting each isomorphism class of groups exactly once. Now, as one learns in undergraduate group theory classes, the answer is just “two”: the cyclic group ")#mi("{C_4}")#text(" and the ")#link("https://en.wikipedia.org/wiki/Klein_four-group")[#text("Klein four-group")]#text(" ")#mi("{C_2 \\times C_2}")#text(".")

#text("More generally, given a class of objects ")#mi("{X}")#text(" and some equivalence relation ")#mi("{\\sim}")#text(" on ")#mi("{X}")#text(" (which one should interpret as describing the property of two objects in ")#mi("{X}")#text(" being “isomorphic”), one can consider the number ")#mi("{|X / \\sim|}")#text(" of objects in ")#mi("{X}")#text(" “up to isomorphism”, which is simply the cardinality of the collection ")#mi("{X/\\sim}")#text(" of equivalence classes ")#mi("{[x]:=\\{y\\in X:x \\sim {}y \\}}")#text(" of ")#mi("{X}")#text(". In the case where ")#mi("{X}")#text(" is finite, one can express this cardinality by the formula ")#metadata(none) <tao-bcceb06fd182e4d27e00>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("|X/\\sim| = \\sum_{x \\in X} \\frac{1}{\\left|[x]\\right|},", block: true)]]

#text("thus one counts elements in ")#mi("{X}")#text(", weighted by the reciprocal of the number of objects they are isomorphic to.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Let ")#mi("{X}")#text(" be the five-element set ")#mi("{\\{-2,-1,0,1,2\\}}")#text(" of integers between ")#mi("{-2}")#text(" and ")#mi("{2}")#text(". Let us say that two elements ")#mi("{x, y}")#text(" of ")#mi("{X}")#text(" are isomorphic if they have the same magnitude: ")#tao-math("{x \\sim y \\iff \\left|x\\right| = \\left|y\\right|}", block: false)#text(". Then the quotient space ")#mi("{X/\\sim}")#text(" consists of just three equivalence classes: ")#mi("{\\{-2,2\\} = [2] = [-2]}")#text(", ")#mi("{\\{-1,1\\} = [-1] = [1]}")#text(", and ")#mi("{\\{0\\} = [0]}")#text(". Thus there are three objects in ")#mi("{X}")#text(" up to isomorphism, and the identity ")#link(<tao-bcceb06fd182e4d27e00>)[#text("(1)")]#text(" is then just")

#align(center)[#tao-fit-display[#mitex("3 = \\frac{1}{2} + \\frac{1}{2} + 1 + \\frac{1}{2} + \\frac{1}{2}.")]]

#text("Thus, to count elements in ")#mi("{X}")#text(" up to equivalence, the elements ")#mi("{-2,-1,1,2}")#text(" are given a weight of ")#mi("{1/2}")#text(" because they are each isomorphic to two elements in ")#mi("{X}")#text(", while the element ")#mi("{0}")#text(" is given a weight of ")#mi("{1}")#text(" because it is isomorphic to just one element in ")#mi("{X}")#text(" (namely, itself).")
]

#text("Given a finite probability set ")#mi("{X}")#text(", there is also a natural probability distribution on ")#mi("{X}")#text(", namely the ")#emph[#text("uniform distribution")]#text(", according to which a random variable ")#mi("{\\mathbf{x} \\in X}")#text(" is set equal to any given element ")#mi("{x}")#text(" of ")#mi("{X}")#text(" with probability ")#tao-math("{\\frac{1}{\\left|X\\right|}}", block: false)#text(":")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\mathbf{x} = x ) = \\frac{1}{\\left|X\\right|}.", block: true)]]

#text("Given a notion ")#mi("{\\sim}")#text(" of isomorphism on ")#mi("{X}")#text(", one can then define the random equivalence class ")#mi("{[\\mathbf{x}] \\in X/\\sim}")#text(" that the random element ")#mi("{\\mathbf{x}}")#text(" belongs to. But if the isomorphism classes are unequal in size, we now encounter a biasing effect: even if ")#mi("{\\mathbf{x}}")#text(" was drawn uniformly from ")#mi("{X}")#text(", the equivalence class ")#mi("{[\\mathbf{x}]}")#text(" need not be uniformly distributed in ")#mi("{X/\\sim}")#text(". For instance, in the above example, if ")#mi("{\\mathbf{x}}")#text(" was drawn uniformly from ")#mi("{\\{-2,-1,0,1,2\\}}")#text(", then the equivalence class ")#mi("{[\\mathbf{x}]}")#text(" will not be uniformly distributed in the three-element space ")#mi("{X/\\sim}")#text(", because it has a ")#mi("{2/5}")#text(" probability of being equal to the class ")#mi("{\\{-2,2\\}}")#text(" or to the class ")#mi("{\\{-1,1\\}}")#text(", and only a ")#mi("{1/5}")#text(" probability of being equal to the class ")#mi("{\\{0\\}}")#text(".")

#text("However, it is possible to remove this bias by changing the weighting in ")#link(<tao-bcceb06fd182e4d27e00>)[#text("(1)")]#text(", and thus changing the notion of what cardinality means. To do this, we generalise the previous situation. Instead of considering sets ")#mi("{X}")#text(" with an equivalence relation ")#mi("{\\sim}")#text(" to capture the notion of isomorphism, we instead consider ")#link("https://en.wikipedia.org/wiki/Groupoid")[#text("groupoids")]#text(", which are sets ")#mi("{X}")#text(" in which there are allowed to be ")#emph[#text("multiple")]#text(" isomorphisms between elements in ")#mi("{X}")#text(" (and in particular, there are allowed to be multiple ")#emph[#text("automorphisms")]#text(" from an element to itself). More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2")]#text(" A groupoid is a set (or proper class) ")#mi("{X}")#text(", together with a (possibly empty) collection ")#mi("{\\mathrm{Iso}(x \\rightarrow y)}")#text(" of “isomorphisms” between any pair ")#mi("{x,y}")#text(" of elements of ")#mi("{X}")#text(", and a composition map ")#mi("{f, g \\mapsto g \\circ f}")#text(" from isomorphisms ")#mi("{f \\in \\mathrm{Iso}(x \\rightarrow y)}")#text(", ")#mi("{g \\in \\mathrm{Iso}(y \\rightarrow z)}")#text(" to isomorphisms in ")#mi("{\\mathrm{Iso}(x \\rightarrow z)}")#text(" for every ")#mi("{x,y,z \\in X}")#text(", obeying the following group-like axioms:")

#list(
[#text("(Identity) For every ")#mi("{x \\in X}")#text(", there is an identity isomorphism ")#mi("{\\mathrm{id}_x \\in \\mathrm{Iso}(x \\rightarrow x)}")#text(", such that ")#mi("{f \\circ \\mathrm{id}_x = \\mathrm{id}_y \\circ f = f}")#text(" for all ")#mi("{f \\in \\mathrm{Iso}(x \\rightarrow y)}")#text(" and ")#mi("{x,y \\in X}")#text(".")],
[#text("(Associativity) If ")#mi("{f \\in \\mathrm{Iso}(x \\rightarrow y)}")#text(", ")#mi("{g \\in \\mathrm{Iso}(y \\rightarrow z)}")#text(", and ")#mi("{h \\in \\mathrm{Iso}(z \\rightarrow w)}")#text(" for some ")#mi("{x,y,z,w \\in X}")#text(", then ")#mi("{h \\circ (g \\circ f) = (h \\circ g) \\circ f}")#text(".")],
[#text("(Inverse) If ")#mi("{f \\in \\mathrm{Iso}(x \\rightarrow y)}")#text(" for some ")#mi("{x,y \\in X}")#text(", then there exists an inverse isomorphism ")#mi("{f^{-1} \\in \\mathrm{Iso}(y \\rightarrow x)}")#text(" such that ")#mi("{f \\circ f^{-1} = \\mathrm{id}_y}")#text(" and ")#mi("{f^{-1} \\circ f = \\mathrm{id}_x}")#text(".")]
)

#text("We say that two elements ")#mi("{x,y}")#text(" of a groupoid are ")#emph[#text("isomorphic")]#text(", and write ")#mi("{x \\sim y}")#text(", if there is at least one isomorphism from ")#mi("{x}")#text(" to ")#mi("{y}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" ")#metadata(none) <tao-77af778b51abd4a3c51c>#text(" Any ")#link("https://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(" gives a groupoid by taking ")#mi("{X}")#text(" to be the set (or class) of objects, and ")#mi("{\\mathrm{Iso}(x \\rightarrow y)}")#text(" to be the collection of invertible morphisms from ")#mi("{x}")#text(" to ")#mi("{y}")#text(". For instance, in the category ")#mi("{\\mathbf{Set}}")#text(" of sets, ")#mi("{\\mathrm{Iso}(x \\rightarrow y)}")#text(" would be the collection of bijections from ")#mi("{x}")#text(" to ")#mi("{y}")#text("; in the category ")#mi("{\\mathbf{Vec}/k}")#text(" of linear vector spaces over some given base field ")#mi("{k}")#text(", ")#mi("{\\mathrm{Iso}(x \\rightarrow y)}")#text(" would be the collection of invertible linear transformations from ")#mi("{x}")#text(" to ")#mi("{y}")#text("; and so forth.")
]

#text("Every set ")#mi("{X}")#text(" equipped with an equivalence relation ")#mi("{\\sim}")#text(" can be turned into a groupoid by assigning precisely one isomorphism ")#mi("{\\iota_{x \\rightarrow y}}")#text(" from ")#mi("{x}")#text(" to ")#mi("{y}")#text(" for any pair ")#mi("{x,y \\in X}")#text(" with ")#mi("{x \\sim y}")#text(", and no isomorphisms from ")#mi("{x}")#text(" to ")#mi("{y}")#text(" when ")#mi("{x \\not \\sim y}")#text(", with the groupoid operations of identity, composition, and inverse defined in the only way possible consistent with the axioms. We will call this the ")#emph[#text("simply connected groupoid")]#text(" associated with this equivalence relation. For instance, with ")#mi("{X = \\{-2,-1,0,1,2\\}}")#text(" as above, if we turn ")#mi("{X}")#text(" into a simply connected groupoid, there will be precisely one isomorphism from ")#mi("{2}")#text(" to ")#mi("{-2}")#text(", and also precisely one isomorphism from ")#mi("{2}")#text(" to ")#mi("{2}")#text(", but no isomorphisms from ")#mi("{2}")#text(" to ")#mi("{-1}")#text(", ")#mi("{0}")#text(", or ")#mi("{1}")#text(".")

#text("However, one can also form multiply-connected groupoids in which there can be multiple isomorphisms from one element of ")#mi("{X}")#text(" to another. For instance, one can view ")#mi("{X = \\{-2,-1,0,1,2\\}}")#text(" as a space that is acted on by multiplication by the two-element group ")#mi("{\\{-1,+1\\}}")#text(". This gives rise to two types of isomorphisms, an identity isomorphism ")#mi("{(+1)_x}")#text(" from ")#mi("{x}")#text(" to ")#mi("{x}")#text(" for each ")#mi("{x \\in X}")#text(", and a negation isomorphism ")#mi("{(-1)_x}")#text(" from ")#mi("{x}")#text(" to ")#mi("{-x}")#text(" for each ")#mi("{x \\in X}")#text("; in particular, there are ")#emph[#text("two")]#text(" automorphisms of ")#mi("{0}")#text(" (i.e., isomorphisms from ")#mi("{0}")#text(" to itself), namely ")#mi("{(+1)_0}")#text(" and ")#mi("{(-1)_0}")#text(", whereas the other four elements of ")#mi("{X}")#text(" only have a single automorphism (the identity isomorphism). One defines composition, identity, and inverse in this groupoid in the obvious fashion (using the group law of the two-element group ")#mi("{\\{-1,+1\\}}")#text("); for instance, we have ")#mi("{(-1)_{-2} \\circ (-1)_2 = (+1)_2}")#text(".")

#text("For a finite multiply-connected groupoid, it turns out that ")#link("https://ncatlab.org/nlab/show/groupoid+cardinality")[#text("the natural notion of “cardinality”")]#text(" (or as I prefer to call it, “cardinality up to isomorphism”) is given by the variant")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in X} \\frac{1}{\\left|\\{ f: f \\in \\mathrm{Iso}(x \\rightarrow y) \\text{ for some } y\\}\\right|}", block: true)]]

#text("of ")#link(<tao-bcceb06fd182e4d27e00>)[#text("(1)")]#text(". That is to say, in the multiply connected case, the denominator is no longer the number of objects ")#mi("{y}")#text(" isomorphic to ")#mi("{x}")#text(", but rather the number of ")#emph[#text("isomorphisms")]#text(" from ")#mi("{x}")#text(" to other objects ")#mi("{y}")#text(". Grouping together all summands coming from a single equivalence class ")#mi("{[x]}")#text(" in ")#mi("{X/\\sim}")#text(", we can also write this expression as ")#metadata(none) <tao-30b40c297f904a8fcdd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{[x] \\in X/\\sim} \\frac{1}{\\left|\\mathrm{Aut}(x)\\right|}", block: true)]]

#text("where ")#mi("{\\mathrm{Aut}(x) := \\mathrm{Iso}(x \\rightarrow x)}")#text(" is the automorphism group of ")#mi("{x}")#text(", that is to say the group of isomorphisms from ")#mi("{x}")#text(" to itself. (Note that if ")#mi("{x,x^{\\prime}}")#text(" belong to the same equivalence class ")#mi("{[x]}")#text(", then the two groups ")#mi("{\\mathrm{Aut}(x)}")#text(" and ")#mi("{\\mathrm{Aut}(x^{\\prime})}")#text(" will be isomorphic and thus have the same cardinality, and so the above expression is well-defined.")

#text("For instance, if we take ")#mi("{X}")#text(" to be the simply connected groupoid on ")#mi("{\\{-2,-1,0,1,2\\}}")#text(", then the number of elements of ")#mi("{X}")#text(" up to isomorphism is")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} + \\frac{1}{2} + 1 + \\frac{1}{2} + \\frac{1}{2} = 1 + 1 + 1 = 3")]]

#text("exactly as before. If however we take the multiply connected groupoid on ")#mi("{\\{-2,-1,0,1,2\\}}")#text(", in which ")#mi("{0}")#text(" has two automorphisms, the number of elements of ")#mi("{X}")#text(" up to isomorphism is now the smaller quantity")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} + \\frac{1}{2} + \\frac{1}{2} + \\frac{1}{2} + \\frac{1}{2} = 1 + \\frac{1}{2} + 1 = \\frac{5}{2};")]]

#text("the equivalence class ")#mi("{[0]}")#text(" is now counted with weight ")#mi("{1/2}")#text(" rather than ")#mi("{1}")#text(" due to the two automorphisms on ")#mi("{0}")#text(". Geometrically, one can think of this groupoid as being formed by taking the five-element set ")#mi("{\\{-2,-1,0,1,2\\}}")#text(", and “folding it in half” around the fixed point ")#mi("{0}")#text(", giving rise to two “full” quotient points ")#mi("{[1], [2]}")#text(" and one “half” point ")#mi("{[0]}")#text(". More generally, given a finite group ")#mi("{G}")#text(" acting on a finite set ")#mi("{X}")#text(", and forming the associated multiply connected groupoid, the cardinality up to isomorphism of this groupoid will be ")#tao-math("{\\left|X\\right|/\\left|G\\right|}", block: false)#text(", since each element ")#mi("{x}")#text(" of ")#mi("{X}")#text(" will have ")#tao-math("{\\left|G\\right|}", block: false)#text(" isomorphisms on it (whether they be to the same element ")#mi("{x}")#text(", or to other elements of ")#mi("{X}")#text(").")

#text("The definition ")#link(<tao-30b40c297f904a8fcdd8>)[#text("(2)")]#text(" can also make sense for some infinite groupoids; to my knowledge this was first explicitly done in ")#link("https://arxiv.org/abs/math/0004133")[#text("this paper of Baez and Dolan")]#text(". Consider for instance the category ")#mi("{\\mathbf{FinSet}}")#text(" of finite sets, with isomorphisms given by bijections as in Example ")#link(<tao-77af778b51abd4a3c51c>)[#text("3")]#text(". Every finite set is isomorphic to ")#mi("{\\{1,\\dots,n\\}}")#text(" for some natural number ")#mi("{n}")#text(", so the equivalence classes of ")#mi("{\\mathbf{FinSet}}")#text(" may be indexed by the natural numbers. The automorphism group ")#mi("{S_n}")#text(" of ")#mi("{\\{1,\\dots,n\\}}")#text(" has order ")#mi("{n!}")#text(", so the cardinality of ")#mi("{\\mathbf{FinSet}}")#text(" up to isomorphism is")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^\\infty \\frac{1}{n!} = e.")]]

#text("(This fact is sometimes loosely stated as “the number of finite sets is ")#mi("{e}")#text("“, but I view this statement as somewhat misleading if the qualifier “up to isomorphism” is not added.) Similarly, when one allows for multiple isomorphisms from a group to itself, the number of groups of order four up to isomorphism is now")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} + \\frac{1}{6} = \\frac{2}{3}")]]

#text("because the cyclic group ")#mi("{C_4}")#text(" has two automorphisms, whereas the Klein four-group ")#mi("{C_2 \\times C_2}")#text(" has six.")

#text("In the case that the cardinality of a groupoid ")#mi("{X}")#text(" up to isomorphism is finite and non-empty, one can now define the notion of a random isomorphism class ")#mi("{[\\mathbf{x}]}")#text(" in ")#mi("{X/\\sim}")#text(" drawn “uniformly up to isomorphism”, by requiring the probability of attaining any given isomorphism class ")#mi("{[x]}")#text(" to be")

#align(center)[#tao-fit-display[#tao-math("{\\mathbf P}([\\mathbf{x}] = [x]) = \\frac{1 / \\left|\\mathrm{Aut}(x)\\right|}{\\sum_{[y] \\in X/\\sim} 1/\\left|\\mathrm{Aut}(y)\\right|},", block: true)]]

#text("thus the probability of being isomorphic to a given element ")#mi("{x}")#text(" will be inversely proportional to the number of automorphisms that ")#mi("{x}")#text(" has. For instance, if we take ")#mi("{X}")#text(" to be the set ")#mi("{\\{-2,-1,0,1,2\\}}")#text(" with the simply connected groupoid, ")#mi("{[\\mathbf{x}]}")#text(" will be drawn uniformly from the three available equivalence classes ")#mi("{[0], [1], [2]}")#text(", with a ")#mi("{1/3}")#text(" probability of attaining each; but if instead one uses the multiply connected groupoid coming from the action of ")#mi("{\\{-1,+1\\}}")#text(", and draws ")#mi("{[\\mathbf{x}]}")#text(" uniformly up to isomorphism, then ")#mi("{[1]}")#text(" and ")#mi("{[2]}")#text(" will now be selected with probability ")#mi("{2/5}")#text(" each, and ")#mi("{[0]}")#text(" will be selected with probability ")#mi("{1/5}")#text(". Thus this distribution has accounted for the bias mentioned previously: if a finite group ")#mi("{G}")#text(" acts on a finite space ")#mi("{X}")#text(", and ")#mi("{\\mathbf{x}}")#text(" is drawn uniformly from ")#mi("{X}")#text(", then ")#mi("{[\\mathbf{x}]}")#text(" now still be drawn uniformly up to isomorphism from ")#mi("{X/G}")#text(", if we use the multiply connected groupoid coming from the ")#mi("{G}")#text(" action, rather than the simply connected groupoid coming from just the ")#mi("{G}")#text("-orbit structure on ")#mi("{X}")#text(".")

#text("Using the groupoid of finite sets, we see that a finite set chosen uniformly up to isomorphism will have a cardinality that is distributed according to the Poisson distribution of parameter ")#mi("{1}")#text(", that is to say it will be of cardinality ")#mi("{n}")#text(" with probability ")#mi("{\\frac{e^{-1}}{n!}}")#text(".")

#text("One important source of groupoids are the ")#link("https://ncatlab.org/nlab/show/fundamental+groupoid")[#text("fundamental groupoids")]#text(" ")#mi("{\\pi_1(M)}")#text(" of a manifold ")#mi("{M}")#text(" (one can also consider more general topological spaces than manifolds, but for simplicity we will restrict this discussion to the manifold case), in which the underlying space is simply ")#mi("{M}")#text(", and the isomorphisms from ")#mi("{x}")#text(" to ")#mi("{y}")#text(" are the equivalence classes of paths from ")#mi("{x}")#text(" to ")#mi("{y}")#text(" up to homotopy; in particular, the automorphism group of any given point is just the fundamental group of ")#mi("{M}")#text(" at that base point. The equivalence class ")#mi("{[x]}")#text(" of a point in ")#mi("{M}")#text(" is then the connected component of ")#mi("{x}")#text(" in ")#mi("{M}")#text(". The cardinality up to isomorphism of the fundamental groupoid is then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{M^{\\prime} \\in \\pi_0(M)} \\frac{1}{\\left|\\pi_1(M^{\\prime})\\right|}", block: true)]]

#text("where ")#mi("{\\pi_0(M)}")#text(" is the collection of connected components ")#mi("{M^{\\prime}}")#text(" of ")#mi("{M}")#text(", and ")#tao-math("{\\left|\\pi_1(M^{\\prime})\\right|}", block: false)#text(" is the order of the fundamental group of ")#mi("{M^{\\prime}}")#text(". Thus, simply connected components of ")#mi("{M}")#text(" count for a full unit of cardinality, whereas multiply connected components (which can be viewed as quotients of their simply connected cover by their fundamental group) will count for a fractional unit of cardinality, inversely to the order of their fundamental group.")

#text("This notion of cardinality up to isomorphism of a groupoid behaves well with respect to various basic notions. For instance, suppose one has an ")#mi("{n}")#text("-fold covering map ")#mi("{\\pi: X \\rightarrow Y}")#text(" of one finite groupoid ")#mi("{Y}")#text(" by another ")#mi("{X}")#text(". This means that ")#mi("{\\pi}")#text(" is a functor that is surjective, with all preimages of cardinality ")#mi("{n}")#text(", with the property that given any pair ")#mi("{y,y^{\\prime}}")#text(" in the base space ")#mi("{Y}")#text(" and any ")#mi("{x}")#text(" in the preimage ")#mi("{\\pi^{-1}(\\{y\\})}")#text(" of ")#mi("{y}")#text(", every isomorphism ")#mi("{f \\in \\mathrm{Iso}(y \\rightarrow y^{\\prime})}")#text(" has a unique lift ")#mi("{\\tilde f \\in \\mathrm{Iso}(x \\rightarrow x^{\\prime})}")#text(" from the given initial point ")#mi("{x}")#text(" (and some ")#mi("{x^{\\prime}}")#text(" in the preimage of ")#mi("{y^{\\prime}}")#text("). Then one can check that the cardinality up to isomorphism of ")#mi("{X}")#text(" is ")#mi("{n}")#text(" times the cardinality up to isomorphism of ")#mi("{Y}")#text(", which fits well with the geometric picture of ")#mi("{X}")#text(" as the ")#mi("{n}")#text("-fold cover of ")#mi("{Y}")#text(". (For instance, if one covers a manifold ")#mi("{M}")#text(" with finite fundamental group by its universal cover, this is a ")#tao-math("{\\left|\\pi_1(M)\\right|}", block: false)#text("-fold cover, the base has cardinality ")#tao-math("{1/\\left|\\pi_1(M)\\right|}", block: false)#text(" up to isomorphism, and the universal cover has cardinality one up to isomorphism.) Related to this, if one draws an equivalence class ")#mi("{[\\mathrm{x}]}")#text(" of ")#mi("{X}")#text(" uniformly up to isomorphism, then ")#mi("{\\pi([\\mathrm{x}])}")#text(" will be an equivalence class of ")#mi("{Y}")#text(" drawn uniformly up to isomorphism also.")

#text("Indeed, one can show that this notion of cardinality up to isomorphism for groupoids is uniquely determined by a small number of axioms such as these (similar to the axioms that determine ")#link("https://en.wikipedia.org/wiki/Euler_characteristic")[#text("Euler characteristic")]#text("); see ")#link("https://qchu.wordpress.com/2012/11/08/groupoid-cardinality/")[#text("this blog post of Qiaochu Yuan")]#text(" for details.")

#text("The probability distributions on isomorphism classes described by the above recipe seem to arise naturally in many applications. For instance, if one draws a profinite abelian group up to isomorphism at random in this fashion (so that each isomorphism class ")#mi("{[G]}")#text(" of a profinite abelian group ")#mi("{G}")#text(" occurs with probability inversely proportional to the number of automorphisms of this group), then the resulting distribution is known as the ")#emph[#text("Cohen-Lenstra distribution")]#text(", and seems to emerge as the natural asymptotic distribution of many randomly generated profinite abelian groups in number theory and combinatorics, such as the class groups of random quadratic fields; see ")#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/")[#text("this previous blog post")]#text(" for more discussion. For a simple combinatorial example, the set of fixed points of a random permutation on ")#mi("{n}")#text(" elements will have a cardinality that converges in distribution to the Poisson distribution of rate ")#mi("{1}")#text(" (as discussed in ")#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/")[#text("this previous post")]#text("), thus we see that the fixed points of a large random permutation asymptotically are distributed uniformly up to isomorphism. I’ve been told that this notion of cardinality up to isomorphism is also particularly compatible with ")#link("https://en.wikipedia.org/wiki/Stack_(mathematics)")[#text("stacks")]#text(" (which are a good framework to describe such objects as moduli spaces of algebraic varieties up to isomorphism), though I am not sufficiently acquainted with this theory to say much more than this.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479820")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#text("Very interesting! Thanks for sharing your insights! :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/818a3c18f002ddf4fb12759f52b2f7c4289900d81259facfca7627e656d0df3f-42f2acc30ef4c5bccfdc3ba3918b0d104cff941288d33eb16dcc5dc70a6812fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesus Ochoa")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479825")[#strong[#text("Jesus Ochoa")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#text("In the case of stacks, the notion of cardinality has been developed by Weinstein in ")#link("https://arxiv.org/pdf/0809.2130.pdf")[#text("https://arxiv.org/pdf/0809.2130.pdf")]#text(", where it has been called te volume of a stack.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43fc9b908ce5068ca05032b931a39e35c364a611c52741b287f2a89aa8c0c3f-e99ac61b40b88e7dff88ff3fc721bd7040f4c729f5e9cb9fa13e731c524126c3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oscar Cunningham")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479836")[#strong[#text("Oscar Cunningham")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#text("I was thinking about this just the other day. One nice thing that I noticed was that groupoid cardinality behaves nicely with respect to adding additional structure. For example suppose we try to calculate the cardinality of “groups equipped with a chosen element”. Obviously for each group G there will be one such structure up to isomorphism for each orbit of G under Aut(G). The structure (G,g) has size 1/|Aut(G,g)|, and by the orbit-stabilizer theorem this is equal to |G(g)| / |Aut(G)|.")

#text("So if we sum the cardinalities of all the structures with underlying group G we get |G| / |Aut(G)|. So despite the fact that we were counting everything up to isomorphism, we still get that there are |G| ways of picking an element from G!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2ab8856d742c1696913c0bf1ed207f28dcb4380b42d9a6ec993dbb237d5c249-4de5c63fc347e727bb5e99f8736e138dc1ca4848f002ad999353b70486a59af3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ridder")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479840")[#strong[#text("Ridder")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2017")])]

#text("In definition 2, I’m confused about the Identity part: The requirement that Id_y = f, for all f in Iso(x->y) and all x,y in X, it seems strange? Then Iso(x->y) is just {Id_Y}?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a74cc7e05b1e1b19fa17cb484ffb8144e88c560f96940051cb8c44af8bb7df8-9100c6d31c7c9a188cd47ea5568e5d97493b0032c5faa2a698afdd19eb880682.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Azad Tasan")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479841")[#strong[#text("Azad Tasan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2017")])]

#text("I think the second “=” was supposed to be another composition sign, that is f ( Id_x ) = Id_y( f ). Just my guess though.")

#text("[")#emph[#text("Corrected, thanks -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479846")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2017")])]

#text("In addition to the fix mentioned above (which you made), I think you still want the “=f” at the end (otherwise the identity maps can act like an idempotent projection). So the correct formula should have two equalities: f \\circ id_X = id_Y \\circ f = f.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479844")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2017")])]

#text("In the third paragraph the set of all y which are in the same equivalence class as x should read [x]= { y \\in X : x~y } and not [x]= { y \\in X : x~X }.")

#text("Great article!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/280eb763735af9573fe0d6e75160fdf49201f7fc4518e12e9dcfa711d060e39c-18f8b145e6dd0013890319f91ec2381fab0403832c045f9c7cb662b5103fceab.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479845")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2017")])]

#text("Thanks tao for that article (interestingly fascinating)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479897")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2017")])]

#text("I think, even without resorting to functors or hodge theory, the exercise of counting can be rather difficult. We count various things: fish, sources of income, distance to work, etc. This discretization process varies from person to person, and task to task.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a546db3ac050d6fb1166654a6ec5b59d8fe14135c78763b526bb48a0feff7bea-f5a3de93dee35e094a1b084f43d03dbd040edaf55161203fab4ff5e24628d806.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bf")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479924")[#strong[#text("bf")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2017")])]

#text("For algebraic stacks wthere is a well-defined notion of Chow groups with rational coefficients since the paper of ")#link("https://eudml.org/doc/143716")[#text("Vistoli")]#text(" in 1989; the counting you describe corresponds to the degree (pushforward to a point) of a discrete (smooth, zero dimensional) Deligne-Mumford algebraic stack.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-479951")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("Maybe it is worth mentioning that in combinatorics counting according to isomorphism classes is a very important problem and Burnside lemma and ")#link("https://en.wikipedia.org/wiki/P%C3%B3lya_enumeration_theorem")[#text("Polya theory")]#text(" are quite crucial.")

#text("(On a lighter note the discussion of the number of groups of order four reminds me the discussion of the question: ")#link("https://gilkalai.wordpress.com/2011/07/19/in-how-many-ways-you-can-chose-a-committee-of-three-students-from-a-class-of-ten-students/")[#text("In how many ways you can chose a committee of three students from a class of ten students?")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-480046")[#strong[#text("Groups and Group Actions: Lecture 9 | Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2017")]

#text("[…] Tao has just been writing on his blog about classifying objects up to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ofitserov")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-480092")[#strong[#text("Sergei Ofitserov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2017")])]

#text("Dear Terence Tao! Your formula(1) irreproachable! There is elements of expected tasked put a question,meaning whats I can to explain. First, I right away pay attention to unknown divisor |X/~|,what have direct attitude to objects of ascent (raise) up to isomorphism. Secondly, |[x]| in double brackets – that x in closed space (lift in tower of Erdesh). So like, what I know, how liberate (to free) x from closed space. Thus, for a start we necessary to compose plan of operations (or what we necessary?) 1.Quantity groups. 2.Expansion groups. 3. Compress groups. It is possible, the fact that you get to know, perhaps shock or amazement. Secret in divisor! 1. If in |X/~| to put (under) numerical meanings, that which receive: for example X=2017 (this number we know), and ~ = 0,9999. If to make this operation of division on 16-digits calculator, then receive endless quantity groups 2017 2.If in X for example add 0, or X=20017, and in divisor add one 9, or ~ =0,99999, then receive endless quantity groups 20017. 3.If in X=2017 to remove 0, and in divisor to remove one 9, or X=217 and -~ = 0,999, then receive endless quantity groups 217. In all three cases concept of endlessness remain (intact). Thanks. Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54474ad735b5752e6b21a0157a7da0a757e05f1fa88bca7dcd8b1733a9793566-29ce7abc696caab64773312d053db68ec91dfc253ece9f7709847bef02c471f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tan Wei Shing")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-481245")[#strong[#text("Tan Wei Shing")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2017")])]

#text("What a mumbo-jumbo calculation that really intriguing me! Math is definitely my love and passion, appreciate your insights!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/#comment-481549")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2017")])]

#text("It seems as though groupoid cardinality gives a framework for counting the number of “essentially different” objects of a given category. In fact, categories are defined by the axioms which are to be satisfied by the objects therein. Thus, one may define the notion of “categoricity” in terms of groupoid cardinality: A system of axioms is then categorical iff the cardinality of the corresponding category=groupoid up to isomorphism is one.")

#text("For the notion of categoricity see this paper by O. Veblen:")

#link("http://www.ams.org/journals/tran/1904-005-03/S0002-9947-1904-1500678-X/S0002-9947-1904-1500678-X.pdf")[#text("Click to access S0002-9947-1904-1500678-X.pdf")]
]
