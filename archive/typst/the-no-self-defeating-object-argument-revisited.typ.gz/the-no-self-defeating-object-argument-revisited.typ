// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/
// Converted to Typst by tao2typ: "2026-10-14T09:04:26.751815+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The “no self-defeating object” argument, revisited", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The “no self-defeating object” argument, revisited")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 October 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/")[#text("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One notable feature of mathematical reasoning is the reliance on ")#link("http://en.wikipedia.org/wiki/Counterfactual_thinking")[#text("counterfactual thinking")]#text(" – taking a hypothesis (or set of hypotheses) which may or may not be true, and following it (or them) to its logical conclusion. For instance, most propositions in mathematics start with a set of hypotheses (e.g. “Let ")#mi("n")#text(" be a natural number such that …”), which may or may not apply to the particular value of ")#mi("n")#text(" one may have in mind. Or, if one ever argues by dividing into separate cases (e.g. “Case 1: ")#mi("n")#text(" is even. … Case 2: ")#mi("n")#text(" is odd. …”), then for any given ")#mi("n")#text(", at most one of these cases would actually be applicable, with the other cases being counterfactual alternatives. But the purest example of counterfactual thinking in mathematics comes when one employs a ")#link("http://en.wikipedia.org/wiki/Proof_by_contradiction")[#text("proof by contradiction")]#text(" (or ")#emph[#text("reductio ad absurdum")]#text(") – one introduces a hypothesis that in fact has no chance of being true at all (e.g. “Suppose for sake of contradiction that ")#mi("\\sqrt{2}")#text(" is equal to the ratio ")#mi("p/q")#text(" of two natural numbers.”), and proceeds to demonstrate this fact by showing that this hypothesis leads to absurdity.")

#text("Experienced mathematicians are so used to this type of counterfactual thinking that it is sometimes difficult for them to realise that it this type of thinking is not automatically intuitive for students or non-mathematicians, who can anchor their thinking on the single, “real” world to the extent that they cannot easily consider hypothetical alternatives. This can lead to confused exchanges such as the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Lecturer: “Theorem. Let ")#mi("p")#text(" be a prime number. Then…”")

#text("Student: “But how do you know that ")#mi("p")#text(" is a prime number? Couldn’t it be composite?”")
]

#text("or")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Lecturer: “Now we see what the function ")#mi("f")#text(" does when we give it the input of ")#mi("x+dx")#text(" instead. …”")

#text("Student: “But didn’t you just say that the input was equal to ")#mi("x")#text(" just a moment ago?”")
]

#text("This is not to say that counterfactual thinking is not encountered at all outside of mathematics. For instance, an obvious source of counterfactual thinking occurs in fictional writing or film, particularly in ")#link("http://en.wikipedia.org/wiki/Speculative_fiction")[#text("speculative fiction")]#text(" such as science fiction, fantasy, or alternate history. Here, one can certainly take one or more counterfactual hypotheses (e.g. “what if magic really existed?”) and follow them to see what conclusions would result. The analogy between this and mathematical counterfactual reasoning is not perfect, of course: in fiction, consequences are usually not logically entailed by their premises, but are instead driven by more ")#link("http://en.wikipedia.org/wiki/Contingency_(philosophy)")[#text("contingent")]#text(" considerations, such as the need to advance the plot, to entertain or emotionally affect the reader, or to make some moral or ideological point, and these types of narrative elements are almost completely absent in mathematical writing. Nevertheless, the analogy can be somewhat helpful when one is first coming to terms with mathematical reasoning. For instance, the mathematical concept of a proof by contradiction can be viewed as roughly analogous in some ways to such literary concepts as ")#link("http://en.wikipedia.org/wiki/Satire")[#text(" satire")]#text(", ")#link("http://en.wikipedia.org/wiki/Dark_humour")[#text("dark humour")]#text(", or ")#link("http://en.wikipedia.org/wiki/Absurdist_fiction")[#text("absurdist fiction,")]#text(" in which one takes a premise specifically with the intent to derive absurd consequences from it. And if the proof of (say) a lemma is analogous to a short story, then the ")#emph[#text("statement")]#text(" of that lemma can be viewed as analogous to the ")#emph[#text("moral")]#text(" of that story.")

#text("Another source of counterfactual thinking outside of mathematics comes from ")#link("http://en.wikipedia.org/wiki/Simulation")[#text("simulation")]#text(", when one feeds some initial data or hypotheses (that may or may not correspond to what actually happens in the real world) into a simulated environment (e.g. a piece of computer software, a laboratory experiment, or even just a ")#link("http://en.wikipedia.org/wiki/Thought-experiment")[#text("thought-experiment")]#text("), and then runs the simulation to see what consequences result from these hypotheses. Here, proof by contradiction is roughly analogous to the “")#link("http://en.wikipedia.org/wiki/Garbage_In,_Garbage_Out")[#text("garbage in, garbage out")]#text("” phenomenon that is familiar to anyone who has worked with computers: if one’s initial inputs to a simulation are not consistent with the hypotheses of that simulation, or with each other, one can obtain bizarrely illogical (and sometimes unintentionally amusing) outputs as a result; and conversely, such outputs can be used to detect and diagnose problems with the data, hypotheses, or implementation of the simulation.")

#text("Despite the presence of these non-mathematical analogies, though, proofs by contradiction are still often viewed with suspicion and unease by many students of mathematics. Perhaps the quintessential example of this is the standard proof of ")#link("http://en.wikipedia.org/wiki/Cantor's_theorem")[#text("Cantor’s theorem")]#text(" that the set ")#mi("{\\bf R}")#text(" of real numbers is uncountable. This is about as short and as elegant a proof by contradiction as one can have without being utterly trivial, and despite this (or perhaps ")#emph[#text("because")]#text(" of this) it seems to offend the reason of many people when they are first exposed to it, to an extent far greater than most other results in mathematics. (The only other two examples I know of that come close to doing this are the fact that the real number ")#mi("0.999\\ldots")#text(" is equal to 1, and the solution to the ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("blue-eyed islanders puzzle")]#text(".)")

#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("Some time ago on this blog")]#text(", I collected a family of well-known results in mathematics that were proven by contradiction, and specifically by a type of argument that I called the “no self-defeating object” argument; that any object that was so ridiculously overpowered that it could be used to “defeat” its own existence, could not actually exist. Many basic results in mathematics can be phrased in this manner: not only Cantor’s theorem, but ")#link("http://en.wikipedia.org/wiki/Euclid%27s_theorem")[#text("Euclid’s theorem")]#text(" on the infinitude of primes, ")#link("http://en.wikipedia.org/wiki/G%C3%B6del's_incompleteness_theorems")[#text("Gödel’s incompleteness theorem")]#text(", or the conclusion (from ")#link("http://en.wikipedia.org/wiki/Russell's_paradox")[#text("Russell’s paradox")]#text(") that the class of all sets cannot itself be a set.")

#text("I presented each of these arguments in the usual “proof by contradiction” manner; I made the counterfactual hypothesis that the impossibly overpowered object existed, and then used this to eventually derive a contradiction. Mathematically, there is nothing wrong with this reasoning, but because the argument spends almost its entire duration inside the bizarre counterfactual universe caused by an impossible hypothesis, readers who are not experienced with counterfactual thinking may view these arguments with unease.")

#text("It was pointed out to me, though (originally with regards to Euclid’s theorem, but the same point in fact applies to the other results I presented) that one can pull a large fraction of each argument out of this counterfactual world, so that one can see most of the argument directly, without the need for any intrinsically impossible hypotheses. This is done by converting the “no self-defeating object” argument into a logically equivalent “any object can be defeated” argument, with the former then being viewed as an immediate corollary of the latter. This change is almost trivial to enact (it is often little more than just taking the ")#link("http://en.wikipedia.org/wiki/Contraposition")[#text("contrapositive")]#text(" of the original statement), but it does offer a slightly different “non-counterfactual” (or more precisely, “not necessarily counterfactual”) perspective on these arguments which may assist in understanding how they work.")

#text("For instance, consider the very first no-self-defeating result presented in the previous post:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (No largest natural number).")]#text(" There does not exist a natural number ")#mi("N")#text(" that is larger than all the other natural numbers.")
]

#text("This is formulated in the “no self-defeating object” formulation. But it has a logically equivalent “any object can be defeated” form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1′.")]#text(" Given any natural number ")#mi("N")#text(", one can find another natural number ")#mi("N^{\\prime}")#text(" which is larger than ")#mi("N")#text(".")
]

#strong[#text("Proof.")]#text(" Take ")#mi("N^{\\prime} := N+1")#text(". ")#mi("\\Box")

#text("While Proposition 1 and Proposition 1′ are logically equivalent to each other, note one key difference: Proposition 1′ can be illustrated with examples (e.g. take ")#mi("N = 100")#text(", so that the proof gives ")#mi("N^{\\prime}=101")#text(" ), whilst Proposition 1 cannot (since there is, after all, no such thing as a largest natural number). So there is a sense in which Proposition 1′ is more “non-counterfactual” or “constructive” than the “counterfactual” Proposition 1.")

#text("In a similar spirit, ")#link("http://en.wikipedia.org/wiki/Euclid's_theorem")[#text("Euclid’s theorem")]#text(" (which we give using the numbering from the ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("previous post")]#text("),")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3.")]#text(" There are infinitely many primes.")
]

#text("can be recast in “all objects can be defeated” form as")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3′")]#text(". Let ")#mi("p_1,\\ldots,p_n")#text(" be a collection of primes. Then there exists a prime ")#mi("q")#text(" which is distinct from any of the primes ")#mi("p_1,\\ldots,p_n")#text(".")
]

#strong[#text("Proof.")]#text(" Take ")#mi("q")#text(" to be any prime factor of ")#mi("p_1 \\ldots p_n + 1")#text(" (for instance, one could take the smallest prime factor, if one wished to be completely concrete). Since ")#mi("p_1 \\ldots p_n + 1")#text(" is not divisible by any of the primes ")#mi("p_1,\\ldots,p_n")#text(", ")#mi("q")#text(" must be distinct from all of these primes. ")#mi("\\Box")

#text("One could argue that there was a slight use of proof by contradiction in the proof of Proposition 3′ (because one had to briefly entertain and then rule out the counterfactual possibility that ")#mi("q")#text(" was equal to one of the ")#mi("p_1,\\ldots,p_n")#text("), but the proposition itself is not inherently counterfactual, as it does not make as patently impossible a hypothesis as a finite enumeration of the primes. Incidentally, it can be argued that the proof of Proposition 3′ is closer in spirit to Euclid’s original proof of his theorem, than the proof of Proposition 3 that is usually given today. Again, Proposition 3′ is “constructive”; one can apply it to any finite list of primes, say ")#mi("2, 3, 5")#text(", and it will actually exhibit a prime not in that list (in this case, ")#mi("31")#text("). The same cannot be said of Proposition 3, despite the logical equivalence of the two statements.")

#text("[")#emph[#text("Note")]#text(": the article below may make more sense if one first reviews the ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("previous blog post")]#text(" on the “no self-defeating object”. For instance, the section and theorem numbering here is deliberately chosen to match that of the preceding post.]")

#metadata(none) <tao-cb3ecd7ffdd64e0f8624>

#heading(level: 1)[#strong[#text("— 1. Set theory —")]]

#text("Now we revisit examples of the no-self-defeating object in set theory. Take, for instance, ")#link("http://en.wikipedia.org/wiki/Cantor's_theorem")[#text("Cantor’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6.")]#text(" The reals are uncountable.")
]

#text("One can easily recast this in a “non-counterfactual” or “all objects can be defeated” form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6′.")]#text(" Let ")#mi("x_1, x_2, x_3, \\ldots")#text(" be a countable sequence of real numbers (possibly with repetition). Then there exists a real number ")#mi("y")#text(" that is not equal to any of the ")#mi("x_1, x_2, x_3, \\ldots")#text(".")
]

#strong[#text("Proof.")]#text(" Set ")#mi("y")#text(" equal to ")#mi("y = 0.a_1a_2a_3\\ldots")#text(", where")

#enum(start: 1, 
[#mi("a_1")#text(" is the smallest digit in ")#mi("\\{0,\\ldots,9\\}")#text(" that is not equal to the first digit past the decimal point of any decimal representation of ")#mi("x_1")#text(";")],
[#mi("a_2")#text(" is the smallest digit in ")#mi("\\{0,\\ldots,9\\}")#text(" that is not equal to the second digit past the decimal point of any decimal representation of ")#mi("x_2")#text(";")],
[#text("etc.")]
)

#text("(Here we write “any” decimal representation rather than “the” decimal representation to deal with the annoying ")#mi("0.999\\ldots = 1.000\\ldots")#text(" issue mentioned earlier. As with the proof of Euclid’s theorem, there is nothing special about taking the smallest digit here; this is just for sake of concreteness.) Note that any real number has at most two decimal representations, and there are ten digits available, so one can always find ")#mi("a_1, a_2, ...")#text(" with the desired properties. Then, by construction, the real number ")#mi("y")#text(" cannot equal ")#mi("x_1")#text(" (because it differs in the first digit from any of the decimal representations of ")#mi("x_1")#text("), it cannot equal ")#mi("x_2")#text(" (because it differs in the second digit), and so forth. ")#mi("\\Box")

#text("Again, Proposition 6′ is trivially equivalent to Proposition 6, and still briefly uses contradiction in its proof, but in this non-counterfactual form one can actually illustrate it with examples. For instance, one could start with a list of terminating decimals, starting with the single digit terminating decimals, the two-digit terminating decimals, and so forth:")

#tao-aligned(keep: true)[


#tao-math("x_1  & := 0.1, \\quad x_2 := 0.2, \\quad x_3 := 0.3, \\quad \\ldots \\quad x_9 := 0.9,", block: true)



#tao-math("x_{10}  & := 0.01, \\quad x_{11} := 0.02, \\quad \\ldots \\quad x_{108} := 0.99,", block: true)



#tao-math("x_{109}  & := 0.001, \\quad x_{110} := 0.002, \\quad \\ldots \\quad x_{1007} := 0.999,", block: true)
]

#align(center)[#tao-fit-display[#mitex("\\ldots")]]

#text("and one then sees that the construction will, in this case, give the number ")#mi("y = 0.21111\\ldots")#text(", which indeed does not occur on the above list.")

#text("It is instructive to try to “outrun” Proposition 6′ by modifying the list to accommodate ")#mi("0.2111\\ldots")#text(" to the list. One cannot simply tack on this number “at the end” of this list, as the list is infinite and does not actually have an end. One can insert it at, say, the beginning of the list, and then move all the other numbers down one, but then Proposition 6′ gives a new number not on the list (in this case, ")#mi("0.0111\\ldots")#text("). One can add that number to the list also, bumping everyone else down one, but then Proposition 6′ gives yet another number not on the list (in this case, ")#mi("0.10111\\ldots")#text("). After doing this a few times, one can begin to appreciate how Proposition 6′ always defeats any attempt to outrun it, much as one cannot obtain a largest natural number by continually adding +1 to one’s previous proposed candidate.")

#text("It is also remarkable how inoffensive Proposition 6′ and its proof is, when compared against the reaction one sometimes encounters to Proposition 6, which is logically equivalent. A single ")#link("http://en.wikipedia.org/wiki/Contraposition")[#text("contraposition")]#text(" can dramatically change one’s impression of a result.")

#text("In a similar spirit, the result")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (No universal set)")]#text(" There does not exist a set that contains all sets (including itself).")
]

#text("(which, of course, assumes one is working in something like the ")#link("http://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory")[#text("Zermelo-Frankel axioms of set theory")]#text(") becomes")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4′")]#text(". Given any set A, there exists a set B which is not an element of A.")
]

#strong[#text("Proof.")]#text(" Consider the set")

#align(center)[#mi("B := \\{ C \\in A: C \\not \\in C \\}")#text(";")]

#text("the existence of this set is guaranteed by the ")#link("http://en.wikipedia.org/wiki/Axiom_schema_of_specification")[#text("axiom schema of specification")]#text(". If ")#mi("B")#text(" was an element of itself, then by construction we would have ")#mi("B \\not \\in B")#text(", a contradiction. Thus we must have ")#mi("B \\not \\in B")#text(". From construction, this forces ")#mi("B \\not \\in A")#text(". ")#mi("\\Box")

#text("In the usual axiomatic formulation of set theory, the ")#link("http://en.wikipedia.org/wiki/Axiom_of_regularity")[#text("axiom of foundation")]#text(" implies, among other things, that no set is an element of itself. With that axiom, the set B given by Proposition 4′ is nothing other than A itself, which by the axiom of foundation is not an element of A. But since the axiom of foundation was not used in the proof of Proposition 4′, one can also explore (counterfactually!) what happens in set theories in which one does not assume the axiom of foundation. Suppose, for instance, that one managed somehow to produce a set A that contained itself as its only element: ")#mi("A = \\{A\\}")#text(". (Informally, one could think of ")#mi("A")#text(" as an infinite nested chain, ")#mi("A : =\\{ \\{ \\{\\ldots \\} \\} \\}")#text(".) Then the only element that ")#mi("A")#text(" has, namely ")#mi("A")#text(", is an element of itself, so the set ")#mi("B")#text(" produced by Proposition 4′ is the empty set ")#mi("B := \\emptyset")#text(", which is indeed not in ")#mi("A")#text(".")

#text("One can try outrunning Proposition 4′ again to see what happens. For instance, let’s add the empty set to the set ")#mi("A")#text(" produced earlier, to give the new set ")#mi("A^{\\prime} := \\{ A, \\emptyset\\}")#text(". The Proposition 4′ construction then gives the set ")#mi("B = \\{\\emptyset\\}")#text(", which is indeed not in ")#mi("A^{\\prime}")#text(". If we then try to add that set in to get a new set ")#mi("A^{\\prime\\prime} := \\{ A, \\emptyset, \\{ \\emptyset\\} \\}")#text(", then one gets the set ")#mi("B = \\{\\emptyset, \\{\\emptyset\\}\\}")#text(", which is again not in ")#mi("A^{\\prime\\prime}")#text(". Iterating this, one in fact begins constructing the ")#link("http://en.wikipedia.org/wiki/Ordinal_number#Von_Neumann_definition_of_ordinals")[#text("von Neumann ordinals")]#text("! (Actually, the original set ")#mi("A")#text(" plays essentially no role in this construction; one could have started with the empty set and it would have generated the same sequence of ordinals.)")

#heading(level: 1)[#strong[#text("— 2. Logic —")]]

#text("One can also convert the no-self-defeating arguments given in the logic section of the ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("previous post")]#text(" into “every object can be defeated” forms, but it took me a while to find them. (One may wish to pause to try this before moving on.)")

#text("We first turn to the result (essentially coming from the liar paradox) that the notion of truth cannot be captured by a predicate. This was discussed in the previous blog post, but not formalised as a theorem. I will do so now, starting with the easier “self-referential case”:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8.5 (Impredicativity of truth, self-referential case)")]#text(" (Informal statement) Let ")#mi("L")#text(" be a ")#link("http://en.wikipedia.org/wiki/Formal_language")[#text("formal language")]#text(" that contains the concepts of predicates and allows self-reference, and let ")#mi("M")#text(" be an")#link("http://en.wikipedia.org/wiki/Interpretation_(logic)")[#text(" interpretation")]#text(" of that language (i.e. a way of consistently assigning values to every constant, ranges to every variable, and truth values to every sentence in that language, obeying all the axioms of that language). Then there does not exist a “truth predicate” ")#mi("T(x)")#text(" in ")#mi("L")#text(" that takes a sentence ")#mi("x")#text(" as input, with the property that for every sentence ")#mi("x")#text(" in ")#mi("L")#text(", that ")#mi("T(x)")#text(" is true (in ")#mi("M")#text(") if and only if ")#mi("x")#text(" is true (in ")#mi("M")#text(").")
]

#text("Here is the non-counterfactual version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8.5′")]#text(" (Informal statement) Let ")#mi("L")#text(" be a ")#link("http://en.wikipedia.org/wiki/Formal_language")[#text("formal language")]#text(" that contains the concepts of predicates and strings and allows self-reference, and let ")#mi("M")#text(" be an")#link("http://en.wikipedia.org/wiki/Interpretation_(logic)")[#text(" interpretation")]#text(" of that language. Let ")#mi("T()")#text(" be a predicate in ")#mi("L")#text(" that takes sentences as input. Then there exists a sentence ")#mi("G")#text(" such that the truth value of ")#mi("T(G)")#text(" (in ")#mi("M")#text(") is different from the truth value of ")#mi("G")#text(" (in ")#mi("M")#text(").")
]

#strong[#text("Proof.")]#text(" We define ")#mi("G")#text(" be the self-referential “liar sentence”")

#align(center)[#text("G := “T(G) is false”.")]

#text("Then, clearly, ")#mi("G")#text(" is true if and only if ")#mi("T(G)")#text(" is false, and the claim follows. ")#mi("\\Box")

#text("Using the ")#link("http://en.wikipedia.org/wiki/Indirect_self-reference")[#text("Quining trick")]#text(" to achieve indirect self-reference, one can remove the need for direct self-reference in the above argument:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8.6 (Impredicativity of truth)")]#text(" (Informal statement) Let ")#mi("L")#text(" be a ")#link("http://en.wikipedia.org/wiki/Formal_language")[#text("formal language")]#text(" that contains the concepts of predicates and strings, and let ")#mi("M")#text(" be an")#link("http://en.wikipedia.org/wiki/Interpretation_(logic)")[#text(" interpretation")]#text(" of that language (i.e. a way of consistently assigning values to every constant, ranges to every variable, and truth values to every sentence in that language) that interprets strings in the standard manner (so in particular, every sentence or predicate in")#mi("L")#text(" can also be viewed as a string constant in ")#mi("M")#text("). Then there does not exist a “truth predicate” ")#mi("T(x)")#text(" in ")#mi("L")#text(" that takes a string x as input, with the property that for every sentence ")#mi("x")#text(" in ")#mi("L")#text(", that ")#mi("T(x)")#text(" is true (in ")#mi("M")#text(") if and only if ")#mi("x")#text(" is true (in ")#mi("M")#text(").")
]

#text("A more formal version of the above theorem is ")#link("http://en.wikipedia.org/wiki/Tarski's_undefinability_theorem")[#text("Tarski’s undefinability theorem")]#text(".")

#text("Here is the non-counterfactual version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8.6′")]#text(". (Informal statement) Let ")#mi("L")#text(" be a formal language containing the concepts of predicates and strings, and let ")#mi("T(x)")#text(" be a predicate on strings. Then there exists a sentence ")#mi("G")#text(" in ")#mi("L")#text(" with the property that, for any interpretation ")#mi("M")#text(" of ")#mi("L")#text(" that interprets strings in the standard manner,that the truth value of ")#mi("T(G)")#text(" in ")#mi("M")#text(" is different from the truth value of ")#mi("G")#text(" in ")#mi("M")#text(".")
]

#strong[#text("Proof.")]#text(" (Sketch) We use the “quining” trick. Let ")#mi("Q(x)")#text(" be the predicate on strings defined by")

#align(center)[#text("Q(x) = “x is a predicate on strings, and T(x(x)) is false”")]

#text("and let ")#mi("G")#text(" be the “Gödel sentence” ")#mi("G := Q(Q)")#text(". Then, by construction, ")#mi("G")#text(" is true in ")#mi("M")#text(" if and only if ")#mi("T(G)")#text(" is false in ")#mi("M")#text(", and the claim follows. ")#mi("\\Box")

#text("Actually Theorem 8.6′ is marginally stronger than Theorem 8.6 because it makes the sentence ")#mi("G")#text(" independent of the interpretation ")#mi("M")#text(", whereas Theorem 8.6 (when viewed in the contrapositive) allows ")#mi("G")#text(" to depend on ")#mi("M")#text(". This slight strengthening will be useful shortly.")

#text("An important special case of Theorem 8.6′ is the ")#link("http://en.wikipedia.org/wiki/G%C3%B6del%27s_incompleteness_theorems#First_incompleteness_theorem")[#text("first incompleteness theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8.7 (Gödel’s first incompleteness theorem)")]#text(" (Informal statement) Let ")#mi("L")#text(" be a formal language containing the concepts of predicates and strings that has at least one interpretation ")#mi("M")#text(" that gives the standard interpretation of strings (in particular, ")#mi("L")#text(" must be consistent). Then there exists a sentence ")#mi("G")#text(" in ")#mi("L")#text(" that is undecidable in ")#mi("L")#text(" (or more precisely, in a formal recursive proof system for ")#mi("L")#text(").")
]

#strong[#text("Proof.")]#text(" (Sketch) A language ")#mi("L")#text(" that is powerful enough to contain predicates and strings will also be able to contain a provability predicate ")#mi("P()")#text(", so that a sentence ")#mi("x")#text(" in ")#mi("L")#text(" is provable in ")#mi("L")#text("‘s proof system if and only if ")#mi("P(x)")#text(" is true in the standard interpretation ")#mi("M")#text(". Applying Theorem 8.6′ to this predicate, we obtain a ")#emph[#text("Gödel sentence")]#text(" ")#mi("G")#text(" such that the truth value of ")#mi("G")#text(" in ")#mi("M")#text(" differs from the truth value of ")#mi("P(G)")#text(" in ")#mi("M")#text(". If ")#mi("P(G)")#text(" is true in ")#mi("M")#text(", then ")#mi("G")#text(" must be true in ")#mi("M")#text(" also since ")#mi("L")#text(" is consistent, so the only remaining option is that ")#mi("P(G)")#text(" is false in ")#mi("M")#text(" and ")#mi("G")#text(" is true in ")#mi("M")#text(". Thus neither ")#mi("G")#text(" nor its negation can be provable, and hence ")#mi("G")#text(" is undecidable. ")#mi("\\Box")

#text("Now we turn to the ")#link("http://en.wikipedia.org/wiki/G%C3%B6del%27s_incompleteness_theorems#Second_incompleteness_theorem")[#text("second incompleteness theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Second Gödel incompleteness theorem).")]#text(" (Informal statement) No consistent logical system which has the notion of a predicate and a string, can provide a proof of its own logical consistency.")
]

#text("Here is the non-counterfactual version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9′.")]#text(" (Informal statement) Let ")#mi("L, L^{\\prime}")#text(" be consistent logical systems that have the notion of a predicate and a string, such that every sentence in ")#mi("L^{\\prime}")#text(" is also a sentence in ")#mi("L")#text(", and such that the consistency of ")#mi("L^{\\prime}")#text(" can be proven in ")#mi("L")#text(". Then there exists a sentence ")#mi("G")#text(" that lies in both ")#mi("L")#text(" and ")#mi("L^{\\prime}")#text(" that is provable in ")#mi("L")#text(" but is not provable in ")#mi("L^{\\prime}")#text(".")
]

#strong[#text("Proof.")]#text(" (Sketch) In the common language of ")#mi("L")#text(" and ")#mi("L^{\\prime}")#text(", let ")#mi("T()")#text(" be the predicate")

#align(center)[#text("T(x) := ” x is provable in L’ “.")]

#text("Applying Theorem 8.6′, we can find a sentence ")#mi("G")#text(" (common to both ")#mi("L")#text(" and ")#mi("L^{\\prime}")#text(") with the property that in any interpretation M of either L or L’, the truth value of ")#mi("G")#text(" and the truth value of ")#mi("T(G)")#text(" differ.")

#text("By Corollary 8.7′ (or more precisely, the proof of that corollary), ")#mi("G")#text(" is not provable in ")#mi("L^{\\prime}")#text(". Now we show that ")#mi("G")#text(" is provable in ")#mi("L")#text(". Because L can prove the consistency of L’, one can embed the proof Corollary 8.7′ inside the language L, and deduce that the sentence “")#mi("G")#text(" is not provable in ")#mi("L^{\\prime}")#text("” is also provable in ")#mi("L")#text(". In other words, ")#mi("L")#text(" can prove that ")#mi("T(G)")#text(" is false. On the other hand, embedding the proof of Theorem 8.6′ inside L, ")#mi("L")#text(" can also prove that the truth value of ")#mi("G")#text(" and ")#mi("T(G)")#text(" differ. Thus ")#mi("L")#text(" can prove that ")#mi("G")#text(" is true. ")#mi("\\Box")

#text("The advantage of this formulation of the second incompleteness theorem, as opposed to the usual counterfactual one, is that one can actually trace through the argument with a concrete example. For instance, ")#link("http://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory")[#text("Zermelo-Frankel-Choice (ZFC) set theory")]#text(" can prove the consistency of ")#link("http://en.wikipedia.org/wiki/Peano_arithmetic")[#text("Peano arithmetic")]#text(" (a result of ")#link("http://en.wikipedia.org/wiki/Gentzen's_consistency_proof")[#text("Gentzen")]#text("), and so one can follow the above argument to show that the Gödel sentence of Peano arithmetic is provably true in ZFC, but not provable in Peano arithmetic.")

#heading(level: 1)[#strong[#text("— 3. Computability —")]]

#text("By now, it should not be surprising that the no-self-defeating arguments in computability also have a non-counterfactual form, given how close they are to the analogous arguments in set theory and logic. For sake of completeness, we record this for ")#link("http://en.wikipedia.org/wiki/Halting_Theorem")[#text("Turing’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Turing halting theorem)")]#text(" (Informal statement) There does not exist a program ")#mi("P")#text(" which takes a string ")#mi("S")#text(" as input, and determines in finite time whether ")#mi("S")#text(" is a program (with no input) that halts in finite time.")
]

#text("Here is the non-counterfactual version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10′.")]#text(" (Informal statement) Let ")#mi("P")#text(" be a program that takes a string ")#mi("S")#text(" as input, returns a yes-no answer ")#mi("P(S)")#text(" as output, and which always halts in finite time. Then there exists a string ")#mi("G")#text(" that is a program with no input, such that if ")#mi("P")#text(" is given ")#mi("G")#text(" as input, then ")#mi("P")#text(" does ")#emph[#text("not")]#text(" determine correctly whether ")#mi("G")#text(" halts in finite time.")
]

#strong[#text("Proof.")]#text(" Define ")#mi("Q")#text(" to be the program taking a string ")#mi("R")#text(" as input which does the following:")

#list(
[#text("If ")#mi("R")#text(" is not a program that takes a string as input, it halts.")],
[#text("Otherwise, it runs ")#mi("P")#text(" with input ")#mi("R(R)")#text(" (which is a program with no input).")],
[#text("If ")#mi("P(R(R))")#text(" returns “no”, it halts, while if ")#mi("P(R(R))")#text(" returns “yes”, it runs forever.")]
)

#text("Now, let ")#mi("G")#text(" be the program ")#mi("Q(Q)")#text(". By construction, ")#mi("G")#text(" halts if and only if ")#mi("P(G)")#text(" returns “no”, and the claim follows. ")#mi("\\Box")

#text("One can apply Theorem 10′ to various naive halting algorithms. For instance, let ")#mi("P(S)")#text(" be the program that simulates ")#mi("S")#text(" for (say) 1000 CPU cycles, and then returns “yes” if ")#mi("S")#text(" halted by that time, or “no” otherwise. Then the program ")#mi("G")#text(" generated by the above proof will take more than 1000 CPU cycles to execute, and so ")#mi("P")#text(" will determine incorrectly whether ")#mi("G")#text(" halted or not. (Notice the similarity here with Proposition 1′.)")

#text("The same argument also gives a non-counterfactual version of the non-computability of the ")#link("http://en.wikipedia.org/wiki/Busy_beaver_function")[#text("Busy Beaver function")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11′")]#text(". Let ")#mi("f: {\\bf N} \\to {\\bf N}")#text(" be a computable function. Then there exists a natural number ")#mi("n")#text(" and a program ")#mi("G")#text(" of length ")#mi("n")#text(" (and taking no input) that halts in finite time, but requires more than ")#mi("f(n)")#text(" CPU cycles before it halts.")
]

#strong[#text("Proof.")]#text(" Let ")#mi("P(S)")#text(" be the program that simulates ")#mi("S")#text(" for ")#mi("f(n)")#text(" CPU cycles, where ")#mi("n")#text(" is the length of ")#mi("S")#text(", and returns “yes” if ")#mi("S")#text(" halted by that time, or “no” otherwise. Then the program ")#mi("G")#text(" generated by Theorem 10′ is such that ")#mi("P")#text(" does not correctly determine if ")#mi("G")#text(" halts. Since ")#mi("P")#text(" is always correct when it returns “yes”, this means that ")#mi("G")#text(" does halt, but that ")#mi("P(G)")#text(" returned “no”, which implies that ")#mi("G")#text(" takes more than ")#mi("f(n)")#text(" cycles to execute. ")#mi("\\Box")

#text("Of course, once one has a program of length ")#mi("n")#text(" that runs for more than ")#mi("f(n)")#text(" CPU cycles, it is not hard to make a program of length a little bit larger than ")#mi("n")#text(" that outputs a number greater than ")#mi("f(n)")#text(", so that one can conclude as a corollary that the Busy Beaver function outgrows any computable function.")

#heading(level: 1)[#strong[#text("— 4. Miscellaneous —")]]

#text("The ")#link("http://en.wikipedia.org/wiki/Strategy-stealing_argument")[#text("strategy stealing argument")]#text(" in game theory is already more or less set up in non-counterfactual form: in any game that admits “harmless moves” (such as noughts and crosses), any strategy of the second player can be stolen to be defeated (or at least held to a draw) by the first player. Similarly for arbitrage strategies in finance (unless there are loopholes due to imperfect information or friction costs).")

#text("It is a bit more difficult to recast the no-self-defeating objects in physics in a non-counterfactual form, due to the large number of implicit physical assumptions in these arguments. I will present just one simple example of this, which is the ")#link("http://en.wikipedia.org/wiki/Grandfather_paradox")[#text("grandfather paradox")]#text(" that asserts that controlled time travel is impossible because you could use such travel to go back in time to kill your grandfather before you were born. One can convert this to a slightly less counterfactual format:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("“Theorem”")]#text(". (")#emph[#text("Very")]#text(" imprecisely stated!) Suppose that one has a mechanism in universe U to travel back in time and arrive at universe U’. Then there can exist events in U that occurred differently in universe U’.")
]

#text("The “proof” is, of course, the same: starting from U, go back in time and kill your grandfather in universe U’. This version of the “theorem” (though not the precise “proof” given here) is of course invoked often in many science fiction stories involving time travel.")

#text("It seems possible to also cast the no-immovable-objects and no-controlled-and-detectable-tachyon-particles arguments from the ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("previous blog post")]#text(" in this form, but one would have to consider multiple universes to do this properly, and I will not attempt to do so here, as it appears to be rather complicated.")

#text("The “")#link("http://en.wikipedia.org/wiki/Omnipotence_paradox")[#text("omnipotence paradox")]#text("” in philosophy (can an omnipotent being create a stone so heavy that He cannot lift it?) can also be rephrased in a non-counterfactual form that does not require consideration of any omnipotent beings:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("“Theorem”")]#text(": If G is a being, then G will be unable to do at least one of the following two tasks:")

#enum(start: 1, 
[#text("Create a stone so heavy that G cannot lift it.")],
[#text("Be able to lift any possible stone.")]
)
]

#text("(Of course, most beings will fail at both Task 1 and Task 2.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (67)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7228a7642ad1db4e273b456ca1ffc3ee4126b29ae46725cbb382ee0da5d97b16-1d2682adfc228fe5e140eb2f40e454d049a7aa661e5f7c43c2e43da91b08275d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47676")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Dear Mr. Tao,")

#text("In the proof of Proposition 4′ the word “contradiction” is superfluous since, starting with ")#mi("B\\in B \\vee B \\not\\in B")#text(", one shows ")#mi("B \\not\\in B")#text(" anyway. Unfortunately I do not remember whether the former formula is intuitionistically valid.")

#text("kind regards,")#linebreak()#text(" pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47680")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Fair enough; I guess this just shows how ingrained a habit it is for mathematicians like myself to reach for the convenient tool of proof by contradiction, even when it is not strictly necessary. (But in intuitionistic logic, the law of the excluded middle is not available, and so to deduce ")#mi("\\neg A")#text(" from ")#mi("A \\implies \\neg A")#text(" still requires a proof by contradiction (or more precisely, a proof by negation).)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd83ab57967ccfe2fec3a7390f8ee470a99d34703c8a83778c9a2dff057d0298-fd0b212ab9166c7049cdb64effce4a7b0cb415ba88a6226266fd2fd598d74fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DavidTweed")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47678")[#strong[#text("DavidTweed")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Perhaps biggest area of counterfactual analysis outside mathematics/philosophy (and maybe still bigger) is in the law, where almost any case involving damages implicitly depends upon constructing what would have happened absent the criminal act in order to figure out how much money has been “lost”, eg, if X libels Y such that Y maintains he can’t get a job, the damages will be based upon how much it is thought he could have been earning “in a world where he wasn’t slandered”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47679")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Ah, law is a great example (and law does share many features in common with mathematics, such as an insistence on reading definitions literally, and formulating them precisely). One could argue that the fictionalised cross-examinations that one often sees in Hollywood-style legal dramas are a rough analogue of proofs by contradiction (or at least attempted proofs by contradiction). But I would imagine the real-world situation is much more mundane, though I don’t have much experience with actual courtrooms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28cc6f7cb13746fb7ada8107e4cd16e305746899349cadbe9a61fd8ef876dc9b-0cd9ed5a764100cee8c7a92d99976b36ca7321afe22b62342bfa8e2ac2f59502.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrej Bauer")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47683")[#strong[#text("Andrej Bauer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("I wish more mathematicians strived to state their results in a non-counterfactual manner. Statements which are phrased positively are usually much easier to understand, for students as well as for experts. I would just like to make a small remark: irrationality of the square root of 2, as well as several other examples you give, are not proofs by contradiction. They are simply proofs of negation, see ")#link("http://math.andrej.com/2010/03/29/proof-of-negation-and-proof-by-contradiction/")[#text("Proof of negation and proof by contradiction")]#text(" for an explanation. I think it is worthwhile keeping the distinction, especially in teaching.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Yes, I know of this distinction, but it is a bit orthogonal to the one discussed here (being more an issue of intuitionism/constructivism vs. classical logic, as opposed to counterfactual vs. non-counterfactual arguments) so I decided not to emphasise it. Many arguments that are genuinely of proof by contradiction type tend, in fact, to already be non-counterfactual in nature (because they are asserting a positive statement rather than a negative one), but have other undesirable properties (such as ineffectivity) that are not related to the counterfactual/not-counterfactual distinction.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44ec7f798b3f985849ab9177d628a9373176b752606eb33c3c96d5578c7788c6-c841102004ce4c4e15e8dfff639e20b10a6022204007c15a960a48f0198e7410.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Scarth")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47684")[#strong[#text("Robert Scarth")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("I haven’t read the whole article yet, and I haven’t even looked at the previous one. However the general idea that people find the “any object can be defeated” form easier to digest than the “no self defeating object” form is quite similar to the idea of loss aversion in behavioural economics which is about how people dislike losses more than they like gains. Or more precisely given two identical offers, one framed as a gain, and the other framed as a loss, almost everyone will prefer the offer framed as a gain.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20f199d73f38c3d952387bfad00697bc7e065d636c198938edf15dbf723ef460-47eb3a3139f1a9d010f9b109e1fb2743a357c6d2534147b1a523c404e61d8a74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mk")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47685")[#strong[#text("mk")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Prof. Tao,")#linebreak()#text(" In trying to count the reals, I still have trouble understanding Cantor’s argument. If the method you were using to construct the list were eventually comprehensive, wouldn’t you be able to say that given any real number, the list would eventually contain a number close to it up to an arbitrary precision? So, Cantor’s argument would both fail, and be true, depending on whether you carry out Cantor’s argument further, or generate the countable list further? It always has seemed to me like Cantor’s proof relies on just always being able to jump ahead to a number not yet contained in the list you’re building.")

#text("e.g. in the example above, any number such as .2111111… generated by Cantor’s argument may not be included in the list, but would eventually be, if you carried out construction of the list far enough to infinite.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Dear mk,")

#text("You can’t use a partially completed “work in progress” list of real numbers, that you keep updating as needed, to enumerate the real line – you have to supply a finished product. And once you do so, Cantor’s argument then gives you a number that your list didn’t supply. Sure, you could then add that to your list somehow, but it’s too late to do that. Actually, the situation is already well described by the “no largest number” argument, which is perhaps the very simplest example of arguments of this type. Consider the following dialogue:")

#text("A: “I’ve found the largest natural number! It’s 100!”")

#text("B: “Um, isn’t 101 an even larger number?”")

#text("A: “Did I say 100? Sorry, I meant 1,000.”")

#text("B: “But 1,001 is larger than 1,000.”")

#text("A: “Did I say 1,000? Sorry, I meant 10,000”.")

#text("B: “…”")

#text("I think you will agree that A’s claim that he or she has found the largest natural number is thoroughly unconvincing, even though B can never force A to concede completely. The situation is much the same as someone who claims to have a comprehensive list of real numbers that will give every real number you list “if you let it run long enough”, and who decides to extend the list a little bit more every time someone points out that the list is incomplete:")

#text("A: “I’ve found a complete and countable list of all the real numbers! Look, here it is!”")

#text("B: (looks) “Um, 0.2111…. is not on the list.”")

#text("A: “Oops, I didn’t run the list for long enough.” (scribble, scribble.) “OK, now this is the complete list.”")

#text("B: (looks) “But 0.0111… is not on the list either.”")

#text("A: “Oops, I needed to run the list a little bit more.” (scribble, scribble.) “Now it’s OK.”")

#text("B: “…”")

#text("Again, I hope you agree that A does not have a convincing case that he or she possesses a complete list of reals. One should tell A to let the list run for as long as is needed, and then supply the final, finished list, surrendering the right to alter it any further; then Proposition 6′ will supply a number that is not on that list. The fact that the list can then be modified afterwards to accommodate that number does not change the fact that A was unable to supply a complete list in the first place.")

#text("To put it another way: any “work in progress” list, that has not yet been fully completed, can still ")#emph[#text("potentially")]#text(" contain any real number one pleases; but in mathematics we do not work with such “potential” lists, as they tend to be slippery “moving targets” that lack the precision and definiteness needed to do maths, but instead only with ")#emph[#text("complete")]#text(" lists that are not subject to further modification. It is those lists that Cantor’s theorem demonstrates to be unable to cover all the real line.")

#text("(If you do suppose, as a counterfactual hypothesis, that a countable list exists that ")#emph[#text("does")]#text(" contain all the real numbers, then one is in the bizarre counterfactual and inconsistent universe of ")#link("http://en.wikipedia.org/wiki/Principle_of_explosion")[#text("ex falso quodlibet")]#text(", in which statements are both true and false simultaneously – so that a real number can both be on a list and not on it at the same time. The reason for all this bizarreness is, of course, that countable lists that exhaust the reals do not actually exist, as Proposition 6′ shows.)")

#text("p.s. One also needs to distinguish between a real number being ")#emph[#text("approximated")]#text(" by a number on a list, and actually being on the list itself. For instance, in the sample list I gave in the blog, the terminating decimals 0.2, 0.21, 0.211, 0.2111, etc. all lie in the list. However, their limiting value, the non-terminating decimal 0.21111…., does ")#emph[#text("not")]#text(" lie on the list, as the list consisted only of terminating decimals. It is the limit of some of the decimals on that list, but being a limit point of a set is a different concept from being in the set itself; there is no requirement that the list has to be necessarily ")#link("http://en.wikipedia.org/wiki/Closed_set")[#text("closed")]#text(" with respect to limits.")

#text("p.p.s. It is also important to keep in mind that while a countable sequence or list ")#mi("x_1, x_2, x_3, \\ldots")#text(" is infinite in length, each member ")#mi("x_n")#text(" of that sequence only occurs at a ")#emph[#text("finite")]#text(" position into that sequence. For instance, such a sequence can have a 37th member ")#mi("x_{37}")#text(" that is 37 places down the list, or a 967th member ")#mi("x_{967}")#text(" that is 967 places down the list, but it does not have members that are “infinitely far down the list”. (One can find members that are ")#emph[#text("arbitrarily")]#text(" far down the list, but this is a different concept.) In particular, there is no final element at the “end’ of the list, and there is a limit to what one can do by running the list “for long enough”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47693")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Regarding the classic idea of just tacking on the new real numbers produced by Cantor’s diagnolization argument to your list there’s actually some non-trivial math that comes from iterating this. If you iterate this process you get countably many more real numbers added to the list. You can then start again, and keep iterating. And so on. This process works up to any countable ordinal although you will need to reorder so you still have a list. At each stage, you still have only a countable number of reals. But this process will break down if we go out to the first uncountable ordinal and this is connected to the fact that the set of all countable ordinals is not countable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20f199d73f38c3d952387bfad00697bc7e065d636c198938edf15dbf723ef460-47eb3a3139f1a9d010f9b109e1fb2743a357c6d2534147b1a523c404e61d8a74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mk")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47698")[#strong[#text("mk")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("thank you prof. tao for your response.")

#text("I think my unclear understanding is in the concept of a finished product that is infinite, and differentiating a finished product that is countably infinite from one that is uncountable. When I only consider the method or rule used for generating a listing of a set, if the method carried out to infinite lengths seems to me comprehensive in reaching every element of the set in question, then the method you had above for attempting to generate a list of the reals looks to me to be as acceptable for enumerating the reals as a method for enumerating say the natural numbers by counting by 1 would be. It doesn’t seem like either method would leave an element out, and both methods involve counting. But if I consider the finished product of a list to be a general sequence of n elements, then I’m led to the conclusion that the listing for the reals wouldn’t work a la prop 6′. But why doesn’t this same sort of argument apply to other sets that are countably infinite?")

#text("i.e. for any listing of natural numbers, produce a natural number not on the list by adding all the elements of the list together. The way the addition jumps ahead of the listed natural numbers is what I feel the Cantor argument is doing by continuously forming a number not part of the enumerated list but which is eventually reached by the generating method of the list.")

#text("Also, I can accept that at the limit to infinite, the cantor argument produces a real number not on any list, so that’s why I was thinking of taking the limit of the generation of the list to infinite, and counting the numbers approximated as belonging to the set of reals. But I now see your point that limits can’t be considered part of the list necessarily.")

#text("Could you provide just some further clarification to help me understand the concept of a finished complete product when it is an infinite list?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47711")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("You have hit upon one of the key differences between the natural numbers and the real numbers that is actually at the heart of Cantor’s theorem; the reals have many convergent series and sequences (due to the various ")#link("http://en.wikipedia.org/wiki/Complete_metric_space")[#text("completeness")]#text(" and ")#link("http://en.wikipedia.org/wiki/Perfect_set")[#text("perfectness")]#text(" properties they enjoy), whereas the natural numbers do not. Thus, for instance, you can often sum an infinite series of reals (e.g. 1 + 1/2 + 1/4 + … ) to get another real number (in this case, 2), but when you sum an infinite series of natural numbers (e.g. 1+1+1+…) you almost never converge to another natural number. The fact that reals capture many of their limits, while natural numbers do not, already goes a long way to explaining why one cannot enumerate the former by the latter.")

#text("In particular, the argument “for any (countable) listing of natural numbers, produce a natural number not on the list by adding all the elements of the list together” does not work, because the sum of infinitely many natural numbers does not converge to another natural number. In contrast, given an infinite decimal ")#mi("0.a_1 a_2 \\ldots")#text(", the infinite series ")#mi("\\sum_{n=1}^\\infty \\frac{a_n}{10^n}")#text(" ")#emph[#text("does")]#text(" converge to a real number. For instance, ")#mi("0.3333\\ldots = \\sum_{n=1}^\\infty \\frac{3}{10^n}")#text(" converges to 1/3.")

#text("On the other hand, that argument you gave is a perfectly valid proof that the set ")#mi("{\\bf N}")#text(" of natural numbers is not ")#emph[#text("finite")]#text(" (and this is discussed as Proposition 2 of ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("the previous post on this topic")]#text("), because the sum of ")#emph[#text("finitely many")]#text(" natural numbers is still a natural number.")

#text("As for how to understand the concept of an infinite list (or infinite sequence) of numbers, I think the mathematical notation ")#mi("(x_n)_{n \\in {\\bf N}}")#text(" may be helpful here (As opposed to the more informal notation ")#mi("x_1, x_2, x_3, \\ldots")#text(", in which the ellipsis ")#mi("\\ldots")#text(" may lead to confusion if one is not yet comfortable with the mathematical concept of infinity). Thus, an infinite sequence of real numbers, is, formally, a recipe (or more precisely, a ")#emph[#text("function")]#text(") that assigns to each natural number ")#mi("n")#text(", a real number ")#mi("x_n")#text(" that represents the n^th element in the sequence. Thus, such a sequence will contain a 37th element ")#mi("x_{37}")#text(", a 967th element ")#mi("x_{967}")#text(", and so forth, but there are no elements that are “infinitely far” along the sequence, because there are no infinite natural numbers, only finite natural numbers (even though the ")#emph[#text("set")]#text(" ")#mi("{\\bf N}")#text(" of natural numbers is infinite – this is a key distinction!).")

#text("(In general, I recommend trying to express your thoughts for now in formal mathematical notation whenever possible, rather than in words. At this stage of one’s education, this type of mental discipline is very useful for clearing away misconceptions and fuzzy thinking. Once this is done, though, words are better; I talk about this in ")#link("https://terrytao.wordpress.com/career-advice/there%E2%80%99s-more-to-mathematics-than-rigour-and-proofs/")[#text("another page on this blog")]#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f313f15eacebf69cb882ecf84822372cef032924aae58c4f3da2570b57b4ee88-0c3caaedfe52b826ecc1351cf286159d56c1f115d79c134b4bb8d74a5a26b78d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koray")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47844")[#strong[#text("Koray")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2010")])]

#text("Could you outline how the 2nd conversation between A & B would proceed if A were to claim that the complete and countable set of reals was that of “computable” reals?")

#text("In my view B would have no rebuttal as any counter example that he/she can name is a computable real.")

#text("In fact the proof of 6′ states that one is dealing with a countable set of reals whose digits can be computed to arbitrary length, and follows by “constructing” a new real (essentially another computable real).")

#text("How would we prove that the set R minus countable reals is also not countable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47845")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2010")])]

#text("Ah, this is a good question, which highlights the connection between Cantor’s theorem and Turing’s theorem. The conversation would go in one of two ways, depending on whether A’s algorithm for generating the list was itself computable. If it was, it would go like this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A: I’ve found a list of all the computable reals!")

#text("B: Great! Can you tell me the algorithm for generating the list?")

#text("A: Sure, I run the (computable) algorithm P() with input n to generate the n^th computable real ")#mi("x_n := P(n)")#text(".")

#text("B: OK, so what if I run the algorithm to generate a real number x whose n^th digit is different from the n^th digit of P(n) for each n? That’s a computable real. Is x on the list?")

#text("A: Oops, no. I’ll have to try again.")
]

#text("Or, if A uses an uncomputable method to enumerate the reals (such as one that assumes that the halting problem is solvable), the conversation goes instead as something like this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A: I’ve found a list of all the computable reals!")

#text("B: Great! Can you tell me the algorithm for generating the list?")

#text("A: Easy. I enumerate all the possible algorithms for constructing reals, of which there are a countable number, throw away all the algorithms that get stuck in an infinite loop before generating such a number, and then set ")#mi("x_n")#text(" to be the output of the ")#mi("n^{th}")#text(" algorithm that does generate a real number.")

#text("B: So, to run your algorithm, you need to solve the halting problem, right?")

#text("A: Uh, yeah.")

#text("B: You do know that that’s not a computable problem to solve, right?")

#text("A: Yup, by ")#link("http://en.wikipedia.org/wiki/Turing's_halting_theorem")[#text("Turing’s theorem")]#text(". But I’m OK with that.")

#text("B: OK. Using your (uncomputable) algorithm, I can find a real number x whose n^th digit differs from the n^th digit of the number on your list.")

#text("A: But that real number won’t be computable (much like ")#link("http://en.wikipedia.org/wiki/Chaitin's_constant")[#text("Chaitin’s constant")]#text("), so there’s no contradiction.")

#text("B: Yup. Your uncomputable algorithm does generate all the computable reals, but leaves out the uncomputable reals.")
]

#text("In short, what is going on here is that the computable reals are indeed a countable set, but any countable enumeration of this set must itself be uncomputable, and can thus be used to generate uncomputable reals (via diagonalisation) also. (See also ")#link("http://en.wikipedia.org/wiki/Skolem's_paradox")[#text("Skolem’s paradox")]#text(" for a closely related phenomenon.)")

#text("In general, diagonalisation arguments work at just about any level of computational resources; if one limits the resources available to build (say) individual real numbers, then the enumeration of the set of all such real numbers can become possible, but will require a level of resources above the cutoff that you have imposed. It’s the same with many of the other results discussed here; for instance, if one limits the axioms of mathematics one is allowed to use, e.g. to Peano arithmetic, then proving consistency of the system becomes possible, but requires axioms that are more powerful than the ones you have limited yourself to. Or if one limits the maximum size N of the natural numbers that one is allowed to consider, then the set {0,…,N} of all natural numbers becomes finite, but its cardinality requires a number N+1 that exceeds the limits that you had set. If one limits one’s ordinals to be countable, then the set of all ordinals becomes a set – but one which is uncountable. The ")#link("http://en.wikipedia.org/wiki/Interesting_number_paradox")[#text("first uninteresting natural number")]#text(" (which, incidentally, could be used in an attempt to outrun Proposition 1) is interesting, but at a level beyond the limits one had previously set for what constitutes “interesting” (see also the ")#link("http://en.wikipedia.org/wiki/Berry_paradox")[#text("Berry paradox")]#text("). And so forth.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f313f15eacebf69cb882ecf84822372cef032924aae58c4f3da2570b57b4ee88-0c3caaedfe52b826ecc1351cf286159d56c1f115d79c134b4bb8d74a5a26b78d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koray")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47883")[#strong[#text("Koray")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2010")])]

#text("Firstly, thanks for the detailed response.")

#text("The “complete” in “a countable, complete” list I first understood as to mean one that doesn’t exclude any numbers. However, your first conversation, which doesn’t assume halting is solvable, makes it clear that the list is meant to be recursively enumerable.")

#text("In fact at this moment I think I may start treating Cantor’s proof as a proof that the set of computable reals is not recursively enumerable. (i.e. there’s no computable function whose image is the set of computable reals since there’s another computable function whose image includes one more.)")

#text("But, I feel his proof was supposed to be about all reals and whether they were countable; not r.e. or anything else.")

#text("Your second discussion carries on with the r.e. requirement, and so assumes a solution to the halting problem, admits that computable reals were accounted for, but uncomputable reals were left out.")

#text("However, even uncomputable reals like Chaitin’s Omega belong to a countable set (of programs, along with computable reals). I’m afraid I have not yet seen why the reals are uncountable.")

#text("I am well beyond my depth. Thanks for your time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47885")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2010")])]

#text("You can adapt Cantor’s argument to many settings to give a variety of useful conclusions. In its original formulation, it shows that the set of _all_ reals cannot be countably enumerated by _any_ method. However, the argument can be localised to the computable reals (as you requested in your previous comment), in which case the argument shows that the set of all _computable_ reals cannot be countably enumerated by any _computable_ method. As such, the argument actually provides a proof of the halting theorem (though this is pretty close to the standard proof).")

#text("It can also be used to demonstrate a number of other facts too. For instance, when you say that “even uncomputable reals like Chaitin’s Omega belong to a countable set”, you are implicitly using some language L that describes all the programs that you are willing to use to define such numbers as Omega (e.g. one could take a “second order Turing language” that contains the usual language of Turing machines, as well as the ability to solve the halting problem for such machines). If one then enumerates all the real numbers that this language L, then Cantor’s argument provides a new real number x that is not describable in that language L, but is instead describable in a higher order language L’ that incorporates not only L, but also the truth predicate for L (in order to determine which programs in L actually produce valid real numbers). This is a strictly larger language than L itself because of the impredicativity of truth (Theorem 8.6).")

#text("For instance, numbers such as Chaitin’s Omega are definable using a second order Turing language, but one can diagonalise a list of such numbers and create a real number that requires a third order Turing language to define.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f313f15eacebf69cb882ecf84822372cef032924aae58c4f3da2570b57b4ee88-0c3caaedfe52b826ecc1351cf286159d56c1f115d79c134b4bb8d74a5a26b78d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koray")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47893")[#strong[#text("Koray")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2010")])]

#text("I believe from your last reply I’ve isolated our differences. The version of the original proof “localized” to computable reals is actually the only version I’d accept while you consider it valid for _all_ reals. As an example if a certain list included the Omega and you tried to expand its digits for diagonalization I could no longer follow the proof.")

#text("I don’t know whether this position is shared by anyone else. It seems I require proofs to ‘materialize fully’ and then allow syntactic deduction step-by-step.")

#text("Although I don’t believe this is the position of constructivism, wikipedia tells me that there are ")#link("http://en.wikipedia.org/wiki/Constructivism_(mathematics)#Example_from_real_analysis")[#text("forms of constructivism")]#text(" where the definition of reals produces only computable reals.")

#text("(On the same page it reads “…In short, one who takes the view that real numbers are effectively computable interprets Cantor’s result as showing that the real numbers are not recursively enumerable.”, which makes my comments above late to the party already.)")

#text("Thanks again for your time.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbaceb23bc4bdb2cf44f56c293ca939c8150001499d57bdaf33bb09ad37b8a8d-cff216297cef8bd17dbe10e2edae68d23c59d0efe07f73a921e9828bef8b68c8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave Doty")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47689")[#strong[#text("Dave Doty")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("I like proofs by contradiction, except when they have this form:")

#text("Theorem. A ==> B.")

#text("Proof.")#linebreak()#text(" 1) Assume for the sake of contradiction that (A and not(B)) is true.")#linebreak()#text(" 2) Then by some statements that can be derived solely from A, without once using not(B), we arrive at the conclusion that B holds, which is a contradiction.")#linebreak()#text(" 3) Our original assumption of (A and not(B)) was false; therefore A ==> B.")#linebreak()#text(" QED")

#text("Of course, then entire proof works with statements (1) and (3) removed, but the superfluous contradiction has me scrambling to find where in (2) the assumption of not(B) was used. These sorts of proofs are sadly common in papers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Yes, this illustrates a disparity between the style of argument that makes it easy to ")#emph[#text("prove")]#text(" theorems, and the style of argument that makes it easy to ")#emph[#text("understand")]#text(" those proofs. Proof by contradiction, even the “trivial” proofs by contradiction of the type you mention, can be conceptually helpful for ")#emph[#text("finding")]#text(" a valid proof of a theorem; for instance, to show that a function ")#mi("f")#text(" is injective, it is often helpful to visualise (for sake of contradiction) two distinct inputs ")#mi("x \\neq x^{\\prime}")#text(" that collide to give the same output ")#mi("f(x)=f(x^{\\prime})")#text(", and at some point realise that the two inputs in fact had to be equal. Even if one never used the initial hypothesis ")#mi("x \\neq x^{\\prime}")#text(" except to obtain the final contradiction, this type of mental image is very useful for figuring out exactly what obstructs this type of collision from occurring, thus, identifying the mechanism that gives injectivity. Here, contradiction is used as a sort of diagnostic tool to locate the argument, rather than being an essential component of the argument itself.")

#text("But yes, when the time comes to explain the argument to somebody else, who is more interested in understanding the argument than in knowing how it was arrived at, then “polishing” the argument to remove the superfluous proof by contradiction can be preferable. (But if taken too far, it can lead to proofs that are extremely “slick” and “elegant” but do not seem to arise organically from any innate intuition. So there is a tradeoff to be had here.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/635e3c88f2f4a02fb49bd0f1988c1b2e383f2092e6b3d699488156058eb4cb36-fe872f006c10f50aa3928d3658b835fd981b13205923515a6ce971bc2f85a831.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sb")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47690")[#strong[#text("sb")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Two subtle points to think about. 1. If the original result is negative (something is uncountable or something does not exist), then this procedure does give a constructive proof of the “there exists” version. But then to go from “there exisits” version to the original result you need contradiction. So its sort of postponing the inevitable. 2. If the original result is positive, does this approach work ? The only one I thought was positive was Godel’s first incompleteness theorem and that avoided contradiction by making if and only if arguments and was a corollary of “impredicativity of truth” which")#linebreak()#text(" is a negative result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/134452adb943fb271316567128d460304539f33494736b6dde3aadfc82962081-b907b9db7eb8bbb295afd4a336d62b1c8bb9d2018f80b13c55284a68294c6aac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Alexander")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47692")[#strong[#text("Sam Alexander")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("One way to rephrase theorems is to say “If p is prime then…”, rather than “Let p be prime…”")

#text("It’s interesting to consider the logic of such a statement, and it naturally leads to the correct truth table for implication (i.e. that F->F=T), something which, itself, is often confusing to freshmen. For example, take the statement: “If x is positive then x+1 is positive.” Nobody will challenge this statement, however skeptical they might be about truth tables. But that implicitly means the statement is true for all values of x, in particular x=-1, in which case it takes the form F->F…")

#text("Why do we use “Let p be prime…” instead of “If p is prime…”? It seems to be part tradition, and partly a trick to avoid extremely long run-on sentences. Also a writer might mix and match the two just for the sheer purpose of having variety in their writing (math papers can easily fall prey to very very repetitive writing…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47715")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("The command “Let” in mathematics is more than a supposition; it also serves the purpose of declaring a new variable that was not previously used or defined (similar to variable declarations in many modern computer languages). A phrase such as “If p is prime, …” or “Suppose that p is prime.” is only valid mathematical grammar if p has already been defined previously in the argument, whereas “Let p be a prime” is used when p is introduced for the first time.")

#text("(There is also “Suppose that p is ")#emph[#text("a")]#text(" prime,” which is more agnostic as to whether p has previously been defined or not, and also does not carry as much of connotation that suggests that at least one prime exists.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a6d7bfaab15d364e5b49865f28111b03bffa68435b4bdfcda74c51b42070a12-acae0d9c2b0ceb8fc191ea449781973da58d9d8338a5b301c554d0aca602f46e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47900")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2010")])]

#text("The big problem with “If p is prime then X” is that X has to fit within a single sentence. English has no grammatical structure that allows me to make a hypothetical last until the end of a paragraph. When I edit my work, I constantly find overlong sentences of the form “If P, then A, so B, and then C.” When I break them up, they have to become “Suppose P. Then A. So B, and then C. In summary, P implies C.” I wish there were a better way to be clear about exactly how long the supposition of P lasts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c712efc01dda0d0dfde02589d6b51ecad9f919c902b12282c9fbe03366671f0c-cf1225443223e8ac3172f92cde3dbbae84492ce5b80b98fbb2f492ea0bbdbde1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MathStudent")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47696")[#strong[#text("MathStudent")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Dear Prof. Tao,")

#text("Is it also reasonable to conclude that proofs by “no self-defeating object” argument work only when the statement of the existence of the object (or its negation) is sufficiently “strong” and not otherwise? For instance, would it be correct to say that the negation of the “infinity of primes” is strong enough to lead to a proof of the infinity of primes, but fails to work for twin primes because neither that statement (there are infinitely many twin primes) nor its negation is sufficiently “strong”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47716")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("Yes, one can think in these terms. For instance, a strong property that the primes have (as opposed to the twin primes) is the fundamental theorem of arithmetic, which asserts that the primes multiplicatively generate the entire natural numbers. It is this fact that underlies most of the proofs of the infinitude of primes that I know of. Of course, the twin primes do not have anything resembling this property, and so one cannot adapt these arguments for primes directly to the almost primes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/178c3bae28755d8004e7ae4d405b944bbeee94483ddbd526f295ad7323d9f9d2-d433e868256b86f3d2948b62991c388aaa23df05a8a92189e8c1969313026e97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kaizer")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47697")[#strong[#text("Kaizer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("Is proof by contradiction the only way to prove any of these famous results, such as that there are infinitely many primes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47717")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("It’s hard to expunge proof by contradiction (or proof by negation) from one’s toolbox completely (especially when trying to prove a negative result, as opposed to a positive one), but there are other ways to prove the infinitude of primes that have a somewhat different flavour than Euclid’s proof. For instance, starting with Euler’s formula")

#mi("\\sum_{n=1}^\\infty \\frac{1}{n^s} = \\prod_p (1 - \\frac{1}{p^s})^{-1}")

#text("for s > 1 (which is, incidentally, a generating function formulation of the fundamental theorem of arithmetic), one can use the divergence of the harmonic series ")#mi("\\sum_{n=1}^\\infty \\frac{1}{n}")#text(" and a limiting argument to conclude the divergence of the prime harmonic series ")#mi("\\sum_p \\frac{1}{p}")#text(", which implies in particular that there must be infinitely many primes (and also gives some stronger information regarding the distribution of the primes). However, proof by contradiction is still probably buried on many of the steps of the above proof, most notably in the “limiting argument” that I glossed over.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47728")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("There are a few others that have very different flavor also. For example, using the same sort of argument with s=2 in the above along with the fact that Pi^2 is irrational you get the same result. This proof is in some ways a deliberate obfuscation.")

#text("At some point someone should list all the interesting proofs that there are infinitely many primes. Possibly my favorite such proof uses deterministic finite automata’s inability to recognize powers of 2 in a base that isn’t itself a power of 2. Proof sketch: A DFA cannot recognize the language that consists of powers of 2 written out in base 10. But, for any positive integer M, the language “in base 10 n represents an integer divisible by m” is DFA-recognizable. Languages recognizable by DFAs are closed under complements, intersections and unions. So if there are only finite many primes, we can then use the divisibility DFAs to recognize powers of 2. Contradiction and end of proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/778b162bceae6c67b03a5b8f8c3f87559320e863361c0ec50d9a06f2724415ba-38d615848b8f49948687061870d820258feaf6d56d4ca9f2a26536daabc3924d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47827")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("Hmm. You could also use that \\sum_{n=1}^\\infty \\frac{1}{n^2} = \\frac{\\pi^2}{6} and note that it is irrational to conclude that the RHS must also be irrational? If finite, the RHS would be a product of finitely many rational numbers and hence rational. Hence it can’t be a finite product. This introduces contradiction (possibly twice, depending on how you show \\frac{\\pi^2}{6} is irrational), but if all we want is a proof that is ‘essentially different’ from Euclid, this fits the bill too.")

#text("(If \\pi^2/6 were rational, we’d have integers p, q such that p/q = \\pi^2/6 and hence \\pi would be a root of qx^2 -6p, hence algebraic. Exercise: \\pi is not algebraic!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/778b162bceae6c67b03a5b8f8c3f87559320e863361c0ec50d9a06f2724415ba-38d615848b8f49948687061870d820258feaf6d56d4ca9f2a26536daabc3924d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47828")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("I see someone’s already posted this. Sorry!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of small e")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47705")[#strong[#text("small e")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("I am not 100% happy with the final argument in the proof of Proposition 6′: Since there are several (in fact, two) ways to write y as a decimal, one needs to show that none of these representations occurs.")

#text("I think it is easier to just define decimal numbers by one representation (e.g., the one that does not break off).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47709")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("I addressed this point in the construction of y; the n^th digit of the decimal expansion of y that is given is not equal to the n^th digit of ")#emph[#text("any")]#text(" of the representations of x_n, and so cannot equal x_n. (The fact that y may possibly have another decimal representation is not relevant for this argument; as long as at least one of the decimal representations of y is not a decimal representation of x_n, then y is not equal to x_n.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/052236cf4bf4e501e7c94d137f4ec6da96be9a1fb83bbf8a31bd509c5c5ded1a-6f191ce58d7b59b596f510725801b445a71d2e9f8a64237e07eef468daf20a0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47712")[#strong[#text("Josh")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("This may be a bit pedantic: For what it’s worth, I’m not sure “counterfactual” is the best term to use here. What’s really going on is that you’re distinguishing between reasoning with and without suppositions. The particular cases you’re focusing on involve reasoning with suppositions that turn out to be false. But that isn’t exactly the same as reasoning counterfactually. Compare the old chestnut: If Oswald did not shoot Kennedy, someone else did. (True.) If Oswald hadn’t shot Kennedy, someone else would have. (False.) The former is a indicative conditional with a false antecedent. The latter is a genuine subjunctive/counterfactual conditional. We can imagine reasoning with the supposition that Oswald didn’t shoot Kennedy and come to believe someone else did. The various illustrations of “counterfactual thinking” seem rather more like this sort of reasoning than true counterfactual reasoning. More generally, there doesn’t seem to be any need for a genuinely counterfactual/subjunctive conditional in mathematical reasoning.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47713")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("This is a valid distinction, though as you say it is indeed largely erased in mathematics because our existing body of knowledge about a mathematical world consists only of necessary truths and whatever is deducible from one’s hypotheses, whereas in the real world one also has access to contingent truths (e.g. “Kennedy was shot”) that are neither necessarily true in all worlds, nor necessarily deducible from one’s hypotheses, which is the reason that one has to make the distinction in philosophy between indicative implications (adding more hypotheses while retaining the contingent truths) and counterfactual implications (adding more hypotheses, but dropping the contingent truths), whilst in mathematics there is only the material implication (the truth table relation between the truth of the hypotheses and the truth of the conclusions).")

#text("Nevertheless, even if there is no formal distinction between different types of implication in mathematics, I think the way that one _thinks_ about an implication in mathematics can be classified, at least approximately, into such categories as indicative and counterfactual. In particular, when reasoning by contradiction, one has to temporarily be in the mental state where one has to suppress any contingent information about the problem at hand; for instance, you may already be aware from textbooks that the reals are known to be uncountable, but when actually proving Cantor’s theorem, one of course cannot utilise this fact, and so one is indeed temporarily operating in a counterfactual universe in which Cantor’s theorem did not actually appear in textbooks (or Kennedy was not shot, etc.).")

#text("(One can also see the desire to signal different types of implication in mathematical grammar. “If ")#mi("x_1,x_2,\\ldots")#text(" is an enumeration of the reals, then…” and “Suppose that ")#mi("x_1,x_2,\\ldots")#text(" is an enumeration of the reals. Then…” are logically equivalent, but the latter, to me at least, suggests a more counterfactual point of view than the former.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47718")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("The confusions at the beginning at the post remind me of a similar one I posted here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://gilkalai.wordpress.com/2009/07/22/a-proof-by-induction-with-a-difficulty/")[#text("A Proof by Induction with a Difficulty")]
]

#linebreak()#text(" Sasha Barvinok mentioned a similar, more basic, story (or a profound philosophical joke according to Wittgenstein) from “Littelwood’s Miscellany”:")

#text("“Schoolmaster: ‘suppose that x is the number of sheep in the problem.’")

#text("Pupil: ‘But, Sir, suppose that x is not the number of sheep.’ “")

#text("Another remark is that game theory is a nice context to formalize and study counterfactuals.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-468953")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2016")])]

#text("Gil, do you think you understand that item in the Miscellany? I thought your blog post might possibly help me do so, but (not your fault of course) no luck.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-468954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2016")])]

#text("A similar story:")

#text("Schoolmaster: ‘solve the equation ")#mi("x=0")#text(".’")

#text("Pupil: ‘But, Sir, isn’t it the solution of itself?’")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47720")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("Somewhere I read the interesting (and useful) point that when one is trying to prove things, it often in ones best interest to try to avoid proofs by contradiction, especially long proofs by contradiction. The reasoning is that if a mistake is made in a proof by contradiction the arguments that follow are often useless, but if a theorem is “proved” using many lemmas and one lemma is wrong, the others are often still useful. This often makes me suspiscious of long proofs by contradiction, wherever I see them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47739")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("Well, the more precise statement, I think, is that it is best to avoid long proofs by contradiction which consist of many parts, each of which is different to convert to a non-counterfactual form. One sees this sometimes in attempts by amateurs to prove, say, the Riemann hypothesis; one starts with assuming a zero off of the critical line, and then derives a large number of random statements both using this fact, and not using this fact. At some point, one makes an error (e.g. division by zero), but one does not notice it until several pages later, when two of the equations derived disagree with each other. At this point, the author triumphantly declares victory.")

#text("On the other hand, there are many valid long proofs by contradiction in the literature. For instance, in PDE, a common and powerful way to show that a solution to an evolution equation exists for all time is to assume that it doesn’t, and deduce that it must develop a singularity somewhere. One then applies an increasingly sophisticated sequence of analytical tools to control and understand this singularity, until one eventually is able to show that the singularity has an impossible nature (e.g. some limiting asymptotic profile of this singularity has a positive norm in one function space, and a zero norm in another). In many cases this is the only known way to obtain a global regularity result, but most of the proof is left in the counterfactual world where singularities exist. But, the use of contradiction is often “shallow”, in that large parts of the proof can be converted into non-counterfactual form (and indeed, if one looks at the actual proof, it is usually the case that most of the key lemmas and sub-propositions in the proof are stated non-counterfactually). In fact, there are two closely related arguments in PDE, known as the “no minimal energy blowup solution” argument, and the “induction on energy” argument, which are related to each other in much the same way as the well-ordering principle is to the principle of mathematical induction (or the way that the “no self-defeating object” argument is related to the “every object can be defeated” argument); the former is counterfactual and significantly simpler, the latter is not but requires much lengthier and messier arguments. But it is generally accepted that the two methods are, on some level, equivalent.")

#text("Here is an analogy. One can think of a long proof as a long rope connecting point A (the hypotheses) to point B (the conclusion). This rope may be submerged in murky water (the counterfactual world) or held up above it (the non-counterfactual world). A proof by contradiction thus is like a rope that is almost completely submerged underwater, but as long as the rope is only shallowly underwater, one can still see it well enough to conclude that it is unbroken. But if it sinks too far into the depths of the counterfactual world, then it becomes suspicious.")

#text("Finding a non-counterfactual formulation of an argument then resembles the action of lifting the rope up so that it is mostly above water (though, if either the hypothesis A or conclusion B are negative in nature (and thus underwater), one must still spend a tiny fraction of the argument at least in the counterfactual world, as Gowers pointed out in another comment; also, the proof of the non-counterfactual statement may still occasionally use contradiction, so the rope may still dip below the water now and then). This can make the argument clearer, but it is also a bit tiring to lift the entire rope up this way; if one’s objective is simply to connect A to B in the quickest way possible, letting the rope slide underwater is often the simplest solution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/178c3bae28755d8004e7ae4d405b944bbeee94483ddbd526f295ad7323d9f9d2-d433e868256b86f3d2948b62991c388aaa23df05a8a92189e8c1969313026e97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken Joffaniel Gonzales")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47733")[#strong[#text("Ken Joffaniel Gonzales")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("How would you compare proof by contradiction with other methods of proof in terms of rigor? A non-mathematician would, of course, appreciate a proof that really tells what something is, instead of assuming that something isn’t and then proceeding with the conclusion that it actually is. Do we prefer proofs by contradiction when we are stuck in an argument that becomes ugly when proven directly?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("I think Joel Hamkins’ response to this MathOverflow question,")

#link("http://mathoverflow.net/questions/12342/reductio-ad-absurdum-or-the-contrapositive")[#text("http://mathoverflow.net/questions/12342/reductio-ad-absurdum-or-the-contrapositive")]

#text("gives an excellent answer to these questions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47734")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("It seems to me that counterfactual conversion can be applied to many forms of scientific and medical reasoning, not just pure mathematics.")

#text("For example, the conclusion of Richard Wilson’s 1989 ")#emph[#text("Nature")]#text(" review, titled “Is quantum mechanics linear?” can be stated in no-self-defeating form as follows:")

#strong[#text("Proposition (No nonlinearity of quantum dynamics)")]#text(" ")#emph[#text("On any finite-dimensional nonlinear complex state-space, there does not exist a Hamiltonian flow for which cyclic trajectories have an amplitude-independent frequency.")]

#text("Stated in non-counterfactual form this becomes:")

#strong[#text("Proposition’")]#text(" ")#emph[#text("If ")#mi("F")#text(" is a Hamiltonian flow on a finite-dimensional nonlinear complex state-space, then the cyclic trajectories associated to ")#mi("F")#text(" have amplitude-dependent frequency.")]

#text("In the latter form we appreciate that the proposition has counter-examples, for example, state-spaces that are tensor products of Bloch spheres, with a uniform magnetic field as the Hamiltonian.")

#text("Thus counterfactual conversion helps us appreciate that although the resonant frequencies observed in atomic beam experiments are observed to be amplitude-independent to within one part in ")#mi("10^{20}")#text(" (or better), it does ")#emph[#text("not")]#text(" follow that the state-space of quantum mechanics is a (linear) Hilbert space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47736")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("A very interesting post. In particular, it interests me that you found some examples easier to recast than others. Do you have a general explanation for this? With at least some of them it is quite easy to see what to do: you start with a statement of the form ")#mi("\\neg P(X)")#text(" and you prove instead the statement ")#mi("(\\forall Y) P(Y)\\implies Y\\ne X.")#text(" For instance, if ")#mi("P(X)")#text(" is the statement “X is countable” then to prove that ")#mi("\\mathbb{R}")#text(" is uncountable you prove that every countable set fails to equal ")#mi("\\mathbb{R}.")#text(" Though actually you prove something more precise, which is that for every countable subset of ")#mi("\\mathbb{R}")#text(" you can construct a real number that does not belong to that set.")

#text("It’s also interesting to think about what is left to do once one has proved that. How does one actually prove the statement that if ")#mi("Y\\subset X")#text(" and ")#mi("X\\setminus Y\\ne\\emptyset")#text(" then ")#mi("X\\ne Y")#text("? One way would be to say that if ")#mi("X=Y")#text(" then every element of ")#mi("Y")#text(" is an element of ")#mi("X,")#text(" so ")#mi("X\\setminus Y")#text(" must be empty. But normally we would regard this result as so obvious that we would think of the proof as finished once we had got to the stage of showing that ")#mi("X\\setminus Y")#text(" contains an element. So the contradiction, being relegated to a very trivial part of the argument (rather than the usual practice of making it contain the entire argument) hardly feels like a contradiction any more. (I still haven’t embedded the distinction between proof by contradiction and proof by negation into my skull, so apologies to Andrej if this too is not a genuine proof by contradiction.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("It’s certainly true that I found some of the counterfactual arguments more difficult to convert than others. Somehow, it seems that some arguments are more deeply embedded in the counterfactual universe than others, by relying on the counterfactual premise in multiple, interconnected, ways. (See also the “rope” analogy in my reply to Peter.) Also, there was often a conceptual block to overcome; one often had to separate a single object X in the counterfactual argument into two objects X and Y in the non-counterfactual one, and one had to remove certain preconceptions about the argument in order to see exactly how to achieve this separation. (This is perhaps most extreme in the case of the grandfather paradox, when one had to separate the entire universe into two separate universes.)")

#text("The Godel theorems, in particular, took quite a while for me to convert to non-counterfactual form. Once I saw the trick (replacing the concept of “provability in ")#mi("L")#text("” by “provability in ")#mi("L^{\\prime}")#text("“, or by a more abstract predicate which might or might not have anything to do with provability), it was straightforward, but making that connection took perhaps fifteen minutes of thought.")

#text("Actually, I still do not have a fully satisfactory non-counterfactual version of the “no immovable object” or the “no controlled, detectable tachyon particles” arguments in special relativity. The splitting universe trick becomes enormously complicated due to all the possible trajectories in spacetime one would have to split over (unless one uses quantum field theory, but this of course creates its own set of conceptual difficulties).")

#text("For instance, here is one formulation of the “no immovable object” argument that I am not fully satisfied with yet:")

#strong[#text("Proposition")]#text(". (All objects are movable) Assume the postulates of special relativity. Suppose that one has a mechanism M for generating an object O=O(F,X) at rest in any specified inertial frame F, at any specified location X in that frame. Then at least one of the following facts must be true:")

#text("1. Any object generated by this mechanism, can be moved by some external force.")

#text("2. If an object O at rest in one frame F in this mechanism encounters another object O’ at rest in frame F’ also created by this mechanism, then the two objects must pass through each other instead of colliding.")

#text("But perhaps there is a better formulation. The situation with the tachyon pulses is also complicated. The best I can do currently is to say that any controllable generator of detectable particles that can be set up in every inertial frame, must either generate streams of particles that travel at or below the speed of light, or else generate streams of particles that travel to an alternate universe.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ed678126e5ea94bcd9b6bd4a2f8863fba172e72ec3a51a73ea205f9e37f55b6-fd8074e02a23dbe67e6ed39cb6fcaecf29aebc2ade3467e84b0eea90c2b4250c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Gaddis")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47737")[#strong[#text("Jason Gaddis")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("I apologize if this is just semantics, but you say,")

#text("“Again, Proposition 3′ is “constructive”; one can apply it to any finite list of primes, say , and it will actually exhibit a prime not in that list (in this case, 31)”.")

#text("It will exhibit a number that is relatively prime to every number in your list, but that number is not necessarily prime. For example,")#linebreak()#text(" 2*3*5*7*11*13+1 = 30031 = (59)(509)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47738")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("The number being exhibited is a prime factor of the product, not the product itself.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1fa0dc5739bc24e4d6b4ef13aa793365979ae308a2e8401bf8440bd337f878-13cc6a689aaade70f2832eba03554079c456fa07a09b2f8fd06fb5b618718cd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerard")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47742")[#strong[#text("Gerard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("Excellent post. It made me think that in undergraduate mathematics the proof by contradiction method is very commonly used (first university courses, IMO’s, etc.), but in more advanced courses (specially in areas where the idea of continuum is important), and except some typical cases (e.g. show that ")#emph[#text("this thing")]#text(" is unique), i have the impression that it isn’t as useful as it used to be. Is it the case in modern investigation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cec63be731542236f25e1cb4a7d42c9e3ecf844a2bc6f14f1d6dda0602dd4f9f-c2fb5af9a52260ed0c42c0258ed193f17f05833511f60dc48be715542e63548d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Rute")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47744")[#strong[#text("Jason Rute")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2010")])]

#text("Here is a relevant example from calculus. “Show that f(x) = 3x – 1 – sin(x) has exactly one root.” To show at least one root exists, just use IVT. But to show there are no more roots, we teach them a proof by contradiction. Namely pick two roots a and b. Since f(a) = f(b), by Rolle’s Theorem (or MVT) there is a c in-between a and b such that f'(c) = 0. But f'(x) = 3 – sin(x) >=2 > 0. Contradiction.")

#text("The less counter-factual proof would go something like follows. Since f'(x) > 0, we have that f(x) is strictly increasing, hence it can only cross the x-axis once. QED. Of course this is no longer a cookie cutter application of Rolle’s theorem, which is what I feel the book (Stewart) is going for.")

#text("A more MVT-theorem-based-version is as follows. Pick two points a and b. By MVT, there is a point c in-between such that f'(c) (b – a) = f(b) – f(a). Then we have f(b) = f(a) + f'(c) (b – a) >= f(a) + 3(b – a). Not only does this show f(a) doesn’t equal f(b), but it shows how much bigger (or smaller) f(b) is. This is actually related to another problem we assign from the same chapter, namely, “If f is a differentiable function with f'(x)<3, and f(2)=4, what is the largest f(6) can be?\".")

#text("Teaching calculus aside, this post was really insightful. Thanks for sharing!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8145e56a670a8fbaf54577418e47350e67acaec123f3060e19a240a043153f0c-a8235374b53ab547bdcb27970fe951167895b266f403f3a247e9b6a23be103b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Isaac S.")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47829")[#strong[#text("Isaac S.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("From a purely pedagogical perspective, isn’t the learning curve of counterfactual reasoning an important step in developing abstract thinking?")

#text("One might argue that a proof of Cantor’s theorem by contradiction is preferable precisely because it offends student’s sensibilities, and thereby develops lateral thinking.")

#text("Personally, I have found that the de-institutionalization of mathematics de-mystifies it. When mathematics “just has to make sense,”as opposed to needing to adhere to contrived, small-minded rules, creativity ensues.")

#text("If students are to grow in mathematics and critical thinking, they need to struggle with the question of “why,” just as much, if not more, than with the question of “how.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cbfa560fe943c4be841fa579d331a4ade315957474216bab36833d81314f943-d03f548612cc8385ed4cd51c87b84c6cde66608c62315366b247f935d869c517.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AK")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47832")[#strong[#text("AK")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("I think the discussion of the last “Theorem” is superficial. Suppose I am such")#linebreak()#text(" a being, and by Wednesday I have by some means already convinced you that I fulfill condition 2. (It is an interesting question _how_ I convince you of this,")#linebreak()#text(" clearly any finite set of stone-lifting acts can be deemed insufficient, but we leave this to the side now.) Now, having convinced you of C2, on Thursday I proceed to create a stone so heavy that even I can’t lift it. (Again, it is an interesting question on its own right how I convince you of this, how do you know that the created stone is really _that_ heavy, but again this is not what the “Theorem” is about.) It is evident that on Wednesday I fulfilled both C1 and")#linebreak()#text(" C2, being able to lift all stones and being able to create unliftable ones.")

#text("In general, the notion of omnipotence includes the potential to limit this omnipotence. Once limited, the being will no longer be omnipotent, but as long as she chooses not to the “Theorem” fails.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/778b162bceae6c67b03a5b8f8c3f87559320e863361c0ec50d9a06f2724415ba-38d615848b8f49948687061870d820258feaf6d56d4ca9f2a26536daabc3924d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47833")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("Being able to lift “all stones” (your words) is not necessarily the same as being able to lift “any possible stone” (the article’s words). The former could be taken to mean only all currently existing stones; the latter means that even on Wednesday, you (the G in the theorem) are able to lift Thursday’s stone. That stone is a ‘possible stone’ on Wednesday because it’s possible for you to create it.")

#text("You’ve implicitly introduced the notion of time into the language we’re using to describe things here, but you haven’t unambiguously rephrased the original theorem to both account for this notion and adhere to the spirit of the theorem. The obvious interpretation of ‘possible stone’ is ‘stone that exists now or could exist in the future.’ But then if you can lift it on Wednesday then to create it on Thursday you have to change your lifting capabilities to explicitly exclude this stone that on Wednesday you could lift. You’re falling prey to the same sort of trap that ‘mv’ did higher up in the thread: you’re not considering the same object on Wed that you are on Thurs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The “no self-defeating object” argument, and the vagueness paradox « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-47955")[#strong[#text("The “no self-defeating object” argument, and the vagueness paradox « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2010")])]

#text("[…] is the third in a series of posts on the “no self-defeating object” argument in mathematics – a powerful and useful […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c32b77be704877b04581c9dec918e467a3b051d52b8988a64df38adbbbd8b85-7f1fff461f221fc2496c870c44667758f62c5ff47070600801d8c2bd1b15a5c2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Why, when we round n+sqrt(n), do we never get a square? « Republic of Mathematics")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-48314")[#strong[#text("Why, when we round n+sqrt(n), do we never get a square? « Republic of Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2010")])]

#text("[…] Terry Tao has written extensively about these sort of arguments, The general idea is that we set up a world that we believe cannot exist – sort of like in science fiction, but math fiction. Then we carefully examine this world for consequences and see if something truly unacceptable occurs. If it does, we conclude that no such world can exist. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2d7012f1ce8dc48656a287f774f5a2f027acb76a5d2b23e90095a36c5f9327c-4944e88e7753979bbde0bb895db6a4c0c71057c13677a2ec7d49b7767349b272.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Hardy")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-48332")[#strong[#text("Michael Hardy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("“It was pointed out to me, though (originally with regards to Euclid’s theorem, but the same point in fact applies to the other results I presented) that one can pull a large fraction of each argument out of this counterfactual world,”")

#text("I remember pointing this out to you when you visited Minneapolis last year. But what I didn’t say, and possibly should have, but didn’t, mention in my joint article with Catherine Woodgold in the _Mathematical Intelligencer_ about what Euclid did and modern perceptions of it, was that what Euclid did was closer to your Proposition 3′ than to your Proposition 3. In particular, Euclid did not explicitly mention anything being “infinite”. Some people regard this as more than a mere terminology issue: Harold Edwards wrote a letter-to-the-editor that was published in the _Intelligencer_ making an issue of this point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-49549")[#strong[#text("Could God make pi = 3.15? - Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2011")]

#text("[…] grad student studying automorphic forms The following is a nice discussion of a related topic:")#link("https://terrytao.wordpress.com/20")[#text("https://terrytao.wordpress.com/20")]#text("…Insert a dynamic date hereCannot add comment at this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-49729")[#strong[#text("Avoiding Proof By Contradiction « PseudoRandom")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2011")]

#text("[…] Proof By Contradiction In this post Terence Tao explains how to avoid proof by contradiction. It shows another way to explain […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-50362")[#strong[#text("Finite Sets | Poincare's Paradise")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2011")]

#text("[…] links are link1,link2,link3. By going through these links we can understand how this method has been used in mathematics, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-59939")[#strong[#text("Self-Defeating Sentences « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")]

#text("[…] attempts to prove circuit lower bounds are self-defeating. This suggests the need for new ideas. In a fight-fire-with-fire mood, we hope that exploring the arena of self-defeat will stimulate […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-91535")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2011")])]

#text("“Theorem”: If G is a being, then G will be unable to do at least one of the following two tasks:")

#text("Create a stone so heavy that G cannot lift it.")#linebreak()#text(" Be able to lift any possible stone.")

#text("disproof: I can create a stone that weighs 200 pounds. Work out for five weeks. Lift stone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-91537")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2011")])]

#text("perhaps the act of creating a stone involved a lot of heavy lifting, and it also took exactly five weeks to make it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-110974")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("I feel like a simpler method of approaching that theorem would be to say “instead of lifting the rock, drop everything else.” thus the rock was “lifted” per se.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic limitations of the circle method « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-143792")[#strong[#text("Heuristic limitations of the circle method « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("[…] itself (in the spirit of “self-defeating object” arguments, discussed previously several times on this blog). This is actually a fairly common technique in analytic number theory (though not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-381254")[#strong[#text("What books to read to get smarter? | Key to study")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2014")]

#text("[…] Terence Tao’s blog. Tao on sets and logic. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-442952")[#strong[#text("Here Are 97 Books, Articles, And Movies That Will Make You Smarter | TAR News")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2014")]

#text("[…] Terence Tao’s blog. Tao on sets and logic. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-473252")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2016")])]

#text("When explaining the transition from “no self-defeating object” into “every object can be defeated”, you write:")

#text("“This change is almost trivial to enact (it is often little more than just taking the CONTRAPOSITIVE of the original statement), but it does offer a slightly different “non-counterfactual” (or more precisely, “not necessarily counterfactual”) perspective on these arguments which may assist in understanding how they work.”")

#text("Now I wonder: what does this have to do with the contrapositive? I think that the “no self-defeating object” version says ")#mi("\\neg\\exists x : P(x)")#text(", and the “any object can be defeated” version asserts ")#mi("\\forall x : \\neg P(x)")#text(". But the transition from ")#mi("\\neg\\exists x : P(x)")#text(" to ")#mi("\\forall x : \\neg P(x)")#text(" has nothing to do with the contrapositive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-473574")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2016")])]

#text("Terry, could you please answer my question?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b196981b438d17e454e2c80441f283eafc08683e8e13d6a538fa7947ec16d91a-e9f1e16ad8f8c40ae170196f615af3a31809330f17162c6f4560227cd4677d58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lukasz")]], [#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/#comment-535729")[#strong[#text("Lukasz")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2020")])]

#text("“Theorem 9 (Second Gödel incompleteness theorem). (Informal statement) No consistent logical system which has the notion of a predicate and a string, can provide a proof of its own logical consistency.”")

#text("In the paper: T. J. Stępień, Ł. T. Stępień, “On the Consistency of the Arithmetic System”, J. Math. Syst. Sci. 7, No.2, 43-55 (2017); arXiv:1803.11072 , a proof of the consistency of the Arithmetic System has been presented. This proof has been done within this Arithmetic System.")#linebreak()#text(" I know that this message can be received with a disbelief, however, please simply read this paper and consider this proof.")#linebreak()#text(" This paper does not contain any considerations related to either Second Gödel incompleteness theorem or First Gödel incompleteness theorem.")
]
