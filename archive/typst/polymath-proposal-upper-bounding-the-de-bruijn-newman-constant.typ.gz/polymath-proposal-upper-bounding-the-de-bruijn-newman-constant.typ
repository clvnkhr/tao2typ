// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/
// Converted to Typst by tao2typ: "2026-10-14T15:20:00.275153+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath proposal: upper bounding the de Bruijn-Newman constant", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath proposal: upper bounding the de Bruijn-Newman constant")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 January 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Building on the interest expressed in the comments to ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("this previous post")]#text(", I am now formally proposing to initiate a “")#link("https://en.wikipedia.org/wiki/Polymath_Project")[#text("Polymath project")]#text("” on the topic of obtaining new upper bounds on the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(". The purpose of this post is to describe the proposal and discuss the scope and parameters of the project.")

#link("https://mathscinet.ams.org/mathscinet-getitem?mr=37351")[#text("De Bruijn")]#text(" introduced a family ")#mi("{H_t: {\\bf C} \\rightarrow {\\bf C}}")#text(" of entire functions for each real number ")#mi("{t}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("H_t(z) := \\int_0^\\infty e^{tu^2} \\Phi(u) \\cos(zu)\\ du")]]

#text("where ")#mi("{\\Phi}")#text(" is the super-exponentially decaying function")

#align(center)[#tao-fit-display[#mitex("\\Phi(u) := \\sum_{n=1}^\\infty (2\\pi^2 n^4 e^{9u} - 3 \\pi n^2 e^{5u}) \\exp(-\\pi n^2 e^{4u}).")]]

#text("As discussed in ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("this previous post")]#text(", the Riemann hypothesis is equivalent to the assertion that all the zeroes of ")#mi("{H_0}")#text(" are real.")

#text("De Bruijn and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=434982")[#text("Newman")]#text(" showed that there existed a real constant ")#mi("{\\Lambda}")#text(" – the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" – such that ")#mi("{H_t}")#text(" has all zeroes real whenever ")#mi("{t \\geq \\Lambda}")#text(", and at least one non-real zero when ")#mi("{t < \\Lambda}")#text(". In particular, the Riemann hypothesis is equivalent to the upper bound ")#mi("{\\Lambda \\leq 0}")#text(". In the opposite direction, several lower bounds on ")#mi("{\\Lambda}")#text(" have been obtained over the years, most recently in ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("my paper with Brad Rodgers")]#text(" where we showed that ")#mi("{\\Lambda \\geq 0}")#text(", a conjecture ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=434982")[#text("of Newman")]#text(".")

#text("As for upper bounds, ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=37351")[#text("de Bruijn showed")]#text(" back in 1950 that ")#mi("{\\Lambda \\leq 1/2}")#text(". The only progress since then has been the work of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2531375")[#text("Ki, Kim and Lee")]#text(" in 2009, who improved this slightly to ")#mi("{\\Lambda < 1/2}")#text(". The primary proposed aim of this Polymath project is to obtain further explicit improvements to the upper bound of ")#mi("{\\Lambda}")#text(". Of course, if we could lower the upper bound all the way to zero, this would solve the Riemann hypothesis, but I do not view this as a realistic outcome of this project; rather, the upper bounds that one could plausibly obtain by known methods and numerics would be comparable in achievement to the various numerical verifications of the Riemann hypothesis that exist in the literature (e.g., that the first ")#mi("{N}")#text(" non-trivial zeroes of the zeta function lie on the critical line, for various large explicit values of ")#mi("{N}")#text(").")

#text("In addition to the primary goal, one could envisage some related secondary goals of the project, such as a better understanding (both analytic and numerical) of the functions ")#mi("{H_t}")#text(" (or of similar functions), and of the dynamics of the zeroes of these functions. Perhaps further potential goals could emerge in the discussion to this post.")

#text("I think there is a plausible plan of attack on this project that proceeds as follows. Firstly, there are results going back to the original work of de Bruijn that demonstrate that the zeroes of ")#mi("{H_t}")#text(" become attracted to the real line as ")#mi("{t}")#text(" increases; in particular, if one defines ")#mi("{\\sigma_{max}(t)}")#text(" to be the supremum of the imaginary parts of all the zeroes of ")#mi("{H_t}")#text(", then it is known that this quantity obeys the differential inequality ")#metadata(none) <tao-50b8d2c3973594d74271>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{d}{dt} \\sigma_{max}(t) \\leq - \\frac{1}{\\sigma_{max}(t)}")]]



#text(" whenever ")#mi("{\\sigma_{max}(t)}")#text(" is positive; furthermore, once ")#mi("{\\sigma_{max}(t) = 0}")#text(" for some ")#mi("{t}")#text(", then ")#mi("{\\sigma_{max}(t^{\\prime}) = 0}")#text(" for all ")#mi("{t^{\\prime} > t}")#text(". I hope to explain this in a future post (it is basically due to the attraction that a zero off the real axis has to its complex conjugate). As a corollary of this inequality, we have the upper bound ")#metadata(none) <tao-aee610558292023758a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Lambda \\leq t + \\frac{1}{2} \\sigma_{max}(t)^2")]]



#text(" for any real number ")#mi("{t}")#text(". For instance, because all the non-trivial zeroes of the Riemann zeta function lie in the critical strip ")#mi("{\\{ s: 0 \\leq \\mathrm{Re} s \\leq 1 \\}}")#text(", one has ")#mi("{\\sigma_{max}(0) \\leq 1}")#text(", which when inserted into ")#link(<tao-aee610558292023758a4>)[#text("(2)")]#text(" gives ")#mi("{\\Lambda \\leq 1/2}")#text(". The inequality ")#link(<tao-50b8d2c3973594d74271>)[#text("(1)")]#text(" also gives ")#mi("{\\sigma_{max}(t) \\leq \\sqrt{1-2t}}")#text(" for all ")#mi("{0 \\leq t \\leq 1/2}")#text(". If we could find some explicit ")#mi("{t}")#text(" between ")#mi("{0}")#text(" and ")#mi("{1/2}")#text(" where we can improve this upper bound on ")#mi("{\\sigma_{max}(t)}")#text(" by an explicit constant, this would lead to a new upper bound on ")#mi("{\\Lambda}")#text(".")

#text("Secondly, the work of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2531375")[#text("Ki, Kim and Lee")]#text(" (based on an analysis of the various terms appearing in the expression for ")#mi("{H_t}")#text(") shows that for any positive ")#mi("{t}")#text(", all but finitely many of the zeroes of ")#mi("{H_t}")#text(" are real (in contrast with the ")#mi("{t=0}")#text(" situation, where it is still an open question as to whether the proportion of non-trivial zeroes of the zeta function on the critical line is asymptotically equal to ")#mi("{1}")#text("). As a key step in this analysis, Ki, Kim, and Lee show that for any ")#mi("{t>0}")#text(" and ")#mi("{\\varepsilon>0}")#text(", there exists a ")#mi("{T>0}")#text(" such that all the zeroes of ")#mi("{H_t}")#text(" with real part at least ")#mi("{T}")#text(", have imaginary part at most ")#mi("{\\varepsilon}")#text(". Ki, Kim and Lee do not explicitly compute how ")#mi("{T}")#text(" depends on ")#mi("{t}")#text(" and ")#mi("{\\varepsilon}")#text(", but it looks like this bound could be made effective.")

#text("If so, this suggests a possible strategy to get a new upper bound on ")#mi("{\\Lambda}")#text(":")

#list(
[#text("Select a good choice of parameters ")#mi("{t, \\varepsilon > 0}")#text(".")],
[#text("By refining the Ki-Kim-Lee analysis, find an explicit ")#mi("{T}")#text(" such that all zeroes of ")#mi("{H_t}")#text(" with real part at least ")#mi("{T}")#text(" have imaginary part at most ")#mi("{\\varepsilon}")#text(".")],
[#text("By a numerical computation (e.g. using the argument principle), also verify that zeroes of ")#mi("{H_t}")#text(" with real part between ")#mi("{0}")#text(" and ")#mi("{T}")#text(" have imaginary part at most ")#mi("{\\varepsilon}")#text(".")],
[#text("Combining these facts, we obtain that ")#mi("{\\sigma_{max}(t) \\leq \\varepsilon}")#text("; hopefully, one can insert this into ")#link(<tao-aee610558292023758a4>)[#text("(2)")]#text(" and get a new upper bound for ")#mi("{\\Lambda}")#text(".")]
)

#text("Of course, there may also be alternate strategies to upper bound ")#mi("{\\Lambda}")#text(", and I would imagine this would also be a legitimate topic of discussion for this project.")

#text("One appealing thing about the above strategy for the purposes of a polymath project is that it naturally splits the project into several interacting but reasonably independent parts: an analytic part in which one tries to refine the Ki-Kim-Lee analysis (based on explicitly upper and lower bounding various terms in a certain series expansion for ")#mi("{H_t}")#text(" – I may detail this later in a subsequent post); a numerical part in which one controls the zeroes of ")#mi("{H_t}")#text(" in a certain finite range; and perhaps also a dynamical part where one sees if there is any way to improve the inequality ")#link(<tao-aee610558292023758a4>)[#text("(2)")]#text(". For instance, the numerical “team” might, over time, be able to produce zero-free regions for ")#mi("{H_t}")#text(" with an increasingly large value of ")#mi("{T}")#text(", while in parallel the analytic “team” might produce increasingly smaller values of ")#mi("{T}")#text(" beyond which they can control zeroes, and eventually the two bounds would meet up and we obtain a new bound on ")#mi("{\\Lambda}")#text(". This factoring of the problem into smaller parts was also a feature of the successful ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(" on bounded gaps between primes.")

#text("The project also resembles Polymath8 in another aspect: that there is an obvious way to numerically measure progress, by seeing how the upper bound for ")#mi("{\\Lambda}")#text(" decreases over time (and presumably there will also be another metric of progress regarding how well we can control ")#mi("{T}")#text(" in terms of ")#mi("{t}")#text(" and ")#mi("{\\varepsilon}")#text("). However, in Polymath8 the final measure of progress (the upper bound ")#mi("{H}")#text(" on gaps between primes) was a natural number, and thus could not decrease indefinitely. Here, the bound will be a real number, and there is a possibility that one may end up having an infinite descent in which progress slows down over time, with refinements to increasingly less significant digits of the bound as the project progresses. Because of this, I think it makes sense to follow recent Polymath projects and place an expiration date for the project, for instance one year after the launch date, in which we will agree to end the project and (if the project was successful enough) write up the results, unless there is consensus at that time to extend the project. (In retrospect, we should probably have imposed similar sunset dates on older Polymath projects, some of which have now been inactive for years, but that is perhaps a discussion for another time.)")

#text("Some Polymath projects have been known for a breakneck pace, making it hard for some participants to keep up. It’s hard to control these things, but I am envisaging a relatively leisurely project here, perhaps taking the full year mentioned above. It may well be that as the project matures we will largely be waiting for the results of lengthy numerical calculations to come in, for instance. Of course, as with previous projects, we would maintain some wiki pages (and possibly some other resources, such as a code repository) to keep track of progress and also to summarise what we have learned so far. For instance, as was done with some previous Polymath projects, we could begin with some “online reading seminars” where we go through some relevant piece of literature (most obviously the Ki-Kim-Lee paper, but there may be other resources that become relevant, e.g. one could imagine the literature on numerical verification of RH to be of value).")

#text("One could also imagine some incidental outcomes of this project, such as a more efficient way to numerically establish zero free regions for various analytic functions of interest; in particular, the project may well end up focusing on some other aspect of mathematics than the specific questions posed here.")

#text("Anyway, I would be interested to hear in the comments below from others who might be interested in participating, or at least observing, this project, particularly if they have suggestions regarding the scope and direction of the project, and on organisational structure (e.g. if one should start with reading seminars, or some initial numerical exploration of the functions ")#mi("{H_t}")#text(", etc..) One could also begin some preliminary discussion of the actual mathematics of the project itself, though (in line with the leisurely pace I was hoping for), I expect that the main burst of mathematical activity would happen later, once the project is formally launched (with wiki page resources, blog posts dedicated to specific aspects of the project, etc.).")

#heading(level: 1)[#text("Comments (60)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94b119ca4cc69e81179906465f31bc5b87f9af4b97c1d7374f6748d2dd704368-e8dddf8432bc45860ddd8d154896028c6e96836d226ce972fbbb96f057a24065.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jair")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491743")[#strong[#text("Jair")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("There seems to be a missing factor in the given formula for $H_t$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491746")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("Yes, t is missing")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("the differential inequality (1) can be written in a somewhat simpler form")#linebreak()#text(" ")#mi("(\\sigma^2_{max})^{\\prime}(t) \\leq -2")#text(" whenever ")#mi("\\sigma_{max}(t) >0")#linebreak()#text(" Which motivates improving the upper bound ")#mi("-2")#text(" on ")#mi("(\\sigma^2_{max})^{\\prime}(t)")#text(" (thereby improving ")#mi("\\sigma_{max}(t)")#text(" current upper bound), as well as a corresponding lower(!) bound on the rate of decrease of ")#mi("\\sigma^2_{max}(t)")#text(" – since this should imply also a lower bound on ")#mi("\\sigma_{max}(t)")#text(". Suppose e.g. that this rate is lower-bounded by ")#mi("-10")#text(", then it implies that")#linebreak()#text(" ")#mi("0 = \\sigma^2_{max}(\\Lambda) \\geq \\sigma^2_{max}(0) - 10 \\Lambda")#linebreak()#text(" Implying that ")#mi("\\sigma^2_{max}(0) \\leq 10 \\Lambda")#text(" (which for ")#mi("\\Lambda < 0.1")#text(" would give ")#mi("\\sigma_{max}(0) < 1")#text(" – showing the importance of finding also good lower bounds for ")#mi("(\\sigma^2_{max})^{\\prime}(t)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491753")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("Well from the perspective of the numerical team, I would just highlight some good practices which will enable many more people to participate. Firstly, with the previous Polymath 8 project, it was somewhat difficult to access the latest code and revisions, used for example by Pace Nielsen. It would be a good idea to use something like Github and everyone can keep updating code improvements there. Secondly, it would be good to have a pseudocode of an algorithm to quickly calculate zeroes of H_t, something like the Riemann-Siegel formula for zeta zeroes. This way the numerical team can quickly set things up and get going. Thirdly, from a medium term perspective, as we lower t and the computations get heavy, it would be great if some big organizations can donate some cloud computing power. If not that, then maybe a distributed computing structure like Folding@Home. Ofcourse, if we manage to get 3), the project can keep going on from the numerical side even after an year. – KM")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("Although a precise horizontal(!) localization of the zeroes of ")#mi("H_t")#text(" is not really needed (according to (2), only a zero-free rectangular region is needed for a upper bound on ")#mi("\\Lambda")#text(") but for smaller upper bound on ")#mi("\\Lambda")#text(" it seems that smaller ")#mi("t")#text(" and ")#mi("\\epsilon")#text(" are also required (still without need for precise horizontal localization of ")#mi("H_t")#text(" zeroes) for which the dynamics of each ")#mi("H_t")#text(" zero becomes more dependent also on precise horizontal locations of the “nearby attracting zeroes” (whose horizontal distribution becomes “less regular” for smaller ")#mi("t")#text(" values).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491788")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("Well for those comfortable with Github, I have created a GitHub project ")#link("https://github.com/km-git-acc/dbn_upper_bound")[#text("https://github.com/km-git-acc/dbn_upper_bound")]

#text("Please edit it as necessary. I have removed the restriction which allows only collaborators to edit things. And if you face any issues, do let me know.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491794")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("Thanks for this! It has been a while since I have used git but I will try to see if I can access it. In the meantime, I have started a wiki page at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")]#text(" and have added a link to this repository.")

#text("It may take a while for the analysis side of the project to get the point where it really needs the numerical side, but I think it is worth trying to get some numerical activity from the beginning (and it is here where I will need the most help, as I do not have extensive experience with numerics, particularly involving contour integration and locating of zeroes). Perhaps one starting point will be to see if we can get enough preliminary numerics on ")#mi("H_t")#text(" to numerically verify the interesting claims in Theorem 1.4 of ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.164.5595&rep=rep1&type=pdf")[#text("Ki, Kim, and Lee")]#text(", which in the current notation asserts that for any fixed ")#mi("t>0")#text(", the zeroes ")#mi("z_j(t)")#text(" of ")#mi("H_t")#text(" eventually become all real and roughly equally spaced with")

#mi("\\displaystyle z_{j+1}(t)-z_j(t) = (1+o(1)) \\frac{4\\pi}{\\log z_j(t)}")

#text("and also the number ")#mi("N_t(T)")#text(" of zeroes of real part between 0 and ")#mi("T")#text(" should obey the asymptotic")

#mi("\\displaystyle N(T) = \\frac{T}{4\\pi} \\log \\frac{T}{4\\pi} - \\frac{T}{4\\pi} + t \\log \\frac{T}{4\\pi} + O(1).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491797")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("Thanks. I have updated the repo with the Polymath wiki link. I have also started some Python scripting and will later keep working on speed optimizations, areas where I think I will be more useful. H_t for real values of z is much easier to start with, and to compare against the expected N_t(T), so I will begin with that. It would be great to get more help on contour integration.")

#text("On checking some values of the phi decay function, it does decay quite rapidly.")#linebreak()#text(" For eg. I got these values for")#linebreak()#text(" u = 0.001, 0.1 1")#linebreak()#text(" phi_decay (approx) = 0.44668, 0.30427, 5.1*10^-70")#linebreak()#text(" and the values seem to become insensitive to increasing n in the infinite sum. H_t may be well approximated by a low upper limit in the integral.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e0a8a2e2344e131138ae78deea4250c2a4428b848478a322c56d9fa4960eaab-849719771b0abac88643a26bdf8d1667146dc834b5d4a9f9a9e9069a4101bd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TS")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491834")[#strong[#text("TS")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("Let ")#mi("t\\geq 0")#text(" and call ")#mi("KKL(t)")#text(" the property “all but finitely many zeros of ")#mi("H_t")#text(" are real and simple”. I find it very striking that it is known to be true for all ")#mi("t>0")#text(" but not known whether true or not for ")#mi("t=0")#text(". Of course, in dynamical systems theory when one varies parameters some bifurcations can occur which change the local and global properties of the dynamics (incidentaly, scholarpedia is better than wikipedia on these topics). But since, if I understand well, ")#mi("t=0")#text(" is meant to be the low energy regular limit, decreasing ")#mi("t")#text(" shouldn’t worsen things and thus conserve such a property. So there might be a topological way of seeing that ")#mi("KKL(0)")#text(" is true. (There are a few sentences at the beginning of the book Topological Invariants of plane curves and caustics by V.I.Arnold that might be helpfull in that regard, but it is over my head.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491795")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("I think I managed to download git on my machine, clone the repository, and send a test push request, so I think it is all working :)")

#text("Perhaps a very preliminary warmup exercise would be to numerically verify the fact that the function")

#mi("\\Phi(u) = \\sum_{n=1}^\\infty (2\\pi^2 n^4 e^{9u} - 3 \\pi n^2 e^{5u}) \\exp( -\\pi n^2 e^{4u} )")

#text("is indeed even (as proven in a previous blog post), and that the zeroes of")

#mi("H_0(z) = \\int_0^\\infty \\Phi(u) \\cos(zu)\\ du")

#text("are twice the ordinates of the Riemann zeta function (in particular, the first zero should be approximately at ")#mi("z = 28.26")#text(").")

#text("I will try to write an initial Polymath post over the weekend, discussing both the numerical goals and the analytic goals (presumably starting with digesting relevant parts of the KKL paper) to launch the project. I was initially thinking of having two separate posts, one for the analytical side and one for the numerical side, but it looks like the rate of comments will be on the light side for a polymath project, and it should hopefully be possible to follow the progress even if both discussions are merged into a single thread.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491796")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("Actually, I was only able to commit to a local repository but was unable to push to the master (got the error message “remote: Permission to km-git-acc/dbn_upper_bound.git denied … fatal: unable to access ‘https://github.com/km-git-acc/dbn_upper_bound.git/’: The requested URL returned error: 403”). Maybe there is a permissions issue? (Sorry, I am very rusty with git)")

#text("EDIT: ssh access also fails with a different error (git@github.com: Permission denied (publickey)), but this may be a problem from my end. (Now I remember why I stopped using git…)")

#text("SECOND EDIT: Using github for Windows GUI, I can push to the master branch of my own test repository under my github account (user name teorth), but not to the dbn_upper_bound one (“Authentication failed. You may not have permission to access the repository or the repository may have been archived. Open options and verify that you’re signed in with an account that has permission to access this repository.”). So I suspect that the dbn_upper_bound repo can only grant read access and not write access to random github users at present.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491798")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("I will look into the permissions issue. It has been discussed here ")#link("https://stackoverflow.com/questions/17857283/permission-denied-error-on-github-push")[#text("https://stackoverflow.com/questions/17857283/permission-denied-error-on-github-push")]#text(" and could be due to several reasons.")

#text("Also if it is a new file, it may be easier to go to the repo link in the browser and copy paste the content into a new file.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("OK, I have followed the advice in that link of forking the repository, committing to the fork, and sending a pull request back to the master, hopefully that works.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491801")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("This is what I got for H_0 as I took z from 20 to 28.26 to 29, and it seems to be working. There is a sign change after 28.26 indicating a zero nearby. The computation can be made sharper still which I will attempt later.")

#text("z, H_0, error_bound_in_H_0_estimation")

#text("(20, 0.004745981288866963, 3.369905401820819e-12)")#linebreak()#text(" (24, 0.0011029563388465873, 9.344057770371492e-11)")#linebreak()#text(" (26, 0.0003631588937652417, 1.5325919331364568e-10)")#linebreak()#text(" (28, 2.5161805529409477e-05, 2.2423109376223938e-10)")#linebreak()#text(" (28.06, 1.922635521388559e-05, 2.2649502499222374e-10)")#linebreak()#text(" (28.12, 1.3484644556851843e-05, 2.287850213097964e-10)")#linebreak()#text(" (28.18, 7.93277306917266e-06, 2.310924854254104e-10)")#linebreak()#text(" (28.24, 2.5668886862708826e-06, 2.3343800503727863e-10)")#linebreak()#text(" —- (28.26, 8.189321953356443e-07, 2.342308777492086e-10)")#linebreak()#text(" (28.28, -9.089217903637239e-07, 2.35030161131744e-10)")#linebreak()#text(" (28.4, -1.0861641032745077e-05, 2.3999972582205986e-10)")#linebreak()#text(" (29, -5.085338498640488e-05, 2.79882348200311e-10)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("It’s somewhat late here so signing off. Please give your Github handle and I will add you as a collaborator by tomorrow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("Saw your handle teorth in your post just now :), and added you as a collaborator.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491805")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("Have merged your pull request as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("Great! Looks like it is all working now… still have to test if I can do an upstream pull for any new files you have, but I think I see how to do it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a09971234162a15562647a9298f2360626bba53001f4aeea0032eb6628efe388-14bee498c35907261aa2cb911d5eeecc8a147dde11ac3c0e361d90d8bcd34052.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Bauer")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491807")[#strong[#text("Bill Bauer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("FWIW, github users often fork repositories to their own accounts, push changes to their own forks, and issue pull requests from their forks to the original.")

#text("Also, FWIW, I’ll try to maintain a Julia port of the code which appears in KM’s repository. My repo is here ")#link("https://github.com/WilCrofter/DBNUpperBound.jl")[#text("https://github.com/WilCrofter/DBNUpperBound.jl")]#text(". It’s essentially empty at the moment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cdbd72c0f5aec33c714478608ad6e537ceb31603a9db46a5659ab80a801b259-90dd1d0fc86c630531fc91aae4adc745e1b3818ef36c371efbe91e8f9361c683.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491809")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("In case anyone prefers Matlab, here is a function that plots Ht(z). The for loops make the plotting inefficient, but it’s fine for now I suppose.")#linebreak()#text(" —————————")

#text("function dbn_numerics")#linebreak()#text(" %%% this function plots the real and imaginary parts of the function H_t as")#linebreak()#text(" %%% two surfaces. Ht is a function of z=(zreal,zimag).")#linebreak()#text(" %%% Htrealval is the real part of Ht")#linebreak()#text(" %%% Htimagval is the imaginary part of Ht")

#text("t=0; % parameter for the function Ht")#linebreak()#text(" numpts=100; % number of points on a one-dimensional axis")#linebreak()#text(" %r=10;")#linebreak()#text(" %zreal=linspace(-r,r,numpts);")#linebreak()#text(" %zimag=linspace(-r,r,numpts);")#linebreak()#text(" zreal=linspace(26,30,numpts); % real and imaginary parts of z")#linebreak()#text(" zimag=linspace(-2,2,numpts);")#linebreak()#text(" Htrealval=zeros(numpts,numpts);")#linebreak()#text(" Htimagval=zeros(numpts,numpts);")#linebreak()#text(" for i=1:numpts")#linebreak()#text(" for j=1:numpts")#linebreak()#text(" Htrealval(i,j)=RealPartHt(t,zreal(i),zimag(j));")#linebreak()#text(" Htimagval(i,j)=ImagPartHt(t,zreal(i),zimag(j));")#linebreak()#text(" end")#linebreak()#text(" end")#linebreak()#text(" surf(ones(numpts,1)*zreal,zimag’*ones(1,numpts),Htrealval);")#linebreak()#text(" hold on")#linebreak()#text(" surf(ones(numpts,1)*zreal,zimag’*ones(1,numpts),Htimagval);")#linebreak()#text(" xlabel(‘Real z axis’);")#linebreak()#text(" ylabel(‘Imaginary z axis’)")#linebreak()#text(" end")

#text("%we always denote z=x+iy as z=(x,y)")#linebreak()#text(" % using cos (x+iy) = cos x cosh(y) – i sin x sinh(y)")#linebreak()#text(" function h=RealPartHt(t,x,y)")#linebreak()#text(" M=20; % integrate from 0 to M in the definition of Ht")#linebreak()#text(" tol=10^-8; %relative tolerance threshold for integral")

#text("integrateme=@(u)Phi(u).*exp(t.*(u.^2)).*cos(x.*u).*cosh(y.*u); % function to integrate")#linebreak()#text(" h=integral(integrateme,0,M,’RelTol’,tol);s")#linebreak()#text(" end")

#text("%we always denote z=x+iy as z=(x,y)")#linebreak()#text(" % using cos (x+iy) = cos x cosh(y) – i sin x sinh(y)")#linebreak()#text(" function h=ImagPartHt(t,x,y)")#linebreak()#text(" M=20; % integrate from 0 to M in the definition of Ht")#linebreak()#text(" tol=10^-8; %relative tolerance threshold for integral")

#text("integrateme=@(u)Phi(u).*exp(t.*(u.^2)).*sin(x.*u).*sinh(y.*u); % function to integrate")#linebreak()#text(" h=-integral(integrateme,0,M,’AbsTol’,tol);")#linebreak()#text(" end")

#text("function phi=Phi(u)")#linebreak()#text(" N=100; % sum from 1 to N")#linebreak()#text(" n=(1:N)’;")#linebreak()#text(" phivec= (n.^(2)).*(exp(5.*u)).*(2.*(pi^2).*(n.^(2)).*(exp(4.*u)) – 3*pi).*exp(-pi.*(n.^(2)).*exp(4.*u));")#linebreak()#text(" phi=sum(phivec);")#linebreak()#text(" end")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6803f451a822a44c3357dffe0946273ac8b678c1381d8f6f15471f78bf5064e-c0cdd6fbf9fa11cb38f669d32e0c33214ced4ab5f9e837265aa2a25f482e13f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brad")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491810")[#strong[#text("Brad")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("I’ve just signed up for github and started watching — I don’t have any experience using it, but I don’t know that my main contributions will be able to be on the numerical side either. (That said, I will be very interested to learn more about this area; I’ve used e.g. tables of zeta zeros before but have no experience with the actual large-scale computation of them.)")

#text("Terry mentioned in a comment that one interesting numerical exercise would be to numerically verify some of the results of Ki, Kim, and Lee regarding the zeros of H_t(z) for t > 0. It might also be interesting at the same time to numerically locate some of the zeros of H_t(z) for some fixed negative t’s. In particular it seems reasonable enough to suspect that for negative t some zeros with real part ")#mi("T")#text(" will have imaginary part with order as large as ")#mi("\\log T")#text(", although we don’t prove this in our paper.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f8f9b5a6cbc79efa82226a86929dbdbd2668da505056a2a49276ffcfc6a0d5a-85c0a936f7a9698a842b038b35e2c3079f82de78605ec9a35e01b7df0d8c1e81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dhjpolymath")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491866")[#strong[#text("dhjpolymath")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#link("https://help.github.com/articles/permission-levels-for-a-user-account-repository/")[#text("https://help.github.com/articles/permission-levels-for-a-user-account-repository/")]#text(" provide information on permissions for repositories.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491758")[#strong[#text("El duro camino hacia la demostración de la hipótesis de Riemann | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")]

#text("[…] Una pena, pero el nuevo resultado de Tao y Rodgers cierra puertas, en lugar de abrirlas. El artículo es Brad Rodgers, Terence Tao, “The De Bruijn-Newman constant is non-negative,” arXiv:1801.05914 [math.NT]; más información divulgativa (aunque solo para matemáticos) en Terence Tao, “The De Bruijn-Newman constant is non-negative,” What’s new, 19 Jan 2018. Sabemos que 0 ≤ Λ < 1/2, reducir esta cota superior es el objetivo del nuevo proyecto polimatemático Polymath15, como nos cuenta Terence Tao, “Polymath proposal: upper bounding the de Bruijn-Newman constant,” What’s new, 24 Jan 2018. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491769")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("Two further mathematical comments. Firstly, it may be possible to leverage the existing numerical work on the Riemann zeta function. The work of Gourdon et al. verifies that the first 10^13 zeroes of zeta are on the critical line, which should show that H_0 has all zeroes real up to real part 5 x 10^12 or so (from a quick and dirty application of the Riemann-von Mangoldt formula). Unfortunately, we don’t understand the dynamics of the ODE ")#mi("\\partial_t x_j(t) = -2 \\sum_{k \\neq j} \\frac{1}{x_k(t)-x_j(t)}")#text(" well enough yet to directly use this to say much about the zeroes ")#mi("x_j(t)")#text(" of ")#mi("H_t")#text(" for ")#mi("t>0")#text(" (the ODE does not prevent the zeroes from reaching unbounded velocities and so in principle a lot of non-real zeroes could enter the region ")#mi("\\mathrm{Re}(z) \\leq 5 \\times 10^{12}")#text(" in finite time). But maybe we will be able to limit this influx of zero scenario somehow.")

#text("The second comment is to describe at a very high level how the Ki-Kim-Lee analysis works. ")#strike[#text("By Fubini’s theorem, one has an expansion")]

#mi("\\displaystyle H_t(z) = \\sum_{n=1}^\\infty 2\\pi^2 n^4 J_{t,9}( \\pi n^2, z) - 3 \\pi n^2 J_{t,5}(\\pi n^2, z)")

#text("where ")#mi("J_{t,a}(\\beta,z)")#text(" is the oscillatory integral")

#mi("\\displaystyle J_{t,a}(\\beta, z) := \\int_0^\\infty \\exp(tu^2 + au - \\beta e^{4u}) \\cos(zu)\\ du.")

#text("As it turns out, if one uses methods such as the saddle point method, one can show that for ")#mi("t")#text(" positive and as the real part of ")#mi("z")#text(" gets large, the first term ")#mi("2\\pi^2 J_{t,9}(1,z)")#text(" of this series dominates all the others, and also stays away from zero (after renormalising away some decay factors) if one is away from the real axis (actually it would be nice to have some numerical verification of this). This is basically how Ki-Kim-Lee get strong control on ")#mi("H_t(z)")#text(" for ")#mi("t")#text(" positive and real part of ")#mi("z")#text(" large. Interestingly, the control is a lot better asymptotically for ")#mi("t > 0")#text(" than for the much better studied ")#mi("t=0")#text(" case. Presumably if we wanted to make the Ki-Kim-Lee analysis effective, we would begin by getting explicit upper bounds on ")#mi("J_{t,a}(\\beta,z)")#text(" (and lower bounds on ")#mi("J_{t,9}(1,z)")#text(").")

#text("ADDED LATER: it looks like I misread the Ki-Kim-Lee analysis slightly (was a bit confused because they have a different normalisation convention to the one here). They do expand out ")#mi("H_t")#text(" as a series in which a single oscillatory integral dominates, but the series expansion they used is not quite the one I described above; the main term instead looks something like ")#mi("\\int_i^{i+\\infty} x^{-7/4} \\exp( t \\log^2 x - \\pi x + i \\pi z \\log x )\\ dx")#text(". I will have to go through the paper more carefully to figure out exactly what is going on, probably a topic for a future blog post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491778")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("In order to better understand the ODE of the “zero attraction dynamics”, it would be interesting to find the invariants (e.g. “conservation laws”) for this ODE dynamics (similar to the Newtonian gravitational dynamics).")#linebreak()#text(" There are well-developed methods (e.g. Cartan’s equivalence method, or differential algebraic methods) to find the invariants of a given nonlinear system of ODE or PDE.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491779")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("The ODE is a gradient flow (at least in the case of real zeroes), so one wouldn’t expect too many invariants. In the case of real zeroes, there are at least some monotonicity formulae: I discuss these in the previous post ")#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/")[#text("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/")]#text(" . However, for complex zeroes a lot of the monotonicity properties break down. Currently the only monotonicity that seems to be available is the monotonicity of ")#mi("\\sigma_{max}(t)")#text(", but there may well be other quantities whose time derivative is somehow under control.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491799")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("It seems that it is quite simple to identify the main terms controlling the horizontal and vertical components of the “relative velocity” dynamics of two (sufficiently close) simple zeros of ")#mi("H_t")#text(" as follows:")

#text("Let ")#mi("z_i, z_j")#text(" be two distinct simple zeros of ")#mi("H_t")#text(". By the above ODE, simple calculation gives")

#mi("\\partial_t (z_i - z_j) = -2 \\sum_{k \\neq i} 1/ (z_k - z_i) + 2 \\sum_{k \\neq j} 1/(z_k - z_j)")

#mi("= 4 /(z_i - z_j) + 2 \\sum_{k \\neq i, j} [1/(z_k - z_j) - 1/(z_k - z_i)]")

#mi("= 4/ (z_i - z_j) - 2 (z_i - z_j) S_{i, j}")

#text("Where ")#mi("S_{i, j} := \\sum_{k \\neq i, j} 1/ ((z_k - z_i) (z_k - z_j))")

#text("The function ")#mi("S_{i, j}")#text(" is locally analytic in ")#mi("t")#text(", possibly bounded and may be estimated (by partial summation) from sufficiently good estimate on the distribution of ")#mi("H_t")#text(" zeros. Therefore")

#tao-math("\\partial_t [\\left|z_i - z_j\\right|^2] = \\partial_t [(z_i - z_j) \\overline {(z_i - z_j)}]", block: false)

#mi("= 2 \\Re [\\overline {(z_i - z_j)} \\partial_t (z_i - z_j)]")

#tao-math("= 8 \\Re [\\overline {(z_i - z_j)} / (z_i - z_j)] - 4 \\left|z_i - z_j\\right|^2 \\Re (S_{i, j})", block: false)

#text("And similarly")

#mi("\\partial_t [(z_i - z_j)^2] = 2 (z_i - z_j) \\partial_t (z_i - z_j)")

#mi("= 8 - 4 (z_i -z_j)^2 S_{i, j}")

#mi("\\partial_t \\Re [(z_i - z_j)^2] = 8 - 4 \\Re [(z_i - z_j)^2 S_{i, j}]")

#text("Denote by ")#mi("x_i , y_i")#text(" the real and imaginary parts of each zero ")#mi("z_i")#text(" of ")#mi("H_t")#text(". We have (using the above expressions) the following expression for the “horizontal relative dynamics” between two zeros:")

#tao-math("\\partial_t [(x_i - x_j)^2]=(1/2)\\partial_t (\\left|z_i - z_j\\right|^2 + \\Re[(z_i -z_j)^2])", block: false)

#mi("= 4 (\\Re [\\overline {(z_i - z_j)} / (z_i - z_j)] +1)")#text(" (“main term” !)")

#tao-math("- 2 \\left|z_i - z_j\\right|^2 \\Re (S_{i, j}) - 2 \\Re [(z_i - z_j)^2 S_{i, j}]", block: false)

#text("Observe that the above “main term” is ")#tao-math("8 (x_i - x_j)^2 / \\left|z_i - z_j\\right|^2", block: false)#linebreak()#text(" which is non-negative (explaining the “horizontal repulsion” between nearby zeros), bounded(!) by 8, and dependent only(!) on the zeros ")#mi("z_i, z_j")#text(". While the remaining two terms are ")#tao-math("O(\\left|z_i - z_j\\right|^2 \\left|S_{i, j}\\right|)", block: false)#text(" are dependent also on the other zeros but still negligible (with respect to the “main term”) for sufficiently small ")#tao-math("\\left|z_i - z_j\\right|", block: false)#text(".")

#text("Similarly, we have for the “vertical relative dynamics” between two zeros:")

#tao-math("\\partial_t [(y_i - y_j)^2] =(1/2) \\partial_t (\\left|z_i - z_j\\right|^2 -\\Re[(z_i - z_j)^2])", block: false)

#mi("= 4 (\\Re [\\overline {(z_i - z_j)} / (z_i - z_j)] - 1)")#text(" (“main term” !)")

#tao-math("- 2 \\left|z_i - z_j\\right|^2 \\Re (S_{i, j}) + 2 \\Re [(z_i - z_j)^2 S_{i, j}]", block: false)

#text("Observe that the above (vertical!) main term is")

#tao-math("- 8(y_i - y_j)^2 / \\left|z_i - z_j\\right|^2", block: false)

#text("which is non-positive (explaining the “vertical attraction” between nearby zeros), bounded(!) in magnitude by 8, and dependent only(!) on the zeros ")#mi("z_i, z_j")#text(". As before, the remaining two terms are")#linebreak()#text(" ")#tao-math("O(\\left|z_i - z_j\\right|^2 \\left|S_{i, j}\\right|)", block: false)#text(".")

#text("Remark: It seems that this gives good control on the ")#mi("H_t")#text(" zero dynamics, both horizontally and vertically.")#linebreak()#text(" The boundedness of the horizontal dynamics can help to control possible horizontal zero influx to a zero-free region of ")#mi("H_0")#text(" (as you mentioned above), while the boundedness of the vertical dynamics may help to establish a good correspondence between ")#mi("\\Lambda")#text(" and ")#mi("sigma_{max}(0)")#text(" with a possible proof of ")#mi("\\sigma_{max}(0)< 1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491828")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("In principle this is what happens to a zero that is very close to another zero, but the situation could be more complicated than this if there is a cluster of three or more zeroes that are very close to each other. In that case one cannot just pick out one neighbour ")#mi("z_j")#text(" for each ")#mi("z_i")#text(" to designate as the “dominant” interaction and try to treat all other interactions as a lower order background term ")#mi("S_{ij}")#text(", because this term will be comparable or stronger to the main term. The worst case scenario is if some tight cluster of zeroes, starting beyond range of numerics (e.g. beyond the first 10^13 zeroes of zeta somehow begins to acquire a massive horizontal velocity and zooms towards the origin so that by, say, t = 0.1 it ends up at a quite low height. There should be some way to prevent this (some sort of local conservation of center of mass, perhaps?) but it probably involves analysing multiple interactions, not just that of a pair. For similar reasons it could be difficult to numerically model the ODE to high accuracy once a zero can get close to many other zeroes simultaneously.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491832")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("It seems that this require an extended analysis for the dynamics of a cluster of zeros (both for its relative zeros velocities as well as its “center of mass”) with more distant zeros (with some information on their distribution) in the background.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491772")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("Another analytic-probabilistic approach to study the functions ")#mi("H_t")#text(" is to use the backward heat equation satisfied by them and search for a possible stochastic diffusion process which generates this equation (and the functions ")#mi("H_t")#text(" as some related “probability density functions”).")#linebreak()#text(" Such probabilistic interpretation of ")#mi("H_t")#text(" can help to use more probabilistic tools to study its properties (e.g. by using asymptotic random matrix theory, Feynman-Kac formula, etc.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491774")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("It is even possible that ")#mi("\\Lambda =0")#text(" (i.e. RH is true) and for each ")#mi("t >0")#text(" there is a simple Hermitian operator (possibly related to a probabilistic interpretation of ")#mi("H_t")#text(") having ")#mi("H_t")#text(" zeros as its spectrum (i.e. realizing Hilbert-Polya approach for ")#mi("H_t")#text(") but no such operator for ")#mi("t=0")#text(" (which may explain the failed attempts so far to find it). Since the zeros of ")#mi("H_t")#text(" converge to that of ")#mi("H_0")#text(", it is possible that there is a proof of RH via the functions ")#mi("H_t")#text(" (whose zeros are more regularly distributed) but not via direct attack on ")#mi("H_0")#text(" itself!")#linebreak()#text(" Such “homotopic approach” to study ")#mi("H_0")#text(" via ")#mi("H_t")#text(" reminds similar methods used in the past to solve big problems (e.g. de Branges solution – via Loewner’s PDE with flow parameter – of the Bieberbach conjecture, and Perelman’s solution – via Hamilton’s Ricci flow PDE – of the Poincare conjecture).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491808")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("Is there a p-adic reformulation of this using local-global correspondence?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0083d5dc5d246c9e9a925ef09505431f325dc950462cb271db525b27b57a0281-f76e5de930f949c11475dc0173f47660ffcee65a7585e6f76d8fbc6347fbf77e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ?")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491775")[#strong[#text("?")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("Is this going to be hard analytic number theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A new polymath proposal (related to the Riemann Hypothesis) over Tao’s blog | The polymath blog")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491786")[#strong[#text("A new polymath proposal (related to the Riemann Hypothesis) over Tao’s blog | The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("[…] A new polymath proposal over Terry Tao’s blog who wrote: “Building on the interest expressed in the comments to this previous post, I am now formally proposing to initiate a “Polymath project” on the topic of obtaining new upper bounds on the de Bruijn-Newman constant . The purpose of this post is to describe the proposal and discuss the scope and parameters of the project.” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2018")])]

#text("There are some updates")

#text("There is a function implementing H_t for real z values (Ht_real_compute.py)")#linebreak()#text(" These are the first few approx zero locations obtained for different values of t")

#text("t, first few zeroes")#linebreak()#text(" 0 — 28.25, 42.05, 50.05, 60.85, 65.85, 75.15, 81.85, 86.65, 96.05, 99.55")#linebreak()#text(" 0.1 — 28.25, 41.95, 49.95, 60.75, 65.85, 75.05, 81.75, 86.65, 95.85, 99.55")#linebreak()#text(" 0.2 — 28.15, 41.85, 49.95, 60.65, 65.75, 75.05, 81.65, 86.55, 95.75, 99.45")#linebreak()#text(" 0.3 — 28.05, 41.85, 49.85, 60.55, 65.75, 74.95, 81.55, 86.55, 95.65, 99.45")#linebreak()#text(" 0.4 — 28.05, 41.75, 49.75, 60.45, 65.65, 74.85, 81.45, 86.45, 95.55, 99.35")#linebreak()#text(" 0.5 — 27.95, 41.65, 49.75, 60.35, 65.65, 74.85, 81.45, 86.45, 95.45, 99.35")

#text("I varied t and z by 0.1, too coarse-grained, but it was an initial run. There seem to be slight deformations as expected in the locations of zeroes as t varies.")

#text("Also I am now putting all the python codes in the python folder, and have created empty folders for julia and matlab, if you want to use other languages.")

#text("Will also look for real zeroes for negative t values, and then start thinking about searching for potential imaginary zeroes.")#linebreak()#text(" -KM")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("It would also be interesting to check numerically if the dependence of each zero on the parameter ")#mi("t")#text(" is (approximately) according to its ODE dynamics (which depends mainly on the attraction of its neighboring zeros).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491820")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("A simple and efficient method to compute the zeros ")#mi("z_j(t)")#text(" of ")#mi("H_t(z)")#text(" (for each given ")#mi("j <10^{13}")#text(") is to start with the known zeros ")#mi("z_j(0)")#text(" of ")#mi("H_0(z)")#text(" and for each such j-th zero to \"follow its trajectory\" by a discrete sequence ")#mi("t_k")#text(" of the parameter ")#mi("t")#text(", with increments sufficiently small to ensure local convergence to the zero ")#mi("z_j(t_k)")#text(" (starting with ")#mi("z_j(t_{k-1})")#text(" by a fast local zero-finding (e.g. Newton-Raphson) algorithm")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491825")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("I was thinking about using the regions around the H_0 zeroes, but this could be much faster. Interesting question would be whether I would miss any zeroes for H_t using this method, or does every H_t zero, at least the real ones, lies on a trajectory starting at a zeta zero. From the N_t(T) estimate where a tlogT factor gets added, and that as t increases, the height of the nth zero seems to decrease, it does seem plausible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("Since ")#mi("H_t(z)")#text(" is analytic in both ")#mi("t")#text(" and ")#mi("z")#text(", each simple (not necessarily real) zero of ")#mi("H_0")#text(" has a neighborhood for which there is only one zero ")#mi("z(t)")#text(" of ")#mi("H_t")#text(" which remains simple in this neighborhood for sufficiently small ")#tao-math("\\left|t\\right|", block: false)#text(". Moreover, this (local) “zero trajectory” ")#mi("z(t)")#text(" is analytic (except at the crossing points of trajectories of other zeros of ")#mi("H_0")#text(".)")#linebreak()#text(" So, if it is known that for some given ")#mi("T> 0")#text(" all zeros of ")#mi("H_0")#text(" with real part in ")#mi("(-T, T)")#text(" are real and simple, so are the zeros of ")#mi("H_t")#text(" for sufficiently small ")#tao-math("\\left|t\\right|", block: false)#text(". An interesting problem is to estimate this “sufficiently small” ")#mi("t")#text(" for such given (large) ")#mi("T")#text(" (e.g. for the first 10^{13} zeros of ")#mi("H_0")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491827")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("Thanks for this! The t=0 data seems to line up with (twice) the ordinates 14.13, 21.02, 25.01, 30.42, 32.93, 37.58, of the first few zeroes of zeta (see e.g. ")#link("http://mathworld.wolfram.com/RiemannZetaFunctionZeros.html")[#text("http://mathworld.wolfram.com/RiemannZetaFunctionZeros.html")]#text(" ), and there seems to be a slight drift towards the origin as t increases, which makes sense because the zeroes (which repel each other) get denser as one moves away from the origin. So everything seems to check out so far. The dynamics look a bit slower I expected; maybe more interesting things happen further out along the real axis, particularly when we start seeing zeroes that are initially close to each other (in particular, I am curious to see how the zeroes are supposed to align themselves towards an arithmetic progression locally, as is predicted by theory).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491831")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("Using a root finding algorithm, we can now get much better estimates of the zero locations for H_t (those which have a nearby H_0 zero counterpart)")

#text("for example for t=0.1 we get for the first 10 zeroes")#linebreak()#text(" t, n, nth zero")#linebreak()#text(" 0.1, 0, 28.2115092359")#linebreak()#text(" 0.1, 1, 41.9686550793")#linebreak()#text(" 0.1, 2, 49.9630971635")#linebreak()#text(" 0.1, 3, 60.7545079573")#linebreak()#text(" 0.1, 4, 65.8233207833")#linebreak()#text(" 0.1, 5, 75.0885948458")#linebreak()#text(" 0.1, 6, 81.751928485")#linebreak()#text(" 0.1, 7, 86.6088478461")#linebreak()#text(" 0.1, 8, 96.0103491423")#linebreak()#text(" 0.1, 9, 99.547664956")

#text("Also, for the first 5 zeroes, I used a t step size of 0.001 and got a pretty plot (the data used for the plot is also kept there)")

#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/python/H_t%20zero%20trajectory%20plot.png")[#image("../assets/b8e70690aac5fe03aadcb09ab737f5df83e5a29f25ace733f62a517302bb4baa-63e2fbeefdd381053479bb85be9acbdc8dd78bc02251654b161c1ff8782d1d01.png", width: 90%)]

#text("I think we are now close to analyzing zero spacings for H_t and comparing zero counts against N_t")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491833")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("Interestingly, in the plot, the slopes ")#mi("z^{\\prime}_j(t)")#text(" (in particular for larger ")#mi("t")#text(") are almost constant – indicating that the “acceleration” of the first zeros dynamics (due to relatively distant “neighboring zeros”) is quite small.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, first thread: computing $H_t$, asymptotics, and dynamics of zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491836")[#strong[#text("Polymath15, first thread: computing $H_t$, asymptotics, and dynamics of zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("[…] Bruijn-Newman constant . Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-491838")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("I have now created a “research thread” for this project (which is now christened Polymath15) over at ")#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/")[#text("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/")]#text(" to try to organise the mathematical discussion a bit better and to also record some predicted asymptotics for ")#mi("H_t")#text(" that one can get from Laplace’s method and contour shifting. This current post can be used for all the non-research discussion on the project, such as organisational issues or commentary on the project from external observers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, second thread: generalising the Riemann-Siegel approximate functional equation | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-492041")[#strong[#text("Polymath15, second thread: generalising the Riemann-Siegel approximate functional equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("[…] this previous thread. Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, third thread: computing and approximating H_t | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-492498")[#strong[#text("Polymath15, third thread: computing and approximating H_t | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("[…] this previous thread. Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-492592")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("I have seen a paper for the hot-spot conjecture on euclidean triangles (")#link("https://arxiv.org/abs/1802.01800")[#text("https://arxiv.org/abs/1802.01800")]#text("), which was the topic of polymath 7. Does this proof use insights from the polymath7 project (similar to your discrepancy proof and polymath5)? I wonder how many other polymath projects, which have not (yet) written up the results, have lead to interesting results that could actually be compiled into an article? I assume for future researchers, it is much easier to follow short final write-ups than the whole thought-process that is presented in the discussions of the projects? Is it worth and feasible to try compiling some of the results? Or at least, write a closing statements?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-492599")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("We discussed this a little for Polymath7, but as it turned out the partial results we had weren’t really compelling enough to write up. It seems that the new paper did not directly rely on the Polymath7 results, though there are of course some similarities in some of the tools used, which is not so surprising given that they were attacking exactly the same problem.")

#text("For more recent polymaths we have instituted an end date to the project, at which point it may well be reasonable to write up some partial results. Tim Gowers did write up something like this for Polymath5 (even though this project never formally came with an end date).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, fifth thread: finishing off the test problem? | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-493396")[#strong[#text("Polymath15, fifth thread: finishing off the test problem? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("[…] , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-493408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("So (non-research post) how is this project looking so far? Will finishing the “test problem” turn straightforwardly into a rigorous proof that Λ<0.48, and does that by itself seem like a candidate for an initial D.H.J. Polymath publication? What happens afterwards, i.e. is there more in sight than getting it to 0.47 or 0.46 through optimizing the technical machinery? Just wondering, thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-493409")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2018")])]

#text("this train isn’t slowing down until anonymous proves the rieman hypothesis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-493447")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("Solving the test problem will come close to proving ")#mi("\\Lambda \\leq 0.48")#text("; the test problem shows that ")#mi("H_t(x+iy) \\neq 0")#text(" whenever ")#mi("y =t = 0.4")#text(", and to prove ")#mi("\\Lambda \\geq 0.48")#text(" we need to strengthen this to showing that ")#mi("H_t(x+iy) \\neq 0")#text(" whenever ")#mi("t=0.4")#text(" and ")#mi("y \\geq 0.4")#text(" (another way to do it would be to show that ")#mi("H_t(x+iy) \\neq 0")#text(" for ")#mi("0 \\leq t \\leq 0.4")#text(", ")#mi("y =0.4")#text(", and ")#mi("x_0 \\leq x \\leq x_0+1")#text(" for some moderately large ")#mi("x_0")#text("). We haven’t discussed this much yet, but I am hoping that tools like the argument principle and Rouche’s theorem will let us do this, possibly by refining the numerical calculations of ")#mi("H_t(x+iy)")#text(" for small values of ")#mi("x")#text(" to be able to not just keep ")#mi("H_t(x+iy)")#text(" away from the origin, but also to compute how many times it winds around the origin.")

#text("That would be a major milestone for the project… where we go next I think depends on how easy it was to get the bound ")#mi("\\Lambda \\leq 0.48")#text(". If it was only barely within the capability of our method, and further significant progress would require making the argument much more complicated, there might be a case for declaring victory and perhaps handing the baton on to some future research group who might be better placed to come up with a different approach. But if there is significant “room” in the calculation then it would of course be natural to try to push further. One reason for doing this is that it may force us to find better methods, or we may happen upon some numerical phenomenon that is independently interesting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, sixth thread: the test problem and beyond | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-494015")[#strong[#text("Polymath15, sixth thread: the test problem and beyond | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("[…] , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, seventh thread: going below 0.48 | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-494909")[#strong[#text("Polymath15, seventh thread: going below 0.48 | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("[…] , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, eighth thread: going below 0.28 | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-496493")[#strong[#text("Polymath15, eighth thread: going below 0.28 | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("[…] , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, ninth thread: going below 0.22? | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-497738")[#strong[#text("Polymath15, ninth thread: going below 0.22? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("[…] , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, tenth thread: numerics update | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-504628")[#strong[#text("Polymath15, tenth thread: numerics update | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2018")])]

#text("[…] continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath 15, eleventh thread: Writing up the results, and exploring negative t | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-509622")[#strong[#text("Polymath 15, eleventh thread: Writing up the results, and exploring negative t | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("[…] continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal thread. Progress will be summarised at this Polymath wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-513265")[#strong[#text("Dan Romik Studies the Riemann’s Zeta Function, and Other Zeta News. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2019")]

#text("[…] task of polymath15 (proposed here, launched here, last (11th) post here) was to use current analytic number theory technology that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/#comment-657482")[#strong[#text("nt.number theory - Fractional partial derivatives and integrals of De Bruijn's $H_t(z)$-function. Does a simpler form exist for the $z$ derivative/integral? Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2022")]

#text("[…] 2018/2019, the polymath 15 project managed to successfully reduce the upper bound of the De Bruijn-Newman constant and the work […]")
]
