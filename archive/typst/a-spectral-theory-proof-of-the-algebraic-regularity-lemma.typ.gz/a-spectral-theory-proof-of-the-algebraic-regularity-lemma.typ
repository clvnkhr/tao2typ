// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/10/29/a-spectral-theory-proof-of-the-algebraic-regularity-lemma/
// Converted to Typst by tao2typ: "2026-10-14T09:34:13.937291+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A spectral theory proof of the algebraic regularity lemma", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A spectral theory proof of the algebraic regularity lemma")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 October 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/10/29/a-spectral-theory-proof-of-the-algebraic-regularity-lemma/")[#text("https://terrytao.wordpress.com/2013/10/29/a-spectral-theory-proof-of-the-algebraic-regularity-lemma/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{F}")#text(" be a field. A ")#link("http://en.wikipedia.org/wiki/Definable_set")[#text("definable set")]#text(" over ")#mi("{F}")#text(" is a set of the form ")#metadata(none) <tao-f93704013c8bd2583a52>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\{ x \\in F^n | \\phi(x) \\text{ is true} \\}")]]

#text("where ")#mi("{n}")#text(" is a natural number, and ")#mi("{\\phi(x)}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Predicate_(mathematical_logic)")[#text("predicate")]#text(" involving the ring operations ")#mi("{+,\\times}")#text(" of ")#mi("{F}")#text(", the equality symbol ")#mi("{=}")#text(", an arbitrary number of constants and free variables in ")#mi("{F}")#text(", the quantifiers ")#mi("{\\forall, \\exists}")#text(", boolean operators such as ")#mi("{\\vee,\\wedge,\\neg}")#text(", and parentheses and colons, where the quantifiers are always understood to be over the field ")#mi("{F}")#text(". Thus, for instance, the set of quadratic residues")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in F | \\exists y: x = y \\times y \\}")]]

#text("is definable over ")#mi("{F}")#text(", and any algebraic variety over ")#mi("{F}")#text(" is also a definable set over ")#mi("{F}")#text(". Henceforth we will abbreviate “definable over ")#mi("{F}")#text("” simply as “definable”.")

#text("If ")#mi("{F}")#text(" is a finite field, then every subset of ")#mi("{F^n}")#text(" is definable, since finite sets are automatically definable. However, we can obtain a more interesting notion in this case by restricting the ")#emph[#text("complexity")]#text(" of a definable set. We say that ")#mi("{E \\subset F^n}")#text(" is a ")#emph[#text("definable set of complexity at most ")#mi("{M}")]#text(" if ")#mi("{n \\leq M}")#text(", and ")#mi("{E}")#text(" can be written in the form ")#link(<tao-f93704013c8bd2583a52>)[#text("(1)")]#text(" for some predicate ")#mi("{\\phi}")#text(" of length at most ")#mi("{M}")#text(" (where all operators, quantifiers, relations, variables, constants, and punctuation symbols are considered to have unit length). Thus, for instance, a hypersurface in ")#mi("{n}")#text(" dimensions of degree ")#mi("{d}")#text(" would be a definable set of complexity ")#mi("{O_{n,d}(1)}")#text(". We will then be interested in the regime where the complexity remains bounded, but the field size (or field characteristic) becomes large.")

#text("In ")#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/")[#text("a recent paper")]#text(", I established (in the large characteristic case) the following regularity lemma for dense definable graphs, which significantly strengthens the Szemerédi regularity lemma in this context, by eliminating “bad” pairs, giving a polynomially strong regularity, and also giving definability of the cells:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Algebraic regularity lemma)")]#text(" ")#metadata(none) <tao-63518250301558366648>#text(" Let ")#mi("{F}")#text(" be a finite field, let ")#mi("{V,W}")#text(" be definable non-empty sets of complexity at most ")#mi("{M}")#text(", and let ")#mi("{E \\subset V \\times W}")#text(" also be definable with complexity at most ")#mi("{M}")#text(". Assume that the characteristic of ")#mi("{F}")#text(" is sufficiently large depending on ")#mi("{M}")#text(". Then we may partition ")#mi("{V = V_1 \\cup \\ldots \\cup V_m}")#text(" and ")#mi("{W = W_1 \\cup \\ldots \\cup W_n}")#text(" with ")#mi("{m,n = O_M(1)}")#text(", with the following properties:")

#list(
[#text("(Definability) Each of the ")#mi("{V_1,\\ldots,V_m,W_1,\\ldots,W_n}")#text(" are definable of complexity ")#mi("{O_M(1)}")#text(".")],
[#text("(Size) We have ")#tao-math("{\\left|V_i\\right| \\gg_M \\left|V\\right|}", block: false)#text(" and ")#tao-math("{\\left|W_j\\right| \\gg_M \\left|W\\right|}", block: false)#text(" for all ")#mi("{i=1,\\ldots,m}")#text(" and ")#mi("{j=1,\\ldots,n}")#text(".")],
[#text("(Regularity) We have")

#metadata(none) <tao-5744323314533d2583cc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|E \\cap (A \\times B)\\right| = d_{ij} \\left|A\\right| \\left|B\\right| + O_M( \\left|F\\right|^{-1/4} \\left|V\\right| \\left|W\\right| )", block: true)]]

#text("for all ")#mi("{i=1,\\ldots,m}")#text(", ")#mi("{j=1,\\ldots,n}")#text(", ")#mi("{A \\subset V_i}")#text(", and ")#mi("{B\\subset W_j}")#text(", where ")#mi("{d_{ij}}")#text(" is a rational number in ")#mi("{[0,1]}")#text(" with numerator and denominator ")#mi("{O_M(1)}")#text(".")]
)
]

#text("My original proof of this lemma was quite complicated, based on an explicit calculation of the “square”")

#align(center)[#tao-fit-display[#mitex("\\mu(w,w^{\\prime}) := \\{ v \\in V: (v,w), (v,w^{\\prime}) \\in E \\}")]]

#text("of ")#mi("{E}")#text(" using ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("the Lang-Weil bound")]#text(" and some facts about ")#link("http://en.wikipedia.org/wiki/%C3%89tale_fundamental_group")[#text("the étale fundamental group")]#text(". It was the reliance on the latter which was the main reason why the result was restricted to the large characteristic setting. (I then applied this lemma to classify expanding polynomials over finite fields of large characteristic, but I will not discuss these applications here; see ")#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/")[#text("this previous blog post")]#text(" for more discussion.)")

#text("Recently, Anand Pillay and Sergei Starchenko (and independently, Udi Hrushovski) ")#link("http://arxiv.org/abs/1310.7538")[#text("have observed")]#text(" that the theory of the étale fundamental group is not necessary in the argument, and the lemma can in fact be deduced from quite general model theoretic techniques, in particular using (a local version of) the concept of ")#link("http://en.wikipedia.org/wiki/Stable_theory")[#text("stability")]#text(". One of the consequences of this new proof of the lemma is that the hypothesis of large characteristic can be omitted; the lemma is now known to be valid for arbitrary finite fields ")#mi("{F}")#text(" (although its content is trivial if the field is not sufficiently large depending on the complexity at most ")#mi("{M}")#text(").")

#text("Inspired by this, I decided to see if I could find yet another proof of the algebraic regularity lemma, again avoiding the theory of the étale fundamental group. It turns out that the spectral proof of the Szemerédi regularity lemma (discussed in ")#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/")[#text("this previous blog post")]#text(") adapts very nicely to this setting. The key fact needed about definable sets over finite fields is that their cardinality takes on an essentially discrete set of values. More precisely, we have the following fundamental result of ")#link("http://www.ams.org/mathscinet-getitem?mr=590820")[#text("Chatzidakis, van den Dries, and Macintyre")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" ")#metadata(none) <tao-55085deadcfa54f32414>#text(" Let ")#mi("{F}")#text(" be a finite field, and let ")#mi("{M > 0}")#text(".")

#list(
[#text("(Discretised cardinality) If ")#mi("{E}")#text(" is a non-empty definable set of complexity at most ")#mi("{M}")#text(", then one has")

#metadata(none) <tao-d06187170d72b3da9535>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|E\\right| = c \\left|F\\right|^d + O_M( \\left|F\\right|^{d-1/2} )", block: true)]]

#text("where ")#mi("{d = O_M(1)}")#text(" is a natural number, and ")#mi("{c}")#text(" is a positive rational number with numerator and denominator ")#mi("{O_M(1)}")#text(". In particular, we have ")#tao-math("{\\left|F\\right|^d \\ll_M \\left|E\\right| \\ll_M \\left|F\\right|^d}", block: false)#text(".")],
[#text("(Definable cardinality) Assume ")#tao-math("{\\left|F\\right|}", block: false)#text(" is sufficiently large depending on ")#mi("{M}")#text(". If ")#mi("{V, W}")#text(", and ")#mi("{E \\subset V \\times W}")#text(" are definable sets of complexity at most ")#mi("{M}")#text(", so that ")#mi("{E_w := \\{ v \\in V: (v,w) \\in W \\}}")#text(" can be viewed as a definable subset of ")#mi("{V}")#text(" that is definably parameterised by ")#mi("{w \\in W}")#text(", then for each natural number ")#mi("{d = O_M(1)}")#text(" and each positive rational ")#mi("{c}")#text(" with numerator and denominator ")#mi("{O_M(1)}")#text(", the set")

#metadata(none) <tao-e7bbf0eda002c1ba04bf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\{ w \\in W: \\left|E_w\\right| = c \\left|F\\right|^d + O_M( \\left|F\\right|^{d-1/2} ) \\}", block: true)]]

#text("is definable with complexity ")#mi("{O_M(1)}")#text(", where the implied constants in the asymptotic notation used to define ")#link(<tao-e7bbf0eda002c1ba04bf>)[#text("(4)")]#text(" are the same as those that appearing in ")#link(<tao-d06187170d72b3da9535>)[#text("(3)")]#text(". (Informally: the “dimension” ")#mi("{d}")#text(" and “measure” ")#mi("{c}")#text(" of ")#mi("{E_w}")#text(" depends definably on ")#mi("{w}")#text(".)")]
)
]

#text("We will take this proposition as a black box; a proof can be obtained by combining the description of definable sets over pseudofinite fields (discussed in ")#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/")[#text("this previous post")]#text(") with the Lang-Weil bound (discussed in ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("this previous post")]#text("). (The former fact is phrased using nonstandard analysis, but one can use standard compactness-and-contradiction arguments to convert such statements to statements in standard analysis, as discussed in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this post")]#text(".)")

#text("The above proposition places severe restrictions on the cardinality of definable sets; for instance, it shows that one cannot have a definable set of complexity at most ")#mi("{M}")#text(" and cardinality ")#tao-math("{\\left|F\\right|^{1/2}}", block: false)#text(", if ")#tao-math("{\\left|F\\right|}", block: false)#text(" is sufficiently large depending on ")#mi("{M}")#text(". If ")#mi("{E \\subset V}")#text(" are definable sets of complexity at most ")#mi("{M}")#text(", it shows that ")#tao-math("{\\left|E\\right| = (c+ O_M(\\left|F\\right|^{-1/2})) \\left|V\\right|}", block: false)#text(" for some rational ")#mi("{0\\leq c \\leq 1}")#text(" with numerator and denominator ")#mi("{O_M(1)}")#text("; furthermore, if ")#mi("{c=0}")#text(", we may improve this bound to ")#tao-math("{\\left|E\\right| = O_M( \\left|F\\right|^{-1} \\left|V\\right|)}", block: false)#text(". In particular, we obtain the following “self-improving” properties:")

#list(
[#text("If ")#mi("{E \\subset V}")#text(" are definable of complexity at most ")#mi("{M}")#text(" and ")#tao-math("{\\left|E\\right| \\leq \\epsilon \\left|V\\right|}", block: false)#text(" for some ")#mi("{\\epsilon>0}")#text(", then (if ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{M}")#text(" and ")#mi("{F}")#text(" is sufficiently large depending on ")#mi("{M}")#text(") this forces ")#tao-math("{\\left|E\\right| = O_M( \\left|F\\right|^{-1} \\left|V\\right| )}", block: false)#text(".")],
[#text("If ")#mi("{E \\subset V}")#text(" are definable of complexity at most ")#mi("{M}")#text(" and ")#tao-math("{\\left|\\left|E\\right| - c \\right|V\\left|\\left| \\leq \\epsilon \\right|V\\right|}", block: false)#text(" for some ")#mi("{\\epsilon>0}")#text(" and positive rational ")#mi("{c}")#text(", then (if ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{M,c}")#text(" and ")#mi("{F}")#text(" is sufficiently large depending on ")#mi("{M,c}")#text(") this forces ")#tao-math("{\\left|E\\right| = c \\left|V\\right| + O_M( \\left|F\\right|^{-1/2} \\left|V\\right| )}", block: false)#text(".")]
)

#text("It turns out that these self-improving properties can be applied to the coefficients of various matrices (basically powers of the adjacency matrix associated to ")#mi("{E}")#text(") that arise in the spectral proof of the regularity lemma to significantly improve the bounds in that lemma; we describe how this is done below the fold. We also make some connections to the stability-based proofs of Pillay-Starchenko and Hrushovski.")

#metadata(none) <tao-cd97ea799534d49ca626>

#heading(level: 1)[#strong[#text(" — 1. The regularity lemma — ")]]

#text("We begin with proving a slightly weaker version of the lemma, in which the bound ")#tao-math("{O_M(\\left|F\\right|^{-1/4})}", block: false)#text(" is weakened to ")#tao-math("{O_M(\\left|F\\right|^{-1/12})}", block: false)#text("; we will later use the self-improving properties mentioned previously to upgrade this bound. In other words, we begin by showing")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Algebraic regularity lemma, weak version)")]#text(" ")#metadata(none) <tao-70e929e9447e4048c35a>#text(" Let ")#mi("{F}")#text(" be a finite field, let ")#mi("{V,W}")#text(" be definable non-empty sets of complexity at most ")#mi("{M}")#text(", and let ")#mi("{E \\subset V \\times W}")#text(" also be definable with complexity at most ")#mi("{M}")#text(". Then we may partition ")#mi("{V = V_1 \\cup \\ldots V_m}")#text(" and ")#mi("{W = W_1 \\cup \\ldots \\cup W_n}")#text(" with ")#mi("{m,n = O_M(1)}")#text(", with the following properties:")

#list(
[#text("(Definability) Each of the ")#mi("{V_1,\\ldots,V_m,W_1,\\ldots,W_n}")#text(" are definable of complexity ")#mi("{O_M(1)}")#text(".")],
[#text("(Size) We have ")#tao-math("{\\left|V_i\\right| \\gg_M \\left|V\\right|}", block: false)#text(" and ")#tao-math("{\\left|W_j\\right| \\gg_M \\left|W\\right|}", block: false)#text(" for all ")#mi("{i=1,\\ldots,m}")#text(" and ")#mi("{j=1,\\ldots,n}")#text(".")],
[#text("(Regularity) We have")

#align(center)[#tao-fit-display[#tao-math("\\left|E \\cap (A \\times B)\\right| = d_{ij} \\left|A\\right| \\left|B\\right| + O_M( \\left|F\\right|^{-1/12} \\left|V\\right| \\left|W\\right| )", block: true)]]

#text("for all ")#mi("{i=1,\\ldots,m}")#text(", ")#mi("{j=1,\\ldots,n}")#text(", ")#mi("{A \\subset V_i}")#text(", and ")#mi("{B\\subset W_j}")#text(", where ")#mi("{d_{ij}}")#text(" is a rational number in ")#mi("{[0,1]}")#text(" with numerator and denominator ")#mi("{O_M(1)}")#text(".")]
)
]

#text("We now prove this lemma, by combining spectral theory with an (iterated) ")#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/")[#mi("{TT^*}")#text(" method")]#text(". We may assume that ")#tao-math("{\\left|F\\right|}", block: false)#text(" is sufficiently large depending on ")#mi("{M}")#text(", as the claim is trivial otherwise (just take ")#mi("{m=n=1}")#text("). We consider the probability spaces ")#mi("{(V,m_V)}")#text(", ")#mi("{(W, m_W)}")#text(" with the uniform probability measures ")#mi("{m_V, m_W}")#text(" on ")#mi("{V,W}")#text("; we abbreviate ")#mi("{L^p(V,m_V)}")#text(" as ")#mi("{L^p(V)}")#text(" for ")#mi("{1 \\leq p \\leq \\infty}")#text(", and similarly define ")#mi("{L^p(W)}")#text(" (we work exclusively with real-valued functions here). The set ")#mi("{E}")#text(" then defines a linear operator ")#mi("{T: L^2(V) \\rightarrow L^2(W)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("T f(w) := \\int_V 1_E(v,w) f(v)\\ dm_V(v);")]]

#text("thus ")#mi("{T}")#text(" is the operator with integral kernel ")#mi("{1_E}")#text(". We can then compute the adjoint operator ")#mi("{T^*: L^2(W) \\rightarrow L^2(V)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("T^* g(v) = \\int_W 1_E(v,w) g(w)\\ dm_W(w).")]]

#text("From the Cauchy-Schwarz inequality we observe the bounds ")#metadata(none) <tao-c7728651988581c9b388>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|Tf \\right\\|_{L^2(W)} \\leq \\left\\|Tf\\right\\|_{L^\\infty(W)} \\leq \\left\\|f\\right\\|_{L^2(V)}", block: true)]]

#text("for all ")#mi("{f \\in L^2(V)}")#text(", and similarly ")#metadata(none) <tao-f1378c1b1f4599809462>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\|T^*g \\right\\|_{L^2(V)} \\leq \\left\\|T^* g\\right\\|_{L^\\infty(V)} \\leq \\left\\|g\\right\\|_{L^2(W)}", block: true)]]

#text("for all ")#mi("{g \\in L^2(W)}")#text(".")

#text("Now we apply the ")#link("http://en.wikipedia.org/wiki/Singular_value_decomposition")[#text("singular value decomposition")]#text(" (which is easily justified as ")#mi("{L^2(V)}")#text(", ")#mi("{L^2(W)}")#text(" are finite dimensional) to write")

#align(center)[#tao-fit-display[#mitex("T f = \\sum_i \\sigma_i \\langle f, u_i \\rangle_{L^2(V)} y_i")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("T^* g = \\sum_i \\sigma_i\\langle g, y_i \\rangle_{L^2(W)} u_i")]]

#text("for some finite sequence ")#mi("{\\sigma_1 \\geq \\sigma_2 \\geq \\ldots > 0}")#text(" of singular values, the ")#mi("{u_i}")#text(" are an orthonormal system in ")#mi("{L^2(V)}")#text(", and the ")#mi("{y_i}")#text(" are an orthonormal system in ")#mi("{L^2(W)}")#text(". Observe that operator ")#mi("{TT^*: L^2(W) \\rightarrow L^2(W)}")#text(" can be diagonalised as")

#align(center)[#tao-fit-display[#mitex("TT^* g = \\sum_i \\sigma_i^2 \\langle g,y_i \\rangle_{L^2(W)} y_i")]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|W\\right|} \\text{tr}(TT^*) = \\sum_i \\sigma_i^2.", block: true)]]

#text("On the other hand, direct calculation shows that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|W\\right|} \\text{tr}(TT^*) = \\frac{\\left|E\\right|}{\\left|V\\right|\\left|W\\right|} \\leq 1", block: true)]]

#text("and so we have the ")#link("http://en.wikipedia.org/wiki/Frobenius_norm#Frobenius_norm")[#text("Frobenius norm")]#text(" (or Hilbert-Schmidt norm) bound ")#metadata(none) <tao-26b7c362884170e0ba38>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_i \\sigma_i^2 \\leq 1.")]]

#text("Next, from the identities")

#align(center)[#tao-fit-display[#mitex("y_i = \\frac{1}{\\sigma_i} T u_i; \\quad u_i = \\frac{1}{\\sigma_i} T^* y_i")]]

#text("and ")#link(<tao-c7728651988581c9b388>)[#text("(5)")]#text(", ")#link(<tao-f1378c1b1f4599809462>)[#text("(6)")]#text(" we obtain sup-norm bounds on the eigenfunctions: ")#metadata(none) <tao-bedf213853ae9afd32a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| y_i \\right\\|_{L^\\infty(W)}, \\left\\|u_i\\right\\|_{L^\\infty(V)} \\leq \\frac{1}{\\sigma_i}.", block: true)]]

#text("We now use these bounds to obtain a low rank approximation to the sixth power ")#mi("{TT^* TT^* TT^*: L^2(W) \\rightarrow L^2(W)}")#text(". This operator may be diagonalised as ")#metadata(none) <tao-5dab1b2a4c76062128b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("TT^* TT^* TT^* g = \\sum_i \\sigma_i^6 \\langle g,y_i \\rangle_{L^2(W)} y_i.")]]

#text("We let ")#mi("{\\epsilon>0}")#text(" be a small quantity (depending only on ")#mi("{M}")#text(") to be chosen later, and split")

#align(center)[#tao-fit-display[#mitex("TT^* TT^* TT^* = A + B")]]

#text("where ")#mi("{A}")#text(" is a low rank operator")

#align(center)[#tao-fit-display[#mitex("Ag := \\sum_{i: \\sigma_i \\geq \\epsilon} \\sigma_i^6 \\langle g,y_i \\rangle_{L^2(W)} y_i")]]

#text("and ")#mi("{B}")#text(" is the error term")

#align(center)[#tao-fit-display[#mitex("Bg := \\sum_{i: \\sigma_i < \\epsilon} \\sigma_i^6 \\langle g,y_i \\rangle_{L^2(W)} y_i.")]]

#text("Observe from the triangle inequality, Hölder’s inequality and ")#link(<tao-bedf213853ae9afd32a6>)[#text("(8)")]#text(", ")#link(<tao-26b7c362884170e0ba38>)[#text("(7)")]#text(" that")

#tao-aligned(keep: true)[


#tao-math("\\left\\|Bg \\right\\|_{L^\\infty(W)}  & \\leq \\sum_{i: \\sigma_i < \\epsilon} \\sigma_i^6 |\\langle g,y_i \\rangle_{L^2(W)}| \\frac{1}{\\sigma_i}", block: true)



#tao-math(" & \\leq \\sum_{i: \\sigma_i < \\epsilon} \\sigma_i^6 \\frac{1}{\\sigma_i} \\left\\|g\\right\\|_{L^1(W)} \\frac{1}{\\sigma_i}", block: true)



#tao-math(" & \\leq \\epsilon^2 \\sum_i \\sigma_i^2 \\left\\|g\\right\\|_{L^1(W)}", block: true)



#tao-math(" & \\leq \\epsilon^2 \\left\\|g\\right\\|_{L^1(W)}", block: true)
]

#text("for any ")#mi("{g \\in L^1(W)}")#text(". In other words, the integral kernel of ")#mi("{B}")#text(" is bounded pointwise by ")#mi("{\\epsilon^2}")#text(". As for ")#mi("{A}")#text(", we use ")#link(<tao-bedf213853ae9afd32a6>)[#text("(8)")]#text(" to discretise ")#mi("{y_i = y^{\\prime}_i + e_i}")#text(", where ")#mi("{y^{\\prime}_i}")#text(" takes on at most ")#mi("{\\epsilon^{-100}}")#text(" values (say), and ")#mi("{e_i}")#text(" is bounded in magnitude by ")#mi("{O(\\epsilon^{99})}")#text(". We can then split ")#mi("{A = A^{\\prime} + E}")#text(", where")

#align(center)[#tao-fit-display[#mitex("A^{\\prime} g := \\sum_{i: \\sigma_i \\geq \\epsilon} \\sigma_i^6 \\langle g,y^{\\prime}_i \\rangle_{L^2(W)} y^{\\prime}_i")]]

#text("and the error term ")#mi("{E}")#text(" can easily be shown (by arguments similar to before) to have a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\|E g \\right\\|_{L^\\infty(W)} \\ll \\epsilon^2 \\left\\|g\\right\\|_{L^1(W)}", block: true)]]

#text("(with many powers of ")#mi("{\\epsilon}")#text(" to spare). We have thus written ")#mi("{TT^*TT^*TT^* = A^{\\prime} + E^{\\prime}}")#text(", where ")#mi("{E^{\\prime}}")#text(" has integral kernel bounded pointwise by ")#mi("{O(\\epsilon^2)}")#text(".")

#text("Now from ")#link(<tao-26b7c362884170e0ba38>)[#text("(7)")]#text(", the number of summands ")#mi("{i}")#text(" in the definition of ")#mi("{A}")#text(" is at most ")#mi("{1/\\epsilon^2}")#text(". If we then partition ")#mi("{W = W_1 \\cup \\ldots \\cup W_n}")#text(" using the level sets of the corresponding ")#mi("{y^{\\prime}_i}")#text(" (removing any empty cells to ensure the ")#mi("{W_i}")#text(" are non-empty), then we have")

#align(center)[#tao-fit-display[#mitex("n \\leq (\\epsilon^{-100})^{1/\\epsilon^2},")]]

#text("and the integral kernel of ")#mi("{A^{\\prime}}")#text(" is constant on each ")#mi("{W_i \\times W_j}")#text(". Thus, the integral kernel of ")#mi("{TT^*TT^*TT^*}")#text(" fluctuates by at most ")#mi("{O(\\epsilon^2)}")#text(" on each ")#mi("{W_i \\times W_j}")#text(".")

#text("Thus far, we have not used the definability of ")#mi("{E}")#text(". Now we will do so in order to take advantage of self-improving properties. The integral kernel ")#mi("{K_3(w, w^{\\prime})}")#text(" of ")#mi("{TT^*TT^*TT^*}")#text(" can be evaluated explicitly as")

#align(center)[#tao-fit-display[#tao-math("K_3(w,w^{\\prime}) = \\frac{\\left|G_{w,w^{\\prime}}\\right|}{\\left|V\\right|^3 \\left|W\\right|^2}", block: true)]]

#text("where ")#mi("{G_{w,w^{\\prime}} \\subset V \\times W \\times V \\times W \\times V}")#text(" is the set")

#tao-aligned(keep: true)[


#tao-math("G_{w,w^{\\prime}}  & :=\\{ (v_1, w_2, v_2, w_3, v_3) \\in V \\times W \\times V \\times W \\times V:", block: true)



#tao-math("(v_1,w), (v_1,w_2), (v_2,w_2), (v_2,w_3), (v_3,w_3), (v_3,w^{\\prime})  & \\in E \\}.", block: true)
]

#text("Clearly, ")#mi("{G_{w,w^{\\prime}}}")#text(" is a definable set of complexity ")#mi("{O_M(1)}")#text(". From Proposition ")#link(<tao-55085deadcfa54f32414>)[#text("2")]#text(" we thus have the discretisation bounds")

#align(center)[#tao-fit-display[#tao-math("K_3(w,w^{\\prime}) = c_{w,w^{\\prime}} + O_M( \\left|F\\right|^{-1/2} )", block: true)]]

#text("where ")#mi("{c_{w,w^{\\prime}}}")#text(" is a non-negative rational number with numerator and denominator ")#mi("{O_M(1)}")#text(". The set of such rationals is finite (basically a portion of the ")#link("http://en.wikipedia.org/wiki/Farey_sequence")[#text("Farey sequence")]#text("), and thus are separated from each other by some separation ")#mi("{\\gg_M 1}")#text(". If we combine this fact with the local near-constancy of ")#mi("{K_A}")#text(" on ")#mi("{W_i \\times W_j}")#text(", we can thus (if ")#mi("{\\epsilon}")#text(" is small enough) self-improve this near-constancy to the bound ")#metadata(none) <tao-7b662473dbc50ac87677>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("K_3(w,w^{\\prime}) = c_{i,j} + O_M( \\left|F\\right|^{-1/2} )", block: true)]]

#text("for all ")#mi("{1 \\leq i,j \\leq n}")#text(", all ")#mi("{w \\in W_i}")#text(", ")#mi("{w^{\\prime} \\in W_j}")#text(", and some non-negative rational ")#mi("{c_{i,j}}")#text(" depending only on ")#mi("{i,j}")#text(" with numerator and denominator ")#mi("{O_M(1)}")#text(".")

#text("Note that as ")#mi("{K_3}")#text(" is symmetric, ")#mi("{c_{i,j}}")#text(" will be symmetric too. If two ")#mi("{i,i^{\\prime} \\in \\{1,\\ldots,n\\}}")#text(" are indistinguishable in the sense that ")#mi("{c_{i,j} = c_{i^{\\prime},j}}")#text(" for all ")#mi("{1 \\leq j \\leq n}")#text(", then we may concatenate ")#mi("{W_i}")#text(" and ")#mi("{W_{i^{\\prime}}}")#text(" (reducing ")#mi("{n}")#text(" by one), so we may assume that elements of ")#mi("{\\{1,\\ldots,n\\}}")#text(" are pairwise distinguishable. From Proposition ")#link(<tao-55085deadcfa54f32414>)[#text("2")]#text(" we see that for each ")#mi("{1 \\leq j \\leq n}")#text(" and rational ")#mi("{c}")#text(", the set ")#mi("{\\bigcup_{i: c_{i,j} = c} W_i}")#text(" is definable with complexity ")#mi("{O_M(1)}")#text(". Taking boolean combinations and using distinguishability, we conclude that each ")#mi("{W_i}")#text(" is also definable with complexity ")#mi("{O_M(1)}")#text(". In particular, we either have ")#tao-math("{\\left|W_i\\right| \\gg_M \\left|W\\right|}", block: false)#text(" or ")#tao-math("{\\left|W_i\\right| \\ll_M \\left|F\\right|^{-1} \\left|W\\right|}", block: false)#text(".")

#text("Now let ")#mi("{g \\in L^2(W)}")#text(" be supported on ")#mi("{W_j}")#text(" with mean zero for some ")#mi("{1 \\leq j \\leq m}")#text(". From ")#link(<tao-7b662473dbc50ac87677>)[#text("(10)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle TT^* TT^* TT^* g, g \\rangle_{L^2(W)}\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= \\left|\\int_W \\int_W K_3(w,w^{\\prime}) g(w) g(w^{\\prime})\\ dm_W(w) dm_W(w^{\\prime})\\right| \\ll_M \\left|F\\right|^{-1/2}\\left\\|g\\right\\|_{L^2(W)}^2.", block: true)]]

#text("On the other hand, from ")#link(<tao-5dab1b2a4c76062128b3>)[#text("(9)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle TT^* TT^* TT^* g, g \\rangle_{L^2(W)}\\right| = \\sum_i \\sigma_i^6 \\left|\\langle g, y_i \\rangle_{L^2(W)}\\right|^2", block: true)]]

#text("while from Bessel’s inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_i \\left|\\langle g, y_i \\rangle_{L^2(W)}\\right|^2 \\leq \\left\\|g\\right\\|_{L^2(W)}^2", block: true)]]

#text("and thus by Hölder’s inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_i \\sigma_i^2 \\left|\\langle g, y_i \\rangle_{L^2(W)}\\right|^2 \\ll_M \\left|F\\right|^{-1/6} \\left\\|g\\right\\|_{L^2(W)}^2.", block: true)]]

#text("The left-hand side is just ")#tao-math("{\\left\\|T^* g\\right\\|_{L^2(V)}^2}", block: false)#text(", so we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T^* g \\right\\|_{L^2(V)} \\ll_M \\left|F\\right|^{-1/12} \\left\\|g\\right\\|_{L^2(W)}", block: true)]]

#text("whenever ")#mi("{g}")#text(" is supported on one of the ")#mi("{W_j}")#text(" with mean zero.")

#text("In a similar vein, we may find a partition ")#mi("{V = V_1 \\cup \\ldots \\cup V_m}")#text(" into definable sets of complexity ")#mi("{O_M(1)}")#text(" with")

#align(center)[#tao-fit-display[#mitex("m \\leq (\\epsilon^{-100})^{1/\\epsilon^2},")]]

#text("with the property that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T f \\right\\|_{L^2(W)} \\ll_M \\left|F\\right|^{-1/12} \\left\\|f\\right\\|_{L^2(V)}", block: true)]]

#text("whenever ")#mi("{f}")#text(" is supported on one of the ")#mi("{V_i}")#text(" with mean zero.")

#text("Let ")#mi("{1 \\leq i \\leq n}")#text(" and ")#mi("{1 \\leq j \\leq m}")#text(" with ")#tao-math("{\\left|V_i\\right| \\gg_M \\left|V\\right|}", block: false)#text(" and ")#tao-math("{\\left|W_j\\right| \\gg_M \\left|W\\right|}", block: false)#text(". From the above estimates and Cauchy-Schwarz, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle Tf, g \\rangle_{L^2(W)}\\right| \\ll_M \\left|F\\right|^{-1/12} \\left\\|f\\right\\|_{L^2(V)} \\left\\|g\\right\\|_{L^2(W)}", block: true)]]

#text("whenever ")#mi("{f, g}")#text(" are supported on ")#mi("{V_i, W_j}")#text(" respectively, with at least one of ")#mi("{f,g}")#text(" having mean zero. If ")#mi("{A \\subset V_i}")#text(", ")#mi("{B \\subset W_j}")#text(", then by decomposing ")#tao-math("{1_A = (1_A - \\frac{\\left|A\\right|}{\\left|V_i\\right|} 1_{V_i}) + \\frac{\\left|A\\right|}{\\left|V_i\\right|} 1_{V_i}}", block: false)#text(" and ")#tao-math("{1_B = (1_B - \\frac{\\left|B\\right|}{\\left|W_j\\right|} 1_{W_j}) + \\frac{\\left|B\\right|}{\\left|W_j\\right|} 1_{W_j}}", block: false)#text(" into mean-zero and constant components on ")#mi("{V_i,W_j}")#text(" respectively, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\langle T 1_A, 1_B \\rangle_{L^2(W)} = \\frac{\\left|A\\right|}{\\left|V_i\\right|} \\frac{\\left|B\\right|}{\\left|W_j\\right|} \\langle T 1_{V_i}, 1_{W_j} \\rangle_{L^2(W)} + O_M( \\left|F\\right|^{-1/12} ).", block: true)]]

#text("On the other hand, we have")

#align(center)[#tao-fit-display[#tao-math("\\langle T 1_{V_i}, 1_{W_j} \\rangle_{L^2(W)} = \\frac{\\left|E \\cap (V_i \\times W_j)\\right|}{\\left|V\\right| \\left|W\\right|}", block: true)]]

#text("so by Proposition ")#link(<tao-55085deadcfa54f32414>)[#text("2")]#text(", ")#tao-math("{\\langle T 1_{V_i}, 1_{W_j} \\rangle_{L^2(W)} = c_{ij} + O_M(\\left|F\\right|^{-1/2})}", block: false)#text(" for some rational ")#mi("{c_{ij}}")#text(" with numerator and denominator ")#mi("{O_M(1)}")#text(". Also ")#tao-math("{\\left|V_i\\right|/\\left|V\\right| = a_i + O_M(\\left|F\\right|^{-1/2})}", block: false)#text(" and ")#tao-math("{\\left|W_j\\right|/\\left|W\\right| = b_j + O_M(\\left|F\\right|^{-1/2})}", block: false)#text(" for some further rational ")#mi("{a_i,b_j}")#text(" with numerator and denominator ")#mi("{O_M(1)}")#text(". This proves Lemma ")#link(<tao-70e929e9447e4048c35a>)[#text("3")]#text(", except that we have some “small” ")#mi("{V_i}")#text(" and ")#mi("{W_j}")#text(" with ")#tao-math("{\\left|V_i\\right| \\ll_M \\left|F\\right|^{-1} \\left|V\\right|}", block: false)#text(" and ")#tao-math("{\\left|W_j\\right| \\ll_M \\left|F\\right|^{-1} \\left|W\\right|}", block: false)#text(" that we have not yet dealt with. However we may simply concatenate these small cells onto one of the larger cells, as this does not significantly affect the definability or regularity properties of the large cells, and we are done.")

#text("Now we improve the ")#tao-math("{O_M(\\left|F\\right|^{-1/12})}", block: false)#text(" bound to ")#tao-math("{O_M(\\left|F\\right|^{-1/4})}", block: false)#text(". Let ")#mi("{V_i, W_j}")#text(" be large cells as in the preceding argument. Let ")#mi("{T_{ij}: L^2(V_i) \\rightarrow L^2(W_j)}")#text(" be the restriction of ")#mi("{T}")#text(" to ")#mi("{V_i}")#text(" and ")#mi("{W_j}")#text(" (associated to the set ")#mi("{E \\cap (V_i \\times W_j)}")#text("), giving ")#mi("{V_i}")#text(", ")#mi("{W_j}")#text(" uniform probability measure, then we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle T_{ij} f, g \\rangle_{L^2(W_j)}\\right| \\ll_M \\left|F\\right|^{-1/12} \\left\\|f\\right\\|_{L^2(V_i)} \\left\\|g\\right\\|_{L^2(W_j)}", block: true)]]

#text("whenever at least one of ")#mi("{f\\in L^2(V_i)}")#text(", ")#mi("{g \\in L^2(W_j)}")#text(" have mean zero. Thus, we may split ")#mi("{T_{ij} = d_{ij} J + E_{ij}}")#text(" where ")#mi("{d_{ij}}")#text(" is a constant, ")#mi("{J: L^2(V_i) \\rightarrow L^2(W_j)}")#text(" is the rank one operator")

#align(center)[#tao-fit-display[#mitex("J f =\\langle f, 1_{V_i} \\rangle_{L^2(V_i)} 1_{W_j}")]]

#text("and ")#mi("{E_{ij}}")#text(" has operator norm ")#tao-math("{O_M(\\left|F\\right|^{-1/12})}", block: false)#text(". By computing ")#mi("{\\langle T_{ij} 1_{V_i}, 1_{W_j} \\rangle_{L^2(W_j})}")#text(" as before, we see that we may take ")#mi("{d_{ij}}")#text(" to be a rational with numerator and denominator ")#mi("{O_M(1)}")#text(".")

#text("Recall that ")#mi("{T_{ij}}")#text(" has a Hilbert-Schmidt norm of ")#mi("{O(1)}")#text(", and so by the triangle inequality ")#mi("{E_{ij}}")#text(" does also. If we square, we conclude that ")#mi("{T_{ij} T_{ij}^* =d_{ij}^2 JJ^* + E^{\\prime}_{ij}}")#text(", where ")#mi("{E^{\\prime}_{ij}:L^2(V_i) \\rightarrow L^2(V_i)}")#text(" has Hilbert-Schmidt norm ")#tao-math("{O_M( \\left|F\\right|^{-1/12} )}", block: false)#text(". Thus, if ")#mi("{K_2: W_j \\times W_j \\rightarrow {\\bf R}}")#text(" is the integral kernel of ")#mi("{T_{ij} T_{ij}^*}")#text(", then ")#metadata(none) <tao-b7a0cb2544c1363d6015>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\int_{W_j}\\int_{W_j} \\left|K_2(w,w^{\\prime}) - d_{ij}^2\\right|^2\\ dm_{W_j}(w) dm_{W_j}(w^{\\prime}) \\ll_M \\left|F\\right|^{-1/6}.", block: true)]]

#text("On the other hand, we have")

#align(center)[#tao-fit-display[#tao-math("K_2(w,w^{\\prime}) = \\frac{1}{\\left|V_i\\right|} \\left|\\{ v\\in V_i: (v,w), (v,w^{\\prime}) \\in E \\}\\right|", block: true)]]

#text("so by Proposition ")#link(<tao-55085deadcfa54f32414>)[#text("2")]#text(", we have either")

#align(center)[#tao-fit-display[#tao-math("K_2(w,w^{\\prime}) = d_{ij}^2+ O(\\left|F\\right|^{-1/2})", block: true)]]

#text("or")

#align(center)[#tao-fit-display[#tao-math("\\left|K_2(w,w^{\\prime}) - d_{ij}^2\\right| \\gg_M 1", block: true)]]

#text("for each ")#mi("{w,w^{\\prime}\\in W_j}")#text(". Furthermore, the set of pairs ")#mi("{(w,w^{\\prime})}")#text(" for which the latter occurs is a definable subset of ")#mi("{W_j \\times W_j}")#text(" with complexity ")#mi("{O_M(1)}")#text(". On the other hand, from ")#link(<tao-b7a0cb2544c1363d6015>)[#text("(11)")]#text(" and Chebyshev’s inequality, this set has cardinality ")#tao-math("{O_M( \\left|F\\right|^{-1/6} \\left|W_j\\right|^2 )}", block: false)#text(". By Proposition ")#link(<tao-55085deadcfa54f32414>)[#text("2")]#text(", we may self-improve this to ")#tao-math("{O_M( \\left|F\\right|^{-1} \\left|W_j\\right|^2 )}", block: false)#text(". Integrating, we self-improve ")#link(<tao-b7a0cb2544c1363d6015>)[#text("(11)")]#text(" to")

#align(center)[#tao-fit-display[#tao-math("\\int_{W_j}\\int_{W_j} \\left|K_2(w,w^{\\prime}) - d_{ij}^2\\right|^2\\ dm_{W_j}(w) dm_{W_j}(w^{\\prime}) \\ll_M \\left|F\\right|^{-1},", block: true)]]

#text("so by Cauchy-Schwarz we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{W_j} \\int_{W_j} K_2(w,w^{\\prime}) g(w) g(w^{\\prime})\\ dm_{W_j}(w) dm_{W_j}(w^{\\prime})\\right| \\ll_M \\left|F\\right|^{-1/2} \\left\\|g\\right\\|_{L^2(W_j)}^2", block: true)]]

#text("whenever ")#mi("{g}")#text(" has mean zero, thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T_{ij}^* g\\right\\|_{L^2(V_j)} \\ll_M \\left|F\\right|^{-1/4} \\left\\|g\\right\\|_{L^2(W_j)}", block: true)]]

#text("whenever ")#mi("{g}")#text(" has mean zero. By repeating the final steps of the proof of Lemma ")#link(<tao-70e929e9447e4048c35a>)[#text("3")]#text(" we conclude ")#link(<tao-5744323314533d2583cc>)[#text("(2)")]#text(" as required.")

#heading(level: 1)[#strong[#text(" — 2. Stability — ")]]

#text("The following stability result was established by Hrushovski (see Proposition 2.25 of ")#link("http://arxiv.org/abs/0909.2190")[#text("this paper")]#text(")")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Stability)")]#text(" Let ")#mi("{0 \\leq p < q \\leq 1}")#text(" be real numbers, and suppose that there are measurable subsets ")#mi("{E_1,\\ldots,E_n,F_1,\\ldots,F_n}")#text(" of a probability space ")#mi("{(X,\\mu)}")#text(" with the property that")

#align(center)[#tao-fit-display[#mitex("\\mu( E_i \\cap F_j ) \\geq q")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mu( E_j \\cap F_i ) \\leq p")]]

#text("for ")#mi("{1 \\leq i < j \\leq n}")#text(". Then we have ")#mi("{n = O_{p,q}(1)}")#text(".")
]

#text("In the ")#link("http://en.wikipedia.org/wiki/Stable_theory")[#text("language of stability theory")]#text(", this proposition asserts that the relation ")#mi("{\\mu(E_i \\cap F_j) = \\alpha}")#text(" is stable. This proposition was the key input used ")#link("http://en.wikipedia.org/wiki/Stable_theory")[#text("by Pillay-Starchenko")]#text(" and by Hrushovski (together with the discretisation results of Proposition ")#link(<tao-55085deadcfa54f32414>)[#text("2")]#text(") to give an alternate proof of the algebraic regularity lemma.")

#text("Let us first sketch Hrushovski’s proof of this lemma. If the claim failed, then by a compactness argument one can construct infinite sequences ")#mi("{(E_i)_{i=1}^\\infty, (F_i)_{i=1}^\\infty}")#text(" of measurable subsets of a probability space ")#mi("{(X,\\mu)}")#text(" with the property that ")#metadata(none) <tao-344d7f09d245e299d170>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\mu( E_i \\cap F_j ) \\geq q")]]

#text("and ")#metadata(none) <tao-ccfc3bdf2c2dc093db9b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\mu( E_j \\cap F_i ) \\leq p")]]

#text("for all ")#mi("{i < j}")#text(". Next, by Ramsey theory (for directed graphs), for any given ")#mi("{\\epsilon>0}")#text(", we may pass to an infinite subsequence such that")

#align(center)[#tao-fit-display[#mitex("\\mu( E_{i_1} \\cap F_{i_2} ) = \\mu( E_{j_1} \\cap F_{j_2} ) + O(\\epsilon)")]]

#text("for any ")#mi("{i_1 < i_2}")#text(" and ")#mi("{j_1< j_2}")#text(", and by further compactness we may eliminate the ")#mi("{\\epsilon}")#text(" error, so that")

#align(center)[#tao-fit-display[#mitex("\\mu( E_{i_1} \\cap F_{i_2} ) = \\mu( E_{j_1} \\cap F_{j_2} )")]]

#text("for any ")#mi("{i_1< i_2}")#text(" and ")#mi("{j_1 < j_2}")#text(". More generally, (using Ramsey’s theorem for directed hypergraphs and more compactness) we may assume the ")#link("http://en.wikipedia.org/wiki/Indiscernible")[#text("order-indiscernibility")]#text(" property")

#align(center)[#tao-fit-display[#mitex("\\mu( G^1_{i_1} \\cap \\ldots \\cap G^k_{i_k} ) = \\mu( G^1_{j_1} \\cap \\ldots \\cap G^k_{j_k} )")]]

#text("for any ")#mi("{i_1 < \\ldots < i_k}")#text(" and ")#mi("{j_1 < \\ldots < j_k}")#text(", and any ")#mi("{G^1,\\ldots,G^k \\in \\{E,F\\}}")#text(". This implies (by a variant of ")#link("http://en.wikipedia.org/wiki/De_Finetti%27s_Theorem")[#text("de Finetti’s theorem")]#text(", proven in Hrushovski’s paper via the ")#link("http://en.wikipedia.org/wiki/Krein-Milman_theorem")[#text("Krein-Milman theorem")]#text(") that ")#mi("{\\mu}")#text(" is ")#emph[#text("exchangeable")]#text(", which among other things implies that")

#align(center)[#tao-fit-display[#mitex("\\mu( E_i \\cap F_j ) = \\mu(E_j \\cap F_i)")]]

#text("for any ")#mi("{i,j}")#text("; but this contradicts ")#link(<tao-344d7f09d245e299d170>)[#text("(12)")]#text(", ")#link(<tao-ccfc3bdf2c2dc093db9b>)[#text("(13)")]#text(".")

#text("Now we give a spectral proof of the above proposition. Let ")#mi("{A = (a_{ij})_{1\\leq i,j \\leq n}}")#text(" be a matrix to be chosen later, and consider the expression")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{1 \\leq i,j \\leq n} a_{ij} \\mu( E_i \\cap F_j)\\right|.", block: true)]]

#text("We can rewrite this expression as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_X \\sum_{1 \\leq i,j \\leq n} a_{ij} 1_{E_i}(x) 1_{F_j}(x)\\ d\\mu(x)\\right|.", block: true)]]

#text("For any ")#mi("{x}")#text(", the vectors ")#mi("{(1_{E_i}(x))_{i=1}^n}")#text(" and ")#mi("{(1_{F_j}(x))_{i=1}^n}")#text(" have an ")#mi("{\\ell^2}")#text(" norm of at most ")#mi("{\\sqrt{n}}")#text(". Thus, we can bound the preceding expression by")

#align(center)[#tao-fit-display[#tao-math("\\int_X \\left\\| A \\right\\|_{op} \\sqrt{n} \\sqrt{n} \\ d\\mu = n \\left\\|A\\right\\|_{op}", block: true)]]

#text("where ")#tao-math("{\\left\\|A\\right\\|_{op}}", block: false)#text(" is the operator norm of ")#mi("{A}")#text("; thus we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{1 \\leq i,j \\leq n} a_{ij} \\mu( E_i \\cap F_j)\\right| \\leq n \\left\\|A\\right\\|_{op}.", block: true)]]

#text("We apply this inequality to the ")#link("http://en.wikipedia.org/wiki/Hilbert_transform#Discrete_Hilbert_transform")[#text("discrete Hilbert transform")]#text(" matrix, in which ")#mi("{a_{ij} = \\frac{1}{i-j}}")#text(" for ")#mi("{i \\neq j}")#text(" and ")#mi("{a_{ii} = 0}")#text(". This matrix has an operator norm of at most ")#mi("{\\pi}")#text(" (this is ")#link("http://en.wikipedia.org/wiki/Hilbert's_inequality")[#text("Hilbert’s inequality")]#text("). Thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{1 \\leq i < j \\leq n} \\frac{1}{i-j} (\\mu( E_i \\cap F_j)-\\mu( E_j \\cap F_i))\\right| \\leq n \\pi.", block: true)]]

#text("But by ")#link(<tao-344d7f09d245e299d170>)[#text("(12)")]#text(", ")#link(<tao-ccfc3bdf2c2dc093db9b>)[#text("(13)")]#text(", the left-hand side is at least ")#mi("{(q-p) \\sum_{1 \\leq i < j \\leq n} \\frac{1}{i-j} \\gg (q-p) n \\log n}")#text(", and the claim follows (with a bound of the form ")#mi("{n \\ll \\exp( O( \\frac{1}{q-p} ) )}")#text(").")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2013/10/29/a-spectral-theory-proof-of-the-algebraic-regularity-lemma/#comment-249441")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2013")])]

#text("A union symbol seems to be missing in the partition of V in Lemma 3.")

#text("There seems to be a cutoff at the end of the paragraph before the paragraph beginning with “Clearly, G_(w,w’).” Similarly for the double integral that references (10).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2013/10/29/a-spectral-theory-proof-of-the-algebraic-regularity-lemma/#comment-249446")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2013")])]

#text("I’m having trouble understanding the definition of complexity because I don’t see how M relates to the definability definition. There must clearly be some condition on M other than its being at least n, but I can’t find it. Is it to do with the length of the formula?")

#emph[#text("[Oops, yes, I had omitted the length condition. It’s in place now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff39422bba87564dc362dba86346d189c9f13ca60591c0da8772f2d6a73db39-476ea7aed1980e9919a56099f0ba871fd83e9da2e7284c64684097196a1c55a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omar aboura")]], [#link("https://terrytao.wordpress.com/2013/10/29/a-spectral-theory-proof-of-the-algebraic-regularity-lemma/#comment-249465")[#strong[#text("omar aboura")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2013")])]

#text("In the proof of Lemma 3:")#linebreak()#text(" After “Observe from the triangle inequality…”, the sums in the inequality should be $\\sigma_i<\\epsilon$ instead of $\\sigma_i\\geq\\epsilon$.")#linebreak()#text(" In the sentence \"We can then split…\" $E$ should be $E'$ (three times).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2013/10/29/a-spectral-theory-proof-of-the-algebraic-regularity-lemma/#comment-249548")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2013")])]

#text("“Beautiful” formulas tend to take the shape, A = B where A and B have similar complexity. We also seems to like Σ A = B where by averaging A, we get object of lower complexity B.")

#text("Your notion of “definable” makes sense. How else are we going to define subsets of finite fields? We have some starting objects and a finite number of operations we can do to them and construct more objects.")

#text("One could imagine writing a program to test membership in the set A. If A is too complex, the program has to be very long. Maybe, due to this regularity lemma, I could write a random algorithm that does almost the same thing.")

#text("I don’t write a lot of programs over finite fields – I won’t think about that!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2013/10/29/a-spectral-theory-proof-of-the-algebraic-regularity-lemma/#comment-250333")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2013")])]

#text("“avoiding the theory of the étale fundamental group”")

#text("You say that like it’s a _good_ thing!")
]
