// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/
// Converted to Typst by tao2typ: "2026-10-14T15:20:50.690388+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An improvement to Bennett’s inequality for the Poisson distribution", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An improvement to Bennett’s inequality for the Poisson distribution")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 December 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/")[#text("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("If ")#mi("{\\lambda>0}")#text(", a ")#link("https://en.wikipedia.org/wiki/Poisson_distribution")[#text("Poisson random variable")]#text(" ")#mi("{{\\bf Poisson}(\\lambda)}")#text(" with mean ")#mi("{\\lambda}")#text(" is a random variable taking values in the natural numbers with probability distribution")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) = k) = e^{-\\lambda} \\frac{\\lambda^k}{k!}.")]]

#text("One is often interested in bounding upper tail probabilities")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) \\geq \\lambda(1+u))")]]

#text("for ")#mi("{u \\geq 0}")#text(", or lower tail probabilities")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) \\leq \\lambda(1+u))")]]

#text("for ")#mi("{-1 < u \\leq 0}")#text(". A standard tool for this is ")#link("https://en.wikipedia.org/wiki/Bennett%27s_inequality")[#text("Bennett’s inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Bennett’s inequality)")]#text(" One has")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) \\geq \\lambda(1+u)) \\leq \\exp(-\\lambda h(u))")]]

#text("for ")#mi("{u \\geq 0}")#text(" and")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) \\leq \\lambda(1+u)) \\leq \\exp(-\\lambda h(u))")]]

#text("for ")#mi("{-1 < u \\leq 0}")#text(", where")

#align(center)[#tao-fit-display[#mitex("h(u) := (1+u) \\log(1+u) - u.")]]
]

#text("From the Taylor expansion ")#mi("{h(u) = \\frac{u^2}{2} + O(u^3)}")#text(" for ")#mi("{u=O(1)}")#text(" we conclude Gaussian type tail bounds in the regime ")#mi("{u = o(1)}")#text(" (and in particular when ")#mi("{u = O(1/\\sqrt{\\lambda})}")#text(" (in the spirit of the ")#link("https://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff")]#text(", ")#link("https://en.wikipedia.org/wiki/Bernstein_inequalities_(probability_theory)")[#text("Bernstein")]#text(", and ")#link("https://en.wikipedia.org/wiki/Hoeffding%27s_inequality")[#text("Hoeffding")]#text(" inequalities). but in the regime where ")#mi("{u}")#text(" is large and positive one obtains a slight gain over these other classical bounds (of ")#mi("{\\exp(- \\lambda u \\log u)}")#text(" type, rather than ")#mi("{\\exp(-\\lambda u)}")#text(").")

#emph[#text("Proof:")]#text(" We use the exponential moment method. For any ")#mi("{t \\geq 0}")#text(", we have from Markov’s inequality that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) \\geq \\lambda(1+u)) \\leq e^{-t \\lambda(1+u)} {\\bf E} \\exp( t {\\bf Poisson}(\\lambda) ).")]]

#text("A standard computation shows that the ")#link("https://en.wikipedia.org/wiki/Moment-generating_function")[#text("moment generating function")]#text(" of the Poisson distribution is given by")

#align(center)[#tao-fit-display[#mitex("\\exp( t {\\bf Poisson}(\\lambda) ) = \\exp( (e^t - 1) \\lambda )")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) \\geq \\lambda(1+u)) \\leq \\exp( (e^t - 1)\\lambda - t \\lambda(1+u) ).")]]

#text("For ")#mi("{u \\geq 0}")#text(", it turns out that the right-hand side is optimized by setting ")#mi("{t = \\log(1+u)}")#text(", in which case the right-hand side simplifies to ")#mi("{\\exp(-\\lambda h(u))}")#text(". This proves the first inequality; the second inequality is proven similarly (but now ")#mi("{u}")#text(" and ")#mi("{t}")#text(" are non-positive rather than non-negative). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Bennett’s inequality also applies for (suitably normalized) sums of bounded independent random variables. In some cases there are direct comparison inequalities available to relate those variables to the Poisson case. For instance, suppose ")#mi("{S = X_1 + \\dots + X_n}")#text(" is the sum of independent Boolean variables ")#mi("{X_1,\\dots,X_n \\in \\{0,1\\}}")#text(" of total mean ")#mi("{\\sum_{j=1}^n {\\bf E} X_j = \\lambda}")#text(" and with ")#mi("{\\sup_i {\\bf P}(X_i) \\leq \\varepsilon}")#text(" for some ")#mi("{0 < \\varepsilon < 1}")#text(". Then for any natural number ")#mi("{k}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(S=k) = \\sum_{1 \\leq i_1 < \\dots < i_k \\leq n} {\\bf P}(X_{i_1}=1) \\dots {\\bf P}(X_{i_k}=1)")]]

#align(center)[#tao-fit-display[#mitex("\\prod_{i \\neq i_1,\\dots,i_k} {\\bf P}(X_i=0)")]]

#tao-aligned(keep: true)[


#tao-math(" & \\leq \\frac{1}{k!} (\\sum_{i=1}^n \\frac{{\\bf P}(X_i=1)}{{\\bf P}(X_i=0)})^k \\times \\prod_{i=1}^n {\\bf P}(X_i=0)", block: true)



#tao-math(" & \\leq \\frac{1}{k!} (\\frac{\\lambda}{1-\\varepsilon})^k \\prod_{i=1}^n \\exp( - {\\bf P}(X_i = 1))", block: true)



#tao-math(" & \\leq e^{-\\lambda} \\frac{\\lambda^k}{(1-\\varepsilon)^k k!}", block: true)



#tao-math(" & \\leq e^{\\frac{\\varepsilon}{1-\\varepsilon} \\lambda} {\\bf P}( \\mathbf{Poisson}(\\frac{\\lambda}{1-\\varepsilon}) = k).", block: true)
]

#text("As such, for ")#mi("{\\varepsilon}")#text(" small, one can efficiently control the tail probabilities of ")#mi("{S}")#text(" in terms of the tail probability of a Poisson random variable of mean close to ")#mi("{\\lambda}")#text("; this is of course very closely related to the well known fact that the Poisson distribution emerges as the limit of sums of many independent boolean variables, each of which is non-zero with small probability. See ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1947624")[#text("this paper of Bentkus")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3161520")[#text("this paper of Pinelis")]#text(" for some further useful (and less obvious) comparison inequalities of this type.")
]

#text("In this note I wanted to record the observation that one can improve the Bennett bound by a small polynomial factor once one leaves the Gaussian regime ")#mi("{u = O(1/\\sqrt{\\lambda})}")#text(", in particular gaining a factor of ")#mi("{1/\\sqrt{\\lambda}}")#text(" when ")#mi("{u \\sim 1}")#text(". This observation is not difficult and is implicitly in the literature (one can extract it for instance from the much more general results of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1361756")[#text("this paper of Talagrand")]#text(", and the basic idea already appears in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=891601")[#text("this paper of Glynn")]#text("), but I was not able to find a clean version of this statement in the literature, so I am placing it here on my blog. (But if a reader knows of a reference that basically contains the bound below, I would be happy to know of it.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Improved Bennett’s inequality)")]#text(" One has")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) \\geq \\lambda(1+u)) \\ll \\frac{\\exp(-\\lambda h(u))}{\\sqrt{1 + \\lambda \\min(u, u^2)}}")]]

#text("for ")#mi("{u \\geq 0}")#text(" and")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) \\leq \\lambda(1+u)) \\ll \\frac{\\exp(-\\lambda h(u))}{\\sqrt{1 + \\lambda u^2 (1+u)}}")]]

#text("for ")#mi("{-1 < u \\leq 0}")#text(".")
]

#emph[#text("Proof:")]#text(" We begin with the first inequality. We may assume that ")#mi("{u \\geq 1/\\sqrt{\\lambda}}")#text(", since otherwise the claim follows from the usual Bennett inequality. We expand out the left-hand side as")

#align(center)[#tao-fit-display[#mitex("e^{-\\lambda} \\sum_{k \\geq \\lambda(1+u)} \\frac{\\lambda^k}{k!}.")]]

#text("Observe that for ")#mi("{k \\geq \\lambda(1+u)}")#text(" that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\lambda^{k+1}}{(k+1)!} \\leq \\frac{1}{1+u} \\frac{\\lambda^{k}}{k!} .")]]

#text("Thus the sum is dominated by the first term times a geometric series ")#mi("{\\sum_{j=0}^\\infty \\frac{1}{(1+u)^j} = 1 + \\frac{1}{u}}")#text(". We can thus bound the left-hand side by")

#align(center)[#tao-fit-display[#mitex("\\ll e^{-\\lambda} (1 + \\frac{1}{u}) \\sup_{k \\geq \\lambda(1+u)} \\frac{\\lambda^k}{k!}.")]]

#text("By the ")#link("https://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling approximation")]#text(", this is")

#align(center)[#tao-fit-display[#mitex("\\ll e^{-\\lambda} (1 + \\frac{1}{u}) \\sup_{k \\geq \\lambda(1+u)} \\frac{1}{\\sqrt{k}} \\frac{(e\\lambda)^k}{k^k}.")]]

#text("The expression inside the supremum is decreasing in ")#mi("{k}")#text(" for ")#mi("{k > \\lambda}")#text(", thus we can bound it by")

#align(center)[#tao-fit-display[#mitex("\\ll e^{-\\lambda} (1 + \\frac{1}{u}) \\frac{1}{\\sqrt{\\lambda(1+u)}} \\frac{(e\\lambda)^{\\lambda(1+u)}}{(\\lambda(1+u))^{\\lambda(1+u)}},")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{\\exp(-\\lambda h(u))}{\\sqrt{1 + \\lambda \\min(u, u^2)}}")]]

#text("after a routine calculation.")

#text("Now we turn to the second inequality. As before we may assume that ")#mi("{u \\leq -1/\\sqrt{\\lambda}}")#text(". We first dispose of a degenerate case in which ")#mi("{\\lambda(1+u) < 1}")#text(". Here the left-hand side is just")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( {\\bf Poisson}(\\lambda) = 0 ) = e^{-\\lambda}")]]

#text("and the right-hand side is comparable to")

#align(center)[#tao-fit-display[#mitex("e^{-\\lambda} \\exp( - \\lambda (1+u) \\log (1+u) + \\lambda(1+u) ) / \\sqrt{\\lambda(1+u)}.")]]

#text("Since ")#mi("{-\\lambda(1+u) \\log(1+u)}")#text(" is negative and ")#mi("{0 < \\lambda(1+u) < 1}")#text(", we see that the right-hand side is ")#mi("{\\gg e^{-\\lambda}}")#text(", and the estimate holds in this case.")

#text("It remains to consider the regime where ")#mi("{u \\leq -1/\\sqrt{\\lambda}}")#text(" and ")#mi("{\\lambda(1+u) \\geq 1}")#text(". The left-hand side expands as")

#align(center)[#tao-fit-display[#mitex("e^{-\\lambda} \\sum_{k \\leq \\lambda(1+u)} \\frac{\\lambda^k}{k!}.")]]

#text("The sum is dominated by the first term times a geometric series ")#tao-math("{\\sum_{j=-\\infty}^0 \\frac{1}{(1+u)^j} = \\frac{1}{\\left|u\\right|}}", block: false)#text(". The maximal ")#mi("{k}")#text(" is comparable to ")#mi("{\\lambda(1+u)}")#text(", so we can bound the left-hand side by")

#align(center)[#tao-fit-display[#tao-math("\\ll e^{-\\lambda} \\frac{1}{\\left|u\\right|} \\sup_{\\lambda(1+u) \\ll k \\leq \\lambda(1+u)} \\frac{\\lambda^k}{k!}.", block: true)]]

#text("Using the Stirling approximation as before we can bound this by")

#align(center)[#tao-fit-display[#tao-math("\\ll e^{-\\lambda} \\frac{1}{\\left|u\\right|} \\frac{1}{\\sqrt{\\lambda(1+u)}} \\frac{(e\\lambda)^{\\lambda(1+u)}}{(\\lambda(1+u))^{\\lambda(1+u)}},", block: true)]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{\\exp(-\\lambda h(u))}{\\sqrt{1 + \\lambda u^2 (1+u)}}")]]

#text("after a routine calculation. ")#mi("\\Box")

#text("The same analysis can be reversed to show that the bounds given above are basically sharp up to constants, at least when ")#mi("{\\lambda}")#text(" (and ")#mi("{\\lambda(1+u)}")#text(") are large.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-670272")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2022")])]

#text("Is there a known characterization of the class of distributions for which Bennett’s inequality is sharp?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-670320")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2022")])]

#text("I’m pretty sure Bennett’s inequality is almost never going to be completely sharp – the step in the proof where Markov’s inequality is applied is always going to lose something (since the Poisson random variable – or whatever other variable one is applying the inequality to – is not going to be a step function random variable). The main advantage of the Bennett inequality is that it has a clean statement and is reasonably close to optimal, but the point is that there is still a little bit of room for improvement. (There are several other improved versions of Bennett’s inequality in the literature, though so far I have not been able to use those to obtain a proof of Proposition 3 that was shorter than the direct calculation provided here.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-670375")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2022")])]

#text("Is the exponent ")#mi("-1/2")#text(" of the gain factor ")#mi("\\lambda ^{-1/2}")#text(" the best possible?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-670437")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2022")])]

#text("Yes (staying in the regime ")#mi("u \\sim 1")#text(" for simplicity). For instance, suppose that ")#mi("\\lambda")#text(" is an integer and ")#mi("u=1")#text(". Then")

#mi("\\displaystyle {\\bf P}( {\\bf Poisson}(\\lambda) \\geq 2\\lambda ) \\geq {\\bf P}( {\\bf Poisson}(\\lambda) = 2\\lambda )")

#mi("\\displaystyle = e^{-\\lambda} \\frac{\\lambda^{2\\lambda}}{(2\\lambda)!}")

#mi("\\displaystyle \\asymp e^{-\\lambda}  \\frac{\\lambda^{2\\lambda} e^{2\\lambda}}{(2\\lambda)^{2\\lambda} \\sqrt{2\\lambda}}")

#mi("\\displaystyle \\asymp \\exp(-\\lambda h(1))/\\sqrt{\\lambda}")

#text("by the Stirling approximation.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aaf31c4112c8380c5923ad406bb3b1e75771a20016c7979e8f721ccc5fcadfd6-412b03a8f5d3a8e20ff83115003f0674898f81d64e0c74adaaad49a4bd235eef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaohui Chen")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-670294")[#strong[#text("Xiaohui Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2022")])]

#text("Dear Prof. Tao,")

#text("I am not sure if there is an exact reference containing your sharpened bound than the standard Bennett’s inequality. However, your bound reminds me the connection to the standard Gaussian tail probability bound ")#mi("\\Phi(x) \\leq \\phi(x) / x")#text(", which leverages an integration by parts argument that can be generalized to the Poisson distribution.")

#text("Let ")#mi("X")#text(" be a ")#mi("{\\bf Poisson}(\\lambda)")#text(" random variable, my key observation is to note that we can write")

#mi("\\displaystyle P(X=k) - P(X=k-1) = P(X = k) (1 - k / \\lambda) < 0")

#text("for any ")#mi("k \\geq \\lambda (1+u)")#text(".")

#text("Using summation by parts (where the Poisson tail goes to zero sub-exponentially fast), we can write the tail probability as")

#mi("\\displaystyle P(X \\geq \\lambda (1+u)) = \\sum_{k \\geq \\lambda (1+u)} [P(X = k) - P(X = k-1)] / (1 - k / \\lambda)")

#mi("\\displaystyle  = u^{-1} P(X = \\lambda (1+u) - 1) + \\sum_{k \\geq \\lambda (1+u) + 1} P(X = k-1) [(k/\\lambda - 1)^{-1} - ((k-1)/\\lambda - 1)^{-1}].")

#text("Note that the second term on the RHS of the last expression is negative, so we can drop it to yield the following bound:")

#mi("\\displaystyle P(X \\geq \\lambda (1+u)) \\leq u^{-1} P(X = \\lambda (1+u) - 1).")

#text("Using the above relation again, we have")

#mi("\\displaystyle P(X = \\lambda (1+u) - 1) = (1 + u) P(X = \\lambda (1+u)).")

#text("Then,")

#mi("\\displaystyle P(X \\geq \\lambda (1+u)) \\leq (1 + u^{-1}) P(X = \\lambda (1+u)).")

#text("Now, running the same Stirling's approximation as in your argument to simplify the RHS of the last inequality, we obtain your upper bound in Proposition 3.")

#text("Similar lower bound can be deduced with this argument.")

#text("I think we can run the summation of parts argument to get even higher-order refinement of the standard Bennett's inequality with improvement of a factor as O(poly(\\lambda)) in non-Gaussian regime.")

#text("Thus, I believe your bounds can be interpreted as a discrete version of the Mills ratio in the standard Gaussian distribution case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-670311")[#strong[#text("Upper bounds on left and right tails of Poisson probability")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2022")]

#text("[…] Terence Tao published a blog post on bounds for the Poisson probability distribution. Specifically, he wrote about Bennett’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-670313")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2022")])]

#text("Tao’s ego is too big. Stop doing self-promotion and start doing relevant mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85715de62317f4bdb8a99c20806dfc96628407a61749ec38ff42cd47257cea02-b76e1f37c3e67e9eb77e53f21fcec3b3ee59c2f8e54a26785b7fb5c8a227a90d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bert Zwart")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-670767")[#strong[#text("Bert Zwart")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2022")])]

#text("Thanks for this. I would like to point towards other bounds for the Poisson distribution, capitalizing upon the connection with the Lambert W function. We also noticed a connection with a conjecture of Ramanujan (settled by Flajolet in 1995). ")#link("https://www.cambridge.org/core/journals/advances-in-applied-probability/article/gaussian-expansions-and-bounds-for-the-poisson-distribution-applied-to-the-erlang-b-formula/76DB4F08E5A5DE90D85A90E9D0788DA7")[#text("https://www.cambridge.org/core/journals/advances-in-applied-probability/article/gaussian-expansions-and-bounds-for-the-poisson-distribution-applied-to-the-erlang-b-formula/76DB4F08E5A5DE90D85A90E9D0788DA7")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-670783")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2022")])]

#text("Thanks for the reference! Somehow we did not locate it during our own literature search. In principle these sharp asymptotics should recover the cruder upper bounds in Proposition 3, although actually doing the calculations for this seem to be about as complicated as the proof of Proposition 3 already provided in the blog post…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4557957c47c4adbe36189ace47ba9589f62e98e5cbb07f2b0dbc189544591776-91402b4ba13d4bd3ebbbc0dc765d05a25c9007eb6cc04b67a307a0114b570366.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-671998")[#strong[#text("Alexander")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")])]

#text("It seems that something similar can be also done for the Binomial distribution ")#link("https://ieeexplore.ieee.org/abstract/document/9546799")[#text("https://ieeexplore.ieee.org/abstract/document/9546799")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-673254")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2023")])]

#text("Prof you’re amazing just wanted let you know)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd4d46872b08ca776ab0a4237eb6a1ac2ffbcba39db6e413eac3aa201b8fc695-188c236718e3712d7b448977f50ee14acad7e7e716b74209bdb69bda9124ac63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Theo")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-674188")[#strong[#text("Theo")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2023")])]

#text("Hi Terry, thanks for the post; it’s very useful. I believe the RHS above “Thus the sum is dominated…” should be \\frac{1}{1+u}\\frac{\\lambda^k}{k!} instead of \\frac{1}{1+u}\\frac{\\lambda^{k+1}}{(k+1)!}. Thanks again!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-678716")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2023")])]

#text("Update: I have just learned (from Kevin Ford) that these improved Bennett inequalities essentially appear in Section 4 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=419382")[#text("this paper of Norton")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-687727")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2025")])]

#text("How does the final inequality follow by routine calculation? The inequality doesn’t hold for ")#mi("\\lambda=5,  x \\ge 1/\\sqrt{5}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/13/an-improvement-to-bennetts-inequality-for-the-poisson-distribution/#comment-687730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2025")])]

#text("I am not sure what ")#mi("x")#text(" is referring to in your question, but for the final inequality, ")#mi("u")#text(" is restricted to the region ")#mi("-1 < u \\leq 0")#text(" with the additional conditions ")#mi("u \\leq -1/\\sqrt{\\lambda}")#text(" and ")#mi("\\lambda(1+u) \\geq 1")#text(".")
]
]
