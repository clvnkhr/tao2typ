// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/
// Converted to Typst by tao2typ: "2026-10-14T15:18:48.657105+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Poisson-Dirichlet process, and large prime factors of a random number", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Poisson-Dirichlet process, and large prime factors of a random number")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 September 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")[#text("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Define a ")#emph[#text("partition")]#text(" of ")#mi("{1}")#text(" to be a finite or infinite ")#link("http://en.wikipedia.org/wiki/Multiset")[#text("multiset")]#text(" ")#mi("{\\Sigma}")#text(" of real numbers in the interval ")#mi("{I \\in (0,1]}")#text(" (that is, an unordered set of real numbers in ")#mi("{I}")#text(", possibly with multiplicity) whose total sum is ")#mi("{1}")#text(": ")#mi("{\\sum_{t \\in \\Sigma}t = 1}")#text(". For instance, ")#mi("{\\{1/2,1/4,1/8,1/16,\\ldots\\}}")#text(" is a partition of ")#mi("{1}")#text(". Such partitions arise naturally when trying to decompose a large object into smaller ones, for instance:")

#enum(start: 1, 
[#text("(Prime factorisation) Given a natural number ")#mi("{n}")#text(", one can decompose it into prime factors ")#mi("{n = p_1 \\ldots p_k}")#text(" (counting multiplicity), and then the multiset")

#align(center)[#tao-fit-display[#mitex("\\Sigma_{PF}(n) := \\{ \\frac{\\log p_1}{\\log n}, \\ldots,\\frac{\\log p_k}{\\log n} \\}")]]

#text("is a partition of ")#mi("{1}")#text(".")],
[#text("(Cycle decomposition) Given a permutation ")#mi("{\\sigma \\in S_n}")#text(" on ")#mi("{n}")#text(" labels ")#mi("{\\{1,\\ldots,n\\}}")#text(", ")#link("http://en.wikipedia.org/wiki/Cycle_decomposition_(group_theory)")[#text("one can decompose")]#text(" ")#mi("{\\sigma}")#text(" into cycles ")#mi("{C_1,\\ldots,C_k}")#text(", and then the multiset")

#align(center)[#tao-fit-display[#tao-math("\\Sigma_{CD}(\\sigma) := \\{ \\frac{\\left|C_1\\right|}{n}, \\ldots, \\frac{\\left|C_k\\right|}{n} \\}", block: true)]]

#text("is a partition of ")#mi("{1}")#text(".")],
[#text("(Normalisation) Given a multiset ")#mi("{\\Gamma}")#text(" of positive real numbers whose sum ")#mi("{S := \\sum_{x\\in \\Gamma}x}")#text(" is finite and non-zero, the multiset")

#align(center)[#tao-fit-display[#mitex("\\Sigma_N( \\Gamma) := \\frac{1}{S} \\cdot \\Gamma = \\{ \\frac{x}{S}: x \\in \\Gamma \\}")]]

#text("is a partition of ")#mi("{1}")#text(".")]
)

#text("In the spirit of the ")#link("https://terrytao.wordpress.com/tag/universality/")[#text("universality phenomenon")]#text(", one can ask what is the natural distribution for what a “typical” partition should look like; thus one seeks a natural probability distribution on the space of all partitions, analogous to (say) the gaussian distributions on the real line, or GUE distributions on point processes on the line, and so forth. It turns out that there is one natural such distribution which is related to all three examples above, known as the ")#emph[#text("Poisson-Dirichlet distribution")]#text(". To describe this distribution, we first have to deal with the problem that it is not immediately obvious how to cleanly parameterise the space of partitions, given that the cardinality of the partition can be finite or infinite, that multiplicity is allowed, and that we would like to identify two partitions that are permutations of each other")#linebreak()#text(" One way to proceed is to random partition ")#mi("{\\Sigma}")#text(" as a type of ")#link("http://en.wikipedia.org/wiki/Point_process")[#text("point process")]#text(" on the interval ")#mi("{I}")#text(", with the constraint that ")#mi("{\\sum_{x \\in \\Sigma} x = 1}")#text(", in which case one can study statistics such as the counting functions")

#align(center)[#tao-fit-display[#tao-math("N_{[a,b]} := \\left|\\Sigma \\cap [a,b]\\right| = \\sum_{x \\in\\Sigma} 1_{[a,b]}(x)", block: true)]]

#text("(where the cardinality here counts multiplicity). This can certainly be done, although in the case of the Poisson-Dirichlet process, the formulae for the joint distribution of such counting functions is moderately complicated. Another way to proceed is to order the elements of ")#mi("{\\Sigma}")#text(" in decreasing order")

#align(center)[#tao-fit-display[#mitex("t_1 \\geq t_2 \\geq t_3 \\geq \\ldots \\geq 0,")]]

#text("with the convention that one pads the sequence ")#mi("{t_n}")#text(" by an infinite number of zeroes if ")#mi("{\\Sigma}")#text(" is finite; this identifies the space of partitions with an infinite dimensional simplex")

#align(center)[#tao-fit-display[#mitex("\\{ (t_1,t_2,\\ldots) \\in [0,1]^{\\bf N}: t_1 \\geq t_2 \\geq \\ldots; \\sum_{n=1}^\\infty t_n = 1 \\}.")]]

#text("However, it turns out that the process of ordering the elements is not “smooth” (basically because functions such as ")#mi("{(x,y) \\mapsto \\max(x,y)}")#text(" and ")#mi("{(x,y) \\mapsto \\min(x,y)}")#text(" are not smooth) and the formulae for the joint distribution in the case of the Poisson-Dirichlet process is again complicated.")#linebreak()#text(" It turns out that there is a better (or at least “smoother”) way to enumerate the elements ")#mi("{u_1,(1-u_1)u_2,(1-u_1)(1-u_2)u_3,\\ldots}")#text(" of a partition ")#mi("{\\Sigma}")#text(" than the ordered method, although it is random rather than deterministic. This procedure (which I learned from this paper ")#link("http://www.ams.org/mathscinet-getitem?mr=1214904")[#text("of Donnelly and Grimmett")]#text(") works as follows.")

#enum(start: 1, 
[#text("Given a partition ")#mi("{\\Sigma}")#text(", let ")#mi("{u_1}")#text(" be an element of ")#mi("{\\Sigma}")#text(" chosen at random, with each element ")#mi("{t\\in \\Sigma}")#text(" having a probability ")#mi("{t}")#text(" of being chosen as ")#mi("{u_1}")#text(" (so if ")#mi("{t \\in \\Sigma}")#text(" occurs with multiplicity ")#mi("{m}")#text(", the net probability that ")#mi("{t}")#text(" is chosen as ")#mi("{u_1}")#text(" is actually ")#mi("{mt}")#text("). Note that this is well-defined since the elements of ")#mi("{\\Sigma}")#text(" sum to ")#mi("{1}")#text(".")],
[#text("Now suppose ")#mi("{u_1}")#text(" is chosen. If ")#mi("{\\Sigma \\backslash \\{u_1\\}}")#text(" is empty, we set ")#mi("{u_2,u_3,\\ldots}")#text(" all equal to zero and stop. Otherwise, let ")#mi("{u_2}")#text(" be an element of ")#mi("{\\frac{1}{1-u_1} \\cdot (\\Sigma \\backslash \\{u_1\\})}")#text(" chosen at random, with each element ")#mi("{t \\in \\frac{1}{1-u_1} \\cdot (\\Sigma \\backslash \\{u_1\\})}")#text(" having a probability ")#mi("{t}")#text(" of being chosen as ")#mi("{u_2}")#text(". (For instance, if ")#mi("{u_1}")#text(" occurred with some multiplicity ")#mi("{m>1}")#text(" in ")#mi("{\\Sigma}")#text(", then ")#mi("{u_2}")#text(" can equal ")#mi("{\\frac{u_1}{1-u_1}}")#text(" with probability ")#mi("{(m-1)u_1/(1-u_1)}")#text(".)")],
[#text("Now suppose ")#mi("{u_1,u_2}")#text(" are both chosen. If ")#mi("{\\Sigma \\backslash \\{u_1,u_2\\}}")#text(" is empty, we set ")#mi("{u_3, u_4, \\ldots}")#text(" all equal to zero and stop. Otherwise, let ")#mi("{u_3}")#text(" be an element of ")#mi("{\\frac{1}{1-u_2} \\cdot ((\\frac{1}{1-u_1} \\cdot (\\Sigma\\backslash \\{u_1\\}) \\backslash \\{u_2\\})}")#text(", with each element ")#mi("{t \\in \\frac{1}{1-u_2} \\cdot ( \\frac{1}{1-u_1} \\cdot (\\Sigma\\backslash \\{u_1\\}) \\backslash \\{u_2\\})}")#text(" having a probability ")#mi("{t}")#text(" of being chosen as ")#mi("{u_3}")#text(".")],
[#text("We continue this process indefinitely to create elements ")#mi("{u_1,u_2,u_3,\\ldots \\in [0,1]}")#text(".")]
)

#text("We denote the random sequence ")#mi("{Enum(\\Sigma) := (u_1,u_2,\\ldots) \\in [0,1]^{\\bf N}}")#text(" formed from a partition ")#mi("{\\Sigma}")#text(" in the above manner as the ")#emph[#text("random normalised enumeration")]#text(" of ")#mi("{\\Sigma}")#text("; this is a random variable in the infinite unit cube ")#mi("{[0,1]^{\\bf N}}")#text(", and can be defined recursively by the formula")

#align(center)[#tao-fit-display[#mitex("Enum(\\Sigma) = (u_1, Enum(\\frac{1}{1-u_1} \\cdot (\\Sigma\\backslash \\{u_1\\})))")]]

#text("with ")#mi("{u_1}")#text(" drawn randomly from ")#mi("{\\Sigma}")#text(", with each element ")#mi("{t \\in \\Sigma}")#text(" chosen with probability ")#mi("{t}")#text(", except when ")#mi("{\\Sigma =\\{1\\}}")#text(" in which case we instead have")

#align(center)[#tao-fit-display[#mitex("Enum(\\{1\\}) = (1, 0,0,\\ldots).")]]

#text("Note that one can recover ")#mi("{\\Sigma}")#text(" from any of its random normalised enumerations ")#mi("{Enum(\\Sigma) := (u_1,u_2,\\ldots)}")#text(" by the formula ")#metadata(none) <tao-0a64ce10853f25cb3dc3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Sigma = \\{ u_1, (1-u_1) u_2,(1-u_1)(1-u_2)u_3,\\ldots\\}")]]

#text(" with the convention that one discards any zero elements on the right-hand side. Thus ")#mi("{Enum}")#text(" can be viewed as a (stochastic) parameterisation of the space of partitions by the unit cube ")#mi("{[0,1]^{\\bf N}}")#text(", which is a simpler domain to work with than the infinite-dimensional simplex mentioned earlier.")#linebreak()#text(" Note that this random enumeration procedure can also be adapted to the three models described earlier:")

#enum(start: 1, 
[#text("Given a natural number ")#mi("{n}")#text(", one can randomly enumerate its prime factors ")#mi("{n =p^{\\prime}_1 p^{\\prime}_2 \\ldots p^{\\prime}_k}")#text(" by letting each prime factor ")#mi("{p}")#text(" of ")#mi("{n}")#text(" be equal to ")#mi("{p^{\\prime}_1}")#text(" with probability ")#mi("{\\frac{\\log p}{\\log n}}")#text(", then once ")#mi("{p^{\\prime}_1}")#text(" is chosen, let each remaining prime factor ")#mi("{p}")#text(" of ")#mi("{n/p^{\\prime}_1}")#text(" be equal to ")#mi("{p^{\\prime}_2}")#text(" with probability ")#mi("{\\frac{\\log p}{\\log n/p^{\\prime}_1}}")#text(", and so forth.")],
[#text("Given a permutation ")#mi("{\\sigma\\in S_n}")#text(", one can randomly enumerate its cycles ")#mi("{C^{\\prime}_1,\\ldots,C^{\\prime}_k}")#text(" by letting each cycle ")#mi("{C}")#text(" in ")#mi("{\\sigma}")#text(" be equal to ")#mi("{C^{\\prime}_1}")#text(" with probability ")#tao-math("{\\frac{\\left|C\\right|}{n}}", block: false)#text(", and once ")#mi("{C^{\\prime}_1}")#text(" is chosen, let each remaining cycle ")#mi("{C}")#text(" be equalto ")#mi("{C^{\\prime}_2}")#text(" with probability ")#tao-math("{\\frac{\\left|C\\right|}{n-\\left|C^{\\prime}_1\\right|}}", block: false)#text(", and so forth. Alternatively, one traverse the elements of ")#mi("{\\{1,\\ldots,n\\}}")#text(" in random order, then let ")#mi("{C^{\\prime}_1}")#text(" be the first cycle one encounters when performing this traversal, let ")#mi("{C^{\\prime}_2}")#text(" be the next cycle (not equal to ")#mi("{C^{\\prime}_1}")#text(" one encounters when performing this traversal, and so forth.")],
[#text("Given a multiset ")#mi("{\\Gamma}")#text(" of positive real numbers whose sum ")#mi("{S := \\sum_{x\\in\\Gamma} x}")#text(" is finite, we can randomly enumerate ")#mi("{x^{\\prime}_1,x^{\\prime}_2,\\ldots}")#text(" the elements of this sequence by letting each ")#mi("{x \\in \\Gamma}")#text(" have a ")#mi("{\\frac{x}{S}}")#text(" probability of being set equal to ")#mi("{x^{\\prime}_1}")#text(", and then once ")#mi("{x^{\\prime}_1}")#text(" is chosen, let each remaining ")#mi("{x \\in \\Gamma\\backslash \\{x^{\\prime}_1\\}}")#text(" have a ")#mi("{\\frac{x_i}{S-x^{\\prime}_1}}")#text(" probability of being set equal to ")#mi("{x^{\\prime}_2}")#text(", and so forth.")]
)

#text("We then have the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Existence of the Poisson-Dirichlet process)")]#text(" ")#metadata(none) <tao-b78df455e7e2088f31b9>#text(" There exists a random partition ")#mi("{\\Sigma}")#text(" whose random enumeration ")#mi("{Enum(\\Sigma) = (u_1,u_2,\\ldots)}")#text(" has the uniform distribution on ")#mi("{[0,1]^{\\bf N}}")#text(", thus ")#mi("{u_1,u_2,\\ldots}")#text(" are ")#link("http://en.wikipedia.org/wiki/Independent_and_identically_distributed_random_variables")[#text("independently and identically distributed")]#text(" copies of the uniform distribution on ")#mi("{[0,1]}")#text(".")
]

#text("A random partition ")#mi("{\\Sigma}")#text(" with this property will be called the ")#emph[#text("Poisson-Dirichlet process")]#text(". This process, first introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=368264")[#text("by Kingman")]#text(", can be described explicitly using ")#link(<tao-0a64ce10853f25cb3dc3>)[#text("(1)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\Sigma = \\{ u_1, (1-u_1) u_2,(1-u_1)(1-u_2)u_3,\\ldots\\},")]]

#text("where ")#mi("{u_1,u_2,\\ldots}")#text(" are iid copies of the uniform distribution of ")#mi("{[0,1]}")#text(", although it is not immediately obvious from this definition that ")#mi("{Enum(\\Sigma)}")#text(" is indeed uniformly distributed on ")#mi("{[0,1]^{\\bf N}}")#text(". We prove this proposition below the fold.")#linebreak()#text(" An equivalent definition of a Poisson-Dirichlet process is a random partition ")#mi("{\\Sigma}")#text(" with the property that ")#metadata(none) <tao-946f8ec4089ab85cd199>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(u_1, \\frac{1}{1-u_1} \\cdot (\\Sigma \\backslash \\{u_1\\})) \\equiv (U, \\Sigma)")]]

#text(" where ")#mi("{u_1}")#text(" is a random element of ")#mi("{\\Sigma}")#text(" with each ")#mi("{t \\in\\Sigma}")#text(" having a probability ")#mi("{t}")#text(" of being equal to ")#mi("{u_1}")#text(", ")#mi("{U}")#text(" is a uniform variable on ")#mi("{[0,1]}")#text(" that is independent of ")#mi("{\\Sigma}")#text(", and ")#mi("{\\equiv}")#text(" denotes equality of distribution. This can be viewed as a sort of stochastic self-similarity property of ")#mi("{\\Sigma}")#text(": if one randomly removes one element from ")#mi("{\\Sigma}")#text(" and rescales, one gets a new copy of ")#mi("{\\Sigma}")#text(".")#linebreak()#text(" It turns out that each of the three ways to generate partitions listed above can lead to the Poisson-Dirichlet process, either directly or in a suitable limit. We begin with the third way, namely by normalising a Poisson process to have sum ")#mi("{1}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Poisson-Dirichlet processes via Poisson processes)")]#text(" ")#metadata(none) <tao-bc586e2f232a557f65d7>#text(" Let ")#mi("{a>0}")#text(", and let ")#mi("{\\Gamma_a}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Poisson_process")[#text("Poisson process")]#text(" on ")#mi("{(0,+\\infty)}")#text(" with intensity function ")#mi("{t \\mapsto \\frac{1}{t} e^{-at}}")#text(". Then the sum ")#mi("{S :=\\sum_{x \\in \\Gamma_a} x}")#text(" is almost surely finite, and the normalisation ")#mi("{\\Sigma_N(\\Gamma_a) = \\frac{1}{S} \\cdot \\Gamma_a}")#text(" is a Poisson-Dirichlet process.")
]

#text("Again, we prove this proposition below the fold. Now we turn to the second way (a topic, incidentally, that was briefly touched upon in ")#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/")[#text("this previous blog post")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Large cycles of a typical permutation)")]#text(" ")#metadata(none) <tao-07ed400759a0f606a8b5>#text(" For each natural number ")#mi("{n}")#text(", let ")#mi("{\\sigma}")#text(" be a permutation drawn uniformly at random from ")#mi("{S_n}")#text(". Then the random partition ")#mi("{\\Sigma_{CD}(\\sigma)}")#text(" converges in the limit ")#mi("{n \\rightarrow\\infty}")#text(" to a Poisson-Dirichlet process ")#mi("{\\Sigma_{PF}}")#text(" in the following sense: given any fixed sequence of intervals ")#mi("{[a_1,b_1],\\ldots,[a_k,b_k] \\subset I}")#text(" (independent of ")#mi("{n}")#text("), the joint discrete random variable ")#mi("{(N_{[a_1,b_1]}(\\Sigma_{CD}(\\sigma)),\\ldots,N_{[a_k,b_k]}(\\Sigma_{CD}(\\sigma)))}")#text(" converges in distribution to ")#mi("{(N_{[a_1,b_1]}(\\Sigma),\\ldots,N_{[a_k,b_k]}(\\Sigma))}")#text(".")
]

#text("Finally, we turn to the first way:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Large prime factors of a typical number)")]#text(" ")#metadata(none) <tao-e1c49b152e1d72d0a426>#text(" Let ")#mi("{x > 0}")#text(", and let ")#mi("{N_x}")#text(" be a random natural number chosen according to one of the following three rules:")

#enum(start: 1, 
[#text("(Uniform distribution) ")#mi("{N_x}")#text(" is drawn uniformly at random from the natural numbers in ")#mi("{[1,x]}")#text(".")],
[#text("(Shifted uniform distribution) ")#mi("{N_x}")#text(" is drawn uniformly at random from the natural numbers in ")#mi("{[x,2x]}")#text(".")],
[#text("(Zeta distribution) Each natural number ")#mi("{n}")#text(" has a probability ")#mi("{\\frac{1}{\\zeta(s)}\\frac{1}{n^s}}")#text(" of being equal to ")#mi("{N_x}")#text(", where ")#mi("{s := 1 +\\frac{1}{\\log x}}")#text("and ")#mi("{\\zeta(s):=\\sum_{n=1}^\\infty \\frac{1}{n^s}}")#text(".")]
)

#text("Then ")#mi("{\\Sigma_{PF}(N_x)}")#text(" converges as ")#mi("{x \\rightarrow \\infty}")#text(" to a Poisson-Dirichlet process ")#mi("{\\Sigma}")#text(" in the same fashion as in Proposition ")#link(<tao-07ed400759a0f606a8b5>)[#text("3")]#text(".")
]

#text("The process ")#mi("{\\Sigma_{PF}(N_x)}")#text(" was first studied ")#link("http://www.ams.org/mathscinet-getitem?mr=335462")[#text("by Billingsley")]#text(" (and also later ")#link("http://www.ams.org/mathscinet-getitem?mr=498355")[#text("by Knuth-Trabb Pardo")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=856456")[#text("by Vershik")]#text(", but the formulae were initially rather complicated; the proposition above is due to ")#link("http://www.ams.org/mathscinet-getitem?mr=1214904")[#text("of Donnelly and Grimmett")]#text(", although the third case of the proposition is substantially easier and appears in the earlier work ")#link("http://www.ams.org/mathscinet-getitem?mr=757777")[#text("of Lloyd")]#text(". We prove the proposition below the fold.")#linebreak()#text(" The previous two propositions suggests an interesting analogy between large random integers and large random permutations; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1404040")[#text("this ICM article of Vershik")]#text(" and this ")#link("http://www.dms.umontreal.ca/~andrew/PDF/Anatomy.pdf")[#text("non-technical article of Granville")]#text(" (which, incidentally, was ")#link("http://www.msri.org/general_events/19160")[#text("once adapted into a play")]#text(") for further discussion.")#linebreak()#text(" As a sample application, consider the problem of estimating the number ")#mi("{\\pi(x,x^{1/u})}")#text(" of integers up to ")#mi("{x}")#text(" which are not divisible by any prime larger than ")#mi("{x^{1/u}}")#text(" (i.e. they are ")#mi("{x^{1/u}}")#text("–")#link("http://en.wikipedia.org/wiki/Smooth_number")[#text("smooth")]#text("), where ")#mi("{u>0}")#text(" is a fixed real number. This is essentially (modulo some inessential technicalities concerning the distinction between the intervals ")#mi("{[x,2x]}")#text(" and ")#mi("{[1,x]}")#text(") the probability that ")#mi("{\\Sigma}")#text(" avoids ")#mi("{[1/u,1]}")#text(", which by the above theorem converges to the probability ")#mi("{\\rho(u)}")#text(" that ")#mi("{\\Sigma_{PF}}")#text(" avoids ")#mi("{[1/u,1]}")#text(". Below the fold we will show that this function is given by the ")#link("http://en.wikipedia.org/wiki/Dickman_function")[#text("Dickman function")]#text(", defined by setting ")#mi("{\\rho(u)=1}")#text(" for ")#mi("{u < 1}")#text(" and ")#mi("{u\\rho^{\\prime}(u) =- \\rho(u-1)}")#text(" for ")#mi("{u \\geq 1}")#text(", thus recovering the classical result of Dickman that ")#mi("{\\pi(x,x^{1/u}) = (\\rho(u)+o(1))x}")#text(".")#linebreak()#text(" I thank Andrew Granville and Anatoly Vershik for showing me the nice link between prime factors and the Poisson-Dirichlet process. The material here is standard, and (like many of the other notes on this blog) was primarily written for my own benefit, but it may be of interest to some readers. In preparing this article I found ")#link("http://www.newton.ac.uk/preprints/NI04019.pdf")[#text("this exposition by Kingman")]#text(" to be helpful.")#linebreak()#text(" Note: this article will emphasise the computations rather than rigour, and in particular will rely on informal use of infinitesimals to avoid dealing with stochastic calculus or other technicalities. We adopt the convention that we will neglect higher order terms in infinitesimal calculations, e.g. if ")#mi("{dt}")#text(" is infinitesimal then we will abbreviate ")#mi("{dt + o(dt)}")#text(" simply as ")#mi("{dt}")#text(".")#linebreak()#text(" ")#metadata(none) <tao-7a57afb266d6cdf2456f>

#heading(level: 1)[#strong[#text(" — 1. Constructing the Poisson-Dirichlet process — ")]]

#text("We now prove Proposition ")#link(<tao-bc586e2f232a557f65d7>)[#text("2")]#text(", which of course also implies Proposition ")#link(<tao-b78df455e7e2088f31b9>)[#text("1")]#text(".")#linebreak()#text(" Let ")#mi("{a>0}")#text(", and let ")#mi("{\\Gamma_a}")#text(" be as in Proposition ")#link(<tao-bc586e2f232a557f65d7>)[#text("2")]#text(". We note that ")#mi("{\\Gamma_a \\equiv \\frac{1}{a} \\Gamma_1}")#text(", so if one wished, one could normalise ")#mi("{a=1}")#text(". However, for minor technical reasons it will be convenient to allow ")#mi("{a}")#text(" to to be arbitrary.")#linebreak()#text(" We first understand the law of the sum ")#mi("{S :=\\sum_{x \\in\\Gamma_a} x}")#text(" of the Poisson process ")#mi("{\\Gamma_a}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-b374aba771f7ccc3011c>#text(" Let ")#mi("{\\Gamma_a}")#text(" be as in Proposition ")#link(<tao-bc586e2f232a557f65d7>)[#text("2")]#text(". Then ")#mi("{S := \\sum_{x \\in \\Gamma_a} x}")#text(" is an ")#link("http://en.wikipedia.org/wiki/Exponential_distribution")[#text("exponential variable")]#text(" with probability distribution ")#mi("{t \\mapsto a e^{-at}}")#text(". In particular, ")#mi("{S}")#text(" is almost surely finite.")
]

#emph[#text("Proof:")]#text(" Taking Laplace transforms, it suffices to show that ")#metadata(none) <tao-a31fe9656fc8d3a459e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\bf E} \\exp( - s S ) = \\frac{a}{s+a}")]]

#text(" for all ")#mi("{s>0}")#text(". We come the left-hand side by an informal argument using infinitesimals, leaving the rigorous version of the argument as an exercise to the reader. Partitioning ")#mi("{[0,+\\infty)}")#text(" into infinitesimal intervals ")#mi("{[t,t+dt)}")#text(", we expect each interval ")#mi("{[t,t+dt)}")#text(" to contain exactly one element of ")#mi("{\\Gamma}")#text(" with probability about ")#mi("{\\frac{1}{t} e^{-at} dt}")#text(", and to contain two or more elements with negligible probability. We can then write")

#align(center)[#tao-fit-display[#mitex("S = \\sum_t 1_{N_{[t,t+dt)}=1} t")]]

#text("(ignoring higher order terms) and thus")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} \\exp(-sS)  & = \\prod_t (1 + (e^{-st}-1) \\frac{1}{t} e^{-at} dt)", block: true)



#tao-math(" & = \\exp( \\sum_t (e^{-st}-1) \\frac{1}{t} e^{-at}\\ dt )", block: true)
]

#text("and thus on sending ")#mi("{dt}")#text(" to zero")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\exp(-sS) = \\exp( \\int_0^\\infty (e^{-st}-1) \\frac{1}{t} e^{-at}\\ dt ).")]]

#text("The quantity ")#mi("{\\int_0^\\infty (e^{-st}-1) \\frac{1}{t} e^{-at}\\ dt}")#text(" vanishes when ")#mi("{s=0}")#text(" and has an ")#mi("{s}")#text("-derivative of ")#mi("{-\\int_0^\\infty e^{-st} e^{-at}\\ dt = \\frac{-1}{s+a}}")#text(", so on integrating we have")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty (e^{-st}-1) \\frac{1}{t} e^{-at}\\ dt = \\log(a) - \\log(s+a)")]]

#text("and ")#link(<tao-a31fe9656fc8d3a459e6>)[#text("(3)")]#text(" follows. ")#mi("\\Box")#linebreak()#text(" The same analysis can be performed for Poisson processes with more general intensity functions, leading to ")#link("http://en.wikipedia.org/wiki/Campbell's_theorem_(probability)")[#text("Campbell’s theorem")]#text(". However, the exponential nature of ")#mi("{S}")#text(" leads to an important decoupling property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" Let ")#mi("{\\Gamma}")#text(" be as in Proposition ")#link(<tao-bc586e2f232a557f65d7>)[#text("2")]#text(". Then the random variable ")#mi("{S}")#text(" and the normalisation ")#mi("{\\Sigma_N(\\Gamma_a) = \\frac{1}{S} \\cdot \\Gamma_a}")#text(" are independent.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{[t_1,t_1+dt_1],\\ldots,[t_k,t_k+dt_k]}")#text(" be disjoint infinitesimal intervals in ")#mi("{I}")#text(", and let ")#mi("{[s,s+ds]}")#text(" be another infinitesimal interval in ")#mi("{(0,+\\infty)}")#text(", with ")#mi("{ds}")#text(" infinitesimal compared with ")#mi("{dt_1,\\ldots,dt_k}")#text(". We compute the probability of of the (infinitesimal) event ")#mi("{E_{s,t_1,\\ldots,t_k}}")#text(" that ")#mi("{S}")#text(" lies in ")#mi("{[s,s+ds]}")#text(" and each of ")#mi("{[t_i,t_i+dt_i]}")#text(" is occupied by an element of ")#mi("{\\Sigma}")#text("; our goal is to show that this probability decouples into the product of a function of ")#mi("{s,ds}")#text(" and a function of the ")#mi("{t_i,dt_i}")#text(". This event ")#mi("{E_{s,t_1,\\ldots,t_k}}")#text(" is (up to higher order errors) empty if ")#mi("{t_1+\\ldots+t_k >1}")#text(", and is otherwise equal to the event that each of the ")#mi("{[st_i,st_i+sdt_i]}")#text(" is occupied by an element ")#mi("{x_i}")#text(" of ")#mi("{\\Gamma_a}")#text(", and that the sum ")#mi("{S-x_1-\\ldots-x_k}")#text(" of the remaining elements lies in ")#mi("{[s-x_1-\\ldots-x_k,s-x_1-\\ldots-x_k+ds]}")#text(". By definition of Poisson process, the former event occurs with probability")

#align(center)[#tao-fit-display[#mitex("\\prod_{i=1}^k \\frac{1}{st_i} \\exp(- a st_i) s dt_i = \\exp( - as \\sum_{i=1}^k t_i) \\prod_{i=1}^k \\frac{dt_i}{t_i}.")]]

#text("Once we condition on this event, ")#mi("{\\Gamma_a \\backslash \\{x_1,\\ldots,x_k\\}}")#text(" is again a Poisson process of intensity ")#mi("{t \\mapsto \\frac{1}{t} \\exp(-at)}")#text(", so by Lemma ")#link(<tao-b374aba771f7ccc3011c>)[#text("5")]#text(" ")#mi("{S -x_1 - \\ldots- x_k}")#text(" is an exponential variable of parameter ")#mi("{a}")#text(", so it lies in ")#mi("{[s-x_1-\\ldots-x_k,s-x_1-\\ldots-x_k+ds]}")#text(" with probability")

#align(center)[#tao-fit-display[#mitex("a \\exp( -a (s-x_1-\\ldots-x_k) ) ds.")]]

#text("Since ")#mi("{x_i}")#text(" is infinitesimally close to ")#mi("{at_i}")#text(", we conclude that the probability of ")#mi("{E_{s,t_1,\\ldots,t_k}}")#text(" is")

#align(center)[#tao-fit-display[#mitex("a \\exp( -as) (\\prod_{i=1}^k \\frac{dt_i}{t_i}) 1_{t_1+\\ldots+t_k \\leq 1}")]]

#text("giving the claim. ")#mi("\\Box")#linebreak()#text(" Note that the above calculation in fact computes the ")#mi("{k}")#text("-point intensity function of ")#mi("{\\Sigma = \\Sigma_N(\\Gamma_a)}")#text(" as ")#metadata(none) <tao-b3c85fc07d0062c687eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(t_1,\\ldots,t_k)\\mapsto (\\prod_{i=1}^k \\frac{1}{t_i}) 1_{t_1+\\ldots+t_k \\leq 1}.")]]

#linebreak()#text(" We can now show the Poisson-Dirichlet property ")#link(<tao-946f8ec4089ab85cd199>)[#text("(2)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" Let ")#mi("{\\Sigma:= \\Sigma_N(\\Gamma_a)}")#text(", and let ")#mi("{u_1 \\in \\Sigma}")#text(" be a random element, with each ")#mi("{t \\in\\Sigma}")#text(" having a probability ")#mi("{t}")#text(" of equalling ")#mi("{u_1}")#text(". Then ")#mi("{u_1}")#text(" is distributed uniformly in ")#mi("{[0,1]}")#text(", and after one conditions on the value of ")#mi("{u_1}")#text(", ")#mi("{\\frac{1}{1-u_1} \\cdot (\\Sigma\\backslash \\{u_1\\})}")#text(" has the same distribution as ")#mi("{\\Sigma}")#text(".")
]

#emph[#text("Proof:")]#text(" We first establish that ")#mi("{u_1}")#text(" is distributed uniformly in ")#mi("{[0,1]}")#text(". Consider the event ")#mi("{E_u}")#text(" that ")#mi("{u_1}")#text(" lies in an infinitesimal interval ")#mi("{[u,u+du]}")#text(" for some ")#mi("{0 < u \\leq 1}")#text(". This requires the interval ")#mi("{[u,u+du]}")#text(" to contain an element ")#mi("{t}")#text(" of ")#mi("{\\Sigma}")#text(", which occurs with probability ")#mi("{\\frac{1}{u} du}")#text(", and then there is a probability ")#mi("{u \\approx t}")#text(" that this element will be selected as ")#mi("{u_1}")#text(". Thus ")#mi("{E_u}")#text(" has probability ")#mi("{du}")#text(", giving the claim of uniform distribution.")#linebreak()#text(" Now consider the probability of the event ")#mi("{E_{u,t_1,\\ldots,t_k}}")#text(" that ")#mi("{u_1}")#text(" lies in ")#mi("{[u,u+du]}")#text(", and that ")#mi("{\\frac{1}{1-u_1} \\cdot (\\Sigma \\backslash \\{u_1\\})}")#text(" meets each of the disjoint infinitesimal ")#mi("{[t_1,t_1+dt_1],\\ldots,[t_k,t_k+dt_k]}")#text(", where we choose ")#mi("{du}")#text(" to be infinitesimal compared with ")#mi("{t_1,\\ldots,t_k}")#text(". This event is empty if ")#mi("{t_1+\\ldots+t_k > 1}")#text(", and is otherwise equal (up to higher order errors) as the event that ")#mi("{u_1 \\in [u,u+du]}")#text(" and that ")#mi("{\\Sigma}")#text(" meets each of the ")#mi("{[(1-u)t_i, (1-u)t_i+(1-u)dt_i]}")#text(". By ")#link(<tao-b3c85fc07d0062c687eb>)[#text("(4)")]#text(" for ")#mi("{k+1}")#text(" applied at ")#mi("{(u, (1-u)t_1,\\ldots,(1-u)t_k)}")#text(", we conclude that ")#mi("{E_{u,t_1,\\ldots,t_k}}")#text(" occurs with probability")

#align(center)[#tao-fit-display[#mitex("u \\times (\\frac{du}{u} \\times \\frac{(1-u)dt_1}{(1-u)t_1} \\times \\ldots \\times \\frac{(1-u)dt_k}{(1-u)t_k}) 1_{t_1+\\ldots+t_k \\leq 1}")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("du \\times (\\prod_{i=1}^k \\frac{dt_i}{t_i}) 1_{t_1+\\ldots+t_k \\leq 1}.")]]

#text("If we condition out by ")#mi("{E_u}")#text(" which has probability ")#mi("{du}")#text(", we recover the same ")#mi("{k}")#text("-point correlation function ")#link(<tao-b3c85fc07d0062c687eb>)[#text("(4)")]#text(" as ")#mi("{\\Sigma}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" As a crude zeroth approximation to the process ")#mi("{\\Sigma=\\Sigma_N(\\Gamma_a)}")#text(", one can consider the Poisson process ")#mi("{\\Sigma^{\\prime}}")#text(" on ")#mi("{I}")#text(" with intensity function ")#mi("{t \\mapsto \\frac{1}{t} 1_{t\\leq 1}}")#text(". By ")#link(<tao-b3c85fc07d0062c687eb>)[#text("(4)")]#text(", this process has the same ")#mi("{1}")#text("-point intensity function as the true Poisson-Dirichlet process ")#mi("{\\Sigma}")#text(", but has the wrong higher point correlation functions (the cutoff ")#mi("{1_{t_1+\\ldots+t_k \\leq 1}}")#text(" is replaced by ")#mi("{1_{t_1,\\ldots,t_k \\leq 1}}")#text("). Related to this, ")#mi("{\\Sigma^{\\prime}}")#text(" is not a partition in general as there is no reason why ")#mi("{\\sum_{x \\in\\Sigma^{\\prime}} x}")#text(" should equal ")#mi("{1}")#text(". Nevertheless, this zeroth approximation can be used as a crude heuristic in some cases. In the number theoretic setting, it corresponds to a Cramer-type random model in which each prime ")#mi("{p}")#text(" less than a “typical” number ")#mi("{N}")#text(" has an independent probability of ")#mi("{1/p}")#text(" of dividing ")#mi("{N}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" ")#metadata(none) <tao-1df6c17a68ee3e40aaad>#text(" If one starts with a Poisson process ")#mi("{\\Gamma_{\\theta,a}}")#text(" of intensity ")#mi("{\\theta \\frac{1}{t} e^{-at}}")#text(" for some parameter ")#mi("{\\theta>0}")#text(" and normaliises it as above, one arrives at a more general Poisson-Dirichlet process whose enumeration variables ")#mi("{u_1,u_2,\\ldots}")#text(" are distributed according to a ")#link("http://en.wikipedia.org/wiki/Beta_distribution")[#text("beta distribution")]#text(" rather than the uniform distribution.")
]

#heading(level: 1)[#strong[#text(" — 2. Cycle decomposition of random permutations — ")]]

#text("The proof of Proposition ")#link(<tao-07ed400759a0f606a8b5>)[#text("3")]#text(" is essentially immediate from the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" ")#metadata(none) <tao-bcd61b3fbc4075bb19db>#text(" Let ")#mi("{n,\\sigma}")#text(" and ")#mi("{\\Sigma_n := \\Sigma_{CD}(\\sigma)}")#text(" be as in Proposition ")#link(<tao-07ed400759a0f606a8b5>)[#text("3")]#text(". Let ")#mi("{u_1}")#text(" be a random element of ")#mi("{\\Sigma_n}")#text(", with each ")#mi("{t \\in \\Sigma_n}")#text(" occuring with probability ")#mi("{t}")#text(". Then ")#mi("{u_1}")#text(" is distributed uniformly among the multiples ")#mi("{\\{1/n,2/n,\\ldots,1\\}}")#text(" of ")#mi("{1/n}")#text(", and after conditioning on a given value ")#mi("{u_1=j/n}")#text(" of ")#mi("{u_1}")#text(", ")#mi("{\\frac{1}{1-u_1} \\cdot (\\Sigma_n \\backslash \\{u_1\\})}")#text(" has the distribution of ")#mi("{\\Sigma_{n-j}}")#text(".")
]

#text("Heuristically at least, in the limit ")#mi("{n \\rightarrow \\infty}")#text(", this proposition asserts that the limiting distribution of the ")#mi("{\\Sigma_n}")#text(" obeys the defining relation ")#link(<tao-946f8ec4089ab85cd199>)[#text("(2)")]#text(" of the Poisson-Dirichlet process. It is not difficult to make this argument rigorous, but we leave this as an exercise to the reader.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We first compute the probability that ")#mi("{u_1}")#text(" is equal to ")#mi("{j/n}")#text(". Using the cycle interpretation of the enumeration of ")#mi("{\\Sigma_n}")#text(", this is equal to the probability that a randomly chosen element of ")#mi("{\\{1,\\ldots,n\\}}")#text(" lies in a cycle of ")#mi("{\\sigma}")#text(" of length ")#mi("{j}")#text(". By permutation symmetry, it suffices to compute the probability that ")#mi("{1}")#text(" lies in a cycle of length ")#mi("{j}")#text(". To count the number of permutations ")#mi("{\\sigma}")#text(" with this property, observe from direct counting that there are ")#mi("{(n-1) \\times \\ldots \\times (n-j+1)}")#text(" ways to select the cycle of length ")#mi("{j}")#text(" containing ")#mi("{1}")#text(", and once this cycle is chosen there are ")#mi("{(n-j)!}")#text(" ways to select the rest of the permutation ")#mi("{\\sigma}")#text(", leading to ")#mi("{(n-1)!}")#text(" ways in all. Dividing by the total number ")#mi("{n!}")#text(" of permutations, we see that the cycle length ")#mi("{j}")#text(" occurs with probability ")#mi("{1/n}")#text(", giving the required uniform distribution.")#linebreak()#text(" The same analysis shows that once one fixes the cycle of length ")#mi("{j}")#text(" that contains ")#mi("{1}")#text(", the partition associated to the remaining cycles has the distribution of ")#mi("{\\Sigma_{n-j}}")#text(". Averaging over all the cycles of length ")#mi("{j}")#text(" containing ")#mi("{1}")#text(", we obtain the second claim of the proposition. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. Asymptotics of prime divisors — ")]]

#text("We now prove Proposition ")#link(<tao-e1c49b152e1d72d0a426>)[#text("4")]#text(". We first give a simple argument of ")#link("http://www.ams.org/mathscinet-getitem?mr=757777")[#text("Lloyd")]#text(" (as described ")#link("http://www.newton.ac.uk/preprints/NI04019.pdf")[#text("by Kingman")]#text("), which handles the much smoother (and hence much easier) third case of the theorem. In this case one can take advantage of Euler product factorisation. Indeed, if we define ")#mi("{\\Omega_s \\subset {\\mathcal P}}")#text(" to be the point process of primes defined by setting each prime ")#mi("{p}")#text(" to occur with multiplicity ")#mi("{j}")#text(" in ")#mi("{\\Omega_s}")#text(" with probability ")#mi("{(1-p^{-s}) \\frac{1}{p^{js}}}")#text(", independently in ")#mi("{p}")#text(", then we see from the fundamental theorem of arithmetic and the Euler product ")#mi("{\\zeta(s)^{-1} = \\prod_p (1-p^{-s})}")#text(" that the random variable ")#mi("{n}")#text(" has the same distribution as ")#mi("{\\prod_{p \\in \\Omega} p}")#text(", where the product is with multiplicity. Setting ")#mi("{\\Gamma_s := \\frac{1}{x} \\log \\Omega}")#text(" and ")#mi("{S := \\sum_{x \\in \\Gamma_s} x}")#text(", we thus see that the point process ")#mi("{\\Sigma = \\Sigma_s}")#text(" associated to the prime divisors of this random number ")#mi("{N}")#text(" is the same process as ")#mi("{\\frac{1}{S} \\cdot \\Gamma_s}")#text(". On the other hand, it is easy to see (from the same Mertens’ theorem calculation in the introduction) that in the limit as ")#mi("{s \\rightarrow 1}")#text(" (or ")#mi("{x \\rightarrow \\infty}")#text("), the point process ")#mi("{\\Gamma_s}")#text(" converges (in the sense of Theorem ")#link(<tao-07ed400759a0f606a8b5>)[#text("3")]#text(") to the Poisson process with intensity ")#mi("{t \\mapsto \\frac{1}{t} e^{-t}}")#text(", and the claim follows in this case from Proposition ")#link(<tao-bc586e2f232a557f65d7>)[#text("2")]#text(".")#linebreak()#text(" Now we prove the theorem in the first and second cases. Here, the Euler product factorisation is not available (unless one allows ")#mi("{s}")#text(" to be complex and uses something like ")#link("http://en.wikipedia.org/wiki/Perron's_formula")[#text("Perron’s formula")]#text(", but this turns the probabilities involved into complex numbers, and it is difficult to see how this can be made at all rigorous). Instead, we use (a slightly informal version of) the argument ")#link("http://www.ams.org/mathscinet-getitem?mr=1214904")[#text("of Donnelly and Grimmett")]#text(". The key proposition is the following analogue of Proposition ")#link(<tao-bcd61b3fbc4075bb19db>)[#text("11")]#text(", stated slightly informally:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11")]#text(" ")#text(" Let ")#mi("{N_x}")#text(" be as in the first or second case of Proposition ")#link(<tao-e1c49b152e1d72d0a426>)[#text("4")]#text(". Let ")#mi("{p_1}")#text(" be a random prime factor of ")#mi("{N_x}")#text(", with each prime factor ")#mi("{p}")#text(" of ")#mi("{N_x}")#text(" having a probability of ")#mi("{\\frac{\\log p}{\\log N_x}}")#text(" of being chosen as ")#mi("{p_1}")#text(". Then the distribution of ")#mi("{\\frac{\\log p_1}{\\log N_x}}")#text(" converges in the vague topology to the uniform distribution as ")#mi("{x \\rightarrow \\infty}")#text(". Also, if one conditions on a specific value ")#mi("{p_1=p}")#text(" of ")#mi("{p_1}")#text(", then ")#mi("{N_{x}/p_1}")#text(" has the same distribution as ")#mi("{N_{x/p_1}}")#text(" (up to negligible errors).")
]

#text("Again, upon taking logarithms and sending ")#mi("{x \\rightarrow \\infty}")#text(" we conclude, heuristically at least, that the limiting distribution of ")#mi("{\\Sigma_{PF}(N_x)}")#text(" converges to a process that obeys ")#link(<tao-946f8ec4089ab85cd199>)[#text("(2)")]#text(" and is thus a Poisson-Dirichlet process. Again, one can make this argument rigorous; see the ")#link("http://www.ams.org/mathscinet-getitem?mr=1214904")[#text("paper of Donnelly and Grimmett")]#text(" for details.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" (Informal) For sake of concreteness let us work with the second case of Proposition ")#link(<tao-e1c49b152e1d72d0a426>)[#text("4")]#text(", as the first case is similar (and also follows from the second case by a dyadic decomposition). We compute the probability that ")#mi("{p_1}")#text(" is equal to a given prime ")#mi("{p}")#text(", and ")#mi("{N_x}")#text(" equal to a given multiple ")#mi("{pm}")#text(" of ")#mi("{p}")#text(". This requires ")#mi("{pm}")#text(" lies in ")#mi("{[x,2x]}")#text(", and occurs with probability about")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\times \\frac{\\log p}{\\log N_x} 1_{[x,2x]}(pm) \\approx\\frac{1}{p} \\frac{\\log p}{\\log x} \\frac{1}{x/p} 1_{[x/p,2x/p]}(m).")]]

#text("(This is slightly inaccurate in the case that ")#mi("{m}")#text(" is also divisible by ")#mi("{p}")#text(", but this event is negligible in the limit ")#mi("{x \\rightarrow \\infty}")#text(").")#linebreak()#text(" Summing in ")#mi("{m}")#text(", we see that ")#mi("{p_1}")#text(" is equal to ")#mi("{p}")#text(" with probability about ")#mi("{\\frac{1}{p} \\frac{\\log p}{\\log x}}")#text(", and that once one conditions on the event ")#mi("{p_1=p}")#text(", one essentially recovers the distribution of ")#mi("{N_{x/p}}")#text(". Finally, the probability that ")#mi("{\\frac{\\log p}{\\log N_x}}")#text(" lies in ")#mi("{[a,b]}")#text(" is essentially")

#align(center)[#tao-fit-display[#mitex("\\sum_{x^a \\leq p \\leq x^b} \\frac{1}{p} \\frac{\\log p}{\\log x},")]]

#text("which by Mertens’ theorems is asymptotic to ")#mi("{b-a}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" The same argument also works when ")#mi("{N}")#text(" is drawn from the zeta distribution. Comparing this with Lloyd’s argument, this gives another proof of Proposition ")#link(<tao-bc586e2f232a557f65d7>)[#text("2")]#text(" (although ultimately it is just a discrete version of the previous, continuous, proof).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" A variant of Proposition ")#link(<tao-e1c49b152e1d72d0a426>)[#text("4")]#text(" of relevance to the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("polymath8 project")]#text("; if instead of selecting ")#mi("{N}")#text(" uniformly at random from ")#mi("{[x,2x]}")#text(", one instead performs a weighted distribution where each ")#mi("{n \\in [x,2x]}")#text(" has a probability ")#mi("{\\frac{k_0^{\\Omega(n)}}{\\sum_{n \\in [x,2x]} k_0^{\\Omega(n)}}}")#text(" of being chosen as ")#mi("{N}")#text(" for some fixed ")#mi("{k_0 \\geq 1}")#text(", where ")#mi("{\\Omega(n)}")#text(" is the number of prime factors of ")#mi("{n}")#text(", then the same argument shows that ")#mi("{\\Sigma_{PF}(n)}")#text(" is now asymptotic to a generalised Poisson-Dirichlet process in which the coordinates ")#mi("{u_1,u_2,\\ldots}")#text(" of the random enumeration remain independent, but now have the probability density function of ")#mi("{t \\mapsto k_0 (1-t)^{k_0-1}}")#text(" rather than the uniform distribution. (This distribution is in fact of the form in Remark ")#link(<tao-1df6c17a68ee3e40aaad>)[#text("9")]#text(", with ")#mi("{\\theta}")#text(" replaced by ")#mi("{k_0}")#text(".) In particular, when ")#mi("{k_0}")#text(" is large, the elements of ")#mi("{\\Sigma_{PF}(n)}")#text(" tend to cluster near the origin (most elements will have magnitude ")#mi("{O(1/k_0)}")#text("), which helps explain the Motohashi-Pintz-Zhang phenomenon that when sieving for ")#mi("{k_0}")#text("-tuples, the majority of moduli that one encounters in the sieve are quite smooth (or at least densely divisible).")
]

#heading(level: 1)[#strong[#text(" — 4. Dickman’s function — ")]]

#text("Let ")#mi("{\\rho(u)}")#text(" be the probability that the Poisson-Dirichlet process ")#mi("{\\Sigma}")#text(" has no element larger than ")#mi("{1/u}")#text(". Clearly ")#mi("{\\rho(u)=1}")#text(" for ")#mi("{u<1}")#text("; it is also not difficult to show that ")#mi("{\\rho}")#text(" is continuous. It thus suffices to verify the delay-differential equation ")#mi("{u \\rho^{\\prime}(u) = -\\rho(u-1)}")#text(" for ")#mi("{u>1}")#text(".")#linebreak()#text(" Let ")#mi("{u>1}")#text(". If we let ")#mi("{\\Gamma_1}")#text(" be the ")#mi("{a=1}")#text(" process from Proposition ")#link(<tao-bc586e2f232a557f65d7>)[#text("2")]#text(", and ")#mi("{S :=\\sum_{x\\in \\Gamma_1} x}")#text(", we see that ")#mi("{\\rho(u)}")#text(" is equal to the probability that ")#mi("{ut \\leq S}")#text(" for all ")#mi("{t \\in \\Gamma_1}")#text(". Taking (backwards) Newton quotients, we then conclude that ")#mi("{-du \\rho^{\\prime}(u)}")#text(" is equal to the probability that ")#mi("{ut \\leq S}")#text(" for all ")#mi("{t \\in \\Sigma}")#text(", and that ")#mi("{S \\in [(u-du)T_*, uT_*]}")#text(" for the largest element ")#mi("{T_*}")#text(" of ")#mi("{\\Gamma_1}")#text(".")#linebreak()#text(" For any real number ")#mi("{t_*>0}")#text(", let ")#mi("{E_{t_*}}")#text(" denote the event that ")#mi("{T_* \\in [t_*, t_*+dt]}")#text(", ")#mi("{ut \\leq S}")#text(" for all ")#mi("{t \\in \\Gamma_1}")#text(", and that ")#mi("{S \\in [(u-du)T_*, uT_*]}")#text(", where ")#mi("{dt}")#text(" is infinitesimal compared with ")#mi("{du}")#text(". This is essentially the same as the event that ")#mi("{\\Gamma_1}")#text(" contains an element ")#mi("{t^{\\prime}_*}")#text(" in ")#mi("{[t_*, t_*+dt_*]}")#text(", that ")#mi("{(u-1)t \\leq S-t^{\\prime}_*}")#text(" for all ")#mi("{t \\in \\Gamma_1 \\backslash \\{t^{\\prime}_*\\}}")#text(", and that ")#mi("{S - t^{\\prime}_* \\in [(u-du-1)t_*, (u-1)t_*]}")#text(". The first event occurs with probability ")#mi("{\\frac{1}{t_*} e^{-t_*} dt_*}")#text(". Conditioning on this event, ")#mi("{\\Gamma_1 \\backslash \\{t_*\\}}")#text(" is still a Poisson process with intensity ")#mi("{\\frac{1}{t} e^{-t}}")#text(" with sum ")#mi("{S - t_*}")#text(". By Lemma ")#link(<tao-b374aba771f7ccc3011c>)[#text("5")]#text(", the random variable ")#mi("{S-t_*}")#text(" is exponential with parameter ")#mi("{1}")#text(" and indepenent of the process ")#mi("{\\frac{1}{S-t_*} \\cdot \\Gamma_1 \\backslash \\{t_*\\}}")#text(". Thus the remaining two events defining ")#mi("{E_{t_*}}")#text(" are conditionally independent, with the former occuring with probability ")#mi("{\\rho(u-1)}")#text(" and the latter with probability ")#mi("{e^{-(u-1)t_*} du t_*}")#text(". Thus the total probability that ")#mi("{E_{t_*}}")#text(" occurs is")

#align(center)[#tao-fit-display[#mitex("(\\frac{1}{t_*} e^{-t_*} dt) \\times \\rho(u-1) \\times e^{-(u-1)t_*} du t_*")]]

#text("which simplifies to ")#mi("{\\rho(u-1) du e^{-ut_*} dt_*}")#text("; integrating in ")#mi("{t_*}")#text(", we conclude that ")#mi("{-du \\rho^{\\prime}(u)}")#text(" is equal to ")#mi("{\\rho(u-1) du \\frac{1}{u}}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" Using ")#link(<tao-b3c85fc07d0062c687eb>)[#text("(4)")]#text(" and the inclusion-exclusion formula, one also has the integral expression")

#align(center)[#tao-fit-display[#mitex("\\rho(u) = \\sum_{k=0}^\\infty \\frac{(-1)^k}{k!} \\int_{t_1,\\ldots,t_k \\geq 1/u: t_1+\\ldots+t_k \\leq 1} \\frac{dt_1 \\ldots dt_k}{t_1 \\ldots t_k}")]]

#text("for ")#mi("{\\rho}")#text(", with the convention that the ")#mi("{k=0}")#text(" term is ")#mi("{1}")#text("; note that the summands vanish for ")#mi("{k \\geq 1/u}")#text(" and so only finitely many terms in this expression need to be evaluated. This gives another way to verify the delay-differential equation ")#mi("{u\\rho^{\\prime}(u) = -\\rho(u-1)}")#text(".")
]

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-246270")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2013")])]

#text("In step 2 of the enumeration procedure, why isn’t the probability of ")#mi("{u_2}")#text(" equaling ")#mi("{u_1}")#text(" instead ")#mi("{(m-1)u_1/(1-u_1)}")#text(", since there are ")#mi("{(m-1)}")#text(" instances of ")#mi("{u_1}")#text(" remaining in the multiset at that point, each of which has probability ")#mi("{t(=u_1)/(1-u_1)}")#text(" of being chosen?")

#emph[#text("[Oops, that was a careless mistake; fixed now, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-246325")[#strong[#text("D")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2013")])]

#text("The steps 2–4 do not agree with the reconstruction in formula (1). When you pick u_1, do you divide remaining points by 1-u_1? In other words, u_2 does not come from the original list \\Sigma, but from a rescaled list?")

#emph[#text("[Oops, you’re right; the way it was written was completely confusing. I hope I’ve fixed it now – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-246465")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("In the recursive formula for Enum, should the multiplier therefore be ")#mi("{1/1-u_1)}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/519516c95697abaced3b9e3940c32dee347115c49b8ad2fdac6384336d0bb709-2fab8383c40ed85bddba55d002af92a1c50b6e06de97b60ec5675c56e30da0a3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peleg Michaeli پليج (@pelegmichaeli)")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-540143")[#strong[#text("Peleg Michaeli پليج (@pelegmichaeli)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2020")])]

#text("I think this is still written wrongly, or at least unclear. Suppose ")#mi("\\Sigma=\\{1/2,1/3,1/6\\}")#text(", and suppose ")#mi("u_1=1/2")#text(". Then ")#mi("u_2")#text(" is chosen from ")#mi("\\frac{1}{1-u_1}(\\Sigma\\smallsetminus\\{1/2\\})=\\{2/3,1/3\\}")#text(". Now suppose ")#mi("u_2=2/3")#text(". You probably don’t want to have ")#mi("1-u_1-u_2")#text(" in the denominator in step 3.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-246395")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2013")])]

#text("This Poisson-Dirichlet process is PD(1) in a more general family PD(t), see page 99 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1207584")[#text("Poisson processes")]#text(" by Kingman. The same construction, only the uniform distribution is replaced by Beta(1,t) distribution. The process PD(t) itself is PD(0,t) in more general family PD(a,t) in the ")#link("http://www.stat.berkeley.edu/users/pitman/433.pdf")[#text("paper")]#text(" of Pitman and Yor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-246396")[#strong[#text("D")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2013")])]

#text("In Proposition 6, equality sign is missing in {\\Sigma_N(\\Gamma_a) = \\frac{1}{S} \\cdot \\Gamma_a}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ❧ ✲ ❂ ❂ ✲✳ ✴ ✶ ❂✯❀")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-246400")[#strong[#text("❧ ✲ ❂ ❂ ✲✳ ✴ ✶ ❂✯❀")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2013")])]

#text("In Proposition 4, \\Sigma_{PD} is \\Sigma_{PF}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-246424")[#strong[#text("D")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2013")])]

#text("In the case of Zeta distribution, the comment after the proof of Theorem 1 in Kingman’s paper implies that (asymptotically in x) multiplicities of any finite number of largest prime divisors are equal to one. I am assuming this also holds in the case 1 of Uniform distribution, so is it some basic result in number theory that the density of numbers with this property is equal to one? How can the number of largest prime divisors grow with x so that one still has this property?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-246431")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2013")])]

#text("Yes, it is rare for a large number to be divisible by a large prime with multiplicity more than one. This is basically because the sum ")#mi("\\sum_p \\frac{1}{p^2}")#text(" is convergent, so that the sum ")#mi("\\sum_{p>R} \\frac{1}{p^2}")#text(" goes to zero as ")#mi("R")#text(" goes to infinity. Thus, the proportion of numbers which are divisible by the square of a prime greater than ")#mi("R")#text(" goes to zero as ")#mi("R")#text(" goes to infinity. Among other things, this shows that the set of numbers whose largest ")#mi("k")#text(" prime factors occur with multiplicity one, has density one for any fixed ")#mi("k")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a775d453bcd6946c502156f1cb35a4bed1e86c38743b7a8571353128d52ec436-2b5bcc287629bf18fb3f6a74d4985caac1fe38ce645b05a2bab667c82d4872a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vcp")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-247345")[#strong[#text("vcp")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2013")])]

#text("In the first sentence following the box containing Proposition 4, “by first done” can be deleted.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e94b77684a184daf94ca5a67361d9511c1ef4d1a3ebc080e0c89dabaa7168e8e-c736d71e88d8f96fef0cdd9b29cedb5c17f242eadd2a326098fbe5298371bd66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thichchaytron")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-248121")[#strong[#text("thichchaytron")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2013")])]

#text("It very difficulty with me :(")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of X")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-248277")[#strong[#text("X")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")])]

#text("I think that there are some typos in section 1: Resp. 2 and 3 equations below (3), the left-hand side should be E exp(-sS), not E exp(-tS)")#linebreak()#text(" Also, “Theorem 2/3” should be “as in Proposition 2/3”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c4a3d9b5e8497696538b0f7570bc8754d7029db0f49378f586598e6bb24bf8e-ef624d2978e575d60490bdb3540059b4b8f8f6d79dfe01f700df9b77802db3c0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anita")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-250073")[#strong[#text("Anita")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2013")])]

#text("Is it trivial that if they are non-zero and sums to 1, the multiset must be countable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c4a3d9b5e8497696538b0f7570bc8754d7029db0f49378f586598e6bb24bf8e-ef624d2978e575d60490bdb3540059b4b8f8f6d79dfe01f700df9b77802db3c0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anita")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-250216")[#strong[#text("Anita")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("Of course it is, ignore this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3d6bffba8e8df5371c576469675c0ad41386516eb91995e3a5e7902c3c32407-73dfe17c83cd28de17a54665a7371309531e7e38450f74c87a3ab623410858f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigory F")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-250915")[#strong[#text("Grigory F")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2013")])]

#text("Typo in the third line after equation (1): ")#mi("[0,1]^n")#text(" should read ")#mi("[0,1]^{\\bf N}")#text(" instead.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d06eab304e0c3df4f37e10920d7917e03a1408641f3fc41d9dfa64bc7c569662-8ff9a756cf950b19694695206f53f0c04ddfb545aeefbaca7cead51a9664114b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sary D")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-251906")[#strong[#text("Sary D")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2013")])]

#text("Some signs should probably be swapped in section 4 : $u\\rho'(u)=-\\rho(u-1)$ and probability $-du\\rho'(u)$, since rho is decreasing.")#linebreak()#text(" I love reading your blog !")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07a7ff91b522bd7e3d602d732862da024ca4139da9b2c9c501209e58c172fe3f-3d62c9479bfbdbb2f0dea100b15ffb0ef7ef841b2b446f14120e79e1bc868c13.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Chinese Restaurant Process | Eventually Almost Everywhere")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-276114")[#strong[#text("The Chinese Restaurant Process | Eventually Almost Everywhere")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2014")])]

#text("[…] The Poisson-Dirichlet process, and large prime factors of a random number (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07a7ff91b522bd7e3d602d732862da024ca4139da9b2c9c501209e58c172fe3f-3d62c9479bfbdbb2f0dea100b15ffb0ef7ef841b2b446f14120e79e1bc868c13.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Urns and the Dirichlet Distribution | Eventually Almost Everywhere")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-276115")[#strong[#text("Urns and the Dirichlet Distribution | Eventually Almost Everywhere")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2014")])]

#text("[…] The Poisson-Dirichlet process, and large prime factors of a random number (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cycles of a random permutation, and irreducible factors of a random polynomial | What's new")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-457343")[#strong[#text("Cycles of a random permutation, and irreducible factors of a random polynomial | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2015")])]

#text("[…] If is a randomly selected large integer of size , and is a randomly selected prime factor of (with each index being chosen with probability ), then is approximately uniformly distributed between and . (See Proposition 9 of this previous blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92a62560e7ce2524d7a6339f572ab182ff59d1e62604fad9a27b2866e963d2e7-ce1377c780073fe4d0cd447362e7d965470c293b1cb63a00a9cca9deae089327.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saroj")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-467060")[#strong[#text("saroj")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("can any body give me the proof of ”(estimation of s^(2/B))<infinite''????")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e0683a516d5e183002c1821a2bcf77f6dd2048dc7ce652e9eedd2f9745e5a2f-975bc0d752bf5e467bd62ac81478e64b6bcc54536820ca57125439f3daf6a05d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karl Keppler")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-503998")[#strong[#text("Karl Keppler")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("Dickman function arises in a problem proposed here:")#linebreak()#text(" ")#link("https://math.stackexchange.com/questions/2130264/sum-of-random-decreasing-numbers-between-0-and-1-does-it-converge")[#text("https://math.stackexchange.com/questions/2130264/sum-of-random-decreasing-numbers-between-0-and-1-does-it-converge")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6ddee7578d713d1d7f6b288b326d8c64012a8a3ceed0dfa70f50ac9e0601db8-fcff1c27ddf65d3bd961beaf81c7bced360631b5a1041f8a51273a17de04ac75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-506706")[#strong[#text("Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2018")])]

#text("Hi Terry!")

#text("Your blog post asked what’s new in prime numbers. I have something I think is new I would like to show you and the readers of your blog. I hope you don’t mind and are gracious enough to post this.")#linebreak()#text(" Kind regards,")#linebreak()#text(" Martin")

#text("Claim: “All prime numbers can be transformed into an integer sequence equivalent to one-half the sum of the first 2n + 1 primes.”")

#text("Proof:")#linebreak()#text(" 1) Sum each consecutive pair of prime numbers (i.e. 2,3 then 3,5, etc.)")#linebreak()#text(" 2) Subtract the difference between the two numbers.")#linebreak()#text(" 3) Divide the result by 4.")#linebreak()#text(" 4) Keep a continual sum from step 3.")#linebreak()#text(" 5) At odd intervals the continual sum is equivalent to 1/2 half the sum of the first 2n + 1 primes.")

#text("1, 5, 14, 29, 50, 80, 119, 164, 220, 284, 356, 437, 530, 632, 740, 860, 994, 1138, 1292, 1457, 1633, 1819, 2014, 2219, 2444, 2675, 2915, 3169, 3435")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b6abe6e330f945806803a4b897171d8295578e39967d8b5fdd04e9b7d42672-b6ab20e545b6a2a88585cc511b9f95d74808fa77e014eb9dc2df2f635a1d9259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Separating big sticks from little sticks, and applications – Random Permutations")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-534315")[#strong[#text("Separating big sticks from little sticks, and applications – Random Permutations")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2019")])]

#text("[…] Tao on the stick-breaking process, or the Poisson–Dirichlet process (which is essentially the same); […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c5130734f2f8bc09aac0f9115210c9a4cee17cf3554038f14a42ee0bffa61e1-07268bd7fc4bbd3654c812bdf00f3f715d9910b04fb3e44848c35f58a4633071.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noam")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-549166")[#strong[#text("Noam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("I think there is a mistake in the calculation of the integral that appears in the proof that S is an exponential variable – I believe it should be log(a/(s+a)) and not – log(s+a).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a861b523fdb5071ea2d4a76fc38e1e600a3ba2bd97dce963341b3770c82a2e-f09146c65c3fa56f5cfde78a2d6c10c19270ab040979ff9bf0dfd539cba72163.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-593132")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2020")])]

#text("Some kind of malformed formatting tag in the proof of Proposition 7 has gone mad with power and underlined half this post.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-684524")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2024")])]

#text("This is a wonderful blog post and I really enjoyed the read! However, I am struggling to understand few things regarding the proof of Lemma 5.")#linebreak()#text(" – Given the definition of exponential r.v. in the lemma, shouldn’t we show – in (3) – that its Laplace transform is a/(s+a)?")#linebreak()#text(" – Why is \\Gamma_a=a\\Gamma_1? Already by checking the expectation of the two processes, the integrand looks different.")#linebreak()#text(" – I don’t understand how can we rewrite the Laplace transform of S as the product in the third equation of the proof for Lemma 5. Isn’t S given by a Poisson binomial distribution?")#linebreak()#text(" Thanks in advance for the clarifications. FZ")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-684579")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2024")])]

#text("1. This was a typo, now corrected.")#linebreak()#text(" 2. This was also a typo: ")#mi("a \\Gamma_1")#text(" should be ")#mi("\\frac{1}{a} \\Gamma_1")#text(".")#linebreak()#text(" 3. The Laplace transform (aka moment generating function) of a sum of independent random variables is the product of the Laplace transform of the individual variables.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-685183")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2024")])]

#text("When defining the random procedure to order the elements of ")#mi("\\Sigma")#text(", in step 3, you talk about ")#mi("\\Sigma \\setminus \\{u_1,u_2\\}")#text(", when you should instead be talking about ")#mi("\\Big{\\left(\\frac{1}{1-u_1}(\\Sigma \\setminus\\{u_1\\})\\right)}\\setminus\\{u_2\\}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-685719")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2024")])]

#text("Excellent post, really distills the intuition behind a lot of old results with many different proofs. Is it not possible to parametrize partitions of unity as countably infinite multisets, or equivalence classes of vectors in the simplex up to reordering? It seems under such a parametrization the Poisson-Dirichlet construction ")#mi("{u_1,(1-u_1)u_2,...}")#text(" would exhibit the property ")#mi("\\Sigma = (U,(1-U)\\Sigma)")#text(" in distribution taking the place of (2) and would not require this size biased enumeration stuff. Maybe I am missing some technicalities though.")

#text("In the spirit of the Granville survey comparing the anatomy of cycles and prime factors I wonder if there is an analogy between conjugacy classes of permutations and those N that give the same ")#mi("\\Sigma_{PF}(N)")#text("? It’s unclear to me whether ")#mi("\\Sigma_{PF}")#text(" is injective if the partition has different size parts (for example ")#mi("\\Sigma_{PF}(p^k) = \\Sigma_{PF}(q^k)")#text(" for primes p,q). This begs the question of what the set of integers that map to a given partition look like.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Smooth numbers and max-entropy | What's new")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-688766")[#strong[#text("Smooth numbers and max-entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2025")])]

#text("[…] to the subtle differences between the Poisson and Poisson-Dirichlet processes, as discussed in this previous blog post, and is also responsible for the otherwise mysterious factor in Mertens’ third theorem; it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86ff389b9e793f30e148ba62c1cba8da494f4d96e537e5686fd7f542412d2c35-01398ff7a2857f3244537a8f883329745c0fdc5bdb39da8fdc694c841e4cf661.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anastasiia Kovtun")]], [#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-689141")[#strong[#text("Anastasiia Kovtun")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("Thank you for the post, it was really helpful.")

#text("One little thing: I believe that each term in the formula in remark 14 needs is missing a factor 1/k! since the current formula accounts for the same tuple of k points k! times (because of permutations)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/#comment-691733")[#strong[#text("What’s the entropy of a random integer? | Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2026")]

#text("[…] cycle length / N. (This is called the Poisson-Dirichlet process with parameters (0,1). Here’s a Terry T. post about it, and why it governs prime factorizations of random integers.) What’s the entropy of this […]")
]
