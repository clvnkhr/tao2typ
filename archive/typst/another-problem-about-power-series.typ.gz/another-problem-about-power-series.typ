// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/
// Converted to Typst by tao2typ: "2026-10-14T15:19:49.600783+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Another problem about power series", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Another problem about power series")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 October 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/")[#text("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("By an odd coincidence, I stumbled upon a second question in as many weeks about power series, and once again the only way I know how to prove the result is by complex methods; once again, I am leaving it here as a challenge to any interested readers, and I would be particularly interested in knowing of a proof that was not based on complex analysis (or thinly disguised versions thereof), or for a reference to previous literature where something like this identity has occured. (I suspect for instance that something like this may have shown up before in ")#link("https://en.wikipedia.org/wiki/Free_probability")[#text("free probability")]#text(", based on the answer to part (ii) of the problem.)")

#text("Here is a purely algebraic form of the problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" ")#metadata(none) <tao-07d715edb696fb5f628f>#text(" Let ")#mi("{F = F(z)}")#text(" be a formal function of one variable ")#mi("{z}")#text(". Suppose that ")#mi("{G = G(z)}")#text(" is the formal function defined by")

#tao-aligned(keep: true)[


#tao-math("G  & := \\sum_{n=1}^\\infty \\left( \\frac{F^n}{n!} \\right)^{(n-1)}", block: true)



#tao-math(" & = F + \\left(\\frac{F^2}{2}\\right)^{\\prime} + \\left(\\frac{F^3}{6}\\right)^{\\prime\\prime} + \\dots", block: true)



#tao-math(" & = F + FF^{\\prime} + (F (F^{\\prime})^2 + \\frac{1}{2} F^2 F^{\\prime\\prime}) + \\dots,", block: true)
]

#text("where we use ")#mi("{f^{(k)}}")#text(" to denote the ")#mi("{k}")#text("-fold derivative of ")#mi("{f}")#text(" with respect to the variable ")#mi("{z}")#text(".")

#list(
[#text("(i) Show that ")#mi("{F}")#text(" can be formally recovered from ")#mi("{G}")#text(" by the formula")

#tao-aligned(keep: true)[


#tao-math("F  & = \\sum_{n=1}^\\infty (-1)^{n-1} \\left( \\frac{G^n}{n!} \\right)^{(n-1)}", block: true)



#tao-math(" & = G - \\left(\\frac{G^2}{2}\\right)^{\\prime} + \\left(\\frac{G^3}{6}\\right)^{\\prime\\prime} - \\dots", block: true)



#tao-math(" & = G - GG^{\\prime} + (G (G^{\\prime})^2 + \\frac{1}{2} G^2 G^{\\prime\\prime}) - \\dots.", block: true)
]],
[#text("(ii) There is a remarkable further formal identity relating ")#mi("{F(z)}")#text(" with ")#mi("{G(z)}")#text(" that does not explicitly involve any infinite summation. What is this identity?")]
)
]

#text("To rigorously formulate part (i) of this problem, one could work in the ")#link("https://en.wikipedia.org/wiki/Differential_algebra")[#text("commutative differential ring")]#text(" of formal infinite series generated by polynomial combinations of ")#mi("{F}")#text(" and its derivatives (with no constant term). Part (ii) is a bit trickier to formulate in this abstract ring; the identity in question is easier to state if ")#mi("{F, G}")#text(" are formal power series, or (even better) convergent power series, as it involves operations such as composition or inversion that can be more easily defined in those latter settings.")

#text("To illustrate Problem ")#link(<tao-07d715edb696fb5f628f>)[#text("1")]#text("(i), let us compute up to third order in ")#mi("{F}")#text(", using ")#mi("{{\\mathcal O}(F^4)}")#text(" to denote any quantity involving four or more factors of ")#mi("{F}")#text(" and its derivatives, and similarly for other exponents than ")#mi("{4}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("G = F + FF^{\\prime} + (F (F^{\\prime})^2 + \\frac{1}{2} F^2 F^{\\prime\\prime}) + {\\mathcal O}(F^4)")]]

#text("and hence")

#tao-aligned(keep: true)[


#tao-math("G^{\\prime}  & = F^{\\prime} + (F^{\\prime})^2 + FF^{\\prime\\prime} + {\\mathcal O}(F^3)", block: true)



#tao-math("G^{\\prime\\prime}  & = F^{\\prime\\prime} + {\\mathcal O}(F^2);", block: true)
]

#text("multiplying, we have")

#align(center)[#tao-fit-display[#mitex("GG^{\\prime} = FF^{\\prime} + F (F^{\\prime})^2 + F^2 F^{\\prime\\prime} + F (F^{\\prime})^2 + {\\mathcal O}(F^4)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("G (G^{\\prime})^2 + \\frac{1}{2} G^2 G^{\\prime\\prime} = F (F^{\\prime})^2 + \\frac{1}{2} F^2 F^{\\prime\\prime} + {\\mathcal O}(F^4)")]]

#text("and hence after a lot of canceling")

#align(center)[#tao-fit-display[#mitex("G - GG^{\\prime} + (G (G^{\\prime})^2 + \\frac{1}{2} G^2 G^{\\prime\\prime}) = F + {\\mathcal O}(F^4).")]]

#text("Thus Problem ")#link(<tao-07d715edb696fb5f628f>)[#text("1")]#text("(i) holds up to errors of ")#mi("{{\\mathcal O}(F^4)}")#text(" at least. In principle one can continue verifying Problem ")#link(<tao-07d715edb696fb5f628f>)[#text("1")]#text("(i) to increasingly high order in ")#mi("{F}")#text(", but the computations rapidly become quite lengthy, and I do not know of a direct way to ensure that one always obtains the required cancellation at the end of the computation.")

#text("Problem ")#link(<tao-07d715edb696fb5f628f>)[#text("1")]#text("(i) can also be posed in formal power series: if")

#align(center)[#tao-fit-display[#mitex("F(z) = a_1 z + a_2 z^2 + a_3 z^3 + \\dots")]]

#text("is a formal power series with no constant term with complex coefficients ")#mi("{a_1, a_2, \\dots}")#text(" with ")#tao-math("{\\left|a_1\\right|<1}", block: false)#text(", then one can verify that the series")

#align(center)[#tao-fit-display[#mitex("G := \\sum_{n=1}^\\infty \\left( \\frac{F^n}{n!} \\right)^{(n-1)}")]]

#text("makes sense as a formal power series with no constant term, thus")

#align(center)[#tao-fit-display[#mitex("G(z) = b_1 z + b_2 z^2 + b_3 z^3 + \\dots.")]]

#text("For instance it is not difficult to show that ")#mi("{b_1 = \\frac{a_1}{1-a_1}}")#text(". If one further has ")#tao-math("{\\left|b_1\\right| < 1}", block: false)#text(", then it turns out that")

#align(center)[#tao-fit-display[#mitex("F = \\sum_{n=1}^\\infty (-1)^{n-1} \\left( \\frac{G^n}{n!} \\right)^{(n-1)}")]]

#text("as formal power series. Currently the only way I know how to show this is by first proving the claim for power series with a positive radius of convergence using the Cauchy integral formula, but even this is a bit tricky unless one has managed to guess the identity in (ii) first. (In fact, the way I discovered this problem was by first trying to solve (a variant of) the identity in (ii) by Taylor expansion in the course of attacking another problem, and obtaining the transform in Problem ")#link(<tao-07d715edb696fb5f628f>)[#text("1")]#text(" as a consequence.)")

#text("The transform that takes ")#mi("{F}")#text(" to ")#mi("{G}")#text(" resembles both the exponential function")

#align(center)[#tao-fit-display[#mitex("\\exp(F) = \\sum_{n=0}^\\infty \\frac{F^n}{n!}")]]

#text("and Taylor’s formula")

#align(center)[#tao-fit-display[#mitex("F(z) = \\sum_{n=0}^\\infty \\frac{F^{(n)}(0)}{n!} z^n")]]

#text("but does not seem to be directly connected to either (this is more apparent once one knows the identity in (ii)).")

#heading(level: 1)[#text("Comments (37)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7aee203720f098d6048142ae6184bb1708967fc05c298553debe7e8154fbed4f-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanishvili")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473656")[#strong[#text("Paata Ivanishvili")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2016")])]

#text("Apparently this formal identity should be related to Lambert W function because for $F(z)=exp(az)$ we have $G(z)=exp(az)*(-W(-a)/a)$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473658")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2016")])]

#text("In the first line of the problem, is “formal function” means “formal power series”? (and a similar question about the meaning of “k-fold derivative” of a formal function).")

#emph[#text("[See the first paragraph after Problem 1, as well as the discussion afterwards for a version of the problem using formal power series instead of formal functions. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473660")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2016")])]

#text("Turns out that the result is extremely classical – it is a corollary of the ")#link("https://en.wikipedia.org/wiki/Lagrange_reversion_theorem")[#text("Lagrange reversion theorem")]#text(", which I was not aware of until after I had posted the problem (actually I found out about this theorem after following up on the previous comment and reading up on the W-function). Ah well. I still think it is a nice challenge to try to prove it without complex methods.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473665")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2016")])]

#text("Using the above Wikipedia article (with ")#mi("y=1")#text("), the solution ")#mi("v")#text(" to the equation ")#mi("v=x+F(v)")#text(" (with given function ")#mi("F")#text(") is given by ")#mi("v(x)=x+G(x)")#text(" (where the function ")#mi("G")#text(" is as defined by the formal series in the problem statement). Hence ")#mi("F(v(x)) = G(x)")#text(" which implies the required identity ")#mi("F(x+G(x)) = G(x)")#text(", as well as the equivalent “dual” identity ")#mi("F(v) = G(v - F(v))")#text(" (which may explain the remarkable similarity between the two expansions.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/831f7b0b2b2fe51d9aa25ed99e43cb2e76cb43826cfa88f2781c7808e265691d-994413b6fb5fb0ef215ed3b484942517f03d05e10a097f535992434a45ed09b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Renfrew")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473697")[#strong[#text("David Renfrew")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("This relationship does show up in free probability. It is satisfied when G is the Stieltjes transform of a probability measure and F is the Stieltjes transform of the free convolution of that probability measure with the semicircle distribution.")

#text("I’m not sure if it shows up in the way you presented the problem, but it does show up as in the comment above, using the analytic subordination properties of free convolution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473976")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2016")])]

#text("I wrote up a derivation involving the Laplace transform at my website. Since this has so many connections to a variety of combinatoric structures and operational calculus that interest me, could you either write up your derivation here or send me a copy?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-474009")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2016")])]

#text("Here is a sketch of my original argument, working formally for simplicity (ignoring issues of convergence, branches of logarithm, etc.). Given a function ")#mi("F(t)")#text(" (with say ")#mi("F(0)=0")#text(" and ")#mi("F^{\\prime}(0)")#text(" small), we may formally find a function ")#mi("G")#text(" such that the maps ")#mi("t \\mapsto t-F(t)")#text(" and ")#mi("u \\mapsto u + G(u)")#text(" invert each other. Next, take some ")#mi("u")#text(" and consider the quantity")

#mi("\\displaystyle \\sum_{n=1}^\\infty (F^n/n!)^{(n-1)}(u).")

#text("Using the Cauchy integral formula one can write this as")

#mi("\\displaystyle \\sum_{n=1}^\\infty \\frac{1}{2\\pi i} \\int_\\gamma \\frac{F^n(z)}{n (z-u)^n}\\ dz")

#text("for a suitable contour ")#mi("\\gamma")#text(". Summing the series formally, we get")

#mi("\\displaystyle -\\frac{1}{2\\pi i} \\int_\\gamma \\log(1 - \\frac{F(z)}{z-u})\\ dz.")

#text("Making the somewhat prescient change of variables ")#mi("z = w + G(w)")#text(", so that ")#mi("w = z - F(z)")#text(" and hence ")#mi("F(z) = G(w)")#text(", and shifting contours, this becomes")

#mi("\\displaystyle -\\frac{1}{2\\pi i} \\int_\\gamma \\log \\frac{w-u}{w+G(w)-u}\\ (1 + G^{\\prime}(w)) dw.")

#text("By change of variables and shifting contours we (formally) have")

#mi("\\displaystyle \\int_\\gamma \\log(w-u)\\ dw = \\int_\\gamma \\log(w+G(w)-u)\\ (1+G^{\\prime}(w))\\ dw")

#text("so the above simplifies to")

#mi("\\displaystyle -\\frac{1}{2\\pi i} \\int_\\gamma \\log(w-u)  G^{\\prime}(w)\\ dw")

#text("which after integration by parts becomes")

#mi("\\displaystyle \\frac{1}{2\\pi i} \\int_\\gamma \\frac{G(w)}{w-u}\\ dw")

#text("and hence by the Cauchy integral formula we have")

#mi("\\displaystyle G(u) = \\sum_{n=1}^\\infty (F^n/n!)^{(n-1)}(u).")

#text("A similar argument (replacing ")#mi("F,G")#text(" with ")#mi("-G,-F")#text(" throughout) gives")

#mi("\\displaystyle F(t) = \\sum_{n=1}^\\infty (-1)^{n-1} (G^n/n!)^{(n-1)}(t).")

#text("One can carry out the entire argument in the ring of formal Laurent series, using the residue of such series as a substitute for contour integration; this then becomes quite close to Hermite’s proof of the Lagrange inversion formula using residues of formal Laurent series.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-474778")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2016")])]

#text("I) There’s a simpler derivation by resdues by Jacob Lurie in ")#link("http://mathoverflow.net/questions/60478/hirzebruchs-motivation-of-the-todd-class/219616#219616")[#text("http://mathoverflow.net/questions/60478/hirzebruchs-motivation-of-the-todd-class/219616#219616")]#text(", mirroring one by Hirzebruch.")

#text("II) The expansion comprised of the reduced derivatives can be formed umbrally for each order from the multinomial expansion OEIS A036038. E.g., ")#mi("(x_1 + x_2 +x_3)^2/3= [x_1^2+x_2^2+x_3^2 +2 (x_1x_2+x_1x_3+x_2x_3)]/3")#text(" umbrally reduced by erasing subscripts and lowering exponents becomes ")#mi("x_2+2x_1x_1= F^{^{\\prime\\prime}}+2(F^{^{\\prime}})^2")#text(".")

#text("III) The partition expansion is given in ")#link("http://oeis.org/A248927")[#text("http://oeis.org/A248927")]#text(" with ")#mi("h_n = F^{(n)}")#text(" and are the Hadamard products by partition of A036038 and A134264, which enumerates noncrossing partitions and provides another inversion formula. E.g., to the next order the numerical coefficients for the distinct partitions are (1,3,6)(1,3,1)=(1,9,6).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473661")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2016")])]

#text("It seems that this identity should be of the form ")#mi("H(F, G) = 0")#text(" or of the more general form ")#mi("H(F, G, F^{\\prime}, G^{\\prime}) = 0")#text(" for some explicit(!) analytic function ")#mi("H")#text(" (which may contain even higher derivatives of ")#mi("F")#text(" and ")#mi("G")#text("). Therefore, for each known(!) such function ")#mi("H")#text(", one may express formally (using formal derivations) the function ")#mi("G")#text(" (as a solution of this identity) by a power series involving ")#mi("F")#text(" and its derivatives, and vice versa (i.e. ")#mi("F")#text(" as a power series in terms of ")#mi("G")#text(" and its derivatives).")#linebreak()#text(" In order to find the explicit form of the function ")#mi("H")#text(" (representing the identity), a possible approach is to express the coefficients of the (given) expression of ")#mi("G")#text(" (as a power series in ")#mi("F")#text(" and its derivatives) in terms of the (unknown) coefficients of ")#mi("H")#text(" (as a power series in ")#mi("F, H, F^{\\prime}, H^{\\prime}")#text(") and then to solve the resulting equations for the coefficients of ")#mi("H")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473664")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2016")])]

#text("From this identity? ")#mi("\\frac{t}{e^{t}-1}=\\sum_{m=0}^{\\infty }B_{m}\\frac{t^{m}}{m!}")#linebreak()#text(" ")#mi("B_{m}")#text(" – Bernoulli number")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e147fe7e8dc936d944937a3f47efe38550f1c75b3a97d2e913730c503b13ef7-4b2596fa5c254f2b75d80954a40f4a309e0551f5792de3d8566186c426cead43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean-Bernard Zuber")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473668")[#strong[#text("Jean-Bernard Zuber")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2016")])]

#text("It would be interesting to see how Lagrange proved his formula. Presumably not by using Cauchy integral ! There is an alternative proof, of combinatorial nature, making use of differential operators defined by formal power series. See at the end of the following note")#linebreak()#text(" ")#link("https://www.dropbox.com/s/hb1stepdxpu9h1u/lagrange_e.pdf?dl=0")[#text("https://www.dropbox.com/s/hb1stepdxpu9h1u/lagrange_e.pdf?dl=0")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5aac0b3771eb8f66501a570e8af9d786563c6765337fc89471c6996d561c79ff-59dc7be6cc7edc0d466550af425d185932bd66a5c18dedf0726b20c54df23421.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of igessel")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473672")[#strong[#text("igessel")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2016")])]

#text("You can find Lagrange’s paper online at ")#link("http://gallica.bnf.fr/ark:/12148/bpt6k229222d/f6")[#text("http://gallica.bnf.fr/ark:/12148/bpt6k229222d/f6")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5aac0b3771eb8f66501a570e8af9d786563c6765337fc89471c6996d561c79ff-59dc7be6cc7edc0d466550af425d185932bd66a5c18dedf0726b20c54df23421.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of igessel")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473669")[#strong[#text("igessel")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2016")])]

#text("The “Lagrange reversion formula” (this term isn’t used anywhere except in the Wikpedia article) is equivalent to the well-known Lagrange inversion formula, which has many formal power series proofs. See, for example, my survey paper on Lagrange inversion at ")#link("https://arxiv.org/abs/1609.05988")[#text("https://arxiv.org/abs/1609.05988")]#text(", especially formula (2.6.2). Note that ")#mi("z-F(z)")#text(" and ")#mi("z+G(z)")#text(" are compositional inverses. (Presumably this is the identity in (ii).)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473853")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2016")])]

#text("The inverse relation certainly holds for ")#mi("F (z) =z^2")#text(", generating an o.g.f. for the Catalan numbers ")#mi("C(z) = z+G (z)= [1-\\sqrt {(}1-4z)]/2")#text(" with the inverse o.g.f. ")#mi("C^{-1}(z)= z-z^2")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473815")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2016")])]

#text("“(ii) There is a remarkable further formal identity relating {F(z)} with {G(z)} that does not explicitly involve any infinite summation. What is this identity?”")

#text("What is that identity? I didn’t find it on Wikipedia nor Lagrange’s paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tatenda")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473824")[#strong[#text("Tatenda")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2016")])]

#text("Dear Dr. Tao, i’m Tatenda Isaac Kubalalika, a very ambitious and deeply passionate prospective undergraduate student from Zimbabwe, whose academic progress has terribly been halted by an acute lack of funds. I know this post might not be too suitable here, but i would kindly beg you to bare with me. I initially thought of emailing you but then i thought you will probably be too busy.")

#text("Below is what really seems to be an explanation of why the nontrivial zeros of the Riemann zeta function should all lie on the critical line Re(s)=1/2 :")

#text("Consider the derivative of log xi(s) with respect to s, where xi(s) is the Riemann xi function for the variable s. We shall denote by p the nontrivial zero of xi(s).")

#text("This derivative at s=1 is given by:")

#text("(d/ds) log xi(s) = B + the sum over all p of 1/p and 1/(1-p) = 0.023…")

#text("where B is a constant.")

#text("For this infinite sum, it is necessary that each zero be paired with its conjugate.We claim that the conjugate of each p is indeed 1-p. Otherwise, if the conjugate of p was, say q, then the conjugate of 1-p would be 1-q,")

#text("and the above equation would become:")

#text("(d/ds) log xi(s) = B + the sum over all p of 1/p and 1/(1-p) + the sum over all q of 1/q and 1/(1-q)")

#text("Let A be the real part of the sum over all p of 1/p and 1/(1-p). Then observe that the real part of the sum over all q of 1/q and 1/(1-q) is also A, so that the real part of (d/ds) log xi(s) would be")

#text("(real part of B) + A = (real part of B) + 2A")

#text("which yields A=0. But this is evidently false from the known numerical value of this derivative. And we reach a contradiction")

#text("Therefore, it follows that each p is a conjugate of 1-p, which requires the real part of each p yo be 1/2.")

#text("Remark: Due to the overwhelming number of unsuccessful attempted solutions to this problem, the author understands that most people would be exceedingly skeptical of the above argument. However, we urge the reader to patiently go over each step of the above argument, and pass a conclusion of their own.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473828")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2016")])]

#text("I don’t have much to say after Ira Gessel’s response.")

#link("http://mathoverflow.net/questions/32099/what-is-lagrange-inversion-good-for")[#text("http://mathoverflow.net/questions/32099/what-is-lagrange-inversion-good-for")]

#text("One can solve ")#mi("x^5 - x - a = 0")#text(" and you get an answer ")#mi("x= -\\sum \\binom{5k}{k} \\frac{a^{4k+1}}{4k+1}")#text(". Doesn’t thing thing have the full ")#mi("S_5")#text(" Galois group?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473837")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2016")])]

#text("One can verify (e.g. by the ratio test) that this series converges IFF ")#tao-math("\\left|a\\right|  < 4 / 5^{5/4}", block: false)#text(" and that the equation has multiple root IFF ")#mi("a^4 = 4^4 / 5^5")#text(" (which determines the radius of convergence.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473829")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2016")])]

#text("I meant to add my derivation of the chain rule… here is ")#mi("(f^3)^{\\prime\\prime} = f^{\\prime\\prime} f f + ff^{\\prime\\prime}f + ff f^{\\prime\\prime} + f^{\\prime}f^{\\prime}f + f^{\\prime}ff^{\\prime}+ ff^{\\prime}f^{\\prime}=3\\big{\\left( f^2f^{\\prime\\prime}+ (f^{\\prime})^2f \\right)}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473830")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2016")])]

#text("Lagrange inversion is also called series reversion. Relations to free probability and noncrossing partitions are noted in OEIS A134264 (follow the links in Manugal’s reply).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473831")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2016")])]

#text("It is interesting, but not surprising, to see")

#text("1) how many academics use and contribute to the On-line Encyclopedia of Integer Sequences, yet do not reference it in much of their writings")

#text("2) how many academics fail to check the OEIS for info on integer sequences they stumble across, which includes matrices/tables related to partition polynomials, such as those for series reversion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473832")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2016")])]

#text("Related to ")#link("http://oeis.org/A248927")[#text("http://oeis.org/A248927")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cdbe18cfaec59f831a526f3bdf76e5661df9d72ab3cca71132c805d5fc9f96f7-2a59d8c9e09e01dd0a46ed066bdf64312ae15d0bc257173073c2ff6f2ea8030e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Lagrange Reversion Theorem and the Lagrange Inversion Formula | Shadows of Simplicity")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473874")[#strong[#text("The Lagrange Reversion Theorem and the Lagrange Inversion Formula | Shadows of Simplicity")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2016")])]

#text("[…] The lead to the connection between the OEIS entries and the LRT was Terry Tao’s post Another Problem about Power Series. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-473969")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2016")])]

#text("A solution to the problema may be next.")

#text("In algebraic expression ")#mi("F(z)")#text(" and ")#mi("G(z)")#text(" if we have:")

#mi("b_{n} = \\frac{c}{c-1}")#text("; with ")#mi("c > 2")

#text("and ")#mi("a_{n} = \\frac{1}{c-1}")

#text("We can determine ")#mi("F(z)")#text(" from ")#mi("G(z)")#text(" for it.")

#mi("G(z) = \\sum_{n=1}^{\\infty} \\left[\\frac{c}{c-1} - 1\\right] z^{n}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-474199")[#strong[#text("Sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("Respected(dear) Terence Tao! My appearance on horizon not accidental. I for a long time preparation at contact from you. By me there is five rough notebooks and approximate two hundred flat paper pages of bleach on Russian language and (of separate parts) collapsible(format A4) draft or design of big absolute number field. I nobody else no trust in,except you, therefore I be inactive, no undertake nexts steps for publication. Tower of Erdesh- that big book, not yet writing,quantity floors(page’s) in which I not know. Yet I know, how to write that book, not admit not a (single) one floor(page). Yes, that perhaps reckless, if you no believe. Who such Tom Copeland?? I know, how to fill up(fill out) matrix’s sections with partitions in OEIS of integer sequences. Thanks! Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1129c11c02535b3dd3b837e28485a83cb7917feffb121975baf46295ddce212e-c3eb21fd4d3b5ef8caf39c2614284b5e97d7c9ca9b68084519ce80f7a12885a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of david")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-474205")[#strong[#text("david")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("You just take a derivative of G(x), and put one derivative inside each term in the series. You then pull out the first term, change n+1=k in the rest of the series and see that G'(x) = F'(x)(1+G(x)). Isn’t that right? It is easy from there.")

#emph[#text("[Unfortunately this doesn’t work, because the factor ")#mi("F^{\\prime}(x)")#text(" is trapped inside a ")#mi("j-1")#text("-fold derivative and can’t easily be extricated from the series. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1129c11c02535b3dd3b837e28485a83cb7917feffb121975baf46295ddce212e-c3eb21fd4d3b5ef8caf39c2614284b5e97d7c9ca9b68084519ce80f7a12885a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-474232")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("Darn.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An integration approach to the Toeplitz square peg problem | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-474548")[#strong[#text("An integration approach to the Toeplitz square peg problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2016")])]

#text("[…] higher and higher order to try to evade this obstruction (this, incidentally, was when I discovered this cute application of Lagrange reversion) but no matter how high an accuracy I went (I think I ended up expanding to sixth order in a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-474588")[#strong[#text("Sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2016")])]

#text("Dear Terence Tao! I want proceed(with) our discussion by last subject of problem formal power series. First, what attract draw me attention, that identity F(z) and G(z). I can answer on that question. So that: F(z)=G(z) or G(z)=F(z). If extract(cancel) (z), that which receive(get) G=F or GF. In result we have two halfs of ending close field GF(q), where (q)- quatity of elements(field of Galua). If for example (q)=9, what we receive: GF(9)- that one half of field without taking into consideration symmetry, where is critical line, GF(9)=>GF(18)- that already field pattern(whole field), where critical line transform into axis line. In result identity F(z) and G(z)- that aspiration for supersymmetry. Further series O(F’) (extent 4) indispensable replace by O(1,3)- that line operator or group of Lorens, able preserve beginning of coordinates, and present group of transformations in space of Minkovki. In lasts notes of discussion evident developed alternative of proof, more distant. Thanks! Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a76251088446e9531de8b4f5efef67492e5a614189351c5ab19db4a4d6e19bb7-6a1fd3c72f8a9af2815657af5b913fc600ec3b8632b95672c526ee870e3e253a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gavinwraith")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-474744")[#strong[#text("gavinwraith")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("It seems to me that the Lagrange reversion formula is a formal consequence of the fact that in the free noncommutative ring generated by D and X satisfying DX-XD=1 we have an automorphism given by rotation through 90 degrees in the X,D plane: i.e. (D,X)=>(X,-D).")#linebreak()#text(" If T(f,a) is defined to be X+\\sigma_k(a^k/k!.D^(k-1)(F(X)^k)) do we not have T(T(f,a),b)=T(f,a+b)?")#linebreak()#text(" Please excuse the tattered non-LaTeX.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-474749")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("The formal translations ")#mi("T(f,a) = \\sum_{k=0}^\\infty \\frac{a^k}{k!} D^k(f)")#text(" do obey the group action property ")#mi("T(T(f,a),b) = T(f,a+b)")#text(", but as noted in the main post, this is not quite the operation involved in this power series problem because ")#mi("f")#text(" is also raised to a power inside the derivatives.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76accfe5628579d6d7b031a1601c5efcb8eab510e10c8bd8847b792f9312add3-cabe31d49f0a491a27c2a2c4043a07ffe49d2f1dbebf64cf7dd62d5f3a999b45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Stanley")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-476016")[#strong[#text("Richard Stanley")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2017")])]

#text("Here is a combinatorial interpretation of ")#mi("G(x)")#text(". Let")#linebreak()#text(" ")#mi("F(x)=\\sum_{n\\geq 1}a_nx^n")#text(". Then ")#mi("G(x)=\\sum_{n\\geq 1}\\left(\\sum_{T\\in \\mathcal{T}}f(T)(1-a_1)^{-g(T)}\\right)x^n")#text(", where (a) ")#mi("\\mathcal{T}")#text(" is")#linebreak()#text(" the set of all ways to draw a set of nonintersecting diagonals in a")#linebreak()#text(" convex ")#mi("(n+1)")#text("-gon, (b) ")#mi("f(T) =\\prod_{i\\geq 2}a_i^{\\alpha_i}")#text(", where")#linebreak()#text(" ")#mi("T")#text(" has ")#mi("\\alpha_i")#text(" regions with ")#mi("i+1")#text(" sides, and (c) ")#mi("g(T)")#text(" is the")#linebreak()#text(" total number of edges of ")#mi("T")#text(" (i.e., ")#mi("n+1")#text(" plus the number of")#linebreak()#text(" diagonals). If one allows curved diagonals so that any number of")#linebreak()#text(" diagonals can exist between two vertices, thereby creating some")#linebreak()#text(" regions with two edges, then the formula becomes ")#mi("G(x)=\\sum_{n\\geq 1}\\left(\\sum_{T\\in \\mathcal{T}}f(T)\\right)x^n")#text(", where now ")#mi("f(T) =\\prod_{i\\geq 1}a_i^{\\alpha_i}")#text(".")

#text("Example. The coefficient of ")#mi("x^4")#text(" in ")#mi("G(x)")#text(" is ")#mi("a_4(1-a_1)^{-5} + 5a_2a_3(1-a_1)^{-6}+5a_2^3(1-a_1)^{-7}")#text(". Thus for instance there are")#linebreak()#text(" five ways to draw diagonals in a pentagon to create one triangle and")#linebreak()#text(" one quadrilateral. The number of diagonals is 1, so the total number")#linebreak()#text(" of edges is 6. This gives the term ")#mi("5a_2a_3(1-a_1)^{-6}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-476313")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2017")])]

#text("This is essentially ")#link("http://oeis.org/A133437")[#text("http://oeis.org/A133437")]#text(" and ")#link("http://oeis.org/A111785")[#text("http://oeis.org/A111785")]#text(" with the interpretation given in the referenced link therein “Polygonal dissections and series reversion” by Schuetz and Whieldon (")#link("http://arxiv.org/abs/1401.7194")[#text("http://arxiv.org/abs/1401.7194")]#text(")–all related to the Stasheff associahedra, isn’t it? In which case you are missing some signs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-476314")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2017")])]

#text("Or, somehow $a_1$ should be replaced by $1+a_1$ in the final formula?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-476332")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2017")])]

#text("Richard Stanley, can you give me a Web-accessible ref on details of the combinatorics?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3852f3ce9d2c23b6943f2d27717513c1c7fb2cae33a67d378ca27a54ee29ada3-265e07ea3ca6637f2ccef7ab76549cb63df2cfdd8db00b81cd174fd52b622cae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xinrong Ma")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-477645")[#strong[#text("Xinrong Ma")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2017")])]

#text("Dear Tao, your result is a direct consequence of the Lagrange inversion formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf85d9110fcf3f58415f201544894b333bd96314840f6dabab27bd11c635d6ff-1ec50c3540134aef32c5e45a39b71b5eab3dac30073fdabce4afe3dfe7881826.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/23/another-problem-about-power-series/#comment-481430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2017")])]

#text("When teaching Mathematical Analysis several years ago, I did some research on the Lagrange inversion formula. There are two popular proofs: one is given by Laplace, by using the implicit function theorem; the other one is given by Hermite, by using the Cauchy integral formula. One can find both of them in Goursat’s “A Course in Mathematical Analysis” (yes, I know it has been 113-years-old, but still very good, containing a lot of interesting things).")

#text("However, both of them are not the “best” one, because this formula can appear in Mathematical Analysis I, but both methods use higher knowledges. Finally, I find a “brute force” method, without using any “higher” knowledge: prove Faà di Bruno’s formula first, which is a “Mathematical Analysis I” theorem, and can be proved by induction; then prove the Lagrange inversion formula by using Faà di Bruno’s formula. It is complicated, but doesn’t depend on the implicit function theorem or the Cauchy integral formula or any other knowledges that can not proved in Mathematical Analysis I.")
]
