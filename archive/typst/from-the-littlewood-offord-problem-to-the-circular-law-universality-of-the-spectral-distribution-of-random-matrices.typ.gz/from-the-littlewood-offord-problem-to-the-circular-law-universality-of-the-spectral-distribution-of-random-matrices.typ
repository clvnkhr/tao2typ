// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/
// Converted to Typst by tao2typ: "2026-10-18T11:27:54.472504+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "From the Littlewood-Offord problem to the Circular Law: universality of the spectral distribution of random matrices", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("From the Littlewood-Offord problem to the Circular Law: universality of the spectral distribution of random matrices")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/")[#text("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-18 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our survey paper “")#link("http://arxiv.org/abs/0810.2994")[#text("From the Littlewood-Offord problem to the Circular Law: universality of the spectral distribution of random matrices")]#text("“, submitted to ")#link("http://www.ams.org/bull/")[#text("Bull. Amer. Math. Soc.")]#text(". This survey recaps (avoiding most of the technical details) the recent work of ourselves and others that exploits the inverse theory for the Littlewood-Offord problem (which, roughly speaking, amounts to figuring out what types of random walks exhibit concentration at any given point), and how this leads to bounds on condition numbers, least singular values, and resolvents of random matrices; and then how the latter then leads to universality of the empirical spectral distributions (ESDs) of random matrices, and in particular to the circular law for the ESDs for iid random matrices with zero mean and unit variance (see my ")#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/")[#text("previous blog post")]#text(" on this topic, or my ")#link("https://terrytao.wordpress.com/2008/03/18/lewis-lectures/")[#text("Lewis lectures")]#text("). We conclude by mentioning a few open problems in the subject.")

#text("While this subject does unfortunately contain a large amount of technical theory and detail, every so often we find a very elementary observation that simplifies the work required significantly. One such observation is an identity which we call the ")#emph[#text("negative second moment identity")]#text(", which I would like to discuss here. Let A be an ")#mi("n \\times n")#text(" matrix; for simplicity we assume that the entries are real-valued. Denote the n rows of A by ")#mi("X_1,\\ldots,X_n")#text(", which we view as vectors in ")#mi("{\\Bbb R}^n")#text(". Let ")#mi("\\sigma_1(A) \\geq \\ldots \\geq \\sigma_n(A) \\geq 0")#text(" be the ")#link("http://en.wikipedia.org/wiki/Singular_value")[#text("singular values")]#text(" of A. In our applications, the vectors ")#mi("X_j")#text(" are easily described (e.g. they might be randomly distributed on the discrete cube ")#mi("\\{-1,1\\}^n")#text("), but the distribution of the singular values ")#mi("\\sigma_j(A)")#text(" is much more mysterious, and understanding this distribution is a key objective in this entire theory.")

#text("In general, the relationship between the singular values ")#mi("\\sigma_j(A)")#text(" (which encode spectral information about A) and the rows ")#mi("X_j")#text(" (which encode geometric information about A) are rather complicated. However, there are some simple identities (or “trace formulae”, if you will) that link the two. For instance, by computing the second moment ")#mi("\\text{tr}(A A^*)")#text(" in two different ways, one obtains the ")#emph[#text("second moment identity")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sum_{j=1}^n \\sigma_j(A)^2 = \\sum_{j=1}^n \\left|X_j\\right|^2", block: true)]]

#text("where ")#tao-math("\\left|X_j\\right|", block: false)#text(" denotes the length of ")#mi("X_j")#text(". This simple identity is already enough to get some crude upper bounds on the “average” value of ")#mi("\\sigma_j")#text(", although it does not preclude the possibility that a lot of singular values are very close to zero, or that a few singular values are extremely large.")

#text("The latter scenario (a few very large singular values) can be controlled by higher moment identities, for instance based on the fourth moment ")#mi("\\text{tr}(AA^* AA^*)")#text(". But these moments are not good at controlling the former scenario – when one or more singular values comes close to zero, so that A becomes close to ")#link("http://en.wikipedia.org/wiki/Singular_matrix")[#text("singular")]#text(" (or more precisely, ")#link("http://en.wikipedia.org/wiki/Ill-conditioned")[#text("ill-conditioned")]#text("). For this, we need a different set of identities. One such identity comes from computing the unsigned determinant ")#tao-math("\\left|\\det(A)\\right| = \\det(AA^*)^{1/2}", block: false)#text(" in two different ways, one using the singular values and one using the elementary base-times-height formula for volume of a parallelopiped. This gives the useful identity")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^n \\sigma_j(A) = \\prod_{j=1}^n \\text{dist}(X_j, \\text{span}(X_1,\\ldots,X_{j-1}))")]]

#text("or equivalently (assuming A is non-singular)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{j=1}^n \\log \\sigma_j(A) = \\sum_{j=1}^n \\log \\text{dist}(X_j, \\text{span}(X_1,\\ldots,X_{j-1})).")]]

#text("This identity has some ability to control concentration of singular values near the origin (as the logarithm is large in that region), once one understands the distance between a random vector and a subspace spanned by other random vectors. This is the philosophy used for instance in ")#link("http://front.math.ucdavis.edu/math.CO/0411095")[#text("this paper of mine with Van Vu")]#text("; related ideas also appear in ")#link("http://arxiv.org/abs/math/0703503")[#text("these")]#text(" ")#link("http://arxiv.org/abs/0802.3956")[#text("papers")]#text(" ")#link("http://arxiv.org/abs/0805.3407")[#text("by")]#text(" Rudelson and Vershynin.")

#text("The identity (2) is particularly useful for controlling the least singular value ")#mi("\\sigma_n(A)")#text(", but is not so useful for controlling other low singular values (e.g. ")#mi("\\sigma_{n-k}(A)")#text(" for some moderately small k). For this, we found an alternate identity, based on the ")#emph[#text("negative")]#text(" second moment ")#mi("\\text{tr}( (A^{-1})^* A^{-1} )")#text(". Observe that the ")#mi("j^{th}")#text(" column ")#mi("Y_j")#text(" of ")#mi("A^{-1}")#text(" has an inner product of 1 with ")#mi("X_j")#text(" and is orthogonal to all the other rows of A. A little bit of high school geometry then tells us that the length ")#tao-math("\\left|Y_j\\right|", block: false)#text(" of this column is equal to ")#mi("1 / \\text{dist}( X_j, \\text{span}(X_1,\\ldots,X_{j-1},X_{j+1},\\ldots,X_n) )")#text(". Since ")#mi("\\text{tr}( (A^{-1})^* A^{-1} )")#text(" is equal to both ")#mi("\\sum_{j=1}^n \\sigma_j(A)^{-2}")#text(" and ")#tao-math("\\sum_{j=1}^n \\left|Y_j\\right|^2", block: false)#text(", we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{j=1}^n \\sigma_j(A)^{-2} = \\sum_{j=1}^n \\text{dist}( X_j, \\text{span}(X_1,\\ldots,X_{j-1},X_{j+1},\\ldots,X_n) )^{-2}")]]

#text("(compare with (1) and (2)). We found the identity (3) to be useful for preventing too many singular values of A from clustering near the origin, much as (1) prevents too many singular values of A from becoming extremely large, thus saving us from having to deploy more sophisticated and lengthier methods to control the singular values ")#mi("\\sigma_j(A)")#text(". It may well be that further identities or inequalities of this form may simplify these sorts of arguments further.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/comment-page-1/#comment-33110")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2008")])]

#text("It is not evident that inner product of Y_j with X_j is one. The expectation of the inner product is one, that is for sure. Then it is not clear whether the equalities hold with expectations or not. But if the goal is to make the reader interested in the field, it is achieved perfectly 🙂")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/comment-page-1/#comment-33115")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2008")])]

#text("Oops, there was a typo: ")#mi("Y_j")#text(" is supposed to be the j^th column of ")#mi("A^{-1}")#text(", not the j^th column of A.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/comment-page-1/#comment-33171")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("A power of 2 is missing in the |Y_i| terms in the sentence immediately above equation (3). ")#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/comment-page-1/#comment-33228")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")])]

#text("Four weeks ago you blogged about the “The Princeton Companion to Mathematics” and gave a link to its home page. I enjoyed reading some of the sample chapters given there (I guess I’m gonna buy the book – thanks for bringing it to my attention).")#linebreak()#text(" In the sample chapter about “Numerical Analysis” (")#link("http://press.princeton.edu/chapters/gowers/gowers_IV_21.pdf")[#text("http://press.princeton.edu/chapters/gowers/gowers_IV_21.pdf")]#text("), section 4, the author Lloyd N. Trefethen mentions the still missing theoretical analysis of Gaussian elimination with pivoting. Any chance you can tackle this problem using the techniques from your article?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/comment-page-1/#comment-33234")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")])]

#text("Dear anonymous,")

#text("This is a very nice problem. The recent progress on understanding issues such as the effect of random noise on the invertibility of a matrix does support at a heuristic level the empirically verified observation that Gaussian elimination works very well in the presence of random noise, and may indeed help in giving a rigorous explanation of the latter in the future, but there are still significant technical issues to overcome before this is the case. The basic problem is that even if the original matrix A is described by an additive noise model, e.g. A=M+N where M is deterministic and N is a gaussian random matrix, after a few rounds of Gaussian elimination, the matrix that one gets from A is now given by a much more nonlinear random model, and it is not clear how to use the existing technology to continue to guarantee that this new matrix reacts will to future pivoting operations with high probability. One possibility would be to construct some sort of “invariant measure” for the Gaussian elimination algorithm, but it is not obvious to me how one would build such a measure and be able to ensure that it is not singular, unless some algebraic miracle intervenes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13ccbb4335c056d178ff011a4277b7d83717170211f7b35bb400333292b02894-4257f818ef3a02d50c4ffb700861d84f6f9b90315a4a4c0c059935fdcc63fc74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/comment-page-1/#comment-33263")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2008")])]

#text("dear prof. Tao")

#text("in the bottom of page 9 of the article")#linebreak()#text(" it is written: {(x_1,…,x_d) \\in Z^d | M_i <= m_i <= M^’_i for all 1<=i<=d")

#text("you should replace the m_i with x_i")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/comment-page-1/#comment-33266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2008")])]

#text("Dear anonymous: thanks for the correction! We’ll include it in the next major revision of the article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: The distribution of the smallest singular values « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/comment-page-1/#comment-36305")[#strong[#text("Random matrices: The distribution of the smallest singular values « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("[…] with our earlier paper on the universality of the circular law, we do not attempt to prove (1) for general ensembles such as the Bernoulli ensemble (say) […]")
]
