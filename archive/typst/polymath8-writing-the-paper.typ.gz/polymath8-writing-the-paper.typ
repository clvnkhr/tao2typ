// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/
// Converted to Typst by tao2typ: "2026-10-14T15:18:47.438423+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8: Writing the paper", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8: Writing the paper")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 August 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/")[#text("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The main objectives of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("polymath8 project")]#text(", initiated back in June, were to understand the recent breakthrough ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("paper of Zhang")]#text(" establishing an infinite number of prime gaps bounded by a fixed constant ")#mi("{H}")#text(", and then to lower that value of ")#mi("{H}")#text(" as much as possible. After a large number of refinements, optimisations, and other modifications to Zhang’s method, we have now lowered the value of ")#mi("{H}")#text(" from the initial value of ")#mi("{70,000,000}")#text(" down to (provisionally) ")#mi("{4,680}")#text(", as well as to the slightly worse value of ")#mi("{14,994}")#text(" if one wishes to avoid any reliance on the deep theorems of Deligne on the ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text(".")

#text("As has often been the case with other polymath projects, the pace has settled down subtantially after the initial frenzy of activity; in particular, the values of ")#mi("{H}")#text(" (and other key parameters, such as ")#mi("{k_0}")#text(", ")#mi("{\\varpi}")#text(", and ")#mi("{\\delta}")#text(") have stabilised over the last few weeks. While there may still be a few small improvements in these parameters that can be wrung out of our methods, I think it is safe to say that we have cleared out most of the “low-hanging fruit” (and even some of the “medium-hanging fruit”), which means that it is time to transition to the next phase of the polymath project, namely the writing phase.")

#text("After some discussion at the ")#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/")[#text("previous post")]#text(", we have tentatively decided on writing a single research paper, which contains (in a reasonably self-contained fashion) the details of the strongest result we have (i.e. bounded gaps with ")#mi("{H = 4,680}")#text("), together with some variants, such as the bound ")#mi("{H=14,994}")#text(" that one can obtain without invoking Deligne’s theorems. We can of course also include some discussion as to where further improvements could conceivably arise from these methods, although even if one assumes the most optimistic estimates regarding distribution of the primes, we still do not have any way to get past the barrier of ")#mi("{H=16}")#text(" identified as the limit of this method ")#link("http://arxiv.org/abs/math/0508185")[#text("by Goldston, Pintz, and Yildirim")]#text(". This research paper does not necessarily represent the only output of the polymath8 project; for instance, as part of the polymath8 project the ")#link("http://math.mit.edu/~primegaps/")[#text("admissible tuples page")]#text(" was created, which is a repository of narrow prime tuples which can automatically accept (and verify) new submissions. (At an early stage of the project, it was suggested that we set up a computing challenge for mathematically inclined programmers to try to find the narrowest prime tuples of a given width; it might be worth revisiting this idea now that our value of ")#mi("{k_0}")#text(" has stabilised and the prime tuples page is up and running.) Other potential outputs include additional expository articles, lecture notes, or perhaps the details of a “minimal proof” of bounded gaps between primes that gives a lousy value of ")#mi("{H}")#text(" but with as short and conceptual a proof as possible. But it seems to me that these projects do not need to proceed via the traditional research paper route (perhaps ending up on the blog, on the wiki, or on the admissible tuples page instead). Also, these projects might also benefit from the passage of time to lend a bit of perspective and depth, especially given that there are likely to be further advances in this field from outside of the polymath project.")

#text("I have taken the liberty of setting up a ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/_5Sn7mNN3T")[#text("Dropbox folder")]#text(" containing a ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("skeletal outline")]#text(" of a possible research paper, and anyone who is interested in making significant contributions to the writeup of the paper can contact me to be given write access to that folder. However, I am not firmly wedded to the organisational structure of that paper, and at this stage it is quite easy to move sections around if this would lead to a more readable or more logically organised paper.")

#text("I have tried to structure the paper so that the deepest arguments – the ones which rely on Deligne’s theorems – are placed at the end of the paper, so that a reader who wishes to read and understand a proof of bounded gaps that does not rely on Deligne’s theorems can stop reading about halfway through the paper. I have also moved the top-level structure of the argument (deducing bounded gaps from a Dickson-Hardy-Littlewood claim ")#mi("{DHL[k_0,2]}")#text(", which in turn is established from a Motohashi-Pintz-Zhang distribution estimate ")#mi("{MPZ^{(i)}[\\varpi,\\delta]}")#text(", which is in turn deduced from Type I, Type II, and Type III estimates) to the front of the paper.")

#text("Of course, any feedback on the draft paper is encouraged, even from (or especially from!) readers who have been following this project on a casual basis, as this would be valuable in making sure that the paper is written in as accessible as fashion as possible. (Sometimes it is possible to be so close to a project that one loses some sense of perspective, and does not realise that what one is writing might not necessarily be as clear to other mathematicians as it is to the author.)")

#heading(level: 1)[#text("Comments (150)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-243520")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Seems 630 also survives.")

#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7_630_o.mpl")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7_630_o.mpl")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-243526")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Incorrect. Based on the typo found by Gergely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-243529")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("It is easy to see that the J-th Taylor term for ")#mi("\\exp(x)")#text(" is maximal for ")#mi("J \\approx x")#text(" and decreasing afterwards where the remainder term can easily be estimated analytically.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-243612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("I have created a subpage of the polymath wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath8_grant_acknowledgments")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath8_grant_acknowledgments")]

#text("to hold the contact information and grant acknowledgments of the Polymath8 project participants.")

#text("Of course it is not well defined exactly what a “participant” of the project is, since the level of contribution can vary from being responsible for a significant chunk of the research and writeup to leaving a single blog comment. In the past (and specifically for ")#link("http://michaelnielsen.org/polymath1/index.php?title=%22New_Proof%22_grant_acknowledgments")[#text("Polymath1")]#text(" and ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath4_grant_acknowledgments")[#text("Polymath4")]#text("), what we have done is relied on self-reporting: people who feel that they have made a significant mathematical contribution to the project (of the level commensurate with that of a co-author in a traditional mathematical research paper) can add their own name, contact information, and grant information to the first section of the wiki page. Those who feel that they have made an auxiliary contribution to the project (e.g. stylistic suggestions, locating references, etc. – commensurate with a mention in the Acknowledgments section of a mathematical research paper) – can add their name to the second section of the wiki page. The dividing line between the two categories is necessarily a bit blurry, but in practice it seems that most participants are able to categorise their contributions appropriately.")

#text("Because of spam reasons, new user accounts are not currently enabled on the polymath wiki except through emailing the administrator; if you are unable to add your name to the wiki because of this, email me and I can add your name manually.")

#text("p.s. I plan to roll over this thread to a new one soon, as the number of comments here is getting quite large. We are soon reaching the point where we have draft text for each of the sections of the paper, so we can shortly begin focusing on the proofreading and polishing phases of the writeup.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-243619")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("In the line below (4.53) there is a (plausible – but still unjustified!) claim that a certain sequence is decreasing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8: Writing the paper, II | What's new")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-243641")[#strong[#text("Polymath8: Writing the paper, II | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("[…] main purpose of this post is to roll over the discussion from the previous Polymath8 thread, which has become rather full with comments. As with the previous thread, the main focus on […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-243643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("I’m rolling over the discussion to a new thread. Of course, everyone is welcome to continue any active discussions here if it would not make sense to break up the comment thread, but any fresh discussion should probably move over to the new thread where it would be easier to follow.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be2af8833324863183e543625d6a9b6998ae7008e76ca10cd948348fb9953896-e264b72abced211c5147c522add4690016dbdb930def2b404d11fe0e31ab07b2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cainiaozr")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-248703")[#strong[#text("cainiaozr")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("Reblogged this on ")#link("http://zr9558.wordpress.com/2013/10/22/polymath8-writing-the-paper/")[#text("ZHANG RONG")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5b0bfe2d96285a0efd446bd2c0f527099140d7c74579b5abff92ee26e3db3d2-ae646caa2db2637a475b51671338f2ed54efedbc52fe6bf28bd916e984cc0a6a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marouane rhafli")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-320211")[#strong[#text("marouane rhafli")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2014")])]

#text("hi,")#linebreak()#text(" to solve the twin prime conjecture and to find an algorithm that can find all the consecutive prime numbers you must see the prime number theorem differently , personnaly i see that this theorem is based only on estimations and there is anything exact at 100% , this is what i did and start over to understand the partition of prime in the composite numbers and i developped an algorithm to find them exactly , i also developped Pi(x) that can output the exact numbers of primes into an interval I also proved mathematically the twin prime conjecture and goldbach conjecture , you see this on my blog")#linebreak()#text(" ")#link("http://rhaflimarouane.wordpress.com/")[#text("http://rhaflimarouane.wordpress.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-401507")[#strong[#text("Together and Alone, Closing the Prime Gap | For a better Vietnam")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2014")]

#text("[…] Polymath project has focused lately on writing up its findings in a paper, already over 150 pages, which it has been invited to submit to the journal Algebra & Number […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-414617")[#strong[#text("Terry Tao’s blog and the twin prime conjecture | Actumaths")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2014")]

#text("[…] : they started from 70 000 000 in may, and they reached about 50 000 already by mid-june. Now the bound is down to 4680, and a paper is announced. However they apparently won't be able to get past the barrier of N=16 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b650bf852c8009b4f2ec64191e4b6a4e44091d8981d55715614de1e51aac0e5-14134f09ef15c495c648cee3b0b58ab8545f04553359009f34daab8962b99de3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathematicians Team Up on Twin Primes Conjecture | Simons Foundation | fit2read")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-2/#comment-416732")[#strong[#text("Mathematicians Team Up on Twin Primes Conjecture | Simons Foundation | fit2read")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2014")])]

#text("[…] Polymath project has focused lately onwriting up its findings in a paper, already over 150 pages, which it has been invited to submit to the journal Algebra & Number […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2c4699af39d6e67f42f26e4f37f3764ee24c183deb651e3957ec0129bfcb3ca-7a803e7c9ef94a2af874c1479a84d6eda02163a89803ab17c35b84ba75194a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E.L. Wisty")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242177")[#strong[#text("E.L. Wisty")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("Reblogged this on ")#link("http://jsandber.wordpress.com/2013/08/17/polymath8-writing-the-paper/")[#text("Pink Iguana")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mgflax")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242187")[#strong[#text("mgflax")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("Have you considered “git” (the collaboration tool initially developed by Linus Torvalds for Linux but now in widespread use) instead of dropbox?")

#text("A sample intro is at ")#link("http://www.sharelatex.com/blog/2012/10/16/collaborating-with-latex-and-git.html")[#text("http://www.sharelatex.com/blog/2012/10/16/collaborating-with-latex-and-git.html")]#text(" and some best-practices are at stackoverflow.com/questions/6188780/git-latex-workflow. Also, dropbox.com is free as long as all documents are publically-readable.")

#text("It works very well for text-based files (e.g. .tex files). Each participant would create their own (free) repository on github, and any participant could “pull” updates from any other repository. But I’d assume you’d have a “hub-and-spokes” model where you would pull contributions from other participants and then everyone would pull updates from your repository.")

#text("github even has built-in mechanisms so participants could notify you that there are changes in their repository that you should pull, and lots of similar workflow tools.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242191")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("The conclusion of theorem 2.6 is missing.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242196")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("[I just posted this in reply to Eytan’s comment ")#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242193")[#text("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242193")]#text(" on achieving k0=631 but then noticed that the page has now been marked inactive, so I’m reposting here; my apologies if that is contrary to convention.]")

#text("Thank you Eytan. I’m also wondering whether the current Deligne-avoiding k0 of 1788 can be nudged down, though of course this is of more marginal interest to most observers than the headline 632 value.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242205")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("For the Deligne-avoiding case, seems ")#mi("k_0")#text(" might be pushed down to 1783 (")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_1783__.mpl")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_1783__.mpl")]#text("), if there is no error in my implementation.")

#emph[#text("[Paper updated to reflect this improved numerology – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2013")])]

#text("Af the very end of page 1, “")#mi("H = 14994")#text("” should be “")#mi("H = 14950")#text("”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242207")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("Thank you xfxie. I can’t resist noting the entirely gratuitous but possibly amusing fact that if that value holds up, the product of the headline and Deligne-avoiding values of H then creeps below Zhang’s original value! Even 1784 would fail to achieve this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242361")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2013")])]

#text("Actually, on perusing the current draft of the paper, I’ve noticed that even though a whole section is proposed that focuses on computational methods for finding optimal or near-optimal values of H for a given k0, there is not obviously any equivalent intention to include explicit descriptions of methods to find optimal or near-optimal values of k0 for a given (varpi,delta), such as those currently implemented by xfxie. It seems to me that these methods are sufficiently subtle that at least a brief discussion of them in the paper is merited, rather than merely a note that “one may almost pretend that delta vanishes entirely”; apologies if I have misunderstood and this is indeed already intended. In particular, xfxie, I’m interested to understand whether the ideas recently described by Eytan for attempting to reach a k0 of 631 or 630 are in fact encompassed by what your algorithm already does, or whether there is scope for further refinement of these optimisation methods.")

#emph[#text("[Good idea; I’ve added a subsection for this. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242363")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2013")])]

#text("I’ve just discovered the real obstruction for further reducing ")#mi("k_0")#text(" to ")#mi("631")#text(" or ")#mi("630")#text(": In order to make ")#mi("\\epsilon")#text(" positive,")#linebreak()#text(" ")#mi("\\delta")#text(" must be sufficiently reduced (which cause the current upper bound on ")#mi("\\kappa_3")#text(" to grow “too much” – as I found by analyzing its asymptotic dependence on ")#mi("\\delta")#text(") – so to compensate this growth one needs to reduce the G-ratio by decreasing ")#mi("\\delta^{\\prime}")#text(" – but this would cause the upper bound on ")#mi("\\kappa_1")#text(" to increase “too much” !")#linebreak()#text(" It seems that the only way out of this is to improve the upper bound on")#linebreak()#text(" ")#mi("\\kappa 3")#text(" (and, in particular, its asymptotic dependence on small")#linebreak()#text(" ")#mi("\\delta")#text(" – I’m working on it now!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242524")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2013")])]

#text("It would be my pleasure to help some with the subsection “Optimizing the parameters”.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242284")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2013")])]

#text("In the second column of table 2, ")#mi("\\delta")#text(" should be ")#mi("10^{-4}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3947db16505b0ca97e0bf34809ff93ed4f157191457c478aea86ed3f2c52aeb1-93302a4d2cfdc09e653a169f1998054a97a6051c5a6b9f42a74271089371a1b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Hilferty")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242298")[#strong[#text("James Hilferty")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2013")])]

#text("Your last paragraph is all too true; as sometimes you can’t see the wood for the trees; so could you give a hint as to what you are all trying to achieve? I am really only interested in financial maths and am not much good at anything else. However in my domain the fact that exponential (e) is to the wrong power no longer matters since real interest rates (for the financial institutions) is zero; (e) times zero = 1 so the real world is just as mad as the formula. Is this true?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d7430a92e296d15b4884017512dfd7fa6161d95b7fc1f020e526c02c34f14e-14516df62414d1a7d8f571de3397d04e486312b380a84655ddd861288d0895d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cancer_doctor")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242304")[#strong[#text("Cancer_doctor")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2013")])]

#text("What these brilliant mathematicians are trying to do is solve a 3000 year-old problem which is to prove that no matter how high up in the numbers you look you will always find some twin primes. Primes are whole numbers that are exactly divisible only by themselves and one; an example is “13.” Twin primes are primes separated by 2 as in 11 and 13, or 17 and 19.")

#text("The “twin prime conjecture” is so difficult that no real progress was made in solving it until about 6 months ago when an unknown mathematician made a huge start by using a great deal of abstract mathematics developed in the 20th century. These gentlemen, some of the finest minds in the world by the way, are trying to understand that paper on a deep level and improve on it, which they certainly have done. My opinion is that understanding why such a simply stated problem is so enormously hard to prove is the real work that is being done here. Perhaps we, the human race, are ignorant of some terribly important branch of mathematics, or it may be that some seemingly “simple” problems require immense complexity to explain. Perhaps these gentlemen will find out.")

#text("With regard to your question about (e) times zero, any (finite) number times zero is zero, not 1. What you probably meant was (e) to the zeroth power, an entirely different thing, which is, indeed, 1. Even simple business math like computing compound interest would not work correctly without knowing this. Fortunately for us, mathematicians hundreds of years ago did all that hard work for us, just as these mathematicians are doing for future generations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242326")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2013")])]

#text("I’ll be travelling for the next few days, but hope to finish up a draft version of Section 2 (which lists the key subclaims needed to get bounded gaps between primes, and the connections between them) soon. I don’t plan to touch other sections of the paper yet (not that there is much content to any of them at this stage).")

#text("One organisational issue regards how to deal with the van der Corput estimates. There are two places where we use a van der Corput bound: firstly for the “Deligne-free” Type I estimates (and also the Type II estimates), where we have to bound sums of the form")

#mi("\\sum_n \\psi_N(n) e_q( f(n) )")#text(" (1)")

#text("for some smooth modulus ")#mi("q")#text(", some rational function ")#mi("f(n)")#text(" and some smooth cutoff ")#mi("\\psi_N")#text(". These sums are bounded by a combination of the q-van der Corput A-process of Heath-Brown and Graham-Ringrose, the completion of sums method, and the Weil conjectures for curves. Details can be found in Section 1 of ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")]#text(" .")

#text("But then for the improved Type I estimates we use the van der Corput bounds again for sums of the form")

#mi("\\sum_n \\psi_N(n) K(n)")#text(" (2)")

#text("where ")#mi("K")#text(" is a Kloosterman-type sum, ")#mi("K(n) = \\frac{1}{\\sqrt{q}} \\sum_{m \\in {\\bf Z}/q{\\bf Z}} e_q( f(n,m) )")#text(" for some rational function ")#mi("f")#text(" of two variables. These sums are estimated by the same methods as the previous sums, but with the Weil conjectures for curves replaced by Deligne’s “Weil II” theorem on trace weights. Details can be found in Sections 2 and 3 of ")#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/")[#text("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/")]#text(" .")

#text("Strictly speaking, the estimation of the sums (1) are a special case of the estimation of the sums (2), so we could prove the stronger statement about estimation of (2) first and then obtain (1) as a special case. But this would make it more difficult to disentangle which results relied on Deligne’s theorems and which ones did not. Another approach is an axiomatic one (which I tried to set up in the previous post), in which one posits a class of “structured functions” obeying some axioms, proves an abstract van der Corput result for such structured functions, and then specialises to the class of rational phases to prove (1) and then to the class of trace weights to prove (2). A third approach would be to prove (1) directly, and then repeat the arguments to prove (2); this would lead to a slightly longer text but it may be clearer to follow, particularly if we encapsulate all the properties about trace weights that we need for (2) into a single proposition, and if we make the proof of (2) resemble the proof of (1) as much as possible. I’m now inclined towards the final method (even though I was initially disposed to the axiomatic approach), but perhaps others may have opinions on this point as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242375")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2013")])]

#text("Regarding the paper: If you are interested, I can typeset the tables properly for you; I really don’t like how they look now. (On a second note, the ")#mi("\\sim")#text(" in the web address is missing.)")

#emph[#text("[Tilde added. If you would like to contribute, let me know and I can give edit access to the Dropbox. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242526")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2013")])]

#text("@Terry: I’m not a mathematician (just interested in math) so I don’t understand the details in the paper at all; I use LaTeX and just saw that the tables are not very well typeset.")

#text("With that said, I have now typeset the two tables in a seperate document so I can either send it to you by mail or you can give me edit access so that I can put it in the Dropbox folder myself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2013")])]

#text("@Terry: Files “tables.tex” and “tables.pdf” added to folder.")

#emph[#text("[New version of tables implemented, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242426")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2013")])]

#text("A couple of comments (some of them may be too editorial for this early stage, so please ignore accordingly):")#linebreak()#text(" * in the abstract: ")#mi("p_{n+1}, p_n")#text(" –> ")#mi("p_n, p_{n+1}")#linebreak()#text(" * statement of Theorem 1.3: ")#mi("H := 4680")#text(" –> ")#mi("H = 4680")#linebreak()#text(" * section 2.1: (and hence ")#mi("B[H]")#text(" –> brackets don’t close")#linebreak()#text(" * section 2.1, definition of discrepancy, shouldn’t there be a premise of the kind “whenever the sums converge.”?")#linebreak()#text(" * statement of Theorem 2.6: there’s an “11” at the end")#linebreak()#text(" * statement of Claim 2.8: what’s ")#mi("\\theta")#text(" here? should it be recalled that ")#mi("\\theta = \\frac{1}{2} + 2\\varpi")#text("?")#linebreak()#text(" * discussion following Theorem 2.10: “maybe work out exactly what this gives” –> I found the value ")#mi("k_0 = 34429")#text(" (a value which we encountered before; the contribution of $\\kappa_1$ and $\\kappa_2$ is negligible in this region), but maybe this should be double-checked")#linebreak()#text(" * same discussion: ")#mi("\\text{EH}[\\frac{1}{4} + 2\\varpi]")#text(" –> ")#mi("\\text{EH}[\\frac{1}{2} + 2\\varpi]")#linebreak()#text(" * same discussion: I didn’t fully grasp the last phrase about the tradeoff")

#emph[#text("[Corrections implemented, thanks – T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242440")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2013")])]

#text("I would vote to include 34429 and one other representative value of ")#mi("k_0")#text(" between 1783 and 34429, say 5453, in Table 1. In section 3 (which I am working on now) I plan to include a small portion of the benchmark table ")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_narrow_admissible_tuples#Benchmarks")[#text("http://michaelnielsen.org/polymath1/index.php?title=Finding_narrow_admissible_tuples#Benchmarks")]#text(", and it would be helpful to have a few ")#mi("k_0")#text(" values between 1783 and 181000.")

#emph[#text("[I’ve added 34429 to the table; feel free to make further additions, as I will not be making many edits in the next two or three days. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242430")[#strong[#text("Welcome Back! | OU Math Club")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2013")]

#text("[…] This has been a polymath project and they are now in the stage of writing up their calculations. You can read all about it on Dr. Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242654")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2013")])]

#text("In the third column of table 2, the exponent of ")#mi("\\delta")#text(" should be ")#mi("-5")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242719")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("The two lines below table 1 should belong to theorem 2.3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242724")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("Hmm, actually they are already part of that theorem; LaTeX for some reason automatically placed the table within the statement of the theorem. It may be that this problem will sort itself out as the paper evolves. (I think right now, tables are placed at the top of a page, which limits the ability to move them around.)")

#text("Speaking of this table: I have added some new values of ")#mi("k_0")#text(" to this table, arising from the theoretical best possible values of ")#mi("k_0")#text(" for selected values of ")#mi("\\varpi")#text(" arising both from the Bessel-function cutoff and the older GPY polynomial cutoff, namely ")#mi("k_0 = 6,7")#text(" (for the best possible ")#mi("\\varpi=1/4")#text("), ")#mi("k_0 = 630, 3461")#text(" (for ")#mi("\\varpi = 6/700")#text(", our best value), ")#mi("k_0 = 1781, 7140")#text(" (for ")#mi("\\varpi=1/168")#text(", the best Deligne-free value), and ")#mi("k_0 = 34429, 341640")#text(" (for ")#mi("\\varpi=1/1168")#text("; these values were in fact encountered early in the polymath project). This seems to give reasonably good coverage of the various orders of magnitude, although I don’t actually have tuples data for ")#mi("k_0=7140")#text(" and ")#mi("k_0 = 341640")#text(" yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242726")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("For 7140, I can get 69280.")

#link("http://www.cs.cmu.edu/~xfxie/project/admissible/admissible_7140_69280_4678.txt")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/admissible_7140_69280_4678.txt")]

#text("For 341640, seems the memory usage need to be optimized in my current code.")

#emph[#text("[Added, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("By the way, thanks for starting the optimization section; I linked your new file optimize.tex to the current file gpy.tex so that they can both go into the PDF while being edited separately, as I am starting to work on the latter file (having almost finished the work on subtheorems.tex).")

#text("One other thing: if your optimization routines are available, would it be possible to see what the best value of ")#mi("k_0")#text(" one can deduce from the best known constraint ")#mi("600 \\varpi + 180 \\delta < 7")#text(" if one had to use the older implication ")#mi("MPZ[\\varpi,\\delta] \\implies DHL[k_0,2]")#text(" in which ")#mi("\\delta^{\\prime}=\\delta")#text(", i.e. Theorem 6 of ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")]#text(" ? I think it would be good to illustrate how much of a gain the more complicated implication (with ")#mi("\\delta^{\\prime}, \\tilde\\theta, A")#text(", etc.) gives.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242741")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("If still use ")#mi("i=4")#text(", ")#mi("k_0=776")#text(" can be obtained.")

#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_776.mpl")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_776.mpl")]

#text("Please check if the setting is OK.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("Thanks! Actually in the ")#mi("\\delta=\\delta^{\\prime}")#text(" case, the quantity ")#mi("e")#text(" (and hence ")#mi("\\kappa_3")#text(") should vanish and ")#mi("A, \\tilde \\theta, i")#text(" should be irrelevant; there seems to be some little glitch in the maple code that doesn’t see this, but I redid the calculations without ")#mi("\\kappa_3")#text(" and they are of course fine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242751")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("Actually, I was also confused about the realization of ")#mi("e")#text(". Here I copy the latex description in Theorem 2.13.")

#mi("e = \\exp\\left(A + (k_0-1) \\int_{\\tilde \\delta}^\\theta e^{-(A+2\\alpha)t}\\ \\frac{dt}{t}\\right)")

#text("If ")#mi("\\delta=\\delta^{\\prime}")#text(", then ")#mi("\\tilde \\delta = \\theta")#text(", which means the integration term is 0. Then it seems ")#mi("e=\\exp\\left(A\\right)")#text(", which leads to ")#mi("\\kappa_3 \\ne 0")#text(".")

#text("This is quite strange. So I checked the original blog:")#linebreak()#text(" ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")]#text(". In Theorem 5, ")#mi("\\kappa_3")#text(" is still 0 if ")#mi("\\delta=\\delta^{\\prime}")#text(". But afterward, ")#mi("e")#text(" has been replaced by a new upper bound ")#mi("e = \\exp\\left(A + (k_0-1) \\int_{\\tilde \\delta}^\\theta e^{-(A)t}\\ \\frac{dt}{t}\\right)")#text(", which is no longer 0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242759")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("Ah, that explains what was going on. I guess this is confirming Eytan’s suspicions that our estimation of ")#mi("\\kappa_3")#text(" is not entirely efficient…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242727")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("For 341,640 the records page lists 4,656,298 (but I’m sure this can be improved).")

#emph[#text("[Added, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242723")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("Table 1 should be located just before section 2.1 and table 3 just before section 2.2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242729")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("Now Table 1 should be just before sec. 2.2 and table 3 just before sec. 2.3.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242753")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("Some remarks on the optimization problem:")

#text("The optimization problem (for each choice of ")#mi("k_0")#text(") can be formulated in terms of ")#mi("\\delta, \\delta^{\\prime}")#text(" alone (as the “free” parameters), since optimal ")#mi("\\varpi")#text(" and ")#mi("A")#text(" are explicitly determined by given ")#mi("k_0, \\delta, \\delta^{\\prime}")#text(" as follows:")

#text("1. In order to maximize ")#mi("\\epsilon - \\epsilon_2")#text(" (to check if it can be made positive), we see that its maximization with respect to ")#mi("\\varpi")#text(" gives the supremum of ")#mi("\\varpi")#text(" with respect to its constraints (the supremum is allowed since the criterion is based on strict inequality!) which gives optimal ")#mi("\\varpi")#text(" for the maximization of ")#mi("\\epsilon")#text(".")

#text("2. Order to optimize A, we need to minimize ")#mi("\\epsilon_2")#text(" or to minimize the exponent in the bound for ")#mi("\\kappa_3")#text(" for ")#mi("A > 0")#text(" .Denote this exponent by ")#mi("\\psi(A)")#text(". It follows (by differentiating under the integral sign) that")

#mi("\\psi^{\\prime}(A) =  1-[exp(-(A+2\\alpha)\\tilde{\\delta})-exp(-(A+2\\alpha)\\theta)]/(A+2\\alpha)")

#text("and ")#mi("\\psi^{\\prime\\prime} > 0")#text(" on ")#mi("[0, \\infty)")#text(" (hence ")#mi("\\psi^{\\prime}")#text(" is strictly increasing on ")#mi("[0, \\infty)")#text(" and tending to ")#mi("1")#text(" as ")#mi("A \\rightarrow \\infty")#text(". Consider the two cases:")

#text("(i) ")#mi("\\psi^{\\prime}(0) \\geq 0")#text(": In this case (since ")#mi("\\psi^{\\prime}")#text(" is increasing) the optimal A is 0.")

#text("(ii) ")#mi("\\psi^{\\prime}(0) < 0")#text(": In this case the optimal A is the (unique) positive A for which psi'(A) = 0.")#linebreak()#text(" Since ")#mi("\\psi^{\\prime\\prime\\prime} < 0")#text(" on ")#mi("[0, \\infty)")#text(", as can be verified by differentiating under the integral sign, it follows from the concavity of ")#mi("\\psi^{\\prime}")#text(" that Newton iteration for the positive root of ")#mi("/psi^{\\prime}(A)")#text(" should converge (very fast) to the optimal ")#mi("A")#text(" when starting with initial $A = 0$.")

#text("Remark: It seems that the simpler iteration")

#mi("x_{k+1} = (k_0 - 1) [exp(-\\tilde{\\delta}x_k) - exp(-\\theta x_k)]")

#text("with initialization ")#mi("x_0 = k_0-1")#text(" is converging (linearly) to the optimal value of ")#mi("A+2\\alpha")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242778")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2013")])]

#text("On simple and very good approximation of ")#mi("k_0^*(\\varpi)")#text(":")

#text("Let ")#mi("g(\\nu) := j_{\\nu}^2/[(\\nu +1)(\\nu +2)] -1")#text(" for ")#mi("\\nu > 0")#text(".")#linebreak()#text(" (")#mi("\\nu")#text(" which can be any positive number plays the role of ")#mi("k_0 -2")#text(")")

#text("Since ")#mi("j_{\\nu} = \\nu + O(\\nu ^{1/3})")#text(", it follows that")#linebreak()#text(" ")#mi("g(\\nu) \\rightarrow 0")#text(" as ")#mi("\\nu \\rightarrow \\infty")#text(". Moreover, g is strictly decreasing (the proof, to be posted later, depends on a differential equation satisfied by ")#mi("j_{\\nu}")#text(") – implying that ")#mi("k_0^*(\\varpi)")#text(" (defined as the minimal positive integer ")#mi("k")#text(" for which ")#mi("g(k - 2) < 4\\varpi")#text(") is uniquely determined as the smallest integer greater than ")#mi("\\nu(\\varpi) +2")#text(" where ")#mi("\\nu(\\varpi)")#text(" is defined for each ")#mi("\\varpi \\in (0, 1/4)")#text(" as the unique positive ")#mi("\\nu")#text(" satisfying")#linebreak()#text(" ")#mi("g(\\nu) = 4\\varpi")#text(".")

#text("Using the asymptotic expansion")

#mi("j_{\\nu} = \\nu + \\alpha_1 \\nu^{1/3}  + \\alpha_2 \\nu^{-1/3} +O(1/nu)")

#text("Where ")#mi("\\alpha_1 = 1.855757081...")#text(" is the first positive zero of")#linebreak()#text(" ")#mi("Ai(-2^{1/3} x)")#text(" and ")#mi("\\alpha_2 = 0.3 \\alpha_1^2")#text(".")

#text("It follows that ")#mi("\\nu(\\varpi) = P(\\varpi ^{-1/2}) + O(\\varpi ^{1/2})")

#text("Where ")#mi("P(.)")#text(" is a third degree polynomial")

#mi("P(x) = c_0 + c_1 x + c_2 x^2 + c_3 x^3")#text(", where")

#mi("c_0 = -2.7 + (27/16) \\alpha_1^{-3} = -2.964046...")

#mi("c_1 = (\\alpha_1 /2)^{1/2} [1.2 \\alpha_1 -  (27/32) \\alpha_1^{-2}] = 1.909099...")

#mi("c_2 = -1.125")

#mi("c_3 = (\\alpha_1 /2)^{3/2} = 0.8937924...")

#text("It follows that a very good approximation for ")#mi("k_0^*(\\varpi)")#text(" is given by")

#mi("\\lceil P(\\varpi ^{-1/2}) +2 \\rceil")

#text("Examples: ")#mi("\\varpi = 7/600")#text(" gives ")#mi("k_0 = 630")#linebreak()#text(" ")#mi("\\varpi = 1/1168")#text(" gives ")#mi("k_0 = 34429")

#text("This surprisingly good approximating accuracy can be explained by explicit error bounds (to be posted later). It should be remarked that the accuracy should becomes better for larger ")#mi("k_0")#text(" (the approximation error is typically 0 or 1.)")

#emph[#text("[I added a footnote about this to the paper, though I only stated the leading order term explicitly – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242816")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("The last two lines in Table 3 do not agree with my SAGE calculations. For ")#mi("k_0=632")#text(" I get ")#mi("\\kappa_3\\approx 7.018\\times 10^{-8}")#text(" and ")#mi("1-\\frac{j_{k_0-2}^2}{k_0(k_0-1)(1+4\\varpi)}\\approx 1.681\\times 10^{-6}")#text(". For ")#mi("k_0=1783")#text(" I get ")#mi("\\kappa_3\\approx 5.753\\times 10^{-14}")#text(" and ")#mi("1-\\frac{j_{k_0-2}^2}{k_0(k_0-1)(1+4\\varpi)}\\approx 3.666\\times 10^{-6}")#text(".")

#text("The discrepancy probably comes from different values for ")#mi("j_{k_0-2}")#text(". I am using 100-bit precision in SAGE and the precise value for ")#mi("j_{k_0-2}")#text(", not an approximation. I get ")#mi("j_{630}\\approx 646.02920741")#text(" and ")#mi("j_{1781}\\approx 1803.57970070")#text(". Can you please double check these values? I copy some minimal SAGE code below.")

#text("R = RealField(100); R")#linebreak()#text(" k=632")#linebreak()#text(" print R(find_root(Bessel(k-2, typ=’J’),k,k+2*k^(1/3)))")#linebreak()#text(" k=1783")#linebreak()#text(" print R(find_root(Bessel(k-2, typ=’J’),k,k+2*k^(1/3)))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242820")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("I also think that in the second column we should have ")#mi("k_0^*=1783")#text(", because ")#mi("k_0=1782")#text(" yields ")#mi("1+4\\varpi<\\frac{j_{k_0-2}^2}{k_0(k_0-1)}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242834")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("In Maple 16, k0*=1781")

#text("BTW: j_1779 = 1801.571309")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242840")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("xfxie is right, I take this last comment (about ")#mi("k_0^*")#text(") back. For some reason I did not work with ")#mi("\\varpi=1/168")#text(" but with the value decreased by the final value of ")#mi("\\delta")#text(". So ")#mi("k_0^*=1781")#text(" as in the paper. My original comments of 8:56am remain unchanged.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242828")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("Similar results in Maple 16:")

#text("j_630=646.0292074, j_1781=1803.579701")

#text("For the last line: 1.6812E-6, 3.6654E-6")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242843")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("Good catch! I think I sometimes confuse Maple when cut-and-pasting code repeatedly, but I am now getting essentially the same results as you and xfxie here, and have updated the table accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242854")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("Indeed my mistake at 9:24am was due to copy+paste in SAGE…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242831")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("In the proof of theorem 2.14, the upper bound for ")#mi("\\kappa_3")#text(" should be updated to the current bound (with the exponent ")#mi("-(A+2\\alpha)t")#text(" in the integrand) – by using the current bound for ")#mi("G_{k_0 -1}(\\sum t_j, \\sum t_j)")#text(".")#linebreak()#text(" (which is based on the sub-multiplicative property of f and its log-concavity.)")

#emph[#text("[Oops, I had forgotten about this improvement! I think it is fixed now. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242850")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("In the proof of lemma 4.6, it should be ")#mi("-\\alpha")#text(" (instead of ")#mi("\\alpha")#text(") -two places.")

#emph[#text("[Fixed, thanks. I also realised that ")#mi("\\alpha")#text(" was used for two different things in this section, so I changed ")#mi("\\alpha")#text(" here to ")#mi("\\eta")#text(". -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242856")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("In the proof of theorem 2.14, I think that the definition of ")#mi("\\tilde{\\theta}_\\epsilon")#text(" should be dependent on i.")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242857")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("This is not really important, but a slightly cleaner set of parameters for the second column of Table 3 would be ")#mi("\\delta=10^{-5}")#text(", ")#mi("\\delta^{\\prime}=1/300")#text(", ")#mi("A=800")#text(". Then ")#mi("\\varpi\\approx 0.005950")#text(", ")#mi("\\alpha\\approx 456.4")#text(", ")#mi("\\theta\\approx 1.302\\times 10^{-2}")#text(", ")#mi("\\tilde\\theta\\approx 3.625\\times 10^{-2}")#text(", ")#mi("\\tilde\\delta\\approx 3.907\\times 10^{-5}")#text(". Finally, ")#mi("\\kappa_1\\approx 6.662\\times 10^{-7}")#text(", ")#mi("\\kappa_2\\approx 5.209\\times 10^{-9}")#text(", ")#mi("\\kappa_3\\approx 8.340\\times 10^{-47}")#text(", and ")#mi("1-\\frac{j_{k_0-2}^2}{k_0(k_0-1)(1+4\\varpi)}\\approx 6.177\\times 10^{-6}")#text(".")

#emph[#text("[Replaced, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242901")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("Thanks for updating the table! Can you please double check the value of ")#mi("\\kappa_3")#text(" in the first column? SAGE gives me ")#mi("\\kappa_3\\approx 7.0183583762\\times 10^{-8}")#text(" which differs from the given value in the third decimal. The Bessel zero is ")#mi("\\approx 646.02920741")#text(", while ")#mi("\\int_{\\tilde\\delta}^{\\theta}e^{-(A+2\\eta)\\frac{dt}{t}}\\approx 1.2111159453")#text(" with the SAGE command")

#text("print R(numerical_integral(exp(-(A+2*alpha)*t)/t, deltat, theta, eps_abs=1e-20, eps_rel=1e-10)[0])")

#emph[#text("[I didn’t verify this yet, but I put in your corrected version. I was using the off-the-shelf Maple numerical integration which may have had some trouble with precision here. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242907")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("It is possible to check the accuracy of the numerical integration for this integral by expressing it in terms of the exponential integral function E_1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242909")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("SAGE and Mathematica agree (after increased precision) on 16 decimal digits: ")#mi("\\int_{\\tilde\\delta}^{\\theta}e^{-(A+2\\eta)t}\\frac{dt}{t}\\approx 1.2111159452885857")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242912")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("Thanks for suggesting the exponential integral function ")#mi("E_1(z)")#text(". With it we can express the integral as ")#mi("E_1((A+2\\eta)\\tilde\\delta)-E_1((A+2\\eta)\\theta)")#text(", and now SAGE and Mathematica agree on 27 digits (I could not get more digits from Mathematica): ")#mi("\\int_{\\tilde\\delta}^{\\theta}e^{-(A+2\\eta)t}\\frac{dt}{t}\\approx 1.211115945288585665108467030")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242936")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("Not sure if this helps but ")#link("http://mpmath.googlecode.com/svn/trunk/doc/build/functions/expintegrals.html#e1")[#text("http://mpmath.googlecode.com/svn/trunk/doc/build/functions/expintegrals.html#e1")]#text(" is available from mpmath on python.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242865")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2013")])]

#text("I have updated the file subtheorems.tex in the Dropbox folder to get the correct alignment in the tables. (I haven’t compiled so nothing is changed in the PDF file yet.)")

#emph[#text("[Thanks! There was an issue with the \\frac{}{}’s not compiling, but I put dollar signs around them and it works OK now. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("Regarding table 2: I think the readability will improve if one used “")#mi("a/b")#text("” instead of “")#mi("\\frac{a}{b}")#text("” (as done for the ")#mi("\\delta^{\\prime}")#text(" parameter in table 3).")

#emph[#text("[Changed, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242896")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("Another comment: If the package hyperref is loaded (as the last package!), one can use “\\url{http://math.mit.edu/~primegaps/tuples/admissible_632_4680.txt}” to get a proper tilde. Furthermore, with hyperref, all the references in the document become interactive.")

#emph[#text("[Ah, nice! I had previously had problems with hyperref but I found out that this was because some of the .aux files I had were built without hyperref leading to some weird conflict. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242905")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("Remarks for the optimization of parameters:")

#text("1. In the reduced model (4.55), the parameter ")#mi("A")#text(" still appears as a “free” parameter, while it can easily be made dependent on ")#mi("\\delta ,\\delta_d")#text(" (as described in my previous comment above – with a very simple and fast iteration to find it) – reducing the search space to only two parameters.")

#text("2. In the last line of table 4, the values of ")#mi("\\delta, \\delta^{\\prime} , A")#text(" are seemingly their current values (before optimization!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242917")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("Thanks for the remarks.")

#text("1. will add some text about the dependence property.")

#text("BTW: I will try to implement this improvement if we want a full description. (Assuming the policy that the methods that we described should at least have been actually implemented and tested before the paper is finished).")

#text("2. Changed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242935")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("More comments:")

#text("1. The integral in the upper bound for ")#mi("\\kappa_3")#text(" is almost independent on ")#mi("\\theta")#text(". More precisely, this integral is expressible in terms of the exponential integral function ")#mi("E_1")#text(" (see Gergely’s comment above), so in the cost function this integral may be approximated (from above) by")#linebreak()#text(" ")#mi("E_1[(A+2\\eta) \\tilde{\\delta}]")#text(" (i.e. the upper bound for ")#mi("\\kappa_3")#text(" is increased very slightly – as well as the resulting cost function.)")#linebreak()#text(" For this modified cost function, the optimal value of ")#mi("A+2\\eta")#text(" is determined as the (unique) root in ")#mi("(2\\eta, \\infty)")#text(" of the equation")

#mi("x = (k_0 - 1)\\exp(-\\tilde{\\delta}x)")

#text("(which follows from case (ii) of my comment above.)")

#text("It seems (still without proof) that this root can be found by iterating this equation starting with ")#mi("x_0 = k_0 -1")#text(" (probably, the proof has to show that this iteration is a contraction map from ")#mi("(2\\eta, \\infty)")#text(" into itself.)")

#text("2. It follows that the optimal ")#mi("A+2\\eta")#text(" is close (from below) to")#linebreak()#text(" ")#mi("k_0 -1")#text(" (which initialize the iteration above.)")

#text("3. Since (in practice) ")#mi("k_0 \\tilde{\\delta} \\ll 1")#text(" we can use (5.1.11) in A&S to get the following upper bound for ")#mi("E_1[(A+2\\eta) \\tilde{\\delta}]")

#mi("E_1[\\xi] < -\\log (\\xi)- \\gamma - \\sum_{n=1}^3 (-\\xi)^n /(n n!)")

#text("Where ")#mi("\\xi = (A+2\\eta) \\tilde{\\delta}")#text(" and ")#mi("\\gamma")#text(" is Euler's constant.")

#text("Note that this bound shows that for sufficiently small ")#mi("\\delta")#text(", the upper bound on ")#mi("\\kappa_3")#text(" is roughly proportional to ")#mi("\\delta^{1-k_0}")#text(" – so any reduction of ")#mi("delta")#text(" must be compensated by reducing the G-ratio factor (of Bessel functions) in the ")#mi("\\kappa_3")#text(" bound (by appropriate reduction of ")#mi("\\delta^{\\prime}")#text(") – which unfortunately should increase the ")#mi("\\kappa_1")#text(" bound! (this shows the trade-off during the optimization of ")#mi("\\delta")#text(" and ")#mi("\\delta^{\\prime}")#text(" !)")

#text("5. In order to get a truly unconstrained optimization, I suggest to represent ")#mi("\\delta")#text(" in an interval ")#mi("(0, delta_0]")#text(" as ")#mi("\\delta_0 / \\exp(x^2)")#text(" – where ")#mi("x")#text(" is the new parameter (this has the added advantage that the order of magnitude of ")#mi("x")#text(" remains near 1) and similarly for")#linebreak()#text(" ")#mi("\\delta_d")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242950")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("It is a good idea to use the ")#mi("A")#text(" you indicate when performing an exhaustive search. Note that symbolic software packages can quickly and reliably solve the equation ")#mi("x = (k_0 - 1)\\exp(-\\tilde{\\delta}x)")#text(", just as they can find the relevant Bessel root, so in practice there is no need to analyze the equation and its (unique) solution further.")

#text("For example, in SAGE one can use the command")

#text("A=find_root(x==(k-1)*exp(-deltat*x),0,k-1)-2*eta")

#text("This would tell that that in Table 3, keeping the indicated values ")#mi("\\delta")#text(" and ")#mi("\\delta^{\\prime}")#text(", the optimal ")#mi("A")#text(" would be ")#mi("\\approx 187.00914827")#text(" (resp. ")#mi("\\approx 756.76525551")#text("), yielding ")#mi("\\kappa_3\\approx 5.792\\times 10^{-8}")#text(" (resp. ")#mi("\\kappa_3\\approx 4.640\\times 10^{-47}")#text(").")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242958")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("I just did this with Mathematica (but with the maximal ")#mi("\\varpi")#text(" as determined by ")#mi("\\delta")#text(") which gives ")#mi("A = 187.009144...")#text(" – which gives almost the same ")#mi("\\kappa_3")#text(" as for ")#mi("A = 187")#text(" and about ")#mi("17.5%")#text(" reduction in the value of ")#mi("\\kappa_3")#text(" (relative to ")#mi("\\kappa_3")#text(" with the original ")#mi("A = 200")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242959")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("I meant ")#mi("17.5")#text(" % reduction in the value of ")#mi("\\kappa_3")#text(" (latex eliminates the % symbol.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242966")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("@Eytan: For Table 3 I recommended round values of ")#mi("\\delta,\\delta^{\\prime},A")#text(" for expository purposes. They were not meant to be optimal in any sense except that they were good enough to provide the smallest admissible value of ")#mi("k_0")#text(" (as far as we know it).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242969")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("I agree that in table 3, ")#mi("\\delta, \\delta^{\\prime}, A")#text(" may have “rounded” values, (provided that they are compatible with ")#mi("k_0")#text("), but in table 4 they should be nearly optimal (which is still not the case for the last line – which has the same parameter values as in table 3.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242970")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("It seems to me that the main thing to be illustrated in this part of the paper is how close the best values of A, the various kappas, etc., are to achieving an improved k0 – in other words, how robust is the conclusion that the current k0 cannot be improved. Hence, maybe what is needed in the tables is to give the smallest value of eps2-eps (or some other critical quantity?) yet obtained for k0=631, k0=1782 and so on, along with the precise values of A, the various kappas, etc., which produce that value. Perhaps, in order to give a sense of scale, it also makes sense to give the best (negative) value of eps2-eps for the current k0 (i.e for 632, 1783 etc.), but maybe that’s overkill.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242972")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("I meant table 5 (it was table 4). I agree that more information on the size of the cost function for the optimal parameters is needed for ")#mi("k_0 = 630, 631")#text(" (in particular, because I know of some variants of the bounds for the ")#mi("\\kappa")#text("‘s which may lead (with small improvements of the bounds) to ")#mi("k_0 = 631")#text(" or even ")#mi("630")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243149")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("I have put most of the improvements above into the “optimization” part.")

#text("About Table 5, the current parameters are mainly from previous results listed in the record page (unless for solutions that are not optimal). Since this problem is essentially a satisfaction problem, I am not sure how important to put “optimal” parameters for these optimal k_0 values.")

#text("I do agree that it might be useful to generate a “failure” table for optimal parameters for ")#mi("k_0^{opt}-1")#text(", and reports all ")#mi("\\kappa")#text(" errors, which might provide some hints for possible further improvements.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243199")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("Since for each given ")#mi("k_0")#text(", its corresponding parameters ")#mi("\\delta, \\delta^{\\prime} and A")#text(" are termed as “optimal” in table 5, they should be optimized (for that $k_0$ value.)")#linebreak()#text(" Another reason for the importance of this optimization is that the optimized cost function for ")#mi("k_0 = 631 or 630")#text(" might be “sufficiently small” to enable further reduction of ")#mi("k_0")#text(" by slightly reducing the dominant ")#mi("\\kappa")#text(" (i.e. ")#mi("\\kappa_1")#text(") by slightly improving its (probably crude) current bound. So it is very important to know the size of the optimized cost function (for ")#mi("k_0")#text(" and ")#mi("k_0 -1")#text(".)")#linebreak()#text(" BTW, I have some ideas how to improve (perhaps slightly) the values of the ")#mi("\\kappa")#text("‘s – using some simple new bounds for them (which perhaps may lead to further reduction of the ")#mi("k_0")#text(" values – provided that the size of the corresponding cost function is “sufficiently small”!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243334")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2013")])]

#text("@Eytan: I have generated such a table for ")#mi("k_0^{opt}")#text(", (k0opttable.pdf in the dropbox). Both normal and A-free model were tried, the results were similar. Among the three error terms, ")#mi("\\kappa_1")#text(" was always the biggest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243369")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("Thank you! Can you please do it also for ")#mi("k_0 = 631")#text(" (I think we still have a chance to reach it), and in addition the resulting values of ")#mi("\\kappa_1, \\kappa_2 , \\kappa_3")#text(" (for optimized ")#mi("k_0 = 632, 631")#text("?) thanks!")#linebreak()#text(" BTW, ")#mi("\\kappa_2")#text(" should (by its definition) for sufficiently large ")#mi("k_0")#text(" be small compared to ")#mi("\\kappa_1")#text(".")#linebreak()#text(" I think also that (after optimization) ")#mi("\\kappa_1")#text(" and ")#mi("\\kappa_3")#text(" should have comparable sizes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243372")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("Just updated the table.")

#text("For 632: ")#mi("\\kappa_1")#text(", ")#mi("\\kappa_2")#text(", ")#mi("\\kappa_3")#text(" are 3.01E-06, 3.40E-08, 9.89E-08, respectively.")

#text("For 631: ")#mi("\\kappa_1")#text(", ")#mi("\\kappa_2")#text(", ")#mi("\\kappa_3")#text(" are 3.01E-06, 3.40E-08, 1.03E-07, respectively.")

#text("BTW: Seems $\\latex k_0=630$ is feasible if ")#mi("\\kappa_3")#text(" is ignored from the model.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243377")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("Interesting! but I’m not sure that (for ")#mi("k_0 = 631")#text(") these are the optimal values (in particular ")#mi("\\delta")#text(" seems to be “too large” to enable negative cost function – even with zero ")#mi("\\kappa")#text("‘s!) – Please check if the upper bound on ")#mi("\\delta")#text(" is correct and satisfied!")#linebreak()#text(" Based on some preliminary analysis, I suggest to optimize ")#mi("\\delta")#text(" in the interval ")#mi("1/17000, 1/20000")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243378")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("I meant the interval ")#mi("[1/20000, 1/17000]")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243380")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("Please note that")#linebreak()#text(" 1. In the second table ")#mi("\\kappa_2")#text(" appears as ")#mi("\\kappa_1")#text(".")#linebreak()#text(" 2. The values of ")#mi("\\kappa_1, \\kappa_2")#text(" in the last two lines")#linebreak()#text(" (i.e. ")#mi("k_0 = 632, 631")#text(") are the same.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243384")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("@Eytan: I think xfxie’s optimized values for k=632 and k=631 are correct. For k=631 the optimum is about")

#text("objective = 0.000040614908058444562410709227127")#linebreak()#text(" delta = 1/10892 = 0.000091810503121557106132941608520")#linebreak()#text(" deltap = 1/119 = 0.0084033613445378151260504201681")#linebreak()#text(" A = 194.01650795568561574098481763")

#text("By comparison, for delta=1/17000, 1/18000, 1/19000, 1/20000 the optimal choice of deltap=1/n (n an integer) gives")

#text("objective = 0.015653695596778259119692041036")#linebreak()#text(" delta = 1/17000 = 0.000058823529411764705882352941176")#linebreak()#text(" deltap = 1/262 = 0.0038167938931297709923664122137")#linebreak()#text(" A = 227.54976810616371534477281350")

#text("objective = 0.050726720125176960294660949986")#linebreak()#text(" delta = 1/18000 = 0.000055555555555555555555555555556")#linebreak()#text(" deltap = 1/299 = 0.0033444816053511705685618729097")#linebreak()#text(" A = 229.23953230877909430771893788")

#text("objective = 0.15427791851124266114834442323")#linebreak()#text(" delta = 1/19000 = 0.000052631578947368421052631578947")#linebreak()#text(" deltap = 1/343 = 0.0029154518950437317784256559767")#linebreak()#text(" A = 232.39141344513906955169574324")

#text("objective = 0.43652800188855623135923348342")#linebreak()#text(" delta = 1/20000 = 0.000050000000000000000000000000000")#linebreak()#text(" deltap = 1/396 = 0.0025252525252525252525252525253")#linebreak()#text(" A = 235.27252623541871383847962100")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243388")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("The problem is that the current (optimized?) value of ")#mi("\\delta")#text(" for ")#mi("k_0 = 631")#text(" is too large to enable feasibility (i.e. negative cost function) = even for zero ")#mi("\\kappa")#text("‘s!. It is easy to calculate the upper bound on ")#mi("\\delta")#text(" to enable feasibility with zero ")#mi("\\kappa")#text("‘s (it is about 1/15000 -smaller than the current value of ")#mi("\\delta")#text(") – this is the reason for my suggestion to upper bound ")#mi("\\delta")#text(" by 1/17000.")#linebreak()#text(" Since the possible feasibility region (if exists) seems to be quite small, the optimization of the cost function should be done very carefully (the examples you gave do not indicate that the current ")#mi("\\delta")#text(" value is optimal.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243391")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("Clearly, by starting to slowly reduce ")#mi("\\delta")#text(" below its current value (and for each value optimizing ")#mi("\\delta^{\\prime}")#text(" and ")#mi("A")#text(" as in your example, you can see the cost function starting to decrease (up to a certain “optimal” ")#mi("\\delta")#text(" – perhaps less than 1/17000) – the values of ")#mi("\\kappa_1")#text(" and ")#mi("\\kappa_3")#text(" corresponding to the minimal cost function should be of comparable sizes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243398")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("Eytan, it is true that ")#mi("\\delta")#text(" needs to be at least about ")#mi("\\approx 1/16169")#text(" in order to make ")#mi("1-\\frac{j_{k-2}^2}{k(k-1)(1+4\\varpi)}")#text(" positive, when ")#mi("k=631")#text(". Yet, the difference of this expression and ")#mi("2(\\kappa_1+\\kappa_2+\\kappa_3)")#text(" is maximized for ")#mi("\\delta\\approx 10892")#text(" and ")#mi("\\delta^{\\prime}\\approx 1/119")#text(", and it is still negative there. In the range you suggest, the mentioned difference (as maximized in ")#mi("\\delta^{\\prime}")#text(") is a decreasing function of ")#mi("\\delta")#text(":")

#text("delta = 1/17000 = 0.000058823529411764705882352941176")#linebreak()#text(" deltap = 10/2616 = 0.0038226299694189602446483180428")#linebreak()#text(" difference = -0.015625686235754007815067521685")

#text("delta = 1/17001 = 0.000058820069407681901064643256279")#linebreak()#text(" deltap = 10/2617 = 0.0038211692777990064959877722583")#linebreak()#text(" difference = -0.015644105635903322436233767115")

#text("and so on. That’s life. Perhaps you want to study another extremum problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243399")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("It may be possible for ")#mi("k_0 = 631")#text(", that the current values of ")#mi("\\delta, \\delta^{\\prime}, A")#text(" as optimized by xfxie are indeed optimal. If this is the case than the only chance for improving ")#mi("k_0")#text(" to ")#mi("631")#text(" is by improving the current upper bounds on the ")#mi("\\kappa")#text("‘s – I’ll try to check this possibility (I found some examples of such new bounds.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243403")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("I should have posted my previous comment of 11:00 am at this level, not one level up. Sorry about that.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243402")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("Here is more data showing that for ")#mi("k=631")#text(" the extremum is at ")#mi("\\delta\\approx 1/10896")#text(" and ")#mi("\\delta^{\\prime}\\approx 1000/119059")#text(":")

#text("delta = 1/10895 = 0.000091785222579164754474529600734")#linebreak()#text(" deltap = 1000/119043 = 0.0084003259326461866720428752636")#linebreak()#text(" A = 193.97915262578728328433413956")#linebreak()#text(" difference = -0.000040614772581912220284280584210")

#text("delta = 1/10896 = 0.000091776798825256975036710719530")#linebreak()#text(" deltap = 1000/119059 = 0.0083991970367632854299129003267")#linebreak()#text(" A = 194.09113855858381197092882324")#linebreak()#text(" difference = -0.000040614764639407839935052223726")

#text("delta = 1/10897 = 0.000091768376617417637881985867670")#linebreak()#text(" deltap = 1000/119075 = 0.0083980684442578207012387150955")#linebreak()#text(" A = 193.99409796303702518114647794")#linebreak()#text(" difference = -0.000040614771964712124471218772054")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243411")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("I agree!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242923")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("In the sixth line below Theorem 2.20, ")#mi("\\sigma>\\frac{1}{18}+\\frac{28}{9}\\varpi+\\frac{2}{9}\\times\\frac{1}{10}<1")#text(" should be ")#mi("\\frac{1}{18}+\\frac{28}{9}\\varpi+\\frac{2}{9}\\delta<\\frac{1}{10}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242938")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("In the proof of lemma 4.6, a (right) parenthesis is missing at the end of the third line.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-242939")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2013")])]

#text("In the proof of theorem 2.14, it seems that in the cases (i) – (iii), ")#mi("\\delta^{\\prime}")#text(" should be replaced by ")#mi("i\\delta^{\\prime}")#text(".")

#emph[#text("[Fixed this for (iii); I think it is OK as is for (i), (ii). -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243026")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2013")])]

#text("In theorem 2.14, the condition ")#mi("A > 0")#text(" can be relaxed to ")#mi("A \\geq 0")#text(". (Indeed, in case (i) of my comment above, the optimal ")#mi("A")#text(" is ")#mi("0")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("@Authors: I have left the Dropbox folder. (If some LaTeX’ing is needed, I’ll try to do my best after being re-invited.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243112")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("In the third line below (4.43), the statement that “both sides vanish” should be corrected.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243143")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("A typo: it should be “side”.")

#emph[#text("[I was unable to locate this correction, sorry – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243171")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("I meant that In the third line below (4.43), it should be “side” (instead of “sides”).")

#emph[#text("[OK, corrected now, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243133")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("I’m wondering whether there is a case for concluding the paper with a short section summarising the current understanding of what avenues are available – and, critically, of how promising they seem – for further progress on H. It seems to me (though I concede that this may be because my own field, biology, may simply have different conventions for the structure of papers) that the paper as it stands not only lacks such a synthesis but also is overall rather patchy in terms of describing which avenues are and are not promising.")

#text("Most conspicuously, while the reader already comes away with a nicely clear understanding that there is negligible (if any) scope for further reducing H for relevant values of k0, s/he cannot draw comparable conclusions in respect of the best k0 for a given varpi. To clarify: I am not referring to how best to minimise delta by various trickery involving error terms, about which there is a vibrant ongoing discussion here. Rather, what seems to me to be missing is discussion of the potentially much more powerful option of improving the relationship between varpi and “k0*”, most especially the critical exponent -3/2 (originally -2) in that relationship.")

#text("I feel that similar patchiness currently exists in respect of varpi itself: there is proposed to be a nice discussion of why varpi cannot readily be improved by reducing sigma (the “Type V” obstacle), but it is striking that nothing equivalent is proposed to be said about obstacles to further relaxing the current Type 1 boundary, given that that is so overwhelmingly the quantitatively best single option for increasing varpi (in the sense that big improvements of varpi without progress on Type 1 would result only from big progress on both Type III and sigma).")

#text("Finally, maybe there should be a brief mention – here perhaps all that is needed is pointers to the key literature – of what makes the upper bound of 1/4 on varpi (leading to the lower bound of 16 on H) so impregnable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243136")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("Hmm, that sounds like a good idea; I’ve added a stub of a section on possible improvements to the end of the paper. Of course we would also be inserting remarks at various junctures of the paper when some further optimisation looks likely or unlikely, but it does make sense to summarise all that in one concluding section.")

#text("Regarding the varpi/k_0^* relationship, this is more or less the focus of an existing paper of Farkas, Pintz, and Revesz: ")#link("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")[#text("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")]#text(" . We don’t really have much new to add to what they say (which is that the relationship we have is the limit of what one can do just by optimising the cutoff function in the Goldston-Pintz-Yildirim sieve), but we can perhaps recall more prominently some of their conclusions here.")

#text("The Elliott-Halberstam conjecture is known to fail at the endpoint varpi = 1/4; I don’t know offhand the reference where this is first established (maybe in the original Elliott-Halberstam paper?) but I agree this is worth pointing out in the paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243209")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("p.s. I’ve just learned that the failure of the endpoint Elliott-Halberstam conjecture was established in a paper of Friedlander-Granville (")#link("http://www.ams.org/mathscinet-getitem?mr=1220459")[#text("http://www.ams.org/mathscinet-getitem?mr=1220459")]#text("), with a stronger version of that failure established in a followup paper of Friedlander-Granville-Hildebrand-Maier (")#link("http://www.ams.org/mathscinet-getitem?mr=1080647")[#text("http://www.ams.org/mathscinet-getitem?mr=1080647")]#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243137")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("A very minor correction: In the line below (2.5), the constant is in fact")#linebreak()#text(" ")#mi("1.85575708...")#text(" – so I suggest to display it as ")#mi("1.855757...")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1e5a1f8fedf06dc288a89076e2da2ef431c2a3d2382d8380d5e54d12189c87e-ed01907680b2daad77e4a6aee1babf0bb370efeae586d3d3cd26d5bb51b23604.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derek O")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243140")[#strong[#text("Derek O")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("Congratulations to everyone who contributed to this project. As an undergraduate college student (with research in number theory), I was following this since the day it began. This is truly spectacular. Well done, you guys.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243142")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("A typo: in the tenth line of the abstract, it should be “application”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243145")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("I have posted an updated version of narrow.tex to Dropbox that includes essentially everything I wanted to put in to section 3, except for the lower bounds subsection 3.8, which still needs to be written. I am heading off to a conference tomorrow and won’t have time to work on it for a while, so I am happy to turn over the file at this point if someone else wants to take a crack at drafting 3.8 (Wouter?).")

#text("I added a new subsection 3.1 that describes an asymptotically faster admissibility testing algorithm that turned out to be critical for handling the larger values of k (especially 3500000). The upper bounds on H for k=34429, 181000, 341640, and 3500000 have now been improved to 386344, 2323344, 4601036, and 55233504, respectively (see Table 4).")

#text("These values should also be updated in Table 1.")

#text("One thing I thought about putting in, but didn’t, is an updated version of the graphic ")#link("http://math.mit.edu/~drew/hw2data.gif")[#text("http://math.mit.edu/~drew/hw2data.gif")]#text(", which is related to the discrepancy between the prime tuples conjecture and the second Hardy-Littlewood conjecture (which is mentioned in the article but isn’t directly relevant to bounding prime gaps). But if people think it should be included, I would be happy to generate an updated version.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243153")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2013")])]

#text("Just a small update on my end; I have more or less finished editing subtheorems.tex, gpy.tex, and heath-brown.tex for now, and plan to start working on exponential.tex in the next week or so, although I will be traveling and having some other commitments for the next two or three days, so this may take a while to get going. I hadn’t realised that the net length of the paper is likely to exceed the 100 page mark; somehow it seemed smaller than this when split up into individual blog posts! This may complicate the question of where to submit this paper (or whether to convert this paper into a monograph), but perhaps it will be clearer how to proceed on that front as the paper continues to be fleshed out.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243174")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("FYI, I just updated Table 1 in subtheorems.tex to incorporate the improved bounds on H noted above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243192")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("In fact the blog posts and the comments make up more than 600 pages when printed and joined to a pdf file!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243168")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("Sure, I can help with writing Section 3.8.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243173")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("Thanks. I just fixed a typo (3451 changed to 3461), but I’ll hand the file over to you know.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("Typograhpical comment: For maps, one should use “\\colon” instead of “:”, i.e., ")#mi("f \\colon A \\to B")#text(" instead of ")#mi("f : A \\to B")#text("; this gives the correct spacing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243244")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("I’m reporting here some simplifications found by Philippe Michel (and confirmed by Emmanuel Kowalski and myself) to one of the main conclusions of the Deligne machinery needed for our project, namely the fact that the trace weight")

#mi("K(d) := \\frac{1}{\\sqrt{p}} \\sum_{n \\in {\\bf F}_p} e_p( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} + hn )")

#text("for any ")#mi("c,l,v,a,b,h \\in {\\bf F}_p")#text(" with c,l non-zero has bounded conductor and is almost orthogonal to all quadratic phases in the sense that")

#mi("\\sum_d K(d) e_p( sd + td^2 ) = O(\\sqrt{p})")#text(" (*)")

#text("for all ")#mi("s,d")#text(". Currently we are using some rather general ell-adic machinery to establish the bounded conductor property, and Hooley’s criterion on two-dimensional exponential sums to establish the almost orthogonality. However, it turns out that one can manipulate K by some Fourier analysis to avoid both of these steps, instead using the more standard theory of Deligne, Laumon and Katz on “Fourier transforms” of sheaves. The first observation is that the properties required on K (namely, bounded conductor and almost orthognality to quadratic phases) are unaffected by the following “metaplectic” operations:")

#text("* dilation of K (replacing ")#mi("K(d)")#text(" by ")#mi("K(du)")#text(" for any non-zero ")#mi("u")#text(")")

#text("* translation of K (replacing ")#mi("K(d)")#text(" by ")#mi("K(d+u)")#text(" for any ")#mi("u")#text(")")

#text("* frequency modulation of K (replacing ")#mi("K(d)")#text(" by ")#mi("K(d) e_p(ud)")#text(" for any ")#mi("u")#text(")")

#text("* Fourier transform of K (replacing ")#mi("K(d)")#text(" by ")#mi("\\frac{1}{p} \\sum_{u \\in {\\bf F}_p} K(u) e_p(du)")#text(") – this requires Deligne-Laumon-Katz to keep the conductor bounded.")

#text("Using the first three symmetries, one can reduce to the case ")#mi("v=a=b=0")#text(" and ")#mi("l=1")#text(", thus")

#mi("K(d) := \\frac{1}{\\sqrt{p}} \\sum_{n \\in {\\bf F}_p} e_p( \\frac{c}{n(n+d)} + hn ).")

#text("Then taking a Fourier transform we can replace ")#mi("K")#text(" with")

#mi("\\hat K(u) := \\frac{1}{p^{3/2}} \\sum_{d,n \\in {\\bf F}_p} e_p( \\frac{c}{n(n+d)} + hn + du ).")

#text("Making the change of variables ")#mi("(n,w) = (n,n(n+d)/c)")#text(" this becomes")

#mi("\\hat K(u) = \\frac{1}{p^{3/2}} \\sum_{n,w \\in {\\bf F}_p} e_p( \\frac{1}{w} + hn + cwu/n - un )")

#text("which we can write in terms of the Kloosterman weight ")#mi("K_2(s) := \\frac{1}{\\sqrt{p}} \\sum_{w \\in {\\bf F}_p} e_p( \\frac{1}{w} + sw )")#text(" as")

#mi("\\hat K(u) = \\frac{1}{p} \\sum_{n \\in {\\bf F}_p} K_2( cu/n ) e_p( (h-u) n )")

#text("or after the change of variables ")#mi("m = n/cu")

#mi("\\hat K(u) = \\frac{1}{p} \\sum_{n \\in {\\bf F}_p} K_2( 1/m ) e_p( cu(h-u) m ),")

#text("thus ")#mi("\\hat K(u)")#text(" is the Fourier transform of the function ")#mi("m \\mapsto K_2(1/m)")#text(" evaluated at the quadratic function ")#mi("cu(h-u)")#text(" of ")#mi("u")#text(". The results of Deligne, Laumon and Katz then ensure that this is a trace weight of bounded conductor, and one can also show directly that the associated sheaf does not contain quadratic Artin-Schrier components, without the need for the Hooley argument (and generic irreducibility, etc.).")

#text("This argument is easier than the one currently being written into the draft paper, but is not as general (it relies more heavily on the low-degree nature of the rational phases we are using). We are therefore thinking of rewriting this portion of the paper to focus on this easier argument, and only sketch the more complicated and general argument (perhaps details would be given in a future paper, outside of the polymath8 project).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/522b1bbefd8853ef7e3e23b7539cb5abc40676c84379f0f44da255721d0abe83-9c83666091d28e0dc7b7475232787c6455a3611156f8e7446f5bd7f72c0183d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaston Rachlou")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243256")[#strong[#text("Gaston Rachlou")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2013")])]

#text("Please excuse me if the following suggestion has already been made. I understand and appreciate that various versions are being written, with or without this or that technique.")

#text("I think it would be nice to have available somewhere the simplest possible proof of the qualitative result “")#mi("p_{n+1}-p_n")#text(" does not tend to infinity”. The implicit bound could be worse than Zhang’s 70 000 000, the focus being on using the minimal machinery. With the collective expertise acquired during this remarkable endeavour of yours, it could be an interesting task for someone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/522b1bbefd8853ef7e3e23b7539cb5abc40676c84379f0f44da255721d0abe83-9c83666091d28e0dc7b7475232787c6455a3611156f8e7446f5bd7f72c0183d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaston Rachlou")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243261")[#strong[#text("Gaston Rachlou")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2013")])]

#text("Of course this “good idea of mine” was already in your post… Sorry for the wasted room, but it would definitely be a welcome text!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243290")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2013")])]

#text("In ref. [13], there is a typo in the name of Turan.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243299")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2013")])]

#text("It is probably due to the accent which requires an input font package or must be typeset differently. At any rate, the correct spelling is “Turán”, but it seems that the cover of that volume will have “Turan” on it. See ")#link("http://www.degruyter.com/doc/flyer/9783110282375.pdf")[#text("http://www.degruyter.com/doc/flyer/9783110282375.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243302")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2013")])]

#text("Probably so (because the letter ‘a’ is missing.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243306")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2013")])]

#text("Actually, thanks to your comment I found that there were quite a lot of special characters in the bibliography (coming from accents and also from some en-dashes and em-dashes that had been cut-and-pasted into biblio.tex) that were not being LaTeX’ed properly; I think the problem is fixed now.")

#text("Also, reminded by Gaston Rachlou’s comment, I have now added a remark about the “minimal” proof we currently have to the paper at Remark 2.21. After this project is finished, I might write a blog post in which I try to extract this minimal proof (similar to something I did for Gromov’s theorem at ")#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/")[#text("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/")]#text(" ), but that won’t happen for a while.")

#text("Best,")

#text("Terry")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243481")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Thank you Terry! I think Remark 2.21 is particularly valuable to non-specialists. Three things occur to me as a result of it.")

#text("1) There is one aspect that I think may confuse the less expert reader, though (at least it confuses me!): it concerns the assertion that “one can extend the Type II analysis to also cover the Type I case” (which was already noted in the placeholder paragraph for Section 7). Since Type II constraints do not depend on sigma, how exactly does a purely Type II argument dovetail with the need to keep sigma above 1/6? Is it more accurate to say that the Type I argument can be replaced not by precisely a Type II argument but actually by a variant of Type II that does give rise to a dependence on sigma (and thus, presumably, a varpi considerably smaller than 1/68)?")

#text("2) Concerning the extraction of a minimal proof: while I see that that is not a priority, and notwithstanding the closing sentence of Remark 2.21, it seems to me that since the paper is going to include quite extensive discussion of sub-optimal k0 values obtainable without using certain sophisticated machinery, it would be a shame not to include good values of k0 (and H) arising from purely Type II arguments if they could be found fairly easily. If I fully understand Remark 2.21, it seems that the only thing missing from the existing discussion that is needed for this is to identify the relevant linear constraint on (varpi, delta) presuming sigma = 1/6, and then xfxie and Drew could provide good k0 and H in half no time. Is such a constraint already “as good as known” (e.g., is it already available by combining suitable “levels” of the Type I and II constraints on the wiki)? I apologise if I have overlooked some previous discussion of this, or if I am underestimating the difficulty of deriving this constraint.")

#text("3) Finally: I asked some time ago about the possibility of bypassing Weil entirely, and you mentioned the mathoverflow question you’d asked and the lack of a resolution (see ")#link("http://mathoverflow.net/questions/138193/is-there-a-cheap-proof-of-power-savings-for-exponential-sums-over-finite-fields")[#text("http://mathoverflow.net/questions/138193/is-there-a-cheap-proof-of-power-savings-for-exponential-sums-over-finite-fields")]#text("). Would it be appropriate to include a sentence about that issue here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243530")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Regarding (3), I’ve now added an additional remark (Remark 6.2) to address this. As for extending the Type II analysis, I haven’t yet gotten to that part of the writeup (still finishing off Section 6), but will add some comment about this when I reach that point.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a802e57e62da3ee2bf6c6272fe8a1f6540567106180175f933a258fe69dc572-3aa4c24406076b9cd0da16f74eea99ef2d1f783e53bbffc58df26e356318e8fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243295")[#strong[#text("Steve")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2013")])]

#text("Layman question: What is required to confirm H = 4,686? Is it review of a proof, or just some exhaustive calculation? If it’s the latter, I’d be happy to set my GPU about the task of crunching numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243370")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("In the third line of claim 1.1, it seems clearer to have ")#mi("p_{n+1} - p_n")#text(" inside parentheses.")

#emph[#text("[Edited, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243385")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("Any chance of an idiot’s guide to any of this? I’d really love to understand, but don’t know where to start.")

#emph[#text("[ You might try ")#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/")[#text("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af889f21cffed1bc6bdf27a7fed1fde0389bf12b630f305535d4972157aec4d7-90ef39ba9be26d6fc3d07526c03c555ee74ee9c0411fc741d027ab3597c9af5e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neymetms")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243397")[#strong[#text("neymetms")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("newgap (Terence Tao’s conflicted copy 2013-08-30).pdf (p.20)")

#text("3.2 g_n = p_{n + 1} – p_n,")

#text("for n <250150 g_n <174")

#text("for n < 3 750150 g_n < 256")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243401")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("In (4.32), it should be ")#mi("1_{[0,1]}(t)")#text(" (instead of ")#mi("1_{[-1,1]}(t)")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243405")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("In the tenth line above the proof of theorem 2.14, it should be “non-increasing” (instead of “non-decreasing”.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243435")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("A new admissible tuple for ")#mi("k_0 = 341,640")#text(" with diameter 4,597,926")#linebreak()#text(" has been posted at")

#link("http://math.mit.edu/~primegaps/tuples/admissible_341640_4597926.txt")[#text("http://math.mit.edu/~primegaps/tuples/admissible_341640_4597926.txt")]#text(".")

#text("This was obtained by letting the adjustment process described in 3.6.1 run until it could not find any beneficial adjustments using residue classes at up to 3 primes (I did this earlier for ")#mi("k_0 = 181,000")#text("). I’ve posted the new bound on the wiki, but it should also be updated in Table 1 of subtheorems.tex and Table 4 of narrow.tex.")

#emph[#text("[Updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243444")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2013")])]

#text("Two lines below (5.2), ")#mi("[\\frac{1}{2}-\\sigma,\\frac{1}{2}+\\sigma]")#text(" should be ")#mi("(\\frac{1}{2}-\\sigma,\\frac{1}{2}+\\sigma)")#text(". Five lines below (5.2), ")#mi(">\\frac{1}{2}+\\sigma")#text(" (resp. ")#mi("<\\frac{1}{2}-\\sigma")#text(") should be ")#mi("\\geq\\frac{1}{2}+\\sigma")#text(" (resp. ")#mi("\\leq\\frac{1}{2}-\\sigma")#text("). On page 53, line 4, \"exceed\" should be \"be at least\".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243499")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("1. In part (i) of Lemma 2.12, “")#mi("l")#text(" is” should be “")#mi("l")#text(" is ")#mi("k")#text("-tuply”.")

#text("2. At the end of the second paragraph of the proof of Lemma 2.12, ")#mi("p<y")#text(" should be ")#mi("p\\leq y")#text(". Three lines below this, ")#mi("p\\geq y")#text(" in the subscript should be ")#mi("p\\leq y")#text(".")

#text("3. I suggest that in Lemma 2.12 and its proof we rename ")#mi("k")#text(" (resp. ")#mi("i,j")#text(") to ")#mi("i")#text(" (resp. ")#mi("j,k")#text(") in order to be in harmony with Definition 2.11 and its neighborhood.")

#emph[#text("[Changed, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243528")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("These corrections do not appear in the current pdf files (newgap.pdf and your conflicted copy of 2013-09-02). I have not checked the tex files.")

#emph[#text("[Oops, there seems to have been an edit conflict about this; I think it is resolved now. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243539")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Item #3 is implemented now, but it seems items #1 and #2 are not. Thank you in advance!")

#emph[#text("[Gah, fixed now, I hope… -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243542")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Almost :-) In the proof of Lemma 2.12, in the definition of ")#mi("n^{\\prime}")#text(", ")#mi("p>y")#text(" should be ")#mi("p\\leq y")#text(".")

#emph[#text("[OK, hopefully this time it is fixed – T.]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243512")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("On the inefficiency of the current upper bound for ")#mi("\\kappa_3")#text(":")

#text("1. The integral in this bound has a good approximation (from above) in terms of the exponential integral function ")#mi("E_1")#text(" by ")#mi("E_1(z)")#text(", where")#linebreak()#text(" ")#mi("z := (A+2\\eta)\\tilde{\\delta}")#text(" – which (by the expansion 5.1.11 in A$S) is ")#mi("\\log (1/z) - \\gamma  +O(z)")#linebreak()#text(" Where ")#mi("\\gamma = 0.5772...")#text(" is Euler’s constant.")#linebreak()#text(" Note that the optimal ")#mi("A+2\\eta")#text(" is (closely) upper bounded by ")#mi("k_0 -1")#text(" – implying that (in practice) ")#mi("z \\ll 1")#text(".")#linebreak()#text(" 2. Observe that the exponential factor of the current bound is an upper bound for a finite sum (for the original bound) of J-dimensional integrals where")#linebreak()#text(" ")#mi("0 \\leq J \\leq 1/ \\tilde{\\delta}")#text(". It seems (because of the above logarithmic approximation of ")#mi("E_1(z)")#text(") that a major part of these J-dim. integrals is due to integration over small domains of sizes of order O(latex \\tilde{\\delta}) – implying that by the “A – trick” the original integrands over these small “major” domains are multiplied by approximately ")#mi("exp(A)")#text(". Therefore it seems that the true ")#mi("\\kappa_3")#text(" should be much smaller than its current bound (perhaps by a factor of about ")#mi("\\exp(-A)")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243513")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("It should be ")#mi("O(\\tilde{\\delta})")#text(" in my last comment above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Are you saying that ")#mi("\\sum_{0 \\leq J \\leq 1/\\tilde \\delta} \\frac{(k-1)^J}{J!} (\\int_{\\tilde \\delta}^\\infty e^{-(A+2\\eta)t} \\frac{dt}{t})^J")#text(" is much smaller than ")#mi("\\exp((k-1)\\int_{\\tilde \\delta}^\\infty e^{-(A+2\\eta)t} \\frac{dt}{t})")#text("? Or are you scrolling further back in the argument?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243527")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Not exactly. I’m saying that the “A trick” (which is using the fact that the")#linebreak()#text(" J-dim. integrand is zero whenever ")#mi("\\sum t_j \\geq 1")#text(" can be very")#linebreak()#text(" inefficient (multiplying the integrand by about ")#mi("\\exp(A)")#text(" exactly on the “major domain” with size ")#mi("O(\\tilde{\\delta})")#text(" – where the integrand is most important – as reflected by its logarithmic nature – which depends only on domains of size ")#mi("O(\\tilde{\\delta})")#text(".")#linebreak()#text(" The purpose of the “A-trick” is to upper bound the J-dim. integrals over the domain ")#mi("\\sum t_j < 1")#text(" – while still having a multiplicative integrand.")#linebreak()#text(" Unfortunately, this advantage of the \"A-trick\" leads to a very large magnification (about ")#mi("\\exp(A)")#text(") exactly on the above \"major domain\"!")#linebreak()#text(" (I'm trying to reduce this inefficiency by generalizing somewhat the \"A-trick\".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243533")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("If I understand correctly, you are trying to improve on the bound")

#mi("\\sum_{0 \\leq J \\leq \\frac{1}{\\tilde \\delta}} \\frac{(k_0-1)^J}{J!} \\int_{t_j\\geq\\tilde\\delta, t_1+\\ldots+t_J\\leq 1} e^{-2\\eta(t_1+\\ldots+t_J)}\\frac{dt_1 \\ldots dt_J}{t_1 \\ldots t_J}")

#mi("<\\exp(A+(k-1)\\int_{\\tilde \\delta}^\\infty e^{-(A+2\\eta)t} \\frac{dt}{t})")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243535")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Yes!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243543")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("I experimented a little bit for ")#mi("k_0=632")#text(", ")#mi("\\delta=1/10910")#text(", ")#mi("\\delta^{\\prime}=1/119")#text(". The right hand side for the optimal ")#mi("A\\approx 194.29")#text(" is about ")#mi("3.45\\times 10^{436}")#text(". On the left hand side, the ")#mi("J")#text("-term is clearly at least")

#mi("\\frac{(k_0-1)^J}{J!}(\\int_{\\tilde\\delta}^{1/J}e^{-2\\eta t}\\frac{dt}{t})^J")

#text("which for ")#mi("J=523")#text(" is about ")#mi("2.31\\times 10^{321}")#text(". So indeed there is hope to save ")#mi("e^A\\sim 10^{84}")#text(" or more, but of course my benchmark lower bound is very crude.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243552")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("It is easy to express the J-th term as an iterated integral (I tried it for ")#mi("J=2")#text(" and it can’t be expressed exactly in terms of the classical special functions, but at least it has tight lower and upper simple bounds using the expansions for ")#mi("E_1(x)")#text(" for small and large arguments) – I think that these bounds can be extended for general J-th term.")#linebreak()#text(" (This is of course a direct approximation approach, but I intend to try also a generalized “A-trick” bounding approach.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243596")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("The general idea of this “A-trick” is to find a weight function ")#mi("w")#text(" (possibly dependent on ")#mi("J")#text(") on ")#mi("[0, \\infty)")#text(", satisfying")

#text("(i) ")#mi("w \\geq 1")#text(" on ")#mi("[J \\tilde {\\delta}, 1]")#linebreak()#text(" (ii) ")#mi("w(\\sum t_j) \\leq  C \\prod w(t_j)")#text(" for some constant C whenever each ")#mi("t_j \\in [\\tilde{\\delta}, \\theta)")#text(".")

#text("Note that property (ii) is implied by")#linebreak()#text(" (ii)’ ")#mi("w")#text(" is log-concave on ")#mi("[0, \\infty)")#text(".")

#text("One may try to optimize ")#mi("w")#text(" or try to optimize it in a parametric form")

#text("Parametric examples:")

#text("1. ")#mi("w(t) := \\exp [A (1-t)]")#text(" where ")#mi("A \\geq 0")#linebreak()#text(" (this is the current one-parametric example with ")#mi("C = \\exp(A)")#text(").")#linebreak()#text(" 2. ")#mi("w(t) := \\exp [A(1-t)] (1-B t)_{+} / (1-B)")#linebreak()#text(" where ")#mi("A \\geq 0")#text(" and ")#mi("B \\in [0, 1)")#text(" with")#linebreak()#text(" ")#mi("C = \\exp(A) /(1-B)")#text(".")

#text("Note that in the second example, the additional parameter ")#mi("B")#text(" helps in reducing the factor ")#mi("exp(A)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243598")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("In my last comment above, in the two examples, the expressions given for the constant ")#mi("C")#text(" are in fact for its inverse ")#mi("1/C")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243635")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("Some remarks:")

#text("1. The second example is the simplest parametric weight function generalizing the current weight (i.e. example 1) – this could be only a beginning for optimizing a more general weight function (constrained to have the properties (i) and (ii) above). As an example for further generalization, one may use ")#mi("\\prod (1-B_i t)_{+}")#text(" where each ")#mi("B_i \\in [0, 1)")#linebreak()#text(" (this strategy may be called “generalize and optimize”)")

#text("2. It is possible that by fixing ")#mi("A")#text(" and optimizing ")#mi("B")#text(" and than fixing ")#mi("B")#text(" and optimizing ")#mi("A")#text(" and so on, the convergence may be very slow (depending on the condition number of the Hessian of the cost function) – so perhaps an efficient optimization algorithm for combined optimization of the parameters ")#mi("A, B")#text(" is needed (e.g. a quasi-Newton optimization method.)")

#text("3. As I understand (at least intuitively) the role of A, it gives a trade-off between the desire to have low magnification ")#mi("\\exp(A)")#text(" for the important domain of size ")#mi("\\tilde{\\delta}")#text(" while significantly reduce the contribution to the integral of the domain with ")#mi("\\sum t_j >1")#text(".")#linebreak()#text(" Note that the first requirement demands “small A”, while the second one demands “large A” – showing the trade-off in A optimization.")#linebreak()#text(" Now B helps by assisting in the second requirement (steep cut-off for large t) -thereby helping to reduce A to cope with the first requirement (small t).")#linebreak()#text(" Therefore I think that what happened numerically is that B (governing the steepness of the weight function for large t is not sufficiently large) so perhaps a further generalization is needed, i.e.")

#mi("w(t) := \\exp A(1-t) [(1-B t)_{+}/(1-B)]^n")

#text("With parameters ")#mi("A,B,n")#text(" to be optimized (such that A and B should “share” their respective requirements in a better way.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243622")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2013")])]

#text("I tried to implement your second parametric example. It gives, for any ")#mi("A\\geq 0")#text(" and ")#mi("0\\leq B<1")#text(",")

#mi("\\sum_{0 \\leq J \\leq \\frac{1}{\\tilde \\delta}} \\frac{(k_0-1)^J}{J!} \\int_{\\tilde\\delta\\leq t_j\\leq\\theta, t_1+\\ldots+t_J\\leq 1} e^{-2\\eta(t_1+\\ldots+t_J)}\\frac{dt_1 \\ldots dt_J}{t_1 \\ldots t_J}")

#mi("<\\frac{e^A}{1-B}\\exp((k-1)\\int_{\\tilde \\delta}^\\theta e^{-(A+2\\eta)t}(1-Bt)_+\\frac{dt}{t})")

#text("In practice ")#mi("\\theta")#text(" is less than ")#mi("1")#text(", so we can drop the ")#mi("+")#text(" subscript. For ")#mi("k_0=632")#text(", ")#mi("\\delta=1/10910")#text(", ")#mi("\\delta^{\\prime}=1/119")#text(", ")#mi("A=194")#text(", SAGE tells me that the right hand side decreases in ")#mi("B")#text(" very slightly in the beginning, then it increases. So it seems we cannot get a significant savings this way. Here are some sample values:")

#text("B = 0.0000 -> 2.4714682685342455648079262199e438")#linebreak()#text(" B = 0.0005 -> 2.4714677808195620527909981040e438")#linebreak()#text(" B = 0.0010 -> 2.4714679115895903063390145381e438")#linebreak()#text(" B = 0.0100 -> 2.4715767393414678026360526257e438")#linebreak()#text(" B = 0.1000 -> 2.4845919836872781662553066857e438")#linebreak()#text(" B = 0.9990 -> 9.0952599437455008465256980149e440")#linebreak()#text(" B = 0.9999 -> 9.0870726191879883371508337709e441")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243866")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("I’m trying also to prove that ")#mi("k_0 = 631")#text(" is unattainable (this is also not easy – because in this case one needs good lower bounds for the true ")#mi("\\kappa")#text("‘s!)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243518")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("I tried to implement the original e-term before, but seems there were no big difference at that time.")

#text("Based on Eytan’s comment, I just tried a re-implementation of the e-term.")

#text("The direct implementation of e-term seems to be too slow for some parameters:")#linebreak()#text(" e := exp(A)*evalf(Sum((k0-1)^J/J!*int(exp(-(A*t)/t), t=deltat..theta, numeric ), J=0..floor(1/deltat)));")

#text("So I changed to the following form:")#linebreak()#text(" ia := int(exp(-(A*t)/t), t=deltat..theta, numeric)*(k0-1);")#linebreak()#text(" e := exp(A)*evalf(Sum(ia^J/J!, J=0..floor(1/deltat)));")

#text("Then I can get k0=631: ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7_631_o.mpl")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi600d7_631_o.mpl")]

#text("I still need to check if there are any errors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243521")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("I think you have a typo in your notebook: exp(-(A*t)/t) is no good, it should be exp(-A*t)/t or, rather, exp(-(A+2*eta)*t)/t.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243523")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("You are right. Seems the hope is almost lost as going back to here. Basically, if the term J=0 is allowed, e^A is there, since 0^0 =1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/comment-page-1/#comment-243524")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("SAGE tells me that there is virtually no difference between taking the exponential of the integral (multiplied by ")#mi("k-1")#text(") and using the original finite Taylor sum. For ")#mi("k=632")#text(", ")#mi("\\delta=1/10910")#text(", ")#mi("\\delta^{\\prime}=1/119")#text(", ")#mi("A=194")#text(" the two methods give")#linebreak()#text(" kappa3 = 9.8625509966256926663337917961e-8")#linebreak()#text(" kappa3 = 9.8625509966256926663337917960e-8")
]
]
]
