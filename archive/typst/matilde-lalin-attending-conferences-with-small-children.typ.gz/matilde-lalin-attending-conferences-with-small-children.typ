// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/
// Converted to Typst by tao2typ: "2026-10-14T15:19:08.927157+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Matilde Lalin) Attending conferences with small children", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Matilde Lalin) Attending conferences with small children")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 August 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/")[#text("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This guest post is authored by ")#link("http://www.dms.umontreal.ca/~mlalin/")[#text("Matilde Lalin")]#text(", an Associate Professor in the Département de mathématiques et de statistique at the Université de Montréal. I have lightly edited the text, mostly by adding some HTML formatting. -T.]")]

#text("Mathematicians (and likely other academics!) with small children face some unique challenges when traveling to conferences and workshops. The goal of this post is to reflect on these, and to start a constructive discussion what institutions and event organizers could do to improve the experiences of such participants.")

#text("The first necessary step is to recognize that different families have different needs. While it is hard to completely address everybody’s needs, there are some general measures that have a good chance to help most of the people traveling with young children. In this post, I will mostly focus on nursing mothers with infants (")#mi("\\leq 24")#text(" months old) because that is my personal experience. Many of the suggestions will apply to other cases such as non-nursing babies, children of single parents, children of couples of mathematicians who are interested in attending the same conference, etc..")

#text("The mother of a nursing infant that wishes to attend a conference has three options:")

#enum(start: 1, 
[#strong[#text("Bring the infant and a relative/friend to help caring for the infant.")]#text(" The main challenge in this case is to fund the trip expenses of the relative. This involves trip costs, lodging, and food. The family may need a hotel room with some special amenities such as crib, fridge, microwave, etc. Location is also important, with easy access to facilities such as a grocery store, pharmacy, etc. The mother will need to take regular breaks from the conference in order to nurse the baby (this could be as often as every three hours or so). Depending on personal preferences, she may need to nurse privately. It is convenient, thus, to make a private room available, located as close to the conference venue as possible. The relative may need to have a place to stay with the baby near the conference such as a playground or a room with toys, particularly if the hotel room is far.")],
[#strong[#text("Bring the infant and hire someone local (a nanny) to help caring for the infant")]#text(". The main challenges in this case are two: finding the caregiver and paying for such services. Finding a caregiver in a place where one does not live is hard, as it is difficult to conduct interviews or get references. There are agencies that can do this for a (quite expensive) fee: they will find a professional caregiver with background checks, CPR certification, many references, etc. It may be worth it, though, as professional caregivers tend to provide high-quality services and peace of mind is priceless for the mother mathematician attending a conference. As in the previous case, the mother may have particular needs regarding the hotel room, location, and all the other facilities mentioned for Option 1.")],
[#strong[#text("Travel without the infant and pump milk regularly.")]#text(" This can be very challenging for the mother, the baby, and the person that stays behind taking care of the baby, but the costs of this arrangement are much lower than in Option 1 or 2 (I am ignoring the possibility that the family needs to hire help at home, which is necessary in some cases). A nursing mother away from her baby has no option but to pump her milk to prevent her from pain and serious health complications. This mother may have to pump milk very often. Pumping is less efficient than nursing, so she will be gone for longer in each break or she will have more breaks compared to a mother that travels with her baby. For pumping, people need a room which should ideally be private, with a sink, and located as close to the conference venue as possible. It is often impossible for these three conditions to be met at the same time, so different mothers give priority to different features. Some people pump milk in washrooms, to have easy access to water. Other people might prefer to pump in a more comfortable setting, such as an office, and go to the washroom to wash the breast pump accessories after. If the mother expects that the baby will drink breastmilk while she is away, then she will also have to pump milk in advance of her trip. This requires some careful planning.Many pumping mothers try to store the pumped milk and bring it back home. In this case the mother needs a hotel room with a fridge which (ideally, but hard to find) has a freezer. In a perfect world there would also be a fridge in the place where she pumps/where the conference is held.")]
)

#text("It is important to keep in mind that each option has its own set of challenges (even when expenses and facilities are all covered) and that different families may be restricted in their choice of options for a variety of reasons. It is therefore important that all these three options be facilitated.")

#text("As for the effect these choices have on the conference experience for the mother, Option 1 means that she has to balance her time between the conference and spending time with her relative/friend. This pressure disappears when we consider Option 2, so this option may lead to more participation in the conferences activities. In Option 3, the mother is in principle free to participate in all the conference activities, but the frequent breaks may limit the type of activity. A mother may choose different options depending on the nature of the conference.")

#text("I want to stress, for the three options, that having to make choices about what to miss in the conference is very hard. While talks are important, so are the opportunities to meet people and discuss mathematics that happen during breaks and social events. It is very difficult to balance all of this. This is particularly difficult for the pumping mother in Option 3: because she travels without her baby, she is not perceived to be a in special situation or in need of accommodation. However, this mother is probably choosing between going to the last lecture in the morning or having lunch alone, because if she goes to pump right after the last lecture, by the time she is back, everybody has left for lunch.")

#text("Here is the Hall of Fame for those organizations that are already supporting nursing mothers’ travels in mathematics:")

#list(
[#text("The ")#link("http://www.nserc-crsng.gc.ca/Professors-Professeurs/FinancialAdminGuide-guideAdminFinancier/FundsUse-UtilisationSubventions_eng.asp")[#text("Natural Sciences and Engineering Research Council of Canada (NSERC)")]#text(" (search for “child care”) allows to reimburse the costs of child care with Option 2 out of the mother’s grants. They will also reimburse the travel expenses of a relative with Option 1 up to the amount that would cost to hire a local caregiver.")],
[#text("The ")#link("https://www.hcm.uni-bonn.de/en/events/eventpages/2014/analytic-number-theory-2014/description/")[#text("ENFANT/ELEFANT conference")]#text(" (co-organized by ")#link("http://www.math.duke.edu/~pierce/")[#text("Lillian Pierce")]#text(" and ")#link("http://www.math.uni-bonn.de/people/dschindl/")[#text("Damaris Schindler")]#text(") provided a good model to follow regarding accommodation for parents with children during conferences that included funding for covering the travel costs of accompanying caretakers (the funding was provided by the ")#link("http://www.dfg.de/en/")[#text("Deutsche Forschungsgemeinschaft")]#text(", and lactation rooms and play rooms near the conference venue (the facilities were provided by the ")#link("http://www.hausdorff-center.uni-bonn.de/")[#text("Hausdorff Center for Mathematics")]#text(").Additional information (where to go with kids, etc) was provided on site by the organizers and was made available to all participants all the time, by means of a display board that was left standing during the whole week of the conference.")],
[#text("The ")#link("http://aimath.org/visitors/child-care/")[#text("American Institute of Mathematics (AIM)")]#text(" reimburses up to 500 dollars on childcare for visitors and they have some online resources that assist in finding childcare and nannies.")]
)

#text("[UPDATED] Added a few more things to the Hall of Fame")

#list(
[#text("The ")#link("https://jointmathematicsmeetings.org/meetings/national/jmm2014/2160_daycare")[#text("Joint Mathematics Meetings")]#text(" have been providing onsite childcare in the last few years.")],
[#text("The ")#link("https://www.ipam.ucla.edu/visitors/childcare.aspx")[#text("Institute for Applied Mathematics (IPAM)")]#text(" provides childcare resources and funding to workshop participants with small children (comment from ")#link("http://www.juliawolf.org/")[#text("juliawolf")]#text(").")],
[#text("The ")#link("http://simons.berkeley.edu/")[#text("Simons Institute for the Theory of Computing")]#text(" at Berkeley has a separate lactation room as part of some female washrooms (comment from ")#link("http://www.juliawolf.org/")[#text("juliawolf")]#text(").")],
[#text("The ")#link("http://www.lms.ac.uk/grants/childcare-supplementary-grants")[#text("London Mathematical Society (LMS)")]#text(" offers Childcare Supplementary Grants of up to £200 to all mathematicians based in the UK travelling to conferences and other research schools, meetings or visits (comments from Peter).")]
)

#text("In closing, here is a (possibly incomplete) list of resources that institutes, funding agencies, and conferences could consider providing for nursing mother mathematicians:")

#list(

)

#text("I also find it important that these resources be listed publicly in the institute/conference website. This serves a double purpose: first, it helps those in need of the resources to access them easily, and second, it contributes to make these accommodations normal, setting a good model for future events, and inspiring organizers of future events.")

#text("Finally, I am pretty sure that the options and solutions I described do not cover all cases. I would like to finish this note by inviting readers to make suggestions, share experiences, and/or pose questions about this topic.")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad3f3a79ef213c98c05db1ab441cb92661583507ac1a7a5e31f4beaa785f1e3b-bd0c7862157994459c7704585bcfde3a1c363765d691789fd896ca4a5396e667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407736")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("What an excellent article! Thank you, Matilde – I will definitely be referring to these thoughtful points in the future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63f55ae95e48efbc787b5cb33d4fd1c9d226968a323b86fefa542bacef783e36-a3a86c1ab2b809bcbba188b39619ef5fe8ba63cd0812c28d2114adbab1e3c1bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R.m")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407779")[#strong[#text("R.m")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("I experienced option three twice when my children were one year old. It requires a serious motivation. Not so easy to do a trip of one week far away from home (7 hours by plane ) in this context….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63f55ae95e48efbc787b5cb33d4fd1c9d226968a323b86fefa542bacef783e36-a3a86c1ab2b809bcbba188b39619ef5fe8ba63cd0812c28d2114adbab1e3c1bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R.m")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407782")[#strong[#text("R.m")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("Ps. But it can be done. I am happy to have been able to continue breath feeding and attending conferences with this pumping option.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9bf368871c7cad7693f43f06b89dac74ccd870b692b04453979fe238b35ea23-15844e5a4acf5adea389396bf2f0ef15f65769fca58f3bce1b04cb8c5ab78245.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("Thanks for blogging about this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7baa8b73879c1e7a27bcddb2d22a7c4cb1e3f04101acf33ec2d04643dfcfe99a-c5de2c69d38f6ac1994da3b2cd8cfdb6a098320350a5295e9cfa1a2de0fddc60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of streneer")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407860")[#strong[#text("streneer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("Matilde, thanks so much for writing this! I have skipped a few conferences in the last year because I couldn’t figure out how to make it work with my baby. We really need these types of accommodations to become the norm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b4b3d40f2b05a0afebcb461f84bf503c0ac620fda979c6b9a2810650d03c02a3-f97cb9d6a4e0ff546b0c47bbaa89e50da69f249c6cb9d1bde7da8015d3f0bd6f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of juliawolf")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407880")[#strong[#text("juliawolf")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("Just to add to your hall of fame, Matilde, I believe that IPAM provides assistance (both logistic and financial) to workshop participants with small children, although they do not make this clear on their website. The new Simons Institute for the Theory of Computing at Berkeley has a separate lactation room as part of the female washrooms on the second floor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6ac79e3caf04e037ade5906bf5cfe998365b34c8051e14ac3ead7fd889219e-549e784f5facc676539fcc698859075626f561f18e95a68308c99738df295d98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matilde Lalin")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407921")[#strong[#text("Matilde Lalin")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("Thanks Julia! I also forgot the mention that the Joint Mathematics Meetings have been providing on-site childcare for the last few years.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35f8ceee929965a28612e4e1a0900e62b968da10247468dff7bbd4ad567e3d2d-bf9523eda5a5760967cd52ce8c274c7bade433251d9ebd051efb752f2d7be060.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407932")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("Adding to the list of helpful organisations, the London Mathematical Society will give up to £200 per child.")

#text("Since children get older, I would add to the wish list of resources a nearby playground location.")

#text("Adding to the possibilities for a nursing mother, 4. is to attend the conference with one’s partner working in the same field, and split the talks and social opportunities (it’s usually possible to work with a small baby present, with larger children this is limited by their willingness to play alone).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6ac79e3caf04e037ade5906bf5cfe998365b34c8051e14ac3ead7fd889219e-549e784f5facc676539fcc698859075626f561f18e95a68308c99738df295d98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mlalin")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407946")[#strong[#text("mlalin")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("Thanks Peter! Could you please give me some context in which the LMS will give the £200? Will they pay this money each time an academic goes to any conference with a baby or just the LMS conferences? Do they pay for older children too?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35f8ceee929965a28612e4e1a0900e62b968da10247468dff7bbd4ad567e3d2d-bf9523eda5a5760967cd52ce8c274c7bade433251d9ebd051efb752f2d7be060.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-408166")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2014")])]

#link("http://www.lms.ac.uk/grants/childcare-supplementary-grants")[#text("http://www.lms.ac.uk/grants/childcare-supplementary-grants")]

#text("is the link to the LMS scheme. I don’t know what age they would refuse to pay; probably when they cease to believe that there is not a better option than bringing the child with.")

#text("It seems that ‘childcare’ is fairly broadly interpreted, and the first criterion is dealt with by the LMS sending a complaint letter to whichever institution is not providing support (so perhaps this scheme has the extra positive of kicking unhelpful institutions into making some provisions).")

#text("The scheme actually covers more or less any research trip: but obviously if one goes somewhere for a month then £200 doesn’t go far (which they obviously know, and I think they expect most requests to be for the maximum £200). I don’t know what happens if the LMS get several applications a year from the same parents.")

#text("The ‘report’ isn’t expected to be detailed. If you gave a talk, or you can name a paper you worked on, then that seems to be enough.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6ac79e3caf04e037ade5906bf5cfe998365b34c8051e14ac3ead7fd889219e-549e784f5facc676539fcc698859075626f561f18e95a68308c99738df295d98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mlalin")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-408183")[#strong[#text("mlalin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2014")])]

#text("This is very good, since it’s so flexible. I’ve added it to the Hall of Fame. Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cb92e9dc551f35dfee57fd723678692ec6b022318396b6371c526f367fd911a-8ea22721c7bad9f36cd36bd2ec9fafa64ba5a7e614c6bebf6e8b24396a17fc17.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kate Owens (@katemath)")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-407986")[#strong[#text("Kate Owens (@katemath)")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("Thanks, Matilde. I really appreciate you blogging about this. It’s an important topic and I am always happy to see reminders that the set of mathematicians is not disjoint from the set of lactating mothers! I consider myself to be in both groups and it’s nice to know there’s a growing community of us.")

#text("Your list of options is slightly incomplete. Here’s another: “4. Nursing mothers who want to attend conferences can choose to postpone travel.” Now, I am not advocating this as the default strategy, nor am I suggesting it to anyone else. But for my family, this option works best, especially given that options 1-3 are not without costs (financial, emotional, etc). Hopefully options 1-3 will continue get easier over time and eventually no one will consider option 4.")

#text("And thank you to (1) everyone who is working to make conference travel easier on parents and (2) everyone who is lending a voice to important point that mathematicians are people — mothers, fathers, coaches, mentors, parents, siblings, care-takers, …– too.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6ac79e3caf04e037ade5906bf5cfe998365b34c8051e14ac3ead7fd889219e-549e784f5facc676539fcc698859075626f561f18e95a68308c99738df295d98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mlalin")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-408008")[#strong[#text("mlalin")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("Thanks Kate!")

#text("Not traveling (you can’t really postpone going to a conference, the conference will happen no matter what!) is certainly an option that everybody considers, I’m sure. No matter how many advantages that we get to facilitate options 1-3 (and Peter’s 4), there will always be mothers/families for whom not traveling is still the best option and that should be respected.")

#text("However, the option of not traveling may also have some costs career-wise, which is very very unfortunate, but very real as well. Hopefully, all the options will continue to get easier, including not traveling.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b067cc7c98e5c4b61b95ca8cace3984934a60b1c36f63ac99fb68e9b0e200fa1-e16501a6a582f5840488b8e6efac8baa92f1ca84eb54848405e6f330325b4dba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kate Owens (@katemath)")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-414851")[#strong[#text("Kate Owens (@katemath)")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2014")])]

#text("I’ve spent time thinking about this issue since August, and I do concede, as many have pointed out, that “not traveling may also have some costs career-wise.” For a variety of reasons, I’ve made several family and life decisions X that fall under the “X may also have some costs career-wise” beyond just conference travel.")

#text("For example, after the birth of my daughter, I took an entire 12-weeks off from campus (as afforded under FMLA guidelines), even though my “medical necessity” (and thus paid sick leave) ran out at 8-weeks. I could have returned to campus, research, teaching, advising, e-mailing, and so forth, but I chose not to. And I do think this is an X satisfying “X may also have some costs career-wise.”")

#text("Nevertheless, when I consider these personal decisions I’ve made for myself, I try to frame it internally as follows: I don’t want to work very, very hard to join a club where I am not welcomed as a member.")

#text("In this case — for me at least — when consciously making these [potentially] career-harming decisions, I choose to see it that I am withdrawing my name from consideration from a club that doesn’t want people around who make decisions the way I want to make decisions. In other words, if I were to have a boss who does not think I am devoted enough to my career, then this problem is solved not by me changing my decision-making algorithm, but instead by me finding a different boss.")

#text("[Thankfully, my current community of colleagues seems very accepting of the decisions in the way I have made them.]")

#text("Meanwhile, I will continue to push to change “X may have negative career consequences” to “X will not harm your career” for the values of X mentioned above.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-408012")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("In some very large conferences, there are overflow rooms for the main seminar room, in which the lecture is videotaped in the main room and projected onto the overflow. I think I have occasionally seen one of these rooms specifically set aside for nursing mothers or parents of rowdy children. It doesn’t fully substitute for actually being physically present when the speaker is talking, but it could add a little bit more flexibility.")

#text("Eventually, it may be that technology advances to the point where one can realistically “attend” a conference remotely via a video link and get most of the benefits of attendance (not just listening to the talks, but being able to converse with the speakers and other participants, and also being able to present a talk of one’s own). We’re not quite at that stage yet, though. (But times are changing. I recently saw a graduate student in a conference talk with earphones on, using her laptop to watch the live stream of the very talk she was sitting in! I was puzzled as to why she would do this, until there came a point where there was some confusion as to exactly what the lecturer had said, at which point she simply rewound the live stream a minute or so to listen to it again.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a72db09c48b700fdcffb875f480afba2e8236c0507b5d524bd86719e8dedf9c8-f35774a337ea22173173304a4bb0e26c4485207a28ed9c6496a7698e08c4b466.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Smith")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-408232")[#strong[#text("Adam Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2014")])]

#text("Great post.")

#text("I want to point out that fathers also face many of the issues in this post. They do not nurse, which makes separation from small kids logistically easier, but only if there is someone at the other end to stay with the kids (and who doesn’t have work constraints of his or her own).")

#text("Fathers have it easy, in some ways, since many heterosexual couples place most of the burden of raising small ids on the mother. But fathers who do have to travel with small kids face an extra burden of skepticism (“Isn’t that your wife’s job?”).")

#text("My wife and I are both academics and we have made many different arrangements to handle travel situations (we sometimes go to the same conferences, which is a mixed blessing). Hiring out of town nannies via agencies has generally been the most convenient choice, but we have used all three options (in addition to making heavy use of Option 4 — “stay home”).")

#text("Just a few pieces of advice:")

#text("– to find out of town nanny agencies with good reputations, call the concierge desks at a few high-end hotels in the area of the conference, and ask them if they have listings of agencies that their clients use often. Yelp and other web sites are also good resources.")

#text("– Don’t worry too much about financial cost. Extra child care is expensive, but most academics of child-bearing age are just beginning to reach their full earning power. For professional arrangements, it is ok to spend like someone much richer than you are right now — you will become that person in a few years. This is especially important for job interviews. Do NOT skimp on help. The department who is considering you probably doesn’t want to know that you are traveling with small children (in a perfect world, they would be impressed and offer to help you with childcare during your interview… but that is not the world we live in).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e355e3a80a94f0064db1fd34579cbf4f12e886d27c2461680bc16cb00e184050-08470ba9d8d7282bd01f70763571318aa842cf833b368c170ae8b8feb4d2952a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Julie Clutterbuck")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-408683")[#strong[#text("Julie Clutterbuck")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2014")])]

#text("The Australian Maths Society, at the instigation of the Women in Maths special interest group, has just funded a travel award to provide financial support for female and male mathematicians to help cover the cost of caring responsibilities while the mathematician travels to conferences or for research visits.")

#text("It is still new, but we expect the first round to open in September— info about it should be posted on the AustMS website soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39aa31feb0cfa9faf8768ab8f3f399758f3b78e8ed7d3408aa2eff04331ffe89-c2bd8f26260271224616f5f95e659a30b9378e2312d958124f6f10a82071912e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Greatest Good for the Greatest Linkspam (24 August 2014) | Geek Feminism Blog")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-409008")[#strong[#text("The Greatest Good for the Greatest Linkspam (24 August 2014) | Geek Feminism Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("[…] Attending conferences with small children | Matilde Lalin: “Mathematicians (and likely other academics!) with small children face some unique challenges when traveling to conferences and workshops.” (20 August) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6939f128c6938d1237ee80909187de4048c2c48fa33cdbb5e3b8a8b5ff9289c7-2afdfbe367c931ccda5d51a2fc63db84809e784ea692787109633f6108e83575.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rebekah Yates")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-409176")[#strong[#text("Rebekah Yates")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2014")])]

#text("Thanks for this post. As I contemplate attending my second JMM with a nursing child (kid #2 this time), it’s good to be reminded that I am not alone. I am grateful for a very supportive husband and other family members who help out so that option 1 is viable for us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c58d20ac76d30688691ba02cd1ba2090efa08a031aa044e1c84aebfd3e7a2b2-c6238ca5fb438c878029dd135258924aab53e9fd3b29079ad77063ed9f9048bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noah Snyder")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-412626")[#strong[#text("Noah Snyder")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2014")])]

#text("One of the biggest difficulties for organizers is that the US government will not reimburse conference child care expenses, because they’re not a “necessary” expense for traveling according to GAO. (See ")#link("http://quomodocumque.wordpress.com/2012/10/20/")[#text("http://quomodocumque.wordpress.com/2012/10/20/")]#text(" and ")#link("http://www.gao.gov/assets/510/503816.pdf")[#text("http://www.gao.gov/assets/510/503816.pdf")]#text(") Are there any non-government financial resources available to conference organizers in the US for funding child care?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21f981115eac23de64b0e57c9b310ac1a594a81242e2a7e7141f394cac10458f-62196923690a4a2e62fd0b0bbed8d60ae479c394bd19e7c6bea25a289fcbc9c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dmoskovich")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-417632")[#strong[#text("dmoskovich")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2014")])]

#text("I’ve seen people do Option 1 without the Friend/Relative, and indeed I was such a baby when my mum went to conferences. It’s really difficult, because giving a talk while holding a baby is non-trivial, and attending a talk while holding a baby can also be non-trivial. Support from the community and organizers can go a long way.")#linebreak()#text(" I believe strongly in a maximally mum-friendly and baby-friendly academic world.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc6ea076a129f4200c0594ec4fc1d46822551a44bca69512d29626f41543c5f6-dbd6a6ed53a48f71f4703d7ce6bf88dd7024b2d2855d1280bea6376165d06f61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-429496")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("Although I am always happy to see popular math blogs addressing difficulties that female mathematicians face, I am disappointed that the main public discussions mathematicians have on this issue center around childrearing and the availability of lactation rooms.")

#text("After seeing some of the open discussions about women in computing achieved at Grace Hopper this year, I am optimistic that the math community will be able to start its own public discussion about the many obstacles female mathematicians face.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6ac79e3caf04e037ade5906bf5cfe998365b34c8051e14ac3ead7fd889219e-549e784f5facc676539fcc698859075626f561f18e95a68308c99738df295d98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mlalin")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-429555")[#strong[#text("mlalin")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("I agree that there are many obstacles that female mathematicians face. Discussing some of them doesn’t preclude us from discussing others!!!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc6ea076a129f4200c0594ec4fc1d46822551a44bca69512d29626f41543c5f6-dbd6a6ed53a48f71f4703d7ce6bf88dd7024b2d2855d1280bea6376165d06f61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-429556")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("Fantastic! Then let’s start publicly discussing some of the issues that female mathematicians face such as less mentorship, less community support, less encouragement, and less respect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6ac79e3caf04e037ade5906bf5cfe998365b34c8051e14ac3ead7fd889219e-549e784f5facc676539fcc698859075626f561f18e95a68308c99738df295d98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mlalin")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-429557")[#strong[#text("mlalin")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("Unfortunately I don’t keep a blog myself.")

#text("There are several blogs that could serve as platforms for an article on such topics. You could start a dicussion by contacting the hosts and see if you could publish an article there.")

#text("One such blog is tenureshewrote here at wordpress.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc6ea076a129f4200c0594ec4fc1d46822551a44bca69512d29626f41543c5f6-dbd6a6ed53a48f71f4703d7ce6bf88dd7024b2d2855d1280bea6376165d06f61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-429558")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("This is a nice suggestion, but I wonder how many mathematicians read tenureshewrote.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6ac79e3caf04e037ade5906bf5cfe998365b34c8051e14ac3ead7fd889219e-549e784f5facc676539fcc698859075626f561f18e95a68308c99738df295d98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mlalin")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-429562")[#strong[#text("mlalin")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("You can always link the post here in the comments.")

#text("You can also contact the authors of PhD plus epsilon, or mathbabe…")

#text("These are suggestions from the top of my head. I’m sure there are more options.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc6ea076a129f4200c0594ec4fc1d46822551a44bca69512d29626f41543c5f6-dbd6a6ed53a48f71f4703d7ce6bf88dd7024b2d2855d1280bea6376165d06f61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-429570")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("I wrote to Maria Klawe, who is my new hero:")

#text("Dear Maria,")

#text("Thank you so much for sparking a national conversation about the difficulties women in computing face by hosting the Male Allies panel at Grace Hopper. It’s rare to see such a frank public discussion:")

#link("http://www.salon.com/2014/10/09/microsoft_ceo_to_women_dont_ask_for_a_raise_trust_the_system_and_karma/")[#text("http://www.salon.com/2014/10/09/microsoft_ceo_to_women_dont_ask_for_a_raise_trust_the_system_and_karma/")]

#text("I am writing to ask if you have any tips about how female mathematicians might be able to start a similar conversation. Right now, the only public discussions mathematicians have about the difficulties female mathematicians face center around childcare at conferences and the availability of lactation rooms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/")[#text("(Matilde Lalin) Attending conferences with small children")]
]

#text("As you can see, the public conversation about women in mathematics is several steps behind the kind of conversations that were happening at Grace Hopper, where everything from mentorship to asking for raises was discussed.")#linebreak()#text(" ———————")

#text("Maria responded IMMEDIATELY and said she would discuss this with several heads of prominent math societies.")

#text("One incredible thing that Grace Hopper did this year was to invite men to the conversation. Women in mathematics will not inspire real change until we’re able to discuss these issues openly with our male colleagues. This is why I am hesistant to spark this conversation on blogs that are primarily read by female mathematicians.")

#text("More importantly, I also think this issue needs to be handled with grace and tact by somebody well-respected. Maria Klawe, Terry Tao, and Tim Gowers are perhaps natural choices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/20/matilde-lalin-attending-conferences-with-small-children/#comment-459681")[#strong[#text("Childcare in academia: hall of fame - PaolaElefante.com")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2015")]

#text("[…] Matilde Lalin on Attending conferences with small children […]")
]
