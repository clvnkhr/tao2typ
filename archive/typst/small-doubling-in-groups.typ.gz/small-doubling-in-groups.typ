// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/02/01/small-doubling-in-groups/
// Converted to Typst by tao2typ: "2026-10-14T16:36:57.826869+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Small doubling in groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Small doubling in groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 February 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/02/01/small-doubling-in-groups/")[#text("https://terrytao.wordpress.com/2013/02/01/small-doubling-in-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.math.u-psud.fr/~breuilla/indexgb.html")[#text("Emmanuel Breuillard")]#text(", ")#link("https://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", and I have just uploaded to the arXiv our survey “")#link("http://arxiv.org/abs/1301.7718")[#text("Small doubling in groups")]#text("“, for the proceedings of the upcoming ")#link("http://www.renyi.hu/conferences/erdos100/index.html")[#text("Erdos Centennial")]#text(". This is a short survey of the known results on classifying finite subsets ")#mi("A")#text(" of an (abelian) additive group ")#mi("G = (G,+)")#text(" or a (not necessarily abelian) multiplicative group ")#mi("G = (G,\\cdot)")#text(" that have small doubling in the sense that the sum set ")#mi("A+A")#text(" or product set ")#mi("A \\cdot A")#text(" is small. Such sets behave approximately like finite subgroups of ")#mi("G")#text(" (and there is a closely related notion of an ")#emph[#text("approximate group")]#text(" in which the analogy is even tighter) , and so this subject can be viewed as a sort of approximate version of finite group theory. (Unfortunately, thus far the theory does not have much new to say about the classification of actual finite groups; progress has been largely made instead on classifying the (highly restricted) number of ways in which approximate groups can ")#emph[#text("differ")]#text(" from a genuine group.)")

#text("In the classical case when ")#mi("G")#text(" is the integers ")#mi("{\\mathbb Z}")#text(", these sets were classified (in a qualitative sense, at least) by a celebrated ")#link("http://en.wikipedia.org/wiki/Freiman's_theorem")[#text("theorem of Freiman")]#text(", which roughly speaking says that such sets ")#mi("A")#text(" are necessarily “commensurate” in some sense with a ")#link("http://en.wikipedia.org/wiki/Generalized_arithmetic_progression")[#text("(generalised) arithmetic progression")]#text(" ")#mi("P")#text(" of bounded rank. There are a number of essentially equivalent ways to define what “commensurate” means here; for instance, in the original formulation of the theorem, one asks that ")#mi("A")#text(" be a dense subset of ")#mi("P")#text(", but in modern formulations it is often more convenient to require instead that ")#mi("A")#text(" be of comparable size to ")#mi("P")#text(" and be covered by a bounded number of translates of ")#mi("P")#text(", or that ")#mi("A")#text(" and ")#mi("P")#text(" have an intersection that is of comparable size to both ")#mi("A")#text(" and ")#mi("P")#text(" (cf. the notion of ")#link("http://en.wikipedia.org/wiki/Commensurability_(mathematics)#Commensurability_in_group_theory")[#text("commensurability in group theory")]#text(").")

#text("Freiman’s original theorem was extended to more general abelian groups in a sequence of papers ")#link("http://www.ams.org/mathscinet-getitem?mr=2302736")[#text("culminating in the paper of Green and Ruzsa")]#text(" that handled arbitrary abelian groups. As such groups now contain non-trivial finite subgroups, the conclusion of the theorem must be modified by allowing for “coset progressions” ")#mi("P+H")#text(", which can be viewed as “extensions” of generalized arithmetic progressions ")#mi("P")#text(" by genuine finite groups ")#mi("H")#text(".")

#text("The proof methods in these abelian results were Fourier-analytic in nature (except in the cases of sets of very small doubling, in which more combinatorial approaches can be applied, and there were also some geometric or combinatorial methods that gave some weaker structural results). As such, it was a challenge to extend these results to nonabelian groups, although for various important special types of ambient group ")#mi("G")#text(" (such as an linear group over a finite or infinite field) it turns out that one can use tools exploiting the special structure of those groups (e.g. for linear groups one would use tools from Lie theory and algebraic geometry) to obtain quite satisfactory results; see e.g. this ")#link("http://arxiv.org/abs/1208.2538")[#text("survey of Pyber and Szabo")]#text(" for the linear case. When the ambient group ")#mi("G")#text(" is completely arbitrary, it turns out the problem is closely related to the classical Hilbert’s fifth problem of determining the minimal requirements of a topological group in order for such groups to have Lie structure; this connection was first observed and exploited ")#link("http://www.ams.org/mathscinet-getitem?mr=2833482")[#text("by Hrushovski")]#text(", and then used ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("by Breuillard, Green, and myself")]#text(" to obtain the analogue of Freiman’s theorem for an arbitrary nonabelian group.")

#text("This survey is too short to discuss in much detail the proof techniques used in these results (although the abelian case is discussed in ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("this book of mine with Vu")]#text(", and the nonabelian case discussed in this ")#link("https://terrytao.wordpress.com/books/hilberts-fifth-problem-and-related-topics/")[#text("more recent book of mine")]#text("), but instead focuses on the statements of the various known results, as well as some remaining open questions in the subject (in particular, there is substantial work left to be done in making the estimates more quantitative, particularly in the nonabelian setting).")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31d9bf85fc50a928eaaf22cdbcca23dcdfd1a1507be8ef371263a2cabb8cd8-737be98b98745aa666e1df2900b358e7a60a88e09cad53428d115a8bba58c532.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jan de Wit")]], [#link("https://terrytao.wordpress.com/2013/02/01/small-doubling-in-groups/#comment-215717")[#strong[#text("Jan de Wit")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2013")])]

#text("The definition of P(u1; N1) on page 2 ( {h0 + n1u1 : 0 <= n1 < N1} ) has a term 'h0' which shouldn't be there; the definition is the same as that of A, 2 lines further.")

#text("[")#emph[#text("Thanks, this will be corrected in the next revision of the ms – T.")]#text("]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d4f4df6f2bcd9d99f73f1fc9d944014e7a32316887ed5fc3d0e89ad9fe92876-1a5e6a2f6ce5af004b75fd46e6f2faee42ee4ca8caf29557d785f9ca9cb5286d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Beech")]], [#link("https://terrytao.wordpress.com/2013/02/01/small-doubling-in-groups/#comment-217818")[#strong[#text("Sam Beech")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2013")])]

#text("I’m only a third year student so it’s nice to find a journal isn’t 100 years old that I can understand! Thank you, I’ll give it a read tonight.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc6ba7abdc8a6c82b2c0b0ebab71fc1dca8d807a7f5e16573f38d2bf0b627591-5a45f423ae2bdec4ba97d45901a201e078e14ea1874653a4aae61549482f9f04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2013/02/01/small-doubling-in-groups/#comment-245016")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("Given ")#mi("A")#text(" a finite set of integers whose absolute value is bounded by ")#mi("B")#text(", what is the maximum cardinality of ")#mi("kA")#text("? I know minimum cardinality can be guaranteed by taking ")#mi("A")#text(" to be sequences in AP.")
]
