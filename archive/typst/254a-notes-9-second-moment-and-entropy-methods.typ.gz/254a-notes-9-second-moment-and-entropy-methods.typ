// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/
// Converted to Typst by tao2typ: "2026-10-14T10:56:12.770774+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 9 – second moment and entropy methods", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 9 – second moment and entropy methods")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 November 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/")[#text("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In these notes we presume familiarity with the basic concepts of probability theory, such as random variables (which could take values in the reals, vectors, or other measurable spaces), probability, and expectation. Much of this theory is in turn based on measure theory, which we will also presume familiarity with. See for instance this previous set of lecture notes for a ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("brief review")]#text(".")

#text("The basic objects of study in analytic number theory are deterministic; there is nothing inherently random about the set of prime numbers, for instance. Despite this, one can still interpret many of the averages encountered in analytic number theory in probabilistic terms, by introducing random variables into the subject. Consider for instance the form ")#metadata(none) <tao-a160524700113ddd3205>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq x} \\mu(n) = o(x)")]]

#linebreak()#text(" of the prime number theorem (where we take the limit ")#mi("{x \\rightarrow \\infty}")#text("). One can interpret this estimate probabilistically as ")#metadata(none) <tao-ef2e294ff382fb195780>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\mathbb E} \\mu(\\mathbf{n}) = o(1)")]]

#text(" where ")#mi("{\\mathbf{n} = \\mathbf{n}_{\\leq x}}")#text(" is a random variable drawn uniformly from the natural numbers up to ")#mi("{x}")#text(", and ")#mi("{{\\mathbb E}}")#text(" denotes the expectation. (In this set of notes we will use boldface symbols to denote random variables, and non-boldface symbols for deterministic objects.) By itself, such an interpretation is little more than a change of notation. However, the power of this interpretation becomes more apparent when one then imports concepts from probability theory (together with all their attendant intuitions and tools), such as ")#link("https://en.wikipedia.org/wiki/Independence_(probability_theory)")[#text("independence")]#text(", ")#link("https://en.wikipedia.org/wiki/Conditional_probability")[#text("conditioning")]#text(", ")#link("https://en.wikipedia.org/wiki/Stationary_process")[#text("stationarity")]#text(", ")#link("https://en.wikipedia.org/wiki/Total_variation_distance_of_probability_measures")[#text("total variation distance")]#text(", and ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("entropy")]#text(". For instance, suppose we want to use the prime number theorem ")#link(<tao-a160524700113ddd3205>)[#text("(1)")]#text(" to make a prediction for the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\mu(n+1).")]]

#text("After dividing by ")#mi("{x}")#text(", this is essentially")

#align(center)[#tao-fit-display[#mitex("{\\mathbb E} \\mu(\\mathbf{n}) \\mu(\\mathbf{n}+1).")]]

#text("With probabilistic intuition, one may expect the random variables ")#mi("{\\mu(\\mathbf{n}), \\mu(\\mathbf{n}+1)}")#text(" to be approximately independent (there is no obvious relationship between the number of prime factors of ")#mi("{\\mathbf{n}}")#text(", and of ")#mi("{\\mathbf{n}+1}")#text("), and so the above average would be expected to be approximately equal to")

#align(center)[#tao-fit-display[#mitex("({\\mathbb E} \\mu(\\mathbf{n})) ({\\mathbb E} \\mu(\\mathbf{n}+1))")]]

#text("which by ")#link(<tao-ef2e294ff382fb195780>)[#text("(2)")]#text(" is equal to ")#mi("{o(1)}")#text(". Thus we are led to the prediction ")#metadata(none) <tao-708c9a5170d3af96d708>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\leq x} \\mu(n) \\mu(n+1) = o(x).")]]

#text(" The asymptotic ")#link(<tao-708c9a5170d3af96d708>)[#text("(3)")]#text(" is widely believed (it is a special case of the ")#emph[#text("Chowla conjecture")]#text(", which we will discuss in later notes; while there has been recent progress towards establishing it rigorously, it remains open for now.")#linebreak()#text(" How would one try to make these probabilistic intuitions more rigorous? The first thing one needs to do is find a more quantitative measurement of what it means for two random variables to be “approximately” independent. There are several candidates for such measurements, but we will focus in these notes on two particularly convenient measures of approximate independence: the “")#mi("{L^2}")#text("” measure of independence known as ")#link("https://en.wikipedia.org/wiki/Covariance")[#text("covariance")]#text(", and the “")#mi("{L \\log L}")#text("” measure of independence known as ")#link("https://en.wikipedia.org/wiki/Mutual_information")[#text("mutual information")]#text(" (actually we will usually need the more general notion of ")#link("https://en.wikipedia.org/wiki/Conditional_mutual_information")[#text("conditional mutual information")]#text(" that measures ")#link("https://en.wikipedia.org/wiki/Conditional_independence")[#text("conditional independence")]#text("). The use of ")#mi("{L^2}")#text(" type methods in analytic number theory is well established, though it is usually not described in probabilistic terms, being referred to instead by such names as the “second moment method”, the “large sieve” or the “method of bilinear sums”. The use of ")#mi("{L \\log L}")#text(" methods (or “entropy methods”) is much more recent, and has been able to control certain types of averages in analytic number theory that were out of reach of previous methods such as ")#mi("{L^2}")#text(" methods. For instance, in later notes we will use entropy methods to establish the logarithmically averaged version ")#metadata(none) <tao-2f2eabbabee9cea40f23>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n \\leq x} \\frac{\\mu(n) \\mu(n+1)}{n} = o(\\log x)")]]

#linebreak()#text(" of ")#link(<tao-708c9a5170d3af96d708>)[#text("(3)")]#text(", which is implied by ")#link(<tao-708c9a5170d3af96d708>)[#text("(3)")]#text(" but strictly weaker (much as the prime number theorem ")#link(<tao-a160524700113ddd3205>)[#text("(1)")]#text(" implies the bound ")#mi("{\\sum_{n \\leq x} \\frac{\\mu(n)}{n} = o(\\log x)}")#text(", but the latter bound is much easier to establish than the former).")#linebreak()#text(" As with many other situations in analytic number theory, we can exploit the fact that certain assertions (such as approximate independence) can become significantly easier to prove if one only seeks to establish them ")#emph[#text("on average")]#text(", rather than uniformly. For instance, given two random variables ")#mi("{\\mathbf{X}}")#text(" and ")#mi("{\\mathbf{Y}}")#text(" of number-theoretic origin (such as the random variables ")#mi("{\\mu(\\mathbf{n})}")#text(" and ")#mi("{\\mu(\\mathbf{n}+1)}")#text(" mentioned previously), it can often be extremely difficult to determine the extent to which ")#mi("{\\mathbf{X},\\mathbf{Y}}")#text(" behave “independently” (or “conditionally independently”). However, thanks to second moment tools or entropy based tools, it is often possible to assert results of the following flavour: if ")#mi("{\\mathbf{Y}_1,\\dots,\\mathbf{Y}_k}")#text(" are a large collection of “independent” random variables, and ")#mi("{\\mathbf{X}}")#text(" is a further random variable that is “not too large” in some sense, then ")#mi("{\\mathbf{X}}")#text(" must necessarily be nearly independent (or conditionally independent) to many of the ")#mi("{\\mathbf{Y}_i}")#text(", even if one cannot pinpoint precisely which of the ")#mi("{\\mathbf{Y}_i}")#text(" the variable ")#mi("{\\mathbf{X}}")#text(" is independent with. In the case of the second moment method, this allows us to compute correlations such as ")#mi("{{\\mathbb E} {\\mathbf X} \\mathbf{Y}_i}")#text(" for “most” ")#mi("{i}")#text(". The entropy method gives bounds that are significantly weaker quantitatively than the second moment method (and in particular, in its current incarnation at least it is only able to say non-trivial assertions involving interactions with residue classes at small primes), but can control significantly more general quantities ")#mi("{{\\mathbb E} F( {\\mathbf X}, \\mathbf{Y}_i )}")#text(" for “most” ")#mi("{i}")#text(" thanks to tools such as the ")#link("https://en.wikipedia.org/wiki/Pinsker%27s_inequality")[#text("Pinsker inequality")]#text(".")

#metadata(none) <tao-05e246930954f31c253f>

#heading(level: 1)[#strong[#text(" — 1. Second moment methods — ")]]

#text("In this section we discuss probabilistic techniques of an “")#mi("{L^2}")#text("” nature. We fix a probability space ")#mi("{(\\Omega, {\\mathcal F}, \\mathop{\\bf P})}")#text(" to model all of random variables; thus for instance we shall model a complex random variable ")#mi("{\\mathbf{X}}")#text(" in these notes by a measurable function ")#mi("{\\mathbf{X}: \\Omega \\rightarrow {\\bf C}}")#text(". (Strictly speaking, there is a subtle distinction one can maintain between a random variable and its various measure-theoretic models, which becomes relevant if one later decides to modify the probability space ")#mi("{\\Omega}")#text(", but this distinction will not be so important in these notes and so we shall ignore it. See ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("this previous set of notes")]#text(" for more discussion.)")

#text("We will focus here on the space ")#mi("{L^2 = L^2(\\Omega, {\\mathcal F}, \\mathop{\\bf P})}")#text(" of complex random variables ")#mi("{\\mathbf{X}}")#text(" (that is to say, measurable maps ")#mi("{\\mathbf{X}: \\Omega \\rightarrow {\\bf C}}")#text(") whose ")#emph[#text("second moment")]

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E}(\\left|\\mathbf{X}\\right|^2)", block: true)]]

#text("of ")#mi("{\\mathbf{X}}")#text(" is finite. In many number-theoretic applications the finiteness of the second moment will be automatic because ")#mi("{\\mathbf{X}}")#text(" will only take finitely many values. As is well known, the space ")#mi("{L^2}")#text(" has the structure of a complex Hilbert space, with inner product")

#align(center)[#tao-fit-display[#mitex("\\langle \\mathbf{X}, \\mathbf{Y} \\rangle_{L^2} := {\\mathbb E}(\\mathbf{X} \\overline{\\mathbf{Y}})")]]

#text("and norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathbf{X} \\right\\|_{L^2} := ({\\mathbb E} (\\left|\\mathbf{X}\\right|^2))^{1/2}", block: true)]]

#text("for ")#mi("{\\mathbf{X},\\mathbf{Y} \\in L^2}")#text(". By slight abuse of notation, the complex numbers ")#mi("{{\\bf C}}")#text(" can be viewed as a subset of ")#mi("{L^2}")#text(", by viewing any given complex number ")#mi("{z}")#text(" as a constant (deterministic) random variable. Then ")#mi("{{\\bf C}}")#text(" is a one-dimensional subspace of ")#mi("{L^2}")#text(", spanned by the unit vector ")#mi("{1 \\in L^2}")#text(". Given a random variable ")#mi("{\\mathbf{X}}")#text(" to ")#mi("{L^2}")#text(", the projection of ")#mi("{\\mathbf{X}}")#text(" to ")#mi("{{\\bf C}}")#text(" is then the ")#emph[#text("mean")]

#align(center)[#tao-fit-display[#mitex("{\\mathbb E} \\mathbf{X} =\\langle \\mathbf{X}, 1 \\rangle,")]]

#text("and we obtain an orthogonal splitting ")#mi("{\\mathbf{X} = ({\\mathbb E} \\mathbf{X}) + (\\mathbf{X} - {\\mathbb E} \\mathbf{X})}")#text(" of any ")#mi("{\\mathbf{X} \\in L^2}")#text(" into its mean ")#mi("{{\\mathbb E} \\mathbf{X}}")#text(" and its mean zero part ")#mi("{\\mathbf{X} - {\\mathbb E} \\mathbf{X}}")#text(". By Pythagoras’ theorem, we then have")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E}(\\left|\\mathbf{X}\\right|^2) = {\\mathbb E}(\\left|\\mathbf{X} - {\\mathbb E} \\mathbf{X}\\right|^2) + {\\mathbb E} \\left|{\\mathbb E} \\mathbf{X}\\right|^2.", block: true)]]

#text("The first quantity on the right-hand side is the square of the distance from ")#mi("{\\mathbf{X}}")#text(" to ")#mi("{{\\bf C}}")#text(", and this non-negative quantity is known as the ")#link("https://en.wikipedia.org/wiki/Variance")[#text("variance")]#text(" ")#metadata(none) <tao-71a5a9c13dda7ea480e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\mathrm{Var} \\mathbf{X} := {\\mathbb E}(\\left|\\mathbf{X} - {\\mathbb E} \\mathbf{X}\\right|^2) = {\\mathbb E}(\\left|\\mathbf{X}\\right|^2) - \\left|{\\mathbb E} \\mathbf{X}\\right|^2.", block: true)]]

#text(" The square root ")#tao-math("{(\\mathrm{Var} \\mathbf{X})^{1/2} = \\left\\| \\mathbf{X} - {\\mathbb E} \\mathbf{X} \\right\\|_{L^2}}", block: false)#text(" of the variance is known as the ")#link("https://en.wikipedia.org/wiki/Standard_deviation")[#text("standard deviation")]#text(". The variance controls the distribution of the random variable ")#mi("{\\mathbf{X}}")#text(" through ")#link("https://en.wikipedia.org/wiki/Chebyshev%27s_inequality")[#text("Chebyshev’s inequality")]#text(" ")#metadata(none) <tao-01fa52e23fcff7b6e69a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("{\\mathbb P}( \\left|\\mathbf{X} - {\\mathbb E} \\mathbf{X}\\right| \\geq \\lambda ) \\leq \\frac{\\mathrm{Var}(\\mathbf{X})}{\\lambda^2}", block: true)]]

#text(" for any ")#mi("{\\lambda > 0}")#text(", which is immediate from observing the inequality ")#tao-math("{1_{\\left|\\mathbf{X} - {\\mathbb E} \\mathbf{X}\\right| \\geq \\lambda} \\leq \\frac{\\left|\\mathbf{X} - {\\mathbb E} \\mathbf{X}\\right|^2}{\\lambda^2}}", block: false)#text(" and then taking expectations of both sides. Roughly speaking, this inequality asserts that ")#mi("{\\mathbf{X}}")#text(" typically deviates from its mean ")#mi("{{\\mathbb E} \\mathbf{X}}")#text(" by no more than a bounded multiple of the standard deviation ")#mi("{(\\mathrm{Var} \\mathbf{X})^{1/2}}")#text(".")#linebreak()#text(" A slight generalisation of Chebyshev’s inequality that can be convenient to use is ")#metadata(none) <tao-6f6976e9b0f9317466cd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("{\\mathbb P}( \\left|\\mathbf{X} - \\mu\\right| \\geq \\lambda ) \\leq \\frac{\\mathrm{Var}(\\mathbf{X}) + \\left|{\\mathbb E} \\mathbf{X} - \\mu\\right|^2}{\\lambda^2}", block: true)]]

#linebreak()#text(" for any ")#mi("{\\lambda > 0}")#text(" and any complex number ")#mi("{\\mu}")#text(" (which typically will be a simplified approximation to the mean ")#mi("{{\\mathbb E} \\mathbf{X}}")#text("), which is proven similarly to ")#link(<tao-01fa52e23fcff7b6e69a>)[#text("(6)")]#text(" but noting (from ")#link(<tao-71a5a9c13dda7ea480e6>)[#text("(5)")]#text(") that ")#tao-math("{{\\mathbb E} \\left|\\mathbf{X}-\\mu\\right|^2 = \\mathrm{Var}(\\mathbf{X}) + \\left|{\\mathbb E} \\mathbf{X} - \\mu\\right|^2}", block: false)#text(".")#linebreak()#text(" Informally, ")#link(<tao-01fa52e23fcff7b6e69a>)[#text("(6)")]#text(" is an assertion that a square-integrable random variable ")#mi("{\\mathbf{X}}")#text(" will ")#link("https://en.wikipedia.org/wiki/Concentration_of_measure")[#text("concentrate")]#text(" around its mean ")#mi("{{\\mathbb E} \\mathbf{X}}")#text(" if its variance is not too large. See ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("these previous notes")]#text(" for more discussion of the concentration of measure phenomenon. One can often obtain stronger concentration of measure than what is provided by Chebyshev’s inequality if one is able to calculate higher moments than the second moment, such as the fourth moment ")#tao-math("{{\\mathbb E} \\left|\\mathbf{X}\\right|^4}", block: false)#text(" or exponential moments ")#mi("{{\\mathbb E} e^{c\\mathbf{X}}}")#text(", but we will not pursue this direction in this set of notes.")

#text("Clearly the variance is homogeneous of order two, thus")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Var}(c\\mathbf{X}) = \\left|c\\right|^2 \\mathrm{Var}(\\mathbf{X})", block: true)]]

#text("for any ")#mi("{\\mathbf{X} \\in L^2}")#text(" and ")#mi("{c \\in {\\bf C}}")#text(". In particular, the variance is not always additive: the claim ")#mi("{\\mathrm{Var}(\\mathbf{X}+\\mathbf{Y}) = \\mathrm{Var}(\\mathbf{X}) + \\mathrm{Var}(\\mathbf{Y})}")#text(" fails in particular when ")#mi("{\\mathbf{X}=\\mathbf{Y}}")#text(" is not almost surely zero. However, there is an important substitute for this formula. Given two random variables ")#mi("{\\mathbf{X},\\mathbf{Y} \\in L^2}")#text(", the inner product of the corresponding mean zero parts ")#mi("{\\mathbf{X} - {\\mathbb E} \\mathbf{X}, \\mathbf{Y} - {\\mathbb E} \\mathbf{Y}}")#text(" is a complex number known as the ")#link("https://en.wikipedia.org/wiki/Covariance")[#text("covariance")]#text(":")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Cov}(\\mathbf{X},\\mathbf{Y}) := \\langle \\mathbf{X}-{\\mathbb E} \\mathbf{X}, \\mathbf{Y} - {\\mathbb E} \\mathbf{Y} \\rangle_{L^2} = {\\mathbb E}( (\\mathbf{X}-{\\mathbb E} \\mathbf{X}) \\overline{(\\mathbf{Y} - {\\mathbb E} \\mathbf{Y})} ).")]]

#text("As ")#mi("{{\\mathbb E} \\mathbf{X}, {\\mathbb E} \\mathbf{Y}}")#text(" are orthogonal to ")#mi("{\\mathbf{X}-{\\mathbb E} \\mathbf{X}, \\mathbf{Y} - {\\mathbb E} \\mathbf{Y}}")#text(", it is not difficult to obtain the alternate formula ")#metadata(none) <tao-23c5bb276c87edba25e1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\mathrm{Cov}(\\mathbf{X},\\mathbf{Y}) := \\langle \\mathbf{X}, \\mathbf{Y} \\rangle_{L^2} - \\langle {\\mathbb E} \\mathbf{X}, {\\mathbb E} \\mathbf{Y} \\rangle = {\\mathbb E}(\\mathbf{X} \\overline{\\mathbf{Y}}) - ({\\mathbb E} \\mathbf{X}) \\overline{{\\mathbb E} \\mathbf{Y}}")]]

#text(" for the covariance.")#linebreak()#text(" The covariance is then a positive semi-definite inner product on ")#mi("{L^2}")#text(" (it basically arises from the Hilbert space structure of the space ")#mi("{{\\bf C}^\\perp}")#text(" of mean zero variables), and ")#mi("{\\mathrm{Cov}(\\mathbf{X},\\mathbf{X}) = \\mathrm{Var}(\\mathbf{X})}")#text(". From the Cauchy-Schwarz inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathrm{Cov}(\\mathbf{X},\\mathbf{Y})\\right| \\leq \\mathrm{Var}(\\mathbf{X})^{1/2} \\mathrm{Var}(\\mathbf{Y})^{1/2}.", block: true)]]

#text("If ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" have non-zero variance (that is, they are not almost surely constant), then the ratio")

#align(center)[#tao-fit-display[#mitex("\\frac{\\mathrm{Cov}(\\mathbf{X},\\mathbf{Y})}{\\mathrm{Var}(\\mathbf{X})^{1/2} \\mathrm{Var}(\\mathbf{Y})^{1/2}}")]]

#text("is then known as the ")#link("https://en.wikipedia.org/wiki/Correlation_and_dependence")[#text("correlation")]#text(" between ")#mi("{\\mathbf{X}}")#text(" and ")#mi("{\\mathbf{Y}}")#text(", and is a complex number of magnitude at most ")#mi("{1}")#text("; for real-valued ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" that are not almost surely constant, the correlation is instead a real number between ")#mi("{-1}")#text(" and ")#mi("{1}")#text(". At one extreme, a correlation of magnitude ")#mi("{1}")#text(" occurs if and only if ")#mi("{\\mathbf{X} - {\\mathbb E} \\mathbf{X}}")#text(" is a scalar multiple of ")#mi("{\\mathbf{Y} - {\\mathbb E} \\mathbf{Y}}")#text(". At the other extreme, a correlation of zero is an indication (though not a guarantee) of ")#link("https://en.wikipedia.org/wiki/Independence_(probability_theory)")[#text("independence")]#text(". Recall that two random variables ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" are ")#emph[#text("independent")]#text(" if one has")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}( \\mathbf{X} \\in E, \\mathbf{Y} \\in F ) = {\\mathbb P}( \\mathbf{X} \\in E ) {\\mathbb P}( \\mathbf{Y} \\in F )")]]

#text("for all (Borel) measurable ")#mi("{E,F}")#text(". In particular, setting ")#mi("{E = [0,x]}")#text(", ")#mi("{F = [0,y]}")#text(" for ")#mi("{x,y \\geq 0}")#text(" and integrating using Fubini’s theorem, we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\mathbb E} \\max(\\mathbf{X},0) \\max(\\mathbf{Y},0) = ({\\mathbb E} \\max(\\mathbf{X},0)) ({\\mathbb E} \\max(\\mathbf{Y},0));")]]

#text("similarly with ")#mi("{\\max(\\mathbf{X},0)}")#text(" replaced by ")#mi("{-\\min(\\mathbf{X},0)}")#text(", and similarly for ")#mi("{\\mathbf{Y}}")#text(". In particular we have")

#align(center)[#tao-fit-display[#mitex("{\\mathbb E} \\mathbf{X} \\mathbf{Y} = ({\\mathbb E} \\mathbf{X}) ({\\mathbb E} \\mathbf{Y})")]]

#text("and thus from ")#link(<tao-23c5bb276c87edba25e1>)[#text("(8)")]#text(" we thus see that independent random variables have zero covariance (and zero correlation, when they are not almost surely constant). On the other hand, the converse fails:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Provide an example of two random variables ")#mi("{\\mathbf{X}, \\mathbf{Y} \\in L^2}")#text(" which are not independent, but which have zero correlation or covariance with each other. (There are many ways to produce some examples. One comes from exploiting various systems of orthogonal functions, such as sines and cosines. Another comes from working with random variables taking only a small number of values, such as ")#mi("{\\{-1,0,1\\}}")#text(".")
]

#text("From the cosine rule we have ")#metadata(none) <tao-ad9897a115cfe7e49d73>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\mathrm{Var}(\\mathbf{X}+\\mathbf{Y}) = \\mathrm{Var}(\\mathbf{X}) + \\mathrm{Var}(\\mathbf{Y}) + 2 \\mathrm{Re} \\mathrm{Cov}( \\mathbf{X}, \\mathbf{Y} )")]]

#linebreak()#text(" and more generally ")#metadata(none) <tao-d61aa6c404222d6ee803>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\mathrm{Var}(\\mathbf{X}_1+ \\dots + \\mathbf{X}_n) = \\sum_{i=1}^n \\mathrm{Var}(\\mathbf{X}_i) + 2 \\sum_{1 \\leq i < j \\leq n} \\mathrm{Re} \\mathrm{Cov}( \\mathbf{X}_i, \\mathbf{X}_j )")]]

#text(" for any finite collection of random variables ")#mi("{\\mathbf{X}_1, \\dots, \\mathbf{X}_n \\in L^2}")#text(". These identities combine well with Chebyshev-type inequalities such as ")#link(<tao-01fa52e23fcff7b6e69a>)[#text("(6)")]#text(", ")#link(<tao-6f6976e9b0f9317466cd>)[#text("(7)")]#text(", and this leads to a very common instance of the ")#link("https://en.wikipedia.org/wiki/Second_moment_method")[#text("second moment method")]#text(" in action. For instance, we can use it to understand the distribution of the number of prime factors of a random number ")#mi("{\\mathbf{n}}")#text(" that fall within a given set ")#mi("{{\\mathcal P}}")#text(". Given any set ")#mi("{A}")#text(" of natural numbers, define the ")#emph[#text("logarithmic size")]#text(" ")#mi("{l(A)}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#mitex("l(A) := \\sum_{n \\in A} \\frac{1}{n}.")]]

#text("Thus for instance ")#link("https://en.wikipedia.org/wiki/Divergence_of_the_sum_of_the_reciprocals_of_the_primes")[#text("Euler’s theorem")]#text(" asserts that the primes have infinite logarithmic size.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Turan-Kubilius inequality, special case)")]#text(" ")#metadata(none) <tao-28949ea86dcc7636bf5b>#text(" Let ")#mi("{I \\subset {\\bf R}}")#text(" be an interval of length at least ")#mi("{1}")#text(", and let ")#mi("{\\mathbf{n}}")#text(" be an integer drawn uniformly at random from this interval, thus")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}( \\mathbf{n} \\in E ) = \\frac{\\#(E \\cap I)}{\\#({\\bf Z} \\cap I)}")]]

#text("for all ")#mi("{E \\subset {\\bf Z}}")#text(". Let ")#mi("{{\\mathcal P}}")#text(" be a finite collection of primes, all of which have size at most ")#mi("{P}")#text(". Then the random variable ")#mi("{\\mathbf{\\omega} := \\# \\{ p \\in {\\mathcal P}: p | \\mathbf{n} \\}}")#text(" has mean")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E} \\mathbf{\\omega} = l(\\mathcal{P}) + O( \\frac{P}{\\left|I\\right|} )", block: true)]]

#text("and variance")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Var}( \\mathbf{\\omega} ) \\ll l(\\mathcal{P}) + \\frac{P^2}{\\left|I\\right|}.", block: true)]]

#text("In particular,")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E} \\left|\\mathbf{\\omega} - l(\\mathcal{P})\\right|^2 \\ll l(\\mathcal{P}) + \\frac{P^2}{\\left|I\\right|}", block: true)]]

#text("and from ")#link(<tao-6f6976e9b0f9317466cd>)[#text("(7)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb P}( \\left|\\mathbf{\\omega} - l({\\mathcal P}) \\right| \\geq \\lambda ) \\ll \\frac{l({\\mathcal P}) + \\frac{P^2}{\\left|I\\right|} }{\\lambda^2}", block: true)]]

#text("for any ")#mi("{\\lambda > 0}")#text(".")
]

#emph[#text("Proof:")]#text(" For any natural number ")#mi("{d}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I} 1_{d|n} = \\sum_{n \\in I/d} = \\frac{1}{d} \\left|I\\right| + O(1)", block: true)]]

#text("and hence ")#metadata(none) <tao-2da68e03534ea7262d11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("{\\mathbb P}( d | \\mathbf{n}) = \\frac{\\frac{1}{d} \\left|I\\right| + O(1)}{\\left|I\\right| + O(1)} = \\frac{1}{d} + O( \\frac{1}{\\left|I\\right|} ).", block: true)]]

#text(" We now write ")#mi("{\\mathbf{\\omega} = \\sum_{p \\in {\\mathcal P}} 1_{p|{\\mathbf n}}}")#text(". From ")#link(<tao-2da68e03534ea7262d11>)[#text("(11)")]#text(" we see that each indicator random variable ")#mi("{1_{p|{\\mathbf n}}}")#text(", ")#mi("{p \\in {\\mathcal P}}")#text(" has mean ")#tao-math("{\\frac{1}{p} + O( \\frac{1}{\\left|I\\right|})}", block: false)#text(" and variance ")#tao-math("{O( \\frac{1}{p} + \\frac{1}{\\left|I\\right|})}", block: false)#text("; similarly, for any two distinct ")#mi("{p_1, p_2 \\in {\\mathcal P}}")#text(", we see from ")#link(<tao-2da68e03534ea7262d11>)[#text("(11)")]#text(", ")#link(<tao-23c5bb276c87edba25e1>)[#text("(8)")]#text(" the indicators ")#mi("{1_{p_1|{\\mathbf n}}}")#text(", ")#mi("{1_{p_2|{\\mathbf n}}}")#text(" have covariance")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Cov}(1_{p_1|{\\mathbf n}}, 1_{p_2|{\\mathbf n}}) = \\frac{1}{p_1 p_2} + O( \\frac{1}{\\left|I\\right|} ) - ( \\frac{1}{p_1} + O( \\frac{1}{\\left|I\\right|} ) ) ( \\frac{1}{p_2} + O( \\frac{1}{\\left|I\\right|} ) ) = O( \\frac{1}{\\left|I\\right|} )", block: true)]]

#text("and the claim now follows from ")#link(<tao-d61aa6c404222d6ee803>)[#text("(10)")]#text(". ")#mi("\\Box")#linebreak()#text(" The exponents of ")#mi("{P}")#text(" in the error terms here are not optimal; but in practice, we apply this inequality when ")#tao-math("{\\left|I\\right|}", block: false)#text(" is much larger than any given power of ")#mi("{P}")#text(", so factors such as ")#tao-math("{P^3/\\left|I\\right|}", block: false)#text(" will be negligible. Informally speaking, the above lemma asserts that a typical number in a large interval ")#mi("{I}")#text(" will have roughly ")#mi("{l({\\mathcal P})}")#text(" prime factors in a given finite set ")#mi("{{\\mathcal P}}")#text(" of primes, as long as the logarithmic size ")#mi("{l({\\mathcal P})}")#text(" is large.")

#text("If we apply the above lemma to ")#mi("{I = [1,x]}")#text(" for some large ")#mi("{x}")#text(", and ")#mi("{{\\mathcal P}}")#text(" equal to the primes up to (say) ")#mi("{P = x^{0.1}}")#text(", we have ")#mi("{l({\\mathcal P}) = \\log\\log x + O(1)}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E} \\left|\\mathbf{\\omega} - \\log\\log x \\right|^2 \\ll \\log \\log x.", block: true)]]

#text("Since ")#mi("{\\omega(\\mathbf{n}) = \\mathbf{\\omega} + O(1)}")#text(", we recover the main result")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{x} \\sum_{n \\leq x} \\left|\\omega(n) - \\log\\log x\\right|^2 \\ll \\log\\log x", block: true)]]

#text("of Section 5 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" (indeed this is essentially the same argument as in that section, dressed up in probabilistic language). In particular, we recover the Hardy-Ramanujan law that a proportion ")#mi("{1-o(1)}")#text(" of the natural numbers in ")#mi("{[1,x]}")#text(" have ")#mi("{(1+o(1)) \\log\\log x}")#text(" prime factors.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Turan-Kubilius inequality, general case)")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be an additive function (which means that ")#mi("{f(n+m) = f(n) + f(m)}")#text(" whenever ")#mi("{n,m}")#text(" are coprime. Show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{x} \\sum_{n \\leq x} \\left|f(n) - A\\right|^2 \\ll \\sum_{p \\leq x} \\sum_{j \\leq \\log x/\\log p} \\left|f(p^j)\\right|^2 / p^j", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("A := \\sum_{p \\leq x} \\sum_{j \\leq \\log x/\\log p} |f(p^j)| p^{-j} (1-\\frac{1}{p}).")]]

#text("(Hint: one may first want to work with the special case when ")#mi("{f(p^j)}")#text(" vanishes whenever ")#mi("{p^j \\geq x^{0.1}}")#text(" so that the second moment method can be profitably applied, and then figure out how to address the contributions of prime powers larger than ")#mi("{x^{0.1}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Turan-Kubilius inequality, logarithmic version)")]#text(" ")#metadata(none) <tao-16363f6c1b7514b3043f>#text(" Let ")#mi("{2 \\leq y \\leq x}")#text(" with ")#mi("{x/y \\geq 2}")#text(", and let ")#mi("{{\\mathcal P}}")#text(" be a collection of primes of size less than ")#mi("{P}")#text(" with ")#mi("{P \\leq y^{0.1}}")#text(". Show that ")#metadata(none) <tao-7f1b55b860590406f84f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\frac{1}{\\log(x/y)} \\sum_{y \\leq n \\leq x} \\frac{\\left|\\sum_{p \\in {\\mathcal P}} 1_{p|n} - l({\\mathcal P})\\right|^2}{n} \\ll l({\\mathcal P}) + 1", block: true)]]


]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Paley-Zygmund inequality)")]#text(" Let ")#mi("{\\mathbf{X} \\in L^2}")#text(" be non-negative with positive mean. Show that")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}( \\mathbf{X} > \\lambda {\\mathbb E} \\mathbf{X}) \\geq (1-\\lambda)^2 \\frac{ ({\\mathbb E} \\mathbf{X})^2 }{ {\\mathbb E} (\\mathbf{X}^2) }.")]]

#text("This inequality can sometimes give slightly sharper results than the Chebyshev inequality when using the second moment method.")
]

#text("Now we give a useful lemma that quantifies a heuristic mentioned in the introduction, namely that if several random variables ")#mi("{\\mathbf{Y}_1,\\dots,\\mathbf{Y}_n}")#text(" do not correlate with each other, then it is not possible for any further random variable ")#mi("{\\mathbf{X}}")#text(" to correlate with many of them simultaneously. We first state an abstract Hilbert space version.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Bessel type inequality, Hilbert space version)")]#text(" ")#metadata(none) <tao-3236be4074a7fe020fb5>#text(" If ")#mi("{u, v_1,\\dots,v_n}")#text(" are elements of a Hilbert space ")#mi("{H}")#text(", and ")#mi("{w_1,\\dots,w_n}")#text(" are positive reals, then ")#metadata(none) <tao-5b69527fe9a86aae5ed5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left( \\sum_{i=1}^n w_i \\left|\\langle u, v_i \\rangle_{H}\\right|^2\\right)^{1/2} \\leq \\left\\|u \\right\\|_{H} \\left( \\sup_{1 \\leq i \\leq n} \\sum_{j=1}^n w_j \\left|\\langle v_i, v_j\\rangle_{H}\\right| \\right)^{1/2}.", block: true)]]


]

#emph[#text("Proof:")]#text(" We use the duality method. Namely, we can write the left-hand side of ")#link(<tao-5b69527fe9a86aae5ed5>)[#text("(13)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n w_i \\langle u, v_i \\rangle_{H} \\overline{c_i} = \\langle u, \\sum_{i=1}^n w_i c_i v_i \\rangle_{H}")]]

#text("for some complex numbers ")#mi("{c_i}")#text(" with ")#tao-math("{\\sum_{i=1}^n w_i \\left|c_i\\right|^2=1}", block: false)#text(" (just take ")#mi("{c_i}")#text(" to be ")#mi("{\\langle u, v_i \\rangle_{H}}")#text(" normalised by the left-hand side of ")#link(<tao-5b69527fe9a86aae5ed5>)[#text("(13)")]#text(", or zero if that left-hand side vanishes. By Cauchy-Schwarz, it then suffices to establish the dual inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\sum_{i=1}^n w_i c_i v_i \\right\\|_{H}^2 \\leq \\sup_{1 \\leq i \\leq n} \\sum_{j=1}^n w_j |\\langle v_i, v_j\\rangle_{H}|.", block: true)]]

#text("The left-hand side can be written as")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n \\sum_{j=1}^n w_i w_j c_i \\overline{c_j} \\langle v_i, v_j \\rangle.")]]

#text("Using the arithmetic mean-geometric mean inequality ")#tao-math("{c_i \\overline{c_j} \\leq \\frac{1}{2} \\left|c_i\\right|^2 + \\frac{1}{2} \\left|c_j\\right|^2}", block: false)#text(" and symmetry, this may be bounded by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^n w_i \\left|c_i\\right|^2 \\sum_{j=1}^n w_j |\\langle v_i, v_j \\rangle|.", block: true)]]

#text("Since ")#tao-math("{\\sum_{i=1}^n w_i \\left|c_i\\right|^2 =1}", block: false)#text(", the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7 (Bessel type inequality, probabilistic version)")]#text(" ")#metadata(none) <tao-95791788048119f0cf23>#text(" If ")#mi("{\\mathbf{X}, \\mathbf{Y}_1,\\dots,\\mathbf{Y}_n \\in L^2}")#text(", and ")#mi("{w_1,\\dots,w_n}")#text(" are positive reals, then ")#metadata(none) <tao-8b0805c2044b4e5eff78>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\sum_{i=1}^n w_i \\left|\\mathrm{Cov}( \\mathbf{X}, \\mathbf{Y}_i )\\right|^2", block: true)]]



#align(center)[#tao-fit-display[#tao-math("\\leq \\mathrm{Var}(\\mathbf{X}) \\left( \\sup_{1 \\leq i \\leq n} \\sum_{j=1}^n w_j \\left|\\mathrm{Cov}(\\mathbf{Y}_i, \\mathbf{Y}_j)\\right| \\right).", block: true)]]
]

#emph[#text("Proof:")]#text(" By subtracting the mean from each of ")#mi("{\\mathbf{X}, \\mathbf{Y}_i}")#text(" we may assume that these random variables have mean zero. The claim now follows from Lemma ")#link(<tao-3236be4074a7fe020fb5>)[#text("6")]#text(". ")#mi("\\Box")

#text("To get a feel for this inequality, suppose for sake of discussion that ")#mi("{\\mathbf{X}}")#text(" and ")#mi("{\\mathbf{Y}_i}")#text(" all have unit variance and ")#mi("{w_i = 1}")#text(", but that the ")#mi("{\\mathbf{Y}_i}")#text(" are pairwise uncorrelated. Then the right-hand side is equal to ")#mi("{1}")#text(", and the left-hand side is the sum of squares of the correlations between ")#mi("{\\mathbf{X}}")#text(" and each of the ")#mi("{\\mathbf{Y}_i}")#text(". Any individual correlation is then still permitted to be as large as ")#mi("{1}")#text(", but it is not possible for multiple correlations to be this large simultaneously. This is geometrically intuitive if one views the random variables ")#mi("{\\mathbf{X}, \\mathbf{Y}_i}")#text(" as vectors in a Hilbert space (and correlation as a rough proxy for the angle between such vectors). This lemma also shares many commonalities with the large sieve inequality, discussed in ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("this set of notes")]#text(".")

#text("One basic number-theoretic application of this inequality is the following sampling inequality ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=551361")[#text("of Elliott")]#text(", that lets one approximate a sum ")#mi("{\\sum_{n \\in I} f(n)}")#text(" of an arithmetic function by its values ")#mi("{\\sum_{n \\in I} f(n) p 1_{p|n}}")#text(" on multiples of primes ")#mi("{p}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Elliott’s inequality)")]#text(" ")#metadata(none) <tao-e670e2cbf7f657890bf0>#text(" Let ")#mi("{I \\subset {\\bf R}}")#text(" be an interval of length at least ")#mi("{1}")#text(". Show that for any function ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{p \\leq \\left|I\\right|^{0.1}} \\frac{1}{p} \\left| \\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n) - \\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n) p 1_{p|n} \\right|^2 \\ll \\frac{1}{\\left|I\\right|} \\sum_{n \\in I} \\left|f(n)\\right|^2.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" Apply Corollary ")#link(<tao-95791788048119f0cf23>)[#text("7")]#text(" with ")#mi("{X := f({\\mathbf n})}")#text(", ")#mi("{Y_p := p 1_{p|\\mathbf{n}}}")#text(", and ")#mi("{w_p := 1/p}")#text(", where ")#mi("{\\mathbf{n}}")#text(" is the uniform variable from Lemma ")#link(<tao-28949ea86dcc7636bf5b>)[#text("2")]#text(".) Conclude in particular that for every ")#mi("{\\varepsilon > 0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n) = \\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n) p 1_{p|n} + O\\left( \\varepsilon \\left(\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} \\left|f(n)\\right|^2\\right)^{1/2} \\right)", block: true)]]

#text("for all primes ")#tao-math("{p \\leq \\left|I\\right|}", block: false)#text(" outside of a set of exceptional primes of logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(".")
]

#text("Informally, the point of this inequality is that an arbitrary arithmetic function ")#mi("{f}")#text(" may exhibit correlation with the indicator function ")#mi("{1_{p|n}}")#text(" of the multiples of ")#mi("{p}")#text(" for some primes ")#mi("{p}")#text(", but cannot exhibit significant correlation with all of these indicators simultaneously, because these indicators are not very correlated to each other. We note however that this inequality only gains a tiny bit over trivial bounds, because the set of primes up to ")#mi("{x}")#text(" only has logarithmic size ")#mi("{O(\\log\\log x)}")#text(" by Mertens’ theorems; thus, any asymptotics that are obtained using this inequality will typically have error terms that only improve upon the trivial bound by factors such as ")#mi("{\\log\\log x}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Elliott’s inequality, logarithmic form)")]#text(" ")#metadata(none) <tao-e5c58d8a7c863eb64685>#text(" Let ")#mi("{2 \\leq y \\leq x}")#text(" with ")#mi("{x/y \\geq 2}")#text(". Show that for any function ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{p \\leq y^{0.1}} \\frac{1}{p} \\left| \\frac{1}{\\log(x/y)} \\sum_{y \\leq n \\leq x} \\frac{f(n)}{n} - \\frac{1}{\\log(x/y)} \\sum_{y/p \\leq n \\leq x/p} \\frac{f(pn)}{n} \\right|^2", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll \\frac{1}{\\log(x/y)} \\sum_{y \\leq n \\leq x} \\frac{\\left|f(n)\\right|^2}{n}", block: true)]]

#text("and thus for every ")#mi("{\\varepsilon>0}")#text(", one has")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{\\log(x/y)} \\sum_{y \\leq n \\leq x} \\frac{f(n)}{n}  & = \\frac{1}{\\log(x/y)} \\sum_{y/p \\leq n \\leq x/p} \\frac{f(pn)}{n}", block: true)



#tao-math(" & + O\\left( \\varepsilon \\left( \\frac{1}{\\log(x/y)} \\sum_{y \\leq n \\leq x} \\frac{\\left|f(n)\\right|^2}{n} \\right)^{1/2} \\right)", block: true)
]

#text("for all primes ")#mi("{p \\leq y}")#text(" outside of an exceptional set of primes of logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Use Exercise ")#link(<tao-e5c58d8a7c863eb64685>)[#text("(9)")]#text(" and a duality argument to provide an alternate proof of Exercise ")#link(<tao-16363f6c1b7514b3043f>)[#text("4")]#text(". (")#emph[#text("Hint:")]#text(" express the left-hand side of ")#link(<tao-7f1b55b860590406f84f>)[#text("(12)")]#text(" as a correlation between ")#mi("{\\sum_{p \\in {\\mathcal P}} 1_{p|n} - l({\\mathcal P})}")#text(" and some suitably ")#mi("{L^2}")#text("-normalised arithmetic function ")#mi("{f(n)}")#text(".)")
]

#text("As a quick application of Elliott’s inequality, let us establish a weak version of the prime number theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Weak prime number theorem)")]#text(" ")#metadata(none) <tao-bd461b58bf8fc2571eae>#text(" For any ")#mi("{\\varepsilon>0}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log(x/y)} \\sum_{y \\leq n \\leq x} \\frac{\\mu(n)}{n} = O(\\varepsilon)")]]

#text("whenever ")#mi("{y, x/y}")#text(" are sufficiently large depending on ")#mi("{\\varepsilon}")#text(".")
]

#text("This estimate is weaker than what one can obtain by existing methods, such as Exercise 56 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(". However in the next section we will refine this argument to recover the full prime number theorem.")

#emph[#text("Proof:")]#text(" Fix ")#mi("{\\varepsilon}")#text(", and suppose that ")#mi("{y, x/y}")#text(" are sufficiently large. From Exercise ")#link(<tao-e5c58d8a7c863eb64685>)[#text("9")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log(x/y)} \\sum_{y \\leq n \\leq x} \\frac{\\mu(n)}{n} = \\frac{1}{\\log(x/y)} \\sum_{y/p \\leq n \\leq x/p} \\frac{\\mu(pn)}{n} + O(\\varepsilon)")]]

#text("for all primes ")#mi("{p \\leq y}")#text(" outside of an exceptional set of logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(". If we restrict attention to primes ")#mi("{p \\leq (x/y)^\\varepsilon}")#text(" then one sees from the integral test that one can replace the sum ")#mi("{\\sum_{y/p \\leq n \\leq x/p}}")#text(" by ")#mi("{\\sum_{y \\leq n \\leq x}}")#text(" and only incur an additional error of ")#mi("{O(\\varepsilon)}")#text(". If we furthermore restrict to primes ")#mi("{p}")#text(" larger than ")#mi("{\\varepsilon^{-1}}")#text(", then the contribution of those ")#mi("{n}")#text(" that are divisible by ")#mi("{p}")#text(" is also ")#mi("{O(\\varepsilon)}")#text(". For ")#mi("{n}")#text(" not divisible by ")#mi("{p}")#text(", one has ")#mi("{\\mu(pn) = -\\mu(n)}")#text(". Putting all this together, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log(x/y)} \\sum_{y \\leq n \\leq x} \\frac{\\mu(n)}{n} = - \\frac{1}{\\log(x/y)} \\sum_{y \\leq n \\leq x} \\frac{\\mu(n)}{n} + O(\\varepsilon)")]]

#text("for all primes ")#mi("{1/\\varepsilon \\leq p \\leq (x/y)^\\varepsilon, y}")#text(" outside of an exceptional set of logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(". In particular, for ")#mi("{y, x/y}")#text(" large enough this statement is true for at least one such ")#mi("{p}")#text(". The claim then follows. ")#mi("\\Box")#linebreak()#text(" As another application of Elliott’s inequality, we present a criterion for orthogonality between multiplicative functions and other sequences, first discovered ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=836415")[#text("by Katai")]#text(" (with related results also introduced earlier ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=675168")[#text("by Daboussi and Delange")]#text("), and rediscovered ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2986954")[#text("by Bourgain, Sarnak, and Ziegler")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12 (Daboussi-Delange-Katai-Bourgain-Sarnak-Ziegler criterion)")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a multiplicative function with ")#tao-math("{\\left|f(n)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{n}")#text(", and let ")#mi("{g: {\\bf N} \\rightarrow {\\bf C}}")#text(" be another bounded function. Suppose that one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} g(pn) \\overline{g(qn)} = o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" for any two distinct primes ")#mi("{p,q}")#text(". Then one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) \\overline{g(n)} = o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose the claim fails, then there exists ")#mi("{\\varepsilon>0}")#text(" (which we can assume to be small) and arbitrarily large ")#mi("{x}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{x} \\sum_{n \\leq x} f(n) \\overline{g(n)}\\right| \\geq \\varepsilon.", block: true)]]

#text("By Exercise ")#link(<tao-e670e2cbf7f657890bf0>)[#text("8")]#text(", this implies that ")#metadata(none) <tao-9dfd0eed59fbc9107d92>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\frac{1}{x} \\sum_{n \\leq x} f(n) \\overline{g(n)} p 1_{p|n}\\right| \\gg \\varepsilon", block: true)]]

#text(" for all primes ")#mi("{p \\leq x}")#text(" outside of an exceptional set of logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(". Call such primes “good primes”. In particular, by the pigeonhole principle, and assuming ")#mi("{x}")#text(" large enough, there exists a dyadic range ")#mi("{[P, (1+\\varepsilon^2) P]}")#text(" with ")#mi("{\\varepsilon^{-10} \\ll P \\ll_\\varepsilon 1}")#text(" which contains ")#mi("{\\gg \\varepsilon^2 \\frac{P}{\\log P}}")#text(" good primes.")#linebreak()#text(" Fix a good prime ")#mi("{p}")#text(" in ")#mi("{[P, (1+\\varepsilon^2)P]}")#text(". From ")#link(<tao-9dfd0eed59fbc9107d92>)[#text("(15)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{x/P} \\sum_{n \\leq x/p} f(pn) \\overline{g(pn)}\\right| \\gg \\varepsilon.", block: true)]]

#text("We can replace the range ")#mi("{n \\leq x/p}")#text(" by ")#mi("{n \\leq x/P}")#text(" with negligible error. We also have ")#mi("{f(pn) = f(p) f(n)}")#text(" except when ")#mi("{n}")#text(" is a multiple of ")#mi("{p}")#text(", but this latter case only contributes ")#mi("{O(1/p)}")#text(" which is also negligible compared to the right-hand side. We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{x/P} \\sum_{n \\leq x/P} f(n) \\overline{g(pn)}\\right| \\gg \\varepsilon", block: true)]]

#text("for every good prime. On the other hand, from Lemma ")#link(<tao-3236be4074a7fe020fb5>)[#text("6")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_p \\left|\\frac{1}{x/P} \\sum_{n \\leq x/P} f(n) \\overline{g(pn)}\\right|^2 \\ll \\sup_p \\sum_q \\left|\\frac{1}{x/P} \\sum_{n \\leq x/P} g(pn) \\overline{g(qn)}\\right|", block: true)]]

#text("where ")#mi("{p,q}")#text(" range over the good primes in ")#mi("{[P,(1+\\varepsilon) P]}")#text(". The left-hand side is then ")#mi("{\\gg \\varepsilon^3 \\frac{P}{\\log P}}")#text(", and by hypothesis the right-hand side is ")#mi("{O(1)}")#text(" for ")#mi("{x}")#text(" large enough. As ")#mi("{P \\geq \\varepsilon^{-10}}")#text(" and ")#mi("{\\varepsilon}")#text(" is small, this gives the desired contradiction ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Daboussi-Delange theorem)")]#text(" Let ")#mi("{\\alpha}")#text(" be irrational, and let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a multiplicative function with ")#tao-math("{\\left|f(n)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{n}")#text(". Show that ")#metadata(none) <tao-0f1e18bb4143dc4be22e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) e(-\\alpha n) = o(1)")]]

#text(" as ")#mi("{x \\rightarrow \\infty}")#text(". If instead ")#mi("{\\alpha}")#text(" is rational, show that there exists ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a multiplicative function with ")#tao-math("{\\left|f(n)\\right| \\leq 1}", block: false)#text(" for which the statement ")#link(<tao-0f1e18bb4143dc4be22e>)[#text("(16)")]#text(" fails. (Hint: use Dirichlet characters and Plancherel’s theorem for finite abelian groups.)")
]

#heading(level: 1)[#strong[#text(" — 2. An elementary proof of the prime number theorem — ")]]

#text("Define the ")#link("https://en.wikipedia.org/wiki/Mertens_function")[#text("Mertens function")]

#align(center)[#tao-fit-display[#mitex("M(x) := \\sum_{n \\leq x} \\mu(n).")]]

#text("As shown in Theorem 58 of ")#link("https://en.wikipedia.org/wiki/Mertens_function")[#text("Notes 1")]#text(", the prime number theorem is equivalent to the bound ")#metadata(none) <tao-9baf3a40312f39849f46>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\frac{M(x)}{x}=o(1)")]]

#text(" as ")#mi("{x \\rightarrow \\infty}")#text(". We now give a recent proof of this theorem, due to Redmond McNamara (personal communication), that relies primarily on Elliott’s inequality and the Selberg symmetry formula; it is a relative of the standard elementary proof of this theorem due to Erdös and Selberg. In order to keep the exposition simple, we will not arrange the argument in a fashion that optimises the decay rate ")#mi("{o(1)}")#text(" (in any event, there are other proofs of the prime number theorem that give significantly stronger bounds).")#linebreak()#text(" Firstly we see that Elliott’s inequality gives the following weaker version of ")#link(<tao-9baf3a40312f39849f46>)[#text("(17)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14 (Oscillation for Mertens’ function)")]#text(" If ")#mi("{x \\geq 2}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("\\frac{M(x)}{x} = -\\frac{M(x/p)}{x/p} + O(\\varepsilon)")]]

#text("for all primes ")#mi("{p \\leq x}")#text(" outside of an exceptional set of primes of logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(".")
]

#emph[#text("Proof:")]#text(" We may assume ")#mi("{\\varepsilon \\leq 1}")#text(" as the claim is trivial otherwise. From Exercise ")#link(<tao-e670e2cbf7f657890bf0>)[#text("8")]#text(" applied to ")#mi("{I=[1,x]}")#text(" and ")#mi("{f=\\mu}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\frac{M(x)}{x} = \\frac{1}{x/p} \\sum_{n \\leq x/p} \\mu(pn) + O(\\varepsilon)")]]

#text("for all ")#mi("{p \\leq x}")#text(" outside of an exceptional set of primes of logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(". Since ")#mi("{\\mu(pn)=-\\mu(n)}")#text(" for ")#mi("{n}")#text(" not divisible by ")#mi("{p}")#text(", the right-hand side can be written as")

#align(center)[#tao-fit-display[#mitex("-\\frac{M(x/p)}{x/p} + O(\\varepsilon) + O(1/p).")]]

#text("Since ")#mi("{1/p \\leq \\varepsilon}")#text(" outside of an exceptional set of logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(", the claim follows. ")#mi("\\Box")#linebreak()#text(" Informally, this lemma asserts that ")#mi("{\\frac{M(x)}{x} \\approx -\\frac{M(x/p)}{x/p}}")#text(" for most primes ")#mi("{p}")#text(", which morally implies that ")#mi("{\\frac{M(x)}{x} \\approx \\frac{M(x/p_1p_2)}{x/p_1 p_2}}")#text(" for most primes ")#mi("{p_1,p_2}")#text(". If we can then locate suitable primes ")#mi("{p,p_1,p_2}")#text(" with ")#mi("{p \\approx p_1 p_2}")#text(", thus should then lead to ")#mi("{\\frac{M(x)}{x} \\approx -\\frac{M(x)}{x}}")#text(", which should then yield the prime number theorem ")#mi("{\\frac{M(x)}{x} = o(1)}")#text(". The manipulations below are intended to make this argument rigorous.")

#text("It will be convenient to work with a logarithmically averaged version of this claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 15 (Logarithmically averaged oscillation)")]#text(" If ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(", then ")#metadata(none) <tao-650ccebda5bef2f2a987>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\int_{\\log x}^x |\\frac{M(t)}{t} + \\frac{M(t/p)}{t/p}| \\frac{dt}{t} \\ll \\varepsilon \\log x")]]

#text(" for all ")#mi("{p \\leq \\log x}")#text(" outside of an exceptional set of logarithmic size ")#mi("{O(\\varepsilon^{-3})}")#text(".")
]

#emph[#text("Proof:")]#text(" For each ")#mi("{\\log x \\leq t \\leq x}")#text(", we have from the previous lemma that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{M(t)}{t} + \\frac{M(t/p)}{t/p}\\right| \\leq \\varepsilon", block: true)]]

#text("for all ")#mi("{p \\leq \\log x}")#text(" outside of an exceptional set ")#mi("{{\\mathcal P}_t}")#text(" of logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(". We then have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\log x}^x |\\frac{M(t)}{t} + \\frac{M(t/p)}{t/p}| \\frac{dt}{t} \\ll \\varepsilon \\log x + \\int_{\\log x}^x 1_{p \\in {\\mathcal P}_t} \\frac{dt}{t}")]]

#text("so it suffices by Markov’s inequality to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq \\log x} \\frac{1}{p} \\int_{\\log x}^x 1_{p \\in {\\mathcal P}_t} \\frac{dt}{t} \\ll \\varepsilon^{-2} \\log x.")]]

#text("But by Fubini’s theorem, the left-hand side may be bounded by")

#align(center)[#tao-fit-display[#mitex("\\int_{\\log x}^x \\varepsilon^{-2} \\frac{dt}{t}")]]

#text("and the claim follows. ")#mi("\\Box")#linebreak()#text(" Let ")#mi("{\\varepsilon>0}")#text(" be sufficiently small, and let ")#mi("{x}")#text(" be sufficiently large depending on ")#mi("{\\varepsilon}")#text(". Call a prime ")#mi("{p \\leq \\log x}")#text(" ")#emph[#text("good")]#text(" if the bound ")#link(<tao-650ccebda5bef2f2a987>)[#text("(18)")]#text(" holds and ")#emph[#text("bad")]#text(" otherwise, thus all primes ")#mi("{p \\leq \\log x}")#text(" outside of an exceptional set of bad primes of logarithmic size ")#mi("{O(\\varepsilon^{-3})}")#text(" are good. Now we observe that we can make ")#mi("{M(x)/x}")#text(" small as long as we can make two good primes multiply to be close to a third:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 16")]#text(" ")#metadata(none) <tao-729cd87c6329408e2bbf>#text(" Suppose there are good primes ")#mi("{p_1, p_2, p \\leq (\\log x)^{0.1}}")#text(" with ")#mi("{p = (1+O(\\varepsilon)) p_1 p_2}")#text(". Then ")#mi("{\\frac{M(x)}{x} = O(\\varepsilon)}")#text(".")
]

#emph[#text("Proof:")]#text(" By definition of good prime, we have the bounds ")#metadata(none) <tao-325883f79432c4e0e355>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\int_{\\log x}^x |\\frac{M(t)}{t} + \\frac{M(t/p_1)}{t/p_1}| \\frac{dt}{t} \\ll \\varepsilon \\log x")]]

#linebreak()#text(" ")#metadata(none) <tao-187e3a42b4ab486618b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\int_{\\log x}^x |\\frac{M(t)}{t} + \\frac{M(t/p_2)}{t/p_2}| \\frac{dt}{t} \\ll \\varepsilon \\log x")]]

#text(" ")#metadata(none) <tao-726a1f5ef0da9d9e58aa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\int_{\\log x}^x |\\frac{M(t)}{t} + \\frac{M(t/p)}{t/p}| \\frac{dt}{t} \\ll \\varepsilon \\log x.")]]

#text(" We rescale ")#link(<tao-187e3a42b4ab486618b2>)[#text("(20)")]#text(" by ")#mi("{p_1}")#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{p_1\\log x}^{p_1x} |\\frac{M(t/p_1)}{t/p_1} + \\frac{M(t/p_1p_2)}{t/p_1p_2}| \\frac{dt}{t} \\ll \\varepsilon \\log x.")]]

#text("We can replace the integration range here from ")#mi("{[p_1\\log x, x]}")#text(" to ")#mi("{[\\log x, x]}")#text(" with an error of ")#mi("{O(\\varepsilon \\log x)}")#text(" if ")#mi("{x}")#text(" is large enough. Also, since ")#mi("{p = (1+O(\\varepsilon)) p_1 p_2}")#text(", we have ")#mi("{\\frac{M(t/p_1p_2)}{t/p_1p_2} = \\frac{M(t/p)}{t/p} + O(\\varepsilon)}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\log x}^{x} |\\frac{M(t/p_1)}{t/p_1} + \\frac{M(t/p)}{t/p}| \\frac{dt}{t} \\ll \\varepsilon \\log x.")]]

#text("Combining this with ")#link(<tao-325883f79432c4e0e355>)[#text("(19)")]#text(", ")#link(<tao-726a1f5ef0da9d9e58aa>)[#text("(21)")]#text(" and the triangle inequality (writing ")#mi("{\\frac{M(t)}{t}}")#text(" as a linear combination of ")#mi("{\\frac{M(t)}{t} + \\frac{M(t/p_1)}{t/p_1}}")#text(", ")#mi("{\\frac{M(t)}{t} + \\frac{M(t/p)}{t/p}}")#text(", and ")#mi("{\\frac{M(t/p_1)}{t/p_1} + \\frac{M(t/p)}{t/p}}")#text(") we conclude that ")#metadata(none) <tao-f1e2a83eacdee7c87da6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\int_{\\log x}^x |\\frac{M(t)}{t}| \\frac{dt}{t} \\ll \\varepsilon \\log x.")]]

#text(" This is an averaged version of the claim we need. To remove the averaging, we use the identity ")#mi("{\\mu L = - \\mu * \\Lambda}")#text(" (see equation (63) of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\log n = - \\sum_{m \\leq x} \\Lambda(m) M(x/m).")]]

#text("From the triangle inequality one has")

#align(center)[#tao-fit-display[#tao-math("\\left|M(x/m)\\right| \\ll \\varepsilon^{-1} \\int_{x/m}^{(1+\\varepsilon)x/m} \\frac{M(t)}{t}\\ dt + \\varepsilon \\frac{x}{m}", block: true)]]

#text("and hence by Mertens’ theorem")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\mu(n) \\log n \\ll \\varepsilon^{-1} \\sum_{m \\leq x} \\Lambda(m) \\int_{x/m}^{(1+\\varepsilon)x/m} \\frac{\\left|M(t)\\right|}{t}\\ dt + \\varepsilon x \\log x.", block: true)]]

#text("From the Brun-Titchmarsh inequality (Corollary 61 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\Lambda(m) 1_{x/m \\leq t \\leq (1+\\varepsilon)x/m} \\ll \\varepsilon \\frac{x}{t}")]]

#text("and so from the previous estimate and Fubini’s theorem one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\mu(n) \\log n \\ll \\int_{1}^{(1+\\varepsilon)x} \\frac{\\left|M(t)\\right|}{t} \\frac{x}{t}\\ dt + \\varepsilon x \\log x", block: true)]]

#text("and hence by ")#link(<tao-f1e2a83eacdee7c87da6>)[#text("(22)")]#text(" (using trivial bounds to handle the region outside of ")#mi("{[\\log x, x]}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\log n \\ll \\varepsilon x \\log x")]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\log(x/n) \\ll \\sum_{n \\leq x} \\log(x/n) \\ll x,")]]

#text("we conclude (for ")#mi("{x}")#text(" large enough) that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\log x \\ll \\varepsilon x \\log x")]]

#text("and the claim follows. ")#mi("\\Box")#linebreak()#text(" To finish the proof of the prime number theorem, it thus suffices to locate, for ")#mi("{x}")#text(" sufficiently large, three good primes ")#mi("{p_1,p_2,p}")#text(" with ")#mi("{p = (1+O(\\varepsilon)) p_1 p_2}")#text(". If we already had the prime number theorem, or even the weaker form that every interval of the form ")#mi("{[x,e^\\varepsilon x]}")#text(" contained ")#mi("{\\gg \\frac{\\varepsilon x}{\\log x}}")#text(" primes for ")#mi("{x}")#text(" large enough, then this would be quite easy: pick a large natural number ")#mi("{K}")#text(" (depending on ")#mi("{\\varepsilon}")#text(", but independent of ")#mi("{x}")#text("), so that the primes up to ")#mi("{e^{\\varepsilon K}}")#text(" has logarithmic size ")#mi("{\\asymp \\log K}")#text(" (so that only ")#mi("{O(\\frac{\\varepsilon^{-3}}{\\log K})}")#text(" of them are bad, as measured by logarithmic size), and let ")#mi("{\\mathbf{k}_1, \\mathbf{k}_2}")#text(" be random numbers and drawn uniformly from (say) ")#mi("{\\{K+1,\\dots,2K\\}}")#text(". From the prime number theorem, for each ")#mi("{K \\leq k \\leq 4K}")#text(", the interval ")#mi("{I_k := [e^{\\varepsilon k},e^{\\varepsilon(k+1)}]}")#text(" contains ")#mi("{\\gg \\frac{e^{\\varepsilon k}}{k} }")#text(" primes. In particular, ")#mi("{I_{\\mathrm{k}_1}}")#text(" contains ")#mi("{\\gg \\frac{e^{\\varepsilon \\mathbf{k}_1}}{\\mathbf{k}_1} }")#text(" primes, but the expected number of bad primes in this interval is ")#mi("{O( \\frac{\\varepsilon^{-3}}{\\log K} \\frac{e^{\\varepsilon k}}{\\mathbf{k}_1} )}")#text(". Thus by Markov’s inequality there would be at least a ")#mi("{90\\%}")#text(" chance (say) of having at least one good prime ")#mi("{\\mathbf{p_1}}")#text(" in ")#mi("{I_{\\mathbf{k}_1}}")#text("; similarly there is a ")#mi("{90\\%}")#text(" chance of having a good prime ")#mi("{\\mathbf{p_2}}")#text(" in ")#mi("{I_{\\mathbf{k}_1}}")#text(", and a ")#mi("{90\\%}")#text(" chance of having a good prime ")#mi("{\\mathbf{p}}")#text(" in ")#mi("{I_{\\mathbf{k}_1+\\mathbf{k}_2}}")#text(". Thus (as an application of the ")#link("https://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text("), there exist (deterministic) good primes ")#mi("{p_1,p_2,p}")#text(" with the required properties.")

#text("Of course, using the prime number theorem here to prove the prime number theorem would be circular. However, we can still locate a good triple ")#mi("{p_1,p_2,p}")#text(" of primes using the Selberg symmetry formula ")#metadata(none) <tao-a31fe9656fc8d3a459e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sum_{n \\leq x} \\Lambda_2(n) = (2 + o(1)) x \\log x")]]

#linebreak()#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", where ")#mi("{\\Lambda_2}")#text(" is the second von Mangoldt function")

#align(center)[#tao-fit-display[#mitex("\\Lambda_2(n) = \\Lambda(n) \\log n + \\sum_{d|n} \\Lambda(d) \\Lambda(\\frac{n}{d});")]]

#text("see Proposition 60 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(". We can strip away the contribution of the primes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\log^2 p + \\sum_{p_1,p_2: p_1 p_2 \\leq x} \\log p_1 \\log p_2 = (2+o(1)) x \\log x")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")
]

#text("In particular, on evaluating this at ")#mi("{x = e^{\\varepsilon k}, e^{\\varepsilon(k+1)}}")#text(" and subtracting, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\in I_k} \\varepsilon^2 k^2 + \\sum_{p_1,p_2: p_1 p_2 \\in I_k} \\log p_1 \\log p_2 \\asymp \\varepsilon^2 k e^{\\varepsilon k}")]]

#text("whenever ")#mi("{k}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(". In particular, for any such ")#mi("{k}")#text(", one either has ")#metadata(none) <tao-f64551fcd6f07823cb87>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\sum_{p \\in I_k} \\frac{1}{p} \\gg \\frac{1}{k}")]]

#text(" or ")#metadata(none) <tao-3946ca64ff78d93ca610>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\sum_{p_1 p_2 \\in I_k} \\frac{\\log p_1 \\log p_2}{p_1 p_2} \\gg \\varepsilon^2 k")]]

#text(" (or both). Informally, the Selberg symmetry formula shows that the interval ")#mi("{I_k}")#text(" contains either a lot of primes, or a lot of semiprimes. The factor of ")#mi("{\\log p_1 \\log p_2}")#text(" is slightly annoying, so we now remove it. Consider the contribution of those primes ")#mi("{p_1}")#text(" to ")#link(<tao-3946ca64ff78d93ca610>)[#text("(25)")]#text(" with ")#mi("{p_1 \\leq e^{\\varepsilon^3 k}}")#text(". This is bounded by")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1 \\leq e^{\\varepsilon^3 k}} \\frac{\\log p_1}{p_1} \\sum_{p_2 = (1+O(\\varepsilon)) e^{\\varepsilon k} / p_1} \\frac{\\varepsilon k}{p_2}")]]

#text("which we can bound crudely using the Chebyshev bound by")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1 \\leq e^{\\varepsilon^3 k}} \\frac{\\log p_1}{p_1}")]]

#text("which by Mertens theorem is ")#mi("{O(\\varepsilon^3 k)}")#text(". Thus the contribution of this case can be safely removed from ")#link(<tao-3946ca64ff78d93ca610>)[#text("(25)")]#text(". Similarly for those cases when ")#mi("{p_2 \\leq e^{\\varepsilon^3 k}}")#text(". For the remaining cases we bound ")#mi("{\\log p_1 \\log p_2 \\leq \\varepsilon^2 k^2}")#text(". We conclude that for any sufficiently large ")#mi("{k}")#text(", either ")#link(<tao-f64551fcd6f07823cb87>)[#text("(24)")]#text(" or ")#metadata(none) <tao-43bb00d0ce7790a53b91>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{p_1 p_2 \\in I_k: p_1,p_2 \\geq e^{\\varepsilon^3 k}} \\frac{1}{p_1 p_2} \\gg \\frac{1}{k}.")]]

#text(" holds (or both).")#linebreak()#text(" In order to find primes ")#mi("{p_1,p_2,p}")#text(" with ")#mi("{p}")#text(" close to ")#mi("{p_1 p_2}")#text(", it would be very convenient if we could find a ")#mi("{k}")#text(" for which ")#link(<tao-f64551fcd6f07823cb87>)[#text("(24)")]#text(" and ")#link(<tao-43bb00d0ce7790a53b91>)[#text("(26)")]#text(" ")#emph[#text("both")]#text(" hold. We can’t quite do this directly, but due to the “connected” nature of the set of scales ")#mi("{k}")#text(", but we can do the next best thing:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 18")]#text(" Suppose ")#mi("{k_0}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(". Then there exists ")#mi("{k,k^{\\prime} \\in [k_0,k_0+\\varepsilon^{-2}]}")#text(" with ")#tao-math("{\\left|k-k^{\\prime}\\right| \\leq 1}", block: false)#text(" such that ")#metadata(none) <tao-6737e52be097f300f37c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\sum_{p \\in I_k} \\frac{1}{p} \\geq \\frac{\\varepsilon}{k}")]]

#text(" and ")#metadata(none) <tao-5f375258492e89b8bb41>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\sum_{p_1 p_2 \\in I_{k^{\\prime}}: p_1,p_2 \\geq e^{\\varepsilon^3 k^{\\prime}}} \\frac{1}{p_1 p_2} \\geq \\varepsilon \\frac{1}{k^{\\prime}}.")]]


]

#emph[#text("Proof:")]#text(" We know that every ")#mi("{k}")#text(" in ")#mi("{[k_0,k_0+\\varepsilon^{-2}]}")#text(" obeys at least one of ")#link(<tao-6737e52be097f300f37c>)[#text("(27)")]#text(", ")#link(<tao-5f375258492e89b8bb41>)[#text("(28)")]#text(". Our task is to produce an adjacent pair of ")#mi("{k,k^{\\prime}}")#text(", one of which obeys ")#link(<tao-6737e52be097f300f37c>)[#text("(27)")]#text(" and the other obeys ")#link(<tao-5f375258492e89b8bb41>)[#text("(28)")]#text(". Suppose for contradiction that no such pair exists, then whenever ")#mi("{k}")#text(" fails to obey ")#link(<tao-6737e52be097f300f37c>)[#text("(27)")]#text(", then any adjacent ")#mi("{k}")#text(" must also fail to do so, and similarly for ")#link(<tao-5f375258492e89b8bb41>)[#text("(28)")]#text(". Thus either ")#link(<tao-6737e52be097f300f37c>)[#text("(27)")]#text(" will fail to hold for all ")#mi("{k \\in [k_0,k_0+\\varepsilon^{-2}]}")#text(", or ")#link(<tao-5f375258492e89b8bb41>)[#text("(28)")]#text(" will fail to hold for all such ")#mi("{k}")#text(". If ")#link(<tao-6737e52be097f300f37c>)[#text("(27)")]#text(" fails for all ")#mi("{k \\in [k_0,k_0+\\varepsilon^{-2}]}")#text(", then on summing we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{e^{\\varepsilon k_0} \\leq p \\leq e^{\\varepsilon^{-1} e^{\\varepsilon k_0}}} \\frac{1}{p} \\ll \\frac{1}{\\varepsilon k_0}")]]

#text("which contradicts Mertens’ theorem if ")#mi("{\\varepsilon}")#text(" is small enough because the left-hand side is ")#mi("{\\gg \\frac{1}{\\varepsilon^2 k_0}}")#text(". Similarly, if ")#link(<tao-5f375258492e89b8bb41>)[#text("(28)")]#text(" fails for all ")#mi("{k \\in [k_0,k_0+\\varepsilon^{-2}]}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\sum_{e^{\\varepsilon k_0} \\leq p_1 p_2 \\leq e^{\\varepsilon^{-1}} e^{\\varepsilon k_0}: p_1,p_2 \\geq e^{2\\varepsilon^3 k_0}} \\frac{1}{p_1 p_2} \\leq \\frac{1}{\\varepsilon k_0}")]]

#text("and again Mertens’ theorem can be used to lower bound the left-hand side by ")#mi("{\\gg \\frac{1}{\\varepsilon^2 k_0}}")#text(" (in fact one can even gain an additional factor of ")#mi("{\\log \\frac{1}{\\varepsilon}}")#text(" if one works things through carefully) and obtain a contradiction. ")#mi("\\Box")#linebreak()#text(" The above proposition does indeed provide a triple of primes ")#mi("{p_1,p_2,p}")#text(" with ")#mi("{p = (1+O(\\varepsilon)) p_1 p_2}")#text(". If ")#mi("{k_0}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(" and less than (say) ")#mi("{\\log\\log x}")#text(", so that ")#mi("{p_1,p_2,p \\leq \\log^{0.1} x}")#text(", this would give us what we need as long as one of the triples consisted only of good primes. The only way this can fail is if either")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\in I_k: p \\text{ bad}} \\frac{1}{p} \\gg \\varepsilon \\frac{1}{k}")]]

#text("for some ")#mi("{k \\in [k_0,k_0+\\varepsilon^{-2}]}")#text(", or if")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1 p_2 \\in I_{k^{\\prime}}: p_1,p_2 \\geq e^{\\varepsilon^3 k^{\\prime}}; p_1 \\text{ bad}} \\frac{1}{p_1 p_2} \\gg \\frac{\\varepsilon}{k^{\\prime}}")]]

#text("for some ")#mi("{k^{\\prime} \\in [k_0,k_0+\\varepsilon^{-2}]}")#text(". In the first case, we can sum to conclude that ")#metadata(none) <tao-9373526471393ca03b42>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\sum_{e^{\\varepsilon k_0} \\leq p \\leq e^{\\varepsilon k_0 + 2\\varepsilon^{-2}}: p \\text{ bad}} \\frac{1}{p} \\gg \\frac{\\varepsilon}{k_0},")]]

#text(" and in the second case we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{e^{\\varepsilon^3 k_0} \\leq p_1 \\leq e^{\\varepsilon k_0 + 2\\varepsilon^{-2}}; p_1 \\text{ bad}} \\sum_{e^{\\varepsilon k_0}/p_1 \\leq p_2 \\leq e^{\\varepsilon(k_0+1)}/p_1} \\frac{1}{p_1 p_2} \\gg \\frac{\\varepsilon}{k_0}")]]

#text("and hence by Chebyshev bounds ")#metadata(none) <tao-b1b9eed2f22bf4dc655f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\sum_{e^{\\varepsilon^3 k_0} \\leq p_1 \\leq e^{\\varepsilon k_0 + 2\\varepsilon^{-2}}; p_1 \\text{ bad}} \\frac{1}{p_1} \\gg \\varepsilon^2.")]]

#text(" Since the total set of bad primes up to ")#mi("{\\log x}")#text(" has logarithmic size ")#mi("{O(\\varepsilon^{-2})}")#text(", we conclude from the pigeonhole principle (and the divergence of the harmonic series ")#mi("{\\sum_{k_0=1}^\\infty \\frac{1}{k_0}}")#text(") that for any ")#mi("{C_\\varepsilon}")#text(" depending only on ")#mi("{\\varepsilon}")#text(", and any ")#mi("{x}")#text(" large enough, there exists ")#mi("{C_\\varepsilon \\leq k_0 \\leq \\log\\log x}")#text(" such that neither of ")#link(<tao-9373526471393ca03b42>)[#text("(29)")]#text(" and ")#link(<tao-b1b9eed2f22bf4dc655f>)[#text("(30)")]#text(" hold. Indeed the set of ")#mi("{C_\\varepsilon \\leq k_0 \\leq \\log\\log x}")#text(" obeying ")#link(<tao-9373526471393ca03b42>)[#text("(29)")]#text(" has logarithmic size ")#mi("{O_\\varepsilon(1)}")#text(", and similarly for ")#link(<tao-b1b9eed2f22bf4dc655f>)[#text("(30)")]#text(". Choosing a ")#mi("{k_0}")#text(" that avoids both of these scenarios, we then find a good ")#mi("{p \\in I_k}")#text(" and good ")#mi("{p_1,p_2}")#text(" with ")#mi("{p_1 p_2 \\in I_{k^{\\prime}}}")#text(", so that ")#mi("{p_1 p_2 = (1+O(\\varepsilon)) p}")#text(", and then by Proposition ")#link(<tao-729cd87c6329408e2bbf>)[#text("16")]#text(" we conclude that ")#mi("{M(x)/x = O(\\varepsilon)}")#text(" for all sufficiently large ")#mi("{x}")#text(". Sending ")#mi("{\\varepsilon}")#text(" to zero, we obtain the prime number theorem.")

#heading(level: 1)[#strong[#text(" — 3. Entropy methods — ")]]

#text("In the previous section we explored the consequences of the second moment method, which applies to square-integrable random variables ")#mi("{\\mathbf{X} \\in L^2}")#text(" taking values in the real or complex numbers. Now we explore entropy methods, which now apply to random variables which take a finite number of values (equipped with the discrete sigma-algebra), but whose range need not be numerical in nature. (One could extend entropy methods to slightly larger classes of random variables, such as ones that attain a countable number of values, but for our applications finitely-valued random variables will suffice.)")

#text("The fundamental notion here is that of the ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(" of a random variable. If ")#mi("{\\mathbf{X}}")#text(" takes values in a finite set ")#mi("{R}")#text(", its Shannon entropy ")#mi("{\\mathbb{H}(\\mathbf{X})}")#text(" (or ")#emph[#text("entropy")]#text(" for short) is defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}(\\mathbf{X}) := \\sum_{x \\in R} {\\mathbb P}(\\mathbf{X}=x) \\log \\frac{1}{{\\mathbb P}(\\mathbf{X}=x)}")]]

#text("where ")#mi("{x}")#text(" ranges over all the possible values of ")#mi("{\\mathbf{X}}")#text(", and we adopt the convention ")#mi("{0 \\log \\frac{1}{0} = 0}")#text(", so that values that are almost surely not attained by ")#mi("{\\mathbf{X}}")#text(" do not influence the entropy. We choose here to use the natural logarithm ")#mi("{\\log}")#text(" to normalise our entropy (in which case a unit of entropy is known as a “")#link("https://en.wikipedia.org/wiki/Nat_(unit)")[#text("nat")]#text("“); in the information theory literature it is also common to use the base two logarithm ")#mi("{\\log_2}")#text(" to measure entropy (in which case a unit of entropy is known as a “")#link("https://en.wikipedia.org/wiki/Bit")[#text("bit")]#text("“, which is equal to ")#mi("{\\log 2}")#text(" nats). However, the precise choice of normalisation will not be important in our discussion.")#linebreak()#text(" It is clear that if two random variables ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" have the same probability distribution, then they have the same entropy. Also, the precise choice of range set ")#mi("{R}")#text(" is not terribly important: if ")#mi("{\\mathbf{X}}")#text(" takes values in ")#mi("{R}")#text(", and ")#mi("{f: R \\rightarrow R^{\\prime}}")#text(" is an injection, then it is clear that ")#mi("{\\mathbf{X}}")#text(" and ")#mi("{f(\\mathbf{X})}")#text(" have the same entropy: ")#metadata(none) <tao-f44c1a1e364019d095c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\mathbb{H}(f(\\mathbf{X})) = \\mathbb{H}(\\mathbf{X}).")]]

#linebreak()#text(" This is in sharp contrast to moment-based statistics such as the mean or variance, which can be radically changed by applying some injective transformation to the range values.")#linebreak()#text(" Informally, the entropy ")#mi("{\\mathbb{H}(\\mathbf{X})}")#text(" informally measures how “spread out” or “disordered” the distribution of ")#mi("{\\mathbf{X}}")#text(" is, behaving like a logarithm of the size of the “essential support” of such a variable; from an information-theoretic viewpoint, it measures the amount of “information” one learns when one is told the value of ")#mi("{\\mathbf{X}}")#text(". Here are some basic properties of Shannon entropy that help support this intuition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Basic properties of Shannon entropy)")]#text(" Let ")#mi("{\\mathbf{X}}")#text(" be a random variable taking values in a finite set ")#mi("{R}")#text(".")

#list(
[#text("(i) Show that ")#mi("{\\mathbb{H}(\\mathbf{X}) \\geq 0}")#text(", with equality if and only if ")#mi("{\\mathbf{X}}")#text(" is almost surely deterministic (that is to say, it is almost surely equal to a constant ")#mi("{x}")#text(").")],
[#text("(ii) Show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\mathbb{H}(\\mathbf{X}) \\leq \\log \\# R,")]]

#metadata(none) <tao-c87f42bd454c031b875b>#text(" with equality if and only if ")#mi("{\\mathbf{X}}")#text(" is uniformly distributed on ")#mi("{R}")#text(". (Hint: use ")#link("https://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(" and the concavity of the map ")#mi("{t \\mapsto t \\log \\frac{1}{t}}")#text(" on ")#mi("{[0,1]}")#text(".)")],
[#text("(iii) (")#link("https://en.wikipedia.org/wiki/Asymptotic_equipartition_property")[#text("Shannon-McMillan-Breiman theorem")]#text(") Let ")#mi("{n}")#text(" be a natural number, and let ")#mi("{\\mathbf{X}_1, \\mathbf{X}_2, \\dots, \\mathbf{X}_n}")#text(" be independent copies of ")#mi("{\\mathbf{X}}")#text(". As ")#mi("{n \\rightarrow \\infty}")#text(", show that there is a subset ")#mi("{\\Omega_n \\subset R^n}")#text(" of cardinality ")#mi("{e^{(\\mathbb{H}(\\mathbf{X}) + o(1)) n}}")#text(" with the properties that")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}( (\\mathbf{X}_1,\\dots,\\mathbf{X}_n) \\in \\Omega_n ) = 1-o(1)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}( (\\mathbf{X}_1,\\dots,\\mathbf{X}_n) = (x_1,\\dots,x_n) ) = e^{(-\\mathbb{H}(\\mathbf{X}) + o(1)) n}")]]

#text("uniformly for all ")#mi("{(x_1,\\dots,x_n) \\in \\Omega_n}")#text(". (The proof of this theorem will require ")#link("https://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text(", which you may assume here as a black box; see also ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("this previous blog post")]#text(".) Informally, we thus see a large tuple ")#mi("{(\\mathbf{X}_1,\\dots,\\mathbf{X}_n)}")#text(" of independent samples of ")#mi("{\\mathbf{X}}")#text(" approximately behaves like a uniform distribution on ")#mi("{e^{(\\mathbb{H}(\\mathbf{X}) + o(1)) n}}")#text(" values.")]
)
]

#text("One can view Shannon entropy as a generalisation of the notion of cardinality of a finite set (or equivalently, cardinality of finite sets can be viewed as a special case of Shannon entropy); see ")#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/")[#text("this previous blog post")]#text(" for an elaboration of this point.")

#text("The concept of Shannon entropy becomes significantly more powerful when combined with that of ")#link("https://en.wikipedia.org/wiki/Conditional_probability")[#text("conditioning")]#text(". Recall that a random variable ")#mi("{\\mathbf{X}}")#text(" taking values in a range set ")#mi("{R}")#text(" can be modeled by a measurable map ")#mi("{\\mathbf{X}: \\Omega \\rightarrow R}")#text(" from a probability space ")#mi("{(\\Omega,{\\mathcal F}, \\mathop{\\bf P})}")#text(" to the range ")#mi("{R}")#text(". If ")#mi("{E \\in {\\mathcal F}}")#text(" is an event in ")#mi("{\\Omega}")#text(" of positive probability, we can then ")#emph[#text("condition")]#text(" ")#mi("{\\mathbf{X}: \\Omega \\rightarrow R}")#text(" to the event ")#mi("{E}")#text(" to form a new random variable ")#mi("{(\\mathbf{X}|E): E \\rightarrow R}")#text(" on the conditioned probability space ")#mi("{(E, {\\mathcal F}|_E, \\mathop{\\bf P}|E)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("{\\mathcal F}|_E := \\{ E \\cap F: F \\in {\\mathcal F} \\}")]]

#text("is the restriction of the ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal F}}")#text(" to ")#mi("{E}")#text(",")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}(F|E) := \\frac{{\\mathbb P}( E \\cap F )}{{\\mathbb P}(E)}")]]

#text("is the conditional probability measure on ")#mi("{E}")#text(", and ")#mi("{\\mathbf{X}|E:E \\rightarrow R}")#text(" is the restriction of ")#mi("{\\mathbf{X}: \\Omega \\rightarrow R}")#text(" to ")#mi("{E}")#text(". This random variable ")#mi("{(\\mathbf{X}|E)}")#text(" lives on a different probability space than ")#mi("{\\mathbf{X}}")#text(" itself, so it does not make sense to directly combine these variables (thus for instance one cannot form the sum ")#mi("{\\mathbf{X} + (\\mathbf{X}|E)}")#text(" even when both random variables are real or complex valued); however, one can still form the Shannon entropy ")#mi("{\\mathbb{H}( \\mathbf{X}|E )}")#text(" of the conditioned random variable ")#mi("{(\\mathbf{X}|E)}")#text(", which is given by the same formula")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}(\\mathbf{X}|E) := \\sum_{x \\in R} {\\mathbb P}(\\mathbf{X}=x|E) \\log \\frac{1}{{\\mathbb P}(\\mathbf{X}=x|E)}.")]]

#text("Given another random variable ")#mi("{\\mathbf{Y}: \\Omega \\rightarrow S}")#text(" taking values in another finite set ")#mi("{S}")#text(", we can then define the conditional Shannon entropy ")#mi("{\\mathbb{H}(\\mathbf{X}|\\mathbf{Y})}")#text(" to be the expected entropy of the level sets ")#mi("{\\mathbb{H}(\\mathbf{X}|\\mathbf{Y}=y)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}(\\mathbf{X}|\\mathbf{Y}) := \\sum_{y \\in S} {\\mathbb P}( \\mathbf{Y} = y ) \\mathbb{H}(\\mathbf{X}|\\mathbf{Y}=y)")]]

#text("with the convention that the summand here vanishes when ")#mi("{{\\mathbb P}( \\mathbf{Y} = y ) = 0}")#text(". From the ")#link("https://en.wikipedia.org/wiki/Law_of_total_probability")[#text("law of total probability")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}( \\mathbf{X}=x ) = \\sum_{y \\in S} {\\mathbb P}( \\mathbf{Y} = y ) {\\mathbb P}(\\mathbf{X}=x|\\mathbf{Y}=y)")]]

#text("for any ")#mi("{x \\in R}")#text(", and hence by Jensen’s inequality")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}( \\mathbf{X}=x ) \\log \\frac{1}{{\\mathbb P}( \\mathbf{X}=x )} \\leq \\sum_{y \\in S} {\\mathbb P}( \\mathbf{Y} = y ) {\\mathbb P}(\\mathbf{X}=x|\\mathbf{Y}=y) \\log \\frac{1}{{\\mathbb P}(\\mathbf{X}=x|\\mathbf{Y}=y)}")]]

#text("for any ")#mi("{x \\in R}")#text("; summing we obtain the Shannon entropy inequality ")#metadata(none) <tao-64894915db4f89e88bad>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\mathbb{H}(\\mathbf{X}|\\mathbf{Y}) \\leq \\mathbb{H}(\\mathbf{X}).")]]

#text(" Informally, this inequality asserts that the new information content of ")#mi("{\\mathbf{X}}")#text(" can be decreased, but not increased, if one is first told some additional information ")#mi("{\\mathbf{Y}}")#text(".")#linebreak()#text(" This inequality ")#link(<tao-64894915db4f89e88bad>)[#text("(33)")]#text(" can be rewritten in several ways:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{\\mathbf{X}: \\Omega \\rightarrow R}")#text(", ")#mi("{\\mathbf{Y}: \\Omega \\rightarrow S}")#text(" be random variables taking values in finite sets ")#mi("{R,S}")#text(" respectively.")

#list(
[#text("(i) Establish the chain rule")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("\\mathbb{H}(\\mathbf{X}, \\mathbf{Y}) = \\mathbb{H}(\\mathbf{Y}) + \\mathbb{H}(\\mathbf{X}|\\mathbf{Y})")]]

#metadata(none) <tao-9414886b1ebf025db067>#text(" where ")#mi("{(\\mathbf{X}, \\mathbf{Y}): \\Omega \\rightarrow R \\times S}")#text(" is the joint random variable ")#mi("{(\\mathbf{X}, \\mathbf{Y})(\\omega) := (\\mathbf{X}(\\omega), \\mathbf{Y}(\\omega))}")#text(". In particular, ")#link(<tao-64894915db4f89e88bad>)[#text("(33)")]#text(" can be expressed as a subadditivity formula ")#metadata(none) <tao-ee30c0cbfe79a1fe11af>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\mathbb{H}(\\mathbf{X}, \\mathbf{Y}) \\leq \\mathbb{H}(\\mathbf{X}) + \\mathbb{H}(\\mathbf{Y}).")]]

#text(" Show that equality occurs if and only if ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" are independent.")],
[#text("(ii) If ")#mi("{\\mathbf{Y}}")#text(" is a function of ")#mi("{\\mathbf{X}}")#text(", in the sense that ")#mi("{\\mathbf{Y} = f(\\mathbf{X})}")#text(" for some (deterministic) function ")#mi("{f: R \\rightarrow S}")#text(", show that ")#mi("{\\mathbb{H}( \\mathbf{Y} ) \\leq \\mathbb{H}( \\mathbf{X}, \\mathbf{Y} ) = \\mathbb{H}( \\mathbf{X} )}")#text(".")],
[#text("(iii) Define the ")#link("https://en.wikipedia.org/wiki/Mutual_information")[#text("mutual information")]#text(" ")#mi("{\\mathbb{I}( \\mathbf{X}: \\mathbf{Y} )}")#text(" by the formula")

#tao-aligned(keep: true)[


#tao-math("\\mathbb{I}( \\mathbf{X}:\\mathbf{Y} )  & := \\mathbb{H}(\\mathbf{X}) + \\mathbb{H}(\\mathbf{Y}) - \\mathbb{H}( \\mathbf{X}, \\mathbf{Y} )", block: true)



#tao-math(" & = \\mathbb{H}(\\mathbf{X}) - \\mathbb{H}(\\mathbf{X}|\\mathbf{Y})", block: true)



#tao-math(" & = \\mathbb{H}(\\mathbf{Y}) - \\mathbb{H}(\\mathbf{Y}|\\mathbf{X}).", block: true)
]

#text("Establish the inequalities")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\mathbb{I}( \\mathbf{X}:\\mathbf{Y} ) \\leq \\mathbb{H}(\\mathbf{X}), \\mathbb{H}(\\mathbf{Y}),")]]

#text("with the first inequality holding with equality if and only if ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" are independent, and the latter inequalities holding if and only if ")#mi("{\\mathbf{X}}")#text(" is a function of ")#mi("{\\mathbf{Y}}")#text(" (or vice versa).")]
)
]

#text("From the above exercise we see that the mutual information ")#mi("{\\mathbb{I}( \\mathbf{X}: \\mathbf{Y} )}")#text(" is a measure of dependence between ")#mi("{\\mathbf{X}}")#text(" and ")#mi("{\\mathbf{Y}}")#text(", much as correlation or covariance was in the previous sections. There is however one key difference: whereas a zero correlation or covariance is a consequence but not a guarantee of independence, zero mutual information is ")#emph[#text("logically equivalent")]#text(" to independence, and is thus a stronger property. To put it another way, zero correlation or covariance allows one to calculate the average ")#mi("{\\mathbb{E}( \\mathbf{X} \\mathbf{Y} )}")#text(" in terms of individual averages of ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(", but zero mutual information is stronger because it allows one to calculate the more general averages ")#mi("{\\mathbb{E}( f(\\mathbf{X}) g(\\mathbf{Y}) )}")#text(" in terms of individual averages of ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(", for arbitrary functions ")#mi("{f,g}")#text(" taking values into the complex numbers. This increased power of the mutual information statistic will allow us to estimate various averages of interest in analytic number theory in ways that do not seem amenable to second moment methods.")

#text("The subadditivity property formula can be conditioned to any event ")#mi("{E}")#text(" occuring with positive probability (replacing the random variables ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" by their conditioned counterparts ")#mi("{({\\mathbf X}|E), (\\mathbf{Y}|E)}")#text("), yielding the inequality")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}(\\mathbf{X}, \\mathbf{Y}|E) \\leq \\mathbb{H}(\\mathbf{X}|E) + \\mathbb{H}(\\mathbf{Y}|E).")]]

#text("Applying this inequality to the level events ")#mi("{\\mathbf{Z}=z}")#text(" of some auxiliary random variable ")#mi("{\\mathbf{Z}: \\Omega \\rightarrow T}")#text(" taking values in another finite set ")#mi("{T}")#text(", multiplying by ")#mi("{\\mathbf{P}( \\mathbf{Z}=z)}")#text(", and summing, we conclude the inequality")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}(\\mathbf{X}, \\mathbf{Y}|{\\mathbf Z}) \\leq \\mathbb{H}(\\mathbf{X}|\\mathbf{Z}) + \\mathbb{H}(\\mathbf{Y}|\\mathbf{Z}).")]]

#text("In other words, the ")#link("https://en.wikipedia.org/wiki/Conditional_mutual_information")[#text("conditional mutual information")]

#align(center)[#tao-fit-display[#mitex("\\mathbb{I}( \\mathbf{X}: \\mathbf{Y}|{\\mathbf Z} ) := \\mathbb{H}(\\mathbf{X}|\\mathbf{Z}) + \\mathbb{H}(\\mathbf{Y}|\\mathbf{Z})-\\mathbb{H}(\\mathbf{X}, \\mathbf{Y}|{\\mathbf Z})")]]

#text("between ")#mi("{\\mathbf{X}}")#text(" and ")#mi("{\\mathbf{Y}}")#text(" conditioning on ")#mi("{{\\mathbf Z}}")#text(" is always non-negative: ")#metadata(none) <tao-e71eace4dcc32e354f08>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\mathbb{I}( \\mathbf{X}: \\mathbf{Y}|{\\mathbf Z} ) \\geq 0.")]]

#text(" One has conditional analogues of the above exercise:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{\\mathbf{X}: \\Omega \\rightarrow R}")#text(", ")#mi("{\\mathbf{Y}: \\Omega \\rightarrow S}")#text(", ")#mi("{\\mathbf{Z}: \\Omega \\rightarrow T}")#text(" be random variables taking values in finite sets ")#mi("{R,S,T}")#text(" respectively.")

#list(
[#text("(i) Establish the conditional chain rule")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\mathbb{H}(\\mathbf{X}, \\mathbf{Y}|{\\mathbf Z}) = \\mathbb{H}(\\mathbf{X}|{\\mathbf Z}) + \\mathbb{H}(\\mathbf{Y}|\\mathbf{X}, {\\mathbf Z})")]]

#metadata(none) <tao-0ab2dd2f64c9fd4e4310>#text(" and show that ")#metadata(none) <tao-ff3d7d9e4c824480a121>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\mathbb{I}( \\mathbf{X}:\\mathbf{Y} | \\mathbf{Z}) = \\mathbb{H}(\\mathbf{X}|\\mathbf{Z}) - \\mathbb{H}(\\mathbf{X}|\\mathbf{Y}, \\mathbf{Z})")]]



#align(center)[#tao-fit-display[#mitex("= \\mathbb{H}(\\mathbf{Y}|\\mathbf{Z}) - \\mathbb{H}(\\mathbf{Y}|\\mathbf{X}, \\mathbf{Z}).")]]

#text("In particular, ")#link(<tao-e71eace4dcc32e354f08>)[#text("(36)")]#text(" is equivalent to the inequality ")#metadata(none) <tao-bb9af5d1915da1fbc132>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("\\mathbb{H}(\\mathbf{X}|\\mathbf{Y}, \\mathbf{Z}) \\leq \\mathbb{H}(\\mathbf{X}|\\mathbf{Z}).")]]

],
[#text("(ii) Show that equality holds in ")#link(<tao-e71eace4dcc32e354f08>)[#text("(36)")]#text(" if and only if ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" are ")#link("https://en.wikipedia.org/wiki/Conditional_independence")[#text("conditionally independent")]#text(" relative to ")#mi("{\\mathbf{Z}}")#text(", which means that")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}( \\mathbf{X} \\in E, \\mathbf{Y} \\in F | \\mathbf{Z} = z ) = {\\mathbb P}( \\mathbf{X} \\in E|\\mathbf{Z}=z) {\\mathbb P}(\\mathbf{Y} \\in F | \\mathbf{Z} = z )")]]

#text("for any ")#mi("{E \\subset R}")#text(", ")#mi("{F \\subset S}")#text(", ")#mi("{z \\in T}")#text(".")],
[#text("(iii) Show that ")#mi("{\\mathbb{I}( \\mathbf{X}:\\mathbf{Y} | \\mathbf{Z}) \\leq \\mathbb{H}(\\mathbf{X}|\\mathbf{Z})}")#text(", with equality if and only if ")#mi("{\\mathbf{X}}")#text(" is almost surely a deterministic function of ")#mi("{\\mathbf{Y}, \\mathbf{Z}}")#text(".")],
[#text("(iv) Show the ")#link("https://en.wikipedia.org/wiki/Data_processing_inequality")[#text("data processing inequality")]

#align(center)[#tao-fit-display[#mitex("\\mathbb{I}( f(\\mathbf{X}) : g(\\mathbf{Y}) ) \\leq \\mathbb{I}( \\mathbf{X}: \\mathbf{Y} )")]]

#text("for any functions ")#mi("{f: R \\rightarrow R^{\\prime}}")#text(", ")#mi("{g:S \\rightarrow S^{\\prime}}")#text(", and more generally that")

#align(center)[#tao-fit-display[#mitex("\\mathbb{I}( f(\\mathbf{X}) : g(\\mathbf{Y}) | \\mathbf{Z} ) \\leq \\mathbb{I}( \\mathbf{X} : \\mathbf{Y} | \\mathbf{Z} ).")]]],
[#text("(v) If ")#mi("{h: T \\rightarrow T^{\\prime}}")#text(" is an injective function, show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("\\mathbb{I}( \\mathbf{X} : \\mathbf{Y} | h(\\mathbf{Z}) ) = \\mathbb{I}( \\mathbf{X} : \\mathbf{Y} | \\mathbf{Z} ).")]]

#metadata(none) <tao-4968d0cf3b24d26d1d37>#text(" However, if ")#mi("{h: T \\rightarrow T^{\\prime}}")#text(" is not assumed to be injective, show by means of examples that there is no order relation between the left and right-hand side of ")#link(<tao-4968d0cf3b24d26d1d37>)[#text("(40)")]#text(" (in other words, show that either side may be greater than the other). Thus, increasing or decreasing the amount of information that is known may influence the mutual information between two remaining random variables in either direction.")],
[#text("(vi) If ")#mi("{\\mathbf{Z}}")#text(" is a function of ")#mi("{\\mathbf{X}}")#text(", and also a function of ")#mi("{\\mathbf{Y}}")#text(" (thus ")#mi("{\\mathbf{Z} = f(\\mathbf{X}) = g(\\mathbf{Y})}")#text(" for some ")#mi("{f: R \\rightarrow T}")#text(" and ")#mi("{g: S \\rightarrow T}")#text("), and a further random variable ")#mi("{\\mathbf{W}: \\Omega \\rightarrow U}")#text(" is a function jointly of ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" (thus ")#mi("{\\mathbf{W} = h( \\mathbf{X}, \\mathbf{Y})}")#text(" for some ")#mi("{h: R \\times S \\rightarrow U}")#text("), establish the ")#link("https://en.wikipedia.org/wiki/Submodular_set_function")[#text("submodularity inequality")]

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}(\\mathbf{W}) + \\mathbb{H}(\\mathbf{Z}) \\leq \\mathbb{H}(\\mathbf{X}) + \\mathbb{H}(\\mathbf{Y}).")]]]
)
]

#text("We now give a key motivating application of the Shannon entropy inequalities. Suppose one has a sequence ")#mi("{\\mathbf{X}_1, \\mathbf{X}_2, \\dots}")#text(" of random variables, all taking values in a finite set ")#mi("{R}")#text(", which are ")#link("https://en.wikipedia.org/wiki/Stationary_process")[#text("stationary")]#text(" in the sense that the tuples ")#mi("{(\\mathbf{X}_1,\\dots,\\mathbf{X}_n)}")#text(" and ")#mi("{(\\mathbf{X}_2,\\dots,\\mathbf{X}_{n+1})}")#text(" have the same distribution for every ")#mi("{n}")#text(". In particular we will have")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}( \\mathbf{X}_{n+1} | \\mathbf{X}_2,\\dots,\\mathbf{X}_n ) = \\mathbb{H}( \\mathbf{X}_{n} | \\mathbf{X}_1,\\dots,\\mathbf{X}_{n-1} )")]]

#text("and hence by ")#link(<tao-bb9af5d1915da1fbc132>)[#text("(39)")]

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}( \\mathbf{X}_{n+1} | \\mathbf{X}_1,\\dots,\\mathbf{X}_n ) \\leq \\mathbb{H}( \\mathbf{X}_{n} | \\mathbf{X}_1,\\dots,\\mathbf{X}_{n-1} ).")]]

#text("If we write ")#mi("{h_n := \\mathbb{H}(\\mathbf{X}_1,\\dots,\\mathbf{X}_n)}")#text(", we conclude from ")#link(<tao-9414886b1ebf025db067>)[#text("(34)")]#text(" that we have the concavity property")

#align(center)[#tao-fit-display[#mitex("h_{n+1} - h_n \\leq h_n - h_{n-1}.")]]

#text("In particular we have ")#mi("{h_{n+1} - h_n \\leq h_i - h_{i-1}}")#text(" for any ")#mi("{1 \\leq i \\leq n}")#text(", which on summing and telescoping series (noting that ")#mi("{h_0=0}")#text(") gives")

#align(center)[#tao-fit-display[#mitex("n (h_{n+1} - h_n) \\leq h_n")]]

#text("and hence we have the entropy monotonicity ")#metadata(none) <tao-7446783c207819c88f43>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\frac{h_{n+1}}{n+1} \\leq \\frac{h_n}{n}.")]]

#text(" In particular, the limit ")#mi("{\\lim_{n \\rightarrow\\infty} \\frac{h_n}{n}}")#text(" exists. This quantity is known as the ")#link("https://en.wikipedia.org/wiki/Measure-preserving_dynamical_system#Measure-theoretic_entropy")[#text("Kolmogorov-Sinai entropy")]#text(" of the stationary process ")#mi("{\\mathbf{X}_1, \\mathbf{X}_2, \\dots}")#text("; it is an important statistic in the theory of dynamical systems, and roughly speaking measures the amount of entropy produced by this process as a function of a discrete time variable ")#mi("{n}")#text(". We will not directly need the Kolmogorov-Sinai entropy in our notes, but a variant of the entropy monotonicity formula ")#link(<tao-7446783c207819c88f43>)[#text("(41)")]#text(" will be important shortly.")#linebreak()#text(" In our application we will be dealing with processes that are only asymptotically stationary rather than stationary. To control this we recall the notion of the ")#link("https://en.wikipedia.org/wiki/Total_variation_distance_of_probability_measures")[#text("total variation distance")]#text(" ")#mi("{d_{TV}(\\mathbf{X}, \\mathbf{Y})}")#text(" between two random variables ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" taking values in the same finite space ")#mi("{R}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("d_{TV}(\\mathbf{X}, \\mathbf{Y}) := \\sum_{r \\in R} | {\\mathbb P}( \\mathbf{X} = r ) - {\\mathbb P}( \\mathbf{Y} = r ) |.")]]

#text("There is an essentially equivalent notion of this distance which is also often in use:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" If two random variables ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" take values in the same finite space ")#mi("{R}")#text(", establish the inequalities")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} d_{TV}(\\mathbf{X}, \\mathbf{Y}) \\leq \\sup_{E \\subset R} \\left|{\\mathbb P}( \\mathbf{X} = E ) - {\\mathbb P}( \\mathbf{Y} = E )\\right| \\leq d_{TV}(\\mathbf{X}, \\mathbf{Y})", block: true)]]

#text("and for any ")#mi("{f: R \\rightarrow {\\bf C}}")#text(", establish the inequality ")#metadata(none) <tao-0a3f13c673af2389ecb9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#tao-math("\\left|{\\mathbb E} f(\\mathbf{X}) - {\\mathbb E} f(\\mathbf{Y})\\right| \\leq d_{TV}(\\mathbf{X}, \\mathbf{Y}) \\sup_{r \\in R} \\left|f(r)\\right|.", block: true)]]


]

#text("Shannon entropy is continuous in total variation distance as long as we keep the range finite. More quantitatively, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 23")]#text(" ")#metadata(none) <tao-499a7fffbbadda60ba31>#text(" If two random variables ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" take values in the same finite space ")#mi("{R}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}(\\mathbf{X}) = \\mathbb{H}(\\mathbf{Y}) + O( d_{TV}(\\mathbf{X}, \\mathbf{Y}) \\log(\\# R (1 +\\frac{1}{d_{TV}(\\mathbf{X}, \\mathbf{Y})})) )")]]

#text("with the convention that the error term vanishes when ")#mi("{d_{TV}(\\mathbf{X}, \\mathbf{Y}) = 0}")#text(".")
]

#emph[#text("Proof:")]#text(" Set ")#mi("{\\varepsilon := d_{TV}(\\mathbf{X}, \\mathbf{Y})}")#text(". The claim is trivial when ")#mi("{\\varepsilon=0}")#text(" (since then ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" have the same distribution) and when ")#mi("{\\varepsilon \\geq 1/2}")#text(" (from ")#link(<tao-c87f42bd454c031b875b>)[#text("(32)")]#text("), so let us assume ")#mi("{0 < \\varepsilon < \\frac{1}{2}}")#text(", and our task is to show that")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}(\\mathbf{X}) = \\mathbb{H}(\\mathbf{Y}) + O( \\varepsilon \\log \\# R + \\varepsilon \\log \\frac{1}{\\varepsilon} ).")]]

#text("If we write ")#mi("{h(p) := p \\log \\frac{1}{p}}")#text(", ")#mi("{p_r := {\\mathbb P}( \\mathbf{X} = r )}")#text(", and ")#mi("{q_r := {\\mathbb P}( \\mathbf{Y} = r )}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}(\\mathbf{X}) = \\mathbb{H}(\\mathbf{Y}) + \\sum_{r \\in R} h(q_r) - h(p_r).")]]

#text("By dividing into the cases ")#tao-math("{\\left|p_r-q_r\\right| \\leq \\frac{1}{2} q_r}", block: false)#text(" and ")#tao-math("{\\left|p_r-q_r\\right| > \\frac{1}{2} q_r}", block: false)#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("h(q_r) - h(p_r) \\ll \\left|p_r - q_r\\right| + h( \\left|p_r - q_r\\right| )", block: true)]]

#text("since ")#tao-math("{\\varepsilon = \\sum_{r \\in R} \\left|p_r - q_r\\right|}", block: false)#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{r \\in R} h( \\left|p_r - q_r\\right| ) \\ll \\varepsilon \\log \\# R + \\varepsilon \\log \\frac{1}{\\varepsilon}.", block: true)]]

#text("But from Jensen’s inequality ")#link(<tao-c87f42bd454c031b875b>)[#text("(32)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{r \\in R} h( \\frac{\\left|p_r - q_r\\right|}{\\varepsilon} ) \\leq \\log \\# R;", block: true)]]

#text("since ")#tao-math("{h( \\left|p_r - q_r\\right| ) = \\varepsilon h( \\frac{\\left|p_r - q_r\\right|}{\\varepsilon} ) + \\left|p_r-q_r\\right| \\log \\frac{1}{\\varepsilon}}", block: false)#text(", the claim follows. ")#mi("\\Box")#linebreak()#text(" In the converse direction, if a random variable has entropy close to the maximum ")#mi("{\\log \\# R}")#text(", then one can control the total variation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 24 (Special case of Pinsker inequality)")]#text(" ")#metadata(none) <tao-a67a41c8bc79d5da917b>#text(" If ")#mi("{\\mathbf{X}}")#text(" takes values in a finite set ")#mi("{R}")#text(", and ")#mi("{\\mathbf{U}}")#text(" is a uniformly distributed random variable on ")#mi("{R}")#text(", then")

#align(center)[#tao-fit-display[#mitex("d_{TV}( \\mathbf{X}, \\mathbf{U} ) \\ll \\left( \\mathbb{H}( \\mathbf{U} ) - \\mathbb{H}( \\mathbf{X} ) \\right)^{1/2}.")]]
]

#text("Of course, we have ")#mi("{\\mathbb{H}(\\mathbf{U}) = \\log \\# R}")#text(", so we may also write the above inequality as")

#align(center)[#tao-fit-display[#mitex("d_{TV}( \\mathbf{X}, \\mathbf{U} ) \\ll \\left( \\log \\# R - \\mathbb{H}( \\mathbf{X} ) \\right)^{1/2}.")]]

#text("The optimal value of the implied constant here is known to equal ")#mi("{\\sqrt{2}}")#text(", but we will not use this sharp version of the inequality here.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" If we write ")#mi("{p_r := {\\mathbb P}( \\mathbf{X} = r )}")#text(" and ")#mi("{q_r := {\\mathbb P}( \\mathbf{U} = r ) = 1/\\# R}")#text(", and ")#mi("{h(p) := p \\log \\frac{1}{p}}")#text(", then we can rewrite the claimed inequality as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{r \\in R} \\left|p_r - q_r\\right| \\ll \\left( \\sum_{r \\in R} h(q_r) - h(p_r) \\right)^{1/2}.", block: true)]]

#text("Observe that the function ")#mi("{h}")#text(" is concave, and in fact ")#mi("{h^{\\prime\\prime}(p) = - \\frac{1}{p}}")#text(" for all ")#mi("{0 < p \\leq 1}")#text(". From this and Taylor expansion with remainder we may write")

#align(center)[#tao-fit-display[#tao-math("h(q_r) - h(p_r) = h^{\\prime}(q_r) (q_r - p_r) + \\frac{1}{2} \\frac{\\left|p_r - q_r\\right|^2}{s_r}", block: true)]]

#text("for some ")#mi("{s_r}")#text(" between ")#mi("{p_r}")#text(" and ")#mi("{q_r}")#text(". Since ")#mi("{h^{\\prime}(q_r)}")#text(" is independent of ")#mi("{r}")#text(", and ")#mi("{\\sum_{r \\in R} q_r = \\sum_{r \\in R} p_r = 1}")#text(", we thus have on summing in ")#mi("{r}")

#align(center)[#tao-fit-display[#tao-math("\\sum_{r \\in R} h(q_r) - h(p_r) = \\frac{1}{2} \\sum_{r \\in R} \\frac{\\left|p_r - q_r\\right|^2}{s_r}.", block: true)]]

#text("By Cauchy-Schwarz we then have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{r \\in R} \\left|p_r - q_r\\right| \\ll \\left( \\sum_{r \\in R} h(q_r) - h(p_r) \\right)^{1/2} \\left( \\sum_{r \\in R} s_r \\right)^{1/2}.", block: true)]]

#text("Since ")#mi("{s_r = O( p_r + q_r)}")#text(" and ")#mi("{\\sum_{r \\in R} q_r = \\sum_{r \\in R} p_r = 1}")#text(", the claim follows. ")#mi("\\Box")#linebreak()#text(" The above lemma does not hold when the comparison variable ")#mi("{\\mathbf{U}}")#text(" is not assumed to be uniform; in particular, two non-uniform random variables can have precisely the same entropy but yet have different distributions, so that their total variation distance is positive. There is a more general variant, known as the ")#link("https://en.wikipedia.org/wiki/Pinsker%27s_inequality")[#text("Pinsker inequality")]#text(", which we will not use in these notes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Pinsker inequality)")]#text(" If ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" take values in a finite set ")#mi("{R}")#text(", define the ")#link("https://en.wikipedia.org/wiki/Kullback%E2%80%93Leibler_divergence")[#text("Kullback-Leibler divergence")]#text(" of ")#mi("{\\mathbf{X}}")#text(" relative to ")#mi("{\\mathbf{Y}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("d_{KL}( \\mathbf{X} || \\mathbf{Y} ) := \\sum_{r \\in R} \\mathbf{P}( \\mathbf{X} = r ) \\log \\frac{\\mathbf{P}( \\mathbf{X} = r )}{\\mathbf{P}( \\mathbf{Y} = r )}")]]

#text("(with the convention that the summand vanishes when ")#mi("{\\mathbf{P}( \\mathbf{X} = r )}")#text(" vanishes).")

#list(
[#text("(i) Establish the ")#link("https://en.wikipedia.org/wiki/Gibbs%27_inequality")[#text("Gibbs inequality")]#text(" ")#mi("{0 \\leq d_{KL}(\\mathbf{X} || \\mathbf{Y}) \\leq +\\infty}")#text(".")],
[#text("(ii) Establish the ")#link("https://en.wikipedia.org/wiki/Pinsker%27s_inequality")[#text("Pinsker inequality")]

#align(center)[#tao-fit-display[#mitex("d_{TV}( \\mathbf{X}, \\mathbf{Y} ) \\ll d_{KL}( \\mathbf{X} || \\mathbf{Y} )^{1/2}.")]]

#text("In particular, ")#mi("{d_{KL}( \\mathbf{X} || \\mathbf{Y} )}")#text(" vanishes if and only if ")#mi("{\\mathbf{X}, \\mathbf{Y}}")#text(" have identical distribution. Show that this implies Lemma ")#link(<tao-a67a41c8bc79d5da917b>)[#text("24")]#text(" as a special case.")],
[#text("(iii) Give an example to show that the Kullback-Leibler divergence need not be symmetric, thus there exist ")#mi("{\\mathbf{X},\\mathbf{Y}}")#text(" such that ")#mi("{d_{KL}( \\mathbf{X} || \\mathbf{Y} ) \\neq d_{KL}( \\mathbf{Y} || \\mathbf{X} )}")#text(".")],
[#text("(iv) If ")#mi("{\\mathbf{X}_1, \\mathbf{X}_2}")#text(" are random variables taking values in finite sets ")#mi("{R_1,R_2}")#text(", and ")#mi("{\\mathbf{X}^{\\prime}_1, \\mathbf{X}^{\\prime}_2}")#text(" are ")#emph[#text("independent")]#text(" random variables taking values in ")#mi("{R_1,R_2}")#text(" respectively with each ")#mi("{\\mathbf{X}^{\\prime}_i}")#text(" having the same distribution of ")#mi("{\\mathbf{X}_i}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\mathbb{I}( X_1 : X_2 ) = d_{KL}( (X_1,X_2) || (X^{\\prime}_1,X^{\\prime}_2) ).")]]]
)
]

#text("In our applications we will need a relative version of Lemma ")#link(<tao-a67a41c8bc79d5da917b>)[#text("24")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 26 (Relative Pinsker inequality)")]#text(" ")#metadata(none) <tao-b6296fc293b3c39b089f>#text(" If ")#mi("{\\mathbf{X}}")#text(" takes values in a finite set ")#mi("{R}")#text(", ")#mi("{\\mathbf{Z}}")#text(" takes values in a finite set ")#mi("{T}")#text(", and ")#mi("{\\mathbf{U}}")#text(" is a uniformly distributed random variable on ")#mi("{R}")#text(" that is independent of ")#mi("{\\mathbf{Z}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("d_{TV}( (\\mathbf{X},\\mathbf{Z}), (\\mathbf{U},\\mathbf{Z}) ) \\ll \\left( \\mathbb{H}( \\mathbf{U} ) - \\mathbb{H}( \\mathbf{X} | \\mathbf{Z} ) \\right)^{1/2}.")]]
]

#emph[#text("Proof:")]#text(" From direct calculation we have the identity")

#align(center)[#tao-fit-display[#mitex("d_{TV}( (\\mathbf{X},\\mathbf{Z}), (\\mathbf{U},\\mathbf{Z}) ) = \\sum_{t \\in T} d_{TV}( (\\mathbf{X}|\\mathbf{Z}=t), (\\mathbf{U}|\\mathbf{Z}=t) ) {\\mathbb P}(\\mathbf{Z} = t ).")]]

#text("As ")#mi("{\\mathbf{U}}")#text(" is independent of ")#mi("{\\mathbf{Z}}")#text(", ")#mi("{(\\mathbf{U}|\\mathbf{Z}=t)}")#text(" is uniformly distributed on ")#mi("{R}")#text(". From Lemma ")#link(<tao-a67a41c8bc79d5da917b>)[#text("24")]#text(" we conclude")

#align(center)[#tao-fit-display[#mitex("d_{TV}( (\\mathbf{X}|\\mathbf{Z}=t), (\\mathbf{U}|\\mathbf{Z}=t) ) \\ll \\left( \\mathbb{H}( \\mathbf{U} ) - \\mathbb{H}( \\mathbf{X} | \\mathbf{Z}=t ) \\right)^{1/2}.")]]

#text("Inserting this bound and using the Cauchy-Schwarz inequality, we obtain the claim. ")#mi("\\Box")#linebreak()#text(" Now we are ready to apply the above machinery to give a key inequality that is analogous to Elliott’s inequality. Inequalities of this type first appeared in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3569059")[#text("one of my papers")]#text(", introducing what I called the “entropy decrement argument”; the following arrangement of the inequality and proof is due to Redmond McNamara (personal communication).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 27 (Entropy decrement inequality)")]#text(" ")#metadata(none) <tao-e3274f6bbd018f920e7d>#text(" Let ")#mi("{\\mathbf{n}}")#text(" be a random variable taking values in a finite set of integers, which obeys the approximate stationarity ")#metadata(none) <tao-e7318ac4f200ca4173f8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#mitex("d_{TV}(\\mathbf{n}, \\mathbf{n}+1) \\leq \\delta")]]

#text(" for some ")#mi("{0 < \\delta \\leq \\frac{1}{2}}")#text(". Let ")#mi("{p_1,\\dots,p_m}")#text(" be a collection of distinct primes less than some threshold ")#mi("{P}")#text(", and let ")#mi("{1 = \\ell_0 \\leq \\ell_1 \\leq \\dots \\leq \\ell_m \\leq P}")#text(" be natural numbers that are also bounded by ")#mi("{P}")#text(". Let ")#mi("{f: {\\bf Z} \\rightarrow R}")#text(" be a function taking values in a finite set ")#mi("{R}")#text(". For ")#mi("{i=1,\\dots,m}")#text(", let ")#mi("{\\mathbf{X}_i}")#text(" denote the ")#mi("{R^{\\ell_i}}")#text("-valued random variable ")#metadata(none) <tao-62ae0abd39292b6c91ed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("\\mathbf{X}_i := (f(\\mathbf{n}+1), \\dots, f(\\mathbf{n}+\\ell_i))")]]

#text(" and let ")#mi("{\\mathbf{Y}_i}")#text(" denote the ")#mi("{{\\bf Z}/p_i{\\bf Z}}")#text("-valued random variable")

#align(center)[#tao-fit-display[#mitex("\\mathbf{Y}_i := \\mathbf{n} \\text{ mod } p_i.")]]

#text("Also, let ")#mi("{\\mathbf{U}_i}")#text(" be a random variable drawn uniformly from ")#mi("{{\\bf Z}/p_i{\\bf Z}}")#text(", independently of ")#mi("{\\mathbf{n}}")#text(". Then ")#metadata(none) <tao-3f3609325950ac05f812>

#tao-aligned(keep: true)[


#tao-math("\\sum_{i=1}^m \\frac{d_{TV}( (\\mathbf{X}_i, \\mathbf{Y}_i), (\\mathbf{X}_i, \\mathbf{U}_i) )^2 }{\\ell_i}  & \\ll \\log \\# R", block: true)



#tao-math(" & + \\delta \\exp(O(P)) \\log \\frac{\\# R}{\\delta}.", block: true, numbering: n => [#text("(45)")])
]


]

#text("The ")#mi("{\\exp(O(P))}")#text(" factor (arising from an invocation of the Chinese remainder theorem in the proof) unfortunately restricts the usefulness of this theorem to the regime in which all the primes involved are of “sub-logarithmic size”, but once one is in that regime, the second term on the right-hand side of ")#link(<tao-3f3609325950ac05f812>)[#text("(45)")]#text(" tends to be negligible in practice. Informally, this theorem asserts that for most small primes ")#mi("{p_i \\leq P}")#text(", the random variables ")#mi("{\\mathbf{X}_i}")#text(" and ")#mi("{\\mathbf{Y}_i}")#text(" behave as if they are independent of each other.")

#emph[#text("Proof:")]#text(" We can assume ")#mi("{\\# R \\geq 2}")#text(", as the claim is trivial for ")#mi("{\\# R = 1}")#text(" (the ")#mi("{\\mathbf{X}_i}")#text(" all have zero entropy). For ")#mi("{i=0,\\dots,n}")#text(", we introduce the ")#mi("{\\prod_{j \\leq i} {\\bf Z}/p_i{\\bf Z}}")#text("-valued random variable")

#align(center)[#tao-fit-display[#mitex("\\mathbf{Y}_{\\leq i} := (\\mathbf{Y}_j)_{j \\leq i}.")]]

#text("The idea is to exploit some monotonicity properties of the quantity ")#mi("{\\frac{\\mathbb{H}( \\mathbf{X}_i | \\mathbf{Y}_{\\leq i} )}{\\ell_i}}")#text(", in analogy with ")#link(<tao-7446783c207819c88f43>)[#text("(41)")]#text(". By telescoping series we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{i=1}^n \\frac{\\mathbb{H}( \\mathbf{X}_{i-1} | \\mathbf{Y}_{\\leq i-1} )}{\\ell_{i-1}} - \\frac{\\mathbb{H}( \\mathbf{X}_i | \\mathbf{Y}_{\\leq i} )}{\\ell_i}  & \\leq \\mathbb{H}( \\mathbf{X}_0 )", block: true)



#tao-math(" & \\leq \\log \\# R", block: true)
]

#text("where we extend ")#link(<tao-62ae0abd39292b6c91ed>)[#text("(44)")]#text(" to the ")#mi("{i=0}")#text(" case. From ")#link(<tao-ff3d7d9e4c824480a121>)[#text("(38)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}( \\mathbf{X}_i | \\mathbf{Y}_{\\leq i} ) = \\mathbb{H}( \\mathbf{X}_i | \\mathbf{Y}_{\\leq i-1} ) - \\mathbb{I}( \\mathbf{X}_{i} : \\mathbf{Y}_i | \\mathbf{Y}_{\\leq i-1} )")]]

#text("and thus ")#metadata(none) <tao-8a835296be639b7f9967>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("\\sum_{i=1}^n \\frac{\\mathbb{I}( \\mathbf{X}_{i} : \\mathbf{Y}_i | \\mathbf{Y}_{\\leq i-1} )}{\\ell_i}")]]



#align(center)[#tao-fit-display[#mitex("\\leq \\log \\# R - \\sum_{i=1}^n \\frac{\\mathbb{H}( \\mathbf{X}_{i-1} | \\mathbf{Y}_{\\leq i-1} )}{\\ell_{i-1}} - \\frac{\\mathbb{H}( \\mathbf{X}_i | \\mathbf{Y}_{\\leq i-1} )}{\\ell_i}.")]]

#text("Now we lower bound the summand on the right-hand side. From multiple applications of the conditional chain rule ")#link(<tao-0ab2dd2f64c9fd4e4310>)[#text("(37)")]#text(" we have ")#metadata(none) <tao-e9c7f0b52df4abec57cd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#mitex("\\mathbb{H}( \\mathbf{X}_i | \\mathbf{Y}_{\\leq i-1} ) = \\sum_{k=1}^{\\ell_i} c_{k,i}")]]

#text(" and ")#metadata(none) <tao-2bb54c8330ec17f78492>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#mitex("\\mathbb{H}( \\mathbf{X}_{i-1} | \\mathbf{Y}_{\\leq i-1} ) = \\sum_{k=1}^{\\ell_{i-1}} c_{k,i}")]]

#text(" where")

#align(center)[#tao-fit-display[#mitex("c_{k,i} := \\mathbb{H}( f(\\mathbf{n}+k) | \\mathbf{Y}_{\\leq i-1}, f(\\mathbf{n}+1),\\dots,f(\\mathbf{n}+k-1) ).")]]

#text("We now use the approximate stationarity of ")#mi("{\\mathbf{n}}")#text(" to derive an approximate monotonicity property for ")#mi("{c_{k,i}}")#text(". If ")#mi("{k>1}")#text(", then from ")#link(<tao-bb9af5d1915da1fbc132>)[#text("(39)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("c_{k,i} \\leq \\mathbb{H}( f(\\mathbf{n}+k) | \\mathbf{Y}_{\\leq i-1}, f(\\mathbf{n}+2),\\dots,f(\\mathbf{n}+k-1) ).")]]

#text("Write ")#mi("{\\mathbf{n}^{\\prime} := \\mathbf{n} + 1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("\\mathbf{Y}^{\\prime}_{\\leq i-1} := (\\mathbf{n}^{\\prime} \\text{ mod } p_j)_{j \\leq i-1}.")]]

#text("Note that ")#mi("{\\mathbf{Y}^{\\prime}_{\\leq i-1}}")#text(" is a deterministic function of ")#mi("{\\mathbf{Y}_{\\leq i-1}}")#text(" and vice versa. Thus we can replace ")#mi("{\\mathbf{Y}_{\\leq i-1}}")#text(" by ")#mi("{\\mathbf{Y}^{\\prime}_{\\leq i-1}}")#text(" in the above formula, and conclude that")

#align(center)[#tao-fit-display[#mitex("c_{k,i} \\leq \\mathbb{H}( f(\\mathbf{n}^{\\prime}+k-1) | \\mathbf{Y}^{\\prime}_{\\leq i-1}, f(\\mathbf{n}^{\\prime}+1),\\dots,f(\\mathbf{n}^{\\prime}+k-2) ).")]]

#text("The tuple ")#mi("{(f(\\mathbf{n}^{\\prime}_1),\\dots,f(\\mathbf{n}^{\\prime}+k-1), \\mathbf{Y}^{\\prime}_{\\leq i-1})}")#text(" takes values in a set of cardinality ")#mi("{(O(\\# R))^P}")#text(" thanks to the Chebyshev bounds. Hence by two applications of Lemma ")#link(<tao-499a7fffbbadda60ba31>)[#text("23")]#text(", ")#link(<tao-e7318ac4f200ca4173f8>)[#text("(43)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("c_{k,i} \\leq \\mathbb{H}( f(\\mathbf{n}+k-1) | \\mathbf{Y}_{\\leq i-1}, f(\\mathbf{n}+1),\\dots,f(\\mathbf{n}+k-2) ) + O( \\delta \\log \\frac{1}{\\delta} + \\delta P \\log \\# R ).")]]

#text("The first term on the right-hand side is ")#mi("{c_{k-1,i}}")#text(". Worsening the error term slightly, we conclude that")

#align(center)[#tao-fit-display[#mitex("c_{k,i} \\leq c_{k-1,i} + O( \\delta P^{O(1)} \\log \\frac{\\# R}{\\delta} )")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("c_{k,i} \\leq c_{j,i} + O( \\delta P^{O(1)} \\log \\frac{\\# R}{\\delta} )")]]

#text("for any ")#mi("{1 \\leq j \\leq m}")#text(". In particular")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=\\ell_{i-1}+1}^{\\ell_i} c_{k,i} \\leq \\frac{\\ell_i - \\ell_{i-1}}{\\ell_{i-1}} \\sum_{k=1}^{\\ell_{i-1}} c_{k,i} + O( \\delta P^{O(1)} \\log \\frac{\\# R}{\\delta} )")]]

#text("which by ")#link(<tao-e9c7f0b52df4abec57cd>)[#text("(47)")]#text(", ")#link(<tao-2bb54c8330ec17f78492>)[#text("(48)")]#text(" rearranges to")

#align(center)[#tao-fit-display[#mitex("\\frac{\\mathbb{H}( \\mathbf{X}_i | \\mathbf{Y}_{\\leq i-1} )}{\\ell_i} \\leq \\frac{\\mathbb{H}( \\mathbf{X}_{i-1} | \\mathbf{Y}_{\\leq i-1} )}{\\ell_{i-1}} + O( \\delta P^{O(1)} \\log \\frac{\\# R}{\\delta} ).")]]

#text("From ")#link(<tao-8a835296be639b7f9967>)[#text("(46)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^m \\frac{\\mathbb{I}( \\mathbf{X}_{i} : \\mathbf{Y}_i | \\mathbf{Y}_{\\leq i-1} )}{\\ell_i} \\ll \\log \\# R + \\delta P^{O(1)} \\log \\frac{\\# R}{\\delta}.")]]

#text("Meanwhile, from Corollary ")#link(<tao-b6296fc293b3c39b089f>)[#text("26")]#text(", ")#link(<tao-bb9af5d1915da1fbc132>)[#text("(39)")]#text(", ")#link(<tao-ff3d7d9e4c824480a121>)[#text("(38)")]#text(" we have")

#tao-aligned(keep: true)[


#tao-math("d_{TV}( (\\mathbf{X}_i, \\mathbf{Y}_i), (\\mathbf{X}_i, \\mathbf{U}_i) )^2  & \\ll \\mathbb{H}( \\mathbf{U}_i ) - \\mathbb{H}( \\mathbf{Y}_i | \\mathbf{X}_i )", block: true)



#tao-math(" & \\ll \\mathbb{H}( \\mathbf{U}_i ) - \\mathbb{H}( \\mathbf{Y}_i | \\mathbf{X}_i, \\mathbf{Y}_{\\leq i-1} )", block: true)



#tao-math(" & = \\mathbb{H}( \\mathbf{U}_i ) - \\mathbb{H}( \\mathbf{Y}_i | \\mathbf{Y}_{\\leq i-1} ) + \\mathbb{I}( \\mathbf{X}_{i} : \\mathbf{Y}_i | \\mathbf{Y}_{\\leq i-1} )", block: true)



#tao-math(" & = \\mathbb{H}( \\mathbf{U}_i ) + \\mathbb{H}(\\mathbf{Y}_{\\leq i-1}) - \\mathbb{H}( \\mathbf{Y}_{\\leq i} ) + \\mathbb{I}( \\mathbf{X}_{i} : \\mathbf{Y}_i | \\mathbf{Y}_{\\leq i-1} ).", block: true)
]

#text("The probability distribution of ")#mi("{\\mathbf{Y}_{\\leq i}}")#text(" is a function on ")#mi("{\\prod_{j \\leq i} {\\bf Z}/p_j{\\bf Z}}")#text(", which by the Chinese remainder theorem we can identify with a cyclic group ")#mi("{{\\bf Z}/Q_i{\\bf Z}}")#text(" where ")#mi("{Q_i := \\prod_{j \\leq i} p_j}")#text(". From ")#link(<tao-e7318ac4f200ca4173f8>)[#text("(43)")]#text(" we see that the value of this distribution at adjacent values ")#mi("{n,n+1}")#text(" of this cyclic group varies by ")#mi("{O(\\delta)}")#text(", hence the total variation distance between this random variable and the uniform distribution on ")#mi("{\\prod_{j \\leq i} {\\bf Z}/p_i{\\bf Z}}")#text(" is ")#mi("{O( \\delta Q_i^{O(1)} ) = O( \\delta \\exp(O(P)) )}")#text(" by Chebyshev bounds. By Lemma ")#link(<tao-499a7fffbbadda60ba31>)[#text("23")]#text(" we then have")

#align(center)[#tao-fit-display[#mitex("\\mathbb{H}( \\mathbf{Y}_{\\leq i} ) = \\log Q_i + O( \\delta \\exp(O(P)) \\log \\frac{1}{\\delta} )")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("d_{TV}( (\\mathbf{X}_i, \\mathbf{Y}_i), (\\mathbf{X}_i, \\mathbf{U}_i) )^2 \\leq \\mathbb{I}( \\mathbf{X}_{i} : \\mathbf{Y}_i | \\mathbf{Y}_{\\leq i-1} ) + O(\\delta \\exp(O(P)) \\log \\frac{1}{\\delta} ).")]]

#text("The claim follows. ")#mi("\\Box")#linebreak()#text(" We now compare this result to Elliott’s inequality. If one tries to address precisely the same question that Elliott’s inequality does – namely, to try to compare a sum ")#tao-math("{\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n)}", block: false)#text(" with sampled subsums ")#tao-math("{\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n) p 1_{p|n}}", block: false)#text(" – then the results are quantitatively much weaker:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 28 (Weak Elliott inequality)")]#text(" Let ")#mi("{I \\subset {\\bf R}}")#text(" be an interval of length at least ")#mi("{1}")#text(". Let ")#mi("{f:{\\bf Z} \\rightarrow {\\bf C}}")#text(" be a function with ")#tao-math("{\\left|f(n)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{n}")#text(", and let ")#mi("{0 < \\varepsilon < \\frac{1}{2}}")#text(". Then one has")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n) = \\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n) p 1_{p|n} + O(\\varepsilon)", block: true)]]

#text("for all primes ")#tao-math("{p \\leq \\log \\left|I\\right|}", block: false)#text(" outside of an exceptional set of primes of logarithmic size ")#mi("{O( \\varepsilon^{-2} \\log \\frac{1}{\\varepsilon} )}")#text(".")
]

#text("Comparing this with Exercise ")#link(<tao-e670e2cbf7f657890bf0>)[#text("8")]#text(" we see that we cover a much smaller range of primes ")#mi("{p}")#text("; also the size of the exceptional set is slightly worse. This version of Elliot’s inequality is however still strong enough to recover a proof of the prime number theorem as in the previous section.")

#emph[#text("Proof:")]#text(" We can assume that ")#mi("{\\varepsilon}")#text(" is small, as the claim is trivial for ")#mi("{\\varepsilon}")#text(" comparable to ")#mi("{1}")#text(". We can also assume that ")#metadata(none) <tao-d35c416a85b807e9b538>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#tao-math("\\log\\log\\log \\left|I\\right| \\geq \\varepsilon^{-2} \\log \\frac{1}{\\varepsilon}", block: true)]]

#linebreak()#text(" since the claim is also trivial otherwise (just make all primes up to ")#tao-math("{\\log \\left|I\\right|}", block: false)#text(" exceptional, then use Mertens’ theorem). As a consequence of this, any quantity involving ")#tao-math("{\\left|I\\right|}", block: false)#text(" in the denominator will end up being completely negligible in practice. We can also restrict attention to primes less than (say) ")#tao-math("{\\log^{1/2} \\left|I\\right|}", block: false)#text(", since the remaining primes between ")#tao-math("{\\log \\left|I\\right|}", block: false)#text(" and ")#tao-math("{\\log^{1/2} \\left|I\\right|}", block: false)#text(" have logarithmic size ")#mi("{O(1)}")#text(".")#linebreak()#text(" By rounding the real and imaginary parts of ")#mi("{f}")#text(" to the nearest multiple of ")#mi("{\\varepsilon}")#text(", we may assume that ")#mi("{f}")#text(" takes values in some finite set ")#mi("{R}")#text(" of complex numbers of size ")#mi("{O(1)}")#text(" with cardinality ")#mi("{O(\\varepsilon^{-2})}")#text(". Let ")#mi("{\\mathbf{n}}")#text(" be drawn uniformly at random from ")#mi("{I}")#text(". Then ")#link(<tao-e7318ac4f200ca4173f8>)[#text("(43)")]#text(" holds with ")#tao-math("{\\delta = O(1/\\left|I\\right|)}", block: false)#text(", and from Theorem ")#link(<tao-e3274f6bbd018f920e7d>)[#text("27")]#text(" with ")#mi("{\\ell_i = p_i}")#text(" and ")#tao-math("{P = \\log^{1/2} \\left|I\\right|}", block: false)#text(" (which makes the second term of the right-hand side of ")#link(<tao-3f3609325950ac05f812>)[#text("(45)")]#text(" negligible) we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^m \\frac{d_{TV}( (\\mathbf{X}_i, \\mathbf{Y}_i), (\\mathbf{X}_i, \\mathbf{U}_i) )^2 }{p_i} \\ll \\log \\frac{1}{\\varepsilon}")]]

#text("where ")#mi("{p_1,\\dots,p_m}")#text(" are the primes up to ")#tao-math("{\\log^{1/2} \\left|I\\right|}", block: false)#text(", arranged in increasing order. By Markov’s inequality, we thus have")

#align(center)[#tao-fit-display[#mitex("d_{TV}( (\\mathbf{X}_i, \\mathbf{Y}_i), (\\mathbf{X}_i, \\mathbf{U}_i) ) \\ll \\varepsilon")]]

#text("for ")#mi("{p_i}")#text(" outside of a set of primes of logarithmic size ")#mi("{O( \\varepsilon^{-2} \\log \\frac{1}{\\varepsilon} )}")#text(".")#linebreak()#text(" Let ")#mi("{i}")#text(" be as above. Now let ")#mi("{F_i: R^{p_i} \\times {\\bf Z}/p_i{\\bf Z} \\rightarrow {\\bf C}}")#text(" be the function")

#align(center)[#tao-fit-display[#mitex("F_i( (x_1,\\dots,x_{p_i}), a ) := \\sum_{j=1}^{p_i} x_j 1_{j = -a \\text{ mod } p_i},")]]

#text("that is to say ")#mi("{F_i( (x_1,\\dots,x_{p_i}), a )}")#text(" picks out the unique component ")#mi("{x_j}")#text(" of the tuple ")#mi("{(x_1,\\dots,x_{p_i})}")#text(" in which ")#mi("{j+a}")#text(" is divisible by ")#mi("{p_i}")#text(". This function is bounded by ")#mi("{O(1)}")#text(", and then by ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(42)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\mathbb E} F_i( \\mathbf{X}_i, \\mathbf{Y}_i ) = {\\mathbb E} F_i( \\mathbf{X}_i, \\mathbf{U}_i ) + O(\\varepsilon).")]]

#text("The left-hand side is equal to")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} \\sum_{j=1}^{p_i} f(n+j) 1_{j = -n \\text{ mod } p_i} + O(\\varepsilon)", block: true)]]

#text("which on switching the summations and using the large nature of ")#tao-math("{\\left|I\\right|}", block: false)#text(" can be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n) p_i 1_{p_i|n} + O(\\varepsilon).", block: true)]]

#text("Meanwhile, the left-hand side is equal to")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} \\frac{1}{p_i} \\sum_{j=1}^{p_i} f(n+j) + O(\\varepsilon)", block: true)]]

#text("which again by switching the summations becomes")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n) + O(\\varepsilon).", block: true)]]

#text("The claim follows. ")#mi("\\Box")#linebreak()#text(" In the above argument we applied ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(42)")]#text(" with a very specific choice of function ")#mi("{F_i}")#text(". The power of Theorem ")#link(<tao-e3274f6bbd018f920e7d>)[#text("27")]#text(" lies in the ability to select many other such functions ")#mi("{F_i}")#text(", leading to estimates that do not seem to be obtainable purely from the second moment method. In particular we have the following generalisation of the previous estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 29 (Weak Elliott inequality for multiple correlations)")]#text(" Let ")#mi("{I \\subset {\\bf R}}")#text(" be an interval of length at least ")#mi("{1}")#text(". Let ")#mi("{f:{\\bf Z} \\rightarrow {\\bf C}}")#text(" be a function with ")#tao-math("{\\left|f(n)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{n}")#text(", and let ")#mi("{0 < \\varepsilon < \\frac{1}{2}}")#text(". Let ")#mi("{h_1,\\dots,h_k}")#text(" be integers. Then one has")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n+h_1 p) \\dots f(n+h_k p)", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= \\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n + h_1 p) \\dots f(n+h_k p) p 1_{p|n} + O_{k,h_1,\\dots,h_k}(\\varepsilon)", block: true)]]

#text("for all primes ")#tao-math("{p \\leq \\log \\left|I\\right|}", block: false)#text(" outside of an exceptional set of primes of logarithmic size ")#mi("{O_{k,h_1,\\dots,h_k}( \\varepsilon^{-2} \\log \\frac{1}{\\varepsilon} )}")#text(".")
]

#emph[#text("Proof:")]#text(" We allow all implied constants to depend on ")#mi("{k,h_1,\\dots,h_k}")#text(". As before we can assume that ")#mi("{\\varepsilon}")#text(" is sufficiently small (depending on ")#mi("{k,h_1,\\dots,h_k}")#text("), that ")#mi("{f}")#text(" takes values in a set ")#mi("{R}")#text(" of bounded complex numbers of cardinality ")#mi("{O(\\varepsilon^{-2})}")#text(", and that ")#tao-math("{\\left|I\\right|}", block: false)#text(" is large in the sense of ")#link(<tao-d35c416a85b807e9b538>)[#text("(49)")]#text(", and restrict attention to primes up to ")#tao-math("{P := \\log^{1/2} \\left|I\\right|}", block: false)#text(". By shifting the ")#mi("{h_j}")#text(" and using the large nature of ")#tao-math("{\\left|I\\right|}", block: false)#text(" we can assume that the ")#mi("{h_j}")#text(" are all non-negative, taking values in ")#mi("{\\{0,\\dots,H-1\\}}")#text(" for some ")#mi("{H=O(1)}")#text(". We now apply Theorem ")#link(<tao-e3274f6bbd018f920e7d>)[#text("27")]#text(" with ")#mi("{\\ell_i = H p_i}")#text(" and conclude as before that")

#align(center)[#tao-fit-display[#mitex("d_{TV}( (\\mathbf{X}_i, \\mathbf{Y}_i), (\\mathbf{X}_i, \\mathbf{U}_i) ) \\ll \\varepsilon")]]

#text("for ")#mi("{p_i}")#text(" outside of a set of primes of logarithmic size ")#mi("{O( \\varepsilon^{-2} \\log \\frac{1}{\\varepsilon} )}")#text(".")#linebreak()#text(" Let ")#mi("{i}")#text(" be as above. Let ")#mi("{F_i: R^{Hp_i} \\times {\\bf Z}/p_i{\\bf Z} \\rightarrow {\\bf C}}")#text(" be the function")

#align(center)[#tao-fit-display[#mitex("F_i( (x_1,\\dots,x_{Hp_i}), a ) := \\sum_{j=1}^{p_i} x_{j+h_1 p_i} \\dots x_{j+h_k p_i} 1_{j = -a \\text{ mod } p_i}.")]]

#text("This function is still bounded by ")#mi("{O(1)}")#text(", so by ")#link(<tao-0a3f13c673af2389ecb9>)[#text("(42)")]#text(" as before we have")

#align(center)[#tao-fit-display[#mitex("{\\mathbb E} F_i( \\mathbf{X}_i, \\mathbf{Y}_i ) = {\\mathbb E} F_i( \\mathbf{X}_i, \\mathbf{U}_i ) + O(\\varepsilon).")]]

#text("The left-hand side is equal to")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} \\sum_{j=1}^{p_i} f(n+j+h_1 p_i) \\dots f(n+j+h_k p_i) \\dots 1_{j = -n \\text{ mod } p_i} + O(\\varepsilon)", block: true)]]

#text("which on switching the summations and using the large nature of ")#tao-math("{\\left|I\\right|}", block: false)#text(" can be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n+h_1 p_i) \\dots f(n+h_k p_i) p_i 1_{p_i|n} + O(\\varepsilon).", block: true)]]

#text("Meanwhile, the right-hand side is equal to")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} \\frac{1}{p_i} \\sum_{j=1}^{p_i} f(n+j+h_1 p_i) \\dots f(n+j+h_k p_i) + O(\\varepsilon)", block: true)]]

#text("which again by switching the summations becomes")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} f(n+h_1 p_i) \\dots f(n+h_k p_i) + O(\\varepsilon).", block: true)]]

#text("The claim follows. ")#mi("\\Box")#linebreak()#text(" There is a logarithmically averaged version of the above proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Weak Elliott inequality for logarithmically averaged multiple correlations)")]#text(" Let ")#mi("{2 \\leq y \\leq x}")#text(" with ")#mi("{x/y \\geq 2}")#text(", let ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be a function bounded in magnitude by ")#mi("{1}")#text(", let ")#mi("{0 < \\varepsilon < \\frac{1}{2}}")#text(", and let ")#mi("{h_1,\\dots,h_k}")#text(" be integers. Show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log x/y} \\sum_{y \\leq n \\leq x} \\frac{f(n+h_1 p) \\dots f(n+h_k p)}{n}")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{1}{\\log x/y} \\sum_{y \\leq n \\leq x} \\frac{f(n + h_1 p) \\dots f(n+h_k p) p 1_{p|n}}{n} + O_{k,h_1,\\dots,h_k}(\\varepsilon)")]]

#text("for all primes ")#mi("{p \\leq \\log y}")#text(" outside of an exceptional set of primes of logarithmic size ")#mi("{O_{k,h_1,\\dots,h_k}( \\varepsilon^{-2} \\log \\frac{1}{\\varepsilon} )}")#text(".")
]

#text("When one specialises to multiplicative functions, this lets us dilate shifts in multiple correlations by primes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Let ")#mi("{2 \\leq N \\leq y \\leq x}")#text(" with ")#mi("{x/y \\geq N}")#text(", let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a multiplicative function bounded in magnitude by ")#mi("{1}")#text(", let ")#mi("{0 < \\varepsilon < \\frac{1}{2}}")#text(", and let ")#mi("{h_1,\\dots,h_k}")#text(" be nonnegative integers. Show that")

#align(center)[#tao-fit-display[#mitex("f(p)^k \\frac{1}{\\log x/y} \\sum_{y \\leq n \\leq x} \\frac{f(n+h_1) \\dots f(n+h_k)}{n}")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{1}{\\log x/y} \\sum_{y \\leq n \\leq x} \\frac{f(n + h_1 p) \\dots f(n+h_k p)}{n} + O_{k,h_1,\\dots,h_k}(\\varepsilon)")]]

#text("for all primes ")#mi("{p \\leq \\log N}")#text(" outside of an exceptional set of primes of logarithmic size ")#mi("{O_{k,h_1,\\dots,h_k}( \\varepsilon^{-2} \\log \\frac{1}{\\varepsilon} )}")#text(".")
]

#text("For instance, setting ")#mi("{f}")#text(" to be the Möbius function, ")#mi("{h_1=0}")#text(", ")#mi("{h_2=0}")#text(", and ")#mi("{y = \\log x}")#text(" (say), we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{\\mu(n) \\mu(n+1)}{n} = \\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{\\mu(n) \\mu(n+p)}{n} + O(\\varepsilon)")]]

#text("for all primes ")#mi("{p \\leq \\log\\log x}")#text(" outside of an exceptional set of primes of logarithmic size ")#mi("{\\varepsilon^{-2} \\log \\frac{1}{\\varepsilon}}")#text(". In particular, for ")#mi("{x}")#text(" large enough, one can obtain bounds of the form")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{\\mu(n) \\mu(n+1)}{n} =\\frac{1}{(\\# {\\mathcal P}) \\log x} \\sum_{n \\leq x} \\sum_{p \\in {\\mathcal P}} \\frac{\\mu(n) \\mu(n+p)}{n} + O(\\varepsilon)")]]

#text("for various moderately large sets of primes ")#mi("{p}")#text(". It turns out that these double sums on the right-hand side can be estimated by methods which we will cover in later series of notes. Among other things, this allows us to establish estimates such as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{\\mu(n) \\mu(n+1)}{n} = o(1)")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(", which to date have only been established using these entropy methods (in conjunction with the methods discussed in later notes). This is progress towards an open problem in analytic number theory known as ")#emph[#text("Chowla’s conjecture")]#text(", which we will also discuss in later notes.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-528577")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("Some minor typos:")#linebreak()#text(" 1. (8) has a Y where you mean bolded Y.")#linebreak()#text(" 2. There’s something funny happening with your links/equation references right before (22), where you cite the Brun-Titchmarsh inequality.")#linebreak()#text(" 3. I think the equation references in Lemma 6 are probably supposed to be (13) not (14).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-528685")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("It seems that the proof of lemma 2 does not require ")#mi("\\mathcal P")#text(" to be a collection of primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-528701")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("Yes, pairwise coprime would suffice in this case. (Similarly for some other results in this post.) I know some people have experimented with trying to work with other sets of divisors here than primes, though as far as I am aware in most applications of these sorts of techniques the best set of divisors to use are primes.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9d0afd7e80741d26c154be7fedf447a7cfac032e95209918c45d1ef5845352d-a7b7c0c3acee4e3027e89a8cb40753685810505c56a7ce9fbe7830ff1f3be127.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Entropy eigenvectors")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-528713")[#strong[#text("Entropy eigenvectors")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("Hi Terry,")

#text("Is the entropy method useful in isolating the plausibility of the eigenvalue/vector formulae that you and co-authors recently discovered (mentioned in Quanta today) without explicitly using those formulae? Something like: the entropy of the eigenvalues of a matrix A, conditioned on the eigenvalues of the minors, equals the entropy of the eigenvectors of A?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-528719")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("There’s a missing ")#mi("\\mathbb{P}")#text(" in the middle term of the equation before equation (41).")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of roland5999")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-528740")[#strong[#text("roland5999")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2019")])]

#text(".. another funny behavior happens just before (19), where the Latex source code shows instead of the intended neatly-formatted expression…")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54753265e0dc5601fee8273cee5ab7d5af0fe176dd7fb42d3359062efc6dd218-440557b13b4e63e05b5db711103f690c05279f4a8457f1edabe51f1b7ce56469.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kirill M")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-528790")[#strong[#text("Kirill M")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2019")])]

#text("I guess a verb after “may” is omitted in “With probabilistic intuition, one may the random variables”. Most likely, it is “assume” or alike.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c91d989d21bb0cd35f74c0133b2cb1e05143b679c0673020cfc45c46b75d37cd-8ec26e64e4442e05f376cf43ff5b10b8876845db0af1d4d5375aff2aa5268b20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of entropy")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-529180")[#strong[#text("entropy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2019")])]

#text("Sorry for the possibly dumb question but I do not understand the submodularity inequality (vi). Let us suppose that ")#mi("\\mathbf{X}")#text(" and ")#mi("\\mathbf{Y}")#text(" are independent, and the function ")#mi("h")#text(" is injective, so that ")#mi("\\mathbb{H}(\\mathbf{W})=\\mathbb{H}(\\mathbf{XY})=\\mathbb{H}(\\mathbf{X})+\\mathbb{H}(\\mathbf{Y})")#text(". Then, the submodularity inequality would imply ")#mi("\\mathbb{H}(\\mathbf{Z})=0")#text(", always. I am missing something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-529228")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2019")])]

#text("Yes, that is correct. If ")#mi("{\\bf Z}")#text(" is a function of a random variable ")#mi("{\\bf X}")#text(", and is also a function of an independent random variable ")#mi("{\\bf Y}")#text(", then it is deterministic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c91d989d21bb0cd35f74c0133b2cb1e05143b679c0673020cfc45c46b75d37cd-8ec26e64e4442e05f376cf43ff5b10b8876845db0af1d4d5375aff2aa5268b20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of entropy")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-529274")[#strong[#text("entropy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("Thank you for your kind answer. However, please consider the following example. Let ")#mi("\\boldsymbol{X}")#text(" and ")#mi("\\boldsymbol{Y}")#text(" be two independent random variables. The random variable ")#mi("\\boldsymbol{X}")#text(" assumes values in ")#mi("\\{1,2,3\\}")#text(" equiprobably, and let ")#mi("f")#text(" be such that ")#mi("f(1)=f(2)=1")#text(", while ")#mi("f(3)=3")#text(". Then ")#mi("\\boldsymbol{Z}=f(\\boldsymbol{X})")#text(" assumes value ")#mi("1")#text(" with probability ")#mi("2/3")#text(" and value ")#mi("3")#text(" with probability ")#mi("1/3")#text(". Now, let ")#mi("\\boldsymbol{Y}")#text(" assume value ")#mi("1")#text(" with probability ")#mi("2/3")#text(" and value ")#mi("3")#text(" with probability ")#mi("1/3")#text(". Clearly, ")#mi("\\boldsymbol{Z}=g(\\boldsymbol{Y})")#text(", where ")#mi("g")#text(" is a 1-1 function. Therefore, ")#mi("\\boldsymbol{Z}")#text(" is a function of two independent random variables, but it is not deterministic. I am missing some additional hypothesis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-529317")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("It is true that ")#mi("\\mathbf{Z}")#text(" and ")#mi("\\mathbf{Y}")#text(" both assume the value ")#mi("1")#text(" with probability 2/3 and ")#mi("3")#text(" with probability 1/3, but this does not imply that ")#mi("\\mathbf{Z}=g(\\mathbf{Y})")#text(", because the events ")#mi("\\mathbf{Z}=1")#text(" and ")#mi("\\mathbf{Y}=1")#text(" are not the same event (even though they occur with the same probability). What is true (assuming some additional regularity hypotheses on the underlying sample space ")#mi("\\Omega")#text(") is that there is a probability preserving transformation ")#mi("T: \\Omega \\to \\Omega")#text(" such that ")#mi("\\mathbf{Z}(\\omega) = \\mathbf{Y}(T(\\omega))")#text(" for almost all ")#mi("\\omega \\in \\Omega")#text(" in the sample space, but this is a different claim.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c91d989d21bb0cd35f74c0133b2cb1e05143b679c0673020cfc45c46b75d37cd-8ec26e64e4442e05f376cf43ff5b10b8876845db0af1d4d5375aff2aa5268b20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of entropy")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-529323")[#strong[#text("entropy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("OK, got it!. Thanks a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca7feb145282a4628d76ef934e527eaebec2ae3273e677fbc873b4a08dd56a07-315eaebbf6a0b5dd4901277a09803795d516e8eb8b7c58d1a932a449c8a8a7b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MarcNg")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-529524")[#strong[#text("MarcNg")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2019")])]

#text("In Lemma 24 , we have the claim “…From this and Taylor expansion with remainder we have the inequality” but instead appears an equality there.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dfa05e241f7bd891e270b884377583940d9b5b2a55ba9f1bdf4433ed3485904-f6e8802a308958ad8704de5521f6985b31cca1856e75b1921825b58c75bd4ca6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of n_tropy")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-529552")[#strong[#text("n_tropy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2019")])]

#text("Great post, thanks. Possible typo: the direction of the inequalities just before (41) should be reversed. From h_{n+1} – h_n \\leq h_n – h_{n-1} it would follow that h_{n+1} – h_n \\leq h_i – h_{i-1} for i = 1..n.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd36312b310101cd467c6cb0892d776771e7f5895289528a53762ca0d9600acb-9497b6b13651e06c430d9e2a76ba0e271f77d2cf139bb2b0e2bc8e6857e1abfd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-530710")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2019")])]

#text("Dear professor Tao,")

#text("Erring on youtube I got into a 2015 presentation you did at ipam UCLA on this topic (you were using the prisoner + snake/cliff metaphor that time), which got me really excited because it relates to an initial problem that I worked on in material sciences in the past. Take a random material (maybe it’s a biphasic material or something more complicated), you want to compute its averaged (homogenised) properties, which is something we know how to do very well – only it requires tremendous computational power.")#linebreak()#text(" So the idea was, instead of exploring all the probability space, to get one carefully chosen configuration on which to do the complicated thing. So we did a “sudoku like” thing alike the one you were talking about in that presentation (with a bit of variation, because the aim was slightly different: the goal was to have that configuration work out all moments… well it’s related but not the same I think?). But I could never understand that problem as the size went larger, why it was complicated or even if it were complicated in the first place.")

#text("So, that presentation was super interesting, now I know the initial problem (from which we of course strayed rather quickly because applied maths :) We kept working with {+1, -1} though. The focus was on the PDEs part of it.) was complicated, and I have some ideas why, and congratulations on the proof of it.")#linebreak()#text(" And I hope that made you smile to see that this work could have a ramification in the (mostly) unrelated field of material sciences.")

#text("[On a side note, I’m always super happy to read your blog posts (the articles that are close enough to my specialties for me to get something out of them), they shine a light on the little hole into which life and depression have buried me, a place sadly away from maths. Maybe you get that positive feedback all the time, but I’ve been meaning to write this down for a long time.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-532956")[#strong[#text("254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("[…] for instance, in order to combine this type of result with the entropy decrement methods from Notes 9, it is essential that be allowed to grow more slowly than . See also this survey of Soundararajan […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ab2d418ad9cd093e5f159f586f2483d7f34a755eb9a1ba3c77fc3bf979ea85d-001e0ecc9ad43219f621a6575604d9bef6b541d370726fec63fb2efe777a41d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-552746")[#strong[#text("Alexander")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")])]

#text("In the proof Proposition 18 in the first sum probably schould be ..p\\le e^{\\epsilon^{-1}+k_0\\epsilon}. On the other hand is not clear the sentence")

#text("contradicts Mertens’ theorem if {\\varepsilon} is large enough because the left-hand …")

#text("We need \\epsilon \\to 0 ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ab2d418ad9cd093e5f159f586f2483d7f34a755eb9a1ba3c77fc3bf979ea85d-001e0ecc9ad43219f621a6575604d9bef6b541d370726fec63fb2efe777a41d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-552795")[#strong[#text("Alexander")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")])]

#text("Once again some question related proof of Proposition 18.")#linebreak()#text(" By Mertens Theorem we have")

#mi("\\displaystyle S:= \\sum_{e^{\\epsilon k_0}\\le p\\le e^{\\epsilon^{-1}+k_0\\epsilon}} \\frac{1}{p} =\\log(1+(\\epsilon^2k_0)^{-1})+O((k_0\\epsilon)^{-1})")

#text("From this not follows the contradiction with inequality")

#mi("S  \\le 1/(\\epsilon k_0)")#text(". I am right ?")

#text("P.S. In (27) instead p_1 should be p.")

#emph[#text("[Yes, that is correct. The typo is now corrected, thanks -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ab2d418ad9cd093e5f159f586f2483d7f34a755eb9a1ba3c77fc3bf979ea85d-001e0ecc9ad43219f621a6575604d9bef6b541d370726fec63fb2efe777a41d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AlexanderIn")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-556423")[#strong[#text("AlexanderIn")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("Probably In Exercise 17 instead \\log^2 x should be \\log^2 p, and in (26) instead \\frac{e^{\\epsilon k}}{k} should be \\frac{1}{k}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A announcement: Analytic prime number theory | What's new")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-595077")[#strong[#text("254A announcement: Analytic prime number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("[…] The entropy decrement argument […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/403e136d156247c2ea54c6c1169740dc9d8687f69c65c9ac03b8b09382590cfd-91359cb468f4de4f64e9be4a978c2df0cc200bd51d9b8a9dd9bd433d30335bc4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WB")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-604147")[#strong[#text("WB")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2020")])]

#text("In exercise 19, it should be “use the {\\it concavity} of $t \\to t\\log\\left(\\frac{1}{t}\\right)$”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-639583")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2022")])]

#text("In the equation immediately before Exercise 3, there should be an ")#mi("\\omega(n)")#text(" instead of an ")#mi("\\omega(x)")#text(".")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-639639")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2022")])]

#text("In the proof of Lemma 6, you say “[…] normalised by the left-hand side of (14)”. I believe it should be equation (13).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-639653")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2022")])]

#text("In the proof of Proposition 11, in the sentence, “[i]f we furthermore restrict to primes ")#mi("p")#text(" larger than ")#mi("\\varepsilon")#text(", then the contribution of those ")#mi("n")#text(" that are divisible by ")#mi("p")#text(" is also ")#mi("O(\\varepsilon)")#text("“, should it be ")#mi("p")#text(" larger than ")#mi("\\varepsilon^{-1}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-639884")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("In the proof of Lemma 14, you state that “… for all ")#mi("p \\leq x")#text(" outside of an exceptional set of primes of logarithmic size ")#mi("O(\\varepsilon^2)")#text(".” I believe that this should be ")#mi("O(\\varepsilon^{-2})")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-639904")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("Sorry if I’m missing something obvious, but in the proof of Proposition 16, the integral in the equation immediately below the statement, “We rescale (20) by ")#mi("p_1")#text(" to conclude that…” has the bounds ")#mi("[\\log x / p_1, x/p_1]")#text(", when it seems like it should be ")#mi("[p_1\\log x, p_1 x]")#text(".")

#text("Also, in that same proof, you say that “since ")#mi("p = (1+O(\\varepsilon)) p_1 p_2")#text(", we have ")#mi("\\frac{M(t/p_1p_2)}{t/p_1p_2} = \\frac{M(t/p)}{t/p}")#text("“. I want to say that there should be a ")#mi("+ O(\\varepsilon)")#text(" there.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-640185")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2022")])]

#text("In the first equation in the proof of Proposition 18, the upper bound on your sum is ")#mi("e^{\\varepsilon^{-1} e^{\\varepsilon k_0}}")#text(", when I think you mean ")#mi("e^{\\varepsilon^{-1} }e^{\\varepsilon k_0}")#text(". Also, immediately following this, you say that this “contradicts Mertens’ theorem if ")#mi("\\varepsilon")#text(" is large enough”. Do you mean small enough?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-640188")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2022")])]

#text("I think he meant if ")#mi("\\epsilon")#text(" is large enough.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-640248")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2022")])]

#text("The right-hand side of the main equation in Exercise 31 seems to be cut off.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-640252")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("Also, out of curiosity, what notes are you referring to when you mention a “later series of notes” at the very end of this blog post? For instance, in the sentence “It turns out that these double sums on the right-hand side can be estimated by methods which we will cover in later series of notes.”")

#text("[")#emph[#text("[See ")#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/")[#text("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/")]#text(" -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-640284")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("Thank you!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0071c5503c4fb88b4c53152b9ea1a78a0826281448827e2a6f15161b620a1bfc-f421b3ac8b1e2310c90ba85e4cd3e6b890c69b102b7dedfbcfa6f8574466c7ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Leng")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-641888")[#strong[#text("James Leng")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2022")])]

#text("Perhaps this is a naive question, but could iterating this entropy decrement argument lead to a regularity lemma like its “cousin” the energy decrement argument does?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rory McClenagan")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-643225")[#strong[#text("Rory McClenagan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("In Exercise 30, I think you might should be dividing the denominator of the summands by ")#mi("n")#text(". Also, in the proofs of Propositions 28 and 29, you say “[m]eanwhile, the left-hand side is equal to”, and I think it should be “[m]eanwhile, the right-hand side is equal to”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-685700")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2024")])]

#text("In the proof of the entropy decrement inequality should all three instances of ")#mi("I(X_{i-1},Y_i | Y_{\\le i-1})")#text(" instead be ")#mi("I(X_{i},Y_i | Y_{\\le i-1})")#text("? It seems as is the middle equality in the four line display (and possibly earlier inequality) are incorrect.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-692250")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2026")])]

#text("Dear Dr. Tao,")

#text("It seems that “vairable” should be “variable”, and “Kullback-Liebler” should be “Kullback-Leibler”.")

#text("And for the Chebyshev’s inequality part, after (7), some random variables X should be boldfaced.")

#text("I also have a question on the proof of Chebyshev’s inequality: you take the expections of a inequality, which is 1_{|X-EX|≥λ} ≤ |X-EX|^2 /λ^2. Perhaps you find it trivial, but I am not familiar with probability theory, I don’t know why the indicator 1 show up here. I would like to ask that is this a trick that happens to work or a proof technique that can be generalised?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/#comment-692268")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2026")])]

#text("Thanks for the corrections!")

#text("I asked an AI to generate an image to illustrate this inequality, which ")#link("https://gemini.google.com/share/8678265e64ff")[#text("you can find here")]#text(". The technique is part of a more general technique known as the ")#link("https://en.wikipedia.org/wiki/Method_of_moments_(probability_theory)")[#text("moment method")]#text("; it is discussed for instance in the text of Alon and Spencer on the probabilistic method, or in the first chapter of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(".")
]
]
