// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/07/15/classification-of-almost-quarter-pinched-manifolds/
// Converted to Typst by tao2typ: "2026-10-14T16:35:22.501156+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Classification of Almost Quarter-Pinched Manifolds", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Classification of Almost Quarter-Pinched Manifolds")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 July 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/07/15/classification-of-almost-quarter-pinched-manifolds/")[#text("https://terrytao.wordpress.com/2008/07/15/classification-of-almost-quarter-pinched-manifolds/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.math.ucla.edu/~petersen/")[#text("Peter Petersen")]#text(" and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper, “")#link("http://arxiv.org/abs/0807.1900")[#text("Classification of Almost Quarter-Pinched Manifolds")]#text("“, submitted to ")#link("http://www.ams.org/proc/")[#text("Proc. Amer. Math. Soc.")]#text(". This is perhaps the shortest paper (3 pages) I have ever been involved in, because we were fortunate enough that we could simply cite (as a black box) a reference for every single fact that we needed here.")

#text("The paper is related to the famous ")#link("http://en.wikipedia.org/wiki/Sphere_theorem")[#text("sphere theorem")]#text(" from Riemannian geometry. This theorem asserts that any n-dimensional complete simply connected Riemannian manifold which was ")#emph[#text("strictly quarter-pinched")]#text(" (i.e. the ")#link("http://en.wikipedia.org/wiki/Sectional_curvature")[#text("sectional curvatures")]#text(" all in the interval ")#mi("(K/4,K]")#text(" for some ")#mi("K > 0")#text(") must necessarily be homeomorphic to the n-sphere ")#mi("S^n")#text(". (In dimensions 3 or less, this already follows from simple connectedness thanks to the Poincaré conjecture (and ")#link("http://en.wikipedia.org/wiki/Myers_theorem")[#text("Myers theorem")]#text("), so the theorem is really only interesting in higher dimensions. One can easily drop the simple connectedness hypothesis by passing to a universal cover, but then one has to admit sphere quotients ")#mi("S^n/\\Gamma")#text(" as well as spheres.)")

#text("Due to the existence of ")#link("http://en.wikipedia.org/wiki/Exotic_sphere")[#text("exotic spheres")]#text(" in higher dimensions, being homeomorphic to a sphere does not necessarily imply being diffeomorphic to a sphere. (For instance, an example of an exotic sphere with positive sectional curvature (but not quarter-pinched) was recently constructed ")#link("http://arxiv.org/abs/0805.0812")[#text("by Petersen and Wilhelm")]#text(".) Nevertheless, ")#link("http://arxiv.org/abs/0705.0766")[#text("Brendle and Schoen recently proved")]#text(" the diffeomorphic version of the sphere theorem: every strictly quarter-pinched complete simply connected Riemannian manifold is diffeomorphic to a sphere. The proof is based on ")#link("http://en.wikipedia.org/wiki/Ricci_flow")[#text("Ricci flow")]#text(", and involves three main steps:")

#enum(start: 1, 
[#text("A verification that if M is quarter-pinched, then the manifold ")#mi("M \\times {\\Bbb R}^2")#text(" has non-negative isotropic curvature. (The same statement is true without adding the two additional flat dimensions, but these additional dimensions are very convenient for simplifying the analysis by allowing certain two-planes to wander freely in the product tangent space.)")],
[#text("A verification that the property of having non-negative isotropic curvature is preserved by Ricci flow. (By contrast, the quarter-pinched property is ")#emph[#text("not ")]#text("preserved by Ricci flow.)")],
[#text("The pinching theory of ")#link("http://arxiv.org/abs/math/0606187")[#text("Böhm and Wilking")]#text(", which is a refinement of the work of Hamilton (who handled the three and four-dimensional cases).")]
)

#text("Brendle and Schoen in fact proved a slightly stronger statement in which the curvature bound K is allowed to vary with position x, but we will not discuss this strengthening here.")

#text("The quarter-pinching is sharp; the ")#link("http://en.wikipedia.org/wiki/Fubini-Study_metric")[#text("Fubini-Study metric")]#text(" on ")#link("http://en.wikipedia.org/wiki/Complex_projective_space")[#text("complex projective spaces")]#text(" ")#mi("{\\Bbb CP}^n")#text(" is non-strictly quarter-pinched (the sectional curvatures lie in ")#mi("{}[K/4,K]")#text(" but is not homeomorphic to a sphere). Nevertheless, by refining the above methods, an endpoint result was established ")#link("http://arxiv.org/abs/0705.3963")[#text("by Brendle and Schoen")]#text(" (see also a later refinement ")#link("http://arxiv.org/abs/0707.3894")[#text("by Seshadri")]#text("): any complete simply-connected manifold which is non-strictly quarter-pinched is diffeomorphic to either a sphere or a compact ")#link("http://en.wikipedia.org/wiki/Rank_of_a_Lie_group")[#text("rank")]#text(" one ")#link("http://en.wikipedia.org/wiki/Riemannian_symmetric_space")[#text("symmetric space")]#text(" (or CROSS, for short) such as complex projective space. (In the latter case one also has some further control on the metric, which we will not detail here.) The homeomorphic version of this statement was established earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=140054")[#text("by Berger")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=157321")[#text("by Klingenberg")]#text(".")

#text("Our result pushes this further by an epsilon. More precisely, we show for each dimension n that there exists ")#mi("\\varepsilon > 0")#text(" such that any ")#mi("\\frac{1}{4}-\\varepsilon_n")#text("-pinched complete simply connected manifold (i.e. the curvatures lie in ")#mi("{}[K (\\frac{1}{4}-\\varepsilon_n), K]")#text(") is diffeomorphic to either a sphere or a CROSS. (The homeomorphic version of this statement was established earlier in even dimensions by ")#link("http://www.ams.org/mathscinet-getitem?mr=699491")[#text("Berger")]#text(".) We do not know if ")#mi("\\varepsilon_n")#text(" can be made independent of n.")

#metadata(none) <tao-b1e91a1ef2f87d1aa366>

#text("Our initial strategy was to use a compactness argument: assume our theorem failed, then there would be a sequence of asymptotically (non-strictly) quarter-pinched manifolds which were not diffeomorphic to a sphere or CROSS. Taking a “limit”, we would obtain a limit manifold which was non-strictly quarter-pinched, and hopefully by applying the Brendle-Schoen results we would obtain the contradiction.")

#text("Establishing the existence of a limit turned out to be easy enough, thanks to existing literature: a ")#link("http://www.ams.org/mathscinet-getitem?mr=1305984")[#text("result of Abresch and Meyer")]#text(" established a lower bound for the injectivity radius of pinched manifolds (in the much easier even-dimensional case, this is a classical result of Klingenberg), while ")#link("http://en.wikipedia.org/wiki/Myers_theorem")[#text("Myers’ theorem")]#text(" also upper bounds the diameter, and so the manifolds cannot collapse and we can extract a limit from a subsequence. Unfortunately, the problem is that the limit manifold is not smooth; the metric is only ")#mi("C^{1,\\alpha}")#text(" in regularity, and the curvature is only ")#emph[#text("a priori")]#text(" in ")#mi("L^p")#text(" (although the pinching strongly suggests that the curvature should in fact be bounded, this cannot be justified immediately due to the lack of regularity). We then attempted to regularise the metric by Ricci flow, but this presented some analytic difficulties (we needed a low regularity local existence theorem for this flow) as well as geometric difficulties (the quarter-pinching was not preserved by the flow).")

#text("Fortunately, we found a way to evade this problem, by applying Ricci flow ")#emph[#text("before ")]#text("taking limits. The original sequence of asymptotically quarter-pinched manifolds is smooth, and there is no difficulty using standard Ricci flow local existence theory to flow each of these manifolds by a fixed small amount of time. They won’t remain almost quarter-pinched, but some pinching will still remain (here we were able to just cite a ")#link("http://www.ams.org/mathscinet-getitem?mr=1381991")[#text("paper of Rong")]#text(" that contained a proof of this fact). Also, by using a stability version of the Hamilton maximum principle (which was already observed in ")#link("http://www.ams.org/mathscinet-getitem?mr=862046")[#text("Hamilton’s original paper")]#text("; see also ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text(" from my class) that showed that as these almost quarter-pinched manifolds initially had almost non-negative isotropic curvature (after multiplying with ")#mi("{\\Bbb R}^2")#text("), they would continue to do so after performing Ricci flow for a short time. Once one performs Ricci flow, the smoothing effects of that flow allow one to take a limit in ")#mi("C^\\infty")#text(" (this is the ")#link("http://www.ams.org/mathscinet-getitem?mr=1375255")[#text("Hamilton compactness theorem")]#text(", see ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(" from my class) and extract a smooth limit manifold of non-negative isotropic curvature (after multiplying with ")#mi("{\\Bbb R}^2")#text("). Applying the classification results of Brendle and Schoen one obtains the result.")

#text("To summarise, perhaps the one noteworthy observation made in this very short paper is that it seems to be better to apply Ricci flow before taking limits, rather than the other way around.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/15/classification-of-almost-quarter-pinched-manifolds/#comment-31133")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2008")])]

#text("The paper on the positive sectional curvature on the exotic sphere is done by Petersen and Wilhelm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raymond")]], [#link("https://terrytao.wordpress.com/2008/07/15/classification-of-almost-quarter-pinched-manifolds/#comment-31136")[#strong[#text("Raymond")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2008")])]

#text("Where can I find a description of what a CROSS is?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/15/classification-of-almost-quarter-pinched-manifolds/#comment-31161")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Dear Anonymous: thanks for the correction!")

#text("Dear Raymond, CROSS is the acronym for “compact rank one symmetric space”. I believe the only such (simply connected) spaces are the sphere, complex projective space, quaternionic projective space, and the Cayley plane.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/07/15/classification-of-almost-quarter-pinched-manifolds/#comment-31183")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("Raymond,")

#text("See the book by Besse called something like Manifolds all of whose geodesics are closed.")
]
