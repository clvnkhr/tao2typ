// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/03/12/analysis-and-applications-the-mathematical-work-of-elias-stein/
// Converted to Typst by tao2typ: "2026-10-14T15:20:26.277176+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Analysis and applications: The mathematical work of Elias Stein", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Analysis and applications: The mathematical work of Elias Stein")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 March 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/03/12/analysis-and-applications-the-mathematical-work-of-elias-stein/")[#text("https://terrytao.wordpress.com/2020/03/12/analysis-and-applications-the-mathematical-work-of-elias-stein/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short note that the memorial article “")#link("https://www.ams.org/journals/bull/0000-000-00/S0273-0979-2020-01691-5/S0273-0979-2020-01691-5.pdf")[#text("Analysis and applications: The mathematical work of Elias Stein")]#text("” has just been published in the ")#link("https://www.ams.org/journals/bull/0000-000-00/S0273-0979-2020-01691-5/")[#text("Bulletin of the American Mathematical Society")]#text(". This article was a collective effort led by ")#link("https://en.wikipedia.org/wiki/Charles_Fefferman")[#text("Charlie Fefferman")]#text(", ")#link("https://web.math.princeton.edu/~aionescu/")[#text("Alex Ionescu")]#text(", Steve Wainger and myself to describe the various mathematical contributions of ")#link("https://en.wikipedia.org/wiki/Elias_M._Stein")[#text("Elias Stein")]#text(", who passed away in December 2018; it also features contributions from ")#link("https://llanzani.expressions.syr.edu/")[#text("Loredana Lanzani")]#text(", ")#link("http://math.uga.edu/~magyar/")[#text("Akos Magyar")]#text(", ")#link("https://sites.math.rutgers.edu/~mm2809/")[#text("Mariusz Mirek")]#text(", ")#link("https://www.math.wisc.edu/~nagel/")[#text("Alexander Nagel")]#text(", ")#link("https://en.wikipedia.org/wiki/Duong_Hong_Phong")[#text("Duong Phong")]#text(", ")#link("https://en.wikipedia.org/wiki/Lillian_Pierce")[#text("Lillian Pierce")]#text(", ")#link("http://homepage.sns.it/fricci/")[#text("Fulvio Ricci")]#text(", ")#link("https://en.wikipedia.org/wiki/Christopher_D._Sogge")[#text("Christopher Sogge")]#text(", and ")#link("https://www.math.wisc.edu/~street/")[#text("Brian Street")]#text(". (My contribution was mostly focused on Stein’s contribution to restriction theory.)")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d0c9b6e3d598fc6819a9be70726912eb2945d73e74e961443995e631e7c3e4-e5a143bae28f525b55b430b325d4eaeb879ffbbbaf6aa4f7025a0bb4879843c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joerg Grande")]], [#link("https://terrytao.wordpress.com/2020/03/12/analysis-and-applications-the-mathematical-work-of-elias-stein/#comment-545299")[#strong[#text("Joerg Grande")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2020")])]

#text("Thank you for sharing this memorial article. I find it very well written.")#linebreak()#text(" Is there a small typo in the definition of the Hilbert transform on page 2 (x instead of y under the integral)?")
]
