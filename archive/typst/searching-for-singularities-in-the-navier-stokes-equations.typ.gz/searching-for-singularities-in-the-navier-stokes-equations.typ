// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/
// Converted to Typst by tao2typ: "2026-10-14T15:20:17.635959+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Searching for singularities in the Navier–Stokes equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Searching for singularities in the Navier–Stokes equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 May 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/")[#text("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I was recently asked to contribute a short comment to ")#link("https://www.nature.com/natrevphys/")[#text("Nature Reviews Physics")]#text(", as part of a series of articles on fluid dynamics on the occasion of the 200th anniversary (this August) of the birthday of ")#link("https://en.wikipedia.org/wiki/Sir_George_Stokes,_1st_Baronet")[#text("George Stokes")]#text(". My contribution is now online as “")#link("https://www.nature.com/articles/s42254-019-0068-9")[#text("Searching for singularities in the Navier–Stokes equations")]#text("“, where I discuss the global regularity problem for Navier-Stokes and my thoughts on how one could try to construct a solution that blows up in finite time via an approximately discretely self-similar “fluid computer”. (The rest of the series does not currently seem to be available online, but I expect they will become so shortly.)")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2019")])]

#text("It seems that since it is not yet known if a “special initial data” (which leads to a finite time blowup) exists, at least one may try to find necessary properties that such “special initial data” must satisfy, and perhaps even upper bound on the probability of choosing randomly such special initial data (assuming the initial data to be randomly chosen according to some probabilistic rule)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516970")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("Is it possible that such “special initial data” (leading to a finite time blowup) exists but can’t be described by finitely many parameters (or even can’t be constructed by a finite complexity algorithm) which may explain the extreme difficulties of its construction?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c636a0070b7b6d1259c92b75f7f944c491a6d91ae0affed23f8d861a468064e-6bb7ddc5eae84dc8c8e9231851e2a31f6212888f4ee58db5319d35cd6f43a35f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Smart")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516909")[#strong[#text("Robert Smart")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2019")])]

#text("Is this available unpaywalled? If not then I hope you got paid an amount that is commensurate with the effort. I don’t like the business model of “let’s have a commemorative issue to trick the stars of the field to work for us cheaply”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516913")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2019")])]

#text("scihub -> ")#link("https://doi.org/10.1038/s42254-019-0068-9")[#text("https://doi.org/10.1038/s42254-019-0068-9")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-696025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("The scihub link doesn’t work any more and neither does the one below, from the NatureReviews tweet.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516962")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("The ")#link("https://twitter.com/NatRevPhys/status/1134418228103581699")[#text("NatureReviews tweet")]#text(" contains a link to an ")#link("https://www.nature.com/articles/s42254-019-0068-9.epdf?shared_access_token=6rc-x7FPL5kjpveoikZunNRgN0jAjWel9jnR3ZoTv0MfKWsg_vlKrq5yDHjqGGQky1MsgKL3WJRQ32XSOhs-xM9z3gF_OslGamWLNTEd1LaSb8IoX6JS2saOuFLxwG4mVrnLm6T2XrCaLH_eF4_LjQ%3D%3D")[#text("unpaywalled version")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516937")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("I’m wondering why the spelling “programme” … wouldn’t “program” give the sense that you were programming a computer-like system?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516938")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("American English always uses program. British English uses programme unless referring to computers. Australian English recommends program for official usage, but programme is still in common use. I think Prof. Tao was in Australia when he learned how to spell words.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a97deaa3ef13986dc80176f3b5a6ee0c6b50aac91ea4d586c114a25b4b08bb6f-6c6a6b670c64a488edbfc0a351fa1f415f8fa1a444d247a852145bc16b88533f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jair2018")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516942")[#strong[#text("jair2018")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("Awesome")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516948")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("Is there any interesting recent progress (since your last few blog posts) in this area? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516992")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2019")])]

#text("I remember from the old posts that Terry Tao’s strategy for negative answer was (a) NS allows computation and therefore (b) NS has singularities. It is therefore also interesting to understand what the negation of (a) means, which is a weaker statement than regularity. Unlike computational complexity issues here for (a) or its negation we allow very wild forms of reductions. The formal description of (a) or its negation in this context is very interesting and I’d love to see it again.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517009")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2019")])]

#text("This sounds very interesting. Could you elaborate more on the formalisation of (a), i.e. “NS allows computation”? How can one formalize “computation” in this context? This sounds like a very challenging question. I would be very happy for more information what you have in mind, or references to related topics. Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2019")])]

#text("The previous post you’re thinking of may have been this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("Finite time blowup for an averaged three-dimensional Navier-Stokes equation")]
]

#text("I don’t think computation was exactly formalized, but rather the idea was that if you can implement logic gates using moving fluids, you can turn them into a fluid computer, and part of the problem was how to formalize that and get it to work. Or maybe finding and implementing something like “rule 110” in a 3-d neighborhood is equivalent.")

#text("If you have blowup in the form of a self-reproducing machine like in the earlier post, do you automatically get universality? I’ll guess “yes” for the same reason that Conway’s Life is universal (if you can make an array of such machines you can possibly also get them to turn each other on and off), but I don’t have anywhere near the technical knowledge to try to prove that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517042")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2019")])]

#text("In order for any “fluidic logic gates” to be practical, they must be robust to small disturbances during their operation. So their (still unknown) mere existence is not sufficient and the additional requirement of rubustness is required for their operation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517049")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2019")])]

#text("Maybe I’m missing something but I don’t see a need for robustness here. It’s ok for the solution to only work on a set of measure 0. Nobody is proposing constructing these gates out of physical materials. It’s more like the Banach-Tarski paradox, a purely mathematical (non-)construction.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517056")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2019")])]

#text("If there is a proof for the existence of such gates, it would be interesting to know if such a proof can be made constructive or it must depend on nonconstructive existence methods (e.g. by using the axiom of choice.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517078")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2019")])]

#text("Oh sorry, that can’t happen, I only compared Banach-Tarski in the sense that it’s a purely mathematical conception that can’t be implemented with physical objects. Another reason NS blowup can’t be physical is that there has to be a finite time interval in which the fluid is moving faster than light.")

#text("NS uniformity is a ")#mi("\\Pi^0_2")#text(" statement as mentioned by Prof. Tao in an ")#link("https://mathoverflow.net/a/163160")[#text("old MO post")]#text(". Blowup is the negation of uniformity so it is only ")#mi("\\Sigma^0_2")#text(". So ")#link("https://en.wikipedia.org/wiki/Absoluteness#Shoenfield's_absoluteness_theorem")[#text("Schoenfeld’s absoluteness theorem")]#text(" implies that if uniformity (or alternatively blowup) can be proved in ZFC then it can be proved in ZF without AC.")

#text("If I got that wrong someone please yell at me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2019")])]

#text("It seems that in order to get a clearer description of the concept of finite time blowup, one should try to give a precise definition for the “singular set” of “blowup points” (probably with complete classification of the “blowup points” into several classes of rigorously defined “blowup types”) and study properties of this singular set – which might be a very complicated fractal-like set (possibly due to turbulences.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-516998")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2019")])]

#text("Looks like a prediction is made in physics just like Einstein made. Only way to test is by experimental physicists and why is the baton not passed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517023")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2019")])]

#text("This is a math question, not physics. In physical fluid dynamics, NS has to break down once you get to the molecular level. The math question is about how a differential equation behaves in a continuum.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d479a9092fe57b8e2d6d6fcf5793c0b4c028ece225497abd395a6e04838173d4-8ce432f383f6a7eae62e471ed084d3a631332791756696ffaae5ca39d7a86c65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of df")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517099")[#strong[#text("df")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2019")])]

#text("what a blog!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HS")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517124")[#strong[#text("HS")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2019")])]

#text("Surprised that you didn’t reference the recent remarkable work of Buckmaster and Vicol on Navier-Stokes using the method of convex integration.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2019")])]

#text("This is partly due to the restrictions of the format (~1200 words, five references maximum, though the editors did eventually allow me to breach the latter limit) but also because the problem of constructing pathological weak solutions concerns a somewhat different regime of Navier-Stokes than the global regularity problem. In the latter, the solution is initially smooth and the forcing term is either absent or assumed to also be smooth; the singularities, if any, are purely caused by the nonlinear terms overcoming the effects of dissipation due to the supercriticality of the problem. In the former, one is working with weak solutions, which roughly speaking corresponds to (weak limits of) classical solutions with extremely high frequency forcing terms. The pathologies of the solution are then caused primarily by the interactions between the nonlinearity and the high frequency forcing term, with the dissipation actually playing only a minor role, in particular there is no noticeable role played by supercriticality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517156")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2019")])]

#text("I’m not sure if you can make corrections, but $p:[0,+\\infty)\\times\\mathbb{R}^3\\to \\mathbb{R}^3$ should be $p:[0,+\\infty)\\times\\mathbb{R}^3\\to \\mathbb{R}$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a4c7f03ed3aede15010f1aef30bf3340348ce5bcc380c80efa785cf001837ba-d60000c4ec85521959c0a425b3007543baa7c9499a877f2de39bd52131eebd40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-517161")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2019")])]

#text("Can we describe initial conditions for the navier strokes that simulate the n body problem in gravity?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-533362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("There is a new Quanta article about Tarek Elgindi showing blowup in the Euler equations:")

#link("https://www.quantamagazine.org/mathematician-makes-euler-equations-blow-up-20191218/")[#text("https://www.quantamagazine.org/mathematician-makes-euler-equations-blow-up-20191218/")]

#text("Is this as interesting as it sounds? Does it say anything about NS?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-533397")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("I know the result (Tarek gave a talk recently at UCLA about it). It’s quite a nice result; he shows that a certain mild “kink” type model singularity (of regularity ")#mi("C^{1.\\alpha}")#text(" for some small ")#mi("\\alpha")#text(") is stable enough that it can create a (locally) self-similar solution to the Euler equations that blows up (in the same ")#mi("C^{1,\\alpha}")#text(" norm) in finite time. (Here Elgindi uses the standard approach of first analyzing the linear stability of the model profile and then using perturbation theory to get the nonlinear stability.) This is the closest anyone has come to demonstrating finite time blowup to the actual Euler equations (as opposed to various toy models of Euler) from regular data. Unfortunately in Tarek’s method it is essential that the initial data already contains a mild singularity at a point, so it doesn’t say anything yet about the smooth problem (and by the same token, the method does not extend at present to Navier-Stokes, whose evolution is parabolic and would immediately erase this singularity).")

#text("In principle one could now hope to find some other model self-similar blowup profile that is stable and does not initially contain singularities, in order to obtain a similar result from smooth data. Unfortunately there seem to be non-trivial topological obstructions to the stability of such profiles once one does not have any singularities to “hide” the topology in. It would be good to understand this issue better. It may be possible to use the presence of a boundary to somehow remove these topological obstructions, which would be consistent with other recent work establishing blowup for fluid equations with boundary (e.g., ")#link("https://arxiv.org/abs/1910.00173")[#text("https://arxiv.org/abs/1910.00173")]#text(" ).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27d5da4dae92eec2e9ae8cf10aeedc6950307f741f9165dbe2fe9ca66596b1c3-69e44855053309d2475c3a4ccb336b74b77da972d4caecb96107f79cc180676d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-555293")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2020")])]

#text("I wonder if the recent paper on the arXiv, ")#link("https://arxiv.org/abs/2004.08239")[#text("https://arxiv.org/abs/2004.08239")]#text(" by Vu Thanh Nguyen has a chance of being correct, has anyone looked into that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-555375")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2020")])]

#text("Despite the title, the paper is not claiming a solution to the Navier-Stokes global regularity problem (except in the case of small data); instead, the paper claims that solutions to Navier-Stokes (either in Euclidean space or on domains with boundary) remain regular up to the maximal time of existence, which may either be finite or infinite, and in the former case certain norms blow up at the final time of existence. The global regularity problem asks to completely exclude the former scenario in which the maximal time of existence is finite, and this is only done here when the initial data is sufficiently small in a suitable sense. Results of this type are already known for various notions of solution (e.g., mild solutions) and on various domains, being part of the standard local well-posedness and regularity theory for this equation; I have not looked at the paper carefully to see to what extent the results in that paper differ from existing ones.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e106c6b53e9730e72242a5fac371894e43a53804410746f8f1e5508b4d1dedcf-05d11071452f50d2d3a11fefd42038c958c04e7bc49bb2a7949e00b95be8f7dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Flying")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-629333")[#strong[#text("Flying")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2021")])]

#text("With regards to the general concept of blow up, in a way where the energy is transferred/concentrated into a smaller and smaller volume of space, is there an analogy to the case of bouncing balls of different sizes? One can stack a column of balls of smaller and smaller mass, and eventually reach unbounded velocities?")

#link("http://www.exo.net/~pauld/activities/physics/bouncingballs.html")[#text("http://www.exo.net/~pauld/activities/physics/bouncingballs.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9601fb1ceb521e255e9f60e96a4d521a8dde7c7cf01a89b016612bd9b59676e5-8af3a19d0fb72667aaadf1e8150b482476a8d9834d91a65c969622bf92469d77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justastudent")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-631468")[#strong[#text("Justastudent")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2021")])]

#text("Just in case it might be useful for prof Tao, it seems that there has been some big progress in concretely implementing logic gates for fluids ")#link("https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0254524")[#text("https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0254524")]#text(" where ‘1 atm pressure’ = 0 = FALSE and ‘vacuum’ = 1 = TRUE. Perhaps some smoothed variant could help.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/31/searching-for-singularities-in-the-navier-stokes-equations/#comment-688794")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2025")])]

#text("This might be of interest. It’s about computer search for unstable singularities in some PDE’s related to NS (not NS itself, or 3D Euler). They train neural nets to help with the search.")

#link("https://arxiv.org/abs/2509.14185")[#text("https://arxiv.org/abs/2509.14185")]#text(" “discovery of unstable singularities” (preprint)")

#text("Popular-level description: ")#link("https://deepmind.google/discover/blog/discovering-new-solutions-to-century-old-problems-in-fluid-dynamics/")[#text("https://deepmind.google/discover/blog/discovering-new-solutions-to-century-old-problems-in-fluid-dynamics/")]
]
