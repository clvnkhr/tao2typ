// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/
// Converted to Typst by tao2typ: "2026-11-06T14:28:16.558483+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 8: The microstructure of approximate groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 8: The microstructure of approximate groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 November 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/")[#text("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-06 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A common theme in mathematical analysis (particularly in analysis of a “geometric” or “statistical” flavour) is the interplay between “macroscopic” and “microscopic” scales. These terms are somewhat vague and imprecise, and their interpretation depends on the context and also on one’s choice of normalisations, but if one uses a “macroscopic” normalisation, “macroscopic” scales correspond to scales that are comparable to unit size (i.e. bounded above and below by absolute constants), while “microscopic” scales are much smaller, being the minimal scale at which nontrivial behaviour occurs. (Other normalisations are possible, e.g. making the microscopic scale a unit scale, and letting the macroscopic scale go off to infinity; for instance, such a normalisation is often used, at least initially, in the study of groups of polynomial growth. However, for the theory of approximate groups, a macroscopic scale normalisation is more convenient.)")

#text("One can also consider “mesoscopic” scales which are intermediate between microscopic and macroscopic scales, or large-scale behaviour at scales that go off to infinity (and in particular are larger than the macroscopic range of scales), although the behaviour of these scales will not be the main focus of this post. Finally, one can divide the macroscopic scales into “local” macroscopic scales (less than ")#mi("{\\epsilon}")#text(" for some small but fixed ")#mi("{\\epsilon>0}")#text(") and “global” macroscopic scales (scales that are allowed to be larger than a given large absolute constant ")#mi("{C}")#text("). For instance, given a finite approximate group ")#mi("{A}")#text(":")

#list(
[#text("Sets such as ")#mi("{A^m}")#text(" for some fixed ")#mi("{m}")#text(" (e.g. ")#mi("{A^{10}}")#text(") can be considered to be sets at a global macroscopic scale. Sending ")#mi("{m}")#text(" to infinity, one enters the large-scale regime.")],
[#text("Sets such as the sets ")#mi("{S}")#text(" that appear in the Sanders lemma from the previous set of notes (thus ")#mi("{S^m \\subset A^4}")#text(" for some fixed ")#mi("{m}")#text(", e.g. ")#mi("{m=100}")#text(") can be considered to be sets at a local macroscopic scale. Sending ")#mi("{m}")#text(" to infinity, one enters the mesoscopic regime.")],
[#text("The non-identity element ")#mi("{u}")#text(" of ")#mi("{A}")#text(" that is “closest” to the identity in some suitable metric (cf. the proof of Jordan’s theorem from ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Notes 0")]#text(") would be an element associated to the microscopic scale. The orbit ")#mi("{u, u^2, u^3, \\ldots}")#text(" starts out at microscopic scales, and (assuming some suitable “escape” axioms) will pass through mesoscopic scales and finally entering the macroscopic regime. (Beyond this point, the orbit may exhibit a variety of behaviours, such as periodically returning back to the smaller scales, diverging off to ever larger scales, or filling out a dense subset of some macroscopic set; the escape axioms we will use do not exclude any of these possibilities.)")]
)

#text("For comparison, in the theory of locally compact groups, properties about small neighbourhoods of the identity (e.g. local compactness, or the NSS property) would be properties at the local macroscopic scale, whereas the space ")#mi("{L(G)}")#text(" of one-parameter subgroups can be interpreted as an object at the microscopic scale. The exponential map then provides a bridge connecting the microscopic and macroscopic scales.")

#text("We return now to approximate groups. The macroscopic structure of these objects is well described by the ")#emph[#text("Hrushovski Lie model theorem")]#text(" from ")#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/")[#text("the previous set of notes")]#text(", which informally asserts that the macroscopic structure of an (ultra) approximate group can be modeled by a Lie group. This is already an important piece of information about general approximate groups, but it does not directly reveal the full structure of such approximate groups, because these Lie models are unable to see the ")#emph[#text("microscopic")]#text(" behaviour of these approximate groups.")

#text("To illustrate this, let us review one of the examples of a Lie model of an ultra approximate group, namely ")#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/")[#text("Exercise 28 from Notes 7")]#text(". In this example one studied a “nilbox” from a Heisenberg group, which we rewrite here in slightly different notation. Specifically, let ")#mi("{G}")#text(" be the Heisenberg group")

#align(center)[#tao-fit-display[#mitex("G := \\{ (a,b,c): a,b,c \\in {\\bf Z} \\}")]]

#text("with group law ")#metadata(none) <tao-ad936fcbed631fa67e05>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(a,b,c) \\ast (a^{\\prime},b^{\\prime},c^{\\prime}) := (a+a^{\\prime}, b+b^{\\prime}, c+c^{\\prime}+ab^{\\prime})")]]

#text("and let ")#mi("{A = \\prod_{n \\rightarrow \\alpha} A_n}")#text(", where ")#mi("{A_n \\subset G}")#text(" is the box")

#align(center)[#tao-fit-display[#tao-math("A_n := \\{ (a,b,c) \\in G: \\left|a\\right|, \\left|b\\right| \\leq n; \\left|c\\right| \\leq n^{10} \\};", block: true)]]

#text("thus ")#mi("{A}")#text(" is the nonstandard box")

#align(center)[#tao-fit-display[#tao-math("A := \\{ (a,b,c) \\in {}^* G: \\left|a\\right|, \\left|b\\right| \\leq N; \\left|c\\right| \\leq N^{10} \\}", block: true)]]

#text("where ")#mi("{N := \\lim_{n \\rightarrow \\alpha} n}")#text(". As the above exercise establishes, ")#mi("{A \\cup A^{-1}}")#text(" is an ultra approximate group with a Lie model ")#mi("{\\pi: \\langle A \\rangle \\rightarrow {\\bf R}^3}")#text(" given by the formula")

#align(center)[#tao-fit-display[#mitex("\\pi( a, b, c ) := ( \\text{st} \\frac{a}{N}, \\text{st} \\frac{b}{N}, \\text{st} \\frac{c}{N^{10}} )")]]

#text("for ")#mi("{a,b = O(N)}")#text(" and ")#mi("{c = O(N^{10})}")#text(". Note how the nonabelian nature of ")#mi("{G}")#text(" (arising from the ")#mi("{ab^{\\prime}}")#text(" term in the group law ")#link(<tao-ad936fcbed631fa67e05>)[#text("(1)")]#text(") has been lost in the model ")#mi("{{\\bf R}^3}")#text(", because the effect of that nonabelian term on ")#mi("{\\frac{c}{N^{10}}}")#text(" is only ")#mi("{O(\\frac{N^2}{N^8})}")#text(" which is infinitesimal and thus does not contribute to the standard part. In particular, if we replace ")#mi("{G}")#text(" with the abelian group ")#mi("{G^{\\prime} := \\{(a,b,c): a,b,c \\in {\\bf Z} \\}}")#text(" with the additive group law")

#align(center)[#tao-fit-display[#mitex("(a,b,c) \\ast^{\\prime} (a^{\\prime},b^{\\prime},c^{\\prime}) := (a+a^{\\prime},b+b^{\\prime},c+c^{\\prime})")]]

#text("and let ")#mi("{A^{\\prime}}")#text(" and ")#mi("{\\pi^{\\prime}}")#text(" be defined exactly as with ")#mi("{A}")#text(" and ")#mi("{\\pi}")#text(", but placed inside the group structure of ")#mi("{G^{\\prime}}")#text(" rather than ")#mi("{G}")#text(", then ")#mi("{A \\cup A^{-1}}")#text(" and ")#mi("{A^{\\prime} \\cup (A^{\\prime})^{-1}}")#text(" are essentially “indistinguishable” as far as their models by ")#mi("{{\\bf R}^3}")#text(" are concerned, even though the latter approximate group is abelian and the former is not. The problem is that the nonabelian-ness in the former example is so microscopic that it falls entirely inside the kernel of ")#mi("{\\pi}")#text(" and is thus not detected at all by the model.")

#text("The problem of not being able to “see” the microscopic structure of a group (or approximate group) also was a key difficulty in the theory surrounding Hilbert’s fifth problem that was discussed in ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("notes")]#text(". A key tool in being able to resolve such structure was to build left-invariant metrics ")#mi("{d}")#text(" (or equivalently, norms ")#mi("{\\| \\|}")#text(") on one’s group, which obeyed useful “Gleason axioms” such as the commutator axiom ")#metadata(none) <tao-2536035bdd05a9090ceb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| [g,h] \\right\\| \\ll \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("for sufficiently small ")#mi("{g,h}")#text(", or the escape axiom ")#metadata(none) <tao-967849335cfd0901daea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| g^n \\right\\| \\gg \\left|n\\right| \\left\\|g\\right\\|", block: true)]]

#text("when ")#tao-math("{\\left|n\\right| \\left\\|g\\right\\|}", block: false)#text(" was sufficiently small. Such axioms have important and non-trivial content even in the microscopic regime where ")#mi("{g}")#text(" or ")#mi("{h}")#text(" are extremely close to the identity. For instance, in the proof of Jordan’s theorem from ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Notes 0")]#text(", which showed that any finite unitary group ")#mi("{G}")#text(" was boundedly virtually abelian, a key step was to apply the commutator axiom ")#link(<tao-2536035bdd05a9090ceb>)[#text("(2)")]#text(" (for the distance to the identity in operator norm) to the most “microscopic” element of ")#mi("{G}")#text(", or more precisely a non-identity element of ")#mi("{G}")#text(" of minimal norm. The key point was that this microscopic element was virtually central in ")#mi("{G}")#text(", and as such it restricted much of ")#mi("{G}")#text(" to a lower-dimensional subgroup of the unitary group, at which point one could argue using an induction-on-dimension argument. As we shall see, a similar argument can be used to place “virtually nilpotent” structure on finite approximate groups. For instance, in the Heisenberg-type approximate groups ")#mi("{A \\cup A^{-1}}")#text(" and ")#mi("{A^{\\prime} \\cup (A^{\\prime})^{-1}}")#text(" discussed earlier, the element ")#mi("{(0,0,1)}")#text(" will be “closest to the origin” in a suitable sense to be defined later, and is centralised by both approximate groups; quotienting out (the orbit of) that central element and iterating the process two more times, we shall see that one can express both ")#mi("{A \\cup A^{-1}}")#text(" and ")#mi("{A^{\\prime}\\cup (A^{\\prime})^{-1}}")#text(" as a tower of central cyclic extensions, which in particular establishes the nilpotency of both groups.")

#text("The escape axiom ")#link(<tao-967849335cfd0901daea>)[#text("(3)")]#text(" is a particularly important axiom in connecting the microscopic structure of a group ")#mi("{G}")#text(" to its macroscopic structure; for instance, as shown in ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("Notes 2")]#text(", this axiom (in conjunction with the closely related commutator axiom) tends to imply dilation estimates such as ")#mi("{d( g^n, h^n ) \\sim n d(g,h)}")#text(" that allow one to understand the microscopic geometry of points ")#mi("{g,h}")#text(" close to the identity in terms of the (local) macroscopic geometry of points ")#mi("{g^n, h^n}")#text(" that are significantly further away from the identity.")

#text("It is thus of interest to build some notion of a norm (or left-invariant metrics) on an approximate group ")#mi("{A}")#text(" that obeys the escape and commutator axioms (while being non-degenerate enough to adequately capture the geometry of ")#mi("{A}")#text(" in some sense), in a fashion analogous to the Gleason metrics that played such a key role in the theory of Hilbert’s fifth problem. It is tempting to use the Lie model theorem to do this, since Lie groups certainly come with Gleason metrics. However, if one does this, one ends up, roughly speaking, with a norm on ")#mi("{A}")#text(" that only obeys the escape and commutator estimates ")#emph[#text("macroscopically")]#text("; roughly speaking, this means that one has a macroscopic commutator inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| [g,h] \\right\\| \\ll \\left\\|g\\right\\| \\left\\|h\\right\\| + o(1)", block: true)]]

#text("and a macroscopic escape property")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g^n \\right\\| \\gg \\left|n\\right| \\left\\|g\\right\\| - o(\\left|n\\right|)", block: true)]]

#text("but such axioms are too weak for analysis at the microscopic scale, and in particular in establishing centrality of the element closest to the identity.")

#text("Another way to proceed is to build a norm that is specifically designed to obey the crucial escape property. Given an approximate group ")#mi("{A}")#text(" in a group ")#mi("{G}")#text(", and an element ")#mi("{g}")#text(" of ")#mi("{G}")#text(", we can define the ")#emph[#text("escape norm")]#text(" ")#tao-math("{\\left\\|g\\right\\|_{e,A}}", block: false)#text(" of ")#mi("{g}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g \\right\\|_{e,A} := \\inf \\{ \\frac{1}{n+1}: n \\in {\\bf N}: g, g^2, \\ldots, g^n \\in A \\}.", block: true)]]

#text("Thus, ")#tao-math("{\\left\\|g\\right\\|_{e,A}}", block: false)#text(" equals ")#mi("{1}")#text(" if ")#mi("{g}")#text(" lies outside of ")#mi("{A}")#text(", equals ")#mi("{1/2}")#text(" if ")#mi("{g}")#text(" lies in ")#mi("{A}")#text(" but ")#mi("{g^2}")#text(" lies outside of ")#mi("{A}")#text(", and so forth. Such norms had already appeared in ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(", in the context of analysing NSS groups.")

#text("As it turns out, this expression will obey an escape axiom, as long as we place some additional hypotheses on ")#mi("{A}")#text(" which we will present shortly. However, it need not actually be a norm; in particular, the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|gh\\right\\|_{e,A} \\leq \\left\\|g\\right\\|_{e,A} + \\left\\|h\\right\\|_{e,A}", block: true)]]

#text("is not necessarily true. Fortunately, it turns out that by a (slightly more complicated) version of the Gleason machinery from ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(" we can establish a usable substitute for this inequality, namely the quasi-triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g_1 \\ldots g_k \\right\\|_{e,A} \\leq C (\\left\\|g_1\\right\\|_{e,A} + \\ldots + \\left\\|g_k\\right\\|_{e,A}),", block: true)]]

#text("where ")#mi("{C}")#text(" is a constant independent of ")#mi("{k}")#text(". As we shall see, these estimates can then be used to obtain a commutator estimate ")#link(<tao-2536035bdd05a9090ceb>)[#text("(2)")]#text(".")

#text("However, to do all this, it is not enough for ")#mi("{A}")#text(" to be an approximate group; it must obey two additional “trapping” axioms that improve the properties of the escape norm. We formalise these axioms (somewhat arbitrarily) as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Strong approximate group)")]#text(" Let ")#mi("{K \\geq 1}")#text(". A ")#emph[#text("strong ")#mi("{K}")#text("-approximate group")]#text(" is a finite ")#mi("{K}")#text("-approximate group ")#mi("{A}")#text(" in a group ")#mi("{G}")#text(" with a symmetric subset ")#mi("{S}")#text(" obeying the following axioms:")

#list(
[#text("(")#mi("{S}")#text(" small) One has")

#metadata(none) <tao-9d12b056ba72e051cce5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(S^{A^4})^{1000K^3} \\subset A.")]]],
[#text("(First trapping condition) If ")#mi("{g, g^2, \\ldots, g^{1000} \\in A^{100}}")#text(", then ")#mi("{g \\in A}")#text(".")],
[#text("(Second trapping condition) If ")#mi("{g, g^2, \\ldots, g^{10^6 K^3} \\in A}")#text(", then ")#mi("{g \\in S}")#text(".")]
)

#text("An ")#emph[#text("ultra strong ")#mi("{K}")#text("-approximate group")]#text(" is an ultraproduct ")#mi("{A = \\prod_{n \\rightarrow \\alpha} A_n}")#text(" of strong ")#mi("{K}")#text("-approximate groups.")
]

#text("The first trapping condition can be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{e,A} \\leq 1000 \\left\\|g\\right\\|_{e,A^{100}}", block: true)]]

#text("and the second trapping condition can similarly be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{e,S} \\leq 10^6 K^3 \\left\\|g\\right\\|_{e,A}.", block: true)]]

#text("This makes the escape norms of ")#mi("{A, A^{100}}")#text(", and ")#mi("{S}")#text(" comparable to each other, which will be needed for a number of reasons (and in particular to close a certain bootstrap argument properly). Compare this with equation (12) from ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(", which used the NSS hypothesis to obtain similar conclusions. Thus, one can view the strong approximate group axioms as being a sort of proxy for the NSS property.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Let ")#mi("{N}")#text(" be a large natural number. Then the interval ")#mi("{A = [-N,N]}")#text(" in the integers is a ")#mi("{2}")#text("-approximate group, which is also a strong ")#mi("{2}")#text("-approximate group (setting ")#mi("{S = [10^{-6} N, 10^{-6} N]}")#text(", for instance). On the other hand, if one places ")#mi("{A}")#text(" in ")#mi("{{\\bf Z}/5N{\\bf Z}}")#text(" rather than in the integers, then the first trapping condition is lost and one is no longer a strong ")#mi("{2}")#text("-approximate group. Also, if one remains in the integers, but deletes a few elements from ")#mi("{A}")#text(", e.g. deleting ")#mi("{\\pm \\lfloor 10^{-10} N\\rfloor}")#text(" from ")#mi("{A}")#text("), then one is still a ")#mi("{O(1)}")#text("-approximate group, but is no longer a strong ")#mi("{O(1)}")#text("-approximate group, again because the first trapping condition is lost.")
]

#text("A key consequence of the Hrushovski Lie model theorem is that it allows one to replace approximate groups by strong approximate groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Finding strong approximate groups)")]#text(" ")#metadata(none) <tao-cc9103a8b19f9e9f68fc>

#list(
[#text("(i) Let ")#mi("{A}")#text(" be an ultra approximate group with a good Lie model ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L}")#text(", and let ")#mi("{B}")#text(" be a symmetric convex body (i.e. a convex open bounded subset) in the Lie algebra ")#mi("{{\\mathfrak l}}")#text(". Show that if ")#mi("{r>0}")#text(" is a sufficiently small standard number, then there exists a strong ultra approximate group ")#mi("{A^{\\prime}}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\pi^{-1}(\\exp(rB)) \\subset A^{\\prime} \\subset \\pi^{-1}(\\exp(1.1 rB)) \\subset A,")]]

#text("and with ")#mi("{A}")#text(" can be covered by finitely many left translates of ")#mi("{A^{\\prime}}")#text(". Furthermore, ")#mi("{\\pi}")#text(" is also a good model for ")#mi("{A^{\\prime}}")#text(".")],
[#text("(ii) If ")#mi("{A}")#text(" is a finite ")#mi("{K}")#text("-approximate group, show that there is a strong ")#mi("{O_K(1)}")#text("-approximate group ")#mi("{A^{\\prime}}")#text(" inside ")#mi("{A^4}")#text(" with the property that ")#mi("{A}")#text(" can be covered by ")#mi("{O_K(1)}")#text(" left translates of ")#mi("{A^{\\prime}}")#text(". (")#emph[#text("Hint:")]#text(" use (i), Hrushovski’s Lie model theorem, and a compactness and contradiction argument.)")]
)
]

#text("The need to compare the strong approximate group to an exponentiated small ball ")#mi("{\\exp(rB)}")#text(" will be convenient later, as it allows one to easily use the geometry of ")#mi("{L}")#text(" to track various aspects of the strong approximate group.")

#text("As mentioned previously, strong approximate groups exhibit some of the features of NSS locally compact groups. In ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(", we saw that the escape norm for NSS locally compact groups was comparable to a Gleason metric. The following theorem is an analogue of that result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Gleason lemma)")]#text(" ")#metadata(none) <tao-1a916a1070c99ec124f1>#text(" Let ")#mi("{A}")#text(" be a strong ")#mi("{K}")#text("-approximate group in a group ")#mi("{G}")#text(".")

#list(
[#text("(Symmetry) For any ")#mi("{g \\in G}")#text(", one has ")#tao-math("{\\left\\|g^{-1}\\right\\|_{e,A} = \\left\\|g\\right\\|_{e,A}}", block: false)#text(".")],
[#text("(Conjugacy bound) For any ")#mi("{g, h \\in A^{10}}")#text(", one has ")#tao-math("{\\left\\|g^h\\right\\|_{e,A} \\ll \\left\\|g\\right\\|_{e,A}}", block: false)#text(".")],
[#text("(Triangle inequality) For any ")#mi("{g_1,\\ldots,g_k \\in G}")#text(", one has ")#tao-math("{\\left\\|g_1 \\ldots g_k \\right\\|_{e,A} \\ll_K (\\left\\|g_1\\right\\|_{e,A} + \\ldots + \\left\\|g_k\\right\\|_{e,A})}", block: false)#text(".")],
[#text("(Escape property) One has ")#tao-math("{\\left\\|g^n\\right\\|_{e,A} \\gg \\left|n\\right| \\left\\|g\\right\\|_{e,A}}", block: false)#text(" whenever ")#tao-math("{\\left|n\\right| \\left\\|g\\right\\|_{e,A} < 1}", block: false)#text(".")],
[#text("(Commutator inequality) For any ")#mi("{g,h \\in A^{10}}")#text(", one has ")#tao-math("{\\left\\| [g,h] \\right\\|_{e,A} \\ll_K \\left\\|g\\right\\|_{e,A} \\left\\|h\\right\\|_{e,A}}", block: false)#text(".")]
)
]

#text("The proof of this theorem will occupy a large part of the current set of notes. We then aim to use this theorem to classify strong approximate groups. The basic strategy (temporarily ignoring a key technical issue) follows the Bieberbach-Frobenius proof of Jordan’s theorem, as given in ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Notes 0")]#text(", is as follows.")

#enum(start: 1, 
[#text("Start with an (ultra) strong approximate group ")#mi("{A}")#text(".")],
[#text("From the Gleason lemma, the elements with zero escape norm form a normal subgroup of ")#mi("{A}")#text(". Quotient these elements out. Show that all non-identity elements will have positive escape norm.")],
[#text("Find the non-identity element ")#mi("{g_1}")#text(" in (the quotient of) ")#mi("{A}")#text(" of minimal escape norm. Use the commutator estimate (assuming it is inherited by the quotient) to show that ")#mi("{g_1}")#text(" will centralise (most of) this quotient. In particular, the orbit ")#mi("{\\langle g_1 \\rangle}")#text(" is (essentially) a central subgroup of ")#mi("{\\langle A \\rangle}")#text(".")],
[#text("Quotient this orbit out; then find the next non-identity element ")#mi("{g_2}")#text(" in this new quotient of ")#mi("{A}")#text(". Again, show that ")#mi("{\\langle g_2 \\rangle}")#text(" is essentially a central subgroup of this quotient.")],
[#text("Repeat this process until ")#mi("{A}")#text(" becomes entirely trivial. Undoing all the quotients, this should demonstrate that ")#mi("{\\langle A \\rangle}")#text(" is virtually nilpotent, and that ")#mi("{A}")#text(" is essentially a coset nilprogression.")]
)

#text("There are two main technical issues to resolve to make this strategy work. The first is to show that the iterative step in the argument terminates in finite time. This we do by returning to the Lie model theorem. It turns out that each time one quotients out by an orbit of an element that escapes, the dimension of the Lie model drops by at least one. This will ensure termination of the argument in finite time.")

#text("The other technical issue is that while the quotienting out all the elements of zero escape norm eliminates all “torsion” from ")#mi("{A}")#text(" (in the sense that the quotient of ")#mi("{A}")#text(" has no non-trivial elements of zero escape norm), further quotienting operations can inadvertently re-introduce such torsion. This torsion can be re-eradicated by further quotienting, but the price one pays for this is that the final structural description of ")#mi("{\\langle A \\rangle}")#text(" is no longer as strong as “virtually nilpotent”, but is instead a more complicated tower alternating between (ultra) finite extensions and central extensions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Consider the strong ")#mi("{O(1)}")#text("-approximate group")

#align(center)[#tao-fit-display[#tao-math("A := \\{ a N^{10} + 5 b: \\left|a\\right| \\leq N; \\left|b\\right| \\leq N^2 \\}", block: true)]]

#text("in the integers, where ")#mi("{N}")#text(" is a large natural number not divisible by ")#mi("{5}")#text(". As ")#mi("{{\\bf Z}}")#text(" is torsion-free, all non-zero elements of ")#mi("{A}")#text(" have positive escape norm, and the nonzero element of minimal escape norm here is ")#mi("{g=5}")#text(" (or ")#mi("{g=-5}")#text("). But if one quotients by ")#mi("{\\langle g \\rangle}")#text(", ")#mi("{A}")#text(" projects down to ")#mi("{{\\bf Z}/5{\\bf Z}}")#text(", which now has torsion (and all elements in this quotient have zero escape norm). Thus torsion has been re-introduced by the quotienting operation. (A related observation is that the intersection of ")#mi("{A}")#text(" with ")#mi("{\\langle g \\rangle = 5{\\bf Z}}")#text(" is not a simple progression, but is a more complicated object, namely a generalised arithmetic progression of rank two.)")
]

#text("To deal with this issue, we will not quotient out by the entire cyclic group ")#mi("{\\langle g \\rangle = \\{g^n: n \\in {\\bf Z} \\}}")#text(" generated by the element ")#mi("{g}")#text(" of minimal escape norm, but rather by an arithmetic progression ")#tao-math("{P = \\{g^n: \\left|n\\right| \\leq N\\}}", block: false)#text(", where ")#mi("{N}")#text(" is a natural number comparable to the reciprocal ")#tao-math("{1/\\left\\|g\\right\\|_{e,A}}", block: false)#text(" of the escape norm, as this will be enough to cut the dimension of the Lie model down by one without introducing any further torsion. Of course, this cannot be done in the category of global groups, since the arithmetic progression ")#mi("{P}")#text(" will not, in general, be a group. However, it is still a ")#emph[#text("local")]#text(" group, and it turns out that there is an analogue of the quotient space construction in local groups. This fixes the problem, but at a cost: in order to make the inductive portion of the argument work smoothly, it is now more natural to place the ")#emph[#text("entire")]#text(" argument inside the category of local groups rather than global groups, even though the primary interest in approximate groups ")#mi("{A}")#text(" is in the global case when ")#mi("{A}")#text(" lies inside a global group. This necessitates some technical modification to some of the preceding discussion (for instance, the Gleason-Yamabe theorem must be replaced by the local version of this theorem, due to Goldbring); details can be found in ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("this recent paper of Emmanuel Breuillard, Ben Green, and myself")]#text(", but will only be sketched here.")

#heading(level: 1)[#strong[#text(" — 1. Gleason’s lemma — ")]]

#text("Throughout this section, ")#mi("{A}")#text(" is a strong ")#mi("{K}")#text("-approximate group in a global group ")#mi("{G}")#text(". We will prove the various estimates in Theorem ")#link(<tao-1a916a1070c99ec124f1>)[#text("2")]#text(". The arguments will be very close to those in ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text("; indeed, it is possible to unify the results here with the results in those notes by a suitable modification of the notation, but we will not do so here.")

#text("We begin with the easy estimates. The symmetry property is immediate from the symmetry of ")#mi("{A}")#text(". Now we turn to the escape property. By symmetry, we may take ")#mi("{n}")#text(" to be positive (the ")#mi("{n=0}")#text(" case is trivial). We may of course assume that ")#tao-math("{\\left\\|g\\right\\|_{e,A}}", block: false)#text(" is strictly positive, say equal to ")#mi("{1/(m+1)}")#text("; thus ")#mi("{g,\\ldots,g^m \\in A}")#text(" and ")#mi("{g^{m+1} \\not \\in A}")#text(", and ")#mi("{n \\leq m}")#text(". By the first trapping property, this implies that ")#mi("{g^{j(m+1)} \\not \\in A^{100}}")#text(" for some ")#mi("{1 \\leq j \\leq 1000}")#text(".")

#text("Let ")#mi("{kn}")#text(" be the first multiple of ")#mi("{n}")#text(" larger than or equal to ")#mi("{j(m+1)}")#text(", then ")#mi("{kn \\ll m+1}")#text(". Since ")#mi("{kn-j(m+1)}")#text(" is less than ")#mi("{m}")#text(", we have ")#mi("{g^{kn-j(m+1)} \\in A}")#text("; since ")#mi("{g^{j(m+1)} \\not \\in A^{100}}")#text(", we conclude that ")#mi("{g^{kn} \\not \\in A^{99}}")#text(". In particular this shows that ")#tao-math("{\\left\\|g^n\\right\\|_{e,A} \\gg 1/k \\gg n/(m+1)}", block: false)#text(", and the claim follows.")

#text("The escape property implies the conjugacy bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Establish the conjugacy bound. (")#emph[#text("Hint:")]#text(" one can mimic the arguments establishing a nearly identical bound in Section 2 of ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(".)")
]

#text("Now we turn to the triangle inequality, which (as in ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(") is the most difficult property to establish. Our arguments will closely resemble the proof of Proposition 11 from these notes, with ")#mi("{S^{A^4}}")#text(" and ")#mi("{A}")#text(" playing the roles of ")#mi("{U_1}")#text(" and ")#mi("{U_0}")#text(" from that argument. As in that theorem, we will initially assume that we have an ")#emph[#text("a priori")]#text(" bound of the form ")#metadata(none) <tao-862da37a227307662ac8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|g_1 \\ldots g_k \\right\\|_{e,A} \\leq M(\\left\\|g_1\\right\\|_{e,A} + \\ldots + \\left\\|g_k\\right\\|_{e,A})", block: true)]]

#text("for all ")#mi("{g_1,\\ldots,g_k}")#text(", and some (large) ")#mi("{M}")#text(" independent of ")#mi("{k}")#text(", and remove this hypothesis later. We then introduce the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g \\right\\|_{*,A} := \\inf \\{ \\left\\|g_1\\right\\|_{e,A} + \\ldots + \\left\\|g_k\\right\\|_{e,A}: g = g_1 \\ldots g_k \\},", block: true)]]

#text("then ")#tao-math("{\\left\\|g\\right\\|_{*,A}}", block: false)#text(" is symmetric, obeys the triangle inequality, and is comparable to ")#mi("{\\|\\|_{e,A}}")#text(" in the sense that ")#metadata(none) <tao-e02021f2855ba6c21d76>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\frac{1}{M} \\left\\|g\\right\\|_{e,A} \\leq \\left\\|g\\right\\|_{*,A} \\leq \\left\\|g\\right\\|_{e,A}", block: true)]]

#text("for all ")#mi("{g \\in G}")#text(".")

#text("We introduce the function ")#mi("{\\psi: G \\rightarrow {\\bf R}^+}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\psi(x) := (1 - M \\text{dist}_{*,A}(x, A))_+,")]]

#text("where ")#tao-math("{\\text{dist}_{*,A}(x,A) := \\inf_{y \\in A} \\left\\| x^{-1} y \\right\\|_{*,A}}", block: false)#text(". Then ")#mi("{\\psi}")#text(" takes values between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", equals ")#mi("{1}")#text(" on ")#mi("{A}")#text(", is supported on ")#mi("{A^2}")#text(", and obeys the Lipschitz bound ")#metadata(none) <tao-19e322ebbd1a9bcfa748>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\| \\partial_g \\psi \\right\\|_{\\ell^\\infty(G)} \\leq M \\left\\|g\\right\\|_{e,A}", block: true)]]

#text("for all ")#mi("{g}")#text(", thanks to the triangle inequality for ")#mi("{\\| \\|_{*,A}}")#text(" and ")#link(<tao-e02021f2855ba6c21d76>)[#text("(6)")]#text(". We also introduce the function ")#mi("{\\eta: G \\rightarrow {\\bf R}^+}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\eta(x) := \\sup \\{ 1 - \\frac{j}{10^4 K^3}: x \\in (S^{A^2})^j A \\} \\cup \\{0\\},")]]

#text("then ")#mi("{\\eta}")#text(" also takes values between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", equals ")#mi("{1}")#text(" on ")#mi("{A}")#text(", is supported on ")#mi("{A^2}")#text(", and obeys the Lipschitz bound ")#metadata(none) <tao-5e62e18bf834819fdafb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| \\partial_{h^y} \\eta \\right\\|_{\\ell^\\infty(G)} \\leq \\frac{1}{10^4 K^3}", block: true)]]

#text("for all ")#mi("{h \\in S}")#text(" and ")#mi("{y \\in A^4}")#text(".")

#text("Now we form the convolution ")#mi("{\\phi: G \\rightarrow {\\bf R}^+}")#text(" by the formula")

#tao-aligned(keep: true)[


#tao-math("\\phi(x)  & := \\frac{1}{\\left|A\\right|} \\sum_{y \\in G} \\psi(y) \\eta(y^{-1} x)", block: true)



#tao-math(" & = \\frac{1}{\\left|A\\right|} \\sum_{y \\in G} \\psi(x y) \\eta(y^{-1}).", block: true)
]

#text("By construction, ")#mi("{\\phi}")#text(" is supported on ")#mi("{A^4}")#text(" and at least ")#mi("{1}")#text(" at the identity. As ")#mi("{\\psi}")#text(" or ")#mi("{\\eta}")#text(" is supported in ")#mi("{A^2}")#text(", which has cardinality at most ")#tao-math("{K\\left|A\\right|}", block: false)#text(", we have the uniform bound ")#metadata(none) <tao-22f5d235af2327d24f95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| \\phi \\right\\|_{\\ell^\\infty(G)} \\leq K^2.", block: true)]]

#text("Similarly, from the identity")

#align(center)[#tao-fit-display[#tao-math("\\partial_g \\phi(x) = \\frac{1}{\\left|A\\right|} \\sum_{y \\in G} \\partial_g \\psi(y) \\eta(y^{-1} x)", block: true)]]

#text("and ")#link(<tao-19e322ebbd1a9bcfa748>)[#text("(7)")]#text(" we have the Lipschitz bound ")#metadata(none) <tao-a36bad8531df158821de>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| \\partial_g \\phi \\right\\|_{\\ell^\\infty(G)} \\leq K^2 M \\left\\|g\\right\\|_{e,A}.", block: true)]]

#text("Finally, from the identity")

#align(center)[#tao-fit-display[#tao-math("\\partial_h \\partial_g \\phi(x) = \\frac{1}{\\left|A\\right|} \\sum_{y \\in G} \\partial_g \\psi(y) \\partial_{h^y} \\eta(y^{-1} x)", block: true)]]

#text("and restricting ")#mi("{g}")#text(" to ")#mi("{A}")#text(" (so that ")#mi("{\\partial_g \\psi}")#text(" is supported on ")#mi("{A^4}")#text(", which has cardinality at most ")#tao-math("{K^3 \\left|A\\right|}", block: false)#text(") we see from ")#link(<tao-19e322ebbd1a9bcfa748>)[#text("(7)")]#text(", ")#link(<tao-5e62e18bf834819fdafb>)[#text("(8)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_h \\partial_g \\phi \\right\\|_{\\ell^\\infty(G)} \\leq \\frac{1}{10^4} M \\left\\|g\\right\\|_{e,A}", block: true)]]

#text("for ")#mi("{g \\in A}")#text(" and ")#mi("{h \\in S}")#text(".")

#text("We can use this to improve the bound ")#link(<tao-a36bad8531df158821de>)[#text("(10)")]#text(". Indeed, using the telescoping identity")

#align(center)[#tao-fit-display[#mitex("\\partial_{g^n} = n \\partial_g + \\sum_{i=0}^{n-1} \\partial_{g^i} \\partial_{g}")]]

#text("we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_g \\phi \\right\\|_{\\ell^\\infty(G)} \\leq \\frac{1}{n} \\left\\|\\partial_{g^n} \\phi \\right\\|_{\\ell^\\infty(G)} + \\frac{1}{n} \\sum_{i=0}^{n-1} \\left\\| \\partial_{g^i} \\partial_{g} \\phi \\right\\|_{\\ell^\\infty(G)}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_g \\phi \\right\\|_{\\ell^\\infty(G)} \\leq \\frac{1}{n} + \\frac{1}{10^4} M \\left\\|g\\right\\|_{e,A}", block: true)]]

#text("whenever ")#mi("{g,g^2,\\ldots,g^{n-1} \\in S}")#text(". Using the second trapping property, this implies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_g \\phi \\right\\|_{\\ell^\\infty(G)} \\leq (\\frac{1}{10^4} M + O_K(1)) \\left\\|g\\right\\|_{e,A}", block: true)]]

#text("In the converse direction, if ")#tao-math("{\\left\\| \\partial_g \\phi \\right\\|_{\\ell^\\infty(G)} <\\frac{1}{n}}", block: false)#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_{g^i} \\phi \\right\\|_{\\ell^\\infty(G)} < 1", block: true)]]

#text("and thus ")#mi("{g^i \\in A^4}")#text(" from the support of ")#mi("{\\phi}")#text(", for all ")#mi("{1 \\leq i \\leq n}")#text(". But then by the first trapping property, this implies that ")#mi("{g^i \\in A}")#text(" for all ")#mi("{1 \\leq i \\leq n/1000}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{e,A} \\leq 1000 \\left\\| \\partial_g \\phi \\right\\|_{\\ell^\\infty(G)}.", block: true)]]

#text("The triangle inequality for ")#tao-math("{\\left\\| \\partial_g \\phi \\right\\|_{\\ell^\\infty(G)}}", block: false)#text(" then implies a triangle inequality for ")#tao-math("{\\left\\|g\\right\\|_{e,A}}", block: false)#text(",")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g_1 \\ldots g_k \\right\\|_{e,A} \\leq (\\frac{1}{10} M + O_K(1)) (\\left\\|g_1\\right\\|_{e,A}+\\ldots+\\left\\|g_k\\right\\|_{e,A}),", block: true)]]

#text("which is ")#link(<tao-862da37a227307662ac8>)[#text("(5)")]#text(" with ")#mi("{M}")#text(" replaced by ")#mi("{\\frac{1}{10} M + O_K(1)}")#text(". If we knew ")#link(<tao-862da37a227307662ac8>)[#text("(5)")]#text(" for some large but finite ")#mi("{M}")#text(", we could iterate this argument and conclude that ")#link(<tao-862da37a227307662ac8>)[#text("(5)")]#text(" held with ")#mi("{M}")#text(" replaced by ")#mi("{O_K(1)}")#text(", which would give the triangle inequality. Now it is not immediate that ")#link(<tao-862da37a227307662ac8>)[#text("(5)")]#text(" holds for any finite ")#mi("{M}")#text(", but we can avoid this problem with the usual regularisation trick of replacing ")#tao-math("{\\left\\|g\\right\\|_{e,A}}", block: false)#text(" with ")#tao-math("{\\left\\|g\\right\\|_{e,A}+\\epsilon}", block: false)#text(" throughout the argument for some small ")#mi("{\\epsilon>0}")#text(", which makes ")#link(<tao-862da37a227307662ac8>)[#text("(5)")]#text(" automatically true with ")#mi("{M=O(1/\\epsilon)}")#text(", run the above iteration argument, and then finally send ")#mi("{\\epsilon}")#text(" to zero.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Verify that the modifications to the above argument sketched above actually do establish the triangle inequality.")
]

#text("A final application of the Gleason convolution machinery then gives the final estimate in Gleason’s lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Use the properties of the escape norm already established (and in particular, the escape property and the triangle inequality) to establish the commutator inequality. (")#emph[#text("Hint:")]#text(" adapt the argument from Section 2 of ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(".)")
]

#text("The proof of Theorem ")#link(<tao-1a916a1070c99ec124f1>)[#text("2")]#text(" is now complete.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Generalise Theorem ")#link(<tao-1a916a1070c99ec124f1>)[#text("2")]#text(" to the setting where ")#mi("{A}")#text(" is not necessarily finite, but is instead an open precompact subset of a locally compact group ")#mi("{G}")#text(". (")#emph[#text("Hint:")]#text(" replace cardinality by left-invariant Haar measure and follow the arguments in ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(" closely.) Note that this already gives most of one of the key results from that set of notes, namely that any NSS group admits a Gleason metric, since it is not difficult to show that NSS groups contain open precompact strong approximate groups.")
]

#heading(level: 1)[#strong[#text(" — 2. A cheap version of the structure theorem — ")]]

#text("In this section we use Theorem ")#link(<tao-1a916a1070c99ec124f1>)[#text("2")]#text(" to establish a “cheap” version of the structure theorem for ultra approximate groups. We begin by eliminating the elements of zero escape norm. Let us say that an approximate group ")#mi("{A}")#text(" is ")#emph[#text("NSS")]#text(" if it contains no non-trivial subgroups of the ambient group, or equivalently if every non-identity element of ")#mi("{A}")#text(" has a positive escape norm. We say that an ultra approximate group is ")#emph[#text("NSS")]#text(" if it is the ultralimit of NSS approximate groups.")

#text("Using the Gleason lemma, we can easily reduce to the NSS case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Reduction to the NSS case)")]#text(" ")#metadata(none) <tao-2ecf0a10c349176e1fa1>#text(" Let ")#mi("{L}")#text(" be a connected Lie group with Lie algebra ")#mi("{{\\mathfrak l}}")#text(", let ")#mi("{B}")#text(" be a bounded symmetric convex body in ")#mi("{{\\mathfrak l}}")#text(", let ")#mi("{r>0}")#text(" be a sufficiently small standard real. Let ")#mi("{0 < r^{\\prime} < r/2}")#text(", and let ")#mi("{A}")#text(" be an ultra strong approximate group which has a good model ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\pi^{-1}(\\exp(rB)) \\subset A \\subset \\pi^{-1}(\\exp(1.1 rB)).")]]

#text("Let ")#mi("{H}")#text(" be the set of all elements in ")#mi("{A}")#text(" of zero (nonstandard) escape norm. Show that ")#mi("{H}")#text(" is a normal nonstandard finite subgroup of ")#mi("{\\langle A \\rangle}")#text(" that lies in ")#mi("{\\text{ker}(\\pi)}")#text(". If ")#mi("{\\eta: \\langle A \\rangle \\rightarrow \\langle A \\rangle/H}")#text(" is the quotient map, and ")#mi("{\\pi^{\\prime}: \\langle A\\rangle/H \\rightarrow L}")#text(" is the map ")#mi("{\\pi}")#text(" factored through ")#mi("{\\eta}")#text(", show that there exists an ultra strong NSS approximate group ")#mi("{A^{\\prime}}")#text(" in ")#mi("{\\eta(A)}")#text(" which has ")#mi("{\\pi^{\\prime}}")#text(" as a good model with")

#align(center)[#tao-fit-display[#mitex("(\\pi^{\\prime})^{-1}(\\exp(r^{\\prime}B)) \\subset A^{\\prime} \\subset (\\pi^{\\prime})^{-1}(\\exp(1.1 r^{\\prime}B)),")]]

#text("and such that ")#mi("{A}")#text(" is covered by finitely many left-translates of ")#mi("{\\pi^{-1}(A^{\\prime})}")#text(".")
]

#text("Let us now analyse the NSS case. Let ")#mi("{L}")#text(" be a connected Lie group, with Lie algebra ")#mi("{{\\mathfrak l}}")#text(", let ")#mi("{B}")#text(" be a bounded symmetric convex body in ")#mi("{{\\mathfrak l}}")#text(", let ")#mi("{r>0}")#text(" be a sufficiently small standard real. Let ")#mi("{A}")#text(" be an ultra strong NSS approximate group which has a good model ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\pi^{-1}(\\exp(rB)) \\subset A \\subset \\pi^{-1}(\\exp(1.1 rB)).")]]

#text("If ")#mi("{L}")#text(" is zero-dimensional, then by connectedness it is trivial, and then (by the properties of a good model) ")#mi("{A}")#text(" is a nonstandard finite group; since it is NSS, it is also trivial. Now suppose that ")#mi("{L}")#text(" is not zero-dimensional. Then ")#mi("{A}")#text(" contains non-identity elements whose image under ")#mi("{\\pi}")#text(" is arbitrarily close to the identity of ")#mi("{L}")#text("; in particular, ")#mi("{A}")#text(" does not consist solely of the identity element, and thus contains elements of positive escape norm by the NSS assumption. Let ")#mi("{g}")#text(" be a non-identity element of ")#mi("{G}")#text(" with minimal escape norm ")#tao-math("{\\left\\| u \\right\\|_{e,A}}", block: false)#text(", then ")#mi("{\\pi(u)}")#text(" must be the identity (so in particular ")#tao-math("{\\left\\|u\\right\\|_{e,A}}", block: false)#text(" is infinitesimal). (Note that any non-trivial NSS finite approximate group will contain non-identity elements of minimal escape norm, and the extension of this claim to the ultra approximate group case follows from Los’s theorem.) From Theorem ")#link(<tao-1a916a1070c99ec124f1>)[#text("2")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| [u,h] \\right\\|_{e,A} \\ll \\left\\| u \\right\\|_{e,A} \\left\\| h \\right\\|_{e,A}", block: true)]]

#text("for all ")#mi("{h \\in A}")#text(". (Here we are now using the nonstandard asymptotic notation, thus ")#mi("{X \\ll Y}")#text(" means that ")#mi("{X \\leq CY}")#text(" for some standard ")#mi("{C}")#text(".) In particular, from the minimality of ")#tao-math("{\\left\\|u\\right\\|_{e,A}}", block: false)#text(", we see that there is a standard ")#mi("{c>0}")#text(" such that ")#mi("{u}")#text(" commutes with all elements ")#mi("{h}")#text(" with ")#tao-math("{\\left\\|h\\right\\|_{e,A} < c}", block: false)#text(". In particular, if ")#mi("{r^{\\prime} > 0}")#text(" is a sufficiently small standard real number, we can find an ultra approximate subgroup ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\pi^{-1}(\\exp(r^{\\prime}B)) \\subset A^{\\prime} \\subset \\pi^{-1}(\\exp(1.1 r^{\\prime}B))")]]

#text("which is centralised by ")#mi("{u}")#text(".")

#text("Now we show that ")#mi("{u}")#text(" generates a one-parameter subgroup of the model Lie group ")#mi("{L}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (One-parameter subgroups from orbits)")]#text(" ")#metadata(none) <tao-f2898d9badaef8c18cde>#text(" Let the notation be as above. Let ")#mi("{g \\in A}")#text(" be such that ")#tao-math("{\\left\\|g\\right\\|_{e,A}}", block: false)#text(" is infinitesimal but non-zero.")

#list(
[#text("Show that ")#mi("{\\pi(g^i)=1}")#text(" whenever ")#tao-math("{i = o(1/\\left\\|g\\right\\|_{e,A})}", block: false)#text(".")],
[#text("Show that the map ")#tao-math("{t \\mapsto \\pi( g^{\\lfloor t / \\left\\|g\\right\\|_{e,A}} )}", block: false)#text(" is a one-parameter subgroup in ")#mi("{L}")#text(" (i.e. a continuous homomorphism from ")#mi("{{\\bf R}}")#text(" to ")#mi("{L}")#text(").")],
[#text("Show that there exists an element ")#mi("{X}")#text(" of ")#mi("{1.1 rB \\backslash rB}")#text(" such that ")#tao-math("{\\pi(g^i) = \\exp( \\text{st}(i \\left\\|g\\right\\|_{e,A}) X )}", block: false)#text(" for all ")#tao-math("{i = O(1/\\left\\|g\\right\\|_{e,A})}", block: false)#text(".")]
)

#text("Similar statements hold with ")#mi("{A}")#text(", ")#mi("{r}")#text(" replaced by ")#mi("{A^{\\prime}, r^{\\prime}}")#text(".")
]

#text("We can now quotient out by the centraliser of ")#mi("{u}")#text(" and reduce the dimension of the Lie model:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{Z(u) := \\{ h \\in {}^* G: uh = hu \\}}")#text(" be the centraliser of ")#mi("{u}")#text(" in ")#mi("{{}^* G}")#text(", and let ")#mi("{H := \\{ u^n: n \\in {}^* {\\bf Z}\\}}")#text(" be the nonstandard cyclic group generated by ")#mi("{u}")#text(". (Thus, by the preceding discussion, ")#mi("{Z(u)}")#text(" contains ")#mi("{A^{\\prime}}")#text(", and ")#mi("{H}")#text(" is a central subgroup of ")#mi("{Z(u)}")#text(" containing ")#mi("{u}")#text(". It will be important for us that ")#mi("{Z(u)}")#text(" and ")#mi("{H}")#text(" are both nonstandard sets, i.e. ultraproducts of standard sets.)")

#list(
[#text("(i) Show that ")#mi("{\\pi( H \\cap A^m )}")#text(" is a compact subset of ")#mi("{L}")#text(" for each standard ")#mi("{m}")#text(".")],
[#text("(ii) Show that ")#mi("{\\pi(H \\cap \\langle A \\rangle)}")#text(" is a central subgroup of ")#mi("{L}")#text(" that contains ")#mi("{\\phi({\\bf R})}")#text(".")],
[#text("(iii) Show that ")#mi("{\\overline{\\pi(H \\cap \\langle A \\rangle)}}")#text(" is a central subgroup of ")#mi("{L}")#text(" that is a Lie group of dimension at least one, and so the quotient group ")#mi("{L^{\\prime} := L/\\overline{\\pi(H \\cap \\langle A \\rangle)}}")#text(" is a Lie group of dimension strictly less than the dimension of ")#mi("{L}")#text(".")],
[#text("(iv) Let ")#mi("{\\eta: Z(u) \\rightarrow Z(u) / H}")#text(" be the quotient map, and let ")#mi("{\\pi^{\\prime}: \\eta(\\langle A^{\\prime} \\rangle) \\rightarrow L^{\\prime}}")#text(" be the obvious quotient of ")#mi("{\\pi}")#text(". Let ")#mi("{B^{\\prime}}")#text(" be a convex symmetric body in the Lie algebra ")#mi("{{\\mathfrak l}^{\\prime}}")#text(" of ")#mi("{L}")#text(". Show that for sufficiently small standard ")#mi("{r^{\\prime\\prime} > 0}")#text(", there exists an ultra strong approximate group")

#align(center)[#tao-fit-display[#mitex("(\\pi^{\\prime})^{-1}(\\exp(r^{\\prime\\prime}B)) \\subset A^{\\prime\\prime} \\subset (\\pi^{\\prime})^{-1}(\\exp(1.1 r^{\\prime\\prime}B))")]]

#text("with ")#mi("{\\pi^{\\prime}}")#text(" as a good model, with ")#mi("{A^{\\prime\\prime} \\subset \\eta(A^{\\prime})}")#text(", and with ")#mi("{\\pi^{\\prime}(A^{\\prime})}")#text(" covered by finitely many left-translates of ")#mi("{A^{\\prime\\prime}}")#text(".")]
)
]

#text("Note that the quotient approximate group ")#mi("{A^{\\prime\\prime}}")#text(" obtained by the above procedure is not necessarily NSS. However, it can be made NSS by Exercise ")#link(<tao-2ecf0a10c349176e1fa1>)[#text("6")]#text(". As such, one can iterate the above exercise until the dimension of the Lie model shrinks all the way to zero, at which point the NSS approximate group one is working with becomes trivial. This leads to a “cheap” structure theorem for approximate groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Cheap structure theorem)")]#text(" ")#metadata(none) <tao-0c706679d12b6123dac1>#text(" Let ")#mi("{A}")#text(" be an ultra approximate group in a nonstandard group ")#mi("{G}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{A}")#text(" has a good model by a connected Lie group ")#mi("{L}")#text(", then ")#mi("{L}")#text(" is nilpotent. (")#emph[#text("Hint:")]#text(" first use Exercise ")#link(<tao-cc9103a8b19f9e9f68fc>)[#text("1")]#text(", and then induct on the dimension of ")#mi("{L}")#text(".)")],
[#text("(ii) Show that ")#mi("{A}")#text(" is covered by finitely many left translates of a nonstandard subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" which admits a ")#link("http://en.wikipedia.org/wiki/Subgroup_series")[#text("normal series")]

#align(center)[#tao-fit-display[#mitex("G^{\\prime} = G^{\\prime}_0 \\rhd G^{\\prime}_1 \\rhd G^{\\prime}_2 \\rhd \\ldots \\rhd G^{\\prime}_k = \\{1\\}")]]

#text("for some standard ")#mi("{k}")#text(", where for every ")#mi("{0 \\leq i < k}")#text(", ")#mi("{G^{\\prime}_{i+1}}")#text(" is a normal nonstandard subgroup of ")#mi("{G^{\\prime}_i}")#text(", and ")#mi("{G^{\\prime}_i/G^{\\prime}_{i+1}}")#text(" is either a nonstandard finite group or a nonstandard central subgroup of ")#mi("{G^{\\prime}/G^{\\prime}_{i+1}}")#text(". Furthermore, if ")#mi("{G^{\\prime}_i/G^{\\prime}_{i+1}}")#text(" is not central, then it is contained in the image of ")#mi("{A^4 \\cap G^{\\prime}}")#text(" in ")#mi("{G^{\\prime}/G^{\\prime}_{i+1}}")#text(". (")#emph[#text("Hint:")]#text(" first use the Lie model theorem and Exercise ")#link(<tao-cc9103a8b19f9e9f68fc>)[#text("1")]#text(", and then induct on the dimension of ")#mi("{L}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Cheap structure theorem, finite version)")]#text(" Let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate group in a group ")#mi("{G}")#text(". Show that ")#mi("{A}")#text(" is covered by ")#mi("{O_K(1)}")#text(" left-translates of a subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" which admits a normal series")

#align(center)[#tao-fit-display[#mitex("G^{\\prime} = G^{\\prime}_0 \\rhd G^{\\prime}_1 \\rhd G^{\\prime}_2 \\rhd \\ldots \\rhd G^{\\prime}_k = \\{1\\}")]]

#text("for some ")#mi("{k=O_K(1)}")#text(", where for every ")#mi("{0 \\leq i < k}")#text(", ")#mi("{G^{\\prime}_{i+1}}")#text(" is a normal subgroup of ")#mi("{G^{\\prime}_i}")#text(", and ")#mi("{G^{\\prime}_i/G^{\\prime}_{i+1}}")#text(" is either finite or central in ")#mi("{G^{\\prime}/G^{\\prime}_{i+1}}")#text(". Furthermore, if ")#mi("{G^{\\prime}_i/G^{\\prime}_{i+1}}")#text(" is not central, then it is contained in the image of ")#mi("{A^4 \\cap G^{\\prime}}")#text(" in ")#mi("{G^{\\prime}/G^{\\prime}_{i+1}}")#text(".")
]

#text("One can push the cheap structure theorem a bit further by controlling the dimension of the nilpotent Lie group in terms of the covering number ")#mi("{K}")#text(" of the ultra approximate group, as laid out in the following exercise.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Nilpotent groups)")]#text(" A Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is said to be ")#emph[#text("nilpotent")]#text(" if the derived series ")#mi("{{\\mathfrak g}_1 := {\\mathfrak g}}")#text(", ")#mi("{{\\mathfrak g}_2 := [{\\mathfrak g}_1, {\\mathfrak g}]}")#text(", ")#mi("{{\\mathfrak g}_3 := [{\\mathfrak g}_2, {\\mathfrak g}], \\ldots}")#text(" becomes trivial after a finite number of steps.")

#list(
[#text("(i) Show that a connected Lie group is nilpotent if and only if its Lie algebra is nilpotent.")],
[#text("(ii) If ")#mi("{{\\mathfrak g}}")#text(" is a finite-dimensional nilpotent Lie algebra, show that there is a simply connected Lie group ")#mi("{G}")#text(" with Lie algebra ")#mi("{{\\mathfrak g}}")#text(", for which the exponential map ")#mi("{\\exp: {\\mathfrak g} \\rightarrow G}")#text(" is a (global) homeomorphism. Furthermore, any other connected Lie group with Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is a quotient of ")#mi("{G}")#text(" by a discrete central subgroup of ")#mi("{G}")#text(".")],
[#text("(iii) If ")#mi("{{\\mathfrak g}}")#text(" and ")#mi("{G}")#text(" are as in (ii), show that the pushforward of a Haar measure (or Lebesgue measure) on ")#mi("{{\\mathfrak g}}")#text(" is a bi-invariant Haar measure on ")#mi("{G}")#text(". (Recall from Exercise 6 of ")#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("Notes 3")]#text(" that connected nilpotent Lie groups are unimodular.)")],
[#text("(iv) If ")#mi("{{\\mathfrak g}}")#text(" and ")#mi("{G}")#text(" are as in (ii), and ")#mi("{\\mu}")#text(" is a bi-invariant Haar measure on ")#mi("{G}")#text(", show that ")#mi("{\\mu(A^2) \\geq 2^d \\mu(A)}")#text(" for all open precompact ")#mi("{A \\subset G}")#text(", where ")#mi("{d}")#text(" is the dimension of ")#mi("{G}")#text(".")],
[#text("(v) If ")#mi("{\\tilde G}")#text(" is a connected (but not necessarily simply connected) nilpotent Lie group, and ")#mi("{N}")#text(" is the maximal compact normal subgroup of ")#mi("{G}")#text(" (which exists by Exercise 32 of ")#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("Notes 7")]#text("), show that ")#mi("{N}")#text(" is central, and ")#mi("{\\tilde G/N}")#text(" is simply connected. As a consequence, conclude that if ")#mi("{\\tilde \\mu}")#text(" is a left-Haar measure of ")#mi("{\\tilde G}")#text(", then ")#mi("{\\tilde \\mu(\\tilde A^2) \\geq 2^d \\tilde \\mu(\\tilde A)}")#text(" for all open precompact ")#mi("{\\tilde A \\subset \\tilde G}")#text(", where ")#mi("{d}")#text(" is the dimension of ")#mi("{G/N}")#text(".")],
[#text("(vi) Show that if ")#mi("{A}")#text(" is an ultra ")#mi("{K}")#text("-approximate group which has a Lie model ")#mi("{L}")#text(", and ")#mi("{N}")#text(" is the maximal compact normal subgroup of ")#mi("{L}")#text(", then ")#mi("{L/N}")#text(" has dimension at most ")#mi("{\\log_2 K}")#text(".")],
[#text("(vii) Show that if ")#mi("{A}")#text(" is an ultra ")#mi("{K}")#text("-approximate group, then there is an ultra ")#mi("{K^{O(1)}}")#text("-approximate group ")#mi("{A^{\\prime}}")#text(" in ")#mi("{A^4}")#text(" that is modeled by a Lie group ")#mi("{L}")#text(", such that ")#mi("{A}")#text(" is covered by finitely many left-translates of ")#mi("{A}")#text(". (")#emph[#text("Hint:")]#text(" ")#mi("{A^4}")#text(" has a good model ")#mi("{\\pi: A^4 \\rightarrow G}")#text(" by a locally compact group ")#mi("{G}")#text("; by the Gleason-Yamabe theorem, ")#mi("{G}")#text(" has an open subgroup ")#mi("{G^{\\prime}}")#text(" and a normal subgroup ")#mi("{N}")#text(" of ")#mi("{G^{\\prime}}")#text(" inside ")#mi("{\\pi(A^4)}")#text(" with ")#mi("{G^{\\prime}/N}")#text(" a Lie group. Set ")#mi("{A^{\\prime} := A^4 \\cap \\pi^{-1}(G^{\\prime})}")#text(".)")],
[#text("(viii) Show that if ")#mi("{A}")#text(" is an ultra ")#mi("{K}")#text("-approximate group, then there is an ultra ")#mi("{K^{O(1)}}")#text("-approximate group ")#mi("{A^{\\prime\\prime}}")#text(" in ")#mi("{A^{O(1)}}")#text(" that is modeled by a nilpotent group of dimension ")#mi("{O(\\log K)}")#text(", such that ")#mi("{A}")#text(" can be covered by finitely many left-translates of ")#mi("{A}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Local groups — ")]]

#text("The main weakness of the cheap structure theorem in the preceding section is the continual reintroduction of torsion whenever one quotients out by the centraliser ")#mi("{Z(u)}")#text(", which can destroy the NSS property. We now address the issue of how to fix this, by moving to the context of local groups rather than global groups. We will omit some details, referring to ")#link("http://arxiv.org/abs/1110.5008")[#text("this recent paper")]#text(" for details.")

#text("We need to extend many of the notions we have been considering to the local group setting. We begin by generalising the concept of an approximate group.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Approximate groups)")]#text(" A (local) ")#emph[#mi("{K}")#text("-approximate group")]#text(" is a subset ")#mi("{A}")#text(" of a local group ")#mi("{G}")#text(" which is symmetric and contains the identity, such that ")#mi("{A^{200}}")#text(" is well-defined in ")#mi("{G}")#text(", and for which ")#mi("{A^2}")#text(" is covered by ")#mi("{K}")#text(" left translates of ")#mi("{A}")#text(" (by elements in ")#mi("{A^3}")#text("). An ")#emph[#text("ultra approximate group")]#text(" is an ultraproduct ")#mi("{A = \\prod_{n \\rightarrow \\alpha} A_n}")#text(" of ")#mi("{K}")#text("-approximate groups.")
]

#text("Note that we make no topological requirements on ")#mi("{A}")#text(" or ")#mi("{G}")#text(" in this definition; in particular, we may as well give the local group ")#mi("{G}")#text(" the discrete topology. There are some minor technical advantages in requiring the local group to be symmetric (so that the inversion map is globally defined) and cancellative (so that ")#mi("{gh = gk}")#text(" or ")#mi("{hg=kg}")#text(" implies ")#mi("{h=k}")#text("), although these assumptions are essentially automatic in practice.")

#text("The exponent ")#mi("{200}")#text(" here is not terribly important in practice, thanks to the following variant of the Sanders lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate group in a local group ")#mi("{G}")#text(", except with only ")#mi("{A^8}")#text(" known to be well-defined rather than ")#mi("{A^{200}}")#text(". Let ")#mi("{m \\geq 1}")#text(". Show that there exists a finite ")#mi("{O_{K,m}(1)}")#text("-approximate subgroup ")#mi("{A^{\\prime}}")#text(" in ")#mi("{G}")#text(" with ")#mi("{(A^{\\prime})^m}")#text(" well-defined and contained in ")#mi("{A^4}")#text(", and with ")#mi("{A}")#text(" covered by ")#mi("{O_{K,m}(1)}")#text(" left-translates of ")#mi("{A^{\\prime}}")#text(" (by elements in ")#mi("{A^5}")#text("). (")#emph[#text("Hint:")]#text(" adapt the proof of Lemma 1 from ")#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/")[#text("Notes 7")]#text(".)")
]

#text("Just as global approximate groups can be modeled by global locally compact groups (and in particular, global Lie groups), local approximate groups can be modeled by local locally compact groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Good models)")]#text(" Let ")#mi("{A}")#text(" be a (local) ultra approximate group. A (local) ")#emph[#text("good model")]#text(" for ")#mi("{A}")#text(" is a homomorphism ")#mi("{\\pi: A^8 \\rightarrow L}")#text(" from ")#mi("{A^8}")#text(" to a locally compact Hausdorff local group ")#mi("{L}")#text(" that obeys the following axioms:")

#list(
[#text("(Thick image) There exists a neighbourhood ")#mi("{U_0}")#text(" of the identity in ")#mi("{L}")#text(" such that ")#mi("{\\pi^{-1}(U_0) \\subset A}")#text(" and ")#mi("{U_0 \\subset \\pi(A)}")#text(".")],
[#text("(Compact image) ")#mi("{\\pi(A)}")#text(" is precompact.")],
[#text("(Approximation by nonstandard sets) Suppose that ")#mi("{F \\subset U \\subset U_0}")#text(", where ")#mi("{F}")#text(" is compact and ")#mi("{U}")#text(" is open. Then there exists a nonstandard finite set ")#mi("{B}")#text(" such that ")#mi("{\\pi^{-1}(F) \\subset B \\subset \\pi^{-1}(U)}")#text(".")]
)
]

#text("We make the pedantic remark that with our conventions, a global good model ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L}")#text(" of a global approximate group only becomes a local good model of ")#mi("{A}")#text(" by ")#mi("{L}")#text(" after restricting the domain of ")#mi("{\\pi}")#text(" to ")#mi("{A^8}")#text(". It is also convenient for minor technical reasons to assume that the local group ")#mi("{L}")#text(" is symmetric (i.e. the inversion map is globally defined) but this hypothesis is not of major importance.")

#text("The Hrushovski Lie Model theorem can be localised:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Local Hrushovski Lie model theorem)")]#text(" Let ")#mi("{A}")#text(" be a (local) ultra approximate group. Then there is an ultra approximate subgroup ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" (thus ")#mi("{(A^{\\prime})^4 \\subset A^4}")#text(") with ")#mi("{A}")#text(" covered by finitely many left-translates of ")#mi("{A^{\\prime}}")#text(" (by elements in ")#mi("{A \\cdot (A^{\\prime})^{-1}}")#text("), which has a good model by a connected local Lie group ")#mi("{L}")#text(".")
]

#text("The proof of this theorem is basically a localisation of the proof of the global Lie model theorem from ")#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/")[#text("Notes 7")]#text(", and is omitted (see ")#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/\\href")[#text("\\href")]#text(" for details). One key replacement is that if ")#mi("{A}")#text(" is a local approximate group rather than a global one, then the global Gleason-Yamabe theorem (Theorem 1 from ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(") must be replaced by the local Gleason-Yamabe theorem of Goldbring, discussed in Section 6 of ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(".")

#text("One can define the notion of a strong ")#mi("{K}")#text("-approximate group and ultra strong approximate group in the local setting without much difficulty, since strong approximate groups only need to work inside ")#mi("{A^{100}}")#text(", which is well-defined. Using the local Lie model theorem, one can obtain a local version of Exercise ")#link(<tao-cc9103a8b19f9e9f68fc>)[#text("1")]#text(". The Gleason lemma (Theorem ")#link(<tao-1a916a1070c99ec124f1>)[#text("2")]#text(") also localises without much difficulty to local strong approximate groups, as does the reduction to the NSS case in Exercise ")#link(<tao-2ecf0a10c349176e1fa1>)[#text("6")]#text(".")

#text("Now we once again analyse the NSS case. As before, let ")#mi("{L}")#text(" be a connected (local) Lie group, with Lie algebra ")#mi("{{\\mathfrak l}}")#text(", let ")#mi("{B}")#text(" be a bounded symmetric convex body in ")#mi("{{\\mathfrak l}}")#text(", let ")#mi("{r>0}")#text(" be a sufficiently small standard real. Let ")#mi("{A}")#text(" be a (local) ultra strong NSS approximate group which has a (local) good model ")#mi("{\\pi: \\langle A \\rangle \\rightarrow L}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\pi^{-1}(\\exp(rB)) \\subset A \\subset \\pi^{-1}(\\exp(1.1 rB)).")]]

#text("Again, we assume ")#mi("{L}")#text(" has dimension at least ")#mi("{1}")#text(", since ")#mi("{A}")#text(" is trivial otherwise. We let ")#mi("{u}")#text(" be a non-identity element of minimal escape norm. As before, ")#mi("{u}")#text(" will have an infinitesimal escape norm and lie in the kernel of ")#mi("{\\pi}")#text(". If we set ")#tao-math("{N := \\left\\|u\\right\\|_{e,A}}", block: false)#text(", then ")#mi("{N}")#text(" is an unbounded natural number, and the map ")#mi("{\\phi: t \\mapsto \\pi(g^{\\lfloor tN\\rfloor})}")#text(" will be a local one-parameter subgroup, i.e. a continuous homomorphism from ")#mi("{[-1,1]}")#text(" to ")#mi("{L}")#text(". This one-parameter subgroup will be non-trivial and centralised by a neighbourhood of the identity in ")#mi("{L}")#text(".")

#text("In the global setting, we quotiented (the group generated by a large portion of) ")#mi("{A}")#text(" by the centraliser ")#mi("{Z(u)}")#text(" of ")#mi("{u}")#text(". In the local setting, we perform a more “gentle” quotienting, which roughly speaking arises by quotienting ")#mi("{A}")#text(" by the geometric progression ")#mi("{P := \\{ u^n: -cN \\leq n \\leq cN \\}}")#text(", where ")#mi("{c>0}")#text(" is a sufficiently small standard quantity to be chosen later. However, ")#mi("{P}")#text(" is only a local group rather than a global one, and so we must now digress to introduce the notion of quotients of local groups. It is convenient to restrict attention to symmetric cancellative local groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Cancellative local groups)")]#text(" ")#metadata(none) <tao-38de1aee1586090994e8>#text(" A local group ")#mi("{G}")#text(" is ")#emph[#text("symmetric")]#text(" if the inversion operation is globally defined. It is said to be ")#emph[#text("cancellative")]#text(" if the following assertions hold:")

#list(
[#text("(i) Whenever ")#mi("{g,h,k \\in G}")#text(" are such that ")#mi("{gh}")#text(" and ")#mi("{gk}")#text(" are well-defined and equal to each other, then ")#mi("{h=k}")#text(". (Note that this implies in particular that ")#mi("{(g^{-1})^{-1} = g}")#text(".)")],
[#text("(ii) Whenever ")#mi("{g,h,k \\in G}")#text(" are such that ")#mi("{hg}")#text(" and ")#mi("{kg}")#text(" are well-defined and equal to each other, then ")#mi("{h=k}")#text(".")],
[#text("(iii) Whenever ")#mi("{g,h \\in G}")#text(" are such that ")#mi("{gh}")#text(" and ")#mi("{h^{-1}g^{-1}}")#text(" are well-defined, then ")#mi("{(gh)^{-1} = h^{-1}g^{-1}}")#text(". (In particular, if ")#mi("{U \\subset G}")#text(" is symmetric and ")#mi("{U^m}")#text(" is well-defined in ")#mi("{G}")#text(" for some ")#mi("{m \\geq 1}")#text(", then ")#mi("{U^m}")#text(" is also symmetric.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Show that every local group contains an open neighbourhood of the identity which is also a symmetric cancellative local group.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7 (Sub-local groups)")]#text(" Given two symmetric local groups ")#mi("{G^{\\prime}}")#text(" and ")#mi("{G}")#text(", we say that ")#mi("{G^{\\prime}}")#text(" is a ")#emph[#text("sub-local group")]#text(" of ")#mi("{G}")#text(" if ")#mi("{G^{\\prime}}")#text(" is the restriction of ")#mi("{G}")#text(" to a symmetric neighbourhood of the identity, and there exists an open neighbourhood ")#mi("{V}")#text(" of ")#mi("{G^{\\prime}}")#text(" with the property that whenever ")#mi("{g, h \\in G^{\\prime}}")#text(" are such that ")#mi("{gh}")#text(" is defined in ")#mi("{V}")#text(", then ")#mi("{gh \\in G^{\\prime}}")#text("; we refer to ")#mi("{V}")#text(" as an ")#emph[#text("associated neighbourhood")]#text(" for ")#mi("{G^{\\prime}}")#text(". If ")#mi("{G^{\\prime}}")#text(" is also a global group, we say that ")#mi("{G^{\\prime}}")#text(" is a ")#emph[#text("subgroup")]#text(" of ")#mi("{G}")#text(".")

#text("If ")#mi("{G^{\\prime}}")#text(" is a sub-local group of ")#mi("{G}")#text(", we say that ")#mi("{G^{\\prime}}")#text(" is ")#emph[#text("normal")]#text(" if there exists an associated neighbourhood ")#mi("{V}")#text(" for ")#mi("{G^{\\prime}}")#text(" with the additional property that whenever ")#mi("{g^{\\prime} \\in G^{\\prime}, h \\in V}")#text(" are such that ")#mi("{h g^{\\prime} h^{-1}}")#text(" is well-defined and lies in ")#mi("{V}")#text(", then ")#mi("{hg^{\\prime}h^{-1} \\in G^{\\prime}}")#text(". We call ")#mi("{V}")#text(" a ")#emph[#text("normalising neighbourhood")]#text(" of ")#mi("{G^{\\prime}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" If ")#mi("{G, G^{\\prime}}")#text(" are the (additive) local groups ")#mi("{G := \\{-2,-1,0,+1,+2\\}}")#text(" and ")#mi("{G^{\\prime} := \\{-1,0,+1\\}}")#text(", then ")#mi("{G^{\\prime}}")#text(" is a sub-local group of ")#mi("{G}")#text(" (with associated neighbourhood ")#mi("{V = G^{\\prime}}")#text("). Note that this is despite ")#mi("{G^{\\prime}}")#text(" not being closed with respect to addition in ")#mi("{G}")#text("; thus we see why it is necessary to allow the associated neighbourhood ")#mi("{V}")#text(" to be strictly smaller than ")#mi("{G}")#text(". In a similar vein, the open interval ")#mi("{(-1,1)}")#text(" is a sub-local group of ")#mi("{(-2,2)}")#text(".")

#text("The interval ")#mi("{(-1,1) \\times \\{0\\}}")#text(" is also a sub-local group of ")#mi("{{\\bf R}^2}")#text("; here, one can take for instance ")#mi("{(-1,1)^2}")#text(" as the associated neighbourhood. As all these examples are abelian, they are clearly normal.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" Let ")#mi("{T: V \\rightarrow V}")#text(" be a linear transformation on a finite-dimensional vector space ")#mi("{V}")#text(", and let ")#mi("{G := {\\bf Z} \\ltimes_T V}")#text(" be the associated semi-direct product. Let ")#mi("{G^{\\prime} := \\{0\\} \\times W}")#text(", where ")#mi("{W}")#text(" is a subspace of ")#mi("{V}")#text(" that is not preserved by ")#mi("{T}")#text(". Then ")#mi("{G^{\\prime}}")#text(" is not a normal subgroup of ")#mi("{G}")#text(", but it is a normal sub-local group of ")#mi("{G}")#text(", where one can take ")#mi("{\\{0\\} \\times V}")#text(" as a normalising neighbourhood of ")#mi("{G^{\\prime}}")#text(".")
]

#text("Observe that any sub-local group of a cancellative local group is again a cancellative local group.")

#text("One also easily verifies that if ")#mi("{\\phi: U \\rightarrow H}")#text(" is a local homomorphism from ")#mi("{G}")#text(" to ")#mi("{H}")#text(" for some open neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(", then ")#mi("{\\ker(\\phi)}")#text(" is a normal sub-local group of ")#mi("{U}")#text(", and hence of ")#mi("{G}")#text(". Note that the kernel of a local morphism is well-defined up to local identity. If ")#mi("{H}")#text(" is Hausdorff, then the kernel ")#mi("{\\ker(\\phi)}")#text(" will also be closed.")

#text("Conversely, normal sub-local groups give rise to local homomorphisms into quotient spaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Quotient spaces)")]#text(" ")#metadata(none) <tao-d861ee362e3823440ae6>#text(" Let ")#mi("{G}")#text(" be a cancellative local group, and let ")#mi("{H}")#text(" be a normal sub-local group with normalising neighbourhood ")#mi("{V}")#text(". Let ")#mi("{W}")#text(" be a symmetric open neighbourhood of the identity such that ")#mi("{W^6 \\subset V}")#text(". Show that there exists a cancellative local group ")#mi("{W/H}")#text(" and a surjective continuous homomorphism ")#mi("{\\phi: W \\rightarrow W/H}")#text(" such that, for any ")#mi("{g, h \\in W}")#text(", one has ")#mi("{\\phi(g)=\\phi(h)}")#text(" if and only if ")#mi("{gh^{-1} \\in H}")#text(", and for any ")#mi("{E \\subset W/H}")#text(", one has ")#mi("{E}")#text(" open if and only if ")#mi("{\\phi^{-1}(E)}")#text(" is open.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" Let ")#mi("{G}")#text(" be the additive local group ")#mi("{G := (-2,2)^2}")#text(", and let ")#mi("{H}")#text(" be the sub-local group ")#mi("{H := \\{0\\} \\times (-1,1)}")#text(", with normalising neighbourhood ")#mi("{V := (-1,1)^2}")#text(". If we then set ")#mi("{W := (-0.1,0.1)^2}")#text(", then the hypotheses of Exercise ")#link(<tao-d861ee362e3823440ae6>)[#text("14")]#text(" are obeyed, and ")#mi("{W/H}")#text(" can be identified with ")#mi("{(-0.1,0.1)}")#text(", with the projection map ")#mi("{\\phi: (x,y) \\mapsto x}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6")]#text(" Let ")#mi("{G}")#text(" be the torus ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(", and let ")#mi("{H}")#text(" be the sub-local group ")#mi("{H = \\{ (x,\\alpha x) \\mod {\\bf Z}^2: x \\in (-0.1,0.1)\\}}")#text(", where ")#mi("{0 < \\alpha < 1}")#text(" is an irrational number, with normalising neighbourhood ")#mi("{(-0.1,0.1)^2 \\mod {\\bf Z}^2}")#text(". Set ")#mi("{W := (-0.01, 0.01)^2 \\mod{\\bf Z}^2}")#text(". Then the hypotheses of Exercise ")#link(<tao-d861ee362e3823440ae6>)[#text("14")]#text(" are again obeyed, and ")#mi("{W/H}")#text(" can be identified with the interval ")#mi("{I := (-0.01(1+\\alpha),0.01(1+\\alpha))}")#text(", with the projection map ")#mi("{\\phi: (x,y) \\mod {\\bf Z}^2 \\mapsto y - \\alpha x}")#text(" for ")#mi("{(x,y) \\in (-0.01,0.01)^2}")#text(". Note, in contrast, that if one quotiented ")#mi("{G}")#text(" by the ")#emph[#text("global")]#text(" group ")#mi("{\\langle H \\rangle = \\{ (x,\\alpha x) \\mod {\\bf Z}^2: x \\in {\\bf R} \\}}")#text(" generated by ")#mi("{H}")#text(", the quotient would be a non-Hausdorff space (and would also contain a dense set of torsion points, in contrast to the interval ")#mi("{I}")#text(" which is “locally torsion free”). It is because of this pathological behaviour of quotienting by global groups that we need to work with local group quotients instead.")
]

#text("We now return to the analysis of the NSS ultra strong approximate group ")#mi("{A}")#text(". We give the ambient local group ")#mi("{G}")#text(" the discrete topology.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" If ")#mi("{r^{\\prime}>0}")#text(" is a standard real that is sufficiently small depending on ")#mi("{c}")#text(", show that there exists an ultra approximate group ")#mi("{A^{\\prime}}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\pi^{-1}(\\exp(r^{\\prime}B)) \\subset A^{\\prime} \\subset \\pi^{-1}(\\exp(1.1 r^{\\prime}B)),")]]

#text("such that ")#mi("{P}")#text(" is a sub-local group of ")#mi("{A}")#text(" with normalising neighbourhood ")#mi("{(A^{\\prime})^6 \\cup P}")#text(", that is also centralised by ")#mi("{A^{\\prime}}")#text(".")

#text("By Exercise ")#link(<tao-d861ee362e3823440ae6>)[#text("14")]#text(", we may now form the quotient set ")#mi("{A^{\\prime\\prime} := A^{\\prime}/P}")#text(". Show that this is an ultra approximate group that is modeled by ")#mi("{U/\\phi(-c,c)}")#text(", where ")#mi("{U}")#text(" is an open neighbourhood of the identity in ")#mi("{L}")#text(" and ")#mi("{\\phi: [-1,1] \\rightarrow L}")#text(" is the local one-parameter subgroup of ")#mi("{L}")#text(" introduced earlier. In particular, ")#mi("{A^{\\prime\\prime}}")#text(" is modeled by a local Lie group of dimension one less than the dimension of ")#mi("{L}")#text(".")
]

#text("Now we come to a key observation, which is the main reason why we work in the local groups category in the first place:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Preservation of the NSS property)")]#text(" ")#metadata(none) <tao-96dac187ac195be4ea92>#text(" ")#mi("{A^{\\prime\\prime}}")#text(" is NSS.")
]

#text("We will in fact prove a stronger claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Lifting lemma)")]#text(" ")#metadata(none) <tao-5364b92e50b1944f33d1>#text(" If ")#mi("{g \\in A^{\\prime\\prime}}")#text(", then there exists ")#mi("{\\tilde g \\in A^{\\prime}}")#text(" such that ")#mi("{\\kappa(\\tilde g) = g}")#text(" and ")#tao-math("{\\left\\|\\tilde g\\right\\|_{e,A^{\\prime}} \\ll \\left\\|g\\right\\|_{e, A^{\\prime\\prime}}}", block: false)#text(", where ")#mi("{\\kappa: A^{\\prime} \\rightarrow A^{\\prime\\prime}}")#text(" is the projection map.")
]

#text("Since ")#mi("{A^{\\prime}}")#text(" is NSS, all non-identity elements ")#mi("{\\tilde g}")#text(" of ")#mi("{A^{\\prime}}")#text(" have non-zero escape norm, and so by the lifting lemma, all non-identity elements of ")#mi("{A^{\\prime\\prime}}")#text(" also have non-zero escape norm, giving Lemma ")#link(<tao-96dac187ac195be4ea92>)[#text("8")]#text(".")

#emph[#text("Proof:")]#text(" (Proof of Lemma ")#link(<tao-5364b92e50b1944f33d1>)[#text("9")]#text(") We choose ")#mi("{\\tilde g}")#text(" to be a lift of ")#mi("{g}")#text(" (i.e. an element of ")#mi("{\\kappa^{-1}(\\tilde g)}")#text(" in ")#mi("{A^{\\prime}}")#text(") that minimises the escape norm ")#tao-math("{\\left\\|\\tilde g \\right\\|_{e,A^{\\prime}}}", block: false)#text(". (Such a minimum exists since ")#mi("{A^{\\prime}}")#text(" is nonstandard finite, thanks to Los’s theorem.) If ")#mi("{\\tilde g}")#text(" is trivial, then so is ")#mi("{g}")#text(" and there is nothing to prove. Therefore we may assume that ")#mi("{\\tilde g}")#text(" is not the identity and hence, since ")#mi("{A^{\\prime}}")#text(" is NSS, that it has positive escape norm. Suppose, by way of contradiction, that ")#tao-math("{\\left\\| g \\right\\|_{e,A^{\\prime}/P} = o(\\left\\| \\tilde g \\right\\|_{e,A^{\\prime}})}", block: false)#text(". Our goal will be to reach a contradiction by finding another lift ")#mi("{h}")#text(" of ")#mi("{g}")#text(" with strictly smaller escape norm than ")#mi("{\\tilde g}")#text(". We will do this by setting ")#mi("{h = \\tilde g u^m}")#text(" for some suitably chosen ")#mi("{m}")#text(".")

#text("We may assume that ")#tao-math("{\\left\\|g\\right\\|_{e,A^{\\prime\\prime}/P}}", block: false)#text(" is infinitesimal, since otherwise there is nothing to prove; in particular ")#mi("{g}")#text(" lies in the kernel of the local model ")#mi("{\\tilde \\pi: A^{\\prime}/P \\rightarrow U/\\phi(-c,c)}")#text(". We may thus find a lift ")#mi("{\\tilde g}")#text(" of ")#mi("{g}")#text(" in the kernel of ")#mi("{\\pi}")#text(". In particular, we may assume that ")#mi("{\\tilde g}")#text(" has infinitesimal escape norm.")

#text("Set ")#tao-math("{M :=1/\\left\\| \\tilde g \\right\\|_{e,A^{\\prime}}}", block: false)#text(", then ")#mi("{M}")#text(" is unbounded. By hypothesis, ")#tao-math("{\\left\\| g \\right\\|_{e,A^{\\prime}/P} = o(1/M)}", block: false)#text("; thus ")#mi("{g^n \\in A^{\\prime}/P}")#text(" whenever ")#mi("{n=O(M)}")#text(". In particular, for every (standard) integer ")#mi("{k \\in {\\bf N}}")#text(", ")#mi("{g^{kn} \\in A^{\\prime}/P}")#text(". This implies that the group generated by ")#mi("{g^{n}}")#text(" lies in ")#mi("{A^{\\prime}/P}")#text(". In particular, ")#mi("{g^n}")#text(" lies in the kernel of ")#mi("{\\tilde \\pi}")#text(", and hence ")#mi("{\\pi(\\tilde g^n)}")#text(" lies in ")#mi("{\\phi(-c,c)}")#text(" for all ")#mi("{-M \\leq n \\leq M}")#text(".")

#text("By (an appropriate local version of) Exercise ")#link(<tao-f2898d9badaef8c18cde>)[#text("7")]#text(", we can find ")#mi("{X \\in 1.1 B \\backslash B}")#text(" such that ")#metadata(none) <tao-9f79fd6cdc880e3914ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\pi( \\tilde g^n ) = \\exp( \\text{st}(n/M) r^{\\prime} X )")]]

#text("whenever ")#tao-math("{\\left|n\\right| \\leq \\frac{r}{r^{\\prime}} M}", block: false)#text("; since ")#mi("{\\pi(\\tilde g^n)}")#text(" lies in ")#mi("{\\phi(-c,c)}")#text(" for ")#tao-math("{\\left|n\\right| \\leq M}", block: false)#text(", we conclude that ")#mi("{X}")#text(" must be parallel to the generator ")#mi("{\\phi^{\\prime}(0)}")#text(" of ")#mi("{\\phi}")#text(". Similarly, we have ")#metadata(none) <tao-39ee4551970726c324df>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\pi( u^n ) = \\exp( \\text{st}(n/N) r Y )")]]

#text("whenever ")#tao-math("{\\left|n\\right| \\leq 4N}", block: false)#text(" (say) for some ")#mi("{Y \\in 1.1 B \\backslash B}")#text(" that is also parallel to ")#mi("{\\phi^{\\prime}(0)}")#text(". In particular, ")#mi("{Y = \\alpha X}")#text(" for some")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{1.1} \\leq \\alpha \\leq 1.1.")]]

#text("Since ")#tao-math("{1/N = \\left\\|u\\right\\|_{e,A}}", block: false)#text(" is the minimal escape norm of non-identity elements of ")#mi("{A}")#text(", we have ")#tao-math("{\\left\\| \\tilde g \\right\\|_{e,A} \\geq 1/N}", block: false)#text(", and thus ")#mi("{\\tilde g^i \\in A^2 \\backslash A}")#text(" for some ")#mi("{1 \\leq i \\leq N}")#text("; in particular, ")#mi("{\\pi(\\tilde g^i) \\not \\in \\exp(r B)}")#text(". Comparing this with ")#link(<tao-9f79fd6cdc880e3914ac>)[#text("(11)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\text{st}(i/M) r^{\\prime} X \\not \\in rB")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\text{st}(\\frac{N}{M}) \\geq \\frac{1}{1.1} \\frac{r}{r^{\\prime}},")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\frac{M\\alpha}{N} \\leq 1.3 \\frac{r^{\\prime}}{r}.")]]

#text("By the Euclidean algorithm, we can thus find a nonstandard integer number ")#mi("{m}")#text(" such that the quantity")

#align(center)[#tao-fit-display[#mitex("\\theta := 1 + m \\frac{M \\alpha r}{N r^{\\prime}}")]]

#text("lies in the interval ")#mi("{[-0.5, 0.5]}")#text(". In particular")

#align(center)[#tao-fit-display[#tao-math("\\left|m\\right| \\leq 2 \\frac{N r^{\\prime}}{M r}.", block: true)]]

#text("If we set ")#mi("{h := \\tilde g u^m}")#text(" then (as ")#mi("{u}")#text(" commutes with ")#mi("{\\tilde g}")#text(") we see for all ")#tao-math("{\\left|n\\right| \\leq M}", block: false)#text(" that")

#align(center)[#tao-fit-display[#mitex("h^n = \\tilde g^n u^{mn}")]]

#text("and thus by ")#link(<tao-9f79fd6cdc880e3914ac>)[#text("(11)")]#text(", ")#link(<tao-39ee4551970726c324df>)[#text("(12)")]

#tao-aligned(keep: true)[


#tao-math("\\pi( h^n )  & = \\exp( (\\text{st}(n/M) r^{\\prime} + \\text{st}(mn/N) \\alpha r) X )", block: true)



#tao-math(" & = \\exp( (\\text{st}(n/M) \\theta r^{\\prime} X )", block: true)



#tao-math(" & \\in \\exp(r^{\\prime} B)", block: true)
]

#text("for all ")#tao-math("{\\left|n\\right| \\leq M}", block: false)#text(". In particular, ")#tao-math("{\\left\\|h\\right\\|_{e,A^{\\prime}} < 1/M}", block: false)#text(". Since ")#mi("{h}")#text(" is also a lift of ")#mi("{g}")#text(", this contradicts the minimality of ")#tao-math("{\\left\\|\\tilde g\\right\\|_{e,A^{\\prime}} = 1/M}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#text("Because the NSS property is preserved, it is possible to improve upon Exercise ")#link(<tao-0c706679d12b6123dac1>)[#text("9")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Strengthen Exercise ")#link(<tao-0c706679d12b6123dac1>)[#text("9")]#text(" by ensuring the final quotient ")#mi("{G^{\\prime}_{k-1}/G^{\\prime}_k=G^{\\prime}_{k-1}}")#text(" is nonstandard finite, and all the other quotients ")#mi("{G^{\\prime}_i/G^{\\prime}_{i+1}}")#text(" are central in ")#mi("{G^{\\prime}/G^{\\prime}_{i+1}}")#text(".")
]

#text("As a consequence, one obtains a stronger structure theorem than Exercise ")#link(<tao-0c706679d12b6123dac1>)[#text("9")]#text(". Call a symmetric subset ")#mi("{U}")#text(" containing the identity in a local group ")#emph[#text("nilpotent of step at most ")#mi("{s}")]#text(" if every iterated commutator in ")#mi("{U}")#text(" of length ")#mi("{s+1}")#text(" is well-defined and trivial.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Helfgott-Lindenstrauss conjecture)")]#text(" ")#metadata(none) <tao-234d8fac0818118b3bb4>

#list(
[#text("(i) Let ")#mi("{A}")#text(" be a (local) NSS ultra strong approximate group. Show that there is a symmetric subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" containing the identity which is nilpotent of some finite step, such that ")#mi("{A}")#text(" is covered by a finite number of left translates of ")#mi("{A^{\\prime}}")#text(".")],
[#text("(ii) Let ")#mi("{A}")#text(" be a global NSS ultra strong approximate group with ambient group ")#mi("{G}")#text(". Show that there is a nonstandard nilpotent subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" such that ")#mi("{A}")#text(" is covered by a finite number of left translates of ")#mi("{G^{\\prime}}")#text(".")],
[#text("(iii) Let ")#mi("{A}")#text(" be an NSS strong ")#mi("{K}")#text("-approximate group in a global group ")#mi("{G}")#text(". Show that there is a nilpotent subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" of step ")#mi("{O_K(1)}")#text(" such that ")#mi("{A}")#text(" can be covered by a finite number of left translates of ")#mi("{G^{\\prime}}")#text(".")],
[#text("(iv) Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate group in a global group ")#mi("{G}")#text(". Show that there exists a subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" and a normal subgroup ")#mi("{N}")#text(" of ")#mi("{G^{\\prime}}")#text(" contained in ")#mi("{A^4}")#text(", such that ")#mi("{A}")#text(" is covered by ")#mi("{O_K(1)}")#text(" left-translates of ")#mi("{G^{\\prime}}")#text(", and ")#mi("{G^{\\prime}/N}")#text(" is nilpotent of step ")#mi("{O_K(1)}")#text(".")]
)
]

#text("In fact, a stronger statement is true, involving the nilprogressions defined in ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("Notes 6")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" ")#metadata(none) <tao-5f67fa77872a6a97a04e>

#list(
[#text("(i) If ")#mi("{A}")#text(" is an NSS ultra strong approximate group, then there is an ultra nilprogression ")#mi("{Q}")#text(" in ")#mi("{G}")#text(" such that ")#mi("{A}")#text(" contains ")#mi("{Q}")#text(", and ")#mi("{A}")#text(" can be covered by finitely many left-translates of ")#mi("{Q}")#text(".")],
[#text("(ii) If ")#mi("{A}")#text(" is an ultra approximate group, then there is an ultra coset nilprogression ")#mi("{Q}")#text(" in ")#mi("{G}")#text(" such that ")#mi("{A^4}")#text(" contains ")#mi("{Q}")#text(", and ")#mi("{A}")#text(" can be covered by finitely many left-translates of ")#mi("{Q}")#text(".")],
[#text("(iii) For all ")#mi("{K \\geq 1}")#text(", there exists ")#mi("{C_{K}, s_K, r_K \\geq 1}")#text(" such that, given a finite ")#mi("{K}")#text("-approximate group ")#mi("{A}")#text(" in a group ")#mi("{G = (G,\\cdot)}")#text(", one can find a coset nilprogression ")#mi("{Q}")#text(" in ")#mi("{G}")#text(" of rank at most ")#mi("{r_K}")#text(" and step at most ")#mi("{s_K}")#text(" such that ")#mi("{A^4}")#text(" contains ")#mi("{Q}")#text(", and ")#mi("{A}")#text(" can be covered by at most ")#mi("{C_{K}}")#text(" left-translates of ")#mi("{Q}")#text(".")]
)
]

#text("This proposition is established in ")#link("http://arxiv.org/abs/1110.5008")[#text("this paper")]#text(". The key point is to use the lifting lemma to observe that if (with the notation of the preceding discussion) ")#mi("{A^{\\prime}/P}")#text(" contains a large nilprogression, then ")#mi("{A^{\\prime}}")#text(" also contains a large nilprogression. One consequence of this proposition is that there is essentially no difference between local and global approximate groups, at the qualitative level at least:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11")]#text(" Let ")#mi("{A}")#text(" be a local ")#mi("{K}")#text("-approximate group. Then there exists a ")#mi("{O_K(1)}")#text("-approximate subgroup ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(", with ")#mi("{A}")#text(" covered by ")#mi("{O_K(1)}")#text(" left-translates of ")#mi("{A^{\\prime}}")#text(", such that ")#mi("{A^{\\prime}}")#text(" is isomorphic to a ")#emph[#text("global")]#text(" ")#mi("{O_K(1)}")#text("-approximate subgroup.")
]

#text("This is because coset nilprogressions (or large fractions thereof) can be embedded into global groups; again, see ")#link("http://arxiv.org/abs/1110.5008")[#text("this paper")]#text(" for details.")

#text("For most applications, one does not need the full strength of Proposition ")#link(<tao-5f67fa77872a6a97a04e>)[#text("10")]#text("; Exercise ")#link(<tao-234d8fac0818118b3bb4>)[#text("17")]#text(" will suffice. We will give some examples of this in the next set of notes.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ff3d77ab7c8eb8d8f174ccb9e5bc8d18c5dd6b58f0aa41aa095d3e81ab769a-7a8fcdc37963ca24eb97792a0541861e294b616735971b060dd04f4fde09fa37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/comment-page-1/#comment-102096")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2011")])]

#text("Re: trapping conditions (definition 1) remind me the paper by David and Toro “Reifenberg Flat Metric Spaces, Snowballs and Embeddings”, Math. Ann., 315, 1999, 641-720. Indeed, in order to understand the long proof, I collected all constants appearing there and remarked that they concentrate around the same powers of 10 as in your definition 1. Notice that Reinfenberg flatness qualify as a kind of mesoscopic flatness.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81cc75273754d1bc7e2727ece1dee4edd5c2bed1f85587b3e3e1b5eac8457089-7d43d1fe13ce4bfa8da499652df15c56766599b60849c6ca21a08c947d06a05b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Machfudz")]], [#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/comment-page-1/#comment-103182")[#strong[#text("Machfudz")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2011")])]

#text("Hmmm….")#linebreak()#text(" I confused..")#linebreak()#text(" XD")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44fe33be5e6ec3b6cb999dec38b079e1ac85f7bfde1cf14954552e9ee3a80d7a-3df1d2c8ec4815ad78fe8caa68391c4b636ee6aae4035f58747e50bbaf3a30fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eza Volturi")]], [#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/comment-page-1/#comment-103799")[#strong[#text("Eza Volturi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2011")])]

#text("I.m not very very understand Mr. Tao 🙂")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0495f8b8e748b3ed656cc09332e75388264b8051b5618821a84f698f129370d8-ad545e83c630e17edbfdf5495e97334a498f57c0478a1c4b2f8bb9de0acbbbdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lou van den Dries")]], [#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/comment-page-1/#comment-133341")[#strong[#text("Lou van den Dries")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2012")])]

#text("Something strange about exercise 8: part (iv) suggests that the centralizer of u is normal in star G, but I see no reason why that should be so. My guess is that star G should be replaced by the centralizer of u, so as to reduce to the case that u is in the center.")#linebreak()#text(" Next, instead of the centralizer of u one should take the internal subgroup")#linebreak()#text(" generated by u, which by the previous reduction is normal.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36130087db075e42764d062d915f2240b64e7aa8e84a20befb4ee531b20797c6-563816fa7ca72eecede549bae1b0e74dd46090f16fbfd396db4793e32d8c72e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yang")]], [#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/comment-page-1/#comment-633041")[#strong[#text("yang")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("Mr. Tao: I Recently your book Hilbert’s fifth problem and related topics.")#linebreak()#text(" This book is")#linebreak()#text(" consisting of Wide Knowledge of mathematics. particular, I have a question, and i don’t solve it through effort. The following is my Doubt.")#linebreak()#text(" For a lie group G, This question is that can we find ε＞0，such that for any two enough small elements g and h in G with g≠h, there is a integer n＞0 such that d( g^n, h^n ) ＞ε. d is the Gleason metric. This question is can regard as a stronger Phenomenon than escape property. particular,If G is Commutative group ，this question actually is can regard as escape property. I guess the question is true for some class group, but i can solve it. Thanks .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yang")]], [#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/comment-page-1/#comment-633042")[#strong[#text("yang")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("i can’t solve it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/comment-page-1/#comment-633043")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2021")])]

#text("This property is not true in general. Consider for instance the case where ")#mi("G")#text(" is a compact Lie group (e.g., an orthogonal group) and ")#mi("h")#text(" is ")#mi("g")#text(" conjugated by an element of distance ")#mi("\\varepsilon")#text(" to the identity. Then ")#mi("h^n")#text(" is similarly a conjugate of ")#mi("g^n")#text(" by the same element and so ")#mi("d(g^n,h^n) \\ll \\varepsilon")#text(" for all ")#mi("n")#text(". Since one can take ")#mi("\\varepsilon")#text(" arbitrarily small, there is no uniform bound of the type you request.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/comment-page-1/#comment-633079")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2021")])]

#text("To Terence Tao :Thank you. I just saw your reply. I’m glad you answered this question in your busy schedule")
]
]
]
