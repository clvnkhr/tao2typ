// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/11/05/reading-seminar-4-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/
// Converted to Typst by tao2typ: "2026-11-05T14:56:46.527283+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Reading seminar 4: “Stable group theory and approximate subgroups”, by Ehud Hrushovski", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Reading seminar 4: “Stable group theory and approximate subgroups”, by Ehud Hrushovski")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 November 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/11/05/reading-seminar-4-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("https://terrytao.wordpress.com/2009/11/05/reading-seminar-4-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-05 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This week, ")#link("http://www.math.ucla.edu/~hpt/")[#text("Henry Towsner")]#text(" concluded his portion of ")#link("https://terrytao.wordpress.com/category/teaching/logic-reading-seminar/")[#text("reading seminar")]#text(" of the ")#link("http://arxiv.org/abs/0909.2190")[#text("Hrushovski paper")]#text(", by discussing (a weaker, simplified version of) main model-theoretic theorem (Theorem 3.4 of Hrushovski), and described how this theorem implied the combinatorial application in Corollary 1.2 of Hrushovski. The presentation here differs slightly from that in Hrushovski’s paper, for instance by avoiding mention of the more general notions of S1 ideals and forking.")

#text("Here is a collection of resources so far on the Hrushovski paper:")

#list(
[#link("https://terrytao.wordpress.com/wp-content/uploads/2009/11/hrushovskinotes-2.pdf")[#text("Henry Towsner’s notes")]#text(" (which most of Notes 2-4 have been based on);")],
[#link("http://www.math.ucla.edu/~alexus/papers/talks/udi1.pdf")[#text("Alex Usvyatsov’s notes")]#text(" on the derivation of Corollary 1.2 (broadly parallel to the notes here);")],
[#link("http://www.math.uiuc.edu/~vddries/approx.pdf")[#text("Lou van den Dries’ notes")]#text(" (covering most of what we have done so far, and also material on stable theories); and")],
[#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42065")[#text("Anand Pillay’s sketch")]#text(" of a simplified proof of Theorem 1.1.")]
)

#strong[#text(" — 1. Theorem 3.4 — ")]

#text("Here is a weakened version of Hrushovski’s Theorem 3.4:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{M}")#text(" be a countable model of a language extending the language of groups, with a universal extension ")#mi("{G}")#text(". Let ")#mi("{\\mu}")#text(" be a continuous, invariant Keisler measure that is also invariant under translations. Let ")#mi("{X}")#text(" be a symmetric definable subset of ")#mi("{G}")#text(" with ")#mi("{\\mu(X) = 1}")#text(" and ")#mi("{\\mu(X \\cdot X)}")#text(" finite, and let ")#mi("{\\tilde G}")#text(" be the group generated by ")#mi("{X}")#text(". Let ")#mi("{q}")#text(" be a wide type over ")#mi("{M}")#text(" contained in ")#mi("{X}")#text(", and suppose that for every ")#mi("{a \\in q(G)}")#text(", there exists ")#mi("{b \\in q(G)}")#text(" such that ")#mi("{tp(a/M \\cup \\{b\\})}")#text(" and ")#mi("{tp(b/M \\cup \\{a\\})}")#text(" are both wide.")

#text("Then the set ")#mi("{S := q^{-1} q q^{-1} q}")#text(" is a normal subgroup of ")#mi("{\\tilde G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The condition about ")#mi("{a}")#text(" and ")#mi("{b}")#text(" seems to be a statement that there exist plenty of pairs ")#mi("{(a,b)}")#text(" in ")#mi("{q(G)}")#text(" that are in “general position” somehow. In the case of abelian groups, it seems that this hypothesis not necessary. The hypothesis is for all ")#mi("{a \\in q(G)}")#text(", but by homogeneity it suffices to verify it for a single ")#mi("{a}")#text(" (since the action of the automorphism group of ")#mi("{G}")#text(" is transitive on ")#mi("{q(G)}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Interestingly, it seems that no doubling condition on ")#mi("{X}")#text(" is needed to prove this theorem, but the doubling condition arises when one wants to put ")#mi("{S}")#text(" to use.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" As ")#mi("{q}")#text(" is wide, ")#mi("{S}")#text(" is wide also. If we also assume that every finite product ")#mi("{X^{\\cdot n} = X \\cdot \\ldots \\cdot X}")#text(" has finite measure, this leads to the consequence that the index of ")#mi("{S}")#text(" in ")#mi("{\\tilde G}")#text(" does not exceed ")#mi("{2^{\\aleph_0}}")#text(" in cardinality (i.e. has ")#emph[#text("bounded index")]#text(", see Lemma 1 of ")#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("Notes 2")]#text("). Indeed, if this were not the case, then one could find more than ")#mi("{2^{\\aleph_0}}")#text(" disjoint cosets ")#mi("{Sa_i}")#text(" in ")#mi("{\\tilde G}")#text(", and hence in some finite product ")#mi("{X^{\\cdot n}}")#text(". By Section 4 of ")#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("Notes 2")]#text(", ")#mi("{S}")#text(" is ")#mi("{\\bigwedge}")#text("-definable, and so is the intersection of countably many definable sets ")#mi("{S_n}")#text(". For any distinct ")#mi("{i,j}")#text(", ")#mi("{Sa_i, Sa_j}")#text(" are disjoint, thus by saturation we have ")#mi("{S_{n(i,j)} a_i \\cap S_{n(i,j)} a_j}")#text(" non-empty for some integer ")#mi("{n(i,j)}")#text(". By the ")#link("http://en.wikipedia.org/wiki/Infinitary_combinatorics")[#text("Erdös-Rado theorem")]#text(" (an infinitary analogue of Ramsey’s theorem), we can then ass to a countable set of indices ")#mi("{i}")#text(" in which the ")#mi("{n(i,j) = n}")#text(" are constant, thus we have a countable set of disjoint translates ")#mi("{S_n a_i}")#text(", which live in some finite product ")#mi("{X^{\\cdot n}}")#text(". But as ")#mi("{S}")#text(" is wide, ")#mi("{S_n}")#text(" has positive measure, while ")#mi("{X^{\\cdot n}}")#text(" has finite measure, leading to a contradiction.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The set ")#mi("{S}")#text(" can also be defined in a more “")#link("http://en.wikipedia.org/wiki/Characteristic_subgroup")[#text("characteristic")]#text("” fashion as the smallest ")#mi("{\\bigwedge}")#text("-definable subgroup of ")#mi("{\\tilde G}")#text(" of bounded index; we’ll return to this point in a later note (I think).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Here is one example of how the group ")#mi("{S}")#text(" emerges. Start with a finite combinatorial model, in which ")#mi("{X}")#text(" is a discrete interval ")#mi("{\\{-N,\\ldots,N\\}}")#text(" and the group is the integers; we normalise ")#mi("{X}")#text(" to have measure ")#mi("{1}")#text(". Taking ultralimits, we end up with a non-standard discrete interval ")#mi("{X = \\{-N,\\ldots,N\\}}")#text(" in the non-standard integers, with ")#mi("{\\mu}")#text(" being the counting measure normalised to give ")#mi("{X}")#text(" a measure of ")#mi("{1}")#text(". (This is not yet a saturated model, but yet us ignore this issue.) Note that the subsets ")#mi("{\\{-N/k,\\ldots,N/k\\}}")#text(" are definable for any standard natural number ")#mi("{k}")#text(". Their intersection ")#mi("{S := \\bigcap_k \\{-N/k,\\ldots,N/k\\}}")#text(" is a wide subgroup; if ")#mi("{q}")#text(" was a “generic” type in ")#mi("{S}")#text(" then ")#mi("{q}")#text(" would be wide, and ")#mi("{q^{-1} q q^{-1} q}")#text(" would generate ")#mi("{S}")#text(" (this is vaguely reminiscent of the “Bogulybov theorem” in additive combinatorics).")
]

#text("To apply Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", we need the following auxiliary lemma (a weakened version of Hrushovski Lemma 2.15):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-ddc6e2b224d0fd821669>#text(" Let ")#mi("{B}")#text(" be a definable set of positive measure. Then we can refine ")#mi("{B}")#text(" to a wide type ")#mi("{q}")#text(" such that for every ")#mi("{a \\in q(G)}")#text(", there exists ")#mi("{b \\in q(G)}")#text(" such that ")#mi("{tp(a/M \\cup \\{b\\})}")#text(" and ")#mi("{tp(b/M \\cup \\{a\\})}")#text(" are both wide.")
]

#text("This lemma can be viewed as a more technical variant of Lemma 2 from ")#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("Notes 2")]#text(".")

#text("To prove this lemma we need a technical sublemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-0c5caf84af33477c0cd3>#text(" Let ")#mi("{P}")#text(" be a definable set of positive measure, and suppose that the product ")#mi("{P \\times P}")#text(" is covered by two definable sets ")#mi("{C, D}")#text(" (these are sets of pairs, of course). Then one can refine ")#mi("{P}")#text(" to a definable subset ")#mi("{P^{\\prime}}")#text(" of positive measure, such that at least one of the following holds:")

#list(
[#text("(i) For every ")#mi("{a \\in P^{\\prime}}")#text(", the set ")#mi("{C_a := \\{ b: (a,b) \\in C \\}}")#text(" has positive measure; or")],
[#text("(ii) For every ")#mi("{b \\in P^{\\prime}}")#text(", the set ")#mi("{D^b := \\{ a: (a,b) \\in D \\}}")#text(" has positive measure.")]
)
]

#emph[#text("Proof:")]#text(" We can refine ")#mi("{C, D}")#text(" to be contained in ")#mi("{P \\times P}")#text(". At least one of ")#mi("{C, D}")#text(" must have positive measure; let’s say that ")#mi("{\\mu(C)=0}")#text(". We can find a definable set ")#mi("{Q_n}")#text(" between ")#mi("{\\{ a: \\mu(C_a) > 1/n \\}}")#text(" and ")#mi("{\\{ a: \\mu(C_a) \\geq 1/n \\}}")#text(". If any of these ")#mi("{Q_n}")#text(" has positive measure, then we can just take ")#mi("{P^{\\prime} := Q_n}")#text(", so we may assume instead that ")#mi("{\\mu(Q_n)=0}")#text(" for all ")#mi("{n}")#text(", which implies that ")#mi("{\\mu(C) = 0}")#text(" by Fubini’s theorem (which can be extended to Kiesler measures, at least in the weak form we need here), giving the desired contradiction. ")#mi("\\Box")

#text("Now we prove Lemma ")#link(<tao-ddc6e2b224d0fd821669>)[#text("2")]#text(". By starting with ")#mi("{B}")#text(" and refining repeatedly using Lemma ")#link(<tao-0c5caf84af33477c0cd3>)[#text("3")]#text(" (enumerating all the definable sets, ")#mi("{P}")#text(" and pairs of definable sets ")#mi("{C,D}")#text(", so that each pair is revisited infinitely often) one can find a type ")#mi("{q}")#text(" refining ")#mi("{B}")#text(" with the property that whenever ")#mi("{P}")#text(" is a definable set containing ")#mi("{q({\\Bbb U})}")#text(", and ")#mi("{P \\times P}")#text(" is covered by two definable sets ")#mi("{C, D}")#text(", then either ")#mi("{C_a}")#text(" has positive measure for all ")#mi("{a \\in P}")#text(", or ")#mi("{D^b}")#text(" has positive measure for all ")#mi("{b \\in P}")#text(". In particular (setting ")#mi("{C=P \\times P}")#text(" and ")#mi("{D}")#text(" empty) this implies that ")#mi("{q}")#text(" is wide.")

#text("Now let ")#mi("{a \\in q({\\Bbb U})}")#text(", and define ")#mi("{q_a}")#text(" to be the type ")#mi("{q}")#text(", refined using the complement of all the sets of the form ")#mi("{C_a}")#text(" for definable ")#mi("{C}")#text(" with ")#mi("{\\mu(C_a)=0}")#text(", and the complement of the sets of the form ")#mi("{D_a}")#text(" for definable ")#mi("{D}")#text(" with ")#mi("{\\mu(D^a)=0}")#text(" (note the asymmetry here!). We claim that this collection of sentences is still finitely satisfiable. Indeed, if this were not the case, ")#mi("{q}")#text(" would have to be covered by ")#mi("{C_a \\cup D_a}")#text(" for some definable ")#mi("{C, D}")#text(" with ")#mi("{\\mu(C_a)=\\mu(D^a)=0}")#text(". Write ")#mi("{P := C_a \\cup D_a}")#text(", then the set ")#mi("{\\{ x: P = C_x \\cup D_x \\}}")#text(" is definable and contains ")#mi("{a}")#text(", and thus contains ")#mi("{q}")#text(". If we set ")#mi("{P^{\\prime} := \\{ x \\in P: P = C_x \\cup D_x \\}}")#text(", we thus see that ")#mi("{P^{\\prime}}")#text(" is a definable set containing ")#mi("{q}")#text(" and ")#mi("{P^{\\prime} \\times P^{\\prime} \\subset C \\cup D}")#text(", contradicting the construction of ")#mi("{q^{\\prime}}")#text(".")

#text("As ")#mi("{q_a}")#text(" is finitely satisfiable, we may extend it to a type ")#mi("{q^{\\prime}_a}")#text(" over ")#mi("{a}")#text(". Now let ")#mi("{b}")#text(" be any realisation of ")#mi("{q^{\\prime}_a}")#text(". We claim that ")#mi("{tp(b/M \\cup \\{a\\})}")#text(" is wide. For if not, then ")#mi("{b}")#text(" would be contained in a set ")#mi("{C_a}")#text(" of measure zero for some definable ")#mi("{C}")#text(", but by construction ")#mi("{q_a({\\Bbb U})}")#text(" and hence ")#mi("{q^{\\prime}_a({\\Bbb U})}")#text(" is contained in the complement of ")#mi("{C_a}")#text(", a contradiction.")

#text("We similarly claim that ")#mi("{tp(a/M \\cup \\{b\\})}")#text(" is wide. For if not, then ")#mi("{a}")#text(" is contained in a set ")#mi("{D^b}")#text(" of measure zero for some definable ")#mi("{D}")#text(". since ")#mi("{b}")#text(" and ")#mi("{a}")#text(" have the same type over ")#mi("{M}")#text(", ")#mi("{D^a}")#text(" has measure zero also, and so ")#mi("{q_a}")#text(" is contained in the complement of ")#mi("{D_a}")#text(" by construction. In particular, ")#mi("{b}")#text(" lies outside ")#mi("{D_a}")#text(", which is inconsistent with ")#mi("{a}")#text(" lying in ")#mi("{D^b}")#text(". This proves Lemma ")#link(<tao-ddc6e2b224d0fd821669>)[#text("2")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" As I understand it, the argument simplifies in the stable case, when the wideness of ")#mi("{a}")#text(" over ")#mi("{b}")#text(" is equivalent to the wideness of ")#mi("{b}")#text(" over ")#mi("{a}")#text(".")
]

#strong[#text(" — 2. Corollary 1.2 — ")]

#text("Assuming Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", we now establish the following combinatorial consequence, which is (a slightly weaker version of) Corollary 1.2 of Hrushovski:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(" ")#metadata(none) <tao-6b51d431df5d7f141cbe>#text(" Let ")#mi("{k,l,m}")#text(" be positive integers. Then for ")#mi("{p}")#text(" sufficiently close to ")#mi("{1}")#text(", the following statement is true: whenever ")#mi("{X_0}")#text(" is a finite subset of a group ")#mi("{G}")#text(" with the bounded quintipling property ")#tao-math("{\\left|X_0 X X\\right| \\leq k \\left|X_0\\right|}", block: false)#text(", where ")#mi("{X := X_0^{-1} X_0}")#text(", and for a proportion at least ")#mi("{p}")#text(" of the ")#mi("{l}")#text("-tuples ")#mi("{(a_1,\\ldots,a_l) \\in (X \\cdot X)^l}")#text(", one has ")#tao-math("{\\left|a_1^X \\ldots a_l^X\\right| \\geq \\left|X\\right|/m}", block: false)#text(" (recall that ")#mi("{a^X := \\{ x^{-1}ax: x \\in X \\}}")#text("). Then there exists a subgroup ")#mi("{S}")#text(" of ")#mi("{X \\cdot X}")#text(" such that ")#mi("{X_0}")#text(" is contained in at most ")#mi("{k(m+1)}")#text(" cosets of ")#mi("{S}")#text(".")
]

#text("We have weakened things a bit here by drawing the ")#mi("{a_i}")#text(" from ")#mi("{X \\cdot X}")#text(" rather than ")#mi("{X}")#text(" (and also weakening bounded tripling to bounded quintipling); this is in order to achieve some minor simplifications in the proof.")

#text("We now prove the corollary, by the usual “compactness and contradiction” method. If the corollary failed for some ")#mi("{k,l,m}")#text(", then one can find a sequence of groups ")#mi("{G}")#text(" with subsets ")#mi("{X_0}")#text(" of tripling uniformly bounded by ")#mi("{k}")#text(", such that the proportion of ")#mi("{l}")#text("-tuples ")#mi("{(a_1,\\ldots,a_l)}")#text(" in ")#mi("{(X \\cdot X)^l}")#text(" with ")#tao-math("{\\left|a_1^X \\ldots a_l^X\\right| \\geq \\left|X\\right|/m}", block: false)#text(" approaches ")#mi("{1}")#text(", but such that there is no subgroup ")#mi("{S}")#text(" of ")#mi("{X \\cdot X}")#text(" which can cover ")#mi("{X}")#text(" by ")#mi("{k(m+1)}")#text(" cosets.")

#text("Taking an ultralimit (and using counting measure normalised so that ")#mi("{X}")#text(" has mass ")#mi("{1}")#text("), we obtain a subset ")#mi("{X_0}")#text(" of a group ")#mi("{M}")#text(" and a continuous, invariant, translation-invariant Keisler measure ")#mi("{\\mu}")#text(" so that ")#mi("{\\mu(X) = 1}")#text(", ")#mi("{\\mu(X_0 X X) \\leq k \\mu(X_0)}")#text(", and such that the set ")#mi("{Q := \\{ (a_1,\\ldots,a_l) \\in (X \\cdot X)^l: \\mu( a_1^X \\ldots a_l^X ) \\geq \\mu(X)/(m+0.5) \\}}")#text(" (say) has measure ")#mi("{\\mu(X \\cdot X)^l}")#text(". (Strictly speaking, one has to replace ")#mi("{\\mu( a_1^X \\ldots a_l^X ) \\geq \\mu(X)/(m+1)}")#text(" by a definable predicate between ")#mi("{\\mu( a_1^X \\ldots a_l^X ) \\geq \\mu(X)/(m+1)}")#text(" and ")#mi("{\\mu( a_1^X \\ldots a_l^X ) > \\mu(X)/(m+1)}")#text(", but let’s ignore this technicality.) We then extend ")#mi("{M}")#text(" to a universal model ")#mi("{G}")#text(".")

#text("The set ")#mi("{X_0}")#text(" has positive measure (at least ")#mi("{1/k}")#text(", in fact), so by Lemma ")#link(<tao-ddc6e2b224d0fd821669>)[#text("2")]#text(", we may refine it to a wide type ")#mi("{q}")#text(" obeying the hypotheses of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", so that the set ")#mi("{S := q^{-1} q q^{-1} q}")#text(" is a group. Note that this set is contained in ")#mi("{X \\cdot X}")#text(".")

#text("Since ")#mi("{S}")#text(" contains the wide type ")#mi("{q}")#text(", it is itself wide. By Section 4 of ")#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/")[#text("Notes 2")]#text(", ")#mi("{S}")#text(" is ")#mi("{\\bigwedge}")#text("-definable, and is thus the intersection of definable sets ")#mi("{S_n}")#text(", which have positive measure as ")#mi("{S}")#text(" is wide; we can place this inside the definable set ")#mi("{X \\cdot X}")#text(". As ")#mi("{Q}")#text(" has full measure in ")#mi("{(X \\cdot X)^l}")#text(", we see that ")#mi("{Q}")#text(" intersects ")#mi("{S_n^l}")#text(" for every ")#mi("{n}")#text(", by saturation, ")#mi("{Q}")#text(" must also intersect ")#mi("{S^l}")#text(". In particular, there exists ")#mi("{a_1,\\ldots,a_l}")#text(" in ")#mi("{S}")#text(" such that")

#mi("\\displaystyle  \\mu( a_1^X \\ldots a_l^X ) \\geq \\mu(X)/(m+1).")

#text("On the other hand, as ")#mi("{S}")#text(" is normal in ")#mi("{\\tilde G}")#text(", the set ")#mi("{a_1^X \\ldots a_l^X}")#text(" lies in ")#mi("{S}")#text(". This implies that we cannot find more than ")#mi("{\\mu(X_0 X X) (m+1) / \\mu(X) \\leq k(m+1)}")#text(" disjoint translates ")#mi("{xS}")#text(", ")#mi("{x \\in X_0}")#text(". As a consequence, ")#mi("{X_0}")#text(" is covered by at most ")#mi("{k(m+1)}")#text(" translates of ")#mi("{S}")#text(", and so ")#mi("{X^2}")#text(" can be covered by ")#mi("{k^4 (m+1)^4}")#text(" such translates, including ")#mi("{S}")#text(" itself. In particular, ")#mi("{S}")#text(" is both ")#mi("{\\bigwedge}")#text("-definable and ")#mi("{\\bigvee}")#text("-definable (it is the complement of all the other cosets in ")#mi("{X^2}")#text("). But any set ")#mi("{S}")#text(" which is both ")#mi("{\\bigwedge}")#text("-definable and ")#mi("{\\bigvee}")#text("-definable has to be definable. (Proof: we can write ")#mi("{S}")#text(" as the intersection of definable sets ")#mi("{S_n}")#text(" and also as the union of definable sets ")#mi("{U_n}")#text(". By saturation, ")#mi("{U_n \\backslash S_n}")#text(" must be empty for at least one ")#mi("{n}")#text(", and the claim follows.)")

#text("To summarise, ")#mi("{S}")#text(" is now a definable group which can cover ")#mi("{X_0}")#text(" by at most ")#mi("{k(m+1)}")#text(" cosets. This is a first-order statement and so descends back to the original finitary models, but this then contradicts the construction of such sets, and proves the Corollary.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" The argument not only shows the existence of the set ")#mi("{S}")#text(", but shows that this set is “definable”, in the sense that there are a finite number of first-order expressions using ")#mi("{X}")#text(" and normalised cardinality, one of which is guaranteed to generate ")#mi("{S}")#text(" whenever the hypotheses of Corollary ")#link(<tao-6b51d431df5d7f141cbe>)[#text("4")]#text(" are satisfied. Indeed, if this were not the case, one could construct a sequence of counterexamples for which no such recipe for constructing ")#mi("{S}")#text(" would work for sufficiently late elements of this sequence, and then run the above argument to obtain a contradiction.")
]

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46319b39ff62029a779669be02cb0027582e37bd8ab93547f60b8aa0781bab86-370bb954591da1189700301c59b5671eea828384b2f2050db49274a3f277d1a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/11/05/reading-seminar-4-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/comment-page-1/#comment-42269")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("A quick response to your remark 2: the doubling condition is required for the setting to even make sense; without control on doubling, the measure can’t be expected to be well-behaved on subsets of X^2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/reading-seminar-4-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/comment-page-1/#comment-42282")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Hmm, so is the finiteness of ")#mi("\\mu(X^2)")#text(" needed in the hypothesis of the weakened Theorem 3.4? I had the impression that even without this hypothesis, one could still establish that S was a normal subgroup, but couldn’t do much else with this group (e.g. one could not show that S had bounded index).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46319b39ff62029a779669be02cb0027582e37bd8ab93547f60b8aa0781bab86-370bb954591da1189700301c59b5671eea828384b2f2050db49274a3f277d1a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/11/05/reading-seminar-4-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/comment-page-1/#comment-42286")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("I don’t believe that’s the case. While the finiteness of mu(X^2) isn’t used directly in the proof of 3.4, it underlies many of the theorems used to prove it (in particular, 2.16 is used extensively, and the proof of 2.16 was where we kept using the covering argument).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/reading-seminar-4-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/comment-page-1/#comment-42294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("OK, I’ve added the hypothesis in. I guess the situation will get clarified in later seminars, when we get to the proof of Theorem 3.4…")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/474cd66fddf69bfc97a62a81dc8e1e26e916808111ea7f41c7fc311a7b893de6-801013fae7233c6771fab7e2f51a27174170cde3f1041552c65ad12a25e37160.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ehud Hrushovski")]], [#link("https://terrytao.wordpress.com/2009/11/05/reading-seminar-4-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/comment-page-1/#comment-42339")[#strong[#text("Ehud Hrushovski")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2009")])]

#text("I am truly grateful to everyone for your reading, notes, and comments.")#linebreak()#text(" A revised version of the paper can be found at:")

#link("http://www.math.huji.ac.il/~ehud/NQF")[#text("http://www.math.huji.ac.il/~ehud/NQF")]

#text("The changes are all local; the largest ones are in the statement of 1.1 and the proofs of 1.2 and 4.2, based on comments of Anand and Terry. There are also two examples related to Freiman’s theorem, 4.10 and 4.16.")

#text("I’ll update ArXiv after making a few more emendations, but meanwhile")#linebreak()#text(" I plan to keep an updated file at this site.")

#text("Udi")
]
