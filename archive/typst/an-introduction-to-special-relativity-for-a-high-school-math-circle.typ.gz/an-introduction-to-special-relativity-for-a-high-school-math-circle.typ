// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/
// Converted to Typst by tao2typ: "2026-10-14T09:29:06.062924+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An introduction to special relativity for a high school math circle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An introduction to special relativity for a high school math circle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 December 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/")[#text("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Things are pretty quiet here during the holiday season, but one small thing I have been working on recently is ")#link("https://terrytao.wordpress.com/wp-content/uploads/2013/01/relativistic1.pdf")[#text("a set of notes on special relativity")]#text(" that I will be working through in a few weeks with some bright high school students here at our ")#link("http://www.math.ucla.edu/~radko/circles/")[#text("local math circle")]#text(". I have only two hours to spend with this group, and it is unlikely that we will reach the end of the notes (in which I derive the famous ")#link("http://en.wikipedia.org/wiki/Mass%E2%80%93energy_equivalence")[#text("mass-energy equivalence")]#text(" relation E=mc^2, largely following Einstein’s original derivation as discussed in ")#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/")[#text("this previous blog post")]#text("); instead we will probably spend a fair chunk of time on related topics which do not actually require special relativity ")#emph[#text("per se")]#text(", such as spacetime diagrams, the Doppler shift effect, and an analysis of my ")#link("https://terrytao.wordpress.com/2008/12/09/an-airport-inspired-puzzle/")[#text("airport puzzle")]#text(". This will be my first time doing something of this sort (in which I will be spending as much time interacting directly with the students as I would lecturing); I’m not sure exactly how it will play out, being a little outside of my usual comfort zone of undergraduate and graduate teaching, but am looking forward to finding out how it goes. (In particular, it may end up that the discussion deviates somewhat from my prepared notes.)")

#text("The material covered in ")#link("https://terrytao.wordpress.com/wp-content/uploads/2013/01/relativistic1.pdf")[#text("my notes")]#text(" is certainly not new, but I ultimately decided that it was worth putting up here in case some readers here had any corrections or other feedback to contribute (which, as always, would be greatly appreciated).")

#emph[#text("[Dec 24 and then Jan 21: ")#link("https://terrytao.wordpress.com/wp-content/uploads/2013/01/relativistic1.pdf")[#text("notes updated")]#text(", in response to comments.]")]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cd4d6f7c957fadda199dc126443e196e4eda2db3001bdea48132a5f43607760-fb213bab809261697e135d8664d4102f6329e5923004adbd3b7e525268462344.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deane")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-209605")[#strong[#text("Deane")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2012")])]

#text("I’m definitely showing this to my son. And I’m really envious that the LA math circle gets to learn stuff like special relativity from someone like you. As much as I like the math circle my son goes to, this sounds way better. Many thanks for sharing the notes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fd65a86c4e5d1dd78f7c98882d2c57118119c5f1312f4f44b75dc8b15a5acb3-5d9692165feae49991ccc8df282b63f6f9f3b7520f7581f6eb498aeedeac3d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-209621")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2012")])]

#text("An error in the notes: The caption to Figure 1 says “five minutes” where it should say “five seconds.”")

#text("[")#emph[#text("Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-209657")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2012")])]

#text("I too envy your pupils!")

#text("1. Note the difference between mc^2 and cm^2 . The first one breaks the convention of putting coefficients before variables, (it should be written c^2m because c is a constant and m is a variable) and the other one breaks the rule of evaluating power before product, (it should be written (cm)^2 when it means square centimeter rather than centi squaremeter).")

#text("2. One your figure 1 the arrows point in all directions.")

#text("3. In all other graphs of functions of time, the time axis points to the right and the space axis points opwards, but in relativity spacetime diagrams the convention is changed without comment or justification.")

#text("4. In figure 1 Alice is red and Bob is blue. In figure 3 Alice is blue and Bob is red. Why change the color coding?")

#text("5. “we will not use this alternate form of Planck’s relation here.” Why then add to the confusion by mentioning it?")

#text("6. “an elementary particle might decay into two other particles plus a photon”. A bound state of an electron and a positron may decay into two photons (AFAIK). That is a perfectly good example.")

#text("7. “if the algebra looks tough, you might try to warm up by first considering the case c = 1”. Why don’t you take you own medicine yourself? All your formulas become more pallatable when the c is omitted.")

#text("Good luck and thank you!")

#text("[")#emph[#text("Thanks, I’ll update the ms to address some of these issues. Regarding arrows: in such diagrams the arrows are purely decorative and serve no significant function, but part of the philosophy of spacetime diagrams is that time should be treated on an equal footing with space as much as possible. In particular, much as one can freely move one’s spatial perspective arbitrarily to the right or left, one can arbitrarily move one’s temporal perspective into the future or to the past (even though our subjective worldline experience only goes in one direction). ")]

#text("Regarding the c=1 normalisation; I had thought about this issue, but ended up not wanting to spend much time digressing on the topic of the choice of physical units and how they can be used to set various fundamental physical constants to equal 1; this is an important thing to learn, but given the time constraints I felt it would be better if it were omitted. On the other hand, the _mathematical_ trick of attacking a problem by first setting one of the parameters to a simple value to reach a model special case is a general trick that should be immediately useful to these high school students, and I decided to emphasise that approach instead. -T]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4734140d75448931d2959640a0e7d5834d1c1414fc5b39f214d9949a357aad80-0ff663b7a9d5b31683c59ecc76604f878a904846e8af7377c396a77f1191657d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Globules")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-209698")[#strong[#text("Globules")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2012")])]

#text("On page 9, in “So it is natural for A to assign a higher energy value to O…”, replace A with Alice.")

#text("[")#emph[#text("Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8902227f1194907f388762e7671ef0a9a49ebe6c4b9f662aa6563d7c7f5b82a-48cd4c95fc0878e81ec7db7be58bdcf5d6e1d80796fad005ee60f0ca817b0bf1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adriano paolo shaul gershom palma")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-209728")[#strong[#text("adriano paolo shaul gershom palma")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2012")])]

#text("a quicko primer, this is how to derive C (‘c’ is the name fo the speed of light, which is a constant in sR) hug")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-209790")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2012")])]

#text("Typo: “emenating” should be “emanating” in the caption to figure 3.")

#text("In footnote 2 you’ve got “c equal to 1” in one place and “c equal to one” in another. Perhaps this is deliberate — I can kinda see how it might be — but you might consider removing the inconsistency.")

#text("[")#emph[#text("Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19f2fe7b7f034d9d01d35e97bd62d141f6d6f7b2be0ee205896fe4b60644c30f-8099a62c3618dbfb13c35296e6d3b6595d6dfdd53918b78bc84faac0071523cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eitan bachmat")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-209877")[#strong[#text("eitan bachmat")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2012")])]

#text("You can combine airport activity and relativity theory in another way, in fact everytime people board an airplane they are collectively computing the proper time of a (sometimes constrained) maximal curve in a compact space time domain. The Lorentzian metric is determined by the airline boarding policy and the physical configuration of the airplane, namely leg room and number of passengers per row. The simplest case of having no boarding policy and infinite leg room corresponds to Minkowski space.")#linebreak()#text(" See the ICM 2006 address of Percy Deift or that of Richard Stanley for relevant mathematical background. This is a discrete approach to relativity, an approach that started with physicists (Myrheim and t’Hooft, independently), but it models airplain boarding as well and that would be appropriate for high schoolers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-210173")[#strong[#text("Notas de Terry Tao sobre relatividad especial « Hic Sunt Draconis")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2012")]

#text("[…] ")#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-mat")[#text("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-mat")]#text("… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-210211")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2012")])]

#text("Deriving ")#mi("E = mc^2")#text(" for high school students is a challenge and you succeeded. Your argument is surely accessible at that stage. Some of my thoughts:")

#text("1. The airport puzzle is very nice, but does it really fit in here?")

#text("2. Add a figure for Exercise 3.3. The asymmetry is fundamental to your argument. Why hiding it in an exercise?")

#text("3. Is the two-way Doppler shift necessary for your argument?")

#text("4. Why do you introduce an alternate form of Planck’s relation if you are not going to use it? (Bo has mentioned that already.)")

#text("5. Exercise 4.1 and 5.1 are hard (at that level). If your audience does not understand the computations the magic is gone. You might consider to be much more verbose here. Maybe you should even mention elementary things like binomial formulas and the correct application of square roots.")

#text("6. For someone not used to approximations the end looks like cheating. You might consider to add a figure and an exercise to motivate why it is ok to make a small mistake here.")

#emph[#text("[I edited the notes to incorporate these suggestions, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7e8600aa7375a3e8003b7cee63c0d2adebad7753c87a76189f41830032e13a1-47693353c0439e22e8ab5a15dc0d74be09be8d1652c87d47aa91ab7788a32e31.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derek Wise")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-210267")[#strong[#text("Derek Wise")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2012")])]

#text("Typo: “better for Alice to tie one’s shoelaces” should be “better for Alice to tie her shoelaces”. By the way, Alice must be a pro at tying shoelaces — 2 seconds seems quite fast.")

#text("Also: “a light second is the amount of time light travels in a second” — “amount of time” should be “distance”. But this typo just proves that the Minkowskian revolution has really taken hold in your thinking: you forgot there was a difference between space and time. :-)")

#emph[#text("[I edited the notes to incorporate these suggestions, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3f51c6a4616b904a7bf913f57e004c4e90b40197bcf1ff6acdc57863f5247e4-ddea01dcc2ac783e388889925dc3074dc7f939ee50f5de691bc70ec31b0fa2a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvester J.Ryan")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-210424")[#strong[#text("Sylvester J.Ryan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2012")])]

#text("By use of space-time diagrams it is apparent that the two senarios of lace tying immediately before or after use of the motor way end with the same vertex point with parallel lines for motor way use plus lace tying, in the form of a parallelogram- tres dull..the fascination comes with appraisal of the lace tying event in the interval before the vertex point, starting with the simultaneity of the lace tying onset with onset of use of the motor way, and in turn with the moment of cessation of use of the motor way..the slope of the save-time lace tying event is 1/2 of the other two previously mentioned Space-time lines..now without calculations and intuition where will the space-time line of this third category intersect with the vertical portion of the space-time line of the case of lace tying after getting off the motor way..what if one case represented an electron and the other a positron, with lace tying the mutual interaction..does the perpendicular between space-time lines represent time travel?? Too fatigued to do math calc. And is calculation needed for this..geometry versus topology ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f2e90f7b1bd21c93d591d1a92d96a7a440843f6b82aa209f6788de28cd62882-87274f964b908ad08db58e6b1f6039f4f476139fc572ab012d956cf2a8d3b101.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Albanius")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-210754")[#strong[#text("Albanius")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2012")])]

#text("Figure 3 time looks wrong:")#linebreak()#text(" shouldn’t arrival at right side of moving walkway be 12:04:20,")#linebreak()#text(" final arrival 12:07:40, since travel on 100m walkway should take 50s?")

#emph[#text("[Thanks, this will be corrected in the next version of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8e6fe581c75ae56ad27f36b29079a2043bb70488aea3cc76c5e620ce8aef81a-7ab82d051255dee9c7682bc2783ed45176429d60a46b3b1df9dadab046850dd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stuart S")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-210764")[#strong[#text("Stuart S")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2012")])]

#text("Hi Terry, I am not a physicist, so I could very easily be wrong.")

#text("It was my belief that the twin paradox arose due to each twin observing the other twin as traveling at high speeds, hence the paradox arose when one tried to determine which of the twins experienced the time dilation.")

#text("I believed this was cleared up when it was made apparent that the twin which underwent acceleration would be the twin that experiences time dilation.")

#text("Once again, that was my interpretation, and if some would either confirm or contradict, it would be appreciated.")

#text("I am only reading it on my phone at the moment, but I love set out and approach.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c0fd2780085a79cda5285a2f4238ba510deb7f0e7a7c3873d170f838e652f0d-b91abca72e3ecb92e7d3c9188106b410d63d04b8244db7d6ebb56b18732b4aa4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh Samani")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-213013")[#strong[#text("Josh Samani")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2013")])]

#text("Hi Terry,")

#text("I am a physics grad (you’re actually on my grad committee at UCLA), and I think this is an important, subtle point. In your notes you write")

#text("“Actually, it turns")#linebreak()#text(" out that the situation is symmetric: from Bob’s point of view, Alice experiences")#linebreak()#text(" time dilation, while from Alice’s point of view, Bob also experiences time dilation.”")

#text("This is true when both Alice and Bob are inertial observers, but when they start spatially coincident but one of the twins accelerates away from earth and then returns, the symmetry is broken, and that is why it makes sense for one twin to be older and the other younger once they are again spatially coincident in the end.")

#text("My apologies if this was addressed somewhere else, and I didn’t notice.")

#emph[#text("[Fair enough, I’ll add a comment to this effect in the next revision of the ms. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f2e90f7b1bd21c93d591d1a92d96a7a440843f6b82aa209f6788de28cd62882-87274f964b908ad08db58e6b1f6039f4f476139fc572ab012d956cf2a8d3b101.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Albanius")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-507466")[#strong[#text("Albanius")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2018")])]

#text("A simple Gen Rel explanation I got from Sean Carroll: the twin experiencing acceleration follow a worldline which travels more in space, relatively less in time compred to an inertial, unaccelerated trajectory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f2e90f7b1bd21c93d591d1a92d96a7a440843f6b82aa209f6788de28cd62882-87274f964b908ad08db58e6b1f6039f4f476139fc572ab012d956cf2a8d3b101.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of albanius")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-671545")[#strong[#text("albanius")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2023")])]

#text("I posed the question to Sean M. Carroll, the physicist, approximately thus: “if you went off on an interstellar cruise at relativistic speed while biologist Sean B. Carroll stayed on Earth, wouldn’t you each perceive the other as time dilated.” His answer in terms of world lines was clear and conclusive.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-210996")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2012")])]

#text("During a holiday course I have discussed chapter 1 – 3 (because of time constraints without the airport puzzle) with a 17 year old student.That took about 45 minutes with a large fraction of time spent to translate your notes to german. Depending on our motivation we plan to do chapter 4 next week.")

#text("Typo: In the first sentence of chapter 2 … and and …")

#emph[#text("[Thanks, this will be corrected in the next version of the ms. I’m hoping to cover Chapters 1-4 in two hours, and maybe leave Chapter 5 for interested students to work out on their own, if time runs out. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of P")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-211284")[#strong[#text("P")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2012")])]

#text("A little summer school advertisement for high school students:")

#link("http://www.math.tamu.edu/outreach/SMaRT/")[#text("http://www.math.tamu.edu/outreach/SMaRT/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An introduction to special relativity for a high school math circle « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-211416")[#strong[#text("An introduction to special relativity for a high school math circle « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("[…] An introduction to special relativity for a high school math circle. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1a8de4673b1ac28cb0c36dcfbaa8c63b0a8f79963e489f2d2f98dd849a7407-de9933c79d9886bcf7ddbb02f91a6968c2adfe3f4fbf18023ae19851431613b0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Cooper")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-211516")[#strong[#text("Alan Cooper")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2012")])]

#text("I like this but do have some suggestions.")

#text("One thing that always troubles me about the focus on spacetime diagrams as the essence of special relativity is the fact that they are perfectly compatible with the classical case in which there is a well-defined spacelike direction, and indeed the setup of drawing space and time axes is counter to the “mixing” of space and time that is essential to the theory. The essence of relativity is that the axes only represent one person’s point of view and that a moving observer will define them quite differently, and I would suggest making that point right at the outset.")

#text("Also I think Stuart is right about the twin “paradox” (being resolved by the fact that it is impossible to have the twins ever meet to compare ages without violating the condition that both live in inertial frames)")

#text("The derivation of E=mc^2 is cute but kind of begs (part of) the question by starting with the assumption that a material mass can in fact be converted to photons. It might be worth mentioning that there are other derivations which do not require either quantum theory or the convertibility of matter into radiation. (One of the great puzzles of history and paedagogy of modern physics is the extent to which ideas from two theories which we actually find very difficult to combine into a consistent whole are often used to motivate one another’s development.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-211547")[#strong[#text("Weekly links for December 30 « God plays dice")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2012")]

#text("[…] Terry Tao wrote an introduction to special relativity for a high school math circle. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-211672")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2013")])]

#text("I just found out that wikipedia has a wonderful explanation of how twin paradox is resolved. I used to think general relativity is needed to explain the twin paradox. Glad to be proved wrong. I guess the highly motivated students (and readers) would be grateful to know an external reference to this mind boggling problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af9b761f5a64adacdb95766bbb4225028fc40c0f20c92e9e2ab928d926886b95-c52a284815935f67537564de56afb6a7c869cce2eabbc9f2ac22b2676066a765.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhant Saraf")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-212457")[#strong[#text("Siddhant Saraf")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2013")])]

#text("Last line on page 10 (footnote 6) , “… consists of a particle together its antiparticle…”")#linebreak()#text(" Missing a ‘with’ there.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-213091")[#strong[#text("Víkendové surfovanie « life in progress")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")]

#text("[…] Terry Tao o špeciálnej teórii relativity – pripravené pre stredoškolákov […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-213969")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2013")])]

#text("Dear Pro.Tao,")

#text("In figure 4,I found that those black lines which represent sound are not Parallel with each other,nor are they symmetry regarding the t-axis,this means that the |velocity| of the sound changes,but in fact the |velocity| of the sound does not change.Is it your problem or my problem……")

#emph[#text("[Yes, some of the image elements were not aligned properly; it should be fixed now. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-214147")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2013")])]

#text("Dear Prof.Tao,")

#text("In Exercise 4.1,(g),It seems that “Doppler .s.h.i.t.s” should be “Doppler shifts”…")

#emph[#text("[Gah, that is fixed now. Well, I guess some of the high school students will have been amused by that typo… -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cdc94c46dd95f3e06456e52103dda98f2ed72f5f47f4199ac5bf764704fa7995-6868b135518408566e91dbc043fd9ac893028490788323f21c3d701842a39533.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tõnu Eevere")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-217393")[#strong[#text("Tõnu Eevere")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2013")])]

#text("Mistahes üksühene seos (vastavus) on avaldatav funktsionaalselt, nii nagu f(x) = y; nii ka g(y) = x; vastavalt niisiis teisendusfunktsioon f(ct) ja teisenduse pöördfunktsioon. Hulgateoreetiliselt nii f kui ka g laienevad koguhulkadele: fE) = F; ja g(F) = E;")#linebreak()#text(" Kui meil on seos üldliikmete x ja y vahel, siis need elemendid/hulgad – on olemas (Vt. Valiku e. Zermelo aksioom).")#linebreak()#text(" Vaatleme Galilei teisendust sihil v (teljel x), alghetkest, mil AB = r = ct;")#linebreak()#text(" x`= x – vt; f(ct) = ct(1 – v/c); ja g(ct) = ct/(1- v/c);")#linebreak()#text(" On kerge näha, et funktsioon f määrab relatiivse ruumi F; g – aga määrab nn. “sündmuste-vahelise ruumi” E*, mis ei tarvitse olla samane hulgaga E.")#linebreak()#text(" Ometigi, kui küsida vastust Zenoni apooriale: kuskohas saab Achilleus kätte kilpkonna, kui vastavad kiirused on v ja c, kusjuures Achilleus on (kunagi) mõõtnud ära selle esialgse vahemaa kui R =ct.")#linebreak()#text(" Vastus: Achilleus saab kilpkonna kätte Achilleuse ruumis,")#linebreak()#text(" kohal g(ct) = ct/(1 – v/c).")#linebreak()#text(" Üldine Galilei ruumiteisendus on: f(ct) = ct[1 – (v/c)cosa];")#linebreak()#text(" selle laotus Cartesiuse ristkoordinaadile avaldub dimensionaalsete seostega: x`= ctcosa – vt; y`= k ctsina; z`= k ctsina;")#linebreak()#text(" milles k – on k = 1/L, milles L – on Lorentz-tegur.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f076414023cf78cc35eaedc671e0b0ff61340cba522dae267a940f1775960af5-b6828cfa8ffc2f15788b10971a0bb5ca33bbc70ac193953d95c5a78819edbfcf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toofan")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-281310")[#strong[#text("Toofan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2014")])]

#text("There is an excellent physic book which deals with the most complicated aspects of relativity (including General relativity and its cosmological results such as black holes) while only using very simple high school math. (The approximate answers are of course corrected at the end of each calculation).")#linebreak()#text(" Unfortunately the book is in German, but you may find it quite handy and useful in your project, if one can translate it into English.")

#text("Here is the name of the author and the book:")#linebreak()#text(" Roman Ulrich Sexl Gravitation und Kosmologie: Eine Einf. in d. allgemeine Relativitatstheorie (1975)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/22/an-introduction-to-special-relativity-for-a-high-school-math-circle/#comment-671543")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2023")])]

#text("In Figure 4, it looks not so obvious that in the bottom half of the diagram (in which Alice is approaching Bob), the sound waves that reach Bob are squashed together (indicating the higher frequency) and in the top half (in which Alice is moving away from Bob) the sound waves that reach Bob are stretched out. The two groups of black lines both look parallel (within each group). Or are they supposed to be parallel?")

#emph[#text("[They are parallel, but the distance between adjacent parallel lines is shorter in the bottom half (less than a tick) than in the top half (more than a tick) – T.]")]
]
