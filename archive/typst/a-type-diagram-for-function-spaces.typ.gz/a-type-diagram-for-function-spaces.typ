// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/
// Converted to Typst by tao2typ: "2026-10-14T16:36:07.504932+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A type diagram for function spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A type diagram for function spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 March 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/")[#text("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In harmonic analysis and PDE, one often wants to place a function ")#mi("f: {\\bf R}^d \\to {\\bf C}")#text(" on some domain (let’s take a Euclidean space ")#mi("{\\bf R}^d")#text(" for simplicity) in one or more function spaces in order to quantify its “size” in some sense. Examples include")

#list(
[#text("The ")#link("http://en.wikipedia.org/wiki/Lp_space")[#text("Lebesgue spaces")]#text(" ")#mi("L^p")#text(" of functions ")#mi("f")#text(" whose norm ")#tao-math("\\left\\|f\\right\\|_{L^p} := (\\int_{{\\bf R}^d} \\left|f\\right|^p)^{1/p}", block: false)#text(" is finite, as well as their relatives such as the ")#link("http://en.wikipedia.org/wiki/Lp_space#Weak_Lp")[#text("weak ")#mi("L^p")#text(" spaces")]#text(" ")#mi("L^{p,\\infty}")#text(" (and more generally the ")#link("http://en.wikipedia.org/wiki/Lorentz_space")[#text("Lorentz spaces")]#text(" ")#mi("L^{p,q}")#text(") and ")#link("http://en.wikipedia.org/wiki/Birnbaum%E2%80%93Orlicz_space")[#text("Orlicz spaces")]#text(" such as ")#mi("L \\log L")#text(" and ")#mi("e^L")#text(";")],
[#text("The classical regularity spaces ")#mi("C^k")#text(", together with their ")#link("http://en.wikipedia.org/wiki/H%C3%B6lder_condition")[#text("Hölder continuous")]#text(" counterparts ")#mi("C^{k,\\alpha}")#text(";")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Sobolev_space")[#text("Sobolev spaces")]#text(" ")#mi("W^{s,p}")#text(" of functions ")#mi("f")#text(" whose norm ")#tao-math("\\left\\|f\\right\\|_{W^{s,p}} = \\left\\|f\\right\\|_{L^p} + \\left\\| \\left|\\nabla\\right|^s f\\right\\|_{L^p}", block: false)#text(" is finite (other equivalent definitions of this norm exist, and there are technicalities if ")#mi("s")#text(" is negative or ")#mi("p \\not \\in (1,\\infty)")#text("), as well as relatives such as homogeneous Sobolev spaces ")#mi("\\dot W^{s,p}")#text(", ")#link("http://en.wikipedia.org/wiki/Besov_space")[#text("Besov spaces")]#text(" ")#mi("B^{s,p}_q")#text(", and Triebel-Lizorkin spaces ")#mi("F^{s,p}_q")#text(". (The conventions for the superscripts and subscripts here are highly variable.)")],
[#link("http://en.wikipedia.org/wiki/Hardy_space")[#text("Hardy spaces")]#text(" ")#mi("{\\mathcal H}^p")#text(", the space BMO of functions of ")#link("http://en.wikipedia.org/wiki/Bounded_mean_oscillation")[#text("bounded mean oscillation")]#text(" (and the subspace VMO of functions of vanishing mean oscillation);")],
[#text("The ")#link("http://planetmath.org/encyclopedia/WienerAlgebra.html")[#text("Wiener algebra")]#text(" ")#mi("A")#text(";")],
[#text("Morrey spaces ")#mi("M^p_q")#text(";")],
[#text("The space ")#mi("M")#text(" of finite measures;")],
[#text("etc., etc.")]
)

#text("As the above partial list indicates, there is an entire zoo of function spaces one could consider, and it can be difficult at first to see how they are organised with respect to each other. However, one can get some clarity in this regard by drawing a ")#emph[#text("type diagram")]#text(" for the function spaces one is trying to study. A type diagram assigns a tuple (usually a pair) of relevant exponents to each function space. For function spaces ")#mi("X")#text(" on Euclidean space, two such exponents are the ")#emph[#text("regularity")]#text(" ")#mi("s")#text(" of the space, and the ")#emph[#text("integrability")]#text(" ")#mi("p")#text(" of the space. These two quantities are somewhat fuzzy in nature (and are not easily defined for all possible function spaces), but can basically be described as follows. We test the function space norm ")#tao-math("\\left\\|f\\right\\|_X", block: false)#text(" of a modulated rescaled bump function")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(x) := A e^{i x \\cdot \\xi} \\phi( \\frac{x-x_0}{R} )")]]

#text("where ")#mi("A > 0")#text(" is an amplitude, ")#mi("R > 0")#text(" is a radius, ")#mi("\\phi \\in C^\\infty_c({\\bf R}^d)")#text(" is a test function, ")#mi("x_0")#text(" is a position, and ")#mi("\\xi \\in {\\bf R}^d")#text(" is a frequency of some magnitude ")#tao-math("\\left|\\xi\\right| \\sim N", block: false)#text(". One then studies how the norm ")#tao-math("\\left\\|f\\right\\|_X", block: false)#text(" depends on the parameters ")#mi("A, R, N")#text(". Typically, one has a relationship of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|f\\right\\|_X \\sim A N^s R^{d/p}", block: true)]]

#text("for some exponents ")#mi("s, p")#text(", at least in the high-frequency case when ")#mi("N")#text(" is large (in particular, from the uncertainty principle it is natural to require ")#mi("N \\gtrsim 1/R")#text(", and when dealing with inhomogeneous norms it is also natural to require ")#mi("N \\gtrsim 1")#text("). The exponent ")#mi("s")#text(" measures how sensitive the ")#mi("X")#text(" norm is to oscillation, and thus controls regularity; if ")#mi("s")#text(" is large, then oscillating functions will have large ")#mi("X")#text(" norm, and thus functions in ")#mi("X")#text(" will tend not to oscillate too much and thus be smooth. Similarly, the exponent ")#mi("p")#text(" measures how sensitive the ")#mi("X")#text(" norm is to the function ")#mi("f")#text(" spreading out to large scales; if ")#mi("p")#text(" is small, then slowly decaying functions will have large norm, so that functions in ")#mi("X")#text(" tend to decay quickly; conversely, if ")#mi("p")#text(" is large, then singular functions will tend to have large norm, so that functions in ")#mi("X")#text(" will tend to not have high peaks.")

#text("Note that the exponent ")#mi("s")#text(" in (2) could be positive, zero, or negative, however the exponent ")#mi("p")#text(" should be non-negative, since intuitively enlarging ")#mi("R")#text(" should always lead to a larger (or at least comparable) norm. Finally, the exponent in the ")#mi("A")#text(" parameter should always be ")#mi("1")#text(", since norms are by definition homogeneous. Note also that the position ")#mi("x_0")#text(" plays no role in (1); this reflects the fact that most of the popular function spaces in analysis are translation-invariant.")

#text("The type diagram below plots the ")#mi("s, 1/p")#text(" indices of various spaces. The black dots indicate those spaces for which the ")#mi("s, 1/p")#text(" indices are fixed; the blue dots are those spaces for which at least one of the ")#mi("s, 1/p")#text(" indices are variable (and so, depending on the value chosen for these parameters, these spaces may end up in a different location on the type diagram than the typical location indicated here).")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/03/newtype.png")[#image("../assets/68882cb92ebae135f99a0c7a12615d8da2256a5191c28499f2aa8bf47e08b8f0-04211fe66c03b76c26c74a0ceb5d3cb37ceeacb6ae27a795ea756258905b07bf.png", width: 90%)]

#text("(There are some minor cheats in this diagram, for instance for the Orlicz spaces ")#mi("L \\log L")#text(" and ")#mi("e^L")#text(" one has to adjust (1) by a logarithmic factor. Also, the norms for the Schwartz space ")#mi("{\\mathcal S}")#text(" are not translation-invariant and thus not perfectly describable by this formalism. This picture should be viewed as a visual aid only, and not as a genuinely rigorous mathematical statement.)")

#text("The type diagram can be used to clarify some of the relationships between function spaces, such as Sobolev embedding. For instance, when working with inhomogeneous spaces (which basically identifies low frequencies ")#mi("N \\ll 1")#text(" with medium frequencies ")#mi("N \\sim 1")#text(", so that one is effectively always in the regime ")#mi("N \\gtrsim 1")#text("), then decreasing the ")#mi("s")#text(" parameter results in decreasing the right-hand side of (1). Thus, one expects the function space norms to get smaller (and the function spaces to get larger) if one decreases ")#mi("s")#text(" while keeping ")#mi("p")#text(" fixed. Thus, for instance, ")#mi("W^{k,p}")#text(" should be contained in ")#mi("W^{k-1,p}")#text(", and so forth. Note however that this inclusion is not available for homogeneous function spaces such as ")#mi("\\dot W^{k,p}")#text(", in which the frequency parameter ")#mi("N")#text(" can be either much larger than ")#mi("1")#text(" or much smaller than ")#mi("1")#text(".")

#text("Similarly, if one is working in a compact domain rather than in ")#mi("{\\bf R}^d")#text(", then one has effectively capped the radius parameter ")#mi("R")#text(" to be bounded, and so we expect the function space norms to get smaller (and the function spaces to get larger) as one increases ")#mi("1/p")#text(", thus for instance ")#mi("L^2")#text(" will be contained in ")#mi("L^1")#text(". Conversely, if one is working in a discrete domain such as ")#mi("{\\Bbb Z}^d")#text(", then the radius parameter ")#mi("R")#text(" has now effectively been bounded from below, and the reverse should occur: the function spaces should get larger as one ")#emph[#text("decreases")]#text(" ")#mi("1/p")#text(". (If the domain is both compact ")#emph[#text("and")]#text(" discrete, then it is finite, and on a finite-dimensional space all norms are equivalent.)")

#text("As mentioned earlier, the uncertainty principle suggests that one has the restriction ")#mi("N \\gtrsim 1/R")#text(". From this and (2), we expect to be able to enlarge the function space by trading in the regularity parameter ")#mi("s")#text(" for the integrability parameter ")#mi("p")#text(", keeping the dimensional quantity ")#mi("d/p - s")#text(" fixed. This is indeed how Sobolev embedding works. Note in some cases one runs out of regularity before p goes all the way to infinity (thus ending up at an ")#mi("L^p")#text(" space), while in other cases p hits infinity first. In the latter case, one can embed the Sobolev space into a Holder space such as ")#mi("C^{k,\\alpha}")#text(".")

#text("On continuous domains, one can send the frequency ")#mi("N")#text(" off to infinity, keeping the amplitude ")#mi("A")#text(" and radius ")#mi("R")#text(" fixed. From this and (1) we see that norms with a lower regularity ")#mi("s")#text(" can never hope to control norms with a higher regularity ")#mi("s^{\\prime} > s")#text(", no matter what one does with the integrability parameter. Note however that in discrete settings this obstruction disappears; when working on, say, ")#mi("{\\bf Z}^d")#text(", then in fact one can gain as much regularity as one wishes for free, and there is no distinction between a Lebesgue space ")#mi("\\ell^p")#text(" and their Sobolev counterparts ")#mi("W^{k,p}")#text(" in such a setting.")

#text("When interpolating between two spaces (using either the real or complex interpolation method), the interpolated space usually has regularity and integrability exponents on the line segment between the corresponding exponents of the endpoint spaces. (This can be heuristically justified from the formula (2) by thinking about how the real or complex interpolation methods actually work.) Typically, one can control the norm of the interpolated space by the geometric mean of the endpoint norms that is indicated by this line segment; again, this is plausible from looking at (2).")

#text("The space ")#mi("L^2")#text(" is self-dual. More generally, the dual of a function space ")#mi("X")#text(" will generally have type exponents that are the reflection of the original exponents around the ")#mi("L^2")#text(" origin. Consider for instance the dual spaces ")#mi("H^s, H^{-s}")#text(" or ")#mi("{\\mathcal H}^1, BMO")#text(" in the above diagram.")

#text("Spaces whose integrability exponent ")#mi("p")#text(" is larger than 1 (i.e. which lie to the left of the dotted line) tend to be Banach spaces, while spaces whose integrability exponent is less than 1 are almost never Banach spaces. (This can be justified by covering a large ball into small balls and considering how (1) would interact with the triangle inequality in this case). The case ")#mi("p=1")#text(" is borderline; some spaces at this level of integrability, such as ")#mi("L^1")#text(", are Banach spaces, while other spaces, such as ")#mi("L^{1,\\infty}")#text(", are not.")

#text("While the regularity ")#mi("s")#text(" and integrability ")#mi("p")#text(" are usually the most important exponents in a function space (because amplitude, width, and frequency are usually the most important features of a function in analysis), they do not tell the entire story. One major reason for this is that the modulated bump functions (1), while an important class of test examples of functions, are by no means the only functions that one would wish to study. For instance, one could also consider sums of bump functions (1) at different scales. The behaviour of the function space norms on such spaces is often controlled by secondary exponents, such as the second exponent ")#mi("q")#text(" that arises in Lorentz spaces, Besov spaces, or Triebel-Lizorkin spaces. For instance, consider the function")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f_M(x) := \\sum_{m=1}^M 2^{-md} \\phi(x/2^m),")]]

#text("where ")#mi("M")#text(" is a large integer, representing the number of distinct scales present in ")#mi("f_M")#text(". Any function space with regularity ")#mi("s=0")#text(" and ")#mi("p=1")#text(" should assign each summand ")#mi("2^{-md} \\phi(x/2^m)")#text(" in (3) a norm of O(1), so the norm of ")#mi("f_M")#text(" could be as large as ")#mi("O(M)")#text(" if one assumes the triangle inequality. This is indeed the case for the ")#mi("L^1")#text(" norm, but for the weak ")#mi("L^1")#text(" norm, i.e. the ")#mi("L^{1,\\infty}")#text(" norm, ")#mi("f_M")#text(" only has size ")#mi("O(1)")#text(". More generally, for the Lorentz spaces ")#mi("L^{1,q}")#text(", ")#mi("f_M")#text(" will have a norm of about ")#mi("O(M^{1/q})")#text(". Thus we see that such secondary exponents can influence the norm of a function by an amount which is polynomial in the number of scales. In many applications, though, the number of scales is a “logarithmic” quantity and thus of lower order interest when compared against the “polynomial” exponents such as ")#mi("s")#text(" and ")#mi("p")#text(". So the fine distinctions between, say, strong ")#mi("L^1")#text(" and weak ")#mi("L^1")#text(", are only of interest in “critical” situations in which one cannot afford to lose any logarithmic factors (this is for instance the case in much of Calderon-Zygmund theory).")

#text("We have cheated somewhat by only working in the high frequency regime. When dealing with inhomogeneous spaces, one often has a different set of exponents for (1) in the low-frequency regime than in the high-frequency regime. In such cases, one sometimes has to use a more complicated type diagram to genuinely model the situation, e.g. by assigning to each space a convex set of type exponents rather than a single exponent, or perhaps having two separate type diagrams, one for the high frequency regime and one for the low frequency regime. Such diagrams can get quite complicated, and will probably not be much use to a beginner in the subject, though in the hands of an expert who knows what he or she is doing, they can still be an effective visual aid.")

#heading(level: 1)[#text("Comments (33)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba1b7c31d8ddd3ce98d3e9b2bc4bea495bfd1fb26cf4017610b827535a2487b8-157b01713ac8e48c52fb14c671e807be3e294c24acdaa98cbd82bddf7d31ec65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kunal")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43844")[#strong[#text("kunal")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2010")])]

#text("Nice post.")

#text("“…so we expect the function space norms to get smaller (and the function spaces to get larger) as one increases 1/p…”")

#text("– I guess what was meant is that “as one increases p”.")

#text("A similar typo is there for the sequence spaces, immediately after this line.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43851")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2010")])]

#text("Actually, I believe the inclusions are correct as they stand. (Increasing 1/p is of course equivalent to decreasing p.) Note that the norms and the spaces go in different directions; making the norms smaller causes the spaces to become larger, and vice versa.")

#text("For historical reasons p is the exponent used to denote integrability, but in many ways 1/p is in fact the more natural quantity (particularly with regard to interpolation and dimensional analysis).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b007c45df4e4efc7afb6ab6dd122aa86295bb881ef5341831e7c3b70f1babca7-d48de9143ab4bafe86ce90372f6e8d5f0677fa90039212c2302e8ae3f552da55.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathchief")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43852")[#strong[#text("mathchief")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2010")])]

#text("“Thus, one expects the function space norms to get smaller (and the function spaces to get larger) if one decreases s while keeping p fixed. Thus, for instance, W^{k,p} should contain W^{k-1,p}”")

#text("I think it should be the reverse way right? since decrease s by 1, therefore the norms gets smaller, the function may have W^{k,p} norm equal to \\infty but has a finite W^{k-1,p} norm")

#emph[#text("[Corrected, thanks. Ironic that I had to do this after cautioning against precisely this confusion – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b007c45df4e4efc7afb6ab6dd122aa86295bb881ef5341831e7c3b70f1babca7-d48de9143ab4bafe86ce90372f6e8d5f0677fa90039212c2302e8ae3f552da55.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathchief")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43853")[#strong[#text("mathchief")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2010")])]

#text("BTW really nice article, the visualization of different spaces is so awesome, IMHO every analysis book should add the graph whenever introducing the function spaces lol")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43861")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2010")])]

#text("Although two dimensional, the diagram is not a “periodic table” — yet is just as useful and illuminating! Great organizational and explanatory thread.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef3ae79bd944137a0ccf68ddfb4ed9dfeeb13f961a9a3b4d2ab56fa684b5a23a-2affba240ffd94ccd755a866d2425adef2dc8d0dcaadef7222e988fcfcbf79a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43864")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2010")])]

#text("Really cool diagram Terry, thank you! I’m thinking about a 3-D version where the horizontal axes are 1/p and 1/q. This will help better visualize those spaces that depend on two integrability parameters. The third axis would still be smoothness. I’d also add modulation spaces into the mix, which fit nicely in your exposition too. Thanks again!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-613606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2020")])]

#text("Very interesting diagram!")#linebreak()#text(" I have a question. Some of function space are known to be algrbras as well, some are not. For example, as it is well-known, in ")#mi("L^p")#text(" spaces, ")#mi("p= \\infty")#text(" provides a nice algebra, with the usual pointwise multiplication. The resulted algebra is ")#mi("C^*")#text("-algbra (in fact a von Neumann algebra). For ")#mi("p=1")#text(", we have a Banach algebra with convolution as multiplication. And for other ")#mi("p")#text(", there is no algebra.")#linebreak()#text(" It is interesting for me to have an interpretaion of this phenemenon, but I’m not able to do so")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-614220")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#text("Well, all the ")#mi("\\ell^p({\\bf Z})")#text(" spaces for ")#mi("1 \\leq p \\leq \\infty")#text(" are Banach algebras with respect to pointwise multiplication; admittedly only the ")#mi("p=\\infty")#text(" one is unital, but one could for instance adjoin a unit to create a unital Banach algebra ")#mi("{\\bf C} \\oplus \\ell^p({\\bf Z})")#text(". So I don’t think there is any particularly simple relationship between the exponent of integrability of a space and its propensity to be a Banach algebra. (On the other hand, ")#mi("C^*")#text(" algebras are most naturally thought of as spaces with ")#mi("L^\\infty")#text(" type norms (or operator norms, in the noncommutative case), as one sees from the Gelfand-Naimark theorem.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23bf00d119f264c8fb45fb8a053ba42daa31d05a719782cf4eeded1822fff845-72691823a0ab8166006fe0300e84b1b7b9e361146651d68c93ee4f2cf8398220.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Bailey")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43900")[#strong[#text("Andrew Bailey")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2010")])]

#text("Wow, really nice article. It’s given me a whole new perspective. Thanks. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2010")])]

#text("Dear Terry,")

#text("Dumb question: How is regularity defined on discrete spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43928")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("One can use discrete derivatives (i.e. divided differences) or the Fourier transform. In the discrete case, the Sobolev space hierarchy collapses (e.g. ")#mi("W^{s,p}")#text(" collapses to ")#mi("\\ell^p")#text("), as the derivative operators are now bounded in ")#mi("\\ell^p")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43914")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2010")])]

#text("I have seen that some version of this diagram was called “the DeVore diagram”, in approximation theory talks or literature.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4514941d939bcef900e626ddde66fad70a4d7ce517ec98a7260ab82e54f56f4-3ec7286dccac13182ba58953e5421dd8e4bfac68008adf391d2c13c5aecfc590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ming Wang")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43918")[#strong[#text("Ming Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("What a nice diagram! How can I apply it to other function spaces, such as Morrey spaces and Campanato spaces?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-43976")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2010")])]

#text("I remember a crude pre-alpha-version of this diagram in 245C last semester. I’m glad you were able to finish it. It is extremely helpful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a72959a509ac6454f50666acb44a5de1be33b9a0a35486a19cd018078546acdd-76657d174e1ac325488996fc11b24bca5251cee43a444368e1b5c4cc3b3af507.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-44028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2010")])]

#text("Dear Terry,")

#text("Excellent post! If I may ask, what program did you use to draw the diagram?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-44029")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2010")])]

#text("The diagram was initially drawn on Winfig.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amplitude-frequency dynamics for semilinear dispersive equations « What’s new")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-44081")[#strong[#text("Amplitude-frequency dynamics for semilinear dispersive equations « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2010")])]

#text("[…] sometimes acquires a reputation for being unduly technical as a consequence. However, as noted in a previous blog post, one can view function space norms as a way to formalise the intuitive notions of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-44773")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2010")])]

#text("Minor typo:")#linebreak()#text(" “The Sobolev spaces W^{s,p} of functions f of functions whose norm”")#linebreak()#text(" should be")#linebreak()#text(" “The Sobolev spaces W^{s,p} of functions f whose norm”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-46715")[#strong[#text("A type diagram for function spaces (via What’s new) | Hello, world!")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2010")]

#text("[…] In harmonic analysis and PDE, one often wants to place a function on some domain (let's take a Euclidean space for simplicity) in one or more function spaces in order to quantify its \"size\" in some sense. Examples include The Lebesgue spaces of functions whose norm is finite, as well as their relatives such as the weak $ … Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-50762")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")])]

#text("The picture is very nice. What kind of software did you use for the diagram?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-50765")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")])]

#text("xfig (or more precisely, winfig).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-57658")[#strong[#text("Nice picture « Hello, world!")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2011")]

#text("[…] A type diagram for function space from Terence Tao: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc93c032ff955d0251eab37100d880e3eb19336f2f2957d85a03d05845d3fbf0-fe89c866fd57ef796ad195e84b33a953985e4e3df6059b186b61e54430d62fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tati")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-459088")[#strong[#text("Tati")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2015")])]

#text("Dear Professor Tao, is there any way to quantify how large or small e.g. the set of ")#mi("L^2")#text(" functions in the set of ")#mi("L^1")#text(" functions (defined on the same interval), or e.g. how small the set of differentiable functions in the set of all continuous functions (defined on the same interval).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-459089")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2015")])]

#text("The classical approach is through Baire Category; it is an instructive exercise to show for instance that ")#mi("L^2([0,1])")#text(" is a meager subset of ")#mi("L^1([0,1])")#text(". Nowadays one also sees more quantitative ways to measure the smallness of a subset of a Banach space, e.g. covering numbers, Gelfand width, etc. One can also work in finite dimensions and ponder, for instance, the relative sizes of the unit octahedron in ")#mi("\\ell^1_n")#text(" and the unit ball in ")#mi("\\ell^2_n")#text(". The general area of high dimensional geometry addresses these sorts of questions, see e.g. Pisier’s book on the subject.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc93c032ff955d0251eab37100d880e3eb19336f2f2957d85a03d05845d3fbf0-fe89c866fd57ef796ad195e84b33a953985e4e3df6059b186b61e54430d62fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tati")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-459090")[#strong[#text("Tati")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2015")])]

#text("This is very helpful! Thanks so much!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-461563")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("Let ")#mi("U")#text(" be an open set of ")#mi("\\mathbb{R^n}")#text(". I saw in Evan’s ")#emph[#text("Partial Differential Equations")]

#mi("C(U):=\\{u: U\\to\\Bbb{R} \\mid u \\text{ continuous}\\}")#linebreak()#text(" and")#linebreak()#text(" ")#mi("C(\\overline{U}):=\\{u\\in C(U)\\mid u\\ \\text{ is uniformly continuous on bounded subsets of } U\\}.")

#text("In Hunter’s Applied Analysis, ")#mi("C^k(\\overline{U})")#text(" consists of functions whose partial derivatives of order less than or equal to ")#mi("k")#text(" are uniformly continuous in ")#mi("U")#text(".")

#text("Also, I’ve seen some people define ")#mi("C(\\overline{U})")#text(" as functions in ")#mi("C(U)")#text(" that can be extended as functions in ")#mi("C(\\mathbb{R^n})")#text(".")

#text("Leoni points out in his First Course in Sobolev Spaces that while the definitions of the spaces ")#mi("C^k(U)")#text(" and $C^\\infty(U)$ are standard, in the literature there are different definitions of the spaces ")#mi("C^k(\\overline{U})")#text(" and ")#mi("C^\\infty(\\overline{U})")#text(", and “unfortunately these definitions do not coincide”.")

#text("I’ve seen ")#mi("C(\\bar U)")#text(" defined as in an undergraduate real analysis course that")

#mi("C(\\bar U)=\\{u: \\bar U\\to\\Bbb{R} \\mid u\\ \\text{continuous}\\}.")

#text("Would you clarify what is really going on with the spaces ")#mi("C^k(\\overline{U})")#text("? How do PDE people usually think about such issue when a general open domain is considered?")

#emph[#text("[Sorry, I do not really understand the question here. As Leoni states, there is no consensus on the notation here: each paper or text simply uses the notations that are most convenient for the application at hand, and one has to read the notational conventions carefully in those cases. It’s also worth bearing in mind that notation is ultimately an artificial human invention, rather than an innate feature of the mathematics one is working on; sometimes, two writers happen to use the same symbol to denote two rather different concepts, but this does not necessarily mean that these concepts have any deeper connection to them. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-461581")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2015")])]

#text("Ah, sorry for the confusion. What really puzzles me is the ")#emph[#text("definitions")]#text(" of ")#mi("C(\\overline{U})")#text(", ")#mi("C^k(\\overline{U})")#text(" and ")#mi("C^\\infty(\\overline{U})")#text(" for general open subset ")#mi("U")#text(" in ")#mi("\\Bbb{R}^n")#text(". (The classical regularity spaces ")#mi("C^k")#text(", as you put it in this post.)")

#text("In Evan’s book,")

#mi("C(\\overline{U}):=\\{u\\in C(U)\\mid u\\ \\\\ \\text{ is uniformly continuous on bounded subsets of } U\\}")

#text("where")

#mi("C(U):=\\{u: U\\to\\Bbb{R} \\mid u \\text{ continuous}\\} .")

#text("In Hunter’s ")#emph[#text("Applied Analysis, ")#mi("C(\\overline{U})")#text(" consists of functions that are uniformly continuous in ")#mi("U")#text(".")]

#text("ect. (At least four different definitions appear as I asked in the previous question.)")

#text("My question is, do definitions of ")#mi("C(\\overline{U})")#text(" ( ")#mi("C^k(\\overline{U})")#text(", ")#mi("C^\\infty(\\overline{U})")#text(") completely depend on context (so that there is no “the” definition)? Do they have any “stronger”, “weaker” relationship to each other or are these definitions not comparable at all?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-461582")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2015")])]

#text("In all of these cases, ")#mi("C(\\overline{U})")#text(" is a subspace of ")#mi("C(U)")#text(" consisting of functions that somehow have “good behaviour at the boundary”, but the precise nature of “good behaviour” is different in different texts. There are some obvious inclusions between the different versions of ")#mi("C(\\overline{U})")#text(" (e.g. if one is uniformly continuous, one is certainly also uniformly continuous on bounded subsets) but most likely the spaces are otherwise distinct from each other. Similarly for ")#mi("C^k(\\overline{U})")#text(" and ")#mi("C^k(U)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-472598")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("A recent question with an accepted answer on MO (")#link("http://mathoverflow.net/q/250444/14319")[#text("http://mathoverflow.net/q/250444/14319")]#text(") might be related to this discussion.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FUA Kap01-AB04 Klassische Banachräume | UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-506505")[#strong[#text("FUA Kap01-AB04 Klassische Banachräume | UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2018")])]

#text("[…] Viele weitere Beispiele findet man in [Dunford–Schwartz](Chapter IV) und in der Übersicht von T. Tao: A Type Diagram for Function Spaces. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/583a9d46add725ba742db56950433fc05632e3096c8af7a6fe1590508980312a-4bb4f37cb123e5f3656a0adfba363724e6bfc15dee852ed75e6afc9e48ce635f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mary")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-603813")[#strong[#text("Mary")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2020")])]

#text("I strongly agree in this point:")#linebreak()#text(" ____")#linebreak()#text(" there is an entire “zoo of function spaces” one could consider, and it can be difficult at first to see how they are organised with respect to each other.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-621838")[#strong[#text("Uncertainty principle, Sobolev embedding, and norm estimates ~ MathOverflow ~ mathubs.com")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2021")]

#text("[…] Tao offers a nice discussion of different function spaces in this blog. In the blog there is an explanation of the tradeoff between regularity $s$ and integrability $p$, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/#comment-673852")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2023")])]

#text("Can one add the space ")#mi("L^p_{loc}")#text(" somewhere in the diagram?")
]
