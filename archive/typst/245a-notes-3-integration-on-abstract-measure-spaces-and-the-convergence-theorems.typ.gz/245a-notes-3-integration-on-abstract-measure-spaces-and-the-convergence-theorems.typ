// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/
// Converted to Typst by tao2typ: "2026-10-14T09:03:01.105876+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 September 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Thus far, we have only focused on measure and integration theory in the context of Euclidean spaces ")#mi("{{\\bf R}^d}")#text(". Now, we will work in a more abstract and general setting, in which the Euclidean space ")#mi("{{\\bf R}^d}")#text(" is replaced by a more general space ")#mi("{X}")#text(".")

#text("It turns out that in order to properly define measure and integration on a general space ")#mi("{X}")#text(", it is not enough to just specify the set ")#mi("{X}")#text(". One also needs to specify two additional pieces of data:")

#enum(start: 1, 
[#text("A collection ")#mi("{{\\mathcal B}}")#text(" of subsets of ")#mi("{X}")#text(" that one is allowed to measure; and")],
[#text("The measure ")#mi("{\\mu(E) \\in [0,+\\infty]}")#text(" one assigns to each measurable set ")#mi("{E \\in {\\mathcal B}}")#text(".")]
)

#text("For instance, Lebesgue measure theory covers the case when ")#mi("{X}")#text(" is a Euclidean space ")#mi("{{\\bf R}^d}")#text(", ")#mi("{{\\mathcal B}}")#text(" is the collection ")#mi("{{\\mathcal B} = {\\mathcal L}[{\\bf R}^d]}")#text(" of all Lebesgue measurable subsets of ")#mi("{{\\bf R}^d}")#text(", and ")#mi("{\\mu(E)}")#text(" is the Lebesgue measure ")#mi("{\\mu(E)=m(E)}")#text(" of ")#mi("{E}")#text(".")

#text("The collection ")#mi("{{\\mathcal B}}")#text(" has to obey a number of axioms (e.g. being closed with respect to countable unions) that make it a ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("{\\sigma}")#text("-algebra")]#text(", which is a stronger variant of the more well-known concept of a ")#link("http://en.wikipedia.org/wiki/Boolean_algebra_(structure)")[#text("boolean algebra")]#text(". Similarly, the measure ")#mi("{\\mu}")#text(" has to obey a number of axioms (most notably, a countable additivity axiom) in order to obtain a measure and integration theory comparable to the Lebesgue theory on Euclidean spaces. When all these axioms are satisfied, the triple ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" is known as a ")#link("http://en.wikipedia.org/wiki/Measure_space")[#text("measure space")]#text(". These play much the same role in abstract measure theory that ")#link("http://en.wikipedia.org/wiki/Metric_space")[#text("metric spaces")]#text(" or ")#link("http://en.wikipedia.org/wiki/Topological_space")[#text("topological spaces")]#text(" play in abstract ")#link("http://en.wikipedia.org/wiki/Point-set_topology")[#text("point-set topology")]#text(", or that ")#link("http://en.wikipedia.org/wiki/Vector_space")[#text("vector spaces")]#text(" play in abstract ")#link("http://en.wikipedia.org/wiki/Linear_algebra")[#text("linear algebra")]#text(".")

#text("On any measure space, one can set up the unsigned and absolutely convergent integrals in almost exactly the same way as was done in the previous notes for the Lebesgue integral on Euclidean spaces, although the approximation theorems are largely unavailable at this level of generality due to the lack of such concepts as “elementary set” or “continuous function” for an abstract measure space. On the other hand, one ")#emph[#text("does")]#text(" have the fundamental convergence theorems for the subject, namely Fatou’s lemma, the monotone convergence theorem and the dominated convergence theorem, and we present these results here.")

#text("One question that will not be addressed much in this current set of notes is how one actually ")#emph[#text("constructs")]#text(" interesting examples of measures. We will discuss this issue more in later notes (although one of the most powerful tools for such constructions, namely the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(", will not be covered ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("until 245B")]#text(").")

#metadata(none) <tao-a26b047767fd4ef96f4a>

#heading(level: 1)[#strong[#text(" — 1. Boolean algebras — ")]]

#text("We begin by recalling the concept of a ")#link("http://en.wikipedia.org/wiki/Boolean_algebra_(structure)")[#text("Boolean algebra")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Boolean algebras)")]#text(" Let ")#mi("{X}")#text(" be a set. A (concrete) ")#emph[#text("Boolean algebra")]#text(" on ")#mi("{X}")#text(" is a collection ")#mi("{{\\mathcal B}}")#text(" of ")#mi("{X}")#text(" which obeys the following properties:")

#list(
[#text("(Empty set) ")#mi("{\\emptyset \\in {\\mathcal B}}")#text(".")],
[#text("(Complement) If ")#mi("{E \\in {\\mathcal B}}")#text(", then the complement ")#mi("{E^c := X \\backslash E}")#text(" also lies in ")#mi("{{\\mathcal B}}")#text(".")],
[#text("(Finite unions) If ")#mi("{E, F \\in {\\mathcal B}}")#text(", then ")#mi("{E \\cup F \\in {\\mathcal B}}")#text(".")]
)

#text("We sometimes say that ")#mi("{E}")#text(" is ")#emph[#mi("{{\\mathcal B}}")#text("-measurable")]#text(", or ")#emph[#text("measurable with respect to ")#mi("{{\\mathcal B}}")]#text(", if ")#mi("{E \\in {\\mathcal B}}")#text(".")

#text("Given two Boolean algebras ")#mi("{{\\mathcal B}, {\\mathcal B}^{\\prime}}")#text(" on ")#mi("{X}")#text(", we say that ")#mi("{{\\mathcal B}^{\\prime}}")#text(" is ")#emph[#text("finer than")]#text(", or ")#emph[#text("a refinement of")]#text(" ")#mi("{{\\mathcal B}}")#text(", or that ")#mi("{{\\mathcal B}}")#text(" is ")#emph[#text("coarser than, a sub-algebra of,")]#text(" or ")#emph[#text("a coarsening of")]#text(" ")#mi("{{\\mathcal B}^{\\prime}}")#text(", if ")#mi("{{\\mathcal B} \\subset {\\mathcal B}^{\\prime}}")#text(".")
]

#text("We have chosen a “minimalist” definition of a Boolean algebra, in which one is only assumed to be closed under two of the basic Boolean operations, namely complement and finite union. However, by using the laws of Boolean algebra (such as ")#link("http://en.wikipedia.org/wiki/De_Morgan's_laws")[#text("de Morgan’s laws")]#text("), it is easy to see that a Boolean algebra is also closed under other Boolean algebra operations such as intersection ")#mi("{E \\cap F}")#text(", set differerence ")#mi("{E \\backslash F}")#text(", and symmetric difference ")#mi("{E \\Delta F}")#text(". So one could have placed these additional closure properties inside the definition of a Boolean algebra without any loss of generality. However, when we are ")#emph[#text("verifying")]#text(" that a given collection ")#mi("{{\\mathcal B}}")#text(" of sets is indeed a Boolean algebra, it is convenient to have as minimal a set of axioms as possible. (This point is discussed further in ")#link("http://mathoverflow.net/questions/19152/why-is-a-topology-made-up-of-open-sets/30231#30231")[#text("this Math Overflow comment of mine")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can also consider ")#emph[#text("abstract Boolean algebras")]#text(" ")#mi("{{\\mathcal B}}")#text(", which do not necessarily live in an ambient domain ")#mi("{X}")#text(", but for which one has a collection of abstract Boolean operations such as meet ")#mi("{\\wedge}")#text(" and join ")#mi("{\\vee}")#text(" instead of the concrete operations of intersection ")#mi("{\\cap}")#text(" and union ")#mi("{\\cup}")#text(". We will not take this abstract perspective here, but see ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("this blog post of mine")]#text(" for some further discussion of the relationship between concrete and abstract Boolean algebras, which is codified by ")#link("http://en.wikipedia.org/wiki/Stone's_theorem")[#text("Stone’s theorem")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1 (Trivial and discrete algebra)")]#text(" Given any set ")#mi("{X}")#text(", the coarsest Boolean algebra is the ")#emph[#text("trivial algebra")]#text(" ")#mi("{\\{ \\emptyset, X \\}}")#text(", in which the only measurable sets are the empty set and the whole set. The finest Boolean algebra is the ")#emph[#text("discrete algebra")]#text(" ")#mi("{2^X := \\{ E: E \\subset X\\}}")#text(", in which ")#emph[#text("every")]#text(" set is measurable. All other Boolean algebras are intermediate between these two extremes: finer than the trivial algebra, but coarser than the discrete one.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Elementary algebra)")]#text(" Let ")#mi("{\\overline{{\\mathcal E}[{\\bf R}^d]}}")#text(" be the collection of those sets ")#mi("{E \\subset {\\bf R}^d}")#text(" that are either elementary sets, or co-elementary sets (i.e. the complement of an elementary set). Show that ")#mi("{\\overline{{\\mathcal E}[{\\bf R}^d]}}")#text(" is a Boolean algebra. We will call this algebra the ")#emph[#text("elementary Boolean algebra")]#text(" of ")#mi("{{\\bf R}^d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Jordan algebra)")]#text(" Let ")#mi("{\\overline{{\\mathcal J}[{\\bf R}^d]}}")#text(" be the collection of subsets of ")#mi("{{\\bf R}^d}")#text(" that are either Jordan measurable or co-Jordan measurable (i.e. the complement of a Jordan measurable set). Then ")#mi("{\\overline{{\\mathcal J}[{\\bf R}^d]}}")#text(" is a Boolean algebra that is finer than the elementary algebra. We refer to this algebra as the ")#emph[#text("Jordan algebra")]#text(" on ")#mi("{{\\bf R}^d}")#text(" (but caution that there is a completely different concept of a ")#link("http://en.wikipedia.org/wiki/Jordan_algebra")[#text("Jordan algebra")]#text(" in mathematics.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Lebesgue algebra)")]#text(" Let ")#mi("{{\\mathcal L}[{\\bf R}^d]}")#text(" be the collection of Lebesgue measurable subsets of ")#mi("{{\\bf R}^d}")#text(". Then ")#mi("{{\\mathcal L}[{\\bf R}^d]}")#text(" is a Boolean algebra that is finer than the Jordan algebra; we refer to this as the ")#emph[#text("Lebesgue algebra")]#text(" on ")#mi("{{\\bf R}^d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4 (Null algebra)")]#text(" Let ")#mi("{{\\mathcal N}({\\bf R}^d)}")#text(" be the collection of subsets of ")#mi("{{\\bf R}^d}")#text(" that are either Lebesgue null sets or Lebesgue co-null sets (the complement of null sets). Then ")#mi("{{\\mathcal N}({\\bf R}^d)}")#text(" is a Boolean algebra that is coarser than the Lebesgue algebra; we refer to it as the ")#emph[#text("null algebra")]#text(" on ")#mi("{{\\bf R}^d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Restriction)")]#text(" ")#metadata(none) <tao-60dd84cc4bd7b4f3b705>#text(" Let ")#mi("{{\\mathcal B}}")#text(" be a Boolean algebra on a set ")#mi("{X}")#text(", and let ")#mi("{Y}")#text(" be a subset of ")#mi("{X}")#text(" (not necessarily ")#mi("{{\\mathcal B}}")#text("-measurable). Show that the ")#emph[#text("restriction")]#text(" ")#mi("{{\\mathcal B}\\downharpoonright_Y := \\{ E \\cap Y: E \\in {\\mathcal B} \\}}")#text(" of ")#mi("{{\\mathcal B}}")#text(" to ")#mi("{Y}")#text(" is a Boolean algebra on ")#mi("{Y}")#text(". If ")#mi("{Y}")#text(" is ")#mi("{{\\mathcal B}}")#text("-measurable, show that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal B}\\downharpoonright_Y = {\\mathcal B} \\cap 2^Y = \\{ E \\subset Y: E \\in {\\mathcal B} \\}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5 (Atomic algebra)")]#text(" Let ")#mi("{X}")#text(" be partitioned into a union ")#mi("{X = \\bigcup_{\\alpha \\in I} A_\\alpha}")#text(" of disjoint sets ")#mi("{A_\\alpha}")#text(", which we refer to as ")#emph[#text("atoms")]#text(". Then this partition generates a Boolean algebra ")#mi("{{\\mathcal A}( (A_\\alpha)_{\\alpha \\in I} )}")#text(", defined as the collection of all the sets ")#mi("{E}")#text(" of the form ")#mi("{E = \\bigcup_{\\alpha \\in J} A_\\alpha}")#text(" for some ")#mi("{J \\subset I}")#text(", i.e. ")#mi("{{\\mathcal A}( (A_\\alpha)_{\\alpha \\in I} )}")#text(" is the collection of all sets that can be represented as the union of one or more atoms. This is easily verified to be a Boolean algebra, and we refer to it as the ")#emph[#text("atomic algebra")]#text(" with atoms ")#mi("{(A_\\alpha)_{\\alpha \\in I}}")#text(". The trivial algebra corresponds to the trivial partition ")#mi("{X = X}")#text(" into a single atom; at the other extreme, the discrete algebra corresponds to the discrete partition ")#mi("{X = \\bigcup_{x \\in X} \\{x\\}}")#text(" into singleton atoms. More generally, note that finer (resp. coarser) partitions lead to finer (resp. coarser) atomic algebra. In this definition, we permit some of the atoms in the partition to be empty; but it is clear that empty atoms have no impact on the final atomic algebra, and so without loss of generality one can delete all empty atoms and assume that all atoms are non-empty if one wishes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6 (Dyadic algebras)")]#text(" ")#metadata(none) <tao-be3f1b44776624b9c37b>#text(" Let ")#mi("{n}")#text(" be an integer. The ")#emph[#text("dyadic algebra")]#text(" ")#mi("{{\\mathcal D}_n({\\bf R}^d)}")#text(" at scale ")#mi("{2^{-n}}")#text(" in ")#mi("{{\\bf R}^d}")#text(" is defined to be the atomic algebra generated by the half-open dyadic cubes")

#align(center)[#tao-fit-display[#mitex("[\\frac{i_1}{2^n}, \\frac{i_1+1}{2^n}) \\times \\ldots \\times [\\frac{i_d}{2^n}, \\frac{i_d+1}{2^n})")]]

#text("of length ")#mi("{2^{-n}}")#text(" (see Exercise 14 of the ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")[#text("prologue")]#text("). These are Boolean algebras which are increasing in ")#mi("{n}")#text(": ")#mi("{{\\mathcal D}_{n+1} \\supset {\\mathcal D}_{n}}")#text(". Draw a diagram to indicate how these algebras sit in relation to the elementary, Jordan, and Lebesgue, null, discrete, and trivial algebras.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The dyadic algebras are analogous to the finite resolution one has on modern computer monitors, which subdivide space into square pixels. A low resolution monitor (in which each pixel has a large size) can only resolve a very small set of “blocky” images, as opposed to the larger class of images that can be resolved by a finer resolution monitor.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-e77c4b3f81059b97c4d2>#text(" Show that the non-empty atoms of an atomic algebra are determined up to relabeling. More precisely, show that if ")#mi("{X = \\bigcup_{\\alpha \\in I} A_\\alpha = \\bigcup_{\\alpha^{\\prime} \\in I^{\\prime}} A^{\\prime}_{\\alpha^{\\prime}}}")#text(" are two partitions of ")#mi("{X}")#text(" into non-empty atoms ")#mi("{A_\\alpha}")#text(", ")#mi("{A^{\\prime}_{\\alpha^{\\prime}}}")#text(", then ")#mi("{{\\mathcal A}( (A_\\alpha)_{\\alpha \\in I} ) = {\\mathcal A}( (A^{\\prime}_{\\alpha^{\\prime}})_{\\alpha^{\\prime} \\in I^{\\prime}} )}")#text(" if and only if exists a bijection ")#mi("{\\phi: I \\rightarrow I^{\\prime}}")#text(" such that ")#mi("{A^{\\prime}_{\\phi(\\alpha)} = A_\\alpha}")#text(" for all ")#mi("{\\alpha \\in I}")#text(".")
]

#text("While many Boolean algebras are atomic, many are not, as the following two exercises indicate.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-1bf521836de96e75fac7>#text(" Show that every finite Boolean algebra is an atomic algebra. (A Boolean algebra ")#mi("{{\\mathcal B}}")#text(" is ")#emph[#text("finite")]#text(" if its cardinality is finite, i.e. there are only finitely many measurable sets.) Conclude that every finite Boolean algebra has a cardinality of the form ")#mi("{2^{n}}")#text(" for some natural number ")#mi("{n}")#text(". From this exercise and Exercise ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("3")]#text(" we see that there is a one-to-one correspondence between finite Boolean algebras on ")#mi("{X}")#text(" and finite partitions of ")#mi("{X}")#text(" into non-empty sets (up to relabeling).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that the elementary, Jordan, Lebesgue, and null algebras are ")#emph[#text("not")]#text(" atomic algebras. (")#emph[#text("Hint:")]#text(" argue by contradiction. If these algebras were atomic, what must the atoms be?)")
]

#text("Now we describe some further ways to generate Boolean algebras.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Intersection of algebras)")]#text(" ")#metadata(none) <tao-4780c43f8dcb1870d529>#text(" Let ")#mi("{({\\mathcal B}_\\alpha)_{\\alpha \\in I}}")#text(" be a family of Boolean algebras on a set ")#mi("{X}")#text(", indexed by a (possibly infinite or uncountable) label set ")#mi("{I}")#text(". Show that the intersection ")#mi("{\\bigwedge_{\\alpha \\in I} {\\mathcal B}_\\alpha := \\bigcap_{\\alpha \\in I} {\\mathcal B}_\\alpha}")#text(" of these algebras is still a Boolean algebra, and is the finest Boolean algebra that is coarser than all of the ")#mi("{{\\mathcal B}_\\alpha}")#text(". (If ")#mi("{I}")#text(" is empty, we adopt the convention that ")#mi("{\\bigwedge_{\\alpha \\in I} {\\mathcal B}_\\alpha}")#text(" is the discrete algebra.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Generation of algebras)")]#text(" Let ")#mi("{{\\mathcal F}}")#text(" be any family of sets in ")#mi("{X}")#text(". We define ")#mi("{\\langle {\\mathcal F} \\rangle_{\\text{bool}}}")#text(" to be the intersection of all the Boolean algebras that contain ")#mi("{{\\mathcal F}}")#text(", which is again a Boolean algebra by Exercise ")#link(<tao-4780c43f8dcb1870d529>)[#text("6")]#text(". Equivalently, ")#mi("{\\langle {\\mathcal F} \\rangle_{\\text{bool}}}")#text(" is the coarsest Boolean algebra that contains ")#mi("{{\\mathcal F}}")#text(". We say that ")#mi("{\\langle {\\mathcal F} \\rangle_{\\text{bool}}}")#text(" is the Boolean algebra ")#emph[#text("generated")]#text(" by ")#mi("{{\\mathcal F}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" ")#mi("{{\\mathcal F}}")#text(" is a Boolean algebra if and only if ")#mi("{\\langle {\\mathcal F} \\rangle_{\\text{bool}} = {\\mathcal F}}")#text("; thus each Boolean algebra is generated by itself.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-cb2820837eb0958ce731>#text(" Show that the elementary algebra ")#mi("{{\\mathcal E}({\\bf R}^d)}")#text(" is generated by the collection of boxes in ")#mi("{{\\bf R}^d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-cc8ca30e40d51db2f10a>#text(" Let ")#mi("{n}")#text(" be a natural number. Show that if ")#mi("{{\\mathcal F}}")#text(" is a finite collection of ")#mi("{n}")#text(" sets, then ")#mi("{\\langle {\\mathcal F} \\rangle_{\\text{bool}}}")#text(" is a finite Boolean algebra of cardinality at most ")#mi("{2^{2^n}}")#text(" (in particular, finite sets generate finite algebras). Give an example to show that this bound is best possible. (Hint: for the latter, it may be convenient to use a discrete ambient space such as the discrete cube ")#mi("{X = \\{0,1\\}^n}")#text(".)")
]

#text("The Boolean algebra ")#mi("{\\langle {\\mathcal F} \\rangle_{\\text{bool}}}")#text(" can be described explicitly in terms of ")#mi("{{\\mathcal F}}")#text(" as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Recursive description of a generated Boolean algebra)")]#text(" ")#metadata(none) <tao-1a1e52b2e2af0791119e>#text(" Let ")#mi("{{\\mathcal F}}")#text(" be a collection of sets in a set ")#mi("{X}")#text(". Define the sets ")#mi("{{\\mathcal F}_0, {\\mathcal F}_1, {\\mathcal F}_2, \\ldots}")#text(" recursively as follows:")

#list(
[#mi("{{\\mathcal F}_0 := {\\mathcal F}}")#text(".")],
[#text("For each ")#mi("{n \\geq 1}")#text(", we define ")#mi("{{\\mathcal F}_n}")#text(" to be the collection of all sets that either the union of a finite number of sets in ")#mi("{{\\mathcal F}_{n-1}}")#text(" (including the empty union ")#mi("{\\emptyset}")#text("), or the complement of such a union.")]
)

#text("Show that ")#mi("{\\langle {\\mathcal F} \\rangle_{\\text{bool}} = \\bigcup_{n=0}^\\infty {\\mathcal F}_n}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. ")#mi("{\\sigma}")#text("-algebras and measurable spaces — ")]]

#text("In order to obtain a measure and integration theory that can cope well with limits, the finite union axiom of a Boolean algebra is insufficient, and must be improved to a countable union axiom:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Sigma algebras)")]#text(" Let ")#mi("{X}")#text(" be a set. A ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("{\\sigma}")#text("-algebra")]#text(" on ")#mi("{X}")#text(" is a collection ")#mi("{{\\mathcal B}}")#text(" of ")#mi("{X}")#text(" which obeys the following properties:")

#list(
[#text("(Empty set) ")#mi("{\\emptyset \\in {\\mathcal B}}")#text(".")],
[#text("(Complement) If ")#mi("{E \\in {\\mathcal B}}")#text(", then the complement ")#mi("{E^c := X \\backslash E}")#text(" also lies in ")#mi("{{\\mathcal B}}")#text(".")],
[#text("(Countable unions) If ")#mi("{E_1, E_2, \\ldots \\in {\\mathcal B}}")#text(", then ")#mi("{\\bigcup_{n=1}^\\infty E_n \\in {\\mathcal B}}")#text(".")]
)

#text("We refer to the pair ")#mi("{(X, {\\mathcal B})}")#text(" of a set ")#mi("{X}")#text(" together with a ")#mi("{\\sigma}")#text("-algebra on that set as a ")#emph[#text("measurable space")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The prefix ")#mi("{\\sigma}")#text(" usually denotes “countable union”. See also the concepts of a ")#link("http://en.wikipedia.org/wiki/%CE%A3-compact_space")[#mi("{\\sigma}")#text("-compact topological space")]#text(", or a ")#link("http://en.wikipedia.org/wiki/%CE%A3-finite_measure")[#mi("{\\sigma}")#text("-finite measure space")]#text(", or ")#link("http://en.wikipedia.org/wiki/F%CF%83_set")[#mi("{F_\\sigma}")#text(" set")]#text(" for other instances of this prefix.")
]

#text("From de Morgan’s law (which is just as valid for infinite unions and intersections as it is for finite ones), we see that ")#mi("{\\sigma}")#text("-algebras are closed under countable intersections as well as countable unions.")

#text("By padding a finite union into a countable union by using the empty set, we see that every ")#mi("{\\sigma}")#text("-algebra is automatically a Boolean algebra. Thus, we automatically inherit the notion of being measurable with respect to a ")#mi("{\\sigma}")#text("-algebra, or of one ")#mi("{\\sigma}")#text("-algebra being coarser or finer than another.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Show that all atomic algebras are ")#mi("{\\sigma}")#text("-algebras. In particular, the discrete algebra and trivial algebra are ")#mi("{\\sigma}")#text("-algebras, as are the finite algebras and the dyadic algebras on Euclidean spaces.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Show that the Lebesgue and null algebras are ")#mi("{\\sigma}")#text("-algebras, but the elementary and Jordan algebras are not.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Show that any restriction ")#mi("{{\\mathcal B}\\downharpoonright_Y}")#text(" of a ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(" to a subspace ")#mi("{Y}")#text(" of ")#mi("{X}")#text(" (as defined in Exercise ")#link(<tao-60dd84cc4bd7b4f3b705>)[#text("2")]#text(") is again a ")#mi("{\\sigma}")#text("-algebra on the subspace ")#mi("{Y}")#text(".")
]

#text("There is an exact analogue of Exercise ")#link(<tao-4780c43f8dcb1870d529>)[#text("6")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Intersection of ")#mi("{\\sigma}")#text("-algebras)")]#text(" ")#metadata(none) <tao-5d7cd02ecf8d8a4dc314>#text(" Show that the intersection ")#mi("{\\bigwedge_{\\alpha \\in I} {\\mathcal B}_\\alpha := \\bigcap_{\\alpha \\in I} {\\mathcal B}_\\alpha}")#text(" of an arbitrary (and possibly infinite or uncountable) number of ")#mi("{\\sigma}")#text("-algebras ")#mi("{{\\mathcal B}_\\alpha}")#text(" is again a ")#mi("{\\sigma}")#text("-algebra, and is the finest ")#mi("{\\sigma}")#text("-algebra that is coarser than all of the ")#mi("{{\\mathcal B}_\\alpha}")#text(".")
]

#text("Similarly, we have a notion of generation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Generation of ")#mi("{\\sigma}")#text("-algebras)")]#text(" Let ")#mi("{{\\mathcal F}}")#text(" be any family of sets in ")#mi("{X}")#text(". We define ")#mi("{\\langle {\\mathcal F} \\rangle}")#text(" to be the intersection of all the ")#mi("{\\sigma}")#text("-algebras that contain ")#mi("{{\\mathcal F}}")#text(", which is again a ")#mi("{\\sigma}")#text("-algebra by Exercise ")#link(<tao-5d7cd02ecf8d8a4dc314>)[#text("13")]#text(". Equivalently, ")#mi("{\\langle {\\mathcal F} \\rangle}")#text(" is the coarsest ")#mi("{\\sigma}")#text("-algebra that contains ")#mi("{{\\mathcal F}}")#text(". We say that ")#mi("{\\langle {\\mathcal F} \\rangle}")#text(" is the ")#mi("{\\sigma}")#text("-algebra ")#emph[#text("generated")]#text(" by ")#mi("{{\\mathcal F}}")#text(".")
]

#text("Since every ")#mi("{\\sigma}")#text("-algebra is a Boolean algebra, we have the trivial inclusion")

#align(center)[#tao-fit-display[#mitex("\\langle {\\mathcal F} \\rangle_{\\text{bool}} \\subset \\langle {\\mathcal F} \\rangle.")]]

#text("However, equality need not hold; it only holds if and only if ")#mi("{\\langle {\\mathcal F} \\rangle_{\\text{bool}}}")#text(" is a ")#mi("{\\sigma}")#text("-algebra. For instance, if ")#mi("{{\\mathcal F}}")#text(" is the collection of all boxes in ")#mi("{{\\bf R}^d}")#text(", then ")#mi("{\\langle {\\mathcal F} \\rangle_{\\text{bool}}}")#text(" is the elementary algebra (Exercise ")#link(<tao-cb2820837eb0958ce731>)[#text("7")]#text("), but ")#mi("{\\langle {\\mathcal F} \\rangle}")#text(" cannot equal this algebra, as it is not a ")#mi("{\\sigma}")#text("-algebra.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" ")#metadata(none) <tao-2c1d6e232683b189416a>#text(" From the definitions, it is clear that we have the following principle, somewhat analogous to the principle of mathematical induction: if ")#mi("{{\\mathcal F}}")#text(" is a family of sets in ")#mi("{X}")#text(", and ")#mi("{P(E)}")#text(" is a property of sets ")#mi("{E \\subset X}")#text(" which obeys the following axioms:")

#list(
[#mi("{P(\\emptyset)}")#text(" is true.")],
[#mi("{P(E)}")#text(" is true for all ")#mi("{E \\in {\\mathcal F}}")#text(".")],
[#text("If ")#mi("{P(E)}")#text(" is true for some ")#mi("{E \\subset X}")#text(", then ")#mi("{P( X \\backslash E )}")#text(" is true also.")],
[#text("If ")#mi("{E_1,E_2,\\ldots \\subset X}")#text(" are such that ")#mi("{P(E_n)}")#text(" is true for all ")#mi("{n}")#text(", then ")#mi("{P(\\bigcup_{n=1}^\\infty E_n)}")#text(" is true also.")]
)

#text("Then one can conclude that ")#mi("{P(E)}")#text(" is true for all ")#mi("{E \\in \\langle {\\mathcal F} \\rangle}")#text(". Indeed, the set of all ")#mi("{E}")#text(" for which ")#mi("{P(E)}")#text(" holds is a ")#mi("{\\sigma}")#text("-algebra that contains ")#mi("{{\\mathcal F}}")#text(", whence the claim. This principle is particularly useful for establishing properties of Borel measurable sets (see below).")
]

#text("We now turn to an important example of a ")#mi("{\\sigma}")#text("-algebra:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Borel ")#mi("{\\sigma}")#text("-algebra)")]#text(" Let ")#mi("{X}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Metric_space")[#text("metric space")]#text(", or more generally a ")#link("http://en.wikipedia.org/wiki/Topological_space")[#text("topological space")]#text(". The ")#link("http://en.wikipedia.org/wiki/Borel_sigma_algebra")[#text("Borel ")#mi("{\\sigma}")#text("-algebra")]#text(" ")#mi("{{\\mathcal B}[X]}")#text(" of ")#mi("{X}")#text(" is defined to be the ")#mi("{\\sigma}")#text("-algebra generated by the open subsets of ")#mi("{X}")#text(". Elements of ")#mi("{{\\mathcal B}[X]}")#text(" will be called ")#emph[#text("Borel measurable")]#text(".")
]

#text("Thus, for instance, the Borel ")#mi("{\\sigma}")#text("-algebra contains the open sets, the closed sets (which are complements of open sets), the countable unions of closed sets (i.e. ")#link("http://en.wikipedia.org/wiki/F%CF%83_set")[#mi("{F_\\sigma}")#text(" sets")]#text("), the countable intersections of open sets (i.e. ")#link("http://en.wikipedia.org/wiki/G-delta_set")[#mi("{G_\\delta}")#text(" sets")]#text("), the countable intersections of ")#mi("{F_\\sigma}")#text(" sets, and so forth.")

#text("In ")#mi("{{\\bf R}^d}")#text(", every open set is Lebesgue measurable, and so we see that the Borel ")#mi("{\\sigma}")#text("-algebra is coarser than the Lebesgue ")#mi("{\\sigma}")#text("-algebra. We will shortly see, though, that the two ")#mi("{\\sigma}")#text("-algebras are not equal.")

#text("We defined the Borel ")#mi("{\\sigma}")#text("-algebra to be generated by the open sets. However, they are also generated by several other sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}[{\\bf R}^d]}")#text(" of a Euclidean set is generated by any of the following collections of sets:")

#enum(start: 1, 
[#text("The open subsets of ")#mi("{{\\bf R}^d}")#text(".")],
[#text("The closed subsets of ")#mi("{{\\bf R}^d}")#text(".")],
[#text("The compact subsets of ")#mi("{{\\bf R}^d}")#text(".")],
[#text("The open balls of ")#mi("{{\\bf R}^d}")#text(".")],
[#text("The boxes in ")#mi("{{\\bf R}^d}")#text(".")],
[#text("The elementary sets in ")#mi("{{\\bf R}^d}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" To show that two families ")#mi("{{\\mathcal F}, {\\mathcal F}^{\\prime}}")#text(" of sets generate the same ")#mi("{\\sigma}")#text("-algebra, it suffices to show that every ")#mi("{\\sigma}")#text("-algebra that contains ")#mi("{{\\mathcal F}}")#text(", contains ")#mi("{{\\mathcal F}^{\\prime}}")#text(" also, and conversely.)")
]

#text("There is an analogue of Exercise ")#link(<tao-1a1e52b2e2af0791119e>)[#text("9")]#text(", which illustrates the extent to which a generated ")#mi("{\\sigma}")#text("-algebra is “larger” than the analogous generated Boolean algebra:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Recursive description of a generated ")#mi("{\\sigma}")#text("-algebra)")]#text(" ")#metadata(none) <tao-7178355afbe1d5e85e4a>#text(" (This exercise requires familiarity with the theory of ")#link("http://en.wikipedia.org/wiki/Ordinal_number")[#text("ordinals")]#text(", which is reviewed ")#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/")[#text("here")]#text(". Recall that we are assuming the axiom of choice throughout this course.) Let ")#mi("{{\\mathcal F}}")#text(" be a collection of sets in a set ")#mi("{X}")#text(", and let ")#mi("{\\omega_1}")#text(" be the ")#link("http://en.wikipedia.org/wiki/First_uncountable_ordinal")[#text("first uncountable ordinal")]#text(". Define the sets ")#mi("{{\\mathcal F}_\\alpha}")#text(" for every countable ordinal ")#mi("{\\alpha \\in \\omega_1}")#text(" via transfinite induction as follows:")

#list(
[#mi("{{\\mathcal F}_\\alpha := {\\mathcal F}}")#text(".")],
[#text("For each countable successor ordinal ")#mi("{\\alpha = \\beta+1}")#text(", we define ")#mi("{{\\mathcal F}_\\alpha}")#text(" to be the collection of all sets that either the union of an at most countable number of sets in ")#mi("{{\\mathcal F}_{n-1}}")#text(" (including the empty union ")#mi("{\\emptyset}")#text("), or the complement of such a union.")],
[#text("For each countable limit ordinal ")#mi("{\\alpha = \\sup_{\\beta < \\alpha} \\beta}")#text(", we define ")#mi("{{\\mathcal F}_\\alpha := \\bigcup_{\\beta < \\alpha} {\\mathcal F}_\\beta}")#text(".")]
)

#text("Show that ")#mi("{\\langle {\\mathcal F} \\rangle = \\bigcup_{\\alpha \\in \\omega_1} {\\mathcal F}_\\alpha}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" The first uncountable ordinal ")#mi("{\\omega_1}")#text(" will make several further cameo appearances throughout this course, for instance by generating counterexamples to various plausible statements in point-set topology. In the case when ")#mi("{{\\mathcal F}}")#text(" is the collection of open sets in a topological space, so that ")#mi("{\\langle {\\mathcal F} \\rangle}")#text(", then the sets ")#mi("{{\\mathcal F}_\\alpha}")#text(" are essentially the ")#link("http://en.wikipedia.org/wiki/Borel_hierarchy")[#text("Borel hierarchy")]#text(" (which starts at the open and closed sets, then moves on to the ")#mi("{F_\\sigma}")#text(" and ")#mi("{G_\\delta}")#text(" sets, and so forth); these play an important role in ")#link("http://en.wikipedia.org/wiki/Descriptive_set_theory")[#text("descriptive set theory")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-873ac9ffea4dd04fa719>#text(" (This exercise requires familiarity with the theory of ")#link("http://en.wikipedia.org/wiki/Cardinal_number")[#text("cardinals")]#text(".) Let ")#mi("{{\\mathcal F}}")#text(" be an infinite family of subsets of ")#mi("{X}")#text(" of cardinality ")#mi("{\\kappa}")#text(" (thus ")#mi("{\\kappa}")#text(" is an infinite cardinal). Show that ")#mi("{\\langle {\\mathcal F} \\rangle}")#text(" has cardinality at most ")#mi("{\\kappa^{\\aleph_0}}")#text(". (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-7178355afbe1d5e85e4a>)[#text("15")]#text(".) In particular, show that the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}[{\\bf R}^d]}")#text(" has cardinality at most ")#mi("{c := 2^{\\aleph_0}}")#text(".")

#text("Conclude that there exist Jordan measurable (and hence Lebesgue measurable) subsets of ")#mi("{{\\bf R}^d}")#text(" which are not Borel measurable. (")#emph[#text("Hint:")]#text(" How many subsets of the Cantor set are there?) Use this to place the Borel ")#mi("{\\sigma}")#text("-algebra on the diagram that you drew for Exercise ")#link(<tao-be3f1b44776624b9c37b>)[#text("6")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" Despite this demonstration that not all Lebesgue measurable subsets are Borel measurable, it is remarkably difficult (though not impossible) to exhibit a ")#emph[#text("specific")]#text(" set that is not Borel measurable. Indeed, a large majority of the explicitly constructible sets that one actually encounters in practice tend to be Borel measurable, and one can view the property of Borel measurability intuitively as a kind of “constructibility” property. (Indeed, as a ")#emph[#text("very")]#text(" crude first approximation, one can view the Borel measurable sets as those sets of “countable descriptive complexity”; in contrast, sets of finite descriptive complexity tend to be Jordan measurable (assuming they are bounded, of course).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Let ")#mi("{E, F}")#text(" be Borel measurable subsets of ")#mi("{{\\bf R}^{d_1}, {\\bf R}^{d_2}}")#text(" respectively. Show that ")#mi("{E \\times F}")#text(" is a Borel measurable subset of ")#mi("{{\\bf R}^{d_1+d_2}}")#text(". (")#emph[#text("Hint:")]#text(" first establish this in the case when ")#mi("{F}")#text(" is a box, by using Remark ")#link(<tao-2c1d6e232683b189416a>)[#text("4")]#text(". To obtain the general case, apply Remark ")#link(<tao-2c1d6e232683b189416a>)[#text("4")]#text(" yet again.)")
]

#text("The above exercise has a partial converse:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Let ")#mi("{E}")#text(" be a Borel measurable subset of ")#mi("{{\\bf R}^{d_1+d_2}}")#text(".")

#enum(start: 1, 
[#text("Show that for any ")#mi("{x_1 \\in {\\bf R}^{d_1}}")#text(", the slice ")#mi("{\\{ x_2 \\in {\\bf R}^{d_2}: (x_1,x_2) \\in E \\}}")#text(" is a Borel measurable subset of ")#mi("{{\\bf R}^{d_2}}")#text(". Similarly, show that for every ")#mi("{x_2 \\in {\\bf R}^{d_2}}")#text(", the slice ")#mi("{\\{ x_1 \\in {\\bf R}^{d_1}: (x_1,x_2) \\in E \\}}")#text(" is a Borel measurable subset of ")#mi("{{\\bf R}^{d_1}}")#text(".")],
[#text("Give a counterexample to show that this claim is ")#emph[#text("not")]#text(" true if “Borel” is replaced with “Lebesgue” throughout. (")#emph[#text("Hint:")]#text(" the Cartesian product of any set with a point is a null set, even if the first set was not measurable.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Show that the Lebesgue ")#mi("{\\sigma}")#text("-algebra on ")#mi("{{\\bf R}^d}")#text(" is generated by the union of the Borel ")#mi("{\\sigma}")#text("-algebra and the null ")#mi("{\\sigma}")#text("-algebra.")
]

#heading(level: 1)[#strong[#text(" — 3. Countably additive measures and measure spaces — ")]]

#text("Having set out the concept of a ")#mi("{\\sigma}")#text("-algebra a measurable space, we now endow these structures with a measure.")

#text("We begin with the finitely additive theory, although this theory is too weak for our purposes and will soon be supplanted by the countably additive theory.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Finitely additive measure)")]#text(" Let ")#mi("{{\\mathcal B}}")#text(" be a Boolean algebra on a space ")#mi("{X}")#text(". An (unsigned) ")#emph[#text("finitely additive measure")]#text(" ")#mi("{\\mu}")#text(" on ")#mi("{{\\mathcal B}}")#text(" is a map ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" that obeys the following axioms:")

#enum(start: 1, 
[#text("(Empty set) ")#mi("{\\mu(\\emptyset) = 0}")#text(".")],
[#text("(Finite additivity) Whenever ")#mi("{E, F \\in {\\mathcal B}}")#text(" are disjoint, then ")#mi("{\\mu(E \\cup F) = \\mu(E) + \\mu(F)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" The empty set axiom is needed in order to rule out the degenerate situation in which every set (including the empty set) has infinite measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 8")]#text(" Lebesgue measure ")#mi("{m}")#text(" is a finitely additive measure on the Lebesgue ")#mi("{\\sigma}")#text("-algebra, and hence on all sub-algebras (such as the null algebra, the Jordan algebra, or the elementary algebra). In particular, Jordan measure and elementary measure are finitely additive (adopting the convention that co-Jordan measurable sets have infinite Jordan measure, and co-elementary sets have infinite elementary measure).")

#text("On the other hand, as we saw in previous notes, Lebesgue outer measure is ")#emph[#text("not")]#text(" finitely additive on the discrete algebra, and Jordan outer measure is ")#emph[#text("not")]#text(" finitely additive on the Lebesgue algebra.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 9 (Dirac measure)")]#text(" ")#metadata(none) <tao-6a95eb4f0762bfe01733>#text(" Let ")#mi("{x \\in X}")#text(" and ")#mi("{{\\mathcal B}}")#text(" be an arbitrary Boolean algebra on ")#mi("{X}")#text(". Then the ")#link("http://en.wikipedia.org/wiki/Dirac_measure")[#text("Dirac measure")]#text(" ")#mi("{\\delta_x}")#text(" at ")#mi("{x}")#text(", defined by setting ")#mi("{\\delta_x(E) := 1_E(x)}")#text(", is finitely additive.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 10 (Zero measure)")]#text(" The zero measure ")#mi("{0: E \\mapsto 0}")#text(" is a finitely additive measure on any Boolean algebra.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 11 (Linear combinations of measures)")]#text(" If ")#mi("{{\\mathcal B}}")#text(" is a Boolean algebra on ")#mi("{X}")#text(", and ")#mi("{\\mu, \\nu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" are finitely additive measures on ")#mi("{{\\mathcal B}}")#text(", then ")#mi("{\\mu+\\nu: E \\mapsto \\mu(E) + \\nu(E)}")#text(" is also a finitely additive measure, as is ")#mi("{c\\mu: E \\mapsto c \\times \\mu(E)}")#text(" for any ")#mi("{c \\in [0,+\\infty]}")#text(". Thus, for instance, the sum of Lebesgue measure and a Dirac measure is also a finitely additive measure on the Lebesgue algebra (or on any of its sub-algebras).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 12 (Restriction of a measure)")]#text(" ")#metadata(none) <tao-e19e3bc5684859d8e20e>#text(" If ")#mi("{{\\mathcal B}}")#text(" is a Boolean algebra on ")#mi("{X}")#text(", ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" is a finitely additive measure, and ")#mi("{Y}")#text(" is a ")#emph[#mi("{{\\mathcal B}}")#text("-measurable")]#text(" subset of ")#mi("{X}")#text(", then the restriction ")#mi("{\\mu\\downharpoonright_Y: {\\mathcal B}\\downharpoonright_Y \\rightarrow [0,+\\infty]}")#text(" of ")#mi("{{\\mathcal B}}")#text(" to ")#mi("{Y}")#text(", defined by setting ")#mi("{\\mu\\downharpoonright_Y(E) := \\mu(E)}")#text(" whenever ")#mi("{E \\in {\\mathcal B}\\downharpoonright_Y}")#text(" (i.e. if ")#mi("{E \\in {\\mathcal B}}")#text(" and ")#mi("{E \\subset Y}")#text("), is also a finitely additive meaure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 13 (Counting measure)")]#text(" ")#metadata(none) <tao-6c35493a2b937829c981>#text(" If ")#mi("{{\\mathcal B}}")#text(" is a Boolean algebra on ")#mi("{X}")#text(", then the function ")#mi("{\\#: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" defined by setting ")#mi("{\\#(E)}")#text(" to be the cardinality of ")#mi("{E}")#text(" if ")#mi("{E}")#text(" is finite, and ")#mi("{\\#(E) := +\\infty}")#text(" if ")#mi("{E}")#text(" is infinite, is a finitely additive measure, known as ")#emph[#text("counting measure")]#text(".")
]

#text("As with our definition of Boolean algebras and ")#mi("{\\sigma}")#text("-algebras, we adopted a “minimalist” definition so that the axioms are easy to verify. But they imply several further useful properties:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" be a finitely additive measure on a Boolean ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(". Establish the following facts:")

#enum(start: 1, 
[#text("(Monotonicity) If ")#mi("{E, F}")#text(" are ")#mi("{{\\mathcal B}}")#text("-measurable and ")#mi("{E \\subset F}")#text(", then ")#mi("{\\mu(E) \\leq \\mu(F)}")#text(".")],
[#text("(Finite additivity) If ")#mi("{k}")#text(" is a natural number, and ")#mi("{E_1,\\ldots,E_k}")#text(" are ")#mi("{{\\mathcal B}}")#text("-measurable and disjoint, then ")#mi("{\\mu(E_1\\cup \\ldots \\cup E_k) = \\mu(E_1) + \\ldots + \\mu(E_k)}")#text(".")],
[#text("(Finite sub-additivity) If ")#mi("{k}")#text(" is a natural number, and ")#mi("{E_1,\\ldots,E_k}")#text(" are ")#mi("{{\\mathcal B}}")#text("-measurable, then ")#mi("{\\mu(E_1\\cup \\ldots \\cup E_k) \\leq \\mu(E_1) + \\ldots + \\mu(E_k)}")#text(".")],
[#text("(Inclusion-exclusion for two sets) If ")#mi("{E, F}")#text(" are ")#mi("{{\\mathcal B}}")#text("-measurable, then ")#mi("{\\mu(E \\cup F) + \\mu(E \\cap F) = \\mu(E) + \\mu(F)}")#text(".")]
)

#text("(")#emph[#text("Caution:")]#text(" remember that the cancellation law ")#mi("{a+c=b+c \\implies a=b}")#text(" does not hold in ")#mi("{[0,+\\infty]}")#text(" if ")#mi("{c}")#text(" is infinite, and so the use of cancellation (or subtraction) should be avoided if possible.)")
]

#text("One can characterise measures completely for any finite algebra:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{{\\mathcal B}}")#text(" be a finite Boolean algebra, generated by a finite family ")#mi("{A_1,\\ldots,A_k}")#text(" of non-empty atoms. Show that for every finitely additive measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\mathcal B}}")#text(" there exists ")#mi("{c_1,\\ldots,c_k \\in [0,+\\infty]}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mu(E) = \\sum_{1 \\leq j \\leq k: A_j \\subset E} c_j.")]]

#text("Equivalently, if ")#mi("{x_j}")#text(" is a point in ")#mi("{A_j}")#text(" for each ")#mi("{1 \\leq j \\leq k}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mu = \\sum_{j=1}^k c_j \\delta_{x_j}.")]]

#text("Furthermore, show that the ")#mi("{c_1,\\ldots,c_k}")#text(" are uniquely determined by ")#mi("{\\mu}")#text(".")
]

#text("This is about the limit of what one can say about finitely additive measures at this level of generality. We now specialise to the ")#emph[#text("countably additive measures")]#text(" on ")#mi("{\\sigma}")#text("-algebras.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7 (Countably additive measure)")]#text(" Let ")#mi("{(X,{\\mathcal B})}")#text(" be a measurable space. An (unsigned) ")#emph[#text("countably additive measure")]#text(" ")#mi("{\\mu}")#text(" on ")#mi("{{\\mathcal B}}")#text(", or ")#emph[#text("measure")]#text(" for short, is a map ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" that obeys the following axioms:")

#enum(start: 1, 
[#text("(Empty set) ")#mi("{\\mu(\\emptyset) = 0}")#text(".")],
[#text("(Countable additivity) Whenever ")#mi("{E_1,E_2,\\ldots \\in {\\mathcal B}}")#text(" are a countable sequence of disjoint measurable sets, then ")#mi("{\\mu(\\bigcup_{n=1}^\\infty E_n) = \\sum_{n=1}^\\infty \\mu(E_n)}")#text(".")]
)

#text("A triplet ")#mi("{(X,{\\mathcal B}, \\mu)}")#text(", where ")#mi("{(X,{\\mathcal B})}")#text(" is a measurable space and ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" is a countably additive measure, is known as a ")#link("http://en.wikipedia.org/wiki/Measure_space")[#text("measure space")]#text(".")
]

#text("Note the distinction between a measure space and a measurable space. The latter has the ")#emph[#text("capability")]#text(" to be equipped with a measure, but the former is ")#emph[#text("actually")]#text(" equipped with a measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 14")]#text(" Lebesgue measure is a countably additive measure on the Lebesgue ")#mi("{\\sigma}")#text("-algebra, and hence on every sub-")#mi("{\\sigma}")#text("-algebra (such as the Borel ")#mi("{\\sigma}")#text("-algebra).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 15")]#text(" The Dirac measures from Exercise ")#link(<tao-6a95eb4f0762bfe01733>)[#text("9")]#text(" are countably additive, as is counting measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 16")]#text(" Any restriction of a countably additive measure to a measurable subspace is again countably additive.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Countable combinations of measures)")]#text(" Let ")#mi("{(X,{\\mathcal B})}")#text(" be a measurable space.")

#enum(start: 1, 
[#text("If ")#mi("{\\mu}")#text(" is a countably additive measure on ")#mi("{{\\mathcal B}}")#text(", and ")#mi("{c \\in [0,+\\infty]}")#text(", then ")#mi("{c\\mu}")#text(" is also countably additive.")],
[#text("If ")#mi("{\\mu_1,\\mu_2,\\ldots}")#text(" are a sequence of countably additive measures on ")#mi("{{\\mathcal B}}")#text(", then the sum ")#mi("{\\sum_{n=1}^\\infty \\mu_n: E \\mapsto \\sum_{n=1}^\\infty \\mu_n(E)}")#text(" is also a countably additive measure.")]
)
]

#text("Note that countable additivity measures are necessarily finitely additive (by padding out a finite union into a countable union using the empty set), and so countably additive measures inherit all the properties of finitely additive properties, such as monotonicity and finite subadditivity. But one also has additional properties:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-79a0171dfb60fec5fc72>#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space.")

#enum(start: 1, 
[#text("(Countable subadditivity) If ")#mi("{E_1, E_2, \\ldots}")#text(" are ")#mi("{{\\mathcal B}}")#text("-measurable, then ")#mi("{\\mu(\\bigcup_{n=1}^\\infty E_n) \\leq \\sum_{n=1}^\\infty \\mu( E_n )}")#text(".")],
[#text("(Upwards monotone convergence) If ")#mi("{E_1 \\subset E_2 \\subset \\ldots}")#text(" are ")#mi("{{\\mathcal B}}")#text("-measurable, then")

#align(center)[#tao-fit-display[#mitex("\\mu(\\bigcup_{n=1}^\\infty E_n) = \\lim_{n \\rightarrow \\infty} \\mu( E_n ) = \\sup_{n} \\mu( E_n ).")]]],
[#text("(Downwards monotone convergence) If ")#mi("{E_1 \\supset E_2 \\supset \\ldots}")#text(" are ")#mi("{{\\mathcal B}}")#text("-measurable, and ")#mi("{\\mu(E_n)<\\infty}")#text(" for at least one ")#mi("{n}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mu(\\bigcap_{n=1}^\\infty E_n) = \\lim_{n \\rightarrow \\infty} \\mu( E_n ) = \\inf_{n} \\mu( E_n ).")]]]
)

#text("Show that the downward monotone convergence claim can fail if the hypothesis that ")#mi("{\\mu(E_n)<\\infty}")#text(" for at least one ")#mi("{n}")#text(" is dropped. (")#emph[#text("Hint:")]#text(" copy the argument used for Exercise 10 in ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Dominated convergence for sets)")]#text(" ")#metadata(none) <tao-b1c5a688abaa81e16898>#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space. Let ")#mi("{E_1,E_2,\\ldots}")#text(" be a sequence of ")#mi("{{\\mathcal B}}")#text("-measurable sets that converge to another set ")#mi("{E}")#text(", in the sense that ")#mi("{1_{E_n}}")#text(" converges pointwise to ")#mi("{1_E}")#text(".")

#enum(start: 1, 
[#text("Show that ")#mi("{E}")#text(" is also ")#mi("{{\\mathcal B}}")#text("-measurable.")],
[#text("If there exists a ")#mi("{{\\mathcal B}}")#text("-measurable set ")#mi("{F}")#text(" of finite measure (i.e. ")#mi("{\\mu(F) < \\infty}")#text(") that contains all of the ")#mi("{E_n}")#text(", show that ")#mi("{\\lim_{n \\rightarrow\\infty} \\mu(E_n) = \\mu(E)}")#text(". (")#emph[#text("Hint:")]#text(" Apply downward monotonicity to the sets ")#mi("{\\bigcup_{n>N} (E_n \\Delta E)}")#text(".)")],
[#text("Show that the previous part of this exercise can fail if the hypothesis that all the ")#mi("{E_n}")#text(" are contained in a set of finite measure is omitted.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Let ")#mi("{X}")#text(" be an at most countable set with the discrete ")#mi("{\\sigma}")#text("-algebra. Show that every measure ")#mi("{\\mu}")#text(" on this measurable space can be uniquely represented in the form")

#align(center)[#tao-fit-display[#mitex("\\mu = \\sum_{x \\in X} c_x \\delta_x")]]

#text("for some ")#mi("{c_x \\in [0,+\\infty]}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\mu(E) = \\sum_{x \\in E} c_x")]]

#text("for all ")#mi("{E \\subset X}")#text(". (This claim fails in the uncountable case, although showing this is slightly tricky.)")
]

#text("A ")#emph[#text("null set")]#text(" of a measure space ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" is defined to be a ")#mi("{{\\mathcal B}}")#text("-measurable set of measure zero. A ")#emph[#text("sub-null set")]#text(" is any subset of a null set. A measure space is said to be ")#link("http://en.wikipedia.org/wiki/Complete_measure")[#text("complete")]#text(" if every sub-null set is a null set. Thus, for instance, the Lebesgue measure space ")#mi("{({\\bf R}^d, {\\mathcal L}[{\\bf R}^d], m)}")#text(" is complete, but the Borel measure space ")#mi("{({\\bf R}^d, {\\mathcal B}[{\\bf R}^d], m)}")#text(" is not (as can be seen from the solution to Exercise ")#link(<tao-873ac9ffea4dd04fa719>)[#text("16")]#text(").")

#text("Completion is a convenient property to have in some cases, particularly when dealing with properties that hold almost everywhere. Fortunately, it is fairly easy to modify any measure space to be complete:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Completion)")]#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space. Show that there exists a unique refinement ")#mi("{(X, \\overline{{\\mathcal B}}, \\overline{\\mu})}")#text(", known as the ")#link("http://en.wikipedia.org/wiki/Complete_measure")[#text("completion")]#text(" of ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(", which is the coarsest refinement of ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" that is complete. Furthermore, show that ")#mi("{\\overline{{\\mathcal B}}}")#text(" consists precisely of those sets that differ from a ")#mi("{{\\mathcal B}}")#text("-measurable set by a ")#mi("{{\\mathcal B}}")#text("-subnull set.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Show that the Lebesgue measure space ")#mi("{({\\bf R}^d, {\\mathcal L}[{\\bf R}^d], m)}")#text(" is the completion of the Borel measure space ")#mi("{({\\bf R}^d, {\\mathcal B}[{\\bf R}^d], m)}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. Measurable functions, and integration on a measure space — ")]]

#text("Now we are ready to define integration on measure spaces. We first need the notion of a ")#emph[#text("measurable function")]#text(", which is analogous to that of a continuous function in topology. Recall that a function ")#mi("{f: X \\rightarrow Y}")#text(" between two topological spaces ")#mi("{X, Y}")#text(" is continuous if the inverse image ")#mi("{f^{-1}(U)}")#text(" of any open set is open. In a similar spirit, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8")]#text(" Let ")#mi("{(X,{\\mathcal B})}")#text(" be a measurable space, and let ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" or ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be an unsigned or complex-valued function. We say that ")#mi("{f}")#text(" is ")#emph[#text("measurable")]#text(" if ")#mi("{f^{-1}(U)}")#text(" is ")#mi("{{\\mathcal B}}")#text("-measurable for every open subset ")#mi("{U}")#text(" of ")#mi("{[0,+\\infty]}")#text(" or ")#mi("{{\\bf C}}")#text(".")
]

#text("From Lemma 7 of Notes 2, we see that this generalises the notion of a Lebesgue measurable function.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{(X,{\\mathcal B})}")#text(" be a measurable space.")

#enum(start: 1, 
[#text("Show that a function ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" is measurable if and only if the level sets ")#mi("{\\{ x \\in X: f(x) > \\lambda \\}}")#text(" are ")#mi("{{\\mathcal B}}")#text("-measurable.")],
[#text("Show that an indicator function ")#mi("{1_E}")#text(" of a set ")#mi("{E \\subset X}")#text(" is measurable if and only if ")#mi("{E}")#text(" itself is ")#mi("{{\\mathcal B}}")#text("-measurable.")],
[#text("Show that a function ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" or ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" is measurable if and only if ")#mi("{f^{-1}(E)}")#text(" is ")#mi("{{\\mathcal B}}")#text("-measurable for every Borel-measurable subset ")#mi("{E}")#text(" of ")#mi("{[0,+\\infty]}")#text(" or ")#mi("{{\\bf C}}")#text(".")],
[#text("Show that a function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" is measurable if and only if its real and imaginary parts are measurable.")],
[#text("Show that a function ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" is measurable if and only if the magnitudes ")#mi("{f_+ := \\max(f,0)}")#text(", ")#mi("{f_- := \\max(-f,0)}")#text(" of its positive and negative parts are measurable.")],
[#text("If ")#mi("{f_n: X \\rightarrow [0,+\\infty]}")#text(" are a sequence of measurable functions that converge pointwise to a limit ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(", then show that ")#mi("{f}")#text(" is also measurable. Obtain the same claim if ")#mi("{[0,+\\infty]}")#text(" is replaced by ")#mi("{{\\bf C}}")#text(".")],
[#text("If ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" is measurable and ")#mi("{\\phi: [0,+\\infty] \\rightarrow [0,+\\infty]}")#text(" is continuous, show that ")#mi("{\\phi \\circ f}")#text(" is measurable. Obtain the same claim if ")#mi("{[0,+\\infty]}")#text(" is replaced by ")#mi("{{\\bf C}}")#text(".")],
[#text("Show that the sum or product of two measurable functions in ")#mi("{[0,+\\infty]}")#text(" or ")#mi("{{\\bf C}}")#text(" is still measurable.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" ")#metadata(none) <tao-78e5fe1da689719621fb>#text(" One can also view measurable functions in a more ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category theoretic")]#text(" fashion. Define ")#emph[#text("measurable morphism")]#text(" or ")#emph[#text("measurable map")]#text(" ")#mi("{f}")#text(" from one measurable space ")#mi("{(X,{\\mathcal B})}")#text(" to another ")#mi("{(Y, {\\mathcal C})}")#text(" to be a function ")#mi("{f: X \\rightarrow Y}")#text(" with the property that ")#mi("{f^{-1}(E)}")#text(" is ")#mi("{{\\mathcal B}}")#text("-measurable for every ")#mi("{{\\mathcal C}}")#text("-measurable set ")#mi("{E}")#text(". Then a measurable function ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" or ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" is the same thing as a measurable morphism from ")#mi("{X}")#text(" to ")#mi("{[0,+\\infty]}")#text(" or ")#mi("{{\\bf C}}")#text(", where the latter is equipped with the Borel ")#mi("{\\sigma}")#text("-algebra. Also, one ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(" on a space ")#mi("{X}")#text(" is coarser than another ")#mi("{{\\mathcal B}^{\\prime}}")#text(" precisely when the identity map ")#mi("{\\text{id}_X: X \\rightarrow X}")#text(" is a measurable morphism from ")#mi("{(X,{\\mathcal B}^{\\prime})}")#text(" to ")#mi("{(X,{\\mathcal B})}")#text(". The main purpose of adopting this viewpoint is that it is obvious that the composition of measurable morphisms is again a measurable morphism. This is important in those fields of mathematics, such as ")#link("http://en.wikipedia.org/wiki/Ergodic_theory")[#text("ergodic theory")]#text(", in which one frequently wishes to compose measurable transformations (and in particular, to compose a transformation ")#mi("{T: (X,{\\mathcal B}) \\rightarrow (X,{\\mathcal B})}")#text(" with itself repeatedly); but it will not play a major role in this course.")
]

#text("Measurable functions are particularly easy to describe on atomic spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" ")#metadata(none) <tao-4801a65632db73daea89>#text(" Let ")#mi("{(X,{\\mathcal B})}")#text(" be a measurable space that is atomic, thus ")#mi("{{\\mathcal B} = {\\mathcal A}((A_\\alpha)_{\\alpha \\in I})}")#text(" for some partition ")#mi("{X = \\bigcup_{\\alpha \\in I} A_\\alpha}")#text(" of ")#mi("{X}")#text(" into disjoint non-empty atoms. Show that a function ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" or ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" is measurable if and only if it is constant on each atom, or equivalently if one has a representation of the form")

#align(center)[#tao-fit-display[#mitex("f = \\sum_{\\alpha \\in I} c_\\alpha 1_{A_\\alpha}")]]

#text("for some constants ")#mi("{c_\\alpha}")#text(" in ")#mi("{[0,+\\infty]}")#text(" or in ")#mi("{{\\bf C}}")#text(" as appropriate. Furthermore, the ")#mi("{c_\\alpha}")#text(" are uniquely determined by ")#mi("{f}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Egorov’s theorem)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a finite measure space (so ")#mi("{\\mu(X) < \\infty}")#text("), and let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions that converge pointwise almost everywhere to a limit ")#mi("{f: X \\rightarrow {\\bf C}}")#text(", and let ")#mi("{\\epsilon > 0}")#text(". Show that there exists a measurable set ")#mi("{E}")#text(" of measure at most ")#mi("{\\epsilon}")#text(" such that ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(" outside of ")#mi("{E}")#text(". Give an example to show that the claim can fail when the measure ")#mi("{\\mu}")#text(" is not finite.")
]

#text("In Notes 2 we defined first an simple integral, then an unsigned integral, and then finally an absolutely convergent integral. We perform the same three stages here. We begin with the simple integral in the case when the ")#mi("{\\sigma}")#text("-algebra is finite:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Simple integral)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space with ")#mi("{{\\mathcal B}}")#text(" finite. By Exercise ")#link(<tao-1bf521836de96e75fac7>)[#text("4")]#text(", ")#mi("{X}")#text(" is partitioned into a finite number of atoms ")#mi("{A_1,\\ldots,A_n}")#text(". If ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" is measurable, then by Exercise ")#link(<tao-4801a65632db73daea89>)[#text("29")]#text(" it has a unique representation of the form")

#align(center)[#tao-fit-display[#mitex("f = \\sum_{i=1}^n c_i 1_{A_i}")]]

#text("for some ")#mi("{c_1,\\ldots,c_n \\in [0,+\\infty]}")#text(". We then define the ")#emph[#text("simple integral")]#text(" ")#mi("{\\text{Simp} \\int_X f\\ d\\mu}")#text(" of ")#mi("{f}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_X f\\ d\\mu := \\sum_{i=1}^n c_i \\mu(A_i).")]]

#text("Note that, thanks to Exercise ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("3")]#text(", the precise decomposition into atoms does not affect the definition of the simple integral.")
]

#text("One could also define a simple integral for absolutely convergent complex-valued functions on a measurable space with a finite ")#mi("{\\sigma}")#text("-algebra, but we will not need to do so here.")

#text("With this definition, it is clear that one has the monotonicity property")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_X f\\ d\\mu \\leq \\text{Simp} \\int_X g\\ d\\mu")]]

#text("whenever ")#mi("{f \\leq g}")#text(" are unsigned measurable, as well as the linearity properties")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_X f+g\\ d\\mu = \\text{Simp} \\int_X f\\ d\\mu + \\text{Simp} \\int_X g\\ d\\mu")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_X cf\\ d\\mu = c \\times \\text{Simp} \\int_X f\\ d\\mu")]]

#text("for unsigned measurable ")#mi("{f,g}")#text(" and ")#mi("{c \\in [0,+\\infty]}")#text(". We also make the following important technical observation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31 (Simple integral unaffected by refinements)")]#text(" ")#metadata(none) <tao-090f669681cd50562598>#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{(X,{\\mathcal B}^{\\prime},\\mu^{\\prime})}")#text(" be a ")#emph[#text("refinement")]#text(" of ")#mi("{(X,{\\mathcal B},\\mu)}")#text(", which means that ")#mi("{{\\mathcal B}^{\\prime}}")#text(" contains ")#mi("{{\\mathcal B}}")#text(" and ")#mi("{\\mu^{\\prime}: {\\mathcal B}^{\\prime} \\rightarrow [0,+\\infty]}")#text(" agrees with ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" on ")#mi("{{\\mathcal B}}")#text(". Suppose that both ")#mi("{{\\mathcal B}, {\\mathcal B}^{\\prime}}")#text(" are finite, and let ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" be measurable. Show that")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_X f\\ d\\mu = \\text{Simp} \\int_X f\\ d\\mu^{\\prime}.")]]
]

#text("This allows one to extend the simple integral to simple functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Integral of simple functions)")]#text(" An (unsigned) ")#emph[#text("simple function")]#text(" ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" on a measurable space ")#mi("{(X,{\\mathcal B})}")#text(" is a measurable function that takes on finitely many values ")#mi("{a_1,\\ldots,a_k}")#text(". Note that such a function is then automatically measurable with respect to at least one finite sub-")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}^{\\prime}}")#text(" of ")#mi("{{\\mathcal B}}")#text(", namely the ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}^{\\prime}}")#text(" generated by the preimages ")#mi("{f^{-1}(\\{a_1\\}),\\ldots,f^{-1}(\\{a_k\\})}")#text(" of ")#mi("{a_1,\\ldots,a_k}")#text(". We then define the simple integral ")#mi("{\\text{Simp} \\int_X f\\ d\\mu}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_X f\\ d\\mu := \\text{Simp} \\int_X f\\ d\\mu\\downharpoonright_{{\\mathcal B}^{\\prime}},")]]

#text("where ")#mi("{\\mu\\downharpoonright_{{\\mathcal B}^{\\prime}}: {\\mathcal B}^{\\prime} \\rightarrow [0,+\\infty]}")#text(" is the restriction of ")#mi("{\\mu: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" to ")#mi("{{\\mathcal B}^{\\prime}}")#text(".")
]

#text("Note that there could be multiple finite ")#mi("{\\sigma}")#text("-algebras with respect to which ")#mi("{f}")#text(" is measurable, but Exercise ")#link(<tao-090f669681cd50562598>)[#text("31")]#text(" guarantees that all such extensions will give the same simple integral. Indeed, if ")#mi("{f}")#text(" were measurable with respect to two separate finite sub-")#mi("{\\sigma}")#text("-algebras ")#mi("{{\\mathcal B}^{\\prime}}")#text(" and ")#mi("{{\\mathcal B}^{\\prime\\prime}}")#text(" of ")#mi("{{\\mathcal B}}")#text(", then it would also be measurable with respect to their common refinement ")#mi("{{\\mathcal B}^{\\prime} \\vee {\\mathcal B}^{\\prime\\prime} := \\langle {\\mathcal B}^{\\prime} \\cup {\\mathcal B}^{\\prime\\prime} \\rangle}")#text(", which is also finite (by Exercise ")#link(<tao-cc8ca30e40d51db2f10a>)[#text("8")]#text("), and then by Exercise ")#link(<tao-090f669681cd50562598>)[#text("31")]#text(", ")#mi("{\\int_X f\\ d\\mu\\downharpoonright_{{\\mathcal B}^{\\prime}}}")#text(" and ")#mi("{\\int_X f\\ d\\mu\\downharpoonright_{{\\mathcal B}^{\\prime\\prime}}}")#text(" are both equal to ")#mi("{\\int_X f\\ d\\mu\\downharpoonright_{{\\mathcal B}^{\\prime} \\vee {\\mathcal B}^{\\prime\\prime}}}")#text(", and hence equal to each other.")

#text("From this we can deduce the following properties of the simple integral. As with the Lebesgue theory, we say that a property ")#mi("{P(x)}")#text(" of an element ")#mi("{x \\in X}")#text(" of a measure space ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" holds ")#emph[#mi("{\\mu}")#text("-almost everywhere")]#text(" if it holds outside of a sub-null set.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32 (Basic properties of the simple integral)")]#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, and let ")#mi("{f, g: X \\rightarrow [0,+\\infty]}")#text(" be simple functions.")

#enum(start: 1, 
[#text("(Monotonicity) If ")#mi("{f \\leq g}")#text(" pointwise, then ")#mi("{\\text{Simp} \\int_X f\\ d\\mu \\leq \\text{Simp} \\int_X g\\ d\\mu}")#text(".")],
[#text("(Compatibility with measure) For every ")#mi("{{\\mathcal B}}")#text("-measurable set ")#mi("{E}")#text(", we have ")#mi("{\\text{Simp} \\int_X 1_E\\ d\\mu = \\mu(E)}")#text(".")],
[#text("(Homogeneity) For every ")#mi("{c \\in [0,+\\infty]}")#text(", one has ")#mi("{\\text{Simp} \\int_X cf\\ d\\mu = c \\times \\text{Simp} \\int_X f\\ d\\mu}")#text(".")],
[#text("(Finite additivity) ")#mi("{\\text{Simp} \\int_X (f+g)\\ d\\mu = \\text{Simp} \\int_X f\\ d\\mu + \\text{Simp} \\int_X g\\ d\\mu}")#text(".")],
[#text("(Insensitivity to refinement) If ")#mi("{(X, {\\mathcal B}^{\\prime}, \\mu^{\\prime})}")#text(" is a refinement of ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" (as defined in Exercise ")#link(<tao-090f669681cd50562598>)[#text("31")]#text("), then ")#mi("{\\text{Simp} \\int_X f\\ d\\mu = \\text{Simp} \\int_X f\\ d\\mu^{\\prime}}")#text(".")],
[#text("(Almost everywhere equivalence) If ")#mi("{f(x)=g(x)}")#text(" for ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(", then ")#mi("{\\text{Simp} \\int_X f\\ d\\mu = \\text{Simp} \\int_X g\\ d\\mu}")#text(".")],
[#text("(Finiteness) ")#mi("{\\text{Simp} \\int_X f\\ d\\mu < \\infty}")#text(" if and only if ")#mi("{f}")#text(" is finite almost everywhere, and is supported on a set of finite measure.")],
[#text("(Vanishing) ")#mi("{\\text{Simp} \\int_X f\\ d\\mu = 0}")#text(" if and only if ")#mi("{f}")#text(" is zero almost everywhere.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33 (Inclusion-exclusion principle)")]#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, and let ")#mi("{A_1, \\ldots, A_n}")#text(" be ")#mi("{{\\mathcal B}}")#text("-measurable sets of finite measure. Show that")

#align(center)[#tao-fit-display[#tao-math("\\mu( \\bigcup_{i=1}^n A_i ) = \\sum_{J \\subset \\{1,\\ldots,n\\}: J \\neq \\emptyset} (-1)^{\\left|J\\right|-1} \\mu( \\bigcap_{i \\in J} A_i ).", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" Compute ")#mi("{\\text{Simp} \\int_X (1 - \\prod_{i=1}^n (1-1_{A_i}))\\ d\\mu}")#text(" in two different ways.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" The simple integral could also be defined on finitely additive measure spaces, rather than countably additive ones, and all the above properties would still apply. However, on a finitely additive measure space one would have difficulty extending the integral beyond simple functions, as we will now do.")
]

#text("From the simple integral, we can now define the unsigned integral, similarly to what was done for the unsigned Lebesgue integral in ")#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")[#text("Notes 2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 11")]#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, and let ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" be measurable. Then we define the unsigned integral ")#mi("{\\int_X f\\ d\\mu}")#text(" of ")#mi("{f}")#text(" by the formula ")#metadata(none) <tao-1c23a14c49f13b1549b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_X f\\ d\\mu := \\sup_{0 \\leq g \\leq f; g \\text{ simple}} \\text{Simp} \\int_X g\\ d\\mu.")]]




]

#text("Clearly, this definition generalises the corresponding definition in Definition 10 of ")#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")[#text("Notes 2")]#text(". Indeed, if ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is Lebesgue measurable, then ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx = \\int_{{\\bf R}^d} f\\ dm}")#text(".")

#text("We record some easy properties of this integral:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Easy properties of the unsigned integral)")]#text(" ")#metadata(none) <tao-97c10efe01d5c9c88704>#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, and let ")#mi("{f,g: X \\rightarrow [0,+\\infty]}")#text(" be measurable.")

#enum(start: 1, 
[#text("(Almost everywhere equivalence) If ")#mi("{f = g}")#text(" ")#mi("{\\mu}")#text("-almost everywhere, then ")#mi("{\\int_X f\\ d\\mu = \\int_X g\\ d\\mu}")],
[#text("(Monotonicity) If ")#mi("{f \\leq g}")#text(" ")#mi("{\\mu}")#text("-almost everywhere, then ")#mi("{\\int_X f\\ d\\mu \\leq \\int_X g\\ d\\mu}")#text(".")],
[#text("(Homogeneity) We have ")#mi("{\\int_X cf\\ d\\mu = c \\int_X f\\ d\\mu}")#text(" for every ")#mi("{c \\in [0,+\\infty]}")#text(".")],
[#text("(Superadditivity) We have ")#mi("{\\int_X (f+g)\\ d\\mu \\geq \\int_X f\\ d\\mu + \\int_X g\\ d\\mu}")#text(".")],
[#text("(Compatibility with the simple integral) If ")#mi("{f}")#text(" is simple, then ")#mi("{\\int_X f\\ d\\mu = \\text{Simp} \\int_X f\\ d\\mu}")#text(".")],
[#text("(Markov’s inequality) For any ")#mi("{0 < \\lambda < \\infty}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\mu( \\{ x \\in X: f(x) \\geq \\lambda \\} ) \\leq \\frac{1}{\\lambda} \\int_X f\\ d\\mu.")]]

#text("In particular, if ")#mi("{\\int_X f\\ d\\mu < \\infty}")#text(", then the sets ")#mi("{\\{ x \\in X: f(x) \\geq \\lambda \\}}")#text(" have finite measure for each ")#mi("{\\lambda > 0}")#text(".")],
[#text("(Finiteness) If ")#mi("{\\int_X f\\ d\\mu < \\infty}")#text(", then ")#mi("{f(x)}")#text(" is finite for ")#mi("{\\mu}")#text("-almost every ")#mi("{x}")#text(".")],
[#text("(Vanishing) If ")#mi("{\\int_X f\\ d\\mu = 0}")#text(", then ")#mi("{f(x)}")#text(" is zero for ")#mi("{\\mu}")#text("-almost every ")#mi("{x}")#text(".")],
[#text("(Horizontal truncation) We have ")#mi("{\\lim_{n \\rightarrow \\infty} \\int_X \\min(f,n)\\ d\\mu = \\int_X f\\ d\\mu}")#text(".")],
[#text("(Vertical truncation) If ")#mi("{E_1 \\subset E_2 \\subset \\ldots}")#text(" is an increasing sequence of ")#mi("{{\\mathcal B}}")#text("-measurable sets, then")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\int_X f 1_{E_n}\\ d\\mu = \\int_X f 1_{\\bigcup_{n=1}^\\infty E_n}\\ d\\mu.")]]],
[#text("(Restriction) If ")#mi("{Y}")#text(" is a measurable subset of ")#mi("{X}")#text(", then ")#mi("{\\int_X f 1_Y\\ d\\mu = \\int_Y f\\downharpoonright_Y d\\mu\\downharpoonright_Y}")#text(", where ")#mi("{f\\downharpoonright_Y: Y \\rightarrow [0,+\\infty]}")#text(" is the restriction of ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" to ")#mi("{Y}")#text(", and the restriction ")#mi("{\\mu\\downharpoonright_Y}")#text(" was defined in Example ")#link(<tao-e19e3bc5684859d8e20e>)[#text("12")]#text(". We will often abbreviate ")#mi("{\\int_Y f\\downharpoonright_Y d\\mu\\downharpoonright_Y}")#text(" (by slight abuse of notation) as ")#mi("{\\int_Y f\\ d\\mu}")#text(".")]
)
]

#text("As before, one of the key properties of this integral is its additivity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12")]#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, and let ")#mi("{f,g: X \\rightarrow [0,+\\infty]}")#text(" be measurable. Then")

#align(center)[#tao-fit-display[#mitex("\\int_X (f+g)\\ d\\mu = \\int_X f\\ d\\mu + \\int_X g\\ d\\mu.")]]
]

#emph[#text("Proof:")]#text(" In view of super-additivity, it suffices to establish the sub-additivity property")

#align(center)[#tao-fit-display[#mitex("\\int_X (f+g)\\ d\\mu \\leq \\int_X f\\ d\\mu + \\int_X g\\ d\\mu")]]

#text("We establish this in stages. We first deal with the case when ")#mi("{\\mu}")#text(" is a ")#emph[#text("finite")]#text(" measure (which means that ")#mi("{\\mu(X) < \\infty}")#text(") and ")#mi("{f, g}")#text(" are bounded. Pick an ")#mi("{\\epsilon > 0}")#text(", and let ")#mi("{f_\\epsilon}")#text(" be ")#mi("{f}")#text(" rounded down to the nearest integer multiple of ")#mi("{\\epsilon}")#text(", and ")#mi("{f^\\epsilon}")#text(" be ")#mi("{f}")#text(" rounded up to the nearest integer multiple. Clearly, we have the pointwise bounds")

#align(center)[#tao-fit-display[#mitex("f_\\epsilon(x) \\leq f(x) \\leq f^\\epsilon(x)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("f^\\epsilon(x)-f_\\epsilon(x) \\leq \\epsilon.")]]

#text("Since ")#mi("{f}")#text(" is bounded, ")#mi("{f_\\epsilon}")#text(" and ")#mi("{f^\\epsilon}")#text(" are simple. Similarly define ")#mi("{g_\\epsilon, g^\\epsilon}")#text(". We then have the pointwise bound")

#align(center)[#tao-fit-display[#mitex("f+g \\leq f^\\epsilon + g^\\epsilon \\leq f_\\epsilon + g_\\epsilon + 2\\epsilon,")]]

#text("hence by Exercise ")#link(<tao-97c10efe01d5c9c88704>)[#text("34")]#text(" and the properties of the simple integral,")

#tao-aligned(keep: true)[


#tao-math("\\int_X f+g\\ d\\mu  & \\leq \\int_X f_\\epsilon + g_\\epsilon + 2\\epsilon\\ d\\mu", block: true)



#tao-math(" & = \\text{Simp} \\int_X f_\\epsilon + g_\\epsilon + 2\\epsilon\\ d\\mu", block: true)



#tao-math(" & = \\text{Simp} \\int_X f_\\epsilon\\ d\\mu + \\text{Simp} \\int_X g_\\epsilon\\ d\\mu + 2 \\epsilon \\mu(X).", block: true)
]

#text("From ")#link(<tao-1c23a14c49f13b1549b7>)[#text("(1)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_X f+g\\ d\\mu \\leq \\int_X f\\ d\\mu + \\int_X g\\ d\\mu + 2 \\epsilon \\mu(X).")]]

#text("Letting ")#mi("{\\epsilon \\rightarrow 0}")#text(" and using the assumption that ")#mi("{\\mu(X)}")#text(" is finite, we obtain the claim.")

#text("Now we continue to assume that ")#mi("{\\mu}")#text(" is a finite measure, but now do not assume that ")#mi("{f, g}")#text(" are bounded. Then for any natural number ")#mi("{n}")#text(", we can use the previous case to deduce that")

#align(center)[#tao-fit-display[#mitex("\\int_X \\min(f,n) + \\min(g,n)\\ d\\mu \\leq \\int_X \\min(f,n)\\ d\\mu + \\int_X \\min(g,n)\\ d\\mu.")]]

#text("Since ")#mi("{\\min(f+g,n) \\leq \\min(f,n) + \\min(g,n)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_X \\min(f+g,n) \\leq \\int_X \\min(f,n)\\ d\\mu + \\int_X \\min(g,n)\\ d\\mu.")]]

#text("Taking limits as ")#mi("{n \\rightarrow \\infty}")#text(" using horizontal truncation, we obtain the claim.")

#text("Finally, we no longer assume that ")#mi("{\\mu}")#text(" is of finite measure, and also do not require ")#mi("{f, g}")#text(" to be bounded. If either ")#mi("{\\int_X f\\ d\\mu}")#text(" or ")#mi("{\\int_X g\\ d\\mu}")#text(" is infinite, then by monotonicity, ")#mi("{\\int_X f+g\\ d\\mu}")#text(" is infinite as well, and the claim follows; so we may assume that ")#mi("{\\int_X f\\ d\\mu}")#text(" and ")#mi("{\\int_X g\\ d\\mu}")#text(" are both finite. By Markov’s inequality, we conclude that for each natural number ")#mi("{n}")#text(", the set ")#mi("{E_n := \\{ x \\in X: f(x) > \\frac{1}{n} \\} \\cup \\{ x \\in X: g(x) > \\frac{1}{n} \\}}")#text(" has finite measure. These sets are increasing in ")#mi("{n}")#text(", and ")#mi("{f, g, f+g}")#text(" are supported on ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(", and so by vertical truncation")

#align(center)[#tao-fit-display[#mitex("\\int_X (f+g)\\ d\\mu = \\lim_{n \\rightarrow \\infty} \\int_X (f+g) 1_{E_n}\\ d\\mu.")]]

#text("From the previous case, we have")

#align(center)[#tao-fit-display[#mitex("\\int_X (f+g) 1_{E_n}\\ d\\mu \\leq \\int_X f 1_{E_n}\\ d\\mu + \\int_X g 1_{E_n}\\ d\\mu.")]]

#text("Letting ")#mi("{n \\rightarrow \\infty}")#text(" and using vertical truncation we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Linearity in ")#mi("{\\mu}")#text(")")]#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, and let ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" be measurable.")

#enum(start: 1, 
[#text("Show that ")#mi("{\\int_X f\\ d(c\\mu) = c \\times \\int_X f\\ d\\mu}")#text(" for every ")#mi("{c \\in [0,+\\infty]}")#text(".")],
[#text("If ")#mi("{\\mu_1, \\mu_2, \\ldots}")#text(" are a sequence of measures on ")#mi("{{\\mathcal B}}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\sum_{n=1}^\\infty \\mu_n = \\sum_{n=1}^\\infty \\int_X f\\ d\\mu_n.")]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36 (Change of variables formula)")]#text(" ")#metadata(none) <tao-12ea12eace7d655f471c>#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, and let ")#mi("{\\phi: X \\rightarrow Y}")#text(" be a measurable morphism (as defined in Remark ")#link(<tao-78e5fe1da689719621fb>)[#text("8")]#text(") from ")#mi("{(X, {\\mathcal B})}")#text(" to another measurable space ")#mi("{(Y, {\\mathcal C})}")#text(". Define the ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("pushforward")]#text(" ")#mi("{\\phi_* \\mu: {\\mathcal C} \\rightarrow [0,+\\infty]}")#text(" of ")#mi("{\\mu}")#text(" by ")#mi("{\\phi}")#text(" by the formula ")#mi("{\\phi_* \\mu(E) := \\mu(\\phi^{-1}(E))}")#text(".")

#enum(start: 1, 
[#text("Show that ")#mi("{\\phi_* \\mu}")#text(" is a measure on ")#mi("{{\\mathcal C}}")#text(", so that ")#mi("{(Y, {\\mathcal C}, \\phi_* \\mu)}")#text(" is a measure space.")],
[#text("If ")#mi("{f: Y \\rightarrow [0,+\\infty]}")#text(" is measurable, show that ")#mi("{\\int_Y f\\ d\\phi_* \\mu = \\int_X (f \\circ \\phi)\\ d\\mu}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" the quickest proof here is via the monotone convergence theorem below, but it is also possible to prove the exercise without this theorem.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Let ")#mi("{T: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be an invertible linear transformation, and let ")#mi("{m}")#text(" be Lebesgue measure on ")#mi("{{\\bf R}^d}")#text(". Show that ")#tao-math("{T_* m = \\frac{1}{\\left|\\det T\\right|} m}", block: false)#text(", where the pushforward ")#mi("{T_* m}")#text(" of ")#mi("{m}")#text(" was defined in Exercise ")#link(<tao-12ea12eace7d655f471c>)[#text("36")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38 (Sums as integrals)")]#text(" Let ")#mi("{X}")#text(" be an arbitrary set (with the discrete ")#mi("{\\sigma}")#text("-algebra), let ")#mi("{\\#}")#text(" be counting measure (see Example ")#link(<tao-6c35493a2b937829c981>)[#text("13")]#text("), and let ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" be an arbitrary unsigned function. Show that ")#mi("{f}")#text(" is measurable with")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\# = \\sum_{x \\in X} f(x).")]]
]

#text("Once one has the unsigned integral, one can define the absolutely convergent integral exactly as in the Lebesgue case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 13 (Absolutely convergent integral)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space. A measurable function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" is said to be ")#emph[#text("absolutely integrable")]#text(" if the unsigned integral")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^1(X,{\\mathcal B},\\mu)} := \\int_{X} |f|\\ d\\mu", block: true)]]

#text("is finite, and use ")#mi("{L^1(X,{\\mathcal B},\\mu)}")#text(", ")#mi("{L^1(X)}")#text(", or ")#mi("{L^1(\\mu)}")#text(" to denote the space of absolutely integrable functions. If ")#mi("{f}")#text(" is real-valued and absolutely integrable, we define the integral ")#mi("{\\int_X f\\ d\\mu}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\mu := \\int_X f_+\\ d\\mu - \\int_X f_-\\ d\\mu")]]

#text("where ")#mi("{f_+ := \\max(f,0)}")#text(", ")#mi("{f_- := \\max(-f,0)}")#text(" are the magnitudes of the positive and negative components of ")#mi("{f}")#text(". If ")#mi("{f}")#text(" is complex-valued and absolutely integrable, we define the integral ")#mi("{\\int_X f\\ d\\mu}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\mu := \\int_X \\text{Re} f\\ d\\mu + i \\int_X \\text{Im} f\\ d\\mu")]]

#text("where the two integrals on the right are interpreted as real-valued integrals. It is easy to see that the unsigned, real-valued, and complex-valued integrals defined in this manner are compatible on their common domains of definition.")
]

#text("Clearly, this definition generalises the corresponding definition in Definition 13 of ")#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")[#text("Notes 2")]#text(".")

#text("We record some of the key facts about the absolutely convergent integral:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space.")

#enum(start: 1, 
[#text("Show that ")#mi("{L^1(X,{\\mathcal B},\\mu)}")#text(" is a complex vector space.")],
[#text("Show that the integration map ")#mi("{f \\mapsto \\int_X f\\ d\\mu}")#text(" is a complex-linear map from ")#mi("{L^1(X,{\\mathcal B},\\mu)}")#text(" to ")#mi("{{\\bf C}}")#text(".")],
[#text("Establish the triangle inequality ")#tao-math("{\\left\\|f+g\\right\\|_{L^1(\\mu)} \\leq \\left\\|f\\right\\|_{L^1(\\mu)} + \\left\\|g\\right\\|_{L^1(\\mu)}}", block: false)#text(" and the homogeneity property ")#tao-math("{\\left\\|cf\\right\\|_{L^1(\\mu)} = \\left|c\\right| \\left\\|f\\right\\|_{L^1(\\mu)}}", block: false)#text(" for all ")#mi("{f,g \\in L^1(X,{\\mathcal B},\\mu)}")#text(" and ")#mi("{c \\in {\\bf C}}")#text(".")],
[#text("Show that if ")#mi("{f, g \\in L^1(X,{\\mathcal B},\\mu)}")#text(" are such that ")#mi("{f(x)=g(x)}")#text(" for ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(", then ")#mi("{\\int_X f\\ d\\mu = \\int_X g\\ d\\mu}")#text(".")],
[#text("If ")#mi("{f \\in L^1(X,{\\mathcal B},\\mu)}")#text(", and ")#mi("{(X,{\\mathcal B}^{\\prime},\\mu^{\\prime})}")#text(" is a refinement of ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(", then ")#mi("{f \\in L^1(X,{\\mathcal B}^{\\prime}, \\mu^{\\prime})}")#text(", and ")#mi("{\\int_X f\\ d\\mu^{\\prime} = \\int_X f\\ d\\mu}")#text(". (")#emph[#text("Hint:")]#text(" first reduce to the unsigned case. Then it is easy to get one inequality. To get the other inequality, first work in the case when ")#mi("{f}")#text(" is both bounded and has finite measure support (i.e. is both vertically and horizontally truncated).)")],
[#text("Show that if ")#mi("{f \\in L^1(X,{\\mathcal B},\\mu)}")#text(", then ")#tao-math("{\\left\\|f\\right\\|_{L^1(\\mu)}=0}", block: false)#text(" if and only if ")#mi("{f}")#text(" is zero ")#mi("{\\mu}")#text("-almost everywhere.")],
[#text("If ")#mi("{Y \\subset X}")#text(" is ")#mi("{{\\mathcal B}}")#text("-measurable and ")#mi("{f \\in L^1(X,{\\mathcal B},\\mu)}")#text(", then ")#mi("{f\\downharpoonright_Y \\in L^1(Y, {\\mathcal B}\\downharpoonright_Y, \\mu\\downharpoonright_Y)}")#text(" and ")#mi("{\\int_Y f\\downharpoonright_Y\\ d\\mu\\downharpoonright_Y = \\int_X f 1_Y\\ d\\mu}")#text(". As before, by abuse of notation we write ")#mi("{\\int_Y f\\ d\\mu}")#text(" for ")#mi("{\\int_Y f\\downharpoonright_Y\\ d\\mu\\downharpoonright_Y}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 5. The convergence theorems — ")]]

#text("Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{f_1, f_2, \\ldots: X \\rightarrow [0,+\\infty]}")#text(" be a sequence of measurable functions. Suppose that as ")#mi("{n \\rightarrow \\infty}")#text(", ")#mi("{f_n(x)}")#text(" converges pointwise either everywhere, or ")#mi("{\\mu}")#text("-almost everywhere, to a measurable limit ")#mi("{f}")#text(". A basic question in the subject is to determine the conditions under which such pointwise convergence would imply convergence of the integral:")

#align(center)[#tao-fit-display[#mitex("\\int_X f_n\\ d\\mu \\stackrel{?}{\\rightarrow} \\int_X f\\ d\\mu.")]]

#text("To put it another way: when can we ensure that one can interchange integrals and limits,")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu \\stackrel{?}{=} \\int_X \\lim_{n \\rightarrow \\infty} f_n\\ d\\mu?")]]

#text("There are certainly some cases in which one can safely do this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (Uniform convergence on a finite measure space)")]#text(" ")#metadata(none) <tao-42f3871d6e19f585e4dd>#text(" Suppose that ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" is a ")#emph[#text("finite")]#text(" measure space (so ")#mi("{\\mu(X)<\\infty}")#text("), and ")#mi("{f_n: X \\rightarrow [0,+\\infty]}")#text(" (resp. ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(") are a sequence of unsigned measurable functions (resp. absolutely integrable functions) that converge ")#link("http://en.wikipedia.org/wiki/Uniform_convergence")[#text("uniformly")]#text(" to a limit ")#mi("{f}")#text(". Show that ")#mi("{\\int_X f_n\\ d\\mu}")#text(" converges to ")#mi("{\\int_X f\\ d\\mu}")#text(".")
]

#text("However, there are also cases in which one cannot interchange limits and integrals, even when the ")#mi("{f_n}")#text(" are unsigned. We give the three classic examples, all of “moving bump” type, though the way in which the bump moves varies from example to example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 17 (Escape to horizontal infinity)")]#text(" Let ")#mi("{X}")#text(" be the real line with Lebesgue measure, and let ")#mi("{f_n := 1_{[n,n+1]}}")#text(". Then ")#mi("{f_n}")#text(" converges pointwise to ")#mi("{f := 0}")#text(", but ")#mi("{\\int_{\\bf R} f_n(x)\\ dx = 1}")#text(" does not converge to ")#mi("{\\int_{\\bf R} f(x)\\ dx = 0}")#text(". Somehow, all the mass in the ")#mi("{f_n}")#text(" has escaped by moving off to infinity in a horizontal direction, leaving none behind for the pointwise limit ")#mi("{f}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 18 (Escape to width infinity)")]#text(" Let ")#mi("{X}")#text(" be the real line with Lebesgue measure, and let ")#mi("{f_n := \\frac{1}{n} 1_{[0,n]}}")#text(". Then ")#mi("{f_n}")#text(" now converges ")#emph[#text("uniformly")]#text(" ")#mi("{f := 0}")#text(", but ")#mi("{\\int_{\\bf R} f_n(x)\\ dx = 1}")#text(" still does not converge to ")#mi("{\\int_{\\bf R} f(x)\\ dx = 0}")#text(". Exercise ")#link(<tao-42f3871d6e19f585e4dd>)[#text("40")]#text(" would prevent this from happening if all the ")#mi("{f_n}")#text(" were supported in a single set of finite measure, but the increasingly wide nature of the support of the ")#mi("{f_n}")#text(" prevents this from happening.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 19 (Escape to vertical infinity)")]#text(" Let ")#mi("{X}")#text(" be the unit interval ")#mi("{[0,1]}")#text(" with Lebesgue measure (restricted from ")#mi("{{\\bf R}}")#text("), and let ")#mi("{f_n := n 1_{[\\frac{1}{n},\\frac{2}{n}]}}")#text(". Now, we have finite measure, and ")#mi("{f_n}")#text(" converges pointwise to ")#mi("{f}")#text(", but no uniform convergence. And again, ")#mi("{\\int_{[0,1]} f_n(x)\\ dx=1}")#text(" is not converging to ")#mi("{\\int_{[0,1]} f(x)\\ dx = 0}")#text(". This time, the mass has escaped vertically, through the increasingly large values of ")#mi("{f_n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" From the perspective of ")#link("http://en.wikipedia.org/wiki/Time%E2%80%93frequency_analysis")[#text("time-frequency analysis")]#text(" (or perhaps more accurately, space-frequency analysis), these three escapes are analogous (though not quite identical) to escape to spatial infinity, escape to zero frequency, and escape to infinite frequency respectively, thus describing the three different ways in which ")#link("http://en.wikipedia.org/wiki/Phase_space")[#text("phase space")]#text(" fails to be compact (if one excises the zero frequency as being singular).")
]

#text("However, once one shuts down these avenues of escape to infinity, it turns out that one can recover convergence of the integral. There are two major ways to accomplish this. One is to enforce ")#emph[#text("monotonicity")]#text(", which prevents each ")#mi("{f_n}")#text(" from abandoning the location where the mass of the preceding ")#mi("{f_1,\\ldots,f_{n-1}}")#text(" was concentrated and which thus shuts down the above three escape scenarios. More precisely, we have the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Monotone convergence theorem)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{0 \\leq f_1 \\leq f_2 \\leq \\ldots}")#text(" be a monotone non-decreasing sequence of unsigned measurable functions on ")#mi("{X}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu = \\int_X \\lim_{n \\rightarrow \\infty} f_n\\ d\\mu.")]]
]

#text("Note that in the special case when each ")#mi("{f_n}")#text(" is an indicator function ")#mi("{f_n = 1_{E_n}}")#text(", this theorem collapses to the upwards monotone convergence property (Exercise ")#link(<tao-79a0171dfb60fec5fc72>)[#text("23")]#text(".2). Conversely, the upwards monotone convergence property will play a key role in the proof of this theorem.")

#emph[#text("Proof:")]#text(" Write ")#mi("{f := \\lim_{n \\rightarrow \\infty} f_n = \\sup_{n} f_n}")#text(", then ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" is measurable. Since the ")#mi("{f_n}")#text(" are non-decreasing to ")#mi("{f}")#text(", we see from monotonicity that ")#mi("{\\int_X f_n\\ d\\mu}")#text(" are non-decreasing and bounded above by ")#mi("{\\int_X f\\ d\\mu}")#text(", which gives the bound")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu \\leq \\int_X f\\ d\\mu.")]]

#text("It remains to establish the reverse inequality")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\mu \\leq \\lim_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu.")]]

#text("By definition, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_X g\\ d\\mu \\leq \\lim_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu.")]]

#text("whenever ")#mi("{g}")#text(" is a simple function that is bounded pointwise by ")#mi("{f}")#text(". By horizontal truncation we may assume without loss of generality that ")#mi("{g}")#text(" also is finite everywhere, then we can write")

#align(center)[#tao-fit-display[#mitex("g = \\sum_{i=1}^k c_i 1_{A_i}")]]

#text("for some ")#mi("{0 \\leq c_i < \\infty}")#text(" and some disjoint ")#mi("{{\\mathcal B}}")#text("-measurable sets ")#mi("{A_1,\\ldots,A_k}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\int_X g\\ d\\mu = \\sum_{i=1}^k c_i \\mu(A_i).")]]

#text("Let ")#mi("{0 < \\epsilon < 1}")#text(" be arbitrary. Then we have")

#align(center)[#tao-fit-display[#mitex("f(x) = \\sup_n f_n(x) > (1-\\epsilon) c_i")]]

#text("for all ")#mi("{x \\in A_i}")#text(". Thus, if we define the sets")

#align(center)[#tao-fit-display[#mitex("A_{i,n} :=\\{ x \\in A_i: f_n(x) > (1-\\epsilon) c_i \\}")]]

#text("then the ")#mi("{A_{i,n}}")#text(" increase to ")#mi("{A_i}")#text(" and are measurable. By upwards monotonicity of measure, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\mu(A_{i,n}) = \\mu(A_i).")]]

#text("On the other hand, observe the pointwise bound")

#align(center)[#tao-fit-display[#mitex("f_n \\geq \\sum_{i=1}^k (1-\\epsilon) c_i 1_{A_{i,n}}")]]

#text("for any ")#mi("{n}")#text("; integrating this, we obtain")

#align(center)[#tao-fit-display[#mitex("\\int_X f_n\\ d\\mu \\geq (1-\\epsilon) \\sum_{i=1}^k c_i \\mu(A_{i,n}).")]]

#text("Taking limits as ")#mi("{n \\rightarrow \\infty}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu \\geq (1-\\epsilon) \\sum_{i=1}^k c_i \\mu(A_i);")]]

#text("sending ")#mi("{\\epsilon \\rightarrow 0}")#text(" we then obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" It is easy to see that the result still holds if the monotonicity ")#mi("{f_n \\leq f_{n+1}}")#text(" only holds almost everywhere rather than everywhere.")
]

#text("This has a number of important corollaries. Firstly, we can generalise (part of) ")#link("http://en.wikipedia.org/wiki/Fubini's_theorem#Tonelli.27s_theorem")[#text("Tonelli’s theorem")]#text(" for exchanging sums (see Theorem 2 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 15 (Tonelli’s theorem for sums and integrals)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{f_1,f_2,\\ldots: X \\rightarrow [0,+\\infty]}")#text(" be a sequence of unsigned measurable functions. Then one has")

#align(center)[#tao-fit-display[#mitex("\\int_X \\sum_{n=1}^\\infty f_n\\ d\\mu = \\sum_{n=1}^\\infty \\int_X f_n\\ d\\mu.")]]
]

#emph[#text("Proof:")]#text(" Apply the monotone convergence theorem to the partial sums ")#mi("{F_N := \\sum_{n=1}^N f_n}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" Give an example to show that this corollary can fail if the ")#mi("{f_n}")#text(" are assumed to be absolutely integrable rather than unsigned measurable, even if the sum ")#mi("{\\sum_{n=1}^\\infty f_n(x)}")#text(" is absolutely convergent for each ")#mi("{x}")#text(". (")#emph[#text("Hint:")]#text(" think about the three escapes to infinity.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42 (Borel-Cantelli lemma)")]#text(" ")#metadata(none) <tao-1e0bbd6c686ba050b8eb>#text(" Let ")#mi("{(X, {\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{E_1, E_2, E_3, \\ldots}")#text(" be a sequence of ")#mi("{{\\mathcal B}}")#text("-measurable sets such that ")#mi("{\\sum_{n=1}^\\infty \\mu(E_n) < \\infty}")#text(". Show that almost every ")#mi("{x \\in X}")#text(" is contained in at most finitely many of the ")#mi("{E_n}")#text(" (i.e. ")#mi("{\\{ n \\in {\\bf N}: x \\in E_n \\}}")#text(" is finite for almost every ")#mi("{x \\in X}")#text("). (")#emph[#text("Hint:")]#text(" Apply Tonelli’s theorem to the indicator functions ")#mi("{1_{E_n}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]

#enum(start: 1, 
[#text("Give an alternate proof of the Borel-Cantelli lemma (Exercise ")#link(<tao-1e0bbd6c686ba050b8eb>)[#text("42")]#text(") that does not go through any of the convergence theorems, but instead exploits the more basic properties of measure from Exercise ")#link(<tao-79a0171dfb60fec5fc72>)[#text("23")]#text(".")],
[#text("Give a counterexample that shows that the Borel-Cantelli lemma can fail if the condition ")#mi("{\\sum_{n=1}^\\infty \\mu(E_n) < \\infty}")#text(" is relaxed to ")#mi("{\\lim_{n \\rightarrow \\infty} \\mu(E_n) = 0}")#text(".")]
)
]

#text("Secondly, when one does not have monotonicity, one can at least obtain an important inequality, known as ")#link("http://en.wikipedia.org/wiki/Fatou's_lemma")[#text("Fatou’s lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 16 (Fatou’s lemma)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{f_1,f_2,\\ldots: X \\rightarrow [0,+\\infty]}")#text(" be a sequence of unsigned measurable functions. Then")

#align(center)[#tao-fit-display[#mitex("\\int_X \\liminf_{n \\rightarrow \\infty} f_n\\ d\\mu \\leq \\liminf_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu.")]]
]

#emph[#text("Proof:")]#text(" Write ")#mi("{F_N := \\inf_{n \\geq N} f_n}")#text(" for each ")#mi("{N}")#text(". Then the ")#mi("{F_N}")#text(" are measurable and non-decreasing, and hence by the monotone convergence theorem")

#align(center)[#tao-fit-display[#mitex("\\int_X \\sup_{N>0} F_N\\ d\\mu = \\sup_{N>0} \\int_X F_N\\ d\\mu.")]]

#text("By definition of lim inf, we have ")#mi("{\\sup_{N>0} F_N = \\liminf_{n \\rightarrow \\infty} f_n}")#text(". By monotonicity, we have ")#mi("{\\int_X F_N\\ d\\mu \\leq \\int_X f_n\\ d\\mu}")#text(" for all ")#mi("{n \\geq N}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\int_X F_N\\ d\\mu \\leq \\inf_{n \\geq N} \\int_X f_n\\ d\\mu.")]]

#text("Hence we have")

#align(center)[#tao-fit-display[#mitex("\\int_X \\liminf_{n \\rightarrow \\infty} f_n\\ d\\mu \\leq \\sup_{N>0} \\inf_{n \\geq N} \\int_X f_n\\ d\\mu.")]]

#text("The claim then follows by another appeal to the definition of lim inf. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" Informally, Fatou’s lemma tells us that when taking the pointwise limit of unsigned functions ")#mi("{f_n}")#text(", that mass ")#mi("{\\int_X f_n\\ d\\mu}")#text(" can be destroyed in the limit (as was the case in the three key moving bump examples), but it cannot be created in the limit. Of course the unsigned hypothesis is necessary here (consider for instance multiplying any of the moving bump examples by ")#mi("{-1}")#text("). While this lemma was stated only for pointwise limits, the same general principle (that mass can be destroyed, but not created, by the process of taking limits) tends to hold for other “weak” notions of convergence. We will see some instances of this ")#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")[#text("in 245B")]#text(".")
]

#text("Finally, we give the other major way to shut down loss of mass via escape to infinity, which is to ")#emph[#text("dominate")]#text(" all of the functions involved by an absolutely convergent one. This result is known as the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17 (Dominated convergence theorem)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{f_1,f_2,\\ldots: X \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions that converge pointwise ")#mi("{\\mu}")#text("-almost everywhere to a measurable limit ")#mi("{f: X \\rightarrow {\\bf C}}")#text(". Suppose that there is an unsigned absolutely integrable function ")#mi("{G: X \\rightarrow [0,+\\infty]}")#text(" such that ")#tao-math("{\\left|f_n\\right|}", block: false)#text(" are pointwise ")#mi("{\\mu}")#text("-almost everywhere bounded by ")#mi("{G}")#text(" for each ")#mi("{n}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu = \\int_X f\\ d\\mu.")]]
]

#text("From the moving bump examples we see that this statement fails if there is no absolutely integrable dominating function ")#mi("{G}")#text(". The reader is encouraged to see why, in each of the moving bump examples, no such dominating function exists, without appealing to the above theorem. Note also that when each of the ")#mi("{f_n}")#text(" is an indicator function ")#mi("{f_n = 1_{E_n}}")#text(", the dominated convergence theorem collapses to Exercise ")#link(<tao-b1c5a688abaa81e16898>)[#text("24")]#text(".")

#emph[#text("Proof:")]#text(" By modifying ")#mi("{f_n, f}")#text(" on a null set, we may assume without loss of generality that the ")#mi("{f_n}")#text(" converge to ")#mi("{f}")#text(" pointwise everywhere rather than ")#mi("{\\mu}")#text("-almost everywhere, and similarly we can assume that ")#mi("{|f_n}")#text(" are bounded by ")#mi("{G}")#text(" pointwise everywhere rather than ")#mi("{\\mu}")#text("-almost everywhere.")

#text("By taking real and imaginary parts we may assume without loss of generality that ")#mi("{f_n, f}")#text(" are real, thus ")#mi("{-G \\leq f_n \\leq G}")#text(" pointwise. Of course, this implies that ")#mi("{-G \\leq f \\leq G}")#text(" pointwise also.")

#text("If we apply Fatou’s lemma to the unsigned functions ")#mi("{f_n+G}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\int_X f+G\\ d\\mu \\leq \\liminf_{n \\rightarrow \\infty} \\int_X f_n + G\\ d\\mu,")]]

#text("which on subtracting the ")#emph[#text("finite")]#text(" quantity ")#mi("{\\int_X G\\ d\\mu}")#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\mu \\leq \\liminf_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu.")]]

#text("Similarly, if we apply that lemma to the unsigned functions ")#mi("{G-f_n}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\int_X G-f\\ d\\mu \\leq \\liminf_{n \\rightarrow \\infty} \\int_X G - f_n\\ d\\mu;")]]

#text("negating this inequality and then cancelling ")#mi("{\\int_X G\\ d\\mu}")#text(" again we conclude that")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu \\leq \\int_X f\\ d\\mu.")]]

#text("The claim then follows by combining these inequalities. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" We deduced the dominated convergence theorem from Fatou’s lemma, and Fatou’s lemma from the monotone convergence theorem. However, one can obtain these theorems in a different order, depending on one’s taste, as they are so closely related. For instance, in Stein-Shakarchi, the logic is somewhat different; one first obtains the slightly simpler ")#emph[#text("bounded convergence theorem")]#text(", which is the dominated convergence theorem under the assumption that the functions are uniformly bounded and all supported on a single set of finite measure, and then uses that to deduce Fatou’s lemma, which in turn is used to deduce the monotone convergence theorem; and then the horizontal and vertical truncation properties are used to extend the bounded convergence theorem to the dominated convergence theorem. It is instructive to view a couple different derivations of these key theorems to get more of an intuitive understanding as to how they work.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Under the hypotheses of the dominated convergence theorem, establish also that ")#tao-math("{\\left\\|f_n - f \\right\\|_{L^1} \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45 (Almost dominated convergence)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{f_1,f_2,\\ldots: X \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions that converge pointwise ")#mi("{\\mu}")#text("-almost everywhere to a measurable limit ")#mi("{f: X \\rightarrow {\\bf C}}")#text(". Suppose that there is an unsigned absolutely integrable functions ")#mi("{G, g_1, g_2, \\ldots: X \\rightarrow [0,+\\infty]}")#text(" such that the ")#tao-math("{\\left|f_n\\right|}", block: false)#text(" are pointwise ")#mi("{\\mu}")#text("-almost everywhere bounded by ")#mi("{G + g_n}")#text(", and that ")#mi("{\\int_X g_n\\ d\\mu \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu = \\int_X f\\ d\\mu.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46 (Defect version of Fatou’s lemma)")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, and let ")#mi("{f_1,f_2,\\ldots: X \\rightarrow [0,+\\infty]}")#text(" be a sequence of unsigned absolutely integrable functions that converges pointwise to an absolutely integrable limit ")#mi("{f}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\int_X f_n\\ d\\mu - \\int_X f\\ d\\mu - \\left\\|f-f_n\\right\\|_{L^1(\\mu)} \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" Apply the dominated convergence theorem to ")#mi("{\\min(f_n,f)}")#text(".) Informally, this tells us that the gap between the left and right hand sides of Fatou’s lemma can be measured by the quantity ")#tao-math("{\\left\\|f-f_n\\right\\|_{L^1(\\mu)}}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47")]#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, and let ")#mi("{g: X \\rightarrow [0,+\\infty]}")#text(" be measurable. Show that the function ")#mi("{\\mu_g: {\\mathcal B} \\rightarrow [0,+\\infty]}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\mu_g(E) := \\int_X 1_E g\\ d\\mu = \\int_E g\\ d\\mu")]]

#text("is a measure. (We will study such measures in greater detail in ")#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/")[#text("245B")]#text(".)")
]

#text("The monotone convergence theorem is, in some sense, a defining property of the unsigned integral, as the following exercise illustrates.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 48 (Characterisation of the unsigned integral)")]#text(" Let ")#mi("{(X,{\\mathcal B})}")#text(" be a measurable space. ")#mi("{I: f \\mapsto I(f)}")#text(" be a map from the space ")#mi("{{\\mathcal U}(X,{\\mathcal B})}")#text(" of unsigned measurable functions ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" to ")#mi("{[0,+\\infty]}")#text(" that obeys the following axioms:")

#enum(start: 1, 
[#text("(Homogeneity) For every ")#mi("{f \\in {\\mathcal U}(X,{\\mathcal B})}")#text(" and ")#mi("{c \\in [0,+\\infty]}")#text(", one has ")#mi("{I(cf) = cI(f)}")#text(".")],
[#text("(Finite additivity) For every ")#mi("{f, g \\in {\\mathcal U}(X,{\\mathcal B})}")#text(", one has ")#mi("{I(f+g)=I(f)+I(g)}")#text(".")],
[#text("(Monotone convergence) If ")#mi("{0 \\leq f_1 \\leq f_2 \\leq \\ldots}")#text(" are a non-decreasing sequence of unsigned measurable functions, then ")#mi("{I( \\lim_{n \\rightarrow \\infty} f_n ) = \\lim_{n \\rightarrow \\infty} I(f_n)}")#text(".")]
)

#text("Then there exists a unique measure ")#mi("{\\mu}")#text(" on ")#mi("{(X,{\\mathcal B})}")#text(" such that ")#mi("{I(f) = \\int_X f\\ d\\mu}")#text(" for all ")#mi("{f \\in {\\mathcal U}(X,{\\mathcal B})}")#text(". Furthermore, ")#mi("{\\mu}")#text(" is given by the formula ")#mi("{\\mu(E) := I(1_E)}")#text(" for all ")#mi("{{\\mathcal B}}")#text("-measurable sets ")#mi("{E}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49")]#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a finite measure space (i.e. ")#mi("{\\mu(X) < \\infty}")#text("), and let ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" be a bounded function. Suppose that ")#mi("{\\mu}")#text(" is ")#link("http://en.wikipedia.org/wiki/Complete_measure")[#text("complete")]#text(", which means that every sub-null set is a null set. Suppose that the upper integral")

#align(center)[#tao-fit-display[#mitex("\\overline{\\int}_X f\\ d\\mu := \\inf_{g \\geq f; g \\text{ simple}} \\int_X g\\ d\\mu")]]

#text("and lower integral")

#align(center)[#tao-fit-display[#mitex("\\underline{\\int}_X f\\ d\\mu := \\sup_{h \\leq f; h \\text{ simple}} \\int_X h\\ d\\mu")]]

#text("agree. Show that ")#mi("{f}")#text(" is measurable. (This is a converse to Exercise 11 of ")#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")[#text("Notes 2")]#text(".) Here the simple functions are understood to be signed rather than unsigned.")
]

#text("We will continue to see the monotone convergence theorem, Fatou’s lemma, and the dominated convergence theorem make an appearance throughout the rest of this course sequence.")

#heading(level: 1)[#strong[#text(" — 6. Probability spaces (optional) — ")]]

#text("We now pause to isolate a special type of measure space, namely an ")#link("http://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text(". As the name suggests, these spaces are of fundamental importance in the foundations of ")#link("http://en.wikipedia.org/wiki/Probability_theory")[#text("probability")]#text(", although it should be emphasised that probability theory should ")#emph[#text("not")]#text(" be viewed as the study of probability spaces, as these are merely models for the true objects of study of that theory, namely the behaviour of random events and random variables. (See ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("this post")]#text(" for further discussion of this point.) This course will not be focused on applications to probability theory, but other courses (such as the Math 275 sequence at UCLA) will certainly be taking several results from measure theory (e.g. the Borel-Cantelli lemma, Exercise ")#link(<tao-1e0bbd6c686ba050b8eb>)[#text("42")]#text(") and transferring them to a probabilistic context in order to apply them to problems of interest in probability theory.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 18 (Probability space)")]#text(" A ")#emph[#text("probability space")]#text(" is a measure space ")#mi("{(\\Omega, {\\mathcal F}, {\\bf P})}")#text(" of total measure ")#mi("{1}")#text(": ")#mi("{{\\bf P}(\\Omega) = 1}")#text(". The measure ")#mi("{{\\bf P}}")#text(" is known as a ")#emph[#text("probability measure")]#text(".")
]

#text("Note the change of notation: whereas measure spaces are traditionally denoted by symbols such as ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(", probability spaces are traditionally denoted by symbols such as ")#mi("{(\\Omega, {\\mathcal F}, {\\bf P})}")#text(". Of course, such notational changes have no impact on the underlying mathematical formalism, but they reflect the different cultures of measure theory and probability theory. In particular, the various components ")#mi("{\\Omega}")#text(", ")#mi("{{\\mathcal F}}")#text(", ")#mi("{{\\bf P}}")#text(" carry the following interpretations in probability theory, that are absent in other applications of measure theory:")

#list(
[#text("The space ")#mi("{\\Omega}")#text(" is known as the ")#link("http://en.wikipedia.org/wiki/Sample_space")[#text("sample space")]#text(", and is interpreted as the set of all possible ")#emph[#text("states")]#text(" ")#mi("{\\omega \\in \\Omega}")#text(" that a random system could be in.")],
[#text("The ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal F}}")#text(" is known as the ")#emph[#text("event space")]#text(", and is interpreted as the set of all possible ")#link("http://en.wikipedia.org/wiki/Event_(probability_theory)")[#text("events")]#text(" ")#mi("{E \\in {\\mathcal F}}")#text(" that one can measure.")],
[#text("The measure ")#mi("{{\\bf P}(E)}")#text(" of an event is known as the ")#emph[#text("probability")]#text(" of that event.")]
)

#text("The various axioms of a probability space then formalise the ")#link("http://en.wikipedia.org/wiki/Probability_axioms")[#text("foundational axioms of probability")]#text(", as set out by Kolmogorov.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 20 (Normalised measure)")]#text(" Given any measure space ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" with ")#mi("{0 < \\mu(X) < +\\infty}")#text(", the space ")#mi("{(X, {\\mathcal B}, \\frac{1}{\\mu(X)} \\mu)}")#text(" is a probability space. For instance, if ")#mi("{\\Omega}")#text(" is a non-empty finite set with the discrete ")#mi("{\\sigma}")#text("-algebra ")#mi("{2^\\Omega}")#text(" and the counting measure ")#mi("{\\#}")#text(", then the ")#emph[#text("normalised counting measure")]#text(" ")#mi("{\\frac{1}{\\# \\Omega} \\#}")#text(" is a probability measure (known as the ")#link("http://en.wikipedia.org/wiki/Uniform_distribution_(discrete)")[#text("(discrete) uniform probability measure")]#text(" on ")#mi("{\\Omega}")#text("), and ")#mi("{(\\Omega, 2^\\Omega, \\frac{1}{\\# \\Omega} \\#)}")#text(" is a probability space. In probability theory, this probability spaces models the act of drawing an element of the discrete set ")#mi("{\\Omega}")#text(" uniformly at random.")

#text("Similarly, if ")#mi("{\\Omega \\subset {\\bf R}^d}")#text(" is a Lebesgue measurable set of positive finite Lebesgue measure, ")#mi("{0 < m(\\Omega) < \\infty}")#text(", then ")#mi("{(\\Omega, {\\mathcal L}[{\\bf R}^d]\\downharpoonright_\\Omega, \\frac{1}{m(\\Omega)} m\\downharpoonright_\\Omega)}")#text(" is a probability space. The probability measure ")#mi("{\\frac{1}{m(\\Omega)} m\\downharpoonright_\\Omega}")#text(" is known as the ")#link("http://en.wikipedia.org/wiki/Uniform_distribution_(continuous)")[#text("(continuous) uniform probability measure")]#text(" on ")#mi("{\\Omega}")#text(". In probability theory, this probability spaces models the act of drawing an element of the continuous set ")#mi("{\\Omega}")#text(" uniformly at random.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 21 (Discrete and continuous probability measures)")]#text(" If ")#mi("{\\Omega}")#text(" is a (possibly infinite) non-empty set with the discrete ")#mi("{\\sigma}")#text("-algebra ")#mi("{2^\\Omega}")#text(", and if ")#mi("{(p_\\omega)_{\\omega \\in \\Omega}}")#text(" are a collection of real numbers in ")#mi("{[0,1]}")#text(" with ")#mi("{\\sum_{\\omega \\in \\Omega} p_\\omega = 1}")#text(", then the probability measure ")#mi("{{\\bf P}}")#text(" defined by ")#mi("{{\\bf P} := \\sum_{\\omega \\in \\Omega} p_\\omega \\delta_\\omega}")#text(", or in other words")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) := \\sum_{\\omega \\in E} p_\\omega,")]]

#text("is indeed a probability measure, and ")#mi("{(\\Omega, 2^\\Omega, {\\bf P})}")#text(" is a probability space. The function ")#mi("{\\omega \\mapsto p_\\omega}")#text(" is known as the ")#link("http://en.wikipedia.org/wiki/Discrete_probability_distribution")[#text("(discrete) probability distribution")]#text(" of the state variable ")#mi("{\\omega}")#text(".")

#text("Similarly, if ")#mi("{\\Omega}")#text(" is a Lebesgue measurable subset of ")#mi("{{\\bf R}^d}")#text(" of positive (and possibly infinite) measure, and ")#mi("{f: \\Omega \\rightarrow [0,+\\infty]}")#text(" is a Lebesgue measurable function on ")#mi("{\\Omega}")#text(" (where of course we restrict the Lebesgue measure space on ")#mi("{{\\bf R}^d}")#text(" to ")#mi("{\\Omega}")#text(" in the usual fashion) with ")#mi("{\\int_\\Omega f(x)\\ dx = 1}")#text(", then ")#mi("{(\\Omega, {\\mathcal L}[{\\bf R}^d]\\downharpoonright_\\Omega, {\\bf P})}")#text(" is a probability space, where ")#mi("{{\\bf P} := m_f}")#text(" is the measure")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E) := \\int_\\Omega 1_E(x) f(x)\\ dx = \\int_E f(x)\\ dx.")]]

#text("The function ")#mi("{f}")#text(" is known as the ")#link("http://en.wikipedia.org/wiki/Continuous_probability_distribution")[#text("(continuous) probability density")]#text(" of the state variable ")#mi("{\\omega}")#text(". (This density is not quite unique, since one can modify it on a set of probability zero, but it is well-defined up to this ambiguity. We will return to this point in ")#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/")[#text("245B")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50 (No translation-invariant random integer)")]#text(" Show that there is no probability measure ")#mi("{{\\bf P}}")#text(" on the integers ")#mi("{{\\bf Z}}")#text(" with the discrete ")#mi("{\\sigma}")#text("-algebra ")#mi("{2^{\\bf Z}}")#text(" with the translation-invariance property ")#mi("{{\\bf P}(E+n)={\\bf P}(E)}")#text(" for every event ")#mi("{E \\in 2^{\\bf Z}}")#text(" and every integer ")#mi("{n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 51 (No translation-invariant random real)")]#text(" Show that there is no probability measure ")#mi("{{\\bf P}}")#text(" on the reals ")#mi("{{\\bf R}}")#text(" with the Lebesgue ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal L}[{\\bf R}]}")#text(" with the translation-invariance property ")#mi("{{\\bf P}(E+x)={\\bf P}(E)}")#text(" for every event ")#mi("{E \\in {\\mathcal L}[{\\bf R}]}")#text(" and every real ")#mi("{x}")#text(".")
]

#text("Many concepts in measure theory are of importance in probability theory, although the terminology is changed to reflect the different perspective on the subject. For instance, the notion of a property holding almost everywhere is now replaced with that of a property holding ")#link("http://en.wikipedia.org/wiki/Almost_surely")[#text("almost surely")]#text(". A measurable function is now referred to as a ")#link("http://en.wikipedia.org/wiki/Random_variable")[#text("random variable")]#text(" and is often denoted by symbols such as ")#mi("{X}")#text(", and the integral of that function on the probability space (if the random variable is unsigned or absolutely convergent) is known as the ")#link("http://en.wikipedia.org/wiki/Expected_value")[#text("expectation")]#text(" of that random variable, and is denoted ")#mi("{{\\bf E}(X)}")#text(". Thus, for instance, the Borel-Cantelli lemma (Exercise ")#link(<tao-1e0bbd6c686ba050b8eb>)[#text("42")]#text(") now reads as follows: given any sequence ")#mi("{E_1,E_2,E_3,\\ldots}")#text(" of events such that ")#mi("{\\sum_{n=1}^\\infty {\\bf P}(E_n) < \\infty}")#text(", it is almost surely true that at most finitely many of these events hold.")

#text("In later notes, when we develop the machinery of product measures and other tools to construct measures, we will see some more interesting examples of probability spaces, which would correspond in probability theory to random processes that are generated by an infinite number of independent random sources.")

#text("The following exercise will be moved to a more suitable location in the published version of the notes, but is here currently so as not to disrupt the exercise numbering.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 52 (Approximation by an algebra)")]#text(" Let ")#mi("{{\\mathcal A}}")#text(" be a Boolean algebra on ")#mi("{X}")#text(", and let ")#mi("{\\mu}")#text(" be a measure on ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(".")

#enum(start: 1, 
[#text("If ")#mi("{\\mu(X) < \\infty}")#text(", show that for every ")#mi("{E \\in \\langle {\\mathcal A} \\rangle}")#text(" and ")#mi("{\\epsilon > 0}")#text(" there exists ")#mi("{F \\in {\\mathcal A}}")#text(" such that ")#mi("{\\mu( E \\Delta F ) < \\epsilon}")#text(".")],
[#text("More generally, if ")#mi("{X = \\bigcup_{n=1}^\\infty A_n}")#text(" for some ")#mi("{A_1, A_2, \\ldots \\in {\\mathcal A}}")#text(" with ")#mi("{\\mu(A_n) < \\infty}")#text(" for all ")#mi("{n}")#text(", ")#mi("{E \\in \\langle {\\mathcal A} \\rangle}")#text(" has finite measure, and ")#mi("{\\epsilon > 0}")#text(", show that there exists ")#mi("{F \\in {\\mathcal A}}")#text(" such that ")#mi("{\\mu( E \\Delta F ) < \\epsilon}")#text(".")]
)
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (161)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-239631")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2013")])]

#text("A remark to Theorem 17 (Dominated convergence theorem):")

#text("I proved the dominated convergence theorem using Egorove’s theorem together with Exercise 40 (Uniform convergence on a finite measure space) when I was walking outside home.")

#text("I don’t use Fatou’s lemma…..BTW,I think Fatou’s lemma is a naive and easy stuff,so I will be comfortable that I don’t use this lemma….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-239708")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2013")])]

#text("Dear Prof.Tao,")

#text("In the proof of Theorem 17 (Dominated convergence theorem),I think the last inequality")

#mi("\\displaystyle \\limsup_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu \\leq \\int_X f\\ d\\mu.")

#text("should be")

#mi("\\displaystyle \\liminf_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu \\leq \\int_X f\\ d\\mu.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-239710")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2013")])]

#text("I am wrong again……Maybe next time I shouldn’t put any comment until I think 10 times.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-239755")[#strong[#text("A proof of Fatou’s lemma « Asymptote")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2013")]

#text("[…] In this post I give a proof of Fatou’s lemma which is the Corollary 16 of Terence Tao’s post 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-239975")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")])]

#text("Dear Prof.Tao,")

#text("Could you please give me some hints on how the condition “Suppose that ")#mi("\\mu")#text(" is complete, which means that every sub-null set is a null set.” is used in Exercise 49?")

#text("I have a bit doubt on my ability to give a correct proof because I proved Exercise 49 without using this condition……")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-239981")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")])]

#text("If ")#mi("f")#text(" is an indicator function of a sub-null set, what are the upper and lower integrals of ")#mi("f")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-240040")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")])]

#text("If ")#mi("f")#text(" is an indicator function of an unmeasurable sub-null set,it seems that the upper and lower integrals of ")#mi("f")#text(" does not exist.")

#text("Dear Prof.Tao,")

#text("Thank you for your hint.Now I understand that I made a skip in my proof,I thought that according to Littlewood’s principle,I can ignore the subnull set and null set but actually I should not because if I ignore the unmeasurable subnull set,then I will get an unmeasurable monster.")

#text("The reason that I proved this exercise wrongly is that I used wrong intuition.I carry my intuition in Lebesgue measure into this general measure space setting,which result in my fault.More precisely,it seems that Littlewood’s three principle should only work in complete measure space,otherwise I will get a monster……")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c50e5f1f8109cc87a6a3394a68e11c763b6092dcb32a39c8ede2899c1d295ac7-43b5289b51f93c075c052b51197fc2a7f761321fdc8daaea8bbb8d7f7c9c8bdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunting")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-470301")[#strong[#text("Sunting")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2016")])]

#text("i think the important aspect is that if X is not complete, then if fn(measurable) converges to f, a.e., we could not say that f is measurable. if it is complete, then f is measurable.if f is an indicator function of subnull set, then upper and lower integrals both are zero, so they agree, but it seems that in this case f is not measurable.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-411514")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2014")])]

#text("Are Borel sigma algebra ")#mi("{\\mathcal B}[{\\bf C}]")#text(" and ")#mi("{\\mathcal B}[{\\bf R}^2]")#text(" the same? In Folland’s Real Analysis, the author uses ")#mi("{\\mathcal B}[{\\bf C}]={\\mathcal B}[{\\bf R}^2]")#text(" to show that a complex function is measurable iff both the real and imaginary parts are measurable.")

#mi("{\\bf C}")#text(" and ")#mi("{\\bf R}^2")#text(" have different structures. Why one can identify the Borel sigma algebras on them?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-411528")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2014")])]

#mi("{\\bf C}")#text(" and ")#mi("{\\bf R}^2")#text(" have the same topology (after identifying the sets together in the usual fashion), and hence the same Borel sigma-algebra.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-411542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2014")])]

#text("When you say “identifying”, do you mean “homeomorphism”? In ")#mi("{\\bf C}")#text(" one has multiplication for ")#mi("(x+iy)(u+iw)")#text(". But in ")#mi("{\\bf R}^2")#text(", one only has inner product ")#mi("\\langle (x,y),(u.w)\\rangle")#text(", which is not the same as the previous one. Is it because one discards such structures and considers “topology” only that one can “identify” these two Borel sigma algebra. As I understand from your comment, should one view “=” in the identity above as “homromorphism” (or some sort of “isomorphism”)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-411563")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2014")])]

#text("The standard identification ")#mi("x+iy \\equiv (x,y)")#text(" between ")#mi("{\\bf C}")#text(" and ")#mi("{\\bf R}^2")#text(" is an isomorphism of sets (otherwise known as a bijection), and is furthermore an isomorphism of topological spaces (otherwise known as a homeomorphism). As you noted, though, it is not an isomorphism of rings or of inner product spaces. (It is an isomorphism of (additive) groups, but this is not particularly relevant for the current discussion.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-417062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2014")])]

#text("I don’t follow the “without loss of generality” part of the proof of MCT. Suppose ")#mi("g")#text(" is not finite every where, say, ")#mi("c_1=\\infty")#text(" and ")#mi("A_i")#text(" is not of measure zero. How to go on in this situation? How does “vertical truncation” help here (I don’t know what is “truncated” here…)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-417070")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2014")])]

#text("If g attains infinite values, replace g with ")#mi("\\min(g,N)")#text(" (this is the “vertical truncation” of g at height N) and then let ")#mi("N \\to \\infty")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-456048")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2015")])]

#text("Do you have any additional hint on how to prove the dominated convergence theorem for sets? Following the given hint, one takes")#linebreak()#text(" ")#mi("F_N := \\bigcup_{n \\geq N} E_n \\Delta E")#linebreak()#text(" and by monotone convergence for sets")#linebreak()#text(" ")#mi("0 = \\mu(\\bigcap_{N \\geq 1} F_N) = \\lim_N \\mu(F_N).")#linebreak()#text(" How can I prove that ")#mi("\\lim_N \\mu(F_N) = \\mu(E) - \\lim_n \\mu(E_n)")#text(" ?")

#text("Thank you!")

#emph[#text("[You don’t need to prove ")#mi("\\lim_N \\mu(F_N) = \\mu(E) - \\lim_n \\mu(E_n)")#text(" to finish the problem. One just needs an appropriate inequality relating ")#mi("\\mu(E)")#text(" with ")#mi("\\mu(E_N)")#text(" and ")#mi("\\mu(F_N)")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 0: Foundations of probability theory | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-459863")[#strong[#text("275A, Notes 0: Foundations of probability theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#text("[…] begin with the notion of a measurable space. (See also this previous blog post, which covers similar material from the perspective of a real analysis graduate class rather than a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-460042")[#strong[#text("TECNOLOGÍA » 275A, Notes 0: Foundations of probability theory")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2015")]

#text("[…] begin with the notion of a measurable space. (See also this previous blog post, which covers similar material from the perspective of a real analysis graduate class rather than a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 1: Integration and expectation | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-460067")[#strong[#text("275A, Notes 1: Integration and expectation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("[…] of the details of this construction will be left to exercises. See also Chapter 1 of Durrett, or these previous blog notes, for a more detailed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-463810")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("In the proof of MCT, why we need the ")#mi("\\epsilon")#text(" there? What could fail if we just define")

#text("the sets")

#mi("\\displaystyle  A_{i,n} :=\\{ x \\in A_i: f_n(x) > c_i \\}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-463811")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("I meant")

#mi("\\displaystyle  A_{i,n} :=\\{ x \\in A_i: f_n(x) \\geq c_i \\}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-463812")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("In this case, the ")#mi("A_{i,n}")#text(" need not increase to ")#mi("A_i")#text(". (For instance, one could have ")#mi("f_n(x) = (1-1/n) c_i")#text(" on ")#mi("A_i")#text(".)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-463855")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2015")])]

#emph[#text("The reader is encouraged to see why, in each of the moving bump examples, no such dominating function exists, without appealing to the above theorem (DCT)")]

#text("To dominate")

#mi("f_n=1_{[n,n+1]}")

#mi("g")#text(" would be such that ")#mi("g(x)\\geq 1")#text(" for ")#mi("x\\geq 0")#text(" almost everywhere, which can not be integrable. Do you have a hint why there is no integrable dominant function for")

#mi("f_n=n1_{[1/n,2/n]}?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-463867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2015")])]

#text("Graph the functions ")#mi("f_n")#text(", and compare against the graph of ")#mi("1/x")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-471170")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2016")])]

#text("Small typo in Exercise 31. ")#mi("f: {\\mathcal B} \\rightarrow [0,+\\infty]")#text(" should be ")#mi("f: X \\rightarrow [0,+\\infty]")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-474526")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2016")])]

#text("Sorry for the simple question, but can you give a hint for Exercise 34 part 10 (vertical truncation)? I feel like none of the old tricks from Lebesgue integration work here, and we don’t even know if the union of the ")#mi("E_n")#text(" have finite measure. Every time I try to write out a proof, I end up trying to switch limits around, which is what I’m trying to prove I can do.")

#emph[#text("[First try the case when ")#mi("f")#text(" is a simple function, or even an indicator function. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-474573")[#strong[#text("Coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")])]

#text("Thanks Terry. Got it now. Have a great Thanksgiving!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-479076")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2017")])]

#text("Concerning exercise 18, part 1: Is this statement true? How can one prove that if E has measurable projection, then its complement does too? (since projection does not commute with taking complements)")

#emph[#text("[Exercise 18 concerns slices, not projections. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A: Problem solving strategies | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-511380")[#strong[#text("245A: Problem solving strategies | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("[…] the generating sets; in some cases one can also take balls, cubes, or rectangles); see Remark 4 of Notes 3. One can relax the set of properties required, for instance countable intersections is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-568464")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2020")])]

#text("I want to ask a question on Exercise 26 about completion. Do we need to just to prove the existence first then find the structure of the completed space? Or first construct one then show it satisfies all the conditions?")

#emph[#text("[Either approach can work, although the latter is easier in this case -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-570015")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2020")])]

#text("Thanks Prof. Tao")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-570018")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2020")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I tried hard but cannot figure out the complete proof of the Exercise 36 about the change of variables formula about the pushforward measure without the monotone convergence theorem. The question (i) is simple and I made it.For (ii) I only know how to show the conclusion holds for simple functions. But for general unsigned functions I failed to work it out. Can you give a proof or offer just some hints for the general case without the monotone convergence theorem?")#linebreak()#text(" Thank you very much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-570045")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2020")])]

#text("Yes, I’m very eager to know the proof of this problem without the monotone convergence theorem to maintain the fluency of the book.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08adc5972483d4adc2cc7bfe571113236d3cc4079af95e38645b4040400ac321-1b70c8f1da8321986c81e968c8cfe3cd0f53927847a3c3d11d45c1686cd3d8e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo Sera")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-570459")[#strong[#text("Leo Sera")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2020")])]

#text("Hi Ruijun. Looks like someone asked the same question you did here and it already has an answer. ")#link("https://math.stackexchange.com/questions/3738431/proof-of-the-change-of-variables-formula-without-using-the-monotone-convergence/3738505#3738505")[#text("https://math.stackexchange.com/questions/3738431/proof-of-the-change-of-variables-formula-without-using-the-monotone-convergence/3738505#3738505")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-570477")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2020")])]

#text("(Laughter) The question there is also asked by me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-570478")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2020")])]

#text("Maybe there is an answer and I will check it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-570506")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2020")])]

#text("His answer is wrong, I think.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08adc5972483d4adc2cc7bfe571113236d3cc4079af95e38645b4040400ac321-1b70c8f1da8321986c81e968c8cfe3cd0f53927847a3c3d11d45c1686cd3d8e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo Sera")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-570652")[#strong[#text("Leo Sera")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2020")])]

#text("Oh! I just read it I didn’t see the error but looks like it has a couple of edits. Maybe the error you caught has been fixed.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-615278")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("If one wants to develop an integration theory for functions defined on manifolds, does one need to (eventually) use coordinate charts? Or does the nature of “abstract” measure spaces allow one to define Lebesgue integrals in an intrinsic way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-615356")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("There is no canonical measure that one can intrinsically assign to an smooth abstract manifold (pushing forward Lebesgue measure from a coordinate chart is a chart-dependent construction). But if one has an additional structure, such as a Riemannian metric, a symplectic form, Kahler measure, a transitive group action by an amenable group, or an immersion into Euclidean space, one can often create such a canonical measure (Riemannian volume measure, Liouville measure, Haar measure, induced Lebesgue measure, etc.).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-641527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("In the case of the counting measure, one has in Exercise 38 the integral is actually a sum. Does one has a simple formula for ")#mi("\\int_A f\\;d\\mu")#text(" when ")#mi("\\mu")#text(" is the Dirac delta measure, say ")#mi("\\delta_x")#text(" for some fixed ")#mi("x\\in X")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-641538")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("Yes, this is ")#mi("f(x) 1_A(x)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-643923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2022")])]

#text("Dear Professor Tao:")#linebreak()#text(" For exercise 8, is it ideal to prove it by showing that the Boolean algebra generated by ")#mi("n")#text(" sets has most ")#mi("2^n")#text(" atoms, first showing by induction that ")#mi("n")#text(" sets partition the space into at most ")#mi("2^n")#text(" disjoint regions?")

#emph[#text("[Sure, that works – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bf7c324b72742fba31c7da10d6dd43613c5d0f6a5d40944f1b49d96e357f856-389bbf8210dadf7964f10a329b58a83227f74e3d3226e948b8c737f1df9544c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YiLi")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-644579")[#strong[#text("YiLi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2022")])]

#text("Dear Professor Tao: For exercise 35 change of variable formula, I was confused with the version of change of variable formula in the context of calculus, where needs the transformation being at least $C^1$ diffeomorphism? why only needs morphism not isomorphism here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-644996")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2022")])]

#text("The measure-theory perspective allows one to split the change of variables formula into two parts and clarifies exactly where a hypothesis of diffeomorphism is helpful. The first, which is purely measure-theoretic and requires no assumption of diffeomorphism, is Exercise 35 here. The second, which is not part of this notes, is that the pushforward of Lebesgue measure ")#mi("dx")#text(" under a ")#mi("C^1")#text(" diffeomorphism ")#mi("\\phi: {\\bf R}^n \\to {\\bf R}^n")#text(" is given by ")#tao-math("\\left|\\mathrm{det}( D\\phi )\\right| \\circ \\phi^{-1}\\ dx", block: false)#text(". Thus one can push forward a measure (or pull back an integral) by arbitrary measurable maps, but one is not guaranteed to have a nice formula for this change of variables unless one has a diffeomorphism structure (or other nice property of the map).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bf7c324b72742fba31c7da10d6dd43613c5d0f6a5d40944f1b49d96e357f856-389bbf8210dadf7964f10a329b58a83227f74e3d3226e948b8c737f1df9544c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YiLi")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-645015")[#strong[#text("YiLi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2022")])]

#text("I got it thank you, the pull back measure has some set theory beneficial, for example in the construction of the measure preserving map in the Ergodic Theory.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-673328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For exercise $23$, What would be an example of such a sequence of sets if the hypothesis that ${\\mu(E_n)<\\infty}$ for at least one $n$ is dropped? I find it hard to utilize the middle third Cantor set example in this case.")

#emph[#text("[Hint: experiment with half-infinite intervals in the real line. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-673758")[#strong[#text("sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For part (2) of exercise 28(in the textbook), I think one first needs to show that ")#mi("\\mathcal{A}\\cap A_n")#text(" is an algebra on ")#mi("A_n")#text(" for each n, and then ")#mi("\\langle \\mathcal{A} \\cap A_n \\rangle =\\langle \\mathcal{A}\\rangle \\cap A_n")#text(", in order to use part (1) on the finite measure space ")#mi("(A_n, \\mathcal{A}\\cap A_n, \\mu)")#text(". (Here the intersection of an algebra with a set is the collection of the intersection of that set with the members of the algebra). Is this the way the solution is intended? What else can one approaches the problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-674485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For exercise 37, can we prove it by simply replace ")#mi("E")#text(" with ")#mi("T^(-1)(E)")#text(" in exercise 21 of note 1?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-674945")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For ")#mi("(5)")#text(" of Exercise $ latex 39$, it looks like the fact that the integral of ")#mi("f")#text(" being insensitive to refinement follows from the same property of the real-valued ")#mi("f")#text(", which follows from that of the unsigned ")#mi("f")#text(", which then follows from that of the simple $f$. Why then do we need to approximate $f$ as the hint suggested?")

#emph[#text("[This also works – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-685378")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2024")])]

#text("Dear professor Tao,")#linebreak()#text("in excercise 28, we are working on the borel sigma algebra which is not complete. don’t we need complete measure assumption to conclude f is also measurable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-685428")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2024")])]

#text("No, completeness is not required in this exercise. (As a warmup, you could consider what is happening in the case when ")#mi("{\\mathcal B}")#text(" is the trivial sigma algebra, which will almost certainly not be complete.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687128")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2025")])]

#text("Q1. What are measure which respect monotone convergence theorem?")

#text("Q2. Characterize all probability measures ")#mi("\\mu")#text(" such that the set ")#tao-math("\\{f \\in L^2(\\mu): \\left|f\\right|_\\infty \\leq 1\\}", block: false)#text(" is compact in ")#mi("L^2(\\mu)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687468")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2025")])]

#text("In ℝᵈ, one encounters two different ‘completions’: one is the extension from Riemann to Lebesgue integration (which enlarges the class of integrable functions and provides stronger convergence properties), and the other is the completion of the Borel σ‐algebra with respect to Lebesgue measure (thereby including all subsets of null sets to form the Lebesgue σ‐algebra). The first completion is well known for its utility in analysis, but could you explain when and why the second completion—the passage from Borel to Lebesgue measurability—is particularly useful or essential? What are the key applications or theoretical benefits of using the full Lebesgue σ‐algebra instead of just the Borel σ‐algebra?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687469")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2025")])]

#text("Completeness has some minor technical advantages – it allows one to work in an almost everywhere sense without having to worry about whether the various functions or sets constructed are Borel measurable – but it makes little difference in practice, since up to null sets the Lebesgue sigma algebra and the Borel sigma algebra are equivalent. In more abstract settings it is actually more beneficial to work in the measure algebra of either the Borel or Lebesgue sigma algebra quotiented by null sets, in which case there is no distinction between the two whatsoever. (Actually, in non-metrizable settings, the Baire sigma algebra has some minor advantages over the Borel sigma algebra, but that is another story.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687677")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2025")])]

#text("Dear professor Tao:")

#text("For Exercise 26, to get countable additivity of ")#mi("\\overline{\\mu}")#text(", one needs to relate the disjoint sequence of sets in the refined algebra to the corresponding disjoint sequence in the original algebra, can you hint on how to do that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687679")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2025")])]

#text("Try proving countable subadditivity instead, as it is easier, and is good enough (once one has finite additivity).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687761")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2025")])]

#text("Dear professor Tao:")

#text("To clarify a few points about Definition 10: Isn’t ")#mi("\\mathcal{B}")#text(" a sub-algebra of ")#mi("\\mathcal{B}^{\\prime}")#text(" instead, according to the definition? Also, the restriction of a measure is defined on the restriction of an algebra to a measurable subset before, are we defining the restriction of a measure to a smaller algebra in a similar fashion here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687765")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2025")])]

#text("I believe the definition is correct as stated: ")#mi("{\\mathcal B}^{\\prime}")#text(" is a subalgebra of ")#mi("{\\mathcal B}")#text(". Any measure ")#mi("\\mu : {\\mathcal B} \\to [0,+\\infty]")#text(" automatically restricts to a measure ")#mi("\\mu : {\\mathcal B}^{\\prime} \\to [0,+\\infty]")#text(" on a sub-algebra ")#mi("{\\mathcal B}^{\\prime}")#text(" (if one was pedantic one could call this restricted measure a different name such as ")#mi("\\mu \\downharpoonright_{{\\mathcal B}^{\\prime}}")#text(", but there is usually little harm in using the same name for both measures.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2025")])]

#text("I think he means there are some conflicts between def 10 and def 1.")

#text("In def 1, you mentioned ")#mi("\\mathcal{B}^{\\prime}")#text(" is a sub-algebra of ")#mi("\\mathcal{B}")#text(" iff ")#mi("\\mathcal{B} \\subset \\mathcal{B}^{\\prime}")#text(".")

#text("However, I believe this definition is inconsistent with the common definition of sub-sigma-algebra.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687773")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2025")])]

#text("Ah, thanks for clearing that up. That was a typo in Definition 1, now corrected.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-687770")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2025")])]

#text("Dear professor Tao:")#linebreak()#text(" Definition 10 implies that the sub-")#mi("\\sigma")#text("-algebra ")#mi("\\mathcal{B}^{\\prime}")#text(" is the coarser algebra that is contained in the finer algebra ")#mi("\\mathcal{B}")#text(" (hence it makes sense to talk about the “restriction” of ")#mi("\\mu")#text(" to ")#mi("\\mathcal{B}^{\\prime})")#text(". Yet from Definition 1, if ")#mi("\\mathcal{B}^{\\prime}")#text(" is a sub-algebra of ")#mi("\\mathcal{B}")#text(", then it is the other way round that ")#mi("\\mathcal{B} \\subset \\mathcal{B}^{\\prime}")#text(". Where did I get it wrong here?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688003")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("Dear professor Tao:")

#text("An insignificant typo in Exercise 38: “Exercise 13” should be “Example 13”.")

#emph[#text("[Corrected, thanks -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688005")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("Dear professor Tao:")

#text("Can you also give a little further explanation of the hint for part (5) of Exercise 39, on why it is the case that one inequality is obvious, and how should one proceeds when ")#mi("f")#text(" is bounded with finite measure support?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688011")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("What have you tried so far for this problem, and what observations have you made already?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688018")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("I can see that one way is to reduce all the way down to the simple functions, and the claim follows from insensitivity of the simple integral to refinement, as established earlier. I understand the hint to be given for the real-valued functions, but is yet to see how one direction follows directly from definition and the other from the bounded, finite support case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688028")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("Strictly speaking, the hint should be applied for the unsigned integral first, and then from there one can get the claim for the absolutely integrable integral.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688029")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("Dear professor Tao:")

#text("I believe it suffices to reduce to the unsigned case, and utilize the construction o")#mi("f_epsilon")#text(" in the proof of Theorem 12, as well as the horizontal and vertical truncation properties, am I on the right track?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688046")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2025")])]

#text("Dear professor Tao:")

#text("To clarify, are the ")#mi("g_n")#text(" in Exercise 45 assumed to be absolutely integrable as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688053")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2025")])]

#text("The ")#mi("g_n")#text(" are assumed to be non-negative and have ")#mi("\\int_X g_n\\ d\\mu \\to 0")#text(", so they will be absolutely integrable for sufficiently large ")#mi("n")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688049")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2025")])]

#text("Dear professor Tao:")

#text("Exercise 49 uses the notion of signed simple function, but in Definition 10 we are given only the definition of unsigned simple functions. Are they assumed to be defined similarly as in the previous note?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-688059")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2025")])]

#text("Dear professor Tao:")

#text("To get (2) from (1) in Exercise 52, I was trying to restrict the measure, but ran into some difficulties expressing the restriction of a generated algebra as a generated algebra on the restricted space, can you provide some hint on this?")

#emph[#text("[Remark 4 will establish this for you. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-689427")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Dr Tao,")

#text("Vector Space is V= (V, 0, +, ·), and Measure Space is X= (X, B, μ). The two definitions both can be written as the underlying set (V or X) with various additional structures. But what I want to say is the former one is a underlying set with some “external operations” while the Measure Space itself is a structure, and defined by “another strcuture” (σ-algebra B). I would like to ask that why these two definifions seem distinct and what makes it distinct?")

#text("Also, how to explain the difference in a manner a the “package-oriented” manner?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-689436")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2025")])]

#text("There is the minor technical distinction that the vector space operations are functions, while the sigma-algebra is a set, but these are just encodings and one could easily swap them around if desired (e.g., representing the additive structure on a vector space by considering sets of parallelograms, or representing the measurable structure by a “Measurable” predicate that maps subsets of the space to either “true” or “false”).")

#text("In Lean, the two concepts are introduced with rather similar type signatures, e.g.,")

#raw("variable (V:Type) [AddCommMonoid V] [Module ℝ V]")

#text("and")

#raw("variable (X:Type) [MeasureTheory.MeasureSpace X] ")

#text("(Lean’s Mathlib has decided to split the notion of a vector space into two subcomponents, namely that of an additive commutative monoid, and that of a module over a field, but this is a somewhat arbitrary design choice, and the syntax of Lean certainly allows the option to bundle these two concepts together.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-689442")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2025")])]

#text("Thanks for the explanation regarding the encoding in Lean.")

#text("If I may follow up on the ‘distinctness’ part: intuitively, Vector Spaces feel like objects defined by operations satisfying identities, whereas Measure Spaces feel more like Topological Spaces defined by selecting a family of valid subsets")

#text("The confusion might be why we define one by ‘what we can ")#emph[#text("do")]#text(" to elements’ and the other by ‘which subsets are ")#emph[#text("valid")]#text("‘. Is this structural divergence purely historical, or does it reflect a fundamental difference in how we should think about them?")

#text("Also, I wonder can these two structure both explained by the “package”–oriented view?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-689444")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2025")])]

#text("It’s possible that the notion you may be after is that of an ")#link("https://en.wikipedia.org/wiki/Algebraic_theory")[#text("algebraic theory")]#text(", of which vector spaces are a (two-sorted) instance of. Measure spaces can also be viewed algebraically via their dual interpretation as commutative von Neumann algebras; see also ")#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")[#text("my previous post")]#text(" on this topic. In the opposite direction, one could try to view vector spaces in terms of their ")#link("https://en.wikipedia.org/wiki/Matroid#Matroids_from_linear_algebra")[#text("independence matroid")]#text(", which has more of the “selecting a family of valid subsets” perspective, although this matroid does not capture the entirety of the vector space structure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-691552")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2026")])]

#text("Dear Prof. Tao,")

#text("I have problem with the proof of the Monotone Convergence Theorem: Why would you introduce the parameter 1-ε? Could you explain the strategies used here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-691575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2026")])]

#text("Dr Tao,")#linebreak()#text(" I know that a crucial skill in analysis is extracting techniques from proofs, but despite my efforts, I still feel I haven’t grasped the techniques for proving the Monotone Convergence Theorem. Could you possibly explain it a bit?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-691581")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2026")])]

#text("Dear Dr Tao,")

#text("The notion of “generation” reminds me of “spanning” in linear algebra. However, I fail to see what the motivation is to bring up the notion of generation in measure thoery. I would like to ask: why do we care about it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-691586")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2026")])]

#text("A very general and useful proof technique in any sort of algebra (including linear algebra, boolean algebra, and the theory of sigma-algebras (measurable spaces)), is to prove a claim regarding all elements of an algebra by first proving it on generators, and then checking that the claim is somehow closed under whatever operations are used to generate the rest of the algebra. For instance, to show that a linear functional vanishes on a vector space, it suffices to check it on a set of generators (a.k.a. a spanning set), since the linearity of the functional lets one propagate this vanishing to the rest of the vector space. The corresponding trick for sigma-algebras is formalized as Remark 4 in this set of notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692044")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2026")])]

#text("Dr. Tao, in the proof of monotone convergence theorem, the definition of the sets A_{i,n} is a bit lack of motivation. Could you specify this for us?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692048")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2026")])]

#text("I am ")#link("https://claude.ai/share/6f584c0c-c87e-4b32-aa9b-2daf75f58c11")[#text("outsourcing this question to an AI")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692049")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2026")])]

#text("When using the epsilon of room strategy, why do we choose to prove f_n(x) > (1 – ε) c_i instead of proving f_n(x) > c_i – ε?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2026")])]

#text("Using an additive error instead of a multiplicative error ends up causing problems if one of the sets ")#mi("A_j")#text(" has infinite measure, as one encounters the indefinite form ")#mi("\\infty - \\infty")#text(". (But if the underlying measure space was finite, then an additive error would work fine.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2026")])]

#text("Dear Professor Tao:")

#text("In Example 21, I am confused about this term p_ω–Is p_ω called discrete probability distribution or discrete probability distribution function? Also, it seems that the Wiki says p_ω is called probability mass function.")

#emph[#text("[Various permutations of these terminologies are in use, with the precise choice varying across subfields, or depending on the preferences of the author. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692073")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2026")])]

#text("Thanks for replying. Could you give some examples of which specific subfields tend to prefer one term over the others?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692083")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2026")])]

#text("I am ")#link("https://claude.ai/share/278aeffa-9899-4657-8cb9-af0098c1ab06")[#text("outsourcing this question to an AI")]#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692181")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2026")])]

#text("Dear Dr Tao,")

#text("I am confused by the proof of Theorem 12, because the theorem does not seem complicated — so why does its proof appear relatively difficult in comparison?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692191")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2026")])]

#text("Additivity of the Lebesgue integral is indeed a surprisingly subtle and deep fact to establish; much more so than additivity of the Riemann integral. One reason for this is that the Lebesgue integral is defined “horizontally” – by decomposing or approximating the function into indicator functions – rather than “vertically” (decomposing the domain into nice regions, such as rectangles). Pointwise operations such as addition are easier to understand with regards to vertical decompositions than horizontal ones.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2026")])]

#text("Dr Tao:")

#text("When the Euclidean space Rⁿ is replaced by a general space X, if X is infinite-dimensional, does X still have the notion of ")#emph[#text("Lebesgue measure")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-2/#comment-692767")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2026")])]

#text("I am ")#link("https://claude.ai/share/7049af99-61cc-4cbb-89a4-db59f401dbbc")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47258")[#strong[#text("Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")])]

#text("[…] und Jordansche Maß Lecture 1: Das Lebesguesche Maß. Lecture 2: Das Lebesguesche Integral Lecture 3: Maße und Maßräume […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")])]

#text("in example 19, integral of ")#mi("f_n")#text(" is not ")#mi("1.")#text(" ")#emph[#text("[Corrected, thanks – T.]")]

#text("Thanks for the great post")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")])]

#text("in exercise 47, domain of ")#mi("\\mu_g")#text(" is not ")#mi("X.")#text(" ")#emph[#text("[Corrected, thanks – T.]")]

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")])]

#text("in example 21, is ")#mi("f")#text(" probability distribution or probability density?")

#text("thanks,")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c053e31730b497d8214784b3c86199ae6b37222b8e691e9bd655f0d20ab7260d-588904bc5e771d60828be6c161ef722092bfe69ffb87f70f93f532d1dfcdfb43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laurens Gunnarsen")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47281")[#strong[#text("Laurens Gunnarsen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")])]

#text("Dear Professor Tao:")

#text("Although the material in this post has long been familiar to me, and although I have generally been able to apply it successfully in contexts that require a working understanding of its details, I confess that I have never been fully satisfied with it.")

#text("The sources of my dissatisfaction are various, but perhaps I might begin by asking why it is appropriate to formulate the theory so that it includes “measurable” sets whose measure is “infinity.” As a rule, we tend to regard a function as simply undefined wherever one would naively say that it becomes “infinite;” that is, we typically excise such “bad” points from the function’s domain. Yet this generally sound and widespread practice is abandoned in measure theory, for reasons that (despite much reflection) I have never been able fully to appreciate.")

#text("Of course I know perfectly well that allowing the domain of a measure to include sets at which it takes on infinite values is what is always done, and I know that the resulting development “works.” But I have never made my peace with this practice; to me it has always seemed, and still seems, profoundly unnatural.")

#text("Can you explain why I am wrong to be dissatisfied with this feature of the usual expositions of measure theory? Is there in fact a good reason for it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47282")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")])]

#text("As a general rule in analysis, infinities are only really troublesome in averages, sums, or integrals when they are combined with oscillation, due to the indeterminate nature of the form ")#mi("+\\infty - \\infty")#text(". But in the non-negative world, they are fairly safe: the laws of algebra for the finite non-negative numbers ")#mi("[0,+\\infty)")#text(" extend without much distortion to the extended non-negative numbers ")#mi("[0,+\\infty]")#text(". So, for the theory of unsigned measures and the unsigned integral, one can extend the theory to allow for infinite measures and infinite integrals without losing any of the main results of the subject (e.g. the monotone convergence theorem works just fine). As a bonus, the number system becomes compact, which manifests itself in a number of useful ways (e.g. infinite series of numbers in ")#mi("[0,+\\infty]")#text(" always have a limit in ")#mi("[0,+\\infty]")#text("; one no longer has to distinguish between convergent and divergent series).")

#text("Once one has oscillation, though, one usually has to minimise the exposure to infinities. For instance, absolutely integrable functions are only allowed to be infinite or undefined on a set of measure zero. Signed measures either have to have finite total variation, or to be infinite on one side only (e.g. infinite positive variation but finite negative variation). And so forth. This is probably the source of the impression you have received from other parts of mathematics that “infinities are dangerous”.")

#text("But note also that there are other places in mathematics where infinities can be handled safely, by extending the number system in a suitable fashion. For instance, in complex analysis, poles can often be viewed as being non-singular, by extending the complex plane to the Riemann sphere, and in fact certain aspects of complex geometry (e.g. Mobius transformations) become more natural when doing so. Sometimes, infinity is an ally, rather than an enemy to be feared.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6533f7b8b2709c797a92a9d5ba5849c8f1e84a2915bc207d2d6f461fc204226c-f19e978cb40e90b08b03c7c03db25a4715dbadd883bdd1b9632de6dd6c3dcdb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim Ralston")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48070")[#strong[#text("Jim Ralston")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2010")])]

#text("You could also mention the viewpoint of asymptotic analysis: everything is simpler at infinity; high frequency waves propagate in a simpler way than moderate frequency waves, gravitational fields look like they come from point masses, etc.")

#text("[I’ve started reading your website in preparation for Math 245B this winter.]")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8bea315ca6359c18c15191e8c0d78193d6f3ea61bbb50218ad2e13c6988d461-c40618e8fab735dbbbfb1255ca0edd52d56248ddc2554fa418ec4270122523db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47289")[#strong[#text("Johan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2010")])]

#text("In exercise 50 there is a typo: “on the integers \\mathbb{R}”. ")#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8bea315ca6359c18c15191e8c0d78193d6f3ea61bbb50218ad2e13c6988d461-c40618e8fab735dbbbfb1255ca0edd52d56248ddc2554fa418ec4270122523db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47328")[#strong[#text("Johan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2010")])]

#text("The typo has not been fixed completely. It should be \\mu(\\phi^{-1}(E)), not the other way around. ")#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47296")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2010")])]

#text("dear Prof. Tao,")

#text("are you planning to say a few words on ” uniform integrability” which is an important tool in probability theory?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47297")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2010")])]

#text("This will be discussed briefly in the next notes (which will focus on the relationship between different types of convergence).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8bea315ca6359c18c15191e8c0d78193d6f3ea61bbb50218ad2e13c6988d461-c40618e8fab735dbbbfb1255ca0edd52d56248ddc2554fa418ec4270122523db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47305")[#strong[#text("Johan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("Exercise 36, the change of variables formula, contains two typos in the definition of the pushforward where the role of \\phi and \\mu have been interchanged. ")#emph[#text("[Corrected, thanks – T.]")]

#text("Great series of posts by the way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c053e31730b497d8214784b3c86199ae6b37222b8e691e9bd655f0d20ab7260d-588904bc5e771d60828be6c161ef722092bfe69ffb87f70f93f532d1dfcdfb43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laurens Gunnarsen")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47316")[#strong[#text("Laurens Gunnarsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("Dear Professor Tao:")

#text("Thank you for your thoughtful reply to my earlier question about why abstract measure theory must allow the domain of a measure to include points (i.e., measurable sets) at which it takes on infinite values. Certainly I agree that in various mathematical settings a compelling case can be made for permitting the domain of a function to include points at which it takes on infinite values.")

#text("But I would maintain that what what we’re really doing when we take this step is reinterpreting the function’s range. We’re acknowledging that we began with an overly naive conception of the structure we need the range to carry. Mature experience has taught us to value certain structures we did not at first recognize as essential (and to recognize as irrelevant certain other structures we at first thought natural.)")

#text("Certainly this is what happens with meromorphic functions. The better we get to know analytic functions with isolated singular points, the more we become convinced that we should think of them as having the Riemann sphere, rather than the complex plane, as their range set. And it is this revision in our conception of their range set’s structure that causes us to alter our views on which points are to be permitted in their domains.")

#text("But I would argue that, upon careful reflection, we can see why we benefit by revising our structural conceptions in favor of the Riemann sphere. And it is certainly not just the compactness of the Riemann sphere that makes it a compelling alternative to the complex plane. Rather, the crucial fact is that by adding a point at infinity to the complex plane, we produce a simply-connected compact space to which the conformal structure of the complex plane extends naturally and non-singularly. From this it follows that a finite-dimensional Lie group of conformal automorphisms acts transitively on the Riemann sphere. And it is this crucial structural feature of the Riemann sphere that makes the whole theory of meromorphic functions “work.”")

#text("What I meant to ask in my earlier post is how, exactly, the addition of a “point at infinity” alters the structure of the range space of a measure, so as to make the whole of abstract measure theory “work.”")

#text("Which is to say that, at bottom, I want to know exactly what structure the range space of a measure must have, if we are to be able to prove all the theorems that we, as the inheritors of generations of profound work and reflection on the abstract theory of measure and its diverse applications, now know that we want and need to be true.")

#text("And one thing that, it seems to me, bears strikingly on this question is our experience with spectral measures. There, my impression is that the crucial structure on the range space is that of an orthocomplemented modular lattice (with least and greatest elements.)")

#text("Is this your impression as well? Would you be comfortable maintaining that measures must have ranges with at least this much structure, and that the admission of “infinity” as a possible value for the measure of a measurable set is therefore required of us for essentially lattice-theoretic reasons?")

#text("Finally, I hope you will forgive me for asking whether you can clarify your remarks concerning the dangers to analysis of the form “infinity” – “infinity,” and the (relative) harmlessness of other forms in which “infinity” enters. Reading your initial remarks on this subject, I was struck immediately by the two examples")

#text("S = 1 – 2 + 3 – 4 + 5 – …")

#text("and")

#text("T = 1 + 2 + 3 + 4 + 4 + … ,")

#text("the former of which, though exemplifying the “infinity” – “infinity” form about as obviously as possible, is vastly easier to interpret and handle than the latter (e.g., the former is Borel-, Cesaro-, Abel-, and Euler-summable, whereas the latter is none of these.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47317")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("Well, the main advantage of adding +infinity to the unsigned real axis [0,+infty) to obtain the extended unsigned real axis [0,+\\infty] is that infinite series always have a value. For instance, the value of")

#text("T = 1 + 2 + 3 + 4 + …")

#text("is simply T = +infinity. (This is a different value from those obtained by some other series summation methods, e.g. zeta regularisation, but such summation methods are not relevant for measure theory.) If we excluded infinity from our measure theory, we would always behaving to distinguish between convergent and divergent unsigned infinite sums, but by incorporating infinity into our number system, we can handle both in a unified manner, and one does not lose too many of the laws of algebra when doing so, provided that one is not trying to use cancellation or subtraction. So adding infinity to one’s number system is not just for the sake of maximal generalisation or completion; it can actually simplify and streamline the discussion of the finitary theory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0677a8c648b88165e043c3f54323aa922b64d429bb779d398e1ba311990cf047-a299a2d84cf1b7c9e79177070e97b75d2b432da856c52e6e227483ab755c0ccf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47331")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2010")])]

#text("Dear Prof Tao, these are really excellent notes! But for the sake of studying, is there any place I can download the pdf of these lecture notes or any way by which I can generate a pdf of just the post (excluding the side-bars etc.). Thanks.")

#emph[#text("[The “Print preview” feature on your browser should automatically strip out the sidebar and header from the file. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47332")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2010")])]

#text("Immediately following Remark 3, Boolean algebras should be ")#mi("\\sigma")#text("-algebras ")#emph[#text(" [Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47339")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2010")])]

#text("I think the second instance of L(R^d) in exercise 27 should be B(R^d).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2010")])]

#text("Should the scale of D_n(R^d) in Example 6 be 2^-n?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adaf83934ef9e83041fdd0b5ad16e455b02b1c2e6eb01568a16f9884d8d5f8fd-4cb33d494f6365ff4f85492980c809be6fde69086d5ddfee0bef924d0a084420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47887")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2010")])]

#text("also, with this correction isn’t D_n+1 now finer than D_n, so the containment goes the other way")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47365")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("I think the third sentence of section 5 is misworded. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 4: Modes of convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47370")[#strong[#text("245A, Notes 4: Modes of convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("[…] real line with Lebesgue measure. The first three of these examples already were introduced in the previous set of notes. Example 1 (Escape to horizontal infinity) Let . Then converges to zero pointwise (and thus, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47651")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] pointwise almost everywhere to . Applying Fatou’s lemma (Corollary 16 of Notes 3), we conclude […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47924")[#strong[#text("245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2010")])]

#text("[…] that contains . In particular, contains all the elementary sets and hence (by Exercise 14 of Notes 3) contains the Borel -algebra. Restricting to the Borel -algebra we obtain the existence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("Today a question came up regarding whether the uncountable sum of measures on a measurable space (X,M) was itself a measure. I was a little surprised by the result, but it seems like the answer’s yes:")

#text("Let ")#mi("(X,\\mathcal{M})")#text(" be a measurable space, and ")#mi("\\{\\mu_a:a\\in \\mathcal{A}\\}")#text(" be an uncountable collection of measures on ")#mi("(X,\\mathcal{M})")#text(". Then ")#mi("\\mu:=\\sum_{a \\in \\mathcal{A}} \\mu_a")#text(" is itself a measure on ")#mi("(X,\\mathcal{M})")#text(".")

#text("Since ")#mi("\\mu:X \\mapsto [0, +\\infty]")#text(" manifestly, there are two axioms to check:")

#text("1. ")#mi("\\mu(\\emptyset) = 0")#text("; and")#linebreak()#text(" 2. (disjoint) countable additivity: given ")#mi("E= \\bigcup_{j=1}^\\infty E_j")#text(" a disjoint union of measurable sets, ")#mi("\\mu(E) = \\sum_{j=1}^\\infty \\mu(E_j)")#text(".")

#text("The first point is trivial: since ")#mi("\\mu_a(\\emptyset) = 0")#text(" for all ")#mi("a \\in \\mathcal{A}")#text(", we must have ")#mi("\\mu(\\emptyset) = 0")#text(".")

#text("For the second, setting ")#mi("A^+:=\\{a \\in A: \\mu_a(E) >0\\}")#text(", we consider two cases: first, when ")#mi("A^+")#text(" is countable, and secondly, when ")#mi("A^+")#text(" is uncountable.")

#text("In the first instance, we are free to apply Tonelli’s Theorem (cf.\\ Theorem 2, Notes 1) to find")

#mi("\\mu(E) = \\sum_{a \\in A^+} \\mu_a(E) = \\sum_{a \\in A^+} \\sum_{j=1}^\\infty \\mu_a(E_j)")#linebreak()#text(" ")#mi("= \\sum_{j=1}^\\infty \\sum_{a \\in A^+} \\mu_a(E_j) = \\sum_{j=1}^\\infty \\mu(E_j),")

#text("as desired.")

#text("In the second case, decomposing ")#mi("A^+")#text(" into the countable union")

#mi("A^+ = \\bigcup_{j=1}^\\infty \\{a \\in A^+: \\mu_a(E_j) > 0 \\} = \\bigcup_{j=1}^\\infty \\bigcup_{m=1}^\\infty \\{a \\in A^+: \\mu_a(E_j) \\geq \\frac{1}{m} \\}")

#text("forces some ")#mi("A_{j^{\\prime},m^{\\prime}}:=\\left\\{a \\in A^+: \\mu_a(E_{j^{\\prime}}) \\geq \\frac{1}{m^{\\prime}} \\right\\}")#text(" to be uncountable. But then")#linebreak()#text(" ")#mi("\\mu(E_{j^{\\prime}}) \\geq \\sum_{a \\in A_{j^{\\prime},m^{\\prime}}} \\mu_a(E_{j^{\\prime}}) \\geq \\sum_{a \\in A_{j^{\\prime},m^{\\prime}}} \\frac{1}{m^{\\prime}} = +\\infty,")#linebreak()#text(" forcing our desired equality (by the monotonicity of each ")#mi("\\mu_a")#text("):")#linebreak()#text(" ")#mi("\\mu(E) = \\sum_{j=1}^\\infty \\mu(E_j) = +\\infty. \\Box")

#text("Make sense?")

#text("By the way, this is my first post, so sorry if the formatting doesn’t turn out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xtt")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-47999")[#strong[#text("Xtt")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("This may be a stupid question: In excercise 36, if X and Y are both equipped with trivial algebra, and X has a measure 1 of itself and 0 of empty set. And let the morphism X -> Y be: X -> empty set in Y, and empty set in X -> Y. Does this violate the pushforward is a measure?(since its measure on empty set in Y is not zero)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48001")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("A morphism has to be a function from X to Y. If X is non-empty, then the image of X must also be non-empty; there is no function that can map a non-empty set to an empty set.")

#text("In any event, it is the inverse images of the morphism that are more relevant than the forward images, and the inverse image of the empty set by any function is always the empty set (and the inverse image of the range is always the domain).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f361a04950475a41037ec565251c0e2c3286072d70467ca68caf07545c2a4334-83f82a5769ac964a883555046c8486b4350c09066749cf7b896745022888e9bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cy")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48076")[#strong[#text("cy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2010")])]

#text("The left hand side of the last inequality in the proof of Fatou’s lemma, should be liminf instead of limsup.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Y")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48109")[#strong[#text("Y")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2010")])]

#text("Prof. Tao,")#linebreak()#text(" For the definition 1, can one drop the first property ")#mi("\\emptyset \\in \\mathcal{B}")#text(" ? It seems that one can deduce from properties (ii) and (iii). But as you say, it is the “minimalist” definition of a Boolean algebra. Is it because the property ")#mi("\\emptyset \\in \\mathcal{B}")#text(" ensures that ")#mi("\\mathcal{B}")#text(" does have “something” that one can not drop it? After all, it seems quite different from the other two properties. Both (ii) and (iii) start with “If…”. Could you explain why (ii) and (iii) are not enough?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48110")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2010")])]

#text("(ii) and (iii) can only deduce (i) if one knows that the algebra ")#mi("{\\mathcal B}")#text(" contains at least one set. Otherwise, it could be completely empty (not even containing the empty set: ")#mi("{\\mathcal B} = \\{ \\}")#text(".")

#text("The axiom (i) is analogous to the axiom that a group contains an identity element, that a vector space contains an origin, or that an equivalence relation is reflexive. In each of these cases, this basic axiom is almost, but not quite, implied by the other axioms.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ee3b6895eb3331d0d3a2784a6f1479fc63a5b624753b11b7b7fe9fe4b05dcc7-54ce7b2cee0668338ee9b1d13c76d7ee977415081e06617b41cbd6f0222be94a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik Davis")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48313")[#strong[#text("Erik Davis")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2010")])]

#text("Excellent notes. There were two small errors I noticed (unless I misread).")

#text("In exercise 4, I think you mean ")#mi("2^n")#text(", rather than ")#mi("2^{2^n}")#text(" (e.g. the powerset of ")#mi("\\{1,2,3\\}")#text(" has cardinality $\\latex 2^3$)")#linebreak()#text(" In exercise 8, this isn’t true as stated. Consider ")#mi("F = \\{\\{1\\}\\}")#text(". Unless our total space is just the singleton ")#mi("\\{1\\}")#text(", the Boolean algebra generated by ")#mi("F")#text(" will have four elements. For the ")#mi("2^n")#text(" bound I think you need some extra condition, e.g. the family ")#mi("F")#text(" is a cover for our total space.")

#emph[#text("[Corrected, thanks. For some strange reason the ")#mi("2^n")#text(" and ")#mi("2^{2^n}")#text(" got swapped across these two exercises… – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8694af88c9a2be82908d939b142aa32e281d7c015e5005efb82b5639fbc74f-4d7aed741d719062aba62ef4c88e5ccdd4be1b5752daaab58815a95f3fcde7c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dustin Bryant")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-452172")[#strong[#text("Dustin Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2015")])]

#text("Actually, if you look at Halmos’ original text, “Lectures on Boolean Algebras” chapter 16 exercise 3, this is 2^{2^n}. So we should consider very carefully who has the typo.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I’m confused in the Exercise 38. What do you mean by ")#mi("\\sum_{x\\in X}f(x)")#text(" when ")#mi("X")#text(" is uncountable?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48390")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("This is defined in Section 1 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Y")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48395")[#strong[#text("Y")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In Exercise 23, you use the notation ")#mi("\\sup_{n\\rightarrow \\infty} \\mu (E_n)")#text(". Is this a conventional use? Or precisely should it be $latex \\sup_{n\\in \\mathbb{N} } \\mu (E_n)}?")

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48401")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Prof. Tao,")

#text("I can’t catch up with you in the proof of Monotone convergence theorem. What do you mean by “By horizontal truncation we may assume without loss of generality that g also is finite everywhere”? Could you explain it slightly? What’s the relationship between this statement and the horizontal truncation in Exercise 34.10? How can one get “finite everywhere” just by truncation? In the proof of Theorem 12, you used “horizontal truncation”. By I still don’t understand your idea here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48402")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("One uses vertical truncation (applied to g) rather than horizontal truncation here. Once one shows the claim for finite-valued g, the claim then follows for infinite-valued g by replacing g with the vertical truncation ")#mi("\\min(g,N)")#text(", applying the result for finite-valued g, and then letting ")#mi("N \\to \\infty")#text(" using Exercise 34.10.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48403")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Thank you for your answer. I think the main idea here is the construction of ")#mi("A_{i,n}")#text(". However, can one just construct ")#mi("A_n=\\{x: f_n(x)\\geq (1-\\epsilon) g (x)\\}")#text(" without vertically truncate ")#mi("g(x)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48428")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2010")])]

#text("One needs ")#mi("g")#text(" to be vertically truncated to ensure that ")#mi("(1-\\varepsilon) g(x)")#text(" is strictly less than ")#mi("g(x)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-464512")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2015")])]

#text("So according to what you changed in Exercise 34.10, you did mean “horizontal truncation” in the proof of MCT, didn’t you? It seems that you are using the phrase “horizontal truncation” with different meanings in mind: 1. truncate the horizontal axis, 2 truncate the graph of a function using a horizontal line.")

#text("How time flies :-)")

#emph[#text("[Corrected to the latter meaning throughout, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2482bc2e3267d57000dae52859a7af777db285ae043d941a00575c2faa8415ab-39cc115d08a68183c5402330b763b58cf7e52f328a91392de1dd0e7e4510bbb2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Damek Davis")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48863")[#strong[#text("Damek Davis")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2010")])]

#text("Professor Tao,")

#text("In Remark 8, it states that $B$ is coarser than $B’$ precisely when, $\\text{id}_X : X \\rightarrow X$ is a measurable morphism from $(X, B)$ to $(X, B’)$. However, this implies that $B’ \\subseteq B$ because every $B’$ measurable set $E$ is $B$ measurable. I think $(X,B)$ and $(X, B’)$ should be switched. Is this correct?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-48865")[#strong[#text("Is the product of measurable spaces the categorical product? « Graduated Understanding")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2010")]

#text("[…] respects arbitrary unions and complements, and , we only need to show that and for all and (see remark 4 of Terry Tao’s notes on abstract measure spaces). This is easy to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-146615")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2012")])]

#text("Typo in Exercise 9: “…all sets that either the union…”")

#text("Also, isn’t it the case in Exercise 9 that ")#mi("\\mathcal{F}_2")#text(" gives the entire Boolean algebra?")

#text("Since we are considering only finite combinations of set operations, it seems that, for any such expression, we could use ")#mi("\\cup-\\cap")#text(" distributivity to pull all union symbols out of any parentheses containing intersection symbols, and then we would have an expression of the form ")#mi("\\cup_i (\\cap_j A_{i,j})")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-146616")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2012")])]

#text("Maybe what I said above was not so clear. What I mean is:")

#text("If we write union with the symbol ")#mi("+")#text(" and intersection with the symbol ")#mi("\\times")#text(", then for the same reason that we can write any finite combination of sums and products in a ring as a sum of products ")#mi("\\sum_i (\\prod_j a_{i,j})")#text(", we should be able to write any finite combination of set operations as a union over a family of intersections ")#mi("\\cup_i (\\cap_j A_{i,j})")#text(", since we have the same distributivity law that we would have for rings.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-146628")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2012")])]

#text("Typo: “Exercise 15 (Recursive description of a generated Boolean algebra)” This should read ")#mi("\\sigma")#text("-algebra rather than Boolean algebra, although I notice that this has been corrected in the published book.")

#text("Is knowledge of Exercise 15 necessary to prove Exercise 52? I would imagine that one needs some way of describing the sets in ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(" in terms of the sets in ")#mi("\\mathcal{A}")#text(" (such as in Exercise 15) in order to proceed. However, I don’t happen to know anything about ordinals.")

#text("I see how to deduce Exercise 52 from the Hahn-Kolmogorov extension theorem, but this feels like cheating.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-150176")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")])]

#text("Do you have any hints for a way to approach exercise 52?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-150205")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")])]

#text("Use Remark 4. (Alternatively: review the proof of the fact that Lebesgue measurable sets of finite measure can be approximated to arbitrary accuracy by elementary sets.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-175129")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2012")])]

#text("For the construction of integration on abstract measure spaces, the measurable functions of which the range is in ")#mi("{\\mathbb R}")#text(" or ")#mi("{\\mathbb C}")#text(" are used. Can we define integration of measurable functions of which the range is ")#mi("{\\mathbb C}^n")#text(" or any measurable space? What properties should such space have?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-175134")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2012")])]

#text("To integrate functions taking values in a finite-dimensional vector space, one can pick a basis for that vector space and integrate each coordinate of the vector-valued function separately; this gives a well-defined notion of integral that is independent of the choice of basis, and the theory is more or less the same as that for scalar integration.")

#text("For functions taking values in infinite-dimensional vector spaces, things get trickier (much as infinite sums become a more subtle topic in infinite-dimensional vector spaces than in finite-dimensional ones, due to the number of different concepts of convergence for such sums). The two most popular notions of integral here are the ")#link("http://en.wikipedia.org/wiki/Bochner_integral")[#text("Bochner integral")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Pettis_integral")[#text("Pettis integral")]#text(", with the latter being more general (but weaker) than the former. But one can make mistakes if one blindly assumes that all the theorems of Lebesgue integration carry over verbatim to this infinite dimensional setting, so I would recommend working out any particular manipulation (e.g. interchanging limits and integrals) for such vector-valued integrals carefully by hand whenever the need arises.")

#text("For functions taking values in a nonlinear space (e.g. an abstract manifold), the notion of even a finite sum becomes problematic, let alone infinite sums or integrals. It is still worthwhile sometimes to attempt to define integrals or averages on nonlinear spaces, but this generally has to be done on an ")#emph[#text("ad hoc")]#text(" basis (there is no useful general theory analogous to the Lebesgue integration theory here), and it is not always guaranteed that a good integration concept actually exists.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-217988")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2013")])]

#text("The convergence theorems basically deal with questions that when we have")#linebreak()#text(" ")#mi("\\lim_{n\\to\\infty}\\int_Xf_n(x)d\\mu(x)=\\int_X\\lim_{n\\to\\infty}f_n(x)d\\mu(x)")#text(". Is there any theorem in real analysis about the “continuous version” of this formula? That is when can we have for instance something like")#linebreak()#text(" ")#mi("\\lim_{t\\to t_0}\\int_Xf(x,t)d\\mu(x)=\\int_X\\lim_{t\\to t_0}f(x,t)d\\mu(x)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-218117")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2013")])]

#text("Yes, either by adapting the proofs of the sequential convergence theorems, or by recasting the notion of continuous convergence in terms of sequential convegence (e.g. ")#mi("\\lim_{t \\to t_0} f(t) = f(t_0)")#text(" can be reformulated as the assertion that ")#mi("\\lim_{n \\to \\infty} f(t_n) = f(t_0)")#text(" whenever ")#mi("t_n \\to t_0")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-220790")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2013")])]

#text("The change of variables formula in Riemann integration is")

#mi("\\int_{[a,b]}f\\circ\\phi\\ d\\phi=\\int_{[\\phi(a),\\phi(b)]}f")#text(".")

#text("[From ")#link("http://www.math.ucla.edu/~tao/resource/general/131ah.1.03w/week10.pdf%5D")[#text("http://www.math.ucla.edu/~tao/resource/general/131ah.1.03w/week10.pdf%5D")]

#text("In Exercise 36,")

#mi("\\int_Yf\\ d\\phi_*\\mu=\\int_X (f\\circ\\phi)\\ d\\mu")

#text("Should they relate to each other since you call them both the change of variables formula?")

#text("Let ")#mi("X=[a,b]")#text(", ")#mi("Y=[\\phi(a),\\phi(b)]")#text(", and $\\phi$ be the measurable morphism. The first one is almost the same as the second one. But the measure doesn’t match. What do I do wrong here…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-221178")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2013")])]

#text("Let ")#mi("X=[\\phi(a),\\phi(b)]")#text(" and $Y=[a,b]$. Then the first one can be written as")

#mi("\\int_Y (f\\circ\\phi)\\ d\\phi=\\int_X (f\\circ\\phi)\\circ (\\phi)^{-1}d\\mu")

#text("Do you have any hint for the last step, i.e.")

#mi("d\\phi=d(\\phi)^{-1}_*\\mu")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-236288")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("A remark to Exercise 14:")

#text("This exercise make use of the essential facts that:")

#text("1.A countable intersection of Borel measurable sets is also Borel measurable.")

#text("2.Every closed set in ")#mi("\\mathbf{R}")#text(" can be represented as a countable intersection of open sets.")

#text("3.Every open set in ")#mi("\\mathbf{R}")#text(" can be represented as a countable union open closed intervals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-236294")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("Dear Prof.Tao,")

#text("I think “Exercise 15 (Recursive description of a generated Boolean algebra)” should be “Exercise 15 (Recursive description of a generated ")#mi("\\sigma")#text(" algebra) ”…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-236805")[#strong[#text("Solutions to Exercise 9 and Exercise 15 of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems | Asymptote")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2013")]

#text("[…] In this post I give solutions to Exercise 9 and Exercise 15 of Terence Tao’s post 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-236927")[#strong[#text("Solution to Exercise 16 of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems | Asymptote")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")]

#text("[…] In this post I give solution to Exercise 16 of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-236961")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("A remark to Exercise 18:")

#text("If ")#mi("M\\subseteq \\mathbf{R}^n")#text(" is Borel unmeasurable,then ")#mi("\\{(x,0):x\\in M\\}")#text(" is also Borel unmeasurable in ")#mi("\\mathbf{R}^{n+1}")#text(".")

#text("This is a difference between the Borel measure and Lebesgue measure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-237292")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Dear Prof.Tao and peers,")

#text("Definition 8 is stated as follows:")

#text("Let ")#mi("{(X,{\\mathcal B})}")#text(" be a measurable space, and let ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" or ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be an unsigned or complex-valued function. We say that ")#mi("{f}")#text(" is measurable if ")#mi("{f^{-1}(U)}")#text(" is ")#mi("{{\\mathcal B}}")#text("-measurable for every open subset ")#mi("{U}")#text(" of ")#mi("{[0,+\\infty]} or {{\\bf C}}")#text(".")

#text("Why not stated as follows:")

#text("Let ")#mi("{(X,{\\mathcal B})}")#text(" be a measurable space, and let ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" or ")#mi("f: X \\rightarrow {\\bf C}\\bigcup\\{\\infty\\}")#text(" be an unsigned or complex-valued function. We say that ")#mi("{f}")#text(" is measurable if ")#mi("{f^{-1}(U)}")#text(" is ")#mi("{{\\mathcal B}}")#text("-measurable for every open subset ")#mi("{U}")#text(" of ")#mi("{[0,+\\infty]} or {{\\bf C}\\bigcup\\{\\infty\\}}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-237386")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("One can define measurable maps between any two measurable spaces, but the reason I restrict here to ")#mi("[0,+\\infty]")#text(" or to ")#mi("{\\mathbf C}")#text(" is because these two spaces have well-defined addition and multiplication operations, so that one can integrate simple functions without difficulty. For ")#mi("{\\mathbf C} \\cup \\{\\infty\\}")#text(" or ")#mi("{\\mathbf R} \\cup \\{\\pm \\infty\\}")#text(", addition and multiplication are not always defined. (This is not a serious issue if the functions involved are finite almost everywhere, but it is best to not introduce these issues right away as they are not the most important detail in integration theory.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-237774")[#strong[#text("Solution to Exercise 28.6 of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems | Asymptote")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2013")]

#text("[…] In this post I give solution to Exercise 28.6 of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-237947")[#strong[#text("Solution to Exercise 28.8 of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems | Asymptote")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")]

#text("[…] In this post I give solution to Exercise 28.8 of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-237979")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("A remark to Remark 8:")

#text("This conclusion in Remark 8 is insightful:“Also, one ")#mi("{{\\sigma}}")#text("-algebra ")#mi("{{{\\mathcal B}}}")#text(" on a space ")#mi("{{X}}")#text(" is coarser than another ")#mi("{{{\\mathcal B}^{\\prime}}}")#text(" precisely when the identity map ")#mi("{{\\text{id}_X: X \\rightarrow X}}")#text(" is a measurable morphism from ")#mi("{{(X,{\\mathcal B}^{\\prime})}}")#text(" to ")#mi("{{(X,{\\mathcal B})}}")#text(".”")

#text("It makes me think deeply.")

#text("1.If ")#mi("{f:\\mathbf{R}\\rightarrow\\mathbf{R}}")#text(" is continuous,then ")#mi("{f^{-1}}")#text(" will transform any open sets in ")#mi("{\\mathbf{R}}")#text(" into an open sets in ")#mi("{\\mathbf{R}}")#text(",so informally speaking, a continuous map is no better than an identity map,because the inverse of an identity map can also transform any open set in ")#mi("{\\mathbf{R}}")#text(" into an open set.This indicates that a continuous map is too regular,too normal that it is very similar to the identity map!")

#text("Let’s say it in another way,if ")#mi("{f}")#text(" is a continuous map,then ")#mi("{f^{-1}}")#text(" maps a algebra on space ")#mi("{\\mathbf{R}}")#text(" to another algebra on ")#mi("{\\mathbf{R}}")#text(",neither of the two algebra is coarser than the other one.")

#text("2.If ")#mi("{f:\\mathbf{R}\\rightarrow\\mathbf{R}}")#text(" is Lebesgue measurable,then ")#mi("{f^{-1}}")#text(" will transform any open sets in ")#mi("{\\mathbf{R}}")#text(" into a Lebesgue measurable set in ")#mi("{\\mathbf{R}}")#text(",so informally speaking,a Lebesgue measurable function is better than an identity map,this indicates that a Lebesgue measurable function has higher level of complexity than the identity function and continuous function.")

#text("Let’s say it in another way,if ")#mi("{f}")#text(" is a L-measurable map,then ")#mi("{f^{-1}}")#text(" maps a algebra ")#mi("{P}")#text(" on space ")#mi("{\\mathbf{R}}")#text(" to another algebra ")#mi("{Q}")#text(" on ")#mi("{\\mathbf{R}}")#text(",and ")#mi("{P}")#text(" is coarser than ")#mi("{Q}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-238508")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2013")])]

#text("Only unitil the day before yesterday I discovered that I had a wrong proof of Egorov’s theorem before.Now I prove it again!I think this time my proof will be right ,and be a bit shorter than Mr.Tao’s proof.")

#text("Assume the condition stated in this Exercise 30 (Egorov’s theorem).")

#mi("{{{{f}}}}")#text(" is pointwise approximated by ")#mi("{{{{f_n}}}}")#text(" ,where ")#mi("{{{{f:X\\rightarrow\\mathbf{R}}}}}")#text(" is a function,")#mi("{{{{f_n:X\\rightarrow\\mathbf{R}}}}}")#text(" are measurable function.")#linebreak()#text(" This means that,")#mi("{{{{\\forall \\epsilon>0}}}}")#text(",we have")

#tao-math("{{{{{\\displaystyle \\bigcup_{n\\in\\mathbf{N}^+}\\{x:\\left|f(x)-f_n(x)\\right|<\\epsilon\\}=X.\\\\\\\\\\ (1)}}}}}", block: false)

#text("By applying the monotone convergence theorem to (1)(Note ")#mi("{{{{\\mu}}}}")#text(" is finite measure is a must have condition),together with the equation")

#mi("{{{{{\\displaystyle \\lim_{N\\rightarrow\\infty}m\\left(\\bigcup_{n=1}^{N}A_n\\right)=m\\left(\\bigcup_{n\\in\\mathbf{N}^+}A_n\\right)\\\\\\\\\\ (2)}}}}}")

#text("We have")

#tao-math("{{{{{\\displaystyle \\lim_{N\\rightarrow\\infty}m\\left(\\bigcup_{n=1}^{N}\\{x:\\left|f(x)-f_n(x)\\right|<\\epsilon\\}\\right)=m(X).\\\\\\\\\\ (3)}}}}}", block: false)

#text("Translating (3) into English,we have the conclusion that ")#mi("{{{{f}}}}")#text(" can be uniformly approximated by ")#mi("{{{{f_n}}}}")#text(" on ")#mi("{{{{X\\backslash E}}}}")#text(",where ")#mi("{{{{E}}}}")#text(" is a measurable set whose measure is at most ")#mi("{{{{\\epsilon}}}}")#text(". ")#mi("\\Box")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-238524")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2013")])]

#text("I am wrong again.The corrected version is here,now I believe I will be right:")

#mi("{{{{f}}}}")#text(" is pointwise approximated by ")#mi("{{{{f_n}}}}")#text(" ,where ")#mi("{{{{f:X\\rightarrow \\mathbf{R}}}}}")#text(" is a function,")#mi("{{{{f_n:X\\rightarrow\\mathbf{R}}}}}")#text(" are measurable function.")#linebreak()#text(" This means that,")#mi("{{{{\\forall \\epsilon>0}}}}")#text(",we have")

#tao-math("{{{{{\\displaystyle \\bigcup_{n\\in\\mathbf{N}^+}\\{x:\\left|f(x)-f_n(x)\\right|<\\epsilon\\}=X.\\\\\\\\\\ (1)}}}}}", block: false)

#text("By applying the monotone convergence theorem to (1)(Note ")#mi("{{{{\\mu}}}}")#text(" is finite measure is a must have condition),together with the equation")

#mi("{{{{{\\displaystyle \\lim_{N\\rightarrow\\infty}m^{*}\\left(\\bigcup_{n=1}^{N}A_n\\right)=m^{*}\\left(\\bigcup_{n\\in\\mathbf{N}^+}A_n\\right)\\\\\\\\\\ (2)}}}}}")

#text("We have")

#tao-math("{{{{{\\displaystyle \\lim_{N\\rightarrow\\infty}m^{*}\\left(\\bigcup_{n=1}^{N}\\{x:\\left|f(x)-f_n(x)\\right|<\\epsilon\\}\\right)=m^{*}(X)=m(X).\\\\\\\\\\ (3)}}}}}", block: false)

#text("Translating (3) into English,we have the conclusion that ")#mi("{{{{f}}}}")#text(" can be uniformly approximated by ")#mi("{{{{f_n}}}}")#text(" on ")#mi("{{{{X\\backslash E}}}}")#text(",where ")#mi("{{{{E}}}}")#text(" is a measurable set whose measure is very small. ")#mi("\\Box")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-238526")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2013")])]

#text("I wonder why there is no definition of outer measure in general measure space.I think the outer measure ")#mi("\\mu ^{*}(A)")#text(" of ")#mi("A")#text(" can be defined as “the measure of the smallest measurable set that covers ")#mi("A")#text(" “.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-238570")[#strong[#text("A proof of Egorov’s theorem | Asymptote")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2013")]

#text("[…] In this post I give a proof of Egorov’s theorem stated in Exercise 30 of Terence Tao’s post 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-238764")[#strong[#text("A proof of inclusion-exclusion principle | Asymptote")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2013")]

#text("[…] In this post,I prove inclusion-exclusion principle inductively.This principle can be found at Exercise 33 in Terence Tao’s post 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-238770")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2013")])]

#text("A remark to Exercise 28,(6):")

#text("Exercise 28.6 says:If ")#mi("{{{{f_n: X \\rightarrow [0,+\\infty]}}}}")#text(" are a sequence of measurable functions that converge pointwise to a limit ")#mi("{{{{f: X \\rightarrow [0,+\\infty]}}}}")#text(", then show that ")#mi("{{{{f}}}}")#text(" is also measurable. Obtain the same claim if ")#mi("{{{{[0,+\\infty]}}}}")#text(" is replaced by ")#mi("{{{{\\mathbf{C}}}}}")#text(".")

#text("I can do this exercise,but I wonder whether the following is true?")

#text("A measurable function can be pointwise approximated by a sequence of simple functions.")

#text("I can’t prove it,so I believe this is not true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-238773")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2013")])]

#text("A remark to definition 11:")

#text("Definition 11 says: Let ")#mi("{{{{(X, {\\mathcal B}, \\mu)}}}}")#text(" be a measure space, and let ")#mi("{{{{f: X \\rightarrow [0,+\\infty]}}}}")#text(" be measurable. Then we define the unsigned integral ")#mi("{{{{\\int_X f\\ d\\mu}}}}")#text(" of ")#mi("{{{{f}}}}")#text(" by the formula")

#mi("{{{{{\\displaystyle  \\int_X f\\ d\\mu := \\sup_{0 \\leq g \\leq f; g \\text{ simple}} \\text{Simp} \\int_X g\\ d\\mu.}}}}}")

#text("I wonder why not define the unsigned integral as follows?")

#mi("{{{{{\\displaystyle  \\int_X f\\ d\\mu := \\inf_{g \\geq f; g \\text{ simple}} \\text{Simp} \\int_X g\\ d\\mu.}}}}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-238820")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("Dear Prof.Tao,")

#text("Exercise 34,(9) says:")

#text("(Vertical truncation) We have ")#mi("\\lim_{n \\rightarrow \\infty} \\int_X \\min(f,n)\\ d\\mu = \\int_X f\\ d\\mu")#text(".")

#text("But I think an addtional hypothesis should be added:")#mi("f")#text(" should be finite almost everywhere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/comment-page-1/#comment-238821")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("Oh,I am wrong….This additional hypothesis is not needed…")
]
]
