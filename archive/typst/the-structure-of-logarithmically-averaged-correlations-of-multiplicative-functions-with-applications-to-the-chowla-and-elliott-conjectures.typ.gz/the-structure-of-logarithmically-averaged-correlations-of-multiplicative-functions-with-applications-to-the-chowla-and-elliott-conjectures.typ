// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/
// Converted to Typst by tao2typ: "2026-10-14T16:38:10.378765+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 August 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/")[#text("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.utu.fi/en/units/sci/units/math/staff/Pages/jopete.aspx")[#text("Joni Teräväinen")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1708.02610")[#text("The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures")]#text("“, submitted to ")#link("https://www.dukeupress.edu/Duke-Mathematical-Journal/")[#text("Duke Mathematical Journal")]#text(". This paper builds upon ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("my previous paper")]#text(" in which I introduced an “entropy decrement method” to prove the two-point (logarithmically averaged) cases of the Chowla and Elliott conjectures. A bit more specifically, I showed that")

#align(center)[#tao-fit-display[#mitex("\\lim_{m \\rightarrow \\infty} \\frac{1}{\\log \\omega_m} \\sum_{x_m/\\omega_m \\leq n \\leq x_m} \\frac{g_0(n+h_0) g_1(n+h_1)}{n} = 0")]]

#text("whenever ")#mi("{1 \\leq \\omega_m \\leq x_m}")#text(" were sequences going to infinity, ")#mi("{h_0,h_1}")#text(" were distinct integers, and ")#mi("{g_0,g_1: {\\bf N} \\rightarrow {\\bf C}}")#text(" were ")#mi("{1}")#text("-bounded multiplicative functions which were ")#emph[#text("non-pretentious")]#text(" in the sense that ")#metadata(none) <tao-2a9a6720c63579f8f665>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\liminf_{X \\rightarrow \\infty} \\inf_{\\left|t_j\\right| \\leq X} \\sum_{p \\leq X} \\frac{1-\\mathrm{Re}( g_j(p) \\overline{\\chi_j}(p) p^{it_j})}{p} = \\infty", block: true)]]

#text("for all Dirichlet characters ")#mi("{\\chi_j}")#text(" and for ")#mi("{j=0,1}")#text(". Thus, for instance, one had the logarithmically averaged two-point Chowla conjecture")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n) \\lambda(n+h)}{n} = o(\\log x)")]]

#text("for fixed any non-zero ")#mi("{h}")#text(", where ")#mi("{\\lambda}")#text(" was the ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(".")

#text("One would certainly like to extend these results to higher order correlations than the two-point correlations. This looks to be difficult (though perhaps not completely impossible if one allows for logarithmic averaging): in ")#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/")[#text("a previous paper")]#text(" I showed that achieving this in the context of the Liouville function would be equivalent to resolving the logarithmically averaged Sarnak conjecture, as well as establishing logarithmically averaged local Gowers uniformity of the Liouville function. However, in this paper we are able to avoid having to resolve these difficult conjectures to obtain partial results towards the (logarithmically averaged) Chowla and Elliott conjecture. For the Chowla conjecture, we can obtain all odd order correlations, in that ")#metadata(none) <tao-ec005930dcb5b5eaa6f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n+h_1) \\dots \\lambda(n+h_k)}{n} = o(\\log x)")]]

#text("for all odd ")#mi("{k}")#text(" and all integers ")#mi("{h_1,\\dots,h_k}")#text(" (which, in the odd order case, are no longer required to be distinct). (Superficially, this looks like we have resolved “half of the cases” of the logarithmically averaged Chowla conjecture; but it seems the odd order correlations are significantly easier than the even order ones. For instance, because of the Katai-Bourgain-Sarnak-Ziegler criterion, one can basically deduce the odd order cases of ")#link(<tao-ec005930dcb5b5eaa6f0>)[#text("(2)")]#text(" from the even order cases (after allowing for some dilations in the argument ")#mi("{n}")#text(").")

#text("For the more general Elliott conjecture, we can show that")

#align(center)[#tao-fit-display[#mitex("\\lim_{m \\rightarrow \\infty} \\frac{1}{\\log \\omega_m} \\sum_{x_m/\\omega_m \\leq n \\leq x_m} \\frac{g_1(n+h_1) \\dots g_k(n+h_k)}{n} = 0")]]

#text("for any ")#mi("{k}")#text(", any integers ")#mi("{h_1,\\dots,h_k}")#text(" and any bounded multiplicative functions ")#mi("{g_1,\\dots,g_k}")#text(", unless the product ")#mi("{g_1 \\dots g_k}")#text(" ")#emph[#text("weakly pretends to be a Dirichlet character ")#mi("{\\chi}")]#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq X} \\frac{1 - \\text{Re}( g_1 \\dots g_k(p) \\overline{\\chi}(p)}{p} = o(\\log\\log X).")]]

#text("This can be seen to imply ")#link(<tao-ec005930dcb5b5eaa6f0>)[#text("(2)")]#text(" as a special case. Even when ")#mi("{g_1,\\dots,g_k}")#text(" ")#emph[#text("does")]#text(" pretend to be a Dirichlet character ")#mi("{\\chi}")#text(", we can still say something: if the limits")

#align(center)[#tao-fit-display[#mitex("f(a) := \\lim_{m \\rightarrow \\infty} \\frac{1}{\\log \\omega_m} \\sum_{x_m/\\omega_m \\leq n \\leq x_m} \\frac{g_1(n+ah_1) \\dots g_k(n+ah_k)}{n}")]]

#text("exist for each ")#mi("{a \\in {\\bf Z}}")#text(" (which can be guaranteed if we pass to a suitable subsequence), then ")#mi("{f}")#text(" is the uniform limit of periodic functions ")#mi("{f_i}")#text(", each of which is ")#mi("{\\chi}")#text("–")#link("https://en.wikipedia.org/wiki/Isotopy_of_an_algebra")[#text("isotypic")]#text(" in the sense that ")#mi("{f_i(ab) = f_i(a) \\chi(b)}")#text(" whenever ")#mi("{a,b}")#text(" are integers with ")#mi("{b}")#text(" coprime to the periods of ")#mi("{\\chi}")#text(" and ")#mi("{f_i}")#text(". This does not pin down the value of any single correlation ")#mi("{f(a)}")#text(", but does put significant constraints on how these correlations may vary with ")#mi("{a}")#text(".")

#text("Among other things, this allows us to show that all ")#mi("{16}")#text(" possible length four sign patterns ")#mi("{(\\lambda(n+1),\\dots,\\lambda(n+4)) \\in \\{-1,+1\\}^4}")#text(" of the Liouville function occur with positive density, and all ")#mi("{65}")#text(" possible length four sign patterns ")#mi("{(\\mu(n+1),\\dots,\\mu(n+4)) \\in \\{-1,0,+1\\}^4 \\backslash \\{-1,+1\\}^4}")#text(" occur with the conjectured logarithmic density. (In a ")#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/")[#text("previous paper")]#text(" with Matomaki and Radziwill, we obtained comparable results for length three patterns of Liouville and length two patterns of Möbius.)")

#text("To describe the argument, let us focus for simplicity on the case of the Liouville correlations ")#metadata(none) <tao-ee9d7bb2926725fdd2d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f(a) := \\lim_{X \\rightarrow \\infty} \\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{\\lambda(n) \\lambda(n+a) \\dots \\lambda(n+(k-1)a)}{n},")]]

#text("assuming for sake of discussion that all limits exist. (In the paper, we instead use the device of generalised limits, as discussed in ")#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/")[#text("this previous post")]#text(".) The idea is to combine together two rather different ways to control this function ")#mi("{f}")#text(". The first proceeds by the entropy decrement method mentioned earlier, which roughly speaking works as follows. Firstly, we pick a prime ")#mi("{p}")#text(" and observe that ")#mi("{\\lambda(pn)=-\\lambda(n)}")#text(" for any ")#mi("{n}")#text(", which allows us to rewrite ")#link(<tao-ee9d7bb2926725fdd2d7>)[#text("(3)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("(-1)^k f(a) = \\lim_{X \\rightarrow \\infty} \\frac{1}{\\log X}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\frac{\\lambda(pn) \\lambda(pn+ap) \\dots \\lambda(pn+(k-1)ap)}{n}.")]]

#text("Making the change of variables ")#mi("{n^{\\prime} = pn}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("(-1)^k f(a) = \\lim_{X \\rightarrow \\infty} \\frac{1}{\\log X}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n^{\\prime} \\leq pX} \\frac{\\lambda(n^{\\prime}) \\lambda(n^{\\prime}+ap) \\dots \\lambda(n^{\\prime}+(k-1)ap)}{n^{\\prime}} p 1_{p|n^{\\prime}}.")]]

#text("The difference between ")#mi("{n^{\\prime} \\leq pX}")#text(" and ")#mi("{n^{\\prime} \\leq X}")#text(" is negligible in the limit (here is where we crucially rely on the log-averaging), hence")

#align(center)[#tao-fit-display[#mitex("(-1)^k f(a) = \\lim_{X \\rightarrow \\infty} \\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{\\lambda(n) \\lambda(n+ap) \\dots \\lambda(n+(k-1)ap)}{n} p 1_{p|n}")]]

#text("and thus by ")#link(<tao-ee9d7bb2926725fdd2d7>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("(-1)^k f(a) = f(ap) + \\lim_{X \\rightarrow \\infty} \\frac{1}{\\log X}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\frac{\\lambda(n) \\lambda(n+ap) \\dots \\lambda(n+(k-1)ap)}{n} (p 1_{p|n}-1).")]]

#text("The entropy decrement argument can be used to show that the latter limit is small for most ")#mi("{p}")#text(" (roughly speaking, this is because the factors ")#mi("{p 1_{p|n}-1}")#text(" behave like independent random variables as ")#mi("{p}")#text(" varies, so that concentration of measure results such as Hoeffding’s inequality can apply, after using entropy inequalities to decouple somewhat these random variables from the ")#mi("{\\lambda}")#text(" factors). We thus obtain the approximate isotopy property ")#metadata(none) <tao-c80bd9c790fd1e2bffe5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(-1)^k f(a) \\approx f(ap)")]]

#text("for most ")#mi("{a}")#text(" and ")#mi("{p}")#text(".")

#text("On the other hand, by the Furstenberg correspondence principle (as discussed in ")#link("https://terrytao.wordpress.com/tag/correspondence-principle/")[#text("these previous posts")]#text("), it is possible to express ")#mi("{f(a)}")#text(" as a multiple correlation")

#align(center)[#tao-fit-display[#mitex("f(a) = \\int_X g(x) g(T^a x) \\dots g(T^{(k-1)a} x)\\ d\\mu(x)")]]

#text("for some probability space ")#mi("{(X,\\mu)}")#text(" equipped with a measure-preserving invertible map ")#mi("{T: X \\rightarrow X}")#text(". Using results of ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("Bergelson-Host-Kra")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=3294297")[#text("Leibman")]#text(", and ")#link("https://arxiv.org/abs/1708.01361")[#text("Le")]#text(", this allows us to obtain a decomposition of the form ")#metadata(none) <tao-d15198de14ea4414efff>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("f(a) = f_1(a) + f_2(a)")]]

#text("where ")#mi("{f_1}")#text(" is a nilsequence, and ")#mi("{f_2}")#text(" goes to zero in density (even along the primes, or constant multiples of the primes). The original work of Bergelson-Host-Kra required ergodicity on ")#mi("{X}")#text(", which is very definitely a hypothesis that is not available here; however, the later work of Leibman removed this hypothesis, and the work of Le refined the control on ")#mi("{f_1}")#text(" so that one still has good control when restricting to primes, or constant multiples of primes.")

#text("Ignoring the small error ")#mi("{f_2(a)}")#text(", we can now combine ")#link(<tao-d15198de14ea4414efff>)[#text("(5)")]#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("f(a) \\approx (-1)^k f_1(ap).")]]

#text("Using the equidistribution theory of nilsequences (as developed in ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("this previous paper of Ben Green and myself")]#text("), one can break up ")#mi("{f_1}")#text(" further into a periodic piece ")#mi("{f_0}")#text(" and an “irrational” or “minor arc” piece ")#mi("{f_3}")#text(". The contribution of the minor arc piece ")#mi("{f_3}")#text(" can be shown to mostly cancel itself out after dilating by primes ")#mi("{p}")#text(" and averaging, thanks to Vinogradov-type bilinear sum estimates (transferred to the primes). So we end up with")

#align(center)[#tao-fit-display[#mitex("f(a) \\approx (-1)^k f_0(ap),")]]

#text("which already shows (heuristically, at least) the claim that ")#mi("{f}")#text(" can be approximated by periodic functions ")#mi("{f_0}")#text(" which are isotopic in the sense that")

#align(center)[#tao-fit-display[#mitex("f_0(a) \\approx (-1)^k f_0(ap).")]]

#text("But if ")#mi("{k}")#text(" is odd, one can use Dirichlet’s theorem on primes in arithmetic progressions to restrict to primes ")#mi("{p}")#text(" that are ")#mi("{1}")#text(" modulo the period of ")#mi("{f_0}")#text(", and conclude now that ")#mi("{f_0}")#text(" vanishes identically, which (heuristically, at least) gives ")#link(<tao-ec005930dcb5b5eaa6f0>)[#text("(2)")]#text(".")

#text("The same sort of argument works to give the more general bounds on correlations of bounded multiplicative functions. But for the specific task of proving ")#link(<tao-ec005930dcb5b5eaa6f0>)[#text("(2)")]#text(", we initially used a slightly different argument that avoids using the ergodic theory machinery of Bergelson-Host-Kra, Leibman, and Le, but replaces it instead with the Gowers uniformity norm theory used to count linear equations in primes. Basically, by averaging ")#link(<tao-c80bd9c790fd1e2bffe5>)[#text("(4)")]#text(" in ")#mi("{p}")#text(" using the “")#mi("{W}")#text("-trick”, as well as known facts about the Gowers uniformity of the von Mangoldt function, one can obtain an approximation of the form")

#align(center)[#tao-fit-display[#mitex("(-1)^k f(a) \\approx {\\bf E}_{b: (b,W)=1} f(ab)")]]

#text("where ")#mi("{b}")#text(" ranges over a large range of integers coprime to some primorial ")#mi("{W = \\prod_{p \\leq w} p}")#text(". On the other hand, by iterating ")#link(<tao-c80bd9c790fd1e2bffe5>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("f(a) \\approx f(apq)")]]

#text("for most semiprimes ")#mi("{pq}")#text(", and by again averaging over semiprimes one can obtain an approximation of the form")

#align(center)[#tao-fit-display[#mitex("f(a) \\approx {\\bf E}_{b: (b,W)=1} f(ab).")]]

#text("For ")#mi("{k}")#text(" odd, one can combine the two approximations to conclude that ")#mi("{f(a)=0}")#text(". (This argument is not given in the current paper, but we plan to detail it in a subsequent one.)")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/#comment-484839")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("Are these (logarithmically averaged) correlation results sufficiently strong (or at least have the potential) to imply some improvement to the known zero-free region for the zeta function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/#comment-484843")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("No, in fact the causality goes the other way: we use existing zero free regions to conclude a tiny improvement over the trivial bounds for various correlation estimates (well, actually, in the current paper we don’t do this, but my previous work on two-point correlations uses the Matomaki-Radziwill theorem, which when applied to the Liouville function needs a Vinogradov type zero free region). But the gain is of iterated logarithmic type and is too weak to circle back to say anything about zeroes (probably one would need something closer to a power savings for this).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/#comment-484957")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2017")])]

#text("Okay, I’m trying to translate this into terms that I’m slightly more familiar with — please let me know if I’m completely off base.")

#text("The Furstenberg correspondence in this case is basically saying that you have something like a Fourier transform for multiplicative functions — different measure, and instead of R or C, we have Z^+ — but you can still say things like “The Fourier transform of a convolution is the product of the Fourier transforms of the components”.")

#text("You then use a “basic” argument to show that the odd moments of the Fourier transform of \\lambda(n) have to vanish by symmetry. That’s the stuff regarding f_0, I think. Then you have to show that throwing in arbitrary phases into the moment calculation doesn’t throw things off — is that the minor arc?")

#text("I’m trying to figure out how to translate your even-length correlation results into these terms.")

#text("Please let me know if this is even remotely accurate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Odd order cases of of the logarithmically averaged Chowla conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/#comment-487025")[#strong[#text("Odd order cases of of the logarithmically averaged Chowla conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2017")])]

#text("[…] to J. Numb. Thy. Bordeaux. This paper gives an alternate route to one of the main results of our previous paper, and more specifically reproves the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged and non-logarithmically averaged Chowla conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/#comment-487853")[#strong[#text("The logarithmically averaged and non-logarithmically averaged Chowla conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("[…] the logarithmically averaged Chowla conjecture; in this paper of mine I had proven (2) for , and in this recent paper with Joni Teravainen, we proved the conjecture for all odd (with a different proof also given […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of correlations of multiplicative functions at almost all scales, with applications to the Chowla and Elliott conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/#comment-504730")[#strong[#text("The structure of correlations of multiplicative functions at almost all scales, with applications to the Chowla and Elliott conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2018")])]

#text("[…] all scales, with applications to the Chowla and Elliott conjectures“. This is a sequel to our previous paper that studied logarithmic correlations of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/#comment-508357")[#strong[#text("Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("[…] particular bound also follows from some slightly different arguments of Joni Teravainen and myself, but the implication would also work for other non-pretentious […]")
]
