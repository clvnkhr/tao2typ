// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:37:44.127972+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A nonstandard analysis proof of Szemeredi’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A nonstandard analysis proof of Szemeredi’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 July 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/")[#text("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(" asserts that any subset of the integers of positive upper density contains arbitrarily large arithmetic progressions. Here is an equivalent quantitative form of this theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Szemerédi’s theorem)")]#text(" ")#metadata(none) <tao-8651347d5d501956a468>#text(" Let ")#mi("{N}")#text(" be a positive integer, and let ")#mi("{f: {\\bf Z}/N{\\bf Z} \\rightarrow [0,1]}")#text(" be a function with ")#mi("{{\\bf E}_{x \\in {\\bf Z}/N{\\bf Z}} f(x) \\geq \\delta}")#text(" for some ")#mi("{\\delta>0}")#text(", where we use the averaging notation ")#tao-math("{{\\bf E}_{x \\in A} f(x) := \\frac{1}{\\left|A\\right|} \\sum_{x \\in A} f(x)}", block: false)#text(", ")#tao-math("{{\\bf E}_{x,r \\in A} f(x) := \\frac{1}{\\left|A\\right|^2} \\sum_{x, r \\in A} f(x)}", block: false)#text(", etc.. Then for ")#mi("{k \\geq 3}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{x,r \\in {\\bf Z}/N{\\bf Z}} f(x) f(x+r) \\dots f(x+(k-1)r) \\geq c(k,\\delta)")]]

#text("for some ")#mi("{c(k,\\delta)>0}")#text(" depending only on ")#mi("{k,\\delta}")#text(".")
]

#text("The equivalence is basically thanks to an averaging argument ")#link("http://www.ams.org/mathscinet-getitem?mr=76797")[#text("of Varnavides")]#text("; see for instance Chapter 11 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(" or ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("this previous blog post")]#text(" for a discussion. We have removed the cases ")#mi("{k=1,2}")#text(" as they are trivial and somewhat degenerate.")

#text("There are now many proofs of this theorem. Some time ago, I took an ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("ergodic-theoretic proof of Furstenberg")]#text(" and converted it to a ")#link("http://www.ams.org/mathscinet-getitem?mr=2274314")[#text("purely finitary proof of the theorem")]#text(". The argument used some simplifying innovations that had been developed since the original work of Furstenberg (in particular, deployment of the Gowers uniformity norms, as well as a “dual” norm that I called the uniformly almost periodic norm, and an emphasis on van der Waerden’s theorem for handling the “compact extension” component of the argument). But the proof was still quite messy. However, as ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("discussed in this previous blog post")]#text(", messy finitary proofs can often be cleaned up using nonstandard analysis. Thus, there should be a nonstandard version of the Furstenberg ergodic theory argument that is relatively clean. I decided (after some encouragement from Ben Green and Isaac Goldbring) to write down most of the details of this argument in this blog post, though for sake of brevity I will skim rather quickly over arguments that were already discussed at length in other blog posts. In particular, I will presume familiarity with nonstandard analysis (in particular, the notion of a standard part of a bounded real number, and the Loeb measure construction), see for instance ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(" for a discussion.")

#metadata(none) <tao-9e23b938c45ffd1fda7e>

#text("By routine “compactness and contradiction” arguments (as discussed in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous post")]#text("), Theorem ")#link(<tao-8651347d5d501956a468>)[#text("1")]#text(" can be deduced from the following nonstandard variant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" ")#metadata(none) <tao-f0c3d8d967c9ccb2185d>#text(" Let ")#mi("{N}")#text(" be a nonstandard positive integer, let ")#mi("{X}")#text(" be the nonstandard cyclic group ")#mi("{{}^*{\\bf Z}/N^*{\\bf Z}}")#text(", and let ")#mi("{f: X \\rightarrow {}^*[0,1]}")#text(" be an internal function with ")#mi("{\\text{st} \\mathop{\\bf E}_{x \\in X} f(x) > 0}")#text(". Then for any standard ")#mi("{k \\geq 3}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\text{st} \\mathop{\\bf E}_{x,r \\in X} f(x) f(x+r) \\dots f(x+(k-1)r) > 0.")]]

#text("Here of course the averaging notation is interpreted internally.")
]

#text("Indeed, if Theorem ")#link(<tao-8651347d5d501956a468>)[#text("1")]#text(" failed, one could create a sequence of functions ")#mi("{f_n: {\\bf Z}/N_n{\\bf Z} \\rightarrow [0,1]}")#text(" of density at least ")#mi("{\\delta>0}")#text(" for some fixed ")#mi("{\\delta}")#text(", and a fixed ")#mi("{k}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{x,r \\in {\\bf Z}/N_n{\\bf Z}} f_n(x) f_n(x+r) \\dots f_n(x+(k-1)r) \\rightarrow 0;")]]

#text("taking ultralimits one can then soon obtain a counterexample to Theorem ")#link(<tao-f0c3d8d967c9ccb2185d>)[#text("2")]#text(".")

#text("It remains to prove Theorem ")#link(<tao-f0c3d8d967c9ccb2185d>)[#text("2")]#text(". Henceforth ")#mi("{N}")#text(" is a fixed nonstandard positive integer, and ")#mi("{X := {}^* {\\bf Z}/N{}^* {\\bf Z}}")#text(". By the Loeb measure construction (discussed in ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text("), one can give ")#mi("{X}")#text(" the structure of a probability space ")#mi("{(X, {\\mathcal L}_X, \\mu)}")#text(" (the ")#emph[#text("Loeb space")]#text(" of ")#mi("{X}")#text("), such that every internal subset ")#mi("{A}")#text(" of ")#mi("{X}")#text(" is (Loeb) measurable with")

#align(center)[#tao-fit-display[#tao-math("\\mu(A) = \\text{st} \\frac{\\left|A\\right|}{\\left|X\\right|},", block: true)]]

#text("which implies that any bounded internal function ")#mi("{f: X \\rightarrow {}^*{\\bf R}}")#text(" has standard part ")#mi("{\\text{st} f}")#text(" which is (Loeb) measurable with")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\mu = \\text{st} {\\bf E}_{x \\in X} f(x)\\ dx.")]]

#text("Conversely, a countable saturation argument shows that any function in ")#mi("{L^\\infty(X)}")#text(" is equal almost everywhere to the standard part of a bounded internal function.")

#text("From Hölder’s inequality we see that the ")#mi("{k}")#text("-linear form")

#align(center)[#tao-fit-display[#mitex("\\text{st} \\mathop{\\bf E}_{x,r \\in X} f_0(x) f_1(x+r) \\dots f_{k-1}(x+(k-1)r)")]]

#text("vanishes if one of the ")#mi("{f_i}")#text(" has standard part vanishing almost everywhere. As such, we can (by abuse of notation) extend this ")#mi("{k}")#text("-linear form to functions ")#mi("{f_0,\\dots,f_{k-1}}")#text(" that are elements of ")#mi("{L^\\infty(X)}")#text(", rather than bounded internal functions. With this convention, we see that Theorem ")#link(<tao-f0c3d8d967c9ccb2185d>)[#text("2")]#text(" is equivalent to the following assertion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" ")#metadata(none) <tao-c0f1f943df6f60489b19>#text(" For any non-negative ")#mi("{f \\in L^\\infty(X,\\mu)}")#text(" with ")#mi("{\\int_X f\\ d\\mu > 0}")#text(", one has for any standard ")#mi("{k \\geq 3}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\text{st} \\mathop{\\bf E}_{x,r \\in X} f(x) f(x+r) \\dots f(x+(k-1)r) > 0.")]]
]

#text("The next step is to introduce the ")#emph[#text("Gowers-Host-Kra uniformity seminorms")]#text(" ")#tao-math("{\\left\\|f\\right\\|_{U^d(X)}}", block: false)#text(", defined for ")#mi("{f \\in L^\\infty(X)}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f \\right\\|_{U^d(X)}^{2^d} := \\text{st} {\\bf E}_{x,h_1,\\dots,h_d \\in X} \\prod_{\\omega \\in \\{0,1\\}^d} F(x+\\omega_1 h_1 + \\dots + \\omega_d h_d)", block: true)]]

#text("where ")#mi("{F}")#text(" is any bounded internal function whose standard part equals ")#mi("{f}")#text(" almost everywhere. From Hölder’s inequality one can see that the exact choice of ")#mi("{F}")#text(" does not matter, so that this seminorm is well-defined. (It is indeed a seminorm, but we will not need this fact here.)")

#text("We have the following application of the van der Corput inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Generalised von Neumann theorem)")]#text(" Let ")#mi("{k \\geq 3}")#text(" be standard. For any ")#mi("{f_0,\\dots,f_{k-1} \\in L^\\infty(X,\\mu)}")#text(" with ")#tao-math("{\\left\\|f_i\\right\\|_{U^{k-1}(X)}=0}", block: false)#text(" for some ")#mi("{i=0,\\dots,k-1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\text{st} \\mathop{\\bf E}_{x,r \\in X} f_0(x) f_1(x+r) \\dots f_k(x+(k-1)r) = 0.")]]
]

#text("This estimate is proven in numerous places in the literature (e.g. Lemma 11.4 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(", or Exercise 23 of ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("this blog post")]#text(") and will not be repeated here. In particular, from multilinearity we see that ")#metadata(none) <tao-f284bdc3c1c9e24a494e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\text{st} \\mathop{\\bf E}_{x,r \\in X} f(x) f(x+r) \\dots f(x+(k-1)r) = \\text{st} \\mathop{\\bf E}_{x,r \\in X} g(x) g(x+r) \\dots g(x+(k-1)r)")]]

#text("whenever ")#mi("{f,g \\in L^\\infty(X)}")#text(" with ")#tao-math("{\\left\\|f-g\\right\\|_{U^{k-1}(X)} = 0}", block: false)#text(".")

#text("Dual to the Gowers norms ")#mi("{U^{k-1}(X)}")#text(" are the uniformly almost periodic norms ")#mi("{UAP^{k-2}(X)}")#text(". Let us first define the internal version of these norms. We define ")#mi("{{}^* UAP^0(X)}")#text(" to be the space of constant internal functions ")#mi("{f: x \\mapsto c}")#text(", with internal norm ")#tao-math("{\\left\\|f\\right\\|_{{}^* UAP^0(X)} = \\left|c\\right|}", block: false)#text(". Once ")#mi("{{}^* UAP^d(X)}")#text(" is defined for some ")#mi("{d \\geq 0}")#text(", we define ")#mi("{{}^* UAP^{d+1}(X)}")#text(" to be the internal normed vector space of internal functions ")#mi("{f: X \\rightarrow {}^* {\\bf R}}")#text(" for which there exists a nonstandard real number ")#mi("{M}")#text(", an internally finite non-empty set ")#mi("{H}")#text(", an internal family ")#mi("{h \\mapsto g_h}")#text(" of internal functions ")#mi("{g_h: X \\rightarrow {}^* {\\bf R}}")#text(" bounded in magnitude by one for each ")#mi("{h \\in H}")#text(", and an internal family ")#mi("{(n,h) \\mapsto c_{n,h}}")#text(" of internal functions ")#mi("{c_{n,h}: X \\rightarrow {}^* {\\bf R}}")#text(" in the unit ball of ")#mi("{{}^* UAP^d(X)}")#text(" such that one had the representation")

#align(center)[#tao-fit-display[#mitex("T^n f = M {\\bf E}_{h \\in H} c_{n,h} g_h")]]

#text("for all ")#mi("{n \\in X}")#text(", where ")#mi("{T^n f(x) := f(x+n)}")#text(" is the shift of ")#mi("{f}")#text(" by ")#mi("{n}")#text(". The internal infimum of all such ")#mi("{M}")#text(" is then the ")#mi("{{}^* UAP^{d+1}(X)}")#text(" norm of ")#mi("{f}")#text(". This gives each of the ")#mi("{{}^* UAP^d(X)}")#text(" the structure of an internal shift-invariant Banach algebra; see Section 5 of ")#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/\\href")[#text("\\href")]#text(". The ")#mi("{{}^* UAP^d(X)}")#text(" norms also controlled the supremum norm:")

#align(center)[#tao-fit-display[#tao-math("\\sup_{x \\in X} \\left|f(x)\\right| \\leq \\left\\|f\\right\\|_{{}^* UAP^d(X)}.", block: true)]]

#text("In particular, if we write ")#mi("{UAP^d(X)}")#text(" for the space of standard parts of internal functions of bounded norm in ")#mi("{{}^* UAP^d(X)}")#text(", then ")#mi("{UAP^d(X)}")#text(" is an (external) Banach algebra contained (as a real vector space) in ")#mi("{L^\\infty(X)}")#text(". For ")#mi("{d \\geq 1}")#text(", we can then define a factor ")#mi("{Z^{d-1}(X)}")#text(" of ")#mi("{X}")#text(" to be the probability space ")#mi("{Z^{d-1}(X) = (X, {\\mathcal Z}^{d-1}(X), \\mu)}")#text(", where ")#mi("{{\\mathcal Z}^{d-1}(X)}")#text(" is the subalgebra of ")#mi("{{\\mathcal L}_X}")#text(" consisting of those sets ")#mi("{E}")#text(" such that ")#mi("{1_E}")#text(" lies in the ")#mi("{L^2}")#text(" closure of ")#mi("{UAP^d(X)}")#text(". This is easily seen to be a shift-invariant ")#mi("{\\sigma}")#text("-algebra, and so ")#mi("{Z^{d-1}(X)}")#text(" is a factor.")

#text("We have the following key ")#emph[#text("characteristic factor")]#text(" relationship:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(" Let ")#mi("{f \\in L^\\infty(X)}")#text(" with ")#mi("{{\\bf E}(f|Z^{k-2}(X))=0}")#text(". Then ")#tao-math("{\\left\\|f\\right\\|_{U^{k-1}(X)} = 0}", block: false)#text(".")
]

#text("In fact the converse implication is true also (making ")#mi("{Z^{k-2}(X)}")#text(" the ")#emph[#text("universal characteristic factor")]#text(" for the ")#mi("{U^{k-1}(X)}")#text(" seminorm), but we will not need this direction of the implication.")

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#tao-math("{\\left\\|f\\right\\|_{U^{k-1}(X)} > 0}", block: false)#text("; we can normalise ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(X)} \\leq 1}", block: false)#text(". Writing ")#mi("{f = \\text{st} F}")#text(" for some bounded internal ")#mi("{F}")#text(", we then see that ")#mi("{f}")#text(" has a non-zero inner product with ")#mi("{\\text{st} {\\mathcal D}_{k-2} F}")#text(", where the ")#emph[#text("dual function")]#text(" ")#mi("{{\\mathcal D}_d F: X \\rightarrow {}^* {\\bf R}}")#text(" for ")#mi("{d \\geq 0}")#text(" is the bounded internal function")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_d F(x) := {\\bf E}_{h_1,\\dots,h_d \\in X} \\prod_{\\omega \\in \\{0,1\\}^d \\backslash \\{0\\}^d} F(x+\\omega_1 h_1 + \\dots + \\omega_d h_d).")]]

#text("From the easily verified identity")

#align(center)[#tao-fit-display[#mitex("T^n {\\mathcal D}_d F(x) = {\\bf E}_{h \\in X} {\\mathcal D}_{d-1}(T^n f T^h f) T^h f")]]

#text("and a routine induction, we see that ")#mi("{{\\mathcal D}_d F}")#text(" lies in the unit ball of ")#mi("{{}^* UAP^d(X)}")#text(", and so ")#mi("{\\text{st} {\\mathcal D}_d F}")#text(" is measurable with respect to ")#mi("{Z^{k-2}(X)}")#text(". By hypothesis this implies that ")#mi("{f}")#text(" is orthogonal to ")#mi("{\\text{st} {\\mathcal D}_d F}")#text(", a contradiction. ")#mi("\\Box")

#text("In view of the above theorem and ")#link(<tao-f284bdc3c1c9e24a494e>)[#text("(1)")]#text(", we may replace ")#mi("{f}")#text(" by ")#mi("{{\\bf E}(f|Z^{k-2}(X))}")#text(" without affecting the average in Theorem ")#link(<tao-c0f1f943df6f60489b19>)[#text("3")]#text(". Thus that theorem is equivalent to the following.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6")]#text(" ")#metadata(none) <tao-6f7e6f9a97421961fcda>#text(" Let ")#mi("{d \\geq 0}")#text(" and ")#mi("{k \\geq 1}")#text(" be standard. Then for any non-negative ")#mi("{f \\in L^\\infty(Z^d(X))}")#text(" with ")#mi("{\\int_X f\\ d\\mu > 0}")#text(", one has ")#metadata(none) <tao-50281f1fba4985733222>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\text{st} \\mathop{\\bf E}_{x,r \\in X} f(x) f(x+r) \\dots f(x+(k-1)r) > 0.")]]
]

#text("We only apply this theorem in the case ")#mi("{k \\geq 3}")#text(" and ")#mi("{d = k-2}")#text(", but for inductive purposes it is convenient to decouple the two parameters.")

#text("We prove Theorem ")#link(<tao-6f7e6f9a97421961fcda>)[#text("6")]#text(" by induction on ")#mi("{d}")#text(" (allowing ")#mi("{k}")#text(" to be arbitrary). When ")#mi("{d=0}")#text(", the claim is obvious for any ")#mi("{k}")#text(" because all functions in ")#mi("{L^\\infty(Z^0(X))}")#text(" are essentially constant. Now suppose that ")#mi("{d \\geq 1}")#text(" and that the claim has already been proven for ")#mi("{d-1}")#text(".")

#text("Let ")#mi("{f \\in L^\\infty(Z^d(X))}")#text(" be a nonnegative function whose mean ")#mi("{\\delta := \\int_X f\\ d\\mu}")#text(" is positive; we may normalise ")#mi("{f}")#text(" to take values in ")#mi("{[0,1]}")#text(". Let ")#mi("{k \\geq 1}")#text(" be standard, and let ")#mi("{\\varepsilon>0}")#text(" be a sufficiently small standard quantity depending on ")#mi("{k,\\delta}")#text(" to be chosen later (one could for instance take ")#mi("{\\varepsilon := \\frac{\\delta^{10k}}{10 k^{10}}}")#text(", but we will not attempt to optimise in ")#mi("{\\varepsilon}")#text("). As ")#mi("{f}")#text(" is ")#mi("{Z^d(X)}")#text("-measurable, one can find an internal function ")#mi("{F: X \\rightarrow {}^* {\\bf R}}")#text(" with ")#mi("{0 \\leq F \\leq 1}")#text(" and bounded ")#mi("{{}^* UAP^d(X)}")#text(" norm such that ")#tao-math("{\\left\\|f-\\text{st} F\\right\\|_{L^1(X)} \\leq \\varepsilon}", block: false)#text(". (Note though that while the ")#mi("{{}^* UAP^d(X)}")#text(" norm of ")#mi("{F}")#text(" is bounded, this bound could be extremely large compared to ")#mi("{k}")#text(", ")#mi("{1/\\delta}")#text(", ")#mi("{1/\\varepsilon}")#text(".)")

#text("Set ")#mi("{Y := Z^{d-1}(X)}")#text(". We define the relative inner product ")#mi("{\\langle f, g \\rangle_{L^2(X|Y)} \\in L^\\infty(Y)}")#text(" for ")#mi("{f,g \\in L^\\infty(X)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f,g \\rangle_{L^2(X|Y)} := {\\bf E}(f g|Y)")]]

#text("and the relative norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^2(X|Y)} := \\langle f,f \\rangle_{L^2(X|Y)}^{1/2}.", block: true)]]

#text("This gives ")#mi("{L^\\infty(X)}")#text(" the structure of a (pre-)")#link("https://en.wikipedia.org/wiki/Hilbert_C*-module")[#text("Hilbert module")]#text(" over ")#mi("{L^\\infty(Y)}")#text(", as discussed in ")#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("this previous blog post")]#text(".")

#text("A crucial point is that the function ")#mi("{F}")#text(" is ")#emph[#text("relatively almost periodic")]#text(" over the previous characteristic factor ")#mi("{Y}")#text(", in the following sense.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Relative almost periodicity)")]#text(" ")#metadata(none) <tao-f7c465019a477431771a>#text(" There exists a standard natural number ")#mi("{m}")#text(" and functions ")#mi("{q_1,\\dots,q_m}")#text(" in the unit ball of ")#mi("{L^\\infty(X)}")#text(" with the following “relative total boundedness” property: for any ")#mi("{n \\in X}")#text(", there exists a ")#mi("{Y}")#text("-measurable function ")#mi("{i: X \\rightarrow \\{1,\\dots,m\\}}")#text(" such that ")#tao-math("{\\left\\| \\text{st} T^n F - q_i \\right\\|_{L^2(X|Y)} \\leq \\varepsilon}", block: false)#text(" almost everywhere (where ")#mi("{q_i(x)}")#text(" is short-hand for ")#mi("{\\sum_{j=1}^m q_j(x) 1_{i(x)=j}}")#text(").")
]

#emph[#text("Proof:")]#text(" This will be a relative version of the standard analysis fact that integral operators on finite measure spaces with bounded kernel are in the Hilbert-Schmidt class, and thus compact.")

#text("By construction, there exists an internally finite non-empty set ")#mi("{H}")#text(", an internal collection ")#mi("{h \\mapsto g_h}")#text(" of internal functions ")#mi("{g_h: X \\rightarrow {}^* {\\bf R}}")#text(" that are uniformly bounded in ")#mi("{h}")#text(", and an internal collection ")#mi("{(n,h) \\mapsto c_{n,h}}")#text(" of internal functions ")#mi("{c_{n,h}: X \\rightarrow {}^* {\\bf R}}")#text(" that are uniformly bounded in ")#mi("{{}^* UAP^{d-1}(X)}")#text(", such that ")#metadata(none) <tao-5c3a6d6ae233f4b1e47d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("T^n F = {\\bf E}_{h \\in H} c_{n,h} g_h")]]

#text("for all ")#mi("{n \\in X}")#text(". Note in particular that the ")#mi("{\\text{st} c_{n,h}}")#text(" all lie in a bounded subset of ")#mi("{L^\\infty(Y)}")#text(", and the ")#mi("{g_h}")#text(" all lie in a bounded subset of ")#mi("{L^\\infty(X)}")#text(".")

#text("We give ")#mi("{Y \\times H}")#text(" the ")#mi("{\\sigma}")#text("-algebra generated from the standard parts of bounded internal functions ")#mi("{(x,h) \\mapsto f(x,h)}")#text(" such that the standard parts of ")#mi("{x \\mapsto f(x,h)}")#text(" all lie in a bounded subset of ")#mi("{L^\\infty(Y)}")#text("; this gives a probability space that extends the product measure of ")#mi("{Y}")#text(" and ")#mi("{H}")#text(". We define an operator ")#mi("{S: L^\\infty(Y \\times H) \\rightarrow L^\\infty(X)}")#text(" as follows. If ")#mi("{b \\in L^\\infty(Y \\times H)}")#text(", then ")#mi("{b}")#text(" is the standard part of some bounded internal function ")#mi("{B: Y \\times H \\rightarrow {}^* {\\bf R}}")#text(". We then define ")#mi("{Sb}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("Sb(x) := \\text{st} {\\bf E}_{h \\in H} B(x,h) g_h(x).")]]

#text("This can easily be seen to not depend on the choice of ")#mi("{B}")#text(", and ")#mi("{S}")#text(" defines a ")#mi("{L^\\infty(Y)}")#text("-linear operator (embedding ")#mi("{L^\\infty(Y)}")#text(" into both ")#mi("{L^\\infty(Y \\times H)}")#text(" and ")#mi("{L^\\infty(X)}")#text(" in the obvious fashion). Note that ")#mi("{T^n f}")#text(" lies in the range of ")#mi("{S}")#text(" applied to a function in the unit ball of ")#mi("{L^\\infty(Y \\times H)}")#text(".")

#text("Now we claim that this operator is ")#emph[#text("relatively Hilbert-Schmidt")]#text(" over ")#mi("{L^\\infty(Y)}")#text(", in the sense that there exists a finite bound ")#mi("{A}")#text(" such that ")#metadata(none) <tao-dedc571ce5aec0914c42>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| ( \\sum_{m=1}^M \\sum_{n=1}^N \\langle S e_m, f_n \\rangle_{L^2(X|Y)}^2 )^{1/2} \\right\\|_{L^\\infty(Y)} \\leq A", block: true)]]

#text("for all finite collections ")#mi("{e_m \\in L^\\infty(Y \\times H), f_n \\in L^\\infty(X)}")#text(" of functions that are relatively orthonormal over ")#mi("{L^\\infty(Y)}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\langle e_m, e_{m^{\\prime}} \\rangle_{L^2(Y\\times H|Y)} = 1_{m=m^{\\prime}}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\langle f_n, f_{n^{\\prime}} \\rangle_{L^2(X|Y)} = 1_{n=n^{\\prime}}")]]

#text("for all ")#mi("{1 \\leq m,m^{\\prime} \\leq M}")#text(" and ")#mi("{1 \\leq n,n^{\\prime} \\leq N}")#text(". Indeed, the left-hand side of ")#link(<tao-dedc571ce5aec0914c42>)[#text("(4)")]#text(" may be expanded first as")

#align(center)[#tao-fit-display[#mitex("\\int_Y \\sum_{m=1}^M \\sum_{n=1}^N a_{m,n} \\langle S e_m, f_n \\rangle")]]

#text("for some sequence ")#mi("{a_{m,n}}")#text(" in ")#mi("{L^\\infty(Y)}")#text(" with ")#tao-math("{\\sum_{m,n} \\left\\| a_{m,n} \\right\\|_{L^2(Y)}^2 = 1}", block: false)#text(", and then as")

#align(center)[#tao-fit-display[#mitex("\\int_{X \\times H} \\sum_{m=1}^M \\sum_{n=1}^N a_{m,n} e_m f_n g")]]

#text("where we use Loeb measure on ")#mi("{X \\times H}")#text(" and ")#mi("{g \\in L^\\infty(X \\times H)}")#text(" is the function ")#mi("{g(x,h) := \\text{st} g_h(x)}")#text(", and ")#mi("{a_{m,n}, e_m, f_n}")#text(" are lifted up to ")#mi("{L^\\infty(X \\times H)}")#text(" in the obvious fashion. By Cauchy-Schwarz and the boundedness of ")#mi("{g}")#text(", we can bound this by")

#align(center)[#tao-fit-display[#tao-math("A \\left\\| \\left\\|\\sum_{m=1}^M \\sum_{n=1}^N a_{m,n} e_m f_n \\right\\|_{L^2(X \\times H|Y)} \\right\\|_{L^2(Y)},", block: true)]]

#text("But the ")#mi("{e_m f_n}")#text(" are relatively orthonormal over ")#mi("{L^\\infty(Y)}")#text(" (this reflects the relative orthogonality of ")#mi("{Y \\times H}")#text(" and ")#mi("{X}")#text(" over ")#mi("{Y}")#text("), so that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\sum_{m=1}^M \\sum_{n=1}^N a_{m,n} e_m f_n \\right\\|_{L^2(X \\times H|Y)} = (\\sum_{m=1}^M \\sum_{n=1}^N a_{m,n}^2)^{1/2}", block: true)]]

#text("and the claim follows from the hypotheses on ")#mi("{a}")#text(".")

#text("Using the relative spectral theorem for relative Hilbert-Schmidt operators (see Corollary 17 of ")#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/")[#text("this blog post")]#text("), we may thus find relatively orthonormal systems ")#mi("{e_n, f_n}")#text(" in ")#mi("{L^\\infty(Y \\times H)}")#text(" and ")#mi("{L^\\infty(X)}")#text(" respectively over ")#mi("{L^\\infty(Y)}")#text(" and a non-increasing sequence of non-negative coefficients ")#mi("{\\sigma_n \\in L^\\infty(Y)}")#text(" (the relative singular values) with ")#mi("{\\sum_n \\sigma_n^2 \\leq A^2}")#text(" almost everywhere, such that we have the spectral decomposition")

#align(center)[#tao-fit-display[#mitex("Sb = \\sum_n \\sigma_n \\langle b, e_n \\rangle_{L^2(Y \\times H|Y)} f_n")]]

#text("wiht the sum converging in ")#mi("{L^2(X|Y)}")#text(". (If ")#mi("{X, Y, Y \\times H}")#text(" were standard Borel spaces, one could deduce this theorem from the usual spectral theorem for Hilbert-Schmidt operators using disintegration. Loeb spaces are certainly not standard Borel, but as discussed in the linked blog post above, one can adapt the ")#emph[#text("proof")]#text(" of the spectral theorem to the relative setting without using the device of disintegration.")

#text("Since ")#mi("{\\sum_n \\sigma_n^2 \\leq A^2}")#text(" and the ")#mi("{\\sigma_n}")#text(" are decreasing, one can find an ")#mi("{N}")#text(" such that ")#mi("{\\sigma_n \\leq \\varepsilon/2}")#text(" almost everywhere for all ")#mi("{n \\geq N}")#text(". For ")#mi("{b}")#text(" in the unit ball of ")#mi("{L^\\infty(Y \\times H)}")#text(", this lets one approximate ")#mi("{Sb}")#text(" by the finite rank operator ")#mi("{\\sum_{n \\leq N} \\sigma_n \\langle b, e_n \\rangle_{L^2(Y \\times H|Y)} f_n}")#text(" to within ")#mi("{\\varepsilon/2}")#text(" almost everywhere in ")#mi("{L^2(X|Y)}")#text(" norm. If one rounds ")#mi("{\\sigma_n \\langle b, e_n \\rangle_{L^2(Y \\times H|Y)}}")#text(" to the nearest multiple of ")#mi("{\\varepsilon/2N}")#text(" for each ")#mi("{y \\in Y}")#text(", and lets ")#mi("{q_1,\\dots,q_m}")#text(" be the collection of linear combinations of the form ")#mi("{\\sum_n c_n f_n}")#text(" with ")#mi("{c_n \\in [-1,1]}")#text(" a multiple of ")#mi("{\\varepsilon/2N}")#text(", we obtain the claim. ")#mi("\\Box")

#text("We return to the proof of ")#link(<tao-50281f1fba4985733222>)[#text("(2)")]#text(". Since ")#mi("{\\int_X f = \\delta}")#text(" and ")#tao-math("{\\left\\|f-\\text{st} F \\right\\|_{L^1(X)} \\leq \\varepsilon}", block: false)#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\int_Y \\mathop{\\bf E}( \\text{st} F | Y ) = \\int_X \\text{st} F \\geq \\delta/2")]]

#text("if ")#mi("{\\varepsilon}")#text(" is small enough. In particular there is a ")#mi("{Y}")#text("-measurable set ")#mi("{E^{\\prime}}")#text(" of measure at least ")#mi("{\\delta/4}")#text(" such that ")#mi("{\\mathop{\\bf E}( \\text{st} F | Y ) \\geq \\delta/4}")#text(" on ")#mi("{E^{\\prime}}")#text(". Since")

#align(center)[#tao-fit-display[#tao-math("\\int_Y \\mathop{\\bf E}( \\left| f - \\text{st} F \\right| | Y ) = \\left\\|f-\\text{st} F \\right\\|_{L^1(X)} \\leq \\varepsilon,", block: true)]]

#text("we see from Markov’s inequality (for small enough ")#mi("{\\varepsilon}")#text(") that there is a ")#mi("{Y}")#text("-measurable subset ")#mi("{E}")#text(" of ")#mi("{E^{\\prime}}")#text(" of measure at least ")#mi("{\\delta/8}")#text(" such that ")#metadata(none) <tao-032195745028aa5d9412>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|f - \\text{st} F \\right\\|_{L^1(X|Y)} = O_\\delta(\\varepsilon)", block: true)]]

#text("on ")#mi("{E}")#text(", where we write")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^1(X|Y)} := \\mathop{\\bf E}( \\left|f\\right| | Y )", block: true)]]

#text("for the relative ")#mi("{L^1}")#text(" norm. In particular we have ")#metadata(none) <tao-9c3aee7110b787f0fb5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\mathop{\\bf E}(f|Y) \\geq \\delta/8")]]

#text("almost everywhere on ")#mi("{E}")#text(".")

#text("Let ")#mi("{K}")#text(" be a sufficiently large standard natural number (depending on ")#mi("{\\delta,\\varepsilon,k}")#text(" and the quantity ")#mi("{m}")#text(" from Proposition ")#link(<tao-f7c465019a477431771a>)[#text("7")]#text("), in fact it will essentially be a van der Waerden number of these inputs) to be chosen later. Applying the induction hypothesis, we have")

#align(center)[#tao-fit-display[#mitex("\\text{st} \\mathop{\\bf E}_{x,r \\in X} 1_E(x) 1_E(x+r) \\dots 1_E(x+(K-1)r) > 0.")]]

#text("In particular, there is a standard ")#mi("{\\kappa > 0}")#text(", such that for ")#mi("{r}")#text(" in a subset of ")#mi("{X}")#text(" of measure at least ")#mi("{\\kappa}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\text{st} \\mathop{\\bf E}_{x \\in X} 1_E(x) 1_E(x+r) \\dots 1_E(x+(K-1)r) \\geq \\kappa")]]

#text("or equivalently that the set")

#align(center)[#tao-fit-display[#mitex("E_r := E \\cap (E-r) \\cap \\dots \\cap (E - (K-1)r)")]]

#text("has measure at least ")#mi("{\\kappa}")#text(".")

#text("Let ")#mi("{r}")#text(" be as above, and let ")#mi("{q_1,\\dots,q_m}")#text(" be the functions from Proposition ")#link(<tao-f7c465019a477431771a>)[#text("7")]#text(". Then for ")#mi("{j=0,\\dots,K-1}")#text(", we can find a measurable function ")#mi("{i_j: Y \\rightarrow \\{1,\\dots,m\\}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{st} T^{jr} F - q_{i_j} \\right\\|_{L^2(X|Y)} \\leq \\varepsilon", block: true)]]

#text("almost everywhere on ")#mi("{Y}")#text(", hence by ")#link(<tao-032195745028aa5d9412>)[#text("(5)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T^{jr} f - q_{i_j} \\right\\|_{L^1(X|Y)} \\ll_\\delta \\varepsilon", block: true)]]

#text("almost everywhere on ")#mi("{E_r}")#text(". From this and the relative Hölder inequality, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T^{ar} f T^{(a+b)r} f \\dots T^{(a+(k-1)b)r} f - q_{i_a} q_{i_{a+b}} \\dots q_{i_{a+(k-1)b}} \\right\\|_{L^1(X|Y)} \\ll_{\\delta,k} \\varepsilon", block: true)]]

#text("a.e. on ")#mi("{E_r}")#text(" whenever ")#mi("{0 \\leq a, b \\leq K/k}")#text(".")

#text("Now, for ")#mi("{K}")#text(" large enough, we see from van der Warden’s theorem that there exist measurable ")#mi("{a,b: Y \\rightarrow \\{1,\\dots,K/k\\}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("i_a = i_{a+b} = \\dots = i_{a+(k-1)b}")]]

#text("almost everywhere in ")#mi("{Y}")#text(", and hence in ")#mi("{E_r}")#text(" (this can be seen by partitioning ")#mi("{Y}")#text(" into finitely many pieces, with each of the ")#mi("{i_a}")#text(" constant on each of these pieces). For that choice of ")#mi("{a,b}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T^{ar} f T^{(a+b)r} f \\dots T^{(a+(k-1)b)r} f - q_{i_a}^k \\right\\|_{L^1(X|Y)} \\ll_{\\delta,k} \\varepsilon", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T^{ar} f T^{ar} f \\dots T^{ar} f - q_{i_a}^k \\right\\|_{L^1(X|Y)} \\ll_{\\delta,k} \\varepsilon", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}( T^{ar} f T^{(a+b)r} f \\dots T^{(a+(k-1)b)r} f | Y ) \\geq \\mathop{\\bf E}( (T^{ar} f)^k | Y) - O_{\\delta,k}(\\varepsilon)")]]

#text("almost everywhere on ")#mi("{E_r}")#text(". But from ")#link(<tao-9c3aee7110b787f0fb5f>)[#text("(6)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}( T^{ar} f | Y) \\geq \\delta/8")]]

#text("a.e. on ")#mi("{E_r}")#text(", so from Hölder’s inequality we have (for ")#mi("{\\varepsilon}")#text(" sufficiently small) that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}( T^{ar} f T^{(a+b)r} f \\dots T^{(a+(k-1)b)r} f | Y ) \\gg_{\\delta,k} 1.")]]

#text("From non-negativity of ")#mi("{f}")#text(", this implies that")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq i,j \\leq K/k} \\mathop{\\bf E}( T^{ir} fT^{(i+j)r}f \\dots T^{(i+(k-1)j)r} f|Y) \\gg_{\\delta,k} 1")]]

#text("which on integrating in ")#mi("{Y}")#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq i,j \\leq K/k} \\text{st} {\\bf E}_{x \\in X} f(x+ir) f(x+(i+j)r) \\dots f(x+(i+(k-1)j)r)")]]

#align(center)[#tao-fit-display[#mitex("\\gg_{\\delta,k} \\kappa.")]]

#text("Averaging in ")#mi("{r}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq i,j \\leq K/k} \\text{st} {\\bf E}_{x,r \\in X} f(x+ir) f(x+(i+j)r) \\dots f(x+(i+(k-1)j)r)")]]

#align(center)[#tao-fit-display[#mitex("\\gg_{\\delta,k} \\kappa^2.")]]

#text("Shifting ")#mi("{x}")#text(" by ")#mi("{ir}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq j \\leq K/k} \\text{st} {\\bf E}_{x,r \\in X} f(x) f(x+jr) \\dots f(x+(k-1)jr) \\gg_{\\delta,k,K,\\kappa} 1.")]]

#text("Dilating ")#mi("{r}")#text(" by ")#mi("{j}")#text(" (and noting that the map ")#mi("{x \\mapsto jx}")#text(" is at most ")#mi("{j}")#text("-to-one on ")#mi("{X}")#text("), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\text{st} {\\bf E}_{x,r \\in X} f(x) f(x+r) \\dots f(x+(k-1)r) \\gg_{\\delta,k,K,\\kappa} 1,")]]

#text("and ")#link(<tao-50281f1fba4985733222>)[#text("(2)")]#text(" follows.")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457548")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2015")])]

#text("Your notation in theorem 1 for the expected value over x, r is a bit ambiguous. I assume the average is still over x rather than r.")

#emph[#text("[Clarification added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Gasarch")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457562")[#strong[#text("William Gasarch")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2015")])]

#text("What is the easiest proof of Sz theorem known? Is it the one in this blog, or the elementary proof of DHJ, or something else? I know this depends on your definition of easy, so I admit I am asking for a discussion of the point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457582")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2015")])]

#text("My personal favorite is the proof using the hypergraph removal lemma, which nowadays has a reasonably simple (and elementary) proof, but the Furstenberg proof (which is not too far in spirit from the one given here) and the Polymath1 proof of density Hales-Jewett are certainly also quite simple and conceptual (though the Furstenberg proof would not be considered elementary, as for instance it uses measure theory and the spectral theorem). I suppose if one had to cover Szemeredi’s theorem (and ONLY this theorem) in as few lectures as possible to a class of beginning graduate students, the Polymath1 proof would be the fastest, though the other proofs are instructive in a number of other ways that would be useful beyond the narrow goal of proving Szemeredi’s theorem, and so there would be pedagogical advantages with using those proofs instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01e4ea68af866436baf5bbb168505e2c3fd7a3476786f26099f2547431611292-80ec4b0f9db4e1a2f9fcb487a35a57f6c6f9a83fe1c6935ed23c3e5d7097b1b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miklos Abert")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457580")[#strong[#text("Miklos Abert")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2015")])]

#text("I am confused. Can you clarify in what way this is significantly different from Balazs Szegedy’s approach to HOF? I am assuming you know his work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457581")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2015")])]

#text("They are similar in that they both use the Gowers norms and nonstandard analysis, but Szegedy’s approach is closer to Host-Kra’s work on characteristic factors and to my work with Green and Ziegler on the inverse conjecture for the Gowers norms, whereas the argument here is closer to the original arguments of Furstenberg (and Furstenberg-Katznelson-Ornstein) proving Szemeredi’s theorem. At a more technical level, the analysis here only uses the relatively easy fact that the ")#mi("k^{th}")#text(" Host-Kra factor is a compact extension of the ")#mi("(k-1)^{st}")#text(" factor, whereas the analysis of Host-Kra and Szegedy requires a much finer analysis of that extension (roughly, that it is an abelian extension by a cocycle obeying a certain “type equation”, which must then be solved for, or at least (in Szegedy’s approach) used to construct a topological nilspace which one then tries to classify). These are all overkill for the purposes of just proving Szemeredi’s theorem; the arguments of Szegedy or of Host-Kra (or of the more recent work of Gutman-Manners-Varju repairing and building upon Szegedy’s work) are significantly lengthier than those provided here, though they also provide much more precise information. (To give just one example, Furstenberg’s argument shows in a dynamical system that the averages ")#mi("\\frac{1}{N} \\sum_{n=1}^N \\int_X f T^n f \\dots T^{(k-1)n} f\\ d\\mu")#text(" are bounded below, but not that these averages converge to a limit; this latter fact was first proven in the above-mentioned work of Host and Kra using the advanced structure theory of characteristic factors that Szegedy later found nonstandard analogues of.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01e4ea68af866436baf5bbb168505e2c3fd7a3476786f26099f2547431611292-80ec4b0f9db4e1a2f9fcb487a35a57f6c6f9a83fe1c6935ed23c3e5d7097b1b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miklos Abert")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457600")[#strong[#text("Miklos Abert")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("Thanks, Terry! Your response clarifies a lot, but at the same time, it confuses me even more, for two reasons – I may be wrong in both of course.")

#text("1) Your theorems and notions above seem to be mostly byproducts of Szegedy’s already published work. You yourself hint at this when you call his work an overkill for the topic of this post. Simplifying and modifying other’s proofs can of course involve high level mathematics and can be very productive. Clearly, the community will benefit from your post. What confuses me here is that you fail to mention Szegedy’s name in it.")

#text("2) You write about the very recent and unpublished work of Gutman-Manners-Varju as something repairing Szegedy’s work. That is a strong word as it suggests that there are significant errors or gaps in Szegedy’s work. Are you aware of such? If yes, can you please clarify what they are? My understanding is that while the entry cost to Szegedy’s work on HOF is quite high, no one has found a concrete significant mistake or gap in it yet. Is that wrong?")

#text("Regards,")

#text("Miklos")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457613")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("As stated in my post, the proof here is essentially the nonstandard analysis translation of ")#link("http://arxiv.org/abs/math/0405251")[#text("my proof of Szemeredi’s theorem from 2004")]#text(". At the time, I had not learned nonstandard analysis, which I did ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("at around 2007")]#text("; I only got around to writing down a nonstandard translation of the argument because of some recent conversations with colleagues about the possibility of doing so. (This is not the first time that nonstandard translations of combinatorial arguments have been presented in this area; for instance, in 2007, ")#link("http://arxiv.org/abs/0711.1180")[#text("Towsner gave")]#text(" a nonstandard translation of an ergodic convergence result ")#link("http://arxiv.org/abs/0707.1117")[#text("of myself")]#text(" from earlier that year. I think the use of nonstandard methods in ergodic theory can be traced back to ")#link("http://www.ams.org/mathscinet-getitem?mr=682311")[#text("the 1982 paper of Kamae")]#text(" giving a nonstandard proof of the ergodic theorem via the Loeb measure construction.)")

#text("Of course, from about 2009 onwards, Szegedy also started to use nonstandard methods to attack related questions, such as the inverse conjecture for the Gowers norms. However, the methods described in this blog post go back much further than that, and can be largely traced back to the 1977 paper of Furstenberg (though with some simplifications using the Gowers-Host-Kra uniformity seminorms introduced by Gowers in 2001 and Host-Kra in 2005, as well as the uniform almost periodicity norms introduced in my 2004 paper).")

#text("Regarding the issue (involving a subtle distinction between the measurable and continuous nilspace categories) with the 2010 arXiv version of the paper with Camarena, this was confirmed to me as a problem by Balazs back in Nov 2010, and it should be fixable, but I don’t know if an updated version of this paper is available (perhaps Balazs himself could comment on the latest status).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457659")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2015")])]

#text("Let me reply to the correctness issue first.")

#text("In 2010 November, after I announced my version of the inverse theorem for the Gowers norms at the Szemeredi 70 conference, you and I had an")#linebreak()#text(" e-mail conversation on my paper with Camarena on nilspaces – this is the one that deals with the algebraic part of my theory. I indeed wrote you that I plan to add an extra chapter further clarifying the continuity issue related to cocycles, mainly because I wasn’t quite happy with the presentation myself. However, I never hinted at an error in the paper, because I was not aware of one. That is still the case. One can easily check on the later arxiv version (2012) that no major changes were done, just a more detailed writeup.")

#text("It is true that even the 2012 version is a very dense and abstract paper and would deserve an even more detailed exposition but up to my knowledge, no substantial mistake has been found yet. Let me spell it out: I am not aware of such mistakes and no one has contacted me about such. As with many long papers, there are a number of small mistakes and typos and weaknesses in the explanation.")

#text("Back to the issue of ultrafilters.")

#text("Of course Furstenberg was the sole major source of this line of work. However, in my opinion it was a rather non-trivial step to identify the right framework that allowed for a clean way of interpreting the classical notions of Furstenberg’s theory in higher order Fourier analysis. This framework is the ultra-product characteristic factor language that I introduced based on another non-trivial work by myself and Elek on hypergraph-regularity.")

#text("The identification of the unique characteristic factors on ultraproduct groups opened up a perspective that I could use e.g. to prove inverse theorems for the Gowers norms on arbitrary compact abelian groups. The existence of these unique sigma-algebras appear first in my H.O.F paper from 2009.")

#text("Following your logic, the hypergraph removal lemma that I proved with Elek and which follows easily from the Lebesgue density theorem in the nonstandard setting is just a translation. The problem with this point of view is, that often the real mathematical work is done exactly in these translations and the nonstandard setting requires very new ways to prove the same kind of theorem. The same phenomenon happens in HOF.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457661")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2015")])]

#text("To remind you of the issue with the paper which I previously sent to you (in my email of Nov 8, 2010), using the section numbering of the ")#link("http://arxiv.org/abs/1009.3825v3")[#text("2012 version of your paper with Camarena")]#text(":")

#text("In the first paragraph of Section 3.10 on Page 48, you write that “by abusing the notation” you ")#emph[#text("redefine")]#text(" the space ")#mi("Trans(N)")#text(" to denote the space of ")#emph[#text("continuous")]#text(" translations; previously, they were simply the space of translations without continuity hypotheses. Then, at the end of the proof of Lemma 3.23, you assert that “Lemma 3.19 and Lemma 2.1 finish the proof”. However, Lemma 2.1 is stated and proved for the category of nilspaces, not of continuous nilspaces. As such, it is not clear why the object ")#mi("\\beta")#text(" produced by Lemma 3.23 is continuous, as it ought to be to be consistent with the “abuse of notation”. Indeed, given that the section ")#mi("S")#text(" is merely Borel measurable rather than continuous, it is likely that the ")#mi("\\beta")#text(" produced by this argument is also only measurable instead of continuous. It does appear that you have added a result (Theorem 2) in the 2012 version that may help address this issue, but at a bare minimum one needs a version of Lemma 2.1 in the measurable category.")

#text("Regarding the ultraproduct setting, it is true that you were one of the first authors to clean up combinatorial arguments of Szemeredi type by working in the nonstandard setting, starting with your 2007 paper with Elek and then your later 2009 papers on higher order Fourier analysis. But there was parallel work by other authors; see for instance ")#link("http://arxiv.org/abs/0711.1180")[#text("this 2007 paper by Towsner")]#text(" translating a combinatorial argument of my own into the nonstandard setting. In 2009, Ben Green, Tamar Ziegler and I ")#link("http://arxiv.org/abs/0911.5681")[#text("gave a combinatorial proof of the U^4 inverse theorem")]#text(", and announced that the inverse theorem for higher U^k norms (which appeared ")#link("http://arxiv.org/abs/1009.3998")[#text("in 2010")]#text(") would use nonstandard analysis (see page 2 of the U^4 paper).")

#text("Without nonstandard analysis, the arguments are significantly less clean, but still doable. For instance the combinatorial analogue of characteristic factors was first introduced in my ")#link("http://arxiv.org/abs/math/0404188")[#text("2004 paper with Ben Green")]#text(" (see Footnote 8), then developed further in another ")#link("http://arxiv.org/abs/math/0405251")[#text("2004 paper of mine")]#text(" (see Remark 3.7). These combinatorial characteristic factors are not mere “analogues” of their nonstandard counterparts; they are logically equivalent through the transfer principle (roughly speaking, the nonstandard characteristic factor is generated by ultralimits of functions in the combinatorial characteristic factor). Similarly for the combinatorial and nonstandard versions of relative almost periodicity, the former of which appears in my 2004 paper, and the latter of which appears here and (essentially) in your HOF paper (although your formulation does not explicitly use the UAP norms that were one of the innovations of my 2004 paper, and which I continue to use in this blog post).")

#text("Your HOF paper did show that much of the Host-Kra machinery (e.g. the Furstenberg-Weiss reduction to abelian extensions and the Host-Kra type equation for cocycles, and the appearance of Host-Kra strong parallelepiped structures (which you call nilspaces)) could be extended to the nonstandard setting, and thus in principle to the combinatorial setting, and this had not been previously done in the literature. However, this machinery is not needed for the narrow goal of proving Szemeredi’s theorem, which is the focus of this blog post (and of the 2004 paper that it is based on).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457604")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("Hi Terry, following earlier comments I think I have a clarifying question here about this post.")

#text("The main idea in my approach to Higher Order Fourier analysis was to carry out the following program 1) Take the ultra product of finite abelian groups 2) Identify the characteristic factors for the Gowers (and Host-Kra) semi-norms 3) Give a number of equivalent but increasingly stronger descriptions for these characteristic factors leading to a structure theorem.")

#text("The cocycle theorem that you mention in your reply to Abert is one of these equivalent characterisations (of intermediate difficulty) however I have a number of easier ones expressing relative compactness. For example I prove that if you take the sigma algebra F_k and the Hilbert space of L^2 functions in it then it is linearly generated by finite rank shift invariant modules over the algebra of L^\\infty functions in F_{k-1}. The proof of this is tricky but not hard. My main question is: Is this equivalent with your “Relative almost periodicity” or maybe I misunderstand something.")

#text("Balazs")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("Yes, relative almost periodicity (in the sense of being expressible in terms of relatively Hilbert-Schmidt operators, or equivalently being relatively orthogonal to all relatively weakly mixing functions) is essentially the same concept (after applying the relative spectral theorem) as being approximable by finite rank modules over the base. This goes back (in the ergodic theory setting) to at least the original paper of Furstenberg, who called functions in the latter modules generalised eigenfunctions; see for instance Lemma 7.2 and Theorem 7.4 of ")#link("http://link.springer.com/article/10.1007%2FBF02813304")[#text("Furstenberg’s 1977 paper")]#text("; the concept is discussed in more detail in Furstenberg’s book, but I don’t have references to that handy at present. Using the Gowers-Host-Kra seminorms (and their duals) in place of the notion of relative weak mixing (and their duals) gives a slightly different tower of factors than Furstenberg’s factors (which is a tower of maximal compact extensions) but at least on the level of the analysis relating to relative almost periodicity, the structure is basically identical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457614")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("Ok, this clarifies a lot. I think you have to agree that these classical things have to be re-proved in the ultraproduct setting since this is a new framework (and you did that here). I just wanted to say that I also did that in my sequence of papers on higher order fourier analysis. I was less familiar with classical ergodic theory so I had less background but regardless of this I developed it since I needed that for Higer order fourier analysis. For example your theorem 5 and proposition 7 appers explicitly in my work. If you are not familiar with it then I think it may be relevant to this post and is worth sharing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("Yes, these sorts of results come up in most work on this area. For instance, Theorem 5 of this post is more or less Lemma 5.11 of ")#link("http://arxiv.org/abs/math/0405251")[#text("my 2004 paper")]#text(" translated from standard analysis into nonstandard analysis (and the analogue of Lemma 4.3 of Host-Kra’s 2005 paper), and Proposition 7 is similarly a translated version of Lemma 9.3 of my 2004 paper (and, as mentioned previously, is the analogue of Lemma 7.2 and Theorem 7.4 in Furstenberg’s 1977 paper).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457677")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2015")])]

#text("Hi Terry,")

#text("1.) Thank you for bringing up this concrete question about my nilspace paper with Camarena. The answer is quite short:")

#text("It is proved in the paper (see Theorem 2 in section 3.5) that measurable morphisms between nilspaces are continuous. Since translations are automorphisms of nilspaces it follows that measurable translations are continuous.")

#text("Such conversations can help in removing opinions that our paper with Camarena “had to be repaired” or contains fundamental flaws.")

#text("2.) You are right that many earlier finite statements are basically equivalent with statements proved in the non-standard setting later, but then one might ask “what is the advantage of doing the proofs in the non-standard setting?”.")

#text("In my opinion the answer to this question is not just getting rid of epsilon management, but also identifying precise structures in an idealistic infinite setting that appear only in an approximative way in the finite setting. The advantage of this is that it is much easier to work with precise structures than with approximative structures.")

#text("I only wanted to say that the program started in my 2009 HOF paper was to identify the approximative structures related to Gowers norms as precise (sometimes algebraic) structures on the appropriate ultraproduct space.")

#text("This of course, does not decrease the value and originality of you post. I also have to admit that I was not familiar with your 2004 paper. I will of course cite it in my non-standard papers to explain more the connection between my infinite notions (such as Fourier sigma algebras) and the finite language.")

#text("Best,")

#text("Balazs")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457703")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2015")])]

#text("Balazs, in your proof of Theorem 2 on page 39 can you expand on why “The compact nilspace structure on ")#mi("M")#text(" guarantees that ")#mi("f")#text(" depends continuously on the system ")#mi("\\{ f_v \\}_{0 \\neq v \\in \\{0,1\\}^{k+1}}")#text("“? It is clear that this is true in a pointwise sense (in that for any ")#mi("x \\in N")#text(" and ")#mi("c \\in C_x^{k+1}(N)")#text(", that ")#mi("f(x)(c)")#text(" depends continuously on the ")#mi("f_v(x)(c)")#text("); however, the continuity required here is not pointwise but rather in the rather complicated topology of ")#mi("{\\mathcal L}(C^{k+1}(N),M)")#text(", and to verify continuity in this setting appears to require an additional argument, given that nonlinear continuous functions are usually discontinuous in weak topologies. A model question appears to be to establish that if ")#mi("\\{ \\mu_y \\}_{y \\in Y}")#text(" is a CSM on a factor map ")#mi("\\pi: X \\to Y")#text(" and ")#mi("A")#text(" is a compact abelian group, then the group law on ")#mi("{\\mathcal L}(X,A)")#text(" is continuous. Given your analogy between the topology on ")#mi("{\\mathcal L}(X,A)")#text(" and the strong L^1 topology, this is plausible, but of course an analogy is not sufficient by itself to constitute a rigorous proof.")

#text("(Roughly speaking, it seems one needs a relative version of the observation that weak convergence in L^2 plus convergence of norm implies strong convergence in L^2, which you mentioned on page 32 to justify your analogy between the ")#mi("{\\mathcal L}(S,T)")#text(" topology and the strong L^1 topology. If one only has the weak convergence that one starts with in the definition of the ")#mi("{\\mathcal L}(S,T)")#text(" topology, then it is not obvious that even such a “manifestly continuous” operation as squaring ")#mi("f \\mapsto f^2")#text(" is actually continuous even when the domain and range of ")#mi("f")#text(" are compact; note for instance on ")#mi("[0,1]")#text(" that the functions ")#mi("\\sin(nx)")#text(" converge weakly to 0, but ")#mi("\\sin(nx)^2")#text(" does not converge weakly to 0.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457708")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2015")])]

#text("Hi Terry,")

#text("If I understand your question well, the answer relies on a fact about the ")#mi("\\mathcal{L}")#text(" construction. This is that if you have a continuous function of the form ")#mi("G:A\\rightarrow B")#text(" then the function ")#mi("G^{\\prime}:\\mathcal{L}(X,A)\\rightarrow\\mathcal{L}(X,B)")#text(" defined by composition with ")#mi("G")#text(" is continuous. This follows directly from the definition. (Take the basis of continuous functions defining the topology on ")#mi("\\mathcal{L}(X,G)")#text(" and compose them with ")#mi("G^{\\prime}")#text(". These compositions are by definition continuous on ")#mi("\\mathcal{L}(X,A)")#text(".)")

#text("To spell out why this is enough for the proof I break it down into 4 parts (It seems that your problem was in part 3):")

#text("1.) The functions ")#mi("f_v:N\\rightarrow\\mathcal{L}(C^{k+1}(N),M)")#text(" are continuous if ")#mi("0\\neq v\\in\\{0,1\\}^{k+1}")#text(". Based on your question I think that you accepted this part.")

#text("2.) Let ")#mi("f^{\\prime}:N\\rightarrow\\mathcal{L}(C^{k+1}(N),M^{\\{0,1\\}^{k+1}\\setminus\\{0\\}})")#text(" be the function with the property that for every ")#mi("x")#text(" we have that ")#mi("f^{\\prime}(x)")#text(" is the function on ")#mi("C_x^{k+1}(N)")#text(" whose coordinate functions are ")#mi("\\{f_v(x)\\}_{v\\neq 0}")#text(".")#linebreak()#text(" It is clear from the previous statement that ")#mi("f^{\\prime}")#text(" is continuous.")

#text("3.) Let ")#mi("S")#text(" denote the set of corners of ")#mi("k+1")#text(" dimensional cubes in ")#mi("M^{\\{0,1\\}^{k+1}\\setminus\\{0\\}}")#text(". For every ")#mi("x")#text(" the function ")#mi("f^{\\prime}(x)")#text(" on ")#mi("C_x^{k+1}(N)")#text(" takes its values in the closed set ")#mi("S")#text(". Now for every ")#mi("x")#text(" we compose ")#mi("f^{\\prime}(x)")#text(" pointwise (!) with the continuous function ")#mi("h:S\\rightarrow M")#text(" that gives the unique completion of a corner. This way we get the function ")#mi("f:N\\rightarrow\\mathcal{L}(C^{k+1}(N),M)")#text(" that appears in the proof and has the property that ")#mi("f(x)")#text(" is the constant ")#mi("\\phi(x)")#text(" function on ")#mi("C_x(N)")#text(".")

#text("4.) By the observation I started with we have that these constant functions depend continuously on ")#mi("x")#text(" meaning that the constants also depend continuously.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457709")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2015")])]

#text("Actually, in your breakdown, the problem is with Step 2. The continuity of the individual ")#mi("f_v")#text(" does not “clearly” imply the continuity of ")#mi("f^{\\prime}")#text(" because it is not “clear” that the topology on ")#mi("{\\mathcal L}( C^{k+1}(N), M^{\\{0,1\\}^{k+1}\\backslash \\{0\\}})")#text(" is the product of the topologies on the individual ")#mi("{\\mathcal L}(C^{k+1}(N), M )")#text(". (There are test functions on ")#mi("M^{\\{0,1\\}^{k+1} \\backslash \\{0\\}}")#text(" that are not linear combinations of functions of a single component ")#mi("M")#text(", but instead depend jointly on all components in a “high-rank” fashion that cannot be easily resolved into one-component functions without taking tensor products, which is an operation which is not obviously continuous with regards to this topology.)")

#text("To repeat my previous remark, to resolve this issue it appears that one needs a relative version of the classical fact that if a sequence is weakly convergent in L^2 and its norms converge to the norm of the limit, then it is strongly convergent in L^2. But in your setting the measures are varying, and the simple expedient in the classical setting of subtracting a function from its limit is not easily available here.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457722")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2015")])]

#text("Hi Terry, I think the following calculation resolves this issue:")

#strong[#text("Proposition")]#text(" ")#emph[#text("Let ")#mi("X,Y,Z")#text(" be compact spaces. Let ")#mi("\\pi:X\\rightarrow Y")#text(" be a CSM. Assume that ")#mi("\\{f_i\\in\\mathcal{L}(X,Z)\\}_{i=1}^\\infty")#text(" converges to ")#mi("f")#text(" and ")#mi("\\{g_i\\in\\mathcal{L}(X,Z)\\}_{i=1}^\\infty")#text(" converges to ")#mi("g")#text(" such that ")#mi("f_i")#text(" and ")#mi("g_i")#text(" are defined on ")#mi("\\pi^{-1}(y_i)")#text(" and ")#mi("f,g")#text(" are defined on ")#mi("\\pi^{-1}(y)")#text(". Then functions ")#mi("t\\mapsto (f_i(t),g_i(t))")#text(" converge to ")#mi("t\\mapsto (f(t),g(t))")#text(".")]

#text("Proof: We have to show that ")#mi("\\lim_{i\\to\\infty}\\int_{\\pi^{-1}(y_i)}F(f_i,g_i)G=\\int_{\\pi^{-1}(y)}F(f,g)G")#text(" holds for any pair of continuous functions ")#mi("F:Z\\times Z\\to\\mathbb{C}")#text(" and ")#mi("G:X\\rightarrow\\mathbb{C}")#text(".")

#text("First we prove it in the special case when ")#mi("F(a,b)=F_1(a)F_2(b)")#text(" for some continuous functions ")#mi("F_1,F_2:Z\\rightarrow\\mathbb{C}")#text(" and ")#mi("n\\in\\mathbb{N}")#text(".")#linebreak()#text(" For any fixed ")#mi("\\epsilon>0")#text(" we can construct a ")#mi("\\mathbb{C}")#text("-valued continuous function ")#mi("q")#text(" on ")#mi("X")#text(" with ")#tao-math("\\left\\|q\\right\\|_\\infty\\leq\\left\\|F_2\\right\\|_\\infty", block: false)#text(" and such that the restriction ")#mi("q^{\\prime}")#text(" of ")#mi("q")#text(" to ")#mi("\\pi^{-1}(y)")#text(" has the property that ")#tao-math("\\left\\|F_2(g)-q^{\\prime}\\right\\|_2\\leq\\epsilon", block: false)#text(".")#linebreak()#text(" Let ")#mi("q_i")#text(" denote the restriction of ")#mi("q")#text(" to ")#mi("\\pi^{-1}(y_i)")#text(". We have by the convergence of ")#mi("\\{g_i\\}_{i=1}^\\infty")#text(" that ")#tao-math("\\left\\|F_2(g_i) - q_i\\right\\|_2^2=\\int_{\\pi^{-1}(y_i)}(F_2\\circ g_i - q_i)^2", block: false)#text(" converges to ")#tao-math("\\left\\|F_2(g) -q^{\\prime} \\right\\|_2^2", block: false)#text(".")#linebreak()#text(" Now writing ")#mi("F(f_i,g_i)")#text(" as ")#mi("F_1(f_i)(q_i+(F_2(g_i)-q_i))")#text(" we have that ")#mi("F(f_i,g_i)=F_1(f_i)q_i+H_i")#text(" and ")#mi("F(f,g)=F_1(f)q^{\\prime}+H")#text(" where if ")#mi("i")#text(" is big enough the ")#mi("L_2")#text(" norm each ")#mi("H_i")#text(" and ")#mi("H")#text(" is at most ")#tao-math("c(\\epsilon)=\\left\\|F_1\\right\\|_\\infty(2\\left\\|F_2\\right\\|_\\infty\\epsilon)^{1/2}", block: false)#text(". We have by convergence of ")#mi("\\{f_i\\}")#text(" that")

#mi("\\displaystyle \\lim_{i\\to\\infty} \\int_{\\pi^{-1}(y_i)}F_1(f_i)q_iG=\\int_{\\pi^{-1}(y)}F_1(f)q^{\\prime}G.")

#text("It follows from the previous estimates that")

#tao-math("\\displaystyle \\limsup_{i\\to\\infty} \\left|\\int_{\\pi^{-1}(y_i)} F(f_i,g_i)G-\\int_{\\pi^{-1}(y_i)} F(f,g)G\\right|\\leq 2c(\\epsilon)\\left\\|G\\right\\|_\\infty.", block: false)

#text("By converging to ")#mi("0")#text(" with ")#mi("\\epsilon")#text(" we obtain the statement.")

#text("Using Stone-Weierstrass we can approximate every two variable continuous function on ")#mi("Z")#text(" by a linear combination of functions of the form ")#mi("F(a,b)=F_1(a)F_2(b)")#text(". This completes the proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457743")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2015")])]

#text("Balazs, thanks for this argument. It seems that this, together with the expanded argument provided previously for the proof of Theorem 2, as well as suitable clarification of the proof of Lemma 3.23 (in particular explaining why the translation ")#mi("\\beta")#text(" is first Borel measurable, and then continuous) does indeed finally repair the issue I raised with you in my Nov 8 2010 email. (Incidentally, there is a further confusing typo in the proof of Lemma 3.23: it appears that you reference Lemma 2.1 when you should instead be referencing the rather different Proposition 2.1. This issue may also occur elsewhere in the paper, it is worth checking.)")

#text("I have some other questions about your 2010 paper with Camarena, relating more to the relationship between your paper and various concepts and results introduced in previous literature, including the 2005 paper [")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("HK2005")]#text("] of Host and Kra (reference [10] in your paper), the 2006 paper [")#link("http://arxiv.org/abs/math/0606004")[#text("HK2006")]#text("] of Host and Kra (reference [11] in your paper), and a 2009 paper [")#link("http://arxiv.org/abs/0905.3098")[#text("HKM2009")]#text("] of Host, Kra, and Maass (which you might not be aware of, as it is not referenced in your paper; see also the precursor [")#link("http://arxiv.org/abs/math/0609794")[#text("HM2006")]#text("] to [HKM2009]).")

#enum(start: 1, 
[#text("You state on page 3 that your axiom system for nilspaces is a “variant” of the axiom system for strong parallelepiped systems from [HK2006]. But it seems to me that the connection is far tighter than that, namely that the axiom systems are in fact ")#emph[#text("logically equivalent")]#text(": every k-step nilspace is a k-step strong parallelepiped system and vice versa. (Most of [HK2006] is devoted to the cases k=1,2, but the higher k case is discussed in Section 7, and it is clear how to extend the axiom set for 1 and 2-step strong parallelepiped systems to higher k.) [HK2006] has a weaker composition axiom and compensates for this with a gluing axiom, but it seems straightforward to derive one set of axioms from the other (e.g. you derive the gluing axiom in Lemma 2.2 of your paper). There are also other parallels between [HK2006] and your 2010 paper that are worth mentioning, for instance the equivalence relation ")#mi("\\sim_k")#text(" in your Definition 2.3 appears to be the same concept (for k=2 at least) as in Proposition 3 of [HK2006]; the abelian group in your Corollary 2.4 and Theorem 1 appears to be the same as the fibre group constructed in Section 5.2 of [HK2006]; the equivalence between liftability of a translation and a splitting condition (or equivalently, that a certain cocycle is a coboundary) appears both as Lemma 2.20 in your paper and Theorem 2 of [HK2006]; and the importance of the transitivity of the translation group (which you established in the connected setting as Corollary 3.3) is the main result of [HK2006] (see Theorem 1). You did note in page 24 that the translation groups were previously introduced and shown to be nilpotent in [HK2005,HK2006], but I think the connection between these works goes beyond that one result, and should be more strongly emphasised. Anyway, my question is if you could confirm that the axiom systems for nilspaces and k-step strong parallelepiped structures are actually logically equivalent, and not just variants of each other, and if you know of any further connections between the individual lemmas and propositions in [HK2006] and those in your paper.")],
[#text("The paper [HK2005] is set in the ergodic-theory setting rather than the compact nilspace setting, and so are ostensibly discussing different mathematical objects, yet there is a remarkably strong parallel between the structure of your 2010 paper and of that of [HK2005]. We have already discussed the nilpotent translation groups in both papers, but for instance there is also the reduction to abelian extensions which occurs in Lemma 6.2 of [HK2005] and Corollary 2.4 and Theorem 1 of your paper; the cocycles introduced in your Definition 2.14 appear to play a closely analogous role to the type k cocycles introduced in Definition 7.1 of [HK2005] (compare for instance Proposition 7.6 of [HK2005] with the discussion at the end of your Section 2.10); the lifting of translations criterion in your Proposition 2.1 is quite analogous to Lemma 10.6 of [HK2005]; the liftability of short translations appears as Lemma 3.23 in your paper and as Proposition 10.10 in [HK2005]; and the reduction to the finite rank case occurs in Section 3.8 of your paper and Section 10.1 of [HK2005]. You did acknowledge using an argument from Appendix A of [HK2005] to obtain the Lie nature of the translation group in your Theorem 6, but the connections with [HK2005] seem to go far beyond that one fact, and should probably be emphasised more in your paper. Anyway, my question is whether you know of any deeper explanation for the striking parallels between the ergodic theory context and the compact nilspace context (perhaps this issue is addressed in some of your other work?). See also the work in [HKM2009] which ties together the topological dynamics context with both the compact nilspace context and the ergodic theory context.")],
[#text("The paper [HKM2009] associates a compact k-step strong parallelepiped structure (or in your language, a compact nilspace) to each topological dynamical system, and introduces a number of concepts which may have parallels in your 2010 paper, for instance the regionally proximal relation discussed in [HKM2009] looks similar to the equivalence relations in your 2010 paper. There is also extensive discussion on the relation between the topological and measure theoretic categories in that paper which may relate to some of your other papers. Anyway, I was wondering if you could comment on any connections between the concepts studied in [HKM2009] and your paper; it would in particular be interesting to have an interpretation of the regionally proximal relation in the nilspace language.")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457751")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2015")])]

#text("p.s. there may also be a link between the rigidity result in your Theorem 2 (that measurable morphisms are continuous) and the property testing literature, for instance ")#link("http://www.cs.princeton.edu/courses/archive/spr04/cos598B/bib/RonAKKL.pdf")[#text("this 2004 paper of Alon, Kaufman, Krivelevich, Litsyn, and Ron")]#text(", in which they show that the property of being a polynomial of given degree over ")#mi("{\\mathbb F}_2")#text(" is locally testable with one-sided error (the linear case being a famous paper of Blum, Luby, and Rubinfeld). In particular, the arguments in Section 4 of that paper remind me of the combinatorial manipulations on the three-cube in your paper, and the key property of a polynomial used is that its value at one corner of a parallelepiped is determined by its value at all other corners. (The technical details are of course a little different, for instance the alternating signs in the sums are not explicit in the AKKLR paper because they work in characteristic two. Still there seems to be some connection; it may be for instance that taking an ultraproduct of a sequence of instances of functions that locally test to be polynomial in the AKKLR sense leads to a measurable morphism to which your Theorem 2 may be applied. This would be in analogy with how property testing for graph properties interacts well with graph limits, as noted for instance in Lovasz’s book.) This is of course also closely related to the topic of the inverse conjecture for Gowers norms over finite fields.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d85c0a27a788d1724ca0b531d5d2a337ff03f68b01b99b9e9a682ff21fa6a213-46c07a03980a31e3b80178ec8c3699aa7f77a60c9c87dd27d403be0950a8f8e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457707")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2015")])]

#text("Balazs, I think this conversation highlights the frustration felt by those of us who spent time trying to read your papers. The argument is incomplete from the standpoint of a human reader of the papers, by which I mean that there is too much to be filled in between the lines. At least, I found this to be the case. That’s not to suggest that it’s not a subset of a complete argument, quite possibly an everywhere dense one. Indeed the results (some known by other means) as well as the methods are quite natural.")

#text("The problem is compounded by the fact that the notation and the number of definitions and names make the paper extremely heavy reading, and by the fact that from 2009-2012 there were a large number of rather different new versions of the work posted on the arxiv. It looks as if things have stabilised with the 2012 version, which addresses the second issue. As regards the first, I think the community would universally appreciate a greatly expanded version of the complete argument, quite possibly illustrated in the 2-step case throughout. As I understand it, that case contains essentially all of the ideas whilst being much lighter on general notation.")

#text("Best wishes, Ben")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457746")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2015")])]

#text("Hi Ben,")

#text("Thank you for your comment.")

#text("First, the part that I mostly agree with. I take your phrase “everywhere dense argument” as a positive critique. I think what you mean is that the results are correctly broken down into lemmas, but the expositions of the proofs of the individual lemmas are of varying quality. I was definitely more busy (and interested) in breaking through the fundamental difficulties and finding the right inherent language than perfecting the exposition. I am taking responsibility for that.")

#text("A particular weakness in the exposition of the nilspace paper is that it builds on the subject of “continuous systems of measures” CSM’s. Quite surprisingly, this fundamental subject was not developed enough for our purposes. So with Omar we had to do a lot of ground work in it. Terry’s question was also basically about the behavior of CSM’s. I think that the best idea is to publish a separate paper that cleans up the CSM subject and thus making the paper more understandable by freeing it from this burden. We actually plan to write such a paper with Pablo Candela.")

#text("As of the history of my papers on the ArXiv I partially disagree with you. When I wrote my first paper in 2009 I observed that many non standard arguments that we developed for hypergraphs with Elek in 2007 can be also applied for the Gowers norms and I wanted to explore how far one can go with these ideas. So I wrote a sequence of 3 papers, mainly built on my paper with Elek and of course on the fundamental work of Host and Kra. Only at the end of the third paper it became clear to me that this leads to a theory of additive structures in compact abelian groups. My main goal was not to prove the inverse theorem. I look at it as a byproduct of a more general clean structure theory of characteristic factors on ultraproduct groups. I think that already my work in 2010 clearly demonstrates that I had all the fundamental ideas for such a structure theory. It was not a 2 page sketch, the math is there. You are right that it stabilized in a new version in 2012 when I changed some arguments to new ones that I felt more aesthetic.")

#text("I will try my best to come up with a version that is more pleasant to read and I am glad to take any advise from you give on how to do it.")

#text("Best,")

#text("Balazs")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d85c0a27a788d1724ca0b531d5d2a337ff03f68b01b99b9e9a682ff21fa6a213-46c07a03980a31e3b80178ec8c3699aa7f77a60c9c87dd27d403be0950a8f8e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457749")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2015")])]

#text("Balazs – yes, the expositions are of varying quality. I look forward to a fully fleshed out version of the arguments in due course. Best, Ben.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c83180e223ae62e1bd72d4f02b215a6e1ab683b6f7625001472920a54162f26-6922b0066a39e49651453c8917c30a7b0eb311cc93457cb1979dd52393fa791c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Phrase Is Born")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457829")[#strong[#text("A Phrase Is Born")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2015")])]

#text("Ben, that phrase “everywhere dense subset of a complete argument” is a gem that deserves wider circulation. Did you invent it?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457732")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2015")])]

#text("@Balazs")

#text("I am not familiar with this area but I was curious. Since it’s much easier to work with precise structures in the infinite setting, are there any new results in the finite setting that one can obtain using these precise structures that were not known before using the approximate structures?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457734")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2015")])]

#text("Hi Victor there is a standard machinery including furstenberg’s correspondence principle and the transference principle for ultraproducts that allows you to translate back anything that you do in the idealistic infinite universe to the finite setting. This is the way for example how Furstenberg proved Szemeredi’s theorem (which can be regarded as a finite statement) using infinite arguments. There are many finite statements that have much easier proofs in the infinite setting and of corse statements that had their first proofs in the infinite setting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457747")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2015")])]

#text("@all")

#text("Again, to satisfy my curiosity I would like to see mentioned a couple of examples of statements that had their first proofs in the infinite setting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2015")])]

#text("Density Hales-Jewett is a not-completely-bad example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457799")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2015")])]

#text("That’s a good example, thanks! I don’t understand why people took my question so negatively…")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457759")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2015")])]

#text("It is very much true that my whole work (in every aspect) can be regarded as a continuation of the work of Host and Kra starting with my 2009 paper which is built almost exclusively on the famous Annals paper of them on characteristic factors and my paper with Elek. I regard the nilspace paper as just a continuation of the Host-Kra paper on parallelepiped structures and we say it very clearly in the abstract but you are right that we should do a better job with citations throughout the paper. In a new version I will fix this. The main difficulty that we treat with Camarena is the topologization of the language of Host and Kra. The real novelty in the paper is in the methods that we developed for this topologization. (In my application in Higher order Fourier analysis I needed a topological version.)")

#text("Personally I am a big fan of the work of Host and Kra as they had the right vision from very early on and I am glad that I could contribute to it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ff62606cee3f85546fbbc92e4aa7258550ac1c9b7dce5c445ca04fc88ebc421-202cc63481b7e27e9d2ccc3bd724f2047876bcee9bc54025fb9dadfbff8231c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yonatan")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-457824")[#strong[#text("Yonatan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2015")])]

#text("Dear Terry,")

#text("I would like to make some brief comments regarding the questions you posed above:")

#text("Q2 One possible explanation for the “striking parallels between the ergodic theory context and the compact nilspace context” is contained in some recent unpublished work of mine building heavily on the work of Host-Kra and Camarena-Szegedy . Essentially, one can show directly — i.e., without using the structure theory of [HK2005] — that the Host-Kra characteristic factors have (compact) topological (dynamical) models which carry compatible (with the dynamics) compact nilspace structure. This allows the structure theorem of [HK2005] to be *deduced* from a dynamical variant of the Camarena-Szegedy structure theorem for nilspaces due to Freddie Manners, Péter Varjú and myself.")

#text("Q3 Let ")#mi("G")#text(" be an arbitrary topological group and let ")#mi("(G,X)")#text(" be a topological dynamical system. Define a “dynamical” cubespace by (")#mi("n\\in \\mathbb{N}")#text(")")#linebreak()#text(" ")#mi("C_{G}^{n}(X)=\\overline{\\{HK^{n}(G)(x,x,\\ldots,x)|\\,x\\in X\\}}\\subset X^{[n]}")#text(" (")#mi("HK^{n}(G)")#text(" is the Host-Kra cubegroup). For ")#mi("G")#text(" abelian this is ")#mi("C_{G}^{n}(X)=\\overline{\\{\\big{\\left((\\sum_{j=1}^{n}\\epsilon_{j}g_{j})x\\right)}_{\\vec{\\epsilon}\\in\\{0,1\\}^{n}}|\\,x\\in X,\\,\\vec{g}\\in G^{n}\\}}")#text(". Following Camarena-Szegedy define the relation ")#mi("x\\sim_k y")#text(" if ")#mi("(x,x,\\ldots,y)\\in C_{G}^{k+1}(X)")

#text("If ")#mi("G")#text(" is abelian and ")#mi("(G,X)")#text(" is minimal then it follows from the works of Host-Kra-Maass and Shao-Ye that ")#mi("\\sim_k")#text(" is an equivalence relation.")#linebreak()#text(" By a result of Freddie Manners, Péter Varjú and myself If ")#mi("G")#text(" is arbitrary and ")#mi("(G,X)")#text(" is minimal distal then ")#mi("C_{G}")#text(" is a prenilspace (cubespace with ")#mi("k")#text("-completion for all ")#mi("k")#text(") and therefore ")#mi("\\sim_k")#text(" is an equivalence relation.")

#text("Using the dynamical variant of the Camarena-Szegedy structure theorem alluded to above one can conclude that in all of these cases ")#mi("(G,X/\\sim_k)")#text(" is the maximal pronilfactor of (H,X) of degree k (for ")#mi("G=\\mathbb{Z}")#text(" it was already known from Host-Kra-Maass).")

#text("Eli Glasner and myself constructed a ")#mi("\\mathbb{Z}")#text(" minimal example (a proximal extension of a rotation) for which ")#mi("C_{G}")#text(" is not a prenilspace.")

#text("Best wishes,")

#text("Yonatan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c98a424a37e39eaabdff9ae46662cea3bc2a47bb7e4aff4afda1f8818325fc10-7bebb4855515869c2d6244c3a0739825e56ee49b417f3eb458a1029ca7f5c0b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of espressonator")]], [#link("https://terrytao.wordpress.com/2015/07/20/a-nonstandard-analysis-proof-of-szemeredis-theorem/#comment-485934")[#strong[#text("espressonator")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2017")])]

#text("I wish I could work with you, Professor Tao, on some nonstandard mathematics aimed at solving some (hard) open problems. You see things so quickly, it’s nice to read your blog posts and watch your youtube presentations.")
]
