// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/
// Converted to Typst by tao2typ: "2026-10-14T11:16:03.644630+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A digestion of unit distance constructions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A digestion of unit distance constructions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 July 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/")[#text("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Suppose that one has a set ")#mi("{P}")#text(" of ")#mi("{n}")#text(" points in the plane, which we will think of as the complex plane ")#mi("{{\\bf C}}")#text(". Let ")#mi("{d_1(P)}")#text(" denote the number of unit distances determined by these points, i.e., pairs of points ")#mi("{p,q \\in P}")#text(" whose displacement ")#mi("{w = q-p}")#text(" obeys the equation ")#metadata(none) <tao-b4266b3d51d930008913>

#mi("\\displaystyle w \\overline{w} = 1. \\ \\ \\ \\ \\ (1)")

#text("(It makes little difference for the asymptotics, but we will count the pair ")#mi("{(q,p)}")#text(" separately from ")#mi("{(p,q)}")#text(" here.)")

#link("https://www.erdosproblems.com/forum/thread/90")[#text("The Erdös unit distance problem")]#text(" asks, for a given large number ")#mi("{n}")#text(", what is the largest possible value of ")#mi("{d_1(P)}")#text(" amongst all sets ")#mi("{P}")#text(" of cardinality ")#mi("{n}")#text("?")

#text("For instance, if one takes ")#mi("{P}")#text(" to be ")#mi("{n}")#text(" equally spaced collinear points with unit spacing, one can obtain a linear construction with ")#mi("{d_1(P) = 2n-2}")#text(". Erdös observed that one can improve this construction asymptotically:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Erdös construction)")]#metadata(none) <tao-5f80c8e3faa99b558cd4>#text(" There exists point sets ")#mi("{P}")#text(" of arbitrarily large cardinality ")#mi("{n}")#text(" such that ")#mi("{d_1(P) \\gg n^{1 +c / \\log\\log n}}")#text(" for some absolute constant ")#mi("{c > 0}")#text(".")
]

#text("In fact, in the construction one could take ")#mi("{c}")#text(" arbitrarily close to ")#mi("{\\log 2}")#text(". Erdös famously asked whether ")#mi("{d_1(P)}")#text(" had to be bounded above by ")#mi("{n^{1+o(1)}}")#text("; and for decades there was significant effort expended on upper bounding ")#mi("{d_1(P)}")#text(", with the best known upper bound being ")#mi("{d_1(P) \\ll n^{4/3}}")#text(", established by ")#link("https://zbmath.org/0561.52008")[#text("by Spencer, Szemerédi, and Trotter")]#text(" in 1984. We will note here that it seems extremely difficult to improve this upper bound. One reason for this is that if one replaces the equation ")#link(<tao-b4266b3d51d930008913>)[#text("(1)")]#text(" with the superficially similar equation ")#metadata(none) <tao-74b5da6993517385fd97>

#mi("\\displaystyle \\mathrm{Im} w = (\\mathrm{Re} w)^2 \\ \\ \\ \\ \\ (2)")

#text("(i.e., replace the unit circle ")#mi("{(\\mathrm{Re} w)^2 + (\\mathrm{Im} w)^2 = 1}")#text(" by a standard parabola), then the ")#mi("{n^{4/3}}")#text(" bound is best possible, as can be seen by taking ")#mi("{P}")#text(" to be a rectangle in the Gaussian integers of width ")#mi("{\\asymp n^{1/3}}")#text(" and height ")#mi("{\\asymp n^{2/3}}")#text(". Hence any improvement of the ")#mi("{n^{4/3}}")#text(" bound would have to exploit some special property of the unit circle that is not shared by the parabola.")

#text("It came as some surprise recently when a team from OpenAI ")#link("https://cdn.openai.com/pdf/74c24085-19b0-4534-9c90-465b8e29ad73/unit-distance-proof.pdf")[#text("resolved the question of Erdös")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (OpenAI construction)")]#metadata(none) <tao-7d3194f79e645c42e439>#text(" There exists point sets ")#mi("{P}")#text(" of arbitrarily large cardinality ")#mi("{n}")#text(" such that ")#mi("{d_1(P) \\gg n^{1 + c}}")#text(" for some absolute constant ")#mi("{c > 0}")#text(".")
]

#text("The optimal value of ")#mi("{c}")#text(" is still unknown, but the best upper and lower bounds on ")#mi("{c}")#text(" are tracked at ")#link("https://teorth.github.io/optimizationproblems/constants/84a.html")[#text("this page")]#text("; currently we know that ")#mi("{0.03583\\dots \\leq c \\leq 1/3}")#text(".")

#text("The construction in Theorem ")#link(<tao-7d3194f79e645c42e439>)[#text("2")]#text(" is a heavily modified version of that in Theorem ")#link(<tao-5f80c8e3faa99b558cd4>)[#text("1")]#text(", and uses some non-trivial amount of algebraic number theory, in particular the device of Golod–Shafarevich towers of field extensions. However, it was ")#link("https://x.com/__alpoge__/status/2059298565093196012")[#text("later observed")]#text(" using the Mythos AI that one could get a weaker bound with less algebraic number theory, which after optimizing parameters yields the following intermediate result between Theorem ")#link(<tao-5f80c8e3faa99b558cd4>)[#text("1")]#text(" and Theorem ")#link(<tao-7d3194f79e645c42e439>)[#text("2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Mythos construction)")]#metadata(none) <tao-553133ea03bb73bd9d74>#text(" There exists point sets ")#mi("{P}")#text(" of arbitrarily large cardinality ")#mi("{n}")#text(" such that ")#mi("{d_1(P) \\gg n^{1 + c / \\log\\log\\log n}}")#text(" for some absolute constant ")#mi("{c > 0}")#text(".")
]

#text("Furthermore, by inserting Golod–Shafarevich towers back into the Mythos construction, one can recover the full strength of Theorem ")#link(<tao-7d3194f79e645c42e439>)[#text("2")]#text(".")

#text("These results already have a number of expositions; see for instance ")#link("https://arxiv.org/abs/2605.20695")[#text("this article of Alon et al.")]#text(", or ")#link("https://www.erdosproblems.com/forum/thread/blog:6")[#text("this blog post of Bloom")]#text(". As an exercise for myself, I recently spent some time trying to “digest” these constructions and place them on a common footing, with an emphasis on trying to find the minimal route to either heuristically or rigorously recovering these results relying on as little algebraic number theory as possible. The post here is a writeup of this exercise. (Disclosure: AI tools were useful for providing initial summaries of these arguments, as well as on explaining various fundamentals of algebraic number theory to me.)")

#text("The first (trivial) observation is that one can use rescaling to replace the unit distance by any other fixed distance. In particular, for any positive real ")#mi("{m}")#text(", if we let ")#mi("{d_m(P)}")#text(" denote the number of pairs ")#mi("{p,q}")#text(" whose displacement ")#mi("{w = q-p}")#text(" obeys the equation ")#metadata(none) <tao-84fd1af5cb9bcccd5be5>

#mi("\\displaystyle w \\overline{w} = m, \\ \\ \\ \\ \\ (3)")

#text("then it is clear that any construction of a point set ")#mi("{P}")#text(" with a given value of ")#mi("{d_m(P)}")#text(" can be rescaled to another point set ")#mi("{m^{-1/2} \\cdot P}")#text(" of the same cardinality with the corresponding value of ")#mi("{d_1(P)}")#text(". It turns out to be convenient to work with values of ")#mi("{m}")#text(" that are asymptotically large, for instance the product of several large primes.")

#text("All the constructions of good point sets ")#mi("{P}")#text(" basically involve taking all the elements of a certain ring ")#mi("{B}")#text(" of algebraic integers up to some height. In the original construction of Erdös, ")#mi("{B}")#text(" was chosen to be the ring of Gaussian integers ")#mi("{{\\bf Z}[i]}")#text(", but in fact any ring of integers in a non-trivial bounded degree field extension of ")#mi("{{\\bf Q}}")#text(" would suffice to recover Theorem ")#link(<tao-5f80c8e3faa99b558cd4>)[#text("1")]#text(" (though always with the constant ")#mi("{c}")#text(" not exceeding ")#mi("{\\log 2}")#text("). To go beyond this, one has to start considering number fields of unbounded degree. As it turns out, the field extensions arising from Golod–Shafarevich towers are the most efficient for this purpose, and lead to Theorem ")#link(<tao-7d3194f79e645c42e439>)[#text("2")]#text("; but one can work with the more elementary construction of number fields generated by many square roots of medium-sized primes, and this suffices for the intermediate result in Theorem ")#link(<tao-553133ea03bb73bd9d74>)[#text("3")]#text(".")

#text("The numerology can be explained as follows. Take ")#mi("{B}")#text(" to be a ring of integers in some number field of degree ")#mi("{D}")#text(", and suppose for sake of argument that ")#mi("{m}")#text(" is the product of ")#mi("{t}")#text(" (rational) primes ")#mi("{p_1,\\dots,p_t}")#text(", which for simplicity we will assume to all have comparable magnitude, thus ")#mi("{p_i \\asymp T}")#text(" for some ")#mi("{T}")#text(" and all ")#mi("{i=1,\\dots,t}")#text(". Thus, ")#mi("{m}")#text(" is roughly of the size of ")#mi("{T^t}")#text(". In practice one wants to impose some additional “splitting” conditions on these primes ")#mi("{p_1,\\dots,p_t}")#text(", but the prime number theorem, as well as variants such as the Chebotarev density theorem, suggest that we should be able to keep ")#mi("{T}")#text(" reasonably close to ")#mi("{t}")#text(" in size; for instance, if we select primes greedily then we can have ")#mi("{T \\asymp t \\log t}")#text(". In particular we expect to have ")#mi("{\\log T \\asymp \\log t}")#text(" in practice.")

#text("By construction, ")#mi("{m}")#text(" splits into the product of ")#mi("{t}")#text(" rational primes. Moving up to the degree ")#mi("{D}")#text(" extension, one can optimistically hope that ")#mi("{m}")#text(" splits further into the product of ")#mi("{Dt}")#text(" primes in ")#mi("{B}")#text(". Using conjugation symmetry, these primes might split into ")#mi("{Dt/2}")#text(" conjugate pairs ")#mi("{\\rho, \\overline{\\rho}}")#text(". By selecting one element from each pair and multiplying, this generates ")#mi("{2^{Dt/2}}")#text(" solutions to ")#link(<tao-84fd1af5cb9bcccd5be5>)[#text("(3)")]#text(" in ")#mi("{B}")#text(". These solutions ")#mi("{w}")#text(" will of course have complex magnitude ")#mi("{m^{1/2}}")#text("; one can optimistically hope that they in fact have “height” ")#mi("{O(m^{1/2})}")#text(" in some sense.")

#text("To take advantage of this, take ")#mi("{P}")#text(" to be the set of points in ")#mi("{B}")#text(" of height ")#mi("{O(m^{1/2})}")#text(". As ")#mi("{B}")#text(" has rank ")#mi("{D}")#text(", we therefore expect the size ")#tao-math("{n = \\left|P\\right|}", block: false)#text(" of this set to be roughly ")#metadata(none) <tao-09c512bd2b3aec960624>

#mi("\\displaystyle n \\approx (m^{1/2})^D \\approx T^{D t / 2}. \\ \\ \\ \\ \\ (4)")

#text("(For this heuristic discussion I will be deliberately vague about what the symbol ")#mi("{\\approx}")#text(" means.) Meanwhile, using our solutions to ")#link(<tao-84fd1af5cb9bcccd5be5>)[#text("(3)")]#text(", we expect to have ")#metadata(none) <tao-310452bca2c33f824da0>

#mi("\\displaystyle d_m(P) \\gtrapprox n 2^{Dt/2} \\approx n^{1 + \\frac{\\log 2}{\\log T}} \\approx n^{1 + \\frac{\\log 2}{\\log t}}. \\ \\ \\ \\ \\ (5)")



#text("But this can be clarified by the heuristic ")#link(<tao-09c512bd2b3aec960624>)[#text("(4)")]#text(". Taking logarithms, we expect to have ")#metadata(none) <tao-ffeaeec00f5880dda5f4>

#mi("\\displaystyle \\log n \\asymp D t \\log T \\asymp D t \\log t. \\ \\ \\ \\ \\ (6)")

#text("In the regime where the degree ")#mi("{D}")#text(" of the number field is held fixed, we thus expect ")#mi("{t}")#text(" to exhibit logarithmic type growth in ")#mi("{n}")#text(", and on inserting this back into ")#link(<tao-310452bca2c33f824da0>)[#text("(5)")]#text(" we (heuristically) recover Theorem ")#link(<tao-5f80c8e3faa99b558cd4>)[#text("1")]#text(" (with the natural constant ")#mi("{c = \\log 2}")#text("). In fact it is not hard to turn the above heuristics into a rigorous argument, by setting ")#mi("{B}")#text(" equal the Gaussian integers ")#mi("{{\\bf Z}[i]}")#text(" and selecting all the primes ")#mi("{p_1,\\dots,p_t}")#text(" to be ")#mi("{1 \\text{ mod } 4}")#text(", so that they split completely in ")#mi("{{\\bf Z}[i]}")#text(" by the ")#link("https://en.wikipedia.org/wiki/Fermat%27s_theorem_on_sums_of_two_squares")[#text("Fermat two-square theorem")]#text(".")

#text("But if one can permit the degree ")#mi("{D}")#text(" to grow in the construction, and in particular be superpolynomial in ")#mi("{t}")#text(", then the above heuristics suggest that we can start improving upon Theorem ")#link(<tao-5f80c8e3faa99b558cd4>)[#text("1")]#text(" , and even get all the way to Theorem ")#link(<tao-7d3194f79e645c42e439>)[#text("2")]#text(" if we can make the degree go to infinity while keeping the number of primes ")#mi("{t}")#text(" fixed.")

#text("If one naively tries this approach by forcing all the primes ")#mi("{p}")#text(" to split completely in a very high degree number field, one runs into significant technical difficulties, not least of which is the need to obtain good error terms in the ")#link("https://en.wikipedia.org/wiki/Chebotarev_density_theorem")[#text("Chebotarev density theorem")]#text(", which touches upon such difficult questions as the Generalized Riemann Hypothesis and the existence of Siegel zeroes. From an algebraic number theory perspective, this is related to the breakdown of unique factorization in such number fields, as measured by the class group. The size of this group is in turn controlled by the discriminant of the field, as per the ")#link("https://en.wikipedia.org/wiki/Minkowski%27s_bound")[#text("fundamental theorem of Minkowski")]#text(" in this subject.")

#text("But one can hope that the arguments are robust enough to tolerate a little bit of breakdown in unique factorization, so long as the class group is not too large. The most natural way to do this is to use all the standard machinery of algebraic number theory, such as the unique factorization of ideals. But there turns out to be a more elementary (though largely equivalent) approach, which is to weaken the target equation ")#link(<tao-84fd1af5cb9bcccd5be5>)[#text("(3)")]#text(" to a congruence equation ")#metadata(none) <tao-c5873eaf8a8419e1c277>

#mi("\\displaystyle w \\overline{w} = 0 \\text{ mod } mB. \\ \\ \\ \\ \\ (7)")

#text("This condition does not pin down the value of ")#mi("{w \\overline{w}}")#text(" completely, but so long as we can keep the height of ")#mi("{w}")#text(" not too much larger than ")#mi("{m^{1/2}}")#text(", it does restrict ")#mi("{w \\overline{w}}")#text(" to a sufficiently small set of possible values that a simple application of the pigeonhole principle can allow one to conclude.")

#text("In order for this strategy to work well, one needs to locate high-degree number fields ")#mi("{B}")#text(" of controlled discriminant for which it is relatively easy to at least partially split one’s rational primes ")#mi("{p_1,\\dots,p_t}")#text(" into ideals in this field ")#mi("{B}")#text(". It turns out that requiring the field to have a tower structure and admit ")#link("https://en.wikipedia.org/wiki/Complex_multiplication")[#text("complex multiplication")]#text(" (which basically amounts to it including ")#mi("{i}")#text(") is already sufficient to get a satisfactory amount of splitting. To control discriminants, the most efficient choices are the Golod–Shafarevich towers, for which the (root) discriminant stays bounded; but a more naive choice of a tower of quadratic extensions also gives reasonable control on discriminants and is sufficient to establish Theorem ")#link(<tao-553133ea03bb73bd9d74>)[#text("3")]#text(".")

#text("The three constructions thus sit on a continuum, with the key differences being the selection of the key parameters ")#mi("{t}")#text(" (the number of primes multiplied together) and ")#mi("{D}")#text(" (the degree). The Erdös construction keeps the degree fixed and sends the number of primes to infinity. The OpenAI construction does the opposite, keeping the set of primes fixed but sending the degree to infinity. The Mythos construction is a compromise, in which the degree and the number of primes both go to infinity in a coupled fashion. In particular, one could easily imagine an alternate timeline of events in which the Mythos construction was the first to be discovered (by either humans or AI) after the Erdos construction as a reasonably natural modification of the latter, and then subsequently refined (again either by humans or AI) to the OpenAI construction once the significance of Golod–Shafarevich towers was realized.")

#text("In ")#link("https://arxiv.org/abs/2606.13619")[#text("this recent paper of Pohoata")]#text(", the terms “horizontal amplification” and “vertical amplification” were proposed for the technique of constructing large configurations by increasing ")#mi("{t}")#text(" and ")#mi("{D}")#text(", thus the Erdös construction becomes a paradigm for horizontal amplification while the OpenAI construction becomes a paradigm for vertical amplification (and the Mythos construction utilizes both types of amplification). See also ")#link("https://arxiv.org/abs/2605.28781")[#text("this paper of Bloom-Sawin-Schildkraut-Zhelezov")]#text(" for another recent application of vertical amplification.")

#metadata(none) <tao-88ea6e125ffda2ed52fd>

#strong[#text(" — 1. Some more details — ")]

#text("Here we sketch how the quadratic extension approach can recover Theorem ")#link(<tao-553133ea03bb73bd9d74>)[#text("3")]#text(".")

#text("As indicated above, we will work with a product ")#mi("{m = p_1 \\dots p_t}")#text(" of ")#mi("{t}")#text(" (rational) primes of size ")#mi("{\\asymp T}")#text(". Our only requirements of these primes, beyond their size, will be that they are distinct and equal to ")#mi("{1}")#text(" mod ")#mi("{4}")#text(", so that they split in the Gaussian integers. By the prime number theorem in arithmetic progressions, this allows us to take ")#mi("{T}")#text(" as small as ")#mi("{T \\asymp t \\log t}")#text(", so in particular ")#mi("{\\log T \\asymp \\log t}")#text(".")

#text("To construct ")#mi("{B}")#text(", we start by taking ")#mi("{g}")#text(" distinct medium-sized (rational) primes ")#mi("{q_1,\\dots,q_g}")#text(" of size ")#mi("{\\asymp G}")#text(" for some medium-sized parameter ")#mi("{g}")#text(" (eventually, when we optimize parameters, we will take ")#mi("{g}")#text(" to be a small multiple of ")#mi("{t/\\log t}")#text("). We will not need any further properties of these primes, so by the prime number theorem we can take ")#mi("{G}")#text(" as small as ")#mi("{G \\asymp g \\log g}")#text(", so in particular ")#mi("{\\log G \\asymp \\log g}")#text(". We will take ")#mi("{T}")#text(" to be larger than ")#mi("{G}")#text(", so that the primes ")#mi("{p_1,\\dots,p_t}")#text(" are distinct from the primes ")#mi("{q_1,\\dots,q_g}")#text(".")

#text("We will work in the number field ")#mi("\\displaystyle  {\\bf Q}(i, \\sqrt{q_1}, \\dots, \\sqrt{q_g})")#linebreak()#text(" generated by ")#mi("{i}")#text(" and ")#mi("{g}")#text(" real square roots ")#mi("{\\sqrt{q_1},\\dots,\\sqrt{q_g}}")#text(". For instance, if ")#mi("{g = 1}")#text(" and ")#mi("{q_1 = 3}")#text(", a typical element in this field would take the form ")#metadata(none) <tao-88d4266fd4e6338d13b8>

#mi("\\displaystyle  a + b i + c \\sqrt{3} + d i \\sqrt{3} \\ \\ \\ \\ \\ (8)")



#text("In this particular example, the ring of integers would consist of those elements ")#link(<tao-88d4266fd4e6338d13b8>)[#text("(8)")]#text(" for which ")#mi("{a,b,c,d}")#text(" are rational integers. In general, the ring of integers can be slightly larger than this, but for our purposes we can just work with the “naive” ring of integers ")#mi("{B}")#text(" generated by ")#mi("{i}")#text(" and ")#mi("{\\sqrt{q_1},\\dots,\\sqrt{q_g}}")#text(". A typical element of this ring then looks like")

#mi("\\displaystyle  \\sum_{I \\subset \\{0,\\dots,g\\}} a_I \\prod_{i \\in I} \\sqrt{q_i}")#text(" where ")#mi("{a_I}")#text(" are rational integers and we adopt the convention that ")#mi("{\\sqrt{q_0} = i}")#text(". Let us define the (naive) height of such a ring element to be ")#tao-math("{\\max_I \\left|a_I\\right|}", block: false)#text(". Then the number of elements of ")#mi("{B}")#text(" of height at most ")#mi("{H}")#text(" is ")#mi("{\\approx H^D}")#text(" as long as ")#mi("{H}")#text(" is sufficiently large (again I will be vague about what ")#mi("{\\approx}")#text(" means here).")

#text("Our main goal is to find a large number of solutions ")#mi("{w}")#text(" in ")#mi("{B}")#text(" to the congruence equation ")#link(<tao-c5873eaf8a8419e1c277>)[#text("(7)")]#text(". As per the usual ")#link("https://en.wikipedia.org/wiki/Algebraic_number_theory#Real_and_complex_embeddings")[#text("Minkowski embedding")]#text(" based on the various ways to embed ")#mi("{B}")#text(" into ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(", it is convenient to think of ")#mi("{B}")#text(" as a lattice in a ")#mi("{D}")#text("-dimensional vector space, which (due to the presence of ")#mi("{i}")#text(", which excludes purely real embeddings) is naturally thought of as the product of ")#mi("{D/2}")#text(" copies of ")#mi("{{\\bf C}}")#text(". For instance, in the running example, one can identify a ring element ")#mi("{B}")#text(" with an element")

#mi("\\displaystyle ( a + b i + c \\sqrt{3} + d i \\sqrt{3}, a - b i + c \\sqrt{3} - d i \\sqrt{3} )")#text(" of ")#mi("{{\\bf C}^2}")#text(", and with this embedding ")#mi("{B}")#text(" becomes a lattice in ")#mi("{{\\bf C}^2}")#text(". In general, the embedding of ")#mi("{B}")#text(" into ")#mi("{{\\bf C}^{D/2}}")#text(" is essentially the ")#link("https://en.wikipedia.org/wiki/Hadamard_transform")[#text("Walsh–Fourier transform")]#text(", weighted by the various square roots of ")#mi("{q_1,\\dots,q_g}")#text(". (The appearance of the Walsh-Fourier transform reflects the fact that the specific number field we are working with is an abelian Galois extension with Galois group ")#mi("{({\\mathbb Z}/2{\\mathbb Z})^{g+1}}")#text(".) Because of this, one can readily compute the covolume of the lattice, which up to lower order terms is basically ")#mi("{(\\sqrt{q_1} \\dots \\sqrt{q_g})^D}")#text(", which with our construction can be crudely bounded by ")#mi("{G^{O(gD)}}")#text(". As long as we keep ")#mi("{g}")#text(" small compared to ")#mi("{t/\\log t}")#text(", this covolume will be small compared to ")#mi("{2^{tD}}")#text(" and will end up being a lower order term.")

#text("The reason we care about the covolume (whichis essentially the square root of the ")#link("https://en.wikipedia.org/wiki/Discriminant_of_an_algebraic_number_field")[#text("discriminant")]#text(") is because of Minkowski’s theorem, which we will use in this crude form: ")#link("https://en.wikipedia.org/wiki/Minkowski%27s_theorem")[#text("Minkowski’s theorem")]#text(": any lattice ")#mi("{\\Lambda}")#text(" in a ")#mi("{D}")#text("-dimensional space of covolume ")#mi("{V}")#text(" will contain a non-zero lattice vector of length ")#mi("{O(V^{1/D})}")#text(". Thus for instance ")#mi("{B}")#text(" will contain some vector of length ")#mi("{O(Q^{g/2})}")#text(", and any sublattice of ")#mi("{B}")#text(" of index ")#mi("{I}")#text(" will contain a vector of length ")#mi("{O(I^{1/D} G^{O(g)})}")#text(", and thus also of height ")#mi("{O(I^{1/D} G^{O(g)})}")#text(" by inverting the Walsh-Fourier transform.")

#text("Anyway, suppose that we can find some sublattice ")#mi("{\\Lambda}")#text(" (in fact, they will be ideals, but we will not need this) of ")#mi("{B}")#text(" for which we can obtain the inclusion ")#metadata(none) <tao-7f1b55b860590406f84f>

#mi("\\displaystyle \\Lambda \\cdot \\overline{\\Lambda} \\subset m B, \\ \\ \\ \\ \\ (9)")

#text("that is to say one has ")#mi("{w_1 \\overline{w_2} = 0 \\text{ mod } mB}")#text(" for all ")#mi("{w_1, w_2 \\in \\Lambda}")#text(". Then clearly any element ")#mi("{w}")#text(" of ")#mi("{\\Lambda}")#text(" will obey the congruence ")#link(<tao-c5873eaf8a8419e1c277>)[#text("(7)")]#text(". An obvious choice of ")#mi("{\\Lambda}")#text(" would be ")#mi("{\\Lambda = mB}")#text(", but this is way too sparse: this lattice has index ")#mi("{m^D}")#text(" in ")#mi("{B}")#text(", so the shortest vector one can hope to locate in it will have height ")#mi("{O(m G^{O(g)})}")#text(", which is too large for our purposes. Instead, we would like ")#mi("{\\Lambda}")#text(" to have index ")#mi("{m^{D/2}}")#text(" (which is the smallest it can be while still yielding the inclusion ")#link(<tao-7f1b55b860590406f84f>)[#text("(9)")]#text("); then ")#mi("{\\Lambda}")#text(" will contain a non-zero element ")#mi("{w}")#text(" of height ")#mi("{O(m^{1/2} G^{O(g)})}")#text(", which means that ")#mi("{w \\overline{w}}")#text(" is equal to ")#mi("{m}")#text(" times an element of ")#mi("{B}")#text(" of height ")#mi("{O(G^{O(g)})}")#text(". The number of such elements is ")#mi("{O(G^{O(gD)})}")#text(", which will end up being a lower order term that we can easily pigeonhole away.")

#text("We claim that we can find at least ")#mi("{2^{tD/4}}")#text(" different sublattices ")#mi("{\\Lambda}")#text(" of index ")#mi("{m^{D/2}}")#text(" that obey ")#link(<tao-7f1b55b860590406f84f>)[#text("(9)")]#text(". To verify this claim, it is a straightforward matter to use the Chinese remainder theorem to work “prime by prime”. Indeed, it suffices to show for each of the ")#mi("{t}")#text(" primes ")#mi("{p}")#text(" dividing ")#mi("{m}")#text(", that there are ")#mi("{2^{D/4}}")#text(" different sublattices ")#mi("{\\Lambda_p}")#text(" of ")#mi("{B}")#text(" of index ")#mi("{p^{D/2}}")#text(" that obey the inclusion")

#mi("\\displaystyle \\Lambda_p \\cdot \\overline{\\Lambda_p} \\subset p B.")#text(" We can descend now to the finite ring ")#mi("{B/pB}")#text(", which is a ")#mi("{D}")#text("-dimensional vector space over the finite field ")#mi("{{\\mathbb F}_p}")#text(". The complex conjugation operation descends to an involution on this vector space, and we are looking for ")#mi("{2^{D/4}}")#text(" subspaces ")#mi("{V}")#text(" of dimension ")#mi("{D/2}")#text(" with the property that")

#mi("\\displaystyle  V \\cdot \\overline{V} = 0.")

#text("So now we just need to understand the structure of ")#mi("{B/pB}")#text(". The general ")#link("https://en.wikipedia.org/wiki/Wedderburn%E2%80%93Artin_theorem")[#text("Wedderburn–Artin theorem")]#text(" tells us that this ring is the product of finite fields, but we can be much more explicit here in this specific situation. Exactly as Minkowski embedding maps rings in number fields into product of copies of ")#mi("{{\\bf R}}")#text(" and ")#mi("{{\\bf C}}")#text(" associated to the real and complex embeddings of the ring, we can also embed ")#mi("{B/pB}")#text(" into a product of copies of ")#mi("{{\\mathbb F}_p}")#text(" and ")#mi("{{\\mathbb F}_{p^2}}")#text(", depending on how we assign square roots to ")#mi("{-1}")#text(" or ")#mi("{q_1,\\dots,q_g}")#text(" in ")#mi("{{\\mathbb F}_p}")#text(" or the quadratic extension ")#mi("{{\\mathbb F}_{p^2}}")#text(". We can illustrate this with the running example. As ")#mi("{p = -1}")#text(" mod ")#mi("{4}")#text(", the square roots ")#mi("{\\alpha, -\\alpha}")#text(" of ")#mi("{-1}")#text(" in ")#mi("{{\\mathbb F}_p}")#text(" stay in ")#mi("{{\\mathbb F}_p}")#text(". Suppose first that ")#mi("{3}")#text(" also splits into square roots ")#mi("{\\beta, -\\beta}")#text(" in ")#mi("{{\\mathbb F}_p}")#text(". Then we can embed ")#mi("{B/pB}")#text(" into ")#mi("{{\\mathbb F}_p^4}")#text(" by mapping")

#mi("\\displaystyle  a + b i + c \\sqrt{3} + d i \\sqrt{3} \\mapsto (a + b \\alpha + c \\beta + d \\alpha \\beta, a + b \\alpha + c \\beta - d \\alpha \\beta, a - b \\alpha + c \\beta + d \\alpha \\beta, a - b \\alpha + c \\beta - d \\alpha \\beta).")#text(" By counting elements we see that this embedding is in fact an isomorphism. If instead ")#mi("{3}")#text(" does not split, so that ")#mi("{\\pm \\beta}")#text(" now lie in ")#mi("{{\\mathbb F}_{p^2}}")#text(", then we can embed ")#mi("{B/pB}")#text(" into ")#mi("{ {\\mathbb F}_{p^2}^2}")#text(" by mapping")

#mi("\\displaystyle  a + b i + c \\sqrt{3} + d i \\sqrt{3} \\mapsto (a + b \\alpha + c \\beta + d \\alpha \\beta, a - b \\alpha + c \\beta + d \\alpha \\beta),")#text(" thus we drop half of the previous embeddings as being conjugate to the half that we retain. Again, counting shows that this is an isomorphism.")

#text("In general, one can show that ")#mi("{B/pB}")#text(" is isomorphic to either ")#mi("{{\\mathbb F}_p^D}")#text(" (if all the ")#mi("{q_1,\\dots,q_g}")#text(" split in ")#mi("{{\\mathbb F}_p}")#text(") or ")#mi("{{\\mathbb F}_{p^2}^{D/2}}")#text(" (if at least one of the ")#mi("{q_1,\\dots,q_g}")#text(" does not split). Furthermore, in the former case the ")#mi("{D}")#text(" copies of ")#mi("{{\\mathbb F}_p}")#text(" organize into ")#mi("{D/2}")#text(" conjugate pairs (corresponding to flipping ")#mi("{\\alpha}")#text(" to ")#mi("{-\\alpha}")#text("), and in the latter case the ")#mi("{D/2}")#text(" copies of ")#mi("{{\\mathbb F}_{p^2}}")#text(" organize into ")#mi("{D/4}")#text(" conjugate pairs. By selecting one element from each conjugate pair, and taking ")#mi("{V}")#text(" to be the joint kernel of such elements, we can generate either ")#mi("{2^{D/2}}")#text(" or ")#mi("{2^{D/4}}")#text(" different subspaces ")#mi("{V}")#text(" of dimension ")#mi("{D/2}")#text(" with the desired property that ")#mi("{V \\cdot \\overline{V} = 0}")#text(". By the aforementioned Chinese remainder argument, this gives the ")#mi("{2^{tD/4}}")#text(" claimed lattices ")#mi("{\\Lambda}")#text(" of index ")#mi("{m^{D/2}}")#text(".")

#text("Invoking Minkowski’s theorem, this now generates ")#mi("{2^{tD/4}}")#text(" non-zero vectors ")#mi("{w}")#text(" of height ")#mi("{O( m^{1/2} G^{O(g)})}")#text(" obeying ")#link(<tao-c5873eaf8a8419e1c277>)[#text("(7)")]#text(". There is a technical issue that some of these vectors could conceivably collide with each other; however there is a further Chinese remainder theorem argument (which I will omit here) that shows that any such ")#mi("{w}")#text(" can belong to at most ")#mi("{O(G^{O(gD)})}")#text(" such lattices. So the number of distinct ")#mi("{w}")#text(" generated by this argument is at least ")#mi("{2^{tD/4} / O(G)^{O(gD)}}")#text(", and by pigeonholing one can now also get at least at least ")#mi("{2^{tD/4} / O(G)^{O(gD)}}")#text(" solutions to the equation")

#mi("\\displaystyle  w \\overline{w} = a m")#text(" of height ")#mi("{O( m^{1/2} G^{O(g)})}")#text(" for some ")#mi("{a \\in B}")#text(" of height ")#mi("{O(G^{O(g)})}")#text(". As long as we select")

#mi("\\displaystyle  g \\log G \\asymp g \\log G \\lll t,")#text(" then the ")#mi("{O(G^{O(gD)})}")#text(" type factors can be neglected, and we approximately have")

#mi("\\displaystyle  n \\approx T^{D t / 2}, \\quad d_{am}(P) \\gtrapprox n 2^{Dt/4} \\approx n^{1 + \\frac{\\log 2}{4 \\log T}} \\approx n^{1 + \\frac{\\log 2}{4 \\log t}}")#text(" up to lower order terms. If we choose ")#mi("{g}")#text(" to be a small multiple of ")#mi("{t / \\log t}")#text(", then we soon calculate that ")#mi("{\\log t \\asymp \\log\\log\\log n}")#text(", and we recover Theorem ")#link(<tao-553133ea03bb73bd9d74>)[#text("3")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693215")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2026")])]

#text("A couple of quick things to correct:")

#text("(1) You are missing \\ in an \\in in the first line.")

#text("(2) Right after your equation (6), some amount of your text seems to have been eaten up by a link which displays only as a period.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2026")])]

#text("Are results known for 3D?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693240")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2026")])]

#text("In three dimensions, the best known construction is still a three-dimensional grid. There is a known upper bound, which is closer to the lower bound, but still a gap between them. Thomas Bloom’s ")#link("https://www.erdosproblems.com/1085")[#text("Erdős problem website ")]#text("is a good way to learn about the current status of such problems.")

#text("It does not seem possible to use “vertical amplification” to improve the lower bound. For an explanation of why see section 7 of ")#link("https://arxiv.org/pdf/2605.20695")[#text("Remarks on the disproof of the unit distance conjecture")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01664f309cbd911458fdf98f4e94aaf991345a84ca8b081a859f6e3c3389006a-302f3a5c928fc14e64732c4f9ae003677f1acecaaeefb724b36521c6e13152dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cosmin Pohoata")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693243")[#strong[#text("Cosmin Pohoata")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2026")])]

#text("Curiously, if instead one replaces L^2 norm with L^3 norm, it seems to me that a vertical amplification of the proof of Theorem 4.8 from our recent Croot-Mao-Pohoata-Sheffer-Yip paper (")#link("https://arxiv.org/abs/2606.17487")[#text("https://arxiv.org/abs/2606.17487")]#text(") should still produce a set of n points in R^3 with >> n^{1+c} L^3 unit distances, for some absolute constant c > 0.")

#text("I haven’t checked the details, but the argument should be more or less analogous to what we do in this new paper with Sungchul Lee and Daniel Zhu: ")#link("https://arxiv.org/abs/2607.05374")[#text("https://arxiv.org/abs/2607.05374")]#text(" (and, like in R^2, the 3d construction should also have some additional robustness properties).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693246")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2026")])]

#text("Interesting! For an arbitrary norm, one can always get a constant times n unit distances by putting the points on a line with each one a unit distance from the previous one.")

#text("For the usual norm on the plane, the horizontal amplification beats this by an amount less than any power of n, and this is the classical construction, and the vertical amplification beats this by a small power of n. In higher dimensions, for the usual norm, the vertical amplification beats the trivial bound by a small power of n (for example just by restricting to the plane) but now the horizontal amplification beats the trivial bound by a larger power of n since there are many ways of writing an integer as a sum of squares (basically by pigeonhole), so there’s no clear way to improve on the classical construction.")

#text("For a generic norm, one can’t beat the trivial bound by any power of n.")

#text("However, you observe that one can find norms with enough algebraic structure that vertical amplification beats the trivial bound by a small power of n, but not so much algebraic structure that horizontal amplification beats the trivial bound by a larger power of n. It might be interesting to understand the set of such norms.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693220")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2026")])]

#text("There seems to be a typo in the last sentence of the paragraph")

#text("“But if one can permit the degree")

#link("https://s0.wp.com/latex.php?latex=%7BD%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7BD%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("to grow in the construction, and in particular be superpolynomial in")

#link("https://s0.wp.com/latex.php?latex=%7Bt%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7Bt%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text(", then the above heuristics suggest that we can start improving upon Theorem ")#link(<tao-5f80c8e3faa99b558cd4>)[#text("1")]#text(" , and even get all the way to Theorem ")#link(<tao-7d3194f79e645c42e439>)[#text("2")]#text(" if we can make the degree go to infinity while keeping the number the number of primes")

#link("https://s0.wp.com/latex.php?latex=%7Bt%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7Bt%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text(".”")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84695016bafdeb331838d7af7594d1d4f46973b9a891b020abd5ceb85406af1e-aa4dbfdeec683ceed77a7f89b286681ed35d8a3129fa58a03dbde91910175355.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of garylangford")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693226")[#strong[#text("garylangford")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2026")])]

#text("I found it particularly interesting how your exposition recasts the Erdős, Mythos, and OpenAI constructions as members of a single parameterized family rather than presenting them as three unrelated arguments. The progression through geometry, norm equations, algebraic integers, number fields, lattices, and finite quotients made it seem that the principal advance is not simply a stronger counting argument, but a sequence of increasingly informative mathematical representations. Likewise, viewing the constructions through the parameters (horizontal amplification) and (vertical amplification) provides a common coordinate system in which the three approaches become different regions of the same landscape, rather than fundamentally different methods.")

#text("This led me to wonder whether, beyond the parameterization itself, you see a structural invariant that is preserved across all three constructions. Is there an object or organizing principle that you regard as remaining essentially unchanged as one moves from the Erdős construction through Mythos to the OpenAI construction, with and serving primarily as coordinates on that underlying structure?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2026")])]

#text("I am an UCLA student. I am finding these tricks found by AI to be somewhat (or even closely) analogous to algebraic geometric and number theoretic codes and lattices found by Manin, Vladut, Tsfasman and others (")#link("https://www.google.com/books/edition/Algebraic_Geometric_Codes_Basic_Notions/PNt1EAAAQBAJ")[#text("Algebraic Geometric Codes – Google Books")]#text(" and ")#link("https://www.google.com/books/edition/Algebraic_Geometry_Codes_Advanced_Chapte/tjugDwAAQBAJ")[#text("Algebraic Geometry Codes – Google Books")]#text("). Here also packing is the theme. Broadly speaking has AI unearthed a previously unknown dictionary surreptitiously knowing constructions in these? The number of people studying the intersections of these known constructions and Erdos problems is maybe virtually 0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693241")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2026")])]

#text("The relation to prior work on codes and lattices was pointed out in the paper ")#link("https://arxiv.org/pdf/2605.20695")[#text("Remarks on the disproof of the unit distance conjecture")]#text(". It has been somewhat helpful in followup work – the work of Tsfasman on the unit group lattice was one of the inspirations for arguments in Bloom-Sawin-Schildkraut-Zhelezov, and work on codes arising from curves over finite fields was relevant too.")

#text("Indeed, one way to state the insight of the AI is that some of the constructions that work for these packing and coding problems also work for the seemingly different unit distance problem and for others. The sum-product problem might provide the most intuitive explanation of why that is: The crucial thing there is that both the additive group and the multiplicative group of the same number field give reasonably dense packings, which is used to get a set exhibiting both additive and multiplicative structure.")

#text("Sets exhibiting additive and multplicative structure can give good unit distance sets basically because two complex numbers have distance 1 if their difference has norm 1 and difference is, up to sign, the same as addition, while norm 1 complex numbers form a multiplicative subgroup.")

#text("Certainly now I think people are thinking about the intersection of these topics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46c576909e5325621a5a5f7af46c270b2fa5921c01c0e2b1f4c8472884660b8a-eca1f519dba4614c31394c94302bd6b5b560ebca6a7c9d1ad8f2825fa043232c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pantelis Rodis")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693232")[#strong[#text("Pantelis Rodis")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2026")])]

#text("I am especially interested in the algorithmic approach to the unit distance problem and I developed an experimental approach to it; see the paper in ")#link("https://arxiv.org/pdf/2606.29415")[#text("arxiv")]#text(". Specifically, the algorithm performs a greedy search on the rational plane and constructs unit-distance graphs that grow at a rate of $n^1.17$ exceeding theoretical limitations, at least in the finite space in which it ran.")

#text("Although it does not rest on strong theoretical grounds, it provides some interesting insights. I hope you will find it interesting.")

#link("https://arxiv.org/pdf/2606.29415")[#text("https://arxiv.org/pdf/2606.29415")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3945b7809286abba658ee75af873a597740719d68beca61d78cbadb5d7042e9f-6896ba09db6278899bf781123736697877abbcb81ebd9c03118def76a04abd9d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693237")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2026")])]

#text("In your example illustrating the Minkowski embedding, should the second entry have minus signs on the ")#mi("i")#text("‘s?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2026")])]

#text("I tested whether a simple agent based on GPT-5.5 Pro—a publicly available model released before OpenAI announced its disproof—could autonomously prove that the Erdős unit-distance conjecture is false. I conducted eight independent runs in total; each produced a proof that I verified to be essentially correct. The paper, agent code, transcripts, and generated proofs are available at: ")#link("https://github.com/yichenhuang/unit-distance")[#text("https://github.com/yichenhuang/unit-distance")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9580af391efbbce1782924b8c1a8f4acb2e112e9bff2385837abfbd0b4f20ff-18096f248eff194de8b45b4128dc303a0789b5df53e062ebce5c47a01b529e7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wen Huang")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693429")[#strong[#text("Wen Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Follow-up to your Remark (intro): you note all known lower-bound constructions for u(N) lie in rings of algebraic integers. Does this extend to ")#strong[#text("global optima")]#text("?")

#text("Namely: P = all maximizers of u(N) have alg coords; Q = ∃N requiring transcendental.")

#text("If P holds, u(N) search restricts to alg points → Bombieri–Pila/Walsh applicable to the 4/3 upper bound (stuck in incidence 35y). If Q holds, even more striking — a “phase transition” perhaps in your (k,d)-plane?")

#text("Aware of work on the construction–optimum gap from the algebraicity angle?")
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/03/a-digestion-of-unit-distance-constructions/#comment-693430")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2026")])]

#text("For “cheap” reasons, any configuration with transcendental coordinates can be mapped to one with algebraic coordinates (take a transcendence basis for the field of definition, and map them to some generic algebraic numbers). But this is a very qualitative result with extremely poor control on the degree of the resulting algebraic field.")

#text("I don’t see any evidence that focusing on global exact optimizers of the unit distance problem (as opposed to asymptotic optimizers) will lead any particularly new insights; this problem does not have many “local moves” or “global moves” that allow for such an optimality hypothesis to be usefully coercive on the configuration structure. (And it may be that a raw unweighted count of unit distances is actually the wrong statistic to try to directly optimize.)")
]
]
