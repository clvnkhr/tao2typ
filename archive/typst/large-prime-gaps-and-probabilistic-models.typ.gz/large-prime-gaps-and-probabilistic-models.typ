// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/
// Converted to Typst by tao2typ: "2026-10-14T16:38:37.318458+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Large prime gaps and probabilistic models", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Large prime gaps and probabilistic models")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 August 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/")[#text("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.math.missouri.edu/people/banks")[#text("William Banks")]#text(", ")#link("https://faculty.math.illinois.edu/~ford/")[#text("Kevin Ford")]#text(", and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1908.08613")[#text("Large prime gaps and probabilistic models")]#text("“. In this paper we introduce a random model to help understand the connection between two well known conjectures regarding the primes ")#mi("{{\\mathcal P} := \\{2,3,5,\\dots\\}}")#text(", the ")#link("https://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér conjecture")]#text(" and ")#link("https://en.wikipedia.org/wiki/Twin_prime#First_Hardy%E2%80%93Littlewood_conjecture")[#text("the Hardy-Littlewood conjecture")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Cramér conjecture)")]#text(" If ")#mi("{x}")#text(" is a large number, then the largest prime gap ")#mi("{G_{\\mathcal P}(x) := \\sup_{p_n, p_{n+1} \\leq x} p_{n+1}-p_n}")#text(" in ")#mi("{[1,x]}")#text(" is of size ")#mi("{\\asymp \\log^2 x}")#text(". (")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1349149")[#text("Granville")]#text(" refines this conjecture to ")#mi("{\\gtrsim \\xi \\log^2 x}")#text(", where ")#mi("{\\xi := 2e^{-\\gamma} = 1.1229\\dots}")#text(". Here we use the asymptotic notation ")#mi("{X \\gtrsim Y}")#text(" for ")#mi("{X \\geq (1-o(1)) Y}")#text(", ")#mi("{X \\sim Y}")#text(" for ")#mi("{X \\gtrsim Y \\gtrsim X}")#text(", ")#mi("{X \\gg Y}")#text(" for ")#mi("{X \\geq C^{-1} Y}")#text(", and ")#mi("{X \\asymp Y}")#text(" for ")#mi("{X \\gg Y \\gg X}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Hardy-Littlewood conjecture)")]#text(" If ")#mi("{\\mathcal{H} := \\{h_1,\\dots,h_k\\}}")#text(" are fixed distinct integers, then the number of numbers ")#mi("{n \\in [1,x]}")#text(" with ")#mi("{n+h_1,\\dots,n+h_k}")#text(" all prime is ")#mi("{({\\mathfrak S}(\\mathcal{H}) +o(1)) \\int_2^x \\frac{dt}{\\log^k t}}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", where the singular series ")#mi("{{\\mathfrak S}(\\mathcal{H})}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#tao-math("{\\mathfrak S}(\\mathcal{H}) := \\prod_p \\left( 1 - \\frac{\\left|{\\mathcal H} \\text{ mod } p\\right|}{p}\\right) (1-\\frac{1}{p})^{-k}.", block: true)]]
]

#text("(One can view these conjectures as modern versions of two of the classical ")#link("https://en.wikipedia.org/wiki/Landau%27s_problems")[#text("Landau problems")]#text(", namely ")#link("https://en.wikipedia.org/wiki/Legendre%27s_conjecture")[#text("Legendre’s conjecture")]#text(" and the ")#link("https://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("twin prime conjecture")]#text(" respectively.)")

#text("A well known connection between the Hardy-Littlewood conjecture and prime gaps was made ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=409385")[#text("by Gallagher")]#text(". Among other things, Gallagher showed that if the Hardy-Littlewood conjecture was true, then the prime gaps ")#mi("{p_{n+1}-p_n}")#text(" with ")#mi("{n \\leq x}")#text(" were asymptotically distributed according to an ")#link("https://en.wikipedia.org/wiki/Exponential_distribution")[#text("exponential distribution")]#text(" of mean ")#mi("{\\log x}")#text(", in the sense that ")#metadata(none) <tao-b11e23303e7d8bc69ecf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left| \\{ n: p_n \\leq x, p_{n+1}-p_n \\geq \\lambda \\log x \\}\\right| = (e^{-\\lambda}+o(1)) \\frac{x}{\\log x}", block: true)]]



#text(" as ")#mi("{x \\rightarrow \\infty}")#text(" for any fixed ")#mi("{\\lambda \\geq 0}")#text(". Roughly speaking, the way this is established is by using the Hardy-Littlewood conjecture to control the mean values of ")#tao-math("{\\binom{\\left|{\\mathcal P} \\cap (p_n, p_n + \\lambda \\log x)\\right|}{k}}", block: false)#text(" for fixed ")#mi("{k,\\lambda}")#text(", where ")#mi("{p_n}")#text(" ranges over the primes in ")#mi("{[1,x]}")#text(". The relevance of these quantities arises from the ")#link("https://www.encyclopediaofmath.org/index.php/Bonferroni_inequalities")[#text("Bonferroni inequalities")]#text(" (or “")#link("https://en.wikipedia.org/wiki/Brun_sieve")[#text("Brun pure sieve")]#text("“), which can be formulated as the assertion that")

#align(center)[#tao-fit-display[#mitex("1_{N=0} \\leq \\sum_{k=0}^K (-1)^k \\binom{N}{k}")]]

#text("when ")#mi("{K}")#text(" is even and")

#align(center)[#tao-fit-display[#mitex("1_{N=0} \\geq \\sum_{k=0}^K (-1)^k \\binom{N}{k}")]]

#text("when ")#mi("{K}")#text(" is odd, for any natural number ")#mi("{N}")#text("; setting ")#tao-math("{N := \\left|{\\mathcal P} \\cap (p_n, p_n + \\lambda \\log x)\\right|}", block: false)#text(" and taking means, one then gets upper and lower bounds for the probability that the interval ")#mi("{(p_n, p_n + \\lambda \\log x)}")#text(" is free of primes. The most difficult step is to control the mean values of the singular series ")#mi("{{\\mathfrak S}(\\mathcal{H})}")#text(" as ")#mi("{{\\mathcal H}}")#text(" ranges over ")#mi("{k}")#text("-tuples in a fixed interval such as ")#mi("{[0, \\lambda \\log x]}")#text(".")

#text("Heuristically, if one extrapolates the asymptotic ")#link(<tao-b11e23303e7d8bc69ecf>)[#text("(1)")]#text(" to the regime ")#mi("{\\lambda \\asymp \\log x}")#text(", one is then led to Cramér’s conjecture, since the right-hand side of ")#link(<tao-b11e23303e7d8bc69ecf>)[#text("(1)")]#text(" falls below ")#mi("{1}")#text(" when ")#mi("{\\lambda}")#text(" is significantly larger than ")#mi("{\\log x}")#text(". However, this is not a rigorous derivation of Cramér’s conjecture from the Hardy-Littlewood conjecture, since Gallagher’s computations only establish ")#link(<tao-b11e23303e7d8bc69ecf>)[#text("(1)")]#text(" for ")#emph[#text("fixed")]#text(" choices of ")#mi("{\\lambda}")#text(", which is only enough to establish the far weaker bound ")#mi("{G_{\\mathcal P}(x) / \\log x \\rightarrow \\infty}")#text(", which was already known (see ")#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/")[#text("this previous paper")]#text(" for a discussion of the best known unconditional lower bounds on ")#mi("{G_{\\mathcal P}(x)}")#text("). An inspection of the argument shows that if one wished to extend ")#link(<tao-b11e23303e7d8bc69ecf>)[#text("(1)")]#text(" to parameter choices ")#mi("{\\lambda}")#text(" that were allowed to grow with ")#mi("{x}")#text(", then one would need as input a stronger version of the Hardy-Littlewood conjecture in which the length ")#mi("{k}")#text(" of the tuple ")#mi("{{\\mathcal H} = (h_1,\\dots,h_k)}")#text(", as well as the magnitudes of the shifts ")#mi("{h_1,\\dots,h_k}")#text(", were also allowed to grow with ")#mi("{x}")#text(". Our initial objective in this project was then to quantify exactly what strengthening of the Hardy-Littlewood conjecture would be needed to rigorously imply Cramer’s conjecture. The precise results are technical, but roughly we show results of the following form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Large gaps from Hardy-Littlewood, rough statement)")]#text(" ")#metadata(none) <tao-234d8fac0818118b3bb4>

#list(
[#text("If the Hardy-Littlewood conjecture is uniformly true for ")#mi("{k}")#text("-tuples of length ")#mi("{k \\ll \\frac{\\log x}{\\log\\log x}}")#text(", and with shifts ")#mi("{h_1,\\dots,h_k}")#text(" of size ")#mi("{O( \\log^2 x )}")#text(", with a power savings in the error term, then ")#mi("{G_{\\mathcal P}(x) \\gg \\frac{\\log^2 x}{\\log\\log x}}")#text(".")],
[#text("If the Hardy-Littlewood conjecture is “true on average” for ")#mi("{k}")#text("-tuples of length ")#mi("{k \\ll \\frac{y}{\\log x}}")#text(" and shifts ")#mi("{h_1,\\dots,h_k}")#text(" of size ")#mi("{y}")#text(" for all ")#mi("{\\log x \\leq y \\leq \\log^2 x \\log\\log x}")#text(", with a power savings in the error term, then ")#mi("{G_{\\mathcal P}(x) \\gg \\log^2 x}")#text(".")]
)
]

#text("In particular, we can recover Cramer’s conjecture given a sufficiently powerful version of the Hardy-Littlewood conjecture “on the average”.")

#text("Our proof of this theorem proceeds more or less along the same lines as Gallagher’s calculation, but now with ")#mi("{k}")#text(" allowed to grow slowly with ")#mi("{x}")#text(". Again, the main difficulty is to accurately estimate average values of the singular series ")#mi("{{\\mathfrak S}({\\mathfrak H})}")#text(". Here we found it useful to switch to a probabilistic interpretation of this series. For technical reasons it is convenient to work with a truncated, unnormalised version")

#align(center)[#tao-fit-display[#tao-math("V_{\\mathcal H}(z) := \\prod_{p \\leq z} \\left( 1 - \\frac{\\left|{\\mathcal H} \\text{ mod } p\\right|}{p} \\right)", block: true)]]

#text("of the singular series, for a suitable cutoff ")#mi("{z}")#text("; it turns out that when studying prime tuples of size ")#mi("{t}")#text(", the most convenient cutoff ")#mi("{z(t)}")#text(" is the “")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=104639")[#text("Pólya magic cutoff")]#text("“, defined as the largest prime for which ")#metadata(none) <tao-0a27460ea08ea2df4e16>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\prod_{p \\leq z(t)}(1-\\frac{1}{p}) \\geq \\frac{1}{\\log t}")]]



#text(" (this is well defined for ")#mi("{t \\geq e^2}")#text("); by ")#link("https://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("Mertens’ theorem")]#text(", we have ")#mi("{z(t) \\sim t^{1/e^\\gamma}}")#text(". One can interpret ")#mi("{V_{\\mathcal Z}(z)}")#text(" probabilistically as")

#align(center)[#tao-fit-display[#mitex("V_{\\mathcal Z}(z) = \\mathbf{P}( {\\mathcal H} \\subset \\mathcal{S}_z )")]]

#text("where ")#mi("{\\mathcal{S}_z \\subset {\\bf Z}}")#text(" is the randomly sifted set of integers formed by removing one residue class ")#mi("{a_p \\text{ mod } p}")#text(" uniformly at random for each prime ")#mi("{p \\leq z}")#text(". The Hardy-Littlewood conjecture can be viewed as an assertion that the primes ")#mi("{{\\mathcal P}}")#text(" behave in some approximate statistical sense like the random sifted set ")#mi("{\\mathcal{S}_z}")#text(", and one can prove the above theorem by using the Bonferroni inequalities both for the primes ")#mi("{{\\mathcal P}}")#text(" and for the random sifted set, and comparing the two (using an even ")#mi("{K}")#text(" for the sifted set and an odd ")#mi("{K}")#text(" for the primes in order to be able to combine the two together to get a useful bound).")

#text("The proof of Theorem ")#link(<tao-234d8fac0818118b3bb4>)[#text("3")]#text(" ended up not using any properties of the set of primes ")#mi("{{\\mathcal P}}")#text(" other than that this set obeyed some form of the Hardy-Littlewood conjectures; the theorem remains true (with suitable notational changes) if this set were replaced by any other set. In order to convince ourselves that our theorem was not vacuous due to our version of the Hardy-Littlewood conjecture being too strong to be true, we then started exploring the question of coming up with random models of ")#mi("{{\\mathcal P}}")#text(" which obeyed various versions of the Hardy-Littlewood and Cramér conjectures.")

#text("This line of inquiry was started ")#link("https://eudml.org/doc/205441")[#text("by Cramér")]#text(", who introduced what we now call the ")#emph[#text("Cramér random model")]#text(" ")#mi("{{\\mathcal C}}")#text(" of the primes, in which each natural number ")#mi("{n \\geq 3}")#text(" is selected for membership in ")#mi("{{\\mathcal C}}")#text(" with an independent probability of ")#mi("{1/\\log n}")#text(". This model matches the primes well in some respects; for instance, it almost surely obeys the “Riemann hypothesis”")

#align(center)[#tao-fit-display[#tao-math("\\left| {\\mathcal C} \\cap [1,x] \\right| = \\int_2^x \\frac{dt}{\\log t} + O( x^{1/2+o(1)})", block: true)]]

#text("and Cramér also showed that the largest gap ")#mi("{G_{\\mathcal C}(x)}")#text(" was almost surely ")#mi("{\\sim \\log^2 x}")#text(". On the other hand, it does not obey the Hardy-Littlewood conjecture; more precisely, it obeys a simplified variant of that conjecture in which the singular series ")#mi("{{\\mathfrak S}({\\mathcal H})}")#text(" is absent.")

#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1349149")[#text("Granville")]#text(" proposed a refinement ")#mi("{{\\mathcal G}}")#text(" to Cramér’s random model ")#mi("{{\\mathcal C}}")#text(" in which one first sieves out (in each dyadic interval ")#mi("{[x,2x]}")#text(") all residue classes ")#mi("{0 \\text{ mod } p}")#text(" for ")#mi("{p \\leq A}")#text(" for a certain threshold ")#mi("{A = \\log^{1-o(1)} x = o(\\log x)}")#text(", and then places each surviving natural number ")#mi("{n}")#text(" in ")#mi("{{\\mathcal G}}")#text(" with an independent probability ")#mi("{\\frac{1}{\\log n} \\prod_{p \\leq A} (1-\\frac{1}{p})^{-1}}")#text(". One can verify that this model obeys the Hardy-Littlewood conjectures, and Granville showed that the largest gap ")#mi("{G_{\\mathcal G}(x)}")#text(" in this model was almost surely ")#mi("{\\gtrsim \\xi \\log^2 x}")#text(", leading to his conjecture that this bound also was true for the primes. (Interestingly, this conjecture is not yet borne out by numerics; calculations of prime gaps up to ")#mi("{10^{18}}")#text(", for instance, have shown that ")#mi("{G_{\\mathcal P}(x)}")#text(" never exceeds ")#mi("{0.9206 \\log^2 x}")#text(" in this range. This is not necessarily a conflict, however; Granville’s analysis relies on inspecting gaps in an extremely sparse region of natural numbers that are more devoid of primes than average, and this region is not well explored by existing numerics. See ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("this previous blog post")]#text(" for more discussion of Granville’s argument.)")

#text("However, Granville’s model does not produce a power savings in the error term of the Hardy-Littlewood conjectures, mostly due to the need to truncate the singular series at the logarithmic cutoff ")#mi("{A}")#text(". After some experimentation, we were able to produce a tractable random model ")#mi("{{\\mathcal R}}")#text(" for the primes which obeyed the Hardy-Littlewood conjectures with power savings, and which reproduced Granville’s gap prediction of ")#mi("{\\gtrsim \\xi \\log^2 x}")#text(" (we also get an upper bound of ")#mi("{\\lesssim \\xi \\log^2 x \\frac{\\log\\log x}{2 \\log\\log\\log x}}")#text(" for both models, though we expect the lower bound to be closer to the truth); to us, this strengthens the case for Granville’s version of Cramér’s conjecture. The model can be described as follows. We select one residue class ")#mi("{a_p \\text{ mod } p}")#text(" uniformly at random for each prime ")#mi("{p}")#text(", and as before we let ")#mi("{S_z}")#text(" be the sifted set of integers formed by deleting the residue classes ")#mi("{a_p \\text{ mod } p}")#text(" with ")#mi("{p \\leq z}")#text(". We then set")

#align(center)[#tao-fit-display[#mitex("{\\mathcal R} := \\{ n \\geq e^2: n \\in S_{z(t)}\\}")]]

#text("with ")#mi("{z(t)}")#text(" Pólya’s magic cutoff (this is the cutoff that gives ")#mi("{{\\mathcal R}}")#text(" a density consistent with the prime number theorem or the Riemann hypothesis). As stated above, we are able to show that almost surely one has ")#metadata(none) <tao-cdca5ece79dc4dc618f1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\xi \\log^2 x \\lesssim {\\mathcal G}_{\\mathcal R}(x) \\lesssim \\xi \\log^2 x \\frac{\\log\\log x}{2 \\log\\log\\log x}")]]



#text(" and that the Hardy-Littlewood conjectures hold with power savings for ")#mi("{k}")#text(" up to ")#mi("{\\log^c x}")#text(" for any fixed ")#mi("{c < 1}")#text(" and for shifts ")#mi("{h_1,\\dots,h_k}")#text(" of size ")#mi("{O(\\log^c x)}")#text(". This is unfortunately a tiny bit weaker than what Theorem ")#link(<tao-234d8fac0818118b3bb4>)[#text("3")]#text(" requires (which more or less corresponds to the endpoint ")#mi("{c=1}")#text("), although there is a variant of Theorem ")#link(<tao-234d8fac0818118b3bb4>)[#text("3")]#text(" that can use this input to produce a lower bound on gaps in the model ")#mi("{{\\mathcal R}}")#text(" (but it is weaker than the one in ")#link(<tao-cdca5ece79dc4dc618f1>)[#text("(3)")]#text("). In fact we prove a more precise almost sure asymptotic formula for ")#mi("{{\\mathcal G}_{\\mathcal R}(x) }")#text(" that involves the optimal bounds for the ")#emph[#text("linear sieve")]#text(" (or ")#emph[#text("interval sieve")]#text("), in which one deletes one residue class modulo ")#mi("{p}")#text(" from an interval ")#mi("{[0,y]}")#text(" for all primes ")#mi("{p}")#text(" up to a given threshold. The lower bound in ")#link(<tao-cdca5ece79dc4dc618f1>)[#text("(3)")]#text(" relates to the case of deleting the ")#mi("{0 \\text{ mod } p}")#text(" residue classes from ")#mi("{[0,y]}")#text("; the upper bound comes from the delicate analysis of the linear sieve ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=296043")[#text("by Iwaniec")]#text(". Improving on either of the two bounds looks to be quite a difficult problem.")

#text("The probabilistic analysis of ")#mi("{{\\mathcal R}}")#text(" is somewhat more complicated than of ")#mi("{{\\mathcal C}}")#text(" or ")#mi("{{\\mathcal G}}")#text(" as there is now non-trivial coupling between the events ")#mi("{n \\in {\\mathcal R}}")#text(" as ")#mi("{n}")#text(" varies, although moment methods such as the second moment method are still viable and allow one to verify the Hardy-Littlewood conjectures by a lengthy but fairly straightforward calculation. To analyse large gaps, one has to understand the statistical behaviour of a random linear sieve in which one starts with an interval ")#mi("{[0,y]}")#text(" and randomly deletes a residue class ")#mi("{a_p \\text{ mod } p}")#text(" for each prime ")#mi("{p}")#text(" up to a given threshold. For very small ")#mi("{p}")#text(" this is handled by the deterministic theory of the linear sieve as discussed above. For medium sized ")#mi("{p}")#text(", it turns out that there is good concentration of measure thanks to tools such as ")#link("https://en.wikipedia.org/wiki/Bennett%27s_inequality")[#text("Bennett’s inequality")]#text(" or ")#link("https://en.wikipedia.org/wiki/Azuma%27s_inequality")[#text("Azuma’s inequality")]#text(", as one can view the sieving process as a martingale or (approximately) as a sum of independent random variables. For larger primes ")#mi("{p}")#text(", in which only a small number of survivors are expected to be sieved out by each residue class, a direct combinatorial calculation of all possible outcomes (involving the random graph that connects interval elements ")#mi("{n \\in [0,y]}")#text(" to primes ")#mi("{p}")#text(" if ")#mi("{n}")#text(" falls in the random residue class ")#mi("{a_p \\text{ mod } p}")#text(") turns out to give the best results.")

#heading(level: 1)[#text("Comments (47)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d33b7136a506a6b0e8deb05d0ba9cfa4997c269e3c0901344c1562ebc50c4808-7a1849d23fba6196afe727988c83396bf2d3b5befcd9e9b6ecbddcfb3a612242.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thebirdreader")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520385")[#strong[#text("thebirdreader")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("Why do you reveal the journal you submitted it to? More generally, what’s the policy around this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520388")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("It’s nice of William Banks and Kevin Ford that they’ve helped you in uploading your own paper ;)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("In the very first sentence, “my paper” should be “our paper”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("Is it possible to improve the upper bound in (3) by optimizing “Polya magic cutoff” (perhaps by a slight modification of (2))?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520403")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("Varying the cutoff ")#mi("z")#text(" significantly would vary the density of the set ")#mi("{\\mathcal R}")#text(", which would then also vary the lower and upper bounds we obtain for the largest gap (but the ratio between the upper and lower bounds would be essentially unchanged). The more precise version of (3) given in the paper involves the function ")#mi("g(u)")#text(", defined as the largest ")#mi("y")#text(" for which it is possible to delete one residue class mod ")#mi("p")#text(" from ")#mi("[0,y]")#text(" for each prime ")#mi("p \\leq (y/\\log y)^{1/2}")#text(" and end up with at most ")#mi("u/\\log y")#text(" survivors. We basically show that the largest gap ")#mi("{\\mathcal G}_{\\mathcal R}(x)")#text(" is almost surely asymptotic to ")#mi("g(\\xi \\log^2 x)")#text(". On the other hand, the best known bounds on ")#mi("g(u)")#text(" are")

#mi("\\displaystyle u \\lesssim g(u) \\lesssim \\frac{u \\log u}{4 \\log\\log u}")

#text("which is where the bounds (3) are coming from. We believe the lower bound here is closer to the truth, but improving the upper bound requires improving Iwaniec’s bound on the linear sieve, which is likely to be a very difficult problem (relating to breaking the notorious “parity barrier”). In an appendix to our paper we elaborate on the link with the parity problem by recording the folklore observation that a sufficiently strong Siegel zero can lead to a significant improvement in the lower bound for ")#mi("g(u)")#text(" and hence for ")#mi("{\\mathcal G}_{\\mathcal R}(x)")#text(". So showing that the lower bound is sharp is at least as hard as ruling out Siegel zeroes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520588")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2019")])]

#text("Is it necessary to use the same cutoff for both (upper and lower) bounds? Is it possible to optimize the cutoff for the lower bound and use another optimized cutoff for the upper bound?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520408")[#strong[#text("Two conjectures in one – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")]

#text("[…] William Banks, Kevin Ford, and I have just uploaded to the arXiv my paper “Large prime gaps and probabilistic models“, submitted to Inventiones. In this paper we introduce a random model to help understand the connection between two well known conjectures regarding the primes {{mathcal P} := {2,3,5,dots}}, the Cramér conjecture and the Hardy-Littlewood conjecture: … (Terence Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c6a36407d4be468c0a8024beb25723d5c8c8caf75cb7b116d69955550ba9f2c-c7727639b732d46296836c835109404887e284338b2082ff5dce07cbb7997a98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zachary Kyle Knutson")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520427")[#strong[#text("Zachary Kyle Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("Research gate my sample 2 that was my idea…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c6a36407d4be468c0a8024beb25723d5c8c8caf75cb7b116d69955550ba9f2c-c7727639b732d46296836c835109404887e284338b2082ff5dce07cbb7997a98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zachary Kyle Knutson")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520492")[#strong[#text("Zachary Kyle Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2019")])]

#link("https://www.researchgate.net/publication/327477654_Sample_2_Update_J_Equation")[#text("https://www.researchgate.net/publication/327477654_Sample_2_Update_J_Equation")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c6a36407d4be468c0a8024beb25723d5c8c8caf75cb7b116d69955550ba9f2c-c7727639b732d46296836c835109404887e284338b2082ff5dce07cbb7997a98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zachary Kyle Knutson")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520493")[#strong[#text("Zachary Kyle Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2019")])]

#text("yall misunderstand that was to comment not lol to Mr.Terrance…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520535")[#strong[#text("Some Math News | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2019")]

#text("[…] too bad Pat didn’t live to see the latest from Terry Tao, who describes recent results which are related to old work of Gallagher’s by “Our […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e56585db621b41a08296d5c75274bec46a17836a6830fb83773a5f2164759dd7-e8e57b7792a08c4612542db934f36f2ef1215b4825ead7345e8179acf0255d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520572")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2019")])]

#text("Sorry can I ask a very basic question about the constant S(H) in the Hardy-Littlewood conjecture? I would have looked it up on Wikipedia but curiously the first HL-conjecture doesn’t have a page (while the probably-false second HL-conjecture does). As written here it seems to me that the constant equals 0 when all $h_i$ lie in the same congruence class mod $p$ for some $p$, e.g. when they are all even. That seems a bit strange in light of the twin prime conjecture. Conversely I would expect the constant to become 0 when for some $p$ we have$|H mod p| = p$, i.e. the $h_i$ together cover all congruence classes mod $p$, but in this case the contribution of the prime $p$ to the constant seems to be non-zero. Am I missing something obvious here? What is the rationale behind the product making up $S(H)$?")

#emph[#text("[Oops, there was a typo in the definition of the singular series in the blog post, which has now been fixed. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 年轻的数学家")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520656")[#strong[#text("年轻的数学家")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2019")])]

#text("Dear Prof. Tao,")

#text("first of all, there seems to be a typo in the conclusion of thm. 1.5 (or do they also use the lower index for iteration?). Then, I wonder whether even stronger Hardy‒Littlewood-type estimates would imply even stronger bounds on ")#mi("G_{\\mathcal P}(x)")#text(". Also, what about upper bounds? Without having read the paper, the Bonferroni inequalities as stated above seem pretty symmetrical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520753")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("The lower index is indeed used for iteration (see the top of page 2).")

#text("Unfortunately, it appears that Hardy-Littlewood type conjectures can only be used to impose lower bounds on gaps, not upper bounds. To show that there is a prime gap of size at least H, it suffices to show that the number of ")#mi("n")#text(" in a given range such that the tuple ")#mi("\\{n,n+1,\\dots,n+H\\}")#text(" is free of primes is positive; and this can in principle be done by the lower bound Bonferroni inequality and Hardy-Littlewood. But to show that all prime gaps have size at most H, one has to show that the number of ")#mi("n")#text(" for which the tuple ")#mi("\\{n,n+1,\\dots,n+H\\}")#text(" is ")#emph[#text("zero")]#text(". One could only achieve this from an upper bound Bonferroni inequality if the upper bound was absolutely tight (no error term allowed at all), which is basically impossible from analytic number theory techniques (for instance, the Hardy-Littlewood conjectures contain an error term and are thus not usable for such a strategy).")

#text("One can also see this using the “")#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/")[#text("redacted primes")]#text("” test. One can “plant” a large gap in the primes by deleting an interval ")#mi("\\{n,n+1,\\dots,n+H\\}")#text(" from the set of primes. For ")#mi("H")#text(" much smaller than the range ")#mi("x")#text(" (e.g. ")#mi("H = \\log^{10} x")#text("), such a deletion will hardly make an impact on any of the Hardy-Littlewood conjectures (it will easily get absorbed into the error term). Thus these conjectures cannot prevent the creation of an extremely large gap.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 年轻的数学家")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520658")[#strong[#text("年轻的数学家")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2019")])]

#text("I’d also be interested in estimates for ")#mi("g")#text(" that would prove stronger bounds on ")#mi("G_{\\mathcal P}(x)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 年轻的数学家")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520659")[#strong[#text("年轻的数学家")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2019")])]

#text("I realise that according to the above, one would need to disprove the existence of Siegel zeroes. So I’m in fact asking for upper bounds in the event that both the Riemann hypothesis and strong Hardy‒Littlewood-type estimates are true.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mefes")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520749")[#strong[#text("Mefes")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("Good connection, but seems that landau’s problems are not provable though")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520772")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("Dr.Tao, we can deduce the Hardy-Littlewood conjectures without using probabilistic models. You can see my article: ")#link("https://lagrida.com/conjecture_k_uple.html")[#text("https://lagrida.com/conjecture_k_uple.html")]#linebreak()#text(" Where i prove ")#mi("I_{\\mathcal{H}_k}(x) = \\mathcal{G}_k \\, e^{-\\gamma k} \\, \\dfrac{x}{\\log(\\log(x))^k} \\, (1+o(1))")

#text("With : ")#mi("I_{\\mathcal{H}_k}(x) = \\#\\{(b,b+h_1,\\cdots,b+h_{k-1})\\in \\mathcal{B}_{q(x)}^k \\, | \\, b+h_{k-1} \\leq x\\}")#text(" and ")#mi("\\mathcal{B}_q = \\{b \\in \\mathbb{N}^{*} \\, | \\, \\gcd(b, \\displaystyle{\\small \\prod_{\\substack{p \\leq q \\\\ \\text{p premier}}} {\\normalsize p}})=1 \\}")#text(" and ")#mi("q(x)")#text(" is the largest prime verify ")#mi("\\displaystyle{\\small \\left(\\prod_{\\substack{p \\leq q(x) \\\\ \\text{p premier}}} {\\normalsize p}\\right)} \\leq x")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520775")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("And f course ")#mi("\\displaystyle \\mathcal{G}_k = \\prod_{\\text{p premier}}\\frac{1-\\frac{w(\\mathcal{H}_k, p)}{p}}{(1-\\frac1p)^{k}}")

#text("With ")#mi("w(\\mathcal{H}_k, p)")#text(" is the number of distinct residues $\\pmod p$ in $\\mathcal{H}_k$.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520792")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("Hmm. On the largest gap or space, G(X), between consecutive primes less than or equal to large real X, I believe G(x) ≤ (log X)^2 is true according to an analysis involving the Prime Number Theorem and the average spacing between consecutive primes less than or equal to large real X.")

#text("Relevant Reference Link:")

#text("“LARGE GAPS BETWEEN CONSECUTIVE PRIME NUMBERS”,")

#link("https://www.math10.com/forum/viewtopic.php?f=63&t=8263")[#text("https://www.math10.com/forum/viewtopic.php?f=63&t=8263")]

#text("David Cole.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520793")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("Of course, the calculations are estimates/approximations within the known bounds of error associated with PNT/Riemann Prime-Counting Function for all large X… Our model/proof appears to be sound. David Cole.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520794")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("Remark: Riemann Hypothesis is true! David Cole. :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520876")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2019")])]

#text("Now I wonder why I even bother to visit this website/webpage… I always receive no positive feedback or worse. I will stop visiting this site in the future and this is my last comment and visit too. However, I do appreciate the information I gain here in the past. Thank you and goodbye. David Cole.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a778b2ba58f0a83758d062a31b82125493a164e454bac4ed73a5f0b4cb8b8e89-caa1cd9f5051dd9589cb04a35a3d8e1d4fec68bd79393a9eb54194c68326ea90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520799")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("A possibly naive question: do you know if the constant 3/2 is optimal your Theorem 1.4, for the random model?")

#text("Also, does this model make predictions for the number of primes in short intervals much larger than log(x), along the lines of this paper of Montgomery and Soundararajan ")#link("https://arxiv.org/pdf/math/0409258.pdf")[#text("https://arxiv.org/pdf/math/0409258.pdf")]#text(" (e.g. Corollary 1 there)? I guess Theorem 1.3 of your paper allows one to directly reproduce Montgomery and Soundararajan’s computation for intervals of length up to exp(log(x)^{1/2}/loglog(x)), but for this model is there a more direct route that doesn’t pass through the computation of that paper, and is it feasible to consider short intervals larger than this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-520800")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2019")])]

#text("We didn’t seriously try to optimise the exponent in Theorem 1.4, which arises basically from the second moment method and the Borel-Cantelli lemma. One could perhaps do a bit better by exploiting higher moments, but they become more difficult to compute.")

#text("I was planning to ask a graduate student to look into how what this model predicts for primes in short intervals; as we remark in Section 2.5, one does have the analogue of the Maier fluctuations in this model, but we didn’t quantify the size of these fluctuations precisely.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-521062")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2019")])]

#text("If you assume a Heath-Brown-type “conjecture” that the Hardy-Littlewood asymptotic holds with O(1) error term, can you deduce anything more about gaps?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-521064")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2019")])]

#text("I just noticed that the Heath-Brown’s “conjecture” already precludes the qualitative Hardy-Littlewood conjecture, as well as the Granville-Cramer gap prediction, so I’m not sure if there is much sense to be made from my question.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8de5e657fc101702b7b8285747ad6fc25a2dfbe960263701725dbb99b72760-c9c35a2432d01b3d7ef381e03f566399ce714a083d496f75b6c725d7eaa64ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-521698")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2019")])]

#text("Let ")#mi("d_{n}=p_{n+1}-p_n")#text(", then there exists ")#mi("x_0 \\in \\mathbb{N}")#text(" such that for ")#mi("p_n > x_0")#text(" one obtains ")#mi("d_{n+1} \\ll O(p_{n+1}/\\log p_n)")#text(", with the implied constant depending on ")#mi("x_0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/643d2de1b501b3ce5b6c8efd04bb420e1f128e0db0bbd3eaafa3413082e8b2b1-dc380854e198eef069da9b75ec2b16538ea6d09a2e799d28464821b49394a8be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of humble suggestion")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-521920")[#strong[#text("humble suggestion")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("I wonder if it might be worthwhile for Terry to hire an undergrad to periodically delete the nonsense in the comment sections. The posts about high profile results (and to a lesser extent, many other posts) tend to attract a lot of personal or crackpottish comments that are either off topic or nonsensical.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kipperock")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-521930")[#strong[#text("Kipperock")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("I think that this type of moderation would be welcome, both to the writer and the serious visitors.")#linebreak()#text(" This blog’s comment section is quite important, since, for example, in the comments about Prof. Tao’s books there are both errata and many super important explanations – I’m working through his book on measure theory rn and I just feel how invaluable a neat comment section is.")#linebreak()#text(" When reading other posts, expository or research – it would be very cool to see a neat comment section where serious discussions take place and are not spoiled by – sometimes dozens or more! – comments that are clearly.. not in the right neighborhood.")#linebreak()#text(" I guess I understand why the author refrains from flat out full time moderation – he’s got important research to do, teaching duties, two kids and a wife [this list is not written by order of importance :)))], and there probably are things I simply didn’t think of.")#linebreak()#text(" From my experience(see above, and take my word for it that it was me), it is also very, very tiring – since I would like to see certain comments completely gone, but others deserve at least an attempt at an answer.")#linebreak()#text(" I don’t even read the comments on other posts, in order to not get dragged down into the same mess of time and nerve consuming keyboard kung-fu..")#linebreak()#text(" Honestly I think this comment was just a very long way of saying “I agree”, since this comment section already had it’s way with me. I hope Prof. Tao would eventually accept your suggestion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-523111")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")])]

#text("Is it really a good idea to publish this where anyone can read it when it could help hackers break cryptography or evil governments conduct unjust wars. Even if new cryptographic software could be written people in third world countries could be greatly harmed and would not be able to update in time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/086dae9f911120eea4b6a359376ddfd9b653ec38ff39bfb3f9d7e987451befa9-ab330feac99fa2af64cfbf9e974045aca08b3787cfb571f07596812a121c4de2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhang Tan")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-547138")[#strong[#text("Zhang Tan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Proof of the Twin Prime Conjecture")

#text("Let $p_n$ be the nth prime number")#linebreak()#text(" ")#mi("p_1=2,p_2=3,p_3=5")

#text("Let $P_n$ be the first n prime numbers multiplied together")#linebreak()#text(" ")#mi("P_1=p_1,P_2=p_1 \\times p_2,P_3=p_1 \\times p_2 \\times p_3")

#text("Arithmetic Progression")

#mi("\\{mP_n+a\\}")#linebreak()#text(" where ")#mi("a")#text(" in ")#mi("A_n")#text(" where ")#mi("a")#text(" is relatively prime to ")#mi("P_n")#text(" and less than ")#mi("P_n")#text(" and ")#mi("0 \\leq m < p_{n+1}")

#text("There always exist numbers ")#mi("a_1")#text(" and ")#mi("a_2")#text(" in ")#mi("A_s")#text(" succh that ")#mi("a_1+2=a_2")#text(" where ")#mi("s \\geq 3")

#text("Base Case ")#mi("11,13")#text(" in ")#mi("A_3")

#text("Induction Case")

#text("Let ")#mi("a_1")#text(" and ")#mi("a_2")#text(" in ")#mi("A_n")#text(" such that ")#mi("a_1+d=a_2")#text(" will propagate at least ")#mi("p_{n+1}-2")#text(" pairs of numbers which differs by ")#mi("d")#text(" in ")#mi("A_{n+1}")

#text("There are a total of ")#mi("p_{n+1}")#text(" elements generated by arithmetic progression ")#mi("\\{mP_n+a_1\\}")#text(" and out of all of the generated elements there is unique element ")#mi("m_1P_n+a_1")#text(" divisible by ")#mi("p_{n+1}")

#text("There are a total of ")#mi("p_{n+1}")#text(" elements generated by arithmetic progression ")#mi("\\{mP_n+a_2\\}")#text(" and out of all of the generated elements there is unique element ")#mi("m_2P_n+a_2")#text(" divisible by ")#mi("p_{n+1}")

#text("When ")#mi("m_1 \\neq m_2")#text(" there are ")#mi("p_{n+1}-2")#text(" pairs of numbers ")#mi("(\\{mP_n+a_1\\},\\{mP_n+a_2\\})")#text(" differs by ")#mi("d, a_1+d=a_2")#text(" in ")#mi("A_{n+1}")

#text("When ")#mi("m_1 = m_2")#text(" there are ")#mi("p_{n+1}-1")#text(" pairs of numbers ")#mi("(\\{mP_n+a_1\\},\\{mP_n+a_2\\})")#text(" differs by ")#mi("d, a_1+d=a_2")#text(" in ")#mi("A_{n+1}")

#text("Arithmetic Progression")

#mi("\\{mP_n+a\\}")#text(" where ")#mi("a")#text(" in ")#mi("A_n")#text(" where ")#mi("a")#text(" is relatively prime to ")#mi("P_n")#text(" and less than ")#mi("P_n")#text(" and ")#mi("0 \\leq m < P_n")

#text("If there exist an element in ")#mi("\\{mP_n+a_1\\}")#text(" divisible by ")#mi("f")#text(" than in ")#mi("f")#text(" consecutive elements ")#mi("x \\leq m < x+f")#text(" generated by arithmetic progression ")#mi("\\{mP_n+a_1\\}")#text(" there exist unique element ")#mi("m_1P_n+a_1")#text(" divisble by ")#mi("f")

#text("Proof of twin prime conjecture by contradiction")

#text("For there to not exist two prime numbers which differs by ")#mi("d, a_1+d=a_2")#linebreak()#text(" There must exist a non-prime number for every value of ")#mi("m, 0 \\leq m <P_n")#text(" in either ")#mi("\\{mP_n+a_1\\}")#text(" or $\\{mP_n+a_2\\}$")

#text("All non-prime numbers greater than 1 in ")#mi("\\{mP_n+a\\}")#text(" where ")#mi("a")#text(" in ")#mi("A_n")#text(" where ")#mi("a")#text(" in relatively prime to ")#mi("P_n")#text(" and less than ")#mi("P_n")#text(" and ")#mi("0 \\leq m < P_n")#text(" must be divisible by an odd number ")#mi("f")#text(" where ")#mi("3 \\leq f \\leq P_n-1")

#text("Removing pairs of numbers from ")#mi("(\\{mP_n+a_1\\},\\{mP_n+a_2\\})")#text(" where either ")#mi("\\{mP_n+a_1\\}")#text(" or ")#mi("\\{mP_n+a_2\\}")#text(" divisible by ")#mi("f=P_n-1-2o")#text(" where ")#mi("3 \\leq f \\leq P_n-1")

#text("Consider ")#mi("f=P_n-1")#text(" consective elements ")#mi("x \\leq m < x+f")#text(" generated by arithmetic progression ")#mi("\\{mP_n+a_1\\}")#text(" Assume there exist ")#mi("m_1P_n+a_1")#text(" divisible by ")#mi("f")#text(" it is unique in these consecutive elements.")

#text("Consider ")#mi("f=P_n-1")#text(" consective elements ")#mi("x \\leq m < x+f")#text(" generated by arithmetic progression ")#mi("\\{mP_n+a_2\\}")#text(" Assume there exist ")#mi("m_2P_n+a_2")#text(" divisible by ")#mi("f")#text(" it is unique in these consecutive elements.")

#text("Assume ")#mi("m_1 \\neq m_2")

#text("Assume the remaining ")#mi("f-2")#text(" pairs not divisible by ")#mi("f")#text(" are consective.")

#text("Taking the remaining consecutive ")#mi("f-2")#text(" pairs not divisible by ")#mi("f")#text(" remove pairs divisible by ")#mi("f-2")

#text("Consider ")#mi("f=P_n-1-2")#text(" consective elements ")#mi("x \\leq m < x+f")#text(" generated by arithmetic progression ")#mi("\\{mP_n+a_1\\}")#text(" Assume there exist ")#mi("m_1P_n+a_1")#text(" divisible by ")#mi("f")#text(" it is unique in these consecutive elements.")

#text("Consider ")#mi("f=P_n-1-2")#text(" consective elements ")#mi("x \\leq m < x+f")#text(" generated by arithmetic progression ")#mi("\\{mP_n+a_2\\}")#text(" Assume there exist ")#mi("m_2P_n+a_2")#text(" divisible by ")#mi("f")#text(" it is unique in these consecutive elements.")

#text("Assume ")#mi("m_1 \\neq m_2")

#text("Assume the remaining ")#mi("f-2")#text(" pairs not divisible by ")#mi("f")#text(" are consective.")

#text("Continue repeating until with all smaller odd numbers ")#mi("f=P_n-1-2o")#text(" where ")#mi("o=0,1,2,3,\\ldots")#text(" until ")#mi("f=3")

#text("There must exist a prime number in ")#mi("\\{m_1P_n+a_1\\}")#text(" and ")#mi("\\{m_2P_n+a_2\\}")#text(" where ")#mi("m_1=m_2")#text(" and ")#mi("0 \\leq m < P_n")

#text("Therefore there are infinite number of prime numbers which differ by 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4372610114848a00ed22cb2286a270d618f18c7dfeac3b5e473826a2aa1d38ed-65fba7807ad67416859e2ee849f1a04147cfe2d6d0c03021c4149efce86251b0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Pickett")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-602260")[#strong[#text("Thomas Pickett")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2020")])]

#text("My paper titled:")

#text("“Structure is found in Prime Numbers and Gaps are Unbounded as the Quantity of Twin and Cousin Primes Run Neck and Neck Through Infinity”")

#text("Addresses “Large Prime Gaps”.")#linebreak()#text(" It can be found at:")

#link("http://www.primealignmentmatrix.com")[#text("http://www.primealignmentmatrix.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4068e32ee0511df707c32ef91fe5cb9f89448c4ea856980117e368613d0382eb-6dc75fece3532646cc2b6f40dd8e831b7361380dbe21ae08e46e9efc8ae4a8c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leigh")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-639725")[#strong[#text("Leigh")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2022")])]

#text("How does the GUE hypothesis ‘know’ that the prime counting function (or related counting functions) are piecewise constant? When you say “…we have the GUE hypothesis which appears to accurately model the zeta function, but does not capture such basic properties of the primes as the fact that the primes are all natural numbers,” it sounds like you are taking for granted that other distributions of the zeros will still lead to a sensible counting function. Or maybe I am reading too much into this statement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-639741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("In fact none of the plausible models for the distribution for the zeta functions are able to detect the piecewise constancy of the prime counting function. This can be explained in terms of the uncertainty principle (see e.g., the discussion at the end of Section 2 of ")#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("this blog post of mine")]#text("): when trying to use the zeta function ")#mi("\\zeta(1/2+it)")#text(" to understand sums like ")#mi("\\sum_{n \\leq x} \\Lambda(n)")#text(", the uncertainty principle tells us that")

#mi("\\Delta t \\times \\Delta \\log x \\gg 1")

#text("or by the chain rule")

#mi("\\Delta t \\times \\Delta x \\gg x")

#text("To see the piecewise constancy of the prime counting function, one has to resolve the spatial uncertainty down to unit scales, so we need ")#mi("\\Delta x \\ll 1")#text(", which by the uncertainty principle forces ")#mi("\\Delta t \\gg x")#text(". That is to say, we need information on the zeroes on an interval of length ")#mi("\\gg x")#text(" before we could even hope to detect this piecewise constancy. On the other hand, GUE and related models only cover intervals in ")#mi("t")#text("-space of length ")#mi("O(1)")#text(" (or even ")#mi("O(1/\\log T)")#text(") at best, and so have nowhere near the resolution to see these effects; as far as the GUE model (or any other local model for the zeroes) is concerned, the integers and primes may well be continuously distributed.")

#text("It would be a major breakthrough if there was some new way to exploit the discrete nature of the integers and primes that would be visible on the zeta function side, thus circumventing this uncertainty principle barrier. The most obvious instance of this is the functional equation, which ultimately derives from the Poisson summation formula applied to the integers which one can view as a discrete subgroup of the reals. Some of the more advanced bounds on exponential sums related to the zeta function also rely more heavily on the arithmetic structure of the integers, but again not at anywhere near the resolution needed to say much about zeroes on the critical line (though they can help for instance with zero free regions and some zero density estimates, as well as subconvexity bounds).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4068e32ee0511df707c32ef91fe5cb9f89448c4ea856980117e368613d0382eb-6dc75fece3532646cc2b6f40dd8e831b7361380dbe21ae08e46e9efc8ae4a8c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leigh")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-639769")[#strong[#text("Leigh")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("OK that makes sense, thanks very much. I posted the above question on Math Stack Exchange (")#link("https://math.stackexchange.com/questions/4321777/riemanns-explicit-prime-counting-formula-how-is-it-piecewise-constant")[#text("https://math.stackexchange.com/questions/4321777/riemanns-explicit-prime-counting-formula-how-is-it-piecewise-constant")]#text(") a while ago, before posting it here. Do you mind if I copy your answer over there, with proper attribution? Or would you prefer to do so yourself if you do?")

#emph[#text("[Sure, any comment here is public and can be posted with attribution elsewhere. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The convergence of an alternating series of Erdos, assuming the Hardy–Littlewood prime tuples conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-680769")[#strong[#text("The convergence of an alternating series of Erdos, assuming the Hardy–Littlewood prime tuples conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2023")])]

#text("[…] this obstacle, we take advantage of the random sifted model of the primes that was introduced in a paper of Banks, Ford, and myself. To model the primes in an interval such as with drawn randomly from say , we remove one random […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-685066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2024")])]

#text("If Legendre’s conjecture is correct, then the prime gap is stronger than RH?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-685067")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2024")])]

#text("More precisely, Legendre’s conjecture gives a (slightly) stronger bound on the prime gap than what we know how to do assuming the Riemann Hypothesis. However, the ability of RH to control individual prime gaps is relatively weak; both Legendre’s conjecture and RH give much worse control on the prime gap than ")#link("https://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramer’s conjecture")]#text(". And of course, RH has many further consequences beyond controlling prime gaps, whereas Legendre’s conjecture doesn’t have anywhere near as many further number theoretic implications.")

#text("On the other hand, RH is pretty good at controlling the *variance* of prime gaps (the *mean* of prime gaps being easily controlled by the prime number theorem). In particular, ")#link("https://zbmath.org/0063.06869")[#text("Selberg showed")]#text(" that RH implies the estimate")

#mi("\\displaystyle \\sum_{n \\leq x} \\frac{(p_{n+1}-p_n)^2}{p_n} \\ll \\log^2 x")

#text("which among other things places significant limitations (assuming RH) on how often Legendre’s conjecture can be violated (basically, there can only be ")#mi("O(\\log^2 x)")#text(" counterexamples in the first ")#mi("x")#text(" gaps).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-685597")[#strong[#text("Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("[…] which is in turn connected to the parity problem and Siegel zeroes (as is discussed recently in my paper with Banks and Ford, and in more depth in these papers of Ford and of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a80007b69ab69994d7770c6d7efbe2bbae65985a6a306da9801bb0b5aa3e7d0-68fdb0ffb2ac3595eec750eb49279a2ae65fe7034e184eee555817549c60e46d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alufat")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-687612")[#strong[#text("alufat")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("Dear Professor Tao,")

#text("In the Cramér and Granville-Cramér models, there are sometimes concentration inequalities that can be used to produce existence results for sets of integers satisfying conjectures like Bateman-Horn or Goldbach. I am wondering whether this probabilistic model also yields existence results, or if it remains strictly heuristic in nature.")

#text("I apologize if this is a naive question. I ask because the probability space for ")#mi("\\mathcal{C}")#text(" and ")#mi("\\mathcal{G}")#text(" is the product space of independent Bernoullis, which can be identified with the space of subsets of ")#mi("\\mathbb{N}")#text(". However, the events “")#mi("n \\in \\mathcal{R}")#text("” in this model appear to be more complex.")

#text("Lastly, is it possible to say something about how many actual primes are expected to be in ")#mi("\\mathcal{R}")#text("?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-687613")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("Yes, the probabilistic analysis of random models such as ")#mi("{\\mathcal R}")#text(" can be combined with conjectures such as the Hardy-Littlewood prime tuples conjecture to obtain rigorous (albeit conditional) results about the primes themselves. See my later paper ")#link("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/")[#text("https://terrytao.wordpress.com/2023/08/14/the-convergence-of-an-alternating-series-of-erdos-assuming-the-hardy-littlewood-prime-tuples-conjecture/")]#text(" for an example of this (although in this case I ended up not actually using concentration inequalities, but more of a martingale type analysis).")

#text("Being essentially a stationary process, each number of the same size has basically the same chance of being in ")#mi("{\\mathcal R}")#text(", so the expected number of primes in ")#mi("[x,2x]")#text(" that also lie in ")#mi("{\\mathcal R}")#text(" should just be the proportionate number (up to small errors), so in this case about ")#mi("x/\\log^2 x")#text(". There is considerable fluctuation due to local correlations, for instance half the time ")#mi("{\\mathcal R}")#text(" will sieve out all the odd numbers and so the intersection with the actual primes will basically be empty in this case. But if one modifies the model to only sieve out ")#mi("0 \\text{ mod } p")#text(" at small primes then one should start seeing some concentration.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a80007b69ab69994d7770c6d7efbe2bbae65985a6a306da9801bb0b5aa3e7d0-68fdb0ffb2ac3595eec750eb49279a2ae65fe7034e184eee555817549c60e46d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alufat")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-687615")[#strong[#text("alufat")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("Thank you very much for your reply! If I may clarify my first question, in Cramér-Granville’s model ")#mi("\\mathcal{G}")#text(", one sieves out ")#mi("0 \\mod p")#text(" for small primes (say ")#mi("p < \\log n / \\log \\log \\log n")#text("), and defines ")#mi("\\mathbb m{1}_{\\mathcal{G}}(n)")#text(" as independent Bernoulli random variables. Once it is shown that ")#mi("\\mathcal{G}")#text(" satisfies Hardy-Littlewood with probability 1 (using, for example, Kim-Vu’s inequality), it follows from the probabilistic method that there exists a set ")#mi("A \\subseteq \\mathbb{N}")#text(" such that")

#mi("\\displaystyle \\#\\{n \\leq x ~|~ n + h_1, \\ldots, n + h_k \\in A\\} = \\left( \\mathfrak{S}(\\mathcal{H}) + O\\left(\\frac{1}{\\log \\log x}\\right) \\right) \\frac{x}{(\\log x)^k}")

#text("for every fixed admissible ")#mi("k")#text("-tuple ")#mi("\\mathcal{H}")#text(". It is also possible to show that ")#mi("\\mathcal{G}")#text(" has ")#mi("\\gg x \\log\\log x/(\\log x)^2")#text(" primes up to ")#mi("x")#text(" almost surely, so we may pick ")#mi("A")#text(" having this same property.")

#text("With that in mind, I was wondering if the probabilistic framework in Banks-Ford-Tao implies similar results. For instance, does Theorem 1.3 in BFT imply the existence of a set ")#mi("A \\subseteq \\mathbb{N}")#text(" such that")

#mi("\\displaystyle \\#\\{n \\leq x ~|~ n + h_1, \\ldots, n + h_k \\in A\\} = \\mathfrak{S}(\\mathcal{H}) \\int_0^1 \\frac{\\mathrm{d}t}{(\\log t)^k} + O_{\\varepsilon}(x^{1/2 + \\varepsilon})")

#text("uniformly provided ")#mi("\\mathcal{H} \\subseteq [0, \\exp(\\frac{\\log^{1/2}x}{\\log_2 x})]")#text(" and ")#tao-math("\\left|\\mathcal{H}\\right| \\leq (\\log x)^{1/2}", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-687616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("Yes, this follows from our results, which are of an “almost sure” type (one gets a single random set for which Hardy-Littlewood holds for all ")#mi("x")#text(" and all shifts in the indicated range, though as noted the implied constant becomes random). We use the Azuma inequality to get sufficient concentration that a Borel-Cantelli type argument becomes viable.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-687614")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("I still favor Maier’s theorem over the Cramér model.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-687617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("I suspect that both our model and the Cramer-Granville model will obey the conclusions of Maier’s theorem (basically because all the inputs to that theorem have analogues in these models), though I haven’t checked the details.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/26/large-prime-gaps-and-probabilistic-models/#comment-689351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2025")])]

#text("Many models take individual prime gaps as the fundamental random objects. Have you ever considered geometric constraints between consecutive gaps instead—for example, ratios involving three consecutive gaps rather than the gaps themselves?")#linebreak()#text("There is empirical work suggesting that simple angle- or curvature-like quantities derived from triples of primes exhibit structure not captured by standard gap-based models.")
]
