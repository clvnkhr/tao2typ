// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/
// Converted to Typst by tao2typ: "2026-10-14T16:39:13.514624+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A result of Bui–Pratt–Zaharescu, and Erdös problem #437", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A result of Bui–Pratt–Zaharescu, and Erdös problem #437")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 August 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/")[#text("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The following problem was posed ")#link("https://mathscinet.ams.org/mathscinet/relay-station?mr=0592420")[#text("by Erdös and Graham")]#text(" (and is listed as ")#link("https://www.erdosproblems.com/437")[#text("problem #437")]#text(" on the ")#link("https://www.erdosproblems.com/")[#text("Erdös problems website")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" Let ")#mi("{1 \\leq a_1 < \\dots < a_k \\leq x}")#text(" be integers. How many of the partial products ")#mi("{a_1}")#text(", ")#mi("{a_1 a_2}")#text(", ")#mi("{\\dots}")#text(", ")#mi("{a_1 \\dots a_k}")#text(" can be squares? Is it true that, for any ")#mi("{\\varepsilon>0}")#text(", there can be more than ")#mi("{x^{1-\\varepsilon}}")#text(" squares?")
]

#text("If one lets ")#mi("{L(x)}")#text(" denote the maximal number of squares amongst such partial products, it was observed in the paper of Erdös and Graham that the bound ")#mi("{L(x) = o(x)}")#text(" is “trivial” (no proof was provided, but one can for instance argue using the fact that the number of integer solutions to ")#link("https://en.wikipedia.org/wiki/Hyperelliptic_curve")[#text("hyperelliptic equations")]#text(" of the form ")#mi("{(n+h_1) \\dots (n+h_d) = m^2}")#text(" for fixed ")#mi("{h_1 < \\dots < h_d}")#text(" is quite sparse, and in fact finite for ")#mi("{d>2}")#text(" thanks to ")#link("https://en.wikipedia.org/wiki/Siegel%27s_theorem_on_integral_points")[#text("Siegel’s theorem")]#text("), and the problem then asks if ")#mi("{L(x) = x^{1-o(1)}}")#text(".")

#text("It turns out that this problem was essentially solved (though not explicitly) by a ")#link("https://zbmath.org/7806815")[#text("recently published paper of Bui, Pratt, and Zaharescu")]#text(", who studied a closely related quantity ")#mi("{t_n}")#text(" introduced ")#link("https://mathscinet.ams.org/mathscinet/article?mr=1542197")[#text("by Erdös, Graham, and Selfridge")]#text(" (see also Problem B30 of ")#link("https://mathscinet.ams.org/mathscinet/article?mr=2076335")[#text("Guy’s book")]#text("), defined for any natural number ")#mi("{n}")#text(" as the least natural number ")#mi("{t_n}")#text(" such that some subset of ")#mi("{n+1,\\dots,n+t_{n}}")#text(", when multiplied together with ")#mi("{n}")#text(", produced a square. Among the several results proven about ")#mi("{t_n}")#text(" in that paper was the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Bui–Pratt–Zaharescu, Theorem 1.2)")]#text(" ")#metadata(none) <tao-c9e04abb00a43770c0d9>#text(" For ")#mi("{x}")#text(" sufficiently large, there exist ")#mi("{\\gg x \\exp(-(3\\sqrt{2}/2+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x})}")#text(" integers ")#mi("{1 \\leq n \\leq x}")#text(" such that ")#mi("{t_n \\leq \\exp((\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x})}")#text(".")
]

#text("The arguments were in fact quite elementary, with the main tool being the theory of ")#link("https://en.wikipedia.org/wiki/Smooth_number")[#text("smooth numbers")]#text(" (the theory of hyperelliptic equations is used elsewhere in the paper, but not for this particular result).")

#text("If one uses this result as a “black box”, then an easy greedy algorithm argument gives the lower bound")

#align(center)[#tao-fit-display[#mitex("L(x) \\geq x\\exp(-(5\\sqrt{2}/2+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x}),")]]

#text("but with a small amount of additional work, one can modify the ")#emph[#text("proof")]#text(" of the theorem to give a slightly better bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Bounds for ")#mi("{L}")#text(")")]#text(" ")#metadata(none) <tao-6ba9234898ef38b8d53f>#text(" As ")#mi("{x \\rightarrow \\infty}")#text(", we have the lower bound")

#align(center)[#tao-fit-display[#mitex("L(x) \\geq x\\exp(-(\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x})")]]

#text("and the upper bound")

#align(center)[#tao-fit-display[#mitex("L(x) \\leq x\\exp(-(1/\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x}).")]]

#text("In particular, for any ")#mi("{\\varepsilon>0}")#text(", one has ")#mi("{L(x) \\geq x^{1-\\varepsilon}}")#text(" for sufficiently large ")#mi("{x}")#text(".")
]

#text("The purpose of this blog post is to record this modification of the argument, which is short enough to present immediately. For a large ")#mi("{x}")#text(", let ")#mi("{u}")#text(" denote the quantity")

#align(center)[#tao-fit-display[#mitex("u := \\sqrt{2} \\sqrt{\\log x} / \\sqrt{\\log\\log x}.")]]

#text("We call a natural number ")#emph[#mi("{x^{1/u}}")#text("-smooth")]#text(" if all of its prime factors are at most ")#mi("{x^{1/u}}")#text(". From ")#link("https://mathscinet.ams.org/mathscinet/article?mr=831874")[#text("a result of Hildebrand")]#text(" (or the older results of ")#link("https://mathscinet.ams.org/mathscinet/article?mr=46375")[#text("de Bruijn")]#text("), we know that the number ")#mi("{\\pi(x, x^{1/u})}")#text(" of ")#mi("{x^{1/u}}")#text("-smooth numbers less than or equal to ")#mi("{x}")#text(" is")

#metadata(none) <tao-d9eb257f7dbec86f56f0>

#tao-aligned(keep: true)[


#tao-math("\\pi(x, x^{1/u})  & = x \\exp( - (1+o(1)) u \\log u )", block: true, numbering: n => [#text("(1)")])



#tao-math(" & = x \\exp( - (1/\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x} ).", block: true)
]

#text("Let ")#mi("{\\pi(x^{1/u})}")#text(" be the number of primes up to ")#mi("{x^{1/u}}")#text(". From the prime number theorem we have")

#metadata(none) <tao-5d7f4d7241f6c596d9c2>

#tao-aligned(keep: true)[


#tao-math("\\pi(x^{1/u})  & = (1+o(1)) x^{1/u} / \\log x^{1/u}", block: true, numbering: n => [#text("(2)")])



#tao-math(" & = \\exp( (1/\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x} ).", block: true)
]

#text("To prove the lower bound on ")#mi("{L(x)}")#text(", which is a variant of Theorem ")#link(<tao-c9e04abb00a43770c0d9>)[#text("2")]#text(". The key observation is that given any ")#mi("{\\pi(x^{1/u})+1}")#text(" ")#mi("{x^{1/u}}")#text("-smooth numbers ")#mi("{b_1,\\dots,b_{\\pi(x^{1/u})+1}}")#text(", some non-trivial subcollection of them will multiply to a square. This is essentially Lemma 4.2 of ")#link("https://zbmath.org/7806815")[#text("Bui–Pratt–Zaharescu")]#text(", but for the convenience of the reader we give a full proof here. Consider the multiplicative homomorphism ")#mi("{f: {\\bf N} \\rightarrow ({\\bf Z}/2{\\bf Z})^{\\pi(x^{1/u})}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("f(n) := (\\nu_{p_i}(n) \\mod 2)_{i=1}^{\\pi(x^{1/u})},")]]

#text("where ")#mi("{p_i}")#text(" is the ")#mi("{i^{\\mathrm{th}}}")#text(" prime and ")#mi("{\\nu_{p_i}(n)}")#text(" is the number of times ")#mi("{p_i}")#text(" divides ")#mi("{n}")#text(". The vectors ")#mi("{f(b_1),\\dots,f(b_{\\pi(x^{1/u})+1})}")#text(" lie in a ")#mi("{\\pi(x^{1/u})}")#text("-dimensional vector space over ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(", and thus are linearly dependent. Thus there exists a non-trivial collection of these vectors that sums to zero, which implies that the corresponding elements of the sequence ")#mi("{b_1,\\dots,b_{\\pi(x^{1/u})+1}}")#text(" multiply to a square.")

#text("From ")#link(<tao-d9eb257f7dbec86f56f0>)[#text("(1)")]#text(", ")#link(<tao-5d7f4d7241f6c596d9c2>)[#text("(2)")]#text(" we can find ")#mi("{x \\exp( - (\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x} )}")#text(" sequences of ")#mi("{x^{1/u}}")#text("-smooth numbers ")#mi("{b_1 < \\dots < b_{\\pi(x^{1/u})+1}}")#text(" in ")#mi("{\\{1,\\dots,x\\}}")#text(", with each sequence being to the right of the previous sequence. By the above observation, each sequence contains some non-trivial subcollection that multiplies to a square. Concatenating all these subsequences together, we obtain a single sequence ")#mi("{1 \\leq a_1 < \\dots < a_k \\leq x}")#text(" with at least ")#mi("{x \\exp( - (\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x} )}")#text(" partial products multiplying to a square, giving the desired lower bound on ")#mi("{L(x)}")#text(".")

#text("Next, we prove the upper bound on ")#mi("{L(x)}")#text(". Suppose that a sequence ")#mi("{1 \\leq a_1 < \\dots < a_k \\leq x}")#text(" has ")#mi("{L(x)}")#text(" partial products ")#mi("{a_1 \\dots a_{i_l}}")#text(" that are squares for some ")#mi("{1 \\leq i_1 < \\dots < i_{L(x)} \\leq k}")#text(". Then we have ")#mi("{a_{i_l+1} \\dots a_{i_{l+1}}}")#text(" a square for all ")#mi("{0 \\leq l < L(x)}")#text(" (with the convention ")#mi("{i_0=0}")#text("). The key observation (essentially Lemma 3.4 of ")#link("https://zbmath.org/7806815")[#text("Bui–Pratt–Zaharescu")]#text(") is that, for each ")#mi("{0 \\leq l < L(x)}")#text(", one of the following must hold:")

#list(
[#text("(i) At least one of the ")#mi("{a_{i_l+1},\\dots,a_{i_{l+1}}}")#text(" is ")#mi("{x^{1/u}}")#text("-smooth.")],
[#text("(ii) At least one of the ")#mi("{a_{i_l+1},\\dots,a_{i_{l+1}}}")#text(" is divisible by ")#mi("{p^2}")#text(" for some prime ")#mi("{p>x^{1/u}}")#text(".")],
[#text("(iii) ")#mi("{a_{i_{l+1}} - a_{i_l+1} > x^{1/u}}")#text(".")]
)

#text("Indeed, suppose that (i) and (ii) are not true, then one of the terms in the sequence ")#mi("{a_{i_l+1},\\dots,a_{i_{l+1}}}")#text(" is divisible by exactly one copy of ")#mi("{p}")#text(" for some prime ")#mi("{p > x^{1/u}}")#text(". In order for the product ")#mi("{a_{i_l+1} \\dots a_{i_{l+1}}}")#text(" to be a square, another element of the sequence must also be divisible by the same prime; but this implies (iii).")

#text("From ")#link(<tao-d9eb257f7dbec86f56f0>)[#text("(1)")]#text(" we see that the number of ")#mi("{l}")#text(" for which (i) occurs is at most ")#mi("{x \\exp( - (1/\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x})}")#text(". From the union bound we see that the number of ")#mi("{l}")#text(" for which (ii) occurs is at most")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{p > x^{1/u}} x/p^2 \\ll x^{1-1/u} = x \\exp( - (1/\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x}).")]]

#text("Finally, from the pigeonhole principle we see that the number of ")#mi("{l}")#text(" for which (iii) occurs is also at most")

#align(center)[#tao-fit-display[#mitex("x^{1-1/u} = x \\exp( - (1/\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x}).")]]

#text("Thus one has ")#mi("{L(x) \\ll x \\exp( - (1/\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x})}")#text(", as desired. This completes the proof.")

#text("The upper bound arguments seem more crude to the author than the lower bound arguments, so I conjecture that the lower bound is in fact the truth: ")#mi("{L(x) = x\\exp(-(\\sqrt{2}+o(1)) \\sqrt{\\log x} \\sqrt{\\log\\log x})}")#text(".")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685533")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2024")])]

#text("first")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685534")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2024")])]

#text("I just felt like mentioning that that’s the Zaharescu you and I went to grad school with.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685535")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2024")])]

#text("There seems to be a citation missing in “… thanks to ")#link("https://en.wikipedia.org/wiki/Siegel It turns out that this problem was essentially solved (though not explicitly) by a /href")[#text("https://en.wikipedia.org/wiki/Siegel It turns out that this problem was essentially solved (though not explicitly) by a /href")]#text(", who studied …”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685540")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("Write ")#mi("L := \\exp(100 \\sqrt{\\log x})")#text(".")

#text("Can we say that there are at most ")#mi("x/L")#text(" choices of ")#mi("y<x")#text(" where ")#mi("a_1,\\dots, a_t")#text(" live in the interval ")#mi("[y,y+L]")#text(", ")#mi("\\prod_i a_i")#text(" is a square, and ")#mi("t<\\exp(10^{-10} \\sqrt{\\log x})")#text("? This sort of thing would get close to sharpening the bound.")

#text("The only non-obvious part is improving the bound for (iii) using this (hypothetical) information.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685541")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("Hm. I guess to improve (iii), you could simply make ")#mi("u")#text(" slightly larger. Even though that would hurt (i) slightly, the gain we’d hypothetically have from result about few ")#mi("y")#text("’s would override this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("Okay, if ")#mi("a_1,\\dots,a_t")#text(" live an interval of length ")#mi("L")#text(", then ")#mi("\\mathrm{gcd}(a_i,a_j)<L")#text(" for distinct ")#mi("i,j")#text(" it follows that that the “square-free” part ")#mi("s_i")#text(" of each ")#mi("a_i")#text(" should be bounded by ")#mi("L^{t-1}")#text(" (since ")#mi("s_i \\mid \\prod_{j \\neq i} \\mathrm{gcd}(a_i,a_j)")#text(").")

#text("Thus any such interval must contain some element ")#mi("a")#text(" of the form ")#mi("st^2")#text(" for ")#mi("s< L^t< n^{1/100}")#text(" (since ")#mi("100 \\cdot 10^{-10}<1/100")#text("). But the number of such ")#mi("a")#text(" is bounded by ")#mi("n^{1/100+1/2}<n/L^2")#text(". Each ")#mi("a")#text(" belongs to at most ")#mi("L")#text(" intervals, so we win. QED")

#text("Perhaps I will think about optimizing later. But someone else is welcome to do so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685543")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("The non-constructive lower bound argument generalizes from squares to (say) cubes, or even weird requirements where you fix some ")#mi("q_p>1")#text(" for each prime and ask for many products ")#mi("n = \\prod_i a_i")#text(" where ")#mi("q_p \\mid \\nu_p(n)")#text(" for every prime ")#mi("p")#text(". You can define a multiplicative homomorphism ")#mi("f")#text(", now to a product of cyclic groups with sidelengths ")#mi("q_2,q_3,\\dots")#text(". You want to find some submultiset of ")#mi("f(a_1),\\dots,f(a_t)")#text(". I claim there exists some constant ")#mi("C")#text(" depending only on ")#mi("\\mathrm{lcm}(q_{p_1},\\dots,q_{p_d})")#text(" (the torsion of the image of ")#mi("f")#text("), so that if ")#mi("2^{t^{1/C}} > (\\prod_{i \\le d} q_{p_i})")#text(", then the multisubset exists.")

#text("I have been told there is a slick proof of this via the polynomial method (which might even get ")#mi("C=1")#text(" or something). But all I can remember is a long-winded elementary argument that gets ")#mi("C= \\log_2(\\mathrm{lcm}(q_{p_1},\\dots))")#text(" (in particular for ")#mi("2")#text("-torsion it recovers ")#mi("C=1")#text(" as you obtain, but without having to even mention linear independence).")

#text("Anyways, I wonder what is the general behavior for more other choices of ")#mi("q_p")#text(". Probably this is just a mess, but perhaps it could be interesting.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("Ah, my “improvement” forgot a factor of ")#mi("sqrt{loglog x}")#text(" in the exponent. Unfortunate.")

#text("I guess it gives a decent bound without any smooth estimates. I will think a bit about fixing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685547")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("I think this argument only works for ")#mi("t")#text(" as large as ")#mi("\\sqrt{\\log x}")#text(" or so, rather than the ")#mi("\\exp(\\sqrt{\\log x})")#text(" type levels that one would need to make a dent in the leading term in the asymptotics (as opposed to a lower order term).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685548")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("ah yes, I did that very wrong. back to the drawing board.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2024")])]

#text("Are the best constants in the exponents of the lower and upper bounds be necessarily the same?")

#emph[#text("[I see no reason to expect this – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685562")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2024")])]

#text("How can they not be the same?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685583")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2024")])]

#text("Ah, I misinterpreted the question. Most likely the exponents are indeed the same (and as stated in the text, I believe they are both ")#mi("\\sqrt{2}")#text("). However, it is theoretically possible that the bound oscillates infinitely often between two different exponents, as ")#mi("x")#text(" goes to infinity.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/09/a-result-of-bui-pratt-zaharescu-and-erdos-problem-437/#comment-685561")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2024")])]

#text("The sentence after equation (2) is incomplete.")
]
