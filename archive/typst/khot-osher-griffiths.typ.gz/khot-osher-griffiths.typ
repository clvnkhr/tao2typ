// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/
// Converted to Typst by tao2typ: "2026-10-14T10:19:43.325885+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Khot, Osher, Griffiths", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Khot, Osher, Griffiths")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 August 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/")[#text("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In addition to the Fields medallists mentioned in ")#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/")[#text("the previous post")]#text(", the IMU also awarded the ")#link("http://en.wikipedia.org/wiki/Nevanlinna_Prize")[#text("Nevanlinna prize")]#text(" to ")#link("http://en.wikipedia.org/wiki/Subhash_Khot")[#text("Subhash Khot")]#text(", the ")#link("http://en.wikipedia.org/wiki/Gauss_prize")[#text("Gauss prize")]#text(" to ")#link("http://en.wikipedia.org/wiki/Stanley_Osher")[#text("Stan Osher")]#text(" (my colleague here at UCLA!), and the ")#link("http://en.wikipedia.org/wiki/Chern_Medal")[#text("Chern medal")]#text(" to ")#link("http://en.wikipedia.org/wiki/Phillip_Griffiths")[#text("Phillip Griffiths")]#text(". Like I did in 2010, I’ll try to briefly discuss one result of each of the prize winners, though the fields of mathematics here are even further from my expertise than those discussed in the previous post (and all the caveats from that post apply here also).")

#text("Subhash Khot is best known for his ")#link("http://en.wikipedia.org/wiki/Unique_games_conjecture")[#text("Unique Games Conjecture")]#text(", a problem in complexity theory that is perhaps second in importance only to ")#link("http://en.wikipedia.org/wiki/P_versus_NP_problem")[#text("the ")#mi("{P \\neq NP}")#text(" problem")]#text(" for the purposes of demarcating the mysterious line between “easy” and “hard” problems (if one follows standard practice and uses “polynomial time” as the definition of “easy”). The ")#mi("{P \\neq NP}")#text(" problem can be viewed as an assertion that it is difficult to find exact solutions to certain standard theoretical computer science problems (such as ")#link("http://en.wikipedia.org/wiki/Boolean_satisfiability_problem")[#mi("{k}")#text("-SAT")]#text("); thanks to the NP-completeness phenomenon, it turns out that the precise problem posed here is not of critical importance, and ")#mi("{k}")#text("-SAT may be substituted with one of the many other problems known to be NP-complete. The unique games conjecture is similarly an assertion about the difficulty of finding even ")#emph[#text("approximate")]#text(" solutions to certain standard problems, in particular “unique games” problems in which one needs to colour the vertices of a graph in such a way that the colour of one vertex of an edge is determined uniquely (via a specified matching) by the colour of the other vertex. This is an easy problem to solve if one insists on exact solutions (in which 100% of the edges have a colouring compatible with the specified matching), but becomes extremely difficult if one permits approximate solutions, with no exact solution available. In analogy with the NP-completeness phenomenon, the threshold for approximate satisfiability of many other problems (such as the ")#link("http://en.wikipedia.org/wiki/Maximum_cut")[#text("MAX-CUT")]#text(" problem) is closely connected with the truth of the unique games conjecture; remarkably, the truth of the unique games conjecture would imply asymptotically sharp thresholds for many of these problems. This has implications for many theoretical computer science constructions which rely on hardness of approximation, such as ")#link("http://en.wikipedia.org/wiki/Probabilistically_checkable_proof")[#text("probabilistically checkable proofs")]#text(". For a more detailed survey of the unique games conjecture and its implications, see ")#link("http://www.ams.org/journals/bull/2012-49-01/S0273-0979-2011-01361-1/S0273-0979-2011-01361-1.pdf")[#text("this Bulletin article of Trevisan")]#text(".")

#text("My colleague Stan Osher has worked in many areas of applied mathematics, ranging from image processing to modeling fluids for major animation studies such as Pixar or Dreamworks, but today I would like to talk about one of his contributions that is close to an area of my own expertise, namely ")#link("http://en.wikipedia.org/wiki/Compressed_sensing")[#text("compressed sensing")]#text(". One of the basic reconstruction problem in compressed sensing is the ")#link("http://en.wikipedia.org/wiki/Basis_pursuit")[#text("basis pursuit problem")]#text(" of finding the vector ")#mi("{x \\in {\\bf R}^n}")#text(" in an affine space ")#mi("{\\{ x \\in {\\bf R}^n: Ax = b \\}}")#text(" (where ")#mi("{b \\in {\\bf R}^m}")#text(" and ")#mi("{A \\in {\\bf R}^{m\\times n}}")#text(" are given, and ")#mi("{m}")#text(" is typically somewhat smaller than ")#mi("{n}")#text(") which minimises the ")#mi("{\\ell^1}")#text("-norm ")#tao-math("{\\left\\|x\\right\\|_{\\ell^1} := \\sum_{i=1}^n \\left|x_i\\right|}", block: false)#text(" of the vector ")#mi("{x}")#text(". This is a convex optimisation problem, and thus solvable in principle (it is a polynomial time problem, and thus “easy” in the above theoretical computer science sense). However, once ")#mi("{n}")#text(" and ")#mi("{m}")#text(" get moderately large (e.g. of the order of ")#mi("{10^6}")#text("), standard linear optimisation routines begin to become computationally expensive; also, it is difficult for off-the-shelf methods to exploit any additional structure (e.g. sparsity) in the measurement matrix ")#mi("{A}")#text(". Much of the problem comes from the fact that the functional ")#tao-math("{x \\mapsto \\left\\|x\\right\\|_1}", block: false)#text(" is only barely convex. One way to speed up the optimisation problem is to ")#link("http://en.wikipedia.org/wiki/Relaxation_(approximation)")[#text("relax")]#text(" it by replacing the constraint ")#mi("{Ax=b}")#text(" with a convex penalty term ")#tao-math("{\\frac{1}{2 \\epsilon} \\left\\|Ax-b\\right\\|_{\\ell^2}^2}", block: false)#text(", thus one is now trying to minimise the unconstrained functional")

#align(center)[#tao-fit-display[#tao-math("\\left\\|x\\right\\|_1 + \\frac{1}{2\\epsilon} \\left\\|Ax-b\\right\\|_{\\ell^2}^2.", block: true)]]

#text("This functional is more convex, and is over a computationally simpler domain ")#mi("{{\\bf R}^n}")#text(" than the affine space ")#mi("{\\{x \\in {\\bf R}^n: Ax=b\\}}")#text(", so is easier (though still not entirely trivial) to optimise over. However, the minimiser ")#mi("{x^\\epsilon}")#text(" to this problem need not match the minimiser ")#mi("{x^0}")#text(" to the original problem, particularly if the (sub-)gradient ")#tao-math("{\\partial \\left\\|x\\right\\|_1}", block: false)#text(" of the original functional ")#tao-math("{\\left\\|x\\right\\|_1}", block: false)#text(" is large at ")#mi("{x^0}")#text(", and if ")#mi("{\\epsilon}")#text(" is not set to be small. (And setting ")#mi("{\\epsilon}")#text(" ")#emph[#text("too")]#text(" small will cause other difficulties with numerically solving the optimisation problem, due to the need to divide by very small denominators.) However, if one modifies the objective function by an additional linear term")

#align(center)[#tao-fit-display[#tao-math("\\left\\|x\\right\\|_1 - \\langle p, x \\rangle + \\frac{1}{2 \\epsilon} \\left\\|Ax-b\\right\\|_{\\ell^2}^2", block: true)]]

#text("then some simple convexity considerations reveal that the minimiser to this new problem ")#emph[#text("will")]#text(" match the minimiser ")#mi("{x^0}")#text(" to the original problem, provided that ")#mi("{p}")#text(" is (or more precisely, lies in) the (sub-)gradient ")#tao-math("{\\partial \\left\\|x\\right\\|_1}", block: false)#text(" of ")#tao-math("{\\left\\|x\\right\\|_1}", block: false)#text(" at ")#mi("{x^0}")#text(" – even if ")#mi("{\\epsilon}")#text(" is not small. But, one does not know in advance what the correct value of ")#mi("{p}")#text(" should be, because one does not know what the minimiser ")#mi("{x^0}")#text(" is.")

#text("With Yin, Goldfarb and Darbon, ")#link("http://www.caam.rice.edu/~wy1/paperfiles/Rice_CAAM_TR07-13.PDF")[#text("Osher introduced")]#text(" a Bregman iteration method in which one solves for ")#mi("{x}")#text(" and ")#mi("{p}")#text(" simultaneously; given an initial guess ")#mi("{x^k, p^k}")#text(" for both ")#mi("{x^k}")#text(" and ")#mi("{p^k}")#text(", one first updates ")#mi("{x^k}")#text(" to the minimiser ")#mi("{x^{k+1} \\in {\\bf R}^n}")#text(" of the convex functional ")#metadata(none) <tao-ec31682fde561917952f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|x\\right\\|_1 - \\langle p^k, x \\rangle + \\frac{1}{2 \\epsilon} \\left\\|Ax-b\\right\\|_{\\ell^2}^2", block: true)]]



#text(" and then updates ")#mi("{p^{k+1}}")#text(" to the natural value of the subgradient ")#tao-math("{\\partial \\left\\|x\\right\\|_1}", block: false)#text(" at ")#mi("{x^{k+1}}")#text(", namely")

#align(center)[#tao-fit-display[#tao-math("p^{k+1} := p^k - \\nabla \\frac{1}{2 \\epsilon} \\left\\|Ax-b\\right\\|_{\\ell^2}^2|_{x=x^{k+1}} = p_k - \\frac{1}{\\epsilon} (Ax^k - b)", block: true)]]

#text("(note upon taking the first variation of ")#link(<tao-ec31682fde561917952f>)[#text("(1)")]#text(" that ")#mi("{p^{k+1}}")#text(" is indeed in the subgradient). This procedure converges remarkably quickly (both in theory and in practice) to the true minimiser ")#mi("{x^0}")#text(" even for non-small values of ")#mi("{\\epsilon}")#text(", and also has some ability to be parallelised, and has led to actual performance improvements of an order of magnitude or more in certain compressed sensing problems (such as reconstructing an MRI image).")

#text("Phillip Griffiths has made many contributions to complex, algebraic and differential geometry, and I am not qualified to describe most of these; my primary exposure to his work is through ")#link("http://www.ams.org/mathscinet-getitem?mr=507725")[#text("his text on algebraic geometry")]#text(" with Harris, but as excellent though that text is, it is not really representative of his research. But I thought I would mention one cute result of his related to the famous ")#link("http://en.wikipedia.org/wiki/Nash_embedding_theorem")[#text("Nash embedding theorem")]#text(". Suppose that one has a smooth ")#mi("{n}")#text("-dimensional Riemannian manifold that one wants to embed locally into a Euclidean space ")#mi("{{\\bf R}^m}")#text(". The Nash embedding theorem guarantees that one can do this if ")#mi("{m}")#text(" is large enough depending on ")#mi("{n}")#text(", but what is the minimal value of ")#mi("{m}")#text(" one can get away with? Many years ago, my colleague ")#link("http://www.ams.org/mathscinet-getitem?mr=262980")[#text("Robert Greene showed")]#text(" that ")#mi("{m = \\frac{n(n+1)}{2} + n}")#text(" sufficed (a simplified proof was subsequently given ")#link("http://www.ams.org/mathscinet-getitem?mr=1159298")[#text("by Gunther")]#text("). However, this is not believed to be sharp; if one replaces “smooth” with “real analytic” then a standard Cauchy-Kovalevski argument shows that ")#mi("{m = \\frac{n(n+1)}{2}}")#text(" is possible, and no better. So this suggests that ")#mi("{m = \\frac{n(n+1)}{2}}")#text(" is the threshold for the smooth problem also, but this remains open in general. The cases ")#mi("{n=1}")#text(" is trivial, and the ")#mi("{n=2}")#text(" case is not too difficult (if the curvature is non-zero) as the codimension ")#mi("{m-n}")#text(" is one in this case, and the problem reduces to that of solving a Monge-Ampere equation. With Bryant and Yang, ")#link("http://www.ams.org/mathscinet-getitem?mr=726313")[#text("Griffiths settled")]#text(" the ")#mi("{n=3}")#text(" case, under a non-degeneracy condition on the Einstein tensor. This is quite a serious paper – over 100 pages combining differential geometry, PDE methods (e.g. Nash-Moser iteration), and even some harmonic analysis (e.g. they rely at one key juncture on an extension theorem of my advisor, Elias Stein). The main difficulty is that that the relevant PDE degenerates along a certain characteristic submanifold of the cotangent bundle, which then requires an extremely delicate analysis to handle.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6def420a06fd003a9920717079f6c46bf7c0e7ef4e32038aee8d7cd9e725d256-d4be4d5b498d24884b0a2d9ffceae8db9e1f471279e0383dba37bb9dda8dd0b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Bishnoi")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405179")[#strong[#text("Anurag Bishnoi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("“in such a way that the colour of one vertex of an edge is determined uniquely (via a specified matching) by the colour of the other edge.” – Is that a typo? Did you mean to write vertex instead of edge in the end?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("Dear Terry,I’m not a mathematician,but every thing and every man in my hand and my mind.these people win these winners that i knew 4 years ago,may be these award is easier than in future.Order of the world has change.List of winners of the last 50 years .I recognize that only one and only one is on the top in now and futher(I don’t reveal here).Someone is more stupid than if he/she thinks my sayings is stupid.Please don’t cancel my comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405232")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("“This functional is more convex…” – do you mean “This function…”?")

#emph[#text("[Notation changed to refer to ")#link("http://en.wikipedia.org/wiki/Functional_(mathematics)")[#text("functional")]#text(" consistently, rather than function, for the quantity to be extremised. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405388")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("Thanks for the pointer Terry. I didn’t realize that a functional needn’t be a function of a function.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfa0c4385ae96963e98a762a59e760d084c20bb08c5de8b0c784ee27588fb04d-6bffb221df6658f0b7ac32594d2feecb02e740754065808f6aa689a7b13c5c37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deaneyang")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405268")[#strong[#text("deaneyang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("Terry, I am quite flattered that you chose of all the theorems that Griffiths has proved the one I collaborated with him on. I thought I would take advantage of this and write a shamelessly long comment about the theorem.")

#text("First, even the case ")#mi("n=2")#text(" is not fully settled. There, the problem can be reduced to a scalar Monge-Ampere-type equation that is elliptic if the Gauss curvature ")#mi("K")#text(" is positive, hyperbolic if it is negative, and degenerate if it is zero. So if ")#mi("K \\ne 0")#text(" at a point, the local existence of an isometric embedding follows by standard theorems about nonlinear elliptic and hyperbolic PDE’s. If, however, ")#mi("K = 0")#text(" at a point but not in a neighborhood of a point, things get a lot more difficult. C. S. Lin proved local existence theorems if ")#mi("K = 0")#text(" and ")#mi("dK \\ne 0")#text(" at a point, as well as the case ")#mi("K \\le 0")#text(" in a neighborhood of a point. I’m blanking out on whether other cases have been handled since then, but the general question still remains open.")

#text("As for the BGY paper, the first half of the paper is a tour de force of complex and real algebraic geometry (I can say this because I was only a bystander watching it happen. By the way, this was right after Robert got his Ph.D. He would visit Harvard, and we would watch awestruck as he showed us all the things he could do using exterior differential systems.) studying what the symbol of the linearized PDE looked like. What this led to was the observation that if the Einstein tensor satisfied a certain open condition, then the PDE was effectively symmetric or strictly hyperbolic, even though the problem involves in no way a natural time co-ordinate. Instead, there is a cone of tangent directions at a point in the manifold such that if you declare one of them as time, then the PDE can be written as a hyperbolic system with respect to that time co-ordinate. At this point the local existence of smooth solutions to the linear equation is quite straightforward using energy estimates. The only question is how to prove estimates (now called “smooth tame estimates”) needed for applying Nash-Moser to obtain local existence and regularity for the original nonlinear system. This is in fact also quite straightforward and easy. We didn’t know this at the time, because back then (early 80’s) nobody at Harvard knew anything about PDE’s (well, except for Cliff Taubes). Griffiths called Nirenberg, who referred him to Sergiu Klainerman. I went down to Courant, and it took Sergiu about 5 minutes to explain to me how to prove what he called an “elementary calculus lemma” which indeed was elementary (anyone in nonlinear PDE’s knows this stuff in their sleep) and gave the necessary estimates. We then talked about music the rest of the time.")

#text("This and Stein’s extension lemma (which I found in one of his books) were the last pieces we needed. So I would like to express mild disagreement to your statement that this involved “delicate estimates”. Especially by modern standards (for example, recent work by you and others on the Navier-Stokes equation), the PDE part of the BGY paper was rather straightforward. Don’t get me wrong. I’m very proud of this work and believe it was groundbreaking back then. But the PDE part is arguably the easiest part of the paper. If it looks harder than it really is, it’s because I wrote that part.")

#text("And then there’s what came after that paper. We had also shown that for the generic 3-d and 4-d metrics, the PDE was what Hormander called “real principal type”. Hormander used microlocal analysis and Fourier integral operators to prove local existence and regularity theorems for linear PDE’s of real principal type. To obtain a local isometric embedding in these cases, it again sufficed to prove the smooth tame estimates for the solution to the linear system. However, proving such estimates held for the microlocal analysis and Fourier integral operators is rather painful. Nakamura and Maeda did publish a paper grinding through all of this, but it’s not an easy read. Separately, while I was a postdoc at Courant, Jonathan Goodman and I found a proof that involved perturbing a fixed linear PDO using a “microglobal” Fourier integral operator. We submitted it to CPAM, but it was rejected. We wanted to revise it before submitting it to another journal but never got around to it. The preprint is available on my web page.")

#text("Others have extended these results since then, including Qing Han, J. X. Hong, Marcus Khuri, and T. Poole. However, as far as I know, nobody has the slightest clue to how one might be able to prove this in all dimensions with or without curvature assumptions. The linearized PDO has no structure (that other important PDE’s have) that can be used to obtain estimates. In fact, the algebraic geometric analysis of the symbol showed that in some sense the linearized PDO is a generic ")#mi("n")#text("-by-")#mi("n")#text(" first order differential operator. Nothing is known about how to deal with such an operator.")

#emph[#text("[Description of the n=2 case corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa01b2dc905b1532d3ce1fd5308b5249049b4cd5d6c459e37ccf68a978714190-42bd8a11c485ff08764cec99a586fe52a05126fcfd0619def32998b28f2914ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405495")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("Hi Deane, thanks a lot for sharing a bit of the history behind your paper with Bryant and Griffiths. I think it is worthwhile to mention (as it is a matter of my interest) that it is one of the few works one is faced with the problem of solving an *inhomogeneous* nonlinear hyperbolic PDE system (i.e. with sources). Having an external source in the right hand side of a nonlinear PDE brings hurt to pain, as the Navier-Stokes equations show so dramatically in the parabolic case (after all, there is no turbulence if there is no pressure gradient). Also, it seems hopeless to prove global existence in such a case, even for small Cauchy data (unless, perhaps, the source has compact space-time support). On the other hand, since such a problem is clearly an “implicit function problem”, using Nash-Moser becomes a natural idea, even because it’s possible to “tamefy” the energy estimates for the linearized equation (which was first done by Klainerman in his PhD thesis, right?). I also find amusing (albeit not wrong, mind you) that Klainerman called the Moser and Schauder estimates used for this task simply “an elementary calculus lemma”. He kind of called them that in his PhD thesis paper at CPAM as well…")

#text("Making available online your preprint with Prof. Goodman was fantastic (even because it’s very hard to go through the “Kumano-go calculus” Nakamura and Maeda use in their work), and I imagine it was some story to retrieve it – in 2009, I had an email exchange with you and Prof. Goodman when trying to find it. I even asked Prof. Bryant when he came to São Paulo in 2011, and he recalled he maybe had a copy in his office at Duke (he was at Berkeley at the time), but he wasn’t sure. One unfortunate disadvantage of the method in this paper, though, is that uniqueness of solutions is no longer guaranteed as in the hyperbolic case dealt with in your paper with Bryant and Griffiths (albeit this was probably not relevant for the applications you had in mind).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfa0c4385ae96963e98a762a59e760d084c20bb08c5de8b0c784ee27588fb04d-6bffb221df6658f0b7ac32594d2feecb02e740754065808f6aa689a7b13c5c37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deaneyang")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405517")[#strong[#text("deaneyang")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("Pedro, I found the email exchange we had. I see that I never replied to your last email. I’m sorry about that. In any case, I think you had gone beyond my limited knowledge about PDE’s anyway.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa01b2dc905b1532d3ce1fd5308b5249049b4cd5d6c459e37ccf68a978714190-42bd8a11c485ff08764cec99a586fe52a05126fcfd0619def32998b28f2914ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405521")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("That’s OK. In the end, the method used in your paper with Bryant and Griffiths ended up being more useful to me and my collaborators, since we needed uniqueness of the solution and the PDE’s we were interested on were always hyperbolic. However, since we were working in arbitrary Lorentzian manifolds (possibly with non-compact Cauchy hypersurfaces) instead of Euclidean space and needed a solution defined in arbitrarily large compact regions, I had at the same time to geometrize and localize the estimates. In the end, we had to carry a large part of the argument from scratch. In any case, now I can check your preprint…")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a5f266bf5624e8b7ce7b3c0a4d5f085cd7ed639cbd3a17bdf623545c80c9e0c-938b2f9f6b25dd2c817fc2db8ea3c374436ce86fc4b27cdf08b89b2d01de8d22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Bentin")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405293")[#strong[#text("John Bentin")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("(Typo) In line 9 of paragraph 3, should that be “of the vector $x$” (rather than $n$)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be2af8833324863183e543625d6a9b6998ae7008e76ca10cd948348fb9953896-e264b72abced211c5147c522add4690016dbdb930def2b404d11fe0e31ab07b2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zr9558")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405648")[#strong[#text("zr9558")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2014")])]

#text("Reblogged this on ")#link("http://zr9558.com/2014/08/15/khot-osher-griffiths/")[#text("ZHANG RONG")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405655")[#strong[#text("Terrance Tao discusses the Fields Medal winners. | BUMPS")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2014")]

#text("[…] ")#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/")[#text("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dd1d2a1b86420638b8c1395707ac60e72b3db24e1d233e493de84958055b0cf-93b5fda75e4860ef2f076d5ba11c5b0fee47fffd141f56355b7c15438bafc0da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Woolfitt")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-405666")[#strong[#text("Peter Woolfitt")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2014")])]

#text("Minor typo – In line 4 of paragraph 2, it should be “if one follows standard practice” instead of “if one follow standard practice.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-406576")[#strong[#text("Media Item from “Haaretz” Today: “For the first time ever…” | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2014")]

#text("[…] work of all prize recipients. And from Quanta Magazine: (More) More on Osher, Griffiths, and Khot on terry Tao’s blog, on Khot on Scott Aaronson’s blog and on a description of the laudations on Gowers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a89a2856eb9b46997e6a2daaf0b9f250c62879558ec2216c23bea634d1e51065-9dcaabe0724e81953f28e6541e6c0a19e46ad8fbe7a729225aa96fcc1ad389d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scot")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-406700")[#strong[#text("Scot")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2014")])]

#text("In the sentence that begins “One of the basic reconstruction problem…” should A be $m x $n … x is in R^n and b is in R^m? Thanks for the interesting post!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfa0c4385ae96963e98a762a59e760d084c20bb08c5de8b0c784ee27588fb04d-6bffb221df6658f0b7ac32594d2feecb02e740754065808f6aa689a7b13c5c37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deaneyang")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-406788")[#strong[#text("deaneyang")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2014")])]

#text("I also recommend another beautiful and under-appreciated paper “The Gauss equations and rigidity of isometric embeddings” published in the Duke Math Journal in 1983 by Berger, Bryant, and Griffiths. Eric Berger was another graduate student of Phillip two years ahead of me; he unfortunately left academia soon after he got a Ph.D. and was one of the early quants on Wall Street (as was another classmate Farshid Jamshidian).")

#text("In this paper algebraic geometry and representation theory are used to analyze deeply the relationship between the second fundamental form and its covariant derivatives with the Riemann curvature tensor and its covariant derivatives via the Gauss equations, Codazzi-Mainardi equations, and their covariant derivatives. The authors obtain not only new infinitesimal and local rigidity theorems but also identify situations where the isometric embedding has only a finite dimensional space of deformations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-407054")[#strong[#text("Día importante para las Matemáticas: Maryam Mirzakhani (Irán) gana una Medalla Fields | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2014")]

#text("[…] Hairer, Mirzakhani,” What’s New, 12 Aug 2014, y “Khot, Osher, Griffiths,” What’s New, 12 Aug 2014. Tim Gowers, “ICM2014 — Bhargava laudatio,” GWblog, 15 Aug 2014; “ICM2014 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cb2c5e8cf28e2e5adc08c713eb17786955be9691c253173514334efd5913817-8f4901648aaa269676a6bfeda775931c16bdf819697d14e3ddfffe1f80786199.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-633375")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2021")])]

#text("I do not know much of UGC and know much less on the geometry needed. Instead of getting the vectors on the sphere if we get on the hyperbolic sphere would it correspond to inner products being replaced by bilinear forms with generalized signatures? Can there be no utility to such settings or can there be no analog of positivstellensatz in such settings?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bb91da3dcb58c3cf1e0c80f48066ce7d4e5acc3a9390e0ae752e70cfa2c586f-a1a612bfd075741269314e571d1997d1df1c8843eb3ad19158ee819a277e3395.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arulsaravana Jeyaraj")]], [#link("https://terrytao.wordpress.com/2014/08/13/khot-osher-griffiths/#comment-633592")[#strong[#text("Arulsaravana Jeyaraj")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2021")])]

#text("I see. The problem may not be that relevant as P=NP and UGC true are consistent.")
]
