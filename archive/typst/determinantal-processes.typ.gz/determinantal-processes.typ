// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/23/determinantal-processes/
// Converted to Typst by tao2typ: "2026-10-14T15:17:25.936128+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Determinantal processes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Determinantal processes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")[#text("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given a set ")#mi("{S}")#text(", a (simple) ")#link("http://en.wikipedia.org/wiki/Point_process")[#text("point process")]#text(" is a random subset ")#mi("{A}")#text(" of ")#mi("{S}")#text(". (A non-simple point process would allow multiplicity; more formally, ")#mi("{A}")#text(" is no longer a subset of ")#mi("{S}")#text(", but is a Radon measure on ")#mi("{S}")#text(", where we give ")#mi("{S}")#text(" the structure of a locally compact Polish space, but I do not wish to dwell on these sorts of technical issues here.) Typically, ")#mi("{A}")#text(" will be finite or countable, even when ")#mi("{S}")#text(" is uncountable. Basic examples of point processes include")

#list(
[#text("(Bernoulli point process) ")#mi("{S}")#text(" is an at most countable set, ")#mi("{0 \\leq p \\leq 1}")#text(" is a parameter, and ")#mi("{A}")#text(" a random set such that the events ")#mi("{x \\in A}")#text(" for each ")#mi("{x \\in S}")#text(" are jointly independent and occur with a probability of ")#mi("{p}")#text(" each. This process is automatically simple.")],
[#text("(Discrete ")#link("http://en.wikipedia.org/wiki/Poisson_process")[#text("Poisson point process")]#text(") ")#mi("{S}")#text(" is an at most countable space, ")#mi("{\\lambda}")#text(" is a measure on ")#mi("{S}")#text(" (i.e. an assignment of a non-negative number ")#mi("{\\lambda(\\{x\\})}")#text(" to each ")#mi("{x \\in S}")#text("), and ")#mi("{A}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Multiset")[#text("multiset")]#text(" where the multiplicity of ")#mi("{x}")#text(" in ")#mi("{A}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Poisson_distribution")[#text("Poisson random variable")]#text(" with intensity ")#mi("{\\lambda(\\{x\\})}")#text(", and the multiplicities of ")#mi("{x \\in A}")#text(" as ")#mi("{x}")#text(" varies in ")#mi("{S}")#text(" are jointly independent. This process is usually not simple.")],
[#text("(Continuous ")#link("http://en.wikipedia.org/wiki/Poisson_process")[#text("Poisson point process")]#text(") ")#mi("{S}")#text(" is a locally compact Polish space with a Radon measure ")#mi("{\\lambda}")#text(", and for each ")#mi("{\\Omega \\subset S}")#text(" of finite measure, the number of points ")#tao-math("{\\left|A \\cap \\Omega\\right|}", block: false)#text(" that ")#mi("{A}")#text(" contains inside ")#mi("{\\Omega}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Poisson_distribution")[#text("Poisson random variable")]#text(" with intensity ")#mi("{\\lambda(\\Omega)}")#text(". Furthermore, if ")#mi("{\\Omega_1,\\ldots,\\Omega_n}")#text(" are disjoint sets, then the random variables ")#tao-math("{\\left|A \\cap \\Omega_1\\right|, \\ldots, \\left|A \\cap \\Omega_n\\right|}", block: false)#text(" are jointly independent. (The fact that Poisson processes exist at all requires a non-trivial amount of measure theory, and will not be discussed here.) This process is almost surely simple iff all points in ")#mi("{S}")#text(" have measure zero.")],
[#text("(Spectral point processes) The spectrum of a random matrix is a point process in ")#mi("{{\\mathbb C}}")#text(" (or in ")#mi("{{\\mathbb R}}")#text(", if the random matrix is Hermitian). If the spectrum is almost surely simple, then the point process is almost surely simple. In a similar spirit, the zeroes of a random polynomial are also a point process.")]
)

#text("A remarkable fact is that many natural (simple) point processes are ")#emph[#text("determinantal processes")]#text(". Very roughly speaking, this means that there exists a positive semi-definite kernel ")#mi("{K: S \\times S \\rightarrow {\\mathbb R}}")#text(" such that, for any ")#mi("{x_1,\\ldots,x_n \\in S}")#text(", the probability that ")#mi("{x_1,\\ldots,x_n}")#text(" all lie in the random set ")#mi("{A}")#text(" is proportional to the determinant ")#mi("{\\det( (K(x_i,x_j))_{1 \\leq i,j \\leq n} )}")#text(". Examples of processes known to be determinantal include non-intersecting random walks, spectra of random matrix ensembles such as GUE, and zeroes of polynomials with gaussian coefficients.")

#text("I would be interested in finding a good explanation (even at the heuristic level) as to why determinantal processes are so prevalent in practice. I do have a very weak explanation, namely that determinantal processes obey a large number of rather pretty algebraic identities, and so it is plausible that any other process which has a very algebraic structure (in particular, any process involving gaussians, characteristic polynomials, etc.) would be connected in some way with determinantal processes. I’m not particularly satisfied with this explanation, but I thought I would at least describe some of these identities below to support this case. (This is partly for my own benefit, as I am trying to learn about these processes, particularly in connection with the spectral distribution of random matrices.) The material here is partly based on ")#link("http://front.math.ucdavis.edu/math/0503110")[#text("this survey of Hough, Krishnapur, Peres, and Virág")]#text(".")

#metadata(none) <tao-878579e90e6f8e0590a4>

#heading(level: 1)[#strong[#text(" — 1. Discrete determinantal processes — ")]]

#text("In order to ignore all measure-theoretic distractions and focus on the algebraic structure of determinantal processes, we will first consider the discrete case when the space ")#mi("{S}")#text(" is just a finite set ")#mi("{S = \\{1,\\ldots,N\\}}")#text(" of cardinality ")#tao-math("{\\left|S\\right|=N}", block: false)#text(". We say that a process ")#mi("{A \\subset S}")#text(" is a ")#emph[#text("determinantal process")]#text(" with kernel ")#mi("{K}")#text(", where ")#mi("{K}")#text(" is an ")#mi("{k \\times k}")#text(" symmetric real matrix, if one has ")#metadata(none) <tao-664243732d01ab1ce602>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\Bbb P}(\\{i_1,\\ldots,i_k\\} \\subset A) = \\det( K( i_a, i_b ) )_{1 \\leq a,b \\leq k}")]]

#text("for all distinct ")#mi("{i_1,\\ldots,i_k \\in S}")#text(".")

#text("To build determinantal processes, let us first consider point processes of a fixed cardinality ")#mi("{n}")#text(", thus ")#mi("{0 \\leq n \\leq N}")#text(" and ")#mi("{A}")#text(" is a random subset of ")#mi("{S}")#text(" of size ")#mi("{n}")#text(", or in other words a random variable taking values in the set ")#tao-math("{\\binom{S}{n} := \\{ B \\subset S: \\left|B\\right| = n \\}}", block: false)#text(".")

#text("In this simple model, an ")#mi("{n}")#text("-element point processes is basically just a collection of ")#mi("{\\binom{N}{n}}")#text(" probabilities ")#mi("{p_B = {\\Bbb P}( A = B )}")#text(", one for each ")#mi("{B \\in \\binom{S}{n}}")#text(", which are non-negative numbers which add up to ")#mi("{1}")#text(". For instance, in the uniform point process where ")#mi("{A}")#text(" is drawn uniformly at random from ")#mi("{\\binom{S}{n}}")#text(", each of these probabilities ")#mi("{p_B}")#text(" would equal ")#mi("{1/\\binom{N}{n}}")#text(". How would one generate other interesting examples of ")#mi("{n}")#text("-element point processes?")

#text("For this, we can borrow the idea from quantum mechanics that probabilities can arise as the square of coefficients of unit vectors, though unlike quantum mechanics it will be slightly more convenient here to work with real vectors rather than complex ones. To formalise this, we work with the ")#mi("{n^{th}}")#text(" ")#link("http://en.wikipedia.org/wiki/Exterior_algebra")[#text("exterior power")]#text(" ")#mi("{\\bigwedge^n {\\mathbb R}^N}")#text(" of the Euclidean space ")#mi("{{\\mathbb R}^N}")#text("; this space is sort of a “quantisation” of ")#mi("{\\binom{S}{n}}")#text(", and is analogous to the space of quantum states of ")#mi("{n}")#text(" identical ")#link("http://en.wikipedia.org/wiki/Fermion")[#text("fermions")]#text(", if each fermion can exist classically in one of ")#mi("{N}")#text(" states (or “spins”). (The requirement that the process be simple is then analogous to the ")#link("http://en.wikipedia.org/wiki/Pauli_Exclusion_Principle")[#text("Pauli exclusion principle")]#text(".)")

#text("This space of ")#mi("{n}")#text("-vectors in ")#mi("{{\\mathbb R}^N}")#text(" is spanned by the wedge products ")#mi("{e_{i_1} \\wedge \\ldots \\wedge e_{i_n}}")#text(" with ")#mi("{1 \\leq i_1 < \\ldots < i_n \\leq N}")#text(", where ")#mi("{e_1,\\ldots,e_N}")#text(" is the standard basis of ")#mi("{{\\mathbb R}^N}")#text(". There is a natural inner product to place on ")#mi("{\\bigwedge^n {\\mathbb R}^N}")#text(" by declaring all the ")#mi("{e_{i_1} \\wedge \\ldots \\wedge e_{i_n}}")#text(" to be orthonormal.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" If ")#mi("{f_1,\\ldots,f_N}")#text(" is any orthonormal basis of ")#mi("{{\\mathbb R}^N}")#text(", then the ")#mi("{f_{i_1} \\wedge \\ldots \\wedge f_{i_n}}")#text(" for ")#mi("{1 \\leq i_1 < \\ldots < i_n \\leq N}")#text(" are an orthonormal basis for ")#mi("{\\bigwedge^n {\\mathbb R}^N}")#text(".")
]

#emph[#text("Proof:")]#text(" By definition, this is true when ")#mi("{(f_1,\\ldots,f_N)=(e_1,\\ldots,e_N)}")#text(". If the claim is true for some orthonormal basis ")#mi("{f_1,\\ldots,f_N}")#text(", it is not hard to see that the claim also holds if one rotates ")#mi("{f_i}")#text(" and ")#mi("{f_j}")#text(" in the plane that they span by some angle ")#mi("{\\theta}")#text(", where ")#mi("{1 \\leq i < j \\leq n}")#text(" are arbitrary. But any orthonormal basis can be rotated into any other by a sequence of such rotations (e.g. by using ")#link("http://en.wikipedia.org/wiki/Euler_angles")[#text("Euler angles")]#text("), and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" If ")#mi("{v_1,\\ldots,v_n}")#text(" are vectors in ")#mi("{{\\mathbb R}^N}")#text(", then the magnitude of ")#mi("{v_1 \\wedge \\ldots \\wedge v_n}")#text(" is equal to the ")#mi("{n}")#text("-dimensional volume of the parallelopiped spanned by ")#mi("{v_1,\\ldots,v_n}")#text(".")
]

#emph[#text("Proof:")]#text(" Observe that applying row operations to ")#mi("{v_i}")#text(" (i.e. modifying one ")#mi("{v_i}")#text(" by a scalar multiple of another ")#mi("{v_j}")#text(") does not affect either the wedge product or the volume of the parallelopiped. Thus by using the ")#link("http://en.wikipedia.org/wiki/Gram%E2%80%93Schmidt_process")[#text("Gram-Schmidt process")]#text(", we may assume that the ")#mi("{v_i}")#text(" are orthogonal; by normalising we may assume they are orthonormal. The claim now follows from the preceding lemma. ")#mi("\\Box")

#text("From this and the ordinary Pythagorean theorem in the inner product space ")#mi("{\\bigwedge^n {\\mathbb R}^N}")#text(", we conclude the ")#emph[#text("multidimensional Pythagorean theorem")]#text(": the square of the ")#mi("{n}")#text("-dimensional volume of a parallelopiped in ")#mi("{{\\mathbb R}^N}")#text(" is the sum of squares of the ")#mi("{n}")#text("-dimensional volumes of the projection of that parallelopiped to each of the ")#mi("{\\binom{N}{n}}")#text(" coordinate subspaces ")#mi("{\\text{span}(e_{i_1},\\ldots,e_{i_n})}")#text(". (I believe this theorem was first observed in this generality by Donchian and Coxeter.) We also note another related fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Gram identity)")]#text(" If ")#mi("{v_1,\\ldots,v_n}")#text(" are vectors in ")#mi("{{\\mathbb R}^N}")#text(", then the square of the magnitude of ")#mi("{v_1 \\wedge \\ldots \\wedge v_n}")#text(" is equal to the determinant of the ")#link("http://en.wikipedia.org/wiki/Gram_matrix")[#text("Gram matrix")]#text(" ")#mi("{( v_i \\cdot v_j )_{1 \\leq i,j \\leq n}}")#text(".")
]

#emph[#text("Proof:")]#text(" Again, the statement is invariant under row operations, and one can reduce as before to the case of an orthonormal set, in which case the claim is clear. (Alternatively, one can proceed via the ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Binet_formula")[#text("Cauchy-Binet formula")]#text(".) ")#mi("\\Box")

#text("If we define ")#mi("{e_{\\{i_1,\\ldots,i_n\\}} := e_{i_1} \\wedge \\ldots \\wedge e_{i_n}}")#text(", then we have identified the standard basis of ")#mi("{\\bigwedge^n {\\mathbb R}^N}")#text(" with ")#mi("{\\binom{S}{n}}")#text(" by identifying ")#mi("{e_B}")#text(" with ")#mi("{B}")#text(". As a consequence of this and the multidimensional Pythagorean theorem, every unit ")#mi("{n}")#text("-vector ")#mi("{\\omega}")#text(" in ")#mi("{\\bigwedge^n {\\mathbb R}^N}")#text(" determines an ")#mi("{n}")#text("-element point process ")#mi("{A}")#text(" on ")#mi("{S}")#text(", by declaring the probability ")#mi("{p_B}")#text(" of ")#mi("{A}")#text(" taking the value ")#mi("{B}")#text(" to equal ")#tao-math("{\\left|\\omega \\cdot e_B\\right|^2}", block: false)#text(" for each ")#mi("{B \\in \\binom{S}{n}}")#text(". Note that multiple ")#mi("{n}")#text("-vectors can generate the same point process, because only the magnitude of the coefficients ")#mi("{\\omega \\cdot e_B}")#text(" are of interest; in particular, ")#mi("{\\omega}")#text(" and ")#mi("{-\\omega}")#text(" generate the same point process. (This is analogous to how multiplying the wave function in quantum mechanics by a complex phase has no effect on any physical observable.)")

#text("Now we can introduce determinantal processes. If ")#mi("{V}")#text(" is an ")#mi("{n}")#text("-dimensional subspace of ")#mi("{{\\mathbb R}^N}")#text(", we can define the (projection) ")#emph[#text("determinantal process")]#text(" ")#mi("{A = A_V}")#text(" associated to ")#mi("{V}")#text(" to be the point process associated to the ")#link("http://en.wikipedia.org/wiki/Volume_form")[#text("volume form")]#text(" of ")#mi("{V}")#text(", i.e. to the wedge product of an orthonormal basis of ")#mi("{V}")#text(". (This volume form is only determined up to sign, because the orientation of ")#mi("{V}")#text(" has not been fixed, but as observed previously, the sign of the form has no impact on the resulting point process.)")

#text("By construction, the probability that the point process ")#mi("{A}")#text(" is equal to a set ")#mi("{\\{i_1,\\ldots,i_n\\}}")#text(" is equal to the square of the determinant of the ")#mi("{n \\times n}")#text(" matrix consisting of the ")#mi("{i_1,\\ldots,i_n}")#text(" coordinates of an arbitrary orthonormal basis of ")#mi("{V}")#text(". By extending such an orthonormal basis to the rest of ")#mi("{{\\mathbb R}^N}")#text(", and representing ")#mi("{e_{i_1},\\ldots,e_{i_n}}")#text(" in this basis, it is not hard to see that ")#mi("{{\\Bbb P}( A = \\{i_1,\\ldots,i_n\\})}")#text(" can be interpreted geometrically as the square of the volume of the parallelopiped generated by ")#mi("{Pe_{i_1},\\ldots,Pe_{i_n}}")#text(", where ")#mi("{P}")#text(" is the orthogonal projection onto ")#mi("{V}")#text(".")

#text("In fact we have the more general fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" ")#metadata(none) <tao-784a2ddf5d4d61b6ae15>#text(" If ")#mi("{k \\geq 1}")#text(" and ")#mi("{i_1,\\ldots,i_k}")#text(" are distinct elements of ")#mi("{S}")#text(", then ")#mi("{{\\Bbb P}( \\{i_1,\\ldots,i_k\\} \\subset A )}")#text(" is equal to the square of the ")#mi("{k}")#text("-dimensional volume of the parallelopiped generated by the orthogonal projections of ")#mi("{Pe_{i_1},\\ldots,Pe_{i_k}}")#text(" to ")#mi("{V}")#text(".")
]

#emph[#text("Proof:")]#text(" We can assume that ")#mi("{k \\leq n}")#text(", since both expressions in the lemma vanish otherwise.")

#text("By (anti-)symmetry we may assume that ")#mi("{\\{i_1,\\ldots,i_k\\}=\\{1,\\ldots,k\\}}")#text(". By the Gram-Schmidt process we can find an orthonormal basis ")#mi("{v_1,\\ldots,v_n}")#text(" of ")#mi("{V}")#text(" such that each ")#mi("{v_i}")#text(" is orthogonal to ")#mi("{e_1,\\ldots,e_{i-1}}")#text(".")

#text("Now consider the ")#mi("{n \\times N}")#text(" matrix ")#mi("{M}")#text(" with rows ")#mi("{v_1,\\ldots,v_n}")#text(", thus ")#mi("{M}")#text(" vanishes below the diagonal. The probability ")#mi("{{\\Bbb P}( \\{1,\\ldots,k\\} \\in A )}")#text(" is equal to the sum of squares of the determinants of all the ")#mi("{n \\times n}")#text(" minors of ")#mi("{M}")#text(" that contain the first ")#mi("{k}")#text(" rows. As ")#mi("{M}")#text(" vanishes below the diagonal, we see from cofactor expansion that this is equal to the product of the squares of the first ")#mi("{k}")#text(" diagonal entries, times the sum of squares of the determinants of all the ")#mi("{n-k \\times n-k}")#text(" minors of the bottom ")#mi("{n-k}")#text(" rows. But by the generalised Pythagorean theorem, this latter factor is the square of the volume of the parallelopiped generated by ")#mi("{v_{k+1},\\ldots,v_n}")#text(", which is ")#mi("{1}")#text(". Meanwhile, by the base times height formula, we see that the product of the first ")#mi("{k}")#text(" diagonal entries of ")#mi("{M}")#text(" is equal in magnitude to the ")#mi("{k}")#text("-dimensional volume of the orthogonal projections of ")#mi("{e_1,\\ldots,e_k}")#text(" to ")#mi("{V}")#text(". The claim follows. ")#mi("\\Box")

#text("In particular, we have ")#tao-math("{{\\Bbb P}(i \\in A) = \\left\\| P e_i \\right\\|^2}", block: false)#text(" for any ")#mi("{i}")#text(". In particular, if ")#mi("{e_i}")#text(" lies in ")#mi("{V}")#text(", then ")#mi("{i}")#text(" almost surely lies in ")#mi("{A}")#text(", and when ")#mi("{e_i}")#text(" is orthogonal to ")#mi("{V}")#text(", ")#mi("{i}")#text(" almost surely is disjoint from ")#mi("{A}")#text(".")

#text("Let ")#mi("{K(i,j) = Pe_i \\cdot e_j = Pe_i \\cdot Pe_j}")#text(" denote the matrix coefficients of the orthogonal projection ")#mi("{P}")#text(". From Lemma ")#link(<tao-784a2ddf5d4d61b6ae15>)[#text("4")]#text(" and the Gram identity, we conclude that ")#mi("{A}")#text(" is a determinantal process (see ")#link(<tao-664243732d01ab1ce602>)[#text("(1)")]#text(") with kernel ")#mi("{K}")#text(". Also, by combining Lemma ")#link(<tao-784a2ddf5d4d61b6ae15>)[#text("4")]#text(" with the generalised Pythagorean theorem, we conclude a monotonicity property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Monotonicity property)")]#text(" If ")#mi("{V \\subset W}")#text(" are nested subspaces of ")#mi("{{\\mathbb R}^N}")#text(", then ")#mi("{\\mathop{\\mathbb P}( B \\subset A_V ) \\leq \\mathop{\\mathbb P}( B \\subset A_W)}")#text(" for every ")#mi("{B \\subset S}")#text(".")
]

#text("This seems to suggest that there is some way of representing ")#mi("{A_W}")#text(" as the union of ")#mi("{A_V}")#text(" with another process coupled with ")#mi("{A_V}")#text(", but I was not able to build a non-artificial example of such a representation. On the other hand, if ")#mi("{V \\subset {\\mathbb R}^{N}}")#text(" and ")#mi("{V^{\\prime} \\subset {\\mathbb R}^{N^{\\prime}}}")#text(", then the process ")#mi("{A_{V \\oplus V^{\\prime}}}")#text(" associated with the direct sum ")#mi("{V \\oplus V^{\\prime} \\subset {\\mathbb R}^{N+N^{\\prime}}}")#text(" has the same distribution of the disjoint union of ")#mi("{A_V}")#text(" with an independent copy of ")#mi("{A_{V^{\\prime}}}")#text(".")

#text("The determinantal process interacts nicely with complements:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Hodge duality)")]#text(" ")#metadata(none) <tao-d1c667af9c5e1c7f6f35>#text(" Let ")#mi("{V}")#text(" be an ")#mi("{n}")#text("-dimensional subspace of ")#mi("{{\\mathbb R}^N}")#text(". The ")#mi("{N-n}")#text("-element determinantal process ")#mi("{A_{V^\\perp}}")#text(" associated to the orthogonal complement ")#mi("{V^\\perp}")#text(" of ")#mi("{V}")#text(" has the same distribution as the complement ")#mi("{S \\backslash A_V}")#text(" of the ")#mi("{n}")#text("-element determinantal process ")#mi("{A_V}")#text(" associated to ")#mi("{V}")#text(".")
]

#emph[#text("Proof:")]#text(" We need to show that ")#mi("{\\mathop{\\mathbb P}( A_V = B ) = \\mathop{\\mathbb P}( A_{V^\\perp} = S \\backslash B )}")#text(" for all ")#mi("{B \\in \\binom{N}{n}}")#text(". By symmetry we can take ")#mi("{B = \\{1,\\ldots,n\\}}")#text(". Let ")#mi("{v_1,\\ldots,v_n}")#text(" and ")#mi("{v_{n+1},\\ldots,v_N}")#text(" be an orthonormal basis for ")#mi("{V}")#text(" and ")#mi("{V^\\perp}")#text(" respectively, and let ")#mi("{M}")#text(" be the resulting ")#mi("{N \\times N}")#text(" orthogonal matrix; then the task is to show that the top ")#mi("{n \\times n}")#text(" minor ")#mi("{X}")#text(" of ")#mi("{M}")#text(" has the same determinant squared as the bottom ")#mi("{N-n \\times N-n}")#text(" minor ")#mi("{Y}")#text(". But if one splits ")#mi("{M = \\begin{pmatrix} X & Z \\\\ W & Y\\end{pmatrix}}")#text(", we see from the orthogonality property that ")#mi("{XX^* = I_n - ZZ^*}")#text(" and ")#mi("{Y^* Y = I_{N-n} - Z^* Z}")#text(", where ")#mi("{I_n}")#text(" is the ")#mi("{n \\times n}")#text(" identity matrix. But from the ")#link("http://en.wikipedia.org/wiki/Singular_value_decomposition")[#text("singular value decomposition")]#text(" we see that ")#mi("{I_n-ZZ^*}")#text(" and ")#mi("{I_{N-n}-Z^*Z}")#text(" have the same determinant, and the claim follows. (One can also establish this lemma using the ")#link("http://en.wikipedia.org/wiki/Hodge_dual")[#text("Hodge star operation")]#text(".) ")#mi("\\Box")

#text("From this lemma we see that ")#mi("{S \\backslash A}")#text(" is a determinantal process with kernel ")#mi("{I_N - K}")#text(". In particular, we have ")#metadata(none) <tao-af76d43af48494a3542a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\Bbb P}( \\{i_1,\\ldots,i_k\\} \\cap A = \\emptyset ) = \\det( I_k - ( K(i_a,i_b) )_{1 \\leq a,b \\leq k} ).")]]

#text("The construction of the determinantal process given above is somewhat indirect. A more direct way to build the process exploits the following lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" Let ")#mi("{V}")#text(" be an ")#mi("{n}")#text("-dimensional subspace of ")#mi("{{\\mathbb R}^N}")#text(", let ")#mi("{A_V}")#text(" be the corresponding ")#mi("{n}")#text("-element determinantal process, and let ")#mi("{1 \\leq i_1 < \\ldots < i_k \\leq N}")#text(" for some ")#mi("{1 \\leq k \\leq n}")#text(". Then the if one conditions on the event that ")#mi("{\\{i_1,\\ldots,i_k\\} \\in A_V}")#text(" (assuming this event has non-zero probability), the resulting ")#mi("{n-k}")#text("-element process ")#mi("{A_V \\backslash \\{i_1,\\ldots,i_k\\}}")#text(" has the same distribution as the ")#mi("{n-k}")#text("-element determinantal process ")#mi("{A_W}")#text(" associated to the ")#mi("{n-k}")#text("-dimensional subspace ")#mi("{W}")#text(" of ")#mi("{V}")#text(" that is orthogonal to ")#mi("{e_{i_1},\\ldots,e_{i_k}}")#text(".")
]

#emph[#text("Proof:")]#text(" By symmetry it suffices to consider the case ")#mi("{\\{i_1,\\ldots,i_k\\} = \\{1,\\ldots,k\\}}")#text(". By a further application of symmetry it suffices to show that")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( A_V = \\{1,\\ldots,n\\} ) = {\\Bbb P}( \\{1,\\ldots,k\\} \\subset A_V ) {\\Bbb P}( A_W = \\{k+1,\\ldots,n\\} ).")]]

#text("By the Gram-Schmidt process, we can find an orthonormal basis ")#mi("{v_1,\\ldots,v_n}")#text(" of ")#mi("{V}")#text(" whose ")#mi("{n \\times N}")#text(" matrix of coefficients vanishes below the diagonal. One then easily verifies (using Lemma ")#link(<tao-784a2ddf5d4d61b6ae15>)[#text("4")]#text(") that ")#mi("{{\\Bbb P}( A_V = \\{1,\\ldots,n\\} )}")#text(" is the product of the ")#mi("{n}")#text(" diagonal entries, ")#mi("{{\\Bbb P}( \\{1,\\ldots,k\\} \\subset A_V )}")#text(" is the product of the first ")#mi("{k}")#text(", and ")#mi("{{\\Bbb P}( A_W = \\{k+1,\\ldots,n\\} )}")#text(" is the product of the last ")#mi("{n-k}")#text(", and the claim follows. ")#mi("\\Box")

#text("From this lemma, it is not difficult to see that one can build ")#mi("{A_V}")#text(" recursively as ")#mi("{A_V = \\{a\\} \\cup A_{V_a}}")#text(", where ")#mi("{a}")#text(" is a random variable drawn from ")#mi("{S}")#text(" with a ")#tao-math("{{\\Bbb P}(a=i)=\\left\\|P e_i\\right\\|^2 / \\text{dim}(V)}", block: false)#text(" for each ")#mi("{i}")#text(", and ")#mi("{V_a}")#text(" is the subspace of ")#mi("{V}")#text(" orthogonal to ")#mi("{e_a}")#text(". Another consequence of this lemma and the monotonicity property is the negative dependence inequality")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\mathbb P}( B_1 \\cup B_2 \\subset A ) \\leq \\mathop{\\mathbb P}( B_1 \\subset A) \\mathop{\\mathbb P}( B_2 \\subset A )")]]

#text("for any disjoint ")#mi("{B_1, B_2 \\subset S}")#text("; thus the presence of ")#mi("{A}")#text(" on one set ")#mi("{B_1}")#text(" reduces the chance of ")#mi("{A}")#text(" being present on a disjoint set ")#mi("{B_2}")#text(" (not surprising, since ")#mi("{A}")#text(" has fixed size).")

#text("Thus far, we have only considered point processes with a fixed number ")#mi("{n}")#text(" of points. As a consequence, the determinantal kernel ")#mi("{K}")#text(" involved here is of a special form, namely the coefficients of an orthogonal projection matrix to an ")#mi("{n}")#text("-dimensional space (or equivalently, a symmetric matrix whose eigenvalues consist of ")#mi("{n}")#text(" ones and ")#mi("{N-n}")#text(" zeroes). But one can create more general point processes by taking a ")#emph[#text("mixture")]#text(" of the fixed-number processes, e.g. first picking a projection kernel ")#mi("{K}")#text(" (or a subspace ")#mi("{V}")#text(") by some random process, and then sampling ")#mi("{A}")#text(" from the point process associated to that kernel or subspace.")

#text("For instance, let ")#mi("{\\phi_1,\\ldots,\\phi_N}")#text(" be an orthonormal basis of ")#mi("{{\\mathbb R}^N}")#text(", and let ")#mi("{0 \\leq \\lambda_1,\\ldots,\\lambda_N \\leq 1}")#text(" be weights. Then we can create a random subspace ")#mi("{V}")#text(" of ")#mi("{{\\mathbb R}^N}")#text(" by setting ")#mi("{V}")#text(" equal to the span ")#mi("{V_J}")#text(" of some random subset ")#mi("{\\{ \\phi_j: j \\in J \\}}")#text(" of the basis ")#mi("{v_1,\\ldots,v_N}")#text(", where each ")#mi("{j}")#text(" lies in ")#mi("{J}")#text(" with an independent probability of ")#mi("{\\lambda_j}")#text(", and then sampling ")#mi("{A}")#text(" from ")#mi("{A_V}")#text(". Then ")#mi("{A}")#text(" will be a point process whose cardinality can range from ")#mi("{0}")#text(" to ")#mi("{N}")#text(". Given any set ")#mi("{\\{i_1,\\ldots,i_k\\} \\subset S}")#text(", we can then compute the probability ")#mi("{\\mathop{\\mathbb P}( \\{i_1,\\ldots,i_k\\} \\subset A )}")#text(" as")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( \\{i_1,\\ldots,i_k\\} \\subset A ) = {\\Bbb E}_J {\\Bbb P}( \\{i_1,\\ldots,i_k\\} \\subset A_{V_J} )")]]

#text("where ")#mi("{J}")#text(" is selected as above. Using ")#link(<tao-664243732d01ab1ce602>)[#text("(1)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( \\{i_1,\\ldots,i_k\\} \\subset A_{V_J} ) = \\det( K_{V_J}( i_a, i_b ) )_{1 \\leq a,b \\leq k}.")]]

#text("But ")#mi("{K_{V_J}(i_a,i_b) = \\sum_{j \\in J} \\phi_j(i_a) \\phi_j(i_b)}")#text(", where ")#mi("{\\phi_j(i)}")#text(" is the ")#mi("{i^{th}}")#text(" coordinate of ")#mi("{\\phi_j}")#text(". Thus we can write")

#align(center)[#tao-fit-display[#mitex("(K_{V_J}(i_a,i_b))_{1 \\leq a,b \\leq k} = \\sum_{j =1}^N {\\Bbb I}( j \\in J ) R_j")]]

#text("where ")#mi("{{\\Bbb I}( j \\in J )}")#text(" is the indicator of the event ")#mi("{j \\in J}")#text(", and ")#mi("{R_j}")#text(" is the rank one matrix ")#mi("{( \\phi_j(i_a) \\phi_j(i_b) )_{1 \\leq a,b \\leq k}}")#text(". Using multilinearity of the determinant, and the fact that any determinant involving two or more rows of the same rank one matrix automatically vanishes, we see that we can express")

#align(center)[#tao-fit-display[#mitex("\\det( (K_{V_J}(i_a,i_b))_{1 \\leq a,b \\leq k} ) = \\sum_{1 \\leq j_1,\\ldots,j_k \\leq N, \\text{ distinct }} {\\Bbb I}( j_1,\\ldots,j_k \\in J ) \\det( R_{j_1,\\ldots,j_k} )")]]

#text("wheree ")#mi("{R_{j_1,\\ldots,j_k}}")#text(" is the matrix whose first row is the same as that of ")#mi("{R_{j_1}}")#text(", the second row is the same as that of ")#mi("{R_{j_2}}")#text(", and so forth. Taking expectations in ")#mi("{J}")#text(", the quantity ")#mi("{{\\Bbb I}( j_1,\\ldots,j_k \\in J )}")#text(" becomes ")#mi("{\\lambda_{j_1} \\ldots \\lambda_{j_k}}")#text(". Undoing the multilinearity step, we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_J \\det( K_{V_J}( i_a, i_b ) )_{1 \\leq a,b \\leq k} = \\det( \\sum_{j=1}^N \\lambda_j R_j )")]]

#text("and thus ")#mi("{A}")#text(" is a determinantal process with kernel")

#align(center)[#tao-fit-display[#mitex("K( x, y ) := \\sum_{j =1}^N \\lambda_j \\phi_j(x) \\phi_j(y).")]]

#text("To summarise, we have created a determinantal process ")#mi("{A}")#text(" whose kernel ")#mi("{K}")#text(" is now an arbitrary symmetric matrix with eigenvalues ")#mi("{\\lambda_1,\\ldots,\\lambda_n \\in [0,1]}")#text(", and it is a mixture of constant-size processes ")#mi("{A_{V_J}}")#text(". In particular, the cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(" of this process has the same distribution as the cardinality ")#tao-math("{\\left|J\\right|}", block: false)#text(" of the random subset of ")#mi("{\\{1,\\ldots,N\\}}")#text(", or in other words ")#tao-math("{\\left|A\\right| \\equiv I_{\\lambda_1} + \\ldots + I_{\\lambda_k}}", block: false)#text(", where ")#mi("{I_{\\lambda_1},\\ldots,I_{\\lambda_k}}")#text(" are independent Bernoulli variables with expectation ")#mi("{\\lambda_1,\\ldots,\\lambda_k}")#text(" respectively.")

#text("Observe that if one takes a determinantal process ")#mi("{A \\subset S}")#text(" with kernel ")#mi("{K}")#text(", and restricts it to a subset ")#mi("{S^{\\prime}}")#text(" of ")#mi("{S}")#text(", then the resulting process ")#mi("{A \\cap S^{\\prime} \\subset S^{\\prime}}")#text(" is a determinantal process whose kernel ")#mi("{K^{\\prime}}")#text(" is simply the restriction of ")#mi("{K}")#text(" to the ")#mi("{S^{\\prime} \\times S^{\\prime}}")#text(" block of ")#mi("{S \\times S}")#text(". Applying the previous observation, we conclude that the random variable ")#tao-math("{\\left|A \\cap S^{\\prime}\\right|}", block: false)#text(" has the same distribution as the sum of ")#tao-math("{\\left|S^{\\prime}\\right|}", block: false)#text(" independent Bernoulli variables, whose expectations are the eigenvalues of the restriction of ")#mi("{K}")#text(" to ")#mi("{S^{\\prime}}")#text(". (Compare this to the Poisson point process ")#mi("{A}")#text(" with some intensity measure ")#mi("{\\lambda}")#text(", where the distribution of ")#tao-math("{\\left|A \\cap \\Omega\\right|}", block: false)#text(" is a Poisson process with intensity ")#mi("{\\lambda(\\Omega)}")#text(".) Note that most point processes do not obey this property (e.g. the uniform distribution on ")#mi("{\\binom{S}{n}}")#text(" does not unless ")#mi("{n=0,1}")#text(" or ")#mi("{n=N,N-1}")#text("), and so most point processes are not determinantal.")

#text("It is known that increasing a positive semi-definite matrix by another positive semi-definite matrix does not decrease the determinant (indeed, it does not decrease any eigenvalue, by the minimax characterisation of those eigenvalues). As a consequence, if the kernel ")#mi("{K^{\\prime}}")#text(" of a determinantal process ")#mi("{A^{\\prime}}")#text(" is larger than the kernel ")#mi("{K}")#text(" of another determinantal process ")#mi("{A}")#text(" in the sense that ")#mi("{K-K^{\\prime}}")#text(" is positive semi-definite, then ")#mi("{A^{\\prime}}")#text(" is “larger” than ")#mi("{A}")#text(" in the sense that ")#mi("{{\\Bbb P}( B \\subset A^{\\prime}) \\geq {\\Bbb P}( B \\subset A)}")#text(" for all ")#mi("{B \\subset S}")#text(". A particularly nice special case is when ")#mi("{K = c K^{\\prime}}")#text(" for some ")#mi("{0 \\leq c \\leq 1}")#text(", then ")#tao-math("{{\\Bbb P}( B \\subset A) = c^{\\left|B\\right|} {\\Bbb P}( B \\subset A^{\\prime})}", block: false)#text(" for all ")#mi("{B}")#text(", and one can interpret ")#mi("{A}")#text(" as the process obtained from ")#mi("{A^{\\prime}}")#text(" by deleting each element of ")#mi("{A^{\\prime}}")#text(" independently at random with probability ")#mi("{1-c}")#text(" (i.e. keeping that element independently at random with probability ")#mi("{c}")#text(").")

#text("As a consequence of this, one can obtain a converse to our previous construction of determinantal processes, and conclude that a determinantal process can be associated to a symmetric kernel ")#mi("{K}")#text(" only if the eigenvalues of ")#mi("{K}")#text(" lie between zero and one. The fact that ")#mi("{K}")#text(" is positive semi-definite follows from the fact that all symmetric minors of ")#mi("{K}")#text(" have non-negative determinant (thanks to ")#link(<tao-664243732d01ab1ce602>)[#text("(1)")]#text("). Now suppose for contradiction that ")#mi("{K}")#text(" has an eigenvalue larger than ")#mi("{1}")#text(", then one can find ")#mi("{0 \\leq c < 1}")#text(" such that the largest eigenvalue of ")#mi("{cK}")#text(" is exactly ")#mi("{1}")#text(". By our previous discussion, the process ")#mi("{A_{cK}}")#text(" associated to ")#mi("{cK}")#text(" is then formed from the process ")#mi("{A_K}")#text(" by deleting each element of ")#mi("{A}")#text(" with non-zero probability; in particular, ")#mi("{A_K}")#text(" is empty with non-zero probability. On the other hand, we know that ")#tao-math("{\\left|A_K\\right|}", block: false)#text(" has the distribution of the sum of independent Bernoulli variables, at least one of which is ")#mi("{1}")#text(" with probability one, a contradiction. (This proof is due to ")#link("http://front.math.ucdavis.edu/math/0503110")[#text("Hough et al.")]#text(", though the result is originally due ")#link("http://www.ams.org/mathscinet-getitem?mr=1799012")[#text("to Soshnikov")]#text(". An alternate proof is to extend the identity ")#link(<tao-af76d43af48494a3542a>)[#text("(2)")]#text(" to all determinantal processes and conclude that ")#mi("{I-K}")#text(" is necessarily positive definite.)")

#heading(level: 1)[#strong[#text(" — 2. Continuous determinantal processes — ")]]

#text("One can extend the theory of discrete determinantal processes to the continuous setting. For simplicity we restrict attention to (simple) point processes ")#mi("{A \\subset {\\mathbb R}}")#text(" on the real line. A process ")#mi("{A}")#text(" is said to have ")#emph[#text("correlation functions")]#text(" ")#mi("{\\rho_k: {\\mathbb R}^k \\rightarrow {\\mathbb R}}")#text(" for ")#mi("{k \\geq 1}")#text(" if the ")#mi("{\\rho_k}")#text(" are symmetric, non-negative, and locally integrable, and one has the formula")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} \\sum_{x_1,\\ldots,x_k \\in A, \\text{ distinct}} f( x_1,\\ldots,x_k ) = \\int_{{\\mathbb R}^k} f(x_1,\\ldots,x_k) \\rho_k(x_1,\\ldots,x_k)\\ dx_1 \\ldots dx_k")]]

#text("for any bounded measurable symmetric ")#mi("{f}")#text(" with compact support, where the left-hand side is summed over all ")#mi("{k}")#text("-tuples of distinct points in ")#mi("{A}")#text(" (this sum is of course empty if ")#tao-math("{\\left|A\\right| \\leq k}", block: false)#text("). Intuitively, the probability that ")#mi("{A}")#text(" contains an element in the infinitesimal interval ")#mi("{[x_i,x_i+dx_i]}")#text(" for all ")#mi("{1 \\leq i \\leq k}")#text(" and distinct ")#mi("{x_1,\\ldots,x_k}")#text(" is equal to ")#mi("{\\rho_k(x_1,\\ldots,x_k) dx_1 \\ldots dx_k}")#text(". The ")#mi("{\\rho_k}")#text(" are not quite probability distributions; instead, the integral ")#mi("{\\int_{{\\mathbb R}^k} \\rho_k}")#text(" is equal to ")#tao-math("{k! {\\Bbb E} \\binom{\\left|A\\right|}{k}}", block: false)#text(". Thus, for instance, if ")#mi("{A}")#text(" is a constant-size process of cardinality ")#mi("{n}")#text(", then ")#mi("{\\rho_k}")#text(" has integral ")#mi("{\\frac{n!}{(n-k)!}}")#text(" on ")#mi("{{\\mathbb R}^n}")#text(" for ")#mi("{1 \\leq k \\leq n}")#text(" and vanishes for ")#mi("{k>n}")#text(".")

#text("If the correlation functions exist, it is easy to see that they are unique (up to almost everywhere equivalence), and can be used to compute various statistics of the process. For instance, an application of the inclusion-exclusion principle shows that for any bounded measurable set ")#mi("{\\Omega}")#text(", the probability that ")#mi("{A \\cap \\Omega = \\emptyset}")#text(" is (formally) equal to")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=0}^\\infty \\frac{(-1)^k}{k!} \\int_{({\\mathbb R} \\backslash \\Omega)^k} \\rho_k(x_1,\\ldots,x_k)\\ dx_1 \\ldots dx_k.")]]

#text("A process is ")#emph[#text("determinantal")]#text(" with some symmetric measurable kernel ")#mi("{K: {\\mathbb R} \\times {\\mathbb R} \\rightarrow {\\mathbb R}}")#text(" if it has correlation functions ")#mi("{\\rho_k}")#text(" given by the formula ")#metadata(none) <tao-49f380546cf1e36113bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\rho_k(x_1,\\ldots,x_k) = \\det (K(x_i,x_j))_{1 \\leq i,j \\leq k}.")]]

#text("Informally, the probability that ")#mi("{A}")#text(" intersects the infinitesimal intervals ")#mi("{[x_i,x_i+dx_i]}")#text(" for distinct ")#mi("{x_1,\\ldots,x_k}")#text(" is ")#mi("{\\det (K(x_i,x_j) dx_i^{1/2} dx_j^{1/2})_{1 \\leq i,j \\leq k}}")#text(". (Thus, ")#mi("{K}")#text(" is most naturally interpreted as a half-density, or as an integral operator from ")#mi("{L^2({\\mathbb R})}")#text(" to ")#mi("{L^2({\\mathbb R})}")#text(".)")

#text("There are analogues of the discrete theory in this continuous setting. For instance, one can show that a symmetric measurable kernel ")#mi("{K}")#text(" generates a determinantal process if and only if the associated integral operator ")#mi("{{\\mathcal K}}")#text(" has spectrum lies in the interval ")#mi("{[0,1]}")#text(". The analogue of ")#link(<tao-af76d43af48494a3542a>)[#text("(2)")]#text(" is the formula")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( A \\cap \\Omega = \\emptyset ) = \\det( I - {\\mathcal K}|_\\Omega );")]]

#text("more generally, the distribution of ")#tao-math("{\\left|A \\cap \\Omega\\right|}", block: false)#text(" is the sum of independent Bernoulli variables, whose expectations are the eigenvalues of ")#mi("{{\\mathcal K}|_\\Omega}")#text(". Finally, if ")#mi("{{\\mathcal K}}")#text(" is an orthogonal projection onto an ")#mi("{n}")#text("-dimensional space, then the process has a constant size of ")#mi("{n}")#text(". Conversely, if ")#mi("{A}")#text(" is a process of constant size ")#mi("{n}")#text(", whose ")#mi("{n^{th}}")#text(" correlation function ")#mi("{\\rho_n(x_1,\\ldots,x_n)}")#text(" is given by ")#link(<tao-49f380546cf1e36113bd>)[#text("(3)")]#text(", where ")#mi("{{\\mathcal K}}")#text(" is an orthogonal projection onto an ")#mi("{n}")#text("-dimensional space, then ")#link(<tao-49f380546cf1e36113bd>)[#text("(3)")]#text(" holds for all other values of ")#mi("{k}")#text(" as well, and so ")#mi("{A}")#text(" is a determinantal process with kernel ")#mi("{K}")#text(". (This is roughly the analogue of Lemma ")#link(<tao-784a2ddf5d4d61b6ae15>)[#text("4")]#text(".)")

#text("These facts can be established either by approximating a continuous process as the limit of discrete ones, or by obtaining alternate proofs of several of the facts in the previous section which do not rely as heavily on the discrete hypotheses. See ")#link("http://front.math.ucdavis.edu/math/0503110")[#text("Hough et al.")]#text(" for details.")

#text("A Poisson process can be viewed as the limiting case of a determinantal process in which ")#mi("{{\\mathcal K}}")#text(" degenerates to a (normalisation of) a multiplication operator ")#mi("{f \\mapsto \\lambda f}")#text(", where ")#mi("{\\lambda}")#text(" is the intensity function.")

#heading(level: 1)[#strong[#text(" — 3. The spectrum of GUE — ")]]

#text("Now we turn to a specific example of a continuous point process, namely the spectrum ")#mi("{A = \\{\\lambda_1,\\ldots,\\lambda_n\\} \\subset {\\mathbb R}}")#text(" of the ")#emph[#text("Gaussian unitary ensemble")]#text(" ")#mi("{M_n = (\\zeta_{ij})_{1 \\leq i,j \\leq n}}")#text(", where the ")#mi("{\\zeta_{ij}}")#text(" are independent for ")#mi("{1 \\leq i \\leq j \\leq n}")#text(" with mean zero and variance ")#mi("{1}")#text(", with ")#mi("{\\zeta_{ij}}")#text(" being the standard complex gaussian for ")#mi("{i<j}")#text(" and the standard real gaussian ")#mi("{N(0,1)}")#text(" for ")#mi("{i=j}")#text(". The probability distribution of ")#mi("{M_n}")#text(" can be expressed as")

#align(center)[#tao-fit-display[#mitex("c_n \\exp( - \\frac{1}{2} \\text{trace}( M_n^2 ) )\\ dM_n")]]

#text("where ")#mi("{dM_n}")#text(" is Lebesgue measure on the space of Hermitian ")#mi("{n \\times n}")#text(" matrices, and ")#mi("{c_n > 0}")#text(" is some explicit normalising constant.")

#text("The ")#mi("{n}")#text("-point correlation function of ")#mi("{A}")#text(" can be computed explicitly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Ginibre formula)")]#text(" The ")#mi("{n}")#text("-point correlation function ")#mi("{\\rho_n(x_1,\\ldots,x_n)}")#text(" of the GUE spectrum ")#mi("{A}")#text(" is given by ")#metadata(none) <tao-4ad815618f703e2f509a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\rho_n(x_1,\\ldots,x_n) = c^{\\prime}_n (\\prod_{1 \\leq i <j \\leq n} \\left|x_i-x_j\\right|^2) \\exp( - \\sum_{i=1}^n x_i^2 / 2 )", block: true)]]

#text("where the normalising constant ")#mi("{c^{\\prime}_n}")#text(" is chosen so that ")#mi("{\\rho_n}")#text(" has integral ")#mi("{1}")#text(".")
]

#text("The constant ")#mi("{c^{\\prime}_n > 0}")#text(" is essentially the reciprocal of the ")#link("http://en.wikipedia.org/wiki/Partition_function_(mathematics)")[#text("partition function")]#text(" for this ensemble, and can be computed explicitly, but we will not do so here.")

#emph[#text("Proof:")]#text(" Let ")#mi("{D}")#text(" be a diagonal random matrix ")#mi("{D = \\text{diag}(x_1,\\ldots,x_n)}")#text(" whose entries are drawn using the distribution ")#mi("{\\rho_n(x_1,\\ldots,x_n)}")#text(" defined by ")#link(<tao-4ad815618f703e2f509a>)[#text("(4)")]#text(", and let ")#mi("{U \\in U(n)}")#text(" be a unitary matrix drawn uniformly at random (with respect to Haar measure on ")#mi("{U(n)}")#text(") and independently of ")#mi("{D}")#text(". It will suffice to show that the GUE ")#mi("{M_n}")#text(" has the same probability distribution as ")#mi("{U^* DU}")#text(". Since probability distributions have total mass one, it suffices to show that their distributions differ up to multiplicative constants.")

#text("The distributions of ")#mi("{M_n}")#text(" and ")#mi("{U^* DU}")#text(" are easily seen to be continuous and invariant under unitary rotations. Thus, it will suffice to show that their probability density at a given diagonal matrix ")#mi("{D_0 = \\text{diag}(x^0_1, \\ldots, x^0_n)}")#text(" are the same up to multiplicative constants. We may assume that the ")#mi("{x^0_i}")#text(" are distinct, since this occurs for almost every choice of ")#mi("{D_0}")#text(".")

#text("On the one hand, the probability density of ")#mi("{M_n}")#text(" at ")#mi("{D_0}")#text(" is proportional to ")#mi("{\\exp( - \\sum_{i=1}^n (x_i^0)^2 / 2 )}")#text(". On the other hand, a short computation shows that if ")#mi("{U^* D U}")#text(" is within a distance ")#mi("{O(\\epsilon)}")#text(" of ")#mi("{D_0}")#text(" for some infinitesimal ")#mi("{\\epsilon>0}")#text(", then (up to permutations) ")#mi("{D}")#text(" must be a distance ")#mi("{O(\\epsilon)}")#text(" from ")#mi("{D_0}")#text(", and the ")#mi("{ij}")#text(" entry of ")#mi("{U}")#text(" must be a complex number of size ")#tao-math("{O( \\epsilon / \\left|x_i^0 - x_j^0\\right| )}", block: false)#text(" for ")#mi("{1 \\leq i < j \\leq n}")#text(", while the diagonal entries of ")#mi("{U}")#text(" can be arbitrary phases. Pursuing this computation more rigorously (e.g. using the Harish-Chandra formula) and sending ")#mi("{\\epsilon \\rightarrow 0}")#text(", one can show that the probability density of ")#mi("{U^* D U}")#text(" at ")#mi("{D_0}")#text(" is a constant multiple of")

#align(center)[#tao-fit-display[#tao-math("\\rho_n(x_1,\\ldots,x_n) \\prod_{1 \\leq i < j \\leq n} \\frac{1}{\\left|x_i^0 - x_j^0\\right|^2}", block: true)]]

#text("(the square here arising because of the complex nature of the ")#mi("{ij}")#text(" coefficient of ")#mi("{U}")#text(") and the claim follows. ")#mi("\\Box")

#text("One can also represent the ")#mi("{k}")#text("-point correlation functions as a determinant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Gaudin-Mehta formula)")]#text(" The ")#mi("{k}")#text("-point correlation function ")#mi("{\\rho_k(x_1,\\ldots,x_n)}")#text(" of the GUE spectrum ")#mi("{A}")#text(" is given by ")#metadata(none) <tao-96a101c117aa3b69c332>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\rho_k(x_1,\\ldots,x_k) = \\det( K_n( x_i, x_j ) )_{1 \\leq i < j \\leq k}")]]

#text("where ")#mi("{K_n(x,y)}")#text(" is the kernel of the orthogonal projection ")#mi("{{\\mathcal K}}")#text(" in ")#mi("{L^2({\\mathbb R})}")#text(" to the space spanned by the polynomials ")#mi("{x^i e^{-x^2/4}}")#text(" for ")#mi("{i=0,\\ldots,n-1}")#text(". In other words, ")#mi("{A}")#text(" is the ")#mi("{n}")#text("-point determinantal process with kernel ")#mi("{K_n}")#text(".")
]

#emph[#text("Proof:")]#text(" By the material in the preceding section, it suffices to establish this for ")#mi("{k=n}")#text(". As ")#mi("{K}")#text(" is the kernel of an orthogonal projection to an ")#mi("{n}")#text("-dimensional space, it generates an ")#mi("{n}")#text("-point determinantal process and so ")#mi("{\\det( K_n( x_i, x_j ) )_{1 \\leq i < j \\leq n}}")#text(" has integral ")#mi("{\\binom{n}{n}=1}")#text(". Thus it will suffice to show that ")#mi("{\\rho_n}")#text(" and ")#mi("{\\det( K_n( x_i, x_j ) )_{1 \\leq i < j \\leq n}}")#text(" agree up to multiplicative constants.")

#text("By Gram-Schmidt, one can find an orthonormal basis ")#mi("{\\phi_i(x) e^{-x^2/4}}")#text(", ")#mi("{i=0,\\ldots,n-1}")#text(" for the range of ")#mi("{{\\mathcal K}}")#text(", with each ")#mi("{\\phi_i}")#text(" a polynomial of degree ")#mi("{i}")#text(" (these are essentially the ")#link("http://en.wikipedia.org/wiki/Hermite_polynomials")[#text("Hermite polynomials")]#text("). Then we can write")

#align(center)[#tao-fit-display[#mitex("K_n(x_i,x_j) = \\sum_{k=0}^{n-1} \\phi_k(x_i) \\phi_k(x_j) e^{-(x_i^2+x_j^2)/4}.")]]

#text("Cofactor expansion then shows that ")#mi("{\\det( K_n( x_i, x_j ) )_{1 \\leq i < j \\leq n}}")#text(" is equal to ")#mi("{\\exp( - \\sum_{i=1}^n x_i^2 / 2 )}")#text(" times a polynomial ")#mi("{P(x_1,\\ldots,x_n)}")#text(" in ")#mi("{x_1,\\ldots,x_n}")#text(" of degree at most ")#mi("{2\\sum_{k=0}^{n-1} k = n(n-1)}")#text(". On the other hand, this determinant is always non-negative, and vanishes whenever ")#mi("{x_i=x_j}")#text(" for any ")#mi("{1 \\leq i < j \\leq n}")#text(", and so must contain ")#mi("{(x_i-x_j)^2}")#text(" as a factor for all ")#mi("{1 \\leq i < j \\leq n}")#text(". As the total degree of all these (relatively prime) factors is ")#mi("{n(n-1)}")#text(", the claim follows. ")#mi("\\Box")

#text("This formula can be used to obtain asymptotics for the (renormalised) GUE eigenvalue spacings in the limit ")#mi("{n \\rightarrow \\infty}")#text(", by using asymptotics for (renormalised) Hermite polynomials; this was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=278668")[#text("by Dyson")]#text(".")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41119")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2009")])]

#text("Dear Prof. Tao,")

#text("before ")#mi("(1),")#text(" is ")#mi("K")#text(" ")#mi("k \\times k")#text(" or ")#mi("n \\times n")#text("?")

#text("thanks")

#emph[#text("[Corrected, thanks]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2009")])]

#text("Is the expository tag missing? ")#emph[#text("[Added, thanks.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57744d317aabf2623318a0b93bec2c13a4c686b4cea94c1c7eafa52c7a7eaf31-ee1e69b722b749f580dce786d1e425137d5db5835597cc3689cef46fec32a06e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig Tracy")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41127")[#strong[#text("Craig Tracy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2009")])]

#text("TASEP (=totally asymmetric simple exclusion process) is a determinantal process (see Kurt Johansson’s paper “Shape Fluctuations and Random Matrices”) but the more general ASEP (=asymmetric simple exclusion process) is, as far as I understand, not a determinantal process. However, in recent work with Harold Widom we have shown that the limit laws for ASEP are the same as for TASEP (see ")#link("http://arxiv.org/a/tracy_c_1.atom")[#text("http://arxiv.org/a/tracy_c_1.atom")]#text(") thus establishing “KPZ universality”. Hence, what is proved at the level of determinantal processes appears to extend to a larger class of processes. This is similar in spirit to the Soshnikov/Tao/Vu work on Wigner matrices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f58a6fe8e80900cd217f5495a3218d9acd85e5cd977db9fa87967870ef862781-e2c6836262ee65f748346f68b007381932b682cc851bc4e1d0fc0658dba16387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ramanujantao")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41128")[#strong[#text("ramanujantao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2009")])]

#text("What is the point of writing “$la tex {x \\in A}$ instead of ”$la tex x \\in A$?”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcf67163acabbc85ec4bdc69408d6e6da41ba42ef3b9c44b29e1bbf640e6de7a-826164bf683066da1d36ddcb030f1dc9f52b35c5ce2a8880340749958547ef6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ateixeira")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41132")[#strong[#text("ateixeira")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2009")])]

#text("The LateX code appear between {} because of Luca Trevisan’s LateX to wordpress converter: ")#link("http://lucatrevisan.wordpress.com/latex-to-wordpress/")[#text("http://lucatrevisan.wordpress.com/latex-to-wordpress/")]

#text("It is pretty handy if one is writing long posts that use a lot of mathematical expressions in WordPress.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a0b10aff2cf7875bfcfe44b88c9ec8d5b9d91f1061b909b7789f8ec9024b1e8-63662168c63421adb75efd9e1dfce4710a34284aafc6a513b41e3618bd3bde25.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carnegie")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41129")[#strong[#text("carnegie")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2009")])]

#text("Dear Professor Tao,")

#text("There seems to be a deep link between determinantal processes, random matrix theory, orthogonal polynomials, and integrable systems. Your previous commenter Craig Tracy has done very pioneering work in all these areas.")

#text("It would be interesting to know if the determinants which appear are related to the determinants involved in the Kyoto school’s approach to quantum field theory. Determinants there appear essentially when considering changes of basis in a Grassmannian.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41136")[#strong[#text("From Helly to Cayley IV: Probability « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2009")]

#text("[…] of studying determinental probability measures. (You can read more about determinental processes in this post of Terry Tao, and this survey paper by J. Ben Hough, Manjunath Krishnapur, Yuval Peres, and Bálint […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41140")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2009")])]

#text("Dear Terry, It is very cool how the algebra gives quick proofs and insights to these issues. Is the following known: start with a random Gausian n by n matrix and consider the associated (latex 2^n\\times 2^n$) random matrix on the entire exterior algebra. What is the distribution of the eigenvalues of the huge matrix (and the distribution of spacing; maximual eigenvalue etc.) One can simply talk about the set of all products of eigenvalues but maybe the algebraic setting may help.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41323")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2009")])]

#text("Let me add that Gerard Letac and Wlodzimiers Btyc have considered the distribution of eigenvalues of compund matrices.")

#text("My motivation was related toa polymath4 discussion: if the eigenvalues are analogous to the primes then the eigenvalues of the huge ")#mi("2^n \\times 2^n")#text(" matrix are analogous to the squre free integers. Maybe in some sense and for some appropriate normalization (the normalization is important) the ")#mi("2^n")#text(" eigenvalues of the huge matrix will behave like a poisson point process (e.g. in terms of spacings joint-distribution).")

#text("Of course (as Gerard pointed) when you create 2^n numbers out of n you lose a lot of randomness but still for local property (like spacing distributions) you may recover a behavior of Poisson point process for the huge matrix while the behavior for the small matrix is very different.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41143")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2009")])]

#text("Dear Prof. Tao,")

#text("what do you mean by ”Lebesgue measure on the space of Hermitian matrices….” ?")

#text("do not we have Lebesque measure just on ")#mi("{\\mathbb R}^{n}")#text(" ?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JC")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41154")[#strong[#text("JC")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2009")])]

#text("The space of hermitian matrices forms a real vector space (of dimension ")#mi("n^2")#text("), so Lebesgue measure is defined.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41157")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2009")])]

#text("thanks for the answer")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41156")[#strong[#text("On the geometric meaning of the Cauchy Schwarz inequality, an intro to exterior powers, and surface integrals « A Day in the Life of a Wild Positron")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2009")]

#text("[…] the meantime, check out this post of Terence Tao on how this same induced inner product can be used to construct interesting processes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47d66aa36c2a09d9cc955672ced782b243837543f8cc8e0915a463a50804ae85-214cb5e63d230e914ecb88299cd241b6af1104172af5a7120bc2a1fff8bea967.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manju")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41169")[#strong[#text("Manju")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2009")])]

#text("Dear Terry, a possibly related question to understanding why so many processes are determinantal is about how to check if a process is determinantal? If they are so prevalent there ought to be a simple way, but we only know to do this by computing all correlations. Any light on this would be helpful.")

#text("By the way, the exterior algebra formulation is similar to Russell Lyons’ paper")#linebreak()#text(" ")#link("http://front.math.ucdavis.edu/0204.5325")[#text("http://front.math.ucdavis.edu/0204.5325")]#text(". And a longer version (with examples) of our survey is now available in two chapters of")

#link("http://stat-www.berkeley.edu/~peres/GAF_book.pdf")[#text("Click to access GAF_book.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russell Lyons")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41286")[#strong[#text("Russell Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2009")])]

#text("Hi, Terry.")

#text("You write:")

#text("This seems to suggest that there is some way of representing {A_W} as the union of {A_V} with another process coupled with {A_V}, but I was not able to build a non-artificial example of such a representation.")

#text("I’m not sure what that means, but in my paper (mentioned by Manju and cited by Hough et al), I do prove this is always possible. There are other questions about couplings that are open, though, especially for more than two processes. I’d be very interested to see progress on any of them.")

#text("Best,")#linebreak()#text(" Russ")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41287")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2009")])]

#text("Thanks Russ! I assume you are referring to Theorem 6.2 of your paper (which generalises Lemma 5 here). I agree that there ")#emph[#text("exists")]#text(" a way to couple A_V to A_W in such a way that the former set is always a subset of the latter, but I guess I was looking for some sort of “canonical” or “explicit” construction of such a coupling, possibly with additional nice properties (e.g. perhaps one could arrange so that the difference ")#mi("A_W\\backslash A_V")#text(" was also a determinantal process, e.g. associated to the orthogonal complement of V in W? But perhaps this is too naive). [")#emph[#text("Added later:")]#text(" It seems that ")#mi("P( i \\in A_V ) + P( i \\in A_{V^\\perp \\cap W} ) = P( i \\in A_W )")#text(" from Pythagoras’ theorem, which is some weak evidence in favour of such a coupling existing.]")

#text("[")#emph[#text("Added yet later:")]#text(" It seems that you raise a similar question in page 38 of your paper. Actually this seems to be an interesting question; I think I will add it to the list of potential polymath projects for the future.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russell Lyons")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-41288")[#strong[#text("Russell Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2009")])]

#text("Yes, I was referring to my Thm 6.2 and Question 10.1. I have tested this question on numerous random instances up to dimension 9. A coupling always seems to exist, though, of course, I know nothing about a natural coupling. See also the questions about complete couplings in the following section, which I have also tested somewhat.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-42415")[#strong[#text("The Lindstrom-Gessel-Viennot lemma « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2009")]

#text("[…] lemma implies that non-intersecting random walks are a determinantal process, which connects them to many other mysterious processes. I wish I knew what to make of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0: A review of probability theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-43034")[#strong[#text("254A, Notes 0: A review of probability theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")])]

#text("[…] of eigenvalues (counting multiplicity) of a random matrix . I discuss point processes further in this previous blog post. We will return to point processes (and define them more formally) later in this course. Remark 2 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Gaussian ensembles « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-43721")[#strong[#text("254A, Notes 6: Gaussian ensembles « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("[…] Remark 5 This remarkable identity is part of the beautiful algebraic theory of determinantal processes, which I discuss further in this blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ebe939e7740c148f1651da76bbdf3c8b4cfffda1b1b069125d401eab5e3c9bc-151aef42e19c2c5b2587741153ef24d9e8715ee76cd42050ffc124f6783e514b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roozbeh")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-46652")[#strong[#text("Roozbeh")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2010")])]

#text("Dear Terry, it seems there is a crucial flaw in proof of lemma 6 (Hodge duality). the correct formula is Y*Y= I – W*W not Y*Y= I – Z*Z.")#linebreak()#text(" I have seen a explicit form of K(x,y) in lemma 9, it would be nice if you could guide me to see their equivalence.")#linebreak()#text(" at the end, I have to say your notes are the best among similar notes, I’m writing my graduate thesis manly based on your notes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-46659")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")])]

#text("I believe the formula ")#mi("Y^* Y=I-Z^*Z")#text(" is correct as it stands (it comes from ")#mi("M^* M = I")#text("). You may be thinking instead of the formula ")#mi("YY^* = 1-WW^*")#text(", which comes from ")#mi("MM^* = I")#text(".")

#text("I discuss the Gaudin kernel further in these notes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("254A, Notes 6: Gaussian ensembles")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The mesoscopic structure of GUE eigenvalues « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-49088")[#strong[#text("The mesoscopic structure of GUE eigenvalues « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2010")])]

#text("[…] whenever are and matrices respectively (or more generally, and could be linear operators with sufficiently good spectral properties that make both sides equal). Note that the left-hand side is an determinant, while the right-hand side is a determinant; this formula is particularly useful when computing determinants of large matrices (or of operators), as one can often use it to transform such determinants into much smaller determinants. In particular, the asymptotic behaviour of determinants as can be converted via this formula to determinants of a fixed size (independent of ), which is often a more favourable situation to analyse. Unsurprisingly, this trick is particularly useful for understanding the asymptotic behaviour of determinantal processes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-132071")[#strong[#text("The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2012")])]

#text("[…] decoupled from the event in (1) when is drawn from GUE. To do this we use some of the theory of determinantal processes, and in particular the nice fact that when one conditions a determinantal process to the event that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1559fc4dbe09c859d4ebb43bebf5d47a9ee21b6c1a7773c894126ceac0a734c-b8839c9ae883a625793eb7e05feb0affdf34dec09bb70c381761e0956c6f8e7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jsteinhardt")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-248816")[#strong[#text("jsteinhardt")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("The separate construction of a general DPP as a mixture of fixed-size DPPs seems a bit unsatisfying; could we try to write the general construction directly in terms of exterior powers as follows?")

#text("Associate the exterior algebra with the corresponding (anti-commutative) polynomial algebra. Then the fixed-size DPP construction is obtained by taking ")#mi("v_1,\\ldots,v_n")#text(" to be orthonormal degree-1 (linear) polynomials and letting ")#mi("\\omega = v_1 \\wedge \\cdots \\wedge v_n")#text(". Since ")#mi("\\omega")#text(" is homogeneous of degree ")#mi("n")#text(", the DPP is fixed-size. But we could instead imagine taking ")#mi("v_1,\\ldots,v_n")#text(" to be *affine* polynomials, in which case ")#mi("\\omega")#text(" is inhomogeneous but will still satisfy ")#mi("\\langle \\omega, \\omega \\rangle = 1")#text(" as long as the ")#mi("v_i")#text(" are orthonormal. Does this work or am I missing something?")

#text("Thanks,")#linebreak()#text(" Jacob")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russell Lyons")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-248818")[#strong[#text("Russell Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("Jacob,")

#text("I could not figure out what you are saying in a way that makes it work. However, I can say that the general case arises from the fixed-size case just by restricting to a subset of the ground set. See Sec. 8 of my paper referred to above.")

#text("–Russ")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-248821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2013")])]

#text("Yes, I think this works, although one has to interpret the orthonormality of ")#mi("v_i")#text(" properly (it seems that only the vector parts of the ")#mi("v_i")#text(" are orthogonal to each other). Namely, to obtain a determinantal process with kernel ")#mi("\\sum_i \\lambda_i u_i u_i^*")#text(" for some orthonormal system ")#mi("u_i")#text(", we set ")#mi("v_i")#text(" to be the sum ")#mi("v_i = \\sqrt{1-\\lambda_i} + \\sqrt{\\lambda_i} u_i")#text(" of a scalar and a vector, and then I believe that the magnitude square of the components of the wedge product ")#mi("v_1 \\wedge \\ldots \\wedge v_n")#text(" give the distribution of the point process.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-278090")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2014")]

#strong[#text("What are the most unexpected places you’ve seen determinants come up?")]

#text("Thanks for the great answer, Justin. My first exposure to DPPs came from Terence Tao’s blog (which I found really helpful as a precursor to 1207.6083): ")#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")[#text("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/#comment-456632")[#strong[#text("Entropy optimality: Forster’s isotropy | tcs math")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2015")]

#text("[…] of entropy optimality applied to a determinental measure (see, for instance, Terry Tao’s post on determinental processes). I think this is an especially fertile setting for entropy maximization, but this will be the only […]")
]
