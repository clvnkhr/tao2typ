// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/
// Converted to Typst by tao2typ: "2026-10-14T16:35:18.206562+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Pearls before breakfast, II", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Pearls before breakfast, II")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/")[#text("https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Over a year ago, I had a ")#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/")[#text("brief post")]#text(" here pointing out ")#link("http://en.wikipedia.org/wiki/Gene_Weingarten")[#text("Gene Weingarten")]#text("‘s article in the ")#link("http://www.washingtonpost.com/")[#text("Washington Post")]#text(" entitled “")#link("http://www.washingtonpost.com/wp-dyn/content/article/2007/04/04/AR2007040401721.html")[#text("Pearls before breakfast")]#text("“, in which the Post asked the question of what would happen if a world-class musician (in this case, ")#link("http://en.wikipedia.org/wiki/Joshua_Bell")[#text("Joshua Bell")]#text("), were to perform incognito and out of context, in a Washington subway during the morning rush hour? If you haven’t yet read the ")#link("http://www.washingtonpost.com/wp-dyn/content/article/2007/04/04/AR2007040401721.html")[#text("article")]#text(" describing the experiment and the outcome, I recommend it to you.")

#text("Anyway, a few weeks ago, this article was awarded the ")#link("http://www.pulitzer.org/year/2008/feature-writing")[#text("2008 Pulitzer Prize for Feature Writing")]#text(". Congratulations to Gene, Joshua, and the other Washington Post staff!")

#text("[Actually, this article was highly atypical for Gene; he usually sticks to writing a weekly low-brow humour column entitled “Below the Beltway”. By a random coincidence, I, together with ")#link("http://en.wikipedia.org/wiki/Curt_mcmullen")[#text("Curt McMullen")]#text(", even have a ")#link("http://www.washingtonpost.com/wp-dyn/content/article/2008/02/20/AR2008022001966.html")[#text("very minor bit part in one of these columns")]#text(" (on ")#link("http://www.washingtonpost.com/wp-dyn/content/article/2008/02/20/AR2008022001966_2.html")[#text("page 2")]#text("), thanks to a brief phone conversation we each had with Gene.]")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ac13f09f9518a6a24ce0c24d629e67621b906f1ee22835fcd3972ac874a7997-2625942b4a9d9e37b4d21df9ba785c8f64721ee611573f69b9c8c7dd80c9543a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rick")]], [#link("https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/#comment-29336")[#strong[#text("rick")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2008")])]

#text("What a brilliant article, thanks for pointing this out")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/#comment-29347")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2008")])]

#text("Actually, Fritz Kreisler did the same stunt in New York about eighty years ago, with similar results. (That is what I remember, at any rate; has anybody got a reference?) I am fairly amazed that this wasn’t pointed out; surely playing on Kreisler’s violin was intentional?")

#text("PS. What is dour about Bruch’s Violin Concerto?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2413ea49e91edc291d51de27a9f278d355a2db166c2ebed0013fac7b2d1068d7-a123ddfd03e312c5c49d8515de57e643ea0c7f4d36a45e8e3f26c5c595a9bf88.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/#comment-29353")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2008")])]

#text("Even more recently, there was ")#link("http://www.boingboing.net/2008/04/23/experiment-96-of-pas.html")[#text("a similar experiment")]#text(" with paintings.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger")]], [#link("https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/#comment-29359")[#strong[#text("Roger")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2008")])]

#text("It was an amusing stunt, but keep in mind that he did it during the morning commute, when most people could not stop even if they wanted to. Plus, most people do not even like violin music.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lucie")]], [#link("https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/#comment-29419")[#strong[#text("Lucie")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2008")])]

#text("Very interesting article. Thanks a lot.")#linebreak()#text(" I agree it’s kinda cruel, playing beautiful music for anyone to listen for free, but at a moment and a place when most people have to rush and can’t enjoy it. Nice reaction from thr kids too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/#comment-29523")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2008")])]

#text("Mathematics can be a performing art. This raises the question of what would happen if a world-class mathematician (such as Terry Tao), were to perform incognito and out of context, in an inner city public high school, as a substitute teacher, during a morning class?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/25/pearls-before-breakfast-ii/#comment-32431")[#strong[#text("Undercover Busker « Sociomath")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2008")]

#text("[…] here’s the article from which this post came. Oh, and here’s the article in Terrence Tao’s blog which pointed Steve at the WP article. Oh and here’s […]")
]
