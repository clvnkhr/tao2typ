// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/07/14/call-for-long-programs-workshops-and-summer-schools-at-ipam/
// Converted to Typst by tao2typ: "2026-10-14T16:39:24.954557+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Call for long programs, workshops, and summer schools at IPAM", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Call for long programs, workshops, and summer schools at IPAM")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 July 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/07/14/call-for-long-programs-workshops-and-summer-schools-at-ipam/")[#text("https://terrytao.wordpress.com/2026/07/14/call-for-long-programs-workshops-and-summer-schools-at-ipam/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("(I am writing here in my capacity as Director of Special Projects at IPAM.)")]

#text("IPAM seeks program proposals from the mathematical, statistical, and scientific communities for long programs, workshops, and summer schools. Most program proposals are reviewed at IPAM’s Science Advisory Board meeting, held in November each year. Programs are selected on the basis of their scientific impact and contribution to IPAM’s goals. IPAM is committed to supporting a community where people of all backgrounds and points of view can engage, learn, and thrive. If you would like to discuss your program ideas and prepare a proposal for IPAM’s consideration, you are encouraged to ")#link("mailto:director@ipam.ucla.edu")[#text("contact the IPAM Director")]#text(". For more information visit: ")#link("https://www.ipam.ucla.edu/propose-a-program/long-programs-2/")[#text("https://www.ipam.ucla.edu/propose-a-program/long-programs-2/")]

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/14/call-for-long-programs-workshops-and-summer-schools-at-ipam/#comment-693420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2026")])]

#text("Professor Tao, thank you for sharing this call. I am developing an exploratory-workshop idea tentatively entitled “From Experimental Evidence to Certified Theorems: Reproducible Workflows for Open Mathematical Problems.”")

#text("The proposed meeting would use concrete open problems to connect mathematical reduction, SAT/SMT and symbolic computation, AI-assisted discovery, proof certificates, formal verification and reproducible publication standards. Its goal would be to develop practical workflows that take a problem from computational experimentation to an independently verifiable mathematical result.")

#text("I plan to send a short concept note to the IPAM Director and would be grateful for any indication as to whether this direction would complement IPAM’s current work on machine-assisted proofs and large-scale formalization.")
]
