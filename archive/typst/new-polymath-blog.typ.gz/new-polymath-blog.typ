// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/
// Converted to Typst by tao2typ: "2026-10-14T07:25:23.569456+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "New polymath blog, and comment ratings", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("New polymath blog, and comment ratings")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 July 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/")[#text("https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In view of the sustained interest in new polymath projects, Tim Gowers, Gil Kalai, Michael Nielsen, and I have ")#link("http://polymathprojects.org/")[#text("set up a new blog")]#text(" to propose, plan, and run these projects. This blog is not intended to hold a “monopoly” on the polymath enterprise, but to merely be a convenient central location for discussing and running such projects should one choose.")

#text("We have started the ball rolling on this blog with some ")#link("http://polymathprojects.org/general-polymath-rules/")[#text("proposed rules for running a polymath")]#text(", a mock-up of what a ")#link("http://polymathprojects.org/2009/07/26/hello-world/")[#text("research thread")]#text(" and a ")#link("http://polymathprojects.org/2009/07/26/mock-up-discussion-thread/")[#text("discussion thread")]#text(" for a project would look like, two new proposals for the next polymath project (")#link("http://polymathprojects.org/2009/07/27/proposal-deterministic-way-to-find-primes/")[#text("deterministic location of primes")]#text(", and a ")#link("http://polymathprojects.org/2009/07/27/proposal-boshernitzans-problem/")[#text("problem of Michael Boshernitzan")]#text("), and a thread on how one should select the next project (which we intend to do in a few months, with a tentative plan to actually start the next project at around October or so). Please come give the blog a visit, and contribute your thoughts and suggestions, though it should be noted that we are ")#strong[#text("not")]#text(" planning to start a new polymath project right away, but merely to plan for the next one for now.")

#text("[")#emph[#text("Update")]#text(", July 28: Actually, this may change. There has already been enough progress on the “deterministic location of primes” project that a ")#link("http://polymathprojects.org/2009/07/28/deterministic-way-to-find-primes-discussion-thread/")[#text("discussion thread ")]#text("and ")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_primes")[#text("wiki page")]#text(" has been created, and this polymath project may in fact formally launch much sooner than anticipated, perhaps in a matter of weeks. However, much work still needs to be done in laying the groundwork of this project, in particular developing preparatory materials in the wiki and elsewhere to allow participants to get up to speed.]")

#text("On a somewhat related note, now that we have a dedicated blog for these sorts of polymath projects, I am thinking of revisiting the ratings system for comments that I recently turned on here. I guess this would be a good question to poll the readers on:")

#metadata(none) <tao-6542d7b88a102c90eb2d>

#metadata(none) <tao-08deeed0655873d29101>

#metadata(none) <tao-be8b0bc99a441de8ae4b>

#text("Note that the ratings system is somewhat customisable: see ")#link("http://support.wordpress.com/ratings/")[#text("this wordpress page")]#text(" for details.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/#comment-40737")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2009")])]

#text("The wiki says the finding primes polymath “will be started in within a few weeks. “")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Lama")]], [#link("https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/#comment-40738")[#strong[#text("Vishal Lama")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2009")])]

#text("Just thought I would share some of my thoughts on the “rating comments” issue. I am not quite sure why all comments should be mapped to a two-valued set, or even, what such a mapping is supposed to tell us. I think there are also other potential problems with rating comments. For instance, supposing there are two “camps” – there could be more but two is a nice number – with somewhat opposing views on a topic. Then, members of one camp might wantonly “rate down” the other camps’ views/ideas and “rate up” their own. This is not to suggest that readers of your blog are not well-informed and mature, but then comments offered by them can hardly be compared to ones offered on popular news sites or similar ones. Also, there is every bit of a risk of very informative ideas/comments being rated down just because a few readers don’t understand what’s being said or presented. Just my two cents.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/#comment-40742")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2009")])]

#text("It seems that the previous polymath projects, while impressively successful, dealt with math problems that are more or less number theoretic or combinatorial. My question is : do you think that one could run polymath projects for open problems in harmonic analysis or PDE, or are these subjects not that amenable to blogosphere collaborative work?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/#comment-40875")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("Well, it’s too early to say yet what works and what doesn’t, but my guess is that one should be able to adapt the polymath paradigm to other fields of mathematics, though perhaps with more technically sophisticated fields there would have to be more of an emphasis on exposition. Note that polymath2 was in functional analysis, though admittedly it didn’t achieve critical mass. (My own thread on the Mahler conjecture from 2007, in convex geometry, could also be viewed as a sort of proto-polymath project, though again it didn’t go critical.)")

#text("It seems plausible to me, though, that to maximise the benefit of the massively collaborative format, one would prefer to pick problems that are as accessible and are as interesting to as wide an audience of qualified contributors as possible. (Note that participants do not have to already be experts in the area to be able to make meaningful contributions; in particular it seems to help if we have people on the sidelines asking the “stupid” questions, or helping out with auxiliary tasks such as improving the wiki.) And it seems that combinatorics and number theory has some relative advantage in these areas (though there are exceptions: every field has its share of not-very-interesting problems.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/#comment-40878")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("Following the comment of anonymous: isn’t it possible for a group or a couple of researchers in a particular field of mathematics to agree on trying to solve a certain open problem using the polymath paradigm rather than collaborating between themselves. The purpose would be to attract others to think of the problem or at least discuss it and share perspectives on it (though I agree that not all problems are amenable to that). This is much like polymath1 (DHJ(k)) where essentially it seems to me (unless I’m wrong) that eventually the main contributers to the project where active researchers in the field. Of course, the participation of other interested people is always enriching as you noted.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/#comment-40876")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("Based on the poll results so far, it seems that a majority of participants have voted to keep the ratings system, either permanently or on a provisional basis. I still have mixed feelings about the system (it encourages one type of participation – rating – at the expense of another type of participation – asking “dumb” questions), but I suppose I will keep the ratings for now (but will also keep the poll open, in case opinions change).")

#text("There is presumably an upper bound as to how deeply one’s feelings can hurt by a single integer, but I would still advise readers to use the “rate down” feature sparingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/28/new-polymath-blog/#comment-40877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("One idea, that I think was suggested by someone else, is to do away with the “thumbs down” and allow for only positive feedback. I’m not sure if this is technologically possible, though.")
]
