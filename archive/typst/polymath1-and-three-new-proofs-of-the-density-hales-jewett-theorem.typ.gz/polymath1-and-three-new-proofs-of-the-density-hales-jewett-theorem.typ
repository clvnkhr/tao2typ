// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:35:40.011741+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath1 and three new proofs of the density Hales-Jewett theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath1 and three new proofs of the density Hales-Jewett theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/")[#text("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week I gave a talk at UCLA on some aspects of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath1 project")]#text(", and specifically on the three new combinatorial proofs of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Density_Hales-Jewett_theorem")[#text("density Hales-Jewett theorem")]#text(" that have been obtained as a consequence of that project. (There have been a number of other achievements of this project, including some accomplished on the ")#link("https://terrytao.wordpress.com/tag/polymath1/")[#text("polymath1 threads hosted on this blog")]#text(", but I will have to postpone a presentation of those to a later post.) It seems that at least two of the proofs will extend to prove this theorem for arbitrary alphabet lengths, but for this talk I will focus on the ")#mi("{k=3}")#text(" case. The theorem to prove is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (")#mi("{k=3}")#text(" density Hales-Jewett theorem)")]#text(" ")#metadata(none) <tao-aa8375b03e4ddd696f78>#text(" Let ")#mi("{0 < \\delta \\leq 1}")#text(". Then if ")#mi("{n}")#text(" is a sufficiently large integer, any subset ")#mi("{A}")#text(" of the cube ")#mi("{[3]^n = \\{1,2,3\\}^n}")#text(" of density ")#tao-math("{\\left|A\\right|/3^n}", block: false)#text(" at least ")#mi("{\\delta}")#text(" contains at least one combinatorial line ")#mi("{\\{ \\ell(1), \\ell(2), \\ell(3)\\}}")#text(", where ")#mi("{\\ell \\in \\{1,2,3,x\\}^n \\backslash [3]^n}")#text(" is a string of ")#mi("{1}")#text("s, ")#mi("{2}")#text("s, ")#mi("{3}")#text("s, and ")#mi("{x}")#text("‘s containing at least one “wildcard” ")#mi("{x}")#text(", and ")#mi("{\\ell(i)}")#text(" is the string formed from ")#mi("{\\ell}")#text(" by replacing all ")#mi("{x}")#text("‘s with ")#mi("{i}")#text("‘s.")
]

#text("The full density Hales-Jewett theorem is the same statement, but with ")#mi("{[3]}")#text(" replaced by ")#mi("{[k]}")#text(" for some ")#mi("{k \\geq 1}")#text(". (The case ")#mi("{k=1}")#text(" is trivial, and the case ")#mi("{k=2}")#text(" follows from ")#link("http://en.wikipedia.org/wiki/Sperner%27s_theorem")[#text("Sperner’s theorem")]#text(".)")

#text("This theorem was first proven ")#link("http://www.ams.org/mathscinet-getitem?mr=1001397")[#text("by Furstenberg and Katznelson")]#text(", by first converting it to a statement in ergodic theory; the original paper of Furstenberg-Katznelson argument was for the ")#mi("{k=3}")#text(" case only, and gave only part of the proof in detail, but in ")#link("http://math.stanford.edu/ katznel/dhj12.pdf")[#text("a subsequent paper")]#text(" a full proof in general ")#mi("{k}")#text(" was provided. The remaining components of the original ")#mi("{k=3}")#text(" argument were later completed in ")#link("http://www.msci.memphis.edu/ randall/preprints/HJk3.pdf")[#text("unpublished notes of McCutcheon")]#text(". One of the new proofs is essentially a finitary translation of this ")#mi("{k=3}")#text(" argument; in principle one could also finitise the significantly more complicated argument of Furstenberg and Katznelson for general ")#mi("{k}")#text(", but this has not been properly carried out yet (the other two proofs are likely to generalise much more easily to higher ")#mi("{k}")#text("). The result is considered quite deep; for instance, the general ")#mi("{k}")#text(" case of the density Hales-Jewett theorem already implies ")#link("http://en.wikipedia.org/wiki/Szemeredi%27s_theorem")[#text("Szemerédi’s theorem")]#text(", which is a highly non-trivial theorem in its own right, as a special case.")

#text("Another of the proofs is based primarily on the density increment method that goes back to Roth, and also incorporates some ideas from a ")#link("http://www.ams.org/mathscinet-getitem?mr=369299")[#text("paper of Ajtai and Szemerédi")]#text(" establishing what we have called the “")#link("http://michaelnielsen.org/polymath1/index.php?title=Corners_theorem")[#text("corners theorem")]#text("” (and which is also implied by the ")#mi("{k=3}")#text(" case of the density Hales-Jewett theorem). A key new idea involved studying the correlations of the original set ")#mi("{A}")#text(" with special subsets of ")#mi("{[3]^n}")#text(", such as ")#mi("{ij}")#text("-insensitive sets, or intersections of ")#mi("{ij}")#text("-insensitive and ")#mi("{ik}")#text("-insensitive sets. Work is currently ongoing to extend this argument to higher ")#mi("{k}")#text(", and it seems that there are no major obstacles in doing so.")

#text("This correlations idea inspired a new ergodic proof of the density Hales-Jewett theorem for all values of ")#mi("{k}")#text(" ")#link("http://arxiv.org/abs/0903.1633")[#text("by Austin")]#text(", which is in the spirit of the triangle removal lemma (or hypergraph removal lemma) proofs of Roth’s theorem (or the multidimensional Szemerédi theorem). A finitary translation of this argument in the ")#mi("{k=3}")#text(" case has been sketched out; I believe it also extends in a relatively straightforward manner to the higher ")#mi("{k}")#text(" case (in analogy with some proofs of the hypergraph removal lemma ).")

#metadata(none) <tao-4ee559d16e0cbd431620>

#heading(level: 1)[#strong[#text(" — 1. Simpler cases of density Hales-Jewett — ")]]

#text("In order to motivate the known proofs of the density Hales-Jewett theorem, it is instructive to consider some simpler theorems which are implied by this theorem. The first is the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Corners_theorem")[#text("corners theorem")]#text(" of Ajtai and Szemerédi:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Corners theorem)")]#text(" ")#metadata(none) <tao-9b2479a856f23c4e9a92>#text(" Let ")#mi("{0 < \\delta \\leq 1}")#text(". Then if ")#mi("{n}")#text(" is a sufficiently large integer, any subset ")#mi("{A}")#text(" of the square ")#mi("{[n]^2}")#text(" of density ")#tao-math("{\\left|A\\right|/n^2}", block: false)#text(" at least ")#mi("{\\delta}")#text(" contains at least one right-angled triangle (or “corner”) ")#mi("{\\{ (x,y), (x+r,y), (x,y+r) \\}}")#text(" with ")#mi("{r \\neq 0}")#text(".")
]

#text("The ")#mi("{k=3}")#text(" density Hales-Jewett theorem implies the corners theorem; this is proven by utilising the map ")#mi("{\\phi: [3]^n \\rightarrow [n]^2}")#text(" from the cube to the square, defined by mapping a string ")#mi("{x \\in [3]^n}")#text(" to a pair ")#mi("{(a,b)}")#text(", where ")#mi("{a, b}")#text(" are the number of ")#mi("{1}")#text("s and ")#mi("{2}")#text("s respectively in ")#mi("{x}")#text(". The key point is that ")#mi("{\\phi}")#text(" maps combinatorial lines to corners. (Strictly speaking, this mapping only establishes the corners theorem for dense subsets of ")#mi("{[n/3 - \\sqrt{n}, n/3 + \\sqrt{n}]^2}")#text(", but it is not difficult to obtain the general case from this by replacing ")#mi("{n}")#text(" by ")#mi("{n^2}")#text(" and using translation-invariance.)")

#text("(The corners theorem is also closely related to the problem of finding dense sets of points in a triangular grid without any equilateral triangles, a problem which we have called ")#link("http://michaelnielsen.org/polymath1/index.php?title=Fujimura%27s_problem")[#text("Fujimura’s problem")]#text(".")

#text("The corners theorem in turn implies")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Roth’s theorem)")]#text(" ")#metadata(none) <tao-a5822a8c8b00deb97c29>#text(" Let ")#mi("{0 < \\delta \\leq 1}")#text(". Then if ")#mi("{n}")#text(" is a sufficiently large integer, any subset ")#mi("{A}")#text(" of the interval ")#mi("{[n]}")#text(" of density ")#tao-math("{\\left|A\\right|/n}", block: false)#text(" at least ")#mi("{\\delta}")#text(" contains at least one arithmetic progression ")#mi("{a, a+r, a+2r}")#text(" of length three.")
]

#text("Roth’s theorem can be deduced from the corners theorem by considering the map ")#mi("{\\psi: [n]^2 \\rightarrow [3n]}")#text(" defined by ")#mi("{\\psi(a,b) := a+2b}")#text("; the key point is that ")#mi("{\\psi}")#text(" maps corners to arithmetic progressions of length three.")

#text("There are higher ")#mi("{k}")#text(" analogues of these implications; the general ")#mi("{k}")#text(" version of the density Hales-Jewett theorem implies a general ")#mi("{k}")#text(" version of the corners theorem known as the multidimensional Szemerédi theorem, which in term implies a general version of Roth’s theorem known as ")#link("http://en.wikipedia.org/wiki/Szemeredi%27s_theorem")[#text("Szemerédi’s theorem")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. The density increment argument — ")]]

#text("The strategy of the density increment argument, which goes back to Roth’s proof of Theorem ")#link(<tao-a5822a8c8b00deb97c29>)[#text("3")]#text(" in 1956, is to perform a downward induction on the density ")#mi("{\\delta}")#text(". Indeed, the theorem is obvious for high enough values of ")#mi("{\\delta}")#text("; for instance, if ")#mi("{\\delta > 2/3}")#text(", then partitioning the cube ")#mi("{[3]^n}")#text(" into lines and applying the pigeonhole principle will already give a combinatorial line. So the idea is to deduce the claim for a fixed density ")#mi("{\\delta}")#text(" from that of a higher density ")#mi("{\\delta}")#text(".")

#text("A key concept here is that of an ")#mi("{m}")#text("-dimensional ")#emph[#text("combinatorial subspace")]#text(" of ")#mi("{[3]^n}")#text(" – a set of the form ")#mi("{\\phi([3]^m)}")#text(", where ")#mi("{\\phi \\in \\{1,2,3,*_1,\\ldots,*_m\\}^n}")#text(" is a string formed using the base alphabet and ")#mi("{m}")#text(" wildcards ")#mi("{*_1,\\ldots,*_m}")#text(" (with each wildcard appearing at least opnce), and ")#mi("{\\phi(a_1 \\ldots a_m)}")#text(" is the string formed by substituting ")#mi("{a_i}")#text(" for ")#mi("{*_i}")#text(" for each ")#mi("{i}")#text(". (Thus, for instance, a combinatorial line is a combinatorial subspace of dimension ")#mi("{1}")#text(".) The identification ")#mi("{\\phi}")#text(" between ")#mi("{[3]^m}")#text(" and the combinatorial space ")#mi("{\\phi([3]^m)}")#text(" maps combinatorial lines to combinatorial lines. Thus, to prove Theorem ")#link(<tao-aa8375b03e4ddd696f78>)[#text("1")]#text(", it suffices to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Lack of lines implies density increment)")]#text(" ")#metadata(none) <tao-e3f315ea36abca8f80be>#text(" Let ")#mi("{0 < \\delta \\leq 1}")#text(". Then if ")#mi("{n}")#text(" is a sufficiently large integer, and ")#mi("{A \\subset [3]^n}")#text(" has density at least ")#mi("{\\delta}")#text(" and has no combinatorial lines, then there exists an ")#mi("{m}")#text("-dimensional subspace ")#mi("{\\phi([3]^m)}")#text(" of ")#mi("{[3]^n}")#text(" on which ")#mi("{A}")#text(" has density at least ")#mi("{\\delta + c(\\delta)}")#text(", where ")#mi("{c(\\delta) > 0}")#text(" depends only on ")#mi("{\\delta}")#text(" (and is bounded away from zero on any compact range of ")#mi("{\\delta}")#text("), and ")#mi("{m \\geq m_0(n,\\delta)}")#text(" for some function ")#mi("{m_0(n,\\delta)}")#text(" that goes to infinity as ")#mi("{n \\rightarrow \\infty}")#text(" for fixed ")#mi("{\\delta}")#text(".")
]

#text("It is easy to see that Proposition ")#link(<tao-e3f315ea36abca8f80be>)[#text("4")]#text(" implies Theorem ")#link(<tao-aa8375b03e4ddd696f78>)[#text("1")]#text(" (for instance, one could consider the infimum of all ")#mi("{\\delta}")#text(" for which the theorem holds, and show that having this infimum non-zero would lead to a contradiction).")

#text("Now we have to figure out how to get that density increment. The original argument of Roth relied on Fourier analysis, which in turn relies on an underlying translation-invariant structure which is not present in the density Hales-Jewett setting. (Arithmetic progressions are translation-invariant, but combinatorial lines are not.) It turns out that one can proceed instead by adapting a (")#link("http://michaelnielsen.org/polymath1/index.php?title=Modification_of_the_Ajtai-Szemer%C3%A9di_argument")[#text("modification of")]#text(") ")#link("http://michaelnielsen.org/polymath1/index.php?title=Ajtai-Szemer%C3%A9di%27s_proof_of_the_corners_theorem")[#text("an argument of Ajtai and Szemerédi")]#text(", which gave the first proof of Theorem ")#link(<tao-9b2479a856f23c4e9a92>)[#text("2")]#text(".")

#text("The (modified) Ajtai-Szemerédi argument uses the density increment method, assuming that ")#mi("{A}")#text(" has no right-angled triangles and showing that ")#mi("{A}")#text(" has an increased density on a ")#emph[#text("subgrid")]#text(" – a product ")#mi("{P \\times Q}")#text(" of fairly long arithmetic progressions with the same spacing. The argument proceeds in two stages, which we describe slightly informally (in particular, glossing over some technical details regarding quantitative parameters such as ")#mi("{\\varepsilon}")#text(") as follows:")

#list(
[#text("Step 1. If ")#mi("{A \\subset [n]^2}")#text(" is dense but has no right-angled triangles, then ")#mi("{A}")#text(" has an increased density on a cartesian product ")#mi("{U \\times V}")#text(" of dense sets ")#mi("{U, V \\subset [n]}")#text(" (which are not necessarily arithmetic progressions).")],
[#text("Step 2. Any Cartesian product ")#mi("{U \\times V}")#text(" in ")#mi("{[n]^2}")#text(" can be partitioned into reasonably large grids ")#mi("{P \\times Q}")#text(", plus a remainder term of small density.")]
)

#text("From Step 1, Step 2 and the pigeonhole principle we obtain the desired density increment of ")#mi("{A}")#text(" on a grid ")#mi("{P \\times Q}")#text(", and then the density increment argument gives us the corners theorem.")

#text("Step 1 is actually quite easy. If ")#mi("{A}")#text(" is dense, then it must also be dense on some diagonal ")#mi("{D = \\{ (x,y): x+y = const \\}}")#text(", by the pigeonhole principle. Let ")#mi("{U}")#text(" and ")#mi("{V}")#text(" denote the rows and columns that ")#mi("{A \\cap D}")#text(" occupies. Every pair of points in ")#mi("{A \\cap D}")#text(" forms the hypotenuse of some corner, whose third vertex lies in ")#mi("{U \\times V}")#text(". Thus, if ")#mi("{A}")#text(" has no corners, then ")#mi("{A}")#text(" must avoid all the points formed by ")#mi("{U \\times V}")#text(" (except for those of the diagonal ")#mi("{D}")#text("). Thus ")#mi("{A}")#text(" has a significant density ")#emph[#text("decrease")]#text(" on the Cartesian product ")#mi("{U \\times V}")#text(". Dividing the remainder ")#mi("{[n]^2 \\backslash (U \\times V)}")#text(" into three further Cartesian products ")#mi("{U \\times ([n]\\backslash V)}")#text(", ")#mi("{([n] \\backslash U) \\times V}")#text(", ")#mi("{([n] \\backslash U) \\times ([n] \\backslash V)}")#text(" and using the pigeonhole principle we obtain the claim (after redefining ")#mi("{U, V}")#text(" appropriately).")

#text("Step 2 can be obtained by iterating a one-dimensional version:")

#list(
[#text("Step 2a. Any set ")#mi("{U \\subset [n]}")#text(" can be partitioned into reasonably long arithmetic progressions ")#mi("{P}")#text(", plus a remainder term of small density.")]
)

#text("Indeed, from Step 2a, one can partition ")#mi("{U \\times [n]}")#text(" into products ")#mi("{P \\times [n]}")#text(" (plus a small remainder), which can be easily repartitioned into grids ")#mi("{P \\times Q}")#text(" (plus small remainder). This partitions ")#mi("{U \\times V}")#text(" into sets ")#mi("{P \\times (V \\cap Q)}")#text(" (plus small remainder). Applying Step 2a again, each ")#mi("{V \\cap Q}")#text(" can be partitioned further into progressions ")#mi("{Q^{\\prime}}")#text(" (plus small remainder), which allows us to partition each ")#mi("{P \\times (V \\cap Q)}")#text(" into grids ")#mi("{P^{\\prime} \\times Q^{\\prime}}")#text(" (plus small remainder).")

#text("So all one has left to do is establish Step 2a. But this can be done by the greedy algorithm: locate one long arithmetic progression ")#mi("{P}")#text(" in ")#mi("{U}")#text(" and remove it from ")#mi("{U}")#text(", then locate another to remove, and so forth until no further long progressions remain in the set. But ")#link("http://en.wikipedia.org/wiki/Szemeredi%27s_theorem")[#text("Szemerédi’s theorem")]#text(" then tells us the remaining set has low density, and one is done!")

#text("This argument has the apparent disadvantage of requiring a deep theorem (Szemerédi’s theorem) in order to complete the proof. However, interestingly enough, when one adapts the argument to the density Hales-Jewett theorem, one gets to replace Szemerédi’s theorem by a more elementary result – one which in fact follows from the (easy) ")#mi("{k=2}")#text(" version of the density Hales-Jewett theorem, i.e. ")#link("http://en.wikipedia.org/wiki/Sperner%27s_theorem")[#text("Sperner’s theorem")]#text(".")

#text("We first need to understand the analogue of the Cartesian products ")#mi("{U \\times V}")#text(". Note that ")#mi("{U \\times V}")#text(" is the intersection of a “vertically insensitive set” ")#mi("{U \\times [n]}")#text(" and a “horizontally insensitive set” ")#mi("{[n] \\times V}")#text(". By “vertically insensitive” we mean that membership of a point ")#mi("{(x,y)}")#text(" in that set is unaffected if one moves that point in a vertical direction, and similarly for “horizontally insensitive”. In a similar fashion, define a “")#mi("{12}")#text("-insensitive set” to be a subset of ")#mi("{[3]^n}")#text(", membership in which is unaffected if one flips a coordinate from a ")#mi("{1}")#text(" to a ")#mi("{2}")#text(" or vice versa (e.g. if ")#mi("{1223}")#text(" lies in the set, then so must ")#mi("{1213}")#text(", ")#mi("{1113}")#text(", ")#mi("{2113}")#text(", etc.). Similarly define the notion of a “")#mi("{13}")#text("-insensitive set”. We then define a “complexity ")#mi("{1}")#text(" set” to be the intersection ")#mi("{E_{12} \\cap E_{13}}")#text(" of a ")#mi("{12}")#text("-insensitive set ")#mi("{E_{12}}")#text(" and a ")#mi("{13}")#text("-insensitive set ")#mi("{E_{13}}")#text("; these are analogous to the Cartesian products ")#mi("{U \\times V}")#text(".")

#text("(For technical reasons, one actually has to deal with ")#emph[#text("local")]#text(" versions of insensitive sets and complexity ")#mi("{1}")#text(" sets, in which one is only allowed to flip a moderately small number of the ")#mi("{n}")#text(" coordinates rather than all of them. But to simplify the discussion let me ignore this (important) detail, which is also a major issue to address in the other two proofs of this theorem.)")

#text("The analogues of Steps 1, 2 for the density Hales-Jewett theorem are then")

#list(
[#text("Step 1. If ")#mi("{A \\subset [3]^n}")#text(" is dense but has no combinatorial lines, then ")#mi("{A}")#text(" has an increased density on a (local) complexity ")#mi("{1}")#text(" set ")#mi("{E_{12} \\cap E_{13}}")#text(".")],
[#text("Step 2. Any (local) complexity ")#mi("{1}")#text(" set ")#mi("{E_{12} \\cap E_{13} \\subset [3]^n}")#text(" can be partitioned into moderately large combinatorial subspaces (plus a small remainder).")]
)

#text("We can sketch how Step 1 works as follows. Given any ")#mi("{x \\in [3]^n}")#text(", let ")#mi("{\\pi_{1 \\rightarrow 2}(x)}")#text(" denote the string formed by replacing all ")#mi("{1}")#text("s with ")#mi("{2}")#text("s, e.g. ")#mi("{\\pi_{1 \\rightarrow 2}(1321) = 2322}")#text(". Similarly define ")#mi("{\\pi_{1 \\rightarrow 3}(x)}")#text(". Observe that ")#mi("{x, \\pi_{1 \\rightarrow 2}(x), \\pi_{1 \\rightarrow 3}(x)}")#text(" forms a combinatorial line (except in the rare case when ")#mi("{x}")#text(" doesn’t contain any ")#mi("{1}")#text("s). Thus if we let ")#mi("{E_{12} := \\{ x: \\pi_{1 \\rightarrow 2}(x) \\in A\\}}")#text(", ")#mi("{E_{13} := \\{ x: \\pi_{1 \\rightarrow 3}(x) \\in A\\}}")#text(", we see that ")#mi("{A}")#text(" must avoid essentially all of ")#mi("{E_{12} \\cap E_{13}}")#text(". On the other hand, observe that ")#mi("{E_{12}}")#text(" and ")#mi("{E_{13}}")#text(" are ")#mi("{12}")#text("-insensitive and ")#mi("{13}")#text("-insensitive sets respectively. Taking complements and using the same sort of pigeonhole argument as before, we obtain the claim. (Actually, this argument doesn’t quite work because ")#mi("{E_{12}}")#text(", ")#mi("{E_{13}}")#text(" could be very sparse; this problem can be fixed, but requires one to use local complexity ")#mi("{1}")#text(" sets rather than global ones, and also to introduce the concept of “equal-slices measure”; I will not discuss these issues here.)")

#text("Step 2 can be reduced, much as before, to the following analogue of Step 2a:")

#list(
[#text("Step 2a. Any ")#mi("{12}")#text("-insensitive set ")#mi("{E_{12} \\subset [3]^n}")#text(" can be partitioned into moderately large combinatorial subspaces (plus a small remainder).")]
)

#text("Identifying the letters ")#mi("{1}")#text(" and ")#mi("{2}")#text(" together, one can quotient ")#mi("{[3]^n}")#text(" down to ")#mi("{[2]^n}")#text("; the preimages of this projection are precisely the ")#mi("{12}")#text("-insensitive sets. Because of this, Step 2a is basically equivalent (modulo some technicalities about measure) to")

#list(
[#text("Step 2a’. Any ")#mi("{E \\subset [2]^n}")#text(" can be partitioned into moderately large combinatorial subspaces (plus a small remainder).")]
)

#text("By the greedy algorithm, we will be able to accomplish this step if we can show that every dense subset of ")#mi("{[2]^n}")#text(" contains moderately large subspaces. But this turns out to be possible by carefully iterating Sperner’s theorem (which shows that every dense subset of ")#mi("{[2]^n}")#text(" contains combinatorial lines).")

#text("This proof of Theorem ")#link(<tao-aa8375b03e4ddd696f78>)[#text("1")]#text(" seems to extend without major difficulty to the case of higher ")#mi("{k}")#text(", though details are still being worked out.")

#heading(level: 1)[#strong[#text(" — 3. The triangle removal argument — ")]]

#text("The ")#link("http://michaelnielsen.org/polymath1/index.php?title=Triangle_removal_lemma")[#text("triangle removal lemma")]#text(" of Ruzsa and Szemerédi is a graph-theoretic result which implies the corners theorem (and hence Roth’s theorem). It asserts the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Triangle removal lemma)")]#text(" For every ")#mi("{\\varepsilon > 0}")#text(" there exists ")#mi("{\\delta > 0}")#text(" such that if a graph ")#mi("{G}")#text(" on ")#mi("{n}")#text(" vertices has fewer than ")#mi("{\\delta n^3}")#text(" triangles, then the triangles can be deleted entirely by removing at most ")#mi("{\\varepsilon n^2}")#text(" edges.")
]

#text("Let’s see how the triangle removal lemma implies the corners theorem. A corner is, of course, already a triangle in the geometric sense, but we need to convert it to a triangle in the graph-theoretic sense, as follows. Let ")#mi("{A}")#text(" be a subset of ")#mi("{[n]^2}")#text(" with no corners; the aim is to show that ")#mi("{A}")#text(" has small density. Let ")#mi("{V_h}")#text(" be the set of all horizontal lines in ")#mi("{[n]^2}")#text(", ")#mi("{V_v}")#text(" the set of vertical lines, and ")#mi("{V_d}")#text(" the set of diagonal lines (thus all three sets have size about ")#mi("{n}")#text("). We create a tripartite graph ")#mi("{G}")#text(" on the vertex sets ")#mi("{V_h \\cup V_v \\cup V_d}")#text(" by joining a horizontal line ")#mi("{h \\in V_h}")#text(" to a vertical line ")#mi("{v \\in V_v}")#text(" whenever ")#mi("{h}")#text(" and ")#mi("{v}")#text(" intersect at a point in ")#mi("{A}")#text(", and similarly connecting ")#mi("{V_h}")#text(" or ")#mi("{V_v}")#text(" to ")#mi("{V_d}")#text(". Observe that a triangle in ")#mi("{G}")#text(" corresponds either to a corner in ")#mi("{A}")#text(", or to a “degenerate” corner in which the horizontal, vertical, and diagonal line are all concurrent. In particular, there are very few triangle in ")#mi("{G}")#text(", which can then be deleted by removing a small number of edges from ")#mi("{G}")#text(" by the triangle removal lemma. But each edge removed can delete at most one degenerate corner, and the number of degenerate corners is ")#tao-math("{\\left|A\\right|}", block: false)#text(", and so ")#tao-math("{\\left|A\\right|}", block: false)#text(" is small as required.")

#text("All known proofs of the triangle removal lemma proceed by some version of the following three steps:")

#list(
[#text("“Regularity lemma step”: Applying tools such as the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(", one can partition the graph ")#mi("{G}")#text(" into components ")#mi("{G_{ij}}")#text(" between cells ")#mi("{V_i, V_j}")#text(" of vertices, such that most of the ")#mi("{G_{ij}}")#text(" are “pseudorandom”. One way to define what pseudorandom means is to view each graph component ")#mi("{G_{ij}}")#text(" as a subset of the Cartesian product ")#mi("{V_i \\times V_j}")#text(", in which case ")#mi("{G_{ij}}")#text(" is pseudorandom if it does not have a significant density increment on any smaller Cartesian product ")#mi("{V^{\\prime}_i \\times V^{\\prime}_j}")#text(" of non-trivial size.")],
[#text("”Counting lemma step”: By exploiting the pseudorandomness property, one shows that if ")#mi("{G}")#text(" has a triple ")#mi("{G_{ij}, G_{jk}, G_{ki}}")#text(" of dense pseudorandom graphs between cells ")#mi("{V_i, V_j, V_k}")#text(" of non-trivial size, then this triple must generate a large number of triangles; hence, if ")#mi("{G}")#text(" has very few triangles, then one cannot find such a triple of dense pseudorandom graphs.")],
[#text("”Cleaning step”: If one then removes all components of ")#mi("{G}")#text(" which are too sparse or insufficiently pseudorandom, one can thus eliminate all triangles.")]
)

#text("Pulling this argument back to the corners theorem, we see that cells such as ")#mi("{V_i, V_j, V_k}")#text(" will correspond either to horizontally insensitive sets, vertically insensitive sets, or diagonally insensitive sets. Thus this proof of the corners theorem proceeds by partitioning ")#mi("{[n]^2}")#text(" in three different ways into insensitive sets in such a way that ")#mi("{A}")#text(" is pseudorandom with respect to many of the cells created by any two of these partitions, counting the corners generated by any triple of large cells in which A is pseudorandom and dense, and cleaning out all the other cells.")

#text("It turns out that a variant of this argument can give Theorem ")#link(<tao-aa8375b03e4ddd696f78>)[#text("1")]#text("; this was in fact the original approach studied by the polymath1 project, though it was only after a detour through ergodic theory (as well as the development of the density-increment argument discussed above) that the triangle-removal approach could be properly executed. In particular, an ergodic argument based on the infinitary analogue of the triangle removal lemma (and its hypergraph generalisations) was developed ")#link("http://arxiv.org/abs/0903.1633")[#text("by Austin")]#text(", which then inspired the combinatorial version sketched here.")

#text("The analogue of the vertex cells ")#mi("{V_i}")#text(" are given by certain ")#mi("{12}")#text("-insensitive sets ")#mi("{E_{12}^a}")#text(", ")#mi("{13}")#text("-insensitive sets ")#mi("{E_{13}^b}")#text(", and ")#mi("{23}")#text("-insensitive sets ")#mi("{E_{23}^c}")#text(". Roughly speaking, a set ")#mi("{A \\subset [3]^n}")#text(" would be said to be pseudorandom with respect to a cell ")#mi("{E_{12}^a \\cap E_{13}^b}")#text(" if ")#mi("{A \\cap E_{12}^a \\cap E_{13}^b}")#text(" has no further density increment on any smaller cell ")#mi("{E^{\\prime}_{12} \\cap E^{\\prime}_{13}}")#text(" with ")#mi("{E^{\\prime}_{12}}")#text(" a ")#mi("{12}")#text("-insensitive subset of ")#mi("{E_{12}^a}")#text(", and ")#mi("{E^{\\prime}_{13}}")#text(" a ")#mi("{13}")#text("-insensitive subset of ")#mi("{E_{13}^b}")#text(". (This is an oversimplification, glossing over an important refinement of the concept of pseudorandomness involving the discrepancy between global densities in ")#mi("{[3]^n}")#text(" and local densities in subspaces of ")#mi("{[3]^n}")#text(".) There is a similar notion of ")#mi("{A}")#text(" being pseudorandom with respect to a cell ")#mi("{E_{13}^b \\cap E_{23}^c}")#text(" or ")#mi("{E_{23}^c \\cap E_{12}^a}")#text(".")

#text("We briefly describe the “regularity lemma” step. By modifying the proof of the regularity lemma, one can obtain three partitions")

#align(center)[#tao-fit-display[#mitex("[3]^n = E_{12}^1 \\cup \\ldots \\cup E_{12}^{M_{12}} = E_{13}^1 \\cup \\ldots \\cup E_{13}^{M_{13}} = E_{23}^1 \\cup \\ldots \\cup E_{23}^{M_{23}}")]]

#text("into ")#mi("{12}")#text("-insensitive, ")#mi("{13}")#text("-insensitive, and ")#mi("{23}")#text("-insensitive components respectively, where ")#mi("{M_{12}, M_{13}, M_{23}}")#text(" are not too large, and ")#mi("{A}")#text(" is pseudorandom with respect to most cells ")#mi("{E_{12}^a \\cap E_{13}^b}")#text(", ")#mi("{E_{13}^b \\cap E_{23}^c}")#text(", and ")#mi("{E_{23}^c \\cap E_{12}^a}")#text(".")

#text("In order for the counting step to work, one also needs an additional “stationarity” reduction, which is difficult to state precisely, but roughly speaking asserts that the “local” statistics of sets such as ")#mi("{E_{12}^a}")#text(" on medium-dimensional subspaces are close to the corresponding “global” statistics of such sets; this can be achieved by an additional pigeonholing argument. We will gloss over this issue, pretending that there is no distinction between local statistics and global statistics. (Thus, for instance, if ")#mi("{E_{12}^a}")#text(" has large global density in ")#mi("{[3]^n}")#text(", we shall assume that ")#mi("{E_{12}^a}")#text(" also has large density on most medium-sized subspaces of ")#mi("{[3]^n}")#text(".)")

#text("Now for the “counting lemma” step. Suppose we can find ")#mi("{a,b,c}")#text(" such that the cells ")#mi("{E_{12}^a, E_{13}^b, E_{23}^c}")#text(" are large, and that ")#mi("{A}")#text(" intersects ")#mi("{E_{12}^a \\cap E_{13}^b}")#text(", ")#mi("{E_{13}^b \\cap E_{23}^c}")#text(", and ")#mi("{E_{23}^c \\cap E_{12}^a}")#text(" in a dense pseudorandom manner. We claim that this will force ")#mi("{A}")#text(" to have a large number of combinatorial lines ")#mi("{\\ell}")#text(", with ")#mi("{\\ell(1)}")#text(" in ")#mi("{A \\cap E_{12}^a \\cap E_{13}^b}")#text(", ")#mi("{\\ell(2)}")#text(" in ")#mi("{A \\cap E_{23}^c \\cap E_{12}^a}")#text(", and ")#mi("{\\ell(3)}")#text(" in ")#mi("{A \\cap E_{13}^b \\cap E_{23}^c}")#text(". Because of the dense pseudorandom nature of ")#mi("{A}")#text(" in these cells, it turns out that it will suffice to show that there are a lot of lines ")#mi("{\\ell(1)}")#text(" with ")#mi("{\\ell(1) \\in E_{12}^a \\cap E_{13}^b}")#text(", ")#mi("{\\ell(2) \\in E_{23}^c \\cap E_{12}^a}")#text(", and ")#mi("{\\ell(3) \\in E_{13}^b \\cap E_{23}^c}")#text(".")

#text("One way to generate a line ")#mi("{\\ell}")#text(" is by taking the triple ")#mi("{\\{ x, \\pi_{1 \\rightarrow 2}(x), \\pi_{1 \\rightarrow 3}(x) \\}}")#text(", where ")#mi("{x \\in [3]^n}")#text(" is a generic point. (Actually, as we will see below, we would have to to a subspace of ")#mi("{[3]^n}")#text(" before using this recipe to generate lines.) Then we need to find many ")#mi("{x}")#text(" obeying the constraints")

#align(center)[#tao-fit-display[#mitex("x \\in E_{12}^a \\cap E_{13}^b; \\quad \\pi_{1 \\rightarrow 2}(x) \\in E_{23}^c \\cap E_{12}^a; \\quad \\pi_{1 \\rightarrow 3}(x) \\in E_{13}^b \\cap E_{23}^c.")]]

#text("Because of the various insensitivity properties, many of these conditions are redundant, and we can simplify to")

#align(center)[#tao-fit-display[#mitex("x \\in E_{12}^a \\cap E_{13}^b; \\quad \\pi_{1 \\rightarrow 2}(x) \\in E_{23}^c.")]]

#text("Now note that the property “")#mi("{\\pi_{1 \\rightarrow 2}(x) \\in E_{23}^c}")#text("” is 123-insensitive; it is simultaneously 12-insensitive, 23-insensitive, and 13-insensitive. As ")#mi("{E_{23}^c}")#text(" is assumed to be large, there will be large combinatorial subspaces on which (a suitably localised version of) this property “")#mi("{\\pi_{1 \\rightarrow 2}(x) \\in E_{23}^c}")#text("” will be always true. Localising to this space (taking advantage of the stationarity properties alluded to earlier), we are now looking for solutions to")

#align(center)[#tao-fit-display[#mitex("x \\in E_{12}^a \\cap E_{13}^b.")]]

#text("We’ll pick ")#mi("{x}")#text(" to be of the form ")#mi("{\\pi_{2 \\rightarrow 1}(y)}")#text(" for some ")#mi("{y}")#text(". We can then rewrite the constraints on ")#mi("{y}")#text(" as")

#align(center)[#tao-fit-display[#mitex("y \\in E_{12}^a; \\quad \\pi_{2 \\rightarrow 1}(y) \\in E_{13}^b.")]]

#text("The property “")#mi("{\\pi_{2 \\rightarrow 1}(y) \\in E_{13}^b}")#text("” is 123-invariant, and ")#mi("{E_{13}^b}")#text(" is large, so by arguing as before we can pass to a large subspace where this property is always true. The largeness of ")#mi("{E_{12}^a}")#text(" then gives us a large number of solutions.")

#text("Taking contrapositives, we conclude that if ")#mi("{A}")#text(" in fact has no combinatorial lines, then there do not exist any triple ")#mi("{E_{12}^a, E_{13}^b, E_{23}^c}")#text(" of large cells with respect to which ")#mi("{A}")#text(" is dense and pseudorandom. This forces ")#mi("{A}")#text(" to be confined either to very small cells, or to very sparse subsets of cells, or to the rare cells which fail to be pseudorandom. None of these cases can contribute much to the density of ")#mi("{A}")#text(", and so ")#mi("{A}")#text(" itself is very sparse – contradicting the hypothesis in Theorem ")#link(<tao-aa8375b03e4ddd696f78>)[#text("1")]#text(" that ")#mi("{A}")#text(" is dense (this is the “cleaning step”). This concludes the sketch of the triangle-removal proof of this theorem.")

#text("The ergodic version of this argument, ")#link("http://arxiv.org/abs/0903.1633")[#text("due to Austin")]#text(", works for all values of ")#mi("{k}")#text(", so I expect the combinatorial version to do so as well.")

#heading(level: 1)[#strong[#text(" — 4. The finitary Furstenberg-Katznelson argument — ")]]

#text("In 1989, ")#link("http://www.ams.org/mathscinet-getitem?mr=1001397")[#text("Furstenberg and Katznelson")]#text(" gave the first proof of Theorem ")#link(<tao-aa8375b03e4ddd696f78>)[#text("1")]#text(", by translating it into a recurrence statement about a certain type of stationary process indexed by an infinite cube ")#mi("{[3]^\\omega := \\bigcup_{n=1}^\\infty [3]^n}")#text(". This argument was inspired by a long string of other successful proofs of density Ramsey theorems via ergodic means, starting with the initial 1977 ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("paper of Furstenberg")]#text(" giving an ergodic theory proof of Szemeredi’s theorem. The latter proof was transcribed into a finitary language ")#link("http://www.ams.org/mathscinet-getitem?mr=2274314")[#text("by myself")]#text(", so it was reasonable to expect that the Furstenberg-Katznelson argument could similarly be translated into a combinatorial framework.")

#text("Let us first briefly describe the original strategy of Furstenberg to establish Roth’s theorem, but phrased in an informal, and vaguely combinatorial, language. The basic task is to get a non-trivial lower bound on averages of the form ")#metadata(none) <tao-f284bdc3c1c9e24a494e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\Bbb E}_{a,r} f(a) f(a+r) f(a+2r)")]]

#text("where we will be a bit vague about what ")#mi("{a,r}")#text(" are ranging over, and where ")#mi("{f}")#text(" is some non-negative function of positive mean. It is then natural to study more general averages of the form ")#metadata(none) <tao-36e0fd847d927d68475f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\Bbb E}_{a,r} f(a) g(a+r) h(a+2r).")]]

#text("Now, it turns out that certain types of functions ")#mi("{f,g,h}")#text(" give a negligible contribution to expressions such as ")#link(<tao-36e0fd847d927d68475f>)[#text("(2)")]#text(". In particular, if ")#mi("{f}")#text(" is ")#emph[#text("weakly mixing")]#text(", which roughly means that the pair correlations")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_a f(a) f(a+r)")]]

#text("are small for most ")#mi("{r}")#text(", then the average ")#link(<tao-36e0fd847d927d68475f>)[#text("(2)")]#text(" is small no matter what ")#mi("{g, h}")#text(" are (so long as they are bounded). This can be established by some applications of the Cauchy-Schwarz inequality (or its close cousin, the ")#emph[#text("van der Corput lemma")]#text("). As a consequence of this, all weakly mixing components of ")#mi("{f}")#text(" can essentially be discarded when considering an average such as ")#link(<tao-f284bdc3c1c9e24a494e>)[#text("(1)")]#text(".")

#text("After getting rid of the weakly mixing components, what is left? Being weakly mixing is like saying that almost all the shifts ")#mi("{f(\\cdot+r)}")#text(" of ")#mi("{f}")#text(" are close to orthogonal to each other. At the other extreme is that of ")#emph[#text("periodicity")]#text(" – the shifts ")#mi("{f(\\cdot + r)}")#text(" periodically recur to become equal to ")#mi("{f}")#text(" again. There is a slightly more general notion of ")#emph[#text("almost periodicity")]#text(" – roughly, this means that the shifts ")#mi("{f(\\cdot + r)}")#text(" don’t have to recur exactly to ")#mi("{f}")#text(" again, but they are forced to range in a precompact set, which basically means that for every ")#mi("{\\varepsilon > 0}")#text(", that ")#mi("{f(\\cdot+r)}")#text(" lies within ")#mi("{\\varepsilon}")#text(" (in some suitable norm) of some finite-dimensional space. A good example of an almost periodic function is an ")#emph[#text("eigenfunction")]#text(", in which we have ")#mi("{f(a+r) = \\lambda_r f(a)}")#text(" for each ")#mi("{r}")#text(" and some quantity ")#mi("{\\lambda_r}")#text(" independent of ")#mi("{a}")#text(" (e.g. one can take ")#mi("{f(a) = e^{2\\pi i \\alpha a}}")#text(" for some ")#mi("{\\alpha \\in {\\mathbb R}}")#text("). In this case, the finite-dimensional space is simply the scalar multiples of ")#mi("{f(a)}")#text(" (and one can even take ")#mi("{\\varepsilon=0}")#text(" in this special case).")

#text("It is easy to see that non-trivial almost periodic functions are not weakly mixing; more generally, any function which correlates non-trivially with an almost periodic function can also be seen to not be weakly mixing. In the converse direction, it is also fairly easy to show that any function which is not weakly mixing must have non-trivial correlation with an almost periodic function. Because of this, it turns out that one can basically decompose ")#emph[#text("any")]#text(" function into almost periodic and weakly mixing components. For the purposes of getting lower bounds on ")#link(<tao-f284bdc3c1c9e24a494e>)[#text("(1)")]#text(", this allows us to essentially reduce matters to the special case when ")#mi("{f}")#text(" is almost periodic. But then the shifts ")#mi("{f(\\cdot + r)}")#text(" are almost ranging in a finite-dimensional set, which allows one to essentially assign each shift ")#mi("{r}")#text(" a colour from a finite range of colours. If one then applies the ")#link("http://en.wikipedia.org/wiki/Van_der_Waerden%27s_theorem")[#text("van der Waerden theorem")]#text(", one can find many arithmetic progressions ")#mi("{a,a+r,a+2r}")#text(" which have the same colour, and this can be used to give a non-trivial lower bound on ")#link(<tao-f284bdc3c1c9e24a494e>)[#text("(1)")]#text(". (Thus we see that the role of a compactness property such as almost periodicity is to reduce density Ramsey theorems to colouring Ramsey theorems.)")

#text("This type of argument can be extended to more advanced recurrence theorems, but certain things become more complicated. For instance, suppose one wanted to count progressions of length ")#mi("{4}")#text("; this amounts to lower bounding expressions such as ")#metadata(none) <tao-f29a448b780745bf2e10>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\Bbb E}_{a,r} f(a) f(a+r) f(a+2r) f(a+3r).")]]

#text("It turns out that ")#mi("{f}")#text(" being weakly mixing is no longer enough to give a negligible contribution to expressions such as ")#link(<tao-f29a448b780745bf2e10>)[#text("(3)")]#text(". For that, one needs the stronger property of being ")#emph[#text("weakly mixing relative to almost periodic functions")]#text("; roughly speaking, this means that for most ")#mi("{r}")#text(", the expression ")#mi("{f(\\cdot) f(\\cdot+r)}")#text(" is not merely of small mean (which is what weak mixing would mean), but that this expression furthermore does not correlate strongly with any almost periodic function (i.e. ")#mi("{{\\Bbb E}_a f(a) f(a+r) g(a)}")#text(" is small for any almost periodic ")#mi("{g}")#text("). Once one has this stronger weak mixing property, then one can discard all components of ")#mi("{f}")#text(" which are weakly mixing relative to almost periodic functions.")

#text("One then has to figure out what is left after all these components are discarded. Because we strengthened the notion of weak mixing, we have to weaken the notion of almost periodicity to compensate. The correct notion is no longer that of almost periodicity – in which the shifts ")#mi("{f(\\cdot + r)}")#text(" almost take values in a finite-dimensional vector space – but that of almost periodicity ")#emph[#text("relative")]#text(" to almost periodic functions, in which the shifts almost take values in a finite-dimensional ")#emph[#text("module")]#text(" over the algebra of almost periodic functions. A good example of such a beast is that of a ")#emph[#text("quadratic eigenfunction")]#text(", in which we have ")#mi("{f(a+r) = \\lambda_r(a) f(a)}")#text(" where ")#mi("{\\lambda_r(a)}")#text(" is itself an ordinary eigenfunction, and thus almost periodic in the ordinary sense; here, the relative module is the one-dimensional module formed by almost periodic multiples of ")#mi("{f}")#text(". (A typical example of a quadratic eigenfunction is ")#mi("{f(a) = e^{2\\pi i \\alpha a^2}}")#text(" for some ")#mi("{\\alpha \\in {\\mathbb R}}")#text(".)")

#text("It turns out that one can “relativise” all of the previous arguments to the almost periodic “factor”, and decompose an arbitrary ")#mi("{f}")#text(" into a component which is weakly mixing relative to almost periodic functions, and another component which is almost periodic relative to almost periodic functions. The former type of components can be discarded. For the latter, we can once again start colouring the shifts ")#mi("{f(\\cdot+r)}")#text(" with a finite number of colours, but with the caveat that the colour assigned is no longer independent of ")#mi("{a}")#text(", but depends in an almost periodic fashion on ")#mi("{a}")#text(". Nevertheless, it is still possible to combine the van der Waerden colouring Ramsey theorem with the theory of recurrence for ordinary almost periodic functions to get a lower bound on ")#link(<tao-f29a448b780745bf2e10>)[#text("(3)")]#text(" in this case. One can then iterate this argument to deal with arithmetic progressions of longer length, but one now needs to consider even more intricate notions of almost periodicity, e.g. almost periodicity relative to (almost periodic functions relative to almost periodic functions), etc.")

#text("It turns out that these types of ideas can be adapted (with some effort) to the density Hales-Jewett setting. It’s simplest to begin with the ")#mi("{k=2}")#text(" situation rather than the ")#mi("{k=3}")#text(" situation. Here, we are trying to obtain non-trivial lower bounds for averages of the form ")#metadata(none) <tao-593f2d04aab251f60c9e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("{\\Bbb E}_{\\ell} f(\\ell(1)) f(\\ell(2))")]]

#text("where ")#mi("{\\ell}")#text(" ranges in some fashion over combinatorial lines in ")#mi("{[2]^n}")#text(", and ")#mi("{f}")#text(" is some non-negative function with large mean.")

#text("The analogues of weakly mixing and almost periodic in this setting are the ")#mi("{12}")#text("-uniform and ")#mi("{12}")#text("-low influence functions respectively. Roughly speaking, a function is ")#mi("{12}")#text("-low influence if its value usually doesn’t change much if a ")#mi("{1}")#text(" is flipped to a ")#mi("{2}")#text(" or vice versa (e.g. the indicator function of a ")#mi("{12}")#text("-insensitive set is ")#mi("{12}")#text("-low influence); conversely, a ")#mi("{12}")#text("-uniform function is a function ")#mi("{g}")#text(" such that ")#mi("{{\\Bbb E}_{\\ell} f(\\ell(1)) g(\\ell(2))}")#text(" is small for all (bounded) ")#mi("{f}")#text(". One can show that any function can be decomposed, more or less orthogonally, into a ")#mi("{12}")#text("-uniform function and a ")#mi("{12}")#text("-low influence function, with the upshot being that one can basically reduce the task of lower bounding ")#link(<tao-593f2d04aab251f60c9e>)[#text("(4)")]#text(" to the case when ")#mi("{f}")#text(" is ")#mi("{12}")#text("-low influence. But then ")#mi("{f(\\ell(1))}")#text(" and ")#mi("{f(\\ell(2))}")#text(" are approximately equal to each other, and it is straightforward to get a lower-bound in this case.")

#text("Now we turn to the ")#mi("{k=3}")#text(" setting, where we are looking at lower-bounding expressions such as ")#metadata(none) <tao-12c243f2ea0b6bc32902>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\Bbb E}_{\\ell} f(\\ell(1)) g(\\ell(2)) h(\\ell(3))")]]

#text("with ")#mi("{f=g=h}")#text(".")

#text("It turns out that ")#mi("{g}")#text(" (say) being ")#mi("{12}")#text("-uniform is no longer enough to give a negligible contribution to the average ")#link(<tao-12c243f2ea0b6bc32902>)[#text("(5)")]#text(". Instead, one needs the more complicated notion of ")#mi("{g}")#text(" being ")#mi("{12}")#text("-uniform relative to ")#mi("{23}")#text("-low influence functions; this means that not only are the averages ")#mi("{{\\Bbb E}_{\\ell} f(\\ell(1)) g(\\ell(2))}")#text(" small for all bounded ")#mi("{f}")#text(", but furthermore ")#mi("{{\\Bbb E}_{\\ell} f(\\ell(1)) g(\\ell(2)) h(\\ell)}")#text(" is small for all bounded ")#mi("{f}")#text(" and all ")#mi("{23}")#text("-low influence ")#mi("{h}")#text(" (there is a minor technical point here that ")#mi("{h}")#text(" is a function of a line rather than of a point, but this should be ignored). Any component of ")#mi("{g}")#text(" in ")#link(<tao-12c243f2ea0b6bc32902>)[#text("(5)")]#text(" which is ")#mi("{12}")#text("-uniform relative to ")#mi("{23}")#text("-low influence functions are negligible and so can be removed.")

#text("One then needs to figure out what is left in ")#mi("{g}")#text(" when these components are removed. The answer turns out to be functions ")#mi("{g}")#text(" that are ")#mi("{12}")#text("-almost periodic relative to ")#mi("{23}")#text("-low influence. The precise definition of this concept is technical, but very roughly speaking it means that if one flips a digit from a ")#mi("{1}")#text(" to a ")#mi("{2}")#text(", then the value of ")#mi("{g}")#text(" changes in a manner which is controlled by ")#mi("{23}")#text("-low influence functions. Anyway, the upshot is that one can reduce ")#mi("{g}")#text(" in ")#link(<tao-12c243f2ea0b6bc32902>)[#text("(5)")]#text(" from ")#mi("{f}")#text(" to the components of ")#mi("{f}")#text(" which are ")#mi("{12}")#text("-almost periodic relative to ")#mi("{23}")#text("-low influence. Similarly, one can reduce ")#mi("{h}")#text(" in ")#link(<tao-12c243f2ea0b6bc32902>)[#text("(5)")]#text(" from ")#mi("{f}")#text(" to the components of ")#mi("{f}")#text(" which are ")#mi("{13}")#text("-almost periodic relative to ")#mi("{23}")#text("-low influence.")

#text("At this point, one has to use a colouring Ramsey theorem – in this case, the Graham-Rothschild theorem – in conjunction with the relative almost periodicity to locate lots of places in which ")#mi("{g(\\ell(2))}")#text(" is close to ")#mi("{g(\\ell(1))}")#text(" while ")#mi("{h(\\ell(3))}")#text(" is simultaneously close to ")#mi("{h(\\ell(1))}")#text(". This turns ")#link(<tao-12c243f2ea0b6bc32902>)[#text("(5)")]#text(" into an expression of the form ")#mi("{{\\Bbb E}_x f(x) g(x) h(x)}")#text(", which turns out to be relatively easy to lower bound (because ")#mi("{g, h}")#text(", being projections of ")#mi("{f}")#text(", tend to be large wherever ")#mi("{f}")#text(" is large).")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-37795")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("The statement of Proposition 4 is messed up. Thanks for the summary! ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-37805")[#strong[#text("Polymath1: Success! « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")]

#text("[…] Success!” It is now becoming clear that there are three new emerging proofs of DHJ. (See this post by Terry Tao. As this update was also based on briefly talking with Terry, Terry’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-37809")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("“It is easy to see that Proposition 4 implies Theorem 1 (for instance, one could consider the infimum of all ")#mi("{\\delta}")#text(" for which the theorem holds, and show that having this infimum non-zero would lead to a contradiction). ”")

#text("I’m probably missing something, but I can’t see how this leads to a contradiction. What if the infimum is 1/2 and ")#mi("c(\\delta)=\\frac{1/2-\\delta}{2}")#text(", when ")#mi("\\delta")#text(" is less than ")#mi("1/2")#text(", and ")#mi("c(\\delta)=1/2")#text(" otherwise? Or is c assumed to be continuous?")

#text("One more question: Does ")#mi("m_0(n)")#text(" depend on ")#mi("\\delta")#text("? (Still in proposition 4)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-37819")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("Dear Sune,")

#text("Yes, one needs some assumption that ")#mi("c(\\delta)")#text(" has some uniform bound away from zero for ")#mi("\\delta")#text(" in a compact set (which is of course automatic if c is continuous), and yes, ")#mi("m_0(n)")#text(" is allowed to depend on ")#mi("\\delta")#text(". I’ve adjusted the text accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-37822")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("In connection with the two previous posts.")

#text("I think it is rather common in applications of the density increment strategy that ")#mi("c(\\delta)")#text(" is an increasing function; say, in the standard capset problem argument, we have ")#mi("c(\\delta)=\\delta^2")#text(" (up to lower order terms). It is not difficult to show that if ")#mi("C")#text(" is a positive constant, ")#mi("\\delta_0 > 0")#text(", and ")#mi("\\delta_{n+1}\\ge\\delta_n+C\\delta_n^2")#text(", then for a non-negative integer ")#mi("n")#text(" with ")#mi("n\\ge\\frac1{C\\delta_0}+\\ln\\frac1{\\delta_0}")#text(" we have ")#mi("\\delta_n\\ge 1")#text(". (This is nearly best possible: if ")#mi("n> \\frac1{C\\delta_0}-\\frac1C")#text(", then ")#mi("\\delta_n< 1")#text(".)")

#text("It might be a nice little project to prove a sharp result of this sort under an assumption like ")#mi("\\delta_{n+1}\\ge\\delta_n+C\\delta_n^{1+\\kappa}")#text(", with fixed ")#mi("C,\\kappa > 0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-37826")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("Terry, your link to “unpublished notes of McCutcheon” seems to have been mangled by WordPress: it should be")

#link("http://www.msci.memphis.edu/~randall/preprints/HJk3.pdf")[#text("Click to access HJk3.pdf")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-37838")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("Dear Terry,")

#text("there also seems to be something wrong with the link to the ‘subsequent paper’ by Furstenberg and Katznelson. The correct link should be ")#link("http://math.stanford.edu/~katznel/dhj12.pdf")[#text("http://math.stanford.edu/~katznel/dhj12.pdf")]

#emph[#text("[Ah, my conversion software is having some trouble with tildes, apparently. Fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-37906")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2009")])]

#text("A minor typo to correct: in “")#mi("A")#text(" must avoid essentially all of ")#mi("E_{12}\\times E_{13}")#text("“, the cross product should be replaced with the intersection. Also, it is not clear to me exactly how “taking complements … we obtain the claim”: we may obtain, say, that ")#mi("A")#text(" has a density increment on ")#mi("E_{12}\\cap{\\overline E}_{13}")#text(", but ")#mi("{\\overline E}_{13}")#text(" is not an insensitive set?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-37918")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2009")])]

#text("Thanks for the correction! As for your question, it turns out that the complement of (say) a 13-insensitive set is automatically a 13-insensitive set also (much as the complement of a vertically insensitive set is vertically insensitive).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-38079")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2009")])]

#text("Another minor typo of the same kind in “products of ")#mi("ij")#text("-insensitive and ")#mi("ik")#text("-insensitive”.")

#text("Another point not quite clear to me concerns with deducing corners from DHJ(3). Given a subset of ")#mi("[n]^2")#text(", we associate with it a subset of ")#mi("[3]^n")#text(", and seek a combinatorial line in this latter subset. The problem is, the fact that the original subset of ")#mi("[n]^2")#text(" is dense does not seem to guarantee that the resulting subset of ")#mi("[3]^n")#text(" is dense; consider, for instance, the subset ")#mi("[n/4]\\times[n/4]")#text(". Is this, indeed, a problem to address, or am I missing something?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-38080")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2009")])]

#text("Thanks for the correction! It’s true that the mapping I mentioned only establishes the corners theorem directly for dense subsets of ")#mi("[n/3 - \\sqrt{n}, n/3 + \\sqrt{n}]^2")#text(" rather than ")#mi("[n]^2")#text(" (using Stirling’s formula), but then one can recover the general case by replacing n by n^2 and using translation invariance.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-38431")[#strong[#text("Un blog concentra a cientos de matemáticos en la demostración conjunta de un teorema « Francis (th)E mule Science’s News")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")]

#text("[…] al genial Terence Tao, quien nos relata el resultado del proyecto Polymath1 en su blog, “Polymath1 and three new proofs of the density Hales-Jewett theorem.” La idea del proyecto era obtener una nueva demostración del teorema de la densidad de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-41614")[#strong[#text("Preview: Doing Science on the Web, or What I Want to Fix with CoLab | The Stark Effect")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2009")]

#text("[…] people can write up the results formally in a wiki. The projects have been surprisingly active and successful and it’s very similar to how I see CoLab […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A new proof of the density Hales-Jewett theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-41965")[#strong[#text("A new proof of the density Hales-Jewett theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("[…] The argument is based on the density increment argument as pioneered by Roth, and also used in later papers of Ajtai-Szemerédi and Shkredov on the corners problem, which was also influential in our current work (though, perhaps paradoxically, the generality of our setting makes our argument simpler than the above arguments, in particular allowing one to avoid use of the Fourier transform, regularity lemma, or Szemerédi’s theorem). I discuss the argument in the first part of this previous blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-43229")[#strong[#text("Massively Collaborative Mathematics: lessons from polymath1 « Hypios – Thinking")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2010")]

#text("[…] most influential post in history?) and 1000 comments later, the whole thing was over. There were at least three new proofs for DHJ. To take into account the most fruitful comments and threads, spread over Tao and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/02/polymath1-and-three-new-proofs-of-the-density-hales-jewett-theorem/#comment-43785")[#strong[#text("Five for Friday: Biggest Breakthroughs in Open Science « Hypios – Thinking")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2010")]

#text("[…] most influential post in history?) and 1000 comments later, the whole thing was over. There were at least three new proofs for DHJ. To take into account the most fruitful comments and threads, spread over Tao and […]")
]
