// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/
// Converted to Typst by tao2typ: "2026-10-14T15:20:37.905801+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The inclusion-exclusion principle for commuting projections", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The inclusion-exclusion principle for commuting projections")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 February 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/")[#text("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The (classical) ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu: {\\bf N} \\rightarrow {\\bf Z}}")#text(" is the unique function that obeys the classical ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_inversion_formula")[#text("Möbius inversion formula")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Classical Möbius inversion)")]#text(" ")#metadata(none) <tao-02bd1a9d63bfc967219f>#text(" Let ")#mi("{f,g: {\\bf N} \\rightarrow A}")#text(" be functions from the natural numbers to an additive group ")#mi("{A}")#text(". Then the following two claims are equivalent:")

#list(
[#text("(i) ")#mi("{f(n) = \\sum_{d|n} g(d)}")#text(" for all ")#mi("{n \\in {\\bf N}}")#text(".")],
[#text("(ii) ")#mi("{g(n) = \\sum_{d|n} \\mu(n/d) f(d)}")#text(" for all ")#mi("{n \\in {\\bf N}}")#text(".")]
)
]

#text("There is a generalisation of this formula to (finite) posets, due to Hall, in which one sums over chains ")#mi("{n_0 > \\dots > n_k}")#text(" in the poset:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Poset Möbius inversion)")]#text(" ")#metadata(none) <tao-61310766ad8b45a0271d>#text(" Let ")#mi("{{\\mathcal N}}")#text(" be a finite poset, and let ")#mi("{f,g: {\\mathcal N} \\rightarrow A}")#text(" be functions from that poset to an additive group ")#mi("{A}")#text(". Then the following two claims are equivalent:")

#list(
[#text("(i) ")#mi("{f(n) = \\sum_{d \\leq n} g(d)}")#text(" for all ")#mi("{n \\in {\\mathcal N}}")#text(", where ")#mi("{d}")#text(" is understood to range in ")#mi("{{\\mathcal N}}")#text(".")],
[#text("(ii) ")#mi("{g(n) = \\sum_{k=0}^\\infty (-1)^k \\sum_{n = n_0 > n_1 > \\dots > n_k} f(n_k)}")#text(" for all ")#mi("{n \\in {\\mathcal N}}")#text(", where in the inner sum ")#mi("{n_0,\\dots,n_k}")#text(" are understood to range in ")#mi("{{\\mathcal N}}")#text(" with the indicated ordering.")]
)

#text("(Note from the finite nature of ")#mi("{{\\mathcal N}}")#text(" that the inner sum in (ii) is vacuous for all but finitely many ")#mi("{k}")#text(".)")
]

#text("Comparing Proposition ")#link(<tao-61310766ad8b45a0271d>)[#text("2")]#text(" with Proposition ")#link(<tao-02bd1a9d63bfc967219f>)[#text("1")]#text(", it is natural to refer to the function ")#mi("{\\mu(d,n) := \\sum_{k=0}^\\infty (-1)^k \\sum_{n = n_0 > n_1 > \\dots > n_k = d} 1}")#text(" as the ")#link("https://en.wikipedia.org/wiki/Incidence_algebra#Special_elements")[#text("Möbius function of the poset")]#text("; the condition (ii) can then be written as")

#align(center)[#tao-fit-display[#mitex("g(n) = \\sum_{d \\leq n} \\mu(d,n) f(d).")]]

#emph[#text("Proof:")]#text(" If (i) holds, then we have")

#metadata(none) <tao-1b2e7a1306b0563dfab3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("g(n) = f(n) - \\sum_{d<n} g(d)")]]

#text("for any ")#mi("{n \\in {\\mathcal N}}")#text(". Iterating this we obtain (ii). Conversely, from (ii) and separating out the ")#mi("{k=0}")#text(" term, and grouping all the other terms based on the value of ")#mi("{d:=n_1}")#text(", we obtain ")#link(<tao-1b2e7a1306b0563dfab3>)[#text("(1)")]#text(", and hence (i). ")#mi("\\Box")

#text("In fact it is not completely necessary that the poset ")#mi("{{\\mathcal N}}")#text(" be finite; an inspection of the proof shows that it suffices that every element ")#mi("{n}")#text(" of the poset has only finitely many predecessors ")#mi("{\\{ d \\in {\\mathcal N}: d < n \\}}")#text(".")

#text("It is not difficult to see that Proposition ")#link(<tao-61310766ad8b45a0271d>)[#text("2")]#text(" includes Proposition ")#link(<tao-02bd1a9d63bfc967219f>)[#text("1")]#text(" as a special case, after verifying the combinatorial fact that the quantity")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=0}^\\infty (-1)^k \\sum_{d=n_k | n_{k-1} | \\dots | n_1 | n_0 = n} 1")]]

#text("is equal to ")#mi("{\\mu(n/d)}")#text(" when ")#mi("{d}")#text(" divides ")#mi("{n}")#text(", and vanishes otherwise.")

#text("I recently discovered that Proposition ")#link(<tao-61310766ad8b45a0271d>)[#text("2")]#text(" can also lead to a useful variant of the ")#link("https://en.wikipedia.org/wiki/Inclusion%E2%80%93exclusion_principle")[#text("inclusion-exclusion principle")]#text(". The classical version of this principle can be phrased in terms of indicator functions: if ")#mi("{A_1,\\dots,A_\\ell}")#text(" are subsets of some set ")#mi("{X}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^\\ell (1-1_{A_j}) = \\sum_{k=0}^\\ell (-1)^k \\sum_{1 \\leq j_1 < \\dots < j_k \\leq \\ell} 1_{A_{j_1} \\cap \\dots \\cap A_{j_k}}.")]]

#text("In particular, if there is a finite measure ")#mi("{\\nu}")#text(" on ")#mi("{X}")#text(" for which ")#mi("{A_1,\\dots,A_\\ell}")#text(" are all measurable, we have")

#align(center)[#tao-fit-display[#mitex("\\nu(X \\backslash \\bigcup_{j=1}^\\ell A_j) = \\sum_{k=0}^\\ell (-1)^k \\sum_{1 \\leq j_1 < \\dots < j_k \\leq \\ell} \\nu( A_{j_1} \\cap \\dots \\cap A_{j_k} ).")]]

#text("One drawback of this formula is that there are exponentially many terms on the right-hand side: ")#mi("{2^\\ell}")#text(" of them, in fact. However, in many cases of interest there are “collisions” between the intersections ")#mi("{A_{j_1} \\cap \\dots \\cap A_{j_k}}")#text(" (for instance, perhaps many of the pairwise intersections ")#mi("{A_i \\cap A_j}")#text(" agree), in which case there is an opportunity to collect terms and hopefully achieve some cancellation. It turns out that it is possible to use Proposition ")#link(<tao-61310766ad8b45a0271d>)[#text("2")]#text(" to do this, in which one only needs to sum over chains in the resulting poset of intersections:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Hall-type inclusion-exclusion principle)")]#text(" ")#metadata(none) <tao-dd805812f2fd7ff1476c>#text(" Let ")#mi("{A_1,\\dots,A_\\ell}")#text(" be subsets of some set ")#mi("{X}")#text(", and let ")#mi("{{\\mathcal N}}")#text(" be the finite poset formed by intersections of some of the ")#mi("{A_i}")#text(" (with the convention that ")#mi("{X}")#text(" is the empty intersection), ordered by set inclusion. Then for any ")#mi("{E \\in {\\mathcal N}}")#text(", one has")

#metadata(none) <tao-27fbe6c3e52243152dac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("1_E \\prod_{F \\subsetneq E} (1 - 1_F) = \\sum_{k=0}^\\ell (-1)^k \\sum_{E = E_0 \\supsetneq E_1 \\supsetneq \\dots \\supsetneq E_k} 1_{E_k}")]]

#text("where ")#mi("{F, E_0,\\dots,E_k}")#text(" are understood to range in ")#mi("{{\\mathcal N}}")#text(". In particular (setting ")#mi("{E}")#text(" to be the empty intersection) if the ")#mi("{A_j}")#text(" are all proper subsets of ")#mi("{X}")#text(" then we have")

#metadata(none) <tao-8e00dbaf556664d6702a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\prod_{j=1}^\\ell (1-1_{A_j}) = \\sum_{k=0}^\\ell (-1)^k \\sum_{X = E_0 \\supsetneq E_1 \\supsetneq \\dots \\supsetneq E_k} 1_{E_k}.")]]

#text("In particular, if there is a finite measure ")#mi("{\\nu}")#text(" on ")#mi("{X}")#text(" for which ")#mi("{A_1,\\dots,A_\\ell}")#text(" are all measurable, we have")

#align(center)[#tao-fit-display[#mitex("\\mu(X \\backslash \\bigcup_{j=1}^\\ell A_j) = \\sum_{k=0}^\\ell (-1)^k \\sum_{X = E_0 \\supsetneq E_1 \\supsetneq \\dots \\supsetneq E_k} \\mu(E_k).")]]
]

#text("Using the Möbius function ")#mi("{\\mu}")#text(" on the poset ")#mi("{{\\mathcal N}}")#text(", one can write these formulae as")

#tao-aligned(keep: true)[


#tao-math("1_E \\prod_{F \\subsetneq E} (1 - 1_F)  & = \\sum_{F \\subseteq E} \\mu(F,E) 1_F,", block: true)



#tao-math("\\prod_{j=1}^\\ell (1-1_{A_j})  & = \\sum_F \\mu(F,X) 1_F", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\nu(X \\backslash \\bigcup_{j=1}^\\ell A_j) = \\sum_F \\mu(F,X) \\nu(F).")]]

#emph[#text("Proof:")]#text(" It suffices to establish ")#link(<tao-27fbe6c3e52243152dac>)[#text("(2)")]#text(" (to derive ")#link(<tao-8e00dbaf556664d6702a>)[#text("(3)")]#text(" from ")#link(<tao-27fbe6c3e52243152dac>)[#text("(2)")]#text(" observe that all the ")#mi("{F \\subsetneq X}")#text(" are contained in one of the ")#mi("{A_j}")#text(", so the effect of ")#mi("{1-1_F}")#text(" may be absorbed into ")#mi("{1 - 1_{A_j}}")#text("). Applying Proposition ")#link(<tao-61310766ad8b45a0271d>)[#text("2")]#text(", this is equivalent to the assertion that")

#align(center)[#tao-fit-display[#mitex("1_E = \\sum_{F \\subseteq E} 1_F \\prod_{G \\subsetneq F} (1 - 1_G)")]]

#text("for all ")#mi("{E \\in {\\mathcal N}}")#text(". But this amounts to the assertion that for each ")#mi("{x \\in E}")#text(", there is precisely one ")#mi("{F \\subseteq E}")#text(" in ")#mi("{{\\mathcal n}}")#text(" with the property that ")#mi("{x \\in F}")#text(" and ")#mi("{x \\not \\in G}")#text(" for any ")#mi("{G \\subsetneq F}")#text(" in ")#mi("{{\\mathcal N}}")#text(", namely one can take ")#mi("{F}")#text(" to be the intersection of all ")#mi("{G \\subseteq E}")#text(" in ")#mi("{{\\mathcal N}}")#text(" such that ")#mi("{G}")#text(" contains ")#mi("{x}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" If ")#mi("{A_1,A_2,A_3 \\subsetneq X}")#text(" with ")#mi("{A_1 \\cap A_2 = A_1 \\cap A_3 = A_2 \\cap A_3 = A_*}")#text(", and ")#mi("{A_1,A_2,A_3,A_*}")#text(" are all distinct, then we have for any finite measure ")#mi("{\\nu}")#text(" on ")#mi("{X}")#text(" that makes ")#mi("{A_1,A_2,A_3}")#text(" measurable that")

#metadata(none) <tao-91e0c0ac729c11015162>

#tao-aligned(keep: true)[


#tao-math("\\nu(X \\backslash (A_1 \\cup A_2 \\cup A_3))  & = \\nu(X) - \\nu(A_1) - \\nu(A_2)", block: true, numbering: n => [#text("(4)")])



#tao-math(" & - \\nu(A_3) - \\nu(A_*) + 3 \\nu(A_*)", block: true)
]

#text("due to the four chains ")#mi("{X \\supsetneq A_1}")#text(", ")#mi("{X \\supsetneq A_2}")#text(", ")#mi("{X \\supsetneq A_3}")#text(", ")#mi("{X \\supsetneq A_*}")#text(" of length one, and the three chains ")#mi("{X \\supsetneq A_1 \\supsetneq A_*}")#text(", ")#mi("{X \\supsetneq A_2 \\supsetneq A_*}")#text(", ")#mi("{X \\supsetneq A_3 \\supsetneq A_*}")#text(" of length two. Note that this expansion just has six terms in it, as opposed to the ")#mi("{2^3=8}")#text(" given by the usual inclusion-exclusion formula, though of course one can reduce the number of terms by combining the ")#mi("{\\nu(A_*)}")#text(" factors. This may not seem particularly impressive, especially if one views the term ")#mi("{3 \\mu(A_*)}")#text(" as really being three terms instead of one, but if we add a fourth set ")#mi("{A_4 \\subsetneq X}")#text(" with ")#mi("{A_i \\cap A_j = A_*}")#text(" for all ")#mi("{1 \\leq i < j \\leq 4}")#text(", the formula now becomes")

#metadata(none) <tao-e51f268d744540288e5d>

#tao-aligned(keep: true)[


#tao-math("\\nu(X \\backslash (A_1 \\cup A_2 \\cup A_3 \\cap A_4))  & = \\nu(X) - \\nu(A_1) - \\nu(A_2)", block: true, numbering: n => [#text("(5)")])



#tao-math(" & - \\nu(A_3) - \\nu(A_4) - \\nu(A_*) + 4 \\nu(A_*)", block: true)
]

#text("and we begin to see more cancellation as we now have just seven terms (or ten if we count ")#mi("{4 \\nu(A_*)}")#text(" as four terms) instead of ")#mi("{2^4 = 16}")#text(" terms.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5 (Variant of Legendre sieve)")]#text(" If ")#mi("{q_1,\\dots,q_\\ell > 1}")#text(" are natural numbers, and ")#mi("{a_1,a_2,\\dots}")#text(" is some sequence of complex numbers with only finitely many terms non-zero, then by applying the above proposition to the sets ")#mi("{A_j := q_j {\\bf N}}")#text(" and with ")#mi("{\\nu}")#text(" equal to counting measure weighted by the ")#mi("{a_n}")#text(" we obtain a variant of the ")#link("https://en.wikipedia.org/wiki/Legendre_sieve")[#text("Legendre sieve")]

#align(center)[#tao-fit-display[#tao-math("\\sum_{n: (n,q_1 \\dots q_\\ell) = 1} a_n = \\sum_{k=0}^\\ell (-1)^k \\sum_{1 \\left|^{\\prime} d_1 \\right|^{\\prime} \\dots |^{\\prime} d_k} \\sum_{n: d_k |n} a_n", block: true)]]

#text("where ")#mi("{d_1,\\dots,d_k}")#text(" range over the set ")#mi("{{\\mathcal N}}")#text(" formed by taking least common multiples of the ")#mi("{q_j}")#text(" (with the understanding that the empty least common multiple is ")#mi("{1}")#text("), and ")#mi("{d |^{\\prime} n}")#text(" denotes the assertion that ")#mi("{d}")#text(" divides ")#mi("{n}")#text(" but is strictly less than ")#mi("{n}")#text(". I am curious to know of this version of the Legendre sieve already appears in the literature (and similarly for the other applications of Proposition ")#link(<tao-61310766ad8b45a0271d>)[#text("2")]#text(" given here).")
]

#text("If the poset ")#mi("{{\\mathcal N}}")#text(" has bounded depth then the number of terms in Proposition ")#link(<tao-dd805812f2fd7ff1476c>)[#text("3")]#text(" can end up being just polynomially large in ")#mi("{\\ell}")#text(" rather than exponentially large. Indeed, if all chains ")#mi("{X \\supsetneq E_1 \\supsetneq \\dots \\supsetneq E_k}")#text(" in ")#mi("{{\\mathcal N}}")#text(" have length ")#mi("{k}")#text(" at most ")#mi("{k_0}")#text(" then the number of terms here is at most ")#mi("{1 + \\ell + \\dots + \\ell^{k_0}}")#text(". (The examples ")#link(<tao-91e0c0ac729c11015162>)[#text("(4)")]#text(", ")#link(<tao-e51f268d744540288e5d>)[#text("(5)")]#text(" are ones in which the depth is equal to two.) I hope to report in a later post on how this version of inclusion-exclusion with polynomially many terms can be useful in an application.")

#text("Actually in our application we need an abstraction of the above formula, in which the indicator functions are replaced by more abstract ")#link("https://en.wikipedia.org/wiki/Idempotence")[#text("idempotents")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Hall-type inclusion-exclusion principle for idempotents)")]#text(" Let ")#mi("{A_1,\\dots,A_\\ell}")#text(" be pairwise commuting elements of some ring ")#mi("{R}")#text(" with identity, which are all idempotent (thus ")#mi("{A_j A_j = A_j}")#text(" for ")#mi("{j=1,\\dots,\\ell}")#text("). Let ")#mi("{{\\mathcal N}}")#text(" be the finite poset formed by products of the ")#mi("{A_i}")#text(" (with the convention that ")#mi("{1}")#text(" is the empty product), ordered by declaring ")#mi("{E \\leq F}")#text(" when ")#mi("{EF = E}")#text(" (note that all the elements of ")#mi("{{\\mathcal N}}")#text(" are idempotent so this is a partial ordering). Then for any ")#mi("{E \\in {\\mathcal N}}")#text(", one has")

#metadata(none) <tao-ffcf5e9fc96ae60550be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("E \\prod_{F < E} (1-F) = \\sum_{k=0}^\\ell (-1)^k \\sum_{E = E_0 > E_1 > \\dots > E_k} E_k.")]]

#text("where ")#mi("{F, E_0,\\dots,E_k}")#text(" are understood to range in ")#mi("{{\\mathcal N}}")#text(". In particular (setting ")#mi("{E=1}")#text(") if all the ")#mi("{A_j}")#text(" are not equal to ")#mi("{1}")#text(" then we have")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^\\ell (1-A_j) = \\sum_{k=0}^\\ell (-1)^k \\sum_{1 = E_0 > E_1 > \\dots > E_k} E_k.")]]
]

#text("Morally speaking this proposition is equivalent to the previous one after applying a “spectral theorem” to simultaneously diagonalise all of the ")#mi("{A_j}")#text(", but it is quicker to just adapt the previous proof to establish this proposition directly. Using the Möbius function ")#mi("{\\mu}")#text(" for ")#mi("{{\\mathcal N}}")#text(", we can rewrite these formulae as")

#align(center)[#tao-fit-display[#mitex("E \\prod_{F < E} (1-F) = \\sum_{F \\leq E} \\mu(F,E) 1_F")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^\\ell (1-A_j) = \\sum_F \\mu(F,1) 1_F.")]]

#emph[#text("Proof:")]#text(" Again it suffices to verify ")#link(<tao-ffcf5e9fc96ae60550be>)[#text("(6)")]#text(". Using Proposition ")#link(<tao-61310766ad8b45a0271d>)[#text("2")]#text(" as before, it suffices to show that ")#metadata(none) <tao-51eb3baa5efe4c9c6985>#mi("\\displaystyle  E = \\sum_{F \\leq E} F \\prod_{G < F} (1 - G) \\ \\ \\ \\ \\ (7)")#text(" ")#text(" for all ")#mi("{E \\in {\\mathcal N}}")#text(" (all sums and products are understood to range in ")#mi("{{\\mathcal N}}")#text("). We can expand ")#metadata(none) <tao-5312fb609f60384731fc>#mi("\\displaystyle  E = E \\prod_{G < E} (G + (1-G)) = \\sum_{{\\mathcal A}} (\\prod_{G \\in {\\mathcal A}} G) (\\prod_{G < E: G \\not \\in {\\mathcal A}} (1-G)) \\ \\ \\ \\ \\ (8)")#text(" ")#text(" where ")#mi("{{\\mathcal A}}")#text(" ranges over all subsets of ")#mi("{\\{ G \\in {\\mathcal N}: G \\leq E \\}}")#text(" that contain ")#mi("{E}")#text(". For such an ")#mi("{{\\mathcal A}}")#text(", if we write ")#mi("{F := \\prod_{G \\in {\\mathcal A}} G}")#text(", then ")#mi("{F}")#text(" is the greatest lower bound of ")#mi("{{\\mathcal A}}")#text(", and we observe that ")#mi("{F (\\prod_{G < E: G \\not \\in {\\mathcal A}} (1-G))}")#text(" vanishes whenever ")#mi("{{\\mathcal A}}")#text(" fails to contain some ")#mi("{G \\in {\\mathcal N}}")#text(" with ")#mi("{F \\leq G \\leq E}")#text(". Thus the only ")#mi("{{\\mathcal A}}")#text(" that give non-zero contributions to ")#link(<tao-5312fb609f60384731fc>)[#text("(8)")]#text(" are the intervals of the form ")#mi("{\\{ G \\in {\\mathcal N}: F \\leq G \\leq E\\}}")#text(" for some ")#mi("{F \\leq E}")#text(" (which then forms the greatest lower bound for that interval), and the claim ")#link(<tao-51eb3baa5efe4c9c6985>)[#text("(7)")]#text(" follows (after noting that ")#mi("{F (1-G) = F (1-FG)}")#text(" for any ")#mi("{F,G \\in {\\mathcal N}}")#text("). ")#mi("\\Box")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24ce7b918c408fc1eac2a5821637aafd2910c6f0260891e16d85629df2990684-94230018f9873799d3163115132f4aa9f08440e4cf6f1ea20f385dbc8a4f138d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/#comment-622712")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2021")])]

#text("Your propositions feel very similar to “Rota’s crosscut theorem.” See for instance Section 3.9 of Stanley’s EC1, available at ")#link("http://www-math.mit.edu/~rstan/ec/ec1/")[#text("http://www-math.mit.edu/~rstan/ec/ec1/")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/#comment-622809")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2021")])]

#text("I had a similar feeling at first glance. But proposition 6 is actually not exactly the same as the crosscut theorem; it deals with a different treatment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/#comment-622725")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2021")])]

#text("My favorite statement about Möbius inversion is the computation of the Möbius function for a simplicial complex (i.e. the coefficients needed when trying to write the function 1 as a linear combination of the characteristic functions of the closed simplices). It says: the coefficient of a face is 1 – the Euler characteristic of the link of that face.")

#text("When the simplicial complex is a (shellable) ball, the links of interior faces are spheres, giving the coefficient (-1)^codimension. Whereas the links of exterior faces are hemispheres, giving the coefficient 0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/#comment-622730")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2021")])]

#text("Is it true that since only finitary operations (e.g. finite sums) are involved, all proofs of such results can be based on only formal(!) arguments?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/#comment-622810")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2021")])]

#text("In trying to extend the idea to infinite posets you may need additional conditions to deal with the infinite products and sums which you’ll encounter; for instance if you look at Proposition 2, then you can see how the sum in ii can bother you if you try to extend the idea to deal with an infinite poset.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ce674bb00cec5adc4987fa6051f13af6886eeeb887b23d4862b4080ada261b6-2fcf423d97104600d12bab08dba7bd99da8f858b9b24fdb94dc501a95c5b9249.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Knill")]], [#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/#comment-622756")[#strong[#text("Oliver Knill")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2021")])]

#text("Here is a topological angle to the Moebius picture (complementing Allen Knutsen’s remark): a poset P has as its Barycentric refinement the finite abstract simplicial complex G in which the elements are the non-empty subsets of P. For a subset X of G, the number chi(X) = sum_{x in X} omega(x) is known as the Euler characteristic of X, where omega(x) = (-1)^dim(x), dim(x)=|x|-1 and |x| is cardinality. With the core W^-(x)={y, y x } one can write the Moebius function as mu(x,y) =chi(W^+(x) \\cap W^-(y)). (I like to think of W^+ and W^- as unstable and stable manifolds and W^+ cap W^- as a heteroclinic point The Hall equations then read f(x) = sum_{y<x} g(y), g(x) = sum_{y A to a ring A, define chi(X)=sum_{x in X} h(x) and the symmetric matrices L(x,y)=chi(W^-(x) cap W^-(y)) g(x,y) = omega(x) omega(y) chi(W^+(x) cap W^+(y)). The later can be seen as Green functions because g is the inverse of the Laplacian L in the case if h takes values in the units One should think of g(x,y) as the potential energy between x and y. As V(x) = sum_y g(x,y) is a potential or index, Poincare-Hopf then is chi(G) = sum_{x,y in G} g(x,y). This so far only uses the additive structure of A. If A is a ring, then det(L)=det(g)=prod_{x in G} h(x). In the topological case h(x)=omega(x), the number theoretically interesting h(x)=1 or if h(x) takes values in the unit circle of the complex plane, L and g^* are unimodular matrices which are inverses of each other. For h(x)=1, one gets positive definite integral quadratic forms which are inverses of each other. Inclusion-exclusion is used in the proof ")#link("https://arxiv.org/abs/2010.09152")[#text("https://arxiv.org/abs/2010.09152")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88a174888c86f14dcd8abd05ac2d43af61aeeb70c13ff714ce20551f082c28d7-21248216e0d667ba2dd4b80df9b6437b305ec1a9a3a8ee78c6e6a6e39300e41e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Steinberg")]], [#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/#comment-629453")[#strong[#text("Benjamin Steinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2021")])]

#text("Proposition 6 is a slight variant of Theorem 1 of Louis Solomon’s classical paper The Burnside algebra of a finite group, Journal of Combinatorial Theory Volume 2, Issue 4, June 1967, Pages 603-615. Theorem 1 and the remark after it show that the primitive idempotents of the algebra of a finite meet semilattice ")#mi("L")#text(" are of the form ")#mi("e_x=\\sum_{y\\leq x}y\\mu(y,x)")#text(" (he does something slightly more general). Your commuting projections generate a finite meet semilattice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70e75637ca5c54e40ac996b90b350f307b60c8dbbf36bf28042df768a31737c2-2c082a8f0bf08d56a173d320a4964701f04ae5d6292d6107aba1dfd996a7b343.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nishad T M")]], [#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/#comment-630659")[#strong[#text("Nishad T M")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2021")])]

#text("Prof Tao,")#linebreak()#text(" I am Nishad T M from Kerala, India. During Lockdown, I tried to bring the Mathematical Proof of Collatz Conjecture. Since June 2020 I tried, now it is completed. Initially I sent it to Annals of Pure and Applied Mathematics, India to get reviews. As per initial review, I did some slight modifications and submitted to another Journal The Albertian Journal of Pure and Applied Mathematics, publishing from Research Department of Mathematics, St Alberts College Ernakulam, Kerala. I expect its Review report at 30th July.")#linebreak()#text(" I hope the Proof is convincing to Mathematics Graduates and Post Graduates.")#linebreak()#text(" An Introduction to Soul Set, IJSER,")#linebreak()#text(" Soul Process,")#linebreak()#text(" Statistical Soul Process Control,")#linebreak()#text(" The Motto Of Sreenarayanaguru in View of Soul Analysis,")#linebreak()#text(" Origin IJSER")#linebreak()#text(" Soul Set of a Product")#linebreak()#text(" The Errors in awarded PhDs in Mathematics from Kerala State India and Errors in Mathematics Text Books prescribed by Indian Universities, etc")#linebreak()#text(" are some of my Independent effort to bring a new Branch in Mathematics that helps to connect Mathematics with Humanity.")#linebreak()#text(" The Theorem 1 in article Origin, IJSER is very Simple and very effective.")#linebreak()#text(" Thanks for Reading.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b22018e10a005e8a335127704a07d1afbaa70a14167a148564792b99a96afc02-dc99dddbfafdd3686c6f47a9bbb34363169367e4b1535c68eed539a8eadc98e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Isaac Bernabé Duarte Alvarenga")]], [#link("https://terrytao.wordpress.com/2021/02/23/the-inclusion-exclusion-principle-for-commuting-projections/#comment-639362")[#strong[#text("Isaac Bernabé Duarte Alvarenga")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2022")])]

#text("I have a conjecture that I think is true and I think it is weak enough to be proven, for all n→ Pn+3—(Pn+2)(Pn+1)/Pn is smaller than 0 and for all n such that n is not divisible by 2→Pn+2—(Pn+1)^2/Pn is bigger than 0 and forma all n such that n is divisible by 2 →Pn+2—(Pn+1)^2/Pn is smaller than 0 that’s all I hope someone who is reading this can solve it.")
]
