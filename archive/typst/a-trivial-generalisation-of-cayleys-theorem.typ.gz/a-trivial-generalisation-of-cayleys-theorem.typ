// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:37:29.237548+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A trivial generalisation of Cayley’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A trivial generalisation of Cayley’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 October 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/")[#text("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the first basic theorems in group theory is ")#link("http://en.wikipedia.org/wiki/Cayley's_theorem")[#text("Cayley’s theorem")]#text(", which links abstract finite groups with concrete finite groups (otherwise known as ")#link("http://en.wikipedia.org/wiki/Permutation_group")[#text("permutation groups")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Cayley’s theorem)")]#text(" ")#metadata(none) <tao-e6c0a19cb86a5083b734>#text(" Let ")#mi("{G}")#text(" be a group of some finite order ")#mi("{n}")#text(". Then ")#mi("{G}")#text(" is isomorphic to a subgroup ")#mi("{\\tilde G}")#text(" of the ")#link("http://en.wikipedia.org/wiki/Symmetric_group")[#text("symmetric group")]#text(" ")#mi("{S_n}")#text(" on ")#mi("{n}")#text(" elements ")#mi("{\\{1,\\dots,n\\}}")#text(". Furthermore, this subgroup is ")#link("http://en.wikipedia.org/wiki/Group_action#simply_transitive")[#text("simply transitive")]#text(": given two elements ")#mi("{x,y}")#text(" of ")#mi("{\\{1,\\dots,n\\}}")#text(", there is precisely one element ")#mi("{\\sigma}")#text(" of ")#mi("{\\tilde G}")#text(" such that ")#mi("{\\sigma(x)=y}")#text(".")
]

#text("One can therefore think of ")#mi("{S_n}")#text(" as a sort of “universal” group that contains (up to isomorphism) all the possible groups of order ")#mi("{n}")#text(".")

#emph[#text("Proof:")]#text(" The group ")#mi("{G}")#text(" acts on itself by multiplication on the left, thus each element ")#mi("{g \\in G}")#text(" may be identified with a permutation ")#mi("{\\sigma_g: G \\rightarrow G}")#text(" on ")#mi("{G}")#text(" given by the map ")#mi("{\\sigma_g(h) := gh}")#text(". This can be easily verified to identify ")#mi("{G}")#text(" with a simply transitive permutation group on ")#mi("{G}")#text(". The claim then follows by arbitrarily identifying ")#mi("{G}")#text(" with ")#mi("{\\{1,\\dots,n\\}}")#text(". ")#mi("\\Box")

#text("More explicitly, the permutation group ")#mi("{\\tilde G}")#text(" arises by arbitrarily enumerating ")#mi("{G}")#text(" as ")#mi("{\\{s_1,\\dots,s_n\\}}")#text(" and then associating to each group element ")#mi("{g \\in G}")#text(" the permutation ")#mi("{\\sigma_g: \\{1,\\dots,n\\} \\rightarrow \\{1,\\dots,n\\}}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("g s_i = s_{\\sigma_g(i)}.")]]

#text("The simply transitive group ")#mi("{\\tilde G}")#text(" given by Cayley’s theorem is not unique, due to the arbitrary choice of identification of ")#mi("{G}")#text(" with ")#mi("{\\{1,\\dots,n\\}}")#text(", but is unique up to conjugation by an element of ")#mi("{S_n}")#text(". On the other hand, it is easy to see that every simply transitive subgroup of ")#mi("{S_n}")#text(" is of order ")#mi("{n}")#text(", and that two such groups are isomorphic if and only if they are conjugate by an element of ")#mi("{S_n}")#text(". Thus Cayley’s theorem in fact identifies the moduli space of groups of order ")#mi("{n}")#text(" (up to isomorphism) with the simply transitive subgroups of ")#mi("{S_n}")#text(" (up to conjugacy by elements of ")#mi("{S_n}")#text(").")

#text("One can generalise Cayley’s theorem to groups of infinite order without much difficulty. But in this post, I would like to note an (easy) generalisation of Cayley’s theorem in a different direction, in which the group ")#mi("{G}")#text(" is no longer assumed to be of order ")#mi("{n}")#text(", but rather to have an index ")#mi("{n}")#text(" subgroup that is isomorphic to a fixed group ")#mi("{H}")#text(". The generalisation is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Cayley’s theorem for ")#mi("{H}")#text("-sets)")]#text(" ")#metadata(none) <tao-e1d75132a8ece50f1780>#text(" Let ")#mi("{H}")#text(" be a group, and let ")#mi("{G}")#text(" be a group that contains an index ")#mi("{n}")#text(" subgroup isomorphic to ")#mi("{H}")#text(". Then ")#mi("{G}")#text(" is isomorphic to a subgroup ")#mi("{\\tilde G}")#text(" of the ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semidirect product")]#text(" ")#mi("{S_n \\ltimes H^n}")#text(", defined explicitly as the set of tuples ")#mi("{(\\sigma, (h_i)_{i=1}^n)}")#text(" with product")

#align(center)[#tao-fit-display[#mitex("(\\sigma, (h_i)_{i=1}^n) (\\rho, (k_i)_{i=1}^n) := (\\sigma \\circ \\rho, (h_{\\rho(i)} k_i)_{i=1}^n )")]]

#text("and inverse")

#align(center)[#tao-fit-display[#mitex("(\\sigma, (h_i)_{i=1}^n)^{-1} := (\\sigma^{-1}, (h_{\\sigma(i)}^{-1})_{i=1}^n).")]]

#text("(This group is a ")#link("http://en.wikipedia.org/wiki/Wreath_product")[#text("wreath product")]#text(" of ")#mi("{H}")#text(" with ")#mi("{S_n}")#text(", and is sometimes denoted ")#mi("{H \\wr S_n}")#text(", or more precisely ")#mi("{H \\wr_{\\{1,\\dots,n\\}} S_n}")#text(".) Furthermore, ")#mi("{\\tilde G}")#text(" is simply transitive in the following sense: given any two elements ")#mi("{x,y}")#text(" of ")#mi("{\\{1,\\dots,n\\}}")#text(" and ")#mi("{h,k \\in H}")#text(", there is precisely one ")#mi("{(\\sigma, (h_i)_{i=1}^n)}")#text(" in ")#mi("{\\tilde G}")#text(" such that ")#mi("{\\sigma(x)=y}")#text(" and ")#mi("{k = h_x h}")#text(".")
]

#text("Of course, Theorem ")#link(<tao-e6c0a19cb86a5083b734>)[#text("1")]#text(" is the special case of Theorem ")#link(<tao-e1d75132a8ece50f1780>)[#text("2")]#text(" when ")#mi("{H}")#text(" is trivial. This theorem allows one to view ")#mi("{S_n \\ltimes H^n}")#text(" as a “universal” group for modeling all groups containing a copy of ")#mi("{H}")#text(" as an index ")#mi("{n}")#text(" subgroup, in exactly the same way that ")#mi("{S_n}")#text(" is a universal group for modeling groups of order ")#mi("{n}")#text(". This observation is not at all deep, but I had not seen it before, so I thought I would record it here. (EDIT: as pointed out in comments, this is a slight variant of the universal embedding theorem of Krasner and Kaloujnine, which covers the case when ")#mi("{H}")#text(" is normal, in which case one can embed ")#mi("{G}")#text(" into the wreath product ")#mi("{H \\wr G/H}")#text(", which is a subgroup of ")#mi("{H \\wr S_n}")#text(".)")

#emph[#text("Proof:")]#text(" The basic idea here is to replace the category of sets in Theorem ")#link(<tao-e6c0a19cb86a5083b734>)[#text("1")]#text(" by the category of ")#mi("{H}")#text("-sets, by which we mean sets ")#mi("{X}")#text(" with a right-action of the group ")#mi("{H}")#text(". A morphism between two ")#mi("{H}")#text("-sets ")#mi("{X,Y}")#text(" is a function ")#mi("{f: X \\rightarrow Y}")#text(" which respects the right action of ")#mi("{H}")#text(", thus ")#mi("{f(x)h = f(xh)}")#text(" for all ")#mi("{x \\in X}")#text(" and ")#mi("{h \\in H}")#text(".")

#text("Observe that if ")#mi("{G}")#text(" contains a copy of ")#mi("{H}")#text(" as a subgroup, then one can view ")#mi("{G}")#text(" as an ")#mi("{H}")#text("-set, using the right-action of ")#mi("{H}")#text(" (which we identify with the indicated subgroup of ")#mi("{G}")#text("). The left action of ")#mi("{G}")#text(" on itself commutes with the right-action of ")#mi("{H}")#text(", and so we can represent ")#mi("{G}")#text(" by ")#mi("{H}")#text("-set automorphisms on the ")#mi("{H}")#text("-set ")#mi("{G}")#text(".")

#text("As ")#mi("{H}")#text(" has index ")#mi("{n}")#text(" in ")#mi("{G}")#text(", we see that ")#mi("{G}")#text(" is (non-canonically) isomorphic (as an ")#mi("{H}")#text("-set) to the ")#mi("{H}")#text("-set ")#mi("{\\{1,\\dots,n\\} \\times H}")#text(" with the obvious right action of ")#mi("{H}")#text(": ")#mi("{(i,h) k := (i,hk)}")#text(". It is easy to see that the group of ")#mi("{H}")#text("-set automorphisms of ")#mi("{\\{1,\\dots,n\\} \\times H}")#text(" can be identified with ")#mi("{S^n \\ltimes H}")#text(", with the latter group acting on the former ")#mi("{H}")#text("-set by the rule")

#align(center)[#tao-fit-display[#mitex("(\\sigma, (h_i)_{i=1}^n) (i,h) := (\\sigma(i), h_i h)")]]

#text("(it is routine to verify that this is indeed an action of ")#mi("{S^n \\ltimes H}")#text(" by ")#mi("{H}")#text("-set automorphisms. It is then a routine matter to verify the claims (the simple transitivity of ")#mi("{\\tilde G}")#text(" follows from the simple transitivity of the action of ")#mi("{G}")#text(" on itself). ")#mi("\\Box")

#text("More explicitly, the group ")#mi("{\\tilde G}")#text(" arises by arbitrarily enumerating the left-cosets of ")#mi("{H}")#text(" in ")#mi("{G}")#text(" as ")#mi("{\\{s_1H,\\dots,s_nH\\}}")#text(" and then associating to each group element ")#mi("{g \\in G}")#text(" the element ")#mi("{(\\sigma_g, (h_{g,i})_{i=1}^n )}")#text(", where the permutation ")#mi("{\\sigma_g: \\{1,\\dots,n\\} \\rightarrow \\{1,\\dots,n\\}}")#text(" and the elements ")#mi("{h_{g,i} \\in H}")#text(" are defined by the formula")

#align(center)[#tao-fit-display[#mitex("g s_i = s_{\\sigma_g(i)} h_{g,i}.")]]

#text("By noting that ")#mi("{H^n}")#text(" is an index ")#mi("{n!}")#text(" normal subgroup of ")#mi("{S_n \\ltimes H^n}")#text(", we recover the classical result of Poincaré that any group ")#mi("{G}")#text(" that contains ")#mi("{H}")#text(" as an index ")#mi("{n}")#text(" subgroup, contains a normal subgroup ")#mi("{N}")#text(" of index dividing ")#mi("{n!}")#text(" that is contained in ")#mi("{H}")#text(". (Quotienting out the ")#mi("{H}")#text(" right-action, we recover also the classical ")#emph[#text("proof")]#text(" of this result, as the action of ")#mi("{G}")#text(" on itself then collapses to the action of ")#mi("{G}")#text(" on the quotient space ")#mi("{G/H}")#text(", the stabiliser of which is ")#mi("{N}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that a simply transitive subgroup ")#mi("{\\tilde G}")#text(" of ")#mi("{S_n \\ltimes H^n}")#text(" contains a copy of ")#mi("{H}")#text(" as an index ")#mi("{n}")#text(" subgroup; in particular, there is a canonical embedding of ")#mi("{H}")#text(" into ")#mi("{\\tilde G}")#text(", and ")#mi("{\\tilde G}")#text(" can be viewed as an ")#mi("{H}")#text("-set.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that any two simply transitive subgroups ")#mi("{\\tilde G_1, \\tilde G_2}")#text(" of ")#mi("{S_n \\ltimes H^n}")#text(" are isomorphic simultaneously as groups and as ")#mi("{H}")#text("-sets (that is, there is a bijection ")#mi("{\\phi: \\tilde G_1 \\rightarrow \\tilde G_2}")#text(" that is simultaneously a group isomorphism and an ")#mi("{H}")#text("-set isomorphism) if and only if they are conjugate by an element of ")#mi("{S_n \\times H_n}")#text(".")
]

#text("[UPDATE: Exercises corrected; thanks to Keith Conrad for some additional corrections and comments.]")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-428149")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2014")])]

#text("Nice. I think I may assign this as a homework problem this semester.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6429fa47227555ee0fbc9aa0f6a21d9b4f7e76462d53f1c6133995ff382ef536-6a63e284c3afdca0ee7fd24ff8261cd208690a207a9e7de8501f8af6e0db9db5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johannes Hahn")]], [#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-428205")[#strong[#text("Johannes Hahn")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2014")])]

#text("This is just the Kaloujnine-Krasner embedding if I’m not mistaken.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-428214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2014")])]

#text("Thanks for the reference! (Strictly speaking, it seems that the Kaloujnine-Krasner embedding covers the case when ")#mi("H")#text(" is normal, and then one embeds into the wreath product ")#mi("H \\wr G/H")#text(" rather than ")#mi("H \\wr S_n")#text(", but I agree that it is “essentially” the same embedding.) I’ve updated the post to reflect this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/858e52c96ef959222916686f6a7f0d079e7934a65274b30a562edcb38fca86a7-d80941fdbd10a9974ad96a1932517fb3470c71b948666a679e501e384edbae31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frieder Ladisch")]], [#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-430614")[#strong[#text("Frieder Ladisch")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2014")])]

#text("This argument can be used when defining tensor induction (of group representations); for example, essentially the same result appears as Lemma (13.3) in Curtis and Reiner, Methods of Representation theory 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88a174888c86f14dcd8abd05ac2d43af61aeeb70c13ff714ce20551f082c28d7-21248216e0d667ba2dd4b80df9b6437b305ec1a9a3a8ee78c6e6a6e39300e41e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Steinberg")]], [#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-431681")[#strong[#text("Benjamin Steinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2014")])]

#text("You might find amusing how Ribes and I used this embedding to give fairly easy proofs of some classical theorems from combinatorial group theory like Nielsen-Schreier. See ")#link("http://arxiv.org/abs/0812.0027")[#text("http://arxiv.org/abs/0812.0027")]#text(" and I apologize for the self-promotion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d741f0600c069f3fa9b5534400eaf24912d1e1cfcb81f43dc0d8b78a44624ac5-ee6f08d15e6a312aba535b0baa497558039343097db3bb36ef9fac90361295a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Steinberg")]], [#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-431719")[#strong[#text("Benjamin Steinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2014")])]

#text("Terry,")

#text("By the way a more general version of this can be found as Chapter II Proposition 2.1 of Eilenberg’s Automata, Languages and Machines. He considers ")#mi("K\\subseteq H\\subseteq G")#text(" and embeds the faithful quotient of G acting on G/K into the wreath product of the faithful quotient of H acting on H/K with the faithful product of G acting on G/H, as permutation groups. Your statement is the special case K=1.")

#text("Eilenberg says in the chapter notes that this is all “folklore going back to probably to Frobenius”.")

#text("The most general version of your argument I know is due essentially to Schutzenberger. He uses the language of monomial representations but it is essentially the same.")

#text("Namely the endomorphism monoid of the free H-set on n-generators, i.e., Hx{1,…,n} is the wreath product of H with the monoid of all mappings on n letters. The same argument you give in your post shows that if S is a semigroup acting transitively on the right of a set X and H acts freely by automorphisms of the S-action, then S embeds in the semidirect product of H^n and T where T is the quotient of S acting faithfully on $X/H$. A key example, is where S is a finite semigroup and e is an idempotent of its minimal ideal. The eS is acted on by the right by S and on the left by eSe. In this case eSe is a group acting freely on eS by automorphisms and so the above applies. Schutzenberger proved an analogue for any idempotent but here one must allow wreath products if partial transformation semigroups with groups.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f361081d0a833dd8c6a90a3c2a4e4025e42fae5b73eda782f760c7780d7e6419-f53419947ba2ecd084a61edf6bd2184654da3ab1bb158403afcdce2ac1ad5a8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kevinalh")]], [#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-434176")[#strong[#text("kevinalh")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("Reblogged this on ")#link("http://kevinlanguasco.wordpress.com/2014/10/30/a-trivial-generalisation-of-cayleys-theorem/")[#text("Complejidad improbable")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-455996")[#strong[#text("Groups and Group Actions: Lecture 16 | Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2015")]

#text("[…] Terry Tao on a generalisation of Cayley’s theorem (this comes with a health warning: the post is not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-468729")[#strong[#text("Groups and Group Actions: Lecture 16 | Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")]

#text("[…] Terry Tao on a generalisation of Cayley’s theorem (this comes with a health warning: the post is not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/10/06/a-trivial-generalisation-of-cayleys-theorem/#comment-480775")[#strong[#text("Groups and Group Actions: Lecture 16 | Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2017")]

#text("[…] Terry Tao on a generalisation of Cayley’s theorem (this comes with a health warning: the post is not […]")
]
