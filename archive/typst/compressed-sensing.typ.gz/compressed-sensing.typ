// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/06/compressed-sensing/
// Converted to Typst by tao2typ: "2026-10-14T15:16:38.327090+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Compressed Sensing", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Compressed Sensing")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/")[#text("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This week I am in Australia, attending the ")#link("http://www.anziam.org.au/")[#text("ANZIAM")]#text(" annual ")#link("http://www.maths.usyd.edu.au/ANZIAM2008/")[#text("meeting in Katoomba, New South Wales")]#text(" (in the picturesque ")#link("http://www.visitbluemountains.com.au/index.php")[#text("Blue Mountains")]#text("). I gave an overview talk on some recent developments in ")#link("https://terrytao.wordpress.com/tag/compressed-sensing/")[#text("compressed sensing")]#text(", particularly with regards to the basis pursuit approach to recovering sparse (or compressible) signals from incomplete measurements. The slides for my talk ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/03/anziam.pdf")[#text("can be found here")]#text(", with some ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/02/anziam_pics.pdf")[#text("accompanying pictures here")]#text(". (There are of course by now many other presentations of compressed sensing on-line; see for instance ")#link("http://www.dsp.ece.rice.edu/cs/")[#text("this page at Rice")]#text(".)")

#text("There was an interesting discussion after the talk. Some members of the audience asked the very good question as to whether any ")#emph[#text("a priori")]#text(" information about a signal (e.g. some restriction about the support) could be incorporated to improve the performance of compressed sensing; a related question was whether one could perform an adaptive sequence of measurements to similarly improve performance. I don’t have good answers to these questions. Another pointed out that the restricted isometry property was like a local “well-conditioning” property for the matrix, which only applied when one viewed a few columns at a time.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/#comment-25648")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Terry,")

#text("Even though it was supposed to be a feature (being non-adaptive), there has been some headway in the direction of adaptive measurements in the form of a bayesian approach:")

#text("Bayesian Compressive Sensing, Shihao Ji, Ya Xue, and Lawrence Carin,")#linebreak()#text(" ")#link("http://www.ece.duke.edu/~shji/BCS.html")[#text("http://www.ece.duke.edu/~shji/BCS.html")]

#text("and more recent ones:")

#text("Colored Random Projections for Compressed Sensing by Zhongmin Wang; Arce, G.R.; Paredes, J.L., ")#link("http://ieeexplore.ieee.org/xpl/freeabs_all.jsp?arnumber=4217849")[#text("http://ieeexplore.ieee.org/xpl/freeabs_all.jsp?arnumber=4217849")]

#text("Compressed sensing image reconstruction via recursive spatially adaptive filtering,")#linebreak()#text(" Karen Egiazarian, Alessandro Foi, and Vladimir Katkovnik,")

#link("http://www.dsp.ece.rice.edu/cs//Egiazarian_ICIP2007.pdf")[#text("Click to access Egiazarian_ICIP2007.pdf")]

#text("Adaptive compressed image sensing based on wavelet-trees")#linebreak()#text(" S. Dekel")

#link("http://shaidekel.tripod.com/adaptiveCS.pdf")[#text("Click to access adaptiveCS.pdf")]

#text("With regards to a priori information, it would seem that one way to do this is to build a basis that reflects the a priori information that is sought. In the most recent undertakings, several methods have been devised to find specific bases in which the training/most representative datasets end up being sparsely represented:")

#text("MULTISCALE SPARSE IMAGE REPRESENTATION WITH")#linebreak()#text(" LEARNED DICTIONARIES, Julien Mairal, Guillermo Sapiro and Michael Elad")

#link("http://www.ima.umn.edu/preprints/jan2007/2152.pdf")[#text("Click to access 2152.pdf")]

#text("Efficient sparse coding algorithms, Honglak Lee Alexis Battle Rajat Raina Andrew Y. Ng")

#link("http://www.stanford.edu/%7Ehllee/nips06-sparsecoding.pdf")[#text("Click to access nips06-sparsecoding.pdf")]

#text("Once you have the “sparse” basis, you can use CS by obtaining measurements in a basis that is incoherent with the one you just built.")

#text("Igor.")#linebreak()#text(" ")#link("http://nuit-blanche.blogspot.com/search/label/CS")[#text("http://nuit-blanche.blogspot.com/search/label/CS")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f03cbafc0a94311b96f62f2922ff30643c5c0101849e257d65496643568d09e6-0be204c1623132addbd89f2d27831171619ce3e892b19c2e5f73e68e4e94d0cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel Peyré")]], [#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/#comment-25703")[#strong[#text("Gabriel Peyré")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Concerning the enhancement of CS by using more complex models than just sparsity, some pointers for the interested reader are gathered here")#linebreak()#text(" ")#link("http://www.dsp.ece.rice.edu/cs/#ext")[#text("http://www.dsp.ece.rice.edu/cs/#ext")]

#text("This is important since in practice, sparsity is not enough to perform efficient image compression (see e.g. the JPEG-2k image coder, which uses an advanced statistical modeling), so this is likely to be the case for efficient CS recovery.")

#text("Some additional stuffs:")#linebreak()#text(" * optimization in a scale-by-scale fashion of the wavelet coefficients")#linebreak()#text(" D. Donoho and Y. Tsaig, “Extensions of compressed sensing,”")#linebreak()#text(" * positivity or other constraints can be enforced by including additional convex sets for iterative projection on convex sets {x \\ |x|_1 < tau} and {x \\ A*x=b} where A is the sensing matrix.")#linebreak()#text(" E. Candes and J. Romberg, “Practical signal recovery from random projections”")#linebreak()#text(" * low total variation is another constraint that can be enforced (the intuition is that the gradient is sparse).")#linebreak()#text(" E. Candes and J. Romberg, “Practical signal recovery from random projections”")#linebreak()#text(" * One can also use more advanced signals models not based on sparsity")#linebreak()#text(" but rather on low dimensional smooth manifolds (for the whole image or for small patches).")#linebreak()#text(" R. Baraniuk and M. Wakin, “Random projections of smooth manifolds”")#linebreak()#text(" G. Peyre, “Manifold Models for Signals and Images”")#linebreak()#text(" * Recovery of piecewise smooth signals (the wavelet coefficients in this case can be “chained” accross the scale)")#linebreak()#text(" Duarte et al., “Fast reconstruction of piecewise smooth signals from random projections”")#linebreak()#text(" * Recovery of several signals having the same sparsity pattern (e.g. color image or multi-channels), see for instance")#linebreak()#text(" Fornasier et al., “Recovery algorithms for vector valued data with joint sparsity constraints.”")#linebreak()#text(" Gribonval et al., “Atoms of all channels, unite! Average case analysis of multi-channel sparse recovery using greedy algorithms.”")#linebreak()#text(" * sparsity in a best orthogonal basis (e.g. wavelet packets) instead of a fixed basis (e.g. wavelets)")#linebreak()#text(" G. Peyre, “Best Basis Compressed Sensing”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e013bf7cc516a7635d60c069edbcea2c638cfd509d08388f9eeec3cd864bc02-297b28d1f6bb382381dd804b79e01291bf750e44ea80143086b2f8eafc081b33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vivian")]], [#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/#comment-27034")[#strong[#text("Vivian")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2008")])]

#text("Prof. Tao,")

#text("Thanks very much for posting your ANZIAM slides. I realize that I’ve come upon this entry about a month late, but I was hoping that you could clarify one point for me. On slide #4, you write that the least-squares solution for Ax=b, with A mxn and m<n, is:")

#text("x = inv(A*A)A*b.")

#text("But is A*A even invertible under these conditions? The answer I get is:")

#text("x = A*inv(AA*)b.")

#text("Am I misinterpreting your notation somehow?")

#text("Regards,")

#text("Vivian")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/#comment-27040")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2008")])]

#text("Dear Vivian,")

#text("Oops, you are right, the matrices should be multiplied in the reverse order here. Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of More Mahler lectures « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/#comment-41214")[#strong[#text("More Mahler lectures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("[…] Compressed sensing. This is an updated and reformatted version of my ANZIAM talk on this topic. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/#comment-142988")[#strong[#text("Compressive Sensing: The Big Picture | spider's space")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")]

#text("[…] Non-Deterministic and Adaptive Measurement codes/matrices as mentioned here (as well as new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eeb5f4919f0c28d0a78254beecca95bd94a7c8123a33d99cef5b64bdb4f73aa0-0cf2992ffd14d870f4f7f86aae35deb385a53a5326f0a58522b99c23d2bca924.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yuping Zhang")]], [#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/#comment-513478")[#strong[#text("Yuping Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2019")])]

#text("My conclusion is the blue-eyed island puzzle is incorrect.")

#text("Here’s David Lewis’s 100 and N=0 or N=100 puzzle.")#linebreak()#text(" The single color puzzle.")#linebreak()#text(" In this N=0 or N=100 puzzle, the common knowledge is they all know that they all know that: ”At least one of you has green eyes.”")

#text("Here, the crucial key is the entire 100 of them are seeing the single color in the same amount of people=99, therefore, it’s not leaving each day that tells more and more works out but not in Terence Tao’s the blue-eyed island puzzle.")

#text("Let’s see more example.")#linebreak()#text(" The case, 10 and N=1, and N= is the only person to whose eyes are not green. Rest of the 9 are greens.")

#text("Someone announced: ”At least one of the ten has green eyes.”")

#text("In the 9th days, CAN all of the 9 greens figure it out their eye color logically?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/#comment-621989")[#strong[#text("转载：Compressive Sensing: The Big Picture – FIXBBS")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2021")]

#text("[…] Non-Deterministic and Adaptive Measurement codes/matrices as mentioned here (as well as new […]")
]
