// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/03/01/discrete-analysis-site-now-live/
// Converted to Typst by tao2typ: "2026-10-14T16:37:53.241711+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Discrete Analysis site now live", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Discrete Analysis site now live")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 March 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/03/01/discrete-analysis-site-now-live/")[#text("https://terrytao.wordpress.com/2016/03/01/discrete-analysis-site-now-live/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a quick post to note that the arXiv overlay journal Discrete Analysis, managed by Timothy Gowers, has now gone live ")#link("http://discreteanalysisjournal.com/")[#text("with its permanent (and quite modern looking) web site")]#text(", which is run using the Scholastica platform, as well as the first half-dozen or so accepted papers (including ")#link("http://discreteanalysisjournal.com/article/609-the-erdos-discrepancy-problem")[#text("one of my own")]#text("). See ")#link("https://gowers.wordpress.com/2016/03/01/discrete-analysis-launched/")[#text("Tim’s announcement")]#text(" for more details. I am one of the ")#link("http://discreteanalysisjournal.com/editorial-board")[#text("editors of this journal")]#text(" (and am already handling a few submissions). Needless to say, we are happy to take in more submissions (though they will have to be peer reviewed if they are to be accepted, of course).")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf321d2381e42eadefd8656eac9e6e7b6d3ff9a7151d5d15179969026eac88b8-6feb69172594a33a6fb9335aa62951fddf7db2d141a6be16bbeb13cf2f217a2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brendan Murphy")]], [#link("https://terrytao.wordpress.com/2016/03/01/discrete-analysis-site-now-live/#comment-466544")[#strong[#text("Brendan Murphy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2016")])]

#text("I’m glad your proof of the Erdos discrepancy problem is featured in the first “issue”—not only is it a great result, but a lot of the work unfolded online.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2016/03/01/discrete-analysis-site-now-live/#comment-466545")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2016")])]

#text("What attracts me first on the webpage is the pictures. I keep wondering if there is some deep connection between a paper and the picture beneath it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/01/discrete-analysis-site-now-live/#comment-466651")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2016")])]

#text("I think the pictures are basically clip art, supplied by the publishing platform.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/749239c9eb104401f2bbf0db828fa14a2ff9d1b549bbfe68671031b96abf3198-cab107026f379aa6c398d11c57c867e899a57c70afe6aec7448fdc5e87cc289a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Youssef Akoudad")]], [#link("https://terrytao.wordpress.com/2016/03/01/discrete-analysis-site-now-live/#comment-466563")[#strong[#text("Youssef Akoudad")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2016")])]

#text("I think the website doesn’t work on mobiles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa1365f6c950c850c31099c5c7716df071e1cb8a6efce69ef9ae9433d509db6-8ae6ab89d54a8e28245aeacb702ccc10e7706e136c9b30896a01dbb8211ff135.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primework123")]], [#link("https://terrytao.wordpress.com/2016/03/01/discrete-analysis-site-now-live/#comment-466569")[#strong[#text("primework123")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2016")])]

#text("Wow! The DA webpage is slick and spectacular. And it’s content is even more impressive! Thanks for sharing! I hope to submit some work there in the near future.")

#text("I wish DA and all its staff much success! :-)")
]
