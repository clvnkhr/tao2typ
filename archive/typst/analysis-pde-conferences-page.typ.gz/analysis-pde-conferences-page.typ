// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/08/analysis-pde-conferences-page/
// Converted to Typst by tao2typ: "2026-10-14T15:17:02.220374+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Analysis & PDE conferences page", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Analysis & PDE conferences page")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/08/analysis-pde-conferences-page/")[#text("https://terrytao.wordpress.com/2009/02/08/analysis-pde-conferences-page/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("For the last ten years or so, I used to maintain a list of conferences in the area of analysis & PDE (see e.g. this page for a partial archive of this ")#link("http://www.math.ucla.edu/~tao/harmonic/conferences.html")[#text("conference list")]#text("). However, due to many other demands on my time, I eventually ceased to maintain it, instead passing it over to the Harmonic Analysis and Related Problems (HARP) group that was supported by the European Mathematical Society. Unfortunately, the EMS funding ran out a few years back, the HARP group dissolved, and so the page drifted for a while.")

#text("This week, I talked to my good friend ")#link("http://www.math.toronto.edu/colliand/")[#text("Jim Colliander")]#text(" (who maintains the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Main_Page")[#text("DispersiveWiki")]#text(") and he agreed to host a ")#link("http://tosio.math.utoronto.ca/wiki/index.php/Conferences")[#text("new version of the conferences page")]#text(" on the Wiki, where it can be collaboratively updated. It is rather sparse right now, but I hope people will contribute to it, either by adding new conferences and related content, or by cleaning up the organisation of existing content. I have also migrated a ")#link("http://tosio.math.utoronto.ca/wiki/index.php/Courses_and_lecture_notes")[#text("list of lecture notes and courses in analysis and PDE")]#text(" which is badly in need of updating.")

#text("[One can presumably use the Wiki to also host other items of this nature than just a conference list; any suggestions for expanding the page would also be welcome.]")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7ff278529a8bb3e66ae7f37cee5a4db9332a0d4a5407ec0b6a9b062bf19449-a44683bdac6a284cf8b946d08002a48b8a39b588dfdb2a3d2a8923bf7a95dc42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thang Huynh")]], [#link("https://terrytao.wordpress.com/2009/02/08/analysis-pde-conferences-page/#comment-35615")[#strong[#text("Thang Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Thank you for your good news.")#linebreak()#text(" Could you spend some time on giving advices for undergraduate students?")#linebreak()#text(" For example, discuss some open problems at undergraduate level (I took a loot at the Kakeya conjecture and it was difficult for me); or discuss how we [undergraduate students] submit papers to appropriate journals or take part in relevant conferences.")#linebreak()#text(" Once again, thank you.")#linebreak()#text(" Thang Huynh")
]
