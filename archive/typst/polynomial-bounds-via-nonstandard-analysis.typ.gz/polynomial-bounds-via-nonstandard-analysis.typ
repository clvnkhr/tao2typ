// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/07/05/polynomial-bounds-via-nonstandard-analysis/
// Converted to Typst by tao2typ: "2026-10-14T15:18:08.156963+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polynomial bounds via nonstandard analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polynomial bounds via nonstandard analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 July 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/07/05/polynomial-bounds-via-nonstandard-analysis/")[#text("https://terrytao.wordpress.com/2011/07/05/polynomial-bounds-via-nonstandard-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have ")#link("https://terrytao.wordpress.com/tag/nonstandard-analysis/")[#text("blogged several times in the past")]#text(" about ")#link("http://en.wikipedia.org/wiki/Nonstandard_analysis")[#text("nonstandard analysis")]#text(", which among other things is useful in allowing one to import tools from infinitary (or qualitative) mathematics in order to establish results in finitary (or quantitative) mathematics. One drawback, though, to using nonstandard analysis methods is that the bounds one obtains by such methods are usually ")#emph[#text("ineffective")]#text(": in particular, the conclusions of a nonstandard analysis argument may involve an unspecified constant ")#mi("{C}")#text(" that is known to be finite but for which no explicit bound is obviously available. (In many cases, a bound can eventually be worked out by performing ")#emph[#text("proof mining")]#text(" on the argument, and in particular by carefully unpacking the ")#emph[#text("proofs")]#text(" of all the various results from infinitary mathematics that were used in the argument, as opposed to simply using them as “black boxes”, but this is a time-consuming task and the bounds that one eventually obtains tend to be quite poor (e.g. tower exponential or Ackermann type bounds are not uncommon).)")

#text("Because of this fact, it would seem that quantitative bounds, such as polynomial type bounds ")#mi("{X \\leq C Y^C}")#text(" that show that one quantity ")#mi("{X}")#text(" is controlled in a polynomial fashion by another quantity ")#mi("{Y}")#text(", are not easily obtainable through the ineffective methods of nonstandard analysis. Actually, this is not the case; as I will demonstrate by an example below, nonstandard analysis can certainly yield polynomial type bounds. The catch is that the exponent ")#mi("{C}")#text(" in such bounds will be ineffective; but nevertheless such bounds are still good enough for many applications.")

#text("Let us now illustrate this by reproving a lemma from ")#link("http://www.ams.org/mathscinet-getitem?mr=2006555")[#text("this paper of Mei-Chu Chang")]#text(" (Lemma 2.14, to be precise), which was recently pointed out to me by Van Vu. Chang’s paper is focused primarily on the sum-product problem, but she uses a quantitative lemma from algebraic geometry which is of independent interest. To motivate the lemma, let us first establish a qualitative version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Qualitative solvability)")]#text(" ")#metadata(none) <tao-7ac79109ee3ecbd33d6d>#text(" Let ")#mi("{P_1,\\ldots,P_r: {\\bf C}^d \\rightarrow {\\bf C}}")#text(" be a finite number of polynomials in several variables with rational coefficients. If there is a complex solution ")#mi("{z = (z_1,\\ldots,z_d) \\in {\\bf C}^d}")#text(" to the simultaneous system of equations")

#align(center)[#tao-fit-display[#mitex("P_1(z) = \\ldots = P_r(z) = 0,")]]

#text("then there also exists a solution ")#mi("{z \\in \\overline{{\\bf Q}}^d}")#text(" whose coefficients are algebraic numbers (i.e. they lie in the algebraic closure ")#mi("{{\\bf Q}}")#text(" of the rationals).")
]

#emph[#text("Proof:")]#text(" Suppose there was no solution to ")#mi("{P_1(z)=\\ldots=P_r(z)=0}")#text(" over ")#mi("{\\overline{{\\bf Q}}}")#text(". Applying ")#link("http://en.wikipedia.org/wiki/Hilbert's_Nullstellensatz")[#text("Hilbert’s nullstellensatz")]#text(" (which is available as ")#mi("{\\overline{{\\bf Q}}}")#text(" is algebraically closed), we conclude the existence of some polynomials ")#mi("{Q_1,\\ldots,Q_r}")#text(" (with coefficients in ")#mi("{\\overline{{\\bf Q}}}")#text(") such that")

#align(center)[#tao-fit-display[#mitex("P_1 Q_1 + \\ldots + P_r Q_r = 1")]]

#text("as polynomials. In particular, we have")

#align(center)[#tao-fit-display[#mitex("P_1(z) Q_1(z) + \\ldots + P_r(z) Q_r(z) = 1")]]

#text("for all ")#mi("{z \\in {\\bf C}^d}")#text(". This shows that there is no solution to ")#mi("{P_1(z)=\\ldots=P_r(z)=0}")#text(" over ")#mi("{{\\bf C}}")#text(", as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#metadata(none) <tao-3b6a765ede676559e0f2>#text(" Observe that in the above argument, one could replace ")#mi("{{\\bf Q}}")#text(" and ")#mi("{{\\bf C}}")#text(" by any other pair of fields, with the latter containing the algebraic closure of the former, and still obtain the same result.")
]

#text("The above lemma asserts that if a system of rational equations is solvable at all, then it is solvable with some algebraic solution. But it gives no bound on the complexity of that solution in terms of the complexity of the original equation. Chang’s lemma provides such a bound. If ")#mi("{H \\geq 1}")#text(" is an integer, let us say that an algebraic number has ")#link("http://en.wikipedia.org/wiki/Height_function")[#text("height")]#text(" at most ")#mi("{H}")#text(" if its minimal polynomial (after clearing denominators) consists of integers of magnitude at most ")#mi("{H}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Quantitative solvability)")]#text(" ")#metadata(none) <tao-7327d4d86dcf6bd569c0>#text(" Let ")#mi("{P_1,\\ldots,P_r: {\\bf C}^d \\rightarrow {\\bf C}}")#text(" be a finite number of polynomials of degree at most ")#mi("{D}")#text(" with rational coefficients, each of height at most ")#mi("{H}")#text(". If there is a complex solution ")#mi("{z = (z_1,\\ldots,z_d) \\in {\\bf C}^d}")#text(" to the simultaneous system of equations")

#align(center)[#tao-fit-display[#mitex("P_1(z) = \\ldots = P_r(z) = 0,")]]

#text("then there also exists a solution ")#mi("{z \\in \\overline{{\\bf Q}}^d}")#text(" whose coefficients are algebraic numbers of degree at most ")#mi("{C}")#text(" and height at most ")#mi("{CH^C}")#text(", where ")#mi("{C = C_{D, d,r}}")#text(" depends only on ")#mi("{D}")#text(", ")#mi("{d}")#text(" and ")#mi("{r}")#text(".")
]

#text("Chang proves this lemma by essentially establishing a quantitative version of the nullstellensatz, via elementary elimination theory (somewhat similar, actually, to the approach I took to the nullstellensatz in ")#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")[#text("my own blog post")]#text("). She also notes that one could also establish the result through the machinery of ")#link("http://en.wikipedia.org/wiki/Gr%C3%B6bner_basis")[#text("Gröbner bases")]#text(". In each of these arguments, it was not possible to use Lemma ")#link(<tao-7ac79109ee3ecbd33d6d>)[#text("1")]#text(" (or the closely related nullstellensatz) as a black box; one actually had to unpack one of the proofs of that lemma or nullstellensatz to get the polynomial bound. However, using nonstandard analysis, it is possible to get such polynomial bounds (albeit with an ineffective value of the constant ")#mi("{C}")#text(") directly from Lemma ")#link(<tao-7ac79109ee3ecbd33d6d>)[#text("1")]#text(" (or more precisely, the generalisation in Remark ")#link(<tao-3b6a765ede676559e0f2>)[#text("1")]#text(") ")#emph[#text("without")]#text(" having to inspect the proof, and instead simply using it as a black box, thus providing a “soft” proof of Lemma ")#link(<tao-7327d4d86dcf6bd569c0>)[#text("2")]#text(" that is an alternative to the “hard” proofs mentioned above.")

#text("Here’s how the proof works. Informally, the idea is that Lemma ")#link(<tao-7327d4d86dcf6bd569c0>)[#text("2")]#text(" should follow from Lemma ")#link(<tao-7ac79109ee3ecbd33d6d>)[#text("1")]#text(" after replacing the field of rationals ")#mi("{{\\bf Q}}")#text(" with “the field of rationals of polynomially bounded height”. Unfortunately, the latter object does not really make sense as a field in standard analysis; nevertheless, it is a perfectly sensible object in nonstandard analysis, and this allows the above informal argument to be made rigorous.")

#text("We turn to the details. As is common whenever one uses nonstandard analysis to prove finitary results, we use a “compactness and contradiction” argument (or more precisely, an “ultralimit and contradiction” argument). Suppose for contradiction that Lemma ")#link(<tao-7327d4d86dcf6bd569c0>)[#text("2")]#text(" failed. Carefully negating the quantifiers (and using the axiom of choice), we conclude that there exists ")#mi("{D, d, r}")#text(" such that for each natural number ")#mi("{n}")#text(", there is a positive integer ")#mi("{H^{(n)}}")#text(" and a family ")#mi("{P_1^{(n)}, \\ldots, P_r^{(n)}: {\\bf C}^d \\rightarrow {\\bf C}}")#text(" of polynomials of degree at most ")#mi("{D}")#text(" and rational coefficients of height at most ")#mi("{H^{(n)}}")#text(", such that there exist at least one complex solution ")#mi("{z^{(n)} \\in {\\bf C}^d}")#text(" to ")#metadata(none) <tao-a558030fcb3879647678>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("P_1^{(n)}(z^{(n)}) = \\ldots = P_r(z^{(n)}) = 0,")]]

#text("but such that there does not exist any such solution whose coefficients are algebraic numbers of degree at most ")#mi("{n}")#text(" and height at most ")#mi("{n (H^{(n)})^n}")#text(".")

#text("Now we take ultralimits (see e.g. ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous blog post")]#text(" of a quick review of ultralimit analysis, which we will assume knowledge of in the argument that follows). Let ")#mi("{p \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(" be a non-principal ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(". For each ")#mi("{i=1,\\ldots,r}")#text(", the ultralimit")

#align(center)[#tao-fit-display[#mitex("P_i := \\lim_{n \\rightarrow p} P_i^{(n)}")]]

#text("of the (standard) polynomials ")#mi("{P_i^{(n)}}")#text(" is a nonstandard polynomial ")#mi("{P_i: {}^* {\\bf C}^d \\rightarrow {}^* {\\bf C}}")#text(" of degree at most ")#mi("{D}")#text(", whose coefficients now lie in the nonstandard rationals ")#mi("{{}^* {\\bf Q}}")#text(". Actually, due to the height restriction, we can say more. Let ")#mi("{H := \\lim_{n \\rightarrow p} H^{(n)} \\in {}^* {\\bf N}}")#text(" be the ultralimit of the ")#mi("{H^{(n)}}")#text(", this is a nonstandard natural number (which will almost certainly be unbounded, but we will not need to use this). Let us say that a nonstandard integer ")#mi("{a}")#text(" is ")#emph[#text("of polynomial size")]#text(" if we have ")#tao-math("{\\left|a\\right| \\leq C H^C}", block: false)#text(" for some standard natural number ")#mi("{C}")#text(", and say that a nonstandard rational number ")#mi("{a/b}")#text(" is ")#emph[#text("of polynomial height")]#text(" if ")#mi("{a}")#text(", ")#mi("{b}")#text(" are of polynomial size. Let ")#mi("{{\\bf Q}_{poly(H)}}")#text(" be the collection of all nonstandard rationals of polynomial height. (In the language of nonstandard analysis, ")#mi("{{\\bf Q}_{poly(H)}}")#text(" is an ")#emph[#text("external")]#text(" set rather than an internal one, because it is not itself an ultraproduct of standard sets; but this will not be relevant for the argument that follows.) It is easy to see that ")#mi("{{\\bf Q}_{poly(H)}}")#text(" is a field, basically because the sum or product of two integers of polynomial size, remains of polynomial size. By construction, it is clear that the coefficients of ")#mi("{P_i}")#text(" are nonstandard rationals of polynomial height, and thus ")#mi("{P_1,\\ldots,P_r}")#text(" are defined over ")#mi("{{\\bf Q}_{poly(H)}}")#text(".")

#text("Meanwhile, if we let ")#mi("{z := \\lim_{n \\rightarrow p} z^{(n)} \\in {}^* {\\bf C}^d}")#text(" be the ultralimit of the solutions ")#mi("{z^{(n)}}")#text(" in ")#link(<tao-a558030fcb3879647678>)[#text("(1)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("P_1(z) = \\ldots = P_r(z) = 0,")]]

#text("thus ")#mi("{P_1,\\ldots,P_r}")#text(" are solvable in ")#mi("{{}^* {\\bf C}}")#text(". Applying Lemma ")#link(<tao-7ac79109ee3ecbd33d6d>)[#text("1")]#text(" (or more precisely, the generalisation in Remark ")#link(<tao-3b6a765ede676559e0f2>)[#text("1")]#text("), we see that ")#mi("{P_1,\\ldots,P_r}")#text(" are also solvable in ")#mi("{\\overline{{\\bf Q}_{poly(H)}}}")#text(". (Note that as ")#mi("{{\\bf C}}")#text(" is algebraically closed, ")#mi("{{}^*{\\bf C}}")#text(" is also (by Los’s theorem), and so ")#mi("{{}^* {\\bf C}}")#text(" contains ")#mi("{\\overline{{\\bf Q}_{poly(H)}}}")#text(".) Thus, there exists ")#mi("{w \\in \\overline{{\\bf Q}_{poly(H)}}^d}")#text(" with")

#align(center)[#tao-fit-display[#mitex("P_1(w) = \\ldots = P_r(w) = 0.")]]

#text("As ")#mi("{\\overline{{\\bf Q}_{poly(H)}}^d}")#text(" lies in ")#mi("{{}^* {\\bf C}^d}")#text(", we can write ")#mi("{w}")#text(" as an ultralimit ")#mi("{w = \\lim_{n \\rightarrow p} w^{(n)}}")#text(" of standard complex vectors ")#mi("{w^{(n)} \\in {\\bf C}^d}")#text(". By construction, the coefficients of ")#mi("{w}")#text(" each obey a non-trivial polynomial equation of degree at most ")#mi("{C}")#text(" and whose coefficients are nonstandard integers of magnitude at most ")#mi("{C H^C}")#text(", for some standard natural number ")#mi("{C}")#text(". Undoing the ultralimit, we conclude that for ")#mi("{n}")#text(" sufficiently close to ")#mi("{p}")#text(", the coefficients of ")#mi("{w^{(n)}}")#text(" obey a non-trivial polynomial equation of degree at most ")#mi("{C}")#text(" whose coefficients are ")#emph[#text("standard")]#text(" integers of magnitude at most ")#mi("{C (H^{(n)})^C}")#text(". In particular, these coefficients have height at most ")#mi("{C (H^{(n)})^C}")#text(". Also, we have")

#align(center)[#tao-fit-display[#mitex("P_1^{(n)}(w^{(n)}) = \\ldots = P_r^{(n)}(w^{(n)}) = 0.")]]

#text("But for ")#mi("{n}")#text(" larger than ")#mi("{C}")#text(", this contradicts the construction of the ")#mi("{P_i^{(n)}}")#text(", and the claim follows. (Note that as ")#mi("{p}")#text(" is non-principal, any neighbourhood of ")#mi("{p}")#text(" in ")#mi("{{\\bf N}}")#text(" will contain arbitrarily large natural numbers.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The same argument actually gives a slightly stronger version of Lemma ")#link(<tao-7327d4d86dcf6bd569c0>)[#text("2")]#text(", namely that the integer coefficients used to define the algebraic solution ")#mi("{z}")#text(" can be taken to be polynomials in the coefficients of ")#mi("{P_1,\\ldots,P_r}")#text(", with degree and coefficients bounded by ")#mi("{C_{D,d,r}}")#text(".")
]

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2011/07/05/polynomial-bounds-via-nonstandard-analysis/#comment-55012")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2011")])]

#text("For these sort of bounds where the constants or degrees when expanded become very large, do we have any idea if that’s due to the limitation of the techniques or whether the constants really are just really big? Naively answering this sort of question for Lemma 2 looks really tough.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/05/polynomial-bounds-via-nonstandard-analysis/#comment-55013")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2011")])]

#text("There is an active area of research in effective and computational algebraic geometry devoted to these sorts of questions (and in many other fields than algebraic geometry also), but I don’t know the latest results. Certainly, a naive quantification of the textbook qualitative arguments here would lead to various unnecessary exponential losses, but I don’t know if by being careful enough one can eradicate all such exponential factors. (It may be that one has to carefully word the result in order to get, say, polynomial bounds, as many concepts that are equivalent at the exponential bound level or above may become inequivalent at the polynomial bound level.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2011/07/05/polynomial-bounds-via-nonstandard-analysis/#comment-55081")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2011")])]

#text("Given a few functions (e.g., addition and multiplication), a subset (typically external) of the nonstandard world that is closed under these operations is called a cut (sometimes a hypercut). Keisler and Jin (and I’m sure others) have investigated the existence of cuts with various good and bad properties.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rectification and the Lefschetz principle | What's new")]], [#link("https://terrytao.wordpress.com/2011/07/05/polynomial-bounds-via-nonstandard-analysis/#comment-219474")[#strong[#text("Rectification and the Lefschetz principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2013")])]

#text("[…] quantitative elimination theory, and in particular a quantitative variant of a lemma of Chang that was discussed previously on this blog. In that previous blog post, it was observed that (an ineffective version of) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/07/05/polynomial-bounds-via-nonstandard-analysis/#comment-682342")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2023")])]

#text("When you say “By construction, the coefficients of {w} each obey a non-trivial polynomial equation of degree at most {C} and whose coefficients are nonstandard integers of magnitude at most {C H^C},” should the “at most {C}” be “at most {D}”? Since the polynomial ")#mi("P_i")#text(" over ")#mi("\\mathbb{Q}_\\mathrm{poly(H)}")#text(" is of degree ")#mi("\\leq D")#text("? Or am I misreading?")

#emph[#text("[In this sentence one can just take ")#mi("C")#text(" to equal ")#mi("D")#text(". -T]")]
]
