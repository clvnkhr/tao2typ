// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/09/random-covariance-matrices-universality-of-local-statistics-of-eigenvalues/
// Converted to Typst by tao2typ: "2026-10-14T08:50:40.136874+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random covariance matrices: Universality of local statistics of eigenvalues", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random covariance matrices: Universality of local statistics of eigenvalues")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/09/random-covariance-matrices-universality-of-local-statistics-of-eigenvalues/")[#text("https://terrytao.wordpress.com/2009/12/09/random-covariance-matrices-universality-of-local-statistics-of-eigenvalues/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/0912.0966")[#text("Random covariance matrices: Universality of local statistics of eigenvalues")]#text("“, to be submitted shortly. This paper draws heavily on the technology of ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("our previous paper")]#text(", in which we established a Four Moment Theorem for the local spacing statistics of eigenvalues of Wigner matrices. This theorem says, roughly speaking, that these statistics are completely determined by the first four moments of the coefficients of such matrices, at least in the bulk of the spectrum. (In ")#link("https://terrytao.wordpress.com/2009/08/15/random-matrices-universality-of-local-eigenvalue-statistics-up-to-the-edge/")[#text("a subsequent paper")]#text(" we extended the Four Moment Theorem to the edge of the spectrum.)")

#text("In this paper, we establish the analogous result for the ")#emph[#text("singular values")]#text(" of rectangular iid matrices ")#mi("{M = M_{n,p}}")#text(", or (equivalently) the eigenvalues of the associated covariance matrix ")#mi("{\\frac{1}{n} M M^*}")#text(". As is well-known, there is a parallel theory between the spectral theory of random Wigner matrices and those of covariance matrices; for instance, just as the former has asymptotic spectral distribution governed by the semi-circular law, the latter has asymptotic spectral distribution governed by the ")#emph[#text("Marcenko-Pastur law")]#text(". One reason for the connection can be seen by noting that the singular values of a rectangular matrix ")#mi("{M}")#text(" are essentially the same thing as the eigenvalues of the ")#emph[#text("augmented matrix")]

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} 0 & M \\\\ M^* & 0\\end{pmatrix}")]]

#text("after eliminating sign ambiguities and degeneracies. So one can view singular values of a rectangular iid matrix as the eigenvalues of a matrix which resembles a Wigner matrix, except that two diagonal blocks of that matrix have been zeroed out.")

#text("The zeroing out of these elements prevents one from applying the entire Wigner universality theory directly to the covariance matrix setting (in particular, the crucial Talagrand concentration inequality for the magnitude of a projection of a random vector to a subspace does not work perfectly once there are many zero coefficients). Nevertheless, a large part of the theory (particularly the deterministic components of the theory, such as eigenvalue variation formulae) carry through without much difficulty. The one place where one has to spend a bit of time to check details is to ensure that the Erdos-Schlein-Yau delocalisation result (that asserts, roughly speaking, that the eigenvectors of a Wigner matrix are about as small in ")#mi("{\\ell^\\infty}")#text(" norm as one could hope to get) is also true for in the covariance matrix setting, but this is a straightforward (though somewhat tedious) adaptation of the method (which is based on the Stieltjes transform).")

#text("As an application, we extend the sine kernel distribution of local covariance matrix statistics, first established in the case of ")#emph[#text("Wishart ensembles")]#text(" (when the underlying variables are gaussian) by ")#link("http://www.ams.org/mathscinet-getitem?mr=1142971")[#text("Nagao and Wadati")]#text(", and later extended to gaussian-divisible matrices ")#link("http://www.ams.org/mathscinet-getitem?mr=2162782")[#text("by Ben Arous and Peche")]#text(", to any distributions which matches one of these distributions to up to four moments, which covers virtually all complex distributions with independent iid real and imaginary parts, with basically the lone exception of the complex Bernoulli ensemble.")

#text("Recently, ")#link("http://arxiv.org/abs/0911.3687")[#text("Erdos, Schlein, Yau, and Yin")]#text(" generalised their local relaxation flow method to also obtain similar universality results for distributions which have a large amount of smoothness, but without any matching moment conditions. By combining their techniques with ours as in ")#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/")[#text("our joint paper")]#text(", one should probably be able to remove both smoothness and moment conditions, in particular now covering the complex Bernoulli ensemble.")

#text("In this paper we also record a new observation that the exponential decay hypothesis in our earlier paper can be relaxed to a finite moment condition, for a sufficiently high (but fixed) moment. This is done by rearranging the order of steps of the original argument carefully.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/12/09/random-covariance-matrices-universality-of-local-statistics-of-eigenvalues/#comment-42774")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2009")])]

#text("[…] Random covariance matrices: Universality of local statistics of eigenvalues […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/12/09/random-covariance-matrices-universality-of-local-statistics-of-eigenvalues/#comment-44538")[#strong[#text("Libres pensées d’un mathématicien ordinaire » Eigenvectors universality for random matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")]

#text("[…] of random matrices is related to their delocalization, a phenomenon recently investigated by Erdös, Schlein, Ramirez, Yau, Tao, Vu, as a byproduct of their analysis of the universality of local statistics of the spectrum. This is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Wigner-Dyson-Mehta bulk universality conjecture for Wigner matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/09/random-covariance-matrices-universality-of-local-statistics-of-eigenvalues/#comment-49999")[#strong[#text("The Wigner-Dyson-Mehta bulk universality conjecture for Wigner matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2011")])]

#text("[…] exponential decay condition in the four moment theorem to a finite moment condition (established by Vu and myself) and a strong eigenvalue localisation bound of ErdHs, Yau, and Yin}, one can upgrade the averaged […]")
]
