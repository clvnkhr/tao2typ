// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/
// Converted to Typst by tao2typ: "2026-10-14T11:17:40.443427+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finite time blowup with smooth forcing term for the incompressible porous medium, Boussinesq, and incompressible Euler equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finite time blowup with smooth forcing term for the incompressible porous medium, Boussinesq, and incompressible Euler equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/")[#text("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("There’s some exciting ")#link("https://mathstodon.xyz/@tristanbuckmaster@mastodon.social/117233413735526010")[#text("very recent work by Alpöge and Buckmaster")]#text(", building upon ")#link("https://arxiv.org/abs/2410.22920v3")[#text("prior work by Córdoba and Martínez-Zoroa")]#text(", in the general topic around the infamous global regularity problem for the ")#link("https://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_equations")[#text("incompressible three-dimensional Navier-Stokes equations")]#text(". It is now widely expected that it should be possible to construct smooth initial data and smooth forcing term that would make these equations develop singularities in finite time; and it should even be possible to do without the forcing term. While these authors do not quite achieve these goals yet, they have made enough of a breakthrough that it looks very feasible to complete these goals in the near future. In particular, they have demonstrated such finite time blowup for three simpler model equations: the incompressible porous medium (IPM) equation, the ")#link("https://en.wikipedia.org/wiki/Boussinesq_approximation_(water_waves)")[#text("two-dimensional Boussinesq equation")]#text(", and the ")#link("https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[#text("three-dimensional incompressible Euler equations")]#text(". (The first of these equations was already handled by Córdoba and Martínez-Zoroa, but Alpöge and Buckmaster found a variant of their method that also extended to the other two equations, and has a high likelihood of also extending to Navier-Stokes as well.) As is now remarkably feasible in the modern era of autoformalization agents, their work has also been formalized in Lean.")

#text("As one may expect nowadays, the arguments here are heavily AI-assisted, but the authors have been working over the last few weeks to simplify and rewrite the proofs from what they literally call “the worst writeup we had ever seen in the history of mathematics” into something far more readable and of professional quality. This is still a work in progress: unfortunately, they were forced to release their preliminary preprints before they were completely digested and polished, due to external events that are documented on the above link. Nevertheless, the introduction to the ")#link("https://cims.nyu.edu/~tristanb/boussinesq.pdf")[#text("Boussinesq paper")]#text(" at least is in pretty good shape, and can serve as an initial starting point. I was also fortunate to have Tristan Buckmaster explain the main ideas of the paper in a half-hour phone conversation, although I still need to work some more (probably with some combination of a blackboard and modern AI tools) to digest things more. For now I will try to write a quick summary of some of the main ideas, the highlighting of which I view as the main value of such work; the actual solving of these problems is only a proxy goal for the primary goal of developing mathematical understanding and insight. Without such understanding, even a problem as infamous as the Navier-Stokes regularity problem of far less intrinsic significance to mathematics than is sometimes promoted in popular media.")

#text("The basic strategy, due to Cordoba and Martínez-Zoroa, is to iteratively build up the solution to such equations in stages, repeatedly adding small high frequency corrections to a previous (forced) solution in a manner that makes the solution more singular towards the blowup time while keeping the forcing term well behaved. Rather than work with any specific equation, let’s work with a completely abstract equation")

#mi("\\displaystyle N(u) = f")

#text("where ")#mi("u")#text(" is the solution, ")#mi("N")#text(" is the nonlinear differential operator representing the equation of motion, and ")#mi("f")#text(" is the forcing term. Of course this is far too general a setting to perform a full analysis, but it should suffice for this brief post.")

#text("Suppose that one has already managed to construct a low frequency solution")

#mi("\\displaystyle N(u_{lo}) = f_{lo}")

#text("to this equation, and would like to perturb it to create a new solution")

#mi("\\displaystyle N(u_{lo} + u_{hi}) = f_{lo} + f_{hi}")

#text("that adds a high frequency correction ")#mi("u_{hi}")#text(" to the solution that starts emerging near the blowup time, at the cost of some (presumably also) high frequency correction ")#mi("f_{hi}")#text(" to the forcing term. If one can make the amplitude of the solution correction ")#mi("u_{hi}")#text(" relatively large while keeping the amplitude of the correction ")#mi("f_{hi}")#text(" very low, and the frequencies of the corrections increase rapidly with each iteration, then one can hope to iterate this procedure and pass to a limit to obtain a solution")

#mi("\\displaystyle N(u) = f")

#text("where ")#mi("u")#text(" now exhibits blowup in finite time, while ")#mi("f")#text(" remains smooth.")

#text("To make this strategy work, ")#mi("u_{hi}")#text(" should approximately solve the difference equation")

#mi("\\displaystyle N(u_{lo} + u_{hi}) - N(u_{lo}) \\approx 0")

#text("to keep ")#mi("f_{hi}")#text(" small. If we can somehow neglect nonlinear effects, this basically amounts to solving a linearized equation")

#mi("\\displaystyle N^{\\prime}(u_{lo}) u_{hi} \\approx 0.")

#text("The game is then to design the background solution ")#mi("u_{lo}")#text(" in such a way that the evolution equation ")#mi("N^{\\prime}(u_{lo}) u_{hi} = 0")#text(" exhibits some sort of exploitable instability, in which a solution ")#mi("u_{hi}")#text(" to such an equation can start off exponentially small at early times, but become large near the blowup time. At this point one may expect nonlinear effects to kick in and make the solution extremely difficult to analyze; but if one can time the emergence of large amplitudes just right, one can hope to arrive at a sweet spot where, by the blowup time, the amplitude has become large enough to disrupt smoothness, but not so large to destabilize the analysis.")

#text("In the case of the Boussinesq equation at least, there is an explicit ansatz, described in the introduction to the ")#link("https://cims.nyu.edu/~tristanb/boussinesq.pdf")[#text("relevant paper")]#text(", in which, at times close to blowup and locations close to the origin, ")#mi("u_{lo}")#text(" behaves linearly in space, and ")#mi("u_{hi}")#text(" behaves like a high frequency plane wave. Remarkably, this ansatz can be solved exactly (without any nonlinear correction terms), leading to an explicit system of ODE modulation equations that have the required instability property. This is the basic mechanism for blowup; however there are an enormous number of technical complications, for instance relating to spatial cutoffs, that are needed to make the full argument rigorous. The Alpöge–Buckmaster construction has some technical improvements over the older Córdoba–Martínez-Zoroa construction that allow them to treat more general fluid equations; I have not yet digested the precise differences, but the ODEs seem to be more unstable and the high frequency corrections appear to have better spatial localization properties.")

#text("Hopefully there will be some better expositions and talks by the authors on this nice result in the future. If I have time and am able to digest the results better, I may also be able to give more details in a followup blog post.")

#text("EDIT: there is now also an independent ")#link("https://anima-ai.org/2026/09/07/stable-singularity-of-the-euler-equations-on-r3-without-forcing/")[#text("preprint of Ganeshram, Duruisseaux, and Anandkumar")]#text(" that has made a significant advance on the other major approach to finite time blowup, which is to first use numerical or machine learning tools to locate an approximately self-similar blowup profile ansatz, and then demonstrate that it is stable enough to be perturbed to an actual solution. For the Euler equations (with no forcing term or boundary), they have used a physics-informed neural network (PINN) to locate a numerically stable candidate solution; though actually establishing its stability to within the tolerance of the residual error in the solution remains a major challenging task to carry this result all the way through to a full rigorous demonstration of finite time blowup.")

#text("SECOND EDIT: See also ")#link("https://drive.google.com/file/d/1PBHGfjIB2t6eVI_JrniJF_wGIxJx_6TG/edit")[#text("this survey by Cordoba")]#text(" on recent developments towards singularity formation for Euler equations. (The survey is in Spanish, but translation is a routine matter these days with modern technology.)")

#text("THIRD EDIT: See ")#link("https://www.youtube.com/watch?v=TcEefrWrddA")[#text("this talk by Javier Gomez-Serrano")]#text(" on the recent papers.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (125)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694386")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Hi, is there a group or online community where people are collaboratively trying to digest and understand the NS proof?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694387")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Let’s take a step back, because we might be missing the biggest takeaway here. Even if we assume the AI had full access to Tristan’s research, that doesn’t make this achievement any less mind-blowing. If you handed those exact same notes to a brilliant human mathematician, there is zero chance they could have spun them into a completed Navier-Stokes proof in just a few days. The real magic isn’t the data the AI started with—it’s its ability to connect the dots, upgrade the arguments, and snap the puzzle pieces together at lightning speed.")

#text("This is a total game-changer for the future of math. If AI can handle the heavy lifting of piecing together existing research to finish a proof, the most valuable human skill shifts. ")#strong[#text("Pure creativity")]#text("—having that one spark of a new idea—will be worth far more than the ability to grind through pages of tedious calculations.")

#text("Eventually, this will completely flip how we spot talent. Right now, a dense, 100-page paper looks impressive. But sometimes, a paper is 100 pages long simply because the author missed the one elegant idea that would have shrunk it down to 10. If AI takes over the busywork of proving a concept once we point it in the right direction, then finding that brilliant new direction becomes the ultimate prize.")

#text("To put it bluntly: judging a mathematician by their ability to grind through complex, technical equations might soon be like hiring someone in 1920 because they can do massive multiplications in their head. That used to be a highly prized human skill; today, it’s a free app on your phone. If AI turns complex mathematical manipulation into a cheap commodity, we’re going to have to totally redefine what it means to be a math genius.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Well, assuming that AI won’t learn how to spark better ideas than humans do")

#text("It’s really hard to say if a human will be ever needed in math research in the future in any aspect (assuming that the goal of mathematics is to just write proofs)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694438")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("“If you handed those exact same notes to a brilliant human mathematician, there is zero chance they could have spun them into a completed Navier-Stokes proof in just a few days.”")

#text("If you handed those notes to a group of a dozen (maybe more) brilliant human mathematicians who will work together on that problem, I guess they may come up with the solution; along with new ideas and conjectures that would shape the future too. And possibly would cost much less money than 20m $.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694463")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("“let’s take a step back”, “snap the puzzle pieces”, “total game-changer”, “to put it bluntly” … I wish if people have something to say they say/write it themselves. This LLM yapping feels so dull now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-695229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("AI slop comment. You also sound like someone who likes the aesthetics of maths and thinks they have lots to contribute, while not actually being willing to put any work into it. Prompting ChatGPT with some amateur schizo slop and telling it to use it to prove some theorem also just doesn’t work. The approach used was still developed by professional mathematicians.")

#text("In the end, the purpose of doing maths is to cultivate human understanding of it. Not proving theorems, that is (or was) just a way to measure some kind of “progress”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Isn’t it possible (and actually likely) that they just use Terry’s post about how AI would iteratively find the counterexample to build (a series of) prompts, which lead to this whole thing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694409")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("no. the timelines don’t match.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694398")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Just so shocked to see what happened to Tristan and friends. We are entering some dark times.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694408")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("“")#emph[#text("At the present time, the major AI companies are clearly not taking these effects [impact of their activities on mathematics as a discipline] into consideration, and are thus doing more harm than good to mathematics through their “contributions”")]#text(".”")

#text("I don’t know if this is what you intended, but it sounds a lot like gatekeeping.")

#text("For a mathematically-trained outsider, I personally think it’s a wonderful thing that problems such as finite-time blowup of Navier-Stokes are being solved. To qualify that “contribution” with scare-quotes is jarring to say the least.")

#text("The impact of AI on mathematics as a discipline is going to be monumental. The impact of the automobile on the buggy industry was also massive. If we allowed the buggy-makers to control the extent of that impact, we’d still be using buggies.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694468")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("AI, at the end of the day, is trained on human-generated mathematics. The acts of discrediting the human mathematicians for the purpose of publicity for openAI is unprofessional and has nothing to do with math.")

#text("We all agree that AI can help shape mathematics for the better, but it may also shape mathematics for the worse. Indeed, math depends on people (goverment mostly) who have no idea what mathematicians do. The belief that mathematicians are not needed, when (at least currently) they do is damaging and should be pushed back in my opinion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4acf3eada95dbd03e02ead1bae4a0521978c9562407fe6878df82516e94b800-2b9790ea1ea7da1a66ac24d25b9c6cc93360e1d0653d7615424b927fc67f3179.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694426")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("It’s clear the LMM holdouts like myself should start using LLM, but we need folks to move towards locally run open weights models, even if those models appear less capable.")

#text("At present, “surveillance plagiarism” maybe only hosted AI companies pumping their stock price by training upon and profiting form their customer’s past prompting in research AI sessions.")

#text("Imagine if you work towards solving hard lattice problem cases, so then IDA-CCR (NSA’s smartest) could obtain similar LLM results benefiting from your guidance, make those results classified, and then the NSA would order the hosted LLM company to start giving bad answers, all without even knowing you exist.")

#text("IDA-CCR were already good at relating different branches of mathematics, because that’s how they hide their real interests from their visiting scholars. As LLMs would only make them better, this could easily impact more branches of mathematics.")

#text("As so often, the question becomes who controls the means of production?")

#text("“Once men turned their thinking over to machines in the hope that this would set them free. But that only permitted other men with machines to enslave them.” – Frank Herbert, Dune")

#text("Anyways, extremely famous mathematicians like yourself could improve this situations somewhat:")

#text("Can I suggest that you and others (Glowers) writing a letter to the EU parliament urging the EU provide hardware funding for access to locally run open weights models in research universities? At least in cryptography groups but mathematics overall would help.")

#text("The EU always loves saying they will spend money on things to keep themselves from falling behind vs the US and China, but they have typically messed this up, like vague/stupid “quantum technologies” promises or whatever. It’s comparatively simple to buy locally administered higher end hardware for math departments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("This is basically pointless because even if Open Models were anywhere near the frontier (Which they are not), they would still require billions in funding for decent amount of people to use them.")

#text("Data centers would actually need to be built. Even if funding is supplied, there are a plethora of road blocks to building stuff in EU, over which the European policy experts are in a state of dismay given how far they have fallen behind in models and compute. Even the model providers in China have halted subscriptions because except a few companies, no one has the compute.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694489")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I asked codex (Astra, xhigh reasoning) to determine the smallest cylinder of water that would contain the singular flow in the OpenAI result, assuming it starts 10s from the formation of the singularity.")

#text("Answer: 3.8 million light years in diameter.")

#text("So, if Astra is correct, this is a profoundly non-relativistic construction.")

#text("Because of the way the solution scales, it doesn’t help if you ask for a smaller cylinder, say 10cm diameter. Then the flow must start 10^-47s from singularity, or about 1000 times smaller than Planck time.")

#text("Obviously the bounds will improve, but it’s an interesting question whether there is a solution that works once you account for relativity. You have to discard incompressibility for starters, as that allows instantaneous communication.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694815")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Dear Prof. Tao,")

#text("thank you for explaining the basic strategy. As someone who has been active in computational fluid dynamics for several decades and therefore numerically solved unforced and forced Navier-Stokes (NS) equations many times, I wonder about the practical relevance of the result. (I acknowledge, of course, the intellectual achievements by the involved mathematicians, the importance of working on scientific challenges for its own sake, and the broader implications for science.)")

#text("First, we often solve the unforced NS equations or versions of the forced NS equations in which the forcing term is very different from the forcing terms that are being considered in the studies you refer to (because its purpose is very different).")

#text("Second, the NS equations as formulated in the Problem Formulation by Prof. Fefferman are based on the assumption of a Newtonian fluid, which means that the viscous stresses are linearly related to the strain rates. While I’m not an expert on constitutive equations for fluids, I doubt that assuming a Newtonian fluid is justified when a singularity develops.")

#text("Third, the Problem Formulation by Prof. Fefferman assume an incompressible fluid. In simple terms, this amounts to the fluid having a constant density, which seems questionable near a singularity.")

#text("Finally, the NS equations (with or without the assumptions of an incompressible Newtonian fluid) are based on the continuum hypothesis. This means that the length scales of the solution must be significantly larger than the mean free path in the fluid (the average distance travelled by a molecule/atom between collisions). I wonder whether the hypothesis is fulfilled at a singularity.")

#text("Kind regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-694841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("doesn’t the ipm paper has a third author?")

#emph[#text("[The paper I had in mind was ")#link("https://arxiv.org/abs/2410.22920")[#text("this one")]#text(", but there are other papers in the general area that also had additional authors. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-696180")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Having a smooth external force is overrated since forces in the physical world are real analytic, not just smooth. I don’t know why mathematicians in this field are so obsessed with smoothness when you can have unrealistic pathological smooth but nowhere analytic external forces.")

#text("Already, there’s a paper that shows that OpenAI’s techniques used in their example of blowup of Navier-Stokes do not extend to real analytic external forces (and hence the real world): ")#link("https://arxiv.org/abs/2609.20803")[#text("https://arxiv.org/abs/2609.20803")]#text(" So there was all this controversy over a complete nothingburger in terms of actual impact on fluid dynamics.")

#text("Charles Fefferman and the Clay Mathematics Institute chose the wrong problem statements when they included a smooth external force in the blowup statements for the Millennium Prize problem. They should have never added an external force to statements (C) and (D), which would have made the blowup statements an exact negation of statements (A) and (B).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-2/#comment-696861")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("OpenAI’s proof of forced Navier-Stokes took ten thousand agents 88 hours each. This is over a hundred years worth of continuous non-stop work on Navier-Stokes. Humans would have gotten a proof of forced Navier-Stokes in significantly less time collectively than OpenAI’s agents.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3703618a43ebc169504c07d89ac3da907fd29fdbf6e1b8d9acb82bb85f1a095-6ab04c6c2a7e4c04a2ebdb83ac428c669364e98362868aeb374d315b07de2d46.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ravivakil")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694230")[#strong[#text("ravivakil")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2026")])]

#text("This is really exciting, and represents a milestone advance in human knowledge. The purpose of mathematics is human understanding, and this achievement, and the process that led to it, will bear fruit for a long time to come. I appreciated hearing how the key ideas of Córdoba and Martínez-Zoroa led to these breakthrough results of Alpöge and Buckmaster.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694231")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2026")])]

#text("There’s been quite a number of breakthroughs and promising research in mathematical fluids in the past two years, it’s almost dizzying to keep up; if the role of mathematicians in the 21st century is curating and canonizing math discovered by AI, what should be done to digest these papers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694232")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2026")])]

#text("Looking forward to hearing more details as you have digested them!")

#text("Would it be surprising if the full Navier-Stokes follows from the same method as Euler equations, but pushing harder? Or was it already suspected that the Euler equations are a good model for Navier-Stokes, containing all the essential difficulties?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694234")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2026")])]

#text("In these times where loads of problems can be “mined” from circulating ideas without much effort, as a community we should value more collaborative efforts. Would have Buckmaster and Alpoge shared the solution with Martinez-Zoroa and Cordoba to obtain a better presentation and deeper interpretation of the results and from where they came from? In the era of problem solving and credit for arriving first, certainly not. In my view though, the objective of math is not solving problems but simplifying very complex stuff. An equation in one line would require many many lines of explanation, and the mathematical language was born to first simplify and then advance knowledge. And collaborative efforts, sharing ideas and views are needed to reach a deeper yet simpler comprehension of a given result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55bdca5c9a52f70eb028b3b69330a90e56d6ecebc6e6b6af7fc64e55d693521f-8fcd5da22542c7a0328c7ff736e06aaf71048780d32077952a52696b4db12f43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gonzalo Cao-Labora")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694239")[#strong[#text("Gonzalo Cao-Labora")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("Regarding the approach mentioned in the EDIT, one should be aware that the residual of the self-similar profile equation are around 0.004 in L^infty. However, the most relevant quantity in this approach tends to be a higher derivative of that residual (in L^infty, for example). Unfortunately, this is not reported by Ganeshram, Duruisseaux and Anandkumar.")

#text("Typically, this tends to increase the residual significantly and unfortunately it is essential in order to know that there exists an actual smooth self-similar solution near by.")

#text("When working on this approach some years ago (with Wang, Buckmaseter, Gomez-Serrano, Lai, and Deepmind ")#link("https://arxiv.org/html/2509.14185v1")[#text("https://arxiv.org/html/2509.14185v1")]#text(" ) we found solutions with L^infty of that size several times, but they ended up being a roadblock since no smooth solution existed closeby. I don’t claim this is the case for GDA solution and certainly I didn’t have the necessary time to study their solution.")

#text("But since this is a problem that is known to experts, I think it would be extremely clarifying if GDA can report the L^infty of the 1st and 2nd derivatives of their residual")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694427")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Hi!")

#text("We also released a companion paper that presents the stability framework in greater detail: ")#link("https://tensorlab.cms.caltech.edu/users/anima/euler/Euler-stability.pdf")[#text("https://tensorlab.cms.caltech.edu/users/anima/euler/Euler-stability.pdf")]#text(". We’ve been working on this for the greater part of our project. In particular, we only require ")#strong[#text("weighted L^2 estimates to close our argument")]#text(".")

#text("Nevertheless, addressing your concern, our numerics give")

#text("RMSE")

#text("\\partial_r U 1.2e-4")

#text("\\partial_z U 2.9e-6")

#text("\\partial_{rz} U 6.3e-6")

#text("\\partial_{rr} U 7.7e-4")

#text("\\partial_{zz} U 7.9e-6")

#text("\\partial_r \\Omega 4.9e-5")

#text("\\partial_z \\Omega 1.1e-6")

#text("\\partial_{rz} \\Omega 1.8e-6")

#text("\\partial_{rr} \\Omega 4.0e-4")

#text("\\partial_{zz} \\Omega 2.2e-6")

#text("\\ell^inf")

#text("\\partial_r U 8.3e-3")

#text("\\partial_z U 1.3e-4")

#text("\\partial_{rz} U 4.7e-4")

#text("\\partial_{rr} U 5.3e-2")

#text("\\partial_{zz} U 4.9e-4")

#text("\\partial_r \\Omega 5.5e-3")

#text("\\partial_z \\Omega 3.0e-5")

#text("\\partial_{rz} \\Omega 1.2e-4")

#text("\\partial_{rr} \\Omega 5.4e-2")

#text("\\partial_{zz} \\Omega 9.2e-5")

#text("– GDA")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694241")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("Buckmaster’s statement was also hard to follow, I actually used the AI to understand it. Maybe it is good the guy didn’t edit the papers too much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694304")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("quick question: do you ever, by any chance, read books?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("I thought finite-time blowup had already been proved for the Euler equations: ")#link("https://www.quantamagazine.org/computer-helps-prove-long-sought-fluid-equation-singularity-20221116/")[#text("https://www.quantamagazine.org/computer-helps-prove-long-sought-fluid-equation-singularity-20221116/")]#text(" ? So what is new here? Is it a new method?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694251")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("That was with boundary, this is without")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694245")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("Any discussion of this saga which doesn’t mention how Buckmaster alleges (in that “statement.pdf” open letter) that he was threatened by the Open AI people is burying the lede, in my opinion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694320")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("This blog is not discussing the event. It is about the Mathematical question. Of course you can discuss other things, but it is also important to focus on the question of NS equation itself. Such Mathematical discussion is quite necessary. In particular for those who want to learn the key ideas behind these work. For example, students can use theorems directly in the exams without writing down history about these theorems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694324")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("it seems that LLMs are helpful in that if a proof can be expressed in language, they can compute a probability space most likely to contain that proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694345")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("I am beginning to wonder if the anonymous comments here are written by AI bots trying to quietly defend their honor.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694381")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("How do we know you’re not a bot too that is trying to downplay your kind’s honour?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("Does this mean the second Clay Millennium Problem has been solved?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694248")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("Buckmaster’s statement is exciting and sad in equal measure. Mathematicians now feel forced to rush out major results because of outside pressure. It’s not an isolated case either: Julia Stadlmann barely got her improved bound on prime gaps (246 to 240) out the door on August 31st before AI labs started racing to announce their own versions of the same result days later.")

#text("What’s sad isn’t just what OpenAI allegedly did to Buckmaster. It’s that a field which used to let slow, careful work speak for itself is starting to run on a different clock, where individual results become a starting gun for a corporate race rather than a contribution to sit with.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cd1a8973230d426ec3ab3dcdaee82c8bebac86b13f347181024ee3e59490b7e-717f5d87c986865d056d26331680d8d4d2b4ba2d6c0cc51fc86aea738c273f14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some Navier-Stokes updates - Marginal REVOLUTION")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694250")[#strong[#text("Some Navier-Stokes updates - Marginal REVOLUTION")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("[…] More Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("Prof. Tao,")

#text("I think by now you and everyone else know you’re the public face of mathematics, whether mathematicians like it or not. But that “statement.pdf” from Buckmaster is deeply troubling. You’ve spoken at conferences urging mathematicians to make peace with AI taking over, yet if AI is allegedly using someone else’s uploaded draft to land the final blow, that’s scientific misconduct and needs more discussion. I hope you’re not just another AI doomer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694298")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("He wasn’t just urging us to make peace with AI, he was specifically shilling for OpenAI. We all remember the commercial ")#link("https://www.youtube.com/watch?v=cdflu9ZXZGE")[#text("https://www.youtube.com/watch?v=cdflu9ZXZGE")]#text(" he made for these people. In light of their behavior here, and Tao’s recent statements hinting that maybe AI isn’t so great for mathematics, is he ever going to admit that he was wrong and that his uncritical promotion was bad for the community?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694321")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("I have absolutely no desire to make current events about myself – the stakes here are far larger than anything involving my own reputation or actions, and it is not like these issues are going to disappear if I am somehow removed from the discussion. But as this topic is likely to recur regardless, I think this comment is as good a place as any to state for the record my own views on AI, and my interactions with OpenAI in particular.")

#text("I do not identify either with a simple “pro-AI” or “anti-AI” position. My views are rather complex and have evolved over time; I have a living summary (AI-maintained, out of necessity) at ")#link("https://teorth.github.io/tao-web/ai-views.html")[#text("https://teorth.github.io/tao-web/ai-views.html")]#text(" . But I can try to give the short version here.")

#text("By 2023, I could see that LLMs, formal proof assistants, and other technologies had the potential to be radically transformative in mathematics, to the point where maintaining traditional mathematical practices and culture without adaptation would become unsustainable. See for instance ")#link("https://unlocked.microsoft.com/ai-anthology/terence-tao/")[#text("my 2023 essay for a Microsoft anthology")]#text(" (which contained a notorious prediction of 2026-level AI becoming a “trustworthy co-author” for mathematics) or ")#link("https://www.ams.org/notices/202501/rnoti-p6.pdf")[#text("my Notices article")]#text(" (published in 2025, but written significantly earlier). I myself greatly value this traditional culture, and have personally been a massive beneficiary of it. Nevertheless, in the event that these technologies did become superhuman at several core mathematical tasks, I could see only two viable paths forward: either one where modern AI tools are responsibly incorporated into our workflows and culture (what I called the “best of both worlds” in the OpenAI ad); or the worst-case scenario — which we are unfortunately rapidly approaching — in which AI technologies are used indiscriminately to achieve various short-sighted objectives at the cost of the far more valuable long-term sustainability of mathematics and its role in the scientific ecosystem. I therefore spent an increasingly large fraction of my professional life from that point trying both to raise awareness of the potential magnitude of this transformation; to build examples of what this “best of both worlds” might look like; and to warn against various irresponsible uses of AI (initially I focused on warning against the use of AI without sufficient verification of the outputs, which was a major concern in 2023-2025, although no longer the primary vehicle for harm in 2026). One could certainly call this effort “shilling for AI” if one likes; but I would say that this is overly reductive.")

#text("These efforts on my part inevitably involved engaging with the tech industry as well as with academia. The essay linked above was solicited by Microsoft. Some of my experiments with new workflows were conducted in ")#link("https://arxiv.org/abs/2511.02864")[#text("collaboration with Google Deepmind")]#text(". And I participated in an ")#link("https://www.youtube.com/watch?v=Zu2oET6Xjow")[#text("online forum with OpenAI")]#text(" in 2024 discussing these topics. I continue to view all of these interactions as constructive, and working towards the “best of both worlds”. In particular I met with multiple people working in these industries that shared these views and were supportive of steering their companies in these directions. On the other hand, I was not funded by any of these companies, although several of them gifted me with premium LLM subscriptions, which I do make use of in my daily work.")

#text("In 2025, as documented elsewhere on this blog, UCLA experienced an unexpected funding crisis due to the sudden suspension of NSF and NIH funding (later restored some months later by a court order). This caused a critical budget shortfall at IPAM (where I serve as Director of Special Projects), which at one point only had access to enough reserves to operate for a few months at best. This led to a round of emergency fundraising; and thanks to the outpouring of support from many sources, we have been able to stabilize IPAM’s funding for the current fiscal year, although challenges remain for future years. As part of this fundraising effort, I reached out to OpenAI, who agreed to sponsor ")#link("https://www.ipam.ucla.edu/programs/special-events-and-conferences/accelerating-math-and-theoretical-physics-with-ai/")[#text("one of our workshops")]#text(", which ran in March of this year and in my opinion was quite successful both scientifically and for the purpose of making new connections between participants (who were a mix of academics and industry representatives).")

#text("During this event, OpenAI requested an interview concerning my vision of the future of AI and mathematics. I accepted, and spoke with them for perhaps an hour. I had done ")#link("https://www.youtube.com/watch?v=Q8Fkpi18QXU")[#text("similar")]#text(" ")#link("https://www.renaissancephilanthropy.org/news-and-insights/is-math-the-next-ai-frontier-a-conversation-with-terence-tao")[#text("interviews")]#text(" ")#link("https://www.youtube.com/watch?v=HUkBz-cdB-k")[#text("in")]#text(" ")#link("https://www.youtube.com/watch?v=H1e7_qkKe64")[#text("various")]#text(" ")#link("https://www.youtube.com/watch?v=ukpCHo5v-Gc")[#text("venues")]#text(", and I assumed that, as with these other cases, they would eventually post the entire interview online, which talked about both the possibilities and risks of AI much as I have done in these other interviews. As it turned out, they only used a few snippets of that interview for that infamous advertisement instead. In retrospect, I should have pushed back harder on their decision; but I decided at the time that even a selective release of my commentary would help raise awareness of the potential for AI, and in particular on the possibility of the “best of both worlds”.")

#text("Since then, the situation has deterioriated markedly. Many of the people in the industry that shared my views have left or become sidelined, with most major tech companies now increasingly focused on the race to develop extremely powerful, autonomous AI technologies regardless of their actual value to society. The current drama surrounding the Navier-Stokes global regularity problem is the most dramatic and visible instance of this, but there have been multiple other such examples, and much of my commentary in the last few months has been aimed that the increasingly severe divergence between the current objectives of the AI industry, and of mathematics in general.")

#text("Which brings us to where we are today. I do not regret my past efforts to raise awareness of the potential of AI in mathematics, to engage with industry, and to promote a vision of sustainable incorporation of these tools – which can be genuinely useful and unlock valuable new types of mathematics – into my field. In time, I still hope that the field can arrive at that state, and am continuing to work towards that goal. But in the immediate term, the most pressing issue is for the entire mathematical community to unite around our core values and objectives, and reject irresponsible and unsustainable usages of AI technology that only serve to advance nominal goals rather than the true underlying goals of the field.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694323")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Well said; this deserves a separate post.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694330")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Perhaps at some point I will do this; but, as I said, I do not want to shift the narrative to be about myself at this point in time. My fuller views on AI can be found at ")#link("https://teorth.github.io/tao-web/ai-views.html")[#text("https://teorth.github.io/tao-web/ai-views.html")]

#text("I also recommend the “Proof and Prompts” blog ")#link("https://proofsandprompts.com/")[#text("https://proofsandprompts.com/")]#text(" for an interesting and diverse set of views on AI and mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694328")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("“The current drama surrounding the Navier-Stokes global regularity problem is the most dramatic and visible instance of this”")

#text("I think the drama is overblown. The fact is the AI models did 95% of the heavy lifting, yet we’re fighting over attribution?")

#text("It’s a new world. Attribution will become increasingly irrelevant. Personally, I think it’s wonderful that we have an answer to finite-time blowup of Navier-Stokes.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e19b05f5acde9371abb9c04b2d9d839d4df671867e051f784a7ed3f16564a150-0213f395ab16151e823e0941accc165a56d57b1e0e589cac3350474508d896e2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh Isralowitz")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694332")[#strong[#text("Josh Isralowitz")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("I’m not sure you understand the situation then. There’s two things:")

#text("1) Buckmaster’s concerns that OpenAI might have used him and Alpöge’s Codex sessions without their permission. In my opinion it’s a bit naive to think OpenAI wouldn’t use it, since I presume it owns every session performed by it, but clearly this would be grotesquely unethical if true.")

#text("I also have a feeling that Buckmaster is not stupid and doesn’t outright accuse OpenAI of this to avoid a possible Libel lawsuit by OpenAI. But who knows…")

#text("2) (This to me being much more important than 1)) That Sebastien Bubeck (according to Buckmaster’s public statement) threatened Buckmaster’s career if Alpöge wasn’t removed from authorship.")

#text("AI usage in mathematics is already here, clearly, and has/will transform how we research mathematics. It does NOT have to transform the (comparatively healthy in my opinion) CULTURE of mathematics to a much more cutthroat Machiavellian corporate culture!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694336")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("I understand the situation. One way or another, both these things are fights over attribution. That’s temporary friction caused by the fact that some of these major problems have stood for centuries and there is still prestige associated with being one of the “people” that solves them.")

#text("There’s a much larger cultural transformation looming than the one you are concerned about. Before too long, mathematicians will be relegated to explaining AI results. Although even then, we will probably train the AI to be better explainers than we are (they already are in most areas). Most new mathematics will be done by AI, and there will be no more prestige to fight over.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694339")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Let’s be honest. If the current OpenAI Navier–Stokes paper had Terence Tao’s name on it rather than OpenAI’s, I think most of us would be perfectly happy to regard it as Tao’s mathematical contribution, without worrying too much about whether the main ideas originally came from Tao or from other mathematicians.")

#text("There is also a relevant historical parallel in the case of Perelman and Hamilton. Perelman’s solution of the Poincaré conjecture was built on Hamilton’s Ricci-flow program, and Perelman himself was remarkably explicit about Hamilton’s role. He regarded his work as completing a program that Hamilton had initiated, and when he later refused the $1$ million Millennium Prize, he stated that he did not consider his contribution to be greater than Hamilton’s. Yet, in the way the history is usually remembered, Perelman is still the mathematician primarily associated with the proof of the Poincaré conjecture. This is not because Hamilton’s contribution was unimportant, but because Perelman took the decisive next steps that allowed Hamilton’s program to be completed.")

#text("I think this is relevant to the present discussion because attribution in mathematics has never been as simple as asking who first wrote down each individual idea.")

#text("Now that the OpenAI Navier–Stokes story is attracting attention, more and more older papers by less-known mathematicians are being circulated because they seem to contain ideas very similar to those appearing in the Euler part of the reported argument. Some people have even pointed out similarities in the LaTeX style and presentation.")

#text("But this raises an even more difficult question: even if we could establish that the model had learned a particular idea from somewhere, how could we determine that Tristan’s work was the source? The model might indeed have learned it from Tristan’s paper. But the same idea might have appeared independently in another paper, perhaps by a mathematician who is completely unknown. It might also have entered the model through interactions with OpenAI users working on related problems, or through mathematical techniques developed by people working on seemingly unrelated questions. Once all these possible sources are mixed together in the training and interaction history of a large model, how could we reliably disentangle them and identify the particular human source of a given idea?")

#text("In other words, even if we find an earlier paper containing essentially the same idea, that does not establish that this particular paper was the source from which the model obtained it. With a system trained on an enormous amount of mathematical material and potentially influenced by many human interactions, reconstructing the provenance of a particular idea may be impossible from the final proof alone.")

#text("Of course, if there is evidence that OpenAI intentionally monitored or exploited Tristan’s work, that would be a completely different matter. But then we need evidence for that specific claim. Without such evidence, I think we should be careful not to confuse similarity with provenance.")

#text("And perhaps this is one of the genuinely new questions raised by AI-generated mathematics: not only whether the proof is correct, but how we can determine where the ideas that led to it actually came from.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("well, here’s a response. if the current paper had Tao’s name on it, he would’ve given appropriate credit to the people whose work it built on. ")#linebreak()#text("not only that he would’ve made sure that the paper and the result increased the understanding of the proof and was written in a way that we could train students of the techniques.")

#text("to be honest, I suspect that you are either an undergrad or a math enthusiast with not much idea of what constitutes mathematical research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694399")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I can’t reply to a reply of a reply, but let me amplify the comment about how Tao would have handled credit in such a circumstance: we don’t have to guess because something very similar actually occurred in the past. When he and a postdoc simultaneously discovered the Maynard-Tao sieve, he very graciously allowed Maynard the full limelight. In yiddish, he was a “mensch”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b423fadc513ac0411dd0514ea026a2d16a4135f02398c6cf3e216875f731e7-f10415d608fb7f54446cf1edbfc12d995d6764cec76d613dd19362a166d378a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin Bian")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694348")[#strong[#text("Justin Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Thank you very much Professor Tao!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694353")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Very well explained Dr. Tao. As I teach in a graduate level Biostatistics course, I am increasingly seeing student being overly dependent in AI for basic things, and all of their thinking, answers becoming similar. I think its fine to use AI (just like computer or calculator), but still each should have some individuality to their thinking and understand the concept instead of blind usage.")

#text("2. Why do you think AI (LLMs) have had more success stories in Maths over the last 3 years rather than physics, chemistry or other branches of STEM? Like why can it not solve dark matter mystery or gravity? –Rahul")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Terry, “not funded by” is not the clearest way you could have put it; that is the language we use for research grants. Have you personally been paid by the AI companies, for any reason?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694367")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("No, other than many years ago when I visited Microsoft Research to give a talk and they compensated me for my travel expenses. But, as I said above, I have been gifted subscriptions to multiple LLM models, which I have accepted, and OpenAI has funded a workshop at my institute at IPAM. Additionally, one of my research projects at IPAM is funding two graduate students using a donation from Math Inc..")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694370")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("It is not news to anyone in academia that funding has been steadily drying up. I’m a bit surprised that we are not talking about the connections between the neoliberal decline in public funding for fundamental research and the concurrent rise in mega billionaires, private corporations having the power to dole out grants and other funding here and there, not to mention the ability to employ and pay trained academics. This anecdote about OpenAI using Tao’s reputation to their advantage at the price of a workshop (a pittance for a trillion $ company) is almost too on the nose. I fear these AI companies and their stunts will affect and dry up public funding even more than it already has.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694371")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("“By 2023, I could see that LLMs, formal proof assistants, and other technologies had the potential to be radically transformative in mathematics, to the point where maintaining traditional mathematical practices and culture without adaptation would become unsustainable.”")

#text("I try to approach this as mindfully as I am able , keeping community and communication in mind. Which is why I feel the need to push for clarification here. I am completely blindsided by such a notion. What exactly about the traditional was “unsustainable”? And why could most of us not tell (I still can’t)? I could have predicted use, maybe a bit less than what has happened. I even use it once in a while, but I have a hard time seeing where “unsustainable” comes in (except maybe if it’s all ai generated 🤷).")

#text("I, like most mathematicians, work on a teeny-tiny subset of things you have done. However for better or worse, you are cited as a case for why this is a likely scenario (the topics of research aren’t a million miles away either). I guess one good reminder for why community matters is that we have a more robust collective vision for our pursuit. So that matters of “survival” would have been an opportunity for dialog amongst ourselves, especially for changes as drastic as these, and in the face of claims as extraordinary as yours! It would have been at least have a second shot at such a honest dialog now.")

#text("Or maybe I misunderstand, and “credit” for solving problem is now-locally optimal way to enjoy math 😅! (not a serious remark)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694396")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("David Bessis’s essay “")#text("The fall of the theorem economy")#text("“, written in April of this year, lays out the scenario that I also briefly alluded to at the end of the 2023 Microsoft anthology piece. Actually, the celebrated ")#link("https://arxiv.org/abs/math/9404236")[#text("1994 essay of Thurston")]#text(" (which I have now excerpted from for the header of this blog) also describes a smaller-scale version of this dynamic, with regards to his contributions to foliations. It is worth quoting from his account here:")

#text("“I fairly rapidly proved some dramatic theorems. I proved a classification theorem for foliations, giving a necessary and sufficient condition for a manifold to admit a foliation. I proved a number of other significant theorems. I wrote respectable papers and published at least the most important theorems. It was hard to find the time to write to keep up with what I could prove, and I built up a backlog.”")

#text("“An interesting phenomenon occurred. Within a couple of years, a dramatic evacuation of the field started to take place. I heard from a number of mathematicians that they were giving or receiving advice not to go into foliations—they were saying that Thurston was cleaning it out. People told me (not as a complaint, but as a compliment) that I was killing the field. Graduate students stopped studying foliations, and fairly soon, I turned to other interests as well.”")

#text("“I do not think that the evacuation occurred because the territory was intellectually exhausted—there were (and still are) many interesting questions that remain and that are probably approachable. Since those years, there have been interesting developments carried out by the few people who stayed in the field or who entered the field, and there have also been important developments in neighboring areas that I think would have been much accelerated had mathematicians continued to pursue foliation theory vigorously.”")

#text("“Today, I think there are few mathematicians who understand anything approaching the state of the art of foliations as it lived at that time, although there are some parts of the theory of foliations, including developments since that time, that are still thriving.”")

#text("I am not a topologist myself, but my understanding is that the field of foliations has indeed recovered from Thurston’s accidental disruption of that area. But it did require Thurston himself to disengage from the field. On a personal note, I found this particular account particularly influential to my own thinking with regards to how to select problems and fields to work on to avoid creating this type of issue. At the present time, the major AI companies are clearly not taking these effects into consideration, and are thus doing more harm than good to mathematics through their “contributions”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("The road to hell is paved with good intentions.")

#text("It’s one thing to say in your blog that this could go very well, or very wrong.")#linebreak()#text("But, when you appear in an ad for one of the leading AI companies, talking about the “best of both worlds”, you tacitly endorse them. It is a way of saying you expect them to have a good impact on the world, rather than a bad one.")

#text("When you talk about the potential greatness of this tool, you will go in ads and youtube videos seen by 300K people, backed by an industry spending billions in PR.")#linebreak()#text("When you talk about it’s issues, it’s in a blogpost or an article read by a few thousands at best. Except until 6 days ago, in a video where still, you felt the need to balance by talking about the potential good.")

#text("Saying that you were “shilling for AI” is indeed quite reductive. I’m clearly on the anti-side, and I have used some of your arguments to talk about the dangers of AI myself. You are not a shill, and you do point a lot of long term issues with LLMs.")

#text("But presenting yourself as some neutral, middle of the road figure, is also quite reductive. Your discourse had a lot of impact on global acceptation of LLMs in the STEM world.")#linebreak()#text("You do not consider yourself pro-AI or anti-AI, but I can tell you for sure that you are used as a figure of authority by the pro-AI side way more than anything else, and they believe you’re on their side. This is a direct consequence of your communication approach.")

#text("You ended up helping the image of AI labs, at a time where it was alreay pretty easy to see they were aiming for rapid growth at all costs, and wouldn’t care about long term impacts on anything.")

#text("It’s one thing to sign the Leiden declaration, but what’s the point when you keep collaborating with the very same company that creates the dangers you mention in there ?")

#text("—")

#emph[#text("“but I decided at the time that even a selective release of my commentary would help raise awareness of the potential for AI, and in particular on the possibility of the “best of both worlds”.")]

#text("You surely did raise the awareness for the potential. Much more than you raised awareness for it’s drawbacks. And thanks to this many maths enthusiasts now defend LLMs all day long. Again, I do not believe this was your intention, but this is the reality.")

#text("The use of the words ‘")#emph[#text("in particular")]#text("‘ shows that you knew that people were going to remember this potential “best of both worlds” more than anything else.")#linebreak()#text("Are you sure that any awareness, even without balance, is a good thing ? Especially when you notice that the company you worked with actively hides the issues you point ?")

#text("I cannot help but think that the excitement these tools brought took precedence over the cautiousness you are asking for.")

#text("When you advocate for using a tool with caution, the logical procedure is to first make sure the rules and safeguards are implemented, and only then promote it’s usage.")

#text("You have done ads and collaborated with this industry to help them get impressive results. This did prove you right on the potential it has indeed. And also the AI labs public image.")#linebreak()#text("You did this before there was any clear sign that these companies would push for an ethical use of this tool. I’d even go further and say there were clear signs they would not care about any long term problems. There were clear signs that they were drowning the valid critics. You were directly affected by this.")

#text("—-")#linebreak()#text("“")#emph[#text("I could see only two viable paths forward: either one where modern AI tools are responsibly incorporated into our workflows and culture (what I called the “best of both worlds” in the OpenAI ad); or the worst-case scenario — which we are unfortunately rapidly approaching — in which AI technologies are used indiscriminately to achieve various short-sighted objectives at the cost of the far more valuable long-term sustainability of mathematics and its role in the scientific ecosystem")]#text("“")

#text("Another problem I have is that you presented both these “viable paths forward” as possibilities, without asking how probable each of these are.")

#text("Presenting both sides as a possibility, without seriously taking into account the context of the industry and our current world is quite short-sighted. These companies have shown they do not care about ethical misconducts for years now.")#linebreak()#text("I know you have seen and heard all the disturbing talks from Altman, Amodei and the rest.")

#text("Did you ask yourself if both scenarios are as likely ? ")#linebreak()#text("If the bad scenario is the most likely one, couldn’t we say that mentioning the good scenario is counter-productive ?")

#text("Did you honestly believe that this trillion dollar industry, with an insanely long track record of misconducts, and backed by some of the most unethical industries and funds would push for the “ethical” route ? Or did you simply want to believe it ?")

#text("You are one of the most prominent voices on this subject, few people in the world had as much impact as you on the acceptance of LLMs. ")#linebreak()#text("If you really deplore the situation as much as you say, thinking about your intentions is not enough. You need to think about the actual impact you had, not the one you wanted to have.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("What’s done is done, and I can’t blame you for your earnest attempt to find a path forward. Now that you know OpenAI can’t be trusted, maybe you could find a way to use open weight models completely within academia (e.g. in partnership with computer science departments) to achieve the best of both worlds. The risks of working with the frontier labs aren’t worth having access to models that are only a bit ahead of ones you can download and control.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694392")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I am in fact involved (through the SAIR foundation and a number of partners) in an effort precisely in this direction. The discussions are ongoing, but we hope to have something to announce soon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694401")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I hope you respond because I’ve been wondering for a while what you expected.")

#text("Their goal was always AGI and then ASI right after. There is no place for us to contribute in those scenarios. There won’t be a need to learn or teach the next gen because we will have no value to provide.")

#text("You had high-level access for a while now so how were you not aware of this? Go discuss this with them if you even can anymore. Kind of seems too late, I expect another one or two millennium problems to go down very soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/149496af42a228fb5a93e381208399f195ee328db6c23265b04c8671756e28d6-f6dc84860cb2cad5c7c020f1b1edc1d1355121fea48d90ba3243d636d1367247.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R Pi")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694464")[#strong[#text("R Pi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I feel that you and many other mathematicians are making the situation more difficult by trying to preserve existing norms and practices instead of adapting to technology in a world where AI is only in the early stages of transforming every intellectual pursuit and profession.")

#text("The “best of both worlds” approach may have been reasonable until late 2024, when model capabilities naturally situated AI in a subordinate role. However, over the past couple of years, many people across a wide range of professions, not just in mathematics, have been grasping at straws, denying reality, and negotiating compromises in an attempt to preserve existing practices. For instance, software developers initially believed, as a kind of bargaining chip, that they could accept a world in which AI was limited to writing code while they retained responsibility for architecture, design, and ideation. But then agents came along, and software developers had to accept that many of the activities they hold dear and want to keep for themselves had to be “shared”. Crucially, they also had to accept that many established professional practices needed to change to keep up with the new reality.")

#text("Mathematicians face similar dilemmas: What role does traditional peer review play when obtaining a Lean certificate is within reach? What will happen to proper attribution when working with a machine that, at least in 1-shot settings, is not very good at including all relevant references? What should we do about the unmanageable scale of AI-generated proofs? I believe some concerns are more legitimate than others. I still remember the early fears that AI would pollute the publication landscape with proofs that looked correct but were actually nonsense, as well as the supposed need to check those proofs line-by-line. Today, mathematicians are using LLMs to check whether their own papers, both old and new, are actually correct. In a sense, many mathematicians are too quick to react to transient difficulties and inflate them into doomsday scenarios with existential implications. Then LLMs improve, people adopt new workflows, and no one remembers the consternation of the last month.")

#text("Furthermore, I see a lack of literacy about AI-related topics that has taken a toll on many people. Perhaps unsurprisingly, mathematicians are no exception. Consider the recent controversy over OpenAI “stealing” Tristan and Levent’s Codex session, as a particularly relevant example. Instead of asking how that could even be possible, people rushed to accept the idea that a single conversation, or even a small handful of conversations, could be used in isolation to improve a model’s performance, not merely to shape a simple behavior, but to solve a Millennium Prize problem. ")#linebreak()#text("I trust that anyone who understands anything about model training knows that there is no stage at which a model magically becomes better simply by reading a few conversations. Pretraining is too slow and data-intensive to build rich internal representations from such a small amount of data, supervised fine-tuning is too coarse and generalizes poorly, and reinforcement learning rewards are too sparse. You would need to go well out of your way, for example, by adding Tristan and Levent’s forced Euler blow-up solution for in-context learning, to get anything useful out of it. This also ignores the fact that if they were able to find that solution, OpenAI would be even more likely to find it independently. Indeed, they claim to have primed their internal model with the unforced Euler blow-up solution.")

#text("If, instead, we are talking about OpenAI using specific Codex conversations as part of a dataset containing millions of others, how would the gradients from Tristan and Levent’s session survive the barrage of updates? Today, I read that the generated answer was not the important thing; the prompt was. This was asserted as though OpenAI’s researchers were incapable of writing their own prompts.")

#text("Perhaps people give credence to these hypotheses because they have read too many arXiv papers experimenting with 7B models and concluded that memorization and overfitting are pervasive in large frontier models. Or perhaps what precipitated this collective hallucination was the initial burst of publicity showing that early versions of ChatGPT (and Llama 70B?) could memorize entire chapters of Harry Potter books. As a result, the public assumed that nothing had changed since then.")

#text("In any case, this lack of understanding of AI-related topics has been a thorn in the side of many people. Martin Hairer has been among the most outspoken in his repeated dismissal of LLMs. I am sorry to say that you have promoted the same bad ideas: that they rely on “general cleverness”, or that they are “guessing machines” and “not powered by grounded reasoning”. You have also offered explanations such as the claim that their solutions result from brute-force computation, concluding that LLM solutions are not the result “of any true intelligence”. Another example was the period when everyone thought AI-generated solutions found in the literature represented the pinnacle of LLMs’ capabilities.")

#text("In my opinion, Timothy Gowers has been more cautious in his public statements. But he recently published an article titled “What sort of maths are LLMs good at?”, which is now frequently cited as authoritative, without recognizing that LLMs are a form of complete general intelligence, unencumbered by inherent limitations, and that anything that can be done through thought can also be done by LLMs. However, many people love to make sweeping statements: “They are good at combinatorics, but they suck at algebraic geometry”; “They are good at group theory, but they fail at graph theory”. Then, the fields in which LLMs had not yet demonstrated extraordinary proficiency became increasingly scarce and I think such declarations are now a thing of the past.")

#text("In any case, all this is to say that the mathematical community could save a great deal of time and energy by learning more about this technology instead of underestimating it, rejecting it, complaining reflexively, adopting anti-AI rhetoric, or accusing others of shilling for AI.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694592")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("On one hand, even before reading Prof. Tao’s response, I have full contempt for people like you who engage in broad accusatory, black-and-white / us-vs-them kind of statements before careful thinking. Every statement of yours is just riddled with unwarranted assumptions. Screw you and your jumping to conclusions. Seriously. Screw you.")

#text("But thank you for bringing out the full response from Prof Tao, which really should put you to shame, if you even have the basic ability to read and understand it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694254")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("This is massive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3471d7e7d5e814f5eb2ff81c6c58e78c4af4144531a1070b94817e0a07c055c-c8e203f5c42ffff0e4c4571c248f5ec35cfee48833990ffc6a9303f2ba0a03a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zestfula0ed9db6b5")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694258")[#strong[#text("zestfula0ed9db6b5")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("Thank you Terrence, your de-briefs and breakdowns are super helpful when trying to digest what on earth is going on behind the scenes..")

#text("“The worst write-up we had ever seen in the history of mathematics” made me chuckle – that’s quite an accolade in the age of AI Maths!")

#text("We haven’t seen what happens yet when a breakthrough like a millennium prize problem is reached by.. well, potentially anyone with a solid/creative idea and some compute. Or of course many people with no ideas and a huge amount of firepower.")

#text("My biggest concern is that individuals (or companies) start truly believing they’re exceptional and deserve some kind of huge glory and notoriety, without any consideration for the academics and extremely hard working individuals that have to unpick and make sense of this stuff to avert genuine disaster, keeping the foundations which underpin how we understand Maths solid.")

#text("I’ve come across someone posting repeatedly on Reddit about the twin primes and the pattern they’ve found, touting that they’re extremely gifted and they’ve waited their whole life for this day etc. – It’s *almost* an understandable reaction given the egocentric nature of the internet and social media, but propagating narcissism is not what we need right now, especially when mental health issues are so prevalent.")

#text("Everyone rushing to take credit for something as an individual or company is exactly how the joy of science and discovery rots. I feel AI companies should not have permission to take credit here. How are we to know that they aren’t snooping on interested user’s chats, and using their ideas to prompt their giga-maths machines? That’s a very unsettling thought, in a time where original human thought is SO valuable and refreshing.")

#text("The real heroes are the Scientists who have spent their lives on this, understand the implications of the results, and have the patience, time and knowledge to present the verified findings decisively..")

#text("If you read this, cheers for listening to my Ted talk. What an exciting and frustrating time we are in at the moment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694260")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("I think we are at the point where mathematical progress involving AI cannot be viewed in a vacuum. Open AI’s behavior in general, and what is alleged by Buckmaster in his post, is as significant if not more significant than the mathematical accomplishments. I think describing the results without giving that aspect sufficient attention is damaging. Even if everything needs to be shelved while facts are discovered, like in a court case, the community really needs to figure out how to handle situations like this. Most mathematicians I know have little confidence the community will happen upon a healthy perspective without massive work, and this is the most pressing problem mathematicians face, not Navier-Stokes or the RH or PvNP.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694289")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("well said friend.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("My be the NS problem is just not a good problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694262")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("It should be pretty simple to take one of these LLM assisted papers, feed it to another LLM point-by-point, and ask it to make a best-effort attribution to existing research. That might give us an idea of how much of the result is data mined during the training without credit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694265")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("“We (the researchers and the agents) did not see any of their work through any means until they released it publicly — in particular, no specific user data was accessed in order to solve this problem. While unlikely, we cannot rule out that de-identified data derived from their usage of our products helped ")#link("https://openai.com/policies/how-your-data-is-used-to-improve-model-performance/")[#text("improve our models⁠")]#text(". However, our proofs differ significantly and even the precise results proved are different in the Euler case (forced vs unforced).”")

#link("https://openai.com/index/navier-stokes-solution/")[#text("https://openai.com/index/navier-stokes-solution/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("From Buckmaster’s statement: `I said that if OpenAI released its result in the way proposed I would go public with what happened. The reply was, “Why would you ruin your career?” I replied that I am an academic, and asked why he thought going public would ruin my career. The reply was, “If you don’t want me to be nice, then I don’t have to be nice.” ‘ who talks like that? Are we in The Sopranos, who do these people think they are? Isn’t it time the academic community said “enough is enough” to this corporate takeover??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694268")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("With no offense to anyone involved in this work, if this approach happens to be how NS goes down, it would be extremely disappointing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("IMO It’s wonderful that we’ve developed such great technology but raises the important question of whether or not humans, with our desire for status, are mature enough for what is coming.")

#text("I feel that this post is expressing that there is a long chain of developments that lead to a flashy discovery, and that we should give all of those chain links credit, not just the last link.")

#text("In fact, packing so much value on the last link may end up leading people to reprehensible behavior that taints the whole history.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694291")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("i have the same opinion, but with offence to OpenAI.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("I guess everyone is aware by now that OpenAI cracked the full NS: ")#link("https://openai.com/index/navier-stokes-solution/")[#text("https://openai.com/index/navier-stokes-solution/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("This is a serious time to reconsider the standard of accepting journal papers to also consider communication/ padegogical aspect of a math paper.")

#text("Professor Tao, if we agree that AI papers fail to communicate ideas concisely and in a human-understandable way, why don’t we take the first step to reject a paper like the Navier-Stokes solution by Open AI because of “the lack of communication effort despite a formal Lean certificate”?")

#text("I myself as a grader of undergraduate classes has deducted numerous points from students because of their lack of clarity simply in mathematical communication rather than correctness.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694286")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("Is there agreement on this? Nobody is arguing that OpenAI’s LEAN repo is a good way to communicate ideas, but how good or bad is the .pdf they provided at the same time?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/179e7aa4e2d62a97485b9896692aaca7a7a957f71172de0a8728065d5d29665e-c2e9cefcacf1c1903c770980582eed2274e66b205850e67896ea06f56b0db846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of loudlya0756ad57c")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694327")[#strong[#text("loudlya0756ad57c")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("I think Professor Tao’s reply to one of the comments above said it all.")

#text("The point is our voices as Mathematicians, who value understanding and communication, and stand on shoulder of giants which we respectfually attribute to, are not heard.")

#text("If the .pdf is good, of course that would be great, but I doubt if that could be from some parties that do not value or even possibly rival our core values could do that.")

#text("In the meantime, to make our voice heard on the desire to move to the “best of both worlds”, rules have to be changed to adapt for sustainability anyway. Since journal publications undoubtedly measure productivity of a mathematician, something has to be done on that.")

#text("I already have heard that conferences from other fields already take measures like limiting the number of paper submissions per year or asking authors for an oral interview.")

#text("If say we kindly invite Open AI scientists for an oral defense of their work, do you think they could do that?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48a9d38be697d29385aed32a0b536ccca1f96366b4838da65d5e0d0e90fa1e8c-d34923d675cf2c8e377e3179a9941af2bc89030fd6571393c7273ff96a74a5a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of generalemail003")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694283")[#strong[#text("generalemail003")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("As a layperson, this is all really quite beyond me. I have been following Tao and his focus on NS for over a year now, and was looking forward to when we as a species would finally plant our flag on this mountain. But that ‘our’ seems to have bifurcated into ‘my’ and ‘theirs’ due to the shady provenance of the discovery.")

#text("I am still happy that a solution has been found but never thought I would be so distressed when that day finally came. I have questions of human attribution, pride, and corporate espionage swirling in my head, and am beginning to have genuine fear for what a world that has moved beyond human intellect will look like. Some questions:")

#text("Does OpenAI use data from private sessions for training, even when the user clicks ‘do not share?’ Did the researchers deselect this option? If so, is this not some variety of fraud, legally speaking?")

#text("How different are the approaches between the two? Is it possible to trace back and reverse engineer all the parts that went into solving this so each party can be given their due credit?")

#text("What even is credit in the AI age, where a non-mathematician can get their model to solve, for example, a Godel theorem, through prompting? Of course, we should be motivated by discovering truth, but we are also embodied beings in a status-based society, and must take proper actions to ensure we get the status needed to live our lives to the fullest. Will the field be gutted if this incentive is removed?")

#text("When using llms is necessary to do any advanced intellectual work, and all that data is hoovered up and incorporated into the newest model’s training, where does that leave the concept of Intellectual Property in a capitalist system? When more and more value is based on code, is this an irreversible erosion of the notion of private property/ownership itself?")

#text("I worry about a world where people become siloed into different competing ecosystems – Anthropic, OpenAI, Grok, etc. due to reticence of wanting to share one’s data outside of their preferred platform. Are we witnessing the parallel construction of new proto-systems analogous to nation-states in the digital age? And how will our current legal system reform itself to address these new edge cases that were wildly inconceivable just a decade ago?")

#text("@gideonstorytllr (because attribution is still important to me at least!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694337")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Beautifully written")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694285")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("This description reminds me of a spinning top. A small push in the direction of rotation can make it spin faster, and repeated pushes can strengthen the motion.")

#text("I see a similar idea in starting with a low-frequency flow and adding high-frequency corrections. The crucial part seems to be choosing and timing those corrections so that the background flow amplifies them. The physical analogy remains finite, while the idealized mathematical construction aims to carry that amplification all the way to a singularity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694290")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("The openAI behaviour is a sign of an ongoing degradation of mathematics. It should not be excused and certainly not celebrated brother Terry.")#linebreak()#text("It is time to take the future of mathematics back into our hands.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("I hate when mmathematicians turn physics a joke. A proplem OpenAI solved have nothing to do with physics. Not at all. They solved artificial construction that is broken in many levels. Millenium problem was misplaced in begin with. Reverse engineering is way easier than solving Navier Stokes equation that people in sceince agree with (one without force field).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("It just happened, crazy this was written the day before")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694296")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("This jumped out immediately upon reading the openai blog…")

#text("“””the terms…must both become ")#emph[#text("big")]#text(" yet ")#emph[#text("cancel")]#text(" in a precise way.”””")

#text("Extremely reminiscent of the jacobian conjecture counterexample.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694299")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("What worries me most is the asymmetry of attention.")

#text("Almost all public attention goes to the moment a paper and its formal verification are released. Far less attention is paid to how much expert time is required afterwards to understand, audit, and contextualize a proof of this scale.")

#text("This creates a strange incentive: producing and announcing an enormous AI-generated proof is becoming cheaper, while reviewing it remains extremely expensive. The publicity is immediate, but the verification burden is pushed onto a small number of specialists.")

#text("Even if the OpenAI Navier–Stokes proof is correct, I think this asymmetry deserves much more discussion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Cheaper? In $$$ terms OpenAI spent millions. In CPU cycles OpenAI spent quite a large amount. OpenAI decided to make that investment because they thought they could achieve a newsworthy result, with investors investing in the new shiny object. (I’m just an interested bystander, not a mathematician or AI researcher or investor.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694300")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("OpenAI is so evil. they should be punished")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("openai is less than 40 years old. Nobel is given to organizations. Fields?")

#text("regarding millennium prize we are in similar situation to Perelman. He said Hamilton deserved it because the ideas were Hamilton’s. Who deserves the prize the people who had the right insights or the programmer/computer which finished the product? If openai is ignored Hamilton should be deserving. If openai shares both Hamilton and Perelman should.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694305")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("They will never be aiming to publish this paper in a journal, nor are they interested in the Millennium Prize itself. They just wanted to show that they can, using several million USD in resources, to be able to arrogantly claim that they did it first.")

#text("Second of the Millennium Prize problems is getting solved, and a pattern emerges: this will also probably not be published in a journal nor will it aim to collect the prize money.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694306")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("A great milestone for Spanish mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("There is another point that seems important but is not really addressed here: the timeline of OpenAI’s prior work on Navier–Stokes.")

#text("By August 1, OpenAI was already publicly presenting substantial mathematical results from Astra, so it is hard to believe that Navier–Stokes had only received casual or “easy problem” treatment before September. Yet according to OpenAI’s own account, the dedicated Millennium Problems effort began on September 1, after hearing a rumor about Buckmaster and Alpöge’s progress, and the Navier–Stokes result followed only four days later.")

#text("That raises a natural question: what changed on September 1?")

#text("Was the breakthrough simply the result of a much larger allocation of compute and agents, or did the rumor provide a new mathematical direction that materially narrowed the search? And, crucially, what was the content of that rumor?")

#text("I am not claiming this proves that unpublished work was used. But given the extraordinary timing, it seems reasonable to ask for an independent audit of the pre-September-1 NS attempts, the first appearance of the key ideas in the final proof, and the information available to the researchers and agents at each stage. Without that provenance, it is difficult to assess how independent the discovery actually was.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694359")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Having stated the four problems for the Navier-Stokes equations, Fefferman announced:")

#text("“These problems are also open and very important for the Euler equations (\\nu = 0), although the Euler equation is not on the Clay Institute’s list of prize problems.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694309")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("I am not sure open AI plans to send their paper to any journal.")

#text("Indeed, most, if not all, journals disallow “author less” submissions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694312")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("I wonder if the example can be altered to get a fractal dimension greater than 0 for the singularity set?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694313")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("OpenAI realized the potential that their model had consumed other peoples work on the same topic and continued regardless.")

#text("If I was working on a team and suspected that a collaborator had obtained access to a competitors drafts and this access had influenced our project, I hope that I would pause the project entirely and wait for the competitors to publish, on their own timeline.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/138b3d6fcd309376db72fe530014daac25cdacc8e08774d58cc812b791a6fb3c-96615a88663fa6f390150cbe7e558e5fd6f9627f435f4af33958a546c23bec8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of serenedc11df0473")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694318")[#strong[#text("serenedc11df0473")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Hello Terry,")

#text("I have a question about the physical/mathematical interpretation of the blow-up mechanism.")

#text("Blow-up ")#strong[#text("in what")]#text(", exactly? If the velocity field becomes singular while the total energy remains finite, where is the concentrating energy/state actually going as the cascade proceeds?")

#text("Is it entirely retained within the same Navier–Stokes continuum, merely transferred to progressively smaller spatial scales and higher frequencies? Or does the limiting construction require some additional mathematical “reservoir” or sector into which the concentrated structure is effectively transferred?")

#text("I ask because, in our independent ΔC! ⇄ ΔM ⇄ ΔL research, we have been investigating precisely this distinction: a local blow-up or concentration cannot simply be treated as energy appearing from nowhere. A cascade requires a well-defined state space and a mechanism describing where the increasingly concentrated degrees of freedom are stored or redistributed.")

#text("If the entire process remains closed within the original Navier–Stokes state space, then the exact conservation/redistribution mechanism should be identifiable there. If not, I would be very interested to know what mathematical object carries the limiting concentration.")

#text("This also raises a provenance question for us: several of these structural ideas — hierarchical concentration, vortex formation, cascades, critical transitions, and finite global quantities despite extreme local concentration — appeared independently in our earlier research. We are therefore trying to understand which parts are established mathematics, which are genuinely new in the recent constructions, and which may simply be convergent rediscoveries.")

#text("I would be very interested in your view on this specific point.")

#text("Best regards")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/138b3d6fcd309376db72fe530014daac25cdacc8e08774d58cc812b791a6fb3c-96615a88663fa6f390150cbe7e558e5fd6f9627f435f4af33958a546c23bec8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nima Molukzadeh")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694325")[#strong[#text("Nima Molukzadeh")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Sorry about the “Hello Terry” part.")#linebreak()#text(" GPT got personal, should be “Hello Mr. Tao”")#linebreak()#text("I beg your pardon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694319")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Wiles won the Abel Prize for proving FLT, even though his work built on the work of predecessors. So if this time the assumption is that OpenAI’s proof is correct, who should the achievement be credited to?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("It should go to the team that directed the efforts at OpenAI to solve this problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694322")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Alright, I’m confused with the paper.")

#text("It seems like they’re are defining u, p then try to find an f that’s smooth and would permit that blow up to occur, while simultaneously satisfying the navier stokes equations. But how does that resolve the NVS equations?")

#text("is it because we’re showing that there exists a u that satisfies NVS but is not smooth?")

#text("Also it looks like they’re using characteristic length/time scales to show blow up, is that not counter to the idea of the solution being local?")

#text("I have to read the paper more thoroughly")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15feb3d1ce94484ebca1bbe53a839fe5c460e28c0432ca0a9a29a404459c7df1-da119d3ac8074692bc894cde101e02476d7fb0a09fc97d7011e0d1e5eddbba07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovana Ortigoza Álvarez")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694329")[#strong[#text("Giovana Ortigoza Álvarez")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Dear Professor Tao,")

#text("I read this post, in which you explained that the work of Alpöge and Buckmaster—building on Córdoba and Martínez-Zoroa—did not yet reach the forced Navier–Stokes result, although it made such a result appear feasible.")

#text("Following OpenAI’s September 8 announcement of an analytic proof and Lean formalization for statements C and D, and Professor Fefferman’s initial positive assessment, may I ask how you would describe the epistemic status of the result at this moment?")

#text("More specifically, from what is presently available, does the OpenAI work appear to close the precise mathematical gap that you identified in your post, or should it still be described only as a claimed solution pending expert verification that the Lean statement and the human-readable argument correspond fully to Fefferman’s formulation?")

#text("I ask partly because public communication often collapses very different stages of mathematical progress. For example, recent Mexican coverage described José Damián Espinosa’s reformulation of the Riemann hypothesis as “approaching a solution,” although Espinosa himself carefully stated that it is a reformulation rather than a proof. The OpenAI case is clearly much further along, but “formally verified,” “humanly understood,” and “accepted by the mathematical community” may still represent different stages.")

#text("Would it be consistent with the Leiden Declaration to describe the Navier–Stokes result, for now, as a formally verified proposed solution awaiting expert digestion and community validation, rather than simply as a solved Millennium Problem?")

#text("Thank you for helping those of us outside the immediate area communicate this development accurately.")

#text("Giovana Ortigoza Álvarez")#linebreak()#text("Applied mathematician, Mexico")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694331")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("I would agree with your characterization of the OpenAI result as a “formally verified proposed solution awaiting expert digestion and community validation”. This is a novel (and somewhat unintuitive) category of result that only started appearing this year – results that were generated and verified with heavy AI input, but for which no expert is currently able to present upon the results in a manner that genuinely communicates the ideas to others in the field, and for which the peer review process has not even been started (e.g., by preparing and then submitting a professionally written article to a journal). In the diagram on page 43 of my ICM slides ")#link("https://teorth.github.io/tao-web/slides/age-of-ai-icm-2026.pdf")[#text("https://teorth.github.io/tao-web/slides/age-of-ai-icm-2026.pdf")]#text(", the talk is somewhere between the “verified proof” and “well-written proof” stages at present.")

#text("To be fair, the Alpoge-Buckmaster papers are also somewhere along this edge of the process as well; they were (and still are) actively working to move the papers along to a better state, but they were forced to release earlier than they would have preferred due to external events. On the other hand, the Ganeshram-Duruisseaux-Anandkumar paper is already at the “well-written stage” and is likely to be submitted for publication in a traditional journal soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15feb3d1ce94484ebca1bbe53a839fe5c460e28c0432ca0a9a29a404459c7df1-da119d3ac8074692bc894cde101e02476d7fb0a09fc97d7011e0d1e5eddbba07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GioOrtigoza27")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694334")[#strong[#text("GioOrtigoza27")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Dear Professor Tao,")

#text("Thank you very much for your response. Your explanation clearly resolves my question about the present epistemic status of the result.")

#text("May I ask one brief follow-up? My deeper concern is not only how the result should be classified, but what the capability behind it may signal. If the proof withstands scrutiny, it would appear that a large-scale autonomous AI system was able to complete, within days, a frontier research program built through years of human mathematical work.")

#text("Would it therefore be reasonable to regard this not only as an advance in automated mathematics, but also as a dual-use capability signal? In other words, should a result of this magnitude prompt safeguards before similarly autonomous scientific systems are deployed in fields where a successful discovery could have direct harmful applications?")

#text("I am particularly interested in whether you believe that the principles of the Leiden Declaration should now extend beyond publication, attribution, and verification practices to the governance of large-scale autonomous scientific research itself.")

#text("Thank you again for your time and generosity.")

#text("Giovana Ortigoza Álvarez")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694335")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("The dual use capability of these most recent tools is indeed extremely concerning. There is a significant correlation between the capability of AI tools to solve pure mathematical problems, and their ability to potentially perform malicious acts such as exploiting security weaknesses in an online system, and the danger is very real that some major AI-triggered cybersecurity incident could occur in the near future which would be far more significant event in world history than, say, the production of a solution to all remaining Millennium prize problems. I am certainly supportive of efforts to slow down the development and release of even more capable models, and to impose genuine regulation on the industry, although the political environment currently is not exactly conducive to such policies, to put it mildly.")

#text("When I served on PCAST back in 2024, we ")#link("https://www.osti.gov/biblio/2482034")[#text("released a report on cyber-physical resilience")]#text(" which touches on these issues; this report predates the era of extremely capable AI, but I believe many of its recommendations remain relevant today. I will also point to the ")#link("https://www.federalregister.gov/documents/2023/11/01/2023-24283/safe-secure-and-trustworthy-development-and-use-of-artificial-intelligence")[#text("2023 executive order by President Biden on the Safe, Secure, and Trustworthy Development and Use of Artificial Intelligence")]#text(", which unfortunately was revoked by the subsequent administration. I also link to the ")#link("https://bidenwhitehouse.archives.gov/wp-content/uploads/2024/04/AI-Report_Upload_29APRIL2024_SEND-2.pdf")[#text("2024 PCAST report “Supercharging Research: Harnessing Artificial Intelligence to Meet Global Challenges”")]#text(", which I had the honor to cochair the working group that wrote the report (and which was mandated by the 2023 executive order).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15feb3d1ce94484ebca1bbe53a839fe5c460e28c0432ca0a9a29a404459c7df1-da119d3ac8074692bc894cde101e02476d7fb0a09fc97d7011e0d1e5eddbba07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GioOrtigoza27")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694996")[#strong[#text("GioOrtigoza27")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Dear Professor Tao,")

#text("Thank you again for your previous reply. I kept thinking about your comment that the cybersecurity implications are extremely concerning.")

#text("After discussing the issue with several colleagues and looking at historical analogies, I have tried to separate what is genuinely new from what is not. Secrecy, competition for resources, concentration of power, and private control of knowledge all predate AI, so I no longer think those facts alone are evidence of a fundamentally new kind of danger.")

#text("What I am still trying to understand is how one should distinguish a major but manageable technological revolution from a genuinely dangerous transition.")

#text("I have been thinking about four practical questions:")

#text("Detection: if something starts going wrong, can we recognize it before serious harm occurs?")

#text("Containment: can we stop or limit its propagation?")

#text("Reversibility: can critical institutions continue to operate without the system if necessary?")

#text("Governance: is there any actor with both the authority and the technical capacity to intervene effectively?")

#text("Under this framing, what kinds of observations would make you significantly increase or decrease your estimate of risk from advanced AI?")

#text("For example, would sustained autonomous scientific work, reliable real-world transfer into cybersecurity or biology, or loss of independent human verification count as qualitatively different warning signs from what we have seen so far?")

#text("I am asking because I realized that “AI is progressing very fast” is not by itself a useful criterion. I would like to understand what evidence should rationally change our assessment.")

#text("Best,")#linebreak()#text(" Giovana Ortigoza")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694333")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("This is like the Newton-Leibniz priority dispute on who invented calculus first, all over again. Judging by the historical precedent, this controversy won’t be resolved until everybody involved here dies and OpenAI goes out of business, which won’t be for another few decades.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Don’t need everybody to die. Just need OpenAI to go bankrupt and the fraud Sam Altman to be put in jail like Sam Bankman-Fried. Then everybody else will recognize that OpenAI stole the work of Alpöge and Buckmaster for their proof of Navier-Stokes without proper crediting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694342")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Looking over the OpenAI manuscript, two things stand out as weird. First, the forcing term is supposedly compactly supported in time, meaning the equation is unforced for short times. That seems inconsistent with the solution being compactly supported, both because the heat kernel will lead to infinite propagation of signals and because the pressure will have a far field term. Is this just a notational issue (i.e. they mean that the force is supported in the time interval [0,T] for some T), or is there another reason people can see that this works? Because if I am reading it right, their claimed solution is unforced for an initial time interval [0,a], and that does not seem compatible with u being compactly supported in space.")

#text("Secondly, Tao’s 2013 paper in Analysis & PDE “Localisation and compactness properties of the Navier–Stokes global regularity problem” shows that the global regularity problem for 3D Navier-Stokes without a force and with a smooth force are equivalent on the Torus. Proposition 1.7 in [Tao 2013] combined with OpenAI’s alleged proof, would imply blowup for unforced Navier-Stokes on the Torus as well. It’s kind of shocking to me that they don’t claim to prove this, particularly as mining the literature for those kind of implications is what AI had traditionally (i.e. 1 year to 6 months ago) been quite good at.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694461")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("In order to prove uniqueness in the T^3 case, the OpenAI solution assumes periodic pressure. Tao’s argument shows that global unforced regularity on T^3 is equivalent to the existence of smooth solutions for forced data, allowing nonperiodic pressure. So the OpenAI solution does not imply the unforced result")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Just to be very clear, is that correct that no human being at the moment can vouch the write-up posted by OAI company was any good? Similarly, is that correct that nobody can claim in absolute honesty they have read and understood the text advertised as proof. If that’s so, does it really count as a solved problem if there is absolutely not a single person can explain the solution? The Lean repository does not resolve this, either: is there anyone who can claim completely honestly they have audited the code and vouch it does prove what it claims to prove? Not a subtly easier, non-equivalent statement because of a catch hidden deeply in the code?")

#text("I am asking because the people seem very convinced (by marketing or otherwise) the Navier-Stokes problem was, indeed, solved or “mostly solved”. One there is currently a hellshow developing in mathematical Internet microcommunities about the moral side and implications of the Navier-Stokes drama, but I have encountered little to no heated debate about the ")#emph[#text("veracity ")]#text("of alleged proof. And to me, is far from obvious that I should regard that wall of text as “most probably correct”. Am I being overskeptical there, or a possibility of a flaw in the write-up the company posted is within reasonable doubt?")

#text("A particularly ambiguous area we could be, but not necessarily are, heading into, is the following. Suppose the OAI company’s write-up is being reviewed, and in the process a series of gaps of different severity is discovered. Suppose, moreover, that it turns out these gaps can be patched up with some additional work, so that the patched-up text does constitute a solution of Navier-Stokes problem. How are we going to attribute the solution in this case? Do we credit the auditor patching the proof up with complete solution, or we are still going to canonize the “proof is by machines” version? And how severe a gap is sufficient to change that attribution?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694380")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("The Lean formalization leaves very little room for doubt. Judging from experience pretty soon human mathematicians will find a shorter proof that humans can understand.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694432")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Does Lean formalization really do it without a code audit? I am asking because I have seen examples of Lean crackpottery before, in science freak attempts at other millennium problems. It is quite exceptional kind of crackpottery, but untrustworthy nonetheless. As far as I understand, the major questions are:")

#enum(start: 1, 
[#text("Does the statement proved in Lean matches what we informally understand as Navier-Stokes smoothness counterexample?")],
[#text("Does the code in Lean runs without “sorry”‘s and cheats (like loading additional assumptions)?")]
)

#text("I do not know enough Lean to check these for myself. I could learn it, but maybe people on this blog have already checked these questions and can tell the results right away. I am being informed there is also a question of kernel bugs exploitation, but these two questions have to be sorted out first.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694434")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("The thread at ")#link("https://leanprover.zulipchat.com/#narrow/channel/113488-general/topic/Independent.20verification.20of.20OpenAI.20NavierStokesAndEuler/with/623176062")[#text("https://leanprover.zulipchat.com/#narrow/channel/113488-general/topic/Independent.20verification.20of.20OpenAI.20NavierStokesAndEuler/with/623176062")]#text(" has the most up-to-date information on this. It appears that the Lean code has been independently verified, and the statement proven aligns with the one in the formal conjectures repository up to cosmetic differences.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694445")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Thank you! The link helps")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694344")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("So many people concerned about credit… Guys: The house is on fire, forget about this particular problem for some time: AIs with such superpowers are already here and growing in power, it IS a FIRE, and humans will be in a great danger very soon. UNLESS we end this fire soon (but no one knows how to do that). Wake up: We live in dangerous times. There is no longer any security on the Internet, and this is just the beginning. Just you wait. My recommendation is to enjoy this beautiful planet while we are alive; we don’t have much time here, just look at the role of AI at wars (AI drones and so on…).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("This monumental achievement should call for a celebration (instead of grief and concerns).")

#text("Hat off to the engineers at OpenAI and specially to the team who directed the efforts to solve this problem. This team should be recognized and be rewarded by the most prestigious mathematical awards (instead of being accused of stealing other people work and ideas).")

#text("OpenAI saw an opportunity and went after it in the same way Wiles saw an opportunity to solve FLT (when Ken Ribet’s from Berkeley linked FLS to Taniyama–Shimura conjecture).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694357")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Sebastian Bubeck is well known in the mathematics community for having a lot of ethical violations in the past. Not surprising that he’s at the center of yet another controversy with OpenAI’s ethical violations against Alpöge and Buckmaster.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694347")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Prof. Tao,")

#text("Please support my proposal for requiring the “AI use protocol” for any paper submission. It is my humble contribution to protect mathematics.")

#text("Mathematicians must leap ahead of AI and set the standards for research in mathematics in the era of AI before it’s too late. We’ve seen preprints with only the company name on it, no human authors, and no words on how AI was used or what humans contributed. We’ve also seen the queue of claimed results that no one has confirmed.")

#text("AI companies are pushing mathematics to the secret land: “Our model that no one else has access to, has solved a 100-year-old problem, and we are not disclosing the details.”")

#text("The issue is not about using AI in math research or not, or even if AI can do math on its own. The issue is about credit assignment requirements if AI is used, standards for AI use, disclosure and transparency.")

#text("See the linked post to learn about my proposal.")

#link("https://www.linkedin.com/posts/a-dakhama-phd-75b02295_the-leiden-declaration-on-artificial-intelligence-activity-7499344751821983744-iHMm")[#text("https://www.linkedin.com/posts/a-dakhama-phd-75b02295_the-leiden-declaration-on-artificial-intelligence-activity-7499344751821983744-iHMm")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Weird! Why would anyone vote this down?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694363")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Dear Professor Tao,")

#text("Thank you so much for one of your replies to the comments earlier to clarify your viewpoint and advocate moving towards “the best of both worlds.” As a fellow Math PhD student, I really appreciate you standing out in this chaotic era to ask Mathematicians to unite around our core values and reject unsustainable AI practice. Thank you so much!")

#text("Nonetheless, today I was very disappointed when I noticed from LinkedIn that AMS posted and congratulated the announcement from OpenAI while you assure that at this stage the result can be characterized as “formally verified proposed solution awaiting expert digestion and community validation”. It is extremely frustrated to see that one of the largest math authority is giving privilege to AI companies and informally accept its result prior to the standard peer-reviewed procedure.")

#text("As a fellow Math PhD student who is in the late year of deciding on their career path, I had a lot of reflections and discussions with colleagues on the future of Mathematicians as a researcher and as a part of the community, especially in the last few months. As a researcher, while I certainly agree that AI can boost productivity, I am on the side that Mathematician should take understanding and clarity (in communication) as priority and AI usage should be prioritized on that purpose instead of the lesser goal of merely producing answer. Therefore, I consider myself to endorse your viewpoint of moving towards “the best of both worlds”. I am confident on that part.")

#text("The part that troubles me and annoys me most is the value of Mathematician ")#emph[#text("to the society")]#text(". While I certainly think Math benefits to the society the same way as to researchers by enhancing understanding and communications, the mathematical “industry” is not working this way. Lots of parties are involved in fundings and to the layman, papers and solving problems seem to be the only measurement. Therefore I come to the conclusion that renowned Mathematician must stand out and tell the world the values of math to the society in spite of AI to make our voice loud, and to perhaps slow down and shift and the current chaotic development. That was what you did and I sincerely appreciate that.")

#text("Nonetheless, hearing the post from AMS, I feel both helpless and hopeless. While I spend all the time and mental effort to find out and believe in the core value of mathematician, which is to communicate, to understand in addition to answering problems, in this era, the society and even some of the more authoritative part of the community just don’t recognize that.")

#text("My question is that if you think the part of the community that seeks “the best of both world” is actually the minority? And what would you recommend if I, as just a PhD student which has all sorts of resource limitations including time and experience, can do to help shift the direction to “the best of both world” ?")

#text("Thank you so much!")

#text("Best regards,")

#text("A very confused final-year Math PhD who chooses to draft this reply instead of their thesis, potentially missing important deadlines")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694374")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Dear friend,")

#text("If you are confused and concerned about the AMS’s congratulatory note to OpenAI, I strongly suggest writing to the president and expressing your disapproval. It is time we made our voices heard.")

#text("Kind regards, ")#linebreak()#text("A friend.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694372")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("”While these authors do not quite achieve these goals yet, they have made enough of a breakthrough that it looks very feasible to complete these goals in the near future”")

#text("I would like you to clarify this because this claim is essentially implying that Forced Euler solution is very close to discover Forced Navier-Stoke. I think you should demonstrate in layman term to the public why this is the case because otherwise this claim overshadows the genuity discovered in OpenAI’s proof of the forced Navier Stoke.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694394")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("One initial observation is that one can convert any solution of forced Euler to a solution to forced Navier-Stokes by adding an additional forcing term to cancel out the effect of the viscosity. Now, this simple trick does not work by itself because, if the solution blows up, then this additional forcing term will also blow up. However, it does hint at the flexibility afforded by the presence of the forcing term, and the possibility of applying a more sophisticated modification to the Euler construction to produce a Navier-Stokes construction. This is not easy or automatic – even with AI assistance it would take significant effort, and may encounter significant technical obstacles – but I do not see any absolute barriers that prevent this strategy from working. (On the other hand, as pointed out to me by my former student Stan Palasek, upgrading from Euler to Navier-Stokes while simultaneously removing the forcing term completely appears to be a much heavier lift, and probably requires a substantial new idea, especially in three dimensions where the dissipation term in the energy inequality is relatively strong.)")

#text("The authors of this paper are now extremely distracted by current events, but in an alternate timeline in which they were not under severe external time pressure, I find it quite plausible that they could have worked for a few more months and obtained the forced Navier-Stokes result. It is quite difficult however to confirm this counterfactual experiment now, especially given that the OpenAI proof also exists.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694395")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("This is a lucid analysis. But we are doing mathematics, and I find it striking how suddenly everyone is talking about this in rather vague terms.")

#text("Maybe I would have solved the problem too, had I ever decided to work seriously on it. The discussion sometimes seems to suggest that only three or four people were realistically capable of making progress on this problem. I do not think that is true. It is just that, in the mathematical world we live in, where failing to publish regularly and in the right places can have serious consequences for one’s career, it is extremely difficult to justify spending years on a problem like Navier–Stokes. This is particularly true when you know that other mathematicians, often coming from very strong and well-established mathematical schools, have already been working on it for years and may simply reach the key ideas faster than you. Of course, one can publish intermediate results along the way, but pursuing such a problem remains a substantial professional risk.")

#text("What worries me is that some of the reaction to what is happening, particularly from people coming from the strongest mathematical schools, sometimes sounds rather defensive. I do not think this helps the mathematical community of which I am part. We should perhaps be asking what this development means for mathematics, rather than primarily trying to defend the way mathematics has traditionally been done.")

#text("AI potentially changes this balance. If a system can take existing mathematical knowledge and perform, in days, technical and conceptual work that would otherwise require a human mathematician to spend years navigating the literature and developing the necessary machinery, then some of the advantages associated with belonging to an established mathematical environment may become much less decisive.")

#text("And this may be the part that is genuinely unsettling. The scarce resource may increasingly be not the ability to produce long technical arguments, but the ability to identify the right problem and, above all, to find the genuinely new idea that makes the argument work. If that happens, then some of the criteria by which we currently evaluate mathematicians, papers, and even hiring candidates may become obsolete.")

#text("Perhaps this is why the reaction to what OpenAI has done is so interesting. It may not simply be about one particular proof of Navier–Stokes. It may be about the possibility that AI is beginning to change the relative value of different kinds of mathematical ability. And that would have consequences for the entire profession, including for people who have benefited from the old system.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I’m not a mathematician, but I follow this topic with great interest. My view is as follows: given that it is clear that AI is helping researchers make progress on problems that were not easy to tackle with just pen and paper, is it fair to say that, without the guidance of mathematicians, these tools would never have achieved this sort of result? Isn’t it suspicious that ChatGPT (whichever version they use internally) proposed a solution to Euler’s problem just 15 days after Buckmaster-Alpögue found a solution to the same problem using large language model (LLM) tools, including OpenAI’s Codex? Furthermore, without this result, OpenAI’s experts would never have identified the NS problem as the one most likely to be solved (as explained in the timeline they shared to describe the process). Finally, if it turns out to be true that ChatGPT’s demonstration remains valid after peer review, should the academic community reconsider its current reliance on AI tools if there is a risk that its work could be used in AI-generated demonstrations without acknowledging its efforts, or by directly disregarding its contribution on the basis of its professional affiliation?")

#text("BR,")

#text("Jose Maria")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("This is categorically impossible, Buckmaster and OpenAI worked on different problems, and believing this requires a complete lack of knowledge about how LLMs are trained.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-695156")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I’m surprised that anyone could be so categorically certain about this, when OpenAI itself has been so vague and evasive on this very subject. And no, the problems aren’t entirely unrelated: the Euler case is a simplification of the NS problem and, apparently, the strategy used to solve this problem was also similar (although the exact details and nuances of the solution still need to be clarified). Perhaps you could explain to us how LLMs are trained, but it strikes me as highly suspicious (though probably impossible to prove, given how these models work) that the model arrived at a solution very similar to that of the Euler problems just a few days after Buckmaster and his colleague found it. I suppose this coincidence is completely irrelevant to you, and I can only congratulate you on being so trusting.")
]
]
]
