// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:21:15.091515+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A digestion of the proof of Sendov’s conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A digestion of the proof of Sendov’s conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 August 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/")[#text("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This post concerns the following conjecture ")#link("https://zbmath.org/3254142")[#text("of Sendov")]#text(", as well as its strengthening by ")#link("https://zbmath.org/3386011")[#text("Phelps–Rodriguez")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Sendov’s conjecture)")]#text(" Let ")#mi("{n \\geq 2}")#text(", and let ")#mi("{p : {\\bf C} \\rightarrow {\\bf C}}")#text(" be a degree ")#mi("{n}")#text(" polynomial with all zeroes in the unit disk. Then for every zero ")#mi("{a}")#text(" of ")#mi("{p}")#text(", there exists a critical point ")#mi("{\\zeta}")#text(" of ")#mi("{p}")#text(" with ")#tao-math("{\\left|\\zeta-a\\right| \\leq 1}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Phelps–Rodriguez conjecture)")]#text(" Let ")#mi("{n \\geq 2}")#text(", and let ")#mi("{p : {\\bf C} \\rightarrow {\\bf C}}")#text(" be a degree ")#mi("{n}")#text(" polynomial with all zeroes in the unit disk. Then for every zero ")#mi("{a}")#text(" of ")#mi("{p}")#text(", there exists a critical point ")#mi("{\\zeta}")#text(" of ")#mi("{p}")#text(" with ")#tao-math("{\\left|\\zeta-a\\right| < 1}", block: false)#text(", unless ")#mi("{a}")#text(" is on the unit circle and ")#mi("{p}")#text(" is a scalar multiple of ")#mi("{z^n - a^n}")#text(".")
]

#text("By applying a rotation around the origin, we can normalize ")#mi("{a}")#text(" to be a real number with ")#mi("{0 \\leq a \\leq 1}")#text(".")

#text("From the ")#link("https://zbmath.org/3274887")[#text("work of Rubinstein")]#text(", both conjectures were already established in the ")#mi("{a=1}")#text(" case, so one can restrict to the ")#mi("{0 \\leq a < 1}")#text(" case. Both of these conjectures then follow from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3 (Sendov’s conjecture in interior)")]#text(" ")#metadata(none) <tao-6b6b85aed8adda90f7a7>#text(" Let ")#mi("{n \\geq 2}")#text(". Let ")#mi("{p : {\\bf C} \\rightarrow {\\bf C}}")#text(" be a degree ")#mi("{n}")#text(" polynomial with all zeroes in the unit disk. Then if ")#mi("{0 \\leq a < 1}")#text(" is a zero of ")#mi("{p}")#text(", there exists a critical point ")#mi("{\\zeta}")#text(" of ")#mi("{p}")#text(" with ")#tao-math("{\\left|\\zeta-a\\right| < 1}", block: false)#text(".")
]

#text("All three of these conjectures were established for ")#mi("{n \\leq 8}")#text(" (in a sequence of papers culminating in ")#link("https://zbmath.org/1286149")[#text("this paper of Brown and Xiang")]#text(") and for sufficiently large ")#mi("{n}")#text(" (in ")#link("https://terrytao.wordpress.com/2020/12/08/sendovs-conjecture-for-sufficiently-high-degree-polynomials/")[#text("a paper of myself")]#text(", which in turn built upon several partial results in this setting). This left the case of intermediate ")#mi("{n}")#text(" to be settled. My arguments used some qualitative ingredients (most notably analytic continuation) and as such did not easily lend themselves to quantifying the threshold of ")#mi("{n}")#text(" above which the argument was valid.")

#text("Recently, Lech Mazur ")#link("https://www.proofatlas.ai/papers/sendov-conjecture/SENDOV_CONJECTURE_PROOF_AUGUST_5_2026.pdf")[#text("was able to use an AI tool")]#text(" to resolve Sendov’s conjecture for all ")#mi("{n \\geq 2}")#text(", with the proof ")#link("https://www.proofatlas.ai/formalizations/sendov-conjecture/")[#text("verified in Lean")]#text(". However, the AI-generated proof was not human-digested to be in the form of a publication-ready preprint; and it has taken me several days (with ")#link("https://chatgpt.com/share/6a7ceea8-5aa0-83e8-a56b-67cd7ec59f06")[#text("heavy AI assistance")]#text(") to perform such a digestion, to place the proof in proper context with previous literature and to simplify and streamline the argument to highlight the main ideas. (Note: the above chat log only represents a portion of the digestion work: the rest was performed with pen and paper, or using some further AI agents.) The same arguments also give a new proof of Rubinstein’s theorem, which I also give below the fold.")

#text("One consequence of this digestion is that the argument in fact demonstrates Conjecture ")#link(<tao-6b6b85aed8adda90f7a7>)[#text("3")]#text(", and thus resolves both the Sendov conjecture and the Phelps–Rodriguez conjecture in full generality.")

#text("The proof ends up being remarkably elementary. No complex analysis is used other than the fundamental theorem of algebra (and very basic facts about Möbius transformations); and the deepest inequality used as input is the ")#link("https://en.wikipedia.org/wiki/Maclaurin%27s_inequality")[#text("Maclaurin inequality")]#text(" (and we only need a special case of that inequality which can be derived from the arithmetic mean-harmonic mean inequality and an induction argument).")

#text("Using an AI agent, I ")#link("https://github.com/teorth/sendov")[#text("have been able to formalize")]#text(" the entire argument in Lean, extended to ")#mi("{n \\geq 2}")#text(" by some minor modifications to the proof. This formalization is more streamlined than the original formalization (it has about 15,000 lines of code, compared with around 90,000 for the original proof).")

#text("We now prove Conjecture ")#link(<tao-6b6b85aed8adda90f7a7>)[#text("3")]#text(". The ")#mi("{n \\leq 4}")#text(" cases have long been known but need to be treated separately; a short proof using the machinery developed here is provided at the end of the post. Suppose now that we have a counterexample for some ")#mi("{n \\geq 5}")#text(", thus one can find a degree ")#mi("{n}")#text(" polynomial ")#mi("{p}")#text(" with zeroes")

#align(center)[#tao-fit-display[#mitex("a, z_1, \\dots,z_{n-1}")]]

#text("for some ")#mi("{0 \\leq a < 1}")#text(" and ")#mi("{z_j}")#text(", ")#mi("{j=1,\\dots,n-1}")#text(" in the closed unit disk, whose critical points all lie a distance at least ")#mi("{1}")#text(" from ")#mi("{a}")#text(". We use ")#mi("{O()}")#text(" notation here in the non-asymptotic sense, thus ")#mi("{X = O(Y)}")#text(" means that ")#tao-math("{\\left|X\\right| \\leq C Y}", block: false)#text(" for some absolute constant ")#mi("{C}")#text(" (independent of ")#mi("{n}")#text("). We will also use the notation ")#mi("{O_{\\leq}(Y)}")#text(" to denote a quantity that is bounded in magnitude by ")#mi("{Y}")#text(".")

#text("To capture the fact that the critical points lie at a distance at least ")#mi("{1}")#text(" from ")#mi("{a}")#text(", we write these critical points as")

#align(center)[#tao-fit-display[#mitex("a - \\frac{1}{q_1}, \\dots, a - \\frac{1}{q_{n-1}}")]]

#text("for some (non-zero) ")#mi("{q_1,\\dots,q_{n-1}}")#text(" in the closed unit disk.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" ")#metadata(none) <tao-5312fb609f60384731fc>#text(" If ")#mi("{p(z) = z^n - 1}")#text(" and ")#mi("{a=1}")#text(", then ")#mi("{z_1,\\dots,z_{n-1}}")#text(" are the non-trivial ")#mi("{n^{th}}")#text(" roots of unity, while the ")#mi("{q_1,\\dots,q_{n-1}}")#text(" are all equal to ")#mi("{1}")#text(". Strictly speaking this is not actually a counterexample to Conjecture ")#link(<tao-6b6b85aed8adda90f7a7>)[#text("3")]#text(", because ")#mi("{a}")#text(" is not strictly less than one; nevertheless this is an important motivating near-counterexample for the arguments below.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" ")#metadata(none) <tao-eef70f4158cde69e1d7f>#text(" A generalization of the previous example was studied in Section 4 of ")#link("https://arxiv.org/abs/2012.04125")[#text("my paper")]#text(". Here one took")

#align(center)[#tao-fit-display[#mitex("p(z) = (z + \\frac{c_2}{n})^{n-m} P(z) - (a + \\frac{c_2}{n})^{n-m} P(a)")]]

#text("where ")#mi("{n}")#text(" was an asymptotic parameter going to infinity,")

#align(center)[#tao-fit-display[#mitex("P(z) = (z-\\lambda_1) \\dots (z - \\lambda_m)")]]

#text("was a low-degree polynomial for some ")#mi("{m=O(1)}")#text(",")

#align(center)[#tao-fit-display[#mitex("a = 1 - \\frac{c_1}{n},")]]

#text("and ")#mi("{c_1,c_2 > 0}")#text(" were constants. This polynomial has a zero at ")#mi("{a}")#text(", ")#mi("{n-m-1}")#text(" critical points at ")#mi("{-\\frac{c_2}{n}}")#text(", and ")#mi("{m}")#text(" additional critical points near ")#mi("{\\lambda_1,\\dots,\\lambda_m}")#text(". If all the critical points were at distance at least one from ")#mi("{a}")#text(", one would have")

#align(center)[#tao-fit-display[#mitex("c_2 \\geq c_1")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|1-\\lambda_j\\right| \\geq 1 - o(1)", block: true)]]

#text("while if all the zeroes were in the unit disk, the calculations in my paper showed that")

#metadata(none) <tao-a9f6815747c1b2f9466e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("c_2 - c_1 - c_2 \\cos \\theta + \\sum_{j=1}^m \\log \\left|\\frac{1-\\lambda_j}{e^{i\\theta}-\\lambda_j}\\right| \\leq o(1)", block: true)]]

#text("Here ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(". If one ignores the ")#mi("{o(1)}")#text(" errors, one can show that these conditions are only simultaneously feasible if ")#mi("{c_1=c_2}")#text(" and all the ")#mi("{\\lambda_j}")#text(" vanish, but the argument was somewhat subtle (I had to proceed by inspecting the second Fourier coefficient of ")#link(<tao-a9f6815747c1b2f9466e>)[#text("(1)")]#text("). This illustrates the fact that the regime ")#mi("{a = 1 - O(1/n)}")#text(" is particularly delicate.")
]

#text("We now have two sets of points in the closed unit disk: ")#mi("{z_1,\\dots,z_{n-1}}")#text(" and ")#mi("{q_1,\\dots,q_{n-1}}")#text(". They “communicate” with each other through the polynomial ")#mi("{p}")#text(" and its first derivative ")#mi("{p^{\\prime}}")#text(", both of which can be expressed in terms of either set of points (as well as ")#mi("{n}")#text(" and ")#mi("{a}")#text("). Indeed, if we normalize ")#mi("{p}")#text(" to be monic, then we can factor ")#mi("{p}")#text(" in terms of the zeroes as ")#metadata(none) <tao-11daef0cf7ce18d0cd9a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("p(z) = (z-a) \\prod_{j=1}^{n-1} (z-z_j)")]]

#text(" ")#text(" and thus upon differentiating")

#metadata(none) <tao-04fd1dfb96fca8b4ff30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("p^{\\prime}(z) = \\left(\\prod_{j=1}^{n-1} (z-z_j)\\right) \\left(1 + (z-a) \\sum_{j=1}^{n-1} \\frac{1}{z-z_j}\\right).")]]

#text("Here and in the sequel we adopt the convention of removing singularities when dealing with expressions that involve multiplication by both ")#mi("{\\frac{1}{z-z_j}}")#text(" and ")#mi("{z-z_j}")#text(", by cancelling such terms first in the event that ")#mi("{z=z_j}")#text(".")

#text("In a similar vein, ")#mi("{p^{\\prime}}")#text(" can be factored ")#metadata(none) <tao-46e16b2a1816cc420116>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("p^{\\prime}(z) = n \\prod_{j=1}^{n-1} \\left(z - a + \\frac{1}{q_j}\\right)")]]

#text(" ")#text(" and thus on integrating (and using ")#mi("{p(a)=0}")#text(")")

#metadata(none) <tao-bf561560d72d5d032797>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("p(z) = (z-a) \\int_0^1 n \\prod_{j=1}^{n-1} \\left(t(z - a) + \\frac{1}{q_j}\\right)\\ dt.")]]

#text("It is convenient to rule out the easy case ")#mi("{a=0}")#text(" right away. In this case we see from ")#link(<tao-04fd1dfb96fca8b4ff30>)[#text("(3)")]#text(", ")#link(<tao-46e16b2a1816cc420116>)[#text("(4)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("p^{\\prime}(0) = \\prod_{j=1}^{n-1} (-z_j) = n \\prod_{j=1}^{n-1} \\frac{1}{q_j}")]]

#text("which is absurd since the first product has magnitude at most one, and the second product has magnitude at least one. Thus we can assume henceforth that ")#mi("{a>0}")#text(".")

#text("By inspecting ")#mi("{p}")#text(" or ")#mi("{p^{\\prime}}")#text(" at various natural locations, we can thus obtain a number of identities relating the ")#mi("{z_j}")#text(" to the ")#mi("{q_j}")#text(". We record the ones that we actually need here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Communication identities)")]#text(" ")#metadata(none) <tao-13c7351360f0032d02f4>#text(" Let ")#mi("{F}")#text(" denote the function")

#metadata(none) <tao-407eca442505ec8c70f4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("F(t) := \\prod_{j=1}^{n-1} (1 - atq_j).")]]

#list(
[#text("(i) (Centroid identity) We have")

#metadata(none) <tao-37447085f981309300c4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{1}{n} \\left(a + \\sum_{j=1}^{n-1} z_j\\right) = \\frac{1}{n-1} \\sum_{j=1}^{n-1} \\left(a - \\frac{1}{q_j}\\right).")]]

#text("That is to say, the centroid of the zeroes equals the centroid of the critical values.")],
[#text("(ii) (Polar identity) We have")

#metadata(none) <tao-fceb18b39be3c1583906>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\prod_{j=1}^{n-1} \\frac{1-az_j}{a-z_j} = \\int_0^1 \\prod_{j=1}^{n-1} (t (1-a^2) q_j + a)\\ dt.")]]],
[#text("(iii) (First origin identity) We have")

#metadata(none) <tao-78b869235e26652f5653>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("(-1)^{n-1} \\prod_{j=1}^{n-1} z_j = \\frac{n}{\\prod_{j=1}^{n-1} q_j} \\int_0^1 F(t)\\ dt.")]]],
[#text("(iv) (Second origin identity) We have")

#metadata(none) <tao-d263d2e0878dfe5d949c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("(-1)^{n-1} \\prod_{j=1}^{n-1} z_j \\left( 1 + a \\sum_{j=1}^{n-1} \\frac{1}{z_j} \\right) = \\frac{n}{\\prod_{j=1}^{n-1} q_j} F(1).")]]

#text("(Again, we are using the convention of removing singularities to deal with the case where some of the ")#mi("{z_j}")#text(" vanish.)")]
)
]

#emph[#text("Proof:")]#text(" For (i), we inspect the behavior of ")#mi("{p^{\\prime}(z)}")#text(" as ")#mi("{z \\rightarrow \\infty}")#text(". From ")#link(<tao-11daef0cf7ce18d0cd9a>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p(z) = z^n - \\left( a + \\sum_{j=1}^{n-1} z_j \\right) z^{n-1} + O(z^{n-2})")]]

#text("and thus on differentiating term by term")

#align(center)[#tao-fit-display[#mitex("p^{\\prime}(z) = n z^{n-1} - (n-1) \\left( a + \\sum_{j=1}^{n-1} z_j \\right) z^{n-2} + O(z^{n-3}).")]]

#text("Meanwhile, from ")#link(<tao-46e16b2a1816cc420116>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p^{\\prime}(z) = n z^{n-1} - n \\left(\\sum_{j=1}^{n-1} \\left(a - \\frac{1}{q_j}\\right)\\right) z^{n-2} + O(z^{n-3}).")]]

#text("Comparing coefficients, we obtain the claim.")

#text("For (ii), we consider the expression ")#mi("{p(1/a) / p^{\\prime}(a)}")#text(". On the one hand, from ")#link(<tao-11daef0cf7ce18d0cd9a>)[#text("(2)")]#text(", ")#link(<tao-04fd1dfb96fca8b4ff30>)[#text("(3)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\frac{p(1/a)}{p^{\\prime}(a)} = \\frac{(1/a - a) \\prod_{j=1}^{n-1} (1/a - z_j)}{\\prod_{j=1}^{n-1} (a-z_j)}.")]]

#text("(Note from hypothesis that ")#mi("{a}")#text(" cannot be a critical point, so the denominator is non-zero.) On the other hand, from ")#link(<tao-46e16b2a1816cc420116>)[#text("(4)")]#text(", ")#link(<tao-bf561560d72d5d032797>)[#text("(5)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\frac{p(1/a)}{p^{\\prime}(a)} = \\frac{(1/a - a) \\int_0^1 n \\prod_{j=1}^{n-1} \\left(t\\left(\\frac{1}{a} - a\\right) + \\frac{1}{q_j}\\right)\\ dt}{n \\prod_{j=1}^{n-1} \\frac{1}{q_j}}.")]]

#text("Equating the two identities, we obtain (ii) after some algebra.")

#text("For (iii), we evaluate ")#mi("{p(0)}")#text(". From ")#link(<tao-11daef0cf7ce18d0cd9a>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p(0) = -a (-1)^{n-1} \\prod_{j=1}^{n-1} z_j")]]

#text("while from ")#link(<tao-bf561560d72d5d032797>)[#text("(5)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p(0) = -a \\int_0^1 n \\prod_{j=1}^{n-1} \\left(-at + \\frac{1}{q_j}\\right)\\ dt.")]]

#text("Equating the two identities, we obtain (iii) after some algebra using ")#link(<tao-407eca442505ec8c70f4>)[#text("(6)")]#text(".")

#text("For (iv), we similarly evaluate ")#mi("{p^{\\prime}(0)}")#text(". From ")#link(<tao-04fd1dfb96fca8b4ff30>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p^{\\prime}(0) = (-1)^{n-1} \\left(\\prod_{j=1}^{n-1} z_j\\right) \\left(1 + a \\sum_{j=1}^{n-1} \\frac{1}{z_j}\\right)")]]

#text("while from ")#link(<tao-46e16b2a1816cc420116>)[#text("(4)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("p^{\\prime}(0) = n \\prod_{j=1}^{n-1} \\left(- a + \\frac{1}{q_j}\\right).")]]

#text("Equating the two identities, we obtain (iv) after some algebra using ")#link(<tao-407eca442505ec8c70f4>)[#text("(6)")]#text(". ")#mi("\\Box")

#text("Remarkably, the polynomial ")#mi("{p}")#text(" will play no further role in the argument: the identities in (i)-(iv), together with the hypotheses that ")#mi("{0 \\leq a < 1}")#text(" and ")#mi("{z_j, q_j}")#text(" lie in the closed unit disk, will be sufficient by themselves to obtain a contradiction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" Continuing the example in Example ")#link(<tao-5312fb609f60384731fc>)[#text("4")]#text(", in (i) both sides vanish. In (ii), both sides are equal to one. For (iii) and (iv), we have ")#mi("{F(t) = (1-t)^{n-1}}")#text(", with both sides of (iii) equal to one, and both sides of (iv) equal to zero.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The centroid identity is extremely classical, going back to this 1948 ")#link("https://zbmath.org/3047862")[#text("paper of Popoviciu")]#text(". The comparison of the polynomial at a location ")#mi("{a}")#text(" and at the polar inversion ")#mi("{1/a}")#text(" of that location across the closed unit disk is a familiar trick in the literature; see, e.g., Lemma 5 and Theorem 8 of ")#link("https://zbmath.org/6269492")[#text("Dégot")]#text(". The specific form of the polar identity is implicit in the first part of Section 5 of ")#link("https://www.proofatlas.ai/papers/sendov-conjecture/SENDOV_CONJECTURE_PROOF_AUGUST_5_2026.pdf")[#text("Mazur’s AI-generated proof")]#text(", while the origin identities are extracted from equation (6.3) of that proof. The first origin identity is also very close to Theorem 6 of Dégot, while the second origin identity is similar to some identities appearing in the proof of Lemma 6 of Dégot, as well as the work of ")#link("https://zbmath.org/7742078")[#text("Mir–Nazir–Wani")]#text(" and (in the ")#mi("{a=1}")#text(" case) ")#link("https://zbmath.org/3274887")[#text("Rubinstein")]#text(". The work of ")#link("https://zbmath.org/3308557")[#text("Meir–Sharma")]#text(" and ")#link("https://zbmath.org/7742078")[#text("Mir–Nazir–Wani")]#text(" also contain several further identities relating the ")#mi("{z_j}")#text(" to the ")#mi("{q_j}")#text("; see in particular Lemma ")#link(<tao-2830b59f44603921a809>)[#text("15")]#text(" below. Variants of ")#link(<tao-bf561560d72d5d032797>)[#text("(5)")]#text(" also appear in Proposition 10 of ")#link("https://zbmath.org/399047")[#text("Miller")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" The first origin identity ")#link(<tao-78b869235e26652f5653>)[#text("(9)")]#text(" is already strong enough to handle asymptotically all examples of the form in Example ")#link(<tao-eef70f4158cde69e1d7f>)[#text("5")]#text(", except in the endpoint case where ")#mi("{c_1, c_2}")#text(" vanish and the ")#mi("{\\lambda_j}")#text(" are all ")#mi("{0}")#text(". Indeed, as the ")#mi("{z_j, q_j}")#text(" are in the closed unit disk, ")#link(<tao-78b869235e26652f5653>)[#text("(9)")]#text(" implies that")

#align(center)[#tao-fit-display[#tao-math("n \\left|\\int_0^1 F(t)\\ dt\\right| \\leq 1.", block: true)]]

#text("On the other hand, routine calculations (omitted here) show that")

#align(center)[#tao-fit-display[#mitex("n \\int_0^1 F(t)\\ dt = 1 + \\frac{c_2 + \\sum_{j=1}^{m} \\frac{-\\lambda_j}{1-\\lambda_j}}{n} + O\\left(\\frac{1}{n^2}\\right)")]]

#text("leading asymptotically to the constraint")

#align(center)[#tao-fit-display[#mitex("c_2 + \\mathrm{Re} \\sum_{j=1}^{m} \\frac{-\\lambda_j}{1-\\lambda_j} \\leq 0.")]]

#text("But all terms here are non-negative (since ")#tao-math("{\\left|1-\\lambda_j\\right| \\geq 1}", block: false)#text("), so this forces a contradiction unless ")#mi("{c_2}")#text(" (and hence also ")#mi("{c_1}")#text(") and the ")#mi("{\\lambda_j}")#text(" all vanish.")
]

#text("As mentioned in Example ")#link(<tao-eef70f4158cde69e1d7f>)[#text("5")]#text(", the most delicate regime occurs when ")#mi("{a = 1 - O(1/n)}")#text(". It is convenient to introduce the normalized version ")#metadata(none) <tao-f81ab872625c131d92e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\alpha := \\frac{n-1}{2} (1-a^2),")]]

#text(" ")#text(" of ")#mi("{a}")#text(", thus ")#mi("{0 < \\alpha < \\frac{n-1}{2}}")#text(", and the case ")#mi("{a = 1 - O(1/n)}")#text(" corresponds to ")#mi("{\\alpha = O(1)}")#text(". Informally, ")#mi("{\\alpha}")#text(" measures how close ")#mi("{a}")#text(" is to ")#mi("{1}")#text(" (at the scale of ")#mi("{O(1/n)}")#text(").")

#text("A key role in the argument will be played by the mean ")#metadata(none) <tao-c3866d9233f5ede84ef8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("x + iy := \\frac{1}{n-1} \\sum_{j=1}^{n-1} q_j")]]

#text(" ")#text(" of the ")#mi("{q_j}")#text(", particularly the real part ")#mi("{x}")#text(". As the ")#mi("{q_j}")#text(" all lie in the unit disk, the mean ")#mi("{x+iy}")#text(" does also, so that")

#align(center)[#tao-fit-display[#mitex("-1 \\leq x \\leq 1")]]

#text("and")

#metadata(none) <tao-0ca8d948c5e4d25c9347>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|y\\right| \\leq \\sqrt{1-x^2}.", block: true)]]

#text("On the other hand, in the example in Example ")#link(<tao-5312fb609f60384731fc>)[#text("4")]#text(", ")#mi("{x}")#text(" is equal to the extremal value of ")#mi("{1}")#text(", and ")#mi("{y=0}")#text(". In Example ")#link(<tao-eef70f4158cde69e1d7f>)[#text("5")]#text(", we have ")#mi("{x = 1 - O(1/n)}")#text(" (and ")#mi("{y = O(1/n)}")#text(").")

#text("It will be convenient to work with the quadratic polynomial")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\beta(t) := 1 - 2atx + a^2 t^2 = 1 - x^2 + (x - at)^2")]]

#text("with a particular emphasis on the value at ")#mi("{t=1}")#text(":")

#metadata(none) <tao-f096890dbb1b514cf178>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\begin{array}{rl} \\beta(1) &= 1 - 2ax + a^2 \\\\ &= (1-a)^2 + 2a(1-x) = 1 - x^2 + (x-a)^2. \\end{array}")]]

#text("One should primarily think of ")#mi("{\\beta(1)}")#text(" as a measure of how close ")#mi("{x}")#text(" is to ")#mi("{1}")#text(". Clearly we have")

#align(center)[#tao-fit-display[#mitex("\\beta(t) > 0")]]

#text("for all ")#mi("{0 \\leq t \\leq 1}")#text(" (note that ")#mi("{at}")#text(" is strictly less than ")#mi("{1}")#text(").")

#text("The arguments will revolve around the relationship between ")#mi("{\\alpha}")#text(" and ")#mi("{\\beta(1)}")#text(". Specifically, we will establish the following two inequalities below the fold. The first inequality, which we call the “polar inequality”, comes in three forms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Polar inequality)")]#text(" ")#metadata(none) <tao-f712d322b8f5a7e4431b>

#list(
[#text("(i) (Raw polar inequality) We have")

#metadata(none) <tao-a53c716aaaa27d4c6da9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("1 \\leq \\int_0^1 (a^2 + 2 a t x (1-a^2) + t^2 (1-a^2)^2)^{\\frac{n-1}{2}}\\ dt.")]]],
[#text("(ii) (Polar inequality in ")#mi("{\\alpha}")#text(", ")#mi("{\\beta(1)}")#text(" form) We have")

#metadata(none) <tao-67d4143062b55c25f383>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("1 < \\int_0^1 \\exp ( \\alpha (-1 + (2-\\beta(1)) t))\\ dt.")]]],
[#text("(iii) (Simplified polar inequality) We have")

#metadata(none) <tao-5fa61555c7af2e96a6b5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("0 < \\beta(1) < \\min\\left( \\frac{\\alpha}{3+\\alpha}, 1 - \\frac{\\log \\alpha}{\\alpha} \\right).")]]

#text("In particular, since ")#mi("{1 - \\beta(1) = 2a(x-a/2)}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("x > a/2 > 0.")]]]
)
]

#text("It will be the inequality ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text(" that we use in practice, but it will be derived from ")#link(<tao-67d4143062b55c25f383>)[#text("(17)")]#text(", which in turn is a consequence of ")#link(<tao-a53c716aaaa27d4c6da9>)[#text("(16)")]#text(", which will follow from the polar identity ")#link(<tao-fceb18b39be3c1583906>)[#text("(8)")]#text(" together with the fact that the ")#mi("{z_j}")#text(" and ")#mi("{q_j}")#text(" lie in the unit disk. The bound ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text(" is only slightly weaker than ")#link(<tao-67d4143062b55c25f383>)[#text("(17)")]#text("; see the (Gemini-generated) image below.")

#image("../assets/fe44b9e2acf704f5a94f9906c43f5c85e0fbf5e185c8a32dfb3c9ef9d39900e7-52fc1c912892963effe61470818294fb68fd55813df5623cd8b24fb3d617d2ca.png", width: 90%)

#text("I was not able to find an exact duplicate of the above polar inequalities in past literature, but the ")#link("https://zbmath.org/6269492")[#text("paper of Dégot")]#text(" contains several similar inequalities. The inequality ")#link(<tao-a53c716aaaa27d4c6da9>)[#text("(16)")]#text(" was extracted from (5.1) of ")#link("https://www.proofatlas.ai/papers/sendov-conjecture/SENDOV_CONJECTURE_PROOF_AUGUST_5_2026.pdf")[#text("Mazur’s AI-generated proof")]#text("; the subsequent bounds ")#link(<tao-67d4143062b55c25f383>)[#text("(17)")]#text(", ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text(" arose from my attempts to simplify the arguments after that point.")

#text("The second inequality, which is more difficult, also will come in several forms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Origin inequality)")]#text(" ")#metadata(none) <tao-181fdd46fc4a7246b9f4>#text(" Let ")#mi("{n \\geq 5}")#text(".")

#list(
[#text("(i) (Raw origin inequality) We have")

#metadata(none) <tao-314fcbe98cd1f9c33fd4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("2 \\alpha + ax \\leq \\frac{1-x^2}{2(n-1)} + a^2 n(n-1) \\int_0^1 t \\beta(t)^{\\frac{n-2}{2}}\\ dt.")]]],
[#text("(ii) (")#mi("{\\alpha}")#text(" bound) We have")

#metadata(none) <tao-4523540f1504cd17100c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\alpha \\leq 17.")]]],
[#text("(iii) (Origin inequality in ")#mi("{\\alpha}")#text(", ")#mi("{\\beta(1)}")#text(" form) We have")

#metadata(none) <tao-d06c731ee09c8fc019b1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\begin{array}{rl} 1 \\leq & \\frac{\\beta(1)}{2\\alpha(1-\\beta(1))} + \\frac{\\beta(1)}{4\\alpha} + \\frac{1}{2(n-1)} + \\frac{\\beta(1)}{4\\alpha(n-1)} \\\\ & + \\frac{a^4 n (n-1) (n-2) \\beta(1)}{4\\alpha} \\int_0^1 t^3 \\beta(t)^{\\frac{n-4}{2}}\\ dt. \\end{array}")]]]
)
]

#text("Part (i) (which was extracted with some effort from Section 6 of the ")#link("https://www.proofatlas.ai/papers/sendov-conjecture/SENDOV_CONJECTURE_PROOF_AUGUST_5_2026.pdf")[#text("original AI-generated argument")]#text(") will be deduced from the first and second origin identities ")#link(<tao-78b869235e26652f5653>)[#text("(9)")]#text(", ")#link(<tao-d263d2e0878dfe5d949c>)[#text("(10)")]#text(", as well as the centroid identity ")#link(<tao-37447085f981309300c4>)[#text("(7)")]#text(". Part (ii) will follow from (i) and the polar inequality ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text(", while part (iii) is an elementary consequence of (i).")

#text("As it turns out, the last three terms in ")#link(<tao-d06c731ee09c8fc019b1>)[#text("(21)")]#text(" are asymptotically negligible as ")#mi("{n \\rightarrow \\infty}")#text(". Dropping those terms gives a competing feasibility region for ")#mi("{\\alpha}")#text(" and ")#mi("{\\beta(1)}")#text(" which is disjoint from the one coming from the polar inequality ")#link(<tao-67d4143062b55c25f383>)[#text("(17)")]#text(" (or ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text("):")

#image("../assets/53a0b051ce3cbce443f72b3c510c38d964f77d3b9997c373215ad95da2bffa34-3a53c8e046caf8edebbdaf8d148277ef703a86b1f436dead678c3f59a6d7d3dc.png", width: 90%)

#text("This already suggests that one can use this approach to recover my previous result on Sendov’s conjecture holding for all sufficiently large ")#mi("{n}")#text(". In fact, even with the three error terms in ")#link(<tao-d06c731ee09c8fc019b1>)[#text("(21)")]#text(" added, there is enough room between the two inequalities ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text(", ")#link(<tao-d06c731ee09c8fc019b1>)[#text("(21)")]#text(" to obtain a contradiction for all ")#mi("{n \\geq 5}")#text(" (using the additional bound ")#mi("{\\alpha \\leq 17}")#text(" to control these errors), although showing this for medium-sized ")#mi("{n}")#text(" (such as ")#mi("{5 \\leq n \\leq 200}")#text(") requires a certain amount of computer assistance.")

#text("For fixed ")#mi("{\\alpha}")#text(", the right-hand side of ")#link(<tao-d06c731ee09c8fc019b1>)[#text("(21)")]#text(" is monotone increasing in ")#mi("{\\beta(1)}")#text(" (or equivalently, monotone decreasing in ")#mi("{x}")#text("). In view of ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text(", we can thus replace ")#mi("{\\beta(1)}")#text(" by ")#mi("{\\frac{\\alpha}{3+\\alpha}}")#text(" in this inequality, so that ")#mi("{ax = 1 - \\frac{\\alpha}{n-1} - \\frac{\\beta(1)}{2}}")#text(" is replaced by")

#align(center)[#tao-fit-display[#mitex("c(\\alpha) := 1 - \\frac{\\alpha}{n-1} - \\frac{\\alpha}{2(3+\\alpha)},")]]

#text("and ")#mi("{\\beta(t) = 1 - 2axt + a^2t^2}")#text(" replaced by ")#mi("{1 - 2c(\\alpha) t + a^2 t^2}")#text(". The inequality ")#link(<tao-d06c731ee09c8fc019b1>)[#text("(21)")]#text(" then becomes an inequality involving only ")#mi("{\\alpha}")#text(" and ")#mi("{n}")#text(":")

#metadata(none) <tao-40460da8c882cdc79183>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\begin{array}{rl} 1 \\leq & \\frac{1}{6} + \\frac{1}{4(3+\\alpha)} + \\frac{1}{2(n-1)} + \\frac{1}{4(n-1)(3+\\alpha)} \\\\ & + \\frac{a^4 n (n-1) (n-2)}{4(3+\\alpha)} \\int_0^1 t^3 (1 - 2c(\\alpha) t + a^2 t^2)^{\\frac{n-4}{2}}\\ dt. \\end{array}")]]

#text("We also note that the bounds ")#mi("{0 \\leq c(\\alpha) \\leq xa}")#text(" force the constraint")

#align(center)[#tao-fit-display[#mitex("c(\\alpha)^2 \\leq a^2 = 1 - \\frac{2\\alpha}{n-1}.")]]

#text("This prevents ")#mi("{\\alpha}")#text(" from getting too close to the upper limit ")#mi("{\\frac{n-1}{2}}")#text(" (or ")#mi("{a}")#text(" getting too close to zero).")

#text("We can now eliminate all large degrees, e.g., ")#mi("{n > 200}")#text(", as follows. The quadratic ")#mi("{1 - 2c(\\alpha) t + a^2 t^2}")#text(" attains its minimum at ")#mi("{t =c(\\alpha)/a^2}")#text(". For ")#mi("{t \\leq c(\\alpha)/a^2}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("1 - 2c(\\alpha) t + a^2 t^2 \\leq 1 - c(\\alpha) t \\leq \\exp( - c(\\alpha) t)")]]

#text("while for ")#mi("{c(\\alpha) / a^2 < t \\leq 1}")#text(" (if this region is non-vacuous) we can bound the quadratic by its value ")#mi("{\\frac{\\alpha}{3+\\alpha}}")#text(" at ")#mi("{t=1}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl} & \\int_0^1 t^3 (1 - 2c(\\alpha) t + a^2 t^2)^{\\frac{n-4}{2}}\\ dt \\\\ \\leq & \\int_0^\\infty t^3 \\exp\\left( - \\frac{n-4}{2} c(\\alpha) t\\right)\\ dt + \\int_0^1 t^3 \\left(\\frac{\\alpha}{3+\\alpha}\\right)^{\\frac{n-4}{2}}\\ dt. \\end{array}")]]

#text("Evaluating these expressions, we arrive at")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl} 1 \\leq & \\frac{1}{6} + \\frac{1}{4(3+\\alpha)} + \\frac{1}{2(n-1)} + \\frac{1}{4(n-1)(3+\\alpha)} \\\\ & + \\frac{24 a^4 n (n-1) (n-2)}{(3+\\alpha) (n-4)^4 c(\\alpha)^4} + \\frac{a^4 n (n-1) (n-2)}{16(3+\\alpha)} \\left(\\frac{\\alpha}{3+\\alpha}\\right)^{\\frac{n-4}{2}}. \\end{array}")]]

#text("Since ")#mi("{\\alpha \\leq 17}")#text(", we have ")#mi("{\\frac{\\alpha}{3+\\alpha} \\leq \\frac{17}{20}}")#text(". Next, we claim that ")#mi("{(3+\\alpha) c(\\alpha)^4 \\geq 1}")#text(". As ")#mi("{c(\\alpha)}")#text(" is monotone increasing in ")#mi("{n}")#text(", it suffices to do this when ")#mi("{n=201}")#text(". Here one can directly compute that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{d\\alpha} ((3+\\alpha) c(\\alpha)^4) = - c(\\alpha)^3 \\frac{5(3+\\alpha)^2 - 103(3+\\alpha) + 900}{200(3+\\alpha)} < 0")]]

#text("since the discriminant ")#mi("{-7391}")#text(" of the numerator is negative, we conclude that")

#align(center)[#tao-fit-display[#mitex("(3+\\alpha) c(\\alpha)^4 \\geq (3+17) c(17)^4 \\geq 1.1529\\dots > 1")]]

#text("as desired.")

#text("Dropping some ")#mi("{\\alpha}")#text(" and ")#mi("{a}")#text(" terms, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl} 1 \\leq & \\frac{1}{6} + \\frac{1}{12} + \\frac{7}{12(n-1)} + \\frac{24 n (n-1) (n-2)}{(n-4)^4} \\\\ & + \\frac{n (n-1) (n-2)}{48} \\left(\\frac{17}{20}\\right)^{\\frac{n-4}{2}}. \\end{array}")]]

#text("Every term on the right-hand side can be seen to be decreasing in ")#mi("{n}")#text(" for ")#mi("{n \\geq 201}")#text(". Thus the right-hand side can be bounded by")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl} & \\frac{1}{6} + \\frac{1}{12} + \\frac{7}{12 \\times 200} + \\frac{24 \\cdot 201 \\cdot 200 \\cdot 199}{197^4} \\\\ & + \\frac{201 \\cdot 200 \\cdot 199}{48} \\left(\\frac{17}{20}\\right)^{\\frac{201-4}{2}} \\leq 0.399, \\end{array}")]]

#text("giving the desired contradiction.")

#text("The remaining range to handle is when")

#align(center)[#tao-fit-display[#mitex("5 \\leq n \\leq 200; \\quad 0 \\leq \\alpha \\leq 17; \\quad c(\\alpha)^2 \\leq 1 - \\frac{2\\alpha}{n-1}.")]]

#text("It turns out that ")#link(<tao-40460da8c882cdc79183>)[#text("(22)")]#text(" remains infeasible in this range. This can be illustrated numerically without much difficulty: see ")#link("https://teorth.github.io/tao-web/apps/sendov.html")[#text("this applet")]#text(". For instance, in the most delicate case ")#mi("{n=53}")#text(", the right-hand side of ")#link(<tao-40460da8c882cdc79183>)[#text("(22)")]#text(" only gets as large as ")#mi("{0.853}")#text(" (and in particular stays below ")#mi("{1}")#text(") throughout the range ")#mi("{0 \\leq \\alpha \\leq 17}")#text(":")

#image("../assets/5fae6806cd749b01a471ee3ca11e5654b50551219a4aeda1dfc586af691f6cfe-b3b99716657cab537bf20c22bc32852a795a26a9596afbbca0d9f7f4a2181bcc.png", width: 90%)

#text("I have also ")#link("https://github.com/teorth/sendov")[#text("verified this bound in Lean")]#text(".")

#metadata(none) <tao-df21d92e7ec533c81905>

#heading(level: 1)[#strong[#text(" — 1. The polar inequality — ")]]

#text("We begin with a proof of Proposition ")#link(<tao-f712d322b8f5a7e4431b>)[#text("10")]#text(".")

#text("As is well known, the Möbius transform ")#mi("{z \\mapsto \\frac{a-z}{1-az}}")#text(" maps the closed unit disk to itself. In particular, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1-az_j}{a-z_j}\\right| \\geq 1", block: true)]]

#text("for all of the zeroes ")#mi("{z_j}")#text(". Inserting this into the polar identity ")#link(<tao-fceb18b39be3c1583906>)[#text("(8)")]#text(" and using the triangle inequality, we conclude the lower bound")

#metadata(none) <tao-71f0507892b07a9d1396>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\int_0^1 \\prod_{j=1}^{n-1} |t (1-a^2) q_j + a|\\ dt \\geq 1.")]]

#text("We now convert this bound to a bound involving the quantity ")#mi("{x}")#text(" in ")#link(<tao-c3866d9233f5ede84ef8>)[#text("(12)")]#text(". From the arithmetic mean-geometric mean inequality we have")

#metadata(none) <tao-9ac19f93b725c237147c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\prod_{j=1}^{n-1} \\left|t (1-a^2) q_j + a\\right| \\leq \\left(\\frac{1}{n-1} \\sum_{j=1}^{n-1} \\left|t (1-a^2) q_j + a\\right|^2\\right)^{\\frac{n-1}{2}}", block: true)]]

#text("and from ")#link(<tao-c3866d9233f5ede84ef8>)[#text("(12)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{rl} \\sum_{j=1}^{n-1} \\left|t (1-a^2) q_j + a\\right|^2 = & (n-1) a^2 + 2 (n-1) a t (1-a^2) x \\\\ & + t^2 (1-a^2)^2 \\sum_{j=1}^{n-1} \\left|q_j\\right|^2. \\end{array}", block: true)]]

#text("Since ")#tao-math("{\\left|q_j\\right|^2 \\leq 1}", block: false)#text(", we thus have")

#metadata(none) <tao-2522fb7024fe0a83e6b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\frac{1}{n-1} \\sum_{j=1}^{n-1} \\left|t (1-a^2) q_j + a\\right|^2 \\leq a^2 + 2 a t x (1-a^2) + t^2 (1-a^2)^2", block: true)]]

#text("giving the raw polar inequality ")#link(<tao-a53c716aaaa27d4c6da9>)[#text("(16)")]#text(".")

#text("Bounding ")#mi("{t^2}")#text(" by ")#mi("{t}")#text(" and using the quantities ")#mi("{\\alpha,\\beta(1)}")#text(" from ")#link(<tao-f81ab872625c131d92e7>)[#text("(11)")]#text(", ")#link(<tao-f096890dbb1b514cf178>)[#text("(15)")]#text(", we observe that")

#align(center)[#tao-fit-display[#mitex("a^2 + 2 a t x (1-a^2) + t^2 (1-a^2)^2 \\leq 1 + \\frac{2}{n-1} \\alpha (-1 + (2-\\beta(1)) t).")]]

#text("Using the basic inequality ")#mi("{1 + y \\leq \\exp(y)}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("(a^2 + 2 a t x (1-a^2) + t^2 (1-a^2)^2)^{\\frac{n-1}{2}} \\leq \\exp ( \\alpha (-1 + (2-\\beta(1)) t)),")]]

#text("with strict inequality for ")#mi("{t < 1}")#text(". From ")#link(<tao-a53c716aaaa27d4c6da9>)[#text("(16)")]#text(" we conclude ")#link(<tao-67d4143062b55c25f383>)[#text("(17)")]#text(". This also implies ")#mi("{\\beta(1) < 1}")#text(", since otherwise the integrand is always bounded by ")#mi("{1}")#text(", which is absurd.")

#text("On evaluating the integral in ")#link(<tao-67d4143062b55c25f383>)[#text("(17)")]#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("1 < \\frac{e^{\\alpha (1 - \\beta(1))}- e^{-\\alpha}}{\\alpha (2 - \\beta(1))}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("e^{\\alpha (1 - \\beta(1))} > \\alpha (2 - \\beta(1)) + e^{-\\alpha} \\geq \\alpha,")]]

#text("so on taking logarithms we obtain")

#align(center)[#tao-fit-display[#mitex("1 - \\beta(1) > \\frac{\\log \\alpha}{\\alpha}.")]]

#text("It remains to establish the bound")

#metadata(none) <tao-8c7c169ff0187d6bc754>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\beta(1) < \\frac{\\alpha}{3+\\alpha}.")]]

#text("Here we use an AI-generated argument. One can directly calculate")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 \\exp ( \\alpha (-1 + (2-\\beta(1)) t))\\ dt = e^{-u} \\frac{\\sinh h}{h}")]]

#text("where ")#mi("{u = \\alpha \\beta(1)/2}")#text(" and ")#mi("{h = \\alpha (2-\\beta(1))/2}")#text(". If we can show that")

#metadata(none) <tao-206e59c050468c29d63d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\log \\frac{\\sinh h}{h} \\leq \\sqrt{h^2+9} - 3")]]

#text("for all ")#mi("{h > 0}")#text(", then taking logarithms in ")#link(<tao-67d4143062b55c25f383>)[#text("(17)")]#text(" yields")

#align(center)[#tao-fit-display[#mitex("u < \\log \\frac{\\sinh h}{h} \\leq \\sqrt{h^2+9} - 3")]]

#text("from which ")#link(<tao-8c7c169ff0187d6bc754>)[#text("(26)")]#text(" will follow by routine algebra.")

#text("Both sides of ")#link(<tao-206e59c050468c29d63d>)[#text("(27)")]#text(" vanish at ")#mi("{h=0}")#text(". Taking derivatives, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\coth h - \\frac{1}{h} \\leq \\frac{h}{\\sqrt{h^2+9}}")]]

#text("which rearranges to")

#align(center)[#tao-fit-display[#mitex("h^4 \\sinh^2 h - (h^2+9) (h \\cosh h - \\sinh h)^2 \\geq 0.")]]

#text("To expand the left-hand side, we use the double angle formulae ")#mi("{\\sinh^2 h = \\frac{\\cosh 2h - 1}{2}}")#text(" and")

#align(center)[#tao-fit-display[#mitex("(h \\cosh h - \\sinh h)^2 = \\frac{(h^2+1) \\cosh 2h + (h^2-1)}{2} - h \\sinh 2h")]]

#text("to rewrite it as")

#align(center)[#tao-fit-display[#mitex("\\frac{h^4 (\\cosh 2h - 1)}{2} - (h^2+9) \\left( \\frac{(h^2+1) \\cosh 2h + (h^2-1)}{2} - h \\sinh 2h \\right).")]]

#text("Collecting the coefficient of ")#mi("{h^{2k}}")#text(" for ")#mi("{k \\geq 3}")#text(" and extracting a common factor of ")#mi("{\\frac{2^{2k-3}}{(2k)!}}")#text(", one is left with")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\begin{array}{rl} & N (N-1) (N-2) - 10 N (N-1) + 36 N - 36 \\\\ &= (N-1) (N^2 - 12N + 36) = (N-1) (N-6)^2 \\end{array}")]]

#text("where ")#mi("{N := 2k}")#text(". (The remaining coefficients, which also receive contributions from the polynomial terms, all vanish.) Thus the left-hand side has the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=4}^\\infty \\frac{2^{2k-3} (2k-1) (2k-6)^2}{(2k)!} h^{2k},")]]

#text("in which every coefficient is non-negative, giving the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" As the image in the introduction suggests, the bound ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text(" is only slightly weaker than ")#link(<tao-67d4143062b55c25f383>)[#text("(17)")]#text(". For small ")#mi("{\\alpha}")#text(", one can perform Taylor approximation on the latter bound to obtain")

#align(center)[#tao-fit-display[#mitex("\\beta(1) < \\frac{\\alpha}{3} - \\frac{\\alpha^2}{9} + \\frac{19 \\alpha^3}{540} - \\frac{17 \\alpha^4}{1620} + O(\\alpha^5)")]]

#text("while the former bound is")

#align(center)[#tao-fit-display[#mitex("\\beta(1) < \\frac{\\alpha}{3} - \\frac{\\alpha^2}{9} + \\frac{\\alpha^3}{27} - \\frac{\\alpha^4}{81} + O(\\alpha^5).")]]

#text("Note that ")#mi("{\\frac{19}{540} = 0.0351\\dots}")#text(" is slightly smaller than ")#mi("{\\frac{1}{27} = 0.0370\\dots}")#text(".")

#text("Relating to this, the constant ")#mi("{9}")#text(" in ")#link(<tao-206e59c050468c29d63d>)[#text("(27)")]#text(" cannot be improved.")
]

#heading(level: 1)[#strong[#text(" — 2. The origin inequality — ")]]

#text("Now we turn to the proof of Proposition ")#link(<tao-181fdd46fc4a7246b9f4>)[#text("11")]#text(", which is more difficult and revolves around an analysis of the function ")#mi("{F}")#text(" defined in ")#link(<tao-407eca442505ec8c70f4>)[#text("(6)")]#text(". We begin with a heuristic analysis. Inserting the approximation ")#mi("{1 - \\varepsilon \\approx \\exp(-\\varepsilon)}")#text(" for small ")#mi("{\\varepsilon}")#text(" into ")#link(<tao-407eca442505ec8c70f4>)[#text("(6)")]#text(" and using ")#link(<tao-c3866d9233f5ede84ef8>)[#text("(12)")]#text(", we are led to the approximation ")#metadata(none) <tao-9adf009b9ea42792e73e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("F(t) \\approx \\exp( - (n-1) a t (x+iy) ),")]]

#text(" ")#text(" at least when ")#mi("{t}")#text(" is small (which turns out to be the dominant regime in applications). This suggests a relation")

#metadata(none) <tao-bea3fd1274654ed98579>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\int_0^1 F(t)\\ dt \\approx \\frac{1 - F(1)}{(n-1) a (x+iy)}")]]

#text("between the two expressions involving ")#mi("{F}")#text(" in the origin identities in Lemma ")#link(<tao-13c7351360f0032d02f4>)[#text("6")]#text(". Substituting in this approximation, we obtain some (slightly complicated) approximation for the sum ")#mi("{\\sum_{j=1}^{n-1} \\frac{1}{z_j}}")#text(" in terms of ")#mi("{a}")#text(", ")#mi("{n}")#text(", ")#mi("{x}")#text(", ")#mi("{y}")#text(", and the product ")#mi("{J := \\prod_{j=1}^{n-1} z_j q_j}")#text(".")

#text("As ")#mi("{z_j, q_j}")#text(" lie in the closed unit disk, the product ")#mi("{J}")#text(" does also. However, past experience with the Sendov conjecture has taught us that the worst cases tend to be when ")#mi("{z_j, q_j}")#text(" lie very close to the boundary of the disk, so that ")#tao-math("{\\left|J\\right|}", block: false)#text(" is close to one. For instance, in Example ")#link(<tao-5312fb609f60384731fc>)[#text("4")]#text(" all the ")#mi("{z_j}")#text(" and ")#mi("{q_j}")#text(" lie on the unit circle, and ")#mi("{J = (-1)^{n+1}}")#text(". See Remark 3 of ")#link("https://zbmath.org/6269492")[#text("Dégot")]#text(" or Theorem 1.10(ii) of ")#link("https://zbmath.org/7681950")[#text("my own paper")]#text(" for other places where this heuristic is noted. To simplify the discussion, let us assume for now that ")#tao-math("{\\left|J\\right|}", block: false)#text(" is exactly one, so that ")#mi("{z_j, q_j}")#text(" all lie on the unit circle. This leads in particular to the inversion identities ")#metadata(none) <tao-7705accd2694bdc7c292>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\frac{1}{z_j} = \\overline{z_j}; \\quad \\frac{1}{q_j} = \\overline{q_j}.")]]

#text(" ")#text(" The centroid identity in Lemma ")#link(<tao-13c7351360f0032d02f4>)[#text("6")]#text("(i) relates the sum of the ")#mi("{z_j}")#text(" with the sum of the ")#mi("{1/q_j}")#text(". Using ")#link(<tao-7705accd2694bdc7c292>)[#text("(31)")]#text(", this gives a similar identity relating the sum of the ")#mi("{1/z_j}")#text(" with the sum of the ")#mi("{q_j}")#text(". The latter sum is of course just ")#mi("{(n-1) (x+iy)}")#text(". This combines well with the previous approximation, thus giving an approximate identity relating ")#mi("{x}")#text(", ")#mi("{y}")#text(" to ")#mi("{J}")#text(", ")#mi("{a}")#text(", and ")#mi("{n}")#text(". As it turns out, the roles of ")#mi("{y}")#text(" and ")#mi("{J}")#text(" are minor and can be quickly eliminated for the purposes of obtaining useful bounds, leading eventually to the relation in Proposition ")#link(<tao-181fdd46fc4a7246b9f4>)[#text("11")]#text(".")

#text("We turn to the details. To make the approximation ")#link(<tao-bea3fd1274654ed98579>)[#text("(30)")]#text(" more precise, we note that ")#mi("{F(0)=1}")#text(", and hence by the fundamental theorem of calculus")

#align(center)[#tao-fit-display[#mitex("1 = F(1) - \\int_0^1 F^{\\prime}(t)\\ dt.")]]

#text("The heuristic ")#link(<tao-9adf009b9ea42792e73e>)[#text("(29)")]#text(" predicts that ")#mi("{F^{\\prime}(t) \\approx -(n-1) a(x+iy) F(t)}")#text(", which would give ")#link(<tao-bea3fd1274654ed98579>)[#text("(30)")]#text(". If we actually differentiate ")#link(<tao-407eca442505ec8c70f4>)[#text("(6)")]#text(" carefully, we obtain the exact identity")

#align(center)[#tao-fit-display[#mitex("F^{\\prime}(t) = - (n-1) a(x+iy) F(t) - \\sum_{j=1}^{n-1} a^2 t q_j^2 \\prod_{k \\neq j} (1 - atq_k).")]]

#text("Bounding ")#tao-math("{\\left|q_j^2\\right| \\leq 1}", block: false)#text(", we write this")

#align(center)[#tao-fit-display[#tao-math("F^{\\prime}(t) = - (n-1) a(x+iy) F(t) + O_{\\leq} \\left( a^2 t \\sum_{j=1}^{n-1} \\prod_{k \\neq j} \\left|1 - atq_k\\right| \\right).", block: true)]]

#text("When faced with a similar expression in ")#link(<tao-9ac19f93b725c237147c>)[#text("(24)")]#text(", we used the arithmetic mean-geometric mean inequality. Here, the analogous tool is ")#link("https://en.wikipedia.org/wiki/Maclaurin%27s_inequality")[#text("Maclaurin’s inequality")]#text(", which gives")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{n-1} \\sum_{j=1}^{n-1} \\prod_{k \\neq j} \\left|1 - atq_k\\right| \\leq \\left(\\frac{1}{n-1} \\sum_{j=1}^{n-1} \\left|1 - at q_j\\right|\\right)^{n-2},", block: true)]]

#text("and hence by Cauchy–Schwarz")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{n-1} \\sum_{j=1}^{n-1} \\prod_{k \\neq j} \\left|1 - atq_k\\right| \\leq \\left(\\frac{1}{n-1} \\sum_{j=1}^{n-1} \\left|1 - at q_j\\right|^2\\right)^{\\frac{n-2}{2}}.", block: true)]]

#text("Repeating the calculations used to show ")#link(<tao-2522fb7024fe0a83e6b9>)[#text("(25)")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{n-1} \\sum_{j=1}^{n-1} \\left|1 - at q_j\\right|^2 \\leq 1 - 2 a x t + a^2 t^2 = \\beta(t)", block: true)]]

#text("and so we obtain the bound")

#align(center)[#tao-fit-display[#mitex("F^{\\prime}(t) = - (n-1) a(x+iy) F(t) + O_{\\leq} \\left( a^2 t (n-1) \\beta(t)^{\\frac{n-2}{2}} \\right).")]]

#text("Integrating this, we obtain a rigorous analogue of ")#link(<tao-bea3fd1274654ed98579>)[#text("(30)")]#text(",")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl} 1 - F(1) = & (n-1) a(x+iy) \\int_0^1 F(t)\\ dt \\\\ & + O_{\\leq} \\left( \\int_0^1 a^2 t (n-1) \\beta(t)^{\\frac{n-2}{2}}\\ dt \\right) \\end{array}")]]

#text("and thus by the triangle inequality")

#metadata(none) <tao-cddd67830982a78cc839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#tao-math("\\begin{array}{rl} 1 \\leq & \\left|F(1) + (n-1) a(x+iy) \\int_0^1 F(t)\\ dt\\right| \\\\ & + \\int_0^1 a^2 t (n-1) \\beta(t)^{\\frac{n-2}{2}}\\ dt. \\end{array}", block: true)]]

#text("From the first and second origin identities ")#link(<tao-78b869235e26652f5653>)[#text("(9)")]#text(", ")#link(<tao-d263d2e0878dfe5d949c>)[#text("(10)")]#text(" we have")

#metadata(none) <tao-ca6dc3098879e69a8b63>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\begin{array}{rl} & F(1) + (n-1) a(x+iy) \\int_0^1 F(t)\\ dt \\\\ &= \\frac{(-1)^{n-1} J}{n} \\left(1 + a \\sum_{j=1}^{n-1} \\frac{1}{z_j} + (n-1) a(x+iy) \\right). \\end{array}")]]

#text("The next step is thus to estimate ")#mi("{\\sum_{j=1}^{n-1} \\frac{1}{z_j}}")#text(". When ")#tao-math("{\\left|J\\right|=1}", block: false)#text(", then all the ")#mi("{z_j, q_j}")#text(" were on the unit circle and we could use ")#link(<tao-7705accd2694bdc7c292>)[#text("(31)")]#text(" (and the centroid identity) to proceed. Now, we are no longer assuming ")#tao-math("{\\left|J\\right|}", block: false)#text(" to equal ")#mi("{1}")#text(", but we can still adapt the previous arguments with a loss proportional to ")#tao-math("{1 - \\left|J\\right|^2}", block: false)#text(". The key lemma is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 13 (Defect lemma)")]#text(" Let ")#mi("{w_1,\\dots,w_N}")#text(" be some points in the closed unit disk. Then")

#align(center)[#tao-fit-display[#tao-math("\\prod_{j=1}^N \\left|w_j\\right| \\times \\sum_{j=1}^N \\left|\\frac{1}{w_j} - \\overline{w_j}\\right| \\leq 1 - \\prod_{j=1}^N \\left|w_j\\right|^2.", block: true)]]
]

#emph[#text("Proof:")]#text(" By a limiting argument we may assume that none of the ")#mi("{w_j}")#text(" vanish. If we write ")#tao-math("{\\left|w_j\\right| = e^{-a_j}}", block: false)#text(" for some ")#mi("{a_j \\geq 0}")#text(", then we can calculate that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{w_j} - \\overline{w_j}\\right| = 2 \\sinh a_j", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("1 - \\prod_{j=1}^N \\left|w_j\\right|^2 = \\prod_{j=1}^N \\left|w_j\\right| \\times 2 \\sinh \\sum_{j=1}^N a_j.", block: true)]]

#text("Thus the desired inequality reduces to the superadditivity property")

#align(center)[#tao-fit-display[#mitex("\\sinh \\sum_{j=1}^N a_j \\geq \\sum_{j=1}^N \\sinh a_j.")]]

#text("But from the sinh addition formula ")#mi("{\\sinh(a+b) = \\sinh a \\cosh b + \\sinh b \\cosh a}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sinh(a+b) \\geq \\sinh a + \\sinh b")]]

#text("for all non-negative ")#mi("{a,b}")#text(" (this also follows from the convex nature of ")#mi("{\\sinh}")#text(" together with ")#mi("{\\sinh 0 = 0}")#text("), and the claim follows by induction. ")#mi("\\Box")

#text("We remark that the lemma can also be proven by direct induction, without an appeal to hyperbolic trigonometry.")

#text("From taking complex conjugates of the centroid identity ")#link(<tao-37447085f981309300c4>)[#text("(7)")]#text(" and performing some algebra, we have")

#align(center)[#tao-fit-display[#mitex("J \\sum_{j=1}^{n-1} \\left(\\frac{n-1}{n} \\overline{z_j} + \\frac{1}{\\overline{q_j}}\\right) = a J \\frac{(n-1)^2}{n}.")]]

#text("Using the defect lemma (applied to the points ")#mi("{z_1,\\dots,z_{n-1},\\overline{q_1},\\dots,\\overline{q_{n-1}}}")#text(") and the triangle inequality we conclude that")

#align(center)[#tao-fit-display[#tao-math("J \\sum_{j=1}^{n-1} \\left(\\frac{n-1}{n} \\frac{1}{z_j} + q_j\\right) = a J \\frac{(n-1)^2}{n} + O_{\\leq}\\left( 1 - \\left|J\\right|^2 \\right),", block: true)]]

#text("where as before we are removing singularities when some of the ")#mi("{z_j}")#text(" vanish. Applying ")#link(<tao-c3866d9233f5ede84ef8>)[#text("(12)")]#text(" and some algebraic manipulation, we arrive at")

#align(center)[#tao-fit-display[#tao-math("J \\sum_{j=1}^{n-1} \\frac{1}{z_j} = a J (n-1) - n J (x+iy) + O_{\\leq}\\left( \\frac{n}{n-1} (1 - \\left|J\\right|^2) \\right)", block: true)]]

#text("Substituting this back into ")#link(<tao-ca6dc3098879e69a8b63>)[#text("(33)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{rl} & \\left|F(1) + (n-1) a(x+iy) \\int_0^1 F(t)\\ dt\\right| \\\\ &= \\left| \\frac{\\left|J\\right|}{n} + \\frac{a^2 |J|(n-1)}{n} - a|J| (x+iy) + \\frac{a (n-1) (x+iy) \\left|J\\right|}{n} \\right| \\\\ & \\quad + O_{\\leq}\\left( \\frac{a}{n-1} (1-\\left|J\\right|^2) \\right) \\end{array}", block: true)]]

#text("and hence after some algebra and the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\begin{array}{rl} & \\left|F(1) + (n-1) a(x+iy) \\int_0^1 F(t)\\ dt\\right| \\\\ &\\leq \\left|J\\right| \\left| \\frac{a^2 (n-1)}{n} + \\frac{1}{n} - \\frac{a(x+iy)}{n} \\right| + \\frac{a}{n-1} (1-\\left|J\\right|^2). \\end{array}", block: true)]]

#text("Inserting this into ")#link(<tao-cddd67830982a78cc839>)[#text("(32)")]#text(", we obtain")

#metadata(none) <tao-b44bef8b7080b86d50da>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#tao-math("\\begin{array}{rl} 1 \\leq & \\left|J\\right| \\left| \\frac{a^2 (n-1)}{n} + \\frac{1}{n} - \\frac{a(x+iy)}{n} \\right| + \\frac{a}{n-1} (1-\\left|J\\right|^2) \\\\ & + \\int_0^1 a^2 t (n-1) \\beta(t)^{\\frac{n-2}{2}}\\ dt. \\end{array}", block: true)]]

#text("We can simplify ")#link(<tao-b44bef8b7080b86d50da>)[#text("(34)")]#text(" by reducing to the ")#tao-math("{\\left|J\\right|=1}", block: false)#text(" case. Indeed, we shall show that")

#metadata(none) <tao-adca5146416ee41992ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#tao-math("\\left| \\frac{a^2 (n-1)}{n} + \\frac{1}{n} - \\frac{a(x+iy)}{n} \\right| \\geq 2 \\frac{a}{n-1}", block: true)]]

#text("which implies that the right-hand side of ")#link(<tao-b44bef8b7080b86d50da>)[#text("(34)")]#text(" is non-decreasing in ")#tao-math("{\\left|J\\right|}", block: false)#text(" in the range ")#tao-math("{0 \\leq \\left|J\\right| \\leq 1}", block: false)#text(". Thus we may replace ")#tao-math("{\\left|J\\right|}", block: false)#text(" by ")#mi("{1}")#text(" in ")#link(<tao-b44bef8b7080b86d50da>)[#text("(34)")]#text(" to conclude that")

#metadata(none) <tao-8cf72d362257cfee2728>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#tao-math("1 \\leq \\left| \\frac{a^2 (n-1)}{n} + \\frac{1}{n} - \\frac{a(x+iy)}{n} \\right| + \\int_0^1 a^2 t (n-1) \\beta(t)^{\\frac{n-2}{2}}\\ dt.", block: true)]]

#text("Let us now verify ")#link(<tao-adca5146416ee41992ac>)[#text("(35)")]#text(". Using ")#tao-math("{\\left|x+iy\\right| \\leq 1}", block: false)#text(" and the triangle inequality, we can lower bound")

#align(center)[#tao-fit-display[#tao-math("\\left| \\frac{a^2 (n-1)}{n} + \\frac{1}{n} - \\frac{a(x+iy)}{n} \\right| \\geq \\frac{a^2 (n-1)}{n} + \\frac{1}{n} - \\frac{a}{n}.", block: true)]]

#text("Inserting this into ")#link(<tao-adca5146416ee41992ac>)[#text("(35)")]#text(" and clearing denominators, we reduce after some algebra to")

#align(center)[#tao-fit-display[#mitex("(n-1)^2 a^2 - (3n-1) a + n-1 > 0.")]]

#text("But as a quadratic polynomial in ")#mi("{a}")#text(", the left-hand side has discriminant ")#mi("{(3n-1)^2 - 4(n-1)^3}")#text(", which one can check to be negative for sufficiently large ")#mi("{n}")#text(" (in fact ")#mi("{n \\geq 5}")#text(" suffices), giving the claim ")#link(<tao-adca5146416ee41992ac>)[#text("(35)")]#text(".")

#text("Next we eliminate the role of the imaginary term ")#mi("{iy}")#text(". Observe for any complex number ")#mi("{s+it}")#text(" with positive real part that")

#align(center)[#tao-fit-display[#tao-math("\\left|s+it\\right| \\leq s + \\frac{t^2}{2s}", block: true)]]

#text("as can be seen by squaring both sides. The expression ")#mi("{\\frac{a^2 (n-1)}{n} + \\frac{1}{n} - \\frac{a(x+iy)}{n}}")#text(" has real part")

#align(center)[#tao-fit-display[#mitex("\\frac{a^2 (n-1)}{n} + \\frac{1-ax}{n}")]]

#text("which lies between ")#mi("{\\frac{a^2 (n-1)}{n}}")#text(" and ")#mi("{1}")#text(" (in particular, it is positive), and imaginary part of magnitude at most")

#align(center)[#tao-fit-display[#mitex("\\frac{a}{n} (1 - x^2)^{1/2}")]]

#text("by ")#link(<tao-0ca8d948c5e4d25c9347>)[#text("(13)")]#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\frac{a^2 (n-1)}{n} + \\frac{1}{n} - \\frac{a(x+iy)}{n} \\right| \\leq \\frac{a^2 (n-1)}{n} + \\frac{1-ax}{n} + \\frac{1-x^2}{2n(n-1)}.", block: true)]]

#text("The right-hand side can be rearranged using the quantity ")#mi("{\\alpha}")#text(" from ")#link(<tao-f81ab872625c131d92e7>)[#text("(11)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("1 - \\frac{2\\alpha}{n} - \\frac{ax}{n} + \\frac{1-x^2}{2n(n-1)},")]]

#text("so the bound ")#link(<tao-8cf72d362257cfee2728>)[#text("(36)")]#text(" gives ")#link(<tao-314fcbe98cd1f9c33fd4>)[#text("(19)")]#text(".")

#heading(level: 1)[#strong[#text(" — 2.1. Upper bound on ")#mi("{\\alpha}")#text(" — ")]]

#text("Now we can prove ")#link(<tao-4523540f1504cd17100c>)[#text("(20)")]#text(". Suppose for contradiction that ")#mi("{\\alpha > 17}")#text("; since ")#mi("{\\alpha \\leq \\frac{n-1}{2}}")#text(", this implies that ")#mi("{n \\geq 36}")#text(". Crudely discarding the ")#mi("{ax}")#text(" term in ")#link(<tao-314fcbe98cd1f9c33fd4>)[#text("(19)")]#text(" and bounding ")#mi("{\\frac{1-x^2}{2(n-1)}}")#text(" by ")#mi("{\\frac{1}{2(n-1)}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("2 \\alpha \\leq \\frac{1}{2(n-1)} + a^2 n(n-1) \\int_0^1 t \\beta(t)^{\\frac{n-2}{2}}\\ dt.")]]

#text("The quadratic polynomial ")#mi("{\\beta(t)}")#text(" equals ")#mi("{1}")#text(" at ")#mi("{t=0}")#text(" and attains its minimum at ")#mi("{t = x/a}")#text(" with value ")#mi("{1-x^2}")#text(". By convexity, we thus have")

#align(center)[#tao-fit-display[#mitex("\\beta(t) \\leq 1 - axt \\leq \\exp(-axt)")]]

#text("for ")#mi("{0 \\leq t \\leq x/a}")#text(" and")

#align(center)[#tao-fit-display[#mitex("\\beta(t) \\leq \\beta(1)")]]

#text("for ")#mi("{x/a \\leq t \\leq 1}")#text(" (this latter statement is vacuous if ")#mi("{x/a > 1}")#text("). Since ")#mi("{\\int_0^1 t\\ dt = \\frac{1}{2}}")#text(", we can therefore crudely bound")

#tao-aligned(keep: true)[


#tao-math("\\int_0^1 t (1 - 2 a x t + a^2 t^2)^{\\frac{n-2}{2}}\\ dt  & \\leq \\int_0^\\infty t \\exp\\left( - \\frac{n-2}{2} axt\\right)\\ dt + \\frac{1}{2} \\beta(1)^{\\frac{n-2}{2}}", block: true)



#tao-math(" & = \\frac{4}{(n-2)^2 a^2 x^2} + \\frac{1}{2} \\beta(1)^{\\frac{n-2}{2}},", block: true)
]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("2 \\alpha \\leq \\frac{1}{2(n-1)} + \\frac{4n(n-1)}{(n-2)^2 x^2} + \\frac{a^2 n(n-1)}{2} \\beta(1)^{\\frac{n-2}{2}}.")]]

#text("From ")#link(<tao-f096890dbb1b514cf178>)[#text("(15)")]#text(" we have ")#mi("{x^2 \\geq 1-\\beta(1)}")#text(", thus by ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x^2} \\leq \\frac{\\alpha}{\\log \\alpha}.")]]

#text("From another application of ")#link(<tao-5fa61555c7af2e96a6b5>)[#text("(18)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\beta(1) \\leq \\exp( - (1 - \\beta(1)) ) \\leq \\alpha^{-1/\\alpha}.")]]

#text("We conclude that")

#align(center)[#tao-fit-display[#mitex("2 \\alpha \\leq \\frac{1}{2(n-1)} + \\frac{4n(n-1)}{(n-2)^2 \\log \\alpha} \\alpha + \\frac{a^2 n(n-1)}{2} \\alpha^{-\\frac{n-2}{2\\alpha}}.")]]

#text("It is now convenient to introduce the quantity ")#mi("{u := \\frac{a^2}{1-a^2}}")#text(", thus ")#mi("{0 < u < \\infty}")#text(" with")

#align(center)[#tao-fit-display[#mitex("a^2 = \\frac{u}{1+u}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{n-2}{2 \\alpha} = 1 + u - \\frac{1}{2\\alpha}.")]]

#text("Inserting these bounds and dividing by ")#mi("{\\alpha}")#text(", we conclude")

#align(center)[#tao-fit-display[#mitex("2 \\leq \\frac{1}{2(n-1) \\alpha} + \\frac{4n(n-1)}{(n-2)^2 \\log \\alpha} + \\frac{u}{2(1+u) \\alpha^2} n(n-1) \\alpha^{-u} \\alpha^{\\frac{1}{2\\alpha}}.")]]

#text("Since ")#mi("{\\alpha = \\frac{n-1}{2(1+u)}}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("2 \\leq \\frac{1}{2(n-1) \\alpha} + \\frac{4n(n-1)}{(n-2)^2 \\log \\alpha} + \\frac{2n}{n-1} u (1+u) \\alpha^{-u} \\alpha^{\\frac{1}{2\\alpha}}.")]]

#text("Since ")#mi("{n \\geq 36}")#text(" and ")#mi("{\\alpha \\geq 17}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("2 \\leq \\frac{1}{2 \\times 35 \\times 17} + \\frac{4 \\times 36 \\times 35}{(34)^2 \\log 17} + \\frac{2 \\times 36}{35} u (1+u) 17^{-u} 17^{\\frac{1}{2 \\times 17}}.")]]

#text("Routine calculus shows that ")#mi("{u(1+u) 17^{-u}}")#text(" has a maximum of at most ")#mi("{0.1825}")#text(", and that the right-hand side here is at most ")#mi("{1.948}")#text(", giving the required contradiction. This proves ")#link(<tao-4523540f1504cd17100c>)[#text("(20)")]#text(".")

#heading(level: 1)[#strong[#text(" — 2.2. A simplified estimate — ")]]

#text("Now we show ")#link(<tao-d06c731ee09c8fc019b1>)[#text("(21)")]#text(". Note from ")#link(<tao-f81ab872625c131d92e7>)[#text("(11)")]#text(" that ")#metadata(none) <tao-a73fcf33964092920728>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("1-a^2 = \\frac{2\\alpha}{n-1}")]]

#text(" ")#text(" while from ")#link(<tao-f096890dbb1b514cf178>)[#text("(15)")]#text(" we have")

#metadata(none) <tao-a048e640908046be06e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("1 - x^2 \\leq \\beta(1)")]]

#text("and hence also")

#metadata(none) <tao-a5b19b53992e7863d245>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("\\frac{1}{x^2} \\leq 1 + \\frac{\\beta(1)}{1-\\beta(1)}.")]]

#text("From ")#link(<tao-f096890dbb1b514cf178>)[#text("(15)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\beta(t) = (1 - axt)^2 + a^2 t^2 (1-x^2).")]]

#text("By the mean value theorem (noting that ")#mi("{1-axt}")#text(" is non-negative) we thus have")

#align(center)[#tao-fit-display[#mitex("\\beta(t)^{\\frac{n-2}{2}} \\leq \\left((1 - axt)^2\\right)^{\\frac{n-2}{2}} + a^2 t^2 (1-x^2) \\frac{n-2}{2} \\beta(t)^{\\frac{n-4}{2}}.")]]

#text("From the standard beta function identity")

#align(center)[#tao-fit-display[#mitex("\\int_0^{1/ax} t (1 - axt)^{n-2}\\ dt = \\frac{1}{a^2 x^2 n(n-1)}")]]

#text("(and the fact that ")#mi("{1/ax \\geq 1}")#text(") we can thus replace ")#link(<tao-314fcbe98cd1f9c33fd4>)[#text("(19)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl} 2\\alpha + ax \\leq & \\frac{1-x^2}{2(n-1)} + \\frac{1}{x^2} \\\\ & + \\frac{a^4 n (n-1) (n-2) (1-x^2)}{2} \\int_0^1 t^3 \\beta(t)^{\\frac{n-4}{2}}\\ dt. \\end{array}")]]

#text("From ")#link(<tao-f096890dbb1b514cf178>)[#text("(15)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("ax = 1 - \\frac{\\beta(1)}{2} - \\frac{1-a^2}{2}.")]]

#text("Thus by ")#link(<tao-a73fcf33964092920728>)[#text("(37)")]#text(", ")#link(<tao-a048e640908046be06e0>)[#text("(38)")]#text(", ")#link(<tao-a5b19b53992e7863d245>)[#text("(39)")]

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl} 2\\alpha \\leq & \\frac{\\beta(1)}{1-\\beta(1)} + \\frac{\\beta(1)}{2} + \\frac{\\alpha}{n-1} + \\frac{\\beta(1)}{2(n-1)} \\\\ & + \\frac{a^4 n (n-1) (n-2) \\beta(1)}{2} \\int_0^1 t^3 \\beta(t)^{\\frac{n-4}{2}}\\ dt. \\end{array}")]]

#text("Dividing by the positive quantity ")#mi("{2\\alpha}")#text(" gives the claim.")

#heading(level: 1)[#strong[#text(" — 3. Rubinstein’s theorem — ")]]

#text("We now adapt the arguments to give a proof of Rubinstein’s theorem that the Phelps–Rodriguez conjecture holds in the ")#mi("{a=1}")#text(" case, i.e.,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Rubinstein’s theorem)")]#text(" Let ")#mi("{n \\geq 2}")#text(", and let ")#mi("{p : {\\bf C} \\rightarrow {\\bf C}}")#text(" be a degree ")#mi("{n}")#text(" polynomial with all zeroes in the unit disk. If ")#mi("{p(1)=0}")#text(", then there exists a critical point ")#mi("{\\zeta}")#text(" of ")#mi("{p}")#text(" with ")#tao-math("{\\left|\\zeta-1\\right| < 1}", block: false)#text(", unless ")#mi("{p}")#text(" is a scalar multiple of ")#mi("{z^n - 1}")#text(".")
]

#text("The argument here is essentially in Remark 5.1 of ")#link("https://arxiv.org/abs/2508.10341")[#text("this paper of Tang and Zhang")]#text(".")

#text("Taking contrapositives, we may assume that the critical points ")#mi("{\\zeta_j}")#text(" are of the form ")#mi("{1 - 1/q_j}")#text(" for some ")#mi("{q_j}")#text(" in the closed unit disk, and normalize ")#mi("{p}")#text(" to be monic; our task is to show that ")#mi("{p(z) = z^n-1}")#text(".")

#text("The polar identity ")#link(<tao-fceb18b39be3c1583906>)[#text("(8)")]#text(", based on calculating ")#mi("{p(1/a) / p^{\\prime}(a)}")#text(" degenerates to a triviality when ")#mi("{a=1}")#text(", but we have the following usable substitute, valid for any choice of ")#mi("{a}")#text(", first observed in equation (3.2) of ")#link("https://zbmath.org/3308557")[#text("Meir–Sharma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15 (Meir–Sharma identity)")]#text(" ")#metadata(none) <tao-2830b59f44603921a809>#text(" If ")#mi("{p(a)=0}")#text(" and the critical points are of the form ")#mi("{a - 1/q_j}")#text(" then all the zeroes ")#mi("{z_j}")#text(" are not equal to ")#mi("{a}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^{n-1} q_j = 2 \\sum_{j=1}^{n-1} \\frac{1}{a-z_j}.")]]
]

#emph[#text("Proof:")]#text(" By hypothesis, ")#mi("{a}")#text(" is not a critical point of ")#mi("{p}")#text(", so ")#mi("{p^{\\prime}(a) \\neq 0}")#text(" and ")#mi("{z_j \\neq a}")#text(" for all ")#mi("{j}")#text(". Instead of computing ")#mi("{p(1/a)/p^{\\prime}(a)}")#text(", we instead consider the expression ")#mi("{p^{\\prime\\prime}(a) / p^{\\prime}(a)}")#text(". On the one hand, from ")#link(<tao-46e16b2a1816cc420116>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p^{\\prime}(a) = n \\prod_{j=1}^{n-1} \\frac{1}{q_j}")]]

#text("while from differentiating ")#link(<tao-46e16b2a1816cc420116>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p^{\\prime\\prime}(a) = n \\prod_{j=1}^{n-1} \\frac{1}{q_j} \\times \\sum_{j=1}^{n-1} q_j.")]]

#text("Meanwhile, from ")#link(<tao-04fd1dfb96fca8b4ff30>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p^{\\prime}(a) = \\prod_{j=1}^{n-1} (a-z_j)")]]

#text("and from differentiating ")#link(<tao-04fd1dfb96fca8b4ff30>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("p^{\\prime\\prime}(a) = \\left(\\prod_{j=1}^{n-1} (a-z_j)\\right) \\times \\left( \\sum_{j=1}^{n-1} \\frac{1}{a-z_j} + \\sum_{j=1}^{n-1} \\frac{1}{a-z_j} \\right).")]]

#text("Using these identities to compute ")#mi("{p^{\\prime\\prime}(a) / p^{\\prime}(a)}")#text(" in two different ways gives the claim. ")#mi("\\Box")

#text("Now take ")#mi("{a=1}")#text(". Since ")#mi("{z_j}")#text(" lie in the closed unit disk, ")#mi("{\\frac{1}{1-z_j}}")#text(" has real part at least ")#mi("{1/2}")#text(", while ")#mi("{\\mathrm{Re} q_j}")#text(" is at most ")#mi("{1}")#text(". Thus, the only way that the above identity can hold is if ")#mi("{\\mathrm{Re} q_j = 1}")#text(" for all ")#mi("{j}")#text(", hence ")#mi("{q_j = 1}")#text(" for all ")#mi("{j}")#text(". Thus all critical points are at the origin, which forces ")#mi("{p(z) = z^n - c}")#text(" for some ")#mi("{c}")#text(". Since ")#mi("{p(1)=0}")#text(", we conclude that ")#mi("{c=1}")#text(", giving the claim.")

#heading(level: 1)[#strong[#text(" — 4. The ")#mi("{n \\leq 4}")#text(" cases — ")]]

#text("We now prove the ")#mi("{n \\leq 4}")#text(" cases of Conjecture ")#link(<tao-6b6b85aed8adda90f7a7>)[#text("3")]#text(". The starting point is ")#link(<tao-71f0507892b07a9d1396>)[#text("(23)")]#text(". Using the triangle inequality and ")#tao-math("{\\left|q_j\\right| \\leq 1}", block: false)#text(", this implies that")

#align(center)[#tao-fit-display[#mitex("1 \\leq \\int_0^1 (a+(1-a^2) t)^{n-1}\\ dt.")]]

#text("(This also follows from ")#link(<tao-a53c716aaaa27d4c6da9>)[#text("(16)")]#text(" and ")#mi("{x \\leq 1}")#text(".) From Hölder’s inequality and ")#mi("{n \\leq 4}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("1 \\leq \\int_0^1 (a+(1-a^2) t)^3\\ dt.")]]

#text("The right-hand side can be computed to equal")

#align(center)[#tao-fit-display[#mitex("1 - \\frac{(a-1)^2}{4} (a^2 (1-a)^2 + 3(1-a^2) + 2a),")]]

#text("which is obviously less than ")#mi("{1}")#text(" for ")#mi("{0 \\leq a < 1}")#text(", giving the contradiction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" The same argument also works for ")#mi("{n=5}")#text(", but breaks down for higher ")#mi("{n}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 5. Further directions — ")]]

#text("The Sendov and Phelps–Rodriguez conjectures are now resolved, but several related conjectures remain open. The following strengthening of Sendov’s conjecture, by Borcea, is open for any ")#mi("{q < \\infty}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 17 (Borcea conjecture)")]#text(" Let ")#mi("{1 \\leq q < \\infty}")#text(" and ")#mi("{n \\geq 2}")#text(", and let ")#mi("{p}")#text(" be a degree ")#mi("{n}")#text(" polynomial with zeroes ")#mi("{z_1,\\dots,z_n}")#text(" satisfying ")#tao-math("{\\frac{1}{n} \\sum_{j=1}^n \\left|z_j\\right|^q \\leq 1}", block: false)#text(". Then for every zero ")#mi("{a}")#text(" of ")#mi("{p}")#text(", there exists a critical point ")#mi("{\\zeta}")#text(" of ")#mi("{p}")#text(" with ")#tao-math("{\\left|\\zeta - a\\right| \\leq 1}", block: false)#text(".")
]

#text("Sendov’s conjecture is the limiting case ")#mi("{q=\\infty}")#text(" of this conjecture. There has been relatively little progress on this conjecture: the cases ")#mi("{(q,n) = (1,3), (2,4)}")#text(" were established ")#link("https://zbmath.org/6075447")[#text("by Khavinson, Pereira, Putinar, Saff, and Shimorin")]#text(", and in ")#link("https://terrytao.wordpress.com/2025/11/05/mathematical-exploration-and-discovery-at-scale/")[#text("this previous paper")]#text(" we reported the negative result that AlphaEvolve failed to find a counterexample to the conjecture. The proof methods here do not seem to extend easily; all the identities relating zeroes and critical points continue to hold, but now that the ")#mi("{z_j}")#text(" are only constrained to the unit disk in an averaged moment sense, all of the inequalities developed above now fail.")

#text("Another strengthening of Sendov’s conjecture that remains open is ")#link("https://zbmath.org/3539507")[#text("Schmeisser’s conjecture")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 18 (Schmeisser’s conjecture)")]#text(" Let ")#mi("{n \\geq 2}")#text(", and let ")#mi("{p}")#text(" be a degree ")#mi("{n}")#text(" polynomial with all zeroes in the closed unit disk. Then for any ")#mi("{a}")#text(" in the convex hull of the zeroes of ")#mi("{p}")#text(", there exists a critical point ")#mi("{\\zeta}")#text(" of ")#mi("{p}")#text(" with ")#tao-math("{\\left|\\zeta - a\\right| \\leq 1}", block: false)#text(".")
]

#text("Schmeisser proved several special cases of this conjecture, and AlphaEvolve again failed to find a counterexample, but there has not been much further progress. Here, the ")#mi("{z_j}")#text(" are now back in the closed unit disk, but we no longer have ")#mi("{p(a)=0}")#text(", again rendering most of the previous identities invalid. But perhaps some modification of the arguments here can make some progress on this conjecture.")

#text("A common generalization of the Borcea and Schmeisser conjectures was proposed in Conjecture 2.4 of ")#link("https://arxiv.org/abs/2411.07105")[#text("this paper of Zhang")]#text(". A slightly different strengthening was also proposed in Conjecture 1.10 of ")#link("https://arxiv.org/abs/2508.10341")[#text("Tang and Zhang")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 19 (Tang–Zhang conjecture)")]#text(" Let ")#mi("{n \\geq 2}")#text(", and let ")#mi("{p}")#text(" be a degree ")#mi("{n}")#text(" polynomial with all zeroes in the closed unit disk and critical points ")#mi("{a - 1/q_j}")#text(". Then for any ")#mi("{\\lambda \\geq 1}")#text(", one has ")#tao-math("{\\sum_{j=1}^{n-1} \\left|q_j\\right|^\\lambda \\geq n-1}", block: false)#text(".")
]

#text("Sendov’s conjecture is the limiting case ")#mi("{\\lambda = \\infty}")#text(". By Hölder’s inequality, the ")#mi("{\\lambda=1}")#text(" case is the strongest form of the conjecture.")

#text("Another well known variant of Sendov’s conjecture is ")#link("https://zbmath.org/3713836")[#text("Smale’s problem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 20 (Smale’s problem)")]#text(" Let ")#mi("{n \\geq 2}")#text(", and let ")#mi("{p}")#text(" be a degree ")#mi("{n}")#text(" polynomial. Then for any zero ")#mi("{a}")#text(" of ")#mi("{p}")#text(", there exists a critical point ")#mi("{\\zeta}")#text(" of ")#mi("{p}")#text(" with ")#tao-math("{\\left|p(\\zeta)\\right| \\leq (1-\\frac{1}{n}) \\left|\\zeta-a\\right| \\left|p^{\\prime}(a)\\right|}", block: false)#text(".")
]

#text("The constant ")#mi("{1-\\frac{1}{n}}")#text(" is best possible, as can be seen by the example ")#mi("{p(z) = z^n-z}")#text(" and ")#mi("{a=0}")#text(". Using the Koebe one-quarter theorem, Smale proved this conjecture with ")#mi("{1 - \\frac{1}{n}}")#text(" replaced by ")#mi("{4}")#text(". Some slight improvements of this bound have been obtained over the years; for instance for ")#mi("{n \\geq 8}")#text(", the improved bound of ")#mi("{4 - \\frac{2.263}{\\sqrt{n}}}")#text(" was ")#link("https://zbmath.org/5214827")[#text("obtained by Crane")]#text(". Again, AlphaEvolve failed to find a counterexample to this conjecture. This problem does not seem to have a direct relationship with Sendov’s conjecture, and there is no useful normalization of the zeroes and critical points that is confined to the unit disk. Nevertheless there may be some hope of making progress on this conjecture, perhaps working first in the asymptotic regime ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("Needless to say, I did try some desultory attempts to use AI tools to attack these questions, but without much notable success.")

#text("One potential way forward is to find further proofs of Sendov’s conjecture that utilize other techniques that might be more broadly applicable to this larger family of problems. The proof here is remarkable in that the zeroes and critical points are treated almost as independent mathematical objects, communicating with each other only very narrowly through four identities in which one only inspects the underlying polynomial (and its derivative) at a small number of points. It could be that an approach focusing on more global features of the polynomial may lead to new proofs of Sendov’s conjecture, and perhaps also of its generalizations.")

#heading(level: 1)[#text("Comments (48)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693888")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2026")])]

#text("What changes to the university mathematics curriculum need to be made in order to produce people who are experts at digesting mathematical proofs?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2026")])]

#text("In order to “digest” the proof, they should be at least familiar with the basic materials for the required subject no? I don’t see any necessary significant changes to the curriculum other than the fact that homework or take home exams might be obsolete")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("Not sure how can students learn the basic materials without doing homework.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("Homework is optional but strongly recommended to be done without the use of LLMs. Your grades are based solely upon in person exams done in person and on pen and paper without the use of LLMs.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693905")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("Even without large language models, you still have humans coming up with incomprehensible proofs that nobody understands. See for example Mochizuki’s IUT “proof” of the abc conjecture. So any changes to the curriculum needs to be aimed at preventing another Mochizuki from happening in the future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("The solution to Mochizuki is to ignore him since he can’t explain his proof. The problem with large language models is that it produces a million different Mochizukis that overwhelm the peer review system and prevent the rest of the mathematics community from ignoring them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693912")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("The way things are going, proving and understanding theorems in pure mathematics is going to become a hobby. There won’t be much of a university mathematics curriculum at all because Trump’s funding cuts are going to destroy academia and the university system.")

#text("Perhaps some areas of applied mathematics are still going to be around in polytechnics or trade schools, like statistics or actuarial science or classical mechanics. But you can simply forget about much of the abstract formal higher mathematics in universities.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693930")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("Trump is just destroying academia in the United States. He doesn’t have any power to destroy academia elsewhere around the world. Go outside of the United States if you still want a job as a mathematician in academia.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2026")])]

#text("It may also be interesting to ask whether Sendov’s conjecture sits inside a stronger geometric statement concerning the steepest-ascent trajectories of the polynomial logarithmic potential.")

#text("For ")#tao-fit-display[#tao-math("P(z)=\\prod_{j=1}^N(z-a_j), \\qquad \\left|a_j\\right|\\le 1,", block: true)]#text(" consider a finite steepest-ascent branch of ")#tao-math("\\log\\left|P\\right|", block: false)#text(" from a root ")#mi("a_j")#text(" to its terminal critical point ")#mi("c_{a_j}")#text(". I have been investigating the conjectural bound ")#tao-fit-display[#mitex("\\operatorname{length}(\\gamma_j)\\le 1")]#text(" (for ")#mi("N\\ge 4")#text("; there are counterexamples for ")#mi("N=3")#text("). Since ")#tao-fit-display[#tao-math("\\left|a_j-c_{a_j}\\right|\\le \\operatorname{length}(\\gamma_j),", block: true)]#text(" such a bound would imply Sendov while replacing the existential root–critical-point connection by a canonical geometric one.")

#text("I have described the conjecture, its inverse-branch formulation, numerical evidence, and a possible variational approach here: ")#link("https://math.stackexchange.com/questions/5100337/length-bound-for-a-ray-lift-off-from-a-critical-point-of-a-polynomial")[#text("https://math.stackexchange.com/questions/5100337/length-bound-for-a-ray-lift-off-from-a-critical-point-of-a-polynomial")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da89daf911970c1c90a5e4edb8da419937140368c026105efd3e1dac126021b7-fea24ca2115fb708ac13b8abcae20e2e49e76c7ff7dc6607dea2643ee61d8e9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Kuhn")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693891")[#strong[#text("Nick Kuhn")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2026")])]

#text("I think the term “AI ")#emph[#text("tool")]#text("” is redundant at best and misleading at worst (usually tools are targeted for a specific task rather than just being generally good at something).")

#text("Just “AIs” seems cleaner and better for the discourse.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78a9668bc87019752cb588bedfb132969716da2b1ab8a8011686d2ed1f85a762-708e5329096987355205cc66198457a7ab335f430826992f68908126a8759e5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lech Mazur")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693895")[#strong[#text("Lech Mazur")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2026")])]

#text("I should mention that the version of the proof analyzed here is an extreme case of the tradeoff between AI- and human-friendliness. It was deliberately optimized for ease of verification in Lean and avoided external theorems that would have had to be formalized separately. It was also designed to keep the mathematical argument compact and auditable rather than conceptually transparent. Its target is the AI-agent-first ProofAtlas.ai, not a preprint (I’d like to eventually have explanations and notes on that website that are digestible to human mathematicians but that is not my priority at the moment and I figured that anybody interested enough to want to “read” it would be able to use AI to transform it into something that makes sense to them much more effectively than I could with some generalizable workflow.)")

#text("Also, most of the Lean code consisted of generated certificate machinery, not individually AI-written proof code. There were about 17k “authored” lines of Lean out of ~93k total lines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693897")[#strong[#text("Teng")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("About a month ago, I made your “sufficiently large” n_0 explicit, showing that one can take n_0 = 10^200000; see ")#link("https://zhangteng2000.github.io/files/sendov_conjecture_large_n.pdf")[#text("https://zhangteng2000.github.io/files/sendov_conjecture_large_n.pdf")]#text(". Perhaps this bound could be reduced further with the help of AI, but I did not try. In any case, I am very glad to see that Sendov’s conjecture has finally been resolved. In the past, I spent many years trying to approach the problem using methods based on the spectral radius of matrices, but without success.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50caaf1b7970b6f840b45422620b094bc380e0ac9eeedb8ff59d670fe1081cb-665fe8e053890f5ede9036e48bfcda4470030b00623db74827f05f80b6bb3a8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff Pickhardt")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693908")[#strong[#text("Jeff Pickhardt")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("I was curious about it and did something similar about a month ago here, also getting an extremely high number: ")#link("https://omniscienceproject.com/papers/an-explicit-high-degree-threshold-for-sendovs-conjecture-deEGnk8R")[#text("https://omniscienceproject.com/papers/an-explicit-high-degree-threshold-for-sendovs-conjecture-deEGnk8R")]

#text("It seemed clear that a different strategy would be needed for proving Sendov. What’s interesting about this new proof is what Tao said, it being “remarkably elementary.” One would have thought it would require something more powerful, given how long it had been around and how many people had looked into it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("In any case, Sendov’s conjecture was resolved in such an unexpected way. I would not have been surprised if the proof had involved methods from complex analysis and matrix theory, since the Schoenberg conjecture itself was solved using matrix methods. And now, the great garden of mathematics has gained yet another beautiful theorem. Cheers!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("It would extremely helpful if you could share the exact details and process that you followed to generate the Lean proof.")

#text("In the code repository it says:")#linebreak()#link("https://github.com/teorth/sendov#how-this-was-produced")[#text("https://github.com/teorth/sendov#how-this-was-produced")]#linebreak()#text("“””")#linebreak()#text("Essentially all of the Lean source in this repository was written by Claude Opus 5 (Anthropic), working interactively in Claude Code under the direction and review of the author: choosing the Lean formulations, finding and repairing proofs, and designing the certificate machinery. The author set the targets, supplied the informal proof and the staged plans in docs/, made the mathematical decisions, and reviewed the output as it was produced.")#linebreak()#text("“””")#linebreak()#text("but it is very hard to tell how this is really done hands-down.")

#text("Sharing all the details of the process would be a great example for other Mathematicians how this is done so that we can follow suit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693910")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("I have created an AI-generated summary of my conversations with the coding agent ")#link("https://github.com/teorth/sendov/blob/master/docs/making-of.md")[#text("here")]#text(". I also directed the agent to generate ")#link("https://github.com/teorth/sendov/blob/master/docs/getting-started.md")[#text("some general instructions")]#text(" on how to start a “vibe-formalized” Lean formalization of an existing informal proof (bearing in mind that, in the absence of genuine Lean coding experience, such a formalization will only be able to certify that a formal argument is valid, without providing any high quality code for later reuse).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4edcc55e0461a466998593be384f03bf2b128bc2ffc5665880d3bc243787bce-65f1a5c619cc52cf46c42630af9b8803e48cfa42a264eb8050108412bbfa10c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anton Shakov")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693907")[#strong[#text("Anton Shakov")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("Hi Dr. Tao,")

#text("Having thought about Sendov’s conjecture for a number of years, I wanted to ask you a few questions.")

#enum(start: 1, 
[#text("Which part(s) of the proof do you think represent the key insight that human researchers hadn’t previously found?")],
[#text("Are you more impressed that the LLM was able to find this proof, or surprised that humans had not been able to until now?")],
[#text("Do you think it would be possible to describe the approach to a knowledgeable mathematician who could then fill in the details, or is the proof too reliant on hyperspecific silver-bullet identities? (perhaps the Polar and Origin inequalities).")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("The key feature of Sendov’s conjecture which seems to not have been previously appreciated is that there is actually quite a bit of “room” in the conjecture, allowing for relatively crude and elementary approaches to succeed. This is most visible in the second diagram in this blog post, with the highly visible separation between the feasible region in blue provided by the polar inequality, and the (asymptotic) feasible region in red provided by the origin inequality, with the only delicate point being the treatment of the regime in which ")#mi("\\alpha")#text(" and ")#mi("\\beta(1)")#text(" are both close to zero. Previously, the conventional wisdom was that the conjecture was quite delicate and would require a sophisticated analysis of various objects derived from the polynomial ")#mi("p")#text(". Instead, the proof is almost the opposite: one treats the zeroes ")#mi("z_j")#text(" and critical points ")#mi("a - 1/q_j")#text(" almost as independent sets of complex numbers, connected only very loosely by a small number of key identities. This is quite a conceptual departure from the original setup, in which the zeroes of the polynomial completely determine the critical points, as well as vice versa (once one fixes ")#mi("a")#text("). Despite giving up all this information and effectively increasing the number of degrees of freedom from ")#mi("n-O(1)")#text(" to ")#mi("2n-O(1)")#text(" complex variables, the problem almost completely collapses (after applying Maclaurin’s inequality etc.) to a two-parameter problem involving just two real statistics ")#mi("\\alpha, \\beta(1)")#text(" (and the degree ")#mi("n")#text("), which is well within range of a traditional numerical analysis (for small and medium ")#mi("n")#text(") or asymptotic analysis (for large ")#mi("n")#text(").")

#text("In retrospect, the analysis in Section 4 of my paper (partially reproduced here in Example 5, and inspired by earlier perturbative analysis of Miller) also indicated this sort of two-dimensional collapse of the problem (with the relevant parameters in my analysis being ")#mi("c_2")#text(" and ")#mi("\\sum_j \\lambda_j^2")#text("), but my analysis was perturbative around what would be the ")#mi("\\alpha=\\beta(1)=0")#text(" endpoint in the current blog post, and I did not foresee that a suitable modification of this type of two-dimensional reduction would end up solving the entire problem. [EDIT: in fact this “room” in Sendov’s conjecture was already anticipated (with completely different notation, and again only detected in the extremely perturbative regime, with ")#mi("\\alpha")#text(" and ")#mi("\\beta(1)")#text(" sufficiently small depending on ")#mi("n")#text(") in the discussion after Theorem 3 of ")#link("https://www.sciencedirect.com/science/article/pii/S0022247X83711947")[#text("Miller’s 1993 paper")]#text(", where he calls it “quite startling”. So perhaps this approach was latent in the literature after all…]")

#text("As Lech mentioned, this type of low-tech approach is well suited for both AI search and for formalization, but has a high probability of failure and would likely require many repeated attempts before landing on a good set of parameters to study and elementary inequalities to exploit. So it is an approach that, in retrospect, would have been easier for an AI to locate than an expert human. It would still be good to locate a more conceptual proof though. On the other hand, the amount of room present in this proof bodes well for being able to establish stronger conjectures such as the Borcea or Schmeisser conjectures. There, one may end up combining these rather minimalist structural facts coupling zeroes and critical points together with more sophisticated relations between these two sets.")

#text("If one had to summarize the proof in such a way that a knowledgeable mathematician (human or AI) could reconstruct it, I would describe it as this: first, find a small number of equations relating the zeroes and critical points of a putative counterexample by evaluating the expression ")#mi("p(1/a)/p^{\\prime}(a)")#text(" as well as the first two and last two coefficients of ")#mi("p")#text(" in terms of either the zeroes or the critical points. Then, use those equations and elementary inequalities (such as Maclaurin’s inequality) to relate the special zero ")#mi("a")#text(" to the mean ")#mi("x")#text(" of the normalized critical points ")#mi("q_j = \\frac{1}{a-w_j}")#text(" (which, incidentally, is proportional to the real part of ")#mi("p^{\\prime\\prime}(a)/p^{\\prime}(a)")#text(", although this fact is not particularly useful in the argument). Then, use asymptotic analysis (for large ")#mi("n")#text(") or numerical analysis (for small ")#mi("n")#text(") to show that these inequalities lead to a contradiction; there some room here (particularly if ")#mi("a")#text(" and ")#mi("x")#text(" are far from ")#mi("1")#text(") so one can proceed in the latter two steps in a number of ways and still reach the desired contradiction.")

#text("One particular takeaway from this analysis is the importance of the quantity ")#mi("x")#text(" (or ")#mi("p^{\\prime\\prime}(a)/p^{\\prime}(a)")#text(", or ")#mi("\\beta(1)")#text(", which are both closely related to ")#mi("x")#text("). While this quantity has implicitly appeared in previous work, notably the paper of Meir and Sharma, its significance was not highlighted in previous literature. (In particular, I have not seen the fact that the Meir-Sharma identity gives an extremely short proof of Rubinstein’s theorem in prior literature, although it would only have taken an expert in the subject a few minutes of looking in the right direction to notice this.) So I guess the even more abridged summary of the proof strategy is: collect enough constraints on a Sendov counterexample relating ")#mi("a")#text(" and ")#mi("p^{\\prime\\prime}(a)/p^{\\prime}(a)")#text(" to force a contradiction.")

#text("A more minor takeway is the usefulness of the polar ratio ")#mi("p(1/a)/p^{\\prime}(a)")#text(". But this already has some precedent in the literature: for instance, Theorem 5 of ")#link("https://arxiv.org/abs/1106.4126")[#text("Degot’s paper")]#text(" concerns the estimation of ")#mi("p(\\delta)/p^{\\prime}(a)")#text(", albeit with ")#mi("\\delta")#text(" taken on the line segment between ")#mi("0")#text(" and ")#mi("1")#text(" rather than being the polar dual ")#mi("1/a")#text(" of ")#mi("a")#text(". (But Degot also uses a different polar inversion later on in the paper, in Lemma 5 and Theorem 8.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4edcc55e0461a466998593be384f03bf2b128bc2ffc5665880d3bc243787bce-65f1a5c619cc52cf46c42630af9b8803e48cfa42a264eb8050108412bbfa10c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anton Shakov")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693916")[#strong[#text("Anton Shakov")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("Thanks so much for the detailed answer!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693922")[#strong[#text("Teng")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("Thanks for this very nice exposition. Just a small literature note: the observation underlying this very short proof of Rubinstein’s theorem already appears, in translated coordinates, in Remark 5.1 of a preprint by Quanyu Tang and me, “")#link("https://arxiv.org/abs/2508.10341")[#text("Sharp Schoenberg type inequalities and the de Bruin–Sharma problem")]#text("”.")

#text("There we use the identity")

#mi("\\displaystyle \\sum_k \\frac{1}{w_k}=2\\sum_j\\frac{1}{z_j}")

#text("(which is the Meir–Sharma identity after translation) to obtain the ")#mi("a=1")#text(" case of Sendov directly. Keeping track of the equality case in the same argument gives Rubinstein’s stronger conclusion: if there is no critical point at distance less than 1 from the boundary zero, equality forces all the critical points to be 0, and hence the polynomial is a scalar multiple of ")#mi("z^n-1")#text(".")

#text("Also, regarding strengthenings of Sendov’s conjecture, perhaps Conjecture 1.10 of ")#link("https://arxiv.org/abs/2508.10341")[#text("the same paper")]#text(" is worth mentioning.")

#text("In the notation of your post, it predicts that if ")#mi("p")#text(" is a degree-")#mi("n")#text(" polynomial whose zeros lie in the closed unit disk, ")#mi("a")#text(" is a zero of ")#mi("p")#text(", and ")#mi("w_1,\\ldots,w_{n-1}")#text(" are its critical points, then for every ")#mi("\\lambda\\geq 1")#text(",")

#tao-math("\\displaystyle \\sum_{j=1}^{n-1}\\frac{1}{\\left|a-w_j\\right|^{\\lambda}}\\geq n-1.", block: false)

#text("As ")#mi("\\lambda\\to\\infty")#text(", this recovers Sendov’s conjecture.")

#emph[#text("[Post updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693925")[#strong[#text("Teng")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("It seems that the argument in this post gives a short verification of Conjecture 1.10 in several cases.")

#text("First, the whole conjecture is equivalent to the case ")#mi("\\lambda=1")#text(". Indeed, if ")#tao-math("\\sum_{j=1}^{n-1}\\frac{1}{\\left|a-w_j\\right|}\\geq n-1,", block: false)#text(" then for every ")#mi("\\lambda\\geq1")#text(", the power mean inequality gives ")#tao-math("\\frac{1}{n-1}\\sum_{j=1}^{n-1}\\frac{1}{\\left|a-w_j\\right|^\\lambda}\\geq\\left(\\frac{1}{n-1}\\sum_{j=1}^{n-1}\\frac{1}{\\left|a-w_j\\right|}\\right)^\\lambda\\geq1.", block: false)#text(" The converse is immediate by taking ")#mi("\\lambda=1")#text(". After a rotation, we may assume ")#mi("0\\leq a\\leq1")#text(". If ")#mi("a")#text(" is itself a critical point, the assertion is immediate, so we may assume that ")#mi("a")#text(" is a simple zero.")

#text("Case 1: ")#mi("a=0")#text(". By Gauss–Lucas, every critical point satisfies ")#tao-math("\\left|w_j\\right|\\leq1", block: false)#text(". Hence ")#tao-math("\\sum_{j=1}^{n-1}\\frac{1}{\\left|w_j\\right|}\\geq n-1.", block: false)

#text("Case 2: ")#mi("a=1")#text(". Let ")#mi("z_1,\\ldots,z_{n-1}")#text(" be the other zeros. By the Meir–Sharma identity, ")#mi("\\sum_{j=1}^{n-1}\\frac{1}{1-w_j}=2\\sum_{j=1}^{n-1}\\frac{1}{1-z_j}.")#text(" Since ")#tao-math("\\left|z_j\\right|\\leq1", block: false)#text(", ")#mi("\\mathrm{Re}\\frac{1}{1-z_j}\\geq\\frac12.")#text(" Therefore ")#tao-math("\\sum_{j=1}^{n-1}\\frac{1}{\\left|1-w_j\\right|}\\geq\\mathrm{Re}\\sum_{j=1}^{n-1}\\frac{1}{1-w_j}=2\\sum_{j=1}^{n-1}\\mathrm{Re}\\frac{1}{1-z_j}\\geq n-1.", block: false)

#text("Case 3: ")#mi("2\\leq n\\leq5")#text(". Suppose ")#mi("0 <  a < 1")#text(", and put ")#mi("q_j:=\\frac{1}{a-w_j},\\qquad S:=\\sum_{j=1}^{n-1}|q_j|.")#text(" Assume for contradiction that ")#mi("S <  n-1")#text(". The polar lower bound in the post gives ")#mi("1\\leq\\int_0^1\\prod_{j=1}^{n-1}|a+t(1-a^2)q_j|\\,dt.")#text(" By the triangle inequality and AM–GM inequality, ")#tao-math("\\prod_{j=1}^{n-1}\\left|a+t(1-a^2)q_j\\right|\\leq\\prod_{j=1}^{n-1}\\left(a+t(1-a^2)\\left|q_j\\right|\\right)\\leq\\left(a+t(1-a^2)\\frac{S}{n-1}\\right)^{n-1}.", block: false)#text(" Since ")#mi("S  0")#text(" we have ")#mi("\\left(a+t(1-a^2)\\frac{S}{n-1}\\right)^{n-1} < \\left(a+t(1-a^2)\\right)^{n-1}.")#text(" Hence ")#mi("1 < \\int_0^1\\left(a+(1-a^2)t\\right)^{n-1}\\,dt.")

#text("For ")#mi("2\\leq n\\leq4")#text(", since ")#mi("n-1\\leq3")#text(", Holder's inequality on the unit interval gives ")#mi("\\left(\\int_0^1\\left(a+(1-a^2)t\\right)^{n-1}dt\\right)^{1/(n-1)}\\leq\\left(\\int_0^1\\left(a+(1-a^2)t\\right)^3dt\\right)^{1/3}.")#text(" Thus ")#mi("1 < \\int_0^1\\left(a+(1-a^2)t\\right)^3dt.")#text(" But, exactly as computed at the end of the post, ")#mi("\\int_0^1\\left(a+(1-a^2)t\\right)^3dt=1-\\frac{(a-1)^2}{4}\\left(a^2(1-a)^2+3(1-a^2)+2a\\right)  0.")#text(" Thus ")#mi("\\int_0^1\\left(a+(1-a^2)t\\right)^4dt < 1,")#text(" again a contradiction.")

#text("Therefore Conjecture 1.10 holds when ")#mi("a=0")#text(", when ")#tao-math("\\left|a\\right|=1", block: false)#text(", and for every ")#mi("2\\leq n\\leq5")#text(". The remaining case is ")#tao-math("0 < \\left|a\\right| < 1,\\qquad n\\geq6", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("Nice! It seems that a large part of the blog arguments extend to at least the ")#mi("\\lambda=2")#text(" case, in particular all of the polar inequalities extend without difficulty here. The main remaining obstruction seems to be the breakdown of the heuristic (31), in that one can no longer expect the ")#mi("q_j")#text(" to cluster very close to the unit circle (having a ")#mi("\\lambda")#text(" moment control does not strongly prevent fluctuations of order ")#mi("O(1/\\sqrt{n})")#text(" from the unit circle even when ")#mi("\\lambda")#text(" is large). The upshot is that there no longer seems to be a usable approximate relationship between ")#mi("\\sum_j q_j")#text(" and ")#mi("\\sum_j 1/q_j")#text(", so that the centroid identity cannot be used any more to relate ")#mi("\\sum_j 1/z_j")#text(" and ")#mi("\\sum_j q_j")#text(". But perhaps there are other ways to control ")#mi("\\sum_j 1/z_j")#text(" (or more precisely, the ")#mi("n-2")#text("th symmetric polynomial of the ")#mi("z_j")#text(") that are still effective.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693933")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("After playing a bit with an AI it looks like the methods in the blog post can in fact establish the ")#mi("\\lambda=2")#text(" case of Conjecture 1.10 for sufficiently large ")#mi("n")#text(". An ")#link("https://terrytao.wordpress.com/wp-content/uploads/2026/08/sendov_lambda2_complete_two_regime_working_proof.pdf")[#text("AI-generated set of notes")]#text(" is here. In this context, the bound ")#tao-math("\\left|q_j\\right| \\leq 1", block: false)#text(" is now replaced by an ")#mi("L^2")#text("-averaged bound ")#tao-math("\\frac{1}{n-1} \\sum_{j=1}^{n-1} \\left|q_j\\right|^2 \\leq 1", block: false)#text(". The polar inequality turns out to not be affected by this relaxation and continues as before. The argument involving the second origin inequality becomes problematic, but it turns out one can instead proceed purely by analyzing the first origin inequality, together with some elementary arguments of Degot that (in the interior case when ")#mi("a")#text(" is bounded away from ")#mi("1")#text(") control the quantity ")#mi("F(1)")#text(" which previously required the second origin identity to analyze. Eventually what this analysis produces is an approximation for ")#mi("(-1)^{n-1} \\prod_{j=1}^{n-1} q_j z_j")#text(", which on the one hand needs to have magnitude at most 1 by the AM-GM inequality, but which asymptotically can be shown to be about ")#mi("\\frac{1}{a\\mu} ( 1 - \\frac{\\kappa}{(m-1)\\mu^2})")#text(", where ")#mi("\\mu")#text(" is the mean of the ")#mi("q_j")#text(" and ")#mi("\\kappa = \\frac{1}{n-1} \\sum_{j=1}^{n-1} (q_j-\\mu)^2")#text(" is the signed variance. The polar inequality gives an upper bound ")#tao-math("\\left|\\kappa\\right| \\leq \\alpha / 3 \\left|\\mu\\right|^2", block: false)#text(" which can eventually be used to show that the expression ")#mi("(-1)^{n-1} \\prod_{j=1}^{n-1} q_j z_j")#text(" is asymptotically larger than 1 in magnitude, giving the desired contradiction for large ")#mi("n")#text(".")

#text("It’s quite possible that the arguments can be made quantitative enough to handle all decently large ")#mi("n")#text(" (e.g., ")#mi("n \\geq 100")#text(") and then combined with numerics to settle all cases, but I did not attempt to try this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693946")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2026")])]

#text("After digesting the arguments a bit more, I think I can now summarize the general strategy of this approach as follows. The key is actually the first origin identity (which comes from evaluating ")#mi("p(0)")#text(" both in terms of zeros and critical points). This gives the identity")

#mi("\\displaystyle (-1)^{n-1} \\prod_{j=1}^{n-1} z_j q_j = n \\int_0^1 \\prod_{j=1}^{n-1} (1 - a tq_j)\\ dt.")

#text("A counterexample to the Sendov conjecture, or to variants such as Conjecture 1.10, would have the left-hand side having magnitude at most 1; so if one can show the right-hand side has magnitude greater than 1, one gets a contradiction.")

#text("If all the ")#mi("q_j")#text(" were real and equal to their mean ")#mi("x")#text(", then the right-hand side would just be")

#mi("\\displaystyle n \\int_0^1 (1 - a tx)^{n-1}\\ dt \\approx n \\int_0^{1/ax} (1-atx)^{n-1}\\ dt = \\frac{1}{ax}.")

#text("Since ")#mi("a < 1")#text(" and ")#mi("x \\leq 1")#text(", this (morally) gives the required contradiction! All the remaining effort in the proof of the Sendov conjecture (or variants) then goes into controlling error terms coming from the fact that ")#mi("q_j")#text(" can have some imaginary part, or fluctuation around the mean, or to manage the contribution for ")#mi("t \\approx 1")#text(" properly. The polar identity plays a key role in controlling error terms, basically forcing ")#mi("x")#text(" to be close to 1 when ")#mi("a")#text(" is close to 1; the second moment control on the ")#mi("q_j")#text(" in turn shows that the fluctuation around the mean is small when ")#mi("x")#text(" is close to 1. On the other hand, the centroid identity and second origin identity no longer play a role.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693935")[#strong[#text("Teng Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("Thanks! It may be possible to use the quantitative estimates from my ")#link("https://zhangteng2000.github.io/files/sendov_conjecture_large_n.pdf")[#text("earlier paper")]#text(" to make the “sufficiently large n” argument effective and obtain an explicit value of to obtain an explicit, effective value of large N. I will try it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693955")[#strong[#text("Teng Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2026")])]

#text("Hi Terence, Conjecture 1.10 also holds when all the zeros are real (equivalently, collinear); see [this note](")#link("https://zhangteng2000.github.io/files/Sharp_Reciprocal_Moment_Inequalities_Collinear_Zeros.pdf")[#text("https://zhangteng2000.github.io/files/Sharp_Reciprocal_Moment_Inequalities_Collinear_Zeros.pdf")]#text("). I also used AI, guided by the arguments in my paper “Sendov’s conjecture holds for all ")#mi("n\\ge 10^{200000}")#text(",” to make the “sufficiently large ")#mi("n")#text("” statement effective. The argument gives Conjecture 1.10 for ")#mi("n\\ge 10^{200000}")#text(", and the case ")#mi("\\lambda=2")#text("; see [this note](")#link("https://zhangteng2000.github.io/files/explicit_large_n_quadratic_tang_zhang.pdf")[#text("https://zhangteng2000.github.io/files/explicit_large_n_quadratic_tang_zhang.pdf")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693956")[#strong[#text("Teng Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2026")])]

#text("Hi Terence, Just as Schmeisser’s conjecture is a convex-hull strengthening of Sendov’s conjecture, it is natural to ask whether Conjecture 1.10 admits a similar convex-hull strengthening. I considered the variant in which the distinguished zero ")#mi("a")#text(" is replaced by an arbitrary point in the convex hull of the zeros. With AI assistance, I searched for counterexamples and found that the corresponding finite-")#mi("\\lambda")#text(" moment inequalities are false, even when all the zeros are real and collinear. Indeed, let ")#mi("p_n(z)=(z-1)^{n-1}(z+1), \\qquad a=-\\frac14\\in[-1,1].")#text(" Then ")#mi("p_n^{\\prime}(z)=(z-1)^{n-2}(nz+n-2),")#text(" so the critical points are ")#mi("1")#text(" with multiplicity ")#mi("n-2")#text(", together with ")#mi("-(n-2)/n")#text(". Hence ")#tao-math("\\displaystyle \\sum_{j=1}^{n-1}\\frac{1}{\\left|a-w_j\\right|^\\lambda}=(n-2)\\left(\\frac45\\right)^\\lambda+\\left(\\frac{4n}{3n-8}\\right)^\\lambda.", block: false)#text(" For every fixed finite ")#mi("\\lambda\\ge 1")#text(", dividing by ")#mi("n-1")#text(" and letting ")#mi("n\\to\\infty")#text(" gives ")#tao-math("\\displaystyle \\frac{1}{n-1}\\sum_{j=1}^{n-1}\\frac{1}{\\left|a-w_j\\right|^\\lambda}\\longrightarrow\\left(\\frac45\\right)^\\lambda < 1.", block: false)#text(" Thus, for every fixed finite ")#mi("\\lambda\\ge 1")#text(" and all sufficiently large ")#mi("n")#text(", ")#tao-math("\\sum_{j=1}^{n-1}\\frac{1}{\\left|a-w_j\\right|^\\lambda} < n-1,", block: false)#text(" so the convex-hull analogue of Conjecture 1.10 fails. On the other hand ")#tao-math("\\frac{1}{\\left|a-w_2\\right|}=\\frac{4n}{3n-8} > 1,", block: false)#text(" so this family remains consistent with Schmeisser’s conjecture.so this family remains consistent with Schmeisser’s conjecture.")

#emph[#text("[The last line of this comment was reconstructed by AI, as it was lost due to WordPress parsing text between < and > as HTML. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-694016")[#strong[#text("Teng Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("Hi, Terence. Here is a possible common generalization of the Borcea variance conjecture and the Tang–Zhang conjecture. For positive ")#mi("x_1,\\ldots,x_m")#text(", let ")#mi("M_s(x_1,\\ldots,x_m):=\\left(\\frac1m\\sum_{j=1}^m x_j^s\\right)^{1/s},")#text(" with ")#mi("M_\\infty=\\max")#text(" and ")#mi("M_{-\\infty}=\\min")#text(". Let ")#mi("z_1,\\ldots,z_n")#text(" be the zeros of ")#mi("F")#text(", let ")#mi("a")#text(" be one of them, and let ")#mi("w_1,\\ldots,w_{n-1}")#text(" be the critical points. Define ")#tao-math("\\sigma_p(F):=\\min_{c\\in\\mathbb C}M_p(\\left|z_1-c\\right|,\\ldots,\\left|z_n-c\\right|).", block: false)#text(" If ")#mi("q")#text(" is the Hölder conjugate of ")#mi("p")#text(", ")#mi("\\frac1p+\\frac1q=1,")#text(" I would conjecture ")#tao-math("M_{-\\lambda}(\\left|w_1-a\\right|,\\ldots,\\left|w_{n-1}-a\\right|)\\leq\\sigma_p(F),\\qquad \\lambda\\geq q.", block: false)#text(" Since ")#mi("M_{-\\lambda}")#text(" decreases with ")#mi("\\lambda")#text(", the strongest case is ")#tao-math("M_{-q}(\\left|w_1-a\\right|,\\ldots,\\left|w_{n-1}-a\\right|)\\leq\\sigma_p(F).", block: false)#text(" Equivalently, after translating by an ")#mi("L^p")#text("-minimizing center and rescaling, one may assume ")#tao-math("M_p(\\left|z_1\\right|,\\ldots,\\left|z_n\\right|)\\leq1.", block: false)#text(" Thus the zeros need not all lie in the unit disk; only their ")#mi("p")#text("-power mean is controlled. In the notation of the post, write ")#mi("w_j=a-1/q_j")#text(". Then the conjecture is ")#tao-math("M_p(\\left|z_1\\right|,\\ldots,\\left|z_n\\right|)\\leq1\\quad\\Longrightarrow\\quad M_\\lambda(\\left|q_1\\right|,\\ldots,\\left|q_{n-1}\\right|)\\geq1,\\qquad \\lambda\\geq q,", block: false)#text(" and the strongest form is simply ")#tao-math("M_p(\\left|z_1\\right|,\\ldots,\\left|z_n\\right|)\\leq1\\quad\\Longrightarrow\\quad M_q(\\left|q_1\\right|,\\ldots,\\left|q_{n-1}\\right|)\\geq1.", block: false)#text(" Without normalization this is ")#tao-math("\\sigma_p(F)M_q(\\left|q_1\\right|,\\ldots,\\left|q_{n-1}\\right|)\\geq1,", block: false)#text(" or equivalently ")#tao-math("M_{-q}(\\left|w_1-a\\right|,\\ldots,\\left|w_{n-1}-a\\right|)\\leq\\sigma_p(F).", block: false)#text(" This gives a common interpolation between the two conjectures. Taking ")#mi("\\lambda=\\infty")#text(" recovers Borcea’s ")#mi("p")#text("-variance conjecture ")#tao-math("\\min_j\\left|w_j-a\\right|\\leq\\sigma_p(F).", block: false)#text(" For ")#mi("p=1")#text(", ")#mi("q=\\infty")#text(", this is the strongest Borcea ")#mi("1")#text("-variance conjecture. For ")#mi("p=\\infty")#text(", ")#mi("q=1")#text(", the strongest case becomes ")#tao-math("\\sum_{j=1}^{n-1}\\left|q_j\\right|\\geq n-1,", block: false)#text(" which is the strongest Tang–Zhang form.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-694018")[#strong[#text("Teng Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("The intermediate case ")#mi("p=q=2")#text(" seems particularly interesting because ")#mi("\\sigma_2(F)")#text(" is explicit. If ")#mi("\\bar z=\\frac1n\\sum_{k=1}^n z_k")#text(", then ")#tao-math("\\sigma_2(F)^2=\\frac1n\\sum_{k=1}^n\\left|z_k-\\bar z\\right|^2=\\frac1{n^2}\\sum_{1\\leq i < j\\leq n}\\left|z_i-z_j\\right|^2", block: false)#text(". Thus the ")#mi("p=q=2")#text(" case is ")#tao-math("\\left(\\frac1n\\sum_{k=1}^n\\left|z_k-\\bar z\\right|^2\\right)\\left(\\sum_{j=1}^{n-1}\\frac1{\\left|w_j-a\\right|^2}\\right)\\geq n-1", block: false)#text(". If true, this immediately gives ")#tao-math("\\min_j\\left|w_j-a\\right|\\leq\\left(\\frac1{n-1}\\sum_{j=1}^{n-1}\\left|w_j-a\\right|^{-2}\\right)^{-1/2}\\leq\\sigma_2(F)", block: false)#text(", and hence Borcea's ")#mi("2")#text("-variance conjecture; in particular it implies Sendov's conjecture. I initially guessed that smaller values of ")#mi("\\lambda")#text(" might also work, perhaps even every ")#mi("\\lambda\\geq1")#text(". With the help of AI I carried out extensive numerical searches. The experiments instead strongly suggested that ")#mi("q")#text(" is the sharp threshold: I found counterexamples for every tested ")#mi("\\lambda < q")#text(", but none on the boundary ")#mi("\\lambda=q")#text(". The simple family ")#mi("F(z)=z(z-1)^{n-1}")#text(" in fact explains this threshold asymptotically: for every fixed ")#mi("\\lambda < q")#text(", the proposed inequality fails for all sufficiently large ")#mi("n")#text(". Thus the Hölder relation ")#mi("\\frac1p+\\frac1q=1")#text(" appears to be forced by the extremal geometry rather than merely being a formal interpolation.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693926")[#strong[#text("Teng Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("Hi, Terence. On conjecture 19, the authors are Tang and Zhang rather than Teng and Zhang, although my name is Teng Zhang.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693914")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("Your comment about the low-tech nature of the proof makes me wonder about the hypothetical universe in which current AI models were developed before the proof of the prime number theorem. Might AI have come up with the elementary proof of the prime number theorem before the complex-analytic proof? If it had, perhaps it would have had the ironic side effect of delaying progress in analytic number theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693928")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("Long story short: polynomial degeneracy always pushes, not pulls; as in $(x-1) \\cdot (x+1)^(n-1)$ for $n>2$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693929")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("The original Bourbaki members would probably love this new era of mathematics. I think it just proves that math is not as interesting as we previously thought, because the current AI powered machines solving the problems are not intelligent yet, by no means (and they would never have the best ideas that humans have produced, since the Ancient Greeks to the times of Einstein and others). After all, math took the same fate as chess (which makes sense, because chess is a part of math). Still, people can still become physicists! ChatGPT etc can’t solve simple questions about gravity, electromagnetism, astronomy, for now, unless some human already solved it and it knows the answer already! Math will remain interesting as a hobby/pastime/leisure, for those who like to think, but young people will probably see the Riemann hypothesis solved by some AI someday, and what’s the point of competing against such AI? The human brain is very limited, and math is hard for us, but it’s just natural for the AI! :) People are sad because they like math as it’s done nowadays, but everything comes to an end someday! In the past, Jacob Steiner used to complain about coordinate geometry because it reduced the solution of geometric problems to calculations, in contrast to synthetic geometry (where one had to think)… The think is, as math evolves, one needs less and less thinking to solve the problems, that’s one of the points of math! (but it’s not satisfying to our brain!) So: The proofs of important conjectures will soon become not understandable by humans, but we will not have to think to get them, and we should be humble about that. After all: we are just humans, very limited animals! Machines can handle math better than us after all (and someday, probably everything else)…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693938")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("The abstract of the linked paper is a good example of oddly terrible AI writing.")

#text("The second sentence")

#text("“One invertible scaling and rotation turns a hypothetical failure into a normalized obstruction while preserving all root and critical-point multiplicities”")

#text("as far as I can tell, is just referring to the fact you can normalize to assume $a$ is real? But what an overwrought way to state something a human author wouldn’t bother mentioning…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("Why is Phelps–Rodriguez a strengthening? If I understood text and lean definition correctly, it is simply “Sendov’s conjecture is true if we disregard this subset of cases” – so… shouldn’t it be weaker?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693944")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2026")])]

#text("Phelps-Rodriguez improves the non-strict inequality ")#tao-math("\\left|\\zeta-a\\right| \\leq 1", block: false)#text(" of Sendov’s conjecture to strict inequality ")#tao-math("\\left|\\zeta-a\\right| < 1", block: false)#text(". To put it another way, Sendov's conjecture asserts that ")#tao-math("\\min_{p^{\\prime}(\\zeta)=0} \\left|\\zeta-a\\right|", block: false)#text(" is always less than or equal to 1; Phelps-Rodriguez asserts additionally that equality only occurs for scalar multiples of ")#mi("z^n-a^n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693948")[#strong[#text("Teng Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2026")])]

#text("Hi Terence, I noticed that Conjecture 1.10 has the following rather beautiful equivalent formulation:")

#tao-math("(1,\\ldots,1)\\prec_w \\big{\\left(\\left|q_1\\right|,\\ldots,\\left|q_{n-1}\\right|\\right)}.", block: false)#text(" This form also makes it particularly transparent that Conjecture 1.10 is a majorization-type extension of Sendov’s conjecture.")

#text("Here is the matrix-theoretic motivation. Write the zeros of ")#mi("p")#text(" as ")#mi("a,z_1,\\ldots,z_{n-1}")#text(", and put")

#mi("D=\\mathrm{diag}(z_1-a,\\ldots,z_{n-1}-a), \\qquad J=\\mathbf 1\\mathbf 1^*.")

#text("Using the companion-matrix representation, the eigenvalues of ")#mi("C=D\\left(I-\\frac1nJ\\right)")#text(" are precisely ")#mi("\\zeta_1-a,\\ldots,\\zeta_{n-1}-a,")#text(" where ")#mi("\\zeta_1,\\ldots,\\zeta_{n-1}")#text(" are the critical points of ")#mi("p")#text(". Thus Sendov’s conjecture is equivalent to")

#tao-math("\\min_j \\left|\\lambda_j(C)\\right|\\le1.", block: false)

#text("When ")#mi("a")#text(" is a simple zero, ")#mi("C")#text(" is invertible. Since ")#mi("\\left(I-\\frac1nJ\\right)^{-1}=I+J,")#text(" consider ")#mi("B=C^{-1}=(I+J)D^{-1}.")#text(" The eigenvalues of ")#mi("B")#text(" are exactly")

#mi("-q_1,\\ldots,-q_{n-1}")#text(",")

#text("where ")#mi("\\zeta_j=a-\\frac1{q_j}.")#text(" If we order them so that")

#tao-math("\\left|\\lambda_1(B)\\right|\\ge \\left|\\lambda_2(B)\\right|\\ge\\cdots\\ge \\left|\\lambda_{n-1}(B)\\right|,", block: false)

#text("then Sendov’s conjecture becomes simply")

#tao-math("\\left|\\lambda_1(B)\\right|\\ge1.", block: false)

#text("A natural idea is then to try to prove this spectral-radius lower bound by means of Gelfand’s formula")

#tao-math("\\rho(B)=\\lim_{m\\to\\infty}\\left\\|B^m\\right\\|^{1/m}.", block: false)

#text("I have tried to pursue this route on and off over the past few years, but unfortunately I have not been able to make it work. Conjecture 1.10 suggests a different and, in some sense, more global spectral viewpoint. Its ")#mi("\\lambda=1")#text(" case is precisely ")#tao-math("\\sum_{j=1}^{n-1}\\left|\\lambda_j(B)\\right|\\ge n-1.", block: false)#text(" Thus, while Sendov’s conjecture only asks for a lower bound on the largest eigenvalue modulus, Conjecture 1.10 controls the total modulus of the spectrum. This naturally suggests the weak-majorization relation")

#tao-math("(1,\\ldots,1)\\prec_w \\big{\\left(\\left|\\lambda_1(B)\\right|,\\ldots,\\left|\\lambda_{n-1}(B)\\right|\\right)}.", block: false)

#text("What is pleasant is that this weak-majorization statement is not actually stronger than the ")#mi("\\lambda=1")#text(" case of Conjecture 1.10: it is exactly equivalent to it. Indeed, suppose")

#tao-math("\\sum_{j=1}^{n-1}\\left|\\lambda_j(B)\\right|\\ge n-1.", block: false)

#text("Since the moduli are arranged in decreasing order, for every ")#mi("1\\le k\\le n-1")#text(",")

#tao-math("\\frac1k\\sum_{j=1}^k\\left|\\lambda_j(B)\\right|\\ge \\frac1{n-1}\\sum_{j=1}^{n-1}\\left|\\lambda_j(B)\\right|\\ge1.", block: false)

#text("Therefore")

#tao-math("\\sum_{j=1}^k\\left|\\lambda_j(B)\\right|\\ge k, \\qquad 1\\le k\\le n-1,", block: false)

#text("which is exactly ")#tao-math("(1,\\ldots,1)\\prec_w \\big{\\left(\\left|\\lambda_1(B)\\right|,\\ldots,\\left|\\lambda_{n-1}(B)\\right|\\right)}.", block: false)

#text("Conversely, taking ")#mi("k=n-1")#text(" immediately recovers the ")#mi("\\lambda=1")#text(" case of Conjecture 1.10.")

#text("Thus Conjecture 1.10 itself can be viewed equivalently as the weak-majorization statement ")#tao-math("(1,\\ldots,1)\\prec_w \\big{\\left(\\left|q_1\\right|,\\ldots,\\left|q_{n-1}\\right|\\right)}.", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693952")[#strong[#text("Teng Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2026")])]

#text("The weak majorization formulation ")#tao-math("(1,\\ldots,1)\\prec_w (\\left|q_1\\right|,\\ldots,\\left|q_{n-1}\\right|)", block: false)#text(" also yields many further interesting consequences. In particular, for every increasing convex function ")#mi("\\phi:\\mathbb{R}_+\\to\\mathbb{R}")#text(", it implies")

#tao-math("\\displaystyle (n-1)\\phi(1)\\leq \\sum_{j=1}^{n-1}\\phi(\\left|q_j\\right|).", block: false)
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("I’m unfamiliar with minute details of Lean, but in the last part of Sendov.phelps_rodriguez problem statement {p = C c * (X ^ n – C (a ^ n))} where did C appear from? I can see c gets defined right before, but what is C? is it some mathlib-defined way of multiplication constant?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693945")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2026")])]

#raw("C")#text(" is short for ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Algebra/Polynomial/Basic.html#Polynomial.C")[#text("Polynomial.C")]#text(", which is the Lean Mathlib function that turns a scalar ")#raw("c")#text(" into a degree zero polynomial ")#raw("C c")#text(". In informal mathematics, one usually abuses notation and does not make a distinction between, say, the complex scalar ")#mi("17 \\in {\\mathbf C}")#text(", and the constant polynomial ")#mi("17 \\in {\\mathbf C}[X]")#text(" of one variable, and we use the same symbol ")#mi("17")#text(" to refer to both; but Lean has a more nitpicky type theory and it becomes important to keep these two mathematical objects distinct, thus the former would be referred to as ")#raw("17")#text(" (or ")#raw("(17 : ℂ)")#text(" if the complex type cannot be inferred from context), and the latter as ")#raw("C 17")#text(" (or ")#raw("(C 17 : ℂ[X])")#text(" if the complex polynomial type cannot be inferred from context).")

#text("This distinction becomes important when one starts using operations that are defined for polynomials but not for scalars (or vice versa). For instance, ")#raw("C 17")#text(" has degree zero: ")#raw("(C 17).degree = 0")#text(". But the degree of ")#raw("17")#text(" is undefined: ")#raw("17.degree")#text(" does not typecheck. Or: ")#raw("C 17")#text(" has an antiderivative ")#raw("(C 17) * X")#text(": ")#raw("((C 17) * X).deriv = C 17")#text(". But in the complex numbers, there is no antiderivative of ")#raw("17")#text("; indeed the notion of derivative or antiderivative is simply undefined.")

#text("Lean does have the capability to make certain type coercions automatic, so that for instance a complex scalar would be automatically converted into a complex polynomial if that was what was needed from context. (This is done for other some other type conversions: for instance, real numbers are automatically converted to complex numbers when a complex number is called for.) But at some point there was a decision in Mathlib to not do so in the case of polynomials, probably because of operations such as the above where it actually becomes important to distinguish a scalar from its associated constant polynomial. (But it is possible that this decision may be reversed in some future version of Mathlib; it is a living library, constantly under development.)")

#text("I recommend Andrej Bauer’s talk ")#link("https://www.youtube.com/watch?v=wZSvuCJBaFU")[#text("Formalizing invisible mathematics")]#text(" for more discussion of the implicit notational abuse of different types that is actually quite prevalent in informal mathematics, and how formalization can surface this notation abuse and make it all unambiguous and correct.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65c5e04ee1a502636b69db74fa76bab9c4881887c1e8a15673952f98a6808211-0aa3637d3f7b754aa1b558e5bfa8893ff0f93ca68bccabe12aa172b0090719e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dutifullyb3c31ab42c")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693947")[#strong[#text("dutifullyb3c31ab42c")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2026")])]

#text("How is the value of this work (from the aspect of effects on mathematics and the ability of AI respectively) compared with the recent works on Erdős unit distance problem and non-Sofic groups?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693959")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2026")])]

#text("I looked at the Mazur paper, and the project he/his company runs (proofatlas.ai). The site seems really set up as a collaborative project than just resulting from his personal insights and prompts. The preprint is also not mentioning the prompts, contributors etc. Of course, part of it is hidden also behind the fact that the reasoning is something given by LLM in the end, which may not understand it’s sources. But with what justification is this credited as “Lech Mazur with help of LLM” rather than “LLM+?”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65c5e04ee1a502636b69db74fa76bab9c4881887c1e8a15673952f98a6808211-0aa3637d3f7b754aa1b558e5bfa8893ff0f93ca68bccabe12aa172b0090719e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dutifullyb3c31ab42c")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693961")[#strong[#text("dutifullyb3c31ab42c")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2026")])]

#text("I think people should change the way of thinking “who should be the author”. Humans lead this project, and humans deserve to be the author, just marking the contribution by AI is enough. This has already been common in other subjects.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9316578307b53a230ffd92605e8e16ebc6f6e68aa50a2fdb97fb87a13f6a7945-de04f200a1f4622e63c3f98eebb938537d74b2089a6e9bb2aba73dc02448fe99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karim Adiprasito")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693965")[#strong[#text("Karim Adiprasito")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2026")])]

#text("LM seems to only partially understand what he is doing, and since it is a collaborative project on his website, I don’t think his name can reasonably be attached as main author without transparency. It is nice that chatgpt found a proof, even nicer that Terry digested it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693964")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2026")])]

#text("Hi Terrence. Thank you for the breakdown. While at the University of Newcastle, I once (in passing) was acquainted with an approach to Sendov’s conjecture involving the log derivative. An academic there was certain it could be proved in an elegant manner this way.")

#text("I simply asked ChatGPT to rewrite the proof on this page in terms of the log derivative:")

#link("https://chatgpt.com/s/t_6a83b1b602188191a8b0a49bb2652b03")[#text("https://chatgpt.com/s/t_6a83b1b602188191a8b0a49bb2652b03")]

#text("I am unsure if this is useful, but it certainly helped me to understand what was going on")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558a5cc44562166a35d1aef7c3e962303970f6358338dd676ba6909d7914d48-756aa9b284adc4864a56a0184ba06af4a6d262748603cd98f439328d2981473c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teng Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-693976")[#strong[#text("Teng Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2026")])]

#text("I have carefully considered the idea you mentioned. In fact, the proof of Sendov’s conjecture hinges on estimates for the zeros and critical points that, to the best of our knowledge, had not been previously discovered. As for the use of logarithmic derivatives, I am not convinced that it makes the argument any clearer, simpler, or more persuasive than the original approach, nor does it seem to provide any kind of “magic bullet.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-694023")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("In the remark 9, $c_1$ seems to have gotten omitted.")

#emph[#text("[The ")#mi("c_1")#text(" parameter lies between ")#mi("0")#text(" and ")#mi("c_2")#text("; it does not impact the asymptotics described in the remark, but still affects the choice of the zero ")#mi("a")#text(" – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/899eaa704f80c087032bc6b4d83d1cefadac7d60d704e945ac5c6bc2177aca13-fc9e4d17c96ca1352528786ad27d59f2122d7b2aa05b9af232f99d82fc751ab7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marius.cobzarenco+maths")]], [#link("https://terrytao.wordpress.com/2026/08/12/a-digestion-of-the-proof-of-sendovs-conjecture/#comment-694059")[#strong[#text("marius.cobzarenco+maths")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2026")])]

#text("A remark on Conjecture 19 (Tang–Zhang): elementary, but I could not find it stated, and it appears to be the first lower bound valid on an open region of configurations. Let ")#mi("p(z) = (z-a)\\prod_{j=1}^n(z-\\zeta_j)")#text(" with all ")#tao-math("\\left|\\zeta_j\\right| \\le 1", block: false)#text(", critical points ")#mi("w_1,\\dots,w_n")#text(", and ")#mi("q_k = 1/(a-w_k)")#text(". Comparing the two evaluations of ")#mi("p^{\\prime}(a)")#text(": ")#mi("\\displaystyle (n+1)\\prod_{k=1}^n(a-w_k) = \\prod_{j=1}^n(a-\\zeta_j),")#text(" so that ")#tao-math("\\displaystyle \\prod_{k=1}^n\\left|q_k\\right| = \\frac{n+1}{\\prod_{j=1}^n\\left|a-\\zeta_j\\right|},", block: false)#text(" and the power mean inequality then gives, for every positive ")#mi("\\lambda")#text(", ")#tao-math("\\displaystyle \\sum_{k=1}^n\\left|q_k\\right|^{\\lambda} \\ge n\\Big{\\left(\\frac{n+1}{\\prod_{j=1}^n\\left|a-\\zeta_j\\right|}\\right)}^{\\lambda/n}.", block: false)#text(" Hence Conjecture 19 holds, for every positive ")#mi("\\lambda")#text(" rather than only ")#mi("\\lambda \\ge 1")#text(", whenever ")#tao-math("\\prod_{j=1}^n\\left|a-\\zeta_j\\right| \\le n+1", block: false)#text(". Three remarks: 1. The region contains the extremal configuration in its interior (")#tao-math("\\prod_j\\left|a-\\zeta_j\\right| = a^n(n+1)", block: false)#text(" there), and the bound is exact at it. 2. At ")#mi("a = 0")#text(" it gives the conjecture for all ")#mi("\\lambda")#text(" with margin: ")#tao-math("\\sum_k\\left|q_k\\right|^{\\lambda} \\ge n(n+1)^{\\lambda/n} \\ge n + \\lambda\\log(n+1)", block: false)#text(", sharp for ")#mi("z^{n+1} - z")#text(". 3. The configurations reached by the Schoenberg–Cauchy–Schwarz mechanism (as in Tang’s survey) satisfy ")#tao-math("\\prod_j\\left|a-\\zeta_j\\right| \\le n+1", block: false)#text(", so they lie inside this region. Any counterexample must therefore have ")#tao-math("\\prod_j\\left|a-\\zeta_j\\right|", block: false)#text(" strictly larger than ")#mi("n+1")#text(": the geometric mean of the ")#tao-math("\\left|q_k\\right|", block: false)#text(" lies below 1 while the conjecture concerns their power means, so the difficulty concentrates on the near-balanced class where these coincide.")
]
