// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/
// Converted to Typst by tao2typ: "2026-10-14T08:54:11.318652+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 4: The semi-circular law", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 4: The semi-circular law")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We can now turn attention to one of the centerpiece universality results in random matrix theory, namely the ")#link("http://en.wikipedia.org/wiki/Wigner_semi-circle_distribution")[#text("Wigner semi-circle law")]#text(" for Wigner matrices. Recall from ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("previous notes")]#text(" that a ")#emph[#text("Wigner Hermitian matrix ensemble")]#text(" is a random matrix ensemble ")#mi("{M_n = (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(" of Hermitian matrices (thus ")#mi("{\\xi_{ij} = \\overline{\\xi_{ji}}}")#text("; this includes ")#emph[#text("real symmetric matrices")]#text(" as an important special case), in which the upper-triangular entries ")#mi("{\\xi_{ij}}")#text(", ")#mi("{i>j}")#text(" are iid complex random variables with mean zero and unit variance, and the diagonal entries ")#mi("{\\xi_{ii}}")#text(" are iid real variables, independent of the upper-triangular entries, with bounded mean and variance. Particular special cases of interest include the ")#emph[#text("Gaussian Orthogonal Ensemble (GOE)")]#text(", the ")#emph[#text("symmetric random sign matrices")]#text(" (aka ")#emph[#text("symmetric Bernoulli ensemble")]#text("), and the ")#link("http://en.wikipedia.org/wiki/Gaussian_Unitary_Ensemble")[#text("Gaussian Unitary Ensemble (GUE)")]#text(".")

#text("In ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("previous notes")]#text(" we saw that the operator norm of ")#mi("{M_n}")#text(" was typically of size ")#mi("{O(\\sqrt{n})}")#text(", so it is natural to work with the normalised matrix ")#mi("{\\frac{1}{\\sqrt{n}} M_n}")#text(". Accordingly, given any ")#mi("{n \\times n}")#text(" Hermitian matrix ")#mi("{M_n}")#text(", we can form the (normalised) ")#emph[#text("empirical spectral distribution")]#text(" (or ")#emph[#text("ESD")]#text(" for short)")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\frac{1}{\\sqrt{n}} M_n} := \\frac{1}{n} \\sum_{j=1}^n \\delta_{\\lambda_j(M_n) / \\sqrt{n}},")]]

#text("of ")#mi("{M_n}")#text(", where ")#mi("{\\lambda_1(M_n) \\leq \\ldots \\leq \\lambda_n(M_n)}")#text(" are the (necessarily real) eigenvalues of ")#mi("{M_n}")#text(", counting multiplicity. The ESD is a probability measure, which can be viewed as a distribution of the normalised eigenvalues of ")#mi("{M_n}")#text(".")

#text("When ")#mi("{M_n}")#text(" is a random matrix ensemble, then the ESD ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" is now a ")#emph[#text("random")]#text(" measure – i.e. a random variable taking values in the space ")#mi("{\\text{Pr}({\\mathbb R})}")#text(" of probability measures on the real line. (Thus, the distribution of ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" is a probability measure on probability measures!)")

#text("Now we consider the behaviour of the ESD of a sequence of Hermitian matrix ensembles ")#mi("{M_n}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Recall from ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text(" that for any sequence of random variables in a ")#mi("{\\sigma}")#text("-compact metrisable space, one can define notions of ")#emph[#text("convergence in probability")]#text(" and ")#emph[#text("convergence almost surely")]#text(". Specialising these definitions to the case of random probability measures on ")#mi("{{\\mathbb R}}")#text(", and to deterministic limits, we see that a sequence of random ESDs ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" ")#emph[#text("converge in probability")]#text(" (resp. ")#emph[#text("converge almost surely")]#text(") to a deterministic limit ")#mi("{\\mu \\in \\text{Pr}({\\mathbb R})}")#text(" (which, confusingly enough, is a deterministic probability measure!) if, for every test function ")#mi("{\\varphi \\in C_c({\\mathbb R})}")#text(", the quantities ")#mi("{\\int_{\\mathbb R} \\varphi\\ d\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converge in probability (resp. converge almost surely) to ")#mi("{\\int_{\\mathbb R} \\varphi\\ d\\mu}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" As usual, convergence almost surely implies convergence in probability, but not vice versa. In the special case of random probability measures, there is an even weaker notion of convergence, namely ")#emph[#text("convergence in expectation")]#text(", defined as follows. Given a random ESD ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(", one can form its ")#emph[#text("expectation")]#text(" ")#mi("{{\\bf E} \\mu_{\\frac{1}{\\sqrt{n}} M_n} \\in \\text{Pr}({\\mathbb R})}")#text(", defined via duality (the Riesz representation theorem) as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbb R} \\varphi\\ d{\\bf E} \\mu_{\\frac{1}{\\sqrt{n}} M_n} := {\\bf E} \\int_{\\mathbb R} \\varphi\\ d \\mu_{\\frac{1}{\\sqrt{n}} M_n};")]]

#text("this probability measure can be viewed as the law of a ")#emph[#text("random")]#text(" eigenvalue ")#mi("{\\frac{1}{\\sqrt{n}}\\lambda_i(M_n)}")#text(" drawn from a random matrix ")#mi("{M_n}")#text(" from the ensemble. We then say that the ESDs converge in expectation to a limit ")#mi("{\\mu \\in \\text{Pr}({\\mathbb R})}")#text(" if ")#mi("{{\\bf E} \\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges the vague topology to ")#mi("{\\mu}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\int_{\\mathbb R} \\varphi\\ d \\mu_{\\frac{1}{\\sqrt{n}} M_n} \\rightarrow \\int_{\\mathbb R} \\varphi\\ d\\mu")]]

#text("for all ")#mi("{\\phi \\in C_c({\\mathbb R})}")#text(".")

#text("In general, these notions of convergence are distinct from each other; but in practice, one often finds in random matrix theory that these notions are effectively equivalent to each other, thanks to the concentration of measure phenomenon.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{M_n}")#text(" be a sequence of ")#mi("{n \\times n}")#text(" Hermitian matrix ensembles, and let ")#mi("{\\mu}")#text(" be a continuous probability measure on ")#mi("{{\\mathbb R}}")#text(".")

#list(
[#text("Show that ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges almost surely to ")#mi("{\\mu}")#text(" if and only if ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}}}(-\\infty,\\lambda)}")#text(" converges almost surely to ")#mi("{\\mu(-\\infty,\\lambda)}")#text(" for all ")#mi("{\\lambda \\in {\\mathbb R}}")#text(".")],
[#text("Show that ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges in probability to ")#mi("{\\mu}")#text(" if and only if ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}}}(-\\infty,\\lambda)}")#text(" converges in probability to ")#mi("{\\mu(-\\infty,\\lambda)}")#text(" for all ")#mi("{\\lambda \\in {\\mathbb R}}")#text(".")],
[#text("Show that ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges in expectation to ")#mi("{\\mu}")#text(" if and only if ")#mi("{\\mathop{\\mathbb E} \\mu_{\\frac{1}{\\sqrt{n}}}(-\\infty,\\lambda)}")#text(" converges to ")#mi("{\\mu(-\\infty,\\lambda)}")#text(" for all ")#mi("{\\lambda \\in {\\mathbb R}}")#text(".")]
)
]

#text("We can now state the Wigner semi-circular law.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Semicircular law)")]#text(" ")#metadata(none) <tao-c3be8e53070314c8094f>#text(" Let ")#mi("{M_n}")#text(" be the top left ")#mi("{n \\times n}")#text(" minors of an infinite Wigner matrix ")#mi("{(\\xi_{ij})_{i,j \\geq 1}}")#text(". Then the ESDs ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converge almost surely (and hence also in probability and in expectation) to the ")#emph[#text("Wigner semi-circular distribution")]#text(" ")#metadata(none) <tao-e0b9a8799f32453a478c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\mu_{sc} := \\frac{1}{2\\pi} (4-\\left|x\\right|^2)^{1/2}_+\\ dx.", block: true)]]


]

#text("A numerical example of this theorem in action can be seen at the ")#link("http://mathworld.wolfram.com/WignersSemicircleLaw.html")[#text("MathWorld entry for this law")]#text(".")

#text("The semi-circular law nicely complements the ")#emph[#text("upper Bai-Yin theorem")]#text(" from ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(", which asserts that (in the case when the entries have finite fourth moment, at least), the matrices ")#mi("{\\frac{1}{\\sqrt{n}} M_n}")#text(" almost surely has operator norm at most ")#mi("{2+o(1)}")#text(". Note that the operator norm is the same thing as the largest magnitude of the eigenvalues. Because the semi-circular distribution ")#link(<tao-e0b9a8799f32453a478c>)[#text("(1)")]#text(" is supported on the interval ")#mi("{[-2,2]}")#text(" with positive density on the interior of this interval, Theorem ")#link(<tao-c3be8e53070314c8094f>)[#text("1")]#text(" easily supplies the ")#emph[#text("lower Bai-Yin theorem")]#text(", that the operator norm of ")#mi("{\\frac{1}{\\sqrt{n}} M_n}")#text(" is almost surely ")#emph[#text("at least")]#text(" ")#mi("{2-o(1)}")#text(", and thus (in the finite fourth moment case) the norm is in fact ")#emph[#text("equal")]#text(" to ")#mi("{2+o(1)}")#text(". Indeed, we have just shown that the semi-circular law provides an alternate proof of the lower Bai-Yin bound (Proposition 11 of ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(").")

#text("As will hopefully become clearer in the next set of notes, the semi-circular law is the noncommutative (or ")#link("http://en.wikipedia.org/wiki/Free_probability")[#text("free probability")]#text(") analogue of the central limit theorem, with the semi-circular distribution ")#link(<tao-e0b9a8799f32453a478c>)[#text("(1)")]#text(" taking on the role of the normal distribution. Of course, there is a striking difference between the two distributions, in that the former is compactly supported while the latter is merely subgaussian. One reason for this is that the concentration of measure phenomenon is more powerful in the case of ESDs of Wigner matrices than it is for averages of iid variables; compare the concentration of measure results in ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(" with those in ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(".")

#text("There are several ways to prove (or at least to heuristically justify) the semi-circular law. In this set of notes we shall focus on the two most popular methods, the ")#emph[#text("moment method")]#text(" and the ")#emph[#text("Stieltjes transform method")]#text(", together with a third (heuristic) method based on Dyson Brownian motion (")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("Notes 3b")]#text("). In the next set of notes we shall also study the free probability method, and in the set of notes after that we use the determinantal processes method (although this method is initially only restricted to highly symmetric ensembles, such as GUE).")

#metadata(none) <tao-9cbea495990bc4b942d5>

#heading(level: 1)[#strong[#text(" — 1. Preliminary reductions — ")]]

#text("Before we begin any of the proofs of the semi-circular law, we make some simple observations which will reduce the difficulty of the arguments in the sequel.")

#text("The first observation is that the Cauchy interlacing law (Exercise 14 from ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Notes 3a")]#text(") shows that the ESD of ")#mi("{\\frac{1}{\\sqrt{n}} M_n}")#text(" is very stable in ")#mi("{n}")#text(". Indeed, we see from the interlacing law that")

#tao-aligned(keep: true)[


#tao-math("\\frac{n}{m} \\mu_{\\frac{1}{\\sqrt{n}} M_n}( -\\infty, \\lambda / \\sqrt{n}) - \\frac{n-m}{m}  & \\leq \\mu_{\\frac{1}{\\sqrt{m}} M_m}( -\\infty, \\lambda / \\sqrt{m})", block: true)



#tao-math(" & \\leq \\frac{n}{m} \\mu_{\\frac{1}{\\sqrt{n}} M_n}( -\\infty, \\lambda / \\sqrt{n})", block: true)
]

#text("for any threshold ")#mi("{\\lambda}")#text(" and any ")#mi("{n > m > 0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Using this observation, show that to establish the semi-circular law (in any of the three senses of convergence), it suffices to do so for an arbitrary lacunary sequence ")#mi("{n_1, n_2, \\ldots}")#text(" of ")#mi("{n}")#text(" (thus ")#mi("{n_{j+1}/n_j \\geq c}")#text(" for some ")#mi("{c>1}")#text(" and all ")#mi("{j}")#text(").")
]

#text("The above lacunary reduction does not help one establish convergence in probability or expectation, but will be useful when establishing almost sure convergence, as it significantly reduces the inefficiency of the union bound. (Note that a similar lacunary reduction was also used to prove the strong law of large numbers in ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(".)")

#text("Next, we exploit the stability of the ESD with respect to perturbations, by taking advantage of the ")#emph[#text("Weilandt-Hoffmann inequality")]#text(" ")#metadata(none) <tao-509bcf065e86b5932aa2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{j=1}^n \\left|\\lambda_j(A+B)-\\lambda_j(A)\\right|^2 \\leq \\left\\|B\\right\\|_F^2", block: true)]]

#text(" for Hermitian matrices ")#mi("{A, B}")#text(", where ")#tao-math("{\\left\\|B\\right\\|_F := (\\text{tr} B^2)^{1/2}}", block: false)#text(" is the ")#link("http://en.wikipedia.org/wiki/Matrix_norm#Frobenius_norm")[#text("Frobenius norm")]#text(" of ")#mi("{B}")#text(". (This inequality was established in Exercise 6 or Exercise 11 of ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Notes 3a")]#text(".) We convert this inequality into an inequality about ESDs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" For any ")#mi("{n \\times n}")#text(" Hermitian matrices ")#mi("{A, B}")#text(", any ")#mi("{\\lambda}")#text(", and any ")#mi("{\\epsilon > 0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\mu_{\\frac{1}{\\sqrt{n}}(A+B)}(-\\infty, \\lambda) \\leq \\mu_{\\frac{1}{\\sqrt{n}}(A)}(-\\infty, \\lambda+\\epsilon) + \\frac{1}{\\epsilon^2 n^2} \\left\\|B\\right\\|_F^2", block: true)]]

#text("and similarly")

#align(center)[#tao-fit-display[#tao-math("\\mu_{\\frac{1}{\\sqrt{n}}(A+B)}(-\\infty, \\lambda) \\geq \\mu_{\\frac{1}{\\sqrt{n}}(A)}(-\\infty, \\lambda-\\epsilon) - \\frac{1}{\\epsilon^2 n^2} \\left\\|B\\right\\|_F^2.", block: true)]]
]

#emph[#text("Proof:")]#text(" We just prove the first inequality, as the second is similar (and also follows from the first, by reversing the sign of ")#mi("{A, B}")#text(").")

#text("Let ")#mi("{\\lambda_i(A+B)}")#text(" be the largest eigenvalue of ")#mi("{A+B}")#text(" less than ")#mi("{\\lambda \\sqrt{n}}")#text(", and let ")#mi("{\\lambda_j(A)}")#text(" be the largest eigenvalue of ")#mi("{A}")#text(" less than ")#mi("{(\\lambda+\\epsilon) \\sqrt{n}}")#text(". Our task is to show that")

#align(center)[#tao-fit-display[#tao-math("i \\leq j + \\frac{1}{\\epsilon^2 n} \\left\\|B\\right\\|_F^2.", block: true)]]

#text("If ")#mi("{i \\leq j}")#text(" then we are clearly done, so suppose that ")#mi("{i>j}")#text(". Then we have ")#tao-math("{\\left|\\lambda_l(A+B)-\\lambda_l(A)\\right| \\geq \\epsilon \\sqrt{n}}", block: false)#text(" for all ")#mi("{j < l \\leq i}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^n \\left|\\lambda_j(A+B)-\\lambda_j(A)\\right|^2 \\geq \\epsilon^2 (j-i) n.", block: true)]]

#text("The claim now follows from ")#link(<tao-509bcf065e86b5932aa2>)[#text("(2)")]#text(". ")#mi("\\Box")

#text("This has the following corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Stability of ESD laws wrt small perturbations)")]#text(" Let ")#mi("{M_n}")#text(" be a sequence of random Hermitian matrix ensembles such that ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges almost surely to a limit ")#mi("{\\mu}")#text(". Let ")#mi("{N_n}")#text(" be another sequence of Hermitian random matrix ensembles such that ")#tao-math("{\\frac{1}{n^2} \\left\\|N_n\\right\\|_F^2}", block: false)#text(" converges almost surely to zero. Show that ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}}(M_n+N_n)}}")#text(" converges almost surely to ")#mi("{\\mu}")#text(".")

#text("Show that the same claim holds if “almost surely” is replaced by “in probability” or “in expectation” throughout.")
]

#text("Informally, this exercise allows us to discard any portion of the matrix which is ")#mi("{o(n)}")#text(" in the Frobenius norm. For instance, the diagonal entries of ")#mi("{M_n}")#text(" have a Frobenius norm of ")#mi("{O(\\sqrt{n})}")#text(" almost surely, by the strong law of large numbers. Hence, without loss of generality, we may set the diagonal equal to zero for the purposes of the semi-circular law.")

#text("One can also remove any component of ")#mi("{M_n}")#text(" that is of rank ")#mi("{o(n)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Stability of ESD laws wrt small rank perturbations)")]#text(" ")#metadata(none) <tao-07eec6d7c90d79635d1b>#text(" Let ")#mi("{M_n}")#text(" be a sequence of random Hermitian matrix ensembles such that ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" converges almost surely to a limit ")#mi("{\\mu}")#text(". Let ")#mi("{N_n}")#text(" be another sequence of random Hermitian matrix ensembles such that ")#mi("{\\frac{1}{n} \\text{rank}(N_n)}")#text(" converges almost surely to zero. Show that ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}}(M_n+N_n)}}")#text(" converges almost surely to ")#mi("{\\mu}")#text(". (Hint: use the Weyl inequalities instead of the Wielandt-Hoffman law.)")

#text("Show that the same claim holds if “almost surely” is replaced by “in probability” or “in expectation” throughout.")
]

#text("In a similar vein, we may apply the truncation argument (much as was done for the central limit theorem in ")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("Notes 2")]#text(") to reduce the semi-circular law to the bounded case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that in order to prove the semi-circular law (in the almost sure sense), it suffices to do so under the additional hypothesis that the random variables are bounded. Similarly for the convergence in probability or in expectation senses.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" These facts ultimately rely on the stability of eigenvalues with respect to perturbations. This stability is automatic in the Hermitian case, but for non-symmetric matrices, serious instabilities can occur due to the presence of ")#link("http://en.wikipedia.org/wiki/Pseudospectrum")[#text("pseudospectrum")]#text(". We will discuss this phenomenon more in later lectures (but see also this ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("earlier blog post")]#text(").")
]

#heading(level: 1)[#strong[#text(" — 2. The moment method — ")]]

#text("We now prove the semi-circular law via the ")#emph[#text("method of moments")]#text(", which we have already used several times in the previous notes. In order to use this method, it is convenient to use the preceding reductions to assume that the coefficients are bounded, the diagonal vanishes, and that ")#mi("{n}")#text(" ranges over a lacunary sequence. We will implicitly assume these hypotheses throughout the rest of the section.")

#text("As we have already discussed the moment method extensively, much of the argument here will be delegated to exercises. A full treatment of these computations can be found in the ")#link("http://books.google.com/books?id=kd-o5Qdm7ngC&dq=bai+silverstein+spectral&source=gbs_navlinks_s")[#text("book of Bai and Silverstein")]#text(".")

#text("The basic starting point is the observation that the moments of the ESD ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" can be written as normalised traces of powers of ")#mi("{M_n}")#text(": ")#metadata(none) <tao-bcb9dae6ea88dbf28c26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\int_{\\mathbb R} x^k\\ d\\mu_{\\frac{1}{\\sqrt{n}} M_n}(x) = \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k.")]]

#text(" In particular, on taking expectations, we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbb R} x^k\\ d{\\bf E}\\mu_{\\frac{1}{\\sqrt{n}} M_n}(x) = {\\bf E} \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k.")]]

#text("From concentration of measure (and the Bai-Yin theorem) for the operator norm of a random matrix (Proposition 7 of ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text("), we see that the ")#mi("{{\\bf E} \\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" are uniformly subgaussian, indeed we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\mu_{\\frac{1}{\\sqrt{n}} M_n}\\{ \\left|x\\right| \\geq \\lambda \\} \\leq C e^{-c \\lambda^2 n^2}", block: true)]]

#text("for ")#mi("{\\lambda > C}")#text(", where ")#mi("{C, c}")#text(" are absolute (so the decay in fact improves quite rapidly with ")#mi("{n}")#text("). From this and the moment continuity theorem (Theorem 4 of ")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("Notes 2")]#text("), we can now establish the semi-circular law through computing the mean and variance of moments:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]

#list(
[#text("Show that to prove convergence in expectation to the semi-circular law, it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("{\\bf E} \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k = \\int_{\\mathbb R} x^k\\ d\\mu_{sc}(x) + o_k(1)")]]

#metadata(none) <tao-849c273cc0fe4b099304>#text(" for ")#mi("{k=1,2,\\ldots}")#text(", where ")#mi("{o_k(1)}")#text(" is an expression that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(" for fixed ")#mi("{k}")#text(" (and fixed choice of coefficient distribution ")#mi("{\\xi}")#text(").")],
[#text("Show that to prove convergence in probability to the semi-circular law, it suffices to show ")#link(<tao-849c273cc0fe4b099304>)[#text("(4)")]#text(" together with the variance bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\bf Var}(\\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k) = o_k(1)")]]

#metadata(none) <tao-48eefb0fa13cd6d5b549>#text(" for ")#mi("{k=1,2,\\ldots}")#text(".")],
[#text("Show that to prove almost sure convergence to the semi-circular law, it suffices to show ")#link(<tao-849c273cc0fe4b099304>)[#text("(4)")]#text(" together with the variance bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\bf Var}(\\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k) = O_k(n^{-c_k})")]]

#metadata(none) <tao-f8e675e589885e360eb9>#text(" for ")#mi("{k=1,2,\\ldots}")#text(" and some ")#mi("{c_k>0}")#text(". (Note here that it is useful to restrict ")#mi("{n}")#text(" to a lacunary sequence!)")]
)
]

#text("Ordinarily, computing second-moment quantities such as the left-hand side of ")#link(<tao-48eefb0fa13cd6d5b549>)[#text("(5)")]#text(" is harder than computing first-moment quantities such as ")#link(<tao-849c273cc0fe4b099304>)[#text("(4)")]#text(". But one can obtain the required variance bounds from concentration of measure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]

#list(
[#text("When ")#mi("{k}")#text(" is a positive even integer, Use Talagrand’s inequality and convexity of the Schatten norm ")#tao-math("{\\left\\|A\\right\\|_{S^k} = (\\text{tr}(A^k))^{1/k}}", block: false)#text(" to establish ")#link(<tao-f8e675e589885e360eb9>)[#text("(6)")]#text(" (and hence ")#link(<tao-48eefb0fa13cd6d5b549>)[#text("(5)")]#text(") when ")#mi("{k}")#text(" is even.")],
[#text("For ")#mi("{k}")#text(" odd, the formula ")#tao-math("{\\left\\|A\\right\\|_{S^k} = (\\text{tr}(A^k))^{1/k}}", block: false)#text(" still applies as long as ")#mi("{A}")#text(" is positive definite. Applying this observation, the Bai-Yin theorem, and Talagrand’s inequality to the ")#mi("{S^k}")#text(" norms of ")#mi("{\\frac{1}{\\sqrt{n}} M_n + c I_n}")#text(" for a constant ")#mi("{c>2}")#text(", establish ")#link(<tao-f8e675e589885e360eb9>)[#text("(6)")]#text(" (and hence ")#link(<tao-48eefb0fa13cd6d5b549>)[#text("(5)")]#text(") when ")#mi("{k}")#text(" is odd also.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" More generally, concentration of measure results (such as Talagrand’s inequality) can often be used to automatically upgrade convergence in expectation to convergence in probability or almost sure convergence. We will not attempt to formalise this principle here.")
]

#text("It is not difficult to establish ")#link(<tao-f8e675e589885e360eb9>)[#text("(6)")]#text(", ")#link(<tao-48eefb0fa13cd6d5b549>)[#text("(5)")]#text(" through the moment method as well. Indeed, recall from Theorem 10 of ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(" that we have the expected moment ")#metadata(none) <tao-a0244468c755c014cfbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\bf E} \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k = C_{k/2} + o_k(1)")]]

#text(" for all ")#mi("{k=1,2,\\ldots}")#text(", where the ")#link("http://en.wikipedia.org/wiki/Catalan_number")[#text("Catalan number")]#text(" ")#mi("{C_{k/2}}")#text(" is zero when ")#mi("{k}")#text(" is odd, and is equal to ")#metadata(none) <tao-cfb748e687a7f42890d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("C_{k/2} := \\frac{k!}{(k/2+1)! (k/2)!}")]]

#text(" for ")#mi("{k}")#text(" even.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" By modifying the proof of that theorem, show that ")#metadata(none) <tao-d7c670c74fa33a4d6511>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("{\\bf E} \\left|\\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k\\right|^2 = C_{k/2}^2 + o_k(1)", block: true)]]

#text(" and deduce ")#link(<tao-48eefb0fa13cd6d5b549>)[#text("(5)")]#text(". By refining the error analysis (e.g. using Theorem 12 of ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(", also establish ")#link(<tao-f8e675e589885e360eb9>)[#text("(6)")]#text(".")
]

#text("In view of the above computations, the establishment of the semi-circular law now reduces to computing the moments of the semi-circular distribution:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-4968d0cf3b24d26d1d37>#text(" Show that for any ")#mi("{k=1,2,3,\\ldots}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbb R} x^k\\ d\\mu_{sc}(x) = C_{k/2}.")]]

#text("(Hint: use a trigonometric substitution ")#mi("{x = 2 \\cos \\theta}")#text(", and then express the integrand in terms of Fourier phases ")#mi("{e^{in\\theta}}")#text(".)")
]

#text("This concludes the proof of the semi-circular law (for any of the three modes of convergence).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" ")#metadata(none) <tao-f04e8efb46e2d784ddf2>#text(" In the spirit of the Lindeberg exchange method, observe that Exercise ")#link(<tao-4968d0cf3b24d26d1d37>)[#text("(9)")]#text(" is unnecessary if one already knows that the semi-circular law holds for at least one ensemble of Wigner matrices (e.g. the GUE ensemble). Indeed, Exercise ")#link(<tao-4968d0cf3b24d26d1d37>)[#text("9")]#text(" can be ")#emph[#text("deduced")]#text(" from such a piece of knowledge. In such a situation, it is not necessary to actually compute the main term ")#mi("{C_{k/2}}")#text(" on the right of ")#link(<tao-849c273cc0fe4b099304>)[#text("(4)")]#text("; it would be sufficient to know that that limit is ")#emph[#text("universal")]#text(", in that it does not depend on the underlying distribution. In fact, it would even suffice to establish the slightly weaker statement")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n)^k = {\\bf E} \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M^{\\prime}_n)^k + o_k(1)")]]

#text("whenever ")#mi("{M_n, M^{\\prime}_n}")#text(" are two ensembles of Wigner matrices arising from different underlying distributions (but still normalised to have mean zero, unit variance, and to be bounded (or at worst subgaussian)). We will take advantage of this perspective later in these notes.")
]

#heading(level: 1)[#strong[#text(" — 3. The Stieltjes transform method — ")]]

#text("The moment method was computationally intensive, but straightforward. As noted in Remark ")#link(<tao-f04e8efb46e2d784ddf2>)[#text("4")]#text(", even without doing much of the algebraic computation, it is clear that the moment method will show that some universal limit for Wigner matrices exists (or, at least, that the differences between the distributions of two different Wigner matrices converge to zero). But it is not easy to see from this method why the limit should be given by the semi-circular law, as opposed to some other distribution (although one could eventually work this out from an inverse moment computation).")

#text("When studying the central limit theorem, we were able to use the Fourier method to control the distribution of random matrices in a cleaner way than in the moment method. Analogues of this method exist, but require non-trivial formulae from noncommutative Fourier analysis, such as the ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem_for_spherical_functions")[#text("Harish-Chandra integration formula")]#text(" (and also only work for highly symmetric ensembles, such as GUE or GOE), and will not be discussed in this course. (Our later notes on determinantal processes, however, will contain some algebraic identities related in some ways to the noncommutative Fourier-analytic approach.)")

#text("We now turn to another method, the ")#emph[#text("Stieltjes transform method")]#text(", which uses complex-analytic methods rather than Fourier-analytic methods, and has turned out to be one of the most powerful and accurate tools in dealing with the ESD of random Hermitian matrices. Whereas the moment method started from the identity ")#link(<tao-bcb9dae6ea88dbf28c26>)[#text("(3)")]#text(", the Stieltjes transform method proceeds from the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbb R} \\frac{1}{x-z}\\ d\\mu_{\\frac{1}{\\sqrt{n}} M_n}(x) = \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} M_n-zI)^{-1}")]]

#text("for any complex ")#mi("{z}")#text(" not in the support of ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(". We refer to the expression on the left-hand side as the ")#emph[#text("Stieltjes transform")]#text(" of ")#mi("{M_n}")#text(" or of ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(", and denote it by ")#mi("{s_{\\mu_{\\frac{1}{n}} M_n}}")#text(" or as ")#mi("{s_n}")#text(" for short. The expression ")#mi("{(\\frac{1}{\\sqrt{n}} M_n-zI)^{-1}}")#text(" is the normalised ")#link("http://en.wikipedia.org/wiki/Resolvent_formalism")[#text("resolvent")]#text(" of ")#mi("{M_n}")#text(", and plays an important role in the spectral theory of that matrix. Indeed, in contrast to general-purpose methods such as the moment method, the Stieltjes transform method draws heavily on the specific linear-algebraic structure of this problem, and in particular on the rich structure of resolvents.")

#text("On the other hand, the Stieltjes transform can be viewed as a generating function of the moments via the Taylor series expansion")

#align(center)[#tao-fit-display[#mitex("s_n(z) = -\\frac{1}{z} - \\frac{1}{z^2} \\frac{1}{n} \\text{tr} M_n - \\frac{1}{z^3} \\frac{1}{n} \\text{tr} M_n^2 - \\ldots,")]]

#text("valid for ")#mi("{z}")#text(" sufficiently large. This is somewhat (though not exactly) analogous to how the characteristic function ")#mi("{{\\bf E} e^{itX}}")#text(" of a scalar random variable can be viewed as a generating function of the moments ")#mi("{{\\bf E} X^k}")#text(".")

#text("Now let us study the Stieltjes transform more systematically. Given any probability measure ")#mi("{\\mu}")#text(" on the real line, we can form its ")#emph[#text("Stieltjes transform")]

#align(center)[#tao-fit-display[#mitex("s_\\mu(z) := \\int_{\\mathbb R} \\frac{1}{x-z}\\ d\\mu(x)")]]

#text("for any ")#mi("{z}")#text(" outside of the support of ")#mi("{\\mu}")#text("; in particular, the Stieltjes transform is well-defined on the upper and lower half-planes in the complex plane. Even without any further hypotheses on ")#mi("{\\mu}")#text(" other than it is a probability measure, we can say a remarkable amount about how this transform behaves in ")#mi("{z}")#text(". Applying conjugations we obtain the symmetry ")#metadata(none) <tao-1f245ea46ca2eebf725e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\overline{s_\\mu(z)} = s_\\mu(\\overline{z})")]]

#text(" so we may as well restrict attention to ")#mi("{z}")#text(" in the upper half-plane (say). Next, from the trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{x-z}\\right| \\leq \\frac{1}{\\left|\\text{Im}(z)\\right|}", block: true)]]

#text("one has the pointwise bound ")#metadata(none) <tao-7f50fc805a4750b61c40>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|s_\\mu(z)\\right| \\leq \\frac{1}{\\left|\\text{Im}(z)\\right|}.", block: true)]]

#text(" In a similar spirit, an easy application of dominated convergence gives the asymptotic ")#metadata(none) <tao-e29d3542d34ef349d62c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("s_\\mu(z) = \\frac{-1+o_\\mu(1)}{z}")]]

#text(" where ")#mi("{o_\\mu(1)}")#text(" is an expression that, for any fixed ")#mi("{\\mu}")#text(", goes to zero as ")#mi("{z}")#text(" goes to infinity ")#emph[#text("non-tangentially")]#text(" in the sense that ")#tao-math("{\\left|\\text{Re}(z)\\right|/\\left|\\text{Im(z)}\\right|}", block: false)#text(" is kept bounded, where the rate of convergence is allowed to depend on ")#mi("{\\mu}")#text(". From differentiation under the integral sign (or an application of ")#link("http://en.wikipedia.org/wiki/Morera's_theorem")[#text("Morera’s theorem")]#text(" and Fubini’s theorem) we see that ")#mi("{s_\\mu(z)}")#text(" is ")#emph[#text("complex analytic")]#text(" on the upper and lower half-planes; in particular, it is smooth away from the real axis. From the Cauchy integral formula (or differentiation under the integral sign) we in fact get some bounds for higher derivatives of the Stieltjes transform away from this axis: ")#metadata(none) <tao-c2deca13e7c3fc1be86f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|\\frac{d^j}{dz^j} s_\\mu(z)\\right| = O_j( \\frac{1}{\\left|\\text{Im}(z)\\right|^{j+1}} ).", block: true)]]

#text(" Informally, ")#mi("{s_\\mu}")#text(" “behaves like a constant” at scales significantly less than the distance ")#tao-math("{\\left|\\text{Im}(z)\\right|}", block: false)#text(" to the real axis; all the really interesting action here is going on near that axis.")

#text("The imaginary part of the Stieltjes transform is particularly interesting. Writing ")#mi("{z = a+ib}")#text(", we observe that")

#align(center)[#tao-fit-display[#mitex("\\text{Im}\\frac{1}{x-z} = \\frac{b}{(x-a)^2 + b^2} > 0")]]

#text("and so we see that")

#align(center)[#tao-fit-display[#mitex("\\text{Im}( s_\\mu(z) ) > 0")]]

#text("for ")#mi("{z}")#text(" in the upper half-plane; thus ")#mi("{s_\\mu}")#text(" is a complex-analytic map from the upper half-plane to itself, a type of function known as a ")#emph[#text("Herglotz function")]#text(". (In fact, all complex-analytic maps from the upper half-plane to itself that obey the asymptotic ")#link(<tao-e29d3542d34ef349d62c>)[#text("(12)")]#text(" are of this form; this is a special case of the ")#emph[#text("Herglotz representation theorem")]#text(", which also gives a slightly more general description in the case when the asymptotic ")#link(<tao-e29d3542d34ef349d62c>)[#text("(12)")]#text(" is not assumed. A good reference for this material and its consequences is this ")#link("http://www.ams.org/mathscinet-getitem?mr=2261424")[#text("book of Garnett")]#text(".)")

#text("One can also express the imaginary part of the Stieltjes transform as a convolution ")#metadata(none) <tao-c2912b8c99febfbc46b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\text{Im}( s_\\mu(a+ib) ) = \\pi \\mu * P_b(a)")]]

#text(" where ")#mi("{P_b}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Poisson_kernel")[#text("Poisson kernel")]

#align(center)[#tao-fit-display[#mitex("P_b(x) := \\frac{1}{\\pi} \\frac{b}{x^2+b^2} = \\frac{1}{b} P_1(\\frac{x}{b}).")]]

#text("As is well known, these kernels form a family of ")#link("http://en.wikipedia.org/wiki/Nascent_delta_function#nascent_delta_function")[#text("approximations to the identity")]#text(", and thus ")#mi("{\\mu * P_b}")#text(" converges in the vague topology to ")#mi("{\\mu}")#text(" (see e.g. my ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("notes on distributions")]#text("). Thus we see that")

#align(center)[#tao-fit-display[#mitex("\\text{Im} s_\\mu(\\cdot+ib) \\rightharpoonup \\pi \\mu")]]

#text("as ")#mi("{b \\rightarrow 0^+}")#text(" in the vague topology,or equivalently (by ")#link(<tao-1f245ea46ca2eebf725e>)[#text("(10)")]#text(") that ")#metadata(none) <tao-3780c9fcdc8b131bbaa2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\frac{s_\\mu(\\cdot+ib) - s_\\mu(\\cdot-ib)}{2\\pi i} \\rightharpoonup \\mu")]]

#text(" as ")#mi("{b \\rightarrow 0^+}")#text(" (this is closely related to the ")#emph[#text("Plemelj formula")]#text(" in potential theory). Thus we see that a probability measure ")#mi("{\\mu}")#text(" can be recovered in terms of the limiting behaviour of the Stieltjes transform on the real axis.")

#text("A variant of the above machinery gives us a criterion for convergence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Stieltjes continuity theorem)")]#text(" Let ")#mi("{\\mu_n}")#text(" be a sequence of random probability measures on the real line, and let ")#mi("{\\mu}")#text(" be a deterministic probability measure.")

#list(
[#mi("{\\mu_n}")#text(" converges almost surely to ")#mi("{\\mu}")#text(" in the vague topology if and only if ")#mi("{s_{\\mu_n}(z)}")#text(" converges almost surely to ")#mi("{s_\\mu(z)}")#text(" for every ")#mi("{z}")#text(" in the upper half-plane.")],
[#mi("{\\mu_n}")#text(" converges in probability to ")#mi("{\\mu}")#text(" in the vague topology if and only if ")#mi("{s_{\\mu_n}(z)}")#text(" converges in probability to ")#mi("{s_\\mu(z)}")#text(" for every ")#mi("{z}")#text(" in the upper half-plane.")],
[#mi("{\\mu_n}")#text(" converges in expectation to ")#mi("{\\mu}")#text(" in the vague topology if and only if ")#mi("{{\\bf E} s_{\\mu_n}(z)}")#text(" converges to ")#mi("{s_\\mu(z)}")#text(" for every ")#mi("{z}")#text(" in the upper half-plane.")]
)

#text("(Hint: The “only if” parts are fairly easy. For the “if” parts, take a test function ")#mi("{\\phi \\in C_c({\\mathbb R})}")#text(" and approximate ")#mi("{\\int_{\\mathbb R} \\phi\\ d\\mu}")#text(" by ")#mi("{\\int_{\\mathbb R} \\phi*P_b\\ d\\mu = \\frac{1}{\\pi} \\int_{\\mathbb R} s_\\mu(a+ib) \\phi(a)\\ da}")#text(". Then approximate this latter integral in turn by a Riemann sum, using ")#link(<tao-c2deca13e7c3fc1be86f>)[#text("(13)")]#text(".)")
]

#text("Thus, to prove the semi-circular law, it suffices to show that for each ")#mi("{z}")#text(" in the upper half-plane, the Stieltjes transform")

#align(center)[#tao-fit-display[#mitex("s_n(z) = s_{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}(z) = \\frac{1}{n} \\text{tr}( \\frac{1}{\\sqrt{n}} M_n - zI )^{-1}")]]

#text("converges almost surely (and thus in probability and in expectation) to the Stieltjes transform ")#mi("{s_{\\mu_{sc}}(z)}")#text(" of the semi-circular law.")

#text("It is not difficult to compute the Stieltjes transform ")#mi("{s_{\\mu_{sc}}}")#text(" of the semi-circular law, but let us hold off on that task for now, because we want to illustrate how the Stieltjes transform method can be used to ")#emph[#text("find")]#text(" the semi-circular law, even if one did not know this law in advance, by directly controlling ")#mi("{s_n(z)}")#text(". We will fix ")#mi("{z=a+ib}")#text(" to be a complex number not on the real line, and allow all implied constants in the discussion below to depend on ")#mi("{a}")#text(" and ")#mi("{b}")#text(" (we will focus here only on the behaviour as ")#mi("{n \\rightarrow \\infty}")#text(").")

#text("The main idea here is ")#emph[#text("predecessor comparison")]#text(": to compare the transform ")#mi("{s_n(z)}")#text(" of the ")#mi("{n \\times n}")#text(" matrix ")#mi("{M_n}")#text(" with the transform ")#mi("{s_{n-1}(z)}")#text(" of the top left ")#mi("{n-1 \\times n-1}")#text(" minor ")#mi("{M_{n-1}}")#text(", or of other minors. For instance, we have the ")#emph[#text("Cauchy interlacing law")]#text(" (Exercise 14 from ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Notes 3a")]#text("), which asserts that the eigenvalues ")#mi("{\\lambda_1(M_{n-1}),\\ldots,\\lambda_{n-1}(M_{n-1})}")#text(" of ")#mi("{M_{n-1}}")#text(" intersperse that of ")#mi("{\\lambda_1(M_n),\\ldots,\\lambda_n(M_n)}")#text(". This implies that for a complex number ")#mi("{a+ib}")#text(" with ")#mi("{b>0}")#text(", the difference")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^{n-1} \\frac{b}{(\\lambda_j(M_{n-1})/\\sqrt{n}-a)^2 + b^2} - \\sum_{j=1}^{n} \\frac{b}{(\\lambda_j(M_{n})/\\sqrt{n}-a)^2 + b^2}")]]

#text("is an alternating sum of evaluations of the function ")#mi("{x \\mapsto \\frac{b}{(x-a)^2+b^2}}")#text(". The total variation of this function is ")#mi("{O( 1 )}")#text(" (recall that we are suppressing dependence of constaants on ")#mi("{a,b}")#text("), and so the alternating sum above is ")#mi("{O(1)}")#text(". Writing this in terms of the Stieltjes transform, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sqrt{n(n-1)} s_{n-1}( \\frac{\\sqrt{n}}{\\sqrt{n-1}}(a+ib) ) - n s_n( a+ib ) = O(1).")]]

#text("Applying ")#link(<tao-c2deca13e7c3fc1be86f>)[#text("(13)")]#text(" to approximate ")#mi("{s_{n-1}( \\frac{\\sqrt{n}}{\\sqrt{n-1}}(a+ib) )}")#text(" by ")#mi("{s_{n-1}(a+ib)}")#text(", we conclude that ")#metadata(none) <tao-5a386a7d45bd704d30af>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("s_n(a+ib) = s_{n-1}(a+ib) + O( \\frac{1}{n} ).")]]

#text(" So for fixed ")#mi("{z=a+ib}")#text(" away from the real axis, the Stieltjes transform ")#mi("{s_n(z)}")#text(" is quite stable in ")#mi("{n}")#text(".")

#text("This stability has the following important consequence. Observe that while the left-hand side of ")#link(<tao-5a386a7d45bd704d30af>)[#text("(16)")]#text(" depends on the ")#mi("{n \\times n}")#text(" matrix ")#mi("{M_n}")#text(", the right-hand side depends only on the top left minor ")#mi("{M_{n-1}}")#text(" of that matrix. In particular, it is ")#emph[#text("independent")]#text(" of the ")#mi("{n^{th}}")#text(" row and column of ")#mi("{M_n}")#text(". This implies that this entire row and column has only a limited amount of ")#emph[#text("influence")]#text(" on the Stieltjes transform ")#mi("{s_n(a+ib)}")#text(": no matter what value one assigns to this row and column (including possibly unbounded values, as long as one keeps the matrix Hermitian of course), the transform ")#mi("{s_n(a+ib)}")#text(" can only move by ")#tao-math("{O( \\frac{\\left|a\\right|+\\left|b\\right|}{b^2 n} )}", block: false)#text(".")

#text("By permuting the rows and columns, we obtain that in fact any row or column of ")#mi("{M_n}")#text(" can influence ")#mi("{s_n(a+ib)}")#text(" is at most ")#mi("{O( \\frac{1}{n} )}")#text(". (This is closely related to the observation in Exercise ")#link(<tao-07eec6d7c90d79635d1b>)[#text("4")]#text(" that low rank perturbations do not significantly affect the ESD.) On the other hand, the rows of (the upper triangular portion of) ")#mi("{M_n}")#text(" are jointly independent. When ")#mi("{M_n}")#text(" is a Wigner random matrix, we can then apply a standard concentration of measure result, such as ")#link("http://en.wikipedia.org/wiki/McDiarmid's_inequality")[#text("McDiarmid’s inequality")]#text(" (Theorem 7 from ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(") to conclude concetration of ")#mi("{s_n}")#text(" around its mean: ")#metadata(none) <tao-dc00c68db9bb9787a8d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("{\\bf P}( \\left|s_n(a+ib) - {\\Bbb E} s_n(a+ib)\\right| \\geq \\lambda/\\sqrt{n} ) \\leq C e^{-c\\lambda^2}", block: true)]]

#text(" for all ")#mi("{\\lambda > 0}")#text(" and some absolute constants ")#mi("{C, c > 0}")#text(". (This is not necessarily the strongest concentration result one can establish for the Stieltjes transform, but it will certainly suffice for our discussion here.) In particular, we see from the Borel-Cantelli lemma (Exercise 24 of ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0a")]#text(")that for any fixed ")#mi("{z}")#text(" away from the real line, ")#mi("{s_n(z) - {\\bf E} s_n(z)}")#text(" converges almost surely (and thus also in probability) to zero. As a consequence, convergence of ")#mi("{s_n(z)}")#text(" in expectation automatically implies convergence in probability or almost sure convergence.")

#text("However, while concentration of measure tells us that ")#mi("{s_n(z)}")#text(" is close to its mean, it does not shed much light as to what this mean ")#emph[#text("is")]#text(". For this, we have to go beyond the Cauchy interlacing formula and deal with the resolvent ")#mi("{(\\frac{1}{\\sqrt{n}} M_n - z I_n)^{-1}}")#text(" more directly. Firstly, we observe from the linearity of trace that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} s_n(z) = \\frac{1}{n} \\sum_{j=1}^n {\\bf E} [ (\\frac{1}{\\sqrt{n}} M_n - z I_n)^{-1} ]_{jj}")]]

#text("where ")#mi("{[A]_{jj}}")#text(" denotes the ")#mi("{jj}")#text(" component of a matrix ")#mi("{A}")#text(". Because ")#mi("{M_n}")#text(" is a Wigner matrix, it is easy to see on permuting the rows and columns that all of the random variables ")#mi("{[ (\\frac{1}{\\sqrt{n}} M_n - z I_n)^{-1} ]_{jj}}")#text(" have the same distribution. Thus we may simplify the above formula as ")#metadata(none) <tao-d03f3d5a8ba8d47c300a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("{\\bf E} s_n(z) = {\\bf E} [ (\\frac{1}{\\sqrt{n}} M_n - z I_n)^{-1} ]_{nn}.")]]

#text(" So now we have to compute the last entry of an inverse of a matrix. There are of course a number of formulae for this, such as Cramer’s rule. But it will be more convenient here to use a formula based instead on the ")#link("http://en.wikipedia.org/wiki/Schur_complement")[#text("Schur complement")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{A_n}")#text(" be a ")#mi("{n \\times n}")#text(" matrix, let ")#mi("{A_{n-1}}")#text(" be the top left ")#mi("{n-1 \\times n-1}")#text(" minor, let ")#mi("{a_{nn}}")#text(" be the bottom right entry of ")#mi("{A_n}")#text(", let ")#mi("{X \\in {\\mathbb C}^{n-1}}")#text(" be the right column of ")#mi("{A_n}")#text(" with the bottom right entry removed, and let ")#mi("{(X^{\\prime})^* \\in ({\\mathbb C}^{n-1})^*}")#text(" be the bottom row with the bottom right entry removed. In other words,")

#align(center)[#tao-fit-display[#mitex("A_n = \\begin{pmatrix} A_{n-1} & X \\\\ (X^{\\prime})^* & a_{nn} \\end{pmatrix}.")]]

#text("Assume that ")#mi("{A_n}")#text(" and ")#mi("{A_{n-1}}")#text(" are both invertible. Show that")

#align(center)[#tao-fit-display[#mitex("[A_n^{-1}]_{nn} = \\frac{1}{a_{nn} - (X^{\\prime})^* A_{n-1}^{-1} X}.")]]

#text("(")#emph[#text("Hint:")]#text(" Solve the equation ")#mi("{A_n v = e_n}")#text(", where ")#mi("{e_n}")#text(" is the ")#mi("{n^{th}}")#text(" basis vector, using the method of Schur complements (or from first principles).)")
]

#text("The point of this identity is that it describes (part of) the inverse of ")#mi("{A_n}")#text(" in terms of the inverse of ")#mi("{A_{n-1}}")#text(", which will eventually provide a non-trivial recursive relationship between ")#mi("{s_n(z)}")#text(" and ")#mi("{s_{n-1}(z)}")#text(", which can then be played off against ")#link(<tao-5a386a7d45bd704d30af>)[#text("(16)")]#text(" to solve for ")#mi("{s_n(z)}")#text(" in the asymptotic limit ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("In our situation, the matrix ")#mi("{\\frac{1}{\\sqrt{n}} M_n - z I_n}")#text(" and its minor ")#mi("{\\frac{1}{\\sqrt{n}} M_{n-1} - z I_{n-1}}")#text(" is automatically invertible. Inserting the above formula into ")#link(<tao-d03f3d5a8ba8d47c300a>)[#text("(18)")]#text(" (and recalling that we normalised the diagonal of ")#mi("{M_n}")#text(" to vanish), we conclude that ")#metadata(none) <tao-bce6cd18eac3fcc50806>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("{\\bf E} s_n(z) = - {\\bf E} \\frac{1}{z + \\frac{1}{n} X^* (\\frac{1}{\\sqrt{n}} M_{n-1} - z I_{n-1})^{-1} X },")]]

#text(" where ")#mi("{X \\in {\\mathbb C}^{n-1}}")#text(" is the top right column of ")#mi("{M_n}")#text(" with the bottom entry ")#mi("{\\xi_{nn}}")#text(" removed.")

#text("One may be concerned that the denominator here could vanish. However, observe that ")#mi("{z}")#text(" has imaginary part ")#mi("{b}")#text(" if ")#mi("{z=a+ib}")#text(". Furthermore, from the spectral theorem we see that the imaginary part of ")#mi("{(\\frac{1}{\\sqrt{n}} M_{n-1} - z I_{n-1})^{-1}}")#text(" is positive definite, and so ")#mi("{X^* (\\frac{1}{\\sqrt{n}} M_{n-1} - z I_{n-1})^{-1} X}")#text(" has non-negative imaginary part. As a consequence the magnitude of the denominator here is bounded below by ")#tao-math("{\\left|b\\right|}", block: false)#text(", and so its reciprocal is ")#mi("{O(1)}")#text(" (compare with ")#link(<tao-7f50fc805a4750b61c40>)[#text("(11)")]#text("). So the reciprocal here is not going to cause any discontinuity, as we are considering ")#mi("{b}")#text(" is fixed and non-zero.")

#text("Now we need to understand the expression ")#mi("{X^* (\\frac{1}{\\sqrt{n}} M_{n-1} - z I_{n-1})^{-1} X}")#text(". We write this as ")#mi("{X^* R X}")#text(", where ")#mi("{R}")#text(" is the resolvent matrix ")#mi("{R := (\\frac{1}{\\sqrt{n}} M_{n-1} - z I_{n-1})^{-1}}")#text(". The distribution of the random matrix ")#mi("{R}")#text(" could conceivably be quite complicated. However, the key point is that the vector ")#mi("{X}")#text(" only involves the entries of ")#mi("{M_n}")#text(" that do not lie in ")#mi("{M_{n-1}}")#text(", and so the random matrix ")#mi("{R}")#text(" and the vector ")#mi("{X}")#text(" are ")#emph[#text("independent")]#text(". Because of this, we can use the randomness of ")#mi("{X}")#text(" to do most of the work in understanding the expression ")#mi("{X^* R X}")#text(", without having to know much about ")#mi("{R}")#text(" at all.")

#text("To understand this, let us first condition ")#mi("{R}")#text(" to be a ")#emph[#text("deterministic")]#text(" matrix ")#mi("{R = (r_{ij})_{1 \\leq i,j \\leq n-1}}")#text(", and see what we can do with the expression ")#mi("{X^* R X}")#text(".")

#text("Firstly, observe that ")#mi("{R}")#text(" will not be arbitrary; indeed, from the spectral theorem we see that ")#mi("{R}")#text(" will have operator norm at most ")#mi("{O(1)}")#text(". Meanwhile, from the Chernoff (or Hoeffding) inequality (Theorem 2 or Exercise 4 of ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(") we know that ")#mi("{X}")#text(" has magnitude ")#mi("{O( \\sqrt{n} )}")#text(" with overwhelming probability. So we know that ")#mi("{X^* R X}")#text(" has magnitude ")#mi("{O( n )}")#text(" with overwhelming probability.")

#text("Furthermore, we can use concentration of measure as follows. Given any positive semi-definite matrix ")#mi("{A}")#text(" of operator norm ")#mi("{O(1)}")#text(", the expression ")#tao-math("{(X^* A X)^{1/2} = \\left\\| A^{1/2} X \\right\\|}", block: false)#text(" is a Lipschitz function of ")#mi("{X}")#text(" with operator norm ")#mi("{O(1)}")#text(". Applying Talagrand’s inequality (Theorem 9 of ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(") we see that this expression concentrates around its median:")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|(X^* A X)^{1/2} - {\\bf M} (X^* A X)^{1/2}\\right| \\geq \\lambda ) \\leq C e^{-c\\lambda^2}", block: true)]]

#text("for any ")#mi("{\\lambda > 0}")#text(". On the other hand, ")#tao-math("{\\left\\|A^{1/2} X\\right\\| = O( \\left\\|X\\right\\| )}", block: false)#text(" has magnitude ")#mi("{O(\\sqrt{n})}")#text(" with overwhelming probability, so the median ")#mi("{{\\bf M} (X^* A X)^{1/2}}")#text(" must be ")#mi("{O(\\sqrt{n})}")#text(". Squaring, we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|X^* A X - {\\bf M} X^* A X\\right| \\geq \\lambda \\sqrt{n} ) \\leq C e^{-c\\lambda^2}", block: true)]]

#text("(possibly after adjusting the absolute constants ")#mi("{C, c}")#text("). As usual, we may replace the median with the expectation:")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|X^* A X - {\\bf E} X^* A X\\right| \\geq \\lambda \\sqrt{n} ) \\leq C e^{-c\\lambda^2}", block: true)]]

#text("This was for positive-definite matrices, but one can easily use the triangle inequality to generalise to self-adjoint matrices, and then to arbitrary matrices, of operator norm ")#mi("{1}")#text(", and conclude that ")#metadata(none) <tao-30062ed9f04232e10d8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("{\\bf P}( \\left|X^* R X - {\\bf E} X^* R X\\right| \\geq \\lambda \\sqrt{n} ) \\leq C e^{-c\\lambda^2}", block: true)]]

#text(" for any deterministic matrix ")#mi("{R}")#text(" of operator norm ")#mi("{O(1)}")#text(".")

#text("But what is the expectation ")#mi("{{\\bf E} X^* R X}")#text("? This can be expressed in components as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X^* R X = \\sum_{i=1}^{n-1} \\sum_{j=1}^{n-1} {\\bf E} \\overline{\\xi_{in}} r_{ij} \\xi_{jn}")]]

#text("where ")#mi("{\\xi_{in}}")#text(" are the entries of ")#mi("{X}")#text(", and ")#mi("{r_{ij}}")#text(" are the entries of ")#mi("{R}")#text(". But the ")#mi("{\\xi_{in}}")#text(" are iid with mean zero and variance one, so the standard second moment computation shows that this expectation is nothing more than the trace")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(R) = \\sum_{i=1}^{n-1} r_{ii}")]]

#text("of ")#mi("{R}")#text(". We have thus shown the concentration of measure result ")#metadata(none) <tao-5db6e58c4fd3f0395a6a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("{\\bf P}( \\left|X^* R X - \\text{tr}(R)\\right| \\geq \\lambda \\sqrt{n} ) \\leq C e^{-c\\lambda^2}", block: true)]]

#text(" for any deterministic matrix ")#mi("{R}")#text(" of operator norm ")#mi("{O(1)}")#text(", and any ")#mi("{\\lambda > 0}")#text(". Informally, ")#mi("{X^* R X}")#text(" is typically ")#mi("{\\text{tr}(R) +O(\\sqrt{n})}")#text(".")

#text("The bound ")#link(<tao-5db6e58c4fd3f0395a6a>)[#text("(21)")]#text(" was proven for deterministic matrices, but by using conditional expectation it also applies for any random matrix ")#mi("{R}")#text(", so long as that matrix is independent of ")#mi("{X}")#text(". In particular, we may apply it to our specific matrix of interest")

#align(center)[#tao-fit-display[#mitex("R := (\\frac{1}{\\sqrt{n}} M_{n-1} - z I_{n-1})^{-1}.")]]

#text("The trace of this matrix is essentially just the Stieltjes transform ")#mi("{s_{n-1}(z)}")#text(" at ")#mi("{z}")#text(". Actually, due to the normalisation factor being slightly off, we actually have")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(R) = n \\frac{\\sqrt{n}}{\\sqrt{n-1}} s_{n-1}( \\frac{\\sqrt{n}}{\\sqrt{n-1}} z ),")]]

#text("but by using the smoothness ")#link(<tao-c2deca13e7c3fc1be86f>)[#text("(13)")]#text(" of the Stieltjes transform, together with the stability property ")#link(<tao-5a386a7d45bd704d30af>)[#text("(16)")]#text(" we can simplify this as")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(R) = n ( s_n(z) + o(1) ).")]]

#text("In particular, from ")#link(<tao-5db6e58c4fd3f0395a6a>)[#text("(21)")]#text(" and ")#link(<tao-dc00c68db9bb9787a8d5>)[#text("(17)")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("X^* R X = n ( {\\bf E} s_n(z) + o(1) )")]]

#text("with overwhelming probability. Putting this back into ")#link(<tao-bce6cd18eac3fcc50806>)[#text("(19)")]#text(", and recalling that the denominator is bounded away from zero, we have the remarkable equation ")#metadata(none) <tao-196292f8a25dd27f49d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("{\\bf E} s_n(z) = - \\frac{1}{z + {\\bf E} s_n(z)} + o(1).")]]

#text(" Note how this equation came by playing off two ways in which the spectral properties of a matrix ")#mi("{M_n}")#text(" interacted with that of its minor ")#mi("{M_{n-1}}")#text("; firstly via the Cauchy interlacing inequality, and secondly via the Schur complement formula.")

#text("This equation already describes the behaviour of ")#mi("{{\\bf E} s_n(z)}")#text(" quite well, but we will content ourselves with understanding the limiting behaviour as ")#mi("{n \\rightarrow \\infty}")#text(". From ")#link(<tao-c2deca13e7c3fc1be86f>)[#text("(13)")]#text(" and Fubini’s theorem we know that the function ")#mi("{{\\bf E} s_n}")#text(" is locally uniformly equicontinuous and locally uniformly bounded away from the real line. Applying the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(", we thus conclude that on a subsequence at least, ")#mi("{{\\bf E} s_n}")#text(" converges locally uniformly to a limit ")#mi("{s}")#text(". This will be a Herglotz function (i.e. an analytic function mapping the upper half-plane to the upper half-plane), and taking limits in ")#link(<tao-196292f8a25dd27f49d9>)[#text("(22)")]#text(" (observing that the imaginary part of the denominator here is bounded away from zero) we end up with the exact equation ")#metadata(none) <tao-2f684bfc72152ad9632c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("s(z) = -\\frac{1}{z+s(z)}.")]]

#text(" We can of course solve this by the quadratic formula, obtaining")

#align(center)[#tao-fit-display[#mitex("s(z) = - \\frac{z \\pm \\sqrt{z^2-4}}{2} = \\frac{2}{z \\pm \\sqrt{z^2-4}}.")]]

#text("To figure out what branch of the square root one has to use here, we use ")#link(<tao-e29d3542d34ef349d62c>)[#text("(12)")]#text(", which easily implies that")

#align(center)[#tao-fit-display[#mitex("s(z) = \\frac{1+o(1)}{z}")]]

#text("as ")#mi("{z}")#text(" goes to infinity non-tangentially away from the real line. (To justify this, one has to make the error term in ")#link(<tao-e29d3542d34ef349d62c>)[#text("(12)")]#text(" uniform in ")#mi("{n}")#text(", but this can be accomplished without difficulty using the Bai-Yin theorem (for instance).) Also, we know that ")#mi("{s}")#text(" has to be complex analytic (and in particular, continuous) away from the real line. From this and basic complex analysis, we conclude that ")#metadata(none) <tao-2d02936913ab0ce93c33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("s(z) = \\frac{-z + \\sqrt{z^2-4}}{2}")]]

#text(" where ")#mi("{\\sqrt{z^2-4}}")#text(" is the branch of the square root with a branch cut at ")#mi("{[-2,2]}")#text(" and which equals ")#mi("{z}")#text(" at infinity.")

#text("As there is only one possible subsequence limit of the ")#mi("{{\\bf E} s_n}")#text(", we conclude that ")#mi("{{\\bf E} s_n}")#text(" converges locally uniformly (and thus pointwise) to the function ")#link(<tao-2d02936913ab0ce93c33>)[#text("(24)")]#text(", and thus (by the concentration of measure of ")#mi("{s_n(z)}")#text(") we see that for each ")#mi("{z}")#text(", ")#mi("{s_n(z)}")#text(" converges almost surely (and in probability) to ")#mi("{s(z)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-d15690f08a575024650b>#text(" Find a direct proof (starting from ")#link(<tao-196292f8a25dd27f49d9>)[#text("(22)")]#text(", ")#link(<tao-e29d3542d34ef349d62c>)[#text("(12)")]#text(", and the smoothness of ")#mi("{{\\bf E} s_n(z)}")#text(") that ")#mi("{{\\bf E} s_n(z) = s(z) + o(1)}")#text(" for any fixed ")#mi("{z}")#text(", that avoids using the Arzelá-Ascoli theorem. (The basic point here is that one has to solve the approximate equation ")#link(<tao-196292f8a25dd27f49d9>)[#text("(22)")]#text(", using some robust version of the quadratic formula. The fact that ")#mi("{{\\bf E} s_n}")#text(" is a Herglotz function will help eliminate various unwanted possibilities, such as one coming from the wrong branch of the square root.)")
]

#text("To finish computing the limiting ESD of Wigner matrices, we have to figure out what probability measure ")#mi("{s}")#text(" comes from. But this is easily read off from ")#link(<tao-2d02936913ab0ce93c33>)[#text("(24)")]#text(" and ")#link(<tao-3780c9fcdc8b131bbaa2>)[#text("(15)")]#text(": ")#metadata(none) <tao-3f40b0482829b037d2dd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\frac{s(\\cdot+ib) - s(\\cdot-ib)}{2\\pi i} \\rightharpoonup \\frac{1}{2\\pi} (4-x^2)^{1/2}_+\\ dx = \\mu_{sc}")]]

#text(" as ")#mi("{b \\rightarrow 0}")#text(". Thus the semi-circular law is the only possible measure which has Stieltjes transform ")#mi("{s}")#text(", and indeed a simple application of the Cauchy integral formula and ")#link(<tao-3f40b0482829b037d2dd>)[#text("(25)")]#text(" shows us that ")#mi("{s}")#text(" is indeed the Stieltjes transform of ")#mi("{\\mu_{sc}}")#text(".")

#text("Putting all this together, we have completed the Stieltjes transform proof of the semi-circular law.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" In order to simplify the above exposition, we opted for a qualitative analysis of the semi-circular law here, ignoring such questions as the rate of convergence to this law. However, an inspection of the above arguments reveals that it is easy to make all of the above analysis quite quantitative, with quite reasonable control on all terms. (One has to use Exercise ")#link(<tao-d15690f08a575024650b>)[#text("12")]#text(" instead of the Arzelá-Ascoli theorem if one wants everything to be quantitative.) In particular, it is not hard to use the above analysis to show that for ")#tao-math("{\\left|\\text{Im}(z)\\right| \\geq n^{-c}}", block: false)#text(" for some small absolute constant ")#mi("{c>0}")#text(", one has ")#mi("{s_n(z) = s(z) + O(n^{-c})}")#text(" with overwhelming probability. Combining this with a suitably quantitative version of the Stieltjes continuity theorem, this in turn gives a ")#emph[#text("polynomial rate")]#text(" of convergence of the ESDs ")#mi("{\\mu_{\\frac{1}{\\sqrt{n}} M_n}}")#text(" to the semi-circular law ")#mi("{\\mu_{sc}}")#text(", in that one has")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\frac{1}{\\sqrt{n}} M_n}( -\\infty, \\lambda ) = \\mu_{sc}(-\\infty,\\lambda) + O(n^{-c})")]]

#text("with overwhelming probability for all ")#mi("{\\lambda \\in {\\mathbb R}}")#text(".")

#text("A variant of this quantitative analysis can in fact get very good control on this ESD down to quite fine scales, namely to scales ")#mi("{\\frac{\\log^{O(1)} n}{n}}")#text(", which is only just a little bit larger than the mean spacing ")#mi("{O(1/n)}")#text(" of the normalised eigenvalues (recall that we have ")#mi("{n}")#text(" normalised eigenvalues, constrained to lie in the interval ")#mi("{[-2-o(1), 2+o(1)]}")#text(" by the Bai-Yin theorem). This was accomplished by Erdös, Schlein, and Yau (under some additional regularity hypotheses on the distribution ")#mi("{\\xi}")#text(", but these can be easily removed with the assistance of Talagrand’s inequality) by using an additional observation, namely that the ")#emph[#text("eigenvectors")]#text(" of a random matrix are very likely to be ")#emph[#text("delocalised")]#text(" in the sense that their ")#mi("{\\ell^2}")#text(" energy is dispersed more or less evenly across its coefficients. We will return to this point in later notes.")
]

#heading(level: 1)[#strong[#text(" — 4. Dyson Brownian motion and the Stieltjes transform — ")]]

#text("We now explore how the Stieltjes transform interacts with the Dyson Brownian motion introduced in ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("Notes 3b")]#text(". We let ")#mi("{n}")#text(" be a large number, and let ")#mi("{M_{n}(t)}")#text(" be a Wiener process of Hermitian random matrices, with associated eigenvalues ")#mi("{\\lambda_{1}(t),\\ldots,\\lambda_{n}(t)}")#text(", Stieltjes transforms ")#metadata(none) <tao-bb1046b429a7f917a06d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("s(t,z) := \\frac{1}{n} \\sum_{j=1}^n \\frac{1}{\\lambda_{j}(t)/\\sqrt{n} - z}")]]

#text(" and spectral measures ")#metadata(none) <tao-818b710927bc7f74c875>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\mu(t,z) := \\frac{1}{n} \\sum_{j=1}^n \\delta_{\\lambda_j(t)/\\sqrt{n}}.")]]

#text(" We now study how ")#mi("{s}")#text(", ")#mi("{\\mu}")#text(" evolve in time in the asymptotic limit ")#mi("{n \\rightarrow \\infty}")#text(". Our computation will be only heuristic in nature.")

#text("Recall from ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("Notes 3b")]#text(" that the eigenvalues ")#mi("{\\lambda_i = \\lambda_i(t)}")#text(" undergo Dyson Brownian motion ")#metadata(none) <tao-d40d46ae37e21f9dbd3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("d\\lambda_i = dB_i + \\sum_{j \\neq i} \\frac{dt}{\\lambda_i-\\lambda_j}.")]]

#text(" Applying ")#link(<tao-bb1046b429a7f917a06d>)[#text("(26)")]#text(" and Taylor expansion (dropping all terms of higher order than ")#mi("{dt}")#text(", using the Ito heuristic ")#mi("{dB_i = O(dt^{1/2})}")#text("), we conclude that")

#tao-aligned(keep: true)[


#tao-math("ds  & = - \\frac{1}{n^{3/2}} \\sum_{i=1}^n \\frac{dB_i}{(\\lambda_i/\\sqrt{n}-z)^2} - \\frac{1}{n^2} \\sum_{i=1}^n \\frac{\\left|dB_i\\right|^2}{(\\lambda_i/\\sqrt{n}-z)^3}", block: true)



#tao-math(" & - \\frac{1}{n^{3/2}} \\sum_{1 \\leq i,j \\leq n: i \\neq j}\\frac{dt}{(\\lambda_i - \\lambda_j) (\\lambda_j/\\sqrt{n}-z)^2}.", block: true)
]

#text("For ")#mi("{z}")#text(" away from the real line, the term ")#tao-math("{\\frac{1}{n^2} \\sum_{i=1}^n \\frac{\\left|dB_i\\right|^2}{(\\lambda_i/\\sqrt{n}-z)^3}}", block: false)#text(" is of size ")#mi("{O( dt / n )}")#text(" and can heuristically be ignored in the limit ")#mi("{n \\rightarrow \\infty}")#text(". Dropping this term, and then taking expectations to remove the Brownian motion term ")#mi("{dB_i}")#text(", we are led to")

#align(center)[#tao-fit-display[#mitex("{\\bf E} ds = - {\\bf E} \\frac{1}{n^{3/2}} \\sum_{1 \\leq i,j \\leq n: i \\neq j}\\frac{dt}{(\\lambda_i - \\lambda_j) (\\lambda_j/\\sqrt{n}-z)^2}.")]]

#text("Performing the ")#mi("{i}")#text(" summation using ")#link(<tao-bb1046b429a7f917a06d>)[#text("(26)")]#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("{\\bf E} ds = - {\\bf E} \\frac{1}{n} \\sum_{1 \\leq j \\leq n} \\frac{s(\\lambda_j/\\sqrt{n}) dt}{(\\lambda_j/\\sqrt{n}-z)^2}")]]

#text("where we adopt the convention that for real ")#mi("{x}")#text(", ")#mi("{s(x)}")#text(" is the average of ")#mi("{s(x+i0)}")#text(" and ")#mi("{s(x-i0)}")#text(". Using ")#link(<tao-818b710927bc7f74c875>)[#text("(27)")]#text(", this becomes ")#metadata(none) <tao-c5fde5a3ea8156effd63>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("{\\bf E} s_t = - {\\bf E} \\int_{\\mathbb R} \\frac{s(x)}{(x-z)^2}\\ d\\mu(x)")]]

#text(" where the ")#mi("{t}")#text(" subscript denotes differentiation in ")#mi("{t}")#text(". From ")#link(<tao-3780c9fcdc8b131bbaa2>)[#text("(15)")]#text(" we heuristically have")

#align(center)[#tao-fit-display[#mitex("s(x \\pm i0) = s(x) \\pm \\pi i \\mu(x)")]]

#text("(heuristically treating ")#mi("{\\mu}")#text(" as a function rather than a measure) and on squaring one obtains")

#align(center)[#tao-fit-display[#mitex("s(x \\pm i0)^2 = (s(x)^2 - \\pi^2 \\mu^2(x)) \\pm 2 \\pi i s(x) \\mu(x).")]]

#text("From this the Cauchy integral formula around a slit in real axis (using the bound ")#link(<tao-7f50fc805a4750b61c40>)[#text("(11)")]#text(" to ignore the contributions near infinity) we thus have")

#align(center)[#tao-fit-display[#mitex("s^2(z) = \\int_{\\mathbb R} \\frac{2s(x)}{x-z}\\ d\\mu(x)")]]

#text("and thus on differentiation in ")#mi("{z}")

#align(center)[#tao-fit-display[#mitex("2 s s_z(z) = \\int_{\\mathbb R} \\frac{2s(x)}{(x-z)^2}\\ d\\mu(x).")]]

#text("Comparing this with ")#link(<tao-c5fde5a3ea8156effd63>)[#text("(29)")]#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("{\\bf E} s_t + {\\bf E} s s_z = 0.")]]

#text("From concentration of measure, we expect ")#mi("{s}")#text(" to concentrate around its mean ")#mi("{\\overline{s} := {\\bf E} s}")#text(", and similarly ")#mi("{s_z}")#text(" should concentrate around ")#mi("{\\overline{s}_z}")#text(". In the limit ")#mi("{n \\rightarrow \\infty}")#text(", the expected Stieltjes transform ")#mi("{\\overline{s}}")#text(" should thus obey ")#link("http://en.wikipedia.org/wiki/Burgers'_equation")[#text("Burgers’ equation")]#text(" ")#metadata(none) <tao-123067cba2d3fb594e6f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("s_t + s s_z = 0.")]]

#text(" To illustrate how this equation works in practice, let us give an informal derivation of the semi-circular law. We consider the case when the Wiener process starts from ")#mi("{M(0) = 0}")#text(", thus ")#mi("{M_t \\equiv \\sqrt{t} G}")#text(" for a GUE matrix ")#mi("{G}")#text(". As such, we have the scaling symmetry")

#align(center)[#tao-fit-display[#mitex("s(t,z) = \\frac{1}{\\sqrt{t}} s_{GUE}(\\frac{z}{\\sqrt{t}})")]]

#text("where ")#mi("{s_{GUE}}")#text(" is the asymptotic Stieltjes transform for GUE (which we secretly know to be given by ")#link(<tao-2d02936913ab0ce93c33>)[#text("(24)")]#text(", but let us pretend that we did not yet know this fact). Inserting this self-similar ansatz into ")#link(<tao-123067cba2d3fb594e6f>)[#text("(30)")]#text(" and setting ")#mi("{t=1}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("-\\frac{1}{2} s_{GUE} - \\frac{1}{2} z s^{\\prime}_{GUE} + s s^{\\prime}_{GUE} = 0;")]]

#text("multiplying by two and integrating, we conclude that")

#align(center)[#tao-fit-display[#mitex("z s_{GUE} + s_{GUE}^2 = C")]]

#text("for some constant ")#mi("{C}")#text(". But from the asymptotic ")#link(<tao-e29d3542d34ef349d62c>)[#text("(12)")]#text(" we see that ")#mi("{C}")#text(" must equal ")#mi("{-1}")#text(". But then the above equation can be rearranged into ")#link(<tao-2f684bfc72152ad9632c>)[#text("(23)")]#text(", and so by repeating the arguments at the end of the previous section we can deduce the formula ")#link(<tao-2d02936913ab0ce93c33>)[#text("(24)")]#text(", which then gives the semi-circular law by ")#link(<tao-3780c9fcdc8b131bbaa2>)[#text("(15)")]#text(".")

#text("As is well known in PDE, one can solve Burgers’ equation more generally by the ")#link("http://en.wikipedia.org/wiki/Method_of_characteristics")[#text("method of characteristics")]#text(". For reasons that will be come clearer in the next set of notes, I will solve this equation by a slightly different (but ultimately equivalent) method. The idea is that rather than think of ")#mi("{s=s(t,z)}")#text(" as a function of ")#mi("{z}")#text(" for fixed ")#mi("{t}")#text(", we think of ")#mi("{z=z(t,s)}")#text(" as a function of ")#mi("{s}")#text(" for fixed ")#mi("{t}")#text(". (This trick is sometimes known as the ")#link("http://en.wikipedia.org/wiki/Hodograph")[#text("hodograph")]#text(" transform, especially if one views ")#mi("{s}")#text(" as “velocity” and ")#mi("{z}")#text(" as “position”.) Note from ")#link(<tao-e29d3542d34ef349d62c>)[#text("(12)")]#text(" that we expect to be able to invert the relationship between ")#mi("{s}")#text(" and ")#mi("{z}")#text(" as long as ")#mi("{z}")#text(" is large (and ")#mi("{s}")#text(" is small).")

#text("To exploit this change of perspective, we think of ")#mi("{s, z, t}")#text(" as all varying by infinitesimal amounts ")#mi("{ds, dz, dt}")#text(" respectively. Using ")#link(<tao-123067cba2d3fb594e6f>)[#text("(30)")]#text(" and the total derivative formula ")#mi("{ds = s_t dt + s_z dz}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("ds = - s s_z dt + s_z dz.")]]

#text("If we hold ")#mi("{s}")#text(" fixed (i.e. ")#mi("{ds=0}")#text("), so that ")#mi("{z}")#text(" is now just a function of ")#mi("{t}")#text(", and cancel off the ")#mi("{s_z}")#text(" factor, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{dz}{dt} = s.")]]

#text("Integrating this, we see that ")#metadata(none) <tao-17ce30aee1182091ee2b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("z(t,s) = z(0,s) + ts.")]]

#text(" This, in principle, gives a way to compute ")#mi("{s(t,z)}")#text(" from ")#mi("{s(0,z)}")#text(". First, we invert the relationship ")#mi("{s=s(0,z)}")#text(" to ")#mi("{z=z(0,s)}")#text("; then we add ")#mi("{ts}")#text(" to ")#mi("{z(0,s)}")#text("; then we invert again to recover ")#mi("{s(t,z)}")#text(".")

#text("Since ")#mi("{M_t \\equiv M_0 + \\sqrt{t} G}")#text(", where ")#mi("{G}")#text(" is a GUE matrix independent of ")#mi("{M_0}")#text(", we have thus given a formula to describe the Stieltjes transform of ")#mi("{M_0 + \\sqrt{t} G}")#text(" in terms of the Stieltjes transform of ")#mi("{M_0}")#text(". This formula is a special case of a more general formula of Voiculescu for ")#emph[#text("free convolution")]#text(", with the operation of inverting the Stieltjes transform essentially being the famous ")#emph[#mi("{R}")#text("-transform")]#text(" of Voiculescu; we will discuss this more in the next section.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (58)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90c02f41607c68dc2bed941e13427d5caa05ebbef2fbcce8749d6ba70055a4a2-ba58d5187ecfe093fa29070570e91eae9d0d8a98aca2cf6ce452f53fa4647938.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43468")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2010")])]

#text("In the first sentence of the second paragraph I think the “normalized matrix” is misprinted.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/214e0ebf9feb3d960805463514880df26587ac2e3c023af691467e56c3ecfe3d-276d1a74432eee0dced33a5d4ef1aa03cbaa4b5c5ed5cca161a08cf34c66916b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jan")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43494")[#strong[#text("Jan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2010")])]

#text("Thx for the nice article and explanation!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43521")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2010")])]

#text("In the proof of Lemma 2, in the last line of text, perhaps you wanted to wrote ")#mi("j<l\\leq i")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a3f814b4ce3f9613fc9bf695a79a6f792c2f0629bc7e14d11d5840d3f7d743-309dee0d642fa87941549982d0b477a0c57d3958a1e8a9a3153402f98d832952.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ano")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43526")[#strong[#text("ano")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2010")])]

#text("Dear Prof. Tao,")

#text("Sorry for a non-mathematical question — how did you manage to make the WordPress feed show only brief excerpts for the 254a posts, but full content for the others?")#linebreak()#text(" Thanks,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9d337c6142e24c084b9a7e3831a0e03f7fc387e40f02bbe2529afb5b93023f4-624ba2e6ed33e73f8a723be5c27425534c7a9570f5c8181554d1c23f7140ddb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43552")[#strong[#text("Toby")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("Dear Prof. Tao,")

#text("In exercise #1, why the requirement that ")#mi("\\lambda>0")#text("? It seems that by constructing matrix ensembles with all negative eigenvalues, you could give a counterexample. For instance, if ")#mi("\\mu_{\\frac{1}{\\sqrt{n}}}")#text(" consists of (deterministic) point masses at ")#mi("-\\frac{1}{n},-\\frac{2}{n},\\ldots,-1")#text(" (which you could do by making ")#mi("M_n")#text(" just be a deterministic, diagonal matrix with the right things on the diagonal) then ")#mi("\\mu_{\\frac{1}{\\sqrt{n}}}")#text(" converges almost surely to a uniform measure on ")#mi("[-1,0]")#text(". But ")#mi("\\mu_{\\frac{1}{\\sqrt{n}}}(-\\infty,\\lambda)")#text(" for ")#mi("\\lambda>0")#text(" would always be 1, so this would converge to ")#mi("\\mu(-\\infty,\\lambda)")#text(" for ")#emph[#text("any")]#text(" ")#mi("\\mu")#text(" supported on ")#mi("(-\\infty,0]")#text(". Is ")#mi("\\lambda>0")#text(" a mistake, or is there some stronger meaning to Hermitian matrix ensemble that I’m missing?")

#text("Thanks,")#linebreak()#text(" Toby")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43555")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("Oops, you’re right, ")#mi("\\lambda")#text(" should be real throughout. This should be corrected now…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9d337c6142e24c084b9a7e3831a0e03f7fc387e40f02bbe2529afb5b93023f4-624ba2e6ed33e73f8a723be5c27425534c7a9570f5c8181554d1c23f7140ddb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43556")[#strong[#text("Toby")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Free probability « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43565")[#strong[#text("245A, Notes 5: Free probability « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("[…] Much as free groups are in some sense “maximally non-commutative”, freely independent random variables are about as far from being commuting as possible. For instance, if are freely independent and of expectation zero, then vanishes, but instead factors as . As a consequence, the behaviour of freely independent random variables can be quite different from the behaviour of their classically independent commuting counterparts. Nevertheless there is a remarkably strong analogy between the two types of independence, in that results which are true in the classically independent case often have an interesting analogue in the freely independent setting. For instance, the central limit theorem (Notes 2) for averages of classically independent random variables, which roughly speaking asserts that such averages become gaussian in the large limit, has an analogue for averages of freely independent variables, the free central limit theorem, which roughly speaking asserts that such averages become semicircular in the large limit. One can then use this theorem to provide yet another proof of Wigner’s semicircle law (Notes 4). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a89de2a8e5c79528fa8431477b5b1f2a780ddf84234d92293edb0c1ec8159318-ba75f78f5658a6235ba775ec2fd6fc54d6261bc3257a6976150c3b8610b0f872.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Choongbum Lee")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43634")[#strong[#text("Choongbum Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2010")])]

#text("Seems like in Lemma 2 and Exercise 3, the $n^2$ terms should be $n$.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a89de2a8e5c79528fa8431477b5b1f2a780ddf84234d92293edb0c1ec8159318-ba75f78f5658a6235ba775ec2fd6fc54d6261bc3257a6976150c3b8610b0f872.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Choongbum Lee")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43635")[#strong[#text("Choongbum Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2010")])]

#text("Oh, it’s just in Lemma 2. And in the discussion following exercise 3,")#linebreak()#text(" shouldn’t it be we can discard matrices whose Frobenius norm is ")#mi("o(n)")#text(", and the diagonal entries of ")#mi("M_n")#text(" having Frobenius norm ")#mi("O(\\sqrt{n})")#text(" ?")

#emph[#text("[Corrected, thanks. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9d337c6142e24c084b9a7e3831a0e03f7fc387e40f02bbe2529afb5b93023f4-624ba2e6ed33e73f8a723be5c27425534c7a9570f5c8181554d1c23f7140ddb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43646")[#strong[#text("Toby")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("Dear Prof. Tao,")

#text("At the beginning of this post you suggest that the space of probability measures on ")#mi("\\mathbb{R}")#text(" is ")#mi("\\sigma")#text("-compact. I set out to check this and eventually decided it was actually false. Am I mistaken? My proof works (or so I hope) by supposing you can decompose the space of measures into countably many compact (and therefore tight) sets, and then diagonalizing to produce a measure not in any of them.")

#text("Thanks,")#linebreak()#text(" Toby")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43647")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("Ah, yes, there is a slight subtlety here. The space of probability measures is not sigma-compact, but the larger space of non-negative measures with total mass at most 1 is sigma-compact (in fact it is compact) in the vague topology, basically by the Banach-Alaoglu theorem. So one can define the notions of convergence in probability, etc. in the larger space and then descend to the smaller space. (Actually, if all one wants is the definition, then sigma-compactness is not really needed; it’s only when one wants to use the definitions, e.g. to show that two different definitions are equivalent, that some regularity hypotheses on the underlying space are needed, and sigma compactness is probably overkill in most cases.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9d337c6142e24c084b9a7e3831a0e03f7fc387e40f02bbe2529afb5b93023f4-624ba2e6ed33e73f8a723be5c27425534c7a9570f5c8181554d1c23f7140ddb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43648")[#strong[#text("Toby")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("Ahh, thank you. That clears things up for me.")

#text("Toby")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8b639a43211df10c1497a6a6d581ad39edf9adcc7d7df1d2780a6d95c609aae-fb030a1c4d0a1a639c6762bfa40be0bf334c84b04ba90ea3b6ba29fdb8564b06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43654")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" You state that the Stieltjes transform “can be viewed as a generating function of the moments via the Taylor series expansion ” and that “This is somewhat (though not exactly) analogous to how the characteristic function {{\\bf E} e^{itX}} of a scalar random variable can be viewed as a generating function of the moments {{\\bf E} X^k}.”")#linebreak()#text(" Do (14) and (15) also have natural translations in terms of characteristic functions?")#linebreak()#text(" Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43656")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2010")])]

#text("I suppose the Fourier inversion formula would be the closest analogue. The analogy between the Stieltjes transform and the Fourier transform only seems to be particularly strong near infinity (where the Laurent series look very similar, except for a factor of k!); otherwise the two transforms seem rather different in nature.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeed5597923941b57f8b6628c32b825df93f93c87f5d099c69c3d39a2aab865-1f23b8cd15b3653b08bf6d1ea41ea9dbcc1dd08aecad4e897d884cd84dc0fa64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43670")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2010")])]

#text("In Exercise 2,")#linebreak()#text(" I think it is enough considering lacunary sequence of the form")#linebreak()#text(" a_n= [ a^n ], where [] is the floor function, and a>1.")#linebreak()#text(" Also, ‘it suffices to do so for a lacunary sequence ‘ should be changed to ‘it suffices to do so for every lacunary sequences’")

#emph[#text("[Thanks, I’ve reworded. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeed5597923941b57f8b6628c32b825df93f93c87f5d099c69c3d39a2aab865-1f23b8cd15b3653b08bf6d1ea41ea9dbcc1dd08aecad4e897d884cd84dc0fa64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43678")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("In Exercise6, for the last part(almost sure convergence),")#linebreak()#text(" the error term in (4) should also be $O(n^{-c_k})$ ??")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43679")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("This is not necessary; one can derive almost sure convergence without the stronger bound in (4) (although this bound is true). Consider for instance the extreme case when the error term in (4) is o(1), but the variance estimate is infinitely strong (i.e. the variance is zero).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeed5597923941b57f8b6628c32b825df93f93c87f5d099c69c3d39a2aab865-1f23b8cd15b3653b08bf6d1ea41ea9dbcc1dd08aecad4e897d884cd84dc0fa64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43682")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("I see. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0d49273a6902d73f656aaf6252e01edfa69c067c009c75f7c3231020e000cf5-7063c982cd9f41e7454975c7905a8c3429dd93f63516b4fb265f355332515577.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43709")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("Possible typo. In the preliminary reduction section for the inequalities coming from the Cauchy interlacing law, is it supposed to be m>n?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43710")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("Ah, there was a sign error; I think I’ve fixed the problem now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Gaussian ensembles « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43720")[#strong[#text("254A, Notes 6: Gaussian ensembles « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("[…] can then be solved to obtain the semi-circular law as in previous notes. Remark 4 Recall from Notes 3b that Dyson Brownian motion can be used to derive the formula (1). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0d49273a6902d73f656aaf6252e01edfa69c067c009c75f7c3231020e000cf5-7063c982cd9f41e7454975c7905a8c3429dd93f63516b4fb265f355332515577.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43806")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2010")])]

#text("I’d appreciate any help showing that pointwise convergence of ")#mi("s_{\\mu_n}")#text(" gives weak convergence of the measures. Don’t you need some sort of uniformity of ")#mi("Im(s_{\\mu_n}(\\cdot + ib)) \\rightarrow \\mu(\\cdot)")#text(" over n? Also, the hint about using (13) is very mysterious to me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43834")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("One can use (14) to control the integral of any function of the form F*P_b against mu_n with an integral of the corresponding Stieltjes transform against F. The latter can be shown to be convergent using (13).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0d49273a6902d73f656aaf6252e01edfa69c067c009c75f7c3231020e000cf5-7063c982cd9f41e7454975c7905a8c3429dd93f63516b4fb265f355332515577.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43820")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("possible typo: in the formula before (28), it should be ")#mi("s(\\lambda_j/\\sqrt{n})")#text("?")

#emph[#text("[Corrected, thanks. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-43885")[#strong[#text("254A, Notes 8: The circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("[…] the semi-circular law where this reduction follows easily from the Hoffman-Weilandt inequality (see Notes 4). Instead, we must continue working with unbounded random variables throughout the argument […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Localization of the eigenvalues and the necessity of four moments « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-45012")[#strong[#text("Random matrices: Localization of the eigenvalues and the necessity of four moments « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("[…] the vague topology) where is the semicircular distribution. (See these lecture notes on this blog for more discusssion of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-47781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2010")])]

#text("Dear Prof. Tao,")

#text("Do you plan to post on Tracy-Widom distribution (and hence somehow Airy function, Painleve II equation)?I would be great.")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1707bf3c9194bdac5671487a4413d60eda99a805670e2b6c759d86d43c3e3cd3-e5d5774ebda83023fddaf502d84963f1343ba57c0d144a9b22683696897d5674.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FP Recent Follows « YW's E-Profile")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-50546")[#strong[#text("FP Recent Follows « YW's E-Profile")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2011")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/686f7be045573526c8fedff34616c9f97a10010886a4a8d7c594b3a4fc5d4f92-28c499df4582b866e03669db46d56e14dd20271839165609157ba96d616a2508.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Gittens")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-196979")[#strong[#text("Alex Gittens")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2012")])]

#text("In (12), it looks like the denominator’s missing a negative sign, since 1/z is not Herglotz")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81ecb61929079d42bc8790edad7b4879f3de1f2c26236499b4f60f5c9aea7ef0-8b7de35906679535a0af2ceebec2e027b9f91221d047971ad3eab4a00afaaffd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luo Yongming")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-272434")[#strong[#text("Luo Yongming")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Dear Prof. Tao,")

#text("Did you use the Borel-Cantelli-inequality for the almost convergence in the Exercise 6? But to do so, i think ck should at least larger than 1. Or did you mean another approach cause i saw that the hint was “a lacunary sequence” but i couldn’t see that point. What i’ve read from the lecture notes of prob. thry is that every subsequence has a conv. subsequence almost sure iff xn converges to x in probability, but from this i also can’t derive the almost sure convergence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cdbe18cfaec59f831a526f3bdf76e5661df9d72ab3cca71132c805d5fc9f96f7-2a59d8c9e09e01dd0a46ed066bdf64312ae15d0bc257173073c2ff6f2ea8030e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Appell polynomials, cumulants, noncrossing partitions, Dyck lattice paths, and inversion | Shadows of Simplicity")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-447060")[#strong[#text("Appell polynomials, cumulants, noncrossing partitions, Dyck lattice paths, and inversion | Shadows of Simplicity")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2014")])]

#text("[…] ")#link(<tao-9cbea495990bc4b942d5>)[#text("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#more-3426")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c575332825c733d6905a4fce0b7ff0531cd11412f3728e3cd6297855ff0fbbe9-9a84a553e1fbb422dd44a6c6805aec5d5b62dbb7aaa26c8b562bdf70a8346dc1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JulianS")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-451903")[#strong[#text("JulianS")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2015")])]

#text("Dear Prof. Tao,")#linebreak()#text(" the way you phrased Exercise 6(2) it sounds like one can prove weak convergence in probability directly from the Moment Continuity Theorem? I don’t see how this can work. I am not even sure how weak convergence in probability can be phrased in terms of the characteristic functions. Any comment would be highly appreciated!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-451906")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2015")])]

#text("From the moment continuity theorem in the contrapositive, one can show that if ")#mi("X")#text(" a real subgaussian random variable, ")#mi("G")#text(" is a Gaussian variable, and one wishes to show that ")#mi("{\\bf P}(a \\leq X \\leq b) = {\\bf P}(a \\leq G \\leq b) + O(\\varepsilon)")#text(" for some ")#mi("a,b,\\varepsilon")#text(", then it suffices to show that ")#mi("{\\bf E} X^k = {\\bf G}^k + O(\\delta)")#text(" for sufficiently many ")#mi("k")#text(" (depending on ")#mi("a,b,\\varepsilon")#text(" and the subgaussian constants) and some ")#mi("\\delta")#text(" (also depending on ")#mi("a,b,\\varepsilon")#text(" and the subgaussian constants). Applying this to ")#mi("X")#text(" a randomly selected eigenvalue of ")#mi("\\frac{1}{\\sqrt{n}} M_n")#text(" gives the result.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01901599885f643a9707e9fedd90c0126fa3ed4c884d78f12b539d71c776ab8a-a7916bc83fa7ae082c391fb2e1d63cf97ac556259415a1a4a04b1e45cf143fd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kwangjun Ahn")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-470676")[#strong[#text("Kwangjun Ahn")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2016")])]

#text("Dear prof. Tao,")

#text("At the beginning of [1. Preliminary reductions ], you made an argument that it suffices to consider for a lacunary subsequnces. However, I don’t see why this is true because in your argument it appeared that you considered $\\mu (-\\infty , \\lambda/ \\sqrt{n})$ rather than $\\mu (-\\infty , \\lambda)$, which is our actual interest.")

#text("I would be grateful to hear from you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-470699")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("In the interlacing law one can replace ")#mi("\\lambda")#text(" by ")#mi("\\lambda \\sqrt{n}")#text(" and use the fact that ")#mi("\\mu(-\\infty, t)")#text(" is monotone in $t$; this lets one compare the nonlacunary sequence ")#mi("\\mu_{\\frac{1}{\\sqrt{n}} M_n}(-\\infty,\\lambda)")#text(" from above and below by two lacunary sequences (with slightly different values of ")#mi("\\lambda")#text("). One also needs to use the fact that the semicircular law is continuous to conclude.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/016dfe07ea1fc919beadb5aeec48a708d20a420f1cdd5812b2622f1e60371bf3-73f8ec156d07b6b749f793297c995ba50af1d76487f1ddbe615f905b702c5740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tornado92")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-479182")[#strong[#text("tornado92")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2017")])]

#text("I am a bit confused in the discussion following (19).")

#text("Could someone please elaborate on how ")#mi("R")#text(" has a positive definite imaginary part, and why ")#mi("R")#text(" has operator norm ")#mi("O(1)")#text("? How does this follow from the spectral theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-479256")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("The spectral theorem tells us that the Hermitian matrix ")#mi("M_{n-1}")#text(" is unitarily conjugate to a real diagonal matrix, so to establish these two claims it suffices to do so in the case that ")#mi("M_{n-1}")#text(" is a real diagonal matrix. Then the problem decouples into ")#mi("n-1")#text(" copies of the one-dimensional version of the problem, so it suffices to check the scalar case, which is then a straightforward calculation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aea7e770b8fa9d47ef83baa1b31d0d97bbfa2daff51d3c2f125e1f1180a365d3-586b77a9afa7d58fe93998cf2ff7d17550f2c415ff75def4ced0660419755e12.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Kauderer-Abrams")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-479305")[#strong[#text("Eric Kauderer-Abrams")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2017")])]

#text("Dear Prof. Tao,")

#text("In your first observation in 1. Preliminary Reductions, when you apply the Cauchy interlacing law to demonstrate that the ESD is stable in n, shouldn’t the measures be $\\mu_{\\frac{1}{\\sqrt{n}}M_n}(-\\infty, \\lambda \\sqrt{n})$ and $\\mu_{\\frac{1}{\\sqrt{m}}M_m}(-\\infty, \\lambda \\sqrt{m})$,")#linebreak()#text(" instead of $\\mu_{\\frac{1}{\\sqrt{n}}M_n}(-\\infty, \\lambda / \\sqrt{n})$ and $\\mu_{\\frac{1}{\\sqrt{m}}M_m}(-\\infty, \\lambda / \\sqrt{m})$ ?")

#text("The definition that you use for the ESD counts the number of eigenvalues less than $\\lambda / \\sqrt{n}$, so it seems that the changes described above are necessary to ensure that we are counting up to the same value for both $\\mu_{\\frac{1}{\\sqrt{n}}M_n}$ and $\\mu_{\\frac{1}{\\sqrt{m}}M_m}$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/539141c8393eb3bb85bf274049fe3a03508e31f6090bedef76ea38c01467afa7-586b77a9afa7d58fe93998cf2ff7d17550f2c415ff75def4ced0660419755e12.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Kauderer-Abrams")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-479307")[#strong[#text("Eric Kauderer-Abrams")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2017")])]

#text("Dear Prof. Tao,")

#text("In your first observation in 1. Preliminary Reductions, when you apply the Cauchy interlacing law to demonstrate that the ESD is stable in n, shouldn’t the measures be ")#mi("\\mu_{\\frac{1}{\\sqrt{n}}M_n}(-\\infty, \\lambda \\sqrt{n})")#text(" and ")#mi("\\mu_{\\frac{1}{\\sqrt{m}}M_m}(-\\infty, \\lambda \\sqrt{m})")#text(",")#linebreak()#text(" instead of ")#mi("\\mu_{\\frac{1}{\\sqrt{n}}M_n}(-\\infty, \\lambda / \\sqrt{n})")#text(" and ")#mi("\\mu_{\\frac{1}{\\sqrt{m}}M_m}(-\\infty, \\lambda / \\sqrt{m})")#text(" ?")

#text("The definition that you use for the ESD counts the number of eigenvalues less than ")#mi("\\lambda / \\sqrt{n}")#text(", so it seems that the changes described above are necessary to ensure that we are counting up to the same value for both ")#mi("\\mu_{\\frac{1}{\\sqrt{n}}M_n}")#text(" and ")#mi("\\mu_{\\frac{1}{\\sqrt{m}}M_m}")#text(".")

#emph[#text("[I believe the formulae are correct as stated. Note for instance that ")#mi("\\mu_{\\frac{1}{\\sqrt{n}} M_n}(-\\infty, \\lambda / \\sqrt{n} ) = \\mu_{M_n}(-\\infty, \\lambda)")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-479424")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2017")])]

#text("I think it’s fine; the number of eigenvalues of ")#mi("\\frac{1}{\\sqrt{n}} M_n")#text(" below ")#mi("\\lambda / \\sqrt{n}")#text(" is the same as the number of eigenvalues of ")#mi("M_n")#text(" below ")#mi("\\lambda")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-479947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("Does the Stieltjies transform proof, which uses conc. of measure, require that the matrix-entry distribution be bounded?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-479948")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("That was poorly phrased. I meant to ask, does the Stieltjes transform version of the proof of the semicircle law, in which Talagrand’s Concentration Inequality was used, assume that the entries of the random matrix have a bounded distribution? Otherwise it seems, one cannot appeal to Talagrand’s Inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-479955")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("Yes, but thanks to Exercise 5, one can reduce to the bounded distribution case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns | What's new")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-486309")[#strong[#text("Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2017")])]

#text("[…] 2 If is GUE normalised so that each entry has variance , then by the semi-circular law (see previous notes) one has (using an appropriate branch of the square root). One can then verify the self-similar […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-489461")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2017")])]

#text("I want to prove the semicircular law holds for the adjacency matrix of an Erdos Renyi graph G(n, p). The problem is its off-diagonal entries are mean p, not zero. So, I would like to subtract p times the all ones matrix, and then add back the p along the diagonal.")

#text("First, the diagonal doesn’t matter, by Exercise 3. Next, the all ones matrix is low rank, so I want to apply Exercise 4, which as written doesn’t require that the perturbation be Hermitian. But I’m suspicious because the hint for Exercise 4 says to use the Weyl inequalities, which do require Hermitian matrices.")

#text("So is Exercise 4 really true? If not, how does one finish the argument for the Erdos Renyi graph?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-489567")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("The hypothesis that ")#mi("N_n")#text(" be Hermitian (which is for instance the case in your Erdos-Renyi application) was mistakenly omitted from Exercise 4, and is now corrected.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-489573")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("Thank you! Ah, for some reason I had been thinking that the all-ones matrix was not Hermitian, so my previous comment must not have made too much sense.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90179b76cbe221badb72b1ff1405e6fb50f396238365135b85ea3d00797b2b9f-a06ed4f828a3515663ede7826c95a62be8155b9ac7f2cc042478149f15a9e515.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chen")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-509351")[#strong[#text("Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("The question is: if we can discard any portion of the matrix ")#mi("\\frac{1}{\\sqrt{n}} M_n")#text(" that has small frobenius norm, then why can we not discard any small number of entries of ")#mi("\\frac{1}{\\sqrt{n}} M_n")#text(", and repeat the process many times, so that we are left with the zero matrix? At each successive step, we only remove a matrix of small frobenius norm, so we should not change the limiting distribution. But then our starting matrix clearly is different from the zero matrix. What went wrong here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-509357")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("To get the zero matrix, you’d have to discard an o(N) portion Omega(N) times. If you write out and index all the matrices involved in a 2d array, you will see that this is a question of interchanging limits, which is not valid in general (and your example proves it false in this case)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-519534")[#strong[#text("Some news regarding the Paley graph – Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2019")]

#text("[…] with zeros on the diagonal and independent Rademacher variables on the off-diagonal. Since is a Wigner matrix, its spectrum follows a semi-circle law, and so enjoys a similar spectrum with an additional spike […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-602319")[#strong[#text("The Cauchy residue trick: spectral analysis made “easy” – Machine Learning Research Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2020")]

#text("[…] In this post, I have shown various applications of the Cauchy residue formula, for computing integrals and for the spectral analysis of matrices. I have just scratched the surface of spectral analysis, and what I presented extends to many interesting situations, for example, to more general linear operators in infinite-dimensional spaces [3], or to the analysis fo the eigenvalue distribution of random matrices (see a nice and reasonably simple derivation of the semi-circular law from Terry Tao’s blog). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-633319")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2021")])]

#text("Dear Prof Tao,")

#text("A minor notational inconsistency in this post: you sometimes write circular law when semi-circular law is intended. (For instance in the statement of Exercise 2.)")

#emph[#text("[Great, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd615c1ad2f3cee08fb57c088b6c2882a1d020541081d91e63ca3c37fe0758d3-702afc3e2224c61548b93f4d1deb9da29854f11f5e4136dc13ede1609c7f1187.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-644241")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2022")])]

#text("Dear Professor Tao,")#linebreak()#text(" If one allows the variance of the diagonal terms to be of slower order, like O(N^{-1/3}) instead of O(N^-1), would the semicircle law still hold?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-644289")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2022")])]

#text("Yes; this can basically be derived from the small-diagonal case by treating the large diagonal as an additive perturbation and using the ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Weyl eigenvalue inequalities")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6df8e89f81ab16e76a225200d42f6d14666d259d1d6d5ddede0d9b8e9b1a88b-c85b794378e5c49232c1756f358cccbcbbb198581acea9233680f8562eac31bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HH")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-678818")[#strong[#text("HH")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("Dear Prof. Tao,")#linebreak()#text(" For exercise 6 part 3, does one need c_k to be uniformly bounded away from zero over all k? I managed to prove the result via Borel-Cantelli if c_k does not depend on k, but cannot quite figure out how to deal with it when c_k is allowed to approach 0 as k-> infty. It seems that terms of the form inf_{j \\in [k]} n^{-c_j} / j! do not necessarily vanish unless there’s some additional specification on how fast (c_k)’s are allowed to tend to zero.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-678834")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("One can apply Borel-Cantelli separately for each k to obtain almost sure convergence of the k^th moments. Since the countable intersection of almost sure events is almost sure, one then almost surely gets the convergence of all the moments simultaneously.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f281e63f3435c2888eef28395c0673e191936cad26839c46373eecc09d86c969-43432b59a2f7cca1df0fd5442c1a09a7a28b1bd6563474e3ef1cce19f916a19c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cyberrosee7db6d4370")]], [#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/#comment-687713")[#strong[#text("cyberrosee7db6d4370")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2025")])]

#text("Dear Prof. Tao,")

#text("There are Isotropic/Anisotropic local laws for Wigner matrices. I have also seen many works such as The Isotropic Semicircle Law and Deformation of")#linebreak()#text("Wigner Matrices on analysis of eigenvalues of low rank deformations of the Wigner matrices. I wanted to know your suggestion on local laws for the resolvent of these low rank deformations. For instance analysis of <u,R^{-1}u> such that R = frac{(X+P)^T(X+P)}{n} – zI and P is for example Sigma_{i=1}^{k} d_i v_iv_i^* for a fixed k. For simply enough X and P rank 1, it would be dependent on cosine similarity of u and v_i squared and the value of d_i. But what about more generally?")
]
