// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/
// Converted to Typst by tao2typ: "2026-10-14T15:20:58.488640+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "AI Mathematical Olympiad – Progress Prize Competition now open", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("AI Mathematical Olympiad – Progress Prize Competition now open")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 April 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/")[#text("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The first progress prize competition for the ")#link("https://aimoprize.com/")[#text("AI Mathematical Olympiad")]#text(" has ")#link("https://www.kaggle.com/competitions/ai-mathematical-olympiad-prize/overview")[#text("now launched")]#text(". (Disclosure: I am on the ")#link("https://aimoprize.com/updates/2024-02-07-advisory-committee-announced")[#text("advisory committee")]#text(" for the prize.) This is a competition in which contestants submit an AI model which, after the submissions deadline on June 27, will be tested (on a fixed computational resource, without internet access) on a set of 50 “private” test math problems, each of which has an answer as an integer between 0 and 999. Prior to the close of submission, the models can be tested on 50 “public” test math problems (where the results of the model are public, but not the problems themselves), as well as 10 training problems that are available to all contestants. As of this time of writing, the ")#link("https://www.kaggle.com/competitions/ai-mathematical-olympiad-prize/leaderboard")[#text("leaderboard ")]#text("shows that the best-performing model has solved 4 out of 50 of the questions (a standard benchmark, Gemma 7B, had previously solved 3 out of 50). A total of $")#mi("2^{20}")#text(" ($1.048 million) has been allocated for various prizes associated to this competition. More detailed rules can be found ")#link("https://www.kaggle.com/competitions/ai-mathematical-olympiad-prize/rules")[#text("here")]#text(".")

#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dee2646de0eeac7020d185d0c64df19172f5395f9c45110795446b11108464bb-49cef1a583d90c2afde082456d00d5562f14b672bfa9e7f9127716b253855308.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vegafrank")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684644")[#strong[#text("vegafrank")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2024")])]

#text("Feel free to use this practical algorithm that shows P = NP.")

#link("https://www.scienceopen.com/document/read?vid=5e6e97ed-697f-4685-a43b-6c48e598af02")[#text("https://www.scienceopen.com/document/read?vid=5e6e97ed-697f-4685-a43b-6c48e598af02")]

#text("Good Luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684645")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2024")])]

#text("second!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2024")])]

#text("Wow")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2024")])]

#text("Wow, the taxpayer’s money is wasted again… We need to use the money to clean up the human shit on the street first…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2024")])]

#text("This is a privately funded prize; no government funds were involved in creating it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("A side question: Can anyone (who has money) fund a prize and ask a university to administer it? Are there any regulations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684689")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2024")])]

#text("Universities do often accept (and encourage) donations to endow scholarships and other prizes and awards, though they are primarily directed either at their existing students, staff, and faculty, or to student applicants to their institution, rather than to the public at large. Universities that receive public funding will likely also have many additional constraints on what they can expend their administrative resources on, but these will vary according to the laws of the country or state that the university operates in. Many prizes are instead run by non-profit foundations specifically set up to administer such prizes (or other bequests of the donors), or by academic societies (for instance, ")#link("https://www.ams.org/prizes-awards/palist.cgi")[#text("here")]#text(" are the prizes awarded by the American Mathematical Society).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684687")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2024")])]

#text("seems like overkill to mention the funding source for such ridiculous question :D")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684649")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2024")])]

#text("The issue with the LLM / transformer AI paradigm that is currently dominating the AI boom is that it doesn’t even do that well in reciting things from memory. I have asked ChatGPT / Claude etc to simply write down the proof of something classical like the Radon Nikodym theorem but it inevitably makes numerous mistakes. In principle it could have memorized the proof from many sources (including this blog) but is not able to do so.")

#text("Actually solving math problems then seems to be difficult until proof assistants can effectively be combined with LLM style AIs where they do what LLMs do for (say) Python code (iterate until something that compiles is actually generated).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2024")])]

#text("Part of the intention of this prize is to try to separate the hype around AI-assisted mathematics from the reality. Thus far it seems that off-the-shelf LLMs are able to achieve a success rate of about 5-10% on the problem sets – so certainly non-trivial, but far from outstanding. Hopefully a combination of LLMs with other tools can perform better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684680")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2024")])]

#text("Yeah I was training AI models a few weeks ago and it would make very simple mistakes. One that really stood out was saying that every compact space is a Hausdorff space and I had to correct it a few iterations before it finally stopped saying that. There’s even more mistakes it makes than that. Getting an AI chatbot to prove RN-theorem would also be difficult but not impossible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684654")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("One can follow along the state of the competition at the leaderboard in ")#link("https://www.kaggle.com/competitions/ai-mathematical-olympiad-prize/leaderboard")[#text("https://www.kaggle.com/competitions/ai-mathematical-olympiad-prize/leaderboard")]#text(" . For instance, at the time of this comment, the leading submission has managed to solve 7/50, or 14%, of the “public” test set of questions (just a day ago the best record was 5/50). Presumably at some point progress will hit a wall, but it will be interesting to see when and where that happens.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684678")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2024")])]

#text("The current leading submission has now scored 15/50, or 30%. The main advance was apparently to start aggregating together multiple LLM models, and to try to select answers that had been arrived at by several of these models.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684682")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2024")])]

#text("10 data points for training seems tiny and 50 for test also seems tiny.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2024")])]

#text("The intent here is to simulate the conditions that a human contestant in a mathematics competition would encounter. Part of the competition challenge is for the contestants to locate additional data sources with which to train on, beyond the 10 problems provided, and to avoid overfitting their models on that training data. For instance, there are several databases of thousands of mathematics competition problems listed at ")#link("https://aimoprize.com/updates/2024-02-19-resources.md")[#text("https://aimoprize.com/updates/2024-02-19-resources.md")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2024")])]

#text("This 60 data points are not for training but for testing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684708")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2024")])]

#text("Interesting to follow this. Reminded me of following the ‘race’ to improve Zhang’s constant after the bounded gaps proof where the evolution also was very rapid with new improvements every day. Math can be a interesting sport sometimes:) However, now it seem we have reached (the first) plateau you expected where the top 100 entries all have 32-34% with no change in a weeks time. Looks like a new idea is needed to go further…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2024")])]

#text("Actually this is intended to mimic recreating the AlexNet moment (")#link("https://en.wikipedia.org/wiki/AlexNet")[#text("https://en.wikipedia.org/wiki/AlexNet")]#text(").")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684723")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2024")])]

#text("The situations may be similar but it is meaningless to say the experiments ")#strong[#text("intend")]#text(" to come to those situations.")

#text("Scientific experiments are meant to draw conclusions not to satisfy anyone’s need at any moment.")

#text("T.N.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684655")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("professor Tao please tell us about: MARTON’S CONJECTURE IN ABELIAN GROUPS WITH BOUNDED TORSION")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684657")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("I am following this closely, and am reading about machine assisted mathematics. I just finished reading this: ")#link("https://terrytao.files.wordpress.com/2024/03/machine-assisted-proof-notices.pdf")[#text("https://terrytao.files.wordpress.com/2024/03/machine-assisted-proof-notices.pdf")]#text(". Curious to know if you’re at all worried about AI making mathematicians obsolete. I am in undergrad and I wish to have a career in research math. Maybe it’s because I’m not knowledgeable enough in the field of math or AI yet, but I do worry about being made obsolete by a machine before I can make a meaningful contribution to the field at all. What do you think, Professor Tao?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("My personal feeling is that while specific mathematical *practices* may become obsolete (or transform beyond current recognition) by these new technologies, the *profession* of a mathematician will not itself become obsolete, though one’s workflow may well change significantly.")

#text("When I was a graduate student, I routinely had to visit the library to find out the latest developments in my field, photocopy articles, and in some cases laboriously translate them from other languages. To get an offprint from another author, I would often have to send a postcard request. The more senior faculty still handed over handwritten documents to typists in order to have them professionally typeset. These are all obsolete practices now; but we changed our workflows (largely for the better), and still continue to do mathematics.")

#text("With AI and other new technologies, I believe we will be able to write and formalize math much more efficiently, locate and understand relevant literature at far greater scales, create mathematical code with far less programming experience, collaborate in broader and more novel ways, and have some of the more routine calculations automated. Our workflow will increasingly involve conversations with AI assistants, somewhat similarly to how much of current workflow involves interactions with search engines and the like. But it will still be mathematics.")

#text("Back in 2000, Timothy Gowers wrote (in an anthology of “Visions of Mathematics”) about how he envisioned mathematicians would work “in two to three decades’ time”, by a conversation with an expert AI. I have some screenshots of his article at ")#link("https://mathstodon.xyz/@tao/110084623890144657")[#text("https://mathstodon.xyz/@tao/110084623890144657")]#text(" , together with a simulated such conversation generated by GPT-4 for comparison. I found it to be an interesting contrast.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684658")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("Where are the interfaces to the submissions defined?")

#emph[#text("[Dataset descriptions are at ")#link("https://www.kaggle.com/competitions/ai-mathematical-olympiad-prize/data")[#text("https://www.kaggle.com/competitions/ai-mathematical-olympiad-prize/data")]#text(" , although one needs to join the competition and agree to its terms to be able to download the files. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684725")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2024")])]

#text("Dr Tao,")

#text("Do you have any speculations on the winning or best performing algorithms? Such as LLM + Lean or some other high level combinations of existing machinery?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-684753")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2024")])]

#text("When do you think you would be ready to put an AI coauthor to your papers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/02/ai-mathematical-olympiad-progress-prize-competition-now-open/#comment-685422")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2024")])]

#text("Now that the competition is over, do you have any thoughts about AI progress in math?")
]
