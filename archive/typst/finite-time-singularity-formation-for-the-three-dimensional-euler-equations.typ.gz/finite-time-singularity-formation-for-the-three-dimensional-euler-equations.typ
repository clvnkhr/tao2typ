// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/
// Converted to Typst by tao2typ: "2026-11-25T17:29:07.955174+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finite-Time Singularity Formation for the Three-Dimensional Euler Equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finite-Time Singularity Formation for the Three-Dimensional Euler Equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/")[#text("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-25 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[This is a guest post by ")#link("https://web.math.princeton.edu/~mc3498")[#text("Matei P. Coiculescu")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("The Euler equations model the motion of an inviscid fluid: fluid motion in the absence of shear stresses arising from fluid particles “sliding past” each other. In an ideal fluid the dynamics are time-reversible since the arrow of time in a real, viscous fluid is determined by the loss of kinetic energy due to the internal friction of the fluid. We also make the distinction of working with the incompressible Euler equations, where the fluid density is assumed to be constant throughout the fluid. Even with all of these assumptions away from the true behavior of fluid motion, the incompressible Euler equations remain useful in modeling, for instance, the amount of lift generated by an airfoil.")

#text("We can also choose to work with a fluid that occupies a so-called “periodic box”, or a cube with the sides identified. Henceforth we will let this box be")

#align(center)[#tao-fit-display[#mitex("\\mathbb{T}^3:=[-1/2,1/2]^3")]]

#text("with opposite faces identified. This is an assumption often used in numerical simulations of the Euler equations, where it is easier to consider periodic boundary conditions in space rather than deal with the behavior of the fluid at infinity (computers don’t seem to like infinity). We also assume that the fluid is a continuum rather than a collection of particles, to allow for analysis to be performed. The derivation of the Euler equations relies only on Newton’s second law (the conservation of momentum) and the principle of conservation of mass. The former requires the inertial stresses of the fluid to be balanced and leads to the following system of partial differential equations for the velocity of the fluid ")#mi("{u(x,t)}")#text(" and the pressure of the fluid ")#mi("{p(x,t)}")#text(":")

#metadata(none) <tao-0727d7e61a28b6facf1b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_t u + u\\cdot\\nabla u +\\nabla p =0.")]]

#text("The latter requires the following constraint on the motion, which is often called the incompressibility constraint:")

#metadata(none) <tao-9e588883a8caf8bd1ec0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\textrm{div } u=0.")]]

#text("Taken together, we solve for four unknown functions, the components of ")#mi("{u}")#text(" and the scalar valued ")#mi("{p}")#text(", that jointly solve four equations (three from Equation ")#link(<tao-0727d7e61a28b6facf1b>)[#text("(1)")]#text(" and one from Equation ")#link(<tao-9e588883a8caf8bd1ec0>)[#text("(2)")]#text("). Since only one derivative of the velocity is needed to make sense of the equations in the point-wise sense, we say that solutions in ")#mi("{C^{1,\\alpha}}")#text(" are classical. Otherwise, we refer to smooth solutions when dealing in the ")#mi("{C^\\infty}")#text(" class. We note one useful interpretation of the pressure in Equation ")#link(<tao-0727d7e61a28b6facf1b>)[#text("(1)")]#text(": the term ")#mi("{\\nabla p}")#text(" acts as the Lagrange multiplier for the incompressibility constraint.")

#text("The main difficulties of analyzing the incompressible Euler equations lie in their nonlinearity and in their nonlocality. We say that the Euler equations are nonlinear due to the presence of the term ")#mi("{u\\cdot\\nabla u}")#text(" in Equation ")#link(<tao-0727d7e61a28b6facf1b>)[#text("(1)")]#text(", which means that the superposition of two known solutions of the equations is no longer also a solution. In practice, this means that complicated dynamics can occur between, for example, fine-scale eddies and a coarse-scale large vortex that they together lie in. We say that the Euler equations are nonlocal due to the pressure term. Mathematically, we solve for the pressure in terms of the velocity in the following way. If we take the divergence of Equation ")#link(<tao-0727d7e61a28b6facf1b>)[#text("(1)")]#text(" and use the incompressibility constraint, we get:")

#align(center)[#tao-fit-display[#mitex("-\\Delta p = \\textrm{div}^2(u\\otimes u).")]]

#text("Solving for ")#mi("{p}")#text(" means inverting the Laplacian operator, which leads to the use of the Fourier multiplier ")#mi("{(-\\Delta)^{-1}}")#text(", a nonlocal operator. In practice this means that even two blobs of moving fluid located far apart from one another interact on each other through their pressures. This “action at a distance” is why we call the equations non-local.")

#text("We now provide a brief (and heavily truncated) history of the Euler equations with relation to the blowup question. Leonhard Euler derived the system from first principles in [1], a work dating from 1757. In 1925, Lichtenstein proved local-in-time existence of classical solutions to the three-dimensional Euler equations [2], which was followed by Günther’s similar work in 1926 [3]. Then in 1933, Wolibner proved the global-in-time existence for classical solutions of the Euler equations in two-dimensions [4]. Lars Onsager proposed in his 1949 work [5] that solutions of the Euler equations that are not smooth (if you like, “turbulent” solutions) can lose kinetic energy even in the absence of viscosity. This served as the first motivation for studying such “weak” solutions of the Euler equations as well as suggesting the question whether initially smooth solutions can reach such a state in finite-time. In 1966, Arnold proposed a geometric interpretation of solutions of the Euler equations as the geodesic flow in the infinite-dimensional space of fluid particle configurations (the space of volume preserving diffeomorphisms) [6]. Shortly after, Ebin and Marsden proved the local-in-time existence of solutions from smooth data (equivalently, the existence of a geodesic normal neighborhood around the identity diffeomorphism) in [7]. In the same paper from 1970, Ebin and Marsden posed the question whether geodesics can be extended indefinitely, which is equivalent to the global-in-time regularity question for the Euler equations. In 1980, Morf, Orszag, and Frisch provided the first numerical evidence that singularity formation can occur for the three-dimensional Euler equations in a periodic box [8].")

#text("The modern history of the singularity question begins with the 1989 work of DiPerna and Lions in [10], where the first example of norm growth for the three-dimensional Euler equations is given. Bourgain and Li used these ideas to show ill-posedness of the Euler equations in two-dimensions in their 2015 work [11]. Elgindi proved singularity formation for classical ")#mi("{C^{1,\\alpha}}")#text(" solutions by use of a self-similar ansatz in 2021 [12]. In 2025, Córdoba, Martínez-Zoroa, and Zheng expanded on the ideas of DiPerna-Lions-Bourgain-Li to prove finite-time singularity formation for classical solutions of the three-dimensional Euler equations with finite kinetic energy and velocity smooth away from the origin [13]. Lastly, in joint work [14] with Levent Alpöge and Tristan Buckmaster, we prove finite-time singularity formation for smooth solutions of the Euler equations on ")#mi("{\\mathbb{T}^3}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" There is an odd divergence-free ")#mi("{u_0\\in C^\\infty(\\mathbb{T}^3;\\mathbb{R}^3)}")#text(" whose maximal classical solution ")#mi("{u}")#text(" of ")#link(<tao-0727d7e61a28b6facf1b>)[#text("(1)")]#text("—")#link(<tao-9e588883a8caf8bd1ec0>)[#text("(2)")]#text(" is smooth and odd on ")#mi("{\\mathbb{T}^3\\times[0,T_*)}")#text(" for a finite ")#mi("{T_*>0}")#text(", and satisfies")

#align(center)[#tao-fit-display[#tao-math("\\int_0^{T_*}\\left\\|\\nabla u(t)\\right\\|_{L^\\infty}\\,\\mathrm{d}t=\\infty, \\qquad \\int_0^{T_*}\\left\\|\\nabla\\times u(t)\\right\\|_{L^\\infty}\\,\\mathrm{d}t=\\infty.", block: true)]]

#text("Moreover,")

#align(center)[#tao-fit-display[#tao-math("\\sup_{0\\le t<T_*}\\left\\|u(t)\\right\\|_{L^\\infty}<\\infty, \\qquad \\lim_{t\\uparrow T_*}\\left|\\nabla\\times u(t,0)\\right|=\\infty.", block: true)]]

#text("For every compact ")#mi("{K\\subset\\mathbb{T}^3\\setminus\\{0\\}}")#text(" and every integer ")#mi("{m\\ge0}")#text(", both ")#mi("{u(t)}")#text(" and ")#mi("{\\partial_tu(t)}")#text(" converge in ")#mi("{C^m(K)}")#text(" as ")#mi("{t\\uparrow T_*}")#text(".")
]

#metadata(none) <tao-02df8187493116d482cc>

#text("The rest of this post will focus on giving the basic building block of, as well as the three key ideas behind, the proof, which is a “multiscale” construction. In other words, we build a solution that solves the Euler equations that is essentially an infinite sum of increasingly smaller “building blocks” that we can tune to behave in prescribed ways. The building blocks for our construction are the so-called")

#heading(level: 1)[#strong[#text(" — 1. Craik-Criminale Flows — ")]]

#text("Let ")#mi("{D(t)}")#text(" be a time-dependent ")#mi("{3\\times 3}")#text(" matrix and suppose that ")#mi("{D(t)}")#text(" is always trace-free and that ")#mi("{D^{\\prime}(t) +D(t)^2}")#text(" is a symmetric matrix. It is not too difficult to see that ")#mi("{D(t)x}")#text(" is, with these assumptions, an exact solution of the Euler equations in ")#mi("{\\mathbb{R}^3}")#text(". Craik and Criminale found in their work in [9] that one may carefully add an oscillatory perturbation of the form")

#align(center)[#tao-fit-display[#mitex("w(x,t) = \\mathbf{a}(t) F(k(t)\\cdot x),")]]

#text("where ")#mi("{\\mathbf{a}(t)\\cdot k(t)=0}")#text(" for all times ")#mi("{t}")#text(" and ")#mi("{F(s)}")#text(" is a smooth, odd, ")#mi("{1}")#text("-periodic scalar-valued function, and ")#mi("{D(t)x +w(x,t)}")#text(" remains a solution of the Euler equations. For the sum to remain a solution of the Euler equations we require that ")#mi("{k(t)}")#text(" and ")#mi("{{\\mathbf{a}}(t)}")#text(" solve the following system of ordinary differential equations:")

#metadata(none) <tao-3ae644cde993fbb2aa3b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("k^{\\prime} = -D^Tk, \\quad {\\mathbf{a}}^{\\prime} = -D{\\mathbf{a}}+p_w k, \\quad p_w = \\frac{2k\\cdot D{\\mathbf{a}}}{\\left|k\\right|^2}.", block: true)]]

#text("We call this the Craik-Criminale system. The choice of ")#mi("{p_w}")#text(" is such that ")#mi("{k}")#text(" and ")#mi("{{\\mathbf{a}}}")#text(" remain orthogonal throughout their evolution. We call these Craik-Criminale solutions of the Euler equations. The vector ")#mi("{k(t)}")#text(" is called the “wave vector” and determines in what direction the oscillations of the perturbation occur. The magnitude ")#tao-math("{\\left|k\\right|}", block: false)#text(" determines the frequency of the perturbation. The vector ")#mi("{{\\mathbf{a}}}")#text(" is called the amplitude vector and determines the size and direction of the perturbation in space. We always normalize the profile ")#mi("{F}")#text(" of the oscillatory wave so that ")#mi("{F^{\\prime}(0)=1}")#text(", which gives us ")#mi("{\\nabla w(0,t) = {\\mathbf{a}}\\otimes k}")#text(". In particular, the Craik-Criminale solution permits us to add a particular strain at the origin through the newly added oscillatory perturbation ")#mi("{w}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. The Craik-Criminale System and a Multiscale Ansatz — ")]]

#text("The first key idea is to have a good ansatz for amplification due to shearing at the origin. A good ansatz should not only create growth but also be self-replicating. It turns out the Craik-Criminale flows are excellent building blocks for such an ansatz.")

#text("Since we have a multiscale construction, we expect to add another oscillatory perturbation to what we already have above. Due to the separation of scales, the effect of the previously added coarser scales is essentially only the shearing at the origin. Suppose we have some background flow ")#mi("{B}")#text(", and a previously added wave perturbation with wave vector ")#mi("{k_p}")#text(" and amplitude vector ")#mi("{{\\mathbf{a}}_p}")#text(". The velocity gradient at the origin, as we previously observed will be some matrix ")#mi("{D(t) = B + \\mathbf{a}_p \\otimes k_p}")#text(". Let us now add a new perturbation with wave vector ")#mi("{k}")#text(" and amplitude vector ")#mi("{{\\mathbf{a}}}")#text(". We want to see how the directions and sizes of ")#mi("{k}")#text(" and ")#mi("{{\\mathbf{a}}}")#text(" change as they evolve under the shearing of the previous background and wave, and an efficient way of seeing this is to use the previous wave perturbation as an orthonormal frame. In particular, we can let")

#align(center)[#tao-fit-display[#tao-math("E_1 = \\frac{k_p}{\\left|k_p\\right|}, \\quad E_2 = \\frac{\\mathbf{a}_p}{\\left|\\mathbf{a}_p\\right|}, \\quad E_3 = E_1\\times E_2, \\quad \\sigma:= \\left|\\mathbf{a}_p\\right||k_p|.", block: true)]]

#text("Here ")#mi("{\\sigma}")#text(" denotes the strength of the shearing due to the previous wave. We can also assume that the older background ")#mi("{B}")#text(" has only two nonzero entries in the moving frame:")

#align(center)[#tao-fit-display[#mitex("E_1\\cdot BE_2 := \\nu >0, \\quad E_3 \\cdot BE_2=\\eta >0.")]]

#text("This is an assumption we can precisely set up (the other entries of the gradient will be small errors in the iteration) at the start of our iterative construction and prove holds true as the construction proceeds in stages. We also assume that the “coupling ratio” ")#mi("{\\epsilon := \\eta/\\nu \\ll 1}")#text(" and define ")#mi("{\\varphi}")#text(" to be the angle that ")#mi("{k}")#text(" makes from ")#mi("{E_3}")#text(" towards ")#mi("{E_1}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\tan\\varphi = \\frac{k\\cdot E_1}{k\\cdot E_3}.")]]

#text("Now if we consider the evolution of the new vectors ")#mi("{k}")#text(" and ")#mi("{\\mathbf{a}}")#text(" by the Craik-Criminale system Equation ")#link(<tao-3ae644cde993fbb2aa3b>)[#text("(3)")]#text(" in the background flow given by ")#mi("{D(t)}")#text(", we see that at least initially, at ")#mi("{t=0}")#text(", we have that the new amplitude vector coefficients evolve by")

#metadata(none) <tao-123c69fe3b63c824aebf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("a_1^{\\prime} = -2\\nu a_2, \\quad a_2^{\\prime} = -(\\sigma-\\nu)a_1.")]]

#text("When ")#mi("{\\sigma\\gg \\nu}")#text(", if we choose the initial direction of the new amplitude vector ")#mi("{a}")#text(" to be along ")#mi("{E_2 -\\sqrt{2\\nu/\\sigma}E_1}")#text(", it will initially grow at the rate ")#mi("{e^{\\sqrt{2\\nu(\\sigma-\\nu)}}}")#text(" as for the linear system in Equation ")#link(<tao-123c69fe3b63c824aebf>)[#text("(4)")]#text(". The coefficient ")#mi("{\\eta}")#text(" makes ")#mi("{k}")#text(" tilt toward ")#mi("{-E_2}")#text(" and the shearing continues this tilting into the ")#mi("{E_1}")#text(" direction, so if we start the new wave vector ")#mi("{k}")#text(" approximately parallel to ")#mi("{E_3}")#text(", we then see ")#mi("{\\varphi}")#text(" turn from ")#mi("{0}")#text(" to ")#mi("{\\pi/2}")#text(". On the other hand, the new amplitude vector evolves by equations that depart from the linear system with frozen coefficients in Equation ")#link(<tao-123c69fe3b63c824aebf>)[#text("(4)")]#text(". In particular, the pressure from the newly added perturbative wave introduces a prefactor of roughly the size ")#mi("{\\cos^2\\varphi(1-\\epsilon\\tan\\varphi)}")#text(" to the coefficient ")#mi("{2\\nu}")#text(" in the equation for ")#mi("{a_1}")#text(". Thus, once ")#mi("{\\varphi}")#text(" has turned enough so that ")#mi("{\\tan\\varphi \\geq 1/\\epsilon}")#text(", the growth of the amplitude more or less ends in this model. In the meantime, the newly added amplitude vector has grown by a factor of about ")#mi("{\\exp(\\epsilon^{-1/2})}")#text(" until this peak amplitude gain.")

#text("Let ")#tao-math("{\\sigma_+ := \\left|k\\right|\\left|\\mathbf{a}\\right|}", block: false)#text(", and let ")#mi("{E_{i,+}}")#text(" be the orthonormal moving frame according to the newly added wave with vectors ")#mi("{k}")#text(" and ")#mi("{\\mathbf{a}}")#text(". In order to iterate the construction, we not only require the new shear ")#mi("{\\sigma_+}")#text(" to be large but also that the orientation of the frame is correct in the sense that the old, now background gradient ")#mi("{D}")#text(", expressed in the frame of the new wave, maintains the following positive coefficients of the velocity gradient:")

#align(center)[#tao-fit-display[#mitex("\\nu_+ := E_{1,+}\\cdot DE_{2,+}>0, \\quad \\eta_+ := E_{3,+}\\cdot DE_{2,+}>0.")]]

#text("If we also have ")#mi("{\\epsilon_+:= \\eta_+/\\nu_+ \\ll 1,}")#text(" we then have all the ingredients to add yet another wave perturbation on top of what we already have. The turning of ")#mi("{\\varphi}")#text(" described in the previous paragraph permits ")#mi("{\\epsilon_+}")#text(" to reach a prescribed value (less than ")#mi("{\\epsilon}")#text(" from the previous background) after the time of peak amplitude gain for ")#mi("{{\\mathbf{a}}}")#text(" while the new shearing ")#mi("{\\sigma_+}")#text(" still remains large. The initial case of the iterative construction begins with the stationary shear flow")

#align(center)[#tao-fit-display[#mitex("\\sin(2\\pi x_2)(e_1+\\rho e_3),")]]

#text("where ")#mi("{e_i}")#text(" are the coordinate vectors of ")#mi("{\\mathbb{T}^3}")#text(" and ")#mi("{\\rho>0}")#text(" is some small constant that gives the first “coupling ratio”.")

#image("../assets/2e5b363ef669a9eb4a6636771f87f595c01b516fce7f24aae42bf5c011f0293c-b070bfac93e3f77bda44fb54e7090876b1614dde30a2f1235f3f0e2826e02c1c.gif", width: 90%)

#heading(level: 1)[#strong[#text(" — 3. Prescribing Initial Data by a Boundary Value Problem — ")]]

#text("The multiscale ansatz described above is only an approximate solution to the Euler equations, and our goal is to prove finite-time singularity formation for the Euler equations without a force. To correct the approximate solution into an exact solution, we use the freedom left us of choosing the initial data from which we evolve. Another issue resolved by this decision is that we avoid interference from the exponential growth already present in the ansatz itself.")

#text("Suppose ")#mi("{u,p}")#text(" approximately solve the Euler equations with residual ")#mi("{R= \\partial_t u +u\\cdot\\nabla u + \\nabla p}")#text(" and let ")#mi("{X(a,t)}")#text(" be the flowmap of ")#mi("{u}")#text(" (the position at time ")#mi("{t}")#text(" of the particle starting at position ")#mi("{a}")#text(" under the flow of ")#mi("{u}")#text("). We therefore have")

#align(center)[#tao-fit-display[#mitex("\\partial_t X(a,t) = u(X(a,t),t), \\quad X(a,0)=a.")]]

#text("Suppose ")#mi("{b}")#text(" is the correction of ")#mi("{u}")#text(" to an exact solution of the Euler equations to first order, then ")#mi("{b}")#text(" solves the Euler equations linearized around ")#mi("{u}")#text(" with some source ")#mi("{f}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\partial_t b + u\\cdot\\nabla b + b\\cdot\\nabla u + \\nabla q = f, \\quad \\textrm{div } b=0.")]]

#text("If we let ")#mi("{\\xi}")#text(" be the first-order change in particle positions due to the correction term ")#mi("{b}")#text(", then we have")

#metadata(none) <tao-21fba8de533a97c69890>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\partial_t \\xi(a,t) = b(X(a,t),t) + \\nabla u(X(a,t),t)\\xi(a,t), \\quad \\xi(a,0)=0.")]]

#text("If we differentiate Equation ")#link(<tao-21fba8de533a97c69890>)[#text("(5)")]#text(" in time and use that ")#mi("{b}")#text(" solves the linearized problem, we get the following boundary value problem for ")#mi("{\\xi}")#text(":")

#metadata(none) <tao-84747dcd831c7131207a>

#tao-aligned(keep: true)[


#tao-math("\\xi_{tt} +H^\\sharp\\xi + (\\nabla q)\\circ X  & = f\\circ X, \\quad H^\\sharp=(D^2_x p-\\nabla R)\\circ X,", block: true, numbering: n => [#text("(6)")])



#tao-math("\\textrm{div}_x(\\xi\\circ X^{-1}) & =0, \\quad \\xi(0)=\\xi(T)=0.", block: true)
]

#text("The boundary values are due to our desire for the particle positions to match those of the approximate solution up to second-order terms. Equation ")#link(<tao-21fba8de533a97c69890>)[#text("(5)")]#text(" shows that knowledge of ")#mi("{\\xi_t}")#text(" and ")#mi("{\\xi}")#text(" suffice to obtain the first-order corrector ")#mi("{b}")#text(". If we test Equation ")#link(<tao-84747dcd831c7131207a>)[#text("(6)")]#text(" with ")#mi("{-\\xi}")#text(" and integrate by parts (using the incompressibility constraint), we get")

#metadata(none) <tao-c91b619b7b8c208607ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\underbrace{\\int_0^T\\!\\int_{\\mathbb{T}^3} \\big{\\left(\\left|\\xi_t\\right|^2-\\xi\\cdot H^\\sharp\\xi\\right)}\\,\\mathrm{d}a\\,\\mathrm{d}t} _{\\mathcal{Q}(\\xi)} =-\\int_0^T\\!\\int_{\\mathbb{T}^3} (f\\circ X)\\cdot\\xi\\,\\mathrm{d}a\\,\\mathrm{d}t.", block: true)]]

#text("If ")#mi("{H^\\sharp\\leq \\textrm{Id}}")#text(" and ")#mi("{T\\leq 1}")#text(", then ")#mi("{\\mathcal{Q}}")#text(" is a coercive operator and the boundary value problem is solvable. All this is tantamount to constructing a Jacobi field along an “approximate geodesic” in the infinite-dimensional configuration space of Arnold’s formulation of the Euler equations. Our building blocks are carefully tuned at every step so that ")#mi("{H^\\sharp\\leq \\textrm{Id}}")#text(" always in any application of this idea. The key is providing a uniform upper bound on the hessian of the pressure, which provides the coercivity. The upper bound on the pressure hessian is hardly generic: it is a consequence of carefully choosing the profile ")#mi("{F}")#text(" at the wave perturbation at each step. For instance, the profile ")#mi("{F(s) = \\sin(2\\pi s)}")#text(" would not work.")

#image("../assets/56e4cf8a9a4ed31bb23b390f9243f4a81826d73cf19246428fb11f53231ea93e-e2fbacf4acd0ade890d77551ddb1fc705e02524b400728894dafafaa171b8834.png", width: 90%)

#heading(level: 1)[#strong[#text(" — 4. Correcting the Approximate Solution — ")]]

#text("The iterative construction described in the ansatz uses Craik-Criminale waves, which are oscillatory perturbations of affine solutions to the Euler equations in ")#mi("{\\mathbb{R}^3}")#text(" (hence not in ")#mi("{\\mathbb{T}^3}")#text("). We have to localize the ansatz in space (we multiply each wave by a smooth cutoff function supported in the interior of the fundamental box of the torus in Lagrangian coordinates) and, for technical reasons, we perform a mollification of the velocity at each step of the construction by truncating in frequency as well. We also multiply the ansatz by a cutoff function in time so that we do not see any perturbation wave until it begins to be amplified. These cutoffs introduce errors that have to be corrected in addition to the various errors introduced in the simplifying assumptions of the ansatz. For this portion of the post, ")#mi("{U}")#text(" denotes the truncated velocity to which we wish to add a perturbation wave and still get a solution of the Euler equations with very small residual.")

#text("The phase ")#mi("{\\theta}")#text(" of the localized perturbation wave is defined by")

#align(center)[#tao-fit-display[#mitex("\\theta(X(a,t), t) = k\\cdot a,")]]

#text("in other words we transport the phase of what the linear flow would be, ")#mi("{k\\cdot x}")#text(", by the flow of the truncated velocity ")#mi("{U}")#text(". We let ")#mi("{\\kappa = \\nabla_x \\theta}")#text(", which is the wave vector of the newly added localized wave. As in the discussion of the ansatz, we choose ")#mi("{k}")#text(" so that ")#mi("{\\kappa}")#text(" initially lies perpendicular to the wave vector and amplitude vector of the previous step and we also choose ")#mi("{k}")#text(" to have size ")#mi("{\\lambda}")#text(", which we should imagine to be large. The velocity we add to ")#mi("{U}")#text(" is of the form")

#align(center)[#tao-fit-display[#mitex("C_{P+1}+\\sum_{p=1}^P (V_p+C_p+B_p),")]]

#text("where each ")#mi("{V_p}")#text(" is a highly oscillatory wave with zero average and with direction vector perpendicular to ")#mi("{\\kappa}")#text(". The vector ")#mi("{V_1}")#text(" is the next wave we want to add, while the others serve as highly oscillatory correctors to get a small residual and a good approximate solution. Then ")#mi("{C_{p+1}}")#text(" is the correction of ")#mi("{V_p}")#text(" that makes ")#mi("{V_p+C_{p+1}}")#text(" divergence free. Lastly, ")#mi("{B_p}")#text(" is the correction of the “mean” part, which cannot be handled by the highly oscillatory ")#mi("{V_p}")#text("‘s. Evidently, ")#mi("{C_1=0}")#text(" since there is no ")#mi("{V_0}")#text(" whose divergence we need to correct and ")#mi("{B_1=0}")#text(" for similar reasons. We should consider this type of correction as a WKB expansion, where at each ")#emph[#text("level")]#text(" ")#mi("{p}")#text(", the term ")#mi("{V_p+C_p+B_p}")#text(" is of size about ")#mi("{\\lambda^{-2p/3}}")#text(".")

#image("../assets/e3a0ca10fa0bd84c16b7d11259bfd872b523310929a6ea2027797e2f21b72cce-55f309d4abffb2381c5b9e43f55df98f25999e0fc294ec2dad502c238611b2a2.png", width: 90%)

#text("Let us consider the error left over after adding the new wave ")#mi("{V_1}")#text(" and its divergence correction ")#mi("{C_2}")#text(": this is a function ")#mi("{H_2}")#text(" at level ")#mi("{2}")#text(" and we perform corrections on its mean ")#mi("{\\langle H_2\\rangle}")#text(" and its oscillatory part ")#mi("{H_2 - \\langle H_2 \\rangle}")#text(". We first construct ")#mi("{B_2}")#text(" that cancels the average of ")#mi("{H_2}")#text(" as well as the residual of the parent field ")#mi("{U}")#text(". This means that ")#mi("{B_2}")#text(" solves the Euler equations linearized around ")#mi("{U}")#text(" with a forcing coming from ")#mi("{\\langle H_2\\rangle}")#text(" and the residual of ")#mi("{U}")#text(", and the associated boundary-value problem discussed in the previous section selects the data ")#mi("{B_2(0)}")#text(" that permits this cancellation (note that by induction, the parent ")#mi("{U}")#text(" already satisfies the coercivity constraint required). Now in constructing ")#mi("{V_2}")#text(", we observe that ")#mi("{B_2}")#text(" advects the newly added wave ")#mi("{V_1}")#text(", so we need to choose ")#mi("{V_2}")#text(" solving the Euler equations linearized around ")#mi("{U}")#text(" with forcing coming from the oscillatory part ")#mi("{H_2-\\langle H_2\\rangle}")#text(" and the term ")#mi("{B_2\\cdot\\nabla V_1}")#text(", which, like ")#mi("{H_2-\\langle H_2\\rangle}")#text(", is also of zero average and belongs to level ")#mi("{2}")#text(". We then add the divergence correction ")#mi("{C_3}")#text(" of ")#mi("{V_2}")#text(", and ")#mi("{C_3}")#text(" lies at level ")#mi("{3}")#text(", and iterate the procedure, continuing until some level ")#mi("{P}")#text(" where ")#mi("{\\lambda^{-2P/3}}")#text(", the size of the remainder, is small enough. We may then truncate the resulting vector field in space and frequency to get an appropriate parent for the next iteration.")

#text("Continuing in this way, we construct a sequence of smooth approximate solution of the Euler equations whose residuals tend to zero in every spatial ")#mi("{C^m}")#text(" norm, uniformly on compact time intervals. On the other hand, we are guaranteed an amplification mechanism that makes the gradient of the velocity at the origin increasingly larger in the sequence. Therefore, taking the limit, we construct a smooth data from which a finite-time singularity emerges.")

#heading(level: 1)[#strong[#text(" — 5. Physical Intuition — ")]]

#text("We end this blog post with a short remark on the physical intuition behind this construction. In recent months, there has been an incredible success in constructing similar multiscale solutions that exhibit either finite-time singularity formation or spontaneous non-uniqueness. For finite-time singularity constructions, we should imagine that a proof requires a mechanism for transfer of energy from coarser scales to finer scales, permitting concentration of energy and blowup. We should imagine, perhaps like Onsager, that this is related to turbulence, where many small-scale eddies form. On the other hand, the non-uniqueness constructions require a mechanism for transmitting energy from finer scales to coarser scales, and this is reminiscent of many finer eddies dissipating and giving way to a single large vortex, for example. We would also like to point out that the proliferation of LLM tools has allowed for a rapid progress in the field, by providing quite welcome assistance in these highly technical proofs.")

#emph[#text("Notate bene, puristae:")]#linebreak()#text(" The written content of this blog post was created without any AI assistance. The figures and animation were generated by Codex.")

#strong[#text("References")]

#text("[1] L. Euler, ")#emph[#text("Principes généraux du mouvement des fluides")]#text(", Mémoires de l’Académie des sciences de Berlin ")#strong[#text("11")]#text(" (volume for 1755, published 1757), 274–315.")

#text("[2] L. Lichtenstein, ")#emph[#text("Über einige Existenzprobleme der Hydrodynamik homogener, unzusammendrückbarer, reibungsloser Flüssigkeiten und die Helmholtzschen Wirbelsätze")]#text(", Math. Z. ")#strong[#text("23")]#text(" (1925), 89–154.")

#text("[3] N. M. Günther, ")#emph[#text("Über ein Hauptproblem der Hydrodynamik")]#text(", Math. Z. ")#strong[#text("24")]#text(" (1926), 448–499.")

#text("[4] W. Wolibner, ")#emph[#text("Un théorème sur l’existence du mouvement plan d’un fluide parfait, homogène, incompressible, pendant un temps infiniment long")]#text(", Math. Z. ")#strong[#text("37")]#text(" (1933), 698–726.")

#text("[5] L. Onsager, ")#emph[#text("Statistical hydrodynamics")]#text(", Nuovo Cimento (9) ")#strong[#text("6")]#text(" (1949), suppl. 2, 279–287.")

#text("[6] V. Arnold, ")#emph[#text("Sur la géométrie différentielle des groupes de Lie de dimension infinie et ses applications à l’hydrodynamique des fluides parfaits")]#text(", Ann. Inst. Fourier (Grenoble) ")#strong[#text("16")]#text(" (1966), no. 1, 319–361.")

#text("[7] D. G. Ebin and J. Marsden, ")#emph[#text("Groups of diffeomorphisms and the motion of an incompressible fluid")]#text(", Ann. of Math. (2) ")#strong[#text("92")]#text(" (1970), no. 1, 102–163.")

#text("[8] R. H. Morf, S. A. Orszag, and U. Frisch, ")#emph[#text("Spontaneous singularity in three-dimensional inviscid, incompressible flow")]#text(", Phys. Rev. Lett. ")#strong[#text("44")]#text(" (1980), no. 9, 572–574.")

#text("[9] A. D. D. Craik and W. O. Criminale, ")#emph[#text("Evolution of wavelike disturbances in shear flows: a class of exact solutions of the Navier–Stokes equations")]#text(", Proc. Roy. Soc. London Ser. A ")#strong[#text("406")]#text(" (1986), no. 1830, 13–26.")

#text("[10] R. J. DiPerna and P.-L. Lions, ")#emph[#text("Équations différentielles ordinaires et équations de transport avec des coefficients irréguliers")]#text(", Séminaire Goulaouic–Schwartz, École Polytechnique, 1988–1989, exposé no. XIV, 1–9.")

#text("[11] J. Bourgain and D. Li, ")#emph[#text("Strong ill-posedness of the incompressible Euler equation in borderline Sobolev spaces")]#text(", Invent. Math. ")#strong[#text("201")]#text(" (2015), 97–157.")

#text("[12] T. M. Elgindi, ")#emph[#text("Finite-time singularity formation for ")#mi("{C^{1,\\alpha}}")#text(" solutions to the incompressible Euler equations on ")#mi("{\\mathbb{R}^3}")]#text(", Ann. of Math. (2) ")#strong[#text("194")]#text(" (2021), no. 3, 647–727.")

#text("[13] D. Córdoba, L. Martínez-Zoroa, and F. Zheng, ")#emph[#text("Finite time singularities to the 3D incompressible Euler equations for solutions in ")#mi("{C^\\infty(\\mathbb{R}^3\\setminus\\{0\\})\\cap C^{1,\\alpha}\\cap L^2}")]#text(", Ann. PDE ")#strong[#text("11")]#text(" (2025), article 19.")

#text("[14] L. Alpöge, T. Buckmaster, and M. P. Coiculescu, ")#emph[#text("Finite-time singularity formation for the three-dimensional Euler equations")]#text(", ")#link("https://arxiv.org/abs/2611.26772")[#text("arXiv:2611.26772")]#text(".")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-699992")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("This is much better than the OpenAI slop proof a month ago.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-699994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Hopefully Buckmaster gets the Millennium Prize for proving blowup of Navier-Stokes. He deserves it far more than the OpenAI sloptards.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700002")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Buckmaster and Alpoge’s paper is the only paper that has any hope of getting published in a journal, since nobody is working on rewriting OpenAi’s horrendous paper on Navier-Stokes which no journal would ever accept. So it would be two years after Buckmaster and Alpoge’s paper is published in a journal before the Clay Mathematics Institute would accept that Navier-Stokes is solved.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700011")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Does he? The difference primarily seems to be that these guys refuse to acknowledge their massive use of AI tools, but for a brief note:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("We would also like to point out that the proliferation of LLM tools has allowed for a rapid progress in the field, by providing quite welcome assistance in these highly technical proofs.")
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700040")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("Come on, you quoted from a blog post on Euler. In the actual paper(s), they do acknowledge their massive use of AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700062")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("I count two mentions of claude, one of codex, in a a very short paragraph (1.7) which reveals that “Anthropic models” were the source of the original proof.")

#text("Further, their preceding paragraph (1.6) denies provenance to OpenAI and refuses to cite OpenAI’s earlier proof. So what they appear to be claiming in these two buried paragraphs is A) OpenAI deserves no credit, they do, because B) they used AI models to prove the same thing.")

#text("In my opinion, the paper suffers from the same problem as the blog post.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bcf76f63440f7d79f4d6a36dd9618b4808d330395daf5d19dcbec4f77b09c78-49c4881b95c0d221d329660a593af13b6c9d9adf71763763ef5974b85918a77d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jmdpark")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-699996")[#strong[#text("jmdpark")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Nice review.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca8cb3fc006a87e3510003de66bc0a49dc17c88a801df0c73a56af6cf4681b3-3dc434dc68d2dd3cd8eb368c031cae8ae95230747b0aecb4fe2f33b72e6a6256.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700010")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Thanks for this")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700012")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("It’s an extraordinary coincidence that so many of these famous problems were on the verge of being solved by pure human ingenuity just as AI also became capable of solving them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700047")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("I hope you are using a dose of irony here ;)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700061")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("I thought I laid it on thick enough to avoid any doubt :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/759b569bbb004d11ae1fe07935777a1ee426fadc21f3fb6e18d9813d4d728ba5-1242eb21b1db3c8921fa1537a7e1e52993d2374a3ee232f9b8a7a7623a861477.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MJH")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700013")[#strong[#text("MJH")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Thank you for the clear explanation. One detail made me wonder about the role of the clock. In your example, only a finite time elapses, yet the accumulated maximum vorticity grows without bound. I understand that these measure different things. What I’m curious about is whether an observer watching the flow without timestamps could use some change in the fluid itself to tell that the singularity is approached in finite time. What would they need to measure, or would they need an independent clock?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b13f33385ed0883780bc5b02ec2054b1be3d86044bfb2a4bde5799ad62d99ee4-0485a3722b4db8588b22a16bfc22d2f3a19a8a7aabf38b9beddd12d6af497ed5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brewster")]], [#link("https://terrytao.wordpress.com/2026/11/23/finite-time-singularity-formation-for-the-three-dimensional-euler-equations/#comment-700042")[#strong[#text("Brewster")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("I appreciate the work done here. By addressing compressibility constraints first most of the supposed solutions to the Euler equations which follow are more than approximate and surely do answer the questions of finite limitations. I question the avoidability of interference from exponential growth and most of the multiscale ansantz as I will need to review them fully to understand amplitude vectors as noncompressible or exponentially increasing. I really appreciate this work into the singularity as I stated and we be looking forward to the see how the use of these LLM tools can help humanity. Keep Going!")
]
