// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:38:11.652052+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Szemeredi’s proof of Szemeredi’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Szemeredi’s proof of Szemeredi’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 September 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/")[#text("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(" asserts that all subsets of the natural numbers of positive density contain arbitrarily long arithmetic progressions. ")#emph[#text("Roth’s theorem")]#text(" is the special case when one considers arithmetic progressions of length three. Both theorems have many important proofs using tools from additive combinatorics, (higher order) Fourier analysis, (hyper) graph regularity theory, and ergodic theory. However, the original proof by ")#link("http://www.ams.org/mathscinet-getitem?mr=369312")[#text("Endre Szemerédi")]#text(", while extremely intricate, was purely combinatorial (and in particular “elementary”) and almost entirely self-contained, except for an invocation of the ")#link("https://en.wikipedia.org/wiki/Van_der_Waerden%27s_theorem")[#text("van der Waerden theorem")]#text(". It is also notable for introducing a prototype of what is now known as the ")#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(".")

#text("Back in 2005, I ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/szemeredi_theorem.dvi")[#text("rewrote Szemerédi’s original proof")]#text(" in order to understand it better, however my rewrite ended up being about the same length as the original argument and was probably only usable to myself. In 2012, after Szemerédi was awarded the Abel prize, I revisited this argument with the intention to try to write up a more readable version of the proof, but ended up just ")#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/")[#text("presenting some ingredients of the argument in a blog post")]#text(", rather than try to rewrite the whole thing. In that post, I suspected that the cleanest way to write up the argument would be through the language of ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(" (perhaps in an iterated hyperextension that could handle various hierarchies of infinitesimals), but was unable to actually achieve any substantial simplifications by passing to the nonstandard world.")

#text("A few weeks ago, I participated in a ")#link("https://aimath.org/workshops/upcoming/nscombinatorial/")[#text("week-long workshop at the American Institute of Mathematics on “Nonstandard methods in combinatorial number theory”")]#text(", and spent some time in a working group with ")#link("https://blogs.uoregon.edu/akhtari/")[#text("Shabnam Akhtari")]#text(", ")#link("https://www.math.lsu.edu/~ialam1/")[#text("Irfam Alam")]#text(", ")#link("http://jinr.people.cofc.edu/")[#text("Renling Jin")]#text(", ")#link("http://www.unco.edu/nhs/mathematical-sciences/faculty/leth.aspx")[#text("Steven Leth")]#text(", ")#link("https://www.math.lsu.edu/~mahlburg/")[#text("Karl Mahlburg")]#text(", ")#link("https://paulpotgieter.wordpress.com/")[#text("Paul Potgieter")]#text(", and ")#link("http://www.sas.upenn.edu/~htowsner/")[#text("Henry Towsner")]#text(" to try to obtain a manageable nonstandard version of Szemerédi’s original proof. We didn’t end up being able to do so – in fact there are now signs that perhaps nonstandard analysis is not the optimal framework in which to place this argument – but we did at least clarify the existing standard argument, to the point that I was able to go back to my original rewrite of the proof and present it in a more civilised form, which I am ")#link("https://terrytao.wordpress.com/wp-content/uploads/2017/09/szemeredi-proof1.pdf")[#text("now uploading here")]#text(" as an unpublished preprint. There are now a number of simplifications to the proof. Firstly, one no longer needs the full strength of the regularity lemma; only the simpler ")#link("http://www.ams.org/mathscinet-getitem?mr=1723039")[#text("“weak” regularity lemma of Frieze and Kannan")]#text(" is required. Secondly, the proof has been “")#link("https://terrytao.wordpress.com/advice-on-writing-papers/create-lemmas/")[#text("factored")]#text("” into a number of stand-alone propositions of independent interest, in particular involving just (families of) one-dimensional arithmetic progressions rather than the complicated-looking multidimensional arithmetic progressions that occur so frequently in the original argument of Szemerédi. Finally, the delicate manipulations of densities and epsilons via double counting arguments in Szemerédi’s original paper have been abstracted into a certain key property of families of arithmetic progressions that I call the “double counting property”.")

#text("The factoring mentioned above is particularly simple in the case of proving Roth’s theorem, which is now presented separately in ")#link("https://terrytao.wordpress.com/wp-content/uploads/2017/09/szemeredi-proof1.pdf")[#text("the above writeup")]#text(". Roth’s theorem seeks to locate a length three progression ")#mi("{(P(1),P(2),P(3)) = (a, a+r, a+2r)}")#text(" in which all three elements lie in a single set. This will be deduced from an easier variant of the theorem in which one locates (a family of) length three progressions in which just the first two elements ")#mi("{P(1), P(2)}")#text(" of the progression lie in a good set (and some other properties of the family are also required). This is in turn derived from an even easier variant in which now just the first element of the progression is required to be in the good set.")

#text("More specifically, Roth’s theorem is now deduced from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.5")]#text(". Let ")#mi("{L}")#text(" be a natural number, and let ")#mi("{S}")#text(" be a set of integers of upper density at least ")#mi("{1-1/10L}")#text(". Then, whenever ")#mi("{S}")#text(" is partitioned into finitely many colour classes, there exists a colour class ")#mi("{A}")#text(" and a family ")#mi("{(P_l(1),P_l(2),P_l(3))_{l=1}^L}")#text(" of 3-term arithmetic progressions with the following properties:")

#enum(start: 1, 
[#text("For each ")#mi("{l}")#text(", ")#mi("{P_l(1)}")#text(" and ")#mi("{P_l(2)}")#text(" lie in ")#mi("{A}")#text(".")],
[#text("For each ")#mi("{l}")#text(", ")#mi("{P_l(3)}")#text(" lie in ")#mi("{S}")#text(".")],
[#text("The ")#mi("{P_l(3)}")#text(" for ")#mi("{l=1,\\dots,L}")#text(" are in arithmetic progression.")]
)
]

#text("The situation in this theorem is depicted by the following diagram, in which elements of ")#mi("A")#text(" are in blue and elements of ")#mi("S")#text(" are in grey:")

#image("../assets/27f48d2521701e074d78a43cdc62304cc85768713ed760dfc56c06f9440eb360-31a60e979f9a7d18468216e94c7522db07b7b4054785794d9e49d536087477bf.png", width: 90%)

#text("Theorem 1.5 is deduced in turn from the following easier variant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.6")]#text(". Let ")#mi("{L}")#text(" be a natural number, and let ")#mi("{S}")#text(" be a set of integers of upper density at least ")#mi("{1-1/10L}")#text(". Then, whenever ")#mi("{S}")#text(" is partitioned into finitely many colour classes, there exists a colour class ")#mi("{A}")#text(" and a family ")#mi("{(P_l(1),P_l(2),P_l(3))_{l=1}^L}")#text(" of 3-term arithmetic progressions with the following properties:")

#enum(start: 1, 
[#text("For each ")#mi("{l}")#text(", ")#mi("{P_l(1)}")#text(" lie in ")#mi("{A}")#text(".")],
[#text("For each ")#mi("{l}")#text(", ")#mi("{P_l(2)}")#text(" and ")#mi("{P_l(3)}")#text(" lie in ")#mi("{S}")#text(".")],
[#text("The ")#mi("{P_l(2)}")#text(" for ")#mi("{l=1,\\dots,L}")#text(" are in arithmetic progression.")]
)
]

#text("The situation here is described by the figure below.")

#image("../assets/c6bf865aba994dccba3b44060f58a45a80056c0356956e04aeaa9ff264c092ed-782812708ccc808496ee3482b9ef06c806c87df3a2aac26448769560af779e2f.png", width: 90%)

#text("Theorem 1.6 is easy to prove. To derive Theorem 1.5 from Theorem 1.6, or to derive Roth’s theorem from Theorem 1.5, one uses double counting arguments, van der Waerden’s theorem, and the weak regularity lemma, largely as described in ")#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/")[#text("this previous blog post")]#text("; see ")#link("https://terrytao.wordpress.com/wp-content/uploads/2017/09/szemeredi-proof1.pdf")[#text("the writeup")]#text(" for the full details. (I would be interested in seeing a shorter proof of Theorem 1.5 though that did not go through these arguments, and did not use the more powerful theorems of Roth or Szemerédi.)")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-486163")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2017")])]

#text("Considering Erdos’ problem on the characterization of all subsets of natural numbers containing arbitrarily long arithmetic progressions (conjectured to be those sets with divergent sum of the reciprocals of their elements), is there any probabilistic argument for this conjecture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eba78b9309025b46ae9af737374d44e6ca10a6218387ce2923c97a033a6971e-5a7c703fdb52f5e3069f4ca2710a6352efe8edf6129cdedaf4d9c9dcfc6841d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan Kohl")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-486164")[#strong[#text("Stefan Kohl")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2017")])]

#text("@Anonymous: But this works at most one way. — It is easy to find sets of natural numbers which contain arbitrarily long arithmetic progressions such that the sum of reciprocals of the elements does not diverge. — Take e.g. ")#mi("S = \\{2^n + k | n \\in \\mathbb{N}, k \\in 0, \\dots, n\\}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-486166")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2017")])]

#text("Yes! (the above Erdos conjecture for arithmetic progressions, is only a conjectured sufficient condition for such subset to contain arbitrarily long arithmetic progressions) – thanks for the correction!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Epstein")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-486332")[#strong[#text("Paul Epstein")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2017")])]

#text("Thanks a lot for this. Is the purpose of this account to give a proof of Szemeredi’s theorem that is elementary, self-contained, and easy to follow?")

#text("Elementary proofs of van der Waerden are readily googlable, and your omission of this part of the proof is understandable.")

#text("However, what is less clear is whether omitting the proof of your version of Frieze-Kannan regularity can be justified pedagogically. I agree that an experienced mathematician can simply consult the Frieze-Kannan paper and follow their proof, but a person with that degree of mathematical maturity wouldn’t need an elementary proof in the first place.")

#text("Personally speaking, I did consult the Frieze-Kannan paper, and I couldn’t find anything that matched your version. In particular, the discussions always focused on a single partition, rather than two partitions, as in your presentation.")

#text("I would have appreciated your account more if you had either given a proof of your version of Frieze-Kannan regularity, or been more precise and explicit about how exactly you’re using the original Frieze-Kannan paper, instead of a mere citation.")

#text("Thank you very much for your blog which is teaching me a lot, even though I’m not a research-level mathematician.")

#text("Paul Epstein")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-486338")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2017")])]

#text("Fair enough; I’ve added a proof of the weak regularity lemma (using spectral methods) as an appendix.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-486428")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2017")])]

#text("Could surreal numbers (instead of nonstandard reals) be of any use in handling the epsilons? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-486933")[#strong[#text("How to write a 21st century paper – Write down what you’ve done")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2017")]

#text("[…] but still lend themselves to a depiction by other directed acyclic graphs (See for example this rewrite of Szemeredis theorem by Terence Tao, page 8). But the general idea of dividing a proof into smaller (how small) steps and specifying […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauldepstein")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-489447")[#strong[#text("pauldepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2017")])]

#text("Thank you very much for adding a proof of the weak regularity lemma. I learned the SVD theorem as a response to this, so your blog is certainly educating me mathematically. I’m sorry to say that I’m a bit stuck on this proof of the weak regularity lemma.")

#text("Specifically, I’m stuck on page 36 on the equation that occurs after the phrase “whenever i >= 16/ (epsilon ^ 2).")

#text("I understand equation A 1. which involves a sum of products")#linebreak()#text(" of terms f_i(v) * g_i(w).")

#text("However, when you multiply one row the of adjacency matrix by g_i(w), and")#linebreak()#text(" take the sum, I’m very puzzled that so many of the f_i(v) terms seem to melt away.")

#text("Thanks for your help.")

#text("Paul Epstein")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauldepstein")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-489448")[#strong[#text("pauldepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2017")])]

#text("Sorry, I get it now. Just not very used to these orthonormal computations in my head. I understand now, so no need to respond.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauldepstein")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-489471")[#strong[#text("pauldepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2017")])]

#text("Still reading the proof of the weak regularity lemma in the appendix. I’m only stuck on one issue. Consider the i for which lambda_i > epsilon/4. I don’t understand why the sum of these lambda_i is < 4/epsilon. This claim is at the very end of the appendix. I'd be grateful for any help. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-489568")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("If ")#mi("\\lambda_i \\geq \\varepsilon/4")#text(" then ")#mi("\\lambda_i \\leq \\frac{4}{\\varepsilon} \\lambda_i^2")#text(". Since ")#mi("\\sum_i \\lambda_i^2 \\leq 1")#text(", the claim follows.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauldepstein")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-489639")[#strong[#text("pauldepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2017")])]

#text("I’ve learned so much from this paper, and am checking all the claims in full detail. I’ve now finished reading the proof of the regularity lemma in the appendix, however I’m not sure how to formalise the concept “if c is sufficiently slowly decaying” as on page 17. I’m fine up to there, though. Many thanks for any help you can offer, as to how concepts such as “sufficiently slowly” can be formalised along similar lines to epsilon-delta formulations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauldepstein")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-489650")[#strong[#text("pauldepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2017")])]

#text("Just before 3.8 (“and hence by Markov’s inequality”) the >= sign is the wrong way round. I’m afraid I’m uncomfortable with the argument around 3.7 and 3.8 even after making this correction. The epsilon in the denominator in 3.8")#linebreak()#text(" makes it unclear what type of c function is intended.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-489897")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("The inequality seems to be in the right direction to me (note the presence of “but” immediately after (3.8)).")

#text("Recall from (3.5) that one is assuming ")#mi("L_1")#text(" to be much larger than any given function of ")#mi("\\varepsilon")#text(", or equivalently that ")#mi("\\varepsilon")#text(" is larger than any given function of ")#mi("L_1")#text(" that goes to zero. In particular, one can use (3.5) to make ")#mi("\\frac{1}{\\varepsilon}")#text(" less than, say, ")#mi("(\\frac{2}{L_1} + \\eta(L_1) + \\eta^{\\prime}(L_1))^{1/2}")#text(", and then by choosing ")#mi("c(L_1)")#text(" appropriately one can obtain the display after (3.8).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauldepstein")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-490027")[#strong[#text("pauldepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")])]

#text("Thanks, Terry. 3.8 is indeed correct but the inequality before 3.8 is the wrong way round. You’re arguing that a positive quantity is small so we need positive quantity <= … The inequality before 3.8 is the wrong way round. I now can follow everything so far and have read the first 21 pages plus the appendix. There are occasional errors (like the inequality) and I'd be happy to provide an errata list if it would be of sufficient interest.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-490050")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")])]

#text("Ah, I see now, thanks. This typo will be corrected in the next revision of the ms. I’m also happy to take an errata list if you have one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauldepstein")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-490267")[#strong[#text("pauldepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("There are few significant errors that I’ve uncovered so far. I’d like to provide a few gap-fillers so that remarks that puzzled me are proved in more detail. However, this depends on your intended audience. If the intended audience is maths graduates, then perhaps no more details are needed. However, Khinchin’s Three Pearls of Number Theory is readable by complete beginners — a lot would need to be proved in more detail for it to be accessible by the “Three Pearls” audience. If you tell me who the intended audience is, I could maybe make more meaningful suggestions. I think a readable account of the elementary proof of Szemeredi’s theorem is a great concept — no one understands the original and I’ve been trying to understand the original for years.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9caef4b5028ca7355308de0c46c5b850ec5540b37d58342c19ada8249ad4a5d1-1d2a6405039b90a1e214593db2478ec2f5565fc5cc4075f766beb0d3547c7a46.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mallesham kummari")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-541700")[#strong[#text("mallesham kummari")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2020")])]

#text("Let A be a subset of N, the set of natural numbers. Is it true that if the sumset A+A has positive density then A contains arbitrarily long arithmetic progressions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-541997")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2020")])]

#text("This is probably not the case. The square numbers ")#mi("A = \\{1,4,9,16,\\dots\\}")#text(" are almost a counterexample: it is a classical result of Fermat that there are no four squares in arithmetic progression, and ")#mi("A+A")#text(" is close to having positive density (the number of elements up to ")#mi("x")#text(" is something like ")#mi("\\frac{x}{\\sqrt{\\log x}}")#text(" (see ")#link("http://mathworld.wolfram.com/Landau-RamanujanConstant.html")[#text("http://mathworld.wolfram.com/Landau-RamanujanConstant.html")]#text(" ). I would imagine that some perturbation of this construction would give a counterexample.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-681844")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2023")])]

#text("I think another way of disproving the statement is to use the probabilistic method. If you let ")#mi("n")#text(" belong to ")#mi("A")#text(" with probability ")#mi("n^{-\\alpha}")#text(" for some ")#mi("\\alpha")#text(" less than 1/2, then (with probability 1) the sumset will have positive density. But for suitable ")#mi("k")#text(" (I think 5 probably does the job if ")#mi("\\alpha")#text(" is close enough to 1/2, but it is likely to be easier to prove with ")#mi("k")#text(" a bit larger than this) one can show that the expected number of APs of length ")#mi("k")#text(" is less than 1.")

#text("I haven’t checked this super-carefully, but carefully enough to be pretty confident that it can be done. Indeed, I think one can even ask for ")#mi("A+A")#text(" to contain all sufficiently large positive integers, or, if one wants to make a bit more effort, every integer greater than 1.")

#text("It’s not obvious to me whether to expect ")#mi("A")#text(" to have to contain an AP of length 4, but to obtain a counterexample to that, I think one would have to use a method much closer to what Terry suggests.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-681845")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2023")])]

#text("Sorry, that was meant as a reply to mallesham kummari, but it accidentally ended up as a standalone comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0376dd5aea6083bbf234ac36c3dfba89a6661896dd8be23a7713917c6e69df1-dec836accfb04d73be10100171b3b206d6fa8fcdbe35c99a55903edf816651f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsefsolymosi")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-681858")[#strong[#text("jozsefsolymosi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2023")])]

#text("To clarify: You think there is an infinite set of positive integers, A, such that A+A contains all sufficiently large positive integers, but A has no arbitrarily large AP-s?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-681859")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2023")])]

#text("This can be deduced from known results as follows: If we choose a subset of the positive integers by selecting each element with probability $n^{-\\alpha}$ (with $\\alpha > 1/2$) then with probability 1, a positive proportion of integers will be represented as the sum of two elements of this set. This goes back at least to Erdos and Renyi’s work on additive bases (see: ")#link("https://users.renyi.hu/~p_erdos/1960-02.pdf")[#text("https://users.renyi.hu/~p_erdos/1960-02.pdf")]#text("). On the other hand (and this is certainly overkill), by Bourgain’s $\\Lambda(p)$ theorem this set will be a $\\Lambda(2/\\alpha)$ set (again, with probability 1). However a $\\Lambda(p)$ set (for $2<p< \\infty$) can't contain an arbitrarily long AP. In fact, its intersection with an AP of length N can be at most $O(N^{2/p})$. This of course implies the set will contain no AP's of length $k$ for sufficiently large $k$.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-681867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2023")])]

#text("Let’s not think about the sumset but about a well understood progression-free set first.")#linebreak()#text(" Let ")#mi("A")#text(" be the set already in the Erdos-Turan 1936 paper (On some sequences of integers),")#linebreak()#text(" due to Szekeres, consisting of digits 0 and 1 (but not 2) in the ternary system.")#linebreak()#text(" Then ")#mi("A")#text(" does not contain a 3-progressions,")#linebreak()#text(" but ")#mi("A+A")#text(" covers all nonnegative integers, which contradicts the conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c2e5a74e5c44819e3b488cefed88cd751e6b44d155c1c343b34325ebe09a24a-5c706ec675da98f0cd1ece0be9de0b52bae041828a45b794bc813d29b91ec933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumit shingare")]], [#link("https://terrytao.wordpress.com/2017/09/12/szemeredis-proof-of-szemeredis-theorem/#comment-686643")[#strong[#text("Sumit shingare")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Dear Prof. Tao,")

#text("I have a question regarding properties similar to Goldbach’s conjecture whether they are primarily combinatorial or number-theoretic. Specifically, I am curious about the following:")

#enum(start: 1, 
[#text("Is there a positive density subset A of naturals such that restricted sumset A ^+ A has density zero?")

#enum(start: 2, 
[#text("If A is an infinite subset of naturals for which restricted sumset A^+A has density zero, what can we conclude about the size or growth rate of A ?")]
)]
)

#text("Thank you for your time and any insights you might offer.")
]
