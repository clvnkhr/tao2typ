// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/
// Converted to Typst by tao2typ: "2026-10-14T15:16:48.931392+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The sum-product phenomenon in arbitrary rings", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The sum-product phenomenon in arbitrary rings")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 June 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/")[#text("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve uploaded a new paper to the ")#link("http://arxiv.org/")[#text("arXiv")]#text(" entitled “")#link("http://arxiv.org/abs/0806.2497")[#text("The sum-product phenomenon in arbitrary rings")]#text("“, and submitted to ")#link("http://cdm.ucalgary.ca/index.php/cdm")[#text("Contributions to Discrete Mathematics")]#text(". The sum-product phenomenon asserts, very roughly speaking, that given a finite non-empty set A in a ring R, then either the sum set ")#mi("A+A := \\{ a+b: a, b \\in A \\}")#text(" or the product set ")#mi("A \\cdot A := \\{ ab: a, b \\in A \\}")#text(" will be significantly larger than A, unless A is somehow very close to being a subring of R, or if A is highly degenerate (for instance, containing a lot of zero divisors). For instance, in the case of the integers ")#mi("R = {\\Bbb Z}")#text(", which has no non-trivial finite subrings, a long-standing ")#link("http://www.ams.org/mathscinet-getitem?mr=820223")[#text("conjecture of Erdös and Szemerédi")]#text(" asserts that ")#tao-math("\\left|A+A\\right| + \\left|A \\cdot A\\right| \\gg_\\varepsilon \\left|A\\right|^{2-\\varepsilon}", block: false)#text(" for every finite non-empty ")#mi("A \\subset {\\Bbb Z}")#text(" and every ")#mi("\\varepsilon > 0")#text(". (The current best result on this problem is a very recent ")#link("http://arxiv.org/abs/0806.1040")[#text("result of Solymosi")]#text(", who shows that the conjecture holds for any ")#mi("\\varepsilon")#text(" greater than 2/3.) In recent years, many other special rings have been studied intensively, most notably finite fields and cyclic groups, but also the complex numbers, quaternions, and other division algebras, and continuous counterparts in which A is now (for instance) a collection of intervals on the real line. I will not try to summarise all the work on sum-product estimates and their applications (which range from number theory to graph theory to ergodic theory to computer science) here, but I discuss this in the introduction to my paper, which has over 50 references to this literature (and I am probably still missing out on a few).")

#text("I was recently asked the question as to what could be said about the sum-product phenomenon in an arbitrary ring R, which need not be commutative or contain a multiplicative identity. Once one makes some assumptions to avoid the degenerate case when A (or related sets, such as A-A) are full of zero-divisors, it turns out that there is in fact quite a bit one can say, using only elementary methods from additive combinatorics (in particular, the Plünnecke-Ruzsa sum set theory). Roughly speaking, the main results of the paper assert that in an arbitrary ring, a set A which is non-degenerate and has small sum set and product set must be mostly contained inside a subring of R of comparable size to A, or a dilate of such a subring, though in the absence of invertible elements one sometimes has to enlarge the ambient ring R slightly before one can find the subring. At the end of the paper I specialise these results to specific rings, such as division algebras or products of division algebras, cyclic groups, or finite-dimensional algebras over fields. Generally speaking, the methods here give very good results when the set of zero divisors is sparse and easily describable, but poor results otherwise. (In particular, the sum-product theory in cyclic groups, as worked out by Bourgain and coauthors, is only recovered for groups which are the product of a bounded number of primes; the case of cyclic groups whose order has many factors seems to require a more multi-scale analysis which I did not attempt to perform in this paper.)")#linebreak()#text(" ")#metadata(none) <tao-5057e30cd7e98cfc045d>

#text("The key strategy is to study sets of the form")

#align(center)[#tao-fit-display[#tao-math("S_a := \\{ x \\in R: \\left|x \\cdot A + a \\cdot A\\right| \\leq M \\left|A\\right| \\}", block: true)]]

#text("for various ")#mi("a \\in R")#text(" (which will usually be a non-zero-divisor), and some suitable threshold parameter M (which will be a little bit larger than the sum and product doubling constants of A). Roughly speaking, ")#mi("S_a")#text(" collects all the dilates ")#mi("x \\cdot A")#text(" of A which are “parallel” to the dilate ")#mi("a \\cdot A")#text(" in an additive sense. There is a remarkable “self-improving property” of these sets which shows, under suitable hypotheses on A, a, and M, that every element x of ")#mi("S_a")#text(" in fact obeys the improved estimate ")#tao-math("\\left|x \\cdot A + a \\cdot A\\right| \\leq M^{\\prime} \\left|A\\right|", block: false)#text(" for some M’ that can be arranged to be significantly smaller than M. In other words, there is a gap phenomenon: the quantity ")#tao-math("\\left|x \\cdot A + a \\cdot A\\right|", block: false)#text(" can be very small or very large, but cannot be of intermediate size. This gap then leads to some very strong algebraic control on the ")#mi("S_a")#text("; for instance, under reasonable assumptions, ")#mi("S_a")#text(" becomes an additive group, and also exhibits good multiplicative closure properties (for instance, ")#mi("S_1")#text(" will be a subring). Once one has all this algebraic structure, the proofs of the theorems are then a relatively routine application of the sum-set theory and some elementary algebra.")

#text("There is still the issue of what to do when there are plenty of zero divisors. I don’t have a satisfactory resolution to this problem in general, but in the case of finite dimensional algebras over a field, in which the set of zero divisors forms an algebraic set, one can use some basic algebraic geometry to show that if a set of small additive doubling is concentrating inside the set of zero divisors, then it must in fact concentrate inside an affine subspace contained in the set of zero divisors. This does not fully determine the structure of such a set, but it seems to be a useful first step towards analysing this case further.")

#text("[See also my third Milliman lecture “")#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/")[#text("Sum-product estimates, expanders, and exponential sums")]#text("“.]")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of some_student")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-30451")[#strong[#text("some_student")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2008")])]

#text("Dear Terry, this is interesting, do you know if similar robustness questions have been investigated for other structures than addition and multiplication? For instance if one were to consider the ")#link("http://en.wikipedia.org/wiki/Tropical_Mathematics")[#text("“tropical” operations")]#text(" ")#mi("min")#text(" and ")#mi("+")#text("? Or if one looked at a set equiped with one binary law (like ")#mi("+")#text(" or ")#mi("\\times")#text(") and one higher order law (e.g. a ternary operation that is not defined in tems of addition and multiplication)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-30454")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2008")])]

#text("Dear some_student,")

#text("There is some work by Igor Shparlinski on an exponential version of sum-product in finite fields, where one looks at the sets {g^a+g^b: a in A, b in B} and {g^{ab}: a in A, b in B} for some generator g, and also on elliptic curve versions in which one looks at { x(aP) + x(bP): a in A, b in B} and {x(abP): a in A, b in B}, where P is a point on an elliptic curve of some order p, A and B are sets in F_p, and x is the x coordinate of the elliptic curve. Presumably there are many further variations on these themes.")

#text("One particularly nice problem, by the way, is to work out all the polynomials P(x,y) of two variables for which P(A,A) is necessarily much larger than A whenever A is a finite set of, say, integers with A+A small. Apart from trivial examples such as functions of a linear polynomial in x and y, it should be that one has a result of the form |P(A,A)| \\geq |A|^{1+c} for any such P, where c depends on P. There is some work by Van Vu in this direction at")

#link("http://arxiv.org/abs/0705.0715")[#text("http://arxiv.org/abs/0705.0715")]

#text("In the tropical setting, there is unlikely to be any phenomenon of this type, because of the degeneracy of the min operation: the min-set of A and A is just A, and so the min-sum problem is really just a sum problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adelaide Boy")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-30559")[#strong[#text("Adelaide Boy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2008")])]

#text("Dear Terry,")

#text("Along with a recent Anonymous, I often read your posts without")#linebreak()#text(" understanding the details. I have been able to follow this paper")#linebreak()#text(" because you kept it elementary, and thankyou for that.")

#text("In your proof of 3.1.(i), you seem to assume that dA-AA is a subset")#linebreak()#text(" of AA-AA. However, d \\in A-A, so dA-AA would be a")#linebreak()#text(" subset of AA-2AA. Is that right? Also, r and b seem to be")#linebreak()#text(" the same variable in this section.")

#text("Adelaide Boy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-30561")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2008")])]

#text("Dear Adelaide Boy: Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-30893")[#strong[#text("Begging for Submissions « Rigorous Trivialities")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2008")]

#text("[…] The sum-product phenomenon in arbitrary rings […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93dcd51e0a4ece3b6722a686d783691c80da853b2af87ae0536766118c6cfcc1-e70b46576a6fa5feccd2f80233e87256385af4c99390e72f8919ffcced489f67.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John R Ramsden")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-31066")[#strong[#text("John R Ramsden")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2008")])]

#text("I wonder if a related type of phenomenon, perhaps a special case, is at work with the Mahler measure of polynomials, which Graeme Taylor blogged about a few months ago at ")#link("http://maths.straylight.co.uk/archives/114")[#text("http://maths.straylight.co.uk/archives/114")]

#text("Quoting from his article:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The motivation comes from finding polynomials of small Mahler measure- whilst a cyclotomic polynomial has measure 1, all others seem to be pushed away, with the smallest known value being 1.176…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of another student")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-32555")[#strong[#text("another student")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2008")])]

#text("Dear Terry, is there any reason this specific conjecture is of interest? What would be its implications in the research in additive number theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-32561")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2008")])]

#text("Dear another student:")

#text("While the Erdos-Szemeredi conjecture, if true, might possibly have some direct application to number theory (it is tempting, for instance, to try to apply it to, say, the set of quadratic residues in an interval to learn something about their distribution), I would imagine that the new techniques, ideas, and insights that would go into any future proof of this conjecture may be even more interesting, in many ways, than the result itself. (A lot of problems in combinatorics or analysis are of this nature; they can be viewed as sort of benchmarks for measuring the technological progress of one’s tools.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lecture IV: “Sieving for almost primes and expanders” « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-33605")[#strong[#text("Marker lecture IV: “Sieving for almost primes and expanders” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2008")])]

#text("[…] are now some quite elementary proofs of this theorem, but I will not discuss them here (see e.g. my earlier blog post on this topic). I should note, though, that the bulk of the Bourgain-Gamburd-Sarnak work is preoccupied with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xavier")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-46682")[#strong[#text("Xavier")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")])]

#text("Dear Terry, sorry for digging out this old thread.")

#text("Did you already consider non-associative rings ?")#linebreak()#text(" Those arising from octonion algebras, whose multiplication")#linebreak()#text(" verifies the Moufang identities: (ab)(ca)=(a(bc))a")#linebreak()#text(" There are some similarities between SL2(Z) (split-quaternions of norm 1)")#linebreak()#text(" and Zorn “Vektormatrix” (split-octonions). It would then be great to have an equivalent of Helfgott’s results concerning SL2(Z) for Vektormatrices over Z.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-46686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")])]

#text("I did not consider non-associative rings, and the arguments in my paper certainly rely on associativity in a number of places. To my knowledge, there is no literature on the sum-product question for octonions, though I can imagine that such a result is potentially within reach of the current technology.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/#comment-126687")[#strong[#text("254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("[…] exponent in the sum-product theorem. A relatively recent survey of this literature can be found in this paper of mine. In , the best result currently in this direction is by Solymosi, who established that one can take […]")
]
