// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/
// Converted to Typst by tao2typ: "2026-10-14T11:16:35.544799+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Two more apps: visualizing the zeta process and the motions of the heavens", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Two more apps: visualizing the zeta process and the motions of the heavens")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 July 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/")[#text("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I believe that the creation of visualization apps to illustrate mathematical or scientific concepts is a particularly favorable use case for modern coding agents, as many of the downside risks attached to other LLM use cases are limited:")

#enum(start: 1, 
[#strong[#text("Not mission-critical")]#text(". As such apps are not authorative sources of truth and only used for secondary purposes, a small positive error rate in the output can be acceptable.")],
[#strong[#text("Stand-alone")]#text(". As the applets are not destined to be incorporated into a larger codebase or literature, the technical debt incurred by delegating all the coding to an LLM agent is bounded.")],
[#strong[#text("End product is deterministic (and sandboxed)")]#text(". As the applets run on a deterministic language (Javascript), are sandboxed against file or internet access, and do not make any LLM calls at run-time, security and privacy concerns are minimal, and the applet can be maintained without continued premium LLM access or resource-intensive compute.")],
[#strong[#text("Not replacing primary skills")]#text(". While deskilling is the tradeoff one accepts when relying on these tools to accelerate output, I am perfectly willing to forego the opportunity to keep my Javascript skills at a high level, as this is a tertiary skill for me at best in my chosen profession. (I continue to manually program in Lean and in Python to keep in practice with programming in general.)")],
[#strong[#text("Not competing with humans")]#text(". To my knowledge, there is no existing human effort that is being duplicated by these applets (the activity in this direction appears to have peaked two decades ago).")]
)

#text("I would however caution against unrestricted LLM use when one or more of the above five favorable situations is not in effect.")

#text("With these points in mind, I have used such an agent to create two further apps. The first app illustrates the “zeta process” that was introduced in ")#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/")[#text("my recent paper with Alexeev, Barreto, Li, Lichtman, Price, Shah, and Tang")]#text(", though it was ")#link("https://drive.google.com/file/d/1Ubj3t5QdkNu0u9WQipdaFQ8zln_JlbMJ/edit")[#text("first discovered by an AI")]#text(". For each ")#mi("s > 1")#text(", the ")#link("https://en.wikipedia.org/wiki/Zeta_distribution")[#text("zeta distribution")]#text(" ")#mi("Z_s")#text(" is a random natural number with distribution")

#mi("\\displaystyle {\\bf P}( Z_s = k ) = \\frac{1}{\\zeta(s) k^s}.")

#text("It has long been known that this distribution has good number-theoretic properties: for instance, the number of times a given prime ")#mi("p")#text(" divides ")#mi("Z_s")#text(" has a geometric distribution of mean ")#mi("p^{-s}")#text(". However, the new observation is that these random variables ")#mi("Z_s")#text(" can be chained together into a single stochastic process, which we call the “zeta process”, which is an infinite divisibility chain. I ")#link("https://teorth.github.io/tao-web/apps/zeta-process-making-of.html")[#text("used an agent")]#text(" to ")#link("https://teorth.github.io/tao-web/apps/zeta-process.html")[#text("create an app")]#text(" to visualize this process:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/07/image-12.png")[#image("../assets/707220cfbc23aeda4acda8d2c12bbed5f958b5dd706910e41adaf5bd4d0cb50b-104772f3c31e42f2a538bd4a66531d4a3e92af15ce9dc66d74e6231b63ea63a3.png", width: 90%)]
]

#text("The underlying process is generated by several exponential random variables at each prime: in the above instantiation of the process, two such variables are visible at the prime ")#mi("p=2")#text(", and one variable at the primes ")#mi("p=3,5")#text(". At a given choice of ")#mi("s")#text(", ")#mi("Z_s")#text(" is formed by collecting all the variables below this threshold (and for which all predecessors also lie below the threshold); in the above illustration, this amounts to one variable at each of the primes ")#mi("p=2,3,5")#text(", leading to ")#mi("Z_2 = 30")#text(" in this case. Additional visualizations in the app display the distribution of each ")#mi("Z_s")#text(", as well as the distribution of the hitting probability ")#mi("\\nu_\\Lambda")#text(", which among other things can be used to give a quick solution to ")#link("https://www.erdosproblems.com/1196")[#text("Erdős problem #1196")]#text(".")

#text("The ")#link("https://teorth.github.io/tao-web/apps/orrery.html")[#text("second app")]#text(" is rather different in nature, and is a somewhat whimsical attempt to display the motion of the heavens, both at “human” scales of space and time, and at more “astronomical” scales (in which the motion of the planets in particular are more apparent). It is very loosely inspired by the game “")#link("https://en.wikipedia.org/wiki/Katamari_Damacy")[#text("Katamari Damacy")]#text("“, in which one absorbs both terrestrial and celestial objects of many different scales. Here is how the app typically looks at a human scale:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/07/image-13.png")[#image("../assets/e8ecfaa5637200fc5fde2a943873a324df7ab48920d7a43d361d18aca023afba-2136389184b312d933e606362fe58aafbff7d6f569beb65f99c4385a4af6a00b.png", width: 90%)]
]

#text("And here is how it looks when one’s perspective leaves the Earth’s atmosphere:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/07/image-16.png")[#image("../assets/f1f46c354c1282fc4f1521b08506f4f97507add6097d99ba30517d4bdb3b1188-0d1df11e0ec5cbe3fb9913c0d8a63293153892a658a50f6c5116cdc67beb2da1.png", width: 90%)]
]

#text("(As I did not want to render an entire explorable world in this app, the observer in the app is only limited to changing his or her size, from a human to a creature of comparable size to the Earth itself; they cannot move horizontally on the planet.) At the largest scales of space and time, the classic orrery diagram appears:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/07/image-17.png")[#image("../assets/d1eb5c233d990499d0a09adece0c4b1a44107b960806e2a6de6fef15cb69a574-b7c3d0dcec65b27eaae6ec7da34da404858a4f38ac404924fcef7fcb6a191a53.png", width: 90%)]
]

#text("After ")#link("https://teorth.github.io/tao-web/apps/orrery-making-of.html")[#text("lengthy conversations with the agent")]#text(", I was able to implement many astronomical phenomena, including phases of the Moon, the effect of Earth’s rotation against the fixed stars (though one can also stabilize one’s view against those stars to see the Earth’s rotation more directly), and so forth.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b423fadc513ac0411dd0514ea026a2d16a4135f02398c6cf3e216875f731e7-f10415d608fb7f54446cf1edbfc12d995d6764cec76d613dd19362a166d378a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin Bian")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693432")[#strong[#text("Justin Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2026")])]

#text("Great project :) !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d22afeeaff1d99393f742a369f26621bb5d739dfdc71748c7a5434d06cef831-1c4d2f26f0ce2034e23d5c360500d8a59ec91f6047cdf8b1add8c69d92719641.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Birke Heeren")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693438")[#strong[#text("Birke Heeren")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2026")])]

#text("Do you know the site of Dr. Schwebinghaus? There are a lot of interesting mathematical interactiv programs.")#linebreak()#link("https://www.fraktalwelt.de/myhome/index.html")[#text("https://www.fraktalwelt.de/myhome/index.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cf55003cb9c661a0d6e195b3cc4cebcd1905ebbbec641eac16822b846f8097d-9790dd8f2eea1497d22d07af6c6662a48e4141e4c2368957cb9b504ecb48d13b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693459")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2026")])]

#text("What percent of software do you think meets the first four favorable situations but not the fifth one (the “Not competing with humans” one)?")

#text("And if it’s non-zero, do you think that would mean more software (that meets the first four situations) and same amount of software engineers? Or same amount of software (that meets the first four situations) and less software engineers? Or something else entirely?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693465")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2026")])]

#text("I am ")#link("https://claude.ai/share/24d707ce-6791-45f4-acf5-2e36edeafad6")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14ac0ae7fd696758a9c386bf25d6f755a15b3ba9f6e91e2bad88627dc33b5220-0d542ae24deb3e921bbaf2dcafc24588f536c35e46e558dd7e594c07af00a649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mason Porter")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693467")[#strong[#text("Mason Porter")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2026")])]

#text("It’s been close to a couple of decades since I saw someone reference Katamari Damacy. That game was an unexpected hit, and I never could particularly control the prince.")

#text("In terms of these various apps, there is also a sort of intermediary (which is much more common outside of theoretical mathematics, though still not terribly common) with animations that can be hosted e.g. in the Supplementary Materials of journals. So maybe mathematics will see a flux of AI animations placed in such settings. When SIAM started the journal SIAM Journal on Applications of Dynamical Systems (SIADS) a quarter of a century ago, they were hoping that people would take advantage of its online-only publishing model by including animations with their articles, but it didn’t materialize so much in practice.")

#text("A separate thing to point out in this vein (and this is something that could inspire more examples with modern AI tools) is a ‘reimagining’ by Bret Victor of the Watts–Strogatz 1998 ‘small-world’ paper.")

#text("Here is his reimagining: ")#link("https://worrydream.com/ScientificCommunicationAsSequentialArt/")[#text("https://worrydream.com/ScientificCommunicationAsSequentialArt/")]

#text("Victor commented that the Watts–Strogatz paper had basically already reached what he viewed as a quality bound for a prose-only article (I don’t agree with that statement, but that’s a separate issue), and he added knobs for ‘readers’ to do things like interactively adjust parameter values (a rewiring probability, in this case). Further to apps, perhaps we can see more of this type of augmentation in the AI era. It would also be great for ‘readers’ to do this with papers in a semi-automated way even when authors don’t.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693471")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2026")])]

#text("“(I continue to manually program in Lean and in Python to keep in practice with programming in general.)”")

#text("How do you decide which parts of your Lean or Python programming to outsource to AI, and how much of the work do you typically delegate in general?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693475")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2026")])]

#text("The five criteria I listed in the blog post already provide a lot of guidance. For instance, if the Lean code I am writing is destined to be used in a larger code repository such as Mathlib, then it becomes more important to be able to understand the code itself and not just the final outputs, and heavy reliance of AI would usually not be a good idea. On the other hand, using AI tools to automatically review such code remains a reasonably low-risk activity, and I certainly take advantage of the ability of AI agents to review my code for adherence to stylistic guidelines etc.. My ")#link("https://www.youtube.com/@TerenceTao27")[#text("Youtube channel")]#text(" has some examples of various ways in which I use (or do not use) AI tools in my formalization work. (See also my “AI on the red team” advice in ")#link("https://arxiv.org/abs/2603.26524")[#text("my paper with Klowden")]#text(".)")

#text("For Python, my main concern is to avoid deskilling, as I do find it convenient to know how to do quick edits to Python code provided from other sources (including LLMs) to adapt them to my own needs, and to be able to visually inspect Python code for any serious red flags (e.g., unwanted I/O calls). But for the applets I have not found it necessary to directly edit or even review the Javascript provided, and rely on playtesting the final applet and interacting by text with the agent instead to bring the applet up to an acceptable level of quality for this non-mission-critical task.")

#text("(Incidentally, there are other desiderata to keep in mind beyond the five listed in the blog post, for instance whether prior art and intellectual property is being respected and properly attributed, but this is a relatively minor concern in these cases because the mathematical concepts being illustrated or coded originate from the human author, who has the expertise to provide suitable references.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693472")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2026")])]

#text("I see roughly three ways of using AI in programming:")

#enum(start: 1, 
[#text("Writing the code entirely by hand, without AI assistance during implementation, perhaps using AI only afterward for debugging.")],
[#text("Writing the code oneself but using tools such as Copilot for assistance—for example, autocompleting tedious or routine parts.")],
[#text("Outsourcing most of the implementation to AI and mainly reviewing, testing, or correcting the resulting code afterward.")]
)

#text("I’m curious whether your practice in Lean and Python tends to fall into one of these categories, or whether you use a different workflow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2026")])]

#text("These warnings might have been appropriate even 6 months ago, when coding agents were still less capable than humans. However, today there are many use cases that violate almost every item on that checklist, and even in those cases, using LLMs should be an absolute requirement. For example, any competent person working on mission-critical systems would be failing in their duty if they did not use LLMs to write and review code. In any codebase where security matters, LLMs are essential, because security has always been a huge liability at the mercy of human hands.")

#text("I think we have to recognize the big difference between what “vibecoding” entails and what software developers actually do when working with AI models. The work of software developers is not about one-off, only for personal use, disposable scripts with no tests or validation, generated in casual settings. If software developers tried to comply with the permitted use cases in this checklist, the only risk they would have to contend with is losing their job.")

#text("Even people who write code for a living have difficulty grasping the glaring deficiencies in human-generated code, so it is no wonder there is a generalized apprehension about letting an LLM do that job. That said, nobody who values their employment is letting the LLM run unrestricted, as this post implies.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("I would say that my own profession of mathematicians is significantly more than six months behind the software engineering profession right now with regards to median uptake of coding agents and adoption of current best practices. I do hope that over time the responsible use of AI in higher-risk situations becomes standardized, but at present there are enough early adopters of the technology in mathematics using them without sufficient awareness of downsides that caution is still advisable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693584")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Absolutely. Actually, best practices seem to elude most professions, including a large number of software developers. Honestly, many people have to learn the dos and don’ts the hard way, not in high-stakes situations, of course, but by dealing with unexpected inconveniences. Also, the desire to adopt a new technology is not fully compatible with using it only in the least important scenarios. People need to figure out how to handle it, even in riskier situations. Eventually, this leads to embracing better habits (version control, backups, test-driven development, sandboxing, working with specs, setting file permissions, result verification, and so on).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693492")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("Apply criteria 1-5 to the use of calculators. The same kind of arguments were made.")

#text("(not necessarily disagreeing with those criteria in principle, just that they will not be followed in general)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693725")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2026")])]

#text("Hi Prof. Tao,")

#text("I’d like to add what I learned from software construction courses, that software not only needs to be safe today, but also safe in the unknown future. That especially relates to your 1 and 2 of the five principles.")

#text("One feature of modern software engineering is that a large portion of modern software systems are built with software reuse. A piece of software that is standalone and non-critical now may be used unexpectedly in the unknown future, especially when it becomes popular and people wants to modify/expand on it. Therefore, it is very important for software to come with some formal specification that encodes a rather precise understanding of what the software aims to achieve.")

#text("It is unclear to me how well LLM coding agents could generate such formal specifications for their output code, but so much is at least clear, that we will need to additionally verify their spec against their code, by which we will have to read their code anyway, a process that may outweight the benefit of having an agent coding for us in the first place.")

#text("Even if the original author who used the agent has no intention of the software being reused, whoever later decides to reuse it needs to conduct these steps, if that person wants the end product to be safe or correct.")

#text("Therefore, based on what I have learned, it seems that using agents creates a burden of still having to understand (verifying the software against a spec) the code, if the software is to be reused at all in the unknown future.")

#text("What do you think?")

#text("Guanyuming He")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/16/two-more-apps-visualizing-the-zeta-process-and-the-motions-of-the-heavens/#comment-693730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("My view is that now that we are in an era where code is very cheap to generate, many situations in which code re-use was previously warranted will be replaced by concept re-use instead; legacy code artefacts can still be mined for some structural insights, but it will likely be more efficient (and safer) to rewrite the code from scratch, using the preferred language, style conventions, programming practices, etc. of the modern project rather than import any technical debt from the legacy project. For instance, I have upstreamed some results to Mathlib that were first proven with some AI assistance, but while the AI proofs were useful for showing the general structure and pain points of the overall argument, it was still preferable to rewrite the code manually in many places, using the AI proofs merely as inspiration.")

#text("In each of my own apps coded via agents, I have also recorded a summmary of my conversation with that agent in which we discussed the specification and intent of the app, and in the cases where some usable output was generated (such as a JSON), I also directed the app to generate a detailed description of the output format (see the tab below the app in ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html")[#text("https://teorth.github.io/tao-web/apps/paper-diagram.html")]#text(" for an example). This seems sufficient for other humans or code agents to interface with the app (or build variants of it if necessary); having the original source code available as a reference can also be helpful but is not as crucial as it used to be, in my opinion.")
]
]
