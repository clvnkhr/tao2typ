// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/
// Converted to Typst by tao2typ: "2026-10-14T16:38:51.815864+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Foundational aspects of uncountable measure theory: Gelfand duality, Riesz representation, canonical models, and canonical disintegration", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Foundational aspects of uncountable measure theory: Gelfand duality, Riesz representation, canonical models, and canonical disintegration")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 October 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/")[#text("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://asgarjam.wixsite.com/home")[#text("Asgar Jamneshan")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2010.00681")[#text("Foundational aspects of uncountable measure theory: Gelfand duality, Riesz representation, canonical models, and canonical disintegration")]#text("“. This paper arose from our longer-term project to systematically develop “uncountable” ergodic theory – ergodic theory in which the groups acting are not required to be countable, the probability spaces one acts on are not required to be standard Borel, or Polish, and the compact groups that arise in the structural theory (e.g., the theory of group extensions) are not required to be separable. One of the motivations of doing this is to allow ergodic theory results to be applied to ultraproducts of finite dynamical systems, which can then hopefully be transferred to establish combinatorial results with good uniformity properties. An instance of this is the uncountable Mackey-Zimmer theorem, discussed in ")#link("https://terrytao.wordpress.com/2020/10/01/an-uncountable-mackey-zimmer-theorem/")[#text("this companion blog post")]#text(".")

#text("In the course of this project, we ran into the obstacle that many foundational results, such as the ")#link("https://en.wikipedia.org/wiki/Riesz%E2%80%93Markov%E2%80%93Kakutani_representation_theorem")[#text("Riesz representation theorem")]#text(", often require one or more of these countability hypotheses when encountered in textbooks. Other technical issues also arise in the uncountable setting, such as the need to distinguish the ")#link("https://en.wikipedia.org/wiki/Borel_set")[#text("Borel ")#mi("{\\sigma}")#text("-algebra")]#text(" from the (two different types of) ")#link("https://en.wikipedia.org/wiki/Baire_set")[#text("Baire ")#mi("{\\sigma}")#text("-algebra")]#text(". As such we needed to spend some time reviewing and synthesizing the known literature on some foundational results of “uncountable” measure theory, which led to this paper. As such, most of the results of this paper are already in the literature, either explicitly or implicitly, in one form or another (with perhaps the exception of the canonical disintegration, which we discuss below); we view the main contribution of this paper as presenting the results in a coherent and unified fashion. In particular we found that the language of category theory was invaluable in clarifying and organizing all the different results. In subsequent work we (and some other authors) will use the results in this paper for various applications in uncountable ergodic theory.")

#text("The foundational results covered in this paper can be divided into a number of subtopics (Gelfand duality, Baire ")#mi("{\\sigma}")#text("-algebras and Riesz representation, canonical models, and canonical disintegration), which we discuss further below the fold.")

#metadata(none) <tao-a5f4607409e86b536654>

#heading(level: 1)[#strong[#text(" — 1. Gelfand duality — ")]]

#text("Given a compact Hausdorff space ")#mi("{X}")#text(", one can form the space ")#mi("{C(X)}")#text(" of continuous functions from ")#mi("{X}")#text(" to ")#mi("{{\\bf C}}")#text("; such functions are necessarily bounded and compactly supported, and they form a commutative unital ")#link("https://en.wikipedia.org/wiki/C*-algebra")[#mi("{C^*}")#text("-algebra")]#text(". Conversely, given a commutative unital ")#mi("{C^*}")#text("-algebra ")#mi("{{\\mathcal A}}")#text(", one can produce the ")#emph[#text("Gelfand spectrum")]#text(" ")#mi("{\\mathtt{Spec}({\\mathcal A})}")#text(", which we define here as the collection of unital ")#mi("{C^*}")#text("-homomorphisms ")#mi("{\\lambda \\colon {\\mathcal A} \\rightarrow {\\bf C}}")#text(" from ")#mi("{{\\mathcal A}}")#text(" to ")#mi("{{\\bf C}}")#text(". This spectrum can be viewed as a subset of ")#mi("{{\\bf C}^{\\mathcal A}}")#text(" and inherits a topology from the product topology on that latter space that turns the spectrum into a compact Hausdorff space. The classical ")#link("https://en.wikipedia.org/wiki/Gelfand_representation")[#text("Gelfand duality")]#text(" between compact Hausdorff spaces and unital commutative ")#mi("{C^*}")#text("-algebras asserts that these two operations ")#mi("{X \\mapsto C(X)}")#text(" and ")#mi("{{\\mathcal A} \\mapsto \\mathtt{Spec}(A)}")#text(" “essentially invert” each other: ")#mi("{\\mathtt{Spec}(C(X))}")#text(" is homeomorphic to ")#mi("{X}")#text(", and ")#mi("{C(\\mathtt{Spec}({\\mathcal A}))}")#text(" is isomorphic as a commutative unital ")#mi("{C^*}")#text("-algebra to ")#mi("{{\\mathcal A}}")#text(". In fact there is a more precise statement: the operations ")#mi("{C}")#text(", ")#mi("{\\mathtt{Spec}}")#text(" are in fact contravariant functors that form a ")#link("https://en.wikipedia.org/wiki/Equivalence_of_categories")[#text("duality of categories")]#text(" between the category ")#mi("{\\mathbf{CH}}")#text(" of compact Hausdorff spaces and the category ")#mi("{\\mathbf{CC^*Alg}_1}")#text(" of commutative unital ")#mi("{C^*}")#text("-algebras. This duality of categories asserts, roughly speaking, that the operations ")#mi("{C}")#text(", ")#mi("{\\mathtt{Spec}}")#text(" and the Gelfand duality isomorphisms interact in the “natural” fashion with respect to morphisms: for instance, any continuous map ")#mi("{T: X \\rightarrow Y}")#text(" between compact Hausdorff spaces induces a commutative unital ")#mi("{C^*}")#text("-homomorphism ")#mi("{C(T): C(Y) \\rightarrow C(X)}")#text(" defined by the pullback map ")#mi("{C(T) f := f \\circ T}")#text(", and similarly any commutative unital ")#mi("{C^*}")#text("-homomorphism ")#mi("{\\Phi: {\\mathcal A} \\rightarrow {\\mathcal B}}")#text(" induces a continuous map ")#mi("{\\mathtt{Spec}(\\Phi): \\mathtt{Spec}({\\mathcal B}) \\rightarrow \\mathtt{Spec}({\\mathcal A})}")#text(" defined by ")#mi("{\\mathtt{Spec}(\\Phi) \\lambda := \\lambda \\circ \\Phi}")#text(", and the homeomorphisms between ")#mi("{X}")#text(" and ")#mi("{\\mathtt{Spec}(C(X))}")#text(" and between ")#mi("{Y}")#text(" and ")#mi("{\\mathtt{Spec}(C(Y))}")#text(" commute with the continuous maps ")#mi("{T: X \\rightarrow Y}")#text(" and ")#mi("{\\mathtt{Spec}(C(T)): \\mathtt{Spec}(C(X)) \\rightarrow \\mathtt{Spec}(C(Y))}")#text(" in the “")#link("https://en.wikipedia.org/wiki/Natural_transformation")[#text("natural")]#text("” fashion. These sorts of properties are routine to verify and mostly consist of expanding out all the definitions.")

#text("It is natural to ask what the analogous Gelfand duality is for ")#emph[#text("locally")]#text(" compact Hausdorff spaces. Somewhat confusingly, there appeared to be two such Gelfand dualities in the literature, which appeared at first glance to be incompatible with each other. Eventually we understood that there were ")#emph[#text("two")]#text(" natural categories of locally compact Hausdorff spaces, and dually there were ")#emph[#text("two")]#text(" natural categories of (non-unital) commutative ")#mi("{C^*}")#text(" algebras dual to them:")

#list(
[#text("The category ")#mi("{\\mathbf{LCH}}")#text(" of locally compact Hausdorff spaces, whose morphisms consist of arbitrary continuous maps between those spaces.")],
[#text("The subcategory ")#mi("{\\mathbf{LCH}_p}")#text(" of locally compact Hausdorff spaces, whose morphisms consist of continuous ")#link("https://en.wikipedia.org/wiki/Proper_map")[#text("proper")]#text(" maps between those spaces.")],
[#text("The category ")#mi("{\\mathbf{CC^*Alg}_{nd}}")#text(" of commutative ")#mi("{C^*}")#text(" algebras (not necessarily unital), whose morphisms were ")#mi("{C^*}")#text(" homomorphisms ")#mi("{\\Phi: \\mathcal{A} \\rightarrow \\mathcal{B}}")#text(" which were non-degenerate in the sense that ")#mi("{\\Phi({\\mathcal A}){\\mathcal B}}")#text(" is dense in ")#mi("{{\\mathcal B}}")#text(" (this was automatic in the unital case, but now needs to be imposed as an additional hypothesis).")],
[#text("The larger category ")#mi("{\\mathbf{CC^*Alg}_{nd,\\mathtt{Mult}}}")#text(" of commutative ")#mi("{C^*}")#text(" algebras (not necessarily unital), whose morphisms were non-degenerate ")#mi("{C^*}")#text(" homomorphisms ")#mi("{\\Phi: \\mathcal{A} \\rightarrow \\mathtt{Mult}(\\mathcal{B})}")#text(" into the ")#link("https://en.wikipedia.org/wiki/Multiplier_algebra")[#text("multiplier algebra")]#text(" ")#mi("{\\mathtt{Mult}(\\mathcal{B})}")#text(" of ")#mi("{\\mathcal{B}}")#text(". (It is not immediately obvious that one can compose two such morphisms together, but it can be shown that every such homomorphism has a unique extension to a homomorphism from ")#mi("{\\mathtt{Mult}(\\mathcal{A})}")#text(" to ")#mi("{\\mathtt{Mult}(\\mathcal{B})}")#text(", which can then be used to create a composition law.)")]
)

#text("The map ")#mi("{X \\mapsto C_0(X)}")#text(" that takes a locally compact space to the space of continuous functions that vanish at infinity, together with the previously mentioned Gelfand spectrum map ")#mi("{{\\mathcal A} \\rightarrow \\mathtt{Spec}({\\mathcal A})}")#text(", then forms a duality of categories between ")#mi("{\\mathbf{LCH}_p}")#text(" and ")#mi("{\\mathbf{CC^*Alg}_{nd}}")#text(", and between ")#mi("{\\mathbf{LCH}}")#text(" and ")#mi("{\\mathbf{CC^*Alg}_{nd,\\mathtt{Mult}}}")#text(". Furthermore, these dualities of categories interact well with the two standard compactifications of locally compact spaces: the ")#link("https://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Cech compactification")]#text(" ")#mi("{X \\mapsto \\beta X}")#text(", and the ")#link("https://en.wikipedia.org/wiki/Alexandroff_extension")[#text("Alexandroff compactification")]#text(" ")#mi("{X \\mapsto \\mathtt{Alex}(X)}")#text(" (also known as the one point compactification). From a category theoretic perspective, it is most natural to interpret ")#mi("{\\beta: \\mathbf{LCH} \\rightarrow \\mathbf{CH}}")#text(" as a functor from ")#mi("{\\mathbf{LCH}}")#text(" to ")#mi("{\\mathbf{CH}}")#text(", and to interpret ")#mi("{\\mathtt{Alex}: \\mathbf{LCH}_p \\rightarrow (\\mathrm{pt} \\downarrow \\mathbf{CH})}")#text(" as a functor from ")#mi("{\\mathbf{LCH}_p}")#text(" to the category ")#mi("{(\\mathrm{pt} \\downarrow \\mathbf{CH})}")#text(" of pointed compact Hausdorff spaces (the notation here is a special case of ")#link("https://en.wikipedia.org/wiki/Comma_category")[#text("comma category")]#text(" notation). (Note in particular that a continuous map ")#mi("{T: X \\rightarrow Y}")#text(" between locally compact Hausdorff spaces needs to be proper in order to guarantee a continuous extension ")#mi("{\\mathtt{Alex}(T): \\mathtt{Alex}(X) \\rightarrow \\mathtt{Alex}(Y)}")#text(" to the Alexandroff compactification, whereas no such properness condition is needed to obtain a continuous extension ")#mi("{\\beta T \\colon \\beta X \\rightarrow \\beta Y}")#text(" to the Stone-Cech compactification.) In our paper, we summarized relationships between these functors (and some other related functors) in the following diagram, which commutes up to natural isomorphisms:")

#image("../assets/233d012084ed84eb959ab2a0ea67d999fb8f0851c87eacad8b251ceac27044e1-18a3343cc053f39ae2fe7983bd661f3b8faaa2ba03733f38a318828fb5ecedb5.png", width: 90%)

#text("Thus for instance the space ")#mi("{C_b(X)}")#text(" of bounded continuous functions on a locally compact Hausdorff space ")#mi("{X}")#text(" is naturally isomorphic to the multiplier algebra of ")#mi("{C_0(X)}")#text(", and the Stone-Cech compactification ")#mi("{\\beta X}")#text(" is naturally identified with the Gelfand spectrum of ")#mi("{C_b(X)}")#text(": ")#metadata(none) <tao-d4f02eaafd1a9e9de7d1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\beta X \\equiv \\mathtt{Spec}(C_b(X)).")]]

#text(" ")#text(" The coloring conventions in this paper are that (a) categories of “algebras” are displayed in red (and tend to be dual to categories of “spaces”, displayed in black; and (b) functors displayed in blue will be considered “casting functors” (analogous to ")#link("https://en.wikipedia.org/wiki/Type_conversion")[#text("type casting operators")]#text(" in various computing languages), and are used as the default way to convert an object or morphism in one category to an object or morphism in another. For instance, if ")#mi("{X}")#text(" is a compact Hausdorff space, the associated unital commutative ")#mi("{C^*}")#text("-algebra ")#mi("{X_{\\mathbf{CC^*Alg}_1}}")#text(" is defined to be ")#mi("{C(X)}")#text(" by the casting convention.")

#text("Almost every component of the above diagram was already stated somewhere in the literature; our main contribution here is the synthesis of all of these components together into the single unified diagram.")

#heading(level: 1)[#strong[#text(" — 2. Baire ")#mi("{\\sigma}")#text("-algebras and Riesz duality — ")]]

#text("Now we add measure theory to Gelfand duality, by introducing ")#mi("{\\sigma}")#text("-algebras and probability measures on the (locally) compact Hausdorff side of the duality, and by introducing traces on the ")#mi("{C^*}")#text("-algebra side. Here we run into the issue that there are ")#emph[#text("three")]#text(" natural choices of ")#mi("{\\sigma}")#text("-algebra one can assign to a topological space ")#mi("{X}")#text(":")

#list(
[#text("The ")#link("https://en.wikipedia.org/wiki/Borel_set")[#text("Borel ")#mi("{\\sigma}")#text("-algebra")]#text(", generated by the open (or closed) subsets of ")#mi("{X}")#text(".")],
[#text("The ")#link("https://en.wikipedia.org/wiki/Baire_set")[#mi("{C_b}")#text("-Baire ")#mi("{\\sigma}")#text("-algebra")]#text(", generated by the bounded continuous functions on ")#mi("{X}")#text(" (equivalently, one can use arbitrary continuous functions on ")#mi("{X}")#text("; these are also precisely the sets whose indicator functions are ")#link("https://en.wikipedia.org/wiki/Baire_function")[#text("Baire functions")]#text(" with respect to a countable ordinal).")],
[#text("The ")#link("https://en.wikipedia.org/wiki/Baire_set")[#mi("{C_c}")#text("-Baire ")#mi("{\\sigma}")#text("-algebra")]#text(", generated by the compactly supported continuous functions on ")#mi("{X}")#text(" (equivalently, one can use continuous functions on ")#mi("{X}")#text(" going to zero at infinity; these are also precisely the sets generated by compact ")#mi("{G_\\delta}")#text(" sets).")]
)

#text("For compact Hausdorff spaces, the two types of Baire ")#mi("{\\sigma}")#text("-algebras agree, but they can diverge for locally compact Hausdorff spaces. Similarly, the Borel and Baire algebras agree for compact metric spaces, but can diverge for more “uncountable” compact Hausdorff spaces. This is most dramatically exemplified by the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=100909")[#text("Nedoma pathology")]#text(", in which the Borel ")#mi("{\\sigma}")#text("-algebra of the Cartesian square ")#mi("{K \\times K}")#text(" of a locally compact Hausdorff space ")#mi("{K}")#text(" need not be equal to the product of the individual Borel ")#mi("{\\sigma}")#text("-algebra, in contrast to the Baire ")#mi("{\\sigma}")#text("-algebra which reacts well with the product space construction (even when there are uncountably many factors). In particular, the group operations on a locally compact Hausdorff group can fail to be Borel measurable, even though they are always Baire measurable. For these reasons we found it desirable to adopt a “Baire-centric” point of view, in which one prefers to use the Baire ")#mi("{\\sigma}")#text("-algebras over the Borel ")#mi("{\\sigma}")#text("-algebras in compact Hausdorff or locally compact Hausdorff settings. (However, in Polish spaces it seems Borel ")#mi("{\\sigma}")#text("-algebras remain the more natural ")#mi("{\\sigma}")#text("-algebra to use.) It turns out that the two Baire ")#mi("{\\sigma}")#text("-algebras can be divided up naturally between the two categories ")#mi("{\\mathbf{LCH}, \\mathbf{LCH}_p}")#text(" of locally compact Hausdorff spaces, with the ")#mi("{C_c}")#text("-Baire ")#mi("{\\sigma}")#text("-algebra naturally associated to ")#mi("{\\mathbf{LCH}_p}")#text(" and the ")#mi("{C_b}")#text(" ")#mi("{\\sigma}")#text("-algebra naturally associated to ")#mi("{\\mathbf{LCH}}")#text(". The situation can be summarized by the following commuting diagram of functors between the various categories of (locally) compact Hausdorff spaces and the category ")#mi("{\\mathbf{ConcMes}}")#text(" of concrete measurable spaces (sets equipped with a ")#mi("{\\sigma}")#text("-algebra):")

#image("../assets/a2bec2d1d1e0601c8d51ebce97a2ef39b644fc2d35c8f06f0dd940fe58da1bd8-aee6b0953ab9365c9af969ef2bcafee9d3e742d544df9267781b27bf483ae72c.png", width: 90%)

#text("To each category of (locally) compact Hausdorff spaces, we can then define an associated category of (locally) compact Hausdorff spaces equipped with a Radon probability measure, where the underlying ")#mi("{\\sigma}")#text("-algebra is as described above, and “Radon” means “compact ")#mi("{G_\\delta}")#text("-inner regular”. For instance, ")#mi("{\\mathbf{CHPrb}}")#text(" is the category of compact Hausdorff spaces equipped with a Baire probability measure ")#mi("{\\mu}")#text(" with the inner regularity property")

#align(center)[#tao-fit-display[#mitex("\\mu(E) = \\sup \\{ \\mu(F): F \\subset E, F \\text{ is } G_\\delta \\},")]]

#text("and one similarly defines ")#mi("{\\mathbf{LCHPrb}}")#text(", ")#mi("{\\mathbf{LCH}_p \\mathbf{Prb}}")#text(", ")#mi("{(\\mathrm{pt} \\downarrow \\mathbf{CH})\\mathbf{Prb}}")#text(". (In the compact Hausdorff case the inner regularity property is in fact automatic, but in locally compact Hausdorff categories it needs to be imposed as an explicit hypothesis.) On the ")#mi("{C^*}")#text("-algebra side, categories such as ")#mi("{\\mathbf{CC^*Alg}_1}")#text(" can be augmented to tracial categories ")#mi("{\\mathbf{CC^*Alg}_1^\\tau}")#text(" where the ")#mi("{C^*}")#text(" algebra ")#mi("{{\\mathcal A}}")#text(" is now equipped with a trace ")#mi("{\\tau: {\\mathcal A} \\rightarrow {\\bf C}}")#text(", that is to say a non-negative linear functional of operator norm ")#mi("{1}")#text(". It then turns out that the Gelfand spectrum functors ")#mi("{\\mathtt{Spec}}")#text(" from ")#mi("{C^*}")#text("-algebras to (locally) compact Hausdorff spaces can be augmented to “Riesz functors” ")#mi("{\\mathtt{Riesz}}")#text(" from tracial ")#mi("{C^*}")#text("-algebras to (locally) compact Hausdorff spaces with Radon probability measures, where the probability measure in question is given by some form of the Riesz representation theorem; dually, the ")#mi("{C_0}")#text(" functors can similarly be augmented using the Lebesgue integral with respect to the given measure as the trace. This leads one to a complete analogue of the previous diagram of functors, but now in tracial and probabilistic categories, giving a new set of Gelfand-like dualities that we call “Riesz duality”:")

#image("../assets/c3d9483113ee75a942719ea154121f0b70d1c746608ff0e41f337af0eabd9e96-e9e161e5a9510f3416b5ee4ecca45a95a2c93a65f43dba86042ef8fa13c87cd7.png", width: 90%)

#text("Again, each component of this diagram was essentially already in the literature in either explicit or implicit form. In the paper we also review the Riesz representation theory for traces on ")#mi("{C_b(X)}")#text(" rather than ")#mi("{C_c(X)}")#text(", in which an additional “")#mi("{\\tau}")#text("-smoothness” property is needed in order to recover a Radon probability measure on ")#mi("{X}")#text(". The distinction between Baire and Borel ")#mi("{\\sigma}")#text("-algebras ends up being largely elided in the Riesz representation theory, as it turns out that every Baire-Radon probability measure (using either of the two Baire algebras) on a locally compact Hausdorff has a unique extension to a Borel-Radon probability measure (where for Borel measures, the Radon property is now interpreted as “compact inner regular” rather than “compact ")#mi("{G_\\delta}")#text(" inner regular”).")

#heading(level: 1)[#strong[#text(" — 3. The canonical model of opposite probability algebras — ")]]

#text("Given a concrete probability space ")#mi("{X = (X_{\\mathbf{Set}}, X_{\\mathbf{Bool}_\\sigma}, \\mu_X)}")#text(" – a set ")#mi("{X_{\\mathbf{Set}}}")#text(" equipped with a ")#mi("{\\sigma}")#text("-algebra ")#mi("{X_{\\mathbf{Bool}_\\sigma}}")#text(" and a probability measure ")#mi("{\\mu_X \\colon X_{\\mathbf{Bool}_\\sigma} \\rightarrow [0,1]}")#text(" – one can form the associated ")#emph[#text("probability algebra")]#text(" ")#mi("{(X_{\\mathbf{Bool}_\\sigma}/{\\mathcal N}, \\mu_X/{\\sim})}")#text(" by quotienting the ")#mi("{\\sigma}")#text("-algebra ")#mi("{X_{\\mathbf{Bool}_\\sigma}}")#text(" by the null ideal ")#mi("{{\\mathcal N} := \\{ E \\in X_{\\mathbf{Bool}_\\sigma}: \\mu_X(E)=0\\}}")#text(" and then similarly quotienting the measure ")#mi("{\\mu_X}")#text(" to obtain an abstract countably additive probability measure ")#mi("{\\mu_X/{\\sim}: X_{\\mathbf{Bool}_\\sigma}/{\\mathcal N} \\rightarrow [0,1]}")#text(". More generally, one can consider abstract probability algebras ")#mi("{({\\mathcal B}, \\mu)}")#text(" where ")#mi("{{\\mathcal B}}")#text(" is a ")#mi("{\\sigma}")#text("-complete Boolean algebra and ")#mi("{\\mu: {\\mathcal B}\\rightarrow [0,1]}")#text(" is a countably additive probability measure with the property that ")#mi("{\\mu(E)>0}")#text(" whenever ")#mi("{E \\neq 0}")#text(". This gives a category ")#mi("{\\mathbf{ProbAlg}}")#text(". Actually to align things closer to the category of concrete probability spaces ")#mi("{\\mathbf{ConcPrb}}")#text(", it is better to work with the ")#link("https://en.wikipedia.org/wiki/Opposite_category")[#text("opposite category")]#text(" ")#mi("{\\mathbf{ProbAlg}^{op}}")#text(" of opposite probability algebras ")#mi("{({\\mathcal B}, \\mu)^{op}}")#text(" where the directions of the morphisms are reversed.")

#text("Many problems and concepts in ergodic theory are best phrased “up to null sets”, which can be interpreted category-theoretically by applying a suitable functor from a concrete category such as ")#mi("{\\mathbf{ConcPrb}}")#text(" to the opposite probability algebra category ")#mi("{\\mathbf{ProbAlg}^{op}}")#text(" to remove all the null sets. However, it is sometimes convenient to reverse this process and ")#emph[#text("model")]#text(" an opposite probability algebra by a more concrete probability space, and to also model morphisms ")#mi("{T: ({\\mathcal A}, \\mu) \\rightarrow ({\\mathcal B}, \\nu)}")#text(" between opposite probability algebras (")#mi("{\\sigma}")#text("-complete Boolean homomorphisms from ")#mi("{{\\mathcal B}}")#text(" to ")#mi("{{\\mathcal A}}")#text(" that preserve measure) by concrete maps. Ideally the model spaces should also be compact Hausdorff spaces, and the model morphisms continuous maps, so that methods from ")#link("https://en.wikipedia.org/wiki/Topological_dynamics")[#text("topological dynamics")]#text(" may be applied. There are various ")#emph[#text("ad hoc")]#text(" ways to create such models in “countable” settings, but it turns out that there is a canonical and “universal” model ")#mi("{\\mathtt{Conc}(X)}")#text(" of any opposite probability algebra ")#mi("{X}")#text(" that one can construct in a completely functorial setting (so that any dynamics on the opposite probability algebra ")#mi("{X}")#text(" automatically carry over to concrete dynamics on ")#mi("{\\mathtt{Conc}(X)}")#text("). The quickest way to define this model is by the formula")

#align(center)[#tao-fit-display[#mitex("\\mathtt{Conc}(X) \\equiv \\mathtt{Riesz}(L^\\infty(X))")]]

#text("(compare with ")#link(<tao-d4f02eaafd1a9e9de7d1>)[#text("(1)")]#text("), where ")#mi("{L^\\infty(X)}")#text(" is the space of bounded abstractly measurable maps from ")#mi("{X}")#text(" to ")#mi("{{\\bf C}}")#text(", which one can imbue with the structure of a tracial unital commutative ")#mi("{C^*}")#text("-algebra. This gives a (covariant full inclusion) functor from ")#mi("{\\mathbf{ProbAlg}^{op}}")#text(" to ")#mi("{\\mathbf{CHPrb}}")#text(" that has many pleasant properties, including:")

#list(
[#text("(Topological structure) ")#mi("{\\mathtt{Conc}(X)}")#text(" is a compact Hausdorff space. In fact it is a ")#link("https://en.wikipedia.org/wiki/Stone_space")[#text("Stone space")]#text(" with the additional property that every Baire-measurable set is equal to a clopen set modulo a Baire-")#link("https://en.wikipedia.org/wiki/Meagre_set")[#text("meager")]#text(" set (such spaces we call ")#mi("{\\textbf{Stone}_\\sigma}")#text("-spaces in our paper). Furthermore a Baire set is null if and only if it is meager. Any opposite probability algebra morphism ")#mi("{T: X \\rightarrow Y}")#text(" gives rise (in a functorial fashion) to a surjective continuous map ")#mi("{\\mathtt{Conc}(T): \\mathtt{Conc}(X) \\rightarrow \\mathtt{Conc}(Y)}")#text(" with the additional property that the inverse image of Baire-meager sets are Baire-meager. Furthermore, one has the (somewhat surprising) “strong Lusin property”: every element of ")#mi("{L^\\infty(\\mathtt{Conc}(X))}")#text(" has a unique representative in ")#mi("{C(\\mathtt{Conc}(X))}")#text(" (thus, every bounded measurable function on ")#mi("{\\mathtt{Conc}(X)}")#text(" is equal almost everywhere to a unique continuous function).")],
[#text("(Concrete model) The opposite probability algebra of ")#mi("{\\mathtt{Conc}(X)}")#text(" is (naturally) isomorphic to ")#mi("{X}")#text(".")],
[#text("(Universality) There is a natural inclusion (in the category ")#mi("{\\mathbf{AbsPrb}}")#text(" of abstract probability spaces) from ")#mi("{\\mathtt{Inc}(X)}")#text(" (which is ")#mi("{X}")#text(" interpreted in ")#mi("{\\mathbf{AbsPrb}}")#text(") into ")#mi("{\\mathtt{Conc}(X)}")#text(", which is universal amongst all inclusions of ")#mi("{\\mathtt{Inc}(X)}")#text(" into compact Hausdorff probability spaces.")],
[#text("(Canonical extension) Every abstractly measurable map from ")#mi("{\\mathtt{Inc}(X)}")#text(" to a compact Hausdorff space ")#mi("{K}")#text(" has a unique extension to a continuous map from ")#mi("{\\mathtt{Conc}(X)}")#text(" to ")#mi("{K}")#text(".")]
)

#text("This canonical model ")#mi("{\\mathtt{Conc}}")#text(" seems quite analogous to the Stone-Cech compactification ")#mi("{\\beta}")#text(". For instance the analogue of the canonical extension property for ")#mi("{\\beta}")#text(" is that every continuous map from a locally compact space ")#mi("{X}")#text(" to a compact Hausdorff space ")#mi("{K}")#text(" has a unique extension to a continuous map from ")#mi("{\\beta X}")#text(" to ")#mi("{K}")#text(". In both cases the model produced is usually too “large” to be separable, so this is a tool that is only available in “uncountable” frameworks.")

#text("There is an alternate description of the canonical model, which is basically due ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2459668")[#text("to Fremlin")]#text(", and is based on Stone-type dualities rather than Riesz type dualities. Namely, one starts with the ")#mi("{\\sigma}")#text("-complete Boolean algebra attached to the opposite probability space ")#mi("{X}")#text(", and constructs its Stone dual, which is a ")#mi("{\\mathbf{Stone}_\\sigma}")#text(" space. Every Baire set in this space is equal modulo Baire-meager sets to a clopen set, which by Stone duality is identifiable with an element of the probability algebra. The measure on ")#mi("{X}")#text(" then induces a measure on the ")#mi("{\\mathbf{Stone}_\\sigma}")#text("-space, and this compact Hausdorff probability space can serve as the canonical model ")#mi("{\\mathtt{Conc}(X)}")#text(". The functoriality of this construction is closely tied to the functoriality of the Loomis-Sikorski theorem (discussed in ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("this previous blog post")]#text("). The precise connection in terms of functors and categories is a little complicated to describe, though, as the following diagram indicates:")

#image("../assets/95a46dcdc4ddce921a6cf46d87db54fc91619609c02a9b5062aebc44f30f5bd4-7c3993dc9be60802b87feb4ec499f8e548ca2bde76a0e92872d4d400c35ad66a.png", width: 90%)

#text("One quick use of the canonical model is that it allows one to perform a variety of constructions on opposite probability algebras by passing to the canonical model and performing the analogous operation there. For instance, if one wants to construct a product ")#mi("{\\prod_{\\alpha \\in A} X_\\alpha}")#text(" of some number of opposite probability algebras, one can first take the product ")#mi("{\\prod_{\\alpha \\in A} \\mathtt{Conc}(X)}")#text(" of the concrete models (as a compact Hausdorff probability space), then extract the opposite probability algebra of that space. We will similarly use this model to construct group skew-products and homogeneous skew-products in a later paper.")

#heading(level: 1)[#strong[#text(" — 4. Canonical disintegration — ")]]

#text("Given a probability space ")#mi("{(X,\\mu_X)}")#text(" and a probability-preserving factor map ")#mi("{\\pi: X \\rightarrow Y}")#text(" from ")#mi("{X}")#text(" to another probability space ")#mi("{(Y,\\mu_Y)}")#text(", it is often convenient to look for a ")#emph[#text("disintegration")]#text(" of ")#mi("{\\mu_X}")#text(" into fibre measures ")#mi("{\\nu_y, y \\in Y}")#text(" with the property that the conditional expectation ")#mi("{{\\bf E}(f|Y)}")#text(" of a function ")#mi("{f \\in L^\\infty(X,\\mu_X)}")#text(" (defined as the orthogonal projection in ")#mi("{L^2}")#text(" to ")#mi("{L^2(Y,\\mu_Y)}")#text(", viewed as a subspace in ")#mi("{L^2(X,\\mu_X)}")#text(") is given pointwise almost everywhere by")

#align(center)[#tao-fit-display[#mitex("{\\bf E}(f|Y) = \\int_X f\\ d\\nu_y.")]]

#text("The construction of such disintegrations originated in the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=30584")[#text("work of Rohlin")]#text("; the standard disintegration theorems require some sort of separability hypotheses on the spaces ")#mi("{X,Y}")#text(" (e.g., that ")#mi("{X}")#text(", ")#mi("{Y}")#text(" be standard Borel spaces) in order to avoid the issue of having to deal with an uncountable number of exceptional null sets. However, with the canonical model one can construct a canonical disintegration that does not require any of these hypotheses; the catch though is that the disintegration is now in the larger model space ")#mi("{\\mathtt{Conc}(X)}")#text(" rather than in the original space ")#mi("{X}")#text(". Namely, because of the strong Lusin property ")#mi("{L^\\infty(\\mathtt{Conc}(Y)) = C(\\mathtt{Conc}(Y))}")#text(", one can interpret the conditional expectation ")#mi("{{\\bf E}(f|Y)(y)}")#text(" of a function ")#mi("{f \\in L^\\infty(\\mathtt{Conc}(X)) = C(\\mathtt{Conc}(X))}")#text(" evaluated at a point ")#mi("{y \\in \\mathtt{Conc}(Y)}")#text(" as a linear functional on ")#mi("{C(\\mathtt{Conc}(X))}")#text(", and the Riesz representation theorem then produces the required measures ")#mi("{\\nu_y}")#text(".")

#text("Among other things, the canonical disintegration makes it easy to construct relative products ")#mi("{X_1 \\times_Y X_2}")#text(" of opposite probability algebras, and we believe it will also be of use in developing uncountable versions of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2150389")[#text("Host-Kra structure theory")]#text(".")

#heading(level: 1)[#text("Comments (37)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9648a759d7ae294ca9054bd4b2909f64d4cbee755a9798697958ab3e9a1f8dc3-ba170c4b7ea635c1c28b0f3e544bba90c4ed7f313bdff32fa9717343b61de79d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593500")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("I was briefly worried that in your categorical account you’d avoided the term “adjoint functor”. I was glad to see that it’s used in the actual paper (even if probably not enough times).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594303")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Yeah, the Stone-Cech compactification, canonical model, and Loomis-Sikorski functors are all left-adjoint to “forgetful functors” (or more precisely “casting functors”, since one can quibble as to whether actions such as passing from concrete to point-free frameworks and then quotienting out null sets counts as “forgetting structure”). In particular this deepens the analogy between the canonical model and the Stone-Cech compactification. I could imagine that some of the other universality properties of the canonical model that we list are simply abstract nonsense consequences of this adjunction, but in any case we found it instructive to work them out in a more pedestrian fashion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593505")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("This is so heavy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593554")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("It is a neat result that a ")#mi("C^*")#text("-algebra always admits a second topology (in addition to the Banach topology), the *strict* topology, and that the underlying vector space of the multiplier algebra is the completion in this topology. Even better, the two vector space topologies are compatible, making what Cooper calls a “Saks space”, and the multiplier algbra is the Saks space completion. Cooper also defined (commutative) *Saks algebras*, and commutative ")#mi("C^*")#text("-algebras give rise to these in this way, and then the multiplier algebra is the Saks *algebra* completion. This is (as one could expect, a functorial operation. All of this is in the commutative case; the non-commutative case has not been treated, but it is on my long wish-list of things to do, if anyone else finds such a thing interesting.")

#text("The functor from commutative ")#mi("C^*")#text("-algebras to complete (commutative) Saks algebras is what is known as a “relative monad”, and the “larger category” of ")#mi("C^*")#text("-algebras with the more interesting morphisms is the Kleisli category of this relative monad. So the construction of this larger category is in some sense quite formal, since an analogue of the strict topology can be defined on any topological (")#mi("*")#text(")-algebra, in a canonical way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35f2c75c44205a5286380f927e99687e960e14fc3a32990cb417b4f53fda9f36-6cc2c7cbedefa7afb0abe288a54d632911645264c59859e5653f50460dac6b04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fb")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593643")[#strong[#text("fb")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("I think there is a misspell of the author in the Maths Reviews link : it is actually V. A. Rokhlin instead of V. A. Rohlin if I am not mistaken")#linebreak()#text(" (see : ")#link("http://www.mathnet.ru/php/archive.phtml?wshow=paper&jrnid=sm&paperid=5995&option_lang=eng")[#text("http://www.mathnet.ru/php/archive.phtml?wshow=paper&jrnid=sm&paperid=5995&option_lang=eng")]#text(")")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitri")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593707")[#strong[#text("Dmitri")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("The claim about the misspelling is incorrect: the article itself spells it as Rohlin, not Rokhlin. See the scanned PDF file here: ")#link("https://web.archive.org/web/20150722004152/http://ma.huji.ac.il/~matang02/rohlin.pdf")[#text("https://web.archive.org/web/20150722004152/http://ma.huji.ac.il/~matang02/rohlin.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35f2c75c44205a5286380f927e99687e960e14fc3a32990cb417b4f53fda9f36-6cc2c7cbedefa7afb0abe288a54d632911645264c59859e5653f50460dac6b04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fb")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593712")[#strong[#text("fb")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("I do not think; the author is :")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Vladimir_Abramovich_Rokhlin")[#text("https://en.wikipedia.org/wiki/Vladimir_Abramovich_Rokhlin")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593673")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("Are these foundational results based on assuming the standard ZFC set theory?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("Yes, we work in ZFC, and in particular assume the axiom of choice; several Hahn-Banach type extension theorems are implicitly used in order to affirm various dualities such as Stone duality or Gelfand duality. Certainly the Stone-Cech compactification cannot be constructed with the desired properties without the axiom of choice (possibly one might be able to get away with something slightly weaker such as the ultrafilter lemma, but I am not an expert on these subtleties).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of novac")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593676")[#strong[#text("novac")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("Dear Professor")#linebreak()#text(" French typos founded in the last reference of your extraordinary paper [50] (Weil, 1937):")#linebreak()#text(" – a structure —-> à structure")#linebreak()#text(" – sure la topologie —–> sur la topologie")#linebreak()#text(" Your sincerely")

#emph[#text("[Thanks, this will be corrected in the next version of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chen")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593690")[#strong[#text("Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("A minor typo p. 2 : “aforementioned” instead of “above-mentioned”.")

#emph[#text("[This will be changed in the next revision of the ms – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593733")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("How is this a typo")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593768")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("Could you say a bit about the potential combinatorial implications/applications of the longer term program?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2020")])]

#text("One of our primary goals is to be able to establish the inverse conjecture for the Gowers norm and the Host-Kra structure theorem for measure-preserving systems in a unified fashion, as if one takes an “ultraproduct” of the former one gets something that resembles an “uncountable” version of the latter. (The Camarena-Szegedy and Candela-Szegedy proof of the former proceeds somewhat along these lines but falls short of recovering the entirety of the Host-Kra theory.) We also expect this approach to give a strengthened version of the inverse conjecture that has more uniformity properties with respect to the underlying group (or approximate group) with respect to which one is computing the Gowers norm.")

#text("A bit more speculatively, once we have a completely rigorous way to transfer back and forth between additive combinatorics and ergodic theory (beyond the existing Furstenberg correspondence principle, which comes close to, but does not quite manage, to connect the Gowers type theory to the Host-Kra type theory), one could hope to be able to directly apply other deep results in ergodic theory to additive combinatorial settings (as opposed to merely reasoning by analogy, which is basically the current state of affairs). For instance the theory of joinings is a basic tool in ergodic theory which so far has only made a very modest appearance in additive combinatorics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2020")])]

#text("In other words, this program may have the potential to unify several mathematical branches by creating correspondences (or “bridges”) among them.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593771")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("On a style point, definition A.1 is inconsistent with the other usage. “A category Cat is a class of objects (which we refer to as Cat-objects),” conflicts with the long-standing convention in category theory to have “Cat” reserved to refer to the category of (small, say) categories. Saying instead “A category C is a class of objects (which we refer to as C-objects),” will then make more sense. Now C is a placeholder, and the following examples are the cases C=Set and C=Grp. The same is true for Definition A.4 and all the surrounding discussion. And for A.13 etc. It’s even worse there, since functors are the morphisms in Cat, so writing a generic functor as ")#mi("Cat \\to Cat^{\\prime}")#text(", where this is now a morphism in the category of categories, is really, really grating. And it continues. This not a good look.")

#text("This feels like what I imagine it would feel like to a harmonic analysist if a category theorist invented their own notation for objects in analysis that conflicts with decades of established notation. Imagine someone deciding ")#mi("L")#text(" was a good notation for the space of continuous functions, because they preserve limits…).")

#emph[#text("[Good point, this will be changed in the next revision of the ms (fortunately it amounted to changing one line of LaTeX code) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LonYing")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593772")[#strong[#text("LonYing")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("What an incredible paper!!!")#linebreak()#text(" In the bibliography the ref #27 should be yet completed by ‘arXiv:2010.00574 (2020).’ instead of ‘Preprint.’")#linebreak()#text(" Best regards and congratulations for your contribution")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karl")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593773")[#strong[#text("Karl")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("Concerning the ref [50] if a previous post has already pointed out typos in the title, it should be nevertheless corrected as follows: “Publications de l’Institut Mathématique de l’Université de Strasbourg, Vol. 551, Strasbourg, France, (1938).” instead of “Actualités … (1937).”")

#emph[#text("[Thanks, this will be corrected in the next revision of the MS. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-593775")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("in the ref #44 ‘Band’ (in German) ‘Issue’ (in English) if you want to be explicit")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhao")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594033")[#strong[#text("Zhao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2020")])]

#text("In my opinion the preceeding post, which is not very clear, means that if you want to be more explicit for non German readers you should replace in the ref [44] the term “Band” by the term “Issue”.")#linebreak()#text(" Kind regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LeBron")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594036")[#strong[#text("LeBron")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2020")])]

#text("Dear Pr. Dr. Tao,")#linebreak()#text(" In order to be exhaustive, you could add in the bibliography the second corresponding reference of Hewitt & Ross entitled “Abstract Harmonic Analysis. Volume II. …. Springer Verlag”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab92c4f4eb295fee75b8ec51660136a0e4f8d45234545c62e604eb0ad165be33-b8998a25291df0d30b40981f6791d43bb2992808db882ba95a6ef74f66808567.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Knill")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594134")[#strong[#text("Oliver Knill")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("I always had been under the impression that what you can do with countable group actions in ergodic theory can be done in the uncountable case too. There are mechanisms in classical ergodic theory like time one maps or Poincare return maps for example which allow to reduce flows to maps. Also for groups which are inverse limits of groups like p-adic integers one could expect the limit to behave nicely. Also extension of the Mackey Zimmer theorem mentioned in the previous blog entry to the uncountable case confirms also that there is not much new. As a motivation for this part of ergodic theory it would be good to have a concrete example of an uncountable group action on a probability space, where a new ergodic phenomenon happens. The motivation from combinatorics has been mentioned already, but one can suspect that these combinatorial results can be attacked also by traditional ergodic theory of countable group actions once one knows how to do it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594246")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("What seems to be emerging from our investigations is that uncountable ergodic theory closely resembles countable ergodic theory *when set up correctly*, but if one sets things up naively one often runs into pathological counterexamples. For instance, there are various representation theorems (e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=105479")[#text("Maharam-von Neumann")]#text(") for actions of countable groups that roughly speaking allow an abstract action of a countable group on a complete probability space to be modeled by a concrete action on the same space which agrees almost everywhere with the abstract action. But this fails in the uncountable setting, and not just of “pathological” examples: there is a result ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2191233")[#text("of Glasner, Tsirelson, and Weiss")]#text(" that shows that a very natural uncountable group, namely the automorphism group of Gaussian measure, does not act in pointwise fashion on the natural probability space supporting that Gaussian measure. On the other hand, the canonical model given in our paper does give such a pointwise action that is even continuous. The catch is that this action is not on the original probability space, but rather on the Stone space of the underlying probability algebra, which is still compact but is otherwise rather large (in particular, it is not separable or metrisable). Nevertheless this seems to be the “right” concrete model to use in uncountable ergodic theory (we rely on it extensively to prove the uncountable Mackey-Zimmer theorem, for instance).")

#text("In a similar fashion, when working with cocycles taking values in inseparable compact groups we initially assumed naively that we should use the Borel sigma algebra on these groups to perform our analysis, but very quickly ran into the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=100909")[#text("Nedoma pathology")]#text(", which among other things shows that the group options can fail to be Borel measurable, causing huge difficulties. However if one sets up the entire theory using Baire sigma algebras instead of Borel sigma algebras then everything works very nicely, just as in the separable case. (Initially this caused some concern for us because Haar measure is usually defined on the Borel sigma algebra rather than the Baire sigma algebra, but in fact it can be defined on either, with both being equally canonical, because every Baire-Radon probability measure turns out to have a unique Borel-Radon extension.) While these subtleties are perhaps just technicalities, they were somewhat surprising at least to us, and I think the careful untangling of these issues has been edifying (for instance the revelation for us that there were two distinct categories of locally compact Hausdorff spaces which divvied up between them all the various analytic structures of such spaces greatly clarified for us the rather confusing functorial status of basic operations such as the Alexandroff and Stone-Cech compactifications).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594284")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("“The catch is that this action is not on the original probability space, but rather on the Stone space of the underlying probability algebra, which is still compact but is otherwise rather large (in particular, it is not separable or metrisable).”")

#text("This makes me vaguely think that looking at locales might be worthwhile. See for instance discussion at this blog post: ")#link("https://projects.lsv.ens-cachan.fr/topology/?page_id=1597")[#text("https://projects.lsv.ens-cachan.fr/topology/?page_id=1597")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594301")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Yeah, locales are pretty close in spirit to the categories studied here: we play with concrete topological spaces, concrete measurable spaces, and abstract measurable spaces, but we don’t attempt to describe abstract topological spaces, which is what locales are best suited for. One could in particular imagine a completely abstract Riesz representation theorem on certain locales (maybe such a theorem already exists in the literature).")

#text("If one restricts attention to *measurable* locales then one arrives at a category that contains our category of opposite probability algebras (once the actual probability measure is forgotten). There is a Stone and “von Neumann” duality of categories between (measurable) locales and either hyperstonean spaces or commutative von Neumann algebras (not equipped with a trace) that was worked out ")#link("https://arxiv.org/abs/2005.05284")[#text("recently by Pavlov")]#text(". These could be useful if one wished to extend the Riesz representation theorems in this paper to other localizable spaces (and indeed there are already some Riesz representation theorems at this level of generality). We discuss this a bit in Remark 9.3 of the current paper.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c1cf6702093972106d4355d3436ba378ee870e2e6a64ed64addae622cf1efe-722da0096ba8d8c90108df270f0c422e927b95c2aa613a1f88962ed4968409f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asgar Jamneshan")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594270")[#strong[#text("Asgar Jamneshan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("In a forthcoming paper, P. Durcik, R. Greendfeld, A. Iseli and J. Madrid and myself establish an uncountable version of the amenable ergodic Roth theorem of Bergelson, McCutcheon and Zhang, and by using ultraproducts we can derive from this extension that the set of multiple recurrence times of Roth type is uniformly syndetic over a whole class of systems where the acting groups can be taken from a uniformly amenable set of groups. (As was mentioned previously, taking ultraproducts naturally leads to uncountable systems, even for finite systems). As a special case, we obtain a uniform syndeticity result for a class of countable systems with a single uniformly amenable group (e.g., the integers) acting. It is not immediately obvious to us how one could deduce such a combinatorial uniformity result from an ergodic theory for countable group actions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/306e101912caec3b86e0e0d593d48cea2dfc99940f2e72144da868e5f5e953ef-a652ccce1d28119b33e035ec3fb35c7b4d258d595fd62d9467f9892eb5416bef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594149")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Is there any relation to Voevodsky’s category theory work on probability?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594252")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("From what I understand of Voevodsky’s theory, he is working with a category of measurable spaces, in which the morphisms are ")#link("https://en.wikipedia.org/wiki/Transition_kernel")[#text("probability kernels")]#text(" rather than measurable functions. That’s certainly an interesting category (for instance, it is the natural category with which to study Markov processes, which seems to be a key focus of Voevodsky’s work) but we do not use it in this current paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/291eb9a2f8d9143802da9f08082dc2f607bd08a3a89747a7e5ba19e4d07a7ce4-e66ceae8f9faef1713e1f93af3db1e8659550d334d22543291cc512505169f31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594267")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("A second question would be the following natural one. Would this new formulation have any relevance to quantum mechanics where probabilities can be given a complex interpretation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Presumably the framework to consider quantum mechanics would be noncommutative probability, which in our formulation amounts to replacing the category of commutative tracial von Neumann algebras by the category of arbitrary tracial von Neumann algebras. One can also consider noncommutative topology (by similarly removing the requirement of commutativity on the various categories of C^* algebras here). There does seem to be a small amount of literature on, say, noncommutative Riesz representation theorems (e.g., ")#link("https://arxiv.org/abs/math/0606191")[#text("this paper")]#text(") but it does not seem to be an extensively explored subject currently.")

#text("On the other hand it’s not clear to me what the noncommutative analogues of the various dualities in this paper (Gelfand duality, Riesz duality, probability duality, Stone duality) are – it’s reasonably obvious in all the cases what the noncommutative object is on the “algebra” side (one simply removes the requirement that the algebra be commutative), but it’s less clear what is happening on the “physical space” side. For instance, how should one define a “noncommutative compact Hausdorff space”, other than as “an opposite object to a unital C^* algebra”?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e536214e920eb3bfdb3769f7ec2dc26c758f2909a393159a0605a4450a09cedb-806fce88c3c8993c7074644fbad38b9ea8f962f31f07404c4f8a3e238e16ac91.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594289")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Sorry for making my question unclear. All probability models that apply to qm seem to be countable. When we say superposition of states this would mean there is a necessity to invoke uncountable models and thus would the new framework provide anything new to qm?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594302")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("I could potentially imagine that certain quantum field theories (as well as several putative quantum gravity theories) might require an inseparable Hilbert space to model them properly, but generally speaking the mathematical foundational issues with such theories are far more severe than just the separable/inseparable distinction, to the point that the inseparability of the Hilbert space is the least of one’s mathematical concerns with such theories. Physically, of course, one can only ever make a finite number of observations, let alone a countable or uncountable number, so I would imagine that it would be difficult to establish physically meaningful distinctions between countable and uncountable quantum mechanics (though perhaps there are subtleties, in the spirit for instance of the recent negative solution to the Connes embedding problem). The quote of Richard Hamming on an analogous question is perhaps apropos: “Does anyone believe that the difference between the Lebesgue and Riemann integrals can have physical significance, and that whether say, an airplane would or would not fly could depend on this difference? If such were claimed, I should not care to fly in that plane.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d24f0c1138158d2350cbefa6bd4d3fd25520b73a1fa6404d97dafc1d76b67dc-06307c4ec5db81d89d660aaca3d9af711361098b6da825cbed6af92c40cb8af5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594310")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("I guess from an ‘applicable’ view point there isn’t much. I would also imagine the mathematician’s job is also not to make planes. However.the engineer’s job is not to fly planes either does not preclude the engineer from not knowing the engineering of flight and contribute to making planes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f491e3e016b46c369b7152dc57f1736b67869fa3af716ce364439d406a0a3645-54607534850084e594862bcf8d01747ccacc1a37e8196c7a47230d63002ab039.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-596423")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2020")])]

#text("Sorry but does countability have anything to do with quantumness of this universe? Do uncountable models have any roles?")

#emph[#text("[See my previous answer from Oct 7. -T]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xinhua")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594304")[#strong[#text("Xinhua")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Dear Professor")#linebreak()#text(" In the noncommutative case could you use the framework of quaternions in your different new models?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-594493")[#strong[#text("Pablo")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("Is there a connexion of your work with the recent paper of Gilles Pisier on C* algebras uploaded to ArXiv last August?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of arbitrary Conze-Lesigne systems | What's new")]], [#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/#comment-638019")[#strong[#text("The structure of arbitrary Conze-Lesigne systems | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2021")])]

#text("[…] There is an additional technical issue worth pointing out here (which unfortunately was glossed over in some previous work in the area). Because the cocycle equation (1) and the Conze-Lesigne equation (3) are only valid almost everywhere instead of everywhere, the action of on is technically only a near-action rather than a genuine action, and as such one cannot directly define to be the stabiliser of a point without running into multiple problems. To fix this, one has to pass to a topological model of in which the action becomes continuous, and the stabilizer becomes well defined, although one then has to work a little more to check that the action is still transitive. This can be done via Gelfand duality; we proceed using a mixture of a construction from this book of Host and Kra, and the machinery in this recent paper of Asgar and myself. […]")
]
