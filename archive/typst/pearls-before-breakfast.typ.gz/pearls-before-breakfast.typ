// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/
// Converted to Typst by tao2typ: "2026-10-14T06:52:25.187738+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Pearls before breakfast", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Pearls before breakfast")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/")[#text("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The main topic of this post has absolutely nothing to do with mathematics, except insofar as the well-known analogies between mathematics and music are concerned, but the recent article “")#link("http://www.washingtonpost.com/wp-dyn/content/article/2007/04/04/AR2007040401721.html")[#text("Pearls before breakfast")]#text("” in the Washington Post makes for fascinating reading. They conduct a very interesting experiment regarding the relationship between quality and context: what would happen if one took ")#link("http://en.wikipedia.org/wiki/Joshua_Bell")[#text("one of the finest and most renowned violinists in the world")]#text(", and made him give a concert-quality performance, while busking incognito at a busy subway station? The results… well, I won’t spoil them, but suffice to say that the article is well worth the read.")

#text("One wonders whether one could conduct a similar experiment in mathematics. The main new difficulty, of course, is that good music can (in principle) be appreciated by any attentive and interested listener, but the same is much less true of good mathematics. But perhaps there is a substitute experiment which would also be revealing. For instance, in ")#link("http://en.wikipedia.org/wiki/Surely_You're_Joking,_Mr._Feynman!")[#text("Feynman’s well-known book")]#text(" (in the chapter “Alfred Nobel’s other mistake”), one reads that, to avoid crowds of curiosity-seekers, the Nobel prize-winning physicist would sometimes give public lectures unannounced, as a last minute substitute for the announced (and fictional) lecturer; but the published title and abstract (e.g. “On the structure of the proton”) would be absolutely accurate, and thus only draw in people who were interested in the subject matter and not in the lecturer himself. Indeed, the crowds were much reduced as a consequence.")

#text("[Update, April 25, 2008: The above article won the ")#link("http://www.pulitzer.org/year/2008/feature-writing")[#text("2008 Pulitzer Prize for Feature Writing")]#text(".]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-356")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2007")])]

#text("I once saw a talk announced at Harvard by X-Y Z. I’m pretty sure it was Serre not Yau. Serre lecturing tended to shut down math departments all over Cambridge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simple Country Boy")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-358")[#strong[#text("Simple Country Boy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2007")])]

#text("I once encountered the violinist Hillary Hahn playing incognito at Seattle’s Pike Place Market. Her music was fabulous. I barely paused as I did not want to intrude in her space. I later regretted not stopping.")

#text("When I was an undergraduate, Feynman came to my school for a visit with a small class. He made it very clear that nobody outside the class should know of his visit until after he had gone back to Caltech.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JL")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-359")[#strong[#text("JL")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2007")])]

#text("The article begs two questions: Would the circumstances have been different had Bell played in the Boston T or the New York subway? (I think the answer is at least a mild yes.) And, isn’t this one of the underrepresented joys of being an academic? Many of us work just as hard as our counterparts in the business world, but still we are not as busy as them, in a sense- we have more of an opportunity to stop and appreciate the beauty around us (so we come in ten minutes late to a meeting, or miss the intro of a talk…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-362")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2007")])]

#text("Dear JL, I think the WP deliberately avoided all attempts to make the setting more favourable for Bell (e.g. by choosing a more relaxing time, by choosing more crowd-pleasing music, or a better venue). The experiment seemed to be whether first-class concert-quality music, shorn of all supporting props and context, could ")#emph[#text("by quality alone")]#text(" catch the attention of the average passer-by. Unfortunately the answer seemed largely to be no, though it would have been interesting (and more scientific) to have some sort of control experiment at the same time, such as an “ordinary” busker at a different part of the subway.")

#text("There is also the reverse experiment, in which one gets a busker to perform under Joshua Bell’s name at a concert (cf. the old joke about ")#link("http://www.health.uottawa.ca/biomech/csb/archives/joke2.txt")[#text("Einstein’s chauffeur")]#text("). Presumably this would not have gone down well with the ticket-paying audience, however. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cd4d6f7c957fadda199dc126443e196e4eda2db3001bdea48132a5f43607760-fb213bab809261697e135d8664d4102f6329e5923004adbd3b7e525268462344.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deane Yang")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-363")[#strong[#text("Deane Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2007")])]

#text("I would not expect an average person, especially one who does not normally listen to classical music, to take particular note of Bell’s playing. But among the thousands of people who passed through, I would have expected more than a few amateur musicians who have a sufficiently well developed ear to be completely wowed by Bell’s playing. And I agree with JL that the results would have been different in Boston or Manhattan, but it’s also very likely that someone would have recognized Bell by sight.")

#text("I agree that an equivalent experiment involving math talks would be a lot of fun, but this seems hard to set up properly. You would want to set up a situation where, say, average mathematicians happen to walk into a math talk and see if they can appreciate the quality of the talk despite not knowing who is talking. One crucial difference, however, is that for many of us the best math talks are not ones where the speaker displays his or her virtuosity but where the speaker is able to present the ideas in a particularly simple and transparent way. I have never heard you talk (unfortunately, I arrived in Paris last summer too late to attend your talks there), but your writings definitely display this quality. I did hear Okounkov speak last summer, and these were among the most beautiful and yet easiest to understand talks I have ever heard anyone give.")

#text("There is, of course, no chance that an average passerby has any chance of differentiating between a Fields Medalist and a complete charlatan.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10363e310bcdb54abcb59c65fb564f203d0022984d3e0814b67c8c4d6252d093-4042af8a57ba07ecc00848c889610a827652d19e91beae7a2b42a15620ff9dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nets Katz")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-365")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")])]

#text("Terry,")

#text("Once, about eight or nine years ago, I invited you to give a colloquium at UIC.")#linebreak()#text(" We were working on something pretty hard and I didn’t want to be disturbed")#linebreak()#text(" by trivia during your visit, but I got a frantic visit from the local senior harmonic analyst. No one was going to come to a colloquium in analysis. I had")#linebreak()#text(" to compose an e-mail to the department describing you and urging people to come. To my annoyance, I spent fifteen or twenty minutes composing this")#linebreak()#text(" e-mail, writing exactly what I thought. An hour later, this colleague came back")#linebreak()#text(" and told me that what I had written was entirely too effusive. He demanded")#linebreak()#text(" some embarassing changes to tone it down.")

#text("The colloquium was on the equivalence between Bochner Riesz and Restriction problems. It was well attended and it was a good talk. I think")#linebreak()#text(" the only person in the audience who appreciated it besides me was Henri")#linebreak()#text(" Gillet. I felt somewhat humiliated that no one wanted to go out to dinner with")#linebreak()#text(" us. The general consensus, I learned later, was that I had made a particularly")#linebreak()#text(" uninspired choice of colloquium speaker.")

#text("One does not have to look far to find examples of professional mathematicians not appreciating a lecture they have not been told to appreciate. Conversely,")#linebreak()#text(" I could provide a fairly dramatic example of a mathematician receiving")#linebreak()#text(" undeserved hype, far and wide, on the basis of a promotion campaign.")#linebreak()#text(" But it wouldn’t be appropriate for this blog.")

#text("Nets")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/565099a21b0cb1413032aad4001878680d374a974758ddde9928b7fb5664fcac-3700d073179e988a1300df0a644194ebe89d7bce731c6b4ccc426e38ef6c29ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陳力恒 Chan, Lik Hang Nick")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-366")[#strong[#text("陳力恒 Chan, Lik Hang Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")])]

#text("Another analogy:")

#text("I can’t do maths under exam condition. For two reasons: I work too slow and I can’t memorise things well. That’s why I prefer assignments.")

#text("If the quality of music is affected when it’s played in the subway, it’s like we do make mistakes in our calculation in a exam. I believe this is generally true. But it’s not true for Terry, I guess, judging from his performance in the IMO.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-373")[#strong[#text("Pseudo-Polymath » Blog Archive » Morning Highlights")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")]

#text("[…] Terrence Tao notes an interesting human experiment involving one of the worlds best violinists and a subway at What’s New. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cd4d6f7c957fadda199dc126443e196e4eda2db3001bdea48132a5f43607760-fb213bab809261697e135d8664d4102f6329e5923004adbd3b7e525268462344.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deane Yang")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-374")[#strong[#text("Deane Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")])]

#text("Of course, there is one critical difference between us and violinists that I overlooked. The quality of being a great violinist is the exactly the same as the quality of being able to give great performances. But the quality of being a great mathematician is not at all the same as being able to give great talks.")

#text("So we all too often suffer through completely incoherent and impenetrable talks just because of who the speaker is, and we sometimes skip out on much better talks, because we’re not sure who the speaker is. I’ve made both mistakes far too many times.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d899a203f39924ba20960b2fc98127ea1cfddd824f25412cc4fe5545097f04f-2a1aed296cf9507236113b851ba3ee8b3a3b376aae1dd16f2e5f1a578868283a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan Greenleaf")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-376")[#strong[#text("Allan Greenleaf")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")])]

#text("Terry,")

#text("The Washington Post experiment was interesting, but basically a journalistic stunt. After it was over, Joshua Bell could return to his life of a fully-booked calendar and recording contract. There are many skilled musicians of Bell’s caliber or close to it, who live his pretend life on a daily basis. I’ve visited Helsinki a number of times in the last few years, and there are a number of truly amazing classical musicians playing for whatever passersby will throw in their instrument cases. From their appearance and age, I would guess that most of them are refugees from the former Soviet Union, where they may have had positions (dare I say tenure?) in the good old days.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd677417193d480e0119a8c1f04d201d7a27c1264b17d9406d2efd8fae78adf6-d4e9b083a6ff8239d3bdb577495f4779739a6bc93dec2942f7f5f22ca19bcaea.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pspacexnoesis")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-385")[#strong[#text("pspacexnoesis")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")])]

#text("Interesting experience,")#linebreak()#text(" though I wonder how many were really interested in classical music, and for the ones who were, how many did not only listen to it, but did also attend to ‘classical music concerts’ and so on, and thus ‘made’ their ears to fine classical music… My guess is that it leaves only a few people really able to judge and recognize, the talent of a musician (such as Bell), during a rush hour, passing close to him only for a some seconds. (and not thinking that it sounded not to bad because that was the only songs he learned to play).")

#text("But the experiment still keeps its flavour, and shows how people aren’t as ‘open-minded’ as they may think, and tend not to give even a glimpse when that’s not for their interest, or imediate profit.")#linebreak()#text(" Maybe, that if they had put a poster saying: “Maestro Joshua Bell, internationnaly recognized as the finest Violin virtuoso” a lot more people would have stopped by, maybe giving him money, or asking for autographs, pictures or whatever, just for the heck of showing-off at diner-time while telling that to their relatives, when in fact they did not know who this man was :)")

#text("And as Furukawa said in the article, flipping quarters at him, that’s very insulting, him or anybody else, that’s something I wouldn’t do either.")

#text("Something similar happened to me, while in a Baduk club, some mid-level player was showing off, showing all his “knowledge” to beginners and how he was right (and stupid), a friend of mine, in the top-level amateur players decided to go argue with him about some patterns, the result was that the guy always though he was right thinking everybody in the room was dumb enough to believe him, well he’s been taugh a lesson later on… If he had known who he was before, his behavior would have been just the opposit.")

#text("-pxnm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teresa")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-388")[#strong[#text("Teresa")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")])]

#text("Beautiful, ‘Joshua Bell-like performances’ abound in our ‘ordinary’ existence. All we need to do is take notice with an open mind. I always find it fascinating that people would go to great lengths or make unusual sacrifices just to take a look at a lunar eclipse, for example. It’s like people are programmed into thinking that since an eclipse is a once-in-a-blue-moon event that it must be spectacular and not to be missed. In reality, however, it is not nearly as beautiful and wonderful to watch (to me at least) as a beautiful, glorious sunset, for example. Yet, how many people are fascinated by an ‘ordinary’ sunset?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ST")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-392")[#strong[#text("ST")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")])]

#text("Nets,")#linebreak()#text(" You can now invite Terry back to give the same colloquium to complete the control part of the experiment.")#linebreak()#text(" Also, kindly decline dinner invitations from those who didn’t go out last time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mahdi")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-420")[#strong[#text("Mahdi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2007")])]

#text("This reminds me of ")#link("http://news.bbc.co.uk/1/hi/uk/1533946.stm")[#text("a similar story")]#text(" in chess.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec00a3b2431e425ee6e60c73d2b6558af11990635b9a08df6c7dd92e6584fedf-ed30a0b69425e062531e2ae3d776846a1913519e5ee5a08a2401b6ad28ff827a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Doro Ferrante")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-509")[#strong[#text("Daniel Doro Ferrante")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")])]

#text("There’s a nice book that deals exactly with this problem: ")#link("http://www.amazon.com/Distinction-Social-Critique-Judgement-Taste/dp/0674212770/")[#text("Distinction: A Social Critique of the Judgement of Taste")]#text(", by ")#link("http://en.wikipedia.org/wiki/Pierre_Bourdieu")[#text("Pierre Bourdieu")]#text(".")

#text("Perhaps the question to be posed should have been along the following lines: ")#emph[#text("“If, rather than Joshua Bell — a classical musician, violonist — they had Michael Jackson or some American Idol winner, how would the crowd react; how different would the results be?”")]#text(" ;-)")

#text("This looks much more like a “sociological measure” than an intrinsic measure of quality, taste or merit [on Bell’s part].")

#text("Cheers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04c37d853459282ffe256951223c76fef1ef8c693447c8a516a8d7ba68a8a48e-82a3aeb2b2107d0a6365b8f6dd71c293997670cf6543e95a800917d80976ebf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Hillman")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-512")[#strong[#text("Chris Hillman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")])]

#text("Absolutely fascinating experiment! Although I am not sure one can draw any conclusion beyond the obvious: urban commuters tend to be very preoccupied, and strenuously avoid noticing anything unusual in their environment. After all, on an urban sidewalk, “something unusual” is more likely to mean a scary and unpleasant encounter with a criminal or a madman than an unexpected gift like the busking Bell.")

#text("Some might be tempted to argue that this experiment supports the assertion that few Americans are capable of appreciating really fine music, if only because too few public school students have the opportunity to learn to play some instrument. I am not sure that this conclusion is wrong, but I don’t think this stunt provides much evidence for it.")

#text("Interestingly enough, I always become very uneasy in settings in which I feel everyone is “required” to pay very close attention, like museums or orchestral concerts. I conjecture that the man who realized this was no ordinary busker, and who reported feeling conspicuous, humbled, and oddly embarassed, might know just what I mean.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93dcd51e0a4ece3b6722a686d783691c80da853b2af87ae0536766118c6cfcc1-e70b46576a6fa5feccd2f80233e87256385af4c99390e72f8919ffcced489f67.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John R Ramsden")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-607")[#strong[#text("John R Ramsden")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2007")])]

#text("I think in his final paragraph Chris Hillman gets close to the essence of the situation, except that when striding through subway passages and down escalators at a brisk pace most people are in the opposite frame of mind to one which favours “close attention” to a busker’s music, not to mention that they are literally passing the busker by and therefore unable to savour the music for long. Also, these days people who do like music on the hoof are likely to have an iPod wired to their ear.")

#text("But I do agree that a skilled musician busking is oddly embarrasing and, paradoxically, may not make as much at it as a hopeless discordant clown going through the motions. The reason I think is that if people recognize disproportionate talent and skill in such a humble occupation they feel that to offer a pittance is demeaning and condescending, even if with a moment’s thought they’d realize it might be just as welcome and needed as the coin they wouldn’t hesitate to throw in a more unskilled busker’s hat.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-618")[#strong[#text("De ‘Mozart van de wiskunde’ over succes")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2007")]

#text("[…] heeft trouwens een weblog. Meestal schrijft hij wiskundige abracadabra, maar vorige week had hij het over het merkwaardige experiment van de Washington Post, om een wereldberoemde concertviolist met een Stradivarius in een […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-9681")[#strong[#text("De ‘Mozart van de wiskunde’ over succes — jaspervanderkolk.nl")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2007")]

#text("[…] heeft trouwens een weblog. Meestal schrijft hij wiskundige abracadabra, maar vorige week had hij het over het merkwaardige experiment van de Washington Post, om een wereldberoemde concertviolist met een Stradivarius in een […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pearls before breakfast, II « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-29332")[#strong[#text("Pearls before breakfast, II « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2008")])]

#text("[…] Tags: Gene Weingarten, Josh Groban, Pulitzer Prize, Washington Post Over a year ago, I had a brief post here pointing out Gene Weingarten’s article in the Washington Post entitled “Pearls […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b1d58beeac3cfb2c6c58b7435158e3ee409eae3b683768cc66e2cd857989c85-1eb1b72f95183f021355725f6f21553a5fcd078226d5bca1f21969ad0adeb1e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of diego escobar")]], [#link("https://terrytao.wordpress.com/2007/04/09/pearls-before-breakfast/#comment-42069")[#strong[#text("diego escobar")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2009")])]

#text("Good morning!")

#text("someone can help me in this question:")#linebreak()#text(" What few pedestrians noted the presence of Joshua in the metro station completely?")

#text("Thanks")
]
