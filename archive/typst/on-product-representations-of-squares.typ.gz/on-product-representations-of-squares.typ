// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/
// Converted to Typst by tao2typ: "2026-10-14T15:20:59.612398+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On product representations of squares", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On product representations of squares")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 May 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/")[#text("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/2405.11610")[#text("On product representations of squares")]#text("“. This short paper answers (in the negative) a (somewhat obscure) ")#link("https://www.erdosproblems.com/121")[#text("question of Erdös")]#text(". Namely, for any ")#mi("{k \\geq 1}")#text(", let ")#mi("{F_k(N)}")#text(" be the size of the largest subset ")#mi("{A}")#text(" of ")#mi("{\\{1,\\dots,N\\}}")#text(" with the property that no ")#mi("{k}")#text(" distinct elements of ")#mi("{A}")#text(" multiply to a square. In a paper by Erdös, Sárközy, and Sós, the following asymptotics were shown for fixed ")#mi("{k}")#text(":")

#list(
[#mi("{F_1(N) = (1+o(1)) N}")#text(".")],
[#mi("{F_2(N) = (\\frac{6}{\\pi^2} + o(1)) N}")#text(".")],
[#mi("{F_3(N) = (1+o(1)) N}")#text(".")],
[#mi("{F_{4k}(N) = (1+o(1)) \\frac{N}{\\log N}}")#text(" for ")#mi("{k \\geq 1}")#text(".")],
[#mi("{F_{4k+2}(N) = (\\frac{3}{2}+o(1)) \\frac{N}{\\log N}}")#text(" for ")#mi("{k \\geq 1}")#text(".")],
[#mi("{(\\log 2 + o(1)) N \\leq F_{2k+1}(N) \\leq N}")#text(" for ")#mi("{k \\geq 2}")#text(".")]
)

#text("Thus the asymptotics for ")#mi("{F_k(N)}")#text(" for odd ")#mi("{k \\geq 5}")#text(" were not completely settled. Erdös asked if one had ")#mi("{F_k(N) = (1-o(1)) N}")#text(" for odd ")#mi("{k \\geq 5}")#text(". The main result of this paper is that this is not the case; that is to say, there exists ")#mi("{c_k>0}")#text(" such that any subset ")#mi("{A}")#text(" of ")#mi("{\\{1,\\dots,N\\}}")#text(" of cardinality at least ")#mi("{(1-c_k) N}")#text(" will contain ")#mi("{k}")#text(" distinct elements that multiply to a square, if ")#mi("{N}")#text(" is large enough. In fact, the argument works for all ")#mi("{k \\geq 4}")#text(", although it is not new in the even case. I will also note that there are now quite sharp upper and lower bounds on ")#mi("{F_k}")#text(" for even ")#mi("{k \\geq 4}")#text(", using methods from graph theory: see ")#link("https://www.combinatorics.org/ojs/index.php/eljc/article/view/v30i4p31")[#text("this recent paper")]#text(" of Pach and Vizer for the latest results in this direction. Thanks to the ")#link("https://zbmath.org/1036.11042")[#text("results of Granville and Soundararajan")]#text(", we know that the constant ")#mi("{c_k}")#text(" cannot exceed the ")#link("https://mathworld.wolfram.com/Hall-MontgomeryConstant.html")[#text("Hall-Montgomery constant")]

#align(center)[#tao-fit-display[#mitex("1 - \\log(1+\\sqrt{e}) + 2 \\int_1^{\\sqrt{e}} \\frac{\\log t}{t+1}\\ dt = 0.171500\\dots")]]

#text("and I (very tentatively) conjecture that this is in fact the optimal value for this constant. This looks somewhat difficult, but a more feasible conjecture would be that the ")#mi("{c_k}")#text(" asymptotically approach the Hall-Montgomery constant as ")#mi("{k \\rightarrow \\infty}")#text(", since the aforementioned result of Granville and Soundararajan morally corresponds to the ")#mi("{k=\\infty}")#text(" case.")

#text("In the end, the argument turned out to be relatively simple; no advanced results from additive combinatorics, graph theory, or analytic number theory were required. I found it convenient to proceed via the ")#link("https://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text(" (although the more combinatorial technique of double counting would also suffice here). The main idea is to generate a tuple ")#mi("{(\\mathbf{n}_1,\\dots,\\mathbf{n}_k)}")#text(" of distinct random natural numbers in ")#mi("{\\{1,\\dots,N\\}}")#text(" which multiply to a square, and which are reasonably uniformly distributed throughout ")#mi("{\\{1,\\dots,N\\}}")#text(", in that each individual number ")#mi("{1 \\leq n \\leq N}")#text(" is attained by one of the random variables ")#mi("{\\mathbf{n}_i}")#text(" with a probability of ")#mi("{O(1/N)}")#text(". If one can find such a distribution, then if the density of ")#mi("{A}")#text(" is sufficienly close to ")#mi("{1}")#text(", it will happen with positive probability that each of the ")#mi("{\\mathbf{n}_i}")#text(" will lie in ")#mi("{A}")#text(", giving the claim.")

#text("When ")#mi("{k=3}")#text(", this strategy cannot work, as it contradicts the arguments of Erdös, Särközy, and Sós. The reason can be explained as follows. The most natural way to generate a triple ")#mi("{(\\mathbf{n}_1,\\mathbf{n}_2,\\mathbf{n}_3)}")#text(" of random natural numbers in ")#mi("{\\{1,\\dots,N\\}}")#text(" which multiply to a square is to set")

#align(center)[#tao-fit-display[#mitex("\\mathbf{n}_1 := \\mathbf{d}_{12} \\mathbf{d}_{13}, \\mathbf{n}_2 := \\mathbf{d}_{12} \\mathbf{d}_{23}, \\mathbf{n}_3 := \\mathbf{d}_{13} \\mathbf{d}_{23}")]]

#text("for some random natural numbers ")#mi("{\\mathbf{d}_{12} \\mathbf{d}_{13}, \\mathbf{d}_{23}}")#text(". But if one wants all these numbers to have magnitude ")#mi("{\\asymp N}")#text(", one sees on taking logarithms that one would need")

#align(center)[#tao-fit-display[#mitex("\\log \\mathbf{d}_{12} + \\log \\mathbf{d}_{13}, \\log \\mathbf{d}_{12} + \\log \\mathbf{d}_{23}, \\log \\mathbf{d}_{13} + \\log \\mathbf{d}_{23} = \\log N + O(1)")]]

#text("which by elementary linear algebra forces")

#align(center)[#tao-fit-display[#mitex("\\log \\mathbf{d}_{12}, \\log \\mathbf{d}_{13}, \\log \\mathbf{d}_{23} = \\frac{1}{2} \\log N + O(1),")]]

#text("so in particular each of the ")#mi("{\\mathbf{n}_i}")#text(" would have a factor comparable to ")#mi("{\\sqrt{N}}")#text(". However, it follows from known results on the “")#link("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Tenenbaum%E2%80%93Ford_constant")[#text("multiplication table problem")]#text("” (how many distinct integers are there in the ")#mi("{n \\times n}")#text(" multiplication table?) that most numbers up to ")#mi("{N}")#text(" do ")#emph[#text("not")]#text(" have a factor comparable to ")#mi("{\\sqrt{N}}")#text(". (Quick proof: by the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Ramanujan_theorem")[#text("Hardy–Ramanujan law")]#text(", a typical number of size ")#mi("{N}")#text(" or of size ")#mi("{\\sqrt{N}}")#text(" has ")#mi("{(1+o(1)) \\log\\log N}")#text(" factors, hence typically a number of size ")#mi("{N}")#text(" will not factor into two factors of size ")#mi("{\\sqrt{N}}")#text(".) So the above strategy cannot work for ")#mi("{k=3}")#text(".")

#text("However, the situation changes for larger ")#mi("{k}")#text(". For instance, for ")#mi("{k=4}")#text(", we can try the same strategy with the ansatz")

#align(center)[#tao-fit-display[#mitex("\\mathbf{n}_1 = \\mathbf{d}_{12} \\mathbf{d}_{13} \\mathbf{d}_{14}; \\quad \\mathbf{n}_2 = \\mathbf{d}_{12} \\mathbf{d}_{23} \\mathbf{d}_{24}; \\quad \\mathbf{n}_3 = \\mathbf{d}_{13} \\mathbf{d}_{23} \\mathbf{d}_{34}; \\quad \\mathbf{n}_4 = \\mathbf{d}_{14} \\mathbf{d}_{24} \\mathbf{d}_{34}.")]]

#text("Whereas before there were three (approximate) equations constraining three unknowns, now we would have four equations and six unknowns, and so we no longer have strong constraints on any of the ")#mi("{\\mathbf{d}_{ij}}")#text(". So in principle we now have a chance to find a suitable random choice of the ")#mi("{\\mathbf{d}_{ij}}")#text(". The most significant remaining obstacle is the Hardy–Ramanujan law: since the ")#mi("{\\mathbf{n}_i}")#text(" typically have ")#mi("{(1+o(1))\\log\\log N}")#text(" prime factors, it is natural in this ")#mi("{k=4}")#text(" case to choose each ")#mi("{\\mathbf{d}_{ij}}")#text(" to have ")#mi("{(\\frac{1}{3}+o(1)) \\log\\log N}")#text(" prime factors. As it turns out, if one does this (basically by requiring each prime ")#mi("{p \\leq N^{\\varepsilon^2}}")#text(" to divide ")#mi("{\\mathbf{d}_{ij}}")#text(" with an independent probability of about ")#mi("{\\frac{1}{3p}}")#text(", for some small ")#mi("{\\varepsilon>0}")#text(", and then also adding in one large prime to bring the magnitude of the ")#mi("{\\mathbf{n}_i}")#text(" to be comparable to ")#mi("{N}")#text("), the calculations all work out, and one obtains the claimed result.")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-684925")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2024")])]

#text("Bravo!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-684928")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2024")])]

#text("See also ")#link("https://arxiv.org/abs/2405.12088")[#text("https://arxiv.org/abs/2405.12088")]#text(" which just appeared on arXiv.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-684929")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2024")])]

#text("Wow, that is quite a coincidence in timing! It seems the papers, while very adjacent in topic, do not actually overlap, but I will certainly update my paper to reference theirs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-684932")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2024")])]

#text("That’s certainly amazing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-684935")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2024")])]

#text("Why the case of odd 𝑘 ≥ 5? see above")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-684942")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2024")])]

#text("I am not sure exactly what the thrust of your question is, but one can get significantly stronger upper bounds in the even case because one can exploit the birthday paradox: if one can find two separate ")#mi("k")#text("-tuples in ")#mi("A")#text(" whose products have the same square-free part, then the product of the entire ")#mi("2k")#text("-tuple will be a square. One can use this trick to generate even tuples that multiply to a square, but not odd tuples. Similarly, it is easier to generate strong lower bounds in the odd case than in the even case, because the set of numbers that have an odd number of prime factors in a given set ")#mi("{\\mathcal P}")#text(" of primes, will necessarily have all odd products being a non-square, and all known counterexamples are based on this construction with a suitably optimized choice of ")#mi("{\\mathcal P}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-684999")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2024")])]

#text("typo in ")#strong[]#strong[#text("Example 2: Odd ")]#emph[#strong[#text("“k=5k=5")]#text("“")]#linebreak()#text("Sorry and thank you professor for the answer! Why the case of odd 𝑘 ≥ 5? remember 5 is also a untouchable number why is that? my framework is p ≥ 5 modulo 6. thinks about the implications and constraints. Thank you very much for your time ! god bless you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-684943")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2024")])]

#text("Lovely!")

#text("If one were to make the upper bound on the density obtained by this method explicit, it would go to 1 with k. Indeed it couldn’t possibly be higher than 1-1/k since we need to lower bound the probability that a k-tuple of random variables lies in A based only on information in the marginal distribution, requiring us to use the union bound, which loses at least 1 minus the density for each element of the tuple.")

#text("Might it be possible to prove a bound uniform in k at least 5 by some modification of this method? It seems tricky as one would have to prove the events n_i in A approximately independent in some sense. But actually I’m not sure that this is the main obstacle – it’s possible the current bounds from an explicit version of your argument go to 1 significantly faster than this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685000")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2024")])]

#text("It seems one can get a lower bound on the leading constant that is uniform in ")#mi("k")#text(" by leveraging the even ")#mi("k")#text(" theory, which among other things tells us that any set of positive density will contain ")#mi("k")#text(" distinct elements multiplying to a square if ")#mi("k \\geq 4")#text(" is fixed and even. So then if ")#mi("k \\geq 9")#text(" is odd, and ")#mi("A")#text(" is a subset of ")#mi("\\{1,\\dots,N\\}")#text(" that has density close to ")#mi("1")#text(", then one can first locate a tuple of five elements multiplying to a square, delete those elements, and then locate a tuple of ")#mi("k-5")#text(" (which is an even number that is at least 4) elements that multiply to a square in the remaining set. (In the notation of the paper, this argument shows that ")#mi("F_{k+2m}(N) \\geq F_k(N) - o(N)")#text(" for any fixed ")#mi("m \\geq 2")#text(".) I’ll add this as a remark to the paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Csaba Sandor")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685020")[#strong[#text("Csaba Sandor")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("Let ")#mi("k")#text(" be a positive integer. Then ")#mi("F_{k} \\ge F_{k+2}-2")#text(". Let ")#mi("A")#text(" be a largest subset of ")#mi("[1,N]")#text(" that does not contain ")#mi("k+2")#text(" distinct elements whose product is a square. It is known that ")#mi("F_{2}(N)+1 \\le F(N) \\le F_{k+2}(n)")#text(". Then one can locate elements ")#mi("a<a^{\\prime}")#text(", ")#mi("a,a^{\\prime} \\in A")#text(" multiplying to a square. Then ")#mi("A")#text(" is a set that does not contain ")#mi("k")#text(" distinct elements whose product is a square.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685023")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("Nice! So now the monotonicity of ")#mi("c^\\pm_k")#text(" for odd ")#mi("k")#text(" is settled.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685109")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2024")])]

#text("can you add it to your article (with ack. for Sandor of course)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685110")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2024")])]

#text("my bad, v2 already is there…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685026")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("One way to think about this phenomenon is that the set ")#mi("\\{ (n_1,\\dots,n_k): n_1 \\dots n_k \\text{ is a square} \\}")#text(" is not an “irreducible” set in some arithmetic geometry sense, but instead has multiple interesting “components”. In my paper I rely more or less exclusively on the component which has the parameterization ")#mi("n_i = \\prod_{j \\neq i} d_{i,j}")#text(" for some natural numbers ")#mi("d_{i,j}")#text(" with ")#mi("d_{i,j} = d_{j,i}")#text(". But there are other components as well; for instance one can retain this sort of parameterization just for ")#mi("n_1,\\dots,n_{k-2}")#text(", but have an unrelated parameterization ")#mi("n_{k-1} = a^2 m")#text(", ")#mi("n_k = b^2 m")#text(" for the final two components; this is related to the monotonicity of ")#mi("F_k(N)")#text(" for odd ")#mi("k")#text(" discussed previously. It is not clear ")#emph[#text("a priori")]#text(" which components give the strongest bounds on ")#mi("F_k(N)")#text(" (and perhaps the best bounds could even come from a synergy between multiple components, rather than just taking the best bound provided by a single component).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685028")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("As an experiment, I asked ChatGPT to provide Python code to compute the function ")#mi("F(N)")#text(", defined as the size of the largest subset of ")#mi("{1,\\dots,N}")#text(" with no odd number of them multiplying to a square. This is a lower bound for all the ")#mi("F_k(N)")#text(" for odd ")#mi("k")#text("; the quantity ")#mi("N-2F(N)")#text(" is also the minimal size of ")#mi("\\sum_{n \\leq N} f(n)")#text(" where ")#mi("f")#text(" ranges over ")#mi("{-1,+1}")#text("-valued completely multiplicative functions. As it turned out the code ran flawlessly (other than I had to figure out install the sympy package, and how to print the results), and only took me a few minutes to complete: ")#link("https://chatgpt.com/share/e021a5fb-5040-427b-a1a8-260fb31eeb08")[#text("https://chatgpt.com/share/e021a5fb-5040-427b-a1a8-260fb31eeb08")]#text(" . On consulting the OEIS, I found that the sequence ")#mi("N - 2F(N)")#text(" already appears as ")#link("https://oeis.org/A360659")[#text("https://oeis.org/A360659")]#text(" (which also provided confirmation of the correctness of the GPT-provided code, which I also spot-checked with small values of ")#mi("N")#text("), although ")#mi("F(N)")#text(" is not, but I just submitted it to the OEIS. (I haven’t tried the analogous exercise with the ")#mi("F_k(N)")#text(", which are harder to compute for ")#mi("k\\geq 3")#text(", but presumably one could get GPT to produce some algorithm that could produce enough entries to check the OEIS.)")

#text("UPDATE: F(N) is now at ")#link("https://oeis.org/A373114")[#text("https://oeis.org/A373114")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685029")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("Indeed, ChatGPT could compute ")#mi("F_3(N)")#text(" by brute force for ")#mi("N")#text(" up to 10 in less than a minute: ")#link("https://chatgpt.com/share/79ab37e7-d14d-4ae7-96d6-a5794a0a9581")[#text("https://chatgpt.com/share/79ab37e7-d14d-4ae7-96d6-a5794a0a9581")]#text(" . I could verify and extend the sequence by hand to")

#mi("1, 2, 3, 4, 5, 5, 6, 6, 6, 7, 8, 8, 9, 10, 10, 10, ...")

#text("and it does not appear to be in the OEIS; I will add it after the sequence ")#mi("F(N)")#text(" is approved (this is currently in process). [")#mi("F_1(N)")#text(" and ")#mi("F_2(N)")#text(" already appear in the OEIS as ")#link("https://oeis.org/A028391")[#text("https://oeis.org/A028391")]#text(" and ")#link("https://oeis.org/A013928")[#text("https://oeis.org/A013928")]#text(" respectively.]")

#text("UPDATE: ")#mi("F_3(N)")#text(" is now at ")#link("https://oeis.org/A372306")[#text("https://oeis.org/A372306")]#text(". ")#mi("F_4(N)")#text(" is at ")#link("https://oeis.org/A373119")[#text("https://oeis.org/A373119")]#text(", ")#mi("F_5(N)")#text(" is at ")#link("https://oeis.org/A373178")[#text("https://oeis.org/A373178")]#text(", and ")#mi("F_6(N)")#text(" is at ")#link("https://oeis.org/A373195")[#text("https://oeis.org/A373195")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685037")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("has the oeis led to discoveries?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685059")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2024")])]

#text("There are over 10,000 ")#link("https://oeis.org/wiki/Works_Citing_OEIS")[#text("research papers that cite the OEIS")]#text(", so I presume some non-trivial fraction of these found it useful.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685093")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2024")])]

#text("Are there similar results for representations of cubes?")

#emph[#text("[Yes; see the paper ")#link("https://arxiv.org/abs/2405.12088")[#text("https://arxiv.org/abs/2405.12088")]#text(" referenced in a previous comment -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685129")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2024")])]

#text("Is it possible to show that the sequence ")#mi("c_k")#text(" is monotonic?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685154")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2024")])]

#text("Yes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2024")])]

#text("The ")#mi("c_k")#text(" are known to equal 1 for even ")#mi("k \\geq 4")#text(", and are at most ")#mi("c = 0.1715\\dots")#text(" for odd ")#mi("k")#text(", so the sequence is not monotonic over the full natual numbers; however they are monotonic non-decreasing for odd ")#mi("k")#text(" (see the comment of Sandor ")#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/comment-page-1/#comment-685020")[#text("here")]#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2024")])]

#link("https://imgur.com/a/3uaQyKI")[#text("https://imgur.com/a/3uaQyKI")]

#text("Results are getting really close! I keept adding primes up to a millón its working professor!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/05/20/on-product-representations-of-squares/#comment-685191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2024")])]

#text("Out of curiosity, how much time have you (Terry) spend browsing erdosproblems.com? I have spent some time clicking the random button.")
]
