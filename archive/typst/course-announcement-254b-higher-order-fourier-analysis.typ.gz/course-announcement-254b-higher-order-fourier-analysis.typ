// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:36:06.987525+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Course announcement: 254B, Higher order Fourier analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Course announcement: 254B, Higher order Fourier analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 March 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/")[#text("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Starting on Monday, March 29, I will begin my graduate class for the winter quarter, entitled “")#link("http://www.math.ucla.edu/~tao/254b.1.10s/")[#text("Higher order Fourier analysis")]#text("“. While classical Fourier analysis is concerned with correlations with linear phases such as ")#mi("x \\mapsto e(\\alpha x)")#text(" (where ")#mi("e(x) := e^{2\\pi i x}")#text("), quadratic and higher order Fourier analysis is concerned with quadratic and higher order phases such as ")#mi("x \\mapsto e(\\alpha x^2)")#text(", ")#mi("x \\mapsto e(\\alpha x^3)")#text(", etc.")

#text("In recent years, it has become clear that certain problems in additive combinatorics are naturally associated with a certain order of Fourier analysis. For instance, problems involving arithmetic progressions of length three are connected with classical Fourier analysis; problems involving progressions of length four are connected with quadratic Fourier analysis; problems involving progressions of length five are connected with cubic Fourier analysis; and so forth. The reasons for this will be discussed later in the course, but we will just give one indication of the connection here: linear phases ")#mi("x \\mapsto e(\\alpha x)")#text(" and arithmetic progressions ")#mi("n, n+r, n+2r")#text(" of length three are connected by the identity")

#align(center)[#tao-fit-display[#mitex("e(\\alpha n) e(\\alpha(n+r))^{-2} e(\\alpha(n+2r)) = 1,")]]

#text("while quadratic phases ")#mi("x \\mapsto e(\\alpha x^2)")#text(" and arithmetic progressions ")#mi("n, n+r, n+2r, n+3r")#text(" of length four are connected by the identity")

#align(center)[#tao-fit-display[#mitex("e(\\alpha n^2) e(\\alpha(n+r)^2)^{-3} e(\\alpha(n+2r)^2)^3 e(\\alpha(n+3r)^2)^{-1} = 1,")]]

#text("and so forth.")

#text("It turns out that in order to get a complete theory of higher order Fourier analysis, the simple polynomial phases of the type given above do not suffice. One must also consider more exotic objects such as ")#emph[#text("locally")]#text(" polynomial phases, ")#emph[#text("bracket polynomial phases")]#text(" (such as ")#mi("n \\mapsto e( \\lfloor \\alpha n \\rfloor \\beta n )")#text(", and/or ")#emph[#text("nilsequences")]#text(" (sequences arising from an orbit in a nilmanifold ")#mi("G/\\Gamma")#text("). These (closely related) families of objects will be introduced later in the course.")

#text("Classical Fourier analysis revolves around the Fourier transform and the inversion formula. Unfortunately, we have not yet been able to locate similar identities in the higher order setting, but one can establish weaker results, such as higher order ")#emph[#text("structure theorems ")]#text("and ")#emph[#text("arithmetic regularity lemmas")]#text(", which are sufficient for many purposes, such as proving Szemeredi’s theorem on arithmetic progressions, or my theorem with Ben Green that the primes contain arbitrarily long arithmetic progressions. These results are powered by the ")#emph[#text("inverse conjecture for the Gowers norms")]#text(", which is now extremely close to being fully resolved.")

#text("Our focus here will primarily be on the finitary approach to the subject, but there is also an important infinitary aspect to the theory, originally coming from ergodic theory but more recently from nonstandard analysis (or more precisely, ultralimit analysis) as well; we will touch upon these perspectives in the course, though they will not be the primary focus. If time permits, we will also present the number-theoretic applications of this machinery to counting arithmetic progressions and other linear patterns in the primes.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/#comment-43812")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("Great! I am looking forward to learning it! At the same time, I will try my best to finish reading Random matrices, even it is a little hard for me :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c29264fb486ceaec33223c77038ad1b8efd8aa68feb66d6cfa8871af18b07f-fdec1d329b3909327d05b13b92473ec66f3d60d5790e6fee1cf23b2d0d2988f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/#comment-43813")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("I think you have some verb missing in “but one can weaker results”.")#linebreak()#text(" ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/#comment-43828")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("What type of background will you be assuming for this course in terms of, say, classical Fourier analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/#comment-43837")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("The material in my lecture notes")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("245C, Notes 2: The Fourier transform")]
]

#text("would be more than sufficient. I will mostly need the Fourier transform on finite abelian groups, on the integers, and on torii, with an emphasis on the algebraic identities (e.g. relating convolution with multiplication) that this transform enjoys.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ad15d285dfae5699d505cd99c71503105289ce8fe49bb77264d879740dcf412-f2c353b04d7cbed69acfdf5e3a52f9adfefdb51e677ee5c5da9d1467503eb1c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olof")]], [#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/#comment-43912")[#strong[#text("Olof")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2010")])]

#text("Terry, did you mean to put some squares in the identity for four-term progressions?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de3dd1c181c0346698e7d0b761a893a8243fd8c4094aa38b1ddd36286c49ece-ddbfe294ab43e27f6eca7e5ad70fab64b190c1bec39adfd38c98cdf6c5c3e292.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eckhard")]], [#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/#comment-44107")[#strong[#text("Eckhard")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2010")])]

#text("Sorry for being picky, but did you mean to have only one ‘also’ in ‘but there is also an important infinitary aspect to the theory also’?")

#text("[")#emph[#text("Corrected, thanks – T.")]#text("]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/#comment-44166")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2010")])]

#text("Hi Prof. Tao,")

#text("What are you going to teach after that course? Do you have a plan for the following 2-3 semesters?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/#comment-44182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2010")])]

#text("In the fall I will be teaching 245A (measure and integration theory). This is the predecessor to 245B, which I taught a few years ago and whose notes are on this blog. In the winter I will be on sabbatical.")
]
]
