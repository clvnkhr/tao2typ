// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/
// Converted to Typst by tao2typ: "2026-10-14T15:16:22.652036+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series II: Shou-wu Zhang, “Gross-Zagier formula and Birch and Swinnerton-Dyer conjecture ”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series II: Shou-wu Zhang, “Gross-Zagier formula and Birch and Swinnerton-Dyer conjecture ”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 May 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/")[#text("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("On Wednesday, Shou-wu Zhang continued his lecture series. Whereas the first lecture was a general overview of the rational points on curves problem, the second talk focused entirely on the genus 1 case – i.e. the problem of finding rational points on elliptic curves. This is already a very deep and important problem in number theory – for instance, this theory is decisive in Wiles’ proof of Fermat’s last theorem. It was also somewhat more technical than the previous talk, and I had more difficulty following all the details, but in any case here is my attempt to reconstruct the talk from my notes. Once again, the inevitable inaccuracies here are my fault and not Shou-wu’s, and corrections or comments are greatly appreciated.")

#text("NB: the talk here seems to be loosely based in part on Shou-wu’s ")#link("http://www.math.columbia.edu/~szhang/papers/elc.pdf")[#text("“Current developments in Mathematics” article")]#text(" from 2001.")

#metadata(none) <tao-7f61ae9b1e5bd6b4bdc7>

#text("The problem of finding rational (or more generally, algebraic) points on a curve is clearly an algebraic problem, but a remarkable feature of the subject is that it can be profitable (in the right circumstances) to seek such points via using ")#emph[#text("transcendental")]#text(" functions, which at first glance are much more closely related to analysis and geometry than to algebra. Shou-wu gave the analogy of the unit circle ")#mi("\\{(x_1,x_2): x_1^2+x_2^2 - 1 \\}")#text(" as sort of a simplified toy model of an elliptic curve. One way to construct algebraic points on this circle is to use the transcendental functions ")#mi("\\sin: {\\Bbb R}/2\\pi {\\Bbb Z} \\to {\\Bbb R}")#text(" and ")#mi("\\sin^{\\prime} = \\cos: {\\Bbb R}/2\\pi {\\Bbb Z} \\to {\\Bbb R}")#text("; indeed, given any rational number a/q, the point ")#mi("(\\sin 2\\pi \\frac{a}{q}, \\sin^{\\prime} 2\\pi \\frac{a}{q})")#text(" gives an algebraic point on the unit circle. The sine function is not an algebraic function, but can be defined instead via an integral of an algebraic function, since (modulo some small lies) we have")

#align(center)[#tao-fit-display[#mitex("x = \\int_0^{\\sin(x)} \\frac{dt}{\\sqrt{1-t^2}}.")]]

#text("The sine function also satisfies a differential equation, which almost defines this function uniquely:")

#align(center)[#tao-fit-display[#mitex("\\sin^{\\prime}(x)^2 = 1 - \\sin(x)^2.")]]

#text("Finally, of course, we all know that the sine function has a very geometric interpretation.")

#text("Now for constructing rational points on the unit circle, such as ")#mi("(\\frac{3}{5}, \\frac{4}{5})")#text(", it is not so profitable to use these transcendental functions, and it is better to use the purely algebraic formula ")#mi("(\\frac{m^2-n^2}{m^2+n^2}, \\frac{2mn}{m^2+n^2})")#text(" to generate the points. It seems that when we move to elliptic curves, something similar happens: the analogue of the transcendental sine function is the ")#link("http://en.wikipedia.org/wiki/Weierstrass_elliptic_function")[#text("Weierstrass elliptic function")]#text(" ")#mi("{\\mathcal P}")#text(", while the analogue of the purely algebraic formula is more subtle (and becomes transcendental also); once again, the latter is more useful than the former for constructing rational points (as opposed to just algebraic points).")

#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/")[#text("In the previous lecture")]#text(", Shou-wu defined an ")#link("http://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curve")]#text(" E as a genus 1 curve with a marked point P (which will eventually become the group identity element). It is traditional to move this point P to the (vertical) point at infinity ")#mi("1/y = x/y = 0")#text(" and view the curve affinely, in which case the curve can be placed via an affine transformation in the normal form")

#align(center)[#tao-fit-display[#mitex("E = \\{ (x,y): y^2 = x^3 + ax + b \\}")]]

#text("(ignoring some minor difficulties arising from characteristic 2 or 3, and assuming that the ")#link("http://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" ")#mi("\\Delta := -16(4a^3+27b^2)")#text(" is non-zero). As before, we can view this curve over any field k, for instance giving a Riemann surface ")#mi("E({\\Bbb C})")#text(", the rational points ")#mi("E({\\Bbb Q})")#text(", the finite field points ")#mi("E({\\Bbb F}_q)")#text(", etc. (There are some minor issues regarding whether one should view E affinely or projectively here; I don’t fully understand this issue and will therefore ignore it.)")

#text("The Riemann surface ")#mi("E({\\Bbb C})")#text(" was described completely by Weierstrass. Indeed, for any complex constants ")#mi("g_2, g_3")#text(" one can define the Weierstrass elliptic function ")#mi("{\\mathcal P}(u)")#text(" by the contour integration formula")

#align(center)[#mi("u = \\int_{{\\mathcal P}(u)}^\\infty \\frac{dt}{\\sqrt{4t^3 - g_2 t - g_3}}")#text(";")]

#text("note that the RHS is only defined up to a lattice ")#mi("\\Lambda \\subset {\\Bbb C}")#text(" arising from the periods of the multi-valued function ")#mi("\\frac{1}{\\sqrt{4t^3 - g_2 t - g_3}}")#text(", and so the Weierstrass function should really be defined on the torus ")#mi("{\\Bbb C}/\\Lambda")#text(" rather than the complex plane ")#mi("{\\Bbb C}")#text(". As with the sine function, it obeys a differential equation")

#align(center)[#tao-fit-display[#mitex("{\\mathcal P}^{\\prime}(u) = 4 {\\mathcal P}(u)^3 - g_2 {\\mathcal P}(u) - g_3")]]

#text("and so the map ")#mi("u \\mapsto ({\\mathcal P}(u), {\\mathcal P}^{\\prime}(u))")#text(" sends the torus ")#mi("{\\Bbb C}/\\Lambda")#text(" holomorphically to the Riemann surface of an elliptic curve, and in fact every elliptic curve can be described in this manner. Thus, from the complex (and hence topological) perspective, an elliptic curve is nothing more than a torus of one complex dimension (or two real dimensions).")

#text("A complex torus ")#mi("{\\Bbb C}/\\Lambda")#text(" is an abelian Lie group, and hence there should also be an abelian Lie group structure on the original elliptic curve E. This group structure is in fact very easy to describe geometrically in the original affine curve picture: three points P,Q,R on the curve will sum to zero if and only if they are collinear (or more precisely, they are the intersection of the projective curve of E with a line, counting multiplicity, and letting the point at infinity play the role of the origin). This group structure can be described algebraically, and so makes sense over any field, not just the complex numbers.")

#text("One consequence of Weierstrass’ description is that elliptic curves (over the complex numbers) up to isomorphism can be parameterised by the moduli space of all lattices, which is given by ")#mi("X_0(1) = SL_2({\\Bbb Z})\\backslash {\\Bbb H}")#text("; in particular this moduli space has one complex dimension and is thus just a ")#link("http://en.wikipedia.org/wiki/Modular_curve")[#text("modular curve")]#text(". This is the first hint that ")#link("http://en.wikipedia.org/wiki/Modular_function")[#text("modular functions")]#text(" and ")#link("http://en.wikipedia.org/wiki/Modular_form")[#text("modular forms")]#text(" are likely to play a key role in the subject.")

#text("For some special lattices ")#mi("\\Lambda")#text(", the complex torus ")#mi("{\\Bbb C}/\\Lambda")#text(" also enjoys some non-trivial complex endomorphisms; for instance if ")#mi("\\Lambda")#text(" is the Gaussian integers ")#mi("{\\Bbb Z}[\\sqrt{-1}]")#text(" then we have a multiplication by i, or more generally by any Gaussian integer. This gives rise to the theory of ")#link("http://en.wikipedia.org/wiki/Complex_multiplication")[#text("complex multiplication")]#text(" of elliptic curves; it turns out that for many number fields k (and an associated ")#link("http://en.wikipedia.org/wiki/Order_%28ring_theory%29")[#text("order")]#text(" ")#mi("\\theta_k")#text(", which should be thought of as just the ring of integers in k) one can isolate the special elliptic curves E which enjoy a complex multiplication structure of ")#mi("\\theta_k")#text(", or more precisely their endomorphism ring ")#mi("End(E)")#text(" is isomorphic to ")#mi("\\theta_k")#text(". This should be thought of as a zero-dimensional subset (or better yet, as a ")#link("http://en.wikipedia.org/wiki/Divisor_%28algebraic_geometry%29")[#text("divisor")]#text(") of the one-dimensional space of all elliptic curves. These divisors turn out to ultimately be very useful for constructing rational points on elliptic curves.")

#text("It turns out that in order to do all this, one needs to transform the original elliptic curve E into another object, a ")#link("http://en.wikipedia.org/wiki/Modular_curve")[#text("modular curve")]#text(" ")#mi("X_0(N)")#text(", the points of which can themselves be thought of, more or less, as elliptic curves (this appearance of elliptic curves on two different “levels” seems rather confusing to me!). There is in fact now known to be a correspondence in both directions between elliptic curves and modular curves, but Shou-wu mostly focused on the conversion of elliptic curves to modular curves (the converse direction was worked out by Eichler and Shimura).")

#text("Firstly, there are a finite number of primes p where the reduction of E to p is bad for one reason or another; we multiply all these primes p together to form the ")#emph[#text("conductor")]#text(" N, which then gets carried along throughout the rest of the construction. (Incidentally, the ")#link("http://en.wikipedia.org/wiki/Abc_conjecture")[#text("abc conjecture")]#text(" is equivalent to the assertion that ")#tao-math("N \\ll_\\epsilon \\left|\\Delta\\right|^{6+\\epsilon}", block: false)#text(" for all ")#mi("\\epsilon > 0")#text(".) Next, we form the ")#link("http://en.wikipedia.org/wiki/Hasse-Weil_zeta_function")[#text("Hasse-Weil L-function")]#text(" L(s,E), defined as the product over good primes p of the local L-functions ")#mi("(1 - a_p p^{-s} + p^{1-2s})^{-1}")#text(", where ")#mi("a_p = p+1 - \\# E( {\\Bbb F}_p )")#text(" was as in the previous lecture, times some other (not terribly important) factors coming from bad primes. It is a result of Faltings that the L-function basically captures the elliptic curve E up to ")#link("http://en.wikipedia.org/wiki/Isogeny")[#text("isogeny")]#text(", so in principle nothing significant is lost by working just with the L-function.")

#text("This L-function can then be expanded as a Dirichlet series ")#mi("\\sum_n \\frac{a_n}{n^s}")#text("; there are some important issues regarding convergence, analytic continuation, etc. which will be glossed over.")#linebreak()#text(" Next, we apply the ")#link("http://en.wikipedia.org/wiki/Mellin_transform")[#text("Mellin transform")]#text(", which in this context basically converts the Dirichlet series ")#mi("\\sum_n \\frac{a_n}{n^s}")#text(" to the Fourier series ")#mi("f_E(z) := \\sum_n a_n e^{2\\pi i n z}")#text(". This function ")#mi("f_E(z)")#text(" is defined on the upper half-plane ")#mi("{\\Bbb H}")#text(" and is obviously invariant under shifts ")#mi("z \\mapsto z+1")#text(". The amazing and nontrivial fact, ")#link("http://en.wikipedia.org/wiki/Modularity_theorem")[#text("conjectured by Shimura-Taniyama")]#text(", proved in large part ")#link("http://www.ams.org/mathscinet-getitem?mr=1333036")[#text("by Wiles and Taylor")]#text(" (en route to proving Fermat’s last Theorem) and then completed ")#link("http://www.ams.org/mathscinet-getitem?mr=1839918")[#text("by Breuil, Conrad, Diamond and Taylor")]#text(", gives an additional invariance, namely that ")#mi("f_E")#text(" is a modular form of weight 2 with respect to the principal congruence subgroup")

#align(center)[#tao-fit-display[#mitex("\\Gamma_0(N) := \\{ \\left( \\begin{array}{cc} a & b \\\\ c & d \\end{array}\\right) \\in SL_2({\\Bbb Z}): c = 0 \\text{ mod } N \\}")]]

#text("Equivalently, ")#mi("f_E(z)\\ dz")#text(" is a complex 1-form on the modular curve ")#mi("X_0(N) := \\Gamma_0(N) \\backslash {\\Bbb H}")#text(". (This modularity, incidentally, is equivalent after inverting the Mellin transform to a functional equation for the L-function, and can also be used to show that the L-function is entire, which is necessary to even just ")#emph[#text("state")]#text(" the BSD conjecture properly.) One can therefore integrate this 1-form to create a complex map ")#mi("w \\mapsto \\int_w^\\infty f_E(z)\\ dz")#text(" which maps ")#mi("X_0(N)")#text(" to the torus ")#mi("{\\Bbb C}/\\Lambda")#text(", where ")#mi("\\Lambda")#text(" is the lattice of periods arising from integrating ")#mi("f_E(z) dz")#text(" on closed loops in the modular curve. From Weierstrass, we know that the torus is equivalent to an elliptic curve ")#mi("E_f")#text("; from the work of Faltings, this new curve is isogenous to the original curve E.")

#text("To summarise, and ignoring some technical details (which I frankly didn’t fully understand), the deep fact that elliptic curves are modular gives us a new object, the modular curve ")#mi("X_0(N)")#text(", which has an explicit (but somewhat transcendental) map back into the elliptic curve E (or something very much like E). This gives us a strategy to find rational (or algebraic) points on E by first finding special points (or things like points, e.g. divisors) on ")#mi("X_0(N)")#text(", and mapping them into E.")

#text("[Actually, one does not need the full result of Wiles et al. for many applications; in particular, the elliptic curves with complex multiplication were known to be modular by significantly simpler arguments.]")

#text("There are some advantages in working in the modular curve rather than the elliptic curve, one of which is that the points on the modular curve themselves have interesting")#linebreak()#text(" structure. We already noted that when N=1, that the modular curve ")#mi("X_0(1)")#text(" parameterises all elliptic curves. For larger N, there is a slight modification; it turns out that ")#mi("X_0(N)")#text(" parameterises pairs ")#mi("(A,C)")#text(" where A is an elliptic curve and C is a finite subgroup of A isomorphic to ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(". Because both of these objects can be defined over specific fields (such as ")#mi("{\\Bbb C}")#text(" or ")#mi("{\\Bbb Q}")#text("), this gives us a way to define ")#mi("X_0(N)")#text(" concretely over such fields, for instance we can view it as an algebraic curve in ")#mi("{\\Bbb C}^2")#text(" which is also definable over ")#mi("{\\Bbb Q}")#text(". Actually, the complex description of ")#mi("X_0(N)")#text(" can be made extremely concrete by means of the ")#link("http://en.wikipedia.org/wiki/Elliptic_modular_function")[#text("j-invariant")]#text(", which is a modular function on ")#mi("X_0(1)")#text(" which has an expansion on the upper half-plane as")

#align(center)[#tao-fit-display[#mitex("j(\\tau) = e^{-2\\pi i \\tau} + 744 + 19688 e^{2\\pi i \\tau} + \\ldots")]]

#text("and the map ")#mi("\\tau \\mapsto (j(\\tau), j(N\\tau))")#text(" then identifies ")#mi("X_0(N)")#text(" with an algebraic curve in ")#mi("{\\Bbb C}^2")#text(". (This is apparently quite remarkable; most moduli spaces do not have concrete representations as algebraic varieties. I gather from Shou-wu that this phenomenon is ultimately due to the fact that elliptic curves are an abelian variety.) Now it becomes meaningful to talk about rational or other algebraic points in ")#mi("X_0(N)")#text(".")

#text("In particular, given a number field k (e.g. a quadratic field ")#mi("k = {\\Bbb Q}(\\sqrt{-d})")#text(") with the associated ring of integers (or order) ")#mi("\\theta_k")#text(" we can define a sub-moduli space of ")#mi("X_0(N)")#text(" by restricting to those pairs ")#mi("(A,C)")#text(" for which A has a complex multiplication associated to ")#mi("\\theta_k")#text(", thus ")#mi("End(A) \\equiv \\theta_k")#text(". After orienting this set appropriately (this is a little tricky, and may require all bad primes to split in k) we create a divisor in the modular curve ")#mi("X_0(N)")#text(", which one can think of as a signed combination of points; the theory of complex multiplication can be used to show that the degree of this divisor is equal to the ")#link("http://en.wikipedia.org/wiki/Class_number_%28number_theory%29")[#text("class number")]#text(" of the ring of integers. Since each point in the modular curve generates a point in the elliptic curve E, which is a group, we see that this divisor also generates a point in E, which is called a ")#link("http://en.wikipedia.org/wiki/Heegner_point")[#text("Heegner point")]#text("; some Galois theory then shows that this is in fact a point over k, basically because everything in sight is ")#mi("\\text{Gal}(\\overline{k}/k)")#text(" invariant. [As a side note, Heegner, who was a high-school maths teacher, managed to create this technique without any of the modern machinery of elliptic curves, while working on the very classical problem of determining which integers are ")#link("http://en.wikipedia.org/wiki/Congruent_number")[#text("congruent numbers")]#text("; this problem turns out to be equivalent to determining which members of a family of elliptic curves admit rational points.]")

#text("The theory is particularly simple when the field ")#mi("k = {\\Bbb Q}(\\sqrt{-d})")#text(" has unique factorisation, so that the class number is one and the divisor is just a single point. For instance, when d=163 (this is the largest discriminant for which a imaginary quadratic field has unique factorisation), the divisor consists of a single point at ")#mi("\\frac{1 + \\sqrt{-163}}{2}")#text(" (viewed as an element of the half-space, and thence as an element of ")#mi("X_0(1)")#text("); this leads to an integer point, and in particular ")#mi("j( \\frac{1 + \\sqrt{-163}}{2})")#text(" is an integer. Comparing this with the asymptotic expansion of j, we thus conclude the famous fact that ")#mi("e^{\\pi \\sqrt{163}}")#text(" is extremely close to an integer. [I believe there is a common philosophy in this area, articulated for instance by Ellenberg, that asserts that behind every numerical “miracle” there is almost always some interesting arithmetic geometry object that can “explain” the miracle.]")

#text("The method of Heegner points is a powerful way to construct rational or other algebraic points on an elliptic curve, but there is of course the danger that the point constructed is trivial. However, the remarkable Gross-Zagier theorem describes when this occurs. It is formalised as follows: if k is an imaginary quadratic field with discriminant d, and ")#mi("L(E/K,s)")#text(" is defined as the product ")#mi("L(E,s) L(E_D,s)")#text(", where ")#mi("E_D")#text(" is the curve E twisted by D (so that ")#mi("y^2 = x^3 + a x+ b")#text(" becomes ")#mi("Dy^2 = x^3 + ax + b")#text("), then one has a functional equation ")#mi("L(E/K,s) = - L(E/K,2-s)")#text(". The crucial point here is the minus sign; it implies in particular that ")#mi("L(E/K,s)")#text(" vanishes at s=1, and with a bit more work one can show that the derivative at s=1 is equal to an absolute constant times the square of the height of the Heegner point. As a consequence, the Heegner point is non-trivial precisely when the order of vanishing of the L-function is exactly 1, which is consistent with the BSD conjecture. This is remarkable because it connects an analytic fact (a non-vanishing of a derivative of an L-function) with an algebraic fact (the triviality of the Heegner point).")

#text("In fact, Kolyvagin used ideas similar to this to show that the (weak) BSD conjecture is true for rank 1 elliptic curves. There is in fact a conjecture of Goldfeld that asserts that if one takes a fixed elliptic curve and twists it by various discriminants, then the rank of the resulting twisted curve should be 0 with density 50%, 1 with density 50%, and 2 with density 0% – thus “most” twists should have rank 1, and so the BSD conjecture has already been “mostly” proved. (This is a bit misleading though; if instead one orders elliptic curves more naively, e.g. via the discriminant, then it is suspected now that a positive proportion of curves have rank greater than 2.) In terms of the classic problem of congruent numbers, there is a closely related conjecture that asserts that a square free number will always be a congruent number if it is equal to 5,6,7 mod 8, but almost never be congruent if equal to 1,2,3 mod 8; this conjecture is still unsolved, though there are several partial results.")

#text("[")#emph[#text("Update")]#text(", May 5: Brian Conrad pointed out to me that it does not actually make sense to talk about points in a complex torus over a field k, as this concept cannot be defined intrinsically within the complex structure, so I edited the text appropriately.]")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-791")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2007")])]

#text("The question of average rank of elliptic curves (or average order of vanishing) seems quite tricky, and there are really two schools of thought as to whether, ordering by discriminant, one should or not get 50% of rank 0 and rank 1, and a set with “density 0” of curves with rank > 1. There’s a fascinating account of the most recent numerical evidence in:")

#link("http://www.ams.org/bull/2007-44-02/S0273-0979-07-01138-X/home.html")[#text("Average ranks of elliptic curves: Tension between data and conjecture")]#linebreak()#text(" Baur Bektemirov; Barry Mazur; William Stein; Mark Watkins")#linebreak()#text(" Bull. Amer. Math. Soc. 44 (2007), 233-254.")

#text("The Random Matrix models for L-functions tend to strongly suggest the 50/50 split between rank 0 and 1 (assuming the B-SD conjecture), with some function field evidence by Katz and Sarnak.")

#text("In some other families of abelian varieties (obtained from modular curves in ways similar to elliptic curves, though involving modular forms with not-necessarily integral coefficients), the results are quite a bit more complete: there, it has been shown that at least 25% of the relevant abelian varieties have rank 0 (50% among those which should have even rank), and at least 43.75% have rank 1 (i.e., 87.5% among those which should have odd rank have rank 1). See e.g.")

#link("http://www.math.u-bordeaux1.fr/~kowalski/high-derivatives.pdf")[#text("Click to access high-derivatives.pdf")]

#text("(joint with P. Michel and J. Vanderkam).")

#text("Incidentally, these results arise from some form of very precise approximate orthogonality for the Fourier coefficients of the relevant modular forms (the Petersson formula). If the Fourier coefficients of elliptic curves, averaged properly with the desired ordering, have the same type of approximate orthogonality, there would be a similar result. This is described a bit in the following survey :")

#link("http://www.math.u-bordeaux1.fr/~kowalski/elliptic-curves-families.pdf")[#text("Click to access elliptic-curves-families.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-815")[#strong[#text("Not Even Wrong » Blog Archive » All Sorts of Stuff")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2007")]

#text("[…] to come up with amazingly good blog entries. His latest is a series of three postings (here, here and here), reporting on my colleague Shouwu Zhang’s lectures at UCLA on the topic of rational […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9d00e86ca8cffb6563fa6d82adfdceb9240d70813780bf0099170bd53cbe49f-d1146be2136fe601e3437e4ef8dc7a871b4c56e029cfda7fd997b69781efe2ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jordan Ellenberg")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-818")[#strong[#text("Jordan Ellenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2007")])]

#text("I agree with the philosophy ascribed to me above but I’m certain I don’t deserve any primary credit for articulating it!")

#emph[#text("(This is apparently quite remarkable; most moduli spaces do not have concrete representations as algebraic varieties. I gather from Shou-wu that this phenomenon is ultimately due to the fact that elliptic curves are an abelian variety.)")]

#text("I’m not sure I agree with this, though (but I may not be completely clear about what you’re saying.) The moduli spaces that you meet in arithmetic geometry do have representations as algebraic varieties, or at least algebraic stacks; what is rare is to have, as with X_0(N), a reasonably nice way of writing down ")#emph[#text("explicit equations")]#text(" for such a variety. I think that’s pretty rare even when you are studying moduli spaces of abelian varieties, so I’m not quite sure of the meaning of Shou-Wu’s comment here.")

#text("But in general it usually turns out not to be so useful to have explicit equations! (That said, I did write a paper where it was quite important to have explicit equations for a Hilbert modular surface, and it was a huge pain. But it would have been a better paper if there were a way to get the result without writing the equations down!) It tends to be more important just to know that there ")#emph[#text("is")]#text(" a moduli space which is an algebraic variety, and to know its properties (dimension, smoothness, properness, morphisms to other varieties of interest, etc.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-823")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2007")])]

#text("Hi Jordan! Thanks for your comments. As for the “philosophy”, I know at least one expert in Diophantine equations who assigns your name to it, but I can believe it has been around for a while.")

#text("I went back to my notes for Shou-wu’s talk and tried to reconstruct his comments more precisely. I don’t really understand what’s going on, but it was something like this: just as moduli of elliptic curves give modular curves, moduli of abelian varieties give Shimura varieties (and this was only because ")#mi("H^1(X)")#text(" was abelian, apparently). Shou-wu made a “moral” at the end of the talk that a really good way to find rational points on a variety is to somehow get nontrivial maps into them from “richer” varieties such as modular varieties, in which the individual points on the variety themselves have algebraic structure. He did concede though that at the present time, this strategy has not really borne much fruit with regard to general Shimura varieties (there was some connection here between Shimura varieties involving a congruence subgroup in ")#mi("Sp_{2g}({\\Bbb Z})")#text(" and a moduli space ")#mi("{\\mathcal M}_g")#text(" of curves, or a moduli space of subgroups of ")#mi("PSL_2({\\Bbb R})")#text(", but I can’t reconstruct what the deal was from my notes).")

#text("My notes also state “For most moduli spaces, there is no “concrete” embedding into projective space”, which is presumably what you just said above. I’m not sure what “concrete” means here, but Shou-wu gave the exponential function ")#mi("x \\mapsto e^{2\\pi i x}")#text(" modeling the torus ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" in the complex plane as an analogy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-461748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2015")])]

#text("Birch and Swinnerton-Dyer conjecture (proven).")

#text("It is shown that there is an equation to solve the elliptic curves.")

#text("example: ")#mi("y^{2} = x^{3} + 4x^{2} + 34x + 85")

#mi("x = \\frac{[b - (\\frac{a}{2})^{2}]^{2}}{4[c - [b - (\\frac{a}{2})^{2}](\\frac{a}{2})]}")

#text("is to say:")

#mi("x = \\frac{[34-(\\frac{4}{2})^{2}]^{2}}{4[85 - [34 - (\\frac{4}{2})^{2}](\\frac{4}{2})]} = 9")

#text("we check.")

#mi("38^{2} = 9^{3} + 4\\times 9^{2} + 34\\times 9 + 85")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-461749")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2015")])]

#text("published in: ")#link("http://www.hrpub.org/journals/jour_info.php?id=24")[#text("http://www.hrpub.org/journals/jour_info.php?id=24")]#text(" Vol 1 (1) 2013")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f854c19d67f4681d8b5ba6b460c4501643495ac91c51974e6bfacf0eeed09bd-6e21955b9609caeb875979882d91ea5d6c4e2356218900c79023d1368919eb03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-471373")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2016")])]

#text("Statement: If to a square, the we subtract a value (n); what is the value (n) for have another square?.")

#text("(n) is the congruent number.")

#text("ie: ")#mi("a{2} - c = c^{2}")#text("; ")#mi("a^{2} + n = (c_{1})^{2}")#text("; ")#mi("n \\neq n")#text("; ")#mi("\\forall(n) \\in Z")#text(".")

#text("We have the solution in the equation of Enfer; published in (UJCM Vol 1 (1) 2013).")

#mi("\\forall a^{2} = 4 + \\sum_{c \\geq 2}^{k} (2c+1)")#text(" (1)")

#text("Therefore:")

#mi("a^{2} - n = c^{2} = \\left[4 + \\sum_{c\\geq 2}^{k} (2c+1)\\right] - (2k+1)")

#text("Which implies that (n = 2k+1) and therefore all odd numbers are congruent number.")

#text("ie: ")#mi("5; 7; 9; 11; 13; 15; 17;........\\infty")

#text("They continue sequence of two; but also sequences are grouped four, eight,etc.")

#mi("5; 9; 13; 17; 21...........")#linebreak()#text(" ")#mi("5; 13; 21; 29;..........")

#text("Equation (1) also gives us numbers that are congruent pairs; for they we subtract couples of odd.")

#mi("\\left[4 + \\sum_{c\\geq 2}^{k} (2c+1)\\right] - \\left[(2k+1) + (2(k-1) + 1)\\right] = a^{2}")

#text("The smallest number congruent is number six. It is defined of the triangle ")#mi("(a=3; b=4)")#text(" and also all others because.")

#mi("a*b= 2n")

#text("and")

#mi("(Z)* a*b = 2n*(Z)")#text("; ")#mi("\\rightarrow")#text(" congruent number = ")#mi("n*(Z)")

#text("Are the following: ")#mi("\\forall(n) \\in Z")

#mi("6; 12; 18; 24; 30; 36;..........\\infty")

#text("We know each one of this numbers (major a six) is:")

#mi("12 = 7 + 5")#text("; ")#mi("18 = 7 + 11")#text("; ")#mi("24 = 11 + 13")#text("; ")#mi("30 = 13 + 17")#text("; ")#mi("36 = 17 + 19")#text("; ……….")

#text("In summary the congruent numbers are also verified in the form.")

#mi("(x \\equiv 5 mod 2)")#linebreak()#text(" ")#mi("(y \\equiv 6 mod 6)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-471380")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2016")])]

#text("See the Wikipedia article “congruent number”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f854c19d67f4681d8b5ba6b460c4501643495ac91c51974e6bfacf0eeed09bd-6e21955b9609caeb875979882d91ea5d6c4e2356218900c79023d1368919eb03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-471394")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2016")])]

#text("The mistake in Wikipedia (14; 20; 22; 28; …..) they are not congruent numbers.")

#text("Beacause:")

#mi("a^{2} - (14; 20; 22; 28;....) \\neq c^{2}")

#text("and turn: ")#mi("(14; 20; 22; 28;...) \\notin y")

#text("Enfer the equation it is as follows.")

#text("$ \\forall a^{2} = 4 + \\sum_{c\\gep 2}^{k} (2c+1) $")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f854c19d67f4681d8b5ba6b460c4501643495ac91c51974e6bfacf0eeed09bd-6e21955b9609caeb875979882d91ea5d6c4e2356218900c79023d1368919eb03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-471419")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2016")])]

#text("To avoid mistakes whith the congruent even numbers; qe passed the expression of (x) and (y) as follows.")

#mi("\\forall (k \\geq 2)")

#mi("2k+1 \\equiv 5 mod 2")

#mi("4(k+1) \\equiv 0 mod 2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-471420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2016")])]

#text("From the expansion of ")#mi("j(\\tau)")#text(" it seems that ")#mi("x := e^{\\pi \\sqrt {163}}")#text(" is very close to an integer, but by continuing this expansion it seems that ")#mi("x + 19688 x^{-1}")#text(" should be even closer to this integer.")#linebreak()#text(" Using this idea, is it possible to extract numerically(!) more coefficients of the above expansion (as long as these coefficients stay relatively small wrt ")#mi("x")#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/03/distinguished-lecture-series-ii-shou-wu-zhang-%e2%80%9cgross-zagier-formula-and-birch-and-swinnerton-dyer-conjecture-%e2%80%9d/#comment-471421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2016")])]

#text("Correction: The coefficient ")#mi("19688")#text(" (taken from ")#mi("j(\\tau)")#text(" expansion in the post) was found (by the above numerical method) to be ")#mi("196884")#text(".")#linebreak()#text(" It seems to be a rare case where a typo in a theoretically derived coefficient is detected by a numerical method!")
]
]
