// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/11/11/analysis-pde/
// Converted to Typst by tao2typ: "2026-10-14T16:35:04.574522+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Analysis & PDE", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Analysis & PDE")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 November 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/11/11/analysis-pde/")[#text("https://terrytao.wordpress.com/2007/11/11/analysis-pde/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve joined the inaugural ")#link("http://pjm.math.berkeley.edu/apde/about/journal/editorial.html")[#text("editorial board")]#text(" for a new mathematical journal, ")#link("http://pjm.math.berkeley.edu/apde/about/journal/about.html")[#text("Analysis & PDE")]#text(". This journal is owned by ")#link("http://www.mathscipub.org/")[#text("Mathematical Sciences Publishers")]#text(", a non-profit organisation dedicated to high-quality, low-cost, and broad-availability mathematical publishing, and run primarily by professional mathematicians. The scope of the journal is, of course, self-explanatory; MSP’s ")#link("http://www.mathscipub.org/journals.html")[#text("other journals")]#text(" have titles such as ")#link("http://msp.warwick.ac.uk/gt/")[#text("Geometry & Topology")]#text(", ")#link("http://www.jant.org/")[#text("Algebra & Number Theory")]#text(", and ")#link("http://msp.warwick.ac.uk/agt/")[#text("Algebraic & Geometric Topology")]#text(".")

#text("We’re just starting out (and haven’t even filled up our first issue yet), so we are looking for strong and significant submissions in all areas of analysis and PDE (broadly defined). If you have a good paper in these areas and are deciding on which journal to submit to, you might want to take a look at the ")#link("http://pjm.math.berkeley.edu/apde/about/journal/submissions.html")[#text("submission guidelines ")]#text("for our journal. Of course, the papers are subject to the usual peer review process and will be held to high standards in order to be accepted.")

#text("[")#emph[#text("Update")]#text(", Nov 11: Link fixed.]")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9117c280bcebaea0538a1837f0687f55474282a43800383770c6924b01f53b16-6e7d9f81fe77c07d18c320e4fbc37ce487fcab0533b3c3854feaa6f39bac88ce.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Webster")]], [#link("https://terrytao.wordpress.com/2007/11/11/analysis-pde/#comment-14391")[#strong[#text("Ben Webster")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2007")])]

#text("Sounds great!")

#text("I thought you might like to know, you seem to have linked to the journal A&GT where you wrote A&NT.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/11/analysis-pde/#comment-14392")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2007")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/11/11/analysis-pde/#comment-14635")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2007")])]

#text("What’s broad-access? Will it be open online access like PLOS? That would be really fantastic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/11/analysis-pde/#comment-14674")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2007")])]

#text("Dear Anonymous,")

#text("I believe MSP mirrors its journal articles on the ArXiV and on Project Euclid, but full access to the articles on its web sites (with hyperlinks, search facilities, etc.) will still require a library subscription.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/11/analysis-pde/#comment-15899")[#strong[#text("New Analysis and PDE Journal « The Lyceum Mathematikoi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2007")]

#text("[…] Terence Tao has joined the editorial board of a new Analysis and PDE journal. If you have any papers that you’re looking to submit, consider this one. Journals in all academic fields are notoriously expensive (read unaccesable), and that serves to be a clog in the arteries of progress. There is a growing consensus among Mathematicians, scientists, and academics that information doesn’t belong in the hands of major publishing houses who require you to sell you their soul just to read what’s inside. […]")
]
