// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/01/06/polynomial-towers-and-inverse-gowers-theory-for-bounded-exponent-groups/
// Converted to Typst by tao2typ: "2026-10-14T16:39:21.006323+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polynomial towers and inverse Gowers theory for bounded-exponent groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polynomial towers and inverse Gowers theory for bounded-exponent groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 January 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/01/06/polynomial-towers-and-inverse-gowers-theory-for-bounded-exponent-groups/")[#text("https://terrytao.wordpress.com/2026/01/06/polynomial-towers-and-inverse-gowers-theory-for-bounded-exponent-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://ajamnesh.github.io/")[#text("Asgar Jamneshan")]#text(", ")#link("https://u.cs.biu.ac.il/~shalomoc/")[#text("Or Shalom")]#text(" and I have uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2601.00961")[#text(" Polynomial towers and inverse Gowers theory for bounded-exponent groups")]#text("“. This continues our investigation into the ergodic-theory approach to the inverse theory of Gowers norms over finite abelian groups ")#mi("{G}")#text(". In this regard, our main result establishes a satisfactory (qualitative) inverse theorem for groups ")#mi("{G}")#text(" of bounded exponent:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{G}")#text(" be a finite abelian group of some exponent ")#mi("{m}")#text(", and let ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" be ")#mi("{1}")#text("-bounded with ")#tao-math("{\\left\\|f\\right\\|_{U^{k+1}(G)} > \\delta}", block: false)#text(". Then there exists a polynomial ")#mi("{P: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" of degree at most ")#mi("{k}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in G} f(x) e(-P(x))\\right| \\gg_{k,m,\\delta} 1.", block: true)]]
]

#text("This type of result was previously known in the case of vector spaces over finite fields (by work ")#link("https://zbmath.org/1252.11012")[#text("of myself")]#text(" ")#link("https://zbmath.org/1306.11015")[#text("and Ziegler")]#text("), groups of squarefree order (by work ")#link("https://arxiv.org/abs/2311.13899")[#text("of Candela, González-Sánchez, and Szegedy")]#text("), and in the ")#mi("{k \\leq 2}")#text(" case (by work of ")#link("https://zbmath.org/8061055")[#text("Jamneshan and myself")]#text("). The case ")#mi("{G = ({\\bf Z}/4{\\bf Z})^n}")#text(", for instance, is treated by this theorem but not covered by previous results. In the aforementioned paper of Candela et al., a result similar to the above theorem was also established, except that the polynomial ")#mi("{P}")#text(" was defined in an extension of ")#mi("{G}")#text(" rather than in ")#mi("{G}")#text(" itself (or equivalently, ")#mi("{f}")#text(" correlated with a projection of a phase polynomial, rather than directly with a phase polynomial on ")#mi("{G}")#text("). This result is consistent with a ")#link("https://zbmath.org/8061055")[#text("conjecture of Jamneshan and myself")]#text(" regarding what the “right” inverse theorem should be in any finite abelian group ")#mi("{G}")#text(" (not necessarily of bounded exponent).")

#text("In contrast to previous work, we do not need to treat the “high characteristic” and “low characteristic” cases separately; in fact, many of the delicate algebraic questions about polynomials in low characteristic do not need to be directly addressed in our approach, although this is at the cost of making the inductive arguments rather intricate and opaque.")

#text("As mentioned above, our approach is ergodic-theoretic, deriving the above combinatorial inverse theorem from an ergodic structure theorem of Host–Kra type. The most natural ergodic structure theorem one could establish here, which would imply the above theorem, would be the statement that if ")#mi("{\\Gamma}")#text(" is a countable abelian group of bounded exponent, and ")#mi("{X}")#text(" is an ergodic ")#mi("{\\Gamma}")#text("-system of order at most ")#mi("{k}")#text(" in the Host–Kra sense, then ")#mi("{X}")#text(" would be an Abramov system – generated by polynomials of degree at most ")#mi("{k}")#text(". This statement was conjectured many years ago ")#link("https://zbmath.org/1189.37007")[#text("by Bergelson, Ziegler, and myself")]#text(", and is true in many “high characteristic” cases, but unfortunately fails in low characteristic, as ")#link("https://zbmath.org/arXiv:2303.04853")[#text("recently shown by Jamneshan, Shalom, and myself")]#text(". However, we are able to recover a weaker version of this statement here, namely that ")#mi("{X}")#text(" admits an ")#emph[#text("extension")]#text(" which is an Abramov system. (This result was ")#link("https://zbmath.org/8103494")[#text("previously established by Candela et al.")]#text(" in the model case when ")#mi("{\\Gamma}")#text(" is a vector space over a finite field.) By itself, this weaker result would only recover a correlation with a projected phase polynomial, as in the work of Candela et al.; but the extension we construct arises as a tower of abelian extensions, and in the bounded exponent case there is an algebraic argument (hinging on a certain short exact sequence of abelian groups splitting) that allows one to map the functions in this tower back to the original combinatorial group ")#mi("{G}")#text(" rather than an extension thereof, thus recovering the full strength of the above theorem.")

#text("It remains to prove the ergodic structure theorem. The standard approach would be to describe the system ")#mi("{X}")#text(" as a Host–Kra tower")

#align(center)[#tao-fit-display[#mitex("Z^{\\leq 0}(X) \\leq Z^{\\leq 1}(X) \\leq \\dots \\leq Z^{\\leq k}(X) = X,")]]

#text("where each extension ")#mi("{Z^{\\leq j+1}(X)}")#text(" of ")#mi("{Z^{\\leq j}(X)}")#text(" is a compact abelian group extension by a cocycle of “type” ")#mi("{j}")#text(", and them attempt to show that each such cocycle is cohomologous to a polynomial cocycle. However, this appears to be impossible in general, particularly in low characteristic, as certain key short exact sequences fail to split in the required ways. To get around this, we have to work with a different tower, extending various levels of this tower as needed to obtain additional good algebraic properties of each level that enables one to split the required short exact sequences. The precise properties needed are rather technical, but the main ones can be described informally as follows:")

#list(
[#text("We need the cocycles to obey an “exactness” property, in that there is a sharp correspondence between the type of the cocycle (or any of its components) and its degree as a polynomial cocycle. (By general nonsense, any polynomial cocycle of degree ")#mi("{\\leq d-1}")#text(" is automatically of type ")#mi("{\\leq d}")#text("; exactness, roughly speaking, asserts the converse.) Informally, the cocycles should be “as polynomial as possible”.")],
[#text("The systems in the tower need to have “large spectrum” in that the set of eigenvalues of the system form a countable dense subgroup of the Pontryagin dual of the acting group ")#mi("{\\Gamma}")#text(" (in fact we demand that a specific countable dense subgroup ")#mi("{\\tilde \\Gamma}")#text(" is represented).")],
[#text("The systems need to be “pure” in the sense that the sampling map ")#mi("{\\iota_{x_0} P(\\gamma) := P(T^\\gamma x_0)}")#text(" that maps polynomials on the system to polynomials on the group ")#mi("{\\Gamma}")#text(" is injective for a.e. ")#mi("{x_0}")#text(", with the image being a ")#link("https://en.wikipedia.org/wiki/Pure_subgroup")[#text("pure subgroup")]#text(". Informally, this means that the problem of taking roots of a polynomial in the system is equivalent to the problem of taking roots of the corresponding polynomial on the group ")#mi("{\\Gamma}")#text(". In low characteristic, the root-taking problem becomes quite complicated, and we do not give a good solution to this problem either in the ergodic theory setting or the combinatorial one; however, purity at least lets one show that the two problems are (morally) equivalent to each other, which turns out to be what is actually needed to make the arguments work. There is also a technical “relative purity” condition we need to impose at each level of the extension to ensure that this purity property propagates up the tower, but I will not describe it in detail here.")]
)

#text("It is then possible to recursively construct a tower of extensions that eventually reaches an extension of ")#mi("{X}")#text(", for which the above useful properties of exactness, large spectrum, and purity are obeyed, and that the system remains Abramov at each level of the tower. This requires a lengthy process of “straightening” the cocycle by differentiating it, obtaining various “Conze–Lesigne” type equations for the derivatives, and then “integrating” those equations to place the original cocycle in a good form. At multiple stages in this process it becomes necessary to have various short exact sequences of (topological) abelian groups split, which necessitates the various good properties mentioned above. To close the induction one then has to verify that these properties can be maintained as one ascends the tower, which is a non-trivial task in itself.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/06/polynomial-towers-and-inverse-gowers-theory-for-bounded-exponent-groups/#comment-689589")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2026")])]

#text("Does there exist a $U^k[Phi_N]$ inverse theorem for $Phi_N$ a Folner sequence for, say, $(mathbb{Q}, +)$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/06/polynomial-towers-and-inverse-gowers-theory-for-bounded-exponent-groups/#comment-689591")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2026")])]

#text("Good question! At the current time we still do not have a completely satisfactory inverse theorem for high order Gowers norms when the ambient group has both high torsion and high rank; we can handle one or the other, but not both. The most recent results of Candela et al. may give an inverse theorem involving some sort of “projected nilsequence” arising from some extension of ")#mi("{\\mathbb Q}")#text(", but it is not clear that this would be what one would want to use in applications. Conjecturally the projection should not be needed, but this has not been established yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/06/polynomial-towers-and-inverse-gowers-theory-for-bounded-exponent-groups/#comment-689595")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2026")])]

#text("Hmm it seems that the recent inverse theorems apply for larger and larger groups, but unless I’m missing something obvious, it seems that converting from the folner sequence $Phi_N$ to a genuine group becomes rather expensive as the rank of the Folner sequence increases, to the point where I’m not sure we have one for$U^3[Phi_N]$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/06/polynomial-towers-and-inverse-gowers-theory-for-bounded-exponent-groups/#comment-689598")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2026")])]

#text("Some additional work would be needed to convert into the infinite case, perhaps broadly along the lines of the arguments in ")#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/")[#text("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/")]#text(" . (The nilspace approach of Candela et al. may also apply directly to this case.) But I have not worked out the details.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/510c66552aeb522f5cb76b75c478fe636cf66825f909bb6c727daf61b2947f20-6dbbb40e17caf4d3068d1767901bd69105f87b499754457556d5c4ae80051e37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TheCoherenceCat")]], [#link("https://terrytao.wordpress.com/2026/01/06/polynomial-towers-and-inverse-gowers-theory-for-bounded-exponent-groups/#comment-691615")[#strong[#text("TheCoherenceCat")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2026")])]

#text("What I’m noticing is that the move you’re making here algebraically, for a very specific class of systems, is the same move I’ve been led to topologically in a more general setting. In both cases, the obstruction isn’t removed internally; it disappears only after embedding the system into a higher-dimensional context where the relevant splitting or exactness becomes available.")

#text("In your case, this is realized through a carefully constructed algebraic tower tailored to bounded-exponent groups. In my work, the same phenomenon shows up abstractly: irreducible obstructions persist under local manipulation, but become trivial once the ambient space is enlarged in the right way. The tools differ, but the underlying mechanism—extension to restore realizability—looks identical.")

#text("This makes me suspect that the tower is not just a technical workaround, but an instance of a broader representational principle: rigidity is a symptom of working in too small a category.")
]
