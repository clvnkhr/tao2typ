// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/06/03/nested-approximate-subgroups/
// Converted to Typst by tao2typ: "2026-10-14T15:19:29.656969+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Nested approximate subgroups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Nested approximate subgroups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 June 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/06/03/nested-approximate-subgroups/")[#text("https://terrytao.wordpress.com/2015/06/03/nested-approximate-subgroups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Suppose that ")#mi("{A \\subset B}")#text(" are two subgroups of some ambient group ")#mi("{G}")#text(", with the index ")#mi("{K := [B:A]}")#text(" of ")#mi("{A}")#text(" in ")#mi("{B}")#text(" being finite. Then ")#mi("{B}")#text(" is the union of ")#mi("{K}")#text(" left cosets of ")#mi("{A}")#text(", thus ")#mi("{B = SA}")#text(" for some set ")#mi("{S \\subset B}")#text(" of cardinality ")#mi("{K}")#text(". The elements ")#mi("{s}")#text(" of ")#mi("{S}")#text(" are not entirely arbitrary with regards to ")#mi("{A}")#text(". For instance, if ")#mi("{A}")#text(" is a ")#emph[#text("normal")]#text(" subgroup of ")#mi("{B}")#text(", then for each ")#mi("{s \\in S}")#text(", the conjugation map ")#mi("{g \\mapsto s^{-1} g s}")#text(" preserves ")#mi("{A}")#text(". In particular, if we write ")#mi("{A^s := s^{-1} A s}")#text(" for the conjugate of ")#mi("{A}")#text(" by ")#mi("{s}")#text(", then")

#align(center)[#tao-fit-display[#mitex("A = A^s.")]]

#text("Even if ")#mi("{A}")#text(" is not normal in ")#mi("{B}")#text(", it turns out that the conjugation map ")#mi("{g \\mapsto s^{-1} g s}")#text(" ")#emph[#text("approximately")]#text(" preserves ")#mi("{A}")#text(", if ")#mi("{K}")#text(" is bounded. To quantify this, let us call two subgroups ")#mi("{A,B}")#text(" ")#emph[#mi("{K}")#text("-commensurate")]#text(" for some ")#mi("{K \\geq 1}")#text(" if one has")

#align(center)[#tao-fit-display[#mitex("[A : A \\cap B], [B : A \\cap B] \\leq K.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" Let ")#mi("{A \\subset B}")#text(" be groups, with finite index ")#mi("{K = [B:A]}")#text(". Then for every ")#mi("{s \\in B}")#text(", the groups ")#mi("{A}")#text(" and ")#mi("{A^s}")#text(" are ")#mi("{K}")#text("-commensurate, in fact")

#align(center)[#tao-fit-display[#mitex("[A : A \\cap A^s ] = [A^s : A \\cap A^s ] \\leq K.")]]
]

#emph[#text("Proof:")]#text(" One can partition ")#mi("{B}")#text(" into ")#mi("{K}")#text(" left translates ")#mi("{xA}")#text(" of ")#mi("{A}")#text(", as well as ")#mi("{K}")#text(" left translates ")#mi("{yA^s}")#text(" of ")#mi("{A^s}")#text(". Combining the partitions, we see that ")#mi("{B}")#text(" can be partitioned into at most ")#mi("{K^2}")#text(" non-empty sets of the form ")#mi("{xA \\cap yA^s}")#text(". Each of these sets is easily seen to be a left translate of the subgroup ")#mi("{A \\cap A^s}")#text(", thus ")#mi("{[B: A \\cap A^s] \\leq K^2}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("[B: A \\cap A^s] = [B:A] [A: A \\cap A^s] = [B:A^s] [A^s: A \\cap A^s]")]]

#text("and ")#mi("{[B:A] = [B:A^s]=K}")#text(", we obtain the claim. ")#mi("\\Box")

#text("One can replace the inclusion ")#mi("{A \\subset B}")#text(" by commensurability, at the cost of some worsening of the constants:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" Let ")#mi("{A, B}")#text(" be ")#mi("{K}")#text("-commensurate subgroups of ")#mi("{G}")#text(". Then for every ")#mi("{s \\in B}")#text(", the groups ")#mi("{A}")#text(" and ")#mi("{A^s}")#text(" are ")#mi("{K^2}")#text("-commensurate.")
]

#emph[#text("Proof:")]#text(" Applying the previous proposition with ")#mi("{A}")#text(" replaced by ")#mi("{A \\cap B}")#text(", we see that for every ")#mi("{s \\in B}")#text(", ")#mi("{A \\cap B}")#text(" and ")#mi("{(A \\cap B)^s}")#text(" are ")#mi("{K}")#text("-commensurate. Since ")#mi("{A \\cap B}")#text(" and ")#mi("{(A \\cap B)^s}")#text(" have index at most ")#mi("{K}")#text(" in ")#mi("{A}")#text(" and ")#mi("{A^s}")#text(" respectively, the claim follows. ")#mi("\\Box")

#text("It turns out that a similar phenomenon holds for the more general concept of an ")#emph[#text("approximate group")]#text(", and gives a “classification” of all the approximate groups ")#mi("{B}")#text(" containing a given approximate group ")#mi("{A}")#text(" as a “bounded index approximate subgroup”. Recall that a ")#mi("{K}")#text("-approximate group ")#mi("{A}")#text(" in a group ")#mi("{G}")#text(" for some ")#mi("{K \\geq 1}")#text(" is a symmetric subset of ")#mi("{G}")#text(" containing the identity, such that the product set ")#mi("{A^2 := \\{ a_1 a_2: a_1,a_2 \\in A\\}}")#text(" can be covered by at most ")#mi("{K}")#text(" left translates of ")#mi("{A}")#text(" (and thus also ")#mi("{K}")#text(" right translates, by the symmetry of ")#mi("{A}")#text("). For simplicity we will restrict attention to finite approximate groups ")#mi("{A}")#text(" so that we can use their cardinality ")#mi("{A}")#text(" as a measure of size. We call finite two approximate groups ")#mi("{A,B}")#text(" ")#emph[#mi("{K}")#text("-commensurate")]#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\left|A^2 \\cap B^2\\right| \\geq \\frac{1}{K} \\left|A\\right|, \\frac{1}{K} \\left|B\\right|;", block: true)]]

#text("note that this is consistent with the previous notion of commensurability for genuine groups.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" Let ")#mi("{G}")#text(" be a group, and let ")#mi("{K_1,K_2,K_3 \\geq 1}")#text(" be real numbers. Let ")#mi("{A}")#text(" be a finite ")#mi("{K_1}")#text("-approximate group, and let ")#mi("{B}")#text(" be a symmetric subset of ")#mi("{G}")#text(" that contains ")#mi("{A}")#text(".")

#list(
[#text("(i) If ")#mi("{B}")#text(" is a ")#mi("{K_2}")#text("-approximate group with ")#tao-math("{\\left|B\\right| \\leq K_3 \\left|A\\right|}", block: false)#text(", then one has ")#mi("{B \\subset SA}")#text(" for some set ")#mi("{S}")#text(" of cardinality at most ")#mi("{K_1 K_2 K_3}")#text(". Furthermore, for each ")#mi("{s \\in S}")#text(", the approximate groups ")#mi("{A}")#text(" and ")#mi("{A^s}")#text(" are ")#mi("{K_1 K_2^5 K_3}")#text("-commensurate.")],
[#text("(ii) Conversely, if ")#mi("{B \\subset SA}")#text(" for some set ")#mi("{S}")#text(" of cardinality at most ")#mi("{K_3}")#text(", and ")#mi("{A}")#text(" and ")#mi("{A^s}")#text(" are ")#mi("{K_2}")#text("-commensurate for all ")#mi("{s \\in S}")#text(", then ")#tao-math("{\\left|B\\right| \\leq K_3 \\left|A\\right|}", block: false)#text(", and ")#mi("{B}")#text(" is a ")#mi("{K_1^6 K_2 K_3^2}")#text("-approximate group.")]
)
]

#text("Informally, the assertion that ")#mi("{B}")#text(" is an approximate group containing ")#mi("{A}")#text(" as a “bounded index approximate subgroup” is equivalent to ")#mi("{B}")#text(" being covered by a bounded number of shifts ")#mi("{sA}")#text(" of ")#mi("{A}")#text(", where ")#mi("{s}")#text(" approximately normalises ")#mi("{A^2}")#text(" in the sense that ")#mi("{A^2}")#text(" and ")#mi("{(A^2)^s}")#text(" have large intersection. Thus, to classify all such ")#mi("{B}")#text(", the problem essentially reduces to that of classifying those ")#mi("{s}")#text(" that approximately normalise ")#mi("{A^2}")#text(".")

#text("To prove the theorem, we recall some standard lemmas from arithmetic combinatorics, which are the foundation stones of the “Ruzsa calculus” that we will use to establish our results:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Ruzsa covering lemma)")]#text(" If ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are finite non-empty subsets of ")#mi("{G}")#text(", then one has ")#mi("{B \\subset SAA^{-1}}")#text(" for some set ")#mi("{S \\subset B}")#text(" with cardinality ")#tao-math("{\\left|S\\right| \\leq \\frac{\\left|BA\\right|}{\\left|A\\right|}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" We take ")#mi("{S}")#text(" to be a subset of ")#mi("{B}")#text(" with the property that the translates ")#mi("{sA, s \\in S}")#text(" are disjoint in ")#mi("{BA}")#text(", and such that ")#mi("{S}")#text(" is maximal with respect to set inclusion. The required properties of ")#mi("{S}")#text(" are then easily verified. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Ruzsa triangle inequality)")]#text(" If ")#mi("{A,B,C}")#text(" are finite non-empty subsets of ")#mi("{G}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left|A C^{-1}\\right| \\leq \\left|A B^{-1}\\right| \\left|B C^{-1}\\right| / \\left|B\\right|.", block: true)]]
]

#emph[#text("Proof:")]#text(" If ")#mi("{ac^{-1}}")#text(" is an element of ")#mi("{AC^{-1}}")#text(" with ")#mi("{a \\in A}")#text(" and ")#mi("{c \\in C}")#text(", then from the identity ")#mi("{ac^{-1} = (ab^{-1}) (bc^{-1})}")#text(" we see that ")#mi("{ac^{-1}}")#text(" can be written as the product of an element of ")#mi("{AB^{-1}}")#text(" and an element of ")#mi("{BC^{-1}}")#text(" in at least ")#tao-math("{\\left|B\\right|}", block: false)#text(" distinct ways. The claim follows. ")#mi("\\Box")

#text("Now we can prove (i). By the Ruzsa covering lemma, ")#mi("{B}")#text(" can be covered by at most")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\left|BA\\right|}{\\left|A\\right|} \\leq \\frac{\\left|B^2\\right|}{\\left|A\\right|} \\leq \\frac{K_2 \\left|B\\right|}{\\left|A\\right|} \\leq K_2 K_3", block: true)]]

#text("left-translates of ")#mi("{A^2}")#text(", and hence by at most ")#mi("{K_1 K_2 K_3}")#text(" left-translates of ")#mi("{A}")#text(", thus ")#mi("{B \\subset SA}")#text(" for some ")#tao-math("{\\left|S\\right| \\leq K_1 K_2 K_3}", block: false)#text(". Since ")#mi("{sA}")#text(" only intersects ")#mi("{B}")#text(" if ")#mi("{s \\in BA}")#text(", we may assume that")

#align(center)[#tao-fit-display[#mitex("S \\subset BA \\subset B^2")]]

#text("and hence for any ")#mi("{s \\in S}")

#tao-aligned(keep: true)[


#tao-math("\\left|A^s A\\right|  & \\leq \\left|B^2 A B^2 A\\right| \\leq \\left|B^6\\right|", block: true)



#tao-math(" & \\leq K_2^5 \\left|B\\right| \\leq K_2^5 K_3 |A|.", block: true)
]

#text("By the Ruzsa covering lemma again, this implies that ")#mi("{A^s}")#text(" can be covered by at most ")#mi("{K_2^5 K_3}")#text(" left-translates of ")#mi("{A^2}")#text(", and hence by at most ")#mi("{K_1 K_2^5 K_3}")#text(" left-translates of ")#mi("{A}")#text(". By the pigeonhole principle, there thus exists a group element ")#mi("{g}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left|A^s \\cap gA\\right| \\geq \\frac{1}{K_1 K_2^5 K_3} |A|.", block: true)]]

#text("Since")

#align(center)[#tao-fit-display[#tao-math("\\left|A^s \\cap gA\\right| \\leq \\left| (A^s \\cap gA)^{-1} (A^s \\cap gA)\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(A^s \\cap gA)^{-1} (A^s \\cap gA) \\subset A^2 \\cap (A^s)^2")]]

#text("the claim follows.")

#text("Now we prove (ii). Clearly")

#align(center)[#tao-fit-display[#tao-math("\\left|B\\right| \\leq \\left|S\\right| \\left|A\\right| \\leq K_3 |A|.", block: true)]]

#text("Now we control the size of ")#mi("{B^2 A}")#text(". We have")

#align(center)[#tao-fit-display[#tao-math("\\left|B^2 A\\right| \\leq \\left|SA SA^2\\right| \\leq K_3^2 \\sup_{s \\in S} \\left|A s A^2\\right| = K_3^2 \\sup_{s \\in S} \\left|A^s A^2\\right|.", block: true)]]

#text("From the Ruzsa triangle inequality and symmetry we have")

#tao-aligned(keep: true)[


#tao-math("\\left|A^s A^2\\right|  & \\leq \\frac{ \\left|A^s (A^2 \\cap (A^2)^s)\\right| \\left|(A^2 \\cap (A^2)^s) A^2\\right|}{\\left|A^2 \\cap (A^2)^s\\right|}", block: true)



#tao-math(" & \\leq \\frac{ \\left|(A^3)^s\\right| \\left|A^4\\right| }{\\left|A\\right|/K_2}", block: true)



#tao-math(" & \\leq K_2 \\frac{ \\left|A^3\\right| \\left|A^4\\right| }{\\left|A\\right|}", block: true)



#tao-math(" & \\leq K_1^5 K_2 \\left|A\\right|", block: true)
]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|B^2 A\\right| \\leq K_1^5 K_2 K_3^2 |A|.", block: true)]]

#text("By the Ruzsa covering lemma, this implies that ")#mi("{B^2}")#text(" is covered by at most ")#mi("{K_1^5 K_2 K_3^2}")#text(" left-translates of ")#mi("{A^2}")#text(", hence by at most ")#mi("{K_1^6 K_2 K_3^2}")#text(" left-translates of ")#mi("{A}")#text(". Since ")#mi("{A \\subset B}")#text(", the claim follows.")

#text("We now establish some auxiliary propositions about commensurability of approximate groups. The first claim is that commensurability is approximately transitive:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" Let ")#mi("{A}")#text(" be a ")#mi("{K_1}")#text("-approximate group, ")#mi("{B}")#text(" be a ")#mi("{K_2}")#text("-approximate group, and ")#mi("{C}")#text(" be a ")#mi("{K_3}")#text("-approximate group. If ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are ")#mi("{K_4}")#text("-commensurate, and ")#mi("{B}")#text(" and ")#mi("{C}")#text(" are ")#mi("{K_5}")#text("-commensurate, then ")#mi("{A}")#text(" and ")#mi("{C}")#text(" are ")#mi("{K_1^2 K_2^3 K_2^3 K_4 K_5 \\max(K_1,K_3)}")#text("-commensurate.")
]

#emph[#text("Proof:")]#text(" From two applications of the Ruzsa triangle inequality we have")

#tao-aligned(keep: true)[


#tao-math("\\left|AC\\right|  & \\leq \\frac{\\left|A (A^2 \\cap B^2)\\right| \\left|(A^2 \\cap B^2) (B^2 \\cap C^2)\\right| \\left|(B^2 \\cap C^2) C\\right|}{\\left|A^2 \\cap B^2\\right| \\left|B^2 \\cap C^2\\right|}", block: true)



#tao-math(" & \\leq \\frac{\\left|A^3\\right| \\left|B^4\\right| \\left|C^3\\right|}{ (\\left|A\\right|/K_4) (\\left|B\\right|/K_5)}", block: true)



#tao-math(" & \\leq K_4 K_5 \\frac{K_1^2 |A| K_2^3 |B| K_3^2 \\left|C\\right|}{ \\left|A\\right| \\left|B\\right| }", block: true)



#tao-math(" & = K_1^2 K_2^3 K_3^2 K_4 K_5 |C|.", block: true)
]

#text("By the Ruzsa covering lemma, we may thus cover ")#mi("{A}")#text(" by at most ")#mi("{K_1^2 K_2^3 K_3^2 K_4 K_5}")#text(" left-translates of ")#mi("{C^2}")#text(", and hence by ")#mi("{K_1^2 K_2^3 K_3^3 K_4 K_5}")#text(" left-translates of ")#mi("{C}")#text(". By the pigeonhole principle, there thus exists a group element ")#mi("{g}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap gC\\right| \\geq \\frac{1}{K_1^2 K_2^3 K_3^3 K_4 K_5} \\left|A\\right|,", block: true)]]

#text("and so by arguing as in the proof of part (i) of the theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\left|A^2 \\cap C^2\\right| \\geq \\frac{1}{K_1^2 K_2^3 K_3^3 K_4 K_5} \\left|A\\right|", block: true)]]

#text("and similarly")

#align(center)[#tao-fit-display[#tao-math("\\left|A^2 \\cap C^2\\right| \\geq \\frac{1}{K_1^3 K_2^3 K_3^2 K_4 K_5} \\left|C\\right|", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#text("The next proposition asserts that the union and (modified) intersection of two commensurate approximate groups is again an approximate group:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" Let ")#mi("{A}")#text(" be a ")#mi("{K_1}")#text("-approximate group, ")#mi("{B}")#text(" be a ")#mi("{K_2}")#text("-approximate group, and suppose that ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are ")#mi("{K_3}")#text("-commensurate. Then ")#mi("{A \\cup B}")#text(" is a ")#mi("{K_1 + K_2 + K_1^2 K_2^4 K_3 + K_1^4 K_2^2 K_3}")#text("-approximate subgroup, and ")#mi("{A^2 \\cap B^2}")#text(" is a ")#mi("{K_1^6 K_2^3 K_3}")#text("-approximate subgroup.")
]

#text("Using this proposition, one may obtain a variant of the previous theorem where the containment ")#mi("{A \\subset B}")#text(" is replaced by commensurability; we leave the details to the interested reader.")

#emph[#text("Proof:")]#text(" We begin with ")#mi("{A \\cup B}")#text(". Clearly ")#mi("{A \\cup B}")#text(" is symmetric and contains the identity. We have ")#mi("{(A \\cup B)^2 = A^2 \\cup AB \\cup BA \\cup B^2}")#text(". The set ")#mi("{A^2}")#text(" is already covered by ")#mi("{K_1}")#text(" left translates of ")#mi("{A}")#text(", and hence of ")#mi("{A \\cup B}")#text("; similarly ")#mi("{B^2}")#text(" is covered by ")#mi("{K_2}")#text(" left translates of ")#mi("{A \\cup B}")#text(". As for ")#mi("{AB}")#text(", we observe from the Ruzsa triangle inequality that")

#tao-aligned(keep: true)[


#tao-math("\\left|AB^2\\right|  & \\leq \\frac{\\left|A (A^2 \\cap B^2)\\right| \\left|(A^2 \\cap B^2) B^2\\right|}{\\left|A^2 \\cap B^2\\right|}", block: true)



#tao-math(" & \\leq \\frac{\\left|A^3\\right| \\left|B^4\\right|}{\\left|A\\right|/K_3}", block: true)



#tao-math(" & \\leq K_1^2 K_2^3 K_3 \\left|B\\right|", block: true)
]

#text("and hence by the Ruzsa covering lemma, ")#mi("{AB}")#text(" is covered by at most ")#mi("{K_1^2 K_2^3 K_3}")#text(" left translates of ")#mi("{B^2}")#text(", and hence by ")#mi("{K_1^2 K_2^4 K_3}")#text(" left translates of ")#mi("{B}")#text(", and hence of ")#mi("{A \\cup B}")#text(". Similarly ")#mi("{BA}")#text(" is covered by at most ")#mi("{K_1^4 K_2^2 K_3}")#text(" left translates of ")#mi("{B}")#text(". The claim follows.")

#text("Now we consider ")#mi("{A^2 \\cap B^2}")#text(". Again, this is clearly symmetric and contains the identity. Repeating the previous arguments, we see that ")#mi("{A}")#text(" is covered by at most ")#mi("{K_1^2 K_2^3 K_3}")#text(" left-translates of ")#mi("{B}")#text(", and hence there exists a group element ")#mi("{g}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap gB\\right| \\geq \\frac{1}{K_1^2 K_2^3 K_3} |A|.", block: true)]]

#text("Now observe that")

#align(center)[#tao-fit-display[#tao-math("\\left|(A^2 \\cap B^2)^2 (A \\cap gB)\\right| \\leq \\left|A^5\\right| \\leq K_1^4 \\left|A\\right|", block: true)]]

#text("and so by the Ruzsa covering lemma, ")#mi("{(A^2 \\cap B^2)^2}")#text(" can be covered by at most ")#mi("{K_1^6 K_2^3 K_3}")#text(" left-translates of ")#mi("{(A \\cap gB) (A \\cap gB)^{-1}}")#text(". But this latter set is (as observed previously) contained in ")#mi("{A^2 \\cap B^2}")#text(", and the claim follows. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/06/03/nested-approximate-subgroups/#comment-456385")[#strong[#text("A SAGE experiment on Nested Approximate Subgroups | Ashani Dasgupta")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2015")]

#text("[…] This concerns a computational experiment (in SAGE platform) inspired by an article by Terence Tao on Nested Approximate Subgroup. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/416b6b963e71c131a49265fb7a9b8cdfde4b4e0479e79ec61450fefe51b913bc-8146e903b4f12a24e376fa093da607dbd49ed65cf497956859efebb310e51a5d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashani Dasgupta")]], [#link("https://terrytao.wordpress.com/2015/06/03/nested-approximate-subgroups/#comment-456435")[#strong[#text("Ashani Dasgupta")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2015")])]

#text("Professor Tao,")

#text("I am trying understand this article. However Ruzsa Calculus and allied topics are unknown to me (I have complete in by undergrad course in mathematics last year).")#linebreak()#text(" In my experience, tracking down good introductory book in any topic can be a critical and daunting task. So I thought of asking for your suggestion. Can you advice me to find a book on that topic to understand this article more vividly?")

#text("Regards,")

#text("Ashani Dasgupta")#linebreak()#text(" ")#link("mailto:ashanidasgupta@yahoo.com")[#text("ashanidasgupta@yahoo.com")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/06/03/nested-approximate-subgroups/#comment-456478")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2015")])]

#text("You can try my book with Van Vu on these topics: ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("https://terrytao.wordpress.com/books/additive-combinatorics/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/416b6b963e71c131a49265fb7a9b8cdfde4b4e0479e79ec61450fefe51b913bc-8146e903b4f12a24e376fa093da607dbd49ed65cf497956859efebb310e51a5d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashani Dasgupta")]], [#link("https://terrytao.wordpress.com/2015/06/03/nested-approximate-subgroups/#comment-456479")[#strong[#text("Ashani Dasgupta")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2015")])]

#text("Thanks for the response. I will")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/06/03/nested-approximate-subgroups/#comment-669682")[#strong[#text("A SAGE experiment on Nested Approximate Subgroups – Ashani Dasgupta")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2022")]

#text("[…] This concerns a computational experiment (in SAGE platform) inspired by an article by Terence Tao on Nested Approximate Subgroup. […]")
]
