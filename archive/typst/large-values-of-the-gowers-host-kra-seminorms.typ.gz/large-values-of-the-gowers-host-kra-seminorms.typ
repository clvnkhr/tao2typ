// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/12/16/large-values-of-the-gowers-host-kra-seminorms/
// Converted to Typst by tao2typ: "2026-10-14T09:05:43.529318+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Large values of the Gowers-Host-Kra seminorms", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Large values of the Gowers-Host-Kra seminorms")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 December 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/12/16/large-values-of-the-gowers-host-kra-seminorms/")[#text("https://terrytao.wordpress.com/2010/12/16/large-values-of-the-gowers-host-kra-seminorms/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("﻿")

#link("http://www.fa.uni-tuebingen.de/members/talo")[#text("Tanja Eisner")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1012.3509")[#text("Large values of the Gowers-Host-Kra seminorms")]#text("“, submitted to ")#link("http://www.ma.huji.ac.il/jdm/")[#text("Journal d’Analyse Mathematique")]#text(". This paper is concerned with the properties of three closely related families of (semi)norms, indexed by a positive integer ")#mi("{k}")#text(":")

#list(
[#text("The ")#emph[#text("Gowers uniformity norms")]#text(" ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)}}", block: false)#text(" of a (bounded, measurable, compactly supported) function ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" taking values on a locally compact abelian group ")#mi("{G}")#text(", equipped with a Haar measure ")#mi("{\\mu}")#text(";")],
[#text("The Gowers uniformity norms ")#tao-math("{\\left\\|f\\right\\|_{U^k([N])}}", block: false)#text(" of a function ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" on a discrete interval ")#mi("{\\{1,\\ldots,N\\}}")#text("; and")],
[#text("The Gowers-Host-Kra seminorms ")#tao-math("{\\left\\|f\\right\\|_{U^k(X)}}", block: false)#text(" of a function ")#mi("{f \\in L^\\infty(X)}")#text(" on an ergodic measure-preserving system ")#mi("{X = (X,{\\mathcal X},\\mu,T)}")#text(".")]
)

#text("These norms have been discussed in depth in ")#link("https://terrytao.wordpress.com/tag/gowers-uniformity-norms/")[#text("previous blog posts")]#text(", so I will just quickly review the definition of the first norm here (the other two (semi)norms are defined similarly). The ")#mi("{U^k(G)}")#text(" norm is defined recursively by setting")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{U^1(G)} := \\left|\\int_G f\\ d\\mu\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^k(G)}^{2^k} := \\int_G \\left\\| \\Delta_h f \\right\\|_{U^{k-1}(G)}^{2^{k-1}}\\ d\\mu(h)", block: true)]]

#text("where ")#mi("{\\Delta_h f(x) := f(x+h) \\overline{f(x)}}")#text(". Equivalently, one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^k(G)} := (\\int_G \\ldots \\int_G \\Delta_{h_1} \\ldots \\Delta_{h_k} f(x)\\ d\\mu(x) d\\mu(h_1) \\ldots d\\mu(h_k))^{1/2^k}.", block: true)]]

#text("Informally, the Gowers uniformity norm ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)}}", block: false)#text(" measures the extent to which (the phase of ")#mi("{f}")#text(") behaves like a polynomial of degree less than ")#mi("{k}")#text(". Indeed, if ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(G)} \\leq 1}", block: false)#text(" and ")#mi("{G}")#text(" is compact with normalised Haar measure ")#mi("{\\mu(G)=1}")#text(", it is not difficult to show that ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)}}", block: false)#text(" is at most ")#mi("{1}")#text(", with equality if and only if ")#mi("{f}")#text(" takes the form ")#mi("{f = e(P) := e^{2\\pi iP}}")#text(" almost everywhere, where ")#mi("{P: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a polynomial of degree less than ")#mi("{k}")#text(" (which means that ")#mi("{\\partial_{h_1} \\ldots \\partial_{h_k} P(x) = 0}")#text(" for all ")#mi("{x,h_1,\\ldots,h_k \\in G}")#text(").")

#text("Our first result is to show that this result is robust, uniformly over all choices of group ")#mi("{G}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (")#mi("{L^\\infty}")#text("-near extremisers)")]#text(" Let ")#mi("{G}")#text(" be a compact abelian group with normalised Haar measure ")#mi("{\\mu(G)=1}")#text(", and let ")#mi("{f \\in L^\\infty(G)}")#text(" be such that ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(G)} \\leq 1}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)} \\geq 1-\\epsilon}", block: false)#text(" for some ")#mi("{\\epsilon > 0}")#text(" and ")#mi("{k \\geq 1}")#text(". Then there exists a polynomial ")#mi("{P: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" of degree at most ")#mi("{k-1}")#text(" such that ")#tao-math("{\\left\\|f-e(P)\\right\\|_{L^1(G)} = o(1)}", block: false)#text(", where ")#mi("{o(1)}")#text(" is bounded by a quantity ")#mi("{c_k(\\epsilon)}")#text(" that goes to zero as ")#mi("{\\epsilon \\rightarrow 0}")#text(" for fixed ")#mi("{k}")#text(".")
]

#text("The quantity ")#mi("{o(1)}")#text(" can be described effectively (it is of polynomial size in ")#mi("{\\epsilon}")#text("), but we did not seek to optimise it here. This result was already known in the case of vector spaces ")#mi("{G = {\\bf F}_p^n}")#text(" over a fixed finite field ")#mi("{{\\bf F}_p}")#text(" (where it is essentially equivalent to the assertion that the property of being a polynomial of degree at most ")#mi("{k-1}")#text(" is locally testable); the extension to general groups ")#mi("{G}")#text(" turns out to fairly routine. The basic idea is to use the recursive structure of the Gowers norms, which tells us in particular that if ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)}}", block: false)#text(" is close to one, then ")#tao-math("{\\left\\|\\Delta_h f\\right\\|_{U^{k-1}(G)}}", block: false)#text(" is close to one for most ")#mi("{h}")#text(", which by induction implies that ")#mi("{\\Delta_h f}")#text(" is close to ")#mi("{e(Q_h)}")#text(" for some polynomials ")#mi("{Q_h}")#text(" of degree at most ")#mi("{k-2}")#text(" and for most ")#mi("{h}")#text(". (Actually, it is not difficult to use cocycle equations such as ")#mi("{\\Delta_{h+k} f = \\Delta_h f \\times T^h \\Delta_k f}")#text(" (when ")#tao-math("{\\left|f\\right|=1}", block: false)#text(") to upgrade “for most ")#mi("{h}")#text("” to “for all ")#mi("{h}")#text("“.) To finish the job, one would like to express the ")#mi("{Q_h}")#text(" as derivatives ")#mi("{Q_h = \\partial_h P}")#text(" of a polynomial ")#mi("{P}")#text(" of degree at most ")#mi("{k-1}")#text(". This turns out to be equivalent to requiring that the ")#mi("{Q_h}")#text(" obey the cocycle equation")

#align(center)[#tao-fit-display[#mitex("Q_{h+k} = Q_h + T^h Q_k")]]

#text("where ")#mi("{T^h F(x) := F(x+h)}")#text(" is the translate of ")#mi("{F}")#text(" by ")#mi("{h}")#text(". (In the paper, the sign conventions are reversed, so that ")#mi("{T^h F(x) := F(x-h)}")#text(", in order to be compatible with ergodic theory notation, but this makes no substantial difference to the arguments or results.) However, one does not quite get this right away; instead, by using some separation properties of polynomials, one can show the weaker statement that ")#metadata(none) <tao-526d29a3c33b25d99673>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("Q_{h+k} = Q_h + T^h Q_k + c_{h,k}")]]

#text("where the ")#mi("{c_{h,k}}")#text(" are small real constants. To eliminate these constants, one exploits the trivial cohomology of the real line. From ")#link(<tao-526d29a3c33b25d99673>)[#text("(1)")]#text(" one soon concludes that the ")#mi("{c_{h,k}}")#text(" obey the ")#mi("{2}")#text("-cocycle equation")

#align(center)[#tao-fit-display[#mitex("c_{h,k} + c_{h+k,l} = c_{h,k+l} + c_{k,l}")]]

#text("and an averaging argument then shows that ")#mi("{c_{h,k}}")#text(" is a ")#mi("{2}")#text("-coboundary in the sense that")

#align(center)[#tao-fit-display[#mitex("c_{h,k} = b_{h+k} - b_h - b_k")]]

#text("for some small scalar ")#mi("{b_h}")#text(" depending on ")#mi("{h}")#text(". Subtracting ")#mi("{b_h}")#text(" from ")#mi("{Q_h}")#text(" then gives the claim.")

#text("Similar results and arguments also hold for the ")#mi("{U^k([N])}")#text(" and ")#mi("{U^k(X)}")#text(" norms, which we will not detail here.")

#text("Dimensional analysis reveals that the ")#mi("{L^\\infty}")#text(" norm is not actually the most natural norm with which to compare the ")#mi("{U^k}")#text(" norms against. An application of Young’s convolution inequality in fact reveals that one has the inequality ")#metadata(none) <tao-86048c1f8ce818d09828>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|f\\right\\|_{U^k(G)} \\leq \\left\\|f\\right\\|_{L^{p_k}(G)}", block: true)]]

#text("where ")#mi("{p_k}")#text(" is the critical exponent ")#mi("{p_k := 2^k/(k+1)}")#text(", without any compactness or normalisation hypothesis on the group ")#mi("{G}")#text(" and the Haar measure ")#mi("{\\mu}")#text(". This allows us to extend the ")#mi("{U^k(G)}")#text(" norm to all of ")#mi("{L^{p_k}(G)}")#text(". There is then a stronger inverse theorem available:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (")#mi("{L^{p_k}}")#text("-near extremisers)")]#text(" Let ")#mi("{G}")#text(" be a locally compact abelian group, and let ")#mi("{f \\in L^{p_k}(G)}")#text(" be such that ")#tao-math("{\\left\\|f\\right\\|_{L^{p_k}(G)} \\leq 1}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)} \\geq 1-\\epsilon}", block: false)#text(" for some ")#mi("{\\epsilon > 0}")#text(" and ")#mi("{k \\geq 1}")#text(". Then there exists a coset ")#mi("{H}")#text(" of a compact open subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(", and a polynomial ")#mi("{P: H to {\\bf R}/{\\bf Z}}")#text(" of degree at most ")#mi("{k-1}")#text(" such that ")#tao-math("{\\left\\|f-e(P) 1_H\\right\\|_{L^{p_k}(G)} = o(1)}", block: false)#text(".")
]

#text("Conversely, it is not difficult to show that equality in ")#link(<tao-86048c1f8ce818d09828>)[#text("(2)")]#text(" is attained when ")#mi("{f}")#text(" takes the form ")#mi("{e(P) 1_H}")#text(" as above. The main idea of proof is to use an inverse theorem for Young’s inequality ")#link("http://www.ams.org/mathscinet-getitem?mr=461034")[#text("due to Fournier")]#text(" to reduce matters to the ")#mi("{L^\\infty}")#text(" case that was already established. An analogous result is also obtained for the ")#mi("{U^k(X)}")#text(" norm on an ergodic system; but for technical reasons, the methods do not seem to apply easily to the ")#mi("{U^k([N])}")#text(" norm. (This norm is essentially equivalent to the ")#mi("{U^k({\\bf Z}/\\tilde N{\\bf Z})}")#text(" norm up to constants, with ")#mi("{\\tilde N}")#text(" comparable to ")#mi("{N}")#text(", but when working with near-extremisers, norms that are only equivalent up to constants can have quite different near-extremal behaviour.)")

#text("In the case when ")#mi("{G}")#text(" is a Euclidean group ")#mi("{{\\bf R}^d}")#text(", it is possible to use the sharp Young inequality ")#link("http://www.ams.org/mathscinet-getitem?mr=385456")[#text("of Beckner")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=412366")[#text("of Brascamp-Lieb")]#text(" to improve ")#link(<tao-86048c1f8ce818d09828>)[#text("(2)")]#text(" somewhat. For instance, when ")#mi("{k=3}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^3({\\bf R}^d)} \\leq 2^{-d/8} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("with equality attained if and only if ")#mi("{f}")#text(" is a gaussian modulated by a quadratic polynomial phase. This additional gain of ")#mi("{2^{-d/8}}")#text(" allows one to pinpoint the threshold ")#mi("{1-\\epsilon}")#text(" for the previous near-extremiser results in the case of ")#mi("{U^3}")#text(" norms. For instance, by using the ")#link("https://terrytao.wordpress.com/2010/12/16/large-values-of-the-gowers-host-kra-seminorms/???")[#text("Host-Kra machinery")]#text(" of characteristic factors for the ")#mi("{U^3(X)}")#text(" norm, combined with an explicit and concrete analysis of the ")#mi("{2}")#text("-step nilsystems generated by that machinery, we can show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^3(X)} \\leq 2^{-1/8} \\left\\|f\\right\\|_{L^2(X)}", block: true)]]

#text("whenever ")#mi("{X}")#text(" is a ")#emph[#text("totally")]#text(" ergodic system and ")#mi("{f}")#text(" is orthogonal to all linear and quadratic eigenfunctions (which would otherwise form immediate counterexamples to the above inequality), with the factor ")#mi("{2^{-1/8}}")#text(" being best possible. We can also establish analogous results for the ")#mi("{U^3([N])}")#text(" and ")#mi("{U^3({\\bf Z}/N{\\bf Z})}")#text(" norms (using the inverse ")#mi("{U^3}")#text(" theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=2391635")[#text("Ben Green and myself")]#text(", in place of the Host-Kra machinery), although it is not clear to us whether the ")#mi("{2^{-1/8}}")#text(" threshold remains best possible in this case.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2010/12/16/large-values-of-the-gowers-host-kra-seminorms/#comment-505607")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2018")])]

#text("Dear Terence Tao, could you please indicate some more detail on how one deduces from (1) the 2-cocyle equation c_{h,k} + c_{h+k,l} = c_{h,k+l} + c_{k,l} ? In your paper with Eisner I cannot see any details either for how to do this deduction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/16/large-values-of-the-gowers-host-kra-seminorms/#comment-505617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2018")])]

#text("From (1) we have ")#mi("Q_{h+k+l} = Q_h + T^h Q_{k+l} + c_{h,k+l}")#text(", ")#mi("Q_{k+l} = Q_k + T^k Q_l + c_{k,l}")#text(", ")#mi("Q_{h+k+l} = Q_{h+k} + T^{h+k} Q_l + c_{h+k,l}")#text(", and ")#mi("Q_{h+k} = Q_h + T^h Q_k + c_{h,k}")#text(". Use these identities to expand out ")#mi("Q_{h+k+l}")#text(" in two different ways and collect terms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/12/16/large-values-of-the-gowers-host-kra-seminorms/#comment-505704")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2018")])]

#text("Great, thank you!")
]
]
]
