// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/
// Converted to Typst by tao2typ: "2026-10-14T15:17:29.892536+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An entropy Plünnecke-Ruzsa inequality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An entropy Plünnecke-Ruzsa inequality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/")[#text("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A handy inequality in additive combinatorics is the ")#link("http://www.ams.org/mathscinet-getitem?mr=2314377")[#text("Plünnecke-Ruzsa inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Plünnecke-Ruzsa inequality)")]#text(" ")#metadata(none) <tao-fc386e015c17c7fcf069>#text(" Let ")#mi("{A, B_1, \\ldots, B_m}")#text(" be finite non-empty subsets of an additive group ")#mi("{G}")#text(", such that ")#tao-math("{\\left|A+B_i\\right| \\leq K_i \\left|A\\right|}", block: false)#text(" for all ")#mi("{1 \\leq i \\leq m}")#text(" and some scalars ")#mi("{K_1,\\ldots,K_m \\geq 1}")#text(". Then there exists a subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" such that ")#tao-math("{\\left|A^{\\prime} + B_1 + \\ldots + B_m\\right| \\leq K_1 \\ldots K_m \\left|A^{\\prime}\\right|}", block: false)#text(".")
]

#text("The proof uses graph-theoretic techniques. Setting ")#mi("{A=B_1=\\ldots=B_m}")#text(", we obtain a useful corollary: if ")#mi("{A}")#text(" has small doubling in the sense that ")#tao-math("{\\left|A+A\\right| \\leq K\\left|A\\right|}", block: false)#text(", then we have ")#tao-math("{\\left|mA\\right| \\leq K^m \\left|A\\right|}", block: false)#text(" for all ")#mi("{m \\geq 1}")#text(", where ")#mi("{mA = A + \\ldots + A}")#text(" is the sum of ")#mi("{m}")#text(" copies of ")#mi("{A}")#text(".")

#text("In ")#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/")[#text("a recent paper")]#text(", I adapted a number of sum set estimates to the entropy setting, in which finite sets such as ")#mi("{A}")#text(" in ")#mi("{G}")#text(" are replaced with discrete random variables ")#mi("{X}")#text(" taking values in ")#mi("{G}")#text(", and (the logarithm of) cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(" of a set ")#mi("{A}")#text(" is replaced by ")#link("http://en.wikipedia.org/wiki/Information_entropy")[#text("Shannon entropy")]#text(" ")#mi("{{\\Bbb H}(X)}")#text(" of a random variable ")#mi("{X}")#text(". (Throughout this note I assume all entropies to be finite.) However, at the time, I was unable to find an entropy analogue of the Plünnecke-Ruzsa inequality, because I did not know how to adapt the graph theory argument to the entropy setting.")

#text("I recently discovered, however, that buried in a ")#link("http://www.ams.org/mathscinet-getitem?mr=704539")[#text("classic paper of Kaimonovich and Vershik")]#text(" (implicitly in Proposition 1.3, to be precise) there was the following analogue of Theorem ")#link(<tao-fc386e015c17c7fcf069>)[#text("1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Entropy Plünnecke-Ruzsa inequality)")]#text(" ")#metadata(none) <tao-87e41e04863be00a3f5f>#text(" Let ")#mi("{X, Y_1, \\ldots, Y_m}")#text(" be independent random variables of finite entropy taking values in an additive group ")#mi("{G}")#text(", such that ")#mi("{{\\Bbb H}(X+Y_i) \\leq {\\Bbb H}(X) + \\log K_i}")#text(" for all ")#mi("{1 \\leq i \\leq m}")#text(" and some scalars ")#mi("{K_1,\\ldots,K_m \\geq 1}")#text(". Then ")#mi("{{\\Bbb H}(X+Y_1+\\ldots+Y_m) \\leq {\\Bbb H}(X) + \\log K_1 \\ldots K_m}")#text(".")
]

#text("In fact Theorem ")#link(<tao-87e41e04863be00a3f5f>)[#text("2")]#text(" is a bit “better” than Theorem ")#link(<tao-fc386e015c17c7fcf069>)[#text("1")]#text(" in the sense that Theorem ")#link(<tao-fc386e015c17c7fcf069>)[#text("1")]#text(" needed to refine the original set ")#mi("{A}")#text(" to a subset ")#mi("{A^{\\prime}}")#text(", but no such refinement is needed in Theorem ")#link(<tao-87e41e04863be00a3f5f>)[#text("2")]#text(". One corollary of Theorem ")#link(<tao-87e41e04863be00a3f5f>)[#text("2")]#text(" is that if ")#mi("{{\\Bbb H}(X_1+X_2) \\leq {\\Bbb H}(X) + \\log K}")#text(", then ")#mi("{{\\Bbb H}(X_1+\\ldots+X_m) \\leq {\\Bbb H}(X) + (m-1) \\log K}")#text(" for all ")#mi("{m \\geq 1}")#text(", where ")#mi("{X_1,\\ldots,X_m}")#text(" are independent copies of ")#mi("{X}")#text("; this improves slightly over the analogous combinatorial inequality. Indeed, the function ")#mi("{m \\mapsto {\\Bbb H}(X_1+\\ldots+X_m)}")#text(" is concave (this can be seen by using the ")#mi("{m=2}")#text(" version of Theorem ")#link(<tao-87e41e04863be00a3f5f>)[#text("2")]#text(" (or ")#link(<tao-3608bca1e44ea6c4d268>)[#text("(2)")]#text(" below) to show that the quantity ")#mi("{{\\Bbb H}(X_1+\\ldots+X_{m+1})-{\\Bbb H}(X_1+\\ldots+X_m)}")#text(" is decreasing in ")#mi("{m}")#text(").")

#text("Theorem ")#link(<tao-87e41e04863be00a3f5f>)[#text("2")]#text(" is actually a quick consequence of the ")#emph[#text("submodularity inequality")]#text(" ")#metadata(none) <tao-6d9e26c2e0533e2488c7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\Bbb H}(W) + {\\Bbb H}(X) \\leq {\\Bbb H}(Y) + {\\Bbb H}(Z)")]]

#text("in information theory, which is valid whenever ")#mi("{X,Y,Z,W}")#text(" are discrete random variables such that ")#mi("{Y}")#text(" and ")#mi("{Z}")#text(" each determine ")#mi("{X}")#text(" (i.e. ")#mi("{X}")#text(" is a function of ")#mi("{Y}")#text(", and also a function of ")#mi("{Z}")#text("), and ")#mi("{Y}")#text(" and ")#mi("{Z}")#text(" jointly determine ")#mi("{W}")#text(" (i.e ")#mi("{W}")#text(" is a function of ")#mi("{Y}")#text(" and ")#mi("{Z}")#text("). To apply this, let ")#mi("{X, Y, Z}")#text(" be independent discrete random variables taking values in ")#mi("{G}")#text(". Observe that the pairs ")#mi("{(X,Y+Z)}")#text(" and ")#mi("{(X+Y,Z)}")#text(" each determine ")#mi("{X+Y+Z}")#text(", and jointly determine ")#mi("{(X,Y,Z)}")#text(". Applying ")#link(<tao-6d9e26c2e0533e2488c7>)[#text("(1)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\Bbb H}(X,Y,Z) + {\\Bbb H}(X+Y+Z) \\leq {\\Bbb H}(X,Y+Z) + {\\Bbb H}(X+Y,Z)")]]

#text("which after using the independence of ")#mi("{X,Y,Z}")#text(" simplifies to the ")#emph[#text("sumset submodularity inequality")]#text(" ")#metadata(none) <tao-3608bca1e44ea6c4d268>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\Bbb H}(X+Y+Z) + {\\Bbb H}(Y) \\leq {\\Bbb H}(X+Y) + {\\Bbb H}(Y+Z)")]]

#text("(this inequality was also recently observed ")#link("http://www.stat.yale.edu/~mm888/Pubs/2008/ITW-sums08.pdf")[#text("by Madiman")]#text("; it is the ")#mi("{m=2}")#text(" case of Theorem ")#link(<tao-87e41e04863be00a3f5f>)[#text("2")]#text("). As a corollary of this inequality, we see that if ")#mi("{{\\Bbb H}(X+Y_i) \\leq {\\Bbb H}(X) + \\log K_i}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\Bbb H}(X+Y_1+\\ldots+Y_i) \\leq {\\Bbb H}(X+Y_1+\\ldots+Y_{i-1}) + \\log K_i,")]]

#text("and Theorem ")#link(<tao-87e41e04863be00a3f5f>)[#text("2")]#text(" follows by telescoping series.")

#text("The proof of Theorem ")#link(<tao-87e41e04863be00a3f5f>)[#text("2")]#text(" seems to be genuinely different from the graph-theoretic proof of Theorem ")#link(<tao-fc386e015c17c7fcf069>)[#text("1")]#text(". It would be interesting to see if the above argument can be somehow adapted to give a stronger version of Theorem ")#link(<tao-fc386e015c17c7fcf069>)[#text("1")]#text(". Note also that both Theorem ")#link(<tao-fc386e015c17c7fcf069>)[#text("1")]#text(" and Theorem ")#link(<tao-87e41e04863be00a3f5f>)[#text("2")]#text(" have extensions to more general combinations of ")#mi("{X,Y_1,\\ldots,Y_m}")#text(" than ")#mi("{X+Y_i}")#text("; see ")#link("http://arxiv.org/abs/0810.1488")[#text("this paper")]#text(" and ")#link("http://www.stat.yale.edu/~mm888/Pubs/2008/ITW-sums08.pdf")[#text("this paper")]#text(" respectively.")

#metadata(none) <tao-8ff987e013a1c0ef733e>

#text("It is also worth remarking that the above inequalities largely carry over to the non-abelian setting. For instance, if ")#mi("{X_1, X_2,\\ldots}")#text(" are iid copies of a discrete random variable in a multiplicative group ")#mi("{G}")#text(", the above arguments show that the function ")#mi("{m \\mapsto {\\Bbb H}(X_1 \\ldots X_m)}")#text(" is concave. In particular, the expression ")#mi("{\\frac{1}{m} {\\Bbb H}(X_1 \\ldots X_m)}")#text(" decreases monotonically to a limit, the ")#emph[#text("asymptotic entropy")]#text(" ")#mi("{{\\Bbb H}(G,X)}")#text(". This quantity plays an important role in the theory of bounded harmonic functions on ")#mi("{G}")#text(", as observed by ")#link("http://www.ams.org/mathscinet-getitem?mr=704539")[#text("Kaimonovich and Vershik")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" Let ")#mi("{G}")#text(" be a discrete group, and let ")#mi("{X}")#text(" be a discrete random variable in ")#mi("{G}")#text(" with finite entropy, whose support generates ")#mi("{G}")#text(". Then there exists a non-constant bounded function ")#mi("{f: G \\rightarrow {\\Bbb R}}")#text(" which is harmonic with respect to ")#mi("{X}")#text(" (which means that ")#mi("{{\\Bbb E} f(X x) = f(x)}")#text(" for all ")#mi("{x \\in G}")#text(") if and only if ")#mi("{{\\Bbb H}(G,X) \\neq 0}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) Suppose first that ")#mi("{{\\Bbb H}(G,X) = 0}")#text(", then we see from concavity that the successive differences ")#mi("{{\\Bbb H}(X_1 \\ldots X_m) - {\\Bbb H}(X_1 \\ldots X_{m-1})}")#text(" converge to zero. From this it is not hard to see that the ")#link("http://en.wikipedia.org/wiki/Mutual_information")[#text("mutual information")]

#align(center)[#tao-fit-display[#mitex("{\\Bbb I}(X_m, X_1 \\ldots X_m) := {\\Bbb H}(X_m) + {\\Bbb H}(X_1 \\ldots X_m) - {\\Bbb H}(X_m|X_1 \\ldots X_m)")]]

#text("goes to zero as ")#mi("{m \\rightarrow \\infty}")#text(". Informally, knowing the value of ")#mi("{X_m}")#text(" reveals very little about the value of ")#mi("{X_1 \\ldots X_m}")#text(" when ")#mi("{m}")#text(" is large.")

#text("Now let ")#mi("{f: G \\rightarrow {\\Bbb R}}")#text(" be a bounded harmonic function, and let ")#mi("{m}")#text(" be large. For any ")#mi("{x \\in G}")#text(" and any value ")#mi("{s}")#text(" in the support of ")#mi("{X_m}")#text(", we observe from harmonicity that")

#align(center)[#tao-fit-display[#mitex("f( s x ) = {\\Bbb E}( f( X_1 \\ldots X_m x ) | X_m = s ).")]]

#text("But from the asymptotic vanishing of mutual information and the boundedness of ")#mi("{f}")#text(", one can show that the right-hand side will converge to ")#mi("{{\\Bbb E}( f(X_1 \\ldots X_m x) )}")#text(", which by harmonicity is equal to ")#mi("{f(x)}")#text(". Thus ")#mi("{f}")#text(" is invariant with respect to the support of ")#mi("{X}")#text(", and is thus constant since this support generates ")#mi("{G}")#text(".")

#text("Conversely, if ")#mi("{{\\Bbb H}(G,X)}")#text(" is non-zero, then the above arguments show that ")#mi("{{\\Bbb I}(X_m, X_1 \\ldots X_m)}")#text(" stays bounded away from zero as ")#mi("{m \\rightarrow \\infty}")#text(", thus ")#mi("{X_1 \\ldots X_m}")#text(" reveals a non-trivial amount of information about ")#mi("{X_m}")#text(". This turns out to be true even if ")#mi("{m}")#text(" is not deterministic, but is itself random, varying over some medium-sized range. From this, one can find a bounded function ")#mi("{F}")#text(" such that the conditional expectation ")#mi("{{\\Bbb E}(F(X_1 \\ldots X_m) | X_m = s)}")#text(" varies non-trivially with ")#mi("{s}")#text(". On the other hand, the bounded function ")#mi("{x \\mapsto {\\Bbb E} F(X_1 \\ldots X_{m-1} x)}")#text(" is approximately harmonic (because we are varying ")#mi("{m}")#text("), and has some non-trivial fluctuation near the identity (by the preceding sentence). Taking a limit as ")#mi("{m \\rightarrow \\infty}")#text(" (using Arzelá-Ascoli) we obtain a non-constant bounded harmonic function as desired. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-42057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2009")])]

#text("Dear Prof. Tao,")

#text("What is the definition of ")#mi("{\\Bbb H}(X)")#text("?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-42058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2009")])]

#text("This is the Shannon entropy of X; I’ve updated the text slightly to emphasise this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-42059")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2009")])]

#text("Dear Terry,")

#text("1) It is my understanding that nobody presently knows how to deduce Theorem 1 from Theorem 2 or vice versa; but do you believe that such deductions exist somewhere in The Book?")

#text("2) Could you explain why is ")#mi("m\\mapsto H(X_1+...+X_m)")#text(" a concave function and how this fact is related to Theorem 2?")

#text("3) Two typos: Kaimonovich is misspelled (both times), and the parenthetical note three lines below equation (1) should read “")#mi("W")#text(" is a function of ")#mi("Y")#text(" and ")#mi("Z")#text("“.")

#text("Thanks for the post!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-42060")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2009")])]

#text("Thanks for the corrections! The concavity comes from the m=2 case of Theorem 2 (i.e. the inequality (2)); I’ve updated the post to sketch the proof.")

#text("Regarding the connection between combinatorial and entropy sum set estimates, the key difference is that one can perturb random variables a little bit without affecting the entropy of those variables or of their sum, but if one adds or removes a few elements from a set, the sumset can change dramatically. Roughly speaking, it seems that entropy sumset estimates correspond to combinatorial estimates for the “essential” component of the sumsets A+B, which is a loosely defined term but can be thought of as the sums in A+B that have _many_ representations of the form a+b, rather than just at least one. There does seem to be some sort of correspondence between entropy sum set estimates and combinatorial essential sum set estimates by using the tensor power trick, noting that when one takes n iid samples for n large of a discrete random variable X then one approximately gets a uniform distribution on ")#mi("\\exp( n ({\\Bbb H}(X)+o(1)) )")#text(" points (this is the “microstate” formulation of entropy). I haven’t tried to make this correspondence rigorous though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b4fdca29e9957d0c47b0e11aa8057962fbef4e5a5973cfd2aa55b60fea3c5119-d1254990b1369ba6006882483e1a56889a1b57b0f0d639e4371cb507c1a32bf1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Fine")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-42487")[#strong[#text("Jonathan Fine")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2009")])]

#text("Sort of off-topic, and definitely non-mathematical. The formula for Shannon entropy is, from time to time, not parsing.")

#text("Here’s the formula (if not mangled in the HTML.")#linebreak()#text(" ")#link("http://l.wordpress.com/latex.php?latex=Bbb+H%28X%29&bg=ffffff&fg=000000&s=0")[#text("http://l.wordpress.com/latex.php?latex=Bbb+H%28X%29&bg=ffffff&fg=000000&s=0")]

#text("I suspect that it may be because WordPress has set up several image servers, and they are not all running the same software.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e58625db1953eee19c28de26f4a69a7dd562d02ceee0f8561ae9ddcd150dd60-57da48480f6f130d3dc480a1825db6c69366f40f876ac44af00168b231707a8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiannis")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-43559")[#strong[#text("Yiannis")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("hi,")

#text("though elementary, the inequality in Theorem 2 is really neat. do you have any applications in mind — any way it can be used, e.g., to prove entropy inequalities analogous to sumset (or inverse sumset) bounds that use the classical Plünnecke inequality?")

#text("thanks!")#linebreak()#text(" yiannis")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-43561")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("Well, if I had known about this inequality in my previous paper on entropy sumset inequalities (op. cit.), then that would have shortened the proofs and tightened the constants a little bit in some places, though the gain is not too dramatic because there were other proofs of Plunnecke-type inequalities in the literature which already extended to the entropy setting.")

#text("Every so often I get tempted to do some sort of entropy gradient flow or something to try to prove Freiman’s theorem by entropy methods, but no luck thus far – it’s one thing to wish for a useful monotonicity formula for a gradient flow, but it’s another to actually find one…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of máté wierdl")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-224895")[#strong[#text("máté wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2013")])]

#text("I think there is small typo in the beginning: in the third line below the first framed result (Ruzsa-Plünnecke), you write $|mA|\\le K^m|A|$ when it should be $|mA|\\le K^{m-1}|A|$")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-224900")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2013")])]

#text("Unfortunately, the more natural bound ")#tao-math("\\left|mA\\right| \\leq K^{m-1} \\left|A\\right|", block: false)#text(", while possibly true, is not easily obtained from the Plunnecke-Ruzsa inequality, which instead gives that ")#tao-math("\\left|A^{\\prime} + mA\\right| \\leq K^m \\left|A\\right|", block: false)#text(" for some non-empty subset ")#mi("A^{\\prime}")#text(" of ")#mi("A")#text(", and then one has to use the crude inequality ")#tao-math("\\left|mA\\right| \\leq \\left|A^{\\prime}+mA\\right|", block: false)#text(" to conclude. I think the ")#tao-math("\\left|mA\\right| \\leq K^{m-1} \\left|A\\right|", block: false)#text(" bound remains open (even with the simplified new proof of Plunnecke-Ruzsa due to Petridis).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6bee38a54cd2271be89034454fa2ba8ff424bf6591e45bc91dda1f9cac5fa17-8f4d488bc24daa25daf62c14b64c16d6318202346fc3b9765214d6fd1010b1f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Shakan")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-541018")[#strong[#text("George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2020")])]

#text("Imre Ruzsa showed me a counterexample to this. Our set will be in ")#mi("\\mathbb{Z}^3")#text(". Take")#linebreak()#text(" ")#mi("A = [n]^3 \\cup e_1\\cdot [n^2] \\cup e_2 \\cdot [n^2] \\cup e_3 \\cdot [n^2]")#text(".")#linebreak()#text(" Then ")#tao-math("\\left|A\\right| \\sim n^3 , \\left|A+A\\right| \\sim n^4", block: false)#text(", and ")#tao-math("\\left|A+A+A\\right| \\sim n^6", block: false)#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Covering and Plünnecke’s inequality | George Shakan")]], [#link("https://terrytao.wordpress.com/2009/10/27/an-entropy-plunnecke-ruzsa-inequality/#comment-501709")[#strong[#text("Covering and Plünnecke’s inequality | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2018")])]

#text("[…] should be compared to this post of Tao, where he talks about an entropy version of Pl”{u}nnecke’s […]")
]
