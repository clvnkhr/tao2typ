// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/
// Converted to Typst by tao2typ: "2026-10-14T16:35:47.974953+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Operator splitting for the KdV equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Operator splitting for the KdV equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/")[#text("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("The summer continues to allow some clearing of the backlog of projects accumulated during the academic year: ")#link("http://www.math.ntnu.no/~holden/")[#text("Helge Holden")]#text(", ")#link("http://www.math.uio.no/~kennethk/")[#text("Kenneth Karlsen")]#text(", ")#link("http://folk.uio.no/nilshr/")[#text("Nils Risebro")]#text(", and myself have uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" the paper “")#link("http://arxiv.org/abs/0906.4902")[#text("Operator splitting for the KdV equation")]#text("“, submitted to ")#link("http://www.ams.org/mcom/")[#text("Math. Comp.")]#text(". This paper is concerned with accurate numerical schemes for solving initial value problems for the ")#link("http://en.wikipedia.org/wiki/Korteweg%E2%80%93de_Vries_equation")[#text("Korteweg-de Vries equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("u_t + u_{xxx} = u u_x; \\quad u(0,x) = u_0(x),")]]

#text("though the analysis here would be valid for a wide range of other semilinear dispersive models as well. In principle, these equations, which are ")#link("http://en.wikipedia.org/wiki/Integrable_system")[#text("completely integrable")]#text(", can be solved exactly by the ")#link("http://en.wikipedia.org/wiki/Inverse_scattering_transform")[#text("inverse scattering method")]#text(", but fast and accurate implementations of this method are still not as satisfactory as one would like. On the other hand, the")#link("http://tosio.math.toronto.edu/wiki/index.php/Airy_equation")[#text(" linear Korteweg-de Vries equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("u_t + u_{xxx} = 0; \\quad u(0,x) = u_0(x)")]]

#text("can be solved exactly (with accurate and fast numerics) via the (fast) Fourier transform, while the (inviscid) ")#link("http://en.wikipedia.org/wiki/Burgers%27_equation")[#text("Burgers equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u_t = u u_x; \\quad u(0,x) = u_0(x)")]]

#text("can also be solved exactly (and quickly) by the ")#link("http://en.wikipedia.org/wiki/Method_of_characteristics")[#text("method of characteristics")]#text(". Since the KdV equation is in some sense a combination of the equations (2) and (3), it is then reasonable to hope that some combination of the solution schemes for (2) and (3) can be used to solve (1), at least in some approximate sense.")

#text("One way to do this is by the method of ")#emph[#text("operator splitting")]#text(". Observe from the formal approximation ")#mi("e^{A \\Delta t} \\approx 1 + A \\Delta t + O( \\Delta t^2)")#text(" (where ")#mi("\\Delta t")#text(" should be thought of as small, and ")#mi("A")#text(" is some matrix or linear operator), that one has")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("e^{(A+B) \\Delta t} u_0 = e^{A \\Delta t} e^{B \\Delta t} u_0 + O( \\Delta t^2 ),")]]

#text("[we do not assume A and B to commute here] and thus we formally have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("e^{n (A+B) \\Delta t} u_0 = (e^{A \\Delta t} e^{B \\Delta t})^n u_0 + O( \\Delta t )")]]

#text("if ")#mi("n = T/\\Delta t")#text(" for some fixed time T (thus ")#mi("n = O(1/\\Delta t)")#text("). As a consequence, if one wants to solve the linear ODE")

#align(center)[#mi("u_t = (A+B) u; \\quad u(0) = u_0")#text(" (1′)")]

#text("for time ")#mi("T = n \\Delta t")#text(", one can achieve an approximate solution (accurate to order ")#mi("\\Delta t")#text(") by alternating ")#mi("n")#text(" times between evolving the ODE")

#align(center)[#mi("u_t = A u")#text(" (2′)")]

#text("for time ")#mi("\\Delta t")#text(", and evolving the ODE")

#align(center)[#mi("u_t = B u")#text(" (3′)")]

#text("for time ")#mi("\\Delta t")#text(", starting with the initial data ")#mi("u_0")#text(".")

#text("It turns out that this scheme can be formalised, and furthermore generalised to nonlinear settings such as those for the KdV equation (1). More precisely, we show that if ")#mi("u_0 \\in H^s({\\Bbb R})")#text(" for some ")#mi("s \\geq 5")#text(", then one can solve (1) to accuracy ")#mi("O(\\Delta t)")#text(" in ")#mi("H^s")#text(" norm for any fixed time ")#mi("T = n \\Delta t")#text(" by alternating between evolving (2) and (3) for times ")#mi("\\Delta t")#text(" (this scheme is known as ")#emph[#text("Godunov splitting")]#text(").")

#text("Actually, one can obtain faster convergence by modifying the scheme, at the cost of requiring higher regularity on the data; the situation is similar to that of ")#link("http://en.wikipedia.org/wiki/Numerical_integration")[#text("numerical integration (or quadrature)")]#text(", in which the ")#link("http://en.wikipedia.org/wiki/Midpoint_rule")[#text("midpoint rule")]#text(" or ")#link("http://en.wikipedia.org/wiki/Simpson%27s_rule")[#text("Simpson’s rule")]#text(" provide more accuracy than the Riemann integral if the integrand is smooth. For instance, one has the variant")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("e^{n (A+B) \\Delta t} = (e^{A \\Delta t/2} e^{B \\Delta t/2} e^{B \\Delta t/2} e^{A \\Delta t/2})^n + O( \\Delta t^2 )")]]

#text("of (5), which can be seen by expansion to second order in ")#mi("\\Delta t")#text(" (or by playing around with the ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula")[#text("Baker-Campbell-Hausdorff formula")]#text("). For KdV, we can rigorously show that the analogous scheme (known as ")#emph[#text("Strang splitting")]#text(") involving the indicated combination of evolutions of (2) and (3) will also converge to accuracy ")#mi("\\Delta t^2")#text(" in ")#mi("H^s")#text(" norm, provided that ")#mi("u_0 \\in H^s({\\Bbb R})")#text(" and ")#mi("s \\geq 17")#text(".")

#metadata(none) <tao-b9b42452b4b579047cee>#text("Our main tools are the energy method (i.e. computations of how ")#mi("H^s({\\Bbb R})")#text("-norm type energies of the solution evolve in time via differentiation and integration by parts), and the use of two time variables rather than one. To describe the second method, let us give a PDE-style proof of (4) (assuming that A, B are finite-dimensional matrices and u is vector-valued to avoid the technical complications associated with infinite dimensional vector spaces). We introduce two time variables ")#mi("t, \\tau")#text(" and consider the PDE problem")

#tao-aligned(keep: true)[


#tao-math("\\partial_\\tau u(t,\\tau)  & = A u(t,\\tau)", block: true)



#tao-math("\\partial_t u(t,0)  & = B u(t,0)", block: true)
]

#align(center)[#mi("u(0,0) = u_0")#text(".")]

#text("Thus, one first solves the equation (3′) along the t axis with initial data ")#mi("u_0")#text(", and then solves the equation (2′) in the ")#mi("\\tau")#text(" direction, thus leading to the explicit solution ")#mi("u(t,\\tau) = e^{\\tau A} e^{t B} u_0")#text(". In particular, the left-hand side of (4) is ")#mi("u(\\Delta t, \\Delta t)")#text(".")

#text("Now we look at the evolution of u along the diagonal axis. Observe from the chain rule that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{d}{dt} u(t,t) = (A+B) u(t,t) + F(t,t)")]]

#text("where ")#mi("F(t,\\tau) :=\\partial_t u(t,\\tau) - B u(t,\\tau)")#text(". On the other hand, F itself solves an ODE in the ")#mi("\\tau")#text(" direction:")

#tao-aligned(keep: true)[


#tao-math("\\partial_\\tau F  & = A F + [A,B] u", block: true)



#tao-math("F(t,0)  & = 0.", block: true)
]

#text("We thus have ")#mi("F(t,t) = O( t )")#text(" for small t, and then by ")#link("http://en.wikipedia.org/wiki/Duhamel%27s_integral")[#text("Duhamel’s formula")]#text(" and (7) we have ")#mi("u(t,t) = e^{(A+B)t} u_0 + O( t^2 )")#text(", which implies (4) as claimed. Note that this analysis also recovers the classical formula ")#mi("e^{(A+B)t} = e^{At} e^{Bt}")#text(" in the special case that A and B commute.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef3ae79bd944137a0ccf68ddfb4ed9dfeeb13f961a9a3b4d2ab56fa684b5a23a-2affba240ffd94ccd755a866d2425adef2dc8d0dcaadef7222e988fcfcbf79a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of demagogue")]], [#link("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/#comment-39779")[#strong[#text("demagogue")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2009")])]

#text("What a wonderful synthesis of ideas!")

#text("On a philosophical note though, isn’t it strange though that there aren’t better numerical methods available to solve completely integrable differential equations, given their infinite dimensional symmetries? Surely, given the way integrability was discovered by numerical work (Fermi-Pasta-Ulam, Kruskal-Zabusky, and in an even cruder sense, even John Scott Russell) there should be more numerical work in this field?")

#text("Although not an expert by any means, I know there has been a burgeoning field of numerical analysis which respects any given symmetries (in all sorts of problems) in recent years. I don’t know the details but most methods boil down to adapting standard numerically stable algorithms to a suitable notion of “orbit space”.")

#text("In a sense, this is “obvious”. If an analytically intractible problem has an ‘exact subpart’ then why throw it away? But the challenges in practice are difficult.")

#text("Here is a very interesting special issue of the Journal of Physics A dedicated to the topic of Geometric Numerical Integration of Differential Equations")

#link("http://www.iop.org/EJ/toc/0305-4470/39/19")[#text("http://www.iop.org/EJ/toc/0305-4470/39/19")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/#comment-39789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2009")])]

#text("Dear demagogue,")

#text("There is a substantial literature on numerical solutions on KdV, though this is more of my co-authors’ area of expertise than mine. In addition to operator splitting, Galerkin-based schemes appear to be rather popular. In contrast, the inverse scattering transform, despite being so fundamental to the theoretical solvability of KdV, seems to be very rarely used in the numerical solvability of this equation (except when dealing with very special solutions, e.g. multisoliton solutions), perhaps because there is no FFT-like way to quickly invert the scattering transform known currently. Similarly, the multiple conservation laws enjoyed by KdV do not seem to be exploited too much in the numerical schemes that are actually used in practice. (Operator splitting will preserve the L^2 norm, because both of the component equations preserve this norm, and also preserves the mass, but it does not respect the other symmetries of the equation.)")

#text("Dear asinop, I am not exactly sure what type of equations you would be seeking to solve here. The energy method (which underlies our approach here) can be applied to quite general background metrics, though if the equations become quasilinear or fully nonlinear rather than semilinear then one would need to proceed rather carefully in order not to lose so many derivatives that one can no longer close a continuity argument. If the background is evolving with the solution (as is the case with Ricci flow or the Einstein equations, for instance) then I suspect the method would not work well at all (though there is no obvious operator splitting for such equations in any case).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13b47d724c54a35c180dfaf7f88e700a4fb6934a27ffcabdbd8608c6e943dcdf-884d6dbf70e4c99a843a9ca42bbd219074d65487768afaedfb3455ca67753351.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asinop")]], [#link("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/#comment-39785")[#strong[#text("asinop")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2009")])]

#text("If you want to solve similar equations on different Riemannian manifolds instead of $[0,\\infty)\\times R$ with very small expansion (Cheeger constant,) would operator splitting part still work?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00dee7b24454562aac70a5d51b77690f666f14f47aad100f72fa7095f787a818-e807704f778bb85a814a39921715b219e8e035e20d299ed1ee8d44b6f7ffe3b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yasser2339")]], [#link("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/#comment-41735")[#strong[#text("yasser2339")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")])]

#text("Dear prof. Tao")

#text("i want to know more about using splitting methods")

#text("how can i solve Recatti equation using operator splitting method")#linebreak()#text(" thanks")

#text("Yasser")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/#comment-42822")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2009")])]

#text("Dear Professor Tao:")

#text("You wrote “the nonlinear Burgers equation generically develops shocks in finite time while the linear Airy equation preserves all Sobolev norms.”")

#text("If I understand correctly then, there must be some threshold of the power of fractional Laplacian between 1 (Burger) and 3/2 (Airy) on which the blowup depends. Is that true, and if so, what is the fractional power; e.g. 5/4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/#comment-42837")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2009")])]

#text("It seems that the Benjamin-Ono equation ")#mi("u_t + H u_{xx} = u u_x")#text(" is the critical threshold between Burgers ")#mi("u_t + u_x = uu_x")#text(" and KdV ")#mi("u_t + u_{xxx} = uu_x")#text(". Benjamin-Ono does not develop singularities for real data, but is badly behaved for complex data; the dispersive effect of the linear part and the singularity-forming effect of the nonlinear part of the equation appear to be in almost perfect balance.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/#comment-42839")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2009")])]

#text("Dear Professor Tao:")

#text("Thank you very much for your response.")

#text("I found that you actually “Global well-posedness of the Benjamin-Ono Equation in H^{1}(R).” I will read that with much interest.")

#text("If I may, I have another question about another paper that I cannot ask elsewhere (I cannot find your blog about it).")

#text("In “Ill-posedness for one-dimensional wave maps at the critical regularity,” you introduce null-coordinates")

#text("u = x + t")

#text("and")

#text("v = x – t")

#text("so that")

#text("\\partial_{u} = 1/2(\\partial_{x} + \\partial_{t})")

#text("\\partial_{v} = 1/2(\\partial_{x} – \\partial_{t})")

#text("and you continue to construct \\phi(t, x) which is a constant in three of the five regions, etc.")

#text("This is a very elegant simple proof that seems to depend on that common decomposition of D’Alembert operator. Hence, I suppose this method, at least in its direct form, is not applicable to other PDEs without the D’Alembert operator like Burger’s. Or is there some modification of this method for other PDEs without the D’Alembert operator? If any, a reference will be very much appreciated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4fc96ad97edc4e74dc0a6886f26e60e347c06337ea73075750358d1e8dfaf35-a71be0c63653789f28967dab3e026f0157a8dc624ae010907573556b22900799.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of afflatus66")]], [#link("https://terrytao.wordpress.com/2009/06/27/operator-splitting-for-the-kdv-equation/#comment-84113")[#strong[#text("afflatus66")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2011")])]

#text("Dear Prof. Tao,")

#text("If the problem is about periodic KdV and NLS in 1D torus and with step function as initial data. How do think about the convergence issue using operator splitting method ?J.Bourgain has already proved the well-poseness for nonlinear Schrodinger equation and KdV equation in periodic domain. And we know for smooth initial data the splitting method has good convergence property. The geometric structure of numerical solution generated by splitting method for smooth initial data has also been considered. Can we use smooth function to approximate step function as initial data to get the convergent property of the situation using step function as initial data ?")
]
