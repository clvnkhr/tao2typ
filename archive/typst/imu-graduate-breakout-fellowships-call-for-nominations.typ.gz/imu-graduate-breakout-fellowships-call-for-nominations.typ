// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/
// Converted to Typst by tao2typ: "2026-10-14T15:19:41.138832+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "IMU Graduate Breakout Fellowships – Call for Nominations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("IMU Graduate Breakout Fellowships – Call for Nominations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 April 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/")[#text("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("http://www.mathunion.org/")[#text("International Mathematical Union")]#text(" (with the assistance of the ")#link("http://friends-imu.org/")[#text("Friends of the International Mathematical Union")]#text(" and ")#link("http://twas.org/")[#text("The World Academy of Sciences")]#text(", and supported by Ian Agol, Simon Donaldson, Maxim Kontsevich, Jacob Lurie, Richard Taylor, and myself) has just launched the ")#link("http://www.mathunion.org/cdc/grants/imu-breakout-graduate-fellowship-program/")[#text("Graduate Breakout Fellowships")]#text(", which will offer highly qualified students from developing countries a full scholarship to study for a PhD in mathematics at an institution that is also located in a developing country. Nominations for this fellowship (which should be from a sponsoring mathematician, preferably a mentor of the nominee) have just opened (with an application deadline of June 22); details on the nomination process and eligibility requirements can be ")#link("http://www.mathunion.org/cdc/grants/imu-breakout-graduate-fellowship-program/")[#text("found at this page")]#text(".")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a53c447048057bf268c9deace8e288f45312f64e5f8b18f44b7838e71bdc954-6583498d239d12da3a83e4f08c749075dd0b69254ef3850d9975357557748149.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Medina")]], [#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-467890")[#strong[#text("John Medina")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2016")])]

#text("Hello Terry,")

#text("I am an foreign-born 20 year-old mathematics student studying in the United States. ( I am also a fan of the Civilization computer game ). I just finished watching the talk you gave at the national museum of mathematics. Terry, since you are such a great believer that the tools of our time are the limiting factor to the advancement of science (not the intelligence of people) have you ever considered becoming an inventor? I know you have done amazing work with neuroimaging.")

#text("Or do you simply feel that you were built to do pure mathematics just as a F1 car is built to race in F1 racetrack and it would not do very well in street racing.")

#text("Thank you,")

#text("John")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-467895")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2016")])]

#text("This is nice news. The name of IMPA came to my mind. Life in Rio is very expensive and there are many talented students from outside of Brazil that could benefit from studying there. Not only in Latin America, but also Indonesia, Africa, etc… It would be nice if there were more mathematicians from these countries. But maybe the Portuguese language could be a barrier depending on the native language of the student… Language barrier could be a serious problem unless one agrees to give the courses in English even tough not the native language of the country where the university is (I don’t know if this is common).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-467896")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2016")])]

#text("By the way, I know that Africa is not a country. :D I was just hasty :D. The intended meaning of the message should be clear anyway (I hope).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-467897")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2016")])]

#text("Ok, now I see that Brazil is not considered a developing country anymore. It still is, it’s just not officially recognized as one. :(")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b888be0be275de5b3877f2e54e8a21aa0f26ea8eaf6930d9e9785ec9273e89fe-94ad56e80e6f291631307c33b1a9f07dbcd8e93d22127df52e56af95222fbec0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of louigiaddario")]], [#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-468017")[#strong[#text("louigiaddario")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2016")])]

#text("This is a wonderful initiative. How many fellowships does the IMU expect to offer, roughly, per year? Is this intended as a long-term program or is being offered for a fixed number of years?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-468071")[#strong[#text("Various Items | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2016")]

#text("[…] various Breakthrough Prize related news, first there’s an announcement from Terry Tao about the new IMU Graduate Breakout Fellowships, funded by him and some of the other math prize […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-468169")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2016")])]

#text("Cool – but it’s a bit disappointing and counterintuitive that, as has already been pointed out, this would not cover a student from a low- or middle-low-income country (such as, say, Bolivia or Peru, respectively) to study in a middle-income country (such as Brazil or Argentina). This is usually what students want to do, and what makes the most sense given that mathematicians tend to group together in order to work and develop. Of course, some middle-income places (such as Brazil) already offer scholarships for foreign students, but they are often threadbare.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-468174")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2016")])]

#text("Part of the motivation of the fellowship is to help develop a mathematical community in a location that has almost no financial resources whatsoever, and in particular even less than what one finds nowadays in middle-income countries such as Brazil. A typical example is the community in Madagascar mentioned by Ingrid Daubechies in this IMU editorial from 2011: ")#link("http://www.mathunion.org/imu-net/archive/2011/imu-net-045/")[#text("http://www.mathunion.org/imu-net/archive/2011/imu-net-045/")]#text(" . This also makes the cost of the fellowship substantially lower than it would be in a middle income country (where, as mentioned in a previous comment, the cost of living has already begun to move upwards) and which should allow us to continue the fellowship indefinitely from the endowment (which is not all that large in the grand scheme of things – a bit more than half a million USD currently, though hopefully we can attract more support in the future).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09bf1bba6531c9907483e3d75e5503909d7caef449a380c75f22e6250e429f36-c6463f37e9239274b5d444497b585b90285989e04507a0abd7e30cc7e63a2484.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Taxpayer")]], [#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-468179")[#strong[#text("The Taxpayer")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2016")])]

#text("They can’t get clean water but they will waste smart people on theoretical math? Send them a Skype connection, if they want to indulge a paper-and-pencil hobby. I see a lot of Indian physicists in this country, although basic sanitation is completely absent from their home country. This kind of liberal elitism is where I begin to vomit. I think we support too many of you people in this country, living off the taxpayer. Applied mathematics is one of the most automatable subjects on earth. I’m not even trying to be sarcastic.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10c8eaf9c4e96bb335d30cd1977b0efff6825db3a284bae1030de9f491e7f16b-ad263deac8f57809e440335dd3bc468e2d5b47dbda1bc2ec66e1185b3c5ffc4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Imran Parvez Khan")]], [#link("https://terrytao.wordpress.com/2016/04/23/imu-graduate-breakout-fellowships-call-for-nominations/#comment-469634")[#strong[#text("Imran Parvez Khan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Great! Will there another phase of it next year?")
]
