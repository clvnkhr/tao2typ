// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/
// Converted to Typst by tao2typ: "2026-10-14T15:19:08.385388+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Variants of the Selberg sieve, and bounded intervals containing many primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Variants of the Selberg sieve, and bounded intervals containing many primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 July 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/")[#text("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv the D.H.J. Polymath paper “")#link("http://arxiv.org/abs/1407.4897")[#text("Variants of the Selberg sieve, and bounded intervals containing many primes")]#text("“, which is the second paper to be produced from ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("the Polymath8 project")]#text(" (the first one being discussed ")#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/")[#text("here")]#text("). We’ll refer to this latter paper here as the Polymath8b paper, and the former as the Polymath8a paper. As with Polymath8a, the Polymath8b paper is concerned with the smallest asymptotic prime gap")

#align(center)[#tao-fit-display[#mitex("H_1 := \\liminf_{n \\rightarrow \\infty}(p_{n+1}-p_n),")]]

#text("where ")#mi("{p_n}")#text(" denotes the ")#mi("{n^{th}}")#text(" prime, as well as the more general quantities")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow \\infty}(p_{n+m}-p_n).")]]

#text("In the breakthrough paper of Goldston, Pintz, and Yildirim, the bound ")#mi("{H_1 \\leq 16}")#text(" was obtained under the strong hypothesis of the ")#link("http://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(". An unconditional bound on ")#mi("{H_1}")#text(", however, remained elusive until the celebrated ")#link("http://annals.math.princeton.edu/articles/8659")[#text("work of Zhang")]#text(" last year, who showed that")

#align(center)[#tao-fit-display[#mitex("H_1 \\leq 70{,}000{,}000.")]]

#text("The Polymath8a paper then improved this to ")#mi("{H_1 \\leq 4{,}680}")#text(". After that, Maynard ")#link("http://annals.math.princeton.edu/articles/8772")[#text("introduced")]#text(" a new multidimensional Selberg sieve argument that gave the substantial improvement")

#align(center)[#tao-fit-display[#mitex("H_1 \\leq 600")]]

#text("unconditionally, and ")#mi("{H_1 \\leq 12}")#text(" on the Elliott-Halberstam conjecture; furthermore, bounds on ")#mi("{H_m}")#text(" for higher ")#mi("{m}")#text(" were obtained for the first time, and specifically that ")#mi("{H_m \\ll m^3 e^{4m}}")#text(" for all ")#mi("{m \\geq 1}")#text(", with the improvements ")#mi("{H_2 \\leq 600}")#text(" and ")#mi("{H_m \\ll m^3 e^{2m}}")#text(" on the Elliott-Halberstam conjecture. (I had independently discovered the multidimensional sieve idea, although I did not obtain Maynard’s specific numerical results, and my asymptotic bounds were a bit weaker.)")

#text("In Polymath8b, we obtain some further improvements. Unconditionally, we have ")#mi("{H_1 \\leq 246}")#text(" and ")#mi("{H_m \\ll m e^{(4 - \\frac{28}{157}) m}}")#text(", together with some explicit bounds on ")#mi("{H_2,H_3,H_4,H_5}")#text("; on the Elliott-Halberstam conjecture we have ")#mi("{H_m \\ll m e^{2m}}")#text(" and some numerical improvements to the ")#mi("{H_2,H_3,H_4,H_5}")#text(" bounds; and assuming the generalised Elliott-Halberstam conjecture we have the bound ")#mi("{H_1 \\leq 6}")#text(", which is best possible from sieve-theoretic methods thanks to the parity problem obstruction.")

#text("There were a variety of methods used to establish these results. Maynard’s paper obtained a criterion for bounding ")#mi("{H_m}")#text(" which reduced to finding a good solution to a certain multidimensional variational problem. When the dimension parameter ")#mi("{k}")#text(" was relatively small (e.g. ")#mi("{k \\leq 100}")#text("), we were able to obtain good numerical solutions both by continuing the method of Maynard (using a basis of symmetric polynomials), or by using a Krylov iteration scheme. For large ")#mi("{k}")#text(", we refined the asymptotics and obtained near-optimal solutions of the variational problem. For the ")#mi("{H_1}")#text(" bounds, we extended the reach of the multidimensional Selberg sieve (particularly under the assumption of the generalised Elliott-Halberstam conjecture) by allowing the function ")#mi("{F}")#text(" in the multidimensional variational problem to extend to a larger region of space than was previously admissible, albeit with some tricky new constraints on ")#mi("{F}")#text(" (and penalties in the variational problem). This required some unusual sieve-theoretic manipulations, notably an “epsilon trick”, ultimately relying on the elementary inequality ")#mi("{(a+b)^2 \\geq a^2 + 2ab}")#text(", that allowed one to get non-trivial lower bounds for sums such as ")#mi("{\\sum_n (a(n)+b(n))^2}")#text(" even if the sum ")#mi("{\\sum_n b(n)^2}")#text(" had no non-trivial estimates available; and a way to estimate divisor sums such as ")#mi("{\\sum_{n\\leq x} \\sum_{d|n} \\lambda_d}")#text(" even if ")#mi("{d}")#text(" was permitted to be comparable to or even exceed ")#mi("{x}")#text(", by using the fundamental theorem of arithmetic to factorise ")#mi("{n}")#text(" (after restricting to the case when ")#mi("{n}")#text(" is almost prime). I hope that these sieve-theoretic tricks will be useful in future work in the subject.")

#text("With this paper, the Polymath8 project is almost complete; there is still a little bit of scope to push our methods further and get some modest improvement for instance to the ")#mi("{H_1 \\leq 246}")#text(" bound, but this would require a substantial amount of effort, and it is probably best to instead wait for some new breakthrough in the subject to come along. One final task we are performing is to write up a retrospective article on both the 8a and 8b experiences, an incomplete writeup of which can be found ")#link("https://www.dropbox.com/sh/koxbhwvw1ysybk9/AADTJ4w3yegvgTut_Tsv0Sana/retrospective.pdf")[#text("here")]#text(". If anyone wishes to contribute some commentary on these projects (whether you were an active contributor, an occasional contributor, or a silent “lurker” in the online discussion), please feel free to do so in the comments to this post.")

#heading(level: 1)[#text("Comments (118)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d815cf5704012394db2ca4090a05f042432268426dc0d796b07dbe928ab0113-744df7ba6c1c283202fc26e4e29016bb9e811f40b4786bd46e580745dd5a9849.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398299")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2014")])]

#text("In the paragraph starting “In Polymath8b, we obtain some further improvements.”, need to put brackets on the exponent in the asymptotic H_m bound to get ‘(4-24/181)m’, not ‘4-24m/181’.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85b1951f8a78f312e438ee638df9d5874d7ac9e2468cd092ac4124a5293f350-52fc9493ff777e3522ac72f04d77065d71f50f5221e7ad6749d5e7fb81ad1ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398303")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2014")])]

#text("Introduction: Remove either “")#mi("H_{m}")#text(" denote the quantity” from the first line or “")#mi("H_{m} :=")#text("” from the formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b083a09d65c647ea3a428eb37b6de129becd8e91fda1b7017fd3764c2204a94-89162fe361fa8cdd12800d5a4d67a64f51185eac00ebb9e8e4576a1ad1a681e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of foobar")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398323")[#strong[#text("foobar")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2014")])]

#text("Couple purely formatting-related notes on the retrospective: footnote 3 on page 3 doesn’t fit on the page (and lacks http:// on the link), and link at “A database had been set up at math.mit.edu/primegaps/” (page 8) similarly lacks ")#link("http://")[#text("http://")]#text(", and has a strange symbol on middle of it (I assume it should be a tilde).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/683b15586bd421cfd2ea909846ce58441b647d64f9f227239775f7cdfc93ad6a-48fd1dd4221064ef6444f97523566ff96ac3de5c1f54284e8221887879591850.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398713")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2014")])]

#text("This is where the ")#link("https://en.wikibooks.org/wiki/LaTeX/Hyperlinks#.5Curl")[#text("\\url{} command in the hyperref package")]#text(" comes in handy; it has a decent ability at breaking lines in the right places.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/496df113db90c886b074336a9d9a23a83acc35953c432b1d710975b8fec55bf5-23ae718152670cf036de2ecbe6e4d9c14d78e1aa5ecf2efc950b5110284f1fc4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398338")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2014")])]

#text("Last sentence of second to last paragraph: “I hope that these sieve-theoretic tricks will be future in other work in the subject.”")#linebreak()#text(" Perhaps you meant “useful in future work”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398521")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2014")])]

#text("It is still possible that ")#mi("M_{53} > 4")#text(" (in fact, as already commented by Ignace, repeated Shanks extrapolations indicate that ")#mi("M_{53}")#text(" seems to be in the interval ")#mi("[4.0004, 4.00004]")#text("). The problem is that the maximal degree of the polynomials in the Krylov bounding method should be sufficiently large (apparently 70-90 – instead of the current 50) in order to rigorously show that.")

#text("If true, this should improve (under EH) theorem 1.4(vii) from ")#mi("H_2 \\leq  270")#text(" to ")#mi("H_2 \\leq 264")#text(". (with corresponding improvements in theorems 3.2(vii) and 3.9(vii)).")

#text("(this possible improvement may be added to the remarks in section 9).")

#emph[#text("[A brief note to this effect added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398592")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2014")])]

#text("I’d happily write a brief piece for the retrospective if you would like, although I think my thoughts might be very similar to those of Pace, and so I’m equally happy to leave his comments as representative of mine as well.")

#text("I think there is a small typo on the exponent for large ")#mi("m")#text("; if ")#mi("\\varpi\\approx 7/600")#text(" then I get an exponent ")#mi("4-28/157")#text(" rather than ")#mi("4-24/181")#text(" (on line 13 of page 14 I think ")#mi("7/600")#text(" has accidentally become ")#mi("6/700")#text(", and this affects the exponent in the next equation, in the abstract, in Theorem 1.4 and in Theorem 3.2)")

#emph[#text("[Corrected, thanks. Given your role in prior developments, I think a separate piece from you would definitely be interesting, even if it echoes other comments. -T.]")]#emph[]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/683b15586bd421cfd2ea909846ce58441b647d64f9f227239775f7cdfc93ad6a-48fd1dd4221064ef6444f97523566ff96ac3de5c1f54284e8221887879591850.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398715")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2014")])]

#text("This sentence appears to be missing a word: “Initially, I was preoccupied with other research projects, and felt content to let the rest of the analytic number theory digest the result”.")

#text("Perhaps insert “community” in between “theory” and “digest”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398830")[#strong[#text("Polymath 8 – a Success! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2014")]

#text("[…] the Selberg sieve, and bounded intervals containing many primes“, is now on the arXiv. See also this post on Terry Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85b1951f8a78f312e438ee638df9d5874d7ac9e2468cd092ac4124a5293f350-52fc9493ff777e3522ac72f04d77065d71f50f5221e7ad6749d5e7fb81ad1ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398885")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2014")])]

#text("Typographical comment: For the seventeen million in the third math expression, you can avoid the space after the commas by inclosing these in brackets; ")#mi("70{,}000{,}000")#text(".")

#emph[#text("[Corrected,thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85b1951f8a78f312e438ee638df9d5874d7ac9e2468cd092ac4124a5293f350-52fc9493ff777e3522ac72f04d77065d71f50f5221e7ad6749d5e7fb81ad1ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-398887")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2014")])]

#text("This also applies to $4{,}680$ in the very next line. 🙂")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-399361")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2014")])]

#text("One thing that I usually do to get around this problem is \\usepackage{icomma}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee7c15ae601e00646b9effd580fa4ab3b688a32584cf901a217488d0f75c252-ef5eaa85162900509d0255ec7a1215d31cf4b7d79121197cb3834c3a55b1ab6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-399751")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2014")])]

#text("Perhaps best to omit the comma altogether for four digit numbers.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-399004")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2014")])]

#text("Lemma 3.4 may be slightly improved as follows:")

#text("Let ")#mi("x, W, B, h_1, ... , h_k, b, \\nu (.)")#text(" defined as in lemma 3.4.")#linebreak()#text(" Let ")#mi("S")#text(" be the set of indices ")#mi("n \\in [x. 2 x] , n=b(W)")

#text("Let ")#mi("m(n)")#text(" be defined for each ")#mi("n \\in S")#text(" as the number of indices ")#mi("i = 1, ... , k")#text(" for which ")#mi("n+h_i")#text(" is prime.")

#text("Denote by ")#mi("m_{av}")#text(" the weighted average (wrt the normalized weights ")#mi("w_n := \\nu (n) / \\sum_{n \\in S} \\nu(n)")#text(") of ")#mi("m(n)")#text(" over ")#mi("S")#text(", i.e.")

#text("(1) $ latex m_{av} := \\sum_{n \\in S} w_n m(n)")

#text("Then")

#text("(2) ")#mi("m_{av} \\geq (\\beta_1 + ... + \\beta_k)/ \\alpha")

#text("Remarks:")

#text("1. Since (obviously) ")#mi("m_{av} \\leq m_{max} := \\max_{n \\in S} m(n)")#text(", this implies lemma 3.4 (i.e. (2) holds with ")#mi("m_{max}")#text(" in the LHS).")

#text("2. Clearly, this is equivalent to lemma 3.4 if and only if ")#mi("m(n)")#text(" is constant over ")#mi("S")#text(". So if there is some way to lower bound the difference ")#mi("m_{max} - m_{av}")#text(" it may lead to some improvements for ")#mi("H_m")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-399104")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2014")])]

#text("In the Polymath8b paper, it seems that a factor ")#mi("(-1)^k")#text(" is missing in the RHS of (77).")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-399109")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2014")])]

#text("In the Polymath8b paper, page 34 line 2, “(77)” should be “(76)”.")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d42e093728db724853bd25d8a3311edb144d4d60ca784835b0b3f8e5a06e8f9a-ed6638089c3eb2ca661a85d38c783c26f3c9915f77e66cec8f5e7ca2970fab54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400248")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2014")])]

#text("awesome work. suggest this following book by Nielsen be cited somewhere. it specifically cites polymath as paradigm shifting and (admittedly somewhat grandiosely, yet with major justification) considers that cyberspatial collaboration is helping facilitate a scientific revolution roughly in scale to the age of enlightenment a half-millenium later. few seem to have read it or digested its implications. ")#link("http://www.amazon.com/Reinventing-Discovery-The-Networked-Science/dp/0691148902/")[#text("Reinventing Discovery: The New Era of Networked Science")]#text(". if a sequel was written (and presumably one will be by someone), Zhangs proof & polymath improvements would surely be in it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d42e093728db724853bd25d8a3311edb144d4d60ca784835b0b3f8e5a06e8f9a-ed6638089c3eb2ca661a85d38c783c26f3c9915f77e66cec8f5e7ca2970fab54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400251")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2014")])]

#text("(oops) 2nd thought another quick point. at various stages in the polymath attack, ")#link("http://stats.stackexchange.com/questions/73801/machine-learning-applications-in-number-theory/77479#77479")[#text("empirical approaches ie computers/ algorithms")]#text(" were used to find improved sieves. this is a relatively well-concealed fact looking at accounts of the proceedings. would like to learn more about this. you might decide the paper might not be the place for that, but it would be great if someone could document this further somewhere. & ps some commentary & many links on ")#link("http://vzn1.wordpress.com/2013/10/04/zhang-twin-prime-breakthru-vs-academic-trackgrind/")[#text("zhang")]#text(" incl much media coverage, interview etc")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400268")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2014")])]

#text("In Polymath8b paper, it seems (according to (16)), that the RHS of (20) should be ")#mi("F(0) - F(\\log _x n)")#text(" (instead of ")#mi("F(0)")#text(") for prime ")#mi("n")#text(". (due to its divisors ")#mi("d = 1, n")#text(").")

#emph[#text("[Clarified -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400271")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2014")])]

#text("I can see now that for ")#mi("n> x")#text(" the second term vanishes!")#linebreak()#text(" (perhaps this condition on ")#mi("n")#text(" may be added in the line below (20)).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400408")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2014")])]

#text("In the line below (20), “")#mi("n \\ll x")#text("” should be “")#mi("n\\geq x")#text("“.")#linebreak()#text(" (so that the second term ")#mi("F(\\log _x n)")#text(" should vanish).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400398")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2014")])]

#text("RIMS has already come back with two referee reports for Polymath8b: ")#link("https://www.dropbox.com/sh/j1ncthw7dwupj6a/AAANZvStKFAwvRptu00rA-ULa")[#text("https://www.dropbox.com/sh/j1ncthw7dwupj6a/AAANZvStKFAwvRptu00rA-ULa")]#text(" The corrections requested are fairly minor, I can address them myself within the next few days.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2d0117ab6d8435931fc7474a057b74f4ebb9e2ef56f7067b698b125177a9cac-87cbcf9e840848e3e481e694111f026de5c1764a9a48eb3347eb3cfc36ac6434.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400401")[#strong[#text("Andreas")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2014")])]

#text("The referee-reports of the two papers are very different. Reports of paper1 had alot of minor corrections, thus indicated that the reviewers calculated alot of the presented material. Reports for paper2 do not have any comments about the technical details at all. Paper1 had 5 or 6 independent referees looking at different sections. Paper2 had 2 reviewers for the whole content. Paper1 took many weeks; paper2 took a few days?")

#text("As a non-mathematician, I wonder what kind of reviews are more common; is the main goal of a reviewer to check the full technical results or check and help to improve the way the paper is presented? I believe, potential mistakes will be found anyway after its published and presented to the whole of experts of the field.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400493")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2014")])]

#text("Andreas, great questions. There are a number of factors which can influence the way a referee report is created.")

#text("1. The type of journal. If the journal is geared towards presenting mathematics to largely non-mathematician audiences, then the focus is different than if the journal is devoted to short articles, which is different than a journal focused on major new results. Some journals pride themselves on quick decisions; others are meticulous about details.")

#text("2. The workload for the referee. When you know that you are one of many reviewers, but you are in charge of reviewing only one (short) section of a paper, you will take more care to check every detail (to pull your own weight, so to speak). If you are reviewing a 50+ page paper in its entirety; then you look at the broad ideas. Ultimately, the correctness of a paper is the author’s, not the referee’s, responsibility. However, referees do try to make a reasonable effort to verify results.")

#text("To give you a more personal example, I’m the type of referee who if I agree to do the job, I want to get it done quickly but also check every detail. So I give myself a month, and try to check every detail. (This is possible since most papers in my field are relatively short.) But there are some papers where it is just too much work to do that, so I check the details for a while, but may just read other parts for cohesion.")

#text("3. Editor instructions. Some journals have huge backlogs, and so editors instruct referees to be more discriminating. Most referee reports from those journals are rejections. In area-specific journals, some editors know that certain authors are “solid” but heavy on technicalities, and so may only require an estimation of the impact of the paper.")

#text("4. Style of the paper. If English is an author’s first language, there will be in many cases fewer typographical changes for the referee to recommend. Similarly, an author versed in LaTeX will make fewer bad choices in that regard. Finally, some papers even if correct are unreadable, while others, such as the polymath 8b paper, are easy to read even with a long length (just as one of the referees mentioned).")

#text("There are many other considerations. To answer your question about what is the usual format of a report; it really does depend on a large number of factors. When an article just “fits” a journal and is well written there are usually fewer recommended changes. On the other hand, if there are oddities that the authors just didn’t see, the referee might focus in on those issues and make a detailed report.")

#text("There are other types of reports than those received for the polymath 8 papers. For instance, some are:")#linebreak()#text(" 1. Rejections with no comments from the referee.")#linebreak()#text(" 2. Acceptance with no comments from the referee. (These are the ones I worry about the most when I get them! A serious referee should have found at least one change to recommend–that’s just the way life is; errors occur.)")#linebreak()#text(" 3. Rejections for serious errors.")#linebreak()#text(" 4. Serious revisions requested for badly written papers, possibly with some results having gaps.")

#text("I hope this helps.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400494")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2014")])]

#text("That’s wonderful news! (I always like quick refereeing.) Those were both very positive reports, with some good recommendations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2014")])]

#text("I’ve now implemented the corrections to 8b. I see there are still a few corrections coming in, so I’ll wait for another day or two before submitting the revised version back to RIMS (who are promising a speedy publication – so 8b may in fact end up in print slightly before 8a, which is actually not entirely uncommon, given the wide variability in publication times).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-402002")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2014")])]

#text("I’ve now sent the revised version back to RIMS.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-402150")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2014")])]

#text("It seems that the typos (mentioned in my comment from 30 July) are still in the paper.")

#emph[#text("[Oops, I somehow overlooked that comment. I’ve implemented the changes now; I won’t update the arXiv version as the changes are minor, but I may have an opportunity to implement the changes in the galley proofs for RMS. -T.]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400417")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2014")])]

#text("In Polymath8b paper, in the fifth line of remark 3.7, it seems that “(20)” should be “(26)”.")

#emph[#text("[No; (26) only addresses the case ")#mi("i \\neq i_0")#text(". (20) asserts that ")#mi("\\lambda_{F_i}(n+h_i) \\lambda_{G_i}(n+h_i)")#text(" is quite large (much larger than its average value) whenever ")#mi("\\theta(n+h_i)")#text(" is non-zero. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400421")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2014")])]

#text("In Polymath8b paper, it seems that in the LHS of (26), “")#mi("\\theta (n+h_i)")#text("” should be “")#mi("\\theta (n+h_{i_0})")#text("“.")

#emph[#text("[Corrected, thanks – and now I see where the prior confusion came from. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400518")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2014")])]

#text("In Polymath8b paper, “")#mi("\\ast")#text("” should be “")#mi("\\star")#text("” both in (8) and in the fourth line below theorem 2.8.")

#text("Also, in (21) “")#mi("i^{\\prime} \\neq i")#text("” seems (slightly) better than “")#mi("i \\neq i^{\\prime}")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of H")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400525")[#strong[#text("H")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2014")])]

#text("I think the boldface caption for the table on p.8 looks a bit strange.")#linebreak()#text(" Also, in the example bmc_article_2col.pdf captions are not bold.")

#text("However, I don’t understand why it gets typeset this way.")

#text("The following small example sets the first table-caption in bold and the second not in bold.")#linebreak()#text(" If the figure in between is removed, then both are typeset in bold.")

#raw("\n\\documentclass{bmcart}\n\\begin{document}")

#text("\\begin{table}")#linebreak()#text(" \\caption{Sample table title.}")#linebreak()#text(" \\end{table}")

#text("\\begin{figure}")#linebreak()#text(" \\caption{\\csentence{Sample figure title.} A short description.}")#linebreak()#text(" \\end{figure}")

#text("\\begin{table}")#linebreak()#text(" \\caption{Sample table title.}")#linebreak()#text(" \\end{table}")

#text("\\end{document}")#linebreak()
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of H")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400825")[#strong[#text("H")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2014")])]

#text("I don’t really understand the latex in bmcart.cls, but I think that every time a figure-environment is created the line")#linebreak()#text(" ")#raw("\n\\setattribute{floatcaption}{size}{\\footnotesize\\sffamily\\raggedright}\n")#linebreak()#text(" is run (lines 720, 734 in bmcart.cls). This affects how the caption of tables are typeset and explains the strange behavior pointed out in the small example.")

#text("Adding the row displayed above to the preamble of the latex document “fixes” the boldness-issue. However, I guess this kind of hack is not encouraged… I’m only posting this to try to explain the weirdness noted in my previous comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82b6072f28c6e9550580519767e4796a7523c7817b067367144b5c698971f614-732fe0e3663ada48917be6b7f6d284f032779fdb59ae54519dac488c46b9e60b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LB")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400550")[#strong[#text("LB")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2014")])]

#text("Three very minor mistakes in several threads:")#linebreak()#text(" In Scott Morrison’s thread (")#link("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart")[#text("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart")]#text("), there is still one time written 3.5*10^7, which should be 3.5*10^6, even though this was already mentioned and corrected once (but not in the 5th paragraph).")#linebreak()#text(" Also, in the second thread (")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")]#text("), in the Bessel differential eqaution the term d/dx^2 should be replaced by d^2/dx^2 for sure.")#linebreak()#text(" Third, in the Polymath 8a paper, in section “Abstract”, there is just written “gives Zhang’s theorem with H=”, without giving the value of 4,680.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cfe8e2451cd2fca31834c86e5e526d612178cc75ec1bea5501a4a1bdb83a2eb-98329cc950e5ae1be7a6d680bc20dd57e46b752dc2b4388112eeab63048d5d37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400679")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2014")])]

#text("Good news from the referee report! Here is a draft of my thoughts for the retrospective article (feel free to edit if this is too long):")

#text("As a graduate student who had be looking at closely related problems, it was thrilling to hear of Zhang’s initial breakthrough. I didn’t participate in the subsequent Polymath 8a project, although I found myself reading several of the posts whilst studying Zhang’s work for myself. I intended to avoid working on anything too close to the Polymath project (to avoid any competition), but one day I was going back through some ideas I’d had a several months earlier on modifications of the `GPY sieve’, and I realized I could overcome the obstacles I had in my original attempt. This modification (also discovered by Tao) gave an alternative stronger approach to gaps between primes, although it didn’t produce the equidistribution results which lie at the heart of Zhang’s work. With some small numerical calculations, this allowed me to show that there were infinitely many pairs of primes which differ by at most 600, and allowed one to show the existence of many primes in bounded length intervals.")

#text("I knew the numerical bounds in my work hadn’t been fully optimized – there was some slack in my approach, and there were also several opportunities to extend the method (such as incorporating ideas from Zhang and Polymath8a, or using more careful arguments). I was therefore pleased and excited when I learnt there was the intention for a polymath 8b project which I could be part of – it was very exciting for me that there was such an interest in my work!")

#text("The style of a large collaborative project was very new to me. I had relatively little experience of research collaboration, and I was used to mainly trying out ideas alone. I certainly hadn’t fully appreciated quite how public the posts were (and how many mathematicians who were not active participants would read the comments). In some ways this was quite fortunate; not realizing the attention posts might receive made me more willing to contribute openly. I posted several ideas which were not fully thought through, some of which were rather stupid in hindsight, but some of which I believe were useful to the project (and probably more useful than posting a fully thought out idea a few days later). The atmosphere of the project certainly helped encourage such partial contributions, which I feel was a large factor in the project’s success.")

#text("It was remarkable (to me, at least) how smoothly the project went; this was partly to do with the problem having very clearly defined goals and being modular in its nature, but also due to the openness and friendliness of the participants. There seemed to be a good balance amongst the participants – some had more computational expertise, whilst others had a more theoretical background, and it was certainly useful to have both groups together for the effectiveness of the project. Much if the improvement in the unconditional bound came from extending the computations I had done initially, and it was certainly useful to have people who were rather more experienced than me with the larger computations.")

#text("I was surprised at how much time I ended up devoting to the polymath project. This was partly because the nature of the project was so compelling – there were clear numerical metrics of `progress’, and always several possible ways of obtaining small improvements, which was continually encouraging. The general enthusiasm amongst the participants (and others outside of the project) also encouraged me to get more and more involved in the project. Finally, the nature of the work also made it very suitable for working on in short bursts, which turned out to be very useful since I was travelling quite a lot whilst most of the project was underway.")

#text("I was aware that as a junior academic without a permanent position that I might ultimately not receive much credit in the eyes of hiring committees for participation in an atypical project such as the polymath, where it is difficult to gauge the merit of my contribution. In my case, the fact that the project was so closely associated with my earlier work, and the fact that I found the project so interesting made me happy to accept this (although I made a conscious effort to continue to work on other projects at the same time). This is certainly something I feel any similarly junior prospective participant should be aware of, however.")

#text("Overall, I really enjoyed the polymath experience. It was a great opportunity to work with several other mathematicians, and I feel pleased with the final results and my contribution to them.")

#emph[#text("[Added to the retrospective paper; may try to do some minor editing later. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400688")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2014")])]

#text("Good thoughts! (By the way, with the quality of you work on multidimensional sieves, and your subsequent follow-up work, I don’t think you have much to worry about from hiring committees.)")

#text("One minor suggestion. You wrote “I had relatively little experience of research collaboration, and I was used to mainly trying out ideas alone.” I initially read “I was used to…” as something like “I was used by the polymath project to…” rather than what you meant, which was “I was more familiar with…”. You might consider changing this sentence to avoid that misreading.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18ac32f1757df2128ad3a7dbe5ae836196e52ea337899648b1954fd17de88a53-604117642946f3f93e6b67fa3d6ac648db2fa29093c98f5c5b218b96551f81a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400771")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2014")])]

#text("James’ nice contribution for the retrospective article encouraged me to write up mine:")

#text("“I guess I am no longer a junior mathematician, which is a bad thing, but on the good side I can perhaps add a different perspective on my participation in the PolyMath8 project.")

#text("Last year I applied for some serious grants, and it was on the same day when I learned that my proposals would be rejected. This was quite discouraging, and I felt as I needed to take some break from my main line of research. Around the same time, Zhang’s exciting paper came out, and shortly after Terry Tao initiated a public reading seminar on his blog that later turned into the PolyMath8 project. I was already familiar with the earlier breakthrough by Goldston-Pintz-Yildirim, in fact I have incorporated it in my courses at Central European University and advised some students in related topics. I have always found this part of number theory very beautiful, although my research interests have been elsewhere. Following Terry’s clean and insightful blog entries and the accompanying comments served for me two different purposes initially. First, I hoped to understand the new developments in a field that I found appealing. Second, I hoped to get a change of air in mathematics for the reasons explained above.")

#text("The PolyMath8 project developed at blazing speed, and my initial goal was simply to catch up and read everything posted on the blog. This was quite challenging, because I am rather slow and prefer to check every line carefully, but at least I could serve as an early referee for the project. As a bonus, I got some ideas how to improve certain points in an argument already posted. In short, the PolyMath8 project helped me to get going and feel myself useful, and participating was a lot of fun. At one point I embarrassed myself by posting several different “proofs” to an improved inequality that I conjectured, only to find out later that the claim was false. All this is recorded and preserved in the blog, but I do not regret it as it was honest and reflects the way mathematics is done. We try and we often fail.")

#text("It was also very interesting how my colleagues reacted. Some thought that one should not devote too much effort to a paper published under a pseudoname, but in fact my participation here got far more attention than elsewhere. For a couple of months the first question I was asked was about the current record on prime gaps. Another benefit of a PolyMath project is that there is no pressure on the participants, one is free to join for a while then leave, and ignorance is normal as in a mathematical conversation.”")

#emph[#text("[Added to the retrospective paper; may try to do some minor editing later. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400796")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2014")])]

#text("In tables 4, 5 (pages 77, 78) of Polymath8b paper, “Best known” seems to be a better description than “Best result”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400862")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2014")])]

#text("Table 5 should also be corrected.")

#emph[#text("[Done, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of H")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400878")[#strong[#text("H")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2014")])]

#text("Some displayed math is left-aligned and some is centered, is this intentional?")#linebreak()#text(" (I think $$-math is centered and \\begin{equation}-math is left-aligned.)")

#emph[#text("[This appears to be the journal house style; I presume that if there is an issue they will raise it in the galley proof stage. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400928")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2014")])]

#text("In the abstract of Polymath8b paper, the exponent of the unconditional asymptotic bound on ")#mi("H_m")#text(" should be corrected (to that of theorem 1.4(vi)).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400938")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2014")])]

#text("Some remarks on the polymath8b paper:")

#text("1. In the abstract, from the disjunction formulation it seems (unlike as in theorem 1.5 formulation) that it is an “exclusive or” type (i.e. exactly one possibility holds).")

#text("2. In section 1.1, theorem 3.2 is not mentioned. (perhaps, table 1 -describing its dependence on other theorems – may be mentioned here.)")

#text("Also in section 1.1, “gives Theorem 1.4” seems better than “to give Theorem 1.4”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/709ea8cc924cc624ff1d7ed0ff29b280c45bfb919bd26e416fa5fb9bf3b70f23-ec55455856bf2af83ab37e935bf56f395e667d1a2c850c97ccf36d0dfc00bbe0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-400957")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2014")])]

#text("Oops. First equation for a=10000011 has “p(n+1)” = 300000359 = 163 x 1840493.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-401167")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2014")])]

#text("Corrections for the Polymath8b paper:")

#text("1. Page 4: line 7 of section 1.1, “in 4” should be “in Section 4”.")

#text("2. Page 6: in Claim 2.6, the condition ")#mi("0 < \\vartheta < 1")#text(" (for fixed ")#mi("\\vartheta")#text(") may be added.")

#text("3. Page 8: in Theorem 3.2. \"")#mi("\\theta")#text("\" (four places !) should be \"")#mi("\\vartheta")#text("\".")

#text("4. Page 28: in (63) and in lines 2, 4, 6. 7 above (63), \"")#mi("x^{\\theta}")#text("\" should be \"")#mi("x^{\\vartheta}")#text("\".")

#text("5. Page 29: in the first two summations, \"")#mi("x^{\\theta}")#text("\" should be \"")#mi("x^{\\vartheta}")#text("\".")

#text("6, Page 38: in the first three summations, the summands should be inside parentheses.")

#text("7. Page 39: in the first summation, the summands should be inside parenheses.")

#text("8. Page 41: in the line below (92), \"of intervals\" should be \"on intervals\".")

#text("9. Page 44: in proposition 6.5, \"")#mi("\\varepsilon \\geq 0")#text("\" should be \"")#mi("0 \\leq \\varepsilon < 1")#text("\".")

#text("10. In the proof of Theorem 6.7, it seems helpful to remark (at appropriate place) that the convention used for the expectation operator is that (without parentheses) it applied to the whole expression to its right.")

#text("11. Page 58: In the sixth line below the expression for ")#mi("P_{\\alpha}  P_{\\beta}")#text(", \"maximize\" should be \"maximizes\" and \"quantity")#mi("C")#text("\" should be \"quantity ")#mi("C")#text("\".")

#emph[#text("[Belatedly corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-402171")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2014")])]

#text("There are still some typos (using the same corrections numbering):")

#text("2. Page 6: in the line above Claim 2.6, “")#mi("\\theta")#text("” (inside the inequality) should be “")#mi("\\vartheta")#text("“.")

#text("3. Page 8: in theorem 3.2, “")#mi("\\theta")#text("” (appearing twice in the second line below (vi), and twice in the second line below (xi)) should be “")#mi("\\vartheta")#text("“.")#linebreak()#text(" (as I understand, ")#mi("\\vartheta")#text(" is consistently reserved to be the parameter for the claims EH[.] and GEH[.]).")

#text("9. Page 44: in proposition 6.5, “")#mi("0 \\leq \\varepsilon < 4")#text("\" should (obviously) be \"")#mi("0 \\leq \\varepsilon < 1")#text("\".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-405085")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("There is still a typo (see my comment above)")

#text("Page 6: in the line above claim 2.6, “")#mi("0 < \\theta < 1")#text("\" should be \"")#mi("0 < \\vartheta < 1")#text("\" .")

#text("Also, in page 36, two lines above the proof of theorem 3.10, it seems that \"")#mi("n + h_k")#text("\" (in the summation) should be \"")#mi("n + h_i")#text("\".")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60804756128ef94d5d2ef08e7f69b0418a4e5946474af6ce5f4e3d79916530e5-feca94c558027f48c7065f4aea5030f370d9362bc91c352a126fb15ca6fc9e39.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-401198")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2014")])]

#text("These are just re-statement of Dirichlet’s theorem.")

#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d815cf5704012394db2ca4090a05f042432268426dc0d796b07dbe928ab0113-744df7ba6c1c283202fc26e4e29016bb9e811f40b4786bd46e580745dd5a9849.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-401374")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2014")])]

#text("My 2 cents for the retrospective.")

#text("“I saw the announcement of Zhang’s talk on Peter Woit’s blog, and posted on Google+ (13 May 2013) about the twin prime problem, prime gaps more generally and about Zhang’s talk and how big a deal it was. This post received much attention (more than I would have expected) and over the course of Polymath 8, and the pre-official Polymath work, I kept posting the current records online, with explanation of what the progress meant or how it happened.")

#text("I’m not an analyst or number theorist (I work in category theory), so I was content to read the progress of the project and learn how all this business worked. I’d read through Zhang’s preprint and was totally nonplussed, but the careful analysis—and exposition!—of Terry Tao and the other active participants made the ideas much clearer. In particular, concepts and tools that are well-known to analytic number theorists and are used without comment were brought into the open and discussed and explained.")

#text("When more specialised experts started working on subproblems, particularly numerical optimisation, it gave me snippets I could mention in my first-year algebra class to let them know how generalisations of the things they were learning (eigenvectors, symmetric matrices, convex optimisation etc) were being applied at the cutting edge of research. I even showed, on projector screens, Terry’s blog and the relevant comments, some made that very day. It has been a great opportunity to expose students of all stripes to the idea of research in pure mathematics, and that a problem in number theory needed serious tools from seemingly unrelated areas.")

#text("For me personally it felt like being able to sneak into the garage and watch a high-performance engine being built up from scratch; something I could never do, but could appreciate the end result, and admire the process.”")

#emph[#text("[Contribution added, thanks! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f748edb4e50bd0eb515b1d1d778ae4d6d8c3d0e9b91b0982a99ebebf1728b0b-bfedad3b1d6d2a5a826707abdb1932af9554c2ba0b223afd50147ad66d902fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-402893")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2014")])]

#text("Here are my comments for the retrospective.")

#text("“I first heard about Zhang’s result shortly after he spoke at Harvard in May, 2013. The techniques he used were well outside my main area of expertise, and I initially followed developments purely as a casual observer. It was only after reading Scott Morrison’s blog, where people had begun discussing improvements to Zhang’s bound, that I realized there was an interesting and essentially self-contained sub-problem (finding narrow admissible tuples) that looked amenable to number-theoretic combinatorial optimization algorithms, a subject with which I have some experience. I ran a few computations, and once I saw the results it was impossible to resist the urge to post them and join the polymath8 project. Aside from interest in the prime gaps problem, I was curious about the polymath phenomenon, and this seemed like a great opportunity to learn about it.")

#text("Like others, I was surprised by how much time I ended up devoting to the project. The initially furious pace of improvements and the public nature of the project made a very addictive combination, and I wound up spending most of that summer working on it. This meant delaying other work, but my collaborators on other projects were very supportive. I certainly do not begrudge the time I devoted to the polymath8 effort; it was a unique opportunity, and I’m glad I participated.")

#text("In terms of the polymath experience, there are a couple of things that stand out in my mind. In order to make the kind of rapid progress that can be achieved in a large scale collaboration, the participants really have to be comfortable with making mistakes in a forum that is both public and permanent. This can be a difficult adjustment, and there was certainly more than one occasion when I really wished I could retract something I had written that was obviously wrong. But one eventually gets used to working this way; the fact that everybody else is in the same boat helps. Actually, I think being forced to become more comfortable with making mistakes can be a very positive thing. This is how we learn.")

#text("The other thing that impressed me about the project is the wide range of people that made meaningful contributions. Not only were there plenty of participants who, like me, are not experts in analytic number theory, there were at least a few for whom mathematics is not their primary field of research. I think this is major strength of the polymath approach, it facilitates collaboration that would otherwise be very unlikely to occur.")

#text("It is perhaps worth highlighting some of the features of this project that made it a particularly good polymath candidate. First, the problem we were working on was well known and naturally attracted a lot of interested observers; this made it easy to recruit participants. Second, we had a clearly defined goal (improving the bound on prime gaps), and a metric against which incremental progress could be easily measured; this kept the project moving forward with lot of momentum. Third, the problem we were working on naturally split into sub-problems that were more or less independent; this allowed us to apply a lot of brain power in parallel, and when one branch of the project would slow down, another might speed up. Finally, we had an extremely capable project leader, one who could see the whole picture and was very adept at organizing and motivating people.")

#text("I don’t mean to suggest that these attributes are all necessary ingredients for a successful polymath project, but I think it is fair to say that, at least in this case, they were sufficient.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-402896")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2014")])]

#text("“Finally, we had an extremely capable project leader, one who could see the whole picture and was very adept at organizing and motivating people.”")

#text("This is something I should have mentioned in my retrospective as well!")

#text("It is also somewhat surprising to me how many of us commented on the time we devoted to the project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-402950")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2014")])]

#text("Thanks, Andrew, both for the retrospective contribution and for the nice words!")

#text("Now that we have a number of different contributions, I think maybe it is not so necessary to try to create a conclusions section, I think it actually works better when each contributor draws their own separate conclusions, although there does seem to be a remarkable amount of consensus amongst the participants. I’ll try to go over the retrospective article as a whole in the next day or two and do some polishing. Though I am debating as to whether to try to harmonise the writing styles (for instance, by making the capitalisation of “Polymath” uniform across contributions) – perhaps it actually would be more authentic to have each contributor write in their own personal style rather than try to enforce uniformity? (But I think we should certainly fix up typos and formatting errors, of course.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-403957")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2014")])]

#text("I cleaned up the text (there was in particular an issue with apostrophes not being recognised by LaTeX that is nwo fixed) and decided to uniformise the capitalisation of “Polymath” as it was a bit jarring. We’re still waiting on a few more contributions, but I think it is beginning to take shape quite nicely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f748edb4e50bd0eb515b1d1d778ae4d6d8c3d0e9b91b0982a99ebebf1728b0b-bfedad3b1d6d2a5a826707abdb1932af9554c2ba0b223afd50147ad66d902fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-407094")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2014")])]

#text("A couple of minor typos in the retrospective:")

#text("1. First sentence of section 5, “had be looking” should be “had been looking”.")

#text("2. There are still two uncapitalized occurrences of “polymath” in section 8 (first and fourth paras).")

#text("3. In the first para of section 9 you wrote “…Zhang had not published little in the area…” Perhaps you meant to write “had published little” (or “had not published much”)?")

#text("One general comment: I think the retrospective would read better if the contributions were listed more or less in the order they were posted to the blog, rather than being ordered alphabetically by last name. Many contributors refer to comments by others that were written chronologically earlier, but in most cases these appear later in the retrospective. In particular, I think it would make a lot of sense to put your comments (currently in section 9) first, this would really help to orient the reader.")

#emph[#text("[Corrections made, and sections now ordered chronologically – T.]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-407101")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2014")])]

#text("I agree with Andrew, and would propose the contributions be listed in chronological rather than alphabetical order.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-405334")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("Here are some personal comments for the retrospective:")

#text("In June last year, one of my colleagues informed me about the polymath8 project and, in particular, about the programming challenge of finding admissible $k$-tuples whose diameter $H$ is as small as possible. I decided to give it a try and join “team $H$” of the production line. Luckily, I jumped in shortly after the project had started, at a point where there was still some low-hanging fruit. Like others I experienced how addictive it was to search for smaller values of $H$, while trying new computational tricks and combining them with ideas of the other participants. Because the value of $k$ kept decreasing as well, new challenges popped up every other day or so, which fueled the excitement. The whole event was intense and highly interactive, and progress was made at an incredible speed. (It is not academic to say so, but when the other teams managed to decrease $k$ to a size where our computational methods became superfluous, this was a bit of a disappointment. Luckily, Maynard’s work on prime triples, quadruples, … put larger values of $k$ back into play.)")#linebreak()#text(" Along the way it became clear that the online arena in which it all took place attracted many spectactors, and it felt like a privilege to be in there. It did require a mental switch to post naive (and sometimes wrong) ideas on the public forum, but in the end I agree with Andrew Sutherland that this is not necessarily a bad thing.")#linebreak()#text(" Gradually, by reading the blog posts, I also learned about the other parts of Zhang’s proof. On a personal level, this I found the most enriching bit: participating in the polymath8 project was a very stimulating way of learning and appreciating a new part of mathematics. This is definitely thanks to the clarifying and enthusing way in which Terence Tao administered the project. At the same time, I must admit that I did not grasp every detail from A to Z. From the point of view of a “coauthor” this is somewhat uncomfortable, but it may be inherent to the production line model along which the polymath projects are organized.")

#emph[#text("[Added to the retrospective, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d815cf5704012394db2ca4090a05f042432268426dc0d796b07dbe928ab0113-744df7ba6c1c283202fc26e4e29016bb9e811f40b4786bd46e580745dd5a9849.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-405336")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("This is not too dissimilar to research projects in experimental fields, where people can contribute a part but not understand other parts. At the extreme end, the people in the teams at CERN may play some small part designing a bit of machinery, but not know about the latest data analysis techniques used to find a significant signal.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-404338")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2014")])]

#text("A simple generalization of the weight function ")#mi("\\nu (n)")#text(" is to replace the square in its definition (18) by any even power (e.g. a fourth power.)")#linebreak()#text(" This seems to emphasize the peaks of the weight function, but it is not clear how to generalize the needed asymptotics (in theorems 3.5, 3.6).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-406632")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2014")])]

#text("In Polymath8b paper, in the last line of section 4.1 (page 20), it seems that in the ")#mi("O(1)")#text(" error contribution estimate, “")#mi("x^{1-\\varepsilon}")#text("” can be replaced by “")#mi("1")#text("“.")#linebreak()#text(" Therefore, it seems that condition (27) is not really needed !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-406692")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2014")])]

#text("The way we are handling the summation over ")#mi("d_1,\\dots,d_k,d^{\\prime}_1,\\dots,d^{\\prime}_k")#text(" here is to group the terms according to the value of the expression ")#mi("[d_1,d^{\\prime}_1] \\dots [d_k,d^{\\prime}_k]")#text(". Each value of this expression indeed contributes ")#mi("\\lessapprox 1")#text(" to the error term; unfortunately, there are ")#mi("\\lessapprox x^{1-\\varepsilon}")#text(" possible values of this expression, so the net size of this error is ")#mi("\\lessapprox x^{1-\\varepsilon}")#text(" rather than ")#mi("\\lessapprox 1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-406705")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2014")])]

#text("Thanks! (I now understand it.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-407236")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2014")])]

#text("In Polymath8b paper, page 19 line 6, “")#mi("\\log W N")#text("” should be “")#mi("\\log (W N)")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-407788")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2014")])]

#text("In Polymath8b paper, the rightmost “")#mi("t_k")#text("” in (31) should be “")#mi("d  t_k")#text("“.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-408205")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2014")])]

#text("In Polymath8b paper, the derivation in page 18 of the crude bounds for ")#mi("\\zeta_{W N}")#text(" can be simplified to")

#tao-math("\\left|\\zeta_{W N}(s)\\right|, \\left|\\zeta_{W N}(s)\\right|^{-1} \\leq \\zeta (1+1/ \\log x) \\ll \\log  x", block: false)

#emph[#text("[Implemented, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410372")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2014")])]

#text("In the explanation (the line below) of the first inequality, it is somewhat simpler to compare the magnitudes of the corresponding factors of the Euler products (instead of the corresponding terms of Dirichlet series.)")

#text("Similarly, the bound ")#mi("\\exp (O (\\log \\log x))")#text(" for the expression above (38), can be replaced by")

#mi("\\zeta^3 (1+1/ \\log x) \\ll \\log^3 x")

#emph[#text("[Changes implemented, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18ac32f1757df2128ad3a7dbe5ae836196e52ea337899648b1954fd17de88a53-604117642946f3f93e6b67fa3d6ac648db2fa29093c98f5c5b218b96551f81a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-408478")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2014")])]

#text("Dear Terry, I can see you added the author affiliations to the retrospective paper, but mine are missing. I am a research advisor at Alfréd Rényi Institute of Mathematics and a professor at Central European University. Please add this information. Thank you!")

#emph[#text("[Oops, sorry about that! Added now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-408482")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2014")])]

#text("In Polymath8b paper, page 18 line 5 from below, the maximum (defining the cubical integration domain) should be over the absolute values of the ")#mi("2 k")#text(" variables.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-408897")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("Emmanuel Kowalski has just added his contribution to the retrospective, and also brought my attention to ")#link("http://smf4.emath.fr/Publications/Gazette/2014/140/smf_gazette_140_19-31.pdf")[#text("this nice article")]#text(" (in French) by de la Breteche for the April 2014 issue of the Gazette of the Société Mathématique de France on prime gaps and on Polymath8.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-409239")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2014")])]

#text("According to Ken Ono’s facebook page, and also according to the polymath website: ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")]#text(" it appears that the paper has been accepted in RIMS.")

#text("Is that correct and/or official?")

#text("Either way, it is probably time for me to give the paper a final thorough read-through.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-409615")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2014")])]

#text("I suppose I should have posted that here: Ken sent me an email on Aug 2 saying that the paper had been accepted in principle, modulo the production people checking that the article format conformed to the standards of the journal, i.e. it is past the refereeing stage and onto the typesetting stage. I don’t think I’ve received any subsequent update yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410126")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2014")])]

#text("Thanks for the update. I’ve read through Section 4, and found the following minor changes to recommend. I would have made most of the changes myself, but I definitely don’t want to introduce a new error at this stage.")

#text("1. Page 6. In the statement of Theorem 2.3, the brackets around [5,62] are slanted. It might look nicer to put the brackets in roman type rather than italicized. (If we do this, do it again in Theorem 2.8)")

#text("2. Page 6. In Claim 2.6, the notation ")#mi("x^{\\varepsilon} \\lessapprox N,M\\lessapprox x^{1-\\varepsilon}")#text(" is open to equivocation, as the comma could be interpretated as a break between two different mathematical quantities. (It’s okay as it stands, if we don’t want to make a change.)")

#text("Also, perhaps “pointwise bound” should be “pointwise bounds” since there are two of them? (OTOH they are both part of (6), so it is also okay as is.)")

#text("3. Page 7. In the proof of Proposition 2.7, the function ")#mi("1(n)")#text(" is introduced. This notation is defined earlier in the paper (in section 1.2) when it has a subscript. Perhaps this unsubscripted function should also be defined there.")

#text("4. Page 9. Table 1 is appearing in the middle of the statement of Theorem 3.3. It would be better to put it afterwards if possible.")

#text("5. Page 11. Two lines above (19), change “for various smooth functions” -> “for various fixed smooth compactly supported functions”. Also, both two lines earlier and one line later “linear combinations” are mentioned. Do we want to specify that they are “fixed” (even though this is obvious)?")

#text("6. Page 11. When deriving (21) from (14) and (20), there is the additional assumption that “")#mi("F")#text(" is supported on ")#mi("[0,1]")#text("“. How do we deduce this extra condition on the support? (If we don’t make that assumption on the support, but just assume ")#mi("x\\leq p\\leq 2x")#text(", we have ")#mi("\\lambda_F(n)=F(0)-F(1)+o(1)")#text(", which seems to work out, but I imagine there is something simple here I’m missing.)")

#text("7. Page 12. The normalization constant ")#mi("B")#text(", defined in the statement of Lemma 3.4 is used again here in Theorem 3.5 (and elsewhere in the paper). It should be clear to most readers what it’s definition is, but if we want to be exact perhaps after Lemma 3.4 we should say that ")#mi("B")#text(" continues to hold that same meaning everywhere else in the paper.")

#text("8. Page 14. In Theorem 3.13, instead of (xii’) it might look better to write (xii$’$), and make similar changes throughout the paper.")

#text("9. Page 22. Section 4.3, line 5 (the first off-set equation), the exponent has ")#mi("\\vartheta")#text(", but I believe this should be ")#mi("1/2 + 2\\varpi")#text(". [This same typo also occurs in the in the last two offset equations of section 4.3, near the bottom of this same page.]")

#text("10. Page 23. In equations (48) and (49), the argument of the indicator function is (implicitly) only appearing in the subscript. It might be better to make the argument appear explicitly as an argument, and modify the subscript accordingly. E.g., in (48) perhaps writing something like ")#mi("1_{p_0|\\cdot}(n+h_{j0})")#text(", and in (49) something like ")#mi("1_{p(\\cdot)\\leq x^{\\varepsilon}}(n+h_{j_0})")#text(".")

#text("Alternatively, in Section 1, when defining indicator functions, we could explain how sometimes we will write the argument in the subscript. This alternative may be preferable as there are other places where this same notation is used.")

#text("11. Page 23. Last line– It seems that we can replace ")#mi("\\ll")#text(" with $\\latex \\leq$.")

#text("12. Page 24. In the offset equation above (50), should ")#mi("p|n")#text(" be ")#mi("p|n+h_j")#text("?")

#text("13. Page 25. Line 2 (first offset equation). The superscript on ")#mi("2")#text(" is missing a right-most parenthesis.")

#text("14. Page 27. Last line (above the footnote). I believe we want to change “divides ")#mi("p")#text(" and ")#mi("d_1")#text("” -> “divides ")#mi("n")#text(" and ")#mi("d_1")#text("”")

#text("—")

#text("I also did a quick spell-check and double-word check.")

#text("Page 73. Misspelled word: “adjustements”")

#text("Page 75. Double words: “by examining the the entries”, “If we sieve the the residue class”, and “This will typically happen for for some”")

#text("—")

#text("Things I’m still struggling to understand within the first four sections.")

#text("Page 30. How is Proposition 4.2 being applied? I’m just not immediately seeing the connection. (It may be obvious, I am still a little jet-lagged.)")

#emph[#text("[Corrected, thanks, with the argument invoking Proposition 4.2 in page 30 reworded. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410127")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2014")])]

#text("In item (2) above, the two ")#mi("\\lessapprox")#text(" symbols should be curly ")#mi("\\ll")#text(" symbols.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8926b3f00b7cafcf23d22389c8ec9283aa389320122eec22b7469327005b55f-2581c425594ea69a2675700b29cea03b5fa4846b4dc021291461a26d23f16283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-409284")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2014")])]

#text("Beginner Q: Section 2 (p.5) introduces distributional estimates on the von Mangoldt function, which “serves as a proxy for the primes.” Does this mean that as x gets large, prime powers beyond the 1st contribute negligibly to the LHS of Claim 2.2?")

#emph[#text("[That is certainly one of the key features of the von Mangoldt function that make it a good proxy for the primes, yes. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8926b3f00b7cafcf23d22389c8ec9283aa389320122eec22b7469327005b55f-2581c425594ea69a2675700b29cea03b5fa4846b4dc021291461a26d23f16283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410121")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2014")])]

#text("p. 4, near the middle of Section 1.1, “…in combination of Lemma 3.4…”: of -> with")

#emph[#text("[Corrected (for the Polymath8b paper), thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410150")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2014")])]

#text("Thanks Terry for making the changes I suggested above!")

#text("One final question. What happens to the arguments when we replace (20) by the condition ")#mi("\\lambda_F(n)=F(0)-F(1)+o(1)")#text(" (which is what happens by dropping the assumption that ")#mi("F")#text(" is supported on ")#mi("[0,1]")#text(", but still assume ")#mi("n")#text(" is a prime in the range ")#mi("[x,2x]")#text(")? I quickly ran through the arguments, so I may have missed something, but it seems to me that:")

#text("1. The ")#mi("o(1)")#text(" term can be safely ignored.")

#text("2. Instead of ")#mi("f_{i,j}(0)")#text(" in a couple formulas, we just replace that factor with ")#mi("(f_{i,j}(0)-f_{i,j}(1))")#text(", and similar looking (but slightly more complicated) integral formulas arise for the asymptotic constants.")

#text("Is this a cheap way to get around the support restriction, or is there some obstruction I’ve missed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410172")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2014")])]

#text("Yes, I think one would still get asymptotics in this case. I think though in our situation we never deal with supports that get as far as 1; I think the largest support we have to deal with is [0,3/4]. (The “classical” simplex ")#mi("\\{ t_1 + \\dots + t_k \\leq \\frac{\\vartheta}{2} \\}")#text(" only gets as far as 1/2, and we do play with an enlarged simplex ")#mi("\\{ t_1 + \\dots + t_k \\leq \\frac{\\vartheta k}{2(k-1)} \\}")#text(", but even in the case when ")#mi("\\vartheta=1")#text(" and ")#mi("k=3")#text(", this only reaches as far as 3/4.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8926b3f00b7cafcf23d22389c8ec9283aa389320122eec22b7469327005b55f-2581c425594ea69a2675700b29cea03b5fa4846b4dc021291461a26d23f16283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410320")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2014")])]

#text("Polymath 8b paper, Page 57.7: “with be” -> “will be”")#linebreak()#text(" Page 58.6: “We took d = 23 and imposing” -> “We took d = 23 and imposed”")#linebreak()#text(" Page 61.4: “If we use … and sets … one can compute” -> “If one uses … and sets … one can compute”")#linebreak()#text(" Page 61.6: “supported the simplex” -> “supported in(?) the simplex”")#linebreak()#text(" Page 62, formula (133): is it (x,y), rather than z, which should be in polygon Qi?")#linebreak()#text(" Page 62.6: “on the coefficients on the Fi” -> “on the coefficients of the Fi”?")#linebreak()#text(" Page 62, last two lines: you might want to be consistent about “x + y” vs. “y + x”")#linebreak()#text(" Page 64, last line: what are “these regions”? (sorry if this is obvious; just skimming)")#linebreak()#text(" Page 67.0: should the 2nd integral after “signed definite integral” have its limits interchanged?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8926b3f00b7cafcf23d22389c8ec9283aa389320122eec22b7469327005b55f-2581c425594ea69a2675700b29cea03b5fa4846b4dc021291461a26d23f16283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410323")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2014")])]

#text("please ignore the Page 67.0 item, I must have vertical dyslexia")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8926b3f00b7cafcf23d22389c8ec9283aa389320122eec22b7469327005b55f-2581c425594ea69a2675700b29cea03b5fa4846b4dc021291461a26d23f16283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410360")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2014")])]

#text("Polymath 8b paper, Pages 47-55: naïve scan didn’t catch anything")#linebreak()#text(" Page 56.4: “finite set b1,…” -> “finite set of functions b1,…”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8926b3f00b7cafcf23d22389c8ec9283aa389320122eec22b7469327005b55f-2581c425594ea69a2675700b29cea03b5fa4846b4dc021291461a26d23f16283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410397")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2014")])]

#text("Polymath 8b paper, Page 8: “…smaller than k, in fact j…” -> “…smaller than k; in fact, j…”")#linebreak()#text(" Page 68: In the first summation subscript of (142) and (144), is it really x (and not say n+h, or n) that should =a(q)?")#linebreak()#text(" Page 68: Are the parenthetical remarks preceding and following (143) both needed?")#linebreak()#text(" Page 78.2: “is already admissibility” -> “is already admissible”")#linebreak()#text(" Page 78.6: “msuch” -> “m such”")#linebreak()#text(" It might help if someone else who doesn’t know too much math would “naïve-scan” the 8b paper. Having done a casual such scan of pages 42-78 (and assuming pages 1-10 have gotten a lot of scrutiny), I guess pages 11-41 would benefit most.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410638")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2014")])]

#text("In Polymath8b paper (page 30), it seems that in (65)-(67) the difference operators")

#text("“")#mi("\\partial_{t_1} ... \\partial_{t_r}")#text("” should be")

#text("“")#mi("\\partial_{(t_1)} \\cdots \\partial_{(t_r)}")#text("”")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410832")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("It should still be corrected at four places (one in (65), two in (66) and one in (67)).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410731")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2014")])]

#text("I forgot to mention this earlier, but about five days ago, Emmanuel and Phillipe finished their streamlining of the ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/AAAumDozECHOx65jJSka0zk_a/newgap.pdf")[#text("Polymath8a paper")]#text(". I’ve now gone through it also, and am pretty happy with it (and it has addressed all the referee concerns). I’ll wait for another week to see if there are more changes to be made, but then we can send it back to Andrew Granville at A&NT. The retrospective is almost complete too, so it looks like all three papers coming out of Polymath8 are on track.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-410851")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("Some minor comments:")

#text("On page 1, “there exists even integers” –> “there exist”.")

#text("On page 3, I didn’t understand the sentence concerning ")#emph[#text("the")]#text(" polynomial ")#mi("P(n)")#text(": is this a single polynomial (in which case it may be better to write ")#mi("1 \\leq i,j \\leq k; i \\neq j")#text(" in the subscript?).")

#text("On page 6, “In addition …, there are some additional concepts …”. Maybe we can just write “There are some additional concepts …”?")

#text("On page 8, there is a ")#mi("\\mathcal{D}^(y)")#text(" that should be ")#mi("\\mathcal{D}^{(y)}")#text(".")

#text("On page 12 in step (0) of the proof: “in checking that an integer ")#mi("n")#text(" is ")#mi("(i,y)")#text("-d.d., it suffices …” –> “in checking that an integer ")#mi("n")#text(" is ")#mi("(i,y)")#text("-d.d, it suffices …” (removed dot)")

#text("On page 61 there are two occurrences of ")#mi("\\overline{\\mathbb{Q}}_\\ell")#text(" that should be ")#mi("\\overline{\\mathbb{Q}_\\ell}")#text(" for consistency (or the other way round, but then there are more changes to make).")

#text("On page 74 in Remark 6.18 in the definition of ")#mi("\\pi_1")#text(" there is a ")#mi("\\mapsto")#text(" that should be a ")#mi("\\to")#text(".")

#text("Reference [11]: “probléme” –> “problème”")

#emph[#text("[Corrected, thanks – though I believe the second dot in d.d. will still be needed to signify the abbreviation. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-412352")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2014")])]

#text("I’ve now sent the revised version of Polymath8a back to Algebra & Number Theory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-1/#comment-411429")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2014")])]

#text("In the retrospective paper, Turan and Erdos names (References [13] and [32]) are misspelled.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8926b3f00b7cafcf23d22389c8ec9283aa389320122eec22b7469327005b55f-2581c425594ea69a2675700b29cea03b5fa4846b4dc021291461a26d23f16283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-411600")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2014")])]

#text("Polymath 8b paper:")#linebreak()#text(" Page 13.3: “establishing certain variational problems” -> “establishing certain variational results” ?")#linebreak()#text(" Page 13.7: “square integrable” -> “square-integrable”")#linebreak()#text(" Page 14.4: “be the defined” -> “be defined”")#linebreak()#text(" Page 14.4: “square-integrable F supported in” -> “square-integrable functions F that are supported in”")#linebreak()#text(" Page 15.3: “square integrable functions” -> “square-integrable functions”")#linebreak()#text(" Page 15.5: “one of the following..hold” -> “one of the following..holds”")#linebreak()#text(" Page 15.9, “there is also a version corresponding to part (i) also”: strike an “also”")#linebreak()#text(" Page 19.9: “…replace [dj , d’j] with…]” -> “…replace the denominators [dj , d’j] with…]”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-411745")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2014")])]

#text("In Polymathe8b paper, after the definition of ")#mi("H_m")#text(" in the abstract, it seems clearer to add (as in the introduction) the definition of ")#mi("p_n")#text(".")

#text("Also, in the first line of page 46, “[52]” should be “[53]”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-411934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2014")])]

#text("Thanks to all for the many corrections on the Polymath8b paper! The RIMS production staff at Springer are now asking for the LaTeX source, so I’ll wait until this evening for any last remaining corrections and then submit the source to them (and also update the arXiv copy).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-412097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2014")])]

#text("OK, I have sent back the source files and updated the arXiv copy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-412389")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2014")])]

#text("In the main page of Polymath8, the links for the arXiv copies of Polymath8a and Polymath8b papers are still for older versions.")

#emph[#text("[It may take about 24 hours or so for the arXiv to update. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8926b3f00b7cafcf23d22389c8ec9283aa389320122eec22b7469327005b55f-2581c425594ea69a2675700b29cea03b5fa4846b4dc021291461a26d23f16283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-412039")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2014")])]

#text("Polymath 8b paper:")#linebreak()#text(" Page 21.5: Is the meaning of “this contribution” sufficiently clear?")#linebreak()#text(" Page 25.3: In the inequality following “We see that”, and in the RHS expansion 2 lines further on, are the ‘3-bar-equals’ signs intended?")#linebreak()#text(" Page 29.0: “In particular, the…tuples..contributes…” -> “In particular, the…tuples…contribute…”")#linebreak()#text(" Page 30.2: In the LHS of the 2nd standalone equation, shouldn’t all inequalities between the pi (& thus the 5th inequality symbol) be strict?")#linebreak()#text(" Page 32.6, “Now that we have proven…we can now establish…”: strike the 2nd “now”")#linebreak()#text(" Page 34.8: “..convolves…by…” -> “…convolves…with…” ?")#linebreak()#text(" Page 36.2, 2nd equation: Is it allowed to have a top-heavy partial derivative like that?")#linebreak()#text(" Page 38.0: “…holds, then…” -> “…holds; then…” (ditto in the next sentence)")#linebreak()#text(" Page 38.4: “for some i0 = 1,…,k” -> “for some 1 lte i0 lte k”??")#linebreak()#text(" Page 38.6: “…this and Theorem 3.5 is not strong enough…” -> “…this combined with Theorem 3.5 is not strong enough…”?")#linebreak()#text(" Page 41.2 “supported of intervals” -> “supported on intervals”")#linebreak()#text(" Page 41.2 “with the support of each component…supported in” -> “with each component…supported in”")#linebreak()#text(" (end of casual “naive scan”)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85b1951f8a78f312e438ee638df9d5874d7ac9e2468cd092ac4124a5293f350-52fc9493ff777e3522ac72f04d77065d71f50f5221e7ad6749d5e7fb81ad1ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-412964")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2014")])]

#text("Polymath 8b paper, v3 on ")#link("http://arxiv.org/pdf/1407.4897v3.pdf")[#text("http://arxiv.org/pdf/1407.4897v3.pdf")]#text(".")

#text("The following are for the bibliography:")

#text("– Ref. 7: $156$ –> $\\mathbf{156}$")#linebreak()#text(" – Ref. 10: $70$ –> $\\mathbf{70}$")#linebreak()#text(" – Ref. 11: $52$ –> $\\mathbf{52}$")#linebreak()#text(" – Ref. 12: $33$ –> $\\mathbf{33}$")#linebreak()#text(" – Ref. 13: $4$ –> $\\mathbf{4}$")#linebreak()#text(" – Ref. 14: to appear in: –> to appear in")#linebreak()#text(" – Ref. 16: $152$ –> $\\mathbf{152}$ + E. –> É [two things]")#linebreak()#text(" – Ref. 20: $4$ –> $\\mathbf{4}$")#linebreak()#text(" – Ref. 21: 945—1040 –> 945–1040")#linebreak()#text(" – Ref. 22: $42$ –> $\\mathbf{42}$")#linebreak()#text(" – Ref. 25: $170$ –> $\\mathbf{170}$")#linebreak()#text(" – Ref. 26: $361$ –> $\\mathbf{361}$")#linebreak()#text(" – Ref. 30: $44$ –> $\\mathbf{44}$")#linebreak()#text(" – Ref. 31: $34$ –> $\\mathbf{34}$")#linebreak()#text(" – Ref. 32: pp. 123–127 –> 123–127")#linebreak()#text(" – Ref. 33: $25$ –> $\\mathbf{25}$")#linebreak()#text(" – Ref. 34: Publications Vol. $53$ –> Publications, vol. $53$ [two things]")#linebreak()#text(" – Ref. 36: $34$ –> $\\mathbf{34}$")#linebreak()#text(" – Ref. 40: volume $227$ of Lecture Notes in Math. Springer –> Lecture Notes in Math. Springer, vol. 227 [two things]")#linebreak()#text(" – Ref. 42: $52$ –> $\\mathbf{52}$")#linebreak()#text(" – Ref. 43: $40$ –> $\\mathbf{40}$")#linebreak()#text(" – Ref. 44: pp. 525–559 –> 525–559")#linebreak()#text(" – Ref. 54: $80$ –> $\\mathbf{80}$")#linebreak()#text(" – Ref. 55: $7$ (1961/1962) 1–8 –> $\\mathbf{7}$ (1961/1962), 1–8 [two things]")#linebreak()#text(" – Ref. 56: $7$ –> $\\mathbf{7}$")#linebreak()#text(" – Ref. 57: Vol. I –> vol. I")#linebreak()#text(" – Ref. 58: in: –> in")#linebreak()#text(" – Ref. 59: $44$ –> $\\mathbf{44}$")

#text("– Ref. 22 should in between ref. 17 and 18")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-413757")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2014")])]

#text("In Polymath8 home page, the table of current records (“without EH”) should be updated to the bounds in Polymath8b paper (theorem 1.4(ii)-(vi)).")

#emph[#text("[Actually, the records are slightly better than the 8b paper, because they use a provisional equidistribution estimate whose proof has not been fully written up due to the need to check some tricky algebraic geometry. There are some people looking to flesh out the details of that estimate, though this would be done by a more traditional collaboration, i.e. outside of the Polymath8 project scope. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-416916")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2014")])]

#text("In Polymath8b paper (page 18), the factorization of the integral kernel ")#mi("K")#text(" into the factors ")#mi("K_p")#text(" (given by (39)) may be verified via the following very general (and simple!) factorization principle:")

#text("Let ")#mi("\\phi")#text(" be a bijection from the product of finite nonempty sets ")#mi("S_1, ... , S_n")#text(" onto a set ")#mi("S")#text(". Let ")#mi("f")#text(" be a complex-valued function on ")#mi("S")#text(" with the (factorization) property:")

#mi("f(\\phi (x_1, ... , x_n)) = \\prod_{j=1}^n f_j(x_j)")

#text("For every ")#mi("x_1 \\in S_1, ... , x_n \\in S_n")#text(", where ")#mi("f_1, ... , f_n")#text(" are certain complex-valued functions on ")#mi("S_1, ... , S_n")#text(", correspondingly. Therefore")

#mi("\\sum_{x \\in S} f(x) = \\sum_{x_1 \\in S_1, ... , x_n \\in S_n}  \\prod_{j=1}^n f_j(x_j) = \\prod_{j=1}^n \\sum_{x_j \\in S_j} f_j(x_j)")

#text("Remark: This factorization principle is for finite sums and products (but under certain regularity conditions it may be extended for countable sums and products.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-420255")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2014")])]

#text("Just a note that all of the people who had agreed to contribute to the retrospective article at ")#link("https://www.dropbox.com/sh/koxbhwvw1ysybk9/AADTJ4w3yegvgTut_Tsv0Sana/retrospective.pdf")[#text("https://www.dropbox.com/sh/koxbhwvw1ysybk9/AADTJ4w3yegvgTut_Tsv0Sana/retrospective.pdf")]#text(" have now done so. I’ll wait until Monday in case there are any last minute edits or suggestions, and then submit to the EMS newsletter.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-421166")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2014")])]

#text("In the definition of ")#mi("H_m")#text(" (in both the abstract and introduction), ")#mi("p_{n+m} - p_n")#text(" should be inside parentheses.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-422189")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2014")])]

#text("It should also be corrected in the introduction (page2, line 14 from below.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-422384")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2014")])]

#text("The closing parenthesis is misplaced.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-423098")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2014")])]

#text("In the retrospective article, after “")#mi("H_1 \\leq 6")#text("” in the introduction (line10 above the introduction end), “generalized” should be added before “Elliott-Halberstam conjecture”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85b1951f8a78f312e438ee638df9d5874d7ac9e2468cd092ac4124a5293f350-52fc9493ff777e3522ac72f04d77065d71f50f5221e7ad6749d5e7fb81ad1ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-420269")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2014")])]

#text("Footnote 5: “Nelson and” –> “Nelson, and”")#linebreak()#text(" Footnote 6: “the” –> “The” + “2004” –> “2004.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-421534")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2014")])]

#text("Some typos:")

#text("1. In Polymath8a paper (definition 1.4 in the old unabridged version, definition 1.2 in the new version) and in Polymath8b paper (definition 1.6), it seems that “")#mi("X \\leq x^{o(1)}Y")#text("” should be “")#tao-math("\\left|X\\right| \\leq  x^{o(1)}Y", block: false)#text("“.")#linebreak()#text(" 2. In Polymath8a paper (page 22), “")#mi("\\Delta(\\alpha_k ; b(q))|")#text("” should be “")#mi("\\Delta(\\alpha_k ; b(q))")#text("” in line 4, and “")#tao-math("\\left|\\Delta(\\alpha_k;b(q))\\right|", block: false)#text("” in line 6.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85b1951f8a78f312e438ee638df9d5874d7ac9e2468cd092ac4124a5293f350-52fc9493ff777e3522ac72f04d77065d71f50f5221e7ad6749d5e7fb81ad1ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-421570")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2014")])]

#text("Retrospective article, Terrence Tao’s input:")#linebreak()#text(" – P. 3, l. -4: “The first that” –> “The first time that”?")#linebreak()#text(" – P. 3, l. -1: “skeptical – the” –> “skeptical—the” or “skeptical\\,—\\,the”")#linebreak()#text(" – P. 7, 2nd paragraph, l. 7: “size – 163” –> “size—163” or “size\\,—\\,163”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-423499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2014")])]

#text("I’ve submitted the retrospective to the newsletter of the EMS and uploaded it to the arXiv. I’ll make a blog post about it when the arXiv paper comes out (and it’s about time to roll over the polymath8 thread again anyway, though presumably this will be the final time to do so, as the project now seems to be more or less concluded).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-424362")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2014")])]

#text("In polymath8b paper, in the line below the estimate (2), “[52, Lemma 1.5]” should be “[53, Lemma 1.5]” (or “[52, Lemma 1.3]”), but it seems that (2) is not explicitly stated in these lemmas.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-425128")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2014")])]

#text("In Polymath8b paper (page 5), “[52, Lemma 1.5]” (in the line below the estimate (2)) should still be corrected to “[52, Lemma 1.3]” – since lemma 1.5 of the older unabridge version [53] is now lemma 1.3 of the new version [52] of Polymath8a paper.")

#text("Although the estimate (2) is not explicitly stated in [52, lemma 1.3], it easily follows (using summation by parts) from [52, lemma 1.3(ii)].")

#emph[#text("[Oops, the correction did not update properly before; fixed now. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The “bounded gaps between primes” Polymath project – a retrospective | What's new")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-424848")[#strong[#text("The “bounded gaps between primes” Polymath project – a retrospective | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2014")])]

#text("[…] post will also serve as the latest (and probably last) of the Polymath8 threads (rolling over this previous post), to wrap up any remaining discussion about any aspect of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87b89f9b1f4c18e4c6984269c44cabaaf809cf7bf72731baa6585b28bc47ae54-2bc3b8355bd0662762aca5865e1068f76c14b93c8c57d7ea83f920c563ea2d72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-428034")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2014")])]

#text("The “work of Zhang” anchor is broken.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afa9eda8eb2ef6697fd7b04750a9993dee7ddfd84b0bcb9fd376b552c6953bbb-655031811e117043e9a33499b5cbff5efe6634d40e075375cf6501231bbdcea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ila")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-467088")[#strong[#text("Ila")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2016")])]

#text("I do believe all the ideas you have introducerd for our post.")#linebreak()#text(" They’rereally convincing and can definitely work.")#linebreak()#text(" Nonetheless, the posts are very brief for novices. May just you please extend")#linebreak()#text(" them a litttle from neext time? Thanks for the post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Bombieri asymptotic sieve | What's new")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-470704")[#strong[#text("Notes on the Bombieri asymptotic sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("[…] of the generalised Elliott-Halberstam (GEH) conjecture (as formulated for instance in Claim 2.6 of the Polymath8b paper), one can also swap the factor in the above asymptotics with other parity-violating weights and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-478580")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("Not sure how many of the contributors to this paper will see this comment three years after the fact, but: the journal that this paper was published in (Research in the Mathematical Sciences) has offered to give our paper a video abstract to feature on their journal (created by their affiliate, Research Square). Two examples of the abstracts they have made can be found at ")#link("https://www.youtube.com/watch?v=GMhZyYeBap4")[#text("https://www.youtube.com/watch?v=GMhZyYeBap4")]#text(" and ")#link("https://www.youtube.com/watch?v=PsGfuSGgHyk")[#text("https://www.youtube.com/watch?v=PsGfuSGgHyk")]#text(" . I’m willing to work with them on this, but wondered if any of the other former participants had any thoughts on the matter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f748edb4e50bd0eb515b1d1d778ae4d6d8c3d0e9b91b0982a99ebebf1728b0b-bfedad3b1d6d2a5a826707abdb1932af9554c2ba0b223afd50147ad66d902fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-478589")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2017")])]

#text("I’d be happy to help.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9f6bc693436a2c18414d720c4f49f279ea5d82c1a72404235abfb3dc6273826-d676495d27b9be6b9fc674570a885fba4fc8cdaf45f77680db9f37d551972b34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoa Huynh")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-516348")[#strong[#text("Hoa Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2019")])]

#text("Recently I made some discovery in Twin Prime Conjecture, and posted the work on my Facebook page:")

#link("https://www.facebook.com/TwinPrimeConjecture/")[#text("https://www.facebook.com/TwinPrimeConjecture/")]

#text("I made one Conjecture and one Thesis from this discovery.")

#text("Conjecture:")

#text("On average, the number of Twin Prime Pairs grows as the interval (L1, L2) ascends the number line; where L1 = (6k-1)^2 and L2 = (6k+1)^2, and k is natural number.")

#text("Thesis:")

#text("The discovery of formulas for L0, L1, and L2 helps to predict the growth of number of Twin Prime Pairs (#TPPs) in a controlled manner, even the Twin Prime Density (TPD) is thinning out, up the number line.")

#text("( L0 = previous L2 = (6(k – 1) + 1)^2 = (6k – 5) ^2 )")

#text("This means Twin Prime Conjecture is TRUE!")

#text("Please visit, like, share and comment.")#linebreak()#text(" Thank you,")#linebreak()#text(" Hoa")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9f6bc693436a2c18414d720c4f49f279ea5d82c1a72404235abfb3dc6273826-d676495d27b9be6b9fc674570a885fba4fc8cdaf45f77680db9f37d551972b34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoa Huynh")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-516355")[#strong[#text("Hoa Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2019")])]

#text("Test with k = 5, 50, 500, 5000")

#text("k = 5 50 500 5000")#linebreak()#text(" L1 = 841 89401 8994001 899940001")#linebreak()#text(" L2 = 961 90601 9006001 900060001")#linebreak()#text(" Pair = 2 14 54 376")

#text("k = natural number")#linebreak()#text(" length of (L1, L2) = 24k (grows linearly); 24 is the size of the sieve of 4 rows x 6 columns")

#text("(L1, L2) needs to grow to compensate for the thinning of Twin Prime Density.")#linebreak()#text(" Number of Twin Prime Pairs grows (on average, or from big picture.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9f6bc693436a2c18414d720c4f49f279ea5d82c1a72404235abfb3dc6273826-d676495d27b9be6b9fc674570a885fba4fc8cdaf45f77680db9f37d551972b34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoa Huynh")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-516394")[#strong[#text("Hoa Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2019")])]

#text("Facebook posts:")#linebreak()#text(" May 13, 2019. Report of data and graphs. 6 pages.")#linebreak()#text(" May 13, 2019: Appendix 4 and conclusion. 1 page.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9f6bc693436a2c18414d720c4f49f279ea5d82c1a72404235abfb3dc6273826-d676495d27b9be6b9fc674570a885fba4fc8cdaf45f77680db9f37d551972b34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoa Huynh")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-516564")[#strong[#text("Hoa Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2019")])]

#text("Just posted, May 22th:")#linebreak()#text(" a) Python program to count TPPs in (L1, L2.)")#linebreak()#text(" b) TPC: Graphical data tells better story than I do.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9f6bc693436a2c18414d720c4f49f279ea5d82c1a72404235abfb3dc6273826-d676495d27b9be6b9fc674570a885fba4fc8cdaf45f77680db9f37d551972b34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoa Huynh")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-516620")[#strong[#text("Hoa Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2019")])]

#text("Just posted: Appendix 5: Twin Prime Pairs are not as scarce as we thought.3 pages, 2 tables, 4 graphs.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9f6bc693436a2c18414d720c4f49f279ea5d82c1a72404235abfb3dc6273826-d676495d27b9be6b9fc674570a885fba4fc8cdaf45f77680db9f37d551972b34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hoa Huynh")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-516902")[#strong[#text("Hoa Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2019")])]

#text("Just posted, Appendix 6 Retrospect: My journey with Twin Prime Conjecture. 5 pages.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c24836e719199a18005ae6f6937c7deded9b203845584382b9d505ba1588b3-e64977382554a3c83fb3de2c459f5010d47cd040a8f15c603b960e206c1d7b76.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/comment-page-2/#comment-548118")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("Maybe this link can be of interest:")#linebreak()#text(" ")#link("http://www.les-mathematiques.net/phorum/read.php?5,1758830")[#text("http://www.les-mathematiques.net/phorum/read.php?5,1758830")]#linebreak()#text(" A proof that the set of integers n such that r0(n)=1 has positive density among the set of integers m such that r0(m) divides 6 would entail that the GEH conjecture implies the twin prime conjecture.")
]
