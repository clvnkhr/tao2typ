// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/
// Converted to Typst by tao2typ: "2026-10-14T10:58:00.189380+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Abel prize awarded to Furstenberg and Margulis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Abel prize awarded to Furstenberg and Margulis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 March 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/")[#text("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short post to note that this year’s Abel prize ")#link("https://www.abelprize.no/c76018/seksjon/vis.html?tid=76019&strukt_tid=76018")[#text("has been awarded jointly")]#text(" to ")#link("https://en.wikipedia.org/wiki/Hillel_Furstenberg")[#text("Hillel Furstenberg")]#text(" and ")#link("https://en.wikipedia.org/wiki/Grigory_Margulis")[#text("Grigory Margulis")]#text(" for “for pioneering the use of methods from probability and dynamics in group theory, number theory and combinatorics”. I was not involved in the decision making process of the Abel committee this year, but I certainly feel that the contributions of both mathematicians are worthy of the prize. Certainly both mathematicians have influenced my own work (for instance, Furstenberg’s proof of Szemeredi’s theorem ended up being a key influence in my result with Ben Green that the primes contain arbitrarily long arithmetic progressions); see for instance these ")#link("https://terrytao.wordpress.com/?s=furstenberg")[#text("blog posts mentioning Furstenberg")]#text(", and these ")#link("https://terrytao.wordpress.com/?s=margulis")[#text("blog posts mentioning Margulis")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-546795")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2020")])]

#text("comparatively")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/066507605c9fc5f7cc694aeb1402287a97d17adbaec1ede11c405325cc72206c-c51b0a1157c878ee9622d89a8e6435abca8acfa58e11a6633847dbfd3ec88862.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danny Crane")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-569396")[#strong[#text("Danny Crane")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2020")])]

#text("I concur with you that the contributions of these two mathematicians deserves a prize. It is really noble of this two individuals to invest their time and skills in exploring these mathematical concepts. We are hoping that they will receive even more recognition even as they go on about their research. ")#link("http://essaymojo.com/writing-services/write-my-economics-research-paper/")[#text("http://essaymojo.com/writing-services/write-my-economics-research-paper/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-546802")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2020")])]

#text("How do you think, my ")#link("https://mathematics21.org/algebraic-general-topology-and-math-synthesis/")[#text("algebraic general topology")]#text(" is also worth the prize or not?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-546822")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2020")])]

#text("I guess you will find out when you’re 70+ !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-546849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2020")])]

#text("This question could be asked only by a very modest person.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-546851")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2020")])]

#text("Something related to modesty vs honesty: ")#link("https://www.quora.com/What-is-wrong-with-our-society-today/answer/Victor-Porton")[#text("https://www.quora.com/What-is-wrong-with-our-society-today/answer/Victor-Porton")]#text(" read item [2].")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-547102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2020")])]

#text("NY Times article:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/089d0cedccdbee32786c7e296994cf315ef1b3c6f13b880e696921e040d47aec-d939e5745c48f83ef6584b0b100445f6f5430f1060f2ee4de3f5348e174ac098.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of riderriju")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-547114")[#strong[#text("riderriju")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Grigory margulis also the winner of fields medal which is equivalent to nobel prize")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neez Duts")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-547161")[#strong[#text("Neez Duts")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Since being equivalent is presumably an equivalence relation, the abel prize is equivalent to the fields model. The only reasonable interpretation is that one wins the abel prize if and only if one wins the fields medal. Therefore, Furstenberg won the fields medal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/089d0cedccdbee32786c7e296994cf315ef1b3c6f13b880e696921e040d47aec-d939e5745c48f83ef6584b0b100445f6f5430f1060f2ee4de3f5348e174ac098.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of riderriju")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-567378")[#strong[#text("riderriju")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2020")])]

#text("Sorry .but i also love Furstenberg .so please pardon me for my comments.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-548186")[#strong[#text("Hillel Furstenberg y Grigori Margulis, Premio Abel 2020 - Gaussianos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")]

#text("[…] Hillel Furstenberg es profesor emérito de la Universidad Hebrea de Jerusalén, y une este galardón al Premio Wolf que ya posee. Es conocido por su aplicación de la teoría de la probabilidad y la teoría ergódica en otras áreas de las matemáticas, como la teoría de números o los grupos de Lie. Entre otros logros matemáticos, simplificó bastante la demostración de un teorema de Endre Szemerédi, y su demostración ayudó mucho a Terence Tao y Ben Green a demostrar su teorema sobre números primos y progresiones aritméticas (lo cuenta el propio Tao aquí). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/18/abel-prize-awarded-to-furstenberg-and-margulis/#comment-623761")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2021")])]

#text("No blogpost about this year’s Abel Prize. Have you ever work with Lovasz?")
]
