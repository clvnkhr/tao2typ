// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/
// Converted to Typst by tao2typ: "2026-10-14T16:39:15.395883+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "AI for Math fund", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("AI for Math fund")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 December 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/")[#text("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Renaissance Philanthropy and XTX Markets have ")#link("https://renaissancephilanthropy.org/news-and-insights/renaissance-philanthropy-and-xtx-markets-launch-new-9-million-ai-for-math-fund/")[#text("announced the launch")]#text(" of the ")#link("https://renaissancephilanthropy.org/initiatives/ai-for-math-fund/")[#text("AI for Math Fund")]#text(", a new grant program supporting projects that apply AI and machine learning to mathematics, with a focus on automated theorem proving, with an initial $9.2 million in funding. The project funding categories, and examples of projects in such categories, are:")

#strong[#text("1. Production Grade Software Tools")]

#list(
[#text("AI-based autoformalization tools for translating natural-language mathematics into the formalisms of proof assistants")],
[#text("AI-based auto-informalization tools for translating proof-assistant proofs into interpretable natural-language mathematics")],
[#text("AI-based models for suggesting tactics/steps or relevant concepts to the user of a proof assistant, or for generating entire proofs")],
[#text("Infrastructure to connect proof assistants with computer algebra systems, calculus, and PDEs")],
[#text("A large-scale, AI-enhanced distributed collaboration platform for mathematicians")]
)

#strong[#text("2. Datasets")]

#list(
[#text("Datasets of formalized theorems and proofs in a proof assistant")],
[#text("Datasets that would advance AI for theorem proving as applied to program verification and secure code generation")],
[#text("Datasets of (natural-language) mathematical problems, theorems, proofs, exposition, etc.")],
[#text("Benchmarks and training environments associated with datasets and model tasks (autoformalization, premise selection, tactic or proof generation, etc.)")]
)

#strong[#text("3. Field Building")]

#list(
[#text("Textbooks")],
[#text("Courses")],
[#text("Documentation and support for proof assistants, and interfaces/APIs to integrate with AI tools")]
)

#strong[#text("4. Breakthrough Ideas")]

#list(
[#text("Expected difficulty estimation (of sub-problems of a proof)")],
[#text("Novel mathematical implications of proofs formalized type-theoretically")],
[#text("Formalization of proof complexity in proof assistants")]
)

#text("The deadline for ")#link("https://airtable.com/appSh677zJHNiCdW7/pagSeCrgvihcU6dha/form")[#text("initial expressions of interest")]#text(" is Jan 10, 2025.")

#text("[Disclosure: I have agreed to serve on the advisory board for this fund.]")

#text("Update: See also ")#link("https://leanprover.zulipchat.com/#narrow/channel/113488-general/topic/AI.20for.20Math.20fund")[#text("this discussion thread")]#text(" on possible projects that might be supported by this fund.")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2024")])]

#text("I believe we are on the brink of a new era in mathematics, where AI will play a key role. However, I also see challenges, particularly in how these technologies can be effectively and reliably applied. Developing proof assistants that truly understand and apply complex mathematical structures may still require years of intensive research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686853")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2024")])]

#text("looks really promising, thanks Terry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2024")])]

#text("Wow!! Revolution has come!")

#text("Can we use AI and med tech to help accelerate the evolution of species?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686865")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2024")])]

#text("I’m enthusiastic about the use of AI in math. I’ve received censure on anonymous forums like r/mathematics on Reddit for advocating the use of AI to help learn mathematics, but it’s becoming clear given the ever-improving ability of LLMs to solve contest problems, suggest relevant ideas, and recommend resources that AI will be indispensable going forward. Some of the objections I’ve seen to AI remind me of Socrates’s claim that writing would impair thinking by making people less reliant on their memories. Others betray a desire to view humans as the inevitable center of the intellectual universe, reminiscent of those who believed in geocentrism out of egocentrism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686868")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2024")])]

#text("One word, exciting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2024")])]

#text("Two words, very exciting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686874")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2024")])]

#text("Is the use of AI in math, especially in proving theorems, a good direction of human development? Using AI and computers to do tedious, boring, tiring work is justifiable (as long as the benefits are distributed to workers whose jobs are replaced)")#strong[#text(", ")]#text("but why should we use AI to interfere with creative actvities in science, art, music and such? Just because it’s possible, it doesn’t mean it should be done, IMO.")

#text("I hope we take a serious look at the consequences of AI research.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686881")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2024")])]

#text("Dear Prof. Wierdl,")

#text("I second your opinion. Currently, our system of wealth distribution is far from being fair, and those whose jobs are replaced by AIs are not those who benefit mostly from it. Instead, most of the gains are taken away by some extremely rich people.")

#text("If we do not improve our system of wealth distribution, but continue to work on more powerful tools, then, even if it is unclear if AI can ever surpass human ability, the power of these tools will mostly benefit those who already have so much, and help them concentrate wealth and poverty to a more extreme degree.")

#text("On the other hand, I personally am very interested in finding the limitations of AI — For now I don’t believe AI can ever surpass human intelligence, if we believe that humans have free will, free in the sense of being independent and unpredictable, just like a source of randomness. Given this assumption, there’s no reason to believe AI, built on deterministic Turing machines, can suddenly acquire free will out of complexity of architecture and enormity of data. But one obstacle is that a lot of concepts here are so hard to define formally.")

#text("Yours truly, Guanyuming He")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686981")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2024")])]

#text("Dealing with AI is not like other scientific projects where only our curiosity should guide and limit our explorations. AI is already used by the military in such a way that it bypasses humans, and it makes decisions over life and death. For example, there is what they call **drone swarm** which already communicate only with each other and decide whom or what to shoot and when. There is no time for human intervention.")

#text("**“For example, unarmed drones may collect information from the field to inform armed drones on where best to strike. Drones armed with guns, bombs, and missiles would allow the drone swarm to use a combination of weapons to carry out an attack,”**")

#link("https://www.forbes.com/sites/davidhambling/2021/03/01/what-are-drone-swarms-and-why-does-everyone-suddenly-want-one/")[#text("https://www.forbes.com/sites/davidhambling/2021/03/01/what-are-drone-swarms-and-why-does-everyone-suddenly-want-one/")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2024")])]

#text("Out of interest, will there be any requirements for the projects being funded to be powered by renewable sources of energy? The environmental harms of increased use of AI cannot be ignored, and that might be one way to reduce tbe environmental impact of this, especially if you’re specifically encouraging the use of more AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-686886")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2024")])]

#text("The fund is not intended to directly support training or operation of large AI models, which is indeed an extremely energy-intensive task that is largely carried out by the large AI tech companies. Instead, the focus is on supporting infrastructure around how to use these tools (as well as more traditional machine assistance) efficiently and effectively, for instance by writing software tools and platforms to allow for easier collaboration or formalization on mathematics projects, or building high quality data sets that would permit AI tools to become more useful for scientific applications. Personally I envision this infrastructure to be of more enduring value than any specific AI technology that could be placed inside this infrastructure, and if these pilot projects are to be deployed at scale then there would certainly be both financial, computational and environmental incentives to rely as much as possible on more lightweight AI models that are suited for the task at hand, rather than automatically attempt to use the largest and most expensive models available. [Related to this, I would like to see a more diverse spectrum of AI tools available, including many developed by grassroots efforts in the communities in which the technology is being applied, beyond the large general-purpose models produced by the largest AI companies.]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-687003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2025")])]

#text("It would be nice to see the ideas in “")#strong[#text("1. Production Grade Software Tools")]#text("” integrated into a single piece of software similar to a programming IDE. It could be like Visual Studio, but for Lean instead of C++.")

#text("To explore a subject, students could just load the relevant package into their Lean IDE and chat about it with the built-in LLM.")

#text("I look forward to the days ahead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba47469313497327de3de34efa15122c0b7b7351949fd77046cd325c79354966-3499be251a3e5f87ef149fc193557ab0bd43ccb934695cb53c5677db06058e9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of majdoddin")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-687016")[#strong[#text("majdoddin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2025")])]

#text("The Fund’s ")#emph[#text("Challenge")]#text(" is more about formal validation, and not only for theorems but also computer programs. Later its ")#emph[#text("Strategy")]#text(" touches automated theorem proving too.")

#text("And are people from the EU eligible to apply or only US citizens, please?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-687018")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2025")])]

#text("From the fund website: “Open to individuals and teams worldwide”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba47469313497327de3de34efa15122c0b7b7351949fd77046cd325c79354966-3499be251a3e5f87ef149fc193557ab0bd43ccb934695cb53c5677db06058e9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of majdoddin")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-687020")[#strong[#text("majdoddin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2025")])]

#text("Thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-687010")[#strong[#text("Carnevale della Matematica 235 - Ingegneria")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2025")]

#text("[…] due collegamenti a Terenzio Taoquesta volta. Il primo period un annuncio per il fondo AI for Math. Il secondo erano i brevi appunti di Tao quaternioni e trigonometria […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-687024")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2025")])]

#text("Wspaniały krok naprzód w kierunku połączenia matematyki z nowoczesnymi technologiami! Inicjatywa AI for Math Fund pod przewodnictwem Terence’a Tao to doskonała szansa dla projektów, które mogą zrewolucjonizować sposób, w jaki myślimy o dowodzeniu twierdzeń i algorytmach matematycznych. $9.2 miliona na wsparcie innowacyjnych narzędzi, baz danych i przełomowych pomysłów to zdecydowanie inwestycja w przyszłość matematyki! 👏 Z niecierpliwością czekam na wyniki tego funduszu i nowe podejścia, które mogą powstać w wyniku tych działań. Matematyka w erze sztucznej inteligencji? To brzmi jak fascynująca podróż!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-687029")[#strong[#text("Aperiodical News Roundup – November & December 2024 | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2025")]

#text("[…] news, Terry Tao has also announced the creation of Renaissance Philanthropy and XTX Markets’ AI for Math fund, supporting projects that apply AI and machine learning to mathematics, with a focus on automated […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df39a7e82fa0547daacacec84f2e90901368a671738016a89f59b3ee9780cd96-b50ccd47325e53d5c81d2863f7a400cec297ea6a16ada5968bbd18ef979e0b02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ppalme")]], [#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-687077")[#strong[#text("ppalme")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2025")])]

#text("Somehow related: How would you use the new Google Studio AI for real-time streaming to understand a math problem? What questions, and in what sequence, would you ask to understand the math problem as quickly as possible? I was just testing Google Studio AI on the paper ")#emph[#text("FRONTIERMATH: A Benchmark for Evaluating Advanced Mathematical Reasoning in AI")]#text(" using Sample Problem 1: Testing Artin’s Primitive Root Conjecture. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/12/05/ai-for-math-fund/#comment-687143")[#strong[#text("Velryba s pořádnou tlamou – Kechlibar.net")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2025")]

#text("[…] Navíc toto už je v podstatě překonaná technologie, stará skoro dva roky, a novější modely AI jsou spolehlivější. Toto je pole, které se rychle vyvíjí, a za rok nebo za dva bude vypadat úplně jinak. Zdaleka ne všechny AI jsou “kecálky” jako ChatGPT, čím dál častěji mají i “dedukční” (reasoning) režimy použitelné například pro řešení vědeckých problémů. Terence Tao, asi nejslavnější žijící matematik nedůchodového věku, charakterizoval své pokusy s loňskou AI jako komunikaci s “průměrným, ale ne zcela neschopným doktorandem“. (Viz také rozhovor s Taem v The Atlantic.) Právě Tao ale také řekl, že kvalita produktů se výrazně zlepšuje, a vstoupil do projektu, který má AI přizpůsobit pro použití v matematice. […]")
]
