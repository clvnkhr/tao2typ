// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/
// Converted to Typst by tao2typ: "2026-10-14T07:24:52.053359+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "IMO 2009 Q6 as a mini-polymath project", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("IMO 2009 Q6 as a mini-polymath project")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 July 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/")[#text("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("http://en.wikipedia.org/wiki/International_Mathematical_Olympiad")[#text("International Mathematical Olympiad")]#text(" (IMO) consists of a set of six problems, to be solved in two sessions of four and a half hours each. Traditionally, the last problem (Problem 6) is significantly harder than the others. Problem 6 of the ")#link("http://imo-official.org/problems.aspx")[#text("2009 IMO")]#text(", which was given out last Wednesday, reads as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 6.")]#text(" Let ")#mi("a_1, a_2, \\ldots, a_n")#text(" be distinct positive integers and let ")#mi("M")#text(" be a set of ")#mi("n-1")#text(" positive integers not containing ")#mi("s = a_1 +a_2 +\\ldots+a_n")#text(". A grasshopper is to jump along the real axis, starting at the point ")#mi("0")#text(" and making ")#mi("n")#text(" jumps to the right with lengths ")#mi("a_1, a_2, \\ldots , a_n")#text(" in some order. Prove that the order can be chosen in such a way that the grasshopper never lands on any point in ")#mi("M")#text(".")
]

#text("Of the 500-odd participants in the Olympiad, only a half-dozen or so managed to solve this problem completely (I don’t have precise statistics yet). I myself worked it out about seven hours after first hearing about the problem, though I was preoccupied with other things for most of that time period.")

#text("I thought that this problem might make a nice “mini-Polymath” project to be solved collaboratively; it is significantly simpler than an unsolved research problem (in particular, being an IMO problem, it is already known that there is a solution, which uses only elementary methods), and the problem is receptive to the incremental, one-trivial-observation-at-a-time ")#link("http://gowers.wordpress.com/2009/01/27/is-massively-collaborative-mathematics-possible/")[#text("polymath approach")]#text(". So I would like to invite people to try solving the problem collaboratively on this blog, by posting one’s own comments, thoughts, and partial progress on the problem here.")

#text("To keep with the spirit of the polymath approach, I would however like to impose some ground rules:")

#enum(start: 1, 
[#text("Everyone who does not already know the solution, and has not worked on the problem already, is welcome to jump in and participate, regardless of mathematical level.")

#enum(start: 1, 
[#text("However, in order not to spoil the experiment, I would ask that those of you who have already found a solution not to give any hint of the solution here until ")#emph[#text("after")]#text(" the collaborative effort has found its solution. (At that point, everyone is welcome to give out their solutions here.) For instance, I will not be participating in the project except as a moderator.")],
[#text("For similar reasons, I would ask that competitors at the actual 2009 IMO refrain from commenting substantively on the problem on this thread until after the collaborative effort has succeeded. (I know this may require some significant restraint, but I suspect the problem will become too easy if we get comments along the lines of “This was a tough problem! I tried X and Y and Z, and they didn’t work; I tried W also but ran out of time. I hear that someone solved the problem using U, though.” Of course, ")#emph[#text("after")]#text(" the collaborative effort has succeeded, you are more than welcome to share your own experiences with the problem.)")]
)],
[#text("Participants should avoid explicitly searching for solutions to this problem on the internet (I would imagine spoilers would become available in a few days). If you do accidentally find such a solution online, I would ask that you recuse yourself from the rest of the collaboration, until after they have found a solution also. (In particular, posting links to a solution is ")#strong[#text("strongly")]#text(" discouraged until ")#emph[#text("after")]#text(" the collaborative effort has succeeded.)")

#enum(start: 1, 
[#text("In a similar vein, extensive searching of the mathematical literature should only be undertaken if there is a consensus to do so on this thread.")]
)],
[#text("Participants are also discouraged from working too hard on this problem “offline”; if you have a potentially useful observation, one should share it with the other collaborators here, rather than develop it further in private, unless it is “obvious” how to carry the observation further.")

#enum(start: 1, 
[#text("Actually, even “frivolous” observations can (and should) be posted on this thread, if there is even a small chance that some other participant may be able to find it helpful for solving the problem.")],
[#text("Similarly, “failed” attempts at a solution are also worth posting; another participant may be able to salvage the argument, or else the failure can be used as a data point to eliminate some approaches to the problem, and to isolate more promising ones.")]
)],
[#text("Participants should view themselves as contributing to a team effort, rather than competing with each other (in contrast to the actual IMO). The point is not to obtain bragging rights for being the first or quickest to solve the problem (which has, after all, already been solved), but instead to experimentally test the hypothesis that a mathematical problem can be solved by a massive collaboration, without requiring serious effort on behalf of any one of the participants. (See Tim Gowers’ essay “")#link("http://gowers.wordpress.com/2009/01/27/is-massively-collaborative-mathematics-possible/")[#text("is massively collaborative mathematics possible")]#text("?” for more discussion.)")],
[#text("To make it easier to reference comments in this thread, I would ask commenters to number their comments (so that the first comment be labeled 1., the second comment be labeled 2., and so forth.)")],
[#text("Unlike the actual IMO, there is no artificial time limit on this exercise, though if there is insufficient participation, or the collaborative effort grinds to a halt, I may at my discretion close the experiment and give out solutions after a reasonable time period.")]
)

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (184)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jens")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40377")[#strong[#text("jens")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("140. to 139")#linebreak()#text(" oh yes, I see the problem, thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40384")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("141. I’m suspicious that Terry is removing posts which give away too much of the answer/have working proofs. So I’m putting my observations from earlier in individual posts. Terry can allow disallow them as he likes, but I did arrive at them after looking at this conversation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40385")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("141a. Given a set where the Grasshopper can reach the end, you might be able to block the only possible path with a point in M. But the moment you add a another jump all bets are off, as that jump could be applied anywhere in the sequence. I’ll be very impressed if someone can make this work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40386")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("141b. Speyer (2) mentioned a minimal size needed to disconnect. This seems a good approach. What is the minimal size needed to prevent the grasshopper from reaching its target. Clearly at least n will suffice as we could select M={a_1,…a_n}. What happens when we remove one element from M.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40388")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("141c. Final observation. The beginning an ending jumps are constrained. There are n possible first jumps, n possible last jumps, but n^2-n-O(A,2) which measures the number of instances where a_i+a_j=a_k+a_l. I’d avoid the middle and focus on the beginning/end of the sequence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40390")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("141addendum. Apologies to Terry. I guess its just the WordPress spam filter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40391")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("142. I wasn’t clear on 141c comment. There are n possible first landing positions. Then n^2-n-O(A,2) second landing positions, n^3-n^2+n-O(A,3) (I think…). Key point is the O(A,2) which measures the # of overlapping 2 sums in A. For A={1,2,3,4} O(A,2)=1 because 1+4=2+3 so there is one overlap. This function is clearly very complicated and changes every time you change A. If you are trying to analyze what happens in the middle of the path, I think it will cause serious problems for you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0c473d67cde178c94599095e3a8c54e04bd59b868d9c6521df465ab302d3122-c12b256352bd50a2926a14a1d7011017d09092221e86f204cf38a758857e2844.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raghu")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40396")[#strong[#text("Raghu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Here’s one way of making the following approach suggested by Gowers and others work.")

#text("Show by induction that for ")#mi("k <= n")#text(" you can take ")#mi("k")#text(" steps that avoid the mines ")#mi("M")#text(".")

#text("The base cases have been discussed before. Suppose that you can take ")#mi("k-1")#text(" steps ")#mi("a_1,a_2,...,a_{k-1}")#text(" (in that order) without hitting a mine. Let ")#mi("a_k < a_{k+1} < ... < a_n")#text(" be the remaining possible steps and let ")#mi("s = a_1+a_2 + ... + a_{k-1}")#text(". Now a strong observation is that if any of ")#mi("s+a_k, s+ a_{k+1},...,s+a_n")#text(" is not a mine we are done. And if not we 'know' the positions of ")#mi("n-k+1")#text(" mines.")

#text("In particular there are at most ")#mi("k")#text(" mines in the interval ")#mi("[0,s+a_{k+1}]")#text(" and at most ")#mi("k-1")#text(" mines in the right open interval ")#mi("[0,s+a_{k+1})")#text(". Let ")#mi("s^{\\prime} = s+ a_{k+1}")#text(". Then, from the above observations for some ")#mi("1 <= i <= k+1")#text(", ")#mi("s^{\\prime}-a_i")#text(" is not a mine and the interval ")#mi("[0,s^{\\prime}-a_i]")#text(" has at most $k-1$ mines. We can now finish the argument by another level of induction on $k$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jens")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40397")[#strong[#text("jens")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("141. trying to fix proof 129.")#linebreak()#text(" Assume a_1<…<a_n, s=a_1+…+a_n, M the set to be avoided, m=max M.")#linebreak()#text(" The induction step works except if s-a_n=m:")

#text("Suppose s-a_nm, set M’=M\\{m}, A’=A\\{a_n}. By induction hypothesis")#linebreak()#text(" there is a permutation p in S_{n-1} s.t. for all j up to n-1 the sums")#linebreak()#text(" s_k=\\sum_{i\\leq k} a_{p(i)} are not in M’. If also s_k is not in")#linebreak()#text(" M for all k, we are done. Otherwise, there is k with s_k=m. Now we")#linebreak()#text(" replace the step a_{p(k)}=s_k-s_{k-1} by a_n which is larger than")#linebreak()#text(" a_{p(k)}. Done.")

#text("A similar argument “from the left” works if a_nmin M, however it")#linebreak()#text(" well may be the case that s-a_n=max M and a_n=min M.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40400")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("143")

#text("I thought I had posted a potential set of equivalence relations between solutions [involving reduction and expansion operations]. A solution is everything stated in the problem, plus a specific path through the minefield (ie with designated jumping-off points). Different paths are different solutions.")

#text("In case Terry is filtering for too much info – can I suggest as a technique looking for an equivalence on solutions (someone suggested a stronger hypothesis, which put this in mind) – which allows reduction of solutions to simpler solutions.")

#text("Then the question is, can I build a solution for a particular configuration using the reverse of the equivalences? Here a possible technique is to find a good ordering on solutions which allows a minimal counterexample to be identified and proved not to exist.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40401")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Ref 143")

#text("I meant an ordering on configurations, not solutions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b888be0be275de5b3877f2e54e8a21aa0f26ea8eaf6930d9e9785ec9273e89fe-94ad56e80e6f291631307c33b1a9f07dbcd8e93d22127df52e56af95222fbec0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Louigi")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40402")[#strong[#text("Louigi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("159. (Number based on total number of comments to date.) A small observation. Suppose that ")#mi("a_1 < a_2 < \\ldots < a_n")#text(" and that the landmines are at ")#mi("m_1 < m_2 < \\ldots < m_{n-1}")#text(". Choose a sequence of steps that avoids as many land mines as possible, and suppose it lands on some mine ")#mi("m_i")#text(". If the last step (the one that leads the walk to land on ")#mi("m_i")#text(" is ")#mi("a_j")#text(" then the walk must also have used ")#mi("a_{j+1},\\ldots,a_n")#text(". Otherwise, we could replace that last step by a large last step and avoid an additional mine (")#mi("m_i")#text("). I don't know exactly what to do with this. Maybe let ")#mi("a_k")#text(" be the largest unused step and replace one of the used steps with ")#mi("a_k")#text(" to avoid ")#mi("m_i")#text(", or something?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0c473d67cde178c94599095e3a8c54e04bd59b868d9c6521df465ab302d3122-c12b256352bd50a2926a14a1d7011017d09092221e86f204cf38a758857e2844.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of emeritusl")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40403")[#strong[#text("emeritusl")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("144. Sorry if this is a repetition of an earlier comment. My previous comments did not make it and now I’m trying from a wordpress account.")

#text("Here’s one way of making the following approach suggested by Gowers and others work.")

#text("Show by induction that for ")#mi("k <= n")#text(" you can take ")#mi("k")#text(" steps that avoid the mines ")#mi("M")#text(".")

#text("The base cases have been discussed before. Suppose that you can take ")#mi("k-1")#text(" steps ")#mi("a_1,a_2,...,a_{k-1}")#text(" (in that order) without hitting a mine. Let ")#mi("a_k < a_{k+1} < ... < a_n")#text(" be the remaining possible steps and let $latx s = a_1+a_2 + … + a_n$. Now a strong observation is that if any of ")#mi("s+a_k, s+ a_{k+1},...,s+a_n")#text(" is not a mine we are done. So suppose not. In this case we 'know' the positions of ")#mi("n-k+1")#text(" mines.")

#text("In particular there are at most ")#mi("k")#text(" mines in the interval ")#mi("[0,s+a_{k+1}]")#text(" and at most ")#mi("k-1")#text(" mines in the right open interval ")#mi("[0,s+a_{k+1})")#text(". Let ")#mi("s^{\\prime} = s+ a_{k+1}")#text(". Then, from the above observations for some ")#mi("1 <= i <= k+1")#text(", ")#mi("s^{\\prime}-a_i")#text(" is not a mine and the interval ")#mi("[0,s^{\\prime}-a_i]")#text(" has at most k-1 mines. We can now finish the argument by another level of induction on k since k < n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40404")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("144")

#text("Given a solution (see 143) here are some equivalences.")

#text("The points the grasshopper hits are called jumping-off points, the distances between them are the Ai. Zero is a jumping off point. The mines are distributed some way along the number line from 1 to s-1. Spaces are points which are neither mines nor jumping off points. The gap between jumping-off points will be called an interval.")

#text("Equivalence 1 – spaces")

#text("Remove one or more spaces from any interval to reduce its length (provided I keep the Ai all different).")#linebreak()#text(" Add one or more spaces to any interval (eg the longest) provided its final length is not one of the Ai.")

#text("These keep n the same and alter one of the Ai (hence also s).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40405")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("146")

#text("Equivalence 2 – intervals with single mines")

#text("Remove any interval with a single mine, merging its two endpoints into one.")

#text("Take any jumping off point, and replace it by an interval containing a single mine, provided is length is not one of the existing Ai.")

#text("These change n by 1, and introduce or remove a single interval.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40406")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("147")

#text("Equivalence 3 – intervals with more than one mine")

#text("Using no 2, I can make sure no interval contains a single mine if I want to. So all my intervals are empty or contain more than one mine. A simple counting argument says I must have at least one empty interval.")

#text("If I have an interval with more than one mine in it, and an interval containing r spaces, I can remove the empty interval (collapsing the two endpoints to one) and replace one of the mines with a space.")

#text("If I have an interval with a space in it, I can replace the space with a mine and replace any jumping off point with an interval of length r, provided r is not one of the existing Ai.")

#text("These reduce or increase n by 1, with a corresponding reduction or increase in the number of empty intervals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40407")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("148")

#text("The equivalences come in pairs for reducing and expanding")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40408")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("149.")

#text("To David Speyer 139.")

#text("An example of the case you propose is the following:")

#mi("A = \\{1,\\ldots, n\\}")#linebreak()#text(" $M = \\{b+1,\\ldots, b+n-1\\}$")

#text("If we remove ")#mi("n")#text(" from ")#mi("A")#text(" and ")#mi("b+n-1")#text(" from ")#mi("M")#text(", any path we obtain by induction will land exactly on ")#mi("b+n-1")#text(".")

#text("For the case ")#mi("A = \\{1,\\ldots,n\\}")#text(" it seems to me that the fact that there is a residue class modulo ")#mi("n")#text(" without landmines is very helpfull (and handles the above situation nicely).")

#text("This residue class splits ")#mi("{}0,\\ldots, n(n+1)/2")#text(" into a number of intervals. Is it true we should allways use ")#mi("n")#text(" to jump over the interval with the most landmines?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40410")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("150")

#text("In response to 149")

#text("If there are three landmines at positions 1,2, and 4, and the Ai are {1,2,3,4} you need to use the 3 to jump the first two mines – and you can’t use the 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1962409330cbd1beaf3d754204de210f4c67cd1750cdfd2efefde25a2d1d381c-bf504f2573995aaa199a74238dac20ffbc086c927526cf541d43288863f2df99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40411")[#strong[#text("Tony")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("I wonder whether the marriage theorem can be used. Let A(x) be a collection of subsets r of A such that the sum of the elements of r < x. Suppose that the elements of M are ordered m1 < m2 <…< m_(n-1) < s. Then we have A(m1) in A(m2) in A(m3) in … in A(m_(n-1)) in A(s). Can we select a set rk from A(mk) such that r1 in r2 in … in r_(n-1) in rn? Note A(s) contains only A.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40412")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("151 To Pablolessa: what is b?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IMO 2009 Q6 mini-polymath project cont. « What’s new")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40413")[#strong[#text("IMO 2009 Q6 mini-polymath project cont. « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("[…] July, 2009 in math.CO | Tags: mini-polymath1 | by Terence Tao Well, participation in the IMO 2009 Q6 polymath project has exceeded my expectations; it appears that the collaborative effort has scored some partial […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40414")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Note: as this thread is becoming quite full, I am closing it and moving on to a fresh thread:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/")[#text("IMO 2009 Q6 mini-polymath project cont.")]
]

#text("This may cause some temporary discontinuity in the discussions, but I think this will be better in the long run, as it should assist in letting readers catch up with things. I recommend that participants use this transition to try to summarise the state of the project so far.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Vieira consegue um feito histórico: a primeira medalha de prata portuguesa nas Olimpíadas Internacionais de Matemática « problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40462")[#strong[#text("Pedro Vieira consegue um feito histórico: a primeira medalha de prata portuguesa nas Olimpíadas Internacionais de Matemática « problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("[…] o tentassem resolver de forma colaborativa, havendo já mais de centena e meia de comentários, no post respectivo, pelo que decidiu abrir um segundo […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40496")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")]

#text("[…] IMO 2009 Q6 as a mini-polymath project The International Mathematical Olympiad (IMO) consists of a set of six problems, to be solved in two sessions of four […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40720")[#strong[#text("Reading for today « Shores of the Dirac Sea")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2009")]

#text("[…] smart, how about you try solving problem number 6 of the IMO without peeking. I found about it here, but I have not had time to even attempt to solve it. It sounds like […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40774")[#strong[#text("Mini Polymath « OU Math Club")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2009")]

#text("[…] In the meanwhile, Terence Tao is running a mini-polymath project. The problem is the sixth (and hardest) problem from the 2009 International Math Olympiad. The problem is: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-40793")[#strong[#text("A mini-polymath project « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/")[#text("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06849e100bf734f45a9dfcc89e627e06270752e577170400c3c3c79ac803d436-f05557b1f5289465627804446ee4710396b835bff4d71dbafcae2d3135a1b52b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bài toán số 6 trong IMO 2009 « Sharing")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-43690")[#strong[#text("Bài toán số 6 trong IMO 2009 « Sharing")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2010")])]

#text("[…] link 2 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-43913")[#strong[#text("Polymath Reflections « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2010")]

#text("[…] Polymath4 devoted to deterministically finding primes that took place on a special polymathblog, a miniPolymath leading to collectively solving an olympiad problem, and an intensive Polymath5 devoted to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Future mini-polymath project: 2010 IMO Q6? « What’s new")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-45461")[#strong[#text("Future mini-polymath project: 2010 IMO Q6? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2010")])]

#text("[…] rules. The rules for the first mini-polymath project can be found here. Basically the spirit of the rules is that the objective is not to be the first to produce an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-137350")[#strong[#text("inamerrata » Blog Archive » Solving hard Maths Olympiad problems")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2012")]

#text("[…] it’s IMO season, and in honour of such, Terry Tao reposed one of the questions on his blog as a “polymath” project — something to be solved collaboratively over […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-151655")[#strong[#text("Polymath project: social problem-solving | Civil Statistician")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2012")]

#text("[…] around the world use a blog and wiki to work together on one of that year’s IMO problems. His 2009 post is a good introduction to the event and the spirit behind it. Personally, I had a blast trying to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83efd627a7889dfcba231ddae7521f40f39e51dae26cdc2a47960406efe4c828-61e29b00f30d8daa16f51a28048d243f4429312a29fe93d242e8085c1815920f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Counting what’s important | Oliver Nash's Blog")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-4/#comment-454925")[#strong[#text("Counting what’s important | Oliver Nash's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2015")])]

#text("[…] Q6 (expected score 0.17) [Thanks to Terry Tao this problem attracted some attention at the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40261")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("91")]#text(" 96. Yeah, I was trying to put together something along the lines of what Kristal says in 85. Suppose you’re trying to find a good ordering of a_1, … a_n. Choose a j such that (sum a_i) – a_j isn’t in M. By induction you know that you can order the (n-1) integers a_1, … a_{j-1},a_{j+1},…a_n so that the partial sums avoid m_1, …. m_{n-2}. But then you can stick a_j at the end and you’ve jumped all the way to sum a_i which isn’t a landmine by assumption. This is obviously too easy to be correct but in the spirit of the project I’ll just leave it here as a paraphrase of Kristal to see what’s wrong with it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nikhil devanur")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40264")[#strong[#text("nikhil devanur")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("92")]#text(" 97. @")#strike[#text("91")]#text(" 96, this is wrong since m_{n-1} could be smaller than (sum a_i) – a_j")#linebreak()#text(" in which case you still have n-1 obstacles, but with only n-1 steps to get over them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40265")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("93")]#text(" 98 oh yeah gotcha.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("94")]#text(" 99. Here’s a slightly different set up for an induction argument. Assume the result holds for |A|=n. We’ll then try to prove it for |A|=n+2. Since the cases n=1 and n=2 are trivial, this is sufficient. Clearly we can assume that every element of M is greater than a_1 and less than a_n. So remove the first and last element and switch the roles of A and M. By the induction hypothesis we can solve this problem. So is there any kind of duality between A and M?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40267")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("94")]#text(" 100. from 86 by anonymous:")

#text("Kristal– You’re idea sounds good, but I don’t completely follow it. When you remove an element of A in the inductive step, what do you take for your set M? It needs to have less element, right?")

#text("My new set M is all the elements that don’t contain the removed element. If there are n+1 then as noted we can take the sets containing the remaining element and easily construct the desired set of sums.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40268")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("95")]#text(" 101. In answer to 87 the solution is to start with 11 then add any other element to it then any other until all elements are used none are in M as all of M’s elements are less than 11 so we easily get a solution")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nikhil devanur")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40269")[#strong[#text("nikhil devanur")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("102. Another take on the divide and conquer approach similar to gowers’ @43:")#linebreak()#text(" It is enough to find k jumps that takes us past k obstacles. Then we just induct on the remaining n-k jumps and n-k-1 obstacles. But there may not exist such k jumps, it could be that you always need atleast k+1 jumps to cross k obstacles all the way to the end. If this happens, then one can perhaps argue that if you start from the end and proceed backwards, then one can find such k jumps, that cross k obstacles and you are then done by induction. (Note that assuming the result to be true, there must always exist such k jumps in either of the 2 directions.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4749da301efe883f73a9e58a545ba47075b7237e28d45101358ac27f7d0a73a-ec9b6bff19c49054ef37ab6bffb2b7b6b224738868f5f4b29213f290b28a6c29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deepak Ramachandran")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40272")[#strong[#text("Deepak Ramachandran")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("96")]#text(" 103.")

#text("Here’s a wrong proof.")#linebreak()#text(" proof by induction:")

#text("w.l.o.g. assume ")#mi("a_1 ... a_n")#text(" and ")#mi("m_1 ... m_{n-1}")#text(" is ordered. By the inductive hypothesis for ")#mi("a_1 ... a_{n-1}")#text(" and ")#mi("m_1 ... m_{n-2}")#text(", there must exist some ordering, ")#mi("a_{\\pi(1)} ... a_{\\pi(n-1)}")#text(", s.t. the partial sums ")#mi("c_1 ... c_{n-1}")#text(" do not contain any of the ")#mi("m_i (i  m_{n-1} > m_t")#text(" ( for all t).")#linebreak()#text(" For, ")#mi("l  j, c^{\\prime}_l > c^{\\prime}_j > m_t")#text(" (for all t).")

#text("QED ???")

#text("The reason this is wrong that to actually use the induction hypothesis, we need to assume that ")#mi("a_1+ \\ldots + a_{n-1}")#text(" is not in M, which of course might not be true. Can we repair this proof though? Maybe splitting into a case analysis involving the condition?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40273")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("97")]#text(" 104. from 94 My new set M is all the elements that don’t contain the removed element.")

#text("This is wrong. My new M would be all set that match sums of the n subset of the n+1 set if n of them matched then I would a problem because I would not free up the remaining elements of that are sums containing the excluded element because some of the sums with the excluded element might match some of the sums without it. This will have to be fixed somehow if the idea from 85 can be made to work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nikhil devanur")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40275")[#strong[#text("nikhil devanur")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("105. Do the same inductive step as proposed by 91, remove m_{n-1} and some a_j such that (sum a_i) – a_j isn’t in M. But now try to find k jumps from the beginning that jump over k obstacles. if you don’t find any such k, then consider the last jump, that is (n-1)st. this jump must start before m_{n-2}, since otherwise we would have had n-2 jumps that cross n-2 obstacles.")#linebreak()#text(" now note that this could not have landed at m_{n-1}, since it has to be equal to (sum a_i) – a_j. So appending a_j to this sequence avoids m_{n-1} also and we are done.")

#text("Am I making any mistake here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40277")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("98")]#text(" 106. Here is an approach which is a bit different from the others. Let s = a_1 + … + a_n, with a_1 < a_2 < … < a_n and let M = { m_1 < m_2 < … < m_{n-1} }. Consider the n intervals (0, m_1), (m_1, m_2), …, (m_{n-1}, s). Since there are n of them, and the grasshopper only lands in (0,s) n-1 times, one of them must be missed (of course, more than one might be missed). Let's try to start our induction by working out which of these is to be missed. This is similar to Tim Gowers' idea above to about skipping over 2, but the extra option of skipping at the end gives us a little more freedom. For notational simplicity, set m_0=0 and m_n = s.")

#text("My first thought was that we have n intervals whose lengths add up to s, so there must be one of them whose length is less than the average of the a_i. I hoped that this was the one that should be skipped. But that isn't always true. Take A = (9, 10, 11, 30) and M = (11, 30, 49).")

#text("Still, we don't need that in order to win. All we need is to have")

#text("m_{k-1} < a_{i_1} + … a_{i_k} < m_k < m_{k+1} < a_{i_1} + … a_{i_k} +a_{i_{k+1}} < m_{k+2}.")

#text("In a few examples, it does seem that we can always achieve this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40278")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("107. Here’s a follow up to my argument above that there is a path of length 2, this time showing there is a path of length 3. Unfortunately, there seems to be a small proliferation of cases, which may mean that a proper inductive extension of this argument would either be a bit complicated, or require a better argument.")

#text("Split the a_i into b_1,b_2 so that b_1,b_1+b_2 is a path, b_1+b_2 is maximal among second terms of paths of length 2, and b_1 is maximal among initial elements of paths of length 2 with second terms of length b_1+b_2. Let c_1<c_2<…<c_{n-2} be the remaining elements.")

#text("Now suppose that b_1+b_2+c_i is in M for each i. Then this accounts for all but one element of M. Consider b_1+c_1; first, suppose b_1+c_1 is not in M. Then c_1<b_2; if also b_1+c_1+c_2 not in M, we are done. So suppose b_1+c_1+c_2 is in M. If b_2<b_1 then c_1+c_2+b_2 is also not in M, and we are done. If b_1<b_2 then b_2 is in M, which means b_2=b_1+c_1+c_2. Then c_1+b_2 cannot be in M, so c_1<b_1, and therefore again c_1+c_2+b_2<b_1+c_j+b_2 for any j other than 1 or 2, and c_1+c_2+b_2 cannot be b_1+c_j+b_2 for j either 1 or 2.")

#text("So we deal with the remaining case, where b_1+c_1 does belong to M. Then c_1 does not belong to M, and neither does c_1+b_2, so c_1<b_1. Then c_1+b_2+c_2<b_1+b_2+c_j for any j, so if c_1+b_2+c_2 is in M then it must be that b_1=b_2+c_2. Then c_2 and c_2+b_1 are in M, so c_2<b_2, so also c_2+b_1+c_1 are not in M, so this is a path of length 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f58a6fe8e80900cd217f5495a3218d9acd85e5cd977db9fa87967870ef862781-e2c6836262ee65f748346f68b007381932b682cc851bc4e1d0fc0658dba16387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ramanujantao")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40279")[#strong[#text("ramanujantao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("108. Also, is there only one order in which the grasshopper never lands on any points in ")#mi("M")#text("? What is ")#mi("M")#text(" contains ")#mi("s = a_1 + a_2 + \\cdots + a_n")#text("? Would we still be able to fins an order in which the grasshopper never lands on any points in ")#mi("M")#text("? Maybe we can use probabilities and random walks? E.g. the probability of going ")#mi("a_1")#text(" units in step ")#mi("1")#text(" is ")#mi("P_{11}")#text(", etc…. Or maybe use some type of inequality involving the mean?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SW")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40282")[#strong[#text("SW")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("101")]#text(" 109. Meta comment first – it would help immensely to have threaded comments. This is getting very hard to read!")

#text("Re Gowers’s 44, 63, etc: Is it clear that we would want to save ")#mi("a_n")#text(" to be the “jump over two landmines” choice? Can anyone think of an example where one is required to use ")#mi("a_n")#text(" to jump only one (or zero) mines?")

#text("It’s possible to prove that *either* there are two mines within ")#mi("a_n - 2")#text(" of each other or else something easy happens. For instance, if ")#mi("a_n")#text(" is not in ")#mi("M")#text(" then we are done by the induction mentioned earlier; similarly ")#mi("s-a_n")#text(" should be in ")#mi("M")#text(".")

#text("Thus either (a) those are the smallest and largest elements of ")#mi("M")#text(", in which case we have ")#mi("n-1")#text(" elements of $M$ in ")#mi("[a_n, s-a_n]")#text(", which is an interval of ")#mi("s-2a_n <= a_n + a_{n-1} + (n-2)(a_n-2) - 2a_n < (n-2)(a_n-2)")#text(",")#linebreak()#text(" or (b) we have elements of ")#mi("M")#text(" less than ")#mi("a_n")#text(" (or on the other side)… but that already is within ")#mi("a_n -2")#text(" of ")#mi("a_n")#text(" unless it is exactly 1, in which case the induction argument works again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40284")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("100")]#text(" 110. I thought I posted this a bit ago, but I don’t see it. Let ")#mi("a_1 < a_2 < \\ldots < a_n")#text(" and let ")#mi("m_1 < m_2 < \\ldots < m_{n-1}")#text(".")

#text("If we can find ")#mi("i_1")#text(", ")#mi("i_2")#text(", …, ")#mi("i_{k+1}")#text(" distinct indices such that")

#mi("m_{k-1} < a_{i_1} + \\ldots + a_{i_k} < m_k < m_{k+1} <")#linebreak()#text(" ")#mi("<  a_{i_1} + \\ldots + a_{i_k} + a_{i_{k+1}} < m_{k+2}")

#text("then we win. This combines two observations above: the one about skipping over two landmines is the case where ")#mi("1 \\leq k \\leq n-2")#text(". The possibility of starting out or ending by jumping over a land mine are the degenerate cases ")#mi("k=0")#text(" or ")#mi("k=n-1")#text(".")

#text("So, it seems like it would be good to figure out what k should be. Notice that there are n intervals ")#mi("(0, m_1)")#text(", ")#mi("(m_1, m_2)")#text(", …, ")#mi("(m_{n-1}, a_1+\\ldots+a_n)")#text(". So the shortest of them is shorter than ")#mi("a_n")#text(". I had hoped that the shortest would always be ")#mi("(m_{k}, m_{k+1})")#text(", but this doesn't seem to be true: consider ")#mi("A=(9,10,11,30)")#text(" and ")#mi("M = (11,30,49)")#text(".")

#text("Still, it does always seem to be true that we can find ")#mi("(m_{k-1}, m_k)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40285")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("103")]#text(" 111. My longer comments aren’t appearing, so I’ll keep this one short:")

#text("Take A = (9, 10, 11, 30) and M = (9, 30, 51). Then we use the long jump to only jump over one mine. Of course, this is one of the cases where we know how to reduce — when we can start by jumping over a single mine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac8e75166fde9bdaee7083d78155718816f28e51e48fa9c90ea5fef780fc1f9f-4baf1a1853760b5b53514bb3e4377613e724e36f52a583401667fa859915049d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40287")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("112. Let me try to summarize nikhil 5:09. (105)")

#text("Lemma (Post 48): Let ")#mi("0< k < n")#text(". If there is ever a sequence of ")#mi("k")#text(" jumps that cross ")#mi("k")#text(" mines then we are done.")#linebreak()#text(" Proof: If this is the case then the subset of ")#mi("A")#text(" of elements we haven't used has size ")#mi("n-k")#text(" and the number of mines left is ")#mi("n-k-1")#text(", and so the lemma follows by induction.")

#text("Proof of Main Result:")#linebreak()#text(" We see that there is a ")#mi("1 \\leq j \\leq n")#text(" such that ")#mi("\\sum_{i=1}^{n} a_i - a_j \\notin M")#text(". We set ")#mi("A^{\\prime} = A -\\{a_{j}\\}")#text(", and ")#mi("M^{\\prime} = M -\\{m_{n-1} \\}")#text(" (where ")#mi("m_{n-1}")#text(" is the largest element of ")#mi("M")#text("). By induction, there is a sequence of partial sums of ")#mi("A^{\\prime}")#text(" that avoid ")#mi("M")#text(". Let ")#mi("\\{b_i\\}_{i=1}^{n-1}")#text(" be the elements of ")#mi("A^{\\prime}")#text(" in the order we form the partial sums. This is to say ")#mi("\\sum_{i=1}^{l} b_i \\notin M^{\\prime}")#text(" for every ")#mi("0<l<n")#text(".")

#text("Now how many elements of ")#mi("M^{\\prime}")#text(" are less than ")#mi("\\sum_{i=1}^{n-2} b_i")#text("? By the lemma we can assume that it is at most ")#mi("n-3")#text(". Thus the element ")#mi("m_{n-1}")#text(" (which we removed from ")#mi("M")#text(" to create ")#mi("M^{\\prime}")#text(") is larger than every partial sum ")#mi("\\sum_{i=1}^{l} b_i")#text(" for ")#mi("0<l<n-2")#text(". So the only problem we could have by adding it back in would be if it was equal to ")#mi("\\sum_{i=1}^{n-1} b_i")#text(". However, by construction we know that this is not an element of ")#mi("M")#text(".")

#text("Lastly, we add ")#mi("a_j")#text(" back in. However, ")#mi("\\sum_{i=1}^{n-1} b_i +a_j = \\sum_{k=1}^{n} a_k")#text(", which isn't in ")#mi("M")#text(" be assumption.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40288")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("113. It looks to me like nikhil devanur 5:09 works. Can anyone find a problem with it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40289")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("114 I’ll agree that Nikhil’s 5:09 post (as kindly spelled out by someone anonymous) looks pretty good.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40290")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("115 What happens if ")#mi("m_{n-1} = \\sum_{k=1}^{n-2} b_k")#text("? It seems to me that the lemma does not apply in this case because the last jump (to ")#mi("m_{n-1}")#text(") lands on a mine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40291")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("116. Re: 115. That does look like a problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40292")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("117 I’m very late to the party as usual. It seems to me that this problem could be tractable by proof by contradiction, and I just had a quick thought. Assume that there is a set ")#mi("M")#text(" for which the statement of this problem fails. There are ")#mi("n!")#text(" possible sequences of partial sums based on the set ")#mi("A = {a_{1}, ... , a_{n}}")#text(". Then at least one member of ")#mi("M")#text(" is always obtained by some partial sum in every sequence of partial sums of ")#mi("A")#text(". If ")#mi("m")#text(" members of ")#mi("M")#text(" lie in the interval ")#mi("(0, s)")#text(", then at least one of those ")#mi("m")#text(" members of ")#mi("M")#text(" is obtained by partial sums in at least ")#mi("n!/m")#text(" different partial sum sequences. I’m guessing that this might be unreasonable since, in general, ")#mi("n!/m \\gg n")#text(", and members of ")#mi("A")#text(" are mutually distinct, but right off hand I don’t know why, and it’s time for bed …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("118 So one approach to the problem pointed out in 115 would be to then back up to the sum ")#mi("\\sum_{j=1}^{n-3} b_j")#text(". By considerations in 112 all of the partial sums up to this point should avoid ")#mi("M")#text(". There are three elements left ")#mi("b_{n-2}, b_{n-1}")#text(" and ")#mi("a_j")#text(". We may assume that ")#mi("\\sum_{j=1}^{n-3} b_j  + b_{n-2} \\in M")#text(".")

#text("Moreover, we could then try to add on one of the other remaining elements instead. Thus there must be collisions with ")#mi("M")#text(" regardless of how you add these 3 remaining elements. This should imply that there are several mines between ")#mi("\\sum_{j=1}^{n-3} b_j")#text(" and ")#mi("\\sum_{j=1}^{n} a_j")#text(" (the finish line).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40294")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("119 Come to think of it, it should be clear that 112 can’t be quite right, because it always chooses a_j as the final step. But we have examples where that isn’t right (a_j was arbitrary so that sum_{i!=j}a_i was not in M), so we know that the correct solution will have to account for the fact that there may be multiple a_j which satisfy that condition, some of which may not be part of a solving path.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52bdeb0786c46b76601fd4cc2a591061fad34871ab96e3aee2412d58360178ee-d83a8a7c8b055d734d8d2f07b8454a5c92a1be72445b355ccc01126305fbb31b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mirror2image")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40295")[#strong[#text("mirror2image")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("120. Would it helpful to consider reduced case? Suppose M is periodic with period K m_i = i*K Take j_max as maximum j such as partial sum of j elements is zero mod K. So any other partial sum including S_j_max is non zero mod K. if j_max < n we have our solution taking S_j_max as tail. If j_max = n we throw away element a_l such a_l mod K != 0 (always exist) and repeat. Is that correct ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard E.")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40296")[#strong[#text("Richard E.")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("121. Following up on David’s comment (#2), there’s a theorem which I believe is due to Noga Alon that says you need at least n-hyperplanes to cover all the vertices except {1,1, … , 1} of the unit hypercube {0,1}^n by hyperplanes not passing through {1,1, … , 1}. The proof is based on linear algebra (combinatorial nullstellensatz). This is probably overkill for an IMO problem and not clear how it would be directly be useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40297")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("122. In the case with ")#mi("n-1")#text(" consecutive landmines discussed by Greg Martin in 51.")

#text("Suppose the landmines ")#mi("b+1,\\ldots, b+n-1")#text(" are all reachable by the grasshopper (i.e. they are all partial sums of the sequence ")#mi("a_1,\\ldots,a_n")#text("). Does anybody have a simple argument to show that ")#mi("b")#text(" is a partial sum?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8a3013f4429139a123a3bec6970d804cd2804710e3ca5db26b43e1fa703bd46-36c5da777bb851e4b79cc21d9381f2ed464040c237c5a6e2e64fa4782c4175d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aj")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40299")[#strong[#text("aj")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("123. @pabloless,122: b need not be a partial sum in that case. Take A={2,3,4,6}, then b=1 isn’t a partial sum, despite 2=b+1..b+n-1=4 all being partial sums. b+n isn’t a partial sum either in this case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40315")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("124. You’re right, aj.")

#text("I’ve worked out the case ")#mi("A = \\{1,2,3,4,5\\}")#text(".")

#text("Since we there are only ")#mi("4")#text(" landmines, there is a residue class modulo ")#mi("5")#text(" that contains no landmines.")

#text("Suppose ")#mi("\\{5,10\\}")#text(" contains no obstacles. We can assume that all obstacles are between ")#mi("6")#text(" and ")#mi("9")#text(" because otherwise we pass an obstacle in one jump (starting at ")#mi("{}0")#text(", or a backwards jump starting at ")#mi("15")#text(").")

#text("If it’s another residue class, it splits $1,\\ldots,15$ into four intervals.")

#text("If there is a landmine in the first interval we jump it over in a single step and proceed by induction. Symmetricaly we solve the problem if there is a landmine in the last interval.")

#text("In the remaining case a center interval contains ")#mi("2")#text(" landmines or more. In this case we can jump over that interval in two steps (again, either two forward steps starting at zero, or two backward steps starting at 15), remaining on the “safe” residue class each time. This solves the problem, by the induction argument stated several times before (for example the lemma in 112).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("Here’s another induction idea.")

#text("We start with ")#mi("n-1")#text(" ")#mi("a_i")#text("‘s and ")#mi("n-2")#text(" ")#mi("m_i")#text("‘s and assume we can solve this case. Let ")#mi("c_l = \\sum_{j=1}^{l} a_i")#text(" (for ")#mi("0<l<n-1")#text(") be a sequence of partial sums that solves the problem for this case. Now we are given ")#mi("m_{n-1}")#text(" and ")#mi("a_n")#text(". We consider the new 'path' given by the partial sums ")#mi("d_l = \\sum_{j=1}^{l} a_i")#text(" (for ")#mi("0<l<n")#text("). We only have trouble if ")#mi("m_{n-1} = c_r")#text(" for some ")#mi("r < n")#text(". Now by the lemma in 112, we may assume that the number of mines less than ")#mi("c_{r-1}")#text(" is at most ")#mi("r-2")#text(". Also we may assume that the number of mines greater than ")#mi("c_{r+1}")#text(" is at most ")#mi("n-r-2")#text(". Thus we have at least ")#mi("(n-2 -r-1-n+r+2 )+1 = 3")#text(" mines between ")#mi("c_{r-1}")#text(" and ")#mi("c_{r+1}")#text(", provided i did the arithmetic correctly.")

#text("That turns out less helpful than I had expected.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40324")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("125.")#linebreak()#text(" Re: 72 David Speyer:")

#text("“Here’s a visual plot of the data for n=20. It looks like it’s flat between (1/4)*(sum_{i=1}^n i) and (3/4)*(sum_{i=1}^n i), and then very erratic outside there. I have no idea why that should be — any ideas?”")

#text("I don’t think there is anything special about 1/4 and 3/4: If you zoom in this interval would be smaller and if you zoom out it would be larger. I think 1/4 and 3/4 tells us more about Mathematica’s plot-function than about the problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40327")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("125. Nikhil’s approach @105 and its elaboration @115 and @118 work fine. I summarize them in a concise way.")

#text("Induct on ")#mi("n")#text(". For ")#mi("n=2")#text(" see post 4@Lugo and ")#mi("n=3")#text(" see post 18@gowers. Assume it holds for ")#mi("n-1")#text(". Let ")#mi("M")#text(" be as in the statement. Set ")#mi("m:=\\max M")#text(" and ")#mi("S:=a_1+\\cdots a_k")#text(". WLOG assume that ")#mi("m<S")#text(". Also, at least one of the numbers ")#mi("S-a_i")#text(" is NOT contained in $M$, since ")#mi("{\\rm card}(M)a_1+\\cdots+a_{n-1}")#text(" we are done, so assume this isn’t the case. Let ")#mi("k")#text(" be the index so that ")#mi("a_1+\\cdots+a_{\\sigma(k)}<\\max M^\\prime<a_1+ cdots+a_{\\sigma(k+1)}")#text(". If ")#mi("k=n-2")#text(" we are done again by our assumption that ")#mi("a_1+\\cdots+a_{n-1}\\notin M")#text(". So assume that $k2$ steps to avoid the two points ")#mi("m^\\prime,m")#text(". This is certainly possible by the case ")#mi("n=3")#text(".")

#text("P.S. We do not need to know the case ")#mi("n=3")#text(" in order for the proof to work, but it simplifies the last step.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard E.")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40328")[#strong[#text("Richard E.")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("126. An induction proof might work if we can find a stronger statement to induct on (researcher’s paradox). Since there’s a natural symmetry going from 0 to s and jumping backwards from s to 0, it would be interesting to investigate if it is possible to find a sequence of jumps avoiding all the points of M and (s – M).")

#text("This is one way to deal with the two strong restrictions coming from the first and last jumps simultaneously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("127. Re:125, Partalopoulo, would you mind elaborating on your argument a bit? I’m having trouble following it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40342")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("127 Here is an general thought.")

#text("Assume that A1 … An are 1,2 … n. I can take a block of n spaces, and put my n-1 mines in those. This forces a jump to the remaining space. I then have to divide up the Ai so that I can jump to that place and from it to the ends. This I can do because the small numbers give me flexibility, and I’ve used all the mines, so there are no more constraints. As I put more holes in my block, the constraints are reduced and there are more ways to hop through.")

#text("And a trivial observation – I can assume that hcf of the Ai is 1.")

#text("Is there an induction on s, or on s and n together, or involving A1?")

#text("If A1 = 1, for example, this interval contains no mines. In fact one of the intervals must contain no mines (pigeonhole).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40343")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("128, Can we come up with a hyper optimistic conjecture to the affect that the worse case sequence is 1,2,3,…,n?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40345")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("129. Reply to 127. I’m sorry, for some reason part of the text didn’t appear.")

#text("Induct on . For ")#mi("n=2")#text(" see post 4@Lugo and for ")#mi("n=3")#text(" see post 18@gowers. Assume it holds for ")#mi("n-1")#text(". Let ")#mi("M")#text(" and ")#mi("A=\\{a_1,\\dots,a_n\\}")#text(" be as in the statement. Set $S=a_1+\\cdots+a_n$ and ")#mi("m=\\max M")#text(" . WLOG assume that ")#mi("m<S")#text(". We have that at least one of the numbers ")#mi("S-a_i")#text(" is NOT contained in ")#mi("M")#text(", since ")#mi("card(M)<n")#text(". WLOG assume that ")#mi("S-a_n\\notin M")#text(".")

#text("Set ")#mi("M^\\prime=M\\setminus\\{m\\}")#text(" and ")#mi("A^\\prime=A\\setminus\\{a_n\\}")#text(". Apply the induction hypothesis on ")#mi("A^\\prime")#text(" and ")#mi("M^\\prime")#text(". So there exists some permutation ")#mi("\\sigma\\in S_{n-1}")#text(" so that the numbers ")#mi("S_j:=a_{\\sigma(1)}+\\cdots+a_{\\sigma(j)}")#text(" do not belong to $\\latex M^\\prime$.")

#text("If ")#mi("a_1+\\cdots a_{n-1}<\\max M^\\prime")#text(" we are done (choose ")#mi("a_n")#text(" as the last step), so assume this is not the case. So there exists some ")#mi("k\\in\\{1,\\dots,n-1\\}")#text(" so that ")#mi("S_k<\\max M^\\prime<S_{k+1}")#text(". If ")#mi("k+1=n-1")#text(", then ")#mi("m\\neq S_{n-1}")#text(" by our assumption, so we are done again. So we may assume that $k+12$ more jumps in order to avoid ")#mi("m")#text(" and ")#mi("M^\\prime")#text(" (possibly changing the order of ")#mi("a_{\\sigma(k+1)},\\dots, a_{\\sigma(n-1)}")#text(" and ")#mi("a_n")#text("). This is certainly possible by the case ")#mi("n=3")#text(" and completes the proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40347")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("I like remark 2(1) (but did not get much further down) and certainly seperating the vertices of the discrete cube (by hyperplanes) look relevant (and perhaps familiar). A simple set that disconnects the distcrete cube is all vertices of fixed weight so a special case of our problem is that for a set of size n the number of sums of k elements is at least n (0<k<n).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40354")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("130. Latex corrections to post 129:")

#text("“Formula does not parse”: … the numbers ")#mi("a_{\\sigma(1)}+\\cdots+a_{\\sigma(j)}")#text("….")

#text("Second half of last paragraph: So we may assume that ")#mi("k+12")#text(" jumps are chosen in order to avoid the points ")#mi("m")#text(" and ")#mi("m^\\prime")#text(" (possibly rearranging ")#mi("a_{\\sigma(k+1)},\\dots,a_{\\sigma(n-1)}")#text(" and ")#mi("a_n")#text(". This is certainly possible by the case ")#mi("n=3")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40358")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("131")#linebreak()#text(" partalopoulo")

#text("I don’t see how (sorry I can’t do latex, will have to learn) A1+ …+An-1 can be less than max(M’) – it seems to me that either your interval is then too long, or the number of mines too small for the induction to go through – ie what is your s’?")

#text("Or have i misunderstood something?")

#text("Mark")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40359")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("133. I’m in a weird position here. If the solution proposed earlier is correct, then I don’t want to read it, as I’d be amused to go off and try to work it out for myself. Looking at the comments, I can’t quite tell whether it is basically fine, or whether there is a problem with it. In the latter case I’d be interested to read it and think about whether it is possible to fix the problem. Can anyone give me advice about this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40360")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("132: Mark, you are right about your comment. I didn’t claim that this always holds though. It’s just that the whole text does not appear for some reason!")

#text("Define S_j=a_{\\sigma(1)}+…+a_{\\sigma(j)}.")

#text("If a_1+…+a_{n-1}<max M', then we are done. If not, then let k in {1,…,n-1} so that S_k<max M'<S_{k+1}. If k+1=n-1, then m is not equal to S_{k+1}=a_1+….+a_{n-1} by our assumption. So assume that k+12 jumps by possibly rearranging a_{\\sigma(k+1)},….,a_{\\sigma(n-1)} and a_n in order for the grasshopper to avoid m and m’. This is possible by the case n=3 and completes the inductive step.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40361")[#strong[#text("Mathematics, Science, and Blogs « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")]

#text("[…] 2009): A polymath3dedicated to the Hirsch conjecture is proposed over this blog. (July 21): A mini polymath is taking place on Terry Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40362")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("135. To Mark@131. You are right about your comment. I didn’t claim this. It’s just that the whole text won’t appear!")

#text("To gowers@133. I think the solution is correct, but as it is posted it is certainly incomplete.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jens")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40363")[#strong[#text("jens")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("136. to partalopoulo@129")#linebreak()#text(" I agree with 131. For example, let n=4, A={1,2,3,4}, M={4,5,6}, hence s=10, m=6.")#linebreak()#text(" We may choose a_n=1, then A’={2,3,4}, M’={4,5}, but by induction hypothesis the steps s_k might be s_1=2, s_2=6, s_3=9, but s_2 is in M.")#linebreak()#text(" Or am I missing some point of the proof?")#linebreak()#text(" Another thing: The proof ends with “k+12 more jumps”, what is meant here really?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jens")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40370")[#strong[#text("jens")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("137. follow-up to 136")#linebreak()#text(" Sorry, I was apparently too quick with that post. I think I understand now the proof, and it seems correct!")#linebreak()#text(" In the last part of the proof you have n-k numbers $a_{\\sigma(k+1)}$, …, $a_{\\sigma(n-1)}$, $a_n$, and you have to avoid only one trap, namely $m$. And that is possible by the case $n=3$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40371")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("138 What happens if ")#mi("S_{n-3} < M_{n-3}")#text(" and ")#mi("S_{n-2} = M_{n-1}")#text("? (So the second to last leap is a big one.) Then we have to avoid 3 mines with only 3 jumps.")

#text("I don't want to be too pessimistic though, I actually think we are very close. Let me gather my thoughts and see what I can come up with.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40372")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("139 To Tim Gowers: I think the proof may be fixable, but I don’t think it is right.")

#text("To those who think the proof works, what happens if S_{n-3} < M_{n-3} and S_{n-2} = M_{n-1}. Then we have to avoid 3 mines with 3 jumps.")

#text("To Terry: Could you please check your spam queue? Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0c473d67cde178c94599095e3a8c54e04bd59b868d9c6521df465ab302d3122-c12b256352bd50a2926a14a1d7011017d09092221e86f204cf38a758857e2844.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raghu")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40374")[#strong[#text("Raghu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("141. My last comment did not appear – may be it got marked as spam. I’m reposting it.")

#text("In reply to Gil’s unnumbered comment following comment 129, here’s a proof by induction of :’for a set of size n the number of sums of k elements is at least n (0<k<n)'. Let the the n numbers be ")#mi("a_1 < a_2 < \\ldots < a_{n-1} < a_n")#text(". As induction hypothesis suppose that for n-1 distinct sets of k-1 elements each ")#mi("S_1, S_2 \\ldots, S_{n-1} \\subseteq \\{1,\\ldots,n-1\\}")#text(" the sums ")#mi("a_{S_i} = \\sum_{j \\in S_i} a_j")#text(" are distinct. Consider the n sums ")#mi("a_1 + \\ldots + a_k, a_{S_1} + a_n, a_{S_2} + a_n, \\ldots, a_{S_{n-1}} + a_n")#text(". These are easily seen to be distinct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-3/#comment-40376")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("140 I have tried at least twenty times to leave a comment and still can’t see them, though it always tell me that I duplicated the same comment.I guess the same situation happens to David,too.")

#text("Let ")#mi("a_1<a_2<\\cdots<a_n")#text(".")

#text("1,")#mi("a_1")#text("can't be blocked, otherwise we can choose our first step to left a landmine behind, finish the inductive step.")

#text("2, Two sets ")#mi("A=\\{a_2,\\cdots,a_n\\}")#text(" and ")#mi("B=a_1+a_2,\\cdots,a_1+a_n")#text(" contains at least n different values. we claim that the elements in B should not be all blocked. otherwise we can choose the first step with ")#mi("a_i")#text(" and then ")#mi("a_i+a_n")#text(" leaving all landmines behind.")

#text("3,so, we can at least get to the second group withour being killed. then we claim that ")#mi("a_1+a_2")#text(" and ")#mi("a_1+a_3")#text(" can't be all blocked. otherwise we can take two steps and leave two landmines behind and finish the inductive step.")

#text("4, through ")#mi("a_1+a_2")#text(" or ")#mi("a_1+a_3")#text(", we can get to")#linebreak()#text(" ")#mi("a_1+a_2+a_3,a_1+a_2+a_4,a_1+a_2+a_n")#text(",")#linebreak()#text(" ")#mi("\\cdots,a_1+a_3+a_4,\\cdots,a_1+a_3+a_n")#text(" which contains at least n-1 different values. Similarly, if all of these are blocked, then we can construct a way to avoid all of the landmines. So, we can get to one of these by the third step.")

#text("5, then we analyze ")#mi("a_1+a_2+a_3,a_1+a_2+a_4,and a_1+a_3+a_4")#text(" in the similar fasion and continue in the road.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40199")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("49. Sort of a meta-comment. It seems to me there are (at least) two really different flavors of approach to this problem.")

#text("ALGORITHMIC APPROACH: where you try to make some kind of inductive argument, a la aj’s 46 above, where the end result would be a procedure that constructed the desired hop-sequence. You can imagine assigning some kind of “barrier to completion” quantity to each state of the grasshopper, and making an argument that that quantity can be decreased at each step.")

#text("COUNTING APPROACH: trying to show that there are fewer forbidden hop-sequences than there are sequences, a la Tim’s 27. This would give a solution to the IMO problem without providing any easy way to construct a sequence avoiding the forbidden integers.")

#text("If the second approach turns out to be successful, it might be an interesting “beyond the IMO” problem to figure out whether there is, in fact, a reasonably fast deterministic algorithm for finding a good sequence! (I can imagine that choosing random sequences might be pretty fast in practice, if indeed the number of forbidden sequences is small.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdo")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40200")[#strong[#text("Abdo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("50. Maybe the graph approach started by David Speyer and followed by Mohammad is not entirely dead. Let G be the quotient graph of the n-cube by the equivalence relation that identifies vertices with the same partial sum. Then (by Menger’s theorem) it is enough to find n vertex independent paths from 0^n to 1^n in G (not in the n-cube !).")

#text("This has the advantage getting rid of the M, as Mohammad said.")

#text("Moreover, the quotient is not arbitrary. For example, the fact that all ")#mi("a_i")#text(" are distinct and positive says that no two different edges in the quotient will share the same source and target, and there will be no loops.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad3f3a79ef213c98c05db1ab441cb92661583507ac1a7a5e31f4beaa785f1e3b-bd0c7862157994459c7704585bcfde3a1c363765d691789fd896ca4a5396e667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Martin")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40202")[#strong[#text("Greg Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("51. Musing on #27 (@gowers): one possible forbidden set is a set of n-1 consecutive integers {b+1, …, b+n-1}. In this case we must arrange to land exactly on b, then use a_n = n to jump over the landmines. Of course this specific task is easy to accomplish; but to me it points out that purely local methods of selecting the next step length are unlikely to work (how do I know, just looking at the safe territory around me at the start, that I must eventually arrive at b with the n-step still available?).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8a3013f4429139a123a3bec6970d804cd2804710e3ca5db26b43e1fa703bd46-36c5da777bb851e4b79cc21d9381f2ed464040c237c5a6e2e64fa4782c4175d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aj")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40203")[#strong[#text("aj")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("52. What are the steps the grasshopper can land on? Obviously, any value that’s of the form ")#mi("\\sum_{i=1}^{n} s_i*a_i")#text(" where ")#mi("s_i \\in {0,1}")#text(". Equally obviously there are no more than ")#mi("2^n")#text(" such values, and we can assign a label to each value using the binary digits ")#mi("s_i")#text(", though some values may have more than one such label.")

#text("Any value in M that is not a possible step the grasshopper can take isn’t interesting; we can reduce the problem to an (n-1) instance by finding a step that can be taken (since there’s n distinct first steps, n-1 forbidden this is possible), and looking at the remaining (n-1) possible steps and (n-2) forbidden steps.")

#text("Iterating on that, we can thus reduce the problem to n’ and M’ where the grasshopper can reach every point in M’, and we can thus label every point in M’ according to the corresponding ")#mi("s_i")#text(" digits (noting some points might have multiple labels).")

#text("An example of a point having multiple labels might be if ")#mi("a_1 = a_2 + a_3")#text(", in which case, a single point will have labels (1,0,0,…) and (0,1,1,…). A slightly more complicated example might be to also have ")#mi("a_4 = a_5 + a_6")#text(" in which case labels 100100, 100011, 011100, and 011011 would all be shared by a single point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40208")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("53. In response to 48 (JSE) and 50 (Greg Martin), a similar point to Greg’s is that using random methods to find a solution algorithmically doesn’t seem as though it will work, since sometimes the move is forced.")

#text("Going back to the approach of trying to find ")#mi("k")#text(" such that you can get past ")#mi("k-1")#text(" landmines with ")#mi("k")#text(" steps (without worrying about whether you land on one except at the final point), and then jump over at least two landmines, and then finish by induction, one obvious necessary condition for this approach to have a chance is that if ")#mi("a_n")#text(" is the biggest step size, then there should somewhere be two landmines that have a distance of at most ")#mi("a_n-2")#text(". Is there an easy argument if this doesn’t happen? I think there probably is.")

#text("Another small thought. Suppose that ")#mi("a_1\\ne 1")#text(". Then we can subtract 1 from every step size, and get some new step sizes ")#mi("b_i-1")#text(". And the ")#mi("k")#text("th partial sum of the ")#mi("b_i")#text(" is the ")#mi("k")#text("th partial sum of the ")#mi("a_i")#text(", minus ")#mi("k")#text(". Hmm … I thought I was going to be able to say something useful there, but it doesn’t seem to be getting anywhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd49510747ed6643ccb1104b73a5c148b27fc0cca8249526bbf6109e6ef5b3a1-8d14aee73aacb6daa3d50009e8d3dcaedf2d03e87ae6953f3f999bf579d23556.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of uss")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40209")[#strong[#text("uss")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("53a. does anybody see the role of the assumption that a_i are integers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40210")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("54 If the gap between every pair of land mines is greater than a_{n}-2, then")

#text("a_1+a_2+…+a_n >= (n-1) (a_{n}-1)")

#text("That ought to be inconsistent with the idea that a_n is the largest of the a_i. (Although the boundary behavior isn’t quite working out for me.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40211")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("55 The problem should become easier if the a_i aren’t integers. It looks like the only thing that matters about the a_i is which equalities of the form \\sum a_{i_r} = \\sum a_{j_s} hold. If some such system of inequalities has a solution in the real numbers, it will have a solution in the integers as well. (It has a solution in the rationals by basic linear algebra; rescale to remove denominators.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e651e5db50e504b981728bda9edd094608ea66f7126e55caf6d3d340b5e5bba-b6abd184a4fa00c2cb62b6566c9adc69fde9e73e561b060a2e770e5048e13148.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KK")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40212")[#strong[#text("KK")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("56. A somewhat offtopic question: Is this a P problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57fdcac65659c283ce97e98515001264d85e95e018a7eaa81af3cbbca7f43d1d-66981614b3f42f47fccedc8296e4bbf8717816503ff0f0852b0d0cf870b5ac27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elianto84")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40213")[#strong[#text("elianto84")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("57. I’m asking myself:")#linebreak()#text(" 1) what happens bringing the first jump to the last position? (i.e. by considering a cyclic permutation of the jumps) Are there any invariant jump endpoints?")#linebreak()#text(" 2) is there a way to work with congruences modulus (n-1) and the pigeonhole principle?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alex")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40214")[#strong[#text("alex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("58. In this comment I try to restate the problem using the term ‘hitting set’.")

#text("For a given ‘a’ sequence, there are N! possible paths. For each path i, define x_i as the set of the N-1 relevant partial sums of the path. Define X as the set of all of these N! x_i sets. Now we know that the set {a} of size N (the set of elements in the sequence ‘a’) is a hitting set of X. Prove that this is a minimum hitting set.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8a3013f4429139a123a3bec6970d804cd2804710e3ca5db26b43e1fa703bd46-36c5da777bb851e4b79cc21d9381f2ed464040c237c5a6e2e64fa4782c4175d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aj")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40215")[#strong[#text("aj")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("62")]#text(" 59. If you look at each ")#mi("m_i \\in M")#text(", and the label(s) assigned to it, you might find one that only has the value 0 in one particular position, say ")#mi("x")#text("; in that case, if you can take a step of size $a_x$ you’ve reduced your problem. (For example, if A={2,3,5,7} then ")#mi("m_i=7")#text(" has labels 1010 and 0001, which is always 0 in the second position — ie as soon as you’ve taken a step of size 3, you can’t hit the landmine at 7).")

#text("Similarly, if you find an ")#mi("m_i")#text(" that only has the value 1 at a particular position in all its labels, and can defer that step to last, you’re safe. (Same example, ")#mi("m_i=12")#text(" has labels 0011 and 1101, which have a 1 in the last position — so if you can do steps 2, 3 and 5 in whatever order saving 7 to last, you’ll not hit 12, and finding a way to avoid ")#mi("M-\\{m_i\\}")#text(" mines with ")#mi("n-1")#text(" steps is an easier instance of the problem — as long as ")#mi("2+3+5 \\notin M")#text(")")

#text("It seems like there might be some way to say that amongst all the initial steps you can make (ie, all the ")#mi("a_i \\notin M")#text(") one of the members of M will match the above.")

#text("Maybe some notation would help: if A is your set of possible steps, then say S(A) is the set of all possible positions you can end up on the way. So eg, if A={2,3,5}, S(A)={0,2,3,5,7,8,10}. Then the above is saying that for some ")#mi("a_i \\in A")#text(" where ")#mi("a_i \\notin M")#text(", there is an ")#mi("m_j \\in M")#text(" where ")#mi("m_j \\notin S(A-\\{a_i\\})")#text(" — in which case you can reduce the problem to ")#mi("A^{\\prime}=A-\\{a_i\\}")#text(", and m’ in M’ iff ")#mi("m^{\\prime}+a_i \\in M-\\{m_j\\}")#text(", and since ")#mi("S(A^{\\prime}) \\notin M^{\\prime}")#text(" we have an instance of the n-1 case.")

#text("That seems like it might be amenable to a proof by contradiction: suppose for every a_i either a_i is in M, or every element of M has a label where the ith bit is set. Then something bad happens, right? Ending up with two different points sharing a label would work, or having more than 2^n labels, maybe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40216")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("54")]#text(" 60. Another small case. Let’s take ")#mi("a_i=i")#text(" for ")#mi("i=1,2,3,4")#text(". So we’re trying to get to 10 in steps of 1,2,3,4 and there are three landmines.")

#text("If there’s a landmine on any of 1,2,3,4, then by 47 (@liuxiaochuan) they must be on 4, or 4 and 3, or 4 and 3 and 2. In the third case we can go to 1 and then to 5, and then we’re done by induction (two steps and zero obstacles, so perhaps induction was a bit of a sledgehammer). If there are obstacles on 4 and 3, then induction is more appropriate — we can either get to 5 in two steps and are then done, or there’s an obstacle at 5, in which case we can go 2,6,7,10. If there’s just an obstacle at 4, things get harder, since then we need to know what goes on after 4. But then we can cheat and say that at least one number between 6 and 9 is an obstacle so we can run things in reverse. The only case not covered is then when the obstacles are at 4,5,6.")

#text("That was still a rather ugly case-by-case argument, but it serves to confirm a sense that the difficult case is when the obstacles are not near the end points.")

#text("I’d like to try to find an argument along the following lines. Order the step sizes as ")#mi("a_1<\\dots<a_n")#text(". Now let's try two paths. The first is where you take the steps in increasing order of size, and the second is where you take it in decreasing order. Now look at where you are half way through this process. Suppose that in the first case you have passed well under half the obstacles and in the second case you've passed well over half. Then it should be possible to move from one extreme to the other and find a permutation where you've passed more or less exactly half. (Actually, of course, the hypothesis here doesn't have to hold, but this is just meant to give the flavour of some kind of argument.) And then there might be a hope of … hmm … I'm still trying to find that elusive jump over two obstacles that takes place at exactly the right time.")

#text("Subquestion. If ")#mi("a_i=i")#text(" and you have ")#mi("n-1")#text(" consecutive obstacles, what's the neatest proof that you must be able to get to the last non-obstacle without using ")#mi("a_n")#text("? (I don't think it's hard to prove it, but it would be good to have something that had a hope of generalizing.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40217")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("63. Re 54. Your analysis shows that it ")#emph[#text("is")]#text(" possible for the gaps all to be at least ")#mi("a_n-1")#text(". Just let all the ")#mi("a_n")#text(" be very large and roughly equal to ")#mi("a")#text(". Then the sum is approximately equal to ")#mi("na")#text(", so if we start near 0 and end near ")#mi("na")#text(", then we can get gaps of size about ")#mi("na/(n-1)")#text(", which is bigger than ")#mi("a_n")#text(". So my proposal runs into difficulty. Not sure how big a difficulty it is though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40218")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("64. Another thought, which could possibly be worth pursuing. Suppose you have ")#mi("n")#text(" obstacles. Then of course it is possible to stop the grasshopper. But perhaps it is sufficiently difficult to stop the grasshopper that it is possible to say quite a lot about the step sizes and the positions of the obstacles. If so, then it might just be possible to do an induction by finding a partial sum of ")#mi("k")#text(" steps that doesn’t land on an obstacle and passes exactly ")#mi("k-1")#text(" obstacles. (The idea would be that if you can’t get past the remaining ")#mi("n-k")#text(" obstacles in the remaining ")#mi("n-k")#text(" steps, then something pretty strong happens and you can use a different argument.) This is a very preliminary attempt to find a stronger inductive hypothesis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6683f2932fac6f48d3f03e8db7a56b76d90d3d4a8574f81b202cf274bbd9fcc-6647493f76c34c01880416ac091af2f1cd2fdfe6db50859778ef29ab15d58967.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vinayakpathak")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40219")[#strong[#text("vinayakpathak")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("65. It might be useful to see whether the solution is unique or not. This can be done by answering the following question – given a sequence of hops that avoids all landmines, can we construct another?")

#text("Also, we can try using Gowers’ approach of skipping k-1 landmines in k hops on the specific case where a_i = i. Since this case looks like a difficult one, it might give new insight.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alex")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40221")[#strong[#text("alex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("68. Re 65: Is it ever true that multiple paths avoid all landmines? Yes, because technically I think none of the landmines even need to be less than sum(a_1, …, a_N). Is it always true that multiple paths avoid all landmines? No; consider a = {1, 2}, M = {1}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40222")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("68")]#text(" 69. Following again on Tim’s 27: loosely speaking, it seems that for a landmine m to kill off a lot of paths effectively, you want m to be equal to a lot of _short_ sums of a_i’s. An equality between m and a sum of about half the a_i’s (or for that matter any proportion greater than 0) is going to kill off only on order of c^{-n} n! paths, right? So you’d need exponentially many of these identities to impede the grasshopper substantially. And surely having this many identities is a serious condition on the a_i?")

#text("I suppose what I’m groping for is some way to claim that “if all the paths are blocked, then some, or many mines must be sums of FEW a_i’s (or “cofew” sums of all but a few a_i’s).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40223")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("68")]#text(" 69a. What’s the largest fraction of all paths that any single point can belong to? Here’s some data in the case where ")#mi("n=5")#text(" and ")#mi("a_i=i")#text(". The total number of paths is ")#mi("120")#text(". This is how many paths each point from 1 to 14 is in. (I may make mistakes here.)")

#text("1 24 (equals 4!)")#linebreak()#text(" 2 24")#linebreak()#text(" 3 2×3!+4!=36")#linebreak()#text(" 4 2×3!+4!=36")#linebreak()#text(" 5 4×3!+4!=42")#linebreak()#text(" 6 6×2!+4×3!=36")#linebreak()#text(" 7 6×2!+4×3!=36")

#text("and by symmetry the rest are 36,36,42,36,36,24,24.")

#text("This proves that it is possible for a single point to knock out more than ")#mi("(n-1)!")#text(" of the paths, which isn’t all that surprising of course, but it suggests that counting arguments would be difficult as they’d have to demonstrate that the sets of paths knocked out had to overlap substantially.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40224")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("70. Ah, so it does seem in this case (where the a_i are in arithmetic progression) that the landmines of “medium size” are capable of killing a substantial fraction of the paths. It would be great if someone ran this computation for a somewhat larger n, where (I think) the sums of size about n^2/4 would be more strongly dominated by sums of length about n/2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40225")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("71: Easy enough to do. Here’s the numbers for n=10:")

#text("{362880, 362880, 443520, 443520, 524160, 554400, 635040, 665280, \\")#linebreak()#text(" 776160, 823680, 571680, 568800, 616320, 600480, 662400, 633600, \\")#linebreak()#text(" 665280, 650880, 666720, 619200, 635040, 637920, 633600, 649440, \\")#linebreak()#text(" 648000, 632160, 646560, 646560, 632160, 648000, 649440, 633600, \\")#linebreak()#text(" 637920, 635040, 619200, 666720, 650880, 665280, 633600, 662400, \\")#linebreak()#text(" 600480, 616320, 568800, 571680, 823680, 776160, 665280, 635040, \\")#linebreak()#text(" 554400, 524160, 443520, 443520, 362880, 362880}")

#text("By the way, Tim Gowers’ numbers above have a typo: 42 should be 48. ")#emph[#text("[Fixed, T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40226")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("72 Here’s a ")#link("http://www-math.mit.edu/~speyer/Walks.png")[#text("visual plot")]#text(" of the data for n=20. It looks like it’s flat between (1/4)*(sum_{i=1}^n i) and (3/4)*(sum_{i=1}^n i), and then very erratic outside there. I have no idea why that should be — any ideas?")

#text("By the way, I suspect that this kind of analysis is not the most efficient route to solving an Olympiad problem. But I’m not doing Olympiads anymore, so I don’t mind having fun.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e651e5db50e504b981728bda9edd094608ea66f7126e55caf6d3d340b5e5bba-b6abd184a4fa00c2cb62b6566c9adc69fde9e73e561b060a2e770e5048e13148.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KK")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40227")[#strong[#text("KK")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("71")]#text(" 72a. In the same line of thought of previous comments for the case a_i=i maybe one can calculate the i which maximize the numbers of paths killed (expressed in function of n of course) , is this possible, easy to do? This could be used in a rough estimate calculation on the maximum number of paths killed by (n-1) landmines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40228")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("73 Here’s ")#link("http://www-math.mit.edu/~speyer/Walks2.png")[#text("n=40")]#text(". I’ve changed to displaying the data as fraction of walks blocked, rather than absolute number of walks blocked. Looks like about it’s constant at 2/n for i between (1/4)*(sum_{i=1}^n i) and (3/4)*(sum_{i=1}^n i).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40230")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("73")]#text(" 74. I may be overlapping with something that has already been suggested (and perhaps ruled out), but what about trying to prove, by induction on the length of the path, that some path of a given length exists (concluding that there is a path of length n). For instance, it is clear that there is a path of length 1, since at most n-1 of points a_n can be blocked off.")

#text("It is possible for there to be paths of length 1 which have no extension to a path of length 2 (say, a_1 isn’t in M, but a_1+a_i belongs to M for each i>1). But we can construct a path of length 2 as follows: let a_j be largest element such that a_j is not in M. Suppose there is no extension of a_j to a path of length 2 (i.e., a_i+a_j is in M for each i other than j). Consider two cases; if there is some n<a_j in M, we can consider the n-1 remaining jumps and at most n-2 points remaining in M, resolving the problem inductively. Otherwise, there is no n<a_j in M; now, let a_1 be the smallest element other than a_j. Since it cannot be that a_1=a_j+a_k for any k, it follows that a_i is not in M (all the elements of M are accounted for as being of the form a_j+a_k). Let a_2 be the smallest element which is neither a_1 nor a_j; then a_1+a_2 can't have the form a_j+a_k for any k: it can't be either a_j+a_1 or a_j+a_2, and since a_1<a_j, a_1+a_2<a_j+a_k when a_k is anything else. So (a_1,a_1+a_2) is a path of length 2.")

#text("But this arguments suggests extending to paths of length 3 might be tricky.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e651e5db50e504b981728bda9edd094608ea66f7126e55caf6d3d340b5e5bba-b6abd184a4fa00c2cb62b6566c9adc69fde9e73e561b060a2e770e5048e13148.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KK")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40231")[#strong[#text("KK")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("75. By the way it seems than the position X=n is the place which maximize the number of paths killed in the case we are studying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93dcd51e0a4ece3b6722a686d783691c80da853b2af87ae0536766118c6cfcc1-e70b46576a6fa5feccd2f80233e87256385af4c99390e72f8919ffcced489f67.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Ramsden")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40232")[#strong[#text("John Ramsden")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("75. Maybe it’s slightly useful also to mention any superficially plausible looking approaches that might turn out *not* to be helpful.")

#text("For example, when seeing a sum like s my first instinct is to telescope it by expressing the terms as differences, b1 – b2, b2 – b3, etc.")

#text("But the fact that any permutation of the a_i may be involved means that cancellation will be patchy, which is discouraging. However, any landing point will be the difference of two sums each involving at most ~ n/2 terms, and typically far fewer, which might be exploitable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40233")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("74")]#text(" 76. My data makes me very pessimistic about a counting approach. It looks like we can create a situation where almost any landmine knocks about (2/n)*n! paths. If we could make these knock outs miss each other, we’d have enough to kill every path twice.")

#text("That doesn’t mean that I believe the problem to be false. If the knockouts are independent, I expect n!*(1-2/n)^n paths to survive, which is roughly n!/e^2. But this does suggest to me that we would have to do a somewhat sophisticated analysis of independence to make the argument work, which seems hard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40234")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("74")]#text(" 76a. So you can imagine, e.g., trying to show that this is “as bad as it gets” and getting an argument in this direction that you can always avoid ~n/2 landmines (or is this obvious for some other reason?)")

#text("This also suggests that if you choose a random set of n landmines (let’s say in the “stable range” between (1/4)sum and (3/4)sum) the proportion of acceptable walks is actually converging to something less than 1.")

#text("Presumably there’s some straightforward argument for 2/n; you could imagine making a similar argument for a k-tuple of landmines, all in the “stable range”, showing that the proportion of walks containing _both_ landmines coverges to some simple f(n,k) which doesn’t depend on the location of the mines. Then you could imagine estimating the PIE (but of course this would depend on estimates which allowed k to be large enough, relative to n, to make the unestimated terms nicely bounded above.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40235")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("77 Hmm, I confirm KK’s observation. For all values of n between 5 and 30, the maximum occurs at n. (And at the symmetrically located \\binom{n}{2}.) KK, do you have an intuition for why?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40236")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("75")]#text(" 77. (I tried to post a somewhat longer piece, but I’m not sure if it’s being held up or just didn’t go through. ")#emph[#text("[The former – T.]")]#text(") What about holding the a_i and M fixed, and proving by induction that a path of length k exists for each k<=n? That is, first show (trivially) that some a_i is not in M. Then show that there is an a_i and an a_j so that neither a_i nor a_i+a_j belongs to M, and so on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40237")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("75")]#text(" 78. I agree. I feel pessimistic about counting arguments, so my thoughts are mainly focused on trying to find a clever induction.")

#text("But it might be quite interesting to see whether we can prove that ")#mi("n/2")#text(" or so obstacles are not enough, by arguing that not enough obstacles can block substantially more than a fraction ")#mi("2/n")#text(" of all possible paths.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca116084471cf4cfe891c1e62a2641c04658f6bdc15b508384b665576a566745-6b81ac9a31e72c42c95cc6a8c1abfbe5da141e0c999c1c22d952da7c5e991814.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristina")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40238")[#strong[#text("Cristina")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("76")]#text(" 78.")

#text("What if we consider the partial sums as follows:")#linebreak()#text(" A1={a1, a2, …, an} (the initial set)")#linebreak()#text(" A2={a1+a2, a1+a3, a1+a4, …, a1+an, a2+a3, ..,a2+an, …, an-1+an}")#linebreak()#text(" A3={a1+a2+a3, a1+a2+a4, …}")#linebreak()#text(" …")#linebreak()#text(" An={a1+a2+…+an}")

#text("The path of the grasshopper can be realised by picking for each step i an element from Ai which contains the element chosen at the previous step.")#linebreak()#text(" Ex. If we choose a1 at step 1, we’ll have to choose an a1+x from A2 for step 2, etc.")

#text("Then we have:")#linebreak()#text(" A1-M= set of elements eligible for step 1")#linebreak()#text(" A2-M= set of elements eligible for step 2")#linebreak()#text(" …")#linebreak()#text(" An-M= set of elements eligible for step n")

#text("Also, we are sure that An-M is non-empty from the hypothesis (as is A1-M).")#linebreak()#text(" Starting from these, we only need to prove, perhaps using some set elements, that all Ai-M are non empty.")

#text("Maybe too trivial, but it’s very late here (classical excuse :-) ) and the point of view might help someone nevertheless.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40239")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("77")]#text(" 79. Following up on the suggestion Cristina and I made. Since there are only n-1 points in M, there must be some a_i not in M. Now we wish to find a path of length 2; let a_L be the largest a_i not in M, and suppose it cannot be extended to a path of length 2. Then a_1 (assuming a_1 is the smallest a_i other than a_L) cannot be in M: if it were, it would have to be a_L+a_j for some j, which is impossible since a_1<=a_j. So a_1<a_L. Now let a_P be either a_2 (if L!=2) or a_3 (if L=2); then a_1+a_2")#text("P, and a_1+a_2 can’t be equal to either a_1+a_P or a_2+a_P. Therefore a_1+a_2 is not in M, so a_1,a_1+a_2 is a path.")

#text("Can this sort of reasoning extend to give a path of length 3?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40240")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("78")]#text(" 80. I don’t understand. What if (a_1, a_2, a_3) = (1,2,3) and M = (4,5). Then the largest a_i not in M is 3, but the path 0 –> 3 cannot be extended.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11f410d2385e1e40affa3713778fc8658732df03c09c9aeddbdb4f37ee99d711-17bb680652e8e4d8d511c8cd23ee731021ea6b53a6688483dcdf5ac638f8b802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arul")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40241")[#strong[#text("Arul")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("77")]#text(" 81. How about proof by contradiction?")#linebreak()#text(" Let for every n and every path, there is one point (partial sum of a_i’s, say a_1+a_2…+a_k) that intersects with a value in M. Then, can we break this down to two sub-problems of size k and n-k, and use the contradiction argument recursively?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sarah")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40242")[#strong[#text("Sarah")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("86")]#text(" 82.")

#text("I agree with Cristina(76) that this sort of approach might be useful. I had a somewhat algorithmic twist on it; consider the following algorithm that picks points arbitrarily, and at each step checks to see if sum = a_i + a_j + a_k … is in M. If the grasshopper at any point finds itself unable to hop forward, it simply hops backwards to its previous point (which, because we are working iteratively is assumed to be safe). Of course it might find itself backtracking the whole path, but since we’re not actually trying to construct an efficient algorithm this is fine.")

#text("Then the question becomes: is there always a path/sum pair that will satisfy our while loop condition? This is trivial for the first step (since there must be at least one a_i that is not covered by a landmine), but for the second step we could imagine that for a fixed a_i the landmines cover all possible n-1 next steps. In this case, however, we backtrack, fix another a_j, and then can proceed completely (well, almost completely, since we can’t discount the case where a_j + a_k = a_i for some k) safely to the finish.")

#text("So I guess I also agree with many of the other commenters that looking at the partial sums must be at least somewhat useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40243")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("77")]#text(" 83.")

#text("I haven’t had a chance to digest all of this yet, but qualitatively, ignoring counting arguments, and focussing on a potential induction:")

#text("If grasshopper can jump from either end over one or more “landmines” I have an induction.")

#text("If not, I have a concentration of landmines in the middle.")

#text("It should then be possible to find an interval in the middle of length Am which contains a ‘large enough’ number of landmines that I can use an inductive hypothesis on each end. I “just” need that interval to allow a partition of the Am which works for each end.")

#text("Now I can either try to find that interval in the middle containing lots of landmines directly, or I can try to progress as far as possible from either end, in which case I am aiming to increase the central density so that I can include lots of landmines in a single leap.")

#text("Question: does in matter that Am>=m (all m) except to jump (n-1) landmines at once? The induction above requires it, but is there a deeper way of using this fact?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40244")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("(")#strike[#text("80")]#text(" 84) In Re Tim Gower’s comment at 63: First, thank for pointing out my error. Second, that case shouldn’t be too hard, as the k-term sums for different values of k should largely fall in distinct intervals.")

#text("For example, ")#link("http://www-math.mit.edu/~speyer/Walks3.png")[#text("here")]#text(" is the case where n=20, and the a_i are 101, 102, 103, …, 120. Notice that, we tend to be getting significantly fewer than 1/n knockouts. It might be nice to prove that 1,2,…,n really does optimize the proportion of k element subsets which is knocked out — and compute the shape of that curve!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40245")[#strong[#text("mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("81")]#text(" 85. Consider just the sequence of points on the line, without encoding their distance:")#linebreak()#text(" write “j” if you have a jump, “m” if there is a point of M, and “x” if there is both a jump and a point of M (situation which we want to avoid), and forget about the other points for the moment.")

#text("Suppose we start from a grasshopper trajectory, represented by a string of j, m, and x. We want to permute the jump lengths in order to cancel as many “x” as possible, since our aim is a string of just “j” and “m”. We can suppose that our string starts well, i.e. not with a “x” (I’m not sure this helps).")

#text("Sometimes it is useful to exchange two successive jumps in order to diminish the number of “x”, i.e. to make changes like:")#linebreak()#text(" [ jxj ]–>[ jmjj ] or [ jjmj ]")#linebreak()#text(" [ jxx ]–>[ jmjx ] or [ jjmx ]")#linebreak()#text(" [ xxx ]–>[ xmjx ] or [ xjmx ]")#linebreak()#text(" This corresponds to the original problem in case n=2.")

#text("Still we can’t deal with sequences of the form [ jmx ] or [xmj ]. We know however from 18 (the case n=3) that strings with 4 jumps and only 2 points of M (besides perhaps the extrema), like [ jxxj ], [ xxxj ] or [ jxmjx ], can also be solved, i.e. transformed in strings that outside the extrema have only “j” and “m” (call “zero” on the first jump point, and call “a”,”b”, “c” the jump sizes to see the isomorphism with case n=3).")

#text("In this way, having solved the problem in in case n=N-1 and less, one has many manipulations of the “x-j-m” string for free. Is it true?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11f410d2385e1e40affa3713778fc8658732df03c09c9aeddbdb4f37ee99d711-17bb680652e8e4d8d511c8cd23ee731021ea6b53a6688483dcdf5ac638f8b802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arul")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40247")[#strong[#text("Arul")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("78")]#text(" 86. Clarifying/following up on my earlier comment(76):")#linebreak()#text(" Hypothesis: Lets assume that for every n and every path (i.e. partial sums), there is atleast one point (say, k’th partial sum) which is equal to a value in M (say M_k, where the values in M are sorted in ascending order).")#linebreak()#text(" Now consider the set of k partial sums, where the last partial sum is M_k due to the assumption above. Now, if we consider the k-1 a_i’s (say, {b_1, b_2,…, b_k}) and {M_1, M_2, …, M_k-1}, this is exactly the same problem as above, but of size k-1. The size of the problem always decreases by atleast 1, so we should be able to disprove the hypothesis if we can show it for a problem of size 1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/441fda2323a8a25f72dba1eca93d0d2ab7007e1da5561ce1610adaf0aea05f84-66d89e932870e2b814c75ce81d75e047b30161cd0b4eab5f4c70b52d59bad083.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gbaloglou")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40248")[#strong[#text("gbaloglou")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("87. It surprises me that no one has mentioned the word “tree”! For the numbers {3, 5, 7, 10} I provide a ")#link("http://www.oswego.edu/~baloglou/gr-q6-tree.html")[#text("tree")]#text(" of trunk 3+5+7+10 with its branches ordered in a special as well as obvious manner that should allow the grasshopper to move backwards … and someone here ‘formalize’ my example into a solution, I hope!")

#text("[There are n distinct 1-branches against n-1 undesirable choices, so the first step backwards is possible; now how many wrong 2-branches can be given the said ordering, etc etc.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66b5a70f158c54a8b46baa5c91ae135f7d5c821b96ead8c00e15e16fc655d5e9-1ddf15c83d0cc546885bc195e3389010cc3918e093f12cf0c2d2f9cfa4494fc5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40249")[#strong[#text("Scott")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("88. There seems to be an important symmetry in this problem. It doesn’t matter whether you start on 0 and travel to s via a sequence of partial sums or whether you start on s and travel backwards by subtracting sequences of partial sums. For this reason I think it might be beneficial to associate 2 values to each a_i (both a_i and s – a_i).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sarah")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40253")[#strong[#text("Sarah")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("84")]#text(" 89. I actually do think there might be value in looking at both a_i and at s – a_i. Consider ordering both the a_i’s and the landmines (call them m_1, …, ")#mi("m_{n-1}")#text(") in increasing order. If ")#mi("s - a_n")#text(" is in M but is *not* the largest mine ")#mi("m_{n-1}")#text(", then we know there are at most n-3 mines between 0 and ")#mi("s - a_n - a_i")#text(" for some element a_i. Using an inductive hypothesis, we could argue that we must therefore be able to reach s – a_i or s – a_n – a_i successfully.")

#text("Otherwise, we could look at the case where both the largest element and the largest landmine are not used. In this case, we again use an inductive hypothesis (sort of). If we don’t reach ")#mi("m_{n-1}")#text(" in these n-1 hops, we add back on a_n and we are done. If we do reach it, say on the i-th hop, then we can try to use a_n instead for that hop (so in essence swap the a_j used for the i-th hop with the last hop in the full n-hop sequence).")

#text("Does any of that make sense?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40254")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("85")]#text(" 90.")

#text("Let me redo my previous post and make some changes:")#linebreak()#text(" If you have proved this for n you should be able to get if for n+1. Take each n subset of the n+1 set and use the result for n then you will get a set of sums that can only be blocked at the nth sum since the n+1 sum is already blocked by hypothesis the nth sum must be removed.")#linebreak()#text(" Here the we may have n+1 blocking elements and the above is not true")#linebreak()#text(" However this can be fixed because if we have n+1 elements blocking the n set and its sums then then we have no elements left to block the one remaining element and we can easily get the desired sums by taking that element and the sums contianing it now we can continue as before and we must remove the n set.")

#text("However it must be removed for every n subset of the n+1 elements then but that means we must remove every n sum. However since every n sum can be represented by subtracting an element from the sum of all n+1 elements and each of the n+1 elements are different then the n sums must be n+1 different elements and we must bloc all of them with M but M has only n elements so we are done with the induction. The theorem is true for 1 trivially and we ought to be able to use that for the base of the induction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("86")]#text(" 91. Kristal– You’re idea sounds good, but I don’t completely follow it. When you remove an element of A in the inductive step, what do you take for your set M? It needs to have less element, right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of k")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40257")[#strong[#text("k")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("85")]#text(" 92")

#text("this idea seems too simple. but i want to give it a try. i can see what is wrong with this. may be some of you can.")

#text("the worst places to put the mines are at the partial sums. i will look at the")#linebreak()#text(" case n = 4. we put the origin at the top of a tree and next level we put")#linebreak()#text(" 4 partial sums a1 to a4. next level you put the six partial sums a1+a2,…")#linebreak()#text(" now you block the vertices where the mines are. there is at most three")#linebreak()#text(" of them. but the total number of paths is (4c1)(4c2)(4c1). if i use the fact")#linebreak()#text(" (4ck) > 3 for any k = 1, 2, 3 you still end up with more than one path from")#linebreak()#text(" the top to s = a1+a2 + a3 + a4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f58a6fe8e80900cd217f5495a3218d9acd85e5cd977db9fa87967870ef862781-e2c6836262ee65f748346f68b007381932b682cc851bc4e1d0fc0658dba16387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ramanujantao")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40258")[#strong[#text("ramanujantao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("87")]#text(" 93. Suppose ")#mi("L = \\{2,4,6,8,9,10, 11 \\}")#text(". Here, ")#mi("n =7")#text(". Also the sum is ")#mi("50")#text(". Now suppose ")#mi("M = \\{2,4,6,8,9,10 \\}")#text(". In this case, the grasshopper can just go ")#mi("11")#text(" units forward. So what about the set ")#mi("M")#text(" not containing the sum, makes the problem solvable?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nikhil devanur")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40259")[#strong[#text("nikhil devanur")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("94. A slightly different take on the problem: Is it even in NP?")#linebreak()#text(" That is, given numbers ")#mi("a_1,a_2 \\ldots a_n")#text(", is there a short witness that for all possible choices of ")#mi("M")#text(" there exists a path the avoids ")#mi("M")#text(". Someone suggested an approach similar to Menger’s theorem, that we could show ")#mi("n")#text(" disjoint paths, but that is not true. Can be seen easily for the instance{1,2,3}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asdf")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-2/#comment-40260")[#strong[#text("asdf")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("90")]#text(" 95. I’m trying to follow ")#strike[#text("85")]#text(" 90. I have my set A of size N and my set M of size N-1, and I want to use inductive solutions of subsets of A and M to build a solution to A and M. There are N subsets A’ of A with size N-1, and there are N-1 subsets M’ of M with size N-2; for each of these N*(N-1) combinations I can use the inductive solution to get a path through A’ that hits at most one mine in M. Well, maybe a bit fewer than N*(N-1) because I can’t get a partial solution when an element in M’ is equal to the sum of A’. So is there some reason that at least one of these roughly N*(N-1) partial solutions of A’ and M’ can always be extended to a full solution of A and M?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40138")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("0. I’d just like to chip in here and say that solving an already solved problem in an open collaborative way is a great idea, as it is basically guaranteed to give us useful data about how such projects can work. I have not yet thought seriously about the problem myself, but I had a few preliminary thoughts offline before you suggested this, so I propose to wait for others to post similar thoughts before I make any comments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca116084471cf4cfe891c1e62a2641c04658f6bdc15b508384b665576a566745-6b81ac9a31e72c42c95cc6a8c1abfbe5da141e0c999c1c22d952da7c5e991814.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristina")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40139")[#strong[#text("Cristina")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("1. Having seen the problem for the first time few minutes ago, the first reaction I have is to try some kind of variation on reductio ad absurdum.")#linebreak()#text(" (I hope this kind of comment is in the spirit of the original idea — I apologise in advance if I’ve stepped over the boundary of the experiment’s rules) ")#emph[#text("[This is definitely in the spirit of the experiment – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40140")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("2. Two vague thoughts:")

#text("(1) Let ")#mi("C_n")#text(" be the edge graph of the unit ")#mi("n")#text("-cube: so ")#mi("C_n")#text(" has ")#mi("2^n")#text(" vertices and ")#mi("n*2^{n-1}")#text(" edges. There is an obvious map ")#mi("p")#text(" from the vertices of ")#mi("C_n")#text(" to the integers, sending the vertex ")#mi("(i_1, i_2, ..., i_n)")#text(" to the point ")#mi("\\sum i_j a_j")#text(". We would like to show that ")#mi("p^{-1}(M)")#text(" cannot disconnect ")#mi("C_n")#text(".")

#text("Is there some classification of sets that disconnect ")#mi("C_n")#text("? Is there some measure of size (probably not simple cardinality) in which ")#mi("p^{-1}(M)")#text(" is too small to disconnect?")

#text("(2) I’d like to induct on ")#mi("n")#text(". I tried to set it up a few times and failed, but maybe someone else can do better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haim")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40141")[#strong[#text("Haim")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("2")]#text(" 3. The following reformulation of the problem may be useful:")#linebreak()#text(" Show that for any permutation s in Sn, the sum a_s(1)+a_s(2)…+a_s(j) is not in M for any j=<n.")

#text("Now, we may use the fact that Sn is \"quite large\" and prove the existence of such permutation with some kind of a pigeonhole-ish principle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab57e9002bec3490bbe57ea4d2aaeb6863d4bd581032243f8621551be2deaeac-8f6f9cd6fbae7084e5f021eb33e2be3ccad5ea5a1f9e4958afa19968608523d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Lugo")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40142")[#strong[#text("Michael Lugo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("2")]#text(" 4. If n = 2, the problem reduces to: let a_1, a_2 be distinct positive integers, and let m be a positive integer which is not s = a_1 + a_2. A grasshopper is to jump along the real axis, starting at the point 0 and making two jumps a_1, a_2. Prove that the order can be chosen in such a way that the grasshopper never lands on m.")

#text("In this case, the desired result is obvious; the sequence of points landed on is either (a_1, a_1 + a_2) or (a_2, a_1 + a_2). If m is not a_1 or a_2 we can pick either sequence; if m is one of those we pick the other one.")

#text("This could be the base case for some induction on n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haim")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40143")[#strong[#text("Haim")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("2")]#text(" 5. The following reformulation of the problem may be useful:")#linebreak()#text(" Show that for any permutation s in Sn, the sum a_s(1)+a_s(2)…+a_s(j) is not in M for any j=<n.")

#text("Now, we may use the fact that Sn is \"quite large\" and prove the existence of such permutation with some kind of a pigeonhole-ish principle")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab57e9002bec3490bbe57ea4d2aaeb6863d4bd581032243f8621551be2deaeac-8f6f9cd6fbae7084e5f021eb33e2be3ccad5ea5a1f9e4958afa19968608523d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Lugo")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40144")[#strong[#text("Michael Lugo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("6. This is an administrative comment: there are now four comments numbered “2”. Is it possible to clean this up? ")#emph[#text("[Now doing so – T.]")]

#text("(Incidentally, I know I’ve seen blogs — and I’m pretty sure they were WordPress blogs — that automatically numbered the comments. I’m not sure how to activate this, but it might be useful for this post and others in the “polymath” vein.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nate")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40145")[#strong[#text("Nate")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("7. Well, my first thought is to see if the hypotheses seem reasonable. The hypothesis that $s= a_1 + … + a_n$ not lie in M is certainly necessary, as the last jump that the grasshopper takes will land on s. The grasshopper’s other steps will land on a partial sums $a_{\\sigma(1)} + … + a_{\\sigma(k)}$ for some permutation $\\sigma$, but we get to choose the permutation. Thus it seems plausible that we can avoid a given set of n-1 points.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a2bef69f7cb22e5901c4f3be9fce9c8f94f784481d397054af3485895393c72-a2075ec9b4371e8ba35e81ab6dd813352b381855d1571618d9b01c8fc09118f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40146")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("2")]#text(" 8. Quick observation. The grasshopper must make a first step. This is always possible, since the a_i are distinct and |M|=n-1; that is, there is always an a_i not in M. However, let’s say M matches all but one of the a_i. Then the first step is uniquely determined. Still, according to the claimed theorem, a second step must still be possible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haim")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40147")[#strong[#text("Haim")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("3")]#text(" 9. Following (")#strike[#text("2")]#text(" 3);")#linebreak()#text(" For any x in M, there are two possibilities:")#linebreak()#text(" 1. x can’t be represented as a sum of (distinct) ai’s.")#linebreak()#text(" 2. x=a_j1+a_j2…+a_jk. In this case, we may assign x the set {j1, j2…jk}")

#text("So M can actually be regarded as a subset of P({1, 2…n})")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51a06662c73bb1f9256cdbc867043042f4c7654ddb60bcb8509bc11fe8d98542-5ab0c2d963dfd0f67316bb730274e462bdc7beea23f926a043881d38c2998b09.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40148")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("1")]#text(" 10.")

#text("Addressing Michael Lugo: I think he means number just your own comments, and then address a (person,number) pair. ")#emph[#text("[Actually, I was proposing a global numbering system; I’ll try to fix it up now. But the (author, number) pair approach would also have worked, except perhaps for anonymous comments. -T]")]

#text("Addressing Haim(")#strike[#text("2")]#text(" 5):")

#text("That’s pretty strong; all you need is that there exists a permutation where that is true. And it doesn’t work; there are numbers $a_1,a_2,\\ldots,a_n$ and sets $M$ of $n-1$ points such that, for instance, $a_1 \\in M$. Then any permutation starting with $a_1$ would not satisfy your conjecture for $j=1$.")

#text("But, just looking for *one* permutation that satisfies $a_s(1)+a_s(2)…+a_s(j) \\not \\in M$ for any $j \\leq n$ (which is basically the statement of the theorem), could lend itself well to induction. In other words, use the fact that for every subset $M’ \\subset M$ of size $j$ not containing $a_s(1)+a_s(2)…+a_s(j)$, there is a way to permute those $j$ numbers to avoid $M’$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40149")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("2")]#text(" 11. The scorings of this problem accroding to the offical result are:")

#text("Score Number of Particpants")#linebreak()#text(" 0 540")#linebreak()#text(" 1 2")#linebreak()#text(" 2 1")#linebreak()#text(" 3 10")#linebreak()#text(" 4 6")#linebreak()#text(" 5 2")#linebreak()#text(" 6 1")#linebreak()#text(" 7 3")

#text("A score of 1-6 represents partial credit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haim")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40150")[#strong[#text("Haim")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("12. Addressing Dave:")

#text("Sorry, indeed I meant: “Show that for *one* permutation…”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40151")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("2")]#text(" 13. Regarding Haim(")#strike[#text("3")]#text(" 9) Unfortunately, the same integer may occur as the sum of many different subsets of M. For example, if M = {1,2,3}, do you assign the integer 3 to {3} or to {1,2}?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neal")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40153")[#strong[#text("neal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("14. can M really be regarded as a subset of P when P({1,2,…,n}) since M is a set of n-1 positive integers not containing s, and not necessarily the set of {1,2,…,(n-1)}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haim")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40154")[#strong[#text("Haim")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("5")]#text(" 15. (I’m lost with the numbering of comments)")

#text("To David:")

#text("You’re right. Instead, we may take a set of the largest possible size, and if there are two such sets, we may order their elements, and take the larger tuple in the lexicographical order. Now, this may be useful: note that M does not contain a1+a2+…+an, so each x in M must be assigned to some j-tuple with j<n. Perhaps we should look for some surjective mapping from Sn to the set of <n-tuples that will assert the existence of the desirable permutation…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 国际奥林匹克数学竞赛2009年的最后一题 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40155")[#strong[#text("国际奥林匹克数学竞赛2009年的最后一题 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("[…] Tao教授将这个习题做成一个小的合作研究的数学实验，敬请关注。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neal")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40156")[#strong[#text("neal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("16. nevermind. my mistake")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40158")[#strong[#text("Wiskundemeisjes » Blog Archive » Doe mee aan een olympiade opdracht")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")]

#text("[…] schreef gisteren al een stukje over de Internationale Wiskunde Olympiade. Op de site van Terence Tao is inmiddels een experiment gestart om als een groep één van de problemen op te lossen. Dit is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of k")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40161")[#strong[#text("k")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("17. we need to show that there is a permutation $\\sigma$ that no partial sum")#linebreak()#text(" $a_{\\sigma(1)}+ \\ldots + a_{\\sigma(j)}, j = 1,2,..n$ is in the set M. we can assume that the numbers $a_1, a_2,.. a_n$ are in increasing order.")#linebreak()#text(" if M does not intersect the interval $[a_1, s=a_1+a_2..a_n]$ then any permutation $\\sigma$ would do. so we assume that max M is less or equal to s.")

#text("choose the initial step $a_j$ where j is the smallest index j so that $a_j$ is not in M. this is possible because M has only n-1 elements. now replace the set M by $M_1 = M – a_j = m – a_j: m in M$, remove $a_j$ and set $\\sigma_1 = j.$")

#text("i need to work on how to make the next step or use induction on j")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40162")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("18. OK, there have been enough comments that I feel I can make my very preliminary, and not obviously helpful, observation. It’s that if on the first step you can get past a forbidden number then you are done by induction.")

#text("However, since there is absolutely no reason to be able to do that on the first step, I think this is probably not the way to go. I’m tempted to try proving it for ")#mi("n=3")#text(" by an ugly method. In fact, here is an attempt at that. Let the numbers be ")#mi("a,b")#text(" and $c$. We’re trying to get to ")#mi("a+b+c")#text(". Let’s write down the first two steps of all six possible routes: ")#mi("(a,a+b)")#text(", ")#mi("(a,a+c)")#text(", ")#mi("(b,b+a)")#text(", ")#mi("(b,b+c)")#text(", ")#mi("(c,c+a)")#text(", ")#mi("(c,c+b)")#text(". Can we find two numbers that intersect all these pairs?")

#text("The answer isn’t instantly obvious, so let’s experiment with blocking ")#mi("a")#text(" and ")#mi("b+c")#text(" to see what happens. Then the only possibilities left are ")#mi("(b,b+a)")#text(" and ")#mi("(c,c+a)")#text(". We know that we have not covered ")#mi("b")#text(" or ")#mi("c")#text(". Actually, we haven’t covered ")#mi("b+a")#text(" either (since ")#mi("a>0")#text(" and ")#mi("a\\ne c")#text(").")

#text("To be more systematic, we have to see what the possible equalities are between the various numbers. We know that ")#mi("a,b")#text(" and $c$ are distinct. Also, ")#mi("a+b")#text(", ")#mi("b+c")#text(" and ")#mi("a+c")#text(" are distinct (subtract them from ")#mi("a+b+c")#text("). So the only possible equalities are things like ")#mi("a=b+c")#text(", Moreover, only one such equality can hold, since the number that equals the sum must be the biggest of the three. So let’s suppose WLOG that ")#mi("b\\ne a+c")#text(" and ")#mi("c\\ne a+b")#text(". Then the pairs ")#mi("(a,a+b)")#text(", ")#mi("(b,a+b)")#text(", ")#mi("(a,a+c)")#text(" and ")#mi("(c,a+c)")#text(" have only the obvious equalities. The only way of blocking all four of these paths is to take ")#mi("a+b")#text(" and ")#mi("a+c")#text(". But that leaves the path ")#mi("(b,b+c)")#text(". (It’s possible that ")#mi("a=b+c")#text(" here, but we were forced not to block ")#mi("a")#text(".)")

#text("I don’t see a general argument coming out of this just yet, but a few little ideas might perhaps be developed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40163")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("20 I think I’m the one who screwed up the comment numbering, so I apologize. I’m going to number this as comment 20, and hopefully we can do sequential numbering from now on. ")#emph[#text("[My count gives 19, but it should be OK to have gaps. A good rule would be: when in doubt, make the number bigger.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e651e5db50e504b981728bda9edd094608ea66f7126e55caf6d3d340b5e5bba-b6abd184a4fa00c2cb62b6566c9adc69fde9e73e561b060a2e770e5048e13148.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KK")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40166")[#strong[#text("KK")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("21. Forgive me for the silly image but that´s the only way I can”feel” the problem. I imagine our grasshopper hero going from 0 to s in n distinct jumps whose lengths are given (a1,a2,…,an) .But there are some numbers x (x belongs to M) where a landmine is placed and if our buddy falls there, game over.")

#text("Now I am only guessing but I think that if we prove that we can find a sequence even for the worst case (n-1 landmines i.e all x between 1 and s-1) we have solved our problem. As it has been suggested we could try induction (for each step an unused ai can be choose so we can avoid the landmines) or we can try a combinatorial approach and prove that there is at least one sequence a1.a2…an whose set of partial sums is disjointed from M. Are these really two really different approaches? A local , step by step on (by Induction) and a global one by combinatorics? or is the same since the induction would need combinatorics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b888be0be275de5b3877f2e54e8a21aa0f26ea8eaf6930d9e9785ec9273e89fe-94ad56e80e6f291631307c33b1a9f07dbcd8e93d22127df52e56af95222fbec0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Louigi")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40167")[#strong[#text("Louigi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("22. Just a quick thought after having read the problem description and the current replies. It is certainly not the case that for fixed M, *any* permutation ")#mi("\\sigma:\\{1,\\ldots,n\\} \\rightarrow \\{1,\\ldots,n\\}")#text(" will yield a sequence of steps ")#mi("a_{\\sigma(1)},a_{\\sigma(1)}+a_{\\sigma(2)},\\ldots")#text(" that avoid M.")

#text("But maybe the following statement, stronger than the original claim, is true: for fixed M and any permutation ")#mi("\\sigma:\\{1,\\ldots,n\\} \\rightarrow \\{1,\\ldots,n\\}")#text(", some cyclic permutation of ")#mi("\\sigma")#text(" will yield a sequence of steps that avoid M.")

#text("I haven’t thought about this approach so maybe there is an easy counterexample.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40168")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("23: “maybe the following statement … is true: for fixed M … some cyclic permutation of \\sigma will yield a sequence of steps that avoid M.”")

#text("Sadly, false. Take (a_1, a_2, a_3) = (1,2,3) and take M = {2,3}. Then none of the cyclic permutations work.")

#text("I like the idea of using a smaller group than the full symmetric group, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40169")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("6")]#text(" 24 I’m thinking about the possibility of transforming this problem into another, where there are several ways to travel from one point to another, and M regulates which ways can’t be chosen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40170")[#strong[#text("mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("1")]#text(" 25. My first ideas:")

#text("– without loss of generality $M$. is a subset of $A:=\\{1,\\ldots,s-1\\}$, where $s:=a_1+\\ldots+a_n$.")

#text("– Let $F$ be the set of possible sums $S_{\\sigma,j} $ for $\\sigma\\in S_n$ and $j\\leq n$, as described by Haim(2). What properties does this set have? One symmetry is as follows: consider $A$ as a set of $s-1$ ordered beads, of which the ones corresponding to $F$ are colored. So $F$ can be considered as a coloring of a set of beads.")

#text("Then consider a MOVE, given by taking a segment $b_1,\\ldots,b_k$ of ordered beads, of which the _first_ and the _last_ are colored. Then reverse its order. now you have a new coloring of the beads.")

#text("I claim that the set $F$ of colored beads is invariant under any MOVE.")#linebreak()#text(" Is it also characterized by this?(ehm..in some sense?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e651e5db50e504b981728bda9edd094608ea66f7126e55caf6d3d340b5e5bba-b6abd184a4fa00c2cb62b6566c9adc69fde9e73e561b060a2e770e5048e13148.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KK")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40171")[#strong[#text("KK")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("24")]#text(" 26. Sorry for not putting the comment number before :( . I just thought, if this can be proven by induction is equivalent to give an algorithm for the sequence right? I dont know maybe something like find the first member of M , use the most/least ai to arrive to a number before it, then use some criteria to select ai to jump over the members of M which could be together or very close and so on. Sorry for the rambling but I would like to see a nice algorithm for this :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40172")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("27. A vague thought that came out of the brute-force approach to the case ")#mi("n=3")#text(". It seems that the more coincidences there are amongst the finite sums of the ")#mi("a_i")#text(", the harder it is for the grasshopper, since the landmines (if we go with that image) can block several paths at once. So it ought, for instance, to be easy to prove that the grasshopper wins if ")#mi("a_i=2^{i-1}")#text(" (so that all sums are distinct). In fact, here’s a quick proof. There are ")#mi("n!")#text(" distinct paths, and any landmine rules out ")#mi("k!(n-k)!")#text(" of them for some ")#mi("k")#text(". But this is maximized when ")#mi("k=1")#text(" (since ")#mi("k=0")#text(" and ")#mi("k=n")#text(" are forbidden), so we can’t rule out more than a proportion ")#mi("n^{-1}")#text(" of all paths. So we are done.")

#text("At the opposite extreme is the case when ")#mi("a_i=i")#text(". Now there are lots of coincidences amongst the sums. Does anyone have an argument for this special case? Morally, it ought to be the hardest, but that doesn’t mean it’s as hard as the whole problem, since the difficulty might lie in actually proving that it’s the extreme case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65b2ea070936748c33339895b7d67b0eb72e599846423bccb09c3f80ef1865b4-b639da33830634e53ff9a86ec9aa80050fd4e8598ff4bbfde6e4dc7075b9c811.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Omar")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40173")[#strong[#text("Omar")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("Generalizing gowers’s comment, if for any k<n we can find k of the a_i whose partial sums avoid M and whose sum gets you past at least k of the elements of M, then you can finish by induction.")

#text("So an indecomposable instance of the problem is one for which the smallest k with the property above is k=n, these are the ones that don't directly fall to induction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40174")[#strong[#text("mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("2")]#text(" 28. (variant of Louigi’s approach) if you start with a given ")#mi("\\sigma")#text(" then maybe it can be useful to iterate “exchanging ")#mi("2")#text(" successive jumps to avoid an element of ")#mi("M")#text("” (this uses the case ")#mi("n=2")#text(" discussed by Michael Lugo (")#strike[#text("2")]#text(" 4)).. in other words you compose your permutation with inversions, or ")#mi("2")#text("-cycles")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73f353ccdd37018a2aaddba95b00a7fcd478031c5210ce26b1061f69e4ed3c54-3a19b7ff4dd69603bb526c84e2fc8b4c1c553c4173efa9a8027870c2faeef53b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pz")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40175")[#strong[#text("pz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("29. Addressing 1 (reductio ad absurdum). Suppose there exists an M such that every grasshopper walk must pass through at least one point of M. Wlog let M = { S_{k_1}, S_{k_2}, …, S_{k_{n-1}}} where each S_{k_j} is a sum of k_j integers a_i. For each S_{k_j}, we have that at most (k_j)!(n-k_j)! grasshopper walks must pass through the point S_{k_j}. Since the total number of walks is n!, we must have:")

#text("(k_1)!(n-k_1)! + (k_2)!(n-k_2)! + … + (k_{n-1})!(n-{k_{n-1}})! >= n!")

#text("Clearly the left hand side is at most (n-1) (n-1)!. Hence we have n-1 > n. QED.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73f353ccdd37018a2aaddba95b00a7fcd478031c5210ce26b1061f69e4ed3c54-3a19b7ff4dd69603bb526c84e2fc8b4c1c553c4173efa9a8027870c2faeef53b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pz")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40176")[#strong[#text("pz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("30. Re my previous post: This was too simple, so there must be a mistake in my proof. What is it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06fbc2f169d721e3ff98f76b7111e678643250652577c137145172950882a0a-e566bf396a87c86246a7660f03db1dfd7db8003ac0eb72f3d616a5773a82f8bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40177")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text(" 1")]#text(" 31.")

#text("Quick thought following on David Speyer’s first comment: The problem asks us to prove that no set of size (n-1) can disconnect two diagonally opposing vertices in the n-cube. By Menger’s theorem, this is equivalent to proving that there are n internally vertex-disjoint paths between these two vertices. So, now we are faced with a constructive problem, independent of the set M: Construct n vertex-disjoint paths from 0^n to 1^n in the n-cube.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40179")[#strong[#text("mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("32. @pz: it is that you assume “wlog” a fact which is not a “generic” bad case. In the generic bad case only one of the sums S_{k} belongs to M.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40183")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("32")]#text(" 33: To pz: the mistake is that the same element of M can be written as a sum of a_i in many ways, and can thus block many more than k!(n-k)! paths. For example, if (a_1, a_2, a_3) = (1,2,3), then putting 3 into M blocks four paths.")

#text("To Mohammed, easy enough to do: look at the n paths")

#text("e_1, e_1+e_2, …, e_1+e_2+…+e_n")#linebreak()#text(" e_2, e_2+e_3, …, e_2+e_3+…+e_1")#linebreak()#text(" …")#linebreak()#text(" e_n, e_n+e_1, …")

#text("Unfortunately, I think we are in a rut here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40184")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("33")]#text(" 34. Let ")#mi("a_1<a_2<\\cdots<a_n")#text(", then try the situation when the first step are blocked except for only one choice.")

#text("If ")#mi("M=\\{a_1,\\cdots,a_{i-1},a_{i+1},\\cdots,a_n\\}")#text(", then our first step is forced to take ")#mi("a_i")#text(". Then we can choose our second step as the largest one, ")#mi("a_n")#text(", to leave all landmines behind.")

#text("I am thinking if we can continue this road, discuss different situations step by step.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7181238363f256c9a64ecc9eb11d49f7482acfd4a7d97bf753d0e4dee15ee366-68df6ae74b671894bed986966dea36ca68b76f170887c8bff4152c18b6db27cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AlexA")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40185")[#strong[#text("AlexA")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("35. Also addressing 1, I propose the following reformulation:")#linebreak()#text(" Prove the following to be false:")#linebreak()#text(" (a) exists b $\\in$ M s.t any path contains a prefix s.t Sum(prefix) = b")#linebreak()#text(" This is equivalent with:")#linebreak()#text(" (b) any 2 paths, exists prefix in each of them s.t Sum(prefix1) = Sum(prefix2)")

#text("It seems like (b) can be proven false by fixing one path, and then proving the existence of another with doesn’t not have the property (unless 2 of the numbers are equal, contradiction). Analysis for increasing length of the prefixes for first path seems to work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73f353ccdd37018a2aaddba95b00a7fcd478031c5210ce26b1061f69e4ed3c54-3a19b7ff4dd69603bb526c84e2fc8b4c1c553c4173efa9a8027870c2faeef53b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pz")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40186")[#strong[#text("pz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("36. @mircea: The S_k’s are arbitrary sums of the a_i elements. What I am saying is that the elements of M are each a potential “hit” (i.e. if an element of M cannot be expressed as a sum of a_i’s, then no grasshopper walk will step on it).. If only one of the sums S_k belongs to M, then we have at most k!(n-k)! walks that go through it, and then we can clearly find a walk out of the n! – k!(n-k)! that doesn’t go through M.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06fbc2f169d721e3ff98f76b7111e678643250652577c137145172950882a0a-e566bf396a87c86246a7660f03db1dfd7db8003ac0eb72f3d616a5773a82f8bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40187")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#strike[#text("2")]#text(" 37.")

#text("If I’m not mistaken, what I said in my last comment can be proved by induction on n:")

#text("By Ind. Hyp., there are n vertex disjoint paths ")#mi("p_1,\\ldots,p_n")#text(" from ")#mi("0^{n+1}")#text(" to ")#mi("1^n0")#text(", that only uses vertices that have 0 at the end. The last vertex of each ")#mi("p_i")#text(" is a vertex of weight n-1 that has 0 at the end. From each ")#mi("p_i")#text(", ")#mi("1\\le i\\le n-1")#text(", we can create a path ")#mi("p^{\\prime}_i")#text(" from ")#mi("0^{n+1}")#text(" to ")#mi("1^{n+1}")#text(" by following ")#mi("p_i")#text(" until the last vertex, which is of the form ")#mi("v0")#text(" where $v$ is a sequence of weight n-1, then jumping to ")#mi("v1")#text(", and then ")#mi("1^{n+1}")#text(". From ")#mi("p_n")#text(", we create ")#mi("p^{\\prime}_n")#text(" by following ")#mi("p_n")#text(" to ")#mi("1^n0")#text(" and then going to ")#mi("1^{n+1}")#text(". Removing the internal vertices of all these paths, we are at least left with the n-cube containing all vertices of the form ")#mi("v1")#text(", except ")#mi("n-1")#text(" of the vertices of weight ")#mi("n")#text(". Say, the vertex of weight ")#mi("n")#text(" that is not taken is ")#mi("01^{n}")#text(". Then we can add another path ")#mi("p^{\\prime}_{n+1}")#text(" as follows: ")#mi("0^{n+1}, 010^{n-1}, 01^20^{n-2},\\ldots,01^{n-1}0,01^n,1^{n+1}")#text(". All ")#mi("p^{\\prime}_i")#text("‘s are vertex disjoint.")

#text("Am I making a mistake?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73f353ccdd37018a2aaddba95b00a7fcd478031c5210ce26b1061f69e4ed3c54-3a19b7ff4dd69603bb526c84e2fc8b4c1c553c4173efa9a8027870c2faeef53b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pz")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40188")[#strong[#text("pz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("38. @David Speyer: Oops. You’re right. Maybe we can try to refine the count, i.e. show that not too many sets of a_i’s can sum to the same integer…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40189")[#strong[#text("pavel")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("39. @gowers:")

#text("I thought about induction on the set of all possible ")#mi("(a_1,\\dots,a_n)")#text(" with some ordering instead of ")#mi("n")#text(". Your approach might provide a nicer base so that one only has to decrease the ")#mi("a_i")#text(" or throw some of them away.")

#text("I.e. what happens if the claim is true for ")#mi("(a_1,\\dots,a_n)")#text(": is it also true for some subset ")#mi("(a_1,\\dots,a_{i-1},a_{i+1},\\dots,a_n)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40190")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("40. Why can’t a S_{k_j} be the sum of another set of integers of a_1, a_2, \\ldots, a_n as well as S_{k_j}that would make (k_j)!(n-k_j)! less than the total number of walks through S_{k_j} as there would be another set of walks based on the second set of integers. if the a_1, a_2, \\ldots, a_n are in arithemetic progression this will happen, the sum of the first and last will equal the sum of the second and the second to last etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40191")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("41. In regards to 31 the proof regarding the n-cube doesn’t the same problem occur, that points of M can go to more than one point of the n cube(because the sums are the same so there are more than n-1 points")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06fbc2f169d721e3ff98f76b7111e678643250652577c137145172950882a0a-e566bf396a87c86246a7660f03db1dfd7db8003ac0eb72f3d616a5773a82f8bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40192")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("42. Right, my mistake.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40193")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("43. Here’s a wrong argument, but I wonder whether it could be turned into a correct argument somehow. It goes like this. Suppose we can find a sum of k of the numbers that is bigger than exactly k-1 of the forbidden points. Then we’ve split the problem into two: get to that point, and then get to the end. The trouble is that for the second part we have to take n-k steps and there are now n-k forbidden points. So we need something stronger. For instance, it would be enough if we could find a sum of k numbers that is bigger than exactly k forbidden points, followed by a jump that clears two forbidden points (and doesn’t land on a forbidden point). Then we’d have divided and conquered.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40194")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("44. Sorry, I meant it’s enough if we can find a sum of k numbers that’s bigger than exactly k-1 forbidden points, followed by clearing at least two forbidden points. This feels vaguely topological.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8a3013f4429139a123a3bec6970d804cd2804710e3ca5db26b43e1fa703bd46-36c5da777bb851e4b79cc21d9381f2ed464040c237c5a6e2e64fa4782c4175d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aj")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40195")[#strong[#text("aj")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("46. So the approach I was looking at was to try splitting the possible sums on a_i into two partially disjoint sets, made up of (respectively) all possible sums of a_1..a_n without a_i, and all possible sums with a_i. Those two sets have to be the same size, and each forms a smaller instance of almost the same problem, setting a’ = (a1..a_n without a_i), and M’ = {m-a_i} or M’=M.")

#text("I was hoping to find some way of removing a member of either of the M’ sets to apply induction — if it worked I could just choose to do a_i either first or last, with the simpler problem in-between, but couldn’t find a way to do it. The problem is that they don’t quite reduce that easily, for instance choosing A={2,3,5,7}, M={7,10,12}, and a_i=2, gives A’={3,5,7} and M’={5,8,10} or {7,10,12}. On the other hand, if you select a_i=3, and M’={4,7,9}, you quickly find 4 isn’t the sum of any combination of {2,5,7}, so can reduce it to A’={2,5,7},M’={7,9}, which is n=k-1 and you have an inductive step.")

#text("Anyone have any idea how to reason about the myriad ways ")#mi("\\sum X = \\sum Y")#text(" when ")#mi("X,Y \\in \\mathcal{P}(A)")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40197")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("47 @gowers: by induction, if several ones of the ")#mi("a_1<a_2<\\cdots<a_n")#text(" should be blocked, then they must be ")#mi("a_n,a_{n-1},\\cdots, a_k")#text(". Otherwise, one can make the first step jump over at least one landmines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haim")]], [#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/comment-page-1/#comment-40198")[#strong[#text("Haim")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("48. Here’s a new approach:")

#text("For each j, let Sn_j be the set of permutations with j fixed points. For a permutation s in Sn_j, we say that a set of integers M (as above) is s-compatible if it doesn’t contain a sum of the form a_s(1)+…+a_s(k) . Denote by Mj the collection of all s-compatible sets for some s in Sn_j. Now, our problem is equivalent to showing that the union of Mj for al j=<n covers all possible sets of integers (of size n-1) not containing a1+…+an.")

#text("Now, it's easy to characterize Mn, and I guess that an easy characterization of the other Mj's may help us finish this proof…")

#text("(I'm sorry if this is being reposted, as I experience some technical problems with this blog)")
]
