// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/
// Converted to Typst by tao2typ: "2026-10-14T16:39:09.364402+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A Maclaurin type inequality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A Maclaurin type inequality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 October 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/")[#text("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/2310.05328")[#text("A Maclaurin type inequality")]#text("“. This paper concerns a variant of the ")#link("https://en.wikipedia.org/wiki/Maclaurin%27s_inequality")[#text("Maclaurin inequality")]#text(" for the elementary symmetric means")

#align(center)[#tao-fit-display[#mitex("s_k(y) := \\frac{1}{\\binom{n}{k}} \\sum_{1 \\leq i_1 < \\dots < i_k \\leq n} y_{i_1} \\dots y_{i_k}")]]

#text("of ")#mi("{n}")#text(" real numbers ")#mi("{y_1,\\dots,y_n}")#text(". This inequality asserts that")

#align(center)[#tao-fit-display[#mitex("s_\\ell(y)^{1/\\ell} \\leq s_k(y)^{1/k}")]]

#text("whenever ")#mi("{1 \\leq k \\leq \\ell \\leq n}")#text(" and ")#mi("{y_1,\\dots,y_n}")#text(" are non-negative. It can be proven as a consequence of the ")#link("https://en.wikipedia.org/wiki/Newton%27s_inequalities")[#text("Newton inequality")]

#align(center)[#tao-fit-display[#mitex("s_{k-1}(y) s_{k+1}(y) \\leq s_k(y)^2")]]

#text("valid for all ")#mi("{1 \\leq k < n}")#text(" and arbitrary real ")#mi("{y_1,\\dots,y_n}")#text(" (in particular, here the ")#mi("{y_i}")#text(" are allowed to be negative). Note that the ")#mi("{k=1, n=2}")#text(" case of this inequality is just the arithmetic mean-geometric mean inequality")

#align(center)[#tao-fit-display[#mitex("y_1 y_2 \\leq (\\frac{y_1+y_2}{2})^2;")]]

#text("the general case of this inequality can be deduced from this special case by a number of standard manipulations (the most non-obvious of which is the operation of differentiating the real-rooted polynomial ")#mi("{\\prod_{i=1}^n (z-y_i)}")#text(" to obtain another real-rooted polynomial, thanks to ")#link("https://en.wikipedia.org/wiki/Rolle%27s_theorem")[#text("Rolle’s theorem")]#text("; the key point is that this operation preserves all the elementary symmetric means up to ")#mi("{s_{n-1}}")#text("). One can think of Maclaurin’s inequality as providing a refined version of the arithmetic mean-geometric mean inequality on ")#mi("{n}")#text(" variables (which corresponds to the case ")#mi("{k=1}")#text(", ")#mi("{\\ell=n}")#text(").")

#text("Whereas Newton’s inequality works for arbitrary real ")#mi("{y_i}")#text(", the Maclaurin inequality breaks down once one or more of the ")#mi("{y_i}")#text(" are permitted to be negative. A key example occurs when ")#mi("{n}")#text(" is even, half of the ")#mi("{y_i}")#text(" are equal to ")#mi("{+1}")#text(", and half are equal to ")#mi("{-1}")#text(". Here, one can verify that the elementary symmetric means ")#mi("{s_k(y)}")#text(" vanish for odd ")#mi("{k}")#text(" and are equal to ")#mi("{ (-1)^{k/2} \\frac{\\binom{n/2}{k/2}}{\\binom{n}{k}}}")#text(" for even ")#mi("{k}")#text(". In particular, some routine estimation then gives the order of magnitude bound ")#metadata(none) <tao-5312fb609f60384731fc>#tao-math("\\displaystyle  \\left|s_k(y)\\right|^{\\frac{1}{k}} \\asymp \\frac{k^{1/2}}{n^{1/2}} \\ \\ \\ \\ \\ (1)", block: false)#text(" ")#text(" for ")#mi("{0 < k \\leq n}")#text(" even, thus giving a significant violation of the Maclaurin inequality even after putting absolute values around the ")#mi("{s_k(y)}")#text(". In particular, vanishing of one ")#mi("{s_k(y)}")#text(" does not imply vanishing of all subsequent ")#mi("{s_\\ell(y)}")#text(".")

#text("On the other hand, it was observed ")#link("https://zbmath.org/1483.65014")[#text("by Gopalan and Yehudayoff")]#text(" that if ")#emph[#text("two")]#text(" consecutive values ")#mi("{s_k(y), s_{k+1}(y)}")#text(" are small, then this makes all subsequent values ")#mi("{s_\\ell(y)}")#text(" small as well. More precise versions of this statement were subsequently observed by ")#link("https://zbmath.org/1433.68604")[#text("Meka-Reingold-Tal")]#text(" and ")#link("https://zbmath.org/?q=rf%3A7330813")[#text("Doron-Hatami-Hoza")]#text(", who obtained estimates of the shape ")#metadata(none) <tao-531ee5099a7b3218f5ce>#tao-math("\\displaystyle  \\left|s_\\ell(y)\\right|^{\\frac{1}{\\ell}} \\ll \\ell^{1/2} \\max (\\left|s_k(y)\\right|^{\\frac{1}{k}}, \\left|s_{k+1}(y)\\right|^{\\frac{1}{k+1}}) \\ \\ \\ \\ \\ (2)", block: false)#text(" ")#text(" whenever ")#mi("{1 \\leq k \\leq \\ell \\leq n}")#text(" and ")#mi("{y_1,\\dots,y_n}")#text(" are real (but possibly negative). For instance, setting ")#mi("{k=1, \\ell=n}")#text(" we obtain the inequality")

#align(center)[#tao-fit-display[#tao-math("(y_1 \\dots y_n)^{1/n} \\ll n^{1/2} \\max( \\left|s_1(y)\\right|, \\left|s_2(y)\\right|^2)", block: true)]]

#text("which can be established by combining the arithmetic mean-geometric mean inequality")

#align(center)[#tao-fit-display[#mitex("(y_1 \\dots y_n)^{2/n} \\leq \\frac{y_1^2 + \\dots + y_n^2}{n}")]]

#text("with the ")#link("https://en.wikipedia.org/wiki/Newton%27s_identities")[#text("Newton identity")]

#align(center)[#tao-fit-display[#mitex("y_1^2 + \\dots + y_n^2 = n^2 s_1(y)^2 - n(n-1) s_2(y).")]]

#text("As with the proof of the Newton inequalities, the general case of ")#link(<tao-531ee5099a7b3218f5ce>)[#text("(2)")]#text(" can be obtained from this special case after some standard manipulations (including the differentiation operation mentioned previously).")

#text("However, if one inspects the bound ")#link(<tao-531ee5099a7b3218f5ce>)[#text("(2)")]#text(" against the bounds ")#link(<tao-5312fb609f60384731fc>)[#text("(1)")]#text(" given by the key example, we see a mismatch – the right-hand side of ")#link(<tao-531ee5099a7b3218f5ce>)[#text("(2)")]#text(" is larger than the left-hand side by a factor of about ")#mi("{k^{1/2}}")#text(". The main result of the paper rectifies this by establishing the optimal (up to constants) improvement ")#metadata(none) <tao-634632f30a1cd9f8d1b5>#tao-math("\\displaystyle  \\left|s_\\ell(y)\\right|^{\\frac{1}{\\ell}} \\ll \\frac{\\ell^{1/2}}{k^{1/2}} \\max (\\left|s_k(y)\\right|^{\\frac{1}{k}}, \\left|s_{k+1}(y)\\right|^{\\frac{1}{k+1}}) \\ \\ \\ \\ \\ (3)", block: false)#text(" ")#text(" of ")#link(<tao-531ee5099a7b3218f5ce>)[#text("(2)")]#text(". This answers a question ")#link("https://mathoverflow.net/questions/446254/maclaurins-inequality-on-elementary-symmetric-polynomials-of-arbitrary-real-num")[#text("posed on MathOverflow")]#text(".")

#text("Unlike the previous arguments, we do not rely primarily on the arithmetic mean-geometric mean inequality. Instead, our primary tool is a new inequality ")#metadata(none) <tao-4f98e2c556b1abf5a58d>#tao-math("\\displaystyle  \\sum_{m=0}^\\ell \\binom{\\ell}{m} |s_m(y)| r^m \\geq (1+ \\left|s_\\ell(y)\\right|^{2/\\ell} r^2)^{\\ell/2}, \\ \\ \\ \\ \\ (4)", block: false)#text(" ")#text(" valid for all ")#mi("{1 \\leq \\ell \\leq n}")#text(" and ")#mi("{r>0}")#text(". Roughly speaking, the bound ")#link(<tao-634632f30a1cd9f8d1b5>)[#text("(3)")]#text(" would follow from ")#link(<tao-4f98e2c556b1abf5a58d>)[#text("(4)")]#text(" by setting ")#tao-math("{r \\asymp (k/\\ell)^{1/2} \\left|s_\\ell(y)\\right|^{-1/\\ell}}", block: false)#text(", provided that we can show that the ")#mi("{m=k,k+1}")#text(" terms of the left-hand side dominate the sum in this regime. This can be done, after a technical step of passing to tuples ")#mi("{y}")#text(" which nearly optimize the required inequality ")#link(<tao-634632f30a1cd9f8d1b5>)[#text("(3)")]#text(".")

#text("We sketch the proof of the inequality ")#link(<tao-4f98e2c556b1abf5a58d>)[#text("(4)")]#text(" as follows. One can use some standard manipulations reduce to the case where ")#mi("{\\ell=n}")#text(" and ")#tao-math("{\\left|s_n(y)\\right|=1}", block: false)#text(", and after replacing ")#mi("{r}")#text(" with ")#mi("{1/r}")#text(" one is now left with establishing the inequality")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=0}^n \\binom{n}{m} |s_m(y)| r^{n-m} \\geq (1+r^2)^{n/2}.")]]

#text("Note that equality is attained in the previously discussed example with half of the ")#mi("{y_i}")#text(" equal to ")#mi("{+1}")#text(" and the other half equal to ")#mi("{-1}")#text(", thanks to the binomial theorem.")

#text("To prove this identity, we consider the polynomial")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^n (z - y_j) = \\sum_{m=0}^n (-1)^m \\binom{n}{m} s_k(m) z^{n-m}.")]]

#text("Evaluating this polynomial at ")#mi("{ir}")#text(", taking absolute values, using the triangle inequality, and then taking logarithms, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\sum_{j=1}^n \\log(y_j^2 + r^2) \\leq \\log(\\sum_{m=0}^n \\binom{n}{m} |s_m(y)| r^{n-m}).")]]

#text("A convexity argument gives the lower bound")

#align(center)[#tao-fit-display[#tao-math("\\log(y_j^2 + r^2) \\geq \\log(1+r^2) + \\frac{2}{1+r^2} \\log \\left|y_j\\right|", block: true)]]

#text("while the normalization ")#tao-math("{\\left|s_n(y)\\right|=1}", block: false)#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^n \\log \\left|y_j\\right| = 0", block: true)]]

#text("and the claim follows.")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-681973")[#strong[#text("U statistics and a new paper by Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2023")]

#text("[…] you have means of elementary symmetric polynomials. This is what Tao just wrote about. Here is his blog post announcing his […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-681976")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2023")])]

#text("The link after Meka-Reingold-Tal to zbmath is misformatted and hence broken.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-681977")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2023")])]

#text("Send it to Israel J Math")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-681979")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2023")])]

#text("“here’s the easiest paper I have ever written”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-681980")[#strong[#text("GPT-4野生代言人陶哲轩：搞论文学新工具没它得崩溃！11页“超简短”新作已上线 – AI 資訊")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2023")]

#text("[…] 参考链接：https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/（博客）https://mathstodon.xyz/@tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-681983")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2023")])]

#text("I like your discovery/creation of (4). I imagine it to be a useful tool in many problems including NS.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-682031")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2023")])]

#text("Is there application to derandomizing like L vs BPL?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-682047")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2023")])]

#text("Sir, I enjoyed your latest lecture on Korean Education Broadcasting System (EBS). As a math guy, I found every statement in the video fascinating. Your statements on vector space might have been confusing (e.g. the 3 million dimension part) to those without enough math backgrounds, but one of your following lectures seems to address the topic in detail so I hope that the viewers will eventually follow your words. By the way, your Chinese name reads ‘도철헌'(Do-Cheol-Heon) in Korean language, which sounds cool and unique in a Korean’s sense. I truly hope that more Korean people will get to see you in the media, find you approachable, and maybe one day even come to affectionately refer to you as ‘철헌 쌤’ (ssam; a colloquial word meaning ‘teacher’ in Korean, similar to ‘sensei’ in Japanese). Sir, I hope you have a fantastic day! 🎉🎉")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-682090")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2023")])]

#text("Dear Prof Tao. It looks like this post and your arxiv paper for this could be quite useful as additional tools when combined with proofs of convergence of numerical methods, eg Taylor series in the time variable. Dr Hayes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-682150")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2023")])]

#text("send it to annals")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-682161")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2023")])]

#text("? well we can’t forget the story about Perelman")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-682177")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2023")])]

#text("Just a remark that I have managed to formalize the results of this paper in Lean4 at ")#link("https://github.com/teorth/symmetric_project")[#text("https://github.com/teorth/symmetric_project")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/10/10/a-maclaurin-type-inequality/#comment-682754")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2024")])]

#text("Prof Tao, on Google scholar i saw some preliminary version of your book An Epsilon of Room, II made available as pdf. Does this mean we’re allowed to print it out for free as study material ?")#linebreak()#text(" -random student")
]
]
