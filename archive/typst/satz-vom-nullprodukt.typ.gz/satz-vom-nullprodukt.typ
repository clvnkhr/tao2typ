// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/
// Converted to Typst by tao2typ: "2026-10-14T11:05:28.681560+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Satz vom Nullprodukt", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Satz vom Nullprodukt")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 February 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/")[#text("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As I have mentioned in some recent posts, I am interested in exploring unconventional modalities for presenting mathematics, for instance using media with high production value. One such recent example of this I saw was a presentation of the fundamental ")#link("https://en.wikipedia.org/wiki/Zero-product_property")[#text("zero product property")]#text(" (or ")#link("https://en.wikipedia.org/wiki/Domain_(ring_theory)")[#text("domain")]#text(" property) of the real numbers – namely, that ")#mi("ab=0")#text(" implies ")#mi("a=0")#text(" or ")#mi("b=0")#text(" for real numbers ")#mi("a,b")#text(" – expressed through the medium of German-language rap:")

#align(center)[

]

#text("EDIT: and here is a lesson on fractions, expressed through the medium of a burger chain advertisement:")

#align(center)[

]

#text("I’d be interested to know what further examples of this type are out there.")

#text("SECOND EDIT: The following two examples from Wired magazine are slightly more conventional in nature, but still worth mentioning, I think. Firstly, my colleague at UCLA, Amit Sahai, presents the concept of zero knowledge proofs at various levels of technicality:")

#align(center)[

]

#text("Secondly, Moon Duchin answers math questions of all sorts from Twitter:")

#align(center)[

]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (56)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640471")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("Is the product operation the simplest (in some sense) binary operation which satisfy the product property over the reals?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640476")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("In a sense, yes! The set ")#mi("\\{ (a,b): a=0 \\text{ or } b=0\\}")#text(" is a (reducible) algebraic curve of degree 2, so the lowest degree non-trivial polynomial ")#mi("P(a,b)")#text(" of two variables for which one can have the zero product property ")#mi("P(a,b)=0 \\implies a=0 \\text{ or } b=0 \\}")#text(" is indeed just the multiplication operation ")#mi("P(a,b)=ab")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Levine")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640480")[#strong[#text("Adam Levine")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("I’d recommend my song to anyone looking to learn about Heegaard Floer homology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640486")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("What about a Spanish song?")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4ef08dae114cedad013473812f60729db74c80f4cb3d63fad539ed6db6b71f-76be97acb0209bd9cd6cd83b5492512528110a2c6e1015055bb5d64e8d8a935e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jochen Voss")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640492")[#strong[#text("Jochen Voss")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("How about this one? ")#link("https://www.youtube.com/watch?v=uFvokQUHh08")[#text("https://www.youtube.com/watch?v=uFvokQUHh08")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb8d2c34c2fbc0a1c4ef0f5e94ffe2240438b43d14d0c71c389250f673c73efd-498b9ede445479e59197094731b098e40bc99b10fdb86142afa0ebc5a36bd83b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kapple19")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640493")[#strong[#text("kapple19")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("Many of acapellascience’s [")#link("https://youtube.com/c/acapellascience")[#text("https://youtube.com/c/acapellascience")]#text("] parodical music videos make references to and sometimes present various levels of mathematics.")#linebreak()#text(" Additionally, from a musical standpoint his harmonies are of a richly and high quality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640495")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("You might be aware of this but let me share it here, just in case you didn’t watch this earlier. ")#link("https://www.youtube.com/watch?v=IUTGFQpKaPU")[#text("https://www.youtube.com/watch?v=IUTGFQpKaPU")]

#text("Here Professor Po-Shen Loh extends the joke-conversation “get real, be rational” between i and pi to elaborate to draw light on Euler’s identity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640498")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("Also there is a nice book titled “What’s your angle” which draws light on Pythagoras’s theorem by means of a story written in a tone which is meant for kids (but some grown-ups may also find it fun to read, like I did).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640499")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("There is also a series titled “Manga guide to …… ” which describes certain math topics through comics.")

#text("For instance: there is the manga guide to linear algebra , the manga guide to calculus, the manga guide to relativity, the manga guide to statistics, etc..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640501")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("Also there are some comic strips which concern some mathematical results. I remember seeing one such example about dominated convergence theorem, but sadly I can’t find it anymore, and my old computer had it saved, but now it’s gone and I certainly don’t have it in my new computer anymore.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640502")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("I have this habit of playing an online game by the name agar.io and there I customize the skins of my agar bubble by writing pieces of math theorems and sometimes even complete proofs (proof without words form).")#linebreak()#text(" Recently I found two other players using customized skins with mathematical things written on it, and it feels good to find people who think alike about this way of promoting mathematics :D .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6def420a06fd003a9920717079f6c46bf7c0e7ef4e32038aee8d7cd9e725d256-d4be4d5b498d24884b0a2d9ffceae8db9e1f471279e0383dba37bb9dda8dd0b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Bishnoi")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640508")[#strong[#text("Anurag Bishnoi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("I was involved with making this video that explains Ramsey numbers via game of thrones: ")#link("https://www.youtube.com/watch?v=WN_tQWIkeV0&ab_channel=anuragbishnoi")[#text("https://www.youtube.com/watch?v=WN_tQWIkeV0&ab_channel=anuragbishnoi")]

#text("I would have loved to make a longer video, but this was for the Veritasium contest and there was max limit of 1 min.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640511")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("Yeah I remember seeing this before; I shared it with some of my friends who are very much up-to-date with the game of thrones movies (although I never watched them, but I have friends who watched them and follow the series closely) but who did not know this thing before. One of them exclaimed that it was like magic.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640510")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("It doesn’t entirely fit your request, however it still provokes a good laugh ;-) ")#link("https://www.youtube.com/watch?v=2un9rO2ZF4g")[#text("https://www.youtube.com/watch?v=2un9rO2ZF4g")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640512")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("I just asked some of my friends, and one of them said that there are some YouTube videos which show how mathematics can be demonstrated through Lego bricks. So, you may like to find that out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640513")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("For a good laugh you may consider watching this. ")#link("https://www.youtube.com/watch?v=SyD4p8_y8Kw")[#text("https://www.youtube.com/watch?v=SyD4p8_y8Kw")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee842db111ab7122b09ae0e589161eed33124e8ee1964eabb0a705a573376b52-54a5853c2f23221be3d900deac4d1995a898d80700219e2cfc4370c7dbef38dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Hunter")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640517")[#strong[#text("Michael Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("I think a good video would be one on a representation domain for a subject area. For example")#linebreak()#text(" [three integrals] Calculus can equal L*W*H Geometry")#linebreak()#text(" I think it may be representation that may cause an issue with people trying to learn a subject. If people learning, understand the domain of representation (identities/formulas) within a subject area, they may be better suited to tackle said subject. Then as the become better mathematicians can understand how the subjects identities can overlap and make math more powerful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roberto D'Autilia")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640521")[#strong[#text("Roberto D'Autilia")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("I imagine that you all know this")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3818af059f9483ca762534ba77dd59dd81664fdd8fcddc5ae1a406ace4890e50-c650ea9a59eaf100ec2abda4cea841f778b74362e2b5e2c29c57cacd83641d29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of José Hdz")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640528")[#strong[#text("José Hdz")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("The burger chain advertisement reminded me of the recent beer ad in which Professor Ken Ono participated:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("Equations song")#linebreak()
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Levine")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640538")[#strong[#text("Adam Levine")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("These other math songs are so poor compared to mine. (See above.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4203212d0bbf423eabd80cc66d2e97c55067ff1de2c82228dd47ec0e3e94e59f-5d43c43472c610b7ecc97711d2a1e4bbb53ff6efd9e4e7ceb6f05444a9a30159.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Weidig")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640547")[#strong[#text("Tom Weidig")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("The German rap is very cool! And the German wording is also well done. I sent it to my teenage nieces!;-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/807dadc2d187d897f20c9881327f1b2887011bd1df912e0d01c708537d9a7667-b0194b7d16e84228f386b75e54b55753f4b85be9c907cf027b00f54732fb923b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florian")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640549")[#strong[#text("Florian")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2022")])]

#text("There is a German channel, called DorFuchs, which is dedicated to mathematical songs and math communication, see ")#link("https://www.youtube.com/c/DorFuchs")[#text("https://www.youtube.com/c/DorFuchs")]

#text("This channel contains songs ranging from the binomial formulas and polynomial division to the irrationality of pi.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d573031373cc3aad07c93d20757b474fde40fd1b82df4caba12e0c34b87cace0-d99a015d94be725eb2da9d6e320c7a5c2015d1564862f381492a74f8dc333d26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olof Sisask")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640550")[#strong[#text("Olof Sisask")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2022")])]

#text("My students mentioned DorFuchs in the context of Calculus just yesterday! In particular, the lyrics you can get out of “cosinus”, “sinus” and “minus” coupled with differentiation and integration:")#linebreak()

#text("Much less entertaining, but hopefully useful nonetheless, is an ongoing experiment of mine together with a couple of others to create an app to help students with Calculus problem solving: ")#link("https://www.dogl.app")[#text("https://www.dogl.app")]#text(". I’ll have to look at adding German-language math music to the app — clearly the pedagogical medium of the future!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helene")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640557")[#strong[#text("Helene")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2022")])]

#text("AGAIN，I cannot see the video you uploaded…what a pity…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640564")[#strong[#text("Satz vom Nullprodukt | Blog.CarlRobitaille.org")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2022")]

#text("[…] Satz vom Nullprodukt […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640568")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2022")])]

#text("sorry，maybe nothing about this blog，but I really want to know，what do you mean by SPENDING in spending symmetry？")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mgflax")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640596")[#strong[#text("mgflax")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2022")])]

#text("Suppose you wished to prove something about the relationship between two points on a circle. By symmetry, you can choose the first point — without any loss of generality — to be a convenient value, e.g. (1,0). But now you’ve “spent” the symmetry and you can’t also assume that the second point is also at a particularly-convenient value.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/462f0a9ac7b0faa284f0f43b4d17b63473ec567476c47ac75d50529efa94e809-aa9130b72a7a4d63575ebb5e4eff5acf33db44c88e362b936051af90dde57f4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640581")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2022")])]

#text("This song is also in german and it’s about the geometric series convergence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d315c6460407102ca37906907d974ec122d076b3d27e0e33cea47ff31b99406-4952b96583752331ddac3936914ff457da4e90071332d6b7d84478915e3a3e4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Th3o_r∈M")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640587")[#strong[#text("Th3o_r∈M")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2022")])]

#text("I am the author of the “Satz vom Nullprodukt” german math rap video.")

#text("Honestly I couldnt believe that it was linked here. This is a great honor for me! Thank you so much! 🙏🏻")

#text("I will add some english subtitles asap.")

#text("As a teacher i felt responsible to create a different approach for my audience in the age of 16+. I try to mix good entertainment in modern HipHop Beats with education realized by mathematical Raps. In an anonymous online feedback one student wrote that he/she enjoys mathematics and having fun for the first time after 10 years of school.")

#text("Most of the students in school need some motivation in math and modern & entertaining music can help with that. I know that they hear my math song in their freetime as well. ;)")

#text("FYI: My next song will be released on Friday, 18th Feb. Title: Symmetry")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640683")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2022")])]

#text("[I don’t know why WordPress does not show my comment. Let me try one more time.]")

#text("You mentioned this one in a blogpost ")#link("https://terrytao.wordpress.com/2009/09/17/a-speech-for-the-american-academy-of-arts-and-sciences/")[#text("more than 10 year ago")]#text(": ")#link("https://www.youtube.com/watch?v=JX3VmDgiFnY&amp;t=10s&amp;ab_channel=jonathanrogness")[#text("Moebius Transformations Revealed")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640685")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2022")])]

#text("By the way, how are the viewpoints of the mentioned speech evolved over the years? :-)")

#text("Recently, there have been videos from ")#link("https://www.3blue1brown.com/")[#text("3Blue1Brown")]#text(".")

#text("And your friend Charlie Fefferman’s talks about ")#link("https://www.youtube.com/watch?v=Jwtn5_d2YCs&ab_channel=Numberphile")[#text(" infinite series")]#text(" and ")#link("https://www.youtube.com/watch?v=j-dce6QmVAQ&t=313s&ab_channel=Numberphile")[#text("the Kakeya’s Needle problem")]#text(" on Numberphile.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640686")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2022")])]

#text("And your talk on Numberphile about ")#link("https://www.youtube.com/watch?v=48Hr3CT5Tpk&ab_channel=Numberphile2")[#text("‘Cheating Strategically’")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640687")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2022")])]

#text("And your talk about ")#link("https://www.youtube.com/watch?v=48Hr3CT5Tpk&ab_channel=Numberphile2")[#text("‘Cheating Strategically’")]#text(" on Numberphile.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640695")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2022")])]

#text("It seems that the examples above (by Charlie Fefferman and the Mobius one) are not of “unconventional modalities” though.")

#text("Do you think unconventional modalities are always possible for presenting mathematics at any level? What in general would you classify as conventional?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640688")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2022")])]

#text("I’ve written a freestyle a while ago about S1 as a complex manifold but the wordplay was too vague so I disregarded it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2022")])]

#text("Maybe because ")#mi("S^1")#text(" isn’t a complex manifold")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-642965")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2022")])]

#text("What isnt a complex manifold? S1?")

#text("What. Did I miss something?")

#text("You can properly embed it into C with a smooth, not even just smooth, but holomorphic atlas.")

#text("Get tf o.")

#text("I need harder questions than this.")

#text("Okay you’re going to ask me which function then.")

#text("And I say the exponential function.")

#text("Qed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-642980")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2022")])]

#text("There is no injective analytic map from S^1 to the disc. Maybe you’re thinking of S^2.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-642996")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2022")])]

#text("S1 is a complex manifold. That’s the point I’m trying to make. Also what disc are you talking about and how is it related?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-642997")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2022")])]

#text("Oh I read about the neighborhoods required for local homemomorphsm and I see what you mean by D now. But I can see S1 properly embedded in C so how is it not a manifold? I can use the level sets of…")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640740")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2022")])]

#link("https://www.youtube.com/channel/UCIqiLefbVHsOAXDAxQJH7Xw")[#text("https://www.youtube.com/channel/UCIqiLefbVHsOAXDAxQJH7Xw")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2022")])]

#linebreak()#text(" Eulers number is irrational – proof & song")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/905d6364a317868f21b78206d17960492ed8fa7bdf16a70cfcc70208af6074db-81b249a619372c3bb4542f081eaf2c7fd00955cf685e27b9ec6f23b3c37066ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Swag Eagle")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640770")[#strong[#text("Swag Eagle")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2022")])]

#text("“Finite simple group of order 2” is epic but maybe not in the scope of what you are looking for. I presume, however, that what follows is in the scope (in French):")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2022")])]

#text("The rap video has been removed:")

#emph[#linebreak()#text(" Video unavailable")#linebreak()#text(" This video is no longer available because the YouTube account associated with this video has been terminated.")#linebreak()#text(" ")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd608080498321c51bfe4a5f11126d8201b0e69f0ed037341cc81b79d48877df-d40da6d65e79cfbcb7d873223c679469ac7e52aa7630741bf38ba63a7fde749e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Th3o_r∈M")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640820")[#strong[#text("Th3o_r∈M")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2022")])]

#text("I am working at the issue of the removed Rap video. I will inform you when it is back online. In the worst case i will send a new link.. But hopefully it will work in a little while.")

#text("Kind regards")#linebreak()#text(" Th3o_r∈M")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d315c6460407102ca37906907d974ec122d076b3d27e0e33cea47ff31b99406-4952b96583752331ddac3936914ff457da4e90071332d6b7d84478915e3a3e4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Th3o_r∈M")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640824")[#strong[#text("Th3o_r∈M")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2022")])]

#text("Update:")#linebreak()#text(" The linked Rap Video is online again.")

#text("The Youtube Team apologize for making a mistake here. Also from my side: I am sorry for the inconvenience.")

#text("If you like you can also check my website. I will release some teaching materials that will be useful for students to develop the topics with my Rap musicvideos. (Some teachers worked already successfully with my music videos.)")

#text("My next math rap song is already recorded and will be released in 4 weeks.")

#text("Thank you for your support. <3")

#text("Kind regards")#linebreak()#text(" Th3o_r∈M")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2022")])]

#text("Will the ICM 2022 still going to happen in Russia?")

#emph[#text("[As per ")#link("https://www.mathunion.org/fileadmin/IMU/Publications/CircularLetters/2022/IMU%20AO%20CL%204_2022.pdf")[#text("this notification")]#text(", there will be a formal announcement about this by the IMU shortly. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2022")])]

#text("Why keep defaulting to these one-off songs? They take")#linebreak()#text(" up so much time and effort to come up yet they barely")#linebreak()#text(" explain one little concept.")

#text("All of these are just “cute” ways to help students remember.")#linebreak()#text(" They don’t foster any understanding of the underlying concept.")

#text("Instead of coming up with ad-hoc attempts, a better way to captivate students would be the following.")

#text("1) Instructors of advanced math courses are really good")#linebreak()#text(" at putting students in the “weeds.” Give them")#linebreak()#text(" a birds eye view of what math can do in neighboring")#linebreak()#text(" fields. (Using Freeman Dyson’s analogy here.)")

#text("2) Interweave lessons with storie and history.")#linebreak()#text(" Math is developed by real people with real stories.")#linebreak()#text(" They serve as good anchor points and they will remember better.")

#text("Turn math into stories, not lessons.")

#text("3) How about some zest when teaching?")#linebreak()#text(" Some educators have as much enthusiasm as Walmart")#linebreak()#text(" employees. Eddie Woo at Youtube is great because he’s so damn")#linebreak()#text(" enthusiastic!")

#text("His channel here: ")#link("https://www.youtube.com/c/misterwootube")[#text("https://www.youtube.com/c/misterwootube")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640993")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2022")])]

#text("Professor Tao，")#linebreak()#text(" can we use mathmetic method to demonstrate that WE DON’T KNOW SOME PARTICULAR INFORMATION？")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-640998")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2022")])]

#text("This is not how mathematics work. Just use your reasoning: how do we know what we don’t know?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-641023")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2022")])]

#text("For instance by showing that certain proposition is undecidable in some given axiomatic system (e.g. the continuum hypothesis was shown by Godel and Cohen to be independent, and consequently undecidable in the standard ZFC axiomatic set theory)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-641482")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2022")])]

#text("I think you know this, but since nobody mentioned: there is a nice weblog called “Math with bad drawings”, although it doesn’t teach anything new but it gives a fun way of looking at known things; I wonder why you haven’t put it up, even though it is mentioned in your blog-roll column.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0eb42b0243d9d6e97a90eeee607e015e28b6c82c7ff503398e9ba061d762f7a-90bb3e0f8854cf5b80f21f3e3234347e8d4c9d1aadbf48675b8630de5fdb9707.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph O'Rourke")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-642240")[#strong[#text("Joseph O'Rourke")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2022")])]

#text("Matt Parker (Stand-Up Maths) makes consistently informative videos. Here’s one that touched on my work, which he entitled “How many 3D nets does a 4D hypercube have?”: ")#link("https://www.youtube.com/watch?v=Yq3P-LhlcQo")[#text("https://www.youtube.com/watch?v=Yq3P-LhlcQo")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-644874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2022")])]

#text("Everyone have a look at this music video, on a great mathematician.:")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/14/satz-vom-nullprodukt/#comment-644907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2022")])]

#text("This is vulgar.")
]
]
