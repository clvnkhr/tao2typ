// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/
// Converted to Typst by tao2typ: "2026-10-14T16:36:15.247928+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Golden-Thompson inequality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Golden-Thompson inequality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 July 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/")[#text("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{A, B}")#text(" be two Hermitian ")#mi("{n \\times n}")#text(" matrices. When ")#mi("{A}")#text(" and ")#mi("{B}")#text(" commute, we have the identity")

#align(center)[#tao-fit-display[#mitex("e^{A+B} = e^A e^B.")]]

#text("When ")#mi("{A}")#text(" and ")#mi("{B}")#text(" do not commute, the situation is more complicated; we have the ")#emph[#text("Baker-Campbell-Hausdorff formula")]

#align(center)[#tao-fit-display[#mitex("e^{A+B} = e^A e^B e^{-\\frac{1}{2}[A,B]} \\ldots")]]

#text("where the infinite product here is explicit but very messy. On the other hand, taking determinants we still have the identity")

#align(center)[#tao-fit-display[#mitex("\\text{det}(e^{A+B}) = \\text{det}(e^A e^B).")]]

#text("Recently I learned (from Emmanuel Candes, who in turn learned it from David Gross) that there is another very nice relationship between ")#mi("{e^{A+B}}")#text(" and ")#mi("{e^A e^B}")#text(", namely the ")#link("http://en.wikipedia.org/wiki/Golden%E2%80%93Thompson_inequality")[#text("Golden-Thompson inequality")]#text(" ")#metadata(none) <tao-f0fa3f464eef13075708>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\text{tr}(e^{A+B}) \\leq \\text{tr}(e^A e^B).")]]

#text("The remarkable thing about this inequality is that no commutativity hypotheses whatsoever on the matrices ")#mi("{A, B}")#text(" are required. Note that the right-hand side can be rearranged using the cyclic property of trace as ")#mi("{\\text{tr}( e^{B/2} e^A e^{B/2} )}")#text("; the expression inside the trace is positive definite so the right-hand side is positive. (On the other hand, there is no reason why expressions such as ")#mi("{\\text{tr}(e^A e^B e^C)}")#text(" need to be positive or even real, so the obvious extension of the Golden-Thompson inequality to three or more Hermitian matrices fails.) I am told that this inequality is quite useful in statistical mechanics, although I do not know the details of this.")#linebreak()#text(" To get a sense of how delicate the Golden-Thompson inequality is, let us expand both sides to fourth order in ")#mi("{A, B}")#text(". The left-hand side expands as")

#tao-aligned(keep: true)[


#tao-math("\\text{tr} 1  & + \\text{tr} (A+B) + \\frac{1}{2} \\text{tr} (A^2 + AB + BA + B^2) + \\frac{1}{6} \\text{tr} (A+B)^3", block: true)



#tao-math(" & + \\frac{1}{24} \\text{tr} (A+B)^4 + \\ldots", block: true)
]

#text("while the right-hand side expands as")

#tao-aligned(keep: true)[


#tao-math("\\text{tr} 1  & + \\text{tr} (A+B) + \\frac{1}{2} \\text{tr} (A^2 + 2AB + B^2)", block: true)



#tao-math(" & + \\frac{1}{6} \\text{tr} (A^3 + 3A^2 B + 3 A B^2+B^3) +", block: true)



#tao-math("\\frac{1}{24} \\text{tr} (A^4 + 4 A^3 B + 6 A^2 B^2 + 4 A B^3 +B^4)  & + \\ldots", block: true)
]

#text("Using the cyclic property of trace ")#mi("{\\text{tr}(AB) = \\text{tr}(BA)}")#text(", one can verify that all terms up to third order agree. Turning to the fourth order terms, one sees after expanding out ")#mi("{(A+B)^4}")#text(" and using the cyclic property of trace as much as possible, we see that the fourth order terms ")#emph[#text("almost")]#text(" agree, but the left-hand side contains a term ")#mi("{\\frac{1}{12} \\text{tr}(ABAB)}")#text(" whose counterpart on the right-hand side is ")#mi("{\\frac{1}{12} \\text{tr}(ABBA)}")#text(". The difference between the two can be factorised (again using the cyclic property of trace) as ")#mi("{-\\frac{1}{24} \\text{tr} [A,B]^2}")#text(". Since ")#mi("{[A,B] := AB-BA}")#text(" is skew-Hermitian, ")#mi("{-[A,B]^2}")#text(" is positive definite, and so we have proven the Golden-Thompson inequality to fourth order. (One could also have used the Cauchy-Schwarz inequality for the Frobenius norm to establish this; see below.)")#linebreak()#text(" Intuitively, the Golden-Thompson inequality is asserting that interactions between a pair ")#mi("{A, B}")#text(" of non-commuting Hermitian matrices are strongest when cross-interactions are kept to a minimum, so that all the ")#mi("{A}")#text(" factors lie on one side of a product and all the ")#mi("{B}")#text(" factors lie on the other. Indeed, this theme will be running through the proof of this inequality, to which we now turn.")

#metadata(none) <tao-f4b0b4ad1d2bf377ef44>

#text("The proof of the Golden-Thompson inequality relies on the somewhat magical power of the ")#link("http://www.tricki.org/article/The_tensor_power_trick")[#text("tensor power trick")]#text(". For any even integer ")#mi("{p = 2,4,6,\\ldots}")#text(" and any ")#mi("{n \\times n}")#text(" matrix ")#mi("{A}")#text(" (not necessarily Hermitian), we define the ")#link("http://en.wikipedia.org/wiki/Schatten_norm")[#mi("{p}")#text("-Schatten norm ")#tao-math("{\\left\\|A\\right\\|_p}", block: false)]#text(" of ")#mi("{A}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A \\right\\|_p := (\\text{tr}(AA^*)^{p/2})^{1/p}.", block: true)]]

#text("(This formula in fact defines a norm for any ")#mi("{p \\geq 1}")#text(", but we will only need the even integer case here.) This norm can be viewed as a non-commutative analogue of the ")#mi("{\\ell^p}")#text(" norm; indeed, the ")#mi("{p}")#text("-Schatten norm of a ")#emph[#text("diagonal")]#text(" matrix is just the ")#mi("{\\ell^p}")#text(" norm of the coefficients.")#linebreak()#text(" Note that the ")#mi("{2}")#text("-Schatten norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A\\right\\|_2 := (\\text{tr}(AA^*))^{1/2}", block: true)]]

#text("is the Hilbert space norm associated to the ")#link("http://en.wikipedia.org/wiki/Matrix_norm#Frobenius_norm")[#text("Frobenius inner product")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Hilbert%E2%80%93Schmidt_operator")[#text("Hilbert-Schmidt inner product")]#text(")")

#align(center)[#tao-fit-display[#mitex("\\langle A, B \\rangle := \\text{tr}(A B^*).")]]

#text("This is clearly a non-negative Hermitian inner product, so by the Cauchy-Schwarz inequality we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\text{tr}(A_1 A_2^*)\\right| \\leq \\left\\| A_1 \\right\\|_2 \\left\\|A_2\\right\\|_2", block: true)]]

#text("for any ")#mi("{n \\times n}")#text(" matrices ")#mi("{A_1, A_2}")#text(". As ")#tao-math("{\\left\\|A_2\\right\\|_2 = \\left\\|A_2^*\\right\\|_2}", block: false)#text(", we conclude in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\text{tr}(A_1 A_2)\\right| \\leq \\left\\| A_1 \\right\\|_2 \\left\\|A_2\\right\\|_2", block: true)]]

#text("We can iterate this and establish the ")#emph[#text("non-commutative Hölder inequality")]#text(" ")#metadata(none) <tao-ae5b8014f0f82047cfd9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\text{tr}(A_1 A_2 \\ldots A_p)\\right| \\leq \\left\\| A_1 \\right\\|_p \\left\\|A_2\\right\\|_p \\ldots \\left\\|A_p\\right\\|_p", block: true)]]

#linebreak()#text(" ")#text(" whenever ")#mi("{p=2,4,8,\\ldots}")#text(" is an even power of ")#mi("{2}")#text(". Indeed, we induct on ")#mi("{p}")#text(", the case ")#mi("{p=2}")#text(" already having been established. If ")#mi("{p \\geq 4}")#text(" is a power of ")#mi("{2}")#text(", then by the induction hypothesis (grouping ")#mi("{A_1 \\ldots A_p}")#text(" into ")#mi("{p/2}")#text(" pairs) we can bound ")#metadata(none) <tao-27abb1b53f5c1b18202d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\text{tr}(A_1 A_2 \\ldots A_p)\\right| \\leq \\left\\| A_1 A_2 \\right\\|_{p/2} \\left\\|A_3 A_4\\right\\|_{p/2} \\ldots \\left\\|A_{p-1} A_p\\right\\|_{p/2}.", block: true)]]

#text("On the other hand, we may expand")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A_1 A_2\\right\\|_{p/2}^{p/2} = \\text{tr} A_1 A_2 A_2^* A_1^* \\ldots A_1 A_2 A_2^* A_1^*.", block: true)]]

#text("We use the cyclic property of trace to move the rightmost ")#mi("{A_1^*}")#text(" factor to the left. Applying the induction hypothesis again, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A_1 A_2\\right\\|_{p/2}^{p/2} \\leq \\left\\| A_1^* A_1 \\right\\|_{p/2} \\left\\|A_2 A_2^*\\right\\|_{p/2} \\ldots \\left\\| A_1^* A_1 \\right\\|_{p/2} \\left\\| A_2 A_2^* \\right\\|_{p/2}.", block: true)]]

#text("But from the cyclic property of trace again, we have ")#tao-math("{\\left\\| A_1^* A_1 \\right\\|_{p/2} = \\left\\|A_1\\right\\|_p^2}", block: false)#text(" and ")#tao-math("{\\left\\| A_2 A_2^* \\right\\|_{p/2} = \\left\\|A_2\\right\\|_p^2}", block: false)#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A_1 A_2 \\right\\|_{p/2} \\leq \\left\\|A_1\\right\\|_p \\left\\|A_2\\right\\|_p", block: true)]]

#text("and similarly for ")#tao-math("{\\left\\|A_3 A_4\\right\\|_{p/2}}", block: false)#text(", etc. Inserting this into ")#link(<tao-27abb1b53f5c1b18202d>)[#text("(3)")]#text(" we obtain ")#link(<tao-ae5b8014f0f82047cfd9>)[#text("(2)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Though we will not need to do so here, it is interesting to note that one can use the tensor power trick to amplify ")#link(<tao-ae5b8014f0f82047cfd9>)[#text("(2)")]#text(" for ")#mi("{p}")#text(" equal to a power of two, to obtain ")#link(<tao-ae5b8014f0f82047cfd9>)[#text("(2)")]#text(" for all positive integers ")#mi("{p}")#text(", at least when the ")#mi("{A_i}")#text(" are all Hermitian. Indeed, pick a large integer ")#mi("{m}")#text(" and let ")#mi("{N}")#text(" be the integer part of ")#mi("{2^m/p}")#text(". Then expand the left-hand side of ")#link(<tao-ae5b8014f0f82047cfd9>)[#text("(2)")]#text(" as ")#mi("{\\text{tr}( A_1^{1/N} \\ldots A_1^{1/N} A_2^{1/N} \\ldots A_p^{1/N} \\ldots A_p^{1/N} )}")#text(" and apply ")#link(<tao-ae5b8014f0f82047cfd9>)[#text("(2)")]#text(" with ")#mi("{p}")#text(" replaced by ")#mi("{2^m}")#text(" to bound this by ")#tao-math("{\\left\\| A_1^{1/N} \\right\\|_{2^m}^N \\ldots \\left\\|A_p^{1/N}\\right\\|_{2^m}^N \\left\\| 1 \\right\\|_{2^m}^{2^m-pN}}", block: false)#text(". Sending ")#mi("{m \\rightarrow \\infty}")#text(" (noting that ")#mi("{2^m = (1+o(1)) Np}")#text(") we obtain the claim.")
]

#text("Specialising ")#link(<tao-ae5b8014f0f82047cfd9>)[#text("(2)")]#text(" to the case where ")#mi("{A_1=\\ldots=A_p = AB}")#text(" for some Hermitian matrices ")#mi("{A, B}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\text{tr}( (AB)^{p} ) \\leq \\left\\| AB \\right\\|_p^p", block: true)]]

#text("and hence by cyclic permutation")

#align(center)[#tao-fit-display[#mitex("\\text{tr}( (AB)^{p} ) \\leq \\text{tr}( (A^2 B^2)^{p/2} )")]]

#text("for any ")#mi("{p = 2,4,\\ldots}")#text(". Iterating this we conclude that ")#metadata(none) <tao-10b640c87169f4f02bf2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\text{tr}( (AB)^{p} ) \\leq \\text{tr}( A^p B^p ).")]]

#text("Applying this with ")#mi("{A, B}")#text(" replaced by ")#mi("{e^{A/p}}")#text(" and ")#mi("{e^{B/p}}")#text(" respectively, we obtain")

#align(center)[#tao-fit-display[#mitex("\\text{tr}( (e^{A/p} e^{B/p})^{p} ) \\leq \\text{tr}( e^A e^B ).")]]

#text("Now we send ")#mi("{p \\rightarrow \\infty}")#text(". Since ")#mi("{e^{A/p} = 1 + A/p + O(1/p^2)}")#text(" and ")#mi("{e^{B/p} = 1 + B/p + O(1/p^2)}")#text(", we have ")#mi("{e^{A/p} e^{B/p} = e^{(A+B)/p + O(1/p^2)}}")#text(", and so the left-hand side is ")#mi("{\\text{tr}( e^{A+B + O(1/p)} )}")#text("; taking the limit as ")#mi("{p \\rightarrow \\infty}")#text(" we obtain the Golden-Thompson inequality. (See also these ")#link("http://www-personal.umich.edu/~romanv/teaching/reading-group/golden-thompson.pdf")[#text("notes of Vershynin")]#text(" for a slight variant of this proof.)")#linebreak()#text(" If we stop the iteration at an earlier point, then the same argument gives the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e^{A+B} \\right\\|_p \\leq \\left\\| e^A e^B \\right\\|_p", block: true)]]

#text("for ")#mi("{p=2,4,8,\\ldots}")#text(" a power of two; one can view the original Golden-Thompson inequality as the ")#mi("{p=1}")#text(" endpoint of this case in some sense. (In fact, the Golden-Thompson inequality is true in any operator norm; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1477662")[#text("Theorem 9.3.7 of Bhatia’s book")]#text(".) In the limit ")#mi("{p \\rightarrow \\infty}")#text(", we obtain in particular the operator norm inequality ")#metadata(none) <tao-b8e8b4ab3ae79840ef68>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| e^{A+B} \\right\\|_{op} \\leq \\left\\| e^A e^B \\right\\|_{op}", block: true)]]

#text("This inequality has a nice consequence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" ")#metadata(none) <tao-818788f1be5d134d223d>#text(" Let ")#mi("{A, B}")#text(" be Hermitian matrices. If ")#mi("{e^A \\leq e^B}")#text(" (i.e. ")#mi("{e^B-e^A}")#text(" is positive semi-definite), then ")#mi("{A \\leq B}")#text(".")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{e^A \\leq e^B}")#text(", we have ")#mi("{\\langle e^A x, x \\rangle \\leq \\langle e^B x, x \\rangle}")#text(" for all vectors ")#mi("{x}")#text(", or in other words ")#tao-math("{\\left\\|e^{A/2} x \\right\\| \\leq \\left\\| e^{B/2} x \\right\\|}", block: false)#text(" for all ")#mi("{x}")#text(". This implies that ")#mi("{e^{A/2} e^{-B/2}}")#text(" is a contraction, i.e. ")#tao-math("{\\left\\|e^{A/2} e^{-B/2} \\right\\|_{op} \\leq 1}", block: false)#text(". By ")#link(<tao-b8e8b4ab3ae79840ef68>)[#text("(5)")]#text(", we conclude that ")#tao-math("{\\left\\|e^{(A-B)/2}\\right\\|_{op} \\leq 1}", block: false)#text(", thus ")#mi("{(A-B)/2 \\leq 0}")#text(", and the claim follows. ")#mi("\\Box")

#text("It is not difficult to reverse the above argument and conclude that ")#link(<tao-818788f1be5d134d223d>)[#text("(2)")]#text(" is in fact equivalent to ")#link(<tao-b8e8b4ab3ae79840ef68>)[#text("(5)")]#text(".")

#text("It is remarkably tricky to try to prove Corollary ")#link(<tao-818788f1be5d134d223d>)[#text("2")]#text(" directly. Here is a somewhat messy proof; I would be interested in seeing a more elegant argument. By the fundamental theorem of calculus, it suffices to show that whenever ")#mi("{A(t)}")#text(" is a Hermitian matrix depending smoothly on a real parameter with ")#mi("{\\frac{d}{dt} e^{A(t)} \\geq 0}")#text(", then ")#mi("{\\frac{d}{dt} A(t) \\geq 0}")#text(". Indeed, Corollary ")#link(<tao-818788f1be5d134d223d>)[#text("2")]#text(" follows from this claim by setting ")#mi("{A(t) := \\log(e^A + t (e^B - e^A))}")#text(" and concluding that ")#mi("{A(1) \\geq A(0)}")#text(".")

#text("To obtain this claim, we use the ")#emph[#text("Duhamel formula")]

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} e^{A(t)} = \\int_0^1 e^{(1-s)A(t)} (\\frac{d}{dt} A(t)) e^{sA(t)}\\ ds.")]]

#text("This formula can be proven by Taylor expansion, or by carefully approximating ")#mi("{e^{A(t)}}")#text(" by ")#mi("{(1 + A(t)/N)^N}")#text("; alternatively, one can integrate the identity")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial s}( e^{-sA(t)} \\frac{\\partial }{\\partial t} e^{sA(t)} ) = e^{-sA(t)} (\\frac{\\partial}{\\partial t} A(t)) e^{sA(t)}")]]

#text("which follows from the product rule and by interchanging the ")#mi("{s}")#text(" and ")#mi("{t}")#text(" derivatives at a key juncture. We rearrange the Duhamel formula as")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} e^{A(t)} = e^{A(t)/2} (\\int_{-1/2}^{1/2} e^{sA(t)} (\\frac{d}{dt} A(t)) e^{-sA(t)}\\ ds) e^{A(t)/2}.")]]

#text("Using the basic identity ")#mi("{e^A B e^{-A} = e^{\\text{ad}(A)} B}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} e^{A(t)} = e^{A(t)/2} [(\\int_{-1/2}^{1/2} e^{s \\text{ad}(A(t))}\\ ds) (\\frac{d}{dt} A(t))] e^{A(t)/2};")]]

#text("formally evaluating the integral, we obtain")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} e^{A(t)} = e^{A(t)/2} [\\frac{\\sinh(\\text{ad}(A(t))/2)}{\\text{ad}(A(t))/2} (\\frac{d}{dt} A(t))] e^{A(t)/2},")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} A(t) = \\frac{\\text{ad}(A(t))/2}{\\sinh(\\text{ad}(A(t))/2)} ( e^{-A(t)/2} (\\frac{d}{dt} e^{A(t)}) e^{-A(t)/2} ).")]]

#text("As ")#mi("{\\frac{d}{dt} e^{A(t)}}")#text(" was positive semi-definite by hypothesis, ")#mi("{e^{-A(t)/2} (\\frac{d}{dt} e^{A(t)}) e^{-A(t)/2}}")#text(" is also. It thus suffices to show that for any Hermitian ")#mi("{A}")#text(", the operator ")#mi("{\\frac{\\text{ad}(A)}{\\sinh(\\text{ad}(A))}}")#text(" preserves the property of being semi-definite.")#linebreak()#text(" Note that for any real ")#mi("{\\xi}")#text(", the operator ")#mi("{e^{2\\pi i \\xi \\text{ad}(A)}}")#text(" maps a positive semi-definite matrix ")#mi("{B}")#text(" to another positive semi-definite matrix, namely ")#mi("{e^{2\\pi i \\xi A} B e^{-2\\pi i \\xi A}}")#text(". By the Fourier inversion formula, it thus suffices to show that the kernel ")#mi("{F(x) := \\frac{x}{\\sinh(x)}}")#text(" is positive semi-definite in the sense that it has non-negative Fourier transform (cf. Bochner’s theorem). But a routine (but somewhat tedious) application of contour integration shows that the Fourier transform ")#mi("{\\hat F(\\xi) = \\int_{\\bf R} e^{-2\\pi i x \\xi} F(x)\\ dx}")#text(" is given by the formula ")#mi("{\\hat F(\\xi) = \\frac{1}{8 \\cosh^2( \\pi^2 \\xi)}}")#text(", and the claim follows.")

#text("Because of the Golden-Thompson inequality, many applications of the ")#emph[#text("exponential moment method")]#text(" in commutative probability theory can be extended without difficulty to the non-commutative case, as was observed by Ahlswede and Winter. For instance, consider (a special case of) the ")#emph[#text("Chernoff inequality")]

#align(center)[#tao-fit-display[#mitex("{\\bf P}( X_1 + \\ldots + X_N \\geq \\lambda \\sigma ) \\leq \\max( e^{-\\lambda^2/4}, e^{-\\lambda \\sigma / 2} )")]]

#text("for any ")#mi("{\\lambda > 0}")#text(", where ")#mi("{X_1,\\ldots,X_n \\equiv X}")#text(" are iid scalar random variables taking values in ")#mi("{[-1,1]}")#text(" of mean zero and with total variance ")#mi("{\\sigma^2}")#text(" (i.e. each factor has variance ")#mi("{\\sigma^2/N}")#text("). We briefly sketch the standard proof of this inequality. We first use Markov’s inequality to obtain")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( X_1 + \\ldots + X_N \\geq \\lambda \\sigma ) \\leq e^{-t\\lambda \\sigma } {\\bf E} e^{t(X_1 + \\ldots + X_N)}")]]

#text("for some parameter ")#mi("{t>0}")#text(" to be optimised later. In the scalar case, we can factor ")#mi("{e^{t(X_1+\\ldots+X_N)}}")#text(" as ")#mi("{e^{tX_1} \\ldots e^{tX_N}}")#text(" and then use the iid hypothesis to write the right-hand side as")

#align(center)[#tao-fit-display[#mitex("e^{-t\\lambda \\sigma } ( {\\bf E} e^{tX} )^N.")]]

#text("An elementary Taylor series computation then reveals the bound ")#mi("{{\\bf E} e^{tX} \\leq \\exp( t^2 \\sigma^2 / N )}")#text(" when ")#mi("{0 \\leq t \\leq 1}")#text("; inserting this bound and optimising in ")#mi("{t}")#text(" we obtain the claim.")#linebreak()#text(" Now suppose that ")#mi("{X_1,\\ldots,X_n \\equiv X}")#text(" are iid ")#mi("{d \\times d}")#text(" Hermitian matrices. One can try to adapt the above method to control the size of the sum ")#mi("{X_1 + \\ldots + X_N}")#text(". The key point is then to bound expressions such as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr} e^{t(X_1 + \\ldots + X_N)}.")]]

#text("As ")#mi("{X_1,\\ldots,X_N}")#text(" need not commute, we cannot separate the product completely. But by Golden-Thompson, we can bound this expression by")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr} e^{t(X_1 + \\ldots + X_{N-1})} e^{tX_n}")]]

#text("which by independence we can then factorise as")

#align(center)[#tao-fit-display[#mitex("\\text{tr} ({\\bf E} e^{t(X_1 + \\ldots + X_{N-1})}) ({\\bf E} e^{tX_n}).")]]

#text("As the matrices involved are positive definite, we can then take out the final factor in operator norm:")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\bf E} e^{tX_n} \\right\\|_{op} \\text{tr} {\\bf E} e^{t(X_1 + \\ldots + X_{N-1})}.", block: true)]]

#text("Iterating this procedure, we can eventually obtain the bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\text{tr} e^{t(X_1 + \\ldots + X_N)} \\leq \\left\\| {\\bf E} e^{tX} \\right\\|_{op}^N.", block: true)]]

#text("Combining this with the rest of the Chernoff inequality argument, we can establish a matrix generalisation")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left\\| X_1 + \\ldots + X_N \\right\\|_{op} \\geq \\lambda \\sigma ) \\leq n \\max( e^{-\\lambda^2/4}, e^{-\\lambda \\sigma / 2} )", block: true)]]

#text("of the Chernoff inequality, under the assumption that the ")#mi("{X_1,\\ldots,X_N}")#text(" are iid with mean zero, have operator norm bounded by ")#mi("{1}")#text(", and have total variance ")#tao-math("{\\sum_{i=1}^n \\left\\| {\\bf E} X_i^2 \\right\\|_{op}}", block: false)#text(" equal to ")#mi("{\\sigma^2}")#text("; see for instance these ")#link("http://www-personal.umich.edu/~romanv/teaching/reading-group/ahlswede-winter.pdf")[#text("notes of Vershynin")]#text(" for details.")#linebreak()#text(" Further discussion of the use of the Golden-Thompson inequality and its variants to non-commutative Chernoff-type inequalities can be found in ")#link("http://arxiv.org/abs/0910.1879")[#text("this paper of Gross")]#text(", these ")#link("http://www-personal.umich.edu/~romanv/teaching/reading-group/ahlswede-winter.pdf")[#text("notes of Vershynin")]#text(" and this ")#link("http://arxiv.org/abs/1004.4389")[#text("recent article of Tropp")]#text(". It seems that the use of this inequality may be quite useful in simplifying the proofs of several of the basic estimates in this subject.")

#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46011")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("There’s a beautiful related result, due to Thompson, stating that when A and B are Hermitian, e^A e^B = e^{U A U^\\dagger +V B V^\\dagger}, where U and V are unitary. My memory of the proof is very hazy, but I believe it relies on Horn’s conjecture, which, of course, wasn’t proved until some years later.")

#text("See: R. C. Thompson, Linear and Multilinear Algebra 19, 187 (1986).")

#text("This result has some applications in quantum computing: ")#link("http://arxiv.org/abs/quant-ph/0307190")[#text("http://arxiv.org/abs/quant-ph/0307190")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46013")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("I believe Corollary 1 has a straightforward proof. Start by observing that it is equivalent to proving that the log function is operator monotone, i.e., A \\leq B implies ln(A) \\leq \\ln(B) where A and B are positive definite.")

#text("There are two ideas we need: (1) the observation that the function, A -> -A^{-1} is operator monotone, when A is positive definite; and (2) an integral representation for the log function.")

#text("The proof of (1) can easily be supplied by elementary techniques. For (2), a suitable integral representation is:")

#text("\\ln(A) = \\int_0^1 dy / (y+(A-I)^{-1})")

#text("Assuming A \\leq B we can applying (1) twice to obtain 1/(y+(A-I)^{-1}) \\leq 1/(y+(B-I)^{-1}). The result then follows.")

#text("There is something wrong with this proof: (A-I) may be singular, and so the the integral representation may not exist. This can be fixed by perturbing A slightly and using a continuity argument. However, I suspect that with a slightly different integral representation that won’t be necessary. I don’t have time to fiddle with it now, unfortunately…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46014")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("Ah, that is a nice argument! I had forgotten that ")#mi("A \\mapsto A^{-1}")#text(" reverses the positive definite ordering, that is certainly a useful thing to keep in mind. (I was relying instead on the fact that ")#mi("A \\mapsto B A B^*")#text(" preserves positive definiteness, but this was significantly trickier to use.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46015")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("I have a vague memory that there may even be a representation theorem for operator monotone functions in terms of integrals over inverse functions. That’s why I tried this strategy. Bhatia is most likely where I saw the result. My copy is in storage, so I can’t look it up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46111")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2010")])]

#text("It’s bothering me that (A-I) may not be invertible, and even if it is, s+(A-I)^{-1} may not be. Anyone see a clean fix?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46112")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2010")])]

#text("It seems to me from the spectral theorem that there will not be an issue as long as the spectrum of A stays away from both 0 and 1, but this seems easy to ensure via a standard perturbation argument.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46113")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2010")])]

#text("If A is finite-dimensional a perturbation argument should work just fine. But if A has a spectrum dense in some interval around 0, say, then it will break down. In the context of the post (finite-dimensional matrices) I guess there’s no problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46114")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2010")])]

#text("I think there are a number of ways around this. For instance, one can first show that ")#mi("\\log(A+\\epsilon) \\leq \\log(B+\\epsilon)")#text(" for every ")#mi("\\epsilon > 0")#text(", and then take limits in, say, the weak operator topology. Now there is no spectrum near zero. There is still the issue of spectrum near 1, but if the operators are bounded then we can simply rescale them to have spectrum away from 1. If they are unbounded, then perhaps one can approximate them by bounded operators and take further limits.")

#text("It may also be possible to deduce the infinite dimensional case from the finite dimensional case by a suitable approximation argument. Certainly I would imagine the compact case would follow fairly easily in this fashion.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aa174104fef35bc1bac80e593405c8675a317adf59f457d32ab8e5e6dd17218-76ebe96909c7b7c253aaba98a3fb9ef62c529e334cd156ad4f8ab2fd4cfd74e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Davies")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46093")[#strong[#text("Brian Davies")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2010")])]

#text("There is a complete and simple classification of monotone matrix functions, due to Lowner in 1934. See for example")

#text("W. F. Donoghue, Monotone matrix functions and analytic continuation. Springer-Verlag, New York, Heidelberg, Berlin, 1974")

#text("or")

#text("G Sparr: Math. Scand 47 (1980) 266-274")

#text("for a short proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a356653f55422c1b906219a53ae3aa534db27c71ef0caef49383edc71330076d-72be8065908bf7be9d192e743893076a0c06dbd275ae525a20ac2a2df95689fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashley")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46018")[#strong[#text("Ashley")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("Very nice post! One typo fix: “Ashwelde and Winter” should be “Ahlswede and Winter”. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e5340c50694555e117870d91ecadd485800508013a67584fb84214d7e395cf-60483904cd0f109029fbd9362fc14b33c65f88f9f9b0a8e6669682293372dada.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Flammia")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46019")[#strong[#text("Steve Flammia")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("It might be worth mentioning that the naive generalization to three matrices,")#linebreak()#text(" Tr(e^{A+B+C}) \\le Tr(e^A e^B e^C)")#linebreak()#text(" is false in general. But there is a nice paper by Lieb with a nontrivial generalization:")#linebreak()#text(" E. Lieb, “Convex trace functions and the Wigner-Yanase-Dyson conjecture”, Advances in Mathematics, 11, 267–288 (1973).")#linebreak()#text(" (The generalization is at the bottom of page 282.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e5340c50694555e117870d91ecadd485800508013a67584fb84214d7e395cf-60483904cd0f109029fbd9362fc14b33c65f88f9f9b0a8e6669682293372dada.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sflammia")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-467733")[#strong[#text("sflammia")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2016")])]

#text("My colleague Marco Tomamichel and his coauthors just posted a very nice paper that further generalizes the Golden-Thompson inequality, as well as Lieb’s extension to three matrices. Their result holds for n matrices, in fact, and it might be of some interest to readers of this blog post.")#linebreak()#text(" ")#link("http://arxiv.org/abs/1604.03023")[#text("http://arxiv.org/abs/1604.03023")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b192f54eb6ebf73d528441a92dfa9ef04d58e741c4e924f3ba80e013ec161fbd-e00e90e06931c806a443166b45bc0d472fbac0fe6dc9860dfe9975dcd52cfb73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mick")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46020")[#strong[#text("mick")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("I second Ashley’s comment, a very nice post.")

#text("Also, I assume that the David Gross mentioned is the one that works in quantum information theory (ie the one that doesn’t have a Nobel prize)? More specifically, ")#link("http://www.itp.uni-hannover.de/~davidg/")[#text("this one")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46040")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2010")])]

#text("Prof. Tao,")

#text("Thanks for the great posts! Is the following comment correct?")

#text("“Since ")#mi("[A,B] := AB-BA")#text(" is skew-Hermitian, ")#mi("[A,B]^2")#text(" is positive definite…”")

#text("Try ")#mi("A =  \\left( \\begin{array}{cc} 0 & -i  \\\\ i & 0 \\end{array} \\right)")#text(" and ")#mi("B =  \\left( \\begin{array}{cc} 0 & 1  \\\\ 1 & 0 \\end{array} \\right)")#text(".")

#text("Then ")#mi("[A,B] = \\left( \\begin{array}{cc} -4 & 0  \\\\ 0 & -4 \\end{array} \\right)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46044")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2010")])]

#text("A factor of i is missing in your computation of the commutator [A,B].")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2010")])]

#text("Ha! Sorry, I had intended to write:")

#mi("[A,B]^2 = \\left( \\begin{array}{cc}           -4 & 0 \\\\ \t  0 & -4         \\end{array} \\right)")#text(",")

#text("which is not positive definite, but both A and B are hermitian.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46053")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2010")])]

#text("Ah, I see what happened now. Yes, there was a sign error in the original text, which has now been fixed.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6c878518c02880d25ba2fa68eec6883ac751c88202e991e7fa4cc843c625bb5-b1d56a7d71c04d3b165d2d8e8ec6846e68d848ea4d2a18b7d3e1f4321d037c03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46050")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2010")])]

#text("With the recent discussion of Cayley graphs in mind I can mention that Demetres Christofides and I used the methods of Ahlswede and Winter to prove a matrix version of Hoeffding’s concentration inequality for martingales, which we used to give an sharpened version of the Alon-Roichman theorem.")#linebreak()#text(" ")#link("http://dx.doi.org/10.1002/rsa.20177")[#text("http://dx.doi.org/10.1002/rsa.20177")]

#text("The Alon-Roichman theorem states that Cayley graphs based on a random subset of the group are likely to be expander graphs if the subset is large enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46074")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2010")])]

#text("What follows is an elementary proof of corollary 1 in the special case that ")#mi("A,\\;B")#text(" are commuting matrices. The proof uses the fact that the product of two positive definite, commuting matrices, is positive definite.")

#text("Consider the matrix valued function ")#mi("A(t)=\\log[(1-t)e^A+te^B]")#text(" defined for every ")#mi("0 \\leq t \\leq 1.")#text(" This function is differentiable and ")#mi("A^\\prime(t)=[(1-t)A+tB]^{-1} \\cdot (e^B-e^A)")#text(" is positive definite because it is the product of two positive definite commuting matrices. Finally, take a vector ")#mi("x \\in {\\bf {\\rm C}}^n")#text(" and apply the mean value theorem to find some real number ")#mi("0 < t < 1")#text(" such that ")#mi("( (B-A)x,x)=(A^{\\prime}(t)x,x) \\geq 0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46092")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2010")])]

#text("Your proof of corollary 1 in case ")#mi("A,B")#text(" commute does not need the Golden-Thompson inequality, because then ")#mi("e^{(A-B)/2}=e^{A/2}e^{-B/2}.")#text(" This is simpler than what I mentioned above.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7663d8948906281d3f582dcbc3ae50c1eb7ab745cd44bb184843546216e9e918-d4a5cc403dde2228bd0b2dfb3f51d81723ccca654fd3e4443e756bfd2acf7cd4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anders Karlsson")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46077")[#strong[#text("Anders Karlsson")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2010")])]

#text("Dear Terry,")

#text("These types of inequalities express that the exponential mapping (in the sense of differential geometry) is distance (semi)increasing, which is the source of nonpositive curvature for symmetric spaces of non-compact type. If I don’t misremember one version of the Golden-Thompson is used in one of the standard proofs (see Lang’s Fundamentals of Differential Geometry; going back to Mostow) that GLnR/OnR has nonpositive curvature.")

#text("I believe that the related inequality (5) for operators is called Segal’s inequality and is again a source of nonpositive curvature (in a weaker sense, because the tangent space is not a Hilbert space) for infinite dimensional symmetric spaces, see Gorach, G.; Porta, H.; Recht, L. A geometric interpretation of Segal’s inequality $\\Vert e^{X+Y}\\Vert \\leq\\Vert e^{X/2}e^Ye^{X/2}\\Vert $. Proc. Amer. Math. Soc. 115 (1992), no. 1, 229–231, and some of their other papers.")

#text("As always, thanks for an excellent blog,")#linebreak()#text(" Anders")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5026ddb1ee27783404a2d6a68d018592e1817047b086c9165d22f01303c3872-df4ad06b267cfc3945513b0e1ff1b0dc9ff92b48ab1db712cc764a8646a72f4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Denes PETZ")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46110")[#strong[#text("Denes PETZ")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2010")])]

#text("I proved in 1994 that equality in the Golden-Thompson inequality if and only if the two matrices commute. ( D. Petz, A survey of trace inequalities, in Functional Analysis and Operator Theory, 287-298, Banach Center Publications, 30 (Warszawa 1994). )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbb74cf57c1fa13e40abe80790d408ee33d56eaa5c1d708207db53d7e80dcba8-76030ea4accddab6ab0e9cba9004104b6db38c1cac22a8073fabd819e0c805cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of percy deift")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46265")[#strong[#text("percy deift")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2010")])]

#text("Dear Terry,")

#text("I have some comments regarding your blog on the Golden-Thompson inequalities that may")#linebreak()#text(" be of interest.")

#text("First one may ask the following quantum-mechanical-type question: For linear operators")#linebreak()#text(" ")#mi("A")#text(" and ")#mi("B")#text(",")

#text("if one “knows” ")#mi("AB")#text(", how much does one know about ")#mi("BA")#text(" ?")

#text("I believe that the best one can do is given by the following:")

#text("(1) ")#mi("spec(AB)/\\{0\\} = spec(BA)/\\{0\\}")

#text("with its quantitative version")

#text("(2) ")#mi("\\lambda(\\lambda + AB)^{-1} + A(\\lambda + BA)^{-1}B =1")

#text("(1)(2) have many and varied applications in scattering theory, spectral theory,")#linebreak()#text(" soliton theory, …( see e.g. my paper in the Duke Math Journal (1978) “On a commutation")#linebreak()#text(" formula”), and also random matrix theory. Over the last 30 years, every 2 or 3 months,")#linebreak()#text(" a new application of “commutation” seems to come up. ")#mi("A")#text(" and ")#mi("B")#text(" can even be unbounded")#linebreak()#text(" operators.")

#text("Here’s how it works for the simplest GT inequality")

#text("(3) ")#tao-math("\\  \\left|\\left|  \\ e^{A+B} \\right|\\right| \\le \\left|\\left|  \\ e^{A}e^{B} \\right|\\right|  .", block: false)

#text("I restrict to the bounded (self-adjoint) operator case for simplicity. Let ")#mi("r(T)")#text(" denote the spectral radius of an operator ")#mi("T")#text(" : we have")

#text("(4) ")#tao-math("\\   r(T) \\le \\left|\\left|\\  T \\right|\\right| .", block: false)

#text("Using self-adjointness, (4), commutation, and the fact that ")#tao-math("\\left|\\left| T^{*} T \\right|\\right|= \\left|\\left| T\\right|\\right|^{2}", block: false)#text(", we have")

#tao-math("\\ \\left|\\left| (e^{B/4}e^{A/2}e^{B/4}) ^{2}  \\right|\\right|  = \\left|\\left|  e^{B/4}e^{A/2}e^{B/4} \\right|\\right|^{2} = ( r( e^{B/4}e^{A/2}e^{B/4} ))^{2} = (r(e^{A/2}e^{B/2}))^{2}", block: false)

#tao-math("\\le \\left|\\left|e^{A/2}e^{B/2}\\right|\\right|^{2} = \\left|\\left| e^{B/2}e^{A}e^{B/2}\\right|\\right| = r(e^{A}e^{B}) \\le \\left|\\left|e^{A}e^{B}\\right|\\right| \\ .", block: false)

#text("Replacing ")#mi("A")#text(" with ")#mi("A/2^{n}")#text(", ")#mi("B")#text(" with ")#mi("B/2^{n}")#text(", and ")#mi("(...)^{2}")#text(" with ")#mi("(...)^{2^{n}}")#text(", shows that")

#tao-math("\\left|\\left| (e^{B/2^{n+1}}e^{A/2{n}}e^{B/2^{n+1}})^{2^{n}}\\right|\\right|", block: false)

#text("is decreasing with ")#mi("n")#text(". Inequality (3) now follows by the Trotter product formula.")

#text("A proof of")

#text("(5) ")#mi("\\ tr(e^{A+B}) \\le tr(e^{A}e^{B})")

#text("using commutation is in Reed-Simon IV. Whereas (3) only uses information about the top of the spectrum,")#linebreak()#text(" the commutation proof of (5) uses the fact that the (algebraic) multiplicity of an eigenvalue ")#mi("-\\lambda")#linebreak()#text(" of ")#mi("AB")#text(" is the same as the algebraic multiplicity of ")#mi("-\\lambda")#text(" in ")#mi("spec(BA)")#text(". This fact also follows from (2).")

#text("Concerning the result")

#mi("e^{A} \\le e^{B}")#text(" implies ")#mi("A \\le B")#text(" ,")

#text("it is clearly enough to show that")

#text("(5) ")#mi("e^{A} \\le e^{B}")#text(" implies ")#mi("e^{A/2} \\le e^{B/2}")

#text("But it is easy to see that if ")#mi("C\\le D")#text(" then for any real nonzero t,")

#mi("C/(C+t^{2}) \\le D/(D+t^{2})")

#text("which implies")

#mi("C^{1/2} = (\\pi)^{-1} \\int C/(C+t^{2}) dt \\le   (\\pi)^{-1} \\int D/(D+t^{2}) dt = D^{1/2} .")

#text("Setting ")#mi("C=e^{A}")#text(" and ")#mi("D=e^{B}")#text(", (5) is then immediate.")

#text("As regards 3 operators ")#mi("A,B,C")#text(", one notices that in the Ising model and other integrable models,")#linebreak()#text(" one always has at hand an extra relation of the type ")#mi("ABC=BAC")#text(". This implies by commutation that all")#linebreak()#text(" six of the permutations ")#mi("tr ABC = ...= tr ACB")#text(" are equal. I believe that this goes to the")#linebreak()#text(" heart of the success of the analysis of the Ising model etc., but I have not thought about this")#linebreak()#text(" for a while.")

#text("Best,")#linebreak()#text(" Percy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73d45f2642d34c99f337080864ac06099f0406b2374395f9e80de6ab13f175a4-870f3e9950c926c3c9f61566cc477093586761397780a94ae1446017e65de360.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Dr. Jaekel")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-46378")[#strong[#text("Christian Dr. Jaekel")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2010")])]

#text("Dear Prof. Tao,")

#text("I would like to point out a reference, that you might find helpful:")

#text("“Golden-Thompson and Peierls-Bogolubov inequalities for a general von Neumann algebra” by Huzihiro Araki, Comm. Math. Phys. Volume 34, Number 3 (1973), 167-178.”")

#text("Best regards,")#linebreak()#text(" Christian")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bc781c772192b2a4708d08787892eb0f8a87a381b7857ed085596dd26c968a8-b98111f6332120dee0e0590c6fe4342e8aa9b964970364cf5e93c236a5621175.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-47635")[#strong[#text("Igor Rivin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("For a very simple proof of the G/T inequality you might want to check out my recent arxiv.org preprint")#linebreak()#text(" ")#link("http://arxiv.org/abs/1010.2193")[#text("http://arxiv.org/abs/1010.2193")]#linebreak()#text(" part of the point of which is to give yet another plug for Chandler Davis’ convexity theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-47637")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("This is very beautiful, and seems like the “right” way of thinking about the result. It’s definitely a great plug for Davis’s convexity theorem, which makes G/T trivial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-517025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2019")])]

#text("What you are proving is the much weaker inequality ")#mi("\\mathrm{tr} \\exp(A + B) \\le \\mathrm{tr} \\exp A \\mathrm{tr} \\exp B")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Topics in random matrix theory « What’s new")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-50426")[#strong[#text("Topics in random matrix theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2011")])]

#text("[…] primarily on my graduate course in the topic, though it also contains material from some additional posts related to random matrices on the blog. It is available online here. As usual, comments and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0a33c8296686b05ce70d19fb2ddc1cdce31d5ff11efc76255ca575c027c8031-c27d4575e5f224c63c8e5eefee14bf76ea257d686108a61b36ecd7176d4d2f34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chao Gao")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-218105")[#strong[#text("Chao Gao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2013")])]

#text("Dear Prof. Tao:")

#text("I have a question about Frobenius norm. Let || . || be the Frobenius norm. Suppose both the largest eigenvalues of A and B are universally upper bounded. Then is it true that ||A-B|| can be upper and lower bounded by a constant (only depends on the largest eigenvalues of A and B) times ||exp(A)-exp(B)||?")

#text("Best,")#linebreak()#text(" Chao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Effros")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-391635")[#strong[#text("Effros")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2014")])]

#text("Frank Hansen has proved a multivariable version of the Golden-Thompson inequality see the Arxiv.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-458081")[#strong[#text("On the Chernoff bound | Triforce Studio")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2015")]

#text("[…] EDIT: I found out the simple answer to this question in a nice blogpost by Terry Tao: ")#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/")[#text("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-505608")[#strong[#text("Rate changes increase substitutions | Bits of DNA")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2018")]

#text("[…] inequality was discovered independently by Sidney Golden and Colin Thompson in 1965. A proof is explained in an expository blog post by Terence Tao who heard of the Golden-Thompson inequality only eight years ago, which makes me feel a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74bbe0a8f949d4f98db97046e4bbb5225492b2fc1be0e44e2e07c9d5a5df648b-d23c23a2b26d1f38db8c18d442d3a43b032a72ab7c9f06e12d1e969d1bb65f88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-634279")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2021")])]

#text("Hi, i have a question regarding special version of Chernoff inequality you use at the end of this note. It seems to me that \\sigma is missing i.e. it should be P(X1+….XN\\geq \\lamba \\sigma)\\leq …. The same in the operator version. Can you check this?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/#comment-636919")[#strong[#text("Online Optimization Post 7: Matrix Multiplicative Weights Update | in theory")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2021")]

#text("[…] to generalize to this matrix setting everything we have proved about multiplicative weights. See this post by Terry Tao for a […]")
]
