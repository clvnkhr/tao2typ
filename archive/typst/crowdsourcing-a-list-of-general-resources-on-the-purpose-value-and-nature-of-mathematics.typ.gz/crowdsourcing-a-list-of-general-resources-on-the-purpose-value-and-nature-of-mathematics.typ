// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T16:39:29.162143+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Crowdsourcing a list of general resources on the purpose, value, and nature of mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Crowdsourcing a list of general resources on the purpose, value, and nature of mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/")[#text("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Parallel to the other crowdsourced resource drive on this blog, I would like to collect books, writings and other resources that discuss or explain the purpose(s), value(s), and nature of mathematics. As seen in reactions to recent events, one can see many oversimplified or inaccurate perceptions of mathematics, such as")

#list(
[#text("“Mathematical research is about solving open problems.”")],
[#text("“The main reason for posing an open problem is to obtain its solution.”")],
[#text("“We should only work on problems that are of immediate benefit to society.”")],
[#text("“We should prioritize maximizing the number of problems solved.”")]
)

#text("The question of what mathematics actually is is far more complex than these assertions might suggest. Here are some classic books and articles on these topics:")

#list(
[#text("Vladimir Arnold, “")#link("https://www.karlin.mff.cuni.cz/~spurny/doc/articles/arnold.htm")[#text("On teaching mathematics")]#text("“, 1997 (somewhat provocative in tone, but still interesting)")],
[#text("Philip Davis, Reuben Hersh, “")#link("https://en.wikipedia.org/wiki/The_Mathematical_Experience")[#text("The Mathematical Experience")]#text("“, 1981")],
[#text("Timothy Gowers, “")#link("https://www.dpmms.cam.ac.uk/~wtg10/2cultures.pdf")[#text("The two cultures of mathematics")]#text("“, 2000")],
[#text("Timothy Gowers, “")#link("https://global.oup.com/academic/product/mathematics-9780192853615")[#text("Mathematics: a very short introduction")]#text("“, 2002")],
[#text("G. H. Hardy, “")#link("https://en.wikipedia.org/wiki/A_Mathematician%27s_Apology")[#text("A Mathematician’s Apology")]#text("“, 1940 (somewhat dated at this point, but still interesting)")],
[#text("Reuben Hersh, “")#link("https://philpapers.org/rec/HERWIM")[#text("What is mathematics, really?")]#text("“, 1997")],
[#text("David Hilbert, “")#link("http://aleph0.clarku.edu/~djoyce/hilbert/problems.html")[#text("Mathematical Problems")]#text("“, 1900. (Most famous for the list of 23 problems themselves, but the preamble is highly recommended reading. For a deeper dive into the quote “A mathematical theory is not to be considered complete until you have made it so clear that you can explain it to the first man whom you meet on the street.” that Hilbert attributed to “an old French mathematician”, see ")#link("https://www.sciencedirect.com/science/article/pii/S0315086016300465?via%3Dihub")[#text("this article")]#text(" of Barrow-Green and Siegmund-Scholze.)")],
[#text("Imre Lakatos, “")#link("https://en.wikipedia.org/wiki/Proofs_and_Refutations")[#text("Proofs and refutations")]#text("“, 1976")],
[#text("Bill Thurston, “")#link("https://arxiv.org/abs/math/9404236")[#text("On proof and progress in mathematics")]#text("“, 1994 (see also ")#link("https://mathoverflow.net/questions/43690/whats-a-mathematician-to-do/44213#44213")[#text("his response")]#text(" to the MathOverflow question “What’s a mathematician to do?”)")],
[#text("Cedric Villani, “")#link("https://www.amazon.com/dp/0374536678")[#text("Birth of a Theorem")]#text("“, 2015")]
)

#text("Here are some more informal links:")

#list(
[#text("Matt Might, ")#link("https://matt.might.net/articles/phd-school-in-pictures/")[#text("The illustrated guide to a Ph.D.")]#text(", 2010.")],
[#text("A ")#link("https://www.smbc-comics.com/comic/spheres-part-1")[#text("collaboration between myself and Zach Wienersmith")]#text(" on sphere packing, as a five part comic strip (Apr 9, 2026)")],
[#link("https://nap.nationalacademies.org/resource/other/deps/illustrating-math/interactive/")[#text("Illustrating the impact of the mathematical sciences")]#text(" – a series of posters by the National Academy of Sciences. (I was on the committee to create these posters.) (2023)")]
)

#text("I can also list a few writings, posts, and interviews I have done on these topics:")

#list(
[#link("https://terrytao.wordpress.com/career-advice/theres-more-to-mathematics-than-rigour-and-proofs/")[#text("There is more to mathematics than rigour and proofs")]#text(" (2007)")],
[#link("https://arxiv.org/abs/math/0702396")[#text("What is good mathematics?")]#text(" (2007)")],
[#link("https://www.youtube.com/watch?v=xt6wGDGGx3o")[#text("The value in “Dumb” questions")]#text(" (2022)")],
[#link("https://www.quantamagazine.org/what-makes-for-good-mathematics-20240201/")[#text("What makes for ‘Good’ Mathematics")]#text(" (2024)")],
[#link("https://terrytao.wordpress.com/wp-content/uploads/2026/03/talk-ver-3.pdf")[#text("What does it mean to think like a mathematician?")]#text(" (Mar 14, 2026)")],
[#link("https://www.youtube.com/watch?v=OOMx2BHHWtE")[#text("Interview with “Big Think”")]#text(" (relating to ")#link("https://www.quantabooks.org/books/six-math-essentials/")[#text("my forthcoming book")]#text(") (Aug 28, 2026) – see also ")#link("https://www.youtube.com/watch?v=svl_1upFpQo")[#text("this abridged version")]],
[#link("https://mathstodon.xyz/@tao/117244102901892965")[#text("On remembering what it is like to be a child: curiosity-driven play, the “largest number” game, and what premature optimization for the nominal goal extinguishes")]#text(" (Sep 9, 2026)")]
)

#text("Please contribute more links in the comments below!")

#heading(level: 1)[#text("Comments (48)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694931")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("This paper may be of interest")

#link("https://link.springer.com/article/10.1007/s11245-009-9059-2")[#text("https://link.springer.com/article/10.1007/s11245-009-9059-2")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694932")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("The “What is mathematics, really?“ link is not working")

#emph[#text("[Updated, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10905479e9b4f913fc4f0ad44e4ba398f7c4e8ce957f89154e9701f6274c48bf-7feed935cc53149e1eca87854c9d7339e4b41f1966ac419b1fa8e6aaada06a4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Vaughan")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694933")[#strong[#text("Robert Vaughan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Terry,")

#text("You ought to include Littlewood’s Miscellany. Much more readable than")#linebreak()#text(" many of the others on your list.")

#text("Best Wishes,")

#text("Bob Vaughan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694935")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Don’t forget Alejandro Garciadiego, Bertrand Russell and the Origins of the Set-theoretic ‘Paradoxes.’")

#text("This is especially important for understanding how the magic trick known as paradox, rose to such bizarre prominence in the late nineteenth century. It also provides amusing insight into Russell as intellectual hustler.")

#text("Make sure you read the footnotes.")

#text("John Ryskamp")

#link("mailto:philneo2001@yahoo.com")[#text("philneo2001@yahoo.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Not a separate resource but RH has been one of the most productive pieces of work in NT:")

#strong[#text("Analytic number theory as a discipline")]

#list(
[#strong[#text("The Prime Number Theorem (1896).")]#text(" Hadamard and de la Vallée Poussin proved it by showing ζ(s) has no zeros on the line Re(s) = 1, a weak form of RH. The complex-analytic techniques they developed became the foundation of modern analytic number theory.")],
[#strong[#text("Explicit formulas.")]#text(" Riemann’s own 1859 paper introduced the idea that primes and zeta zeros are Fourier duals of each other. The explicit formula connecting the two is now a standard tool.")],
[#strong[#text("Zero-free regions and zero-density estimates.")]#text(" Unable to prove RH, mathematicians (de la Vallée Poussin, Vinogradov, Korobov) proved that zeros stay away from the critical strip’s edges. These partial results power most of the current unconditional error terms in prime counting.")]
)

#strong[#text("Hardy–Littlewood and Selberg")]

#list(
[#strong[#text("Hardy’s proof that infinitely many zeros lie on the critical line (1914)")]#text(", followed by Selberg’s result that a positive proportion do, and Levinson’s and Conrey’s improvements. This spawned mollifier techniques used across the field.")],
[#strong[#text("The Hardy–Littlewood circle method")]#text(" was developed alongside their zeta work and became the primary tool for Waring’s problem and Goldbach-type results.")],
[#strong[#text("Selberg’s sieve and the large sieve")]#text(" grew from the same circle of ideas and underpin results like Bombieri–Vinogradov (which is often described as “RH on average” and substitutes for it in many applications).")]
)

#strong[#text("Generalization and geometry")]

#list(
[#strong[#text("The Weil conjectures.")]#text(" Artin, Hasse, and Weil formulated and proved the RH analogue for curves and varieties over finite fields. Grothendieck’s entire étale-cohomology program was built to attack them, and Deligne’s proof (1974) was one of the century’s landmark results. Modern algebraic geometry owes an enormous debt to this pursuit.")],
[#strong[#text("The Langlands program.")]#text(" Generalized L-functions (Dirichlet, Hecke, automorphic) were introduced partly to extend RH; the Grand Riemann Hypothesis is a central organizing conjecture there.")]
)

#strong[#text("Random matrices and physics")]

#list(
[#strong[#text("The Montgomery–Odlyzko law (1973).")]#text(" Montgomery’s pair-correlation conjecture, and Dyson’s famous observation that it matched the Gaussian Unitary Ensemble, created the link between zeta zeros and random matrix theory. This now informs quantum chaos, nuclear physics, and the statistics of L-function families (Katz–Sarnak).")],
[#strong[#text("The Hilbert–Pólya program.")]#text(" The idea that zeros are eigenvalues of a self-adjoint operator drove work on the Berry–Keating Hamiltonian and Connes’ noncommutative-geometry approach.")]
)

#strong[#text("Computation")]

#strong[#text("The Riemann–Siegel formula")]#text(" (recovered from Riemann’s notes by Siegel) and the ")#strong[#text("Odlyzko–Schönhage algorithm")]#text(" were developed to compute zeros efficiently. Turing’s work on verifying zeros was one of the first uses of an electronic computer in pure mathematics, and he invented the “Turing method” for certifying that no zeros are missed.")

#strong[#text("Primality testing.")]#text(" Miller’s 1976 deterministic polynomial-time test is correct only if the Generalized Riemann Hypothesis holds (Rabin later made it probabilistic and unconditional). Many algorithms in computational number theory, including Bach’s explicit bounds and parts of the analysis of factoring and discrete-log algorithms, still carry GRH as a hypothesis.")

#strong[#text("Turing.")]#text(" built the Manchester zero-computation (1950) and invented the method for certifying that a numerical search hasn’t skipped any zeros. It was one of the earliest computer-assisted results in pure mathematics.")

#strong[#text("Computability and logic.")]#text(" RH is equivalent to a Π₁ arithmetic statement, so it’s equivalent to a particular Turing machine never halting. Matiyasevich sketched this, and Yedidia and Aaronson (2016) built an explicit 5,372-state machine (since reduced to 744 states) that halts iff RH is false. It’s a concrete illustration of how RH sits inside the Busy Beaver hierarchy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Silvia De Toffoli, Paolo Mancosu, ")#emph[#text("The Philosophy of Mathematical Practice")]#text(", ")#link("https://plato.stanford.edu/entries/mathematical-practice/")[#text("https://plato.stanford.edu/entries/mathematical-practice/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34f041eeaf82cadd5bde9326522450c4cb8541c9a2f7d71d710e7abe1ae365f1-381bb99d2369129da8a714593ab63f71bd4e186be9d40aa12de0ff158969ac0b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lukeplato")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694951")[#strong[#text("lukeplato")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I imagine some of Grothendieck’s work belongs here (“I am not really doing research, just trying to cultivate myself”).")

#text("I was thinking about his essay, ‘The Rising Sea’. Though I can’t say whether it meets your criteria, it spawned an analogy with our current AGI predicament while in the rising tub:")

#list(
[#text("a being is placed in a tank with high walls (analogously, a civilization is seeded in environment with high developmental potential)")]
)

#list(
[#text("a warm liquid begins slowly rising in the tank, mostly of soothing and positive feeling but causes some irritation over time (analogously, the development of infrastructure and advanced technology)")],
[#text("tiled along the walls are pockets, with some appearing to contain useful items and tools (analogously, scientific discoveries become attainable through advanced technology)")],
[#text("the being has access to a plug with a short chain to extend the plug (analogously, primitive emergency stop mechanisms for physical disrupting or destroying intelligence infrastructure)")],
[#text("the being has access to turn the tap on and off, with the tap located on the wall above the tub (analogously, pausing development while within reach)")],
[#text("some distress occurs as tides begin rising on the being (analogously, early development of superintelligence becomes known)")],
[#text("the being assumes it can float or swim in this liquid (analogously, understand knowledge produced by superintelligence)")],
[#text("dynamics of recursive self intelligence resemble changing the rate of flow of liquid or narrowing the tub at increasing heights.")],
[#text("the primary strategy seems to be: float with the rising tide, repeatedly submerge to turn on/off tap at increasing depths to match physical and mental capabilities, while checking if any pockets contain tools to aid in further exploration (analogously, periodic pauses to verify current model capabilities can be understood, paused, and physically disrupted; while investing in development of tooling and research to extend these safety capabilities alongside increasing intelligence)")],
[#text("Understanding scientific output on frontier challenges seems to analogous to measuring breathing depth/capabilities")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#link("https://davidbessis.substack.com/p/the-fall-of-the-theorem-economy")[#text("The Fall of the Theorem Economy")]#text(", on David Bessis’s substack, has been circulating for some time among math PhD students I know (and, I assume, the rest of the mathematics community). It talks more explicitly about the value and purpose of math in the wake of the First Proof project earlier this year, from a lens similar to that of Proof and Progress in Mathematics.")

#text("Perhaps the expositions from this and last year should go into a separate category, however, as there have been a lot of people writing about this topic recently. Especially after the Leiden declaration and now the claimed proof of Navier-Stokes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fd8f94fb7aaae4a35bab04caf75bd4462278a5a46b6cd92c6f4d4f66bf218fc-4156164f390dcc9744434fbd22497af09ed4cde0a7caf98df4a9487ca007dafc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gentzen")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694954")[#strong[#text("gentzen")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://gentzen.wordpress.com/2022/02/19/why-mathematics/")[#text("Why mathematics?")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694960")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Michèle Friend, ")#emph[#text("Varieties of Pluralism and Objectivity in Mathematics")]#text(", ")#link("https://link.springer.com/chapter/10.1007/978-3-030-15655-8_15")[#text("https://link.springer.com/chapter/10.1007/978-3-030-15655-8_15")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a8967c1e9c778177283e862347313e359f4ec8a94432259f164768abbe4d66-add38f023258e8054c5dd91237a856b3ea53bc730e87d5fe9e3a7ed09b8314e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694961")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Please permit me to share the following chapters from ")#link("https://www.dropbox.com/scl/fi/gxir02vtob03m4oo79egu/16_Anand_Dogmas_Submission_Update_3_Atul-Printers-Copy_250227.pdf?rlkey=4tsiwjw7gllzaze0dupwd0kcp&dl=0")[#text("my book")]#text(" [An22] which address the issue:")

#text("[")#link("https://www.dropbox.com/scl/fi/gxir02vtob03m4oo79egu/16_Anand_Dogmas_Submission_Update_3_Atul-Printers-Copy_250227.pdf?rlkey=4tsiwjw7gllzaze0dupwd0kcp&dl=0")[#text("An22")]#text("], p.116, ")#emph[#text("§1.L. What mathematics is, and what it is not")]#text(" [")#link("https://www.dropbox.com/scl/fi/gxir02vtob03m4oo79egu/16_Anand_Dogmas_Submission_Update_3_Atul-Printers-Copy_250227.pdf?rlkey=4tsiwjw7gllzaze0dupwd0kcp&dl=0")[#text("An22")]#text("], p.324, ")#emph[#text("§13. What is mathematics?")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694974")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I like this piece by Jeremy Kun, “Habits of Highly Mathematical People”.")

#link("https://medium.com/@jeremyjkun/habits-of-highly-mathematical-people-b719df12d15e")[#text("View at Medium.com")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695082")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I haven’t read this essay, but the title calls to mind Al Cuoco and colleagues’ long line of work on “habits of mind”, which I had come here to contribute.")

#text("“[T]he point [is] that mathematical thinking involves more than just understanding important mathematical ideas and learning to apply useful methods and procedures. Modes of thought, or habits of mind, exist that transcend content knowledge and are taken for granted by mathematicians as essential facets of their work.”")

#text("the above quote is the introduction of")

#link("https://savouringtheish.wordpress.com/wp-content/uploads/2015/08/12577_chapter.pdf")[#text("Levasseur, K., & Cuoco, A")]#text(". (2003). Mathematical habits of mind. Teaching mathematics through problem solving: Grades, 6(12), 27-38.")

#text("A more well known manuscript is from the 1990’s.")

#text("“Thinking about the future is risky business. Past experience tells us that today’s first graders will graduate high school most likely facing problems that do not yet exist. Given the uncertain needs of the next generation of high school graduates, how do we decide what mathematics to teach?")

#text("[…][We could replace] one set of established results by another one")

#text("(perhaps newer or more fashionable).")

#text("[…]")

#text("There is another way to think about it, and it involves turning the priorities")

#text("around.")

#strong[]

#text("Much more important than specific mathematical results are the")

#text("habits of mind used by the people who create those results.")#text("“")

#link("https://nrich.maths.org/content/id/12160/Cuoco_etal-1996.pdf")[#text("Cuoco, A., Goldenberg, E. P., & Mark, J")]#text(". (1996). Habits of mind: An organizing principle for mathematics curricula. The Journal of Mathematical Behavior, 15(4), 375-402.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694975")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Hello everyone. Hope you’re all doing well.")

#text("Not really related to mathematics, but I’d like to suggest this article from Emily M. Bender simply titled ‘artifical Intelligence’")

#link("https://faculty.washington.edu/ebender/papers/Bender-AI-2026.pdf")[#text("https://faculty.washington.edu/ebender/papers/Bender-AI-2026.pdf")]

#text("She’s a quite known AI and LLM critic. You may know her as the one that wrote the article that presented LLMs as “Stochastic Parrot” with ex Google employee Timnit Gebru. She is a linguist that specialised in NLP / Computational linguistics.")

#text("I think some people here might dislike this paper as it is a really harsh critic of LLMs and also the AI research domain, but I believe it’s worth a read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("The purpose, value, and nature of mathematics is not just limited to academic mathematicians, but is applicable to anybody who uses mathematics in their day to day lives.")

#text("Hence, this ongoing discussion about what mathematics should be taught at the high school level and introductory university level to different students for their future careers should matter here as well:")

#text("University of Texas’s Charles A. Dana Center, ")#emph[#text("Launch Years: A New Vision for the Transition from High School to Postsecondary Mathematics")]#text(", ")#link("https://www.utdanacenter.org/sites/default/files/2020-03/Launch-Years-A-New-Vision-report-March-2020.pdf")[#text("https://www.utdanacenter.org/sites/default/files/2020-03/Launch-Years-A-New-Vision-report-March-2020.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("S.C. Akolatse, ")#emph[#text("Math is one of the Humanities")]#text(", ")#link("https://scakolatse.substack.com/p/math-is-one-of-the-humanities")[#text("https://scakolatse.substack.com/p/math-is-one-of-the-humanities")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-696298")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("Woah, that’s my post! I noticed a small blip of traffic from terrytao.wordpress.com so I thought I’d investigate… thanks for the shout out – if we do know each other let me know, but if we don’t, that’s very cool; up until recently I figured I’m essentially only writing for my friends :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694990")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Elena Anne Corie Marchisotto, ")#emph[#text("Mathematics as a Humanistic Discipline")]#text(", ")#link("https://scholarship.claremont.edu/hmnj/vol1/iss7/9/")[#text("https://scholarship.claremont.edu/hmnj/vol1/iss7/9/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-694999")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Edgar Fuller, ")#emph[#text("Are University Budget Cuts Becoming a Threat to Mathematics?")]#text(" ")#link("https://www.ams.org/journals/notices/202405/noti2934/noti2934.html")[#text("https://www.ams.org/journals/notices/202405/noti2934/noti2934.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b901258fcb3d91d79e1770c22f16c6a3deffc4fda102cdac7a479ebdd9d45d7f-68004c5e52c5130ce75976119d5e5d89afc5a75362bbd492a4b032c0c97122d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sarah Mayes-Tang")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695001")[#strong[#text("Sarah Mayes-Tang")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Thanks for doing this!")

#text("My students are always very inspired by feminist theories of math. One classic is the following:")

#list(
[#text("Leone Burton, “Moving Towards a Feminist Epistemology of Mathematics”, 1995 (reprinted in 2008)")]
)

#text("There are many other articles (a good place to begin is the articles that cite this one, or the articles that this one cites), but I think that this one fits the assignment the best!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695007")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Rényi Alfréd wrote three texts in the form of Socratic dialogues focusing on mathematics itself, on the applications of mathematics and on mathematics as the language of nature (featuring Socrates, Archimedes, and Galileo as the main character respectively). The book is meant for the widest audience and if there was an open access link for the English translation that would deserve to be included. However, the Hungarian original is freely available online, and google translate seems to be pretty clear and accurate, so I include the link to the original, just in case: ")#link("https://mek.oszk.hu/00800/00856/html/")[#text("https://mek.oszk.hu/00800/00856/html/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695024")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Michael Harris’s recent essay in ")#emph[#text("Boston Review")]#text(", “Knowledge Collapse,” reflects on the purpose and culture of mathematical inquiry as well as the impact of AI on the field: ")#link("https://www.bostonreview.net/articles/knowledge-collapse/")[#text("https://www.bostonreview.net/articles/knowledge-collapse/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695057")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Terry, I feel that many of us have plenty to say, but are not speaking outside our circle because we do not know whom we are supposed to address. Here, too, I am confused: is this meant to be for the general public? For fans of mathematics? For students? For those who were in mathematics and now work for AI companies?")

#text("I recall that, when we met in May, the students and postdocs in our group were feeling crushed. (This was right before the unit distance problem announcement – they got advance notice.) Perhaps that is a group to be addressed in particular?")

#text("I also feel you are a couple of weeks ahead of the game compared to most people, and that translates into what would be a few years if we were not next to a gravitational singularity. I will probably have a small audience of my own in a few weeks’ time – folks in South America are having a meeting on maths in AI, and I’d like to be up to date.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("There is a colleciton of essays by Y. I. Manin “Mathematics as Metaphor”. I enjoyed reading it many times.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695112")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("That is a fantastic book, and some of the essays are also available online, such as: ")#link("https://arxiv.org/abs/math/0703427")[#text("https://arxiv.org/abs/math/0703427")]#text(" or ")#link("https://www.pas.va/content/dam/casinapioiv/pas/pdf-volumi/scripta-varia/sv99/sv99-manin.pdf")[#text("https://www.pas.va/content/dam/casinapioiv/pas/pdf-volumi/scripta-varia/sv99/sv99-manin.pdf")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695090")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("care’s ‘The future of mathematics” in his ")#link("https://henripoincarepapers.univ-nantes.fr/chp/hp-pdf/hp1914sm.pdf")[#text("Science and Method")]#text(" is almost prophetic in the context of the current discussion on AI for mathematics:")

#text("“In the past there have been prophets of ill. They took pleasure in repeating that all problems susceptible of being solved had already been solved, and that after them there would be nothing left but gleanings. Happily we are reassured by the example of the past. Many times already men have thought that they had solved all the problems, or at least that they had made an inventory of all that admit of solution. And then the meaning of the word solution has been extended; the insoluble problems have become the most interesting of all, and other problems hitherto undreamed of have presented themselves.” – H. Poincare")

#text("The same goes for his “Analysis and physics” in ")#link("https://www3.nd.edu/~powers/ame.60611/poincare.pdf")[#text("The value of Science")]#text(":")

#text("“Doubtless you are often asked what is the utility of mathematics and whether its nicely constructed theories, drawn entirely from the mind, are not artificial products of our caprice. Among the persons who ask this question, I must make a distinction. The practical class demand of us nothing but means of getting money. These do not deserve to be answered. Rather ought it to be demanded of them what is the good of accumulating so much wealth and whether, in order to have time for its acquisition, it is necessary to neglect art and science, which alone render the soul capable of enjoying it,")

#text("Et, propter vitam, vivendi perdere causas.")

#text("Moreover, a science produced with a view single to its applications is impossible ; truths are fruitful only if they are concatenated ; if we cleave to those only of which we expect an immediate result, the connecting links will be lacking, and there will be no longer a chain.” H. Poincare")

#text("Kurt Gödel’s 1951 ")#link("https://partiallyexaminedlife.com/wp-content/uploads/Godel-Basic-Theorems-and-Their-Implications-1.pdf")[#text("Gibbs lecture")]#text(":")

#text("“So the following disjunctive conclusion is in evitable: Either mathematics is incompletable in this sense, that its evident axioms can never be comprised in a finite rule, that is to say, the human mind (even within the realm of pure mathematics) infinitely surpasses the powers of any finite machine, or else there exist absolutely unsolvable diophantine problems of the type specified (where the case that both terms of the disjunction are true is not excluded, so that there are, strictly speaking, three alternatives). It is this mathematically established fact which seems to me of great philosophical interest.”-Kurt Gödel")

#text("Hermann Weyl’s ")#link("https://archive.org/details/levelsofinfinity0000weyl/page/n5/mode/2up")[#text("The levels of infinity")]#text(":")

#text("“From this formalistic standpoint, one is no more permitted to seek deeper grounds for the axioms and rules of operation that have been assumed than one would be for a chess game; indeed, it even remains obscure why we are concerned that the game be “non-contradictory.” The floor is closed to all objections, since indeed nothing is being asserted; refusal could only be expressed in the declaration “I am not joining in the game.” If for the sake of preserving its certainty mathematics wished in all seriousness to withdraw to this position of mere play, it would thereby pass entirely out of the world-history of the mind.” – Hermann Weyl")

#text("David Hilbert’s ")#link("https://aichats.substack.com/p/david-hilbert-the-understanding-of?r=4tn68o&utm_campaign=post-expanded-share&utm_medium=web")[#text("The Understanding Nature and Logic")]#text(":")

#text("“But even more striking is a phenomenon, which we, in a different sense than Leibniz, shall call the pre-established harmony, which is virtually an embodiment and realisation of mathematical thoughts. The older examples of this are the conic sections, which were studied long before it was suspected that our planets or even electrons moved in such paths. But the grandest and most wonderful case of the pre-established harmony is the famous Einsteinian theory of relativity. Here, solely through the general demand for invariance combined with the principle of greatest simplicity, the differential equations for the gravitational potential are mathematically uniquely established; and this formulation would have been impossible without the profound and difficult mathematical investigations of Riemann, which existed long before. ” – David Hilbert")

#text("Albert Einstein’s ")#link("https://www.informationphilosopher.com/solutions/scientists/einstein/Method_of_Theoretical_Physics.pdf")[#text("On the Method of Theoretical Physics")]#text(":")

#text("“Our experience up to date justifies us in feeling sure that in Nature is actualized the ideal of mathematical simplicity. It is my conviction that pure mathematical construction enables us to discover the concepts and the laws connecting them which give us the key to the understanding of the phenomena of Nature. Experience can of course guide us in our choice of serviceable mathematical concepts; it cannot possibly be the source from which they are derived; experience of course remains the sole criterion of the serviceability of a mathematical construction for physics, but the truly creative principle resides in mathematics. In a certain sense, therefore, I hold it to be true that pure thought is competent to comprehend the real, as the ancients dreamed” A. Einstein")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695095")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I always found Lakatos to be a bit of a troll. A troll with a point, yes, but a troll nevertheless.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695099")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Here are a few of my favorites:")

#enum(start: 1, 
[#text("Francis Su, ")#emph[#link("https://francissu.com/flourishing/")[#text("Mathematics for Human Flourishing")]]#text(" (Yale University Press, 2020)")],
[#text("Paul Lockhart, ")#link("https://worrydream.com/refs/Lockhart_2002_-_A_Mathematician%27s_Lament.pdf")[#text("A Mathematician’s Lament")]],
[#link("https://scholarship.claremont.edu/jhm/")[#text("Journal of Humanistic Mathematics")]]
)

#text("In fact, I published two papers in (3):")

#text("3a. ")#link("https://scholarship.claremont.edu/cgi/viewcontent.cgi?article=1291&context=jhm")[#text("The User’s Guide Project: Giving Experiential Context to Research Papers")]

#text("3b. ")#link("https://scholarship.claremont.edu/cgi/viewcontent.cgi?article=1666&context=jhm")[#text("The User’s Guide Project: Looking Back and Looking Forward")]

#text("This project was in some sense our attempt to implement what Thurston called for in his essay linked in your post. You can see the user’s guides themselves here: ")#link("https://mathusersguides.com/")[#text("https://mathusersguides.com/")]

#text("Good luck!")#linebreak()#text("David White")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a454a298d8b09b1718cf5ab277ac74e9c903c1d035899d3f225a28143169f5d4-d7571d3406c3b9a9910a9c2db0089f3da2cbbe452dd0a84746fd761f66b86d2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alain Chavarri")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695105")[#strong[#text("Alain Chavarri")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("The paper “Correctness, Artificial Intelligence, and the Epistemic Value of Mathematical Proof” by James Owen Weatherall and Jesse Wolfson.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f42aa55b229b95cbb705672e1a181dea4a096b55f0a759e84fc4cfc8c9e42a58-61e9646899b70d6ccd1b5184915d6d0c6d95d5f42a8d398654590abdab10af7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kmka77")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695108")[#strong[#text("kmka77")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#link("https://en.wikipedia.org/wiki/The_Unreasonable_Effectiveness_of_Mathematics_in_the_Natural_Sciences")[#text("https://en.wikipedia.org/wiki/The_Unreasonable_Effectiveness_of_Mathematics_in_the_Natural_Sciences")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695121")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#link("https://mathoverflow.net/questions/175847/how-does-one-justify-funding-for-mathematics-research")[#text("https://mathoverflow.net/questions/175847/how-does-one-justify-funding-for-mathematics-research")]#text(" talks about the value of mathematics for the public")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d59a434514ac98ceb4699e3d225248ce5497dcf2d8407abc9135345929c63526-8cea065211f91e07ea4bf3b8efb3721aeebc48242429727ad66c70aa37309baa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Naysh")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695122")[#strong[#text("Naysh")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Some relevant writing by Francis Su:")

#list(
[#emph[#link("https://francissu.com/flourishing/")[#text("Mathematics for Human Flourishing")]]],
[#link("https://francissu.substack.com/p/the-lesson-of-grace-in-teaching")[#text("“The Lesson of Grace in Teaching” ")]],
[#link("https://francissu.substack.com/p/the-enduring-value-of-math-in-an")[#text("“The Enduring Value of Math, in an Age of AI”")]],
[#link("https://francissu.substack.com/p/science-in-service-of-love")[#text("“Science, in Service of Love”")]]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Eugenia Cheng, “Mathematics, morally”.")

#align(center)[

]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("“Count me in : community and belonging in mathematics”, edited by Della Dumbaugh and Deanna Haunsperger. This is particularly timely because there is much discussion of the value of collaboration, and the benefits that come from collaborative mathematical projects beyond just the theorems themselves.")

#text("Paulis Gerdes, “Women, Culture and Geometry in Southern Africa”. This is a really engaging book which pushes at the limits of what should be considered mathematics. I find it very relevant today, but I would not say that its approach has caught on. A problem with the work of Gerdes: the same book is published with different titles, and then others are published with a similar title. As far as I can tell, the third edition (with quite relevant updates) is only available from a print-on-demand service.")

#text("Also by Paulus Gerdes, “Sona Geometry from Angola: Mathematics of an African Tradition”, also available in three French volumes as “Une tradition géométrique en Afrique, les dessins sur le sable”. One could say that it is also an effort to push the frontiers of mathematics, and that in practice this book has been more successful at this than the last one I mentioned.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c061e6a60de30ed2309c1ced46a9684af5d5017a44993e2b6d27a94c7fc5285f-9472920595a5993181964163b74c8fea0d51db84a0fa74c85936429e2f816420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elad Kosloff")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695147")[#strong[#text("Elad Kosloff")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Funes the Memorious by Jorge Luis Borge. This story resonates the difference between A.I math and human math.")

#text("While Marx’s political program led to horrific consequences, I think his analysis of the worker’s experience under modern forms of production is surprisingly relevant to the mathematician’s experience of practicing mathematics through button-pushing.")

#link("https://www.marxists.org/archive/marx/works/1844/manuscripts/labour.htm?utm_source=chatgpt.com")[#text("https://www.marxists.org/archive/marx/works/1844/manuscripts/labour.htm?utm_source=chatgpt.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695152")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Bertrand Russell: The value of philosophy. A lot of thoughts in this work can be adapted to describe mathematical thinking. In fact, I believe philosophical and mathematical thinking are very similar.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695162")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I liked Norbert Wiener’s two-volume autobiography “Ex-Prodigy” and “I Am A Mathematician” though a lot of it was cringe. I’m not near a copy but I’ll try to look through it and find some good sections when I get a chance. His book “The Human Use of Human Beings” was also good, though iirc not that math oriented.")

#text("A quote from Whitfield Diffie, about cryptography but related to the famous mathematical divide between problem solvers and theory builders: “It is a situation that has been seen before in mathematics. At the end of the last century, mathematical analysis ground to a halt against intractable problems in Fourier Theory, differential equations, and complex analysis. What many mathematicians did with their time while not solving the great problems was viewed with scorn by critics who spoke of the development of point set topology and abstract algebra as “soft mathematics”. Only at mid-century did it become clear what had happened. In the abstractions a great hammer had been forged and through the 1950s and 1960s the classic problems began to fall under its blows. Perhaps cryptography will be equally lucky.” — W. Diffie, “The First Ten Years of Public-Key Cryptography” Proc. IEEE vol 76:5, May 1988 (should be online somewhere)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a49720e11368cf2e79a56e72c5cc610aaf260439f67a77c25e8dc0a50fd8fe0-67cd508f649d167b1f47b7a89d301b5572f63ef2e976ad596ded0f991cbb4157.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mattecapu")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695196")[#strong[#text("mattecapu")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("These are mostly excellent, I hoped you wouldn’t include Hardy’s outdated and quite elitist essay. In there he says:")

#text("“Exposition, criticism, appreciation, is work for second-rate minds”")

#text("which seems to me quite contrary to the spirit of the other works, and certainly widely refused at this moment…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e83045ee1784bf91fa9a10805f1a09bdafc4ac7f1a2743390ede8176c2d38fe-191cf52af127f77cd932fc2fccbb2837fcd12d24c40d08604fec95a4ed47c6e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Zhao")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695197")[#strong[#text("Jason Zhao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("My colleague Richard Bamler at UC Berkeley recently posted a very nice essay reflecting on AI and mathematics.")

#link("https://rbamler.github.io/math-vision/")[#text("My “vision” for the future of math (or rather, scattered thoughts) | Richard Bamler")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a3bf8a3068e1df5e8e515db87c945ca142ba1773d998a685d137eb0f17a7429-303bd6780e62957c36cc111771e204de072bfc3c875677a6ccaf4d2af0760cc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vinícius Machado Vogt")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695243")[#strong[#text("Vinícius Machado Vogt")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I think that some of the opinions by people like Morris Kline and Vladimir Arnold (the main point of mathematics is to help people understand the world around them!) have become even more relevant today, now that mathematics has become “mechanized”. And it’s nice that both of them were also historians of mathematics, because we will need a lot of “historians” to write about the great feats of LLMs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d3f17cb9afffc5e2a9219647bf1fe1f71769dfc181c92777fddbdc754b91cb0-5b0c341a4c4c67bd9beba780cf4e5076193a4ff7e048b6ae05b24608c2d89a63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YL")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695289")[#strong[#text("YL")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Philip Kitcher is a philosopher who studied the development of mathematics in the 1800s-1900s. He characterized the nature of mathematical practice based on his analysis.")

#link("https://jwood.faculty.unlv.edu/unlv/Articles/Kitcher.pdf")[#text("https://jwood.faculty.unlv.edu/unlv/Articles/Kitcher.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695330")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("“Towards a Philosophy of Real Mathematics” by D. Corfield.")

#link("https://ncatlab.org/davidcorfield/show/Towards+a+Philosophy+of+Real+Mathematics")[#text("https://ncatlab.org/davidcorfield/show/Towards+a+Philosophy+of+Real+Mathematics")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695366")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I suggest the book entitled “Humanizing Mathematics and its Philosophy”, edited by Bharath Sriraman. It was compiled as a Festschrift for Reuben’s 90")#super[#text("th")]#text(" birthday in 2017. Nearly a decade ago, Reuben agreed to have the celebratory book published only if the invited contributors would address the topic of whether mathematicians would at some unspecified future be replaced by computers. It was reviewed by Joseph Auslander in the Notices of the American Mathematical Society Volume 65 Number 11 December 2018.")

#text("Elena Anne Corie Marchisotto")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695381")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("May I suggest that you also start a post crowdsourcing recommendations of books that might stimulate the interest of young children and precocious teenagers in mathematics and its applications? Here’s a list to prime the pump arranged roughly in descending order by increasing age of the intended audience:")

#text("The Number Devil: A Mathematical Adventure by Hans Magnus Enzensberger")

#text("A Brain for Numbers: The Biology of the Number Instinct by Andreas Nieder")

#text("One, Two, Three…Infinity by George Gamow")

#text("Number: The Language of Science by George Dantzig")

#text("In Search of Infinity by Naum Yakovlevich Vilenkin")

#text("Mathematics: The Loss of Certainty by Morris Kline")

#text("PI in the Sky: Counting, Thinking, and Being by John D. Barrow")

#text("The Evolution of Scientific Thought From Newton to Einstein by A D’Abro")

#text("The Rise of the New Physics, Vols. I and II by A. D’Abro")

#text("Mathematics: Its Content, Methods, and Meaning by A. D. Aleksandrov, A. N. Kolmogorov, and M. A. Lavrentev")

#text("Where Mathematics Comes From: How the Embodied Mind Brings Mathematics into Being by George Lakoff and Rafael E. Núñez")

#text("Mathematics and Logic by Mark Kac and Stanislaw M. Ulam.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695382")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Since you listed the provocateur Arnold, I’d throw in Indiscrete Thoughts by Gian-Carlo Rota and Discrete Thoughts: Essays on Mathematics, Science and Philosophy by Mark Kac, Gian-Carlo Rota, and Jacob T. Schwartz, as well")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695415")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("On how mathematics has been done and mathematicians undone particularly relevant to the current oppressive zeitgeist and global spread of aggression:")

#link("https://mathshistory.st-andrews.ac.uk/Extras/Ulam_Scottish_Cafe/")[#text("Memories from the Scottish Café")]#text(" by Stanislaw Ulam")

#link("https://polishhistory.pl/beautiful-minds-extraordinary-mathematicians-from-lwow/")[#text("Beautiful minds. Extraordinary mathematicians from Lwów")]#text(", an interview with Mariusz Urbanek")

#link("https://sztetl.org.pl/en/about-the-project/the-lwow-school-of-mathematics")[#text("The Lwów School of Mathematics")]#text(" by Mariusz Urbanek")

#link("https://inria.hal.science/hal-02386544/document")[#text("Mathematicians at the Scottish Café ")]#text("by Chris Zielinski")

#link("https://www.researchgate.net/publication/226053312_A_visit_to_Hungarian_mathematics")[#text("A Visit to Hungarian Mathematics")]#text(" by Reuben Hersch and Vera John-Steiner")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfd5d9f3528a431bad960005b76a49a2ac689be1e46f6096feb9856a1c4d420a-99fa63f3dcf1832338faa6c9b6c7faa58b5e8b67e7be11b174a3b646be1e249e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peccatte")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695471")[#strong[#text("peccatte")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("The provocative and stimulating article:")#linebreak()#text("Doron Zeilberger, ")#emph[#text("Theorems for a Price : Tomorrow’s Semi-Rigourous Mathematical Culture")]#text(", Notices of the American Mathematical Society, 40, n° 8, 978-981, 1993.")#linebreak()#link("https://sites.math.rutgers.edu/~zeilberg/mamarim/mamarimPDF/priced.pdf")[#text("https://sites.math.rutgers.edu/~zeilberg/mamarim/mamarimPDF/priced.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2371a84fc535d744f8752ba0122faef0d1751c2ebe8d048230f3655125c4ba54-d4f0fa34df2f3d81fdf98208b1039f44004f0703dfceec54e2a6ad11c56478b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Merlin Bumpus")]], [#link("https://terrytao.wordpress.com/2026/09/12/crowdsourcing-a-list-of-general-resources-on-the-purpose-value-and-nature-of-mathematics/#comment-695626")[#strong[#text("Benjamin Merlin Bumpus")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Spurred by conversations with students, I recently wrote an opinion piece about the kinds of mathematics we might do now, given the advent of AI. You can find it here: ")#link("https://bmbumpus.com/2026/09/16/thinking-hard-above-ai/")[#text("https://bmbumpus.com/2026/09/16/thinking-hard-above-ai/")]#text(".")
]
