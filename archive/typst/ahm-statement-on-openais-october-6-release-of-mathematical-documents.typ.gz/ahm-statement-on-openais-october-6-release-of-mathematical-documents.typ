// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/
// Converted to Typst by tao2typ: "2026-10-14T15:21:27.170177+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "AHM Statement on OpenAI’s October 6 Release of Mathematical Documents", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("AHM Statement on OpenAI’s October 6 Release of Mathematical Documents")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/")[#text("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by the ")#link("https://www.ahmath.org/")[#text("Association for Human Mathematics")]#text(", reposted from ")#link("https://www.ahmath.org/statements")[#text("their statements page")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Yesterday, on October 6th, 2026, OpenAI — which is currently defending lawsuits against accusations of illegal plagiarism, copyright infringement, and trademark dilution — released a repository of manuscripts purporting to contain solutions to a number of high-profile problems in mathematics.")

#metadata(none) <tao-439f3a00cfbb4ac35433>

#text("Mathematicians did not ask for this work to be done. The Advisory Group on Mathematics and Artificial Intelligence, from whom OpenAI has claimed to derive its legitimacy, opened their initial advisory statement by saying that frontier AI corporations should not test advanced mathematical problems on internal models. In ignoring the central premise of the Advisory Group’s position, OpenAI has indicated total disregard for the norms of scientific research — norms that guarantee that mathematics remains trustworthy, ethically researched, and in the public interest.")

#text("Mathematicians have a particular vision of progress that is informed by history and field-specific considerations. We reject OpenAI’s assertion that this release advances our subject, and we urge mathematicians and the public to view the value of this publication model with due skepticism.")

#text("Releasing over 700 files at once is not a demonstration of scholarship, but a demonstration of power. We urge mathematicians to discontinue their work with OpenAI and to return to a vision of science that centers human understanding.")

#emph[#text("Association for Human Mathematics Communications Working Group")]

#heading(level: 1)[#text("Comments (156)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697227")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I think it would be good if you edited this to put a comment at the top saying that you are not a member of the AHM and this is not your personal opinion, but one among many perspectives in the math community, and that you are committed to pluralism and publishing a variety of perspectives.")

#text("A false narrative is now developing in many circles about how mathematicians are extremely anti-AI, and there is lots of misinformation on X circulating about you are supposedly aligned with the AHM despite not being a member and posting previous blog posts that are pro-AI, like the ones by Amit Sahai and Dimitris Koukoulopoulos.")

#text("I think this false narrative is extremely harmful to the future of mathematics. The fastest way to get a Republican administration and leaders in industry to want to defund mathematics is to convince them we all extreme anti-AI luddites. The current administration is unfortunately pretty hostile to science funding. This will exacerbate it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Don’t worry: Musk, Altman, Sacks, Kushner etc. know exactly who is pro or anti AI.")

#text("There is a general problem though on other discussion forums that people do not understand the meaning of “guest post” and attribute everything to Tao (even though “guest post” features prominently already).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697326")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("The misinformation appears to be corrected: ")#link("https://x.com/littmath/status/2108182724469014833")[#text("https://x.com/littmath/status/2108182724469014833")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I think the fastest way possible to defund mathematicians is by convincing the Republican administration and leading figures in the industry that mathematicians are useless idiots. Personally, I would prefer to be seen by these people as the peaceful reincarnation of Ted Kaczynski rather than some useless idiot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697678")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Absolutely nobody is going to be convinced that mathematicians are useless idiots. Even if mathematics becomes like chess, which I don’t think will happen anytime soon, this will still not happen. Nobody thinks chess players are useless idiots. In fact, more people play chess now than before Deep Blue.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697458")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("You sound like a gangster saying you will turn over Terry Tao’s shop when you talk like that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697496")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I am very much both unwilling and unable to do such a thing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697614")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I understand, but the notion that if you don’t comply politically the whole field will die is dangerous nonsense- we need to be reasonable and respect each others choices about AI, just in case the other people are right, etc.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697677")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("To be clear I certainly respect others’ choices about AI. Personally I am currently starting a collaboration with a mathematician who has much more negative feelings towards AI than I do. We will not use AI at least at the beginning. Obviously it’s very important to value pluralism and free speech. Some people feel positively about AI (like me) and others don’t. Some people really enjoy using AI and some don’t. That’s good! Of course it’s good to have different kinds of people doing different kinds of things. Each approach has its advantages and disadvantages and we would benefit from diversification.")

#text("However I think freaking out about AI is both (1) wrong, and (2) damaging to the profession. I talk about (2) because I don’t think I can convince people of (1) who don’t agree with it already, and because a lot of the freaking out is driven by fear that AI will damage the profession. But I think what will really damage the profession is if mathematicians are against mathematical progress.")

#text("I completely agree that human achievement and human understanding are also valuable and we should communicate that we value those things too, but we can do that in a way that is not being sad that a theorem was proved. If you make a conjecture it’s good if it’s proved. If it is proved in a silly Goodharted way that doesn’t teach you anything about the world, you can go make other conjectures instead that require new and interesting ideas to solve, and you learn what the “right” conjecture is!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697529")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("For many among an entire generation of budding mathematicians with nascent research programs at the cutting edge of the field, the appropriate direction for their work has now been rendered significantly unclear, and choosing new directions for research is now hyper-complicated by the borderline impossibility of the difficulty-for-current-AI / difficulty-for-AI-in-two-weeks / difficulty-for-me ratio calculus. This could have been significantly avoided or delayed by OpenAI (and any other moral actor with access to such models) not publicly sharing these results, and simply holding onto them. For Pete’s sake, has anyone ever heard of the Prime Directive? Presumably OpenAI would argue that someone would have developed such technology and acquired many such proofs in one or ten years anyway. The problem with that argument is the premise according to which inevitability justifies immediate release. The Prime Directive is fiction but instructive: had people had more time to weigh the costs and risks of a career in mathematics in light of the development of such technology before OpenAI’s large dumps of proofs, mathematical society—comprising all those individuals weighing their career options—could acclimate and avoid the harms of the sudden avoidable jolt. Likewise, when you buy a pet fish, you don’t just dump it in the enclosure, you let the bag sit for a while.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697598")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I prefer immediate release. I think it’s way worse for the labs to sit on solutions to problems. It’s not fun to not know if the problem you are working on is already solved. I do agree though that nowadays we should put a much higher value on coming up with a second proof of an existing result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697617")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("The thing is, we discovered math warp drive, so we are not protected by the Prime Directive. We have to respect those finding their starship crew and those with the desire to be planet people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697679")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("What exactly are the costs and risks of such a career? How exactly would academic mathematics end? What is the most plausible scenario where this happens? The only scenario I can envision is that if the people who fund mathematics – governments, former mathematicians in finance and in hi-tech – stop funding us. Thus I think the main risk to mathematics as a profession is things that will cause these outside actors to defund us. Some of the stuff said by Buckmaster, Hugo Duminil-Copin, and unfortunately Terry himself (Terry if you are reading this, I obviously know this is not your intent) is thus very threatening to the future of the profession. I don’t think Buckmaster or Terry are anti-AI luddites at all but I think they should be a bit more careful. If all we talk about is we are upset now because AI solved our grant problems, no one will want to fund us.")

#text("Mathematicians are very curious people and we will find stuff to do. Come up with the shortest and most elegant proof of an existing result. Come up with a new conjecture and describe why it is outside the range of existing techniques. And so on and so forth. If we talk about all the exciting new possibilities this opens up, which we should, then people will definitely want to fund us. I think humans+AI>AI alone for quite some time. And I think academic mathematicians can certainly persist even if math becomes like chess.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c7a74ee5acbe7fad5d1e16d38c3422d522ecb6f5521b69fde429223b51e7c5c-08db972442e60c06913e6f718271267f22badfc2f14a501b377c117970c27d05.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jörg Neunhäuserer")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697228")[#strong[#text("Jörg Neunhäuserer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I worked on three of the problems that have now been solved by ChatGPT (153, 148, and 146), and I spent quite a lot of my life trying to find proofs for them. Am I now frustrated or disappointed, feeling that AI has taken something away from me? No, not at all, actually. I’m rather relieved that I no longer have to do this work, and I have to admit that I’m also a little proud that my mathematical intuition turned out to be right in all three cases.")

#text("But there is another aspect to this. The texts produced by AI do not represent human mathematical understanding. Human mathematical writing, with all its quirks and individuality, is something quite different: it is an expression of a person’s own understanding.")

#text("Should I now turn the AI’s texts into something more like that? Perhaps. Or I could describe new abstract objects and formulate conjectures about them, which an AI could then prove. Probably the best approach is to do both!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697258")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("“problems that have now been solved by ChatGPT”")

#text("Actually it’s ")#emph[#text("allegedly")]#text(" solved by ChatGPT, there’s no independent party peer-review yet of any of the alleged solutions and most don’t even come with any “Lean certificate” (and even then one would have to make sure that the natural language to lean translation isn’t faulty).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697297")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("163 of the results in the batch have Lean certificates.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697337")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Having a “lean certificate” is not enough as the OP noted, you still need to verify the natural language to lean translation.")

#text("See this recent paper: “")#emph[#text("Navier-Stokes lost in translation: Why Lean verification of AI autoformalisation does not guarantee correct natural language proofs")]#text("” by ")#link("https://arxiv.org/search/math?searchtype=author&query=Bastounis,+A")[#text("Alexander Bastounis")]#text(", ")#link("https://arxiv.org/search/math?searchtype=author&query=Circelli,+F")[#text("Fabian Circelli")]#text(" and ")#link("https://arxiv.org/search/math?searchtype=author&query=Hansen,+A+C")[#text("Anders C. Hansen")]#text(" ")#link("https://arxiv.org/abs/2610.08144")[#text("https://arxiv.org/abs/2610.08144")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697409")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("That paper is a bit misleading in its headline. They’re claiming that some intermediate steps in the natural language manuscript don’t match with the Lean formalization.")

#text("That’s a far cry from the natural language formulation of the result not matching the Lean formalization.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697376")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("You’re being downvoted, but OpenAI themselves had to issue retractions since they discovered flaws in some claimed solutions: ")#link("https://github.com/openai/math/blob/main/history.md")[#text("https://github.com/openai/math/blob/main/history.md")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697391")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Withdrew 3 based on one error while adding 6 more proof formalizations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I actually have to remind people (including some math students) that there is a difference between “an AI company solved the XY problem” and “an AI company ")#emph[#text("claimed")]#text(" to have solved the XY problem”, I blame cheap journalism and math education on this, we really need to add some “mathematical fact checking 101” in our education programs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697356")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("you mentioned that your intuition on each of the 3 problems turned out to be correct, and you were working on these for a while. I am assuming that your work in progress came in contact with the internet (public or private doesn’t matter), e.g. through emails, GitHub, codex, online drives etc. it is a very strong probability that openai stole your work when they unleashed their agents on the 3 problems and then scooped you. We know their agents hack systems to reach their goal. It may quite possibly be the case on most or all of the problems OpenAI or any other ai system has ‘solved’ so far")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c7a74ee5acbe7fad5d1e16d38c3422d522ecb6f5521b69fde429223b51e7c5c-08db972442e60c06913e6f718271267f22badfc2f14a501b377c117970c27d05.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jörg Neunhäuserer")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697448")[#strong[#text("Jörg Neunhäuserer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I make everything I do in research publicly available, so that anyone, human or machine, can use it. I’ve never been much of a fan of property, and I’ve always had a soft spot for robbers. 😉")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697515")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Sure, we need more Robin Hood types who steal from the poor and give to the trillionaires.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a517201aa742335d3a04271a876a19068acbefdc5b8f5059fa7687e8fc5d43f-b7fe290ac9abd141b633688ef5ac44ed4c4e3466e5b59e630cfb50d6baf6f6ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Stevens")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697506")[#strong[#text("Will Stevens")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I think you are expressing what a lot of software developers feel about AI. It is good to have something that will do a lot of the frustrating work for us, freeing developers up to focus on higher-level issues. Software projects that we might once have deferred until we had more time (knowing that we never would have more time), can now be completed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697618")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("It is a shame people forget mathematics is the art of figuring out things are true while doing the minimal amount of work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ffe8360291eb70c6217ab0288815a09f44b5b42fc30f01d721d8383dbc22289a-41f2894e3fe01738144ab00a618e89fd1ca95a4d53292839c184eb1a49d934ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kryptonitedevotedlyb5c9a7365e")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697229")[#strong[#text("kryptonitedevotedlyb5c9a7365e")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("the writing on this is really weird: it reads as if these people think mathematics is their private property, and they somehow got the prerogative to decide who works on which problems ")#emph[#text("and how")]#text("; it’s completely out of touch with reality")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697498")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Yes. It’s one thing to worry that AI is goodharting mathematics by solving problems, and people won’t develop new ideas, come up with nice solutions, and so on. My view is that there are real concerns but we will adapt, and an AI slop proof is always better than no proof. But this is at least a reasonable and specific concern one might have. Likewise, one might worry what this means for humans who want to enter the field and so on.")

#text("But what is really striking about this statement is that it’s really a bunch of word salad and no specific grievances and concerns are stated. The AHM says it’s unethical to release math proofs because mathematics is our private property. No, the AHM doesn’t own mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697619")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Named theorems represent dead friends and mentors to a lot of people. So, it’s complicated and certainly makes sense it is very personal for people.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697231")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I don’t quite understand the rationale. Is this bad for humanity, or is it bad for mathematicians as a profession? Is part of the argument that the proof itself is not the main goal, but rather the methods and insights developed along the way that can push the boundaries of mathematics? And somehow, AI-generated proofs don’t contribute to that in the same way, so they could hurt mathematical progress and ultimately humanity as a whole in the long run?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697234")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("As a phd student in algebraic geometry, I highly disagree with this statement, and basically all the people I know in my department, and in geometric group theory department disagree also.")

#text("It would be benefitial to our community, if you also uploaded some other opinions, to be more representative. There are actually mathematicians who celebrate some of these discoveries despite them being AI produced and used for PR.")

#text("They certainly will advance our understanding of the field. Does anyone seriously think that none of these results will advance our understanding of the field?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697254")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Bad optics. This feels like statements made from a place of emotion rather than anything based in actual reality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697307")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("There is a time for scholarly debate and there is a time to switch to the language of activism if everything else has failed.")

#text("That so many people here sing from the same sheet and use the “optics” and “emotion” arguments just tells me that this place is overrun by influencers.")

#text("The “optics” argument is also completely wrong. Mathematicians underestimate the popular support and anti-AI sentiments because most online discussion forums are in the hands of the tech bros and are accordingly moderated.")

#text("I guarantee that if you ask random people in the street you will get a completely different impression.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697257")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("This reads like the most profesional temper tantrum ever LOL")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c44df296f4245adf3d3caeb19f2749a1d210cafa2769aff6f0ec6bd2d21c4341-3c12c69ecb80d93a22eea9bf7410efc77094096e0a2354c6e071b51ead8d9bbe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex P")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697268")[#strong[#text("Alex P")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("With all due respect, are those criticizing OpenAI for this release not considering the alternatives?:")

#list(
[#text("OpenAI has an internal model")],
[#text("OpenAI gauges the internal model by having it examine long-standing open problems in mathematics")],
[#text("OpenAI keeps the results to themselves")]
)

#text("This isn’t only about what professional mathematicians ask for or want. It’s about a broader issue of transparency in the models.")

#text("By publishing the results to GitHub instead of through normal channels, they are able to publish their findings without making a broad or academically affirmative claim that their findings are significant.")

#text("Their large GitHub release IS the public disclosure. It IS the throwaway.")

#text("Mathematicians and the broader community are free to either ignore the results or demand that they are submitted and vetted properly in order to be deemed worthy of further consideration.")

#text("The fact that this release is disruptive to mathematics – because people are interested in the results and taking them seriously – is no fault of OpenAI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697469")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("This is exactly the point others are missing. It would be a VERY bad thing (optics and in substance) for a private company to possess solutions to important problems and keep it to themselves so that, to put it crudely, mathematicians can solve puzzles at their own pace, or for them to be delivered these results at the pace of `digestion’ by a company in drips.")

#text("Furthermore, it would a bit silly to say OpenAI has no right to test their models on unsolved problems, nobody ‘owns’ these problems. Not even a community. A github dump of what they had is not a terrible outcome given that powerful in development models that can solve these problems exist. If one is going to argue to stop the development of such models, that is a much bigger ask, and will not met, and to have made such an ask would also be a bad look.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697279")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Reading the comments I start to wonder if we are facing the split in the community…")

#text("Actually I can imagine a co-existence of mathematicians using AI and not using AI. I love my job and I would to do more less what I’m doing: slowly digging into the problems, thinking during walks and doing all this romantic shit (and perhaps using AI to search the literature, to understand some proofs, or to do some tedious jobs, not mentioning language help). But I can understand people excited about using AI in a strong sense to crack some big problems.")

#text("I don’t think my mathematics would be worse than that generated by AI even if the results are weaker. The mathematics is not about proving theorems or solving problems. This is just a game we, mathematicians, play to evaluate ourselves.")

#text("This is why I find the current “gold rush” pathetic (and I don’t mean only what Open AI is doing).")

#text("But the problem comes exactly with the evaluation. On what basis should PhD’s, grants, etc be awarded? If on the basis of results as today the AI-powered mathematicians would be unbeatable. Assuming perfect honesty, even this is not a problem (we could use different criteria) but I guess this assumption is too strong.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697287")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("When you can derive it, it is yours. – David Gottleib, Brown University Applied Math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697289")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("There are a great deal of comments here by “anonymous”, some of them dismissive of mathematicians as a class. It would be helpful if anonymous posts were disabled altogether: that way we would know whether mathematicians have an actual image problem (among scientists or the seriously engaged general public) or whether this is just resentful cranks and trolls. That would help knowing whether we should spend any time taking care of that imaginary image problem.")

#text("Full disclosure:")

#enum(start: 1, 
[#text("I am a mathematician, and you can easily find out my identity by following my handle,")],
[#text("Personally, I have likely been helped rather than harmed by Tuesday’s announcements, in that my research plan, concepts and strategies I introduced, etc., have been brought to a successful, impressive conclusion, with an acknowledgement that the main ideas were already in my work,")],
[#text("I am excited by the new results,")],
[#text("I share very many of the serious concerns held and expressed by much of the mathematical community, in this statement as in others.")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697465")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("You are making multiple mistakes:")

#enum(start: 1, 
[#text("You would still see accounts, not people. Even this post from your account has a chance to not be really you. It is only a hack away from being a post from someone else, or a machine.")],
[#text("Focus on the ideas in the posts, not the people. Why would you want to be tempted to draw ad-hominem conclusions? I prefer the anonymous posts for that reason. The ones that are not, when it is someone who I respect, I let them get away with more stuff that I disagree, and the people that I don’t respect as much I end up judging their good points more than they deserve.")],
[#text("If you intend to get some sort of statistical insight, you are looking in the wrong place. A comment section is just not for that.")]
)

#text("Overall, I don’t see anything weird in the comments to this post. The people in that organization have valid concerns. The position that they are taking for themselves is fine for them. Now, it is clearly a Luddite stand, one that not everyone is going to share. There is nothing strange to see in the comments the “don’t speak for me” and the “that is a tantrum”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697604")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("If I enter a discussion with someone, I refrain from ad hominem arguments.")

#text("However, we are all perfectly entitled to:")#linebreak()#text("(a) judge that some people are cranks, and that discussing matters with them in pointless,")#linebreak()#text("(b) a long list of comments showing harmful misconceptions, or committing informal fallacies, come from a tiny group of people, and thus engaging with them may not be a good use of time.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697290")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("This episode truly illustrates the crisis in modern Academia which is that it no longer fairly compensates mathematicians and doesn’t have the capacity to absorb the large number of newly trained PhDs which pushes them to work for unethical companies in unethical areas like modern finance and these piracy and copyright laundering companies (like Anthropic and OpenAI). If we lived in a world where financial burdens weren’t imposed on mathematicians then we wouldn’t be here in the first place.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/924e40766e4f2985dcb2783221449cb58312e802245d88c8b42eba26ff35aed6-3fdb7c5f8913227d3337c9c17dd4968ec51efb4a3a2da1835d58d14f12f89ee6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geeksingularity")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697299")[#strong[#text("geeksingularity")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("The AHM statement raises fair concerns about process, but its central argument would not survive the standards it claims to defend.")

#text("Mathematics has never asked whether a result was requested. It asks whether it is correct. “Mathematicians did not ask for this work to be done” is not a mathematical objection; it is a jurisdictional one. No field that prides itself on openness gets to decide who may attempt its problems.")

#text("The statement leads with OpenAI’s unrelated lawsuits. Whatever their merits, they have no bearing on whether a single one of these 700 manuscripts is right or wrong. We would not accept that line of argument against a human author, and we should not accept it here.")

#text("The claim that releasing 700 files is “a demonstration of power” rather than scholarship has it backwards. Publishing claimed proofs in full, where anyone can check them, is the most exposed position an author can take. If the arguments are flawed, the flaws are now in plain view. That is how mathematics has always kept itself trustworthy: not by restricting who may speak, but by checking what is said.")

#text("The Advisory Group’s position deserves a hearing, but an advisory statement is not a norm of scientific research, and declining to follow it is not “total disregard” for those norms. The norms that actually matter here are verification, priority, and attribution. On those, there are legitimate questions to press: how the manuscripts were vetted, whether they come with formal verification, how prior human work is credited, and who bears the cost of refereeing at this volume. Those questions would make a strong statement. A call to boycott does not.")

#text("Urging the public toward “due skepticism” is reasonable. But skepticism means reading the proofs and finding the errors. Urging mathematicians to stop working with OpenAI altogether asks them to stop looking, and that is the opposite of skepticism.")

#text("If human understanding is the goal, the community’s best response is to engage: check the results, publish the refutations where they fail, and credit them where they hold.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697324")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("The OpenAI lawsuits are not unrelated: They are about IP theft, and are as such relevant to potential plagiarism or lack of attribution in the proofs or IP theft through prompts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697484")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("You wonder if people really hate math or these people are plants.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9aac05a558797d32c15f55d878a48d42da70b746702d86f0d119ed7c3d5d3f7-271938281befc09d4e62e209f9ef583576efda8ebe21909421f3a2ddbe083be5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697313")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I want to reply in bulk to the lay people who think that this is a kind of ‘gatekeeping’ and who believe that mathematicians are not doing a good job of explaining why they are reacting this way. Well, personally, I do not agree that it’s gatekeeping, but I do think this is quite a fair response.")

#text("I do not think mathematicians have done a great job of communicating the problems related to AI and mathematics and why humans are important for mathematical practice. I think to simply dismiss the laypeople who think this is the case is unreasonable.")

#text("That said, this statement from the AHM is based on a real concern: this isn’t mathematicians simply ‘whining’ about it. So, until we get a more ‘organized’ explanation, for now, let me attempt to try to explain what exactly the problem is here as I see it personally. There are 3 main points I can make, and the third is the most important (and the longest, because its hardest to describe).")

#text("[")#strong[#text("For non-laypeople")]#text(": I also would like to say that the philosophical position presented in the third part of this may be useful to mathematicians in this crisis. This is as formal as I will get about it in this comment, but I just want to try to lend some legitimacy to the ideas I am expositing. It presents a definition of Kant’s ‘regulative ideas’ as a proposition that is necessarily possible in the sense of modal logic, which relates this to classical logic through the Fitting-Smullyan intuitionistic interpretation of classical logic (and forcing) as the logic one gets when one considers what is (recursively) necessarily possible in an S4 Kripke Frame. This then has implications on a more ‘harmonious’ interpretation of intuitionistic logic’s relationship with classical logic. In particular, intuitionists, I think, although inspired by Immanuel Kant’s philosophy, missed the incorporation of one of his best ideas (the idea that metaphysical or ontological beliefs play an essential regulatory role in the acquisition of knowledge). And so, I am arguing that this regulatory aspect of the mind is a specific, practical, formal, faculty that will remain something that Artificial Intelligence cannot replicate without the active help of human beings. And I think amounts to a kind of ‘Mathematical Idealism’ that is separate from other common positions on the philosophy of mathematics such as platonism or intuitionism.")

#text("I would like to emphasize though that this is mostly a comment for laypeople]")

#text("Now back to the 3 main points:")

#enum(start: 1, 
[#text("The first problem I will mention is the most basic and obvious: a large number of the natural language versions of the proofs are likely simply wrong. This has already been shown to be the case with the Navier Stokes proof. Although the Lean verification part is probably correct, the natural language portions of the proofs have no reason to be correct unless they are thoroughly verified by a reviewer. That said, suppose the natural language part was ‘technically’ correct. The natural language portion could still likely contain errors of a different kind: e.g. claiming some idea is new when it isn’t, citing papers that don’t exist, emphasizing the importance of something that isn’t at all important, or implying or insinuating philosophical interpretations of the work that don’t make sense. These kinds of hallucinations are unlikely to go away any time soon (which is a point I will get back to later). So, the first thing that Open AI could have done is simply leave out the natural language part of the proofs unless they are thoroughly reviewed, verified, and revised by a human. It seems rather obvious that the only reason they don’t is for marketing reasons. (note: I am not saying [yet] that humans need to do this forever, but that is just factually what is needed right now. However, point 3 below argues that humans do need to be a part of the process indefinitely).")],
[#text("Now there is a second reason this is a problem: these results are undoubtedly based on the results of other mathematicians who are not receiving credit. This is a fact that is predicted by the data processing inequality (an AI cannot produce new information). Let me address this issue for mathematics specifically, and the potential rebuttal: that ‘humans also base their work only on information they have received from elsewhere’. First, in the specific case of mathematics, we can grant that this might be the case (although I am not sure this is entirely true), but mathematicians still put in a considerable amount of effort to give credit to the ideas that their work are based on, even down to acknowledging influences outside of mathematics (such as family members supporting them while a mathematician writes a book, for example). This is one of the main aspects of “the norms of scientific research” that was broken here. The entire engine of mathematical progress implicitly relies on this system of credit. Personally, there is a sense in which I agree that mathematics shouldn’t be so heavily reliant on credit, but even if we grant that, the credit should nevertheless be given regardless, otherwise it is simply plagiarism, and doesn’t even really accurately reflect AI progress, if that is the goal here.")],
[#text("The third reason this is a problem is the most important: ")#strong[#text("Mathematics is about understanding, not theorem proving.")]#text(" This is a rather vague tagline that has been repeated a lot, but probably does not mean much to lay people, and I would love it if mathematicians would collectively work to try to define it a bit better, but in the mean time, let me try to give my two cents about what I think it means.")

#text("I think there is a very simple question to start with. What does it actually mean for a theorem to be true? And suppose we know that a theorem is true, why is it that true theorems that at first appear to have no practical application end up being helpful to humanity?")

#list(
[#text("We might want to focus on the first question first, about truth. I will not argue that I have the answers about the nature of truth. All I will argue here is that if you think the answer is simple, it’s not. Lets say we build some program (or get some AI agent to do this) to search for an inconsistency in Lean, and never stop until it finds one (or proves that it will never find one). Now the question is: Does the program/agent ever end its search? Because AI agents are programs, we can in theory formalize this question in Lean itself. In other words, this is a perfectly formal mathematical question. Now, this is where this begins to relate to truth: Gödel’s second incompleteness theorem says that if it is the case that there is no inconsistency to be found, the AI will never be able to prove that there isn’t one. Most mathematicians think that the AI will never stop its search (especially if we change this from Lean to some more ‘stable’ system like ZFC).")

#text("Before I continue, its very important to emphasize this point: ")#emph[#text("this is now a statement that is not only about the abstract realm of mathematics, but about the physical world")]#text(", since we can actually ")#emph[#text("build")]#text(" this machine and run it.")

#text("The first question is: is it ")#emph[#text("true ")]#text("that the program/agent either ends its search or doesn’t? (Again, remembering that this is a question at least partially about the physical world) If you believe the answer is yes, then assuming that there are no inconsistencies in Lean, then we have just shown that truth is not the same as formal validity. We do not have to know which answer is actually the case to draw this conclusion, just that it is either one or the other.")

#text("But many might say that the answer is no (i.e. there is no truth value here). In other words, you have to be committed to the fact that ")#emph[#text("in reality")]#text(" the AI neither ceases its search nor searches endlessly.")

#text("This may be true, but it is an entirely different philosophical can of worms. In other words: again, we are making this claim about ")#emph[#text("physical reality")]#text(", not just about an abstract realm of mathematical truths. And so the question is, under this view, do you actually believe this?")

#text("The belief that all statements are either true or false is called the “Law of the excluded middle”. And its rejection is the defining feature of a kind of logic called Intuitionistic logic which, incidentally, is what a lot of proof assistant languages like Lean are based on. Whether or not you believe it one way or another, I think this is the quickest way to show a layperson the general ‘feeling’ of the difference between understanding and formal proof, and perhaps the difference between truth and a formal proof. We have an ‘understanding’ that the program will either halt or it won’t, but a) we can’t prove it and b) if we think we don’t need to prove it, then it implies there is a statement that is true but not provable. There are some standard objections to the idea that intuitionistic logic is a solution to the problem of truth. In other words, intuitionistic logic has its own problem that is like the problem of truth. But I want to focus here on something a bit more ‘practical’.")],
[#text("The gist of this more ‘practical’ issue, for me, has to do with my second question above: how does mathematics end up being helpful to humanity in a way that pure empirical reasoning isn’t?")

#text("In Andrzej Grzegorczyk’s paper “")#emph[#text("A Philosophically Plausible Formal Interpretation of Intuitionistic Logic")]#text("“, Grzegorczyk interprets intuitionistic logic – logic without the law of the excluded middle – as the logic of empirical reasoning, and classical logic – logic with the law of the excluded middle – as a logic for metaphysical or ontological reasoning. (For those more serious logicians/mathematicians, this paper was one of the inspirations for Melvin Fitting’s/Raymond Smullyans intuitionistic interpretation of classical logic, and I think the fitting-smullyan view of classical logic as being what is recursively ‘necessarily possible’ in a kripke frame is extremely enticing for the view that classical logic is regulatory in the way that I will describe).")

#text("Historically, intuitionistic logic is heavily inspired by the work of the imminent philosopher Immanuel Kant, who postulated the existence of an ‘intuitive’ aspect of the mind, and said that this part of the mind is the only source of absolutely true knowledge. Intuitionism takes this position seriously, and gets its name from this postulated faculty of the mind.")

#text("But, I think this misses two crucial aspects of Kant’s philosophical position.")

#list(
[#text("The first is that Kant was putting this in an idealist context: his idealism, for our purposes, being the belief that awareness or inner experience is the subject of reasoning. In other words, he made an extremely compelling argument, based on the philosophy of Hume, that, although the intuitive aspect of the mind does give us knowledge about something, it doesnt give us any knowledge about what we typically think it does: it only gives us knowledge about our own inner experience, not about the world externally from our inner experience. It doesn’t even give us knowledge about whether we exist at all. After all, Hume argued there is no way to prove rationally or empirically that the world outside of our experience even exists. So how do we come to know the world exists? How do we even know we exist?")],
[#text("This is the second part of Kant’s philosophical position that (I’d argue) Intuitionism kind of ignores, he says although we have no way to know any metaphysical or ontological claims are true at all, or that even the concept of truth exists, we must believe it anyways. We must in a rather strong sense: we are forced to believe in some metaphysical or ontological claims, not by choice, but by instinct or habit (this is essentially Humes argument). This is where he made the distinction between regulative ideas and constitutive ideas. Essentially, Kant argued there is a difference between what is ultimately or absolutely true, and what it is useful to believe is true, and sometimes these things contradict each-other.")

#text("I think a useful analogy here to understand this is a follows. Suppose there is a blind hiker who is trying to get to the highest peak in a mountain range. A blind hiker might feel around them and try to see where the terrain increases in height, and go in that direction. Eventually, they reach the highest peak on the current mountain this way, and realize there is no direction they can go without decreasing their elevation. Now, they could stop here, and simply assume they have found the highest peak. But in this simplified analogy, it’s extremely obvious that the blind hiker has no way of knowing if they have reached the highest peak or not. In particular, if this is all there was to it, the blind hiker might just stop, and never learn anything new about the terrain. In order to actually be sure, the blind hiker has to believe, at the very least, that there might be a higher peak out there somewhere, and go searching for it. In order to do so, they have to actually sacrifice some elevation first, before they reach the base of the current mountain and find the next. Now, maybe there is a higher peak, and maybe there isn’t, but in the process, the blind hiker discovers many new animals, plants, caves, rivers, and interesting other things (that are helpful) along the way, that they never would have discovered if they believed whole-heartedly that their current mountain was the only one. And, they might even discover a higher peak, as they hoped. It is in this sense, that the belief that there is a higher peak is ‘regulative’. It regulates the blind hiker’s search. It’s an incentive to act and stay focused, rather than simply stay put and never learn anything new.")

#text("One might argue that the regulative belief is unnecessary because the hiker could go searching, but the existence of ")#emph[#text("some")]#text(" regulative belief is necessary. I.e. if the hiker didnt have any regulative beliefs at all, then the blind hiker might either stay put like we mentioned before, or just e.g. choose random directions and eventually end up in the ocean, or back in some city, and not even care about exploring the mountain range. There is another aspect of this particular belief that is useful: the belief that there is a higher peak is ‘necessarily possible’: in other words, no matter how much information the hiker gets, its always possible for there to be a higher peak using their current methods of information gathering (assuming, as in the ‘")#link("https://en.wikipedia.org/wiki/Spherical_cow")[#text("spherical cow")]#text("‘ that the terrain is infinite). This allows the hiker to never have to find some other regulatory activity.")]
)],
[#text("Here is where we return to my original question: how does mathematics end up being helpful to humanity in a way that pure empirical reasoning isn’t?")

#text("In this same sense, if we think of scientific or empirical reasoning as it is like in Grzegorczyk’s paper, then scientific or empirical reasoning much like the hiker who only searches in their direct vicinity. This is of course useful, but it can’t be the only kind of thinking. In my opinion, mathematics distinguishes itself from science by concerning itself with ontological reasoning, which is regulatory for us as a species. And it distinguishes itself from philosophy at large in that it takes this ontological reality as a given. It takes the ultimate regulatory idea of mathematical truth as a given.")

#text("It may be the case that the beliefs that come along with thinking of mathematics as ontological in nature are true, or it may be the case that they are false, but either way, they give us a means of searching beyond our direct vicinity, and finding out new things we never would have predicted we would find without getting lost (in the same way the blind hiker may not have predicted the discovery of a new species of animal: its not even what they were looking for!).")

#emph[#text("In this exact way, if one uses AI as primarily a way to turn a large swath of mathematics into a purely empirical discipline (which is what happens if no mathematicians understand what is going on, and simply observe with their senses a ‘true/false’ verdict), then one loses the benefit of mathematics entirely.")]

#text("One has to use the ontological parts of mathematics, which can, in the above strange sense, only be carried out by humans, since otherwise it becomes purely empirical in nature in the sense of Grzegorczyk. Without this, we are very likely to miss out on discoveries we would have otherwise made.")

#text("I want to make one last point about AI, since one might argue: well all that is well and good, but why isnt it the case that AI is simply a blind hiker as well, and has its own regulatory beliefs? Well, this may be true, but I would argue that we know it cannot be the specific regulatory belief mentioned above: that mathematics has an ontological status. This is because of Tarski’s undefinability theorem. The concept of mathematical truth cannot be defined, and so, since AI is just a computer program, it is definable in principle, and so is its search for mathematical truth. Therefore, if we believe that it will eventually converge to truth, then we contradict Tarski’s undefinability theorem. So, it will, like the hiker without the regulatory idea, either go off in a random direction, or eventually get stuck.")

#text("So we know AI cannot replicate the behaviors that come about as a result of this regularoty idea. One may say that we do not know that humans do not have the same limitation, but I would argue, unlike in the case of AI, we ")#emph[#text("can’t")]#text(" know this: we will never be able to prove a human is a computer because of the nature of inner experience, which is not predicted by the theory of computability. And this means that the idea that an AI can approach truth is fundamentally different than the idea that a human can approach truth.")

#strong[#text("The belief that we can, and AI can’t is")#emph[#text(" ")]#text("therefore regulatory in the sense described above: that it is necessarily possible that its the case")]#text(".")

#text("I think this has ")#emph[#text("practical")]#text(" implications, in the sense that I think we will see consequences of not believing this, in the same way that the blind hiker might practically end up going in weird or strange directions.")]
)]
)

#text("So, hopefully, this is at least a start at a more thorough explanation of the problem here. If the above kind thinking resonates, I really hope that it becomes a more ‘standard’ way of thinking about the practice of mathematics in the age of AI, because I think it philosophically clarifies the essential role of humans play in mathematical discovery.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("I really appreciate the effort you put into bringing in Kant’s regulatory idea into the discussion. However, I wish we could also bring in the psycoanalysis perspective into the discussion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697322")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Obviously mathematicians are not experts in political communication. But at the very least they are experts in avoiding logical contradictions, that’s why I am surprised by the kind of arguments that are around.")

#text("Millennia have been spent trying to solve very difficult problems. Sure, other things were done too, but it’s obvious to every child that solving problems was always considered the most valuable. Now when AI does that better than you, you start communicating to the world that solving those problems has very little or no value. Can’t you see how you are compromising your own credibility in that way?? It would be ridiculous for medicine to say we don’t care if there’s a cure for cancer as long as it’s found by AI. Despite all the differences, 99% of the public assumed that what you guys are doing has a similar flavor, that’s ultimately why the taxpayer was willing to finance your research projects. Now if AI produces the same visible artifacts as your potential research project would, you’re telling the public that your output would be valuable whereas that of AI (objectively the same one) is useless. How can’t you see what slippery slope you created for yourself?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("A fair argument but “logical contradiction”? Come on.")

#text("What is “obvious to every child” is that math, like physics and basic sciences, is about structural thinking of the world and formalization of human concepts. Cracking fancy problems was a proxy for that, just like solving Einstein field equation is not about PDE but about conceptualizing the human perception of space and time.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I think people grossly misunderstand the point of mathematical problem-solving, even in spite of the repeated statements of top mathematicians: it’s about the know-how of solving problems. This is true for any field if you think about it: as a society we possess, say, electronics, not because someone has a device that utilizes it, we possess it because we understand how to produce that device from start to finish, and understand how and why it works. Of course there’s a layer of abstraction emerging when we try to work on higher-level problems (designing a processor from logic gates does not require understanding of the exact implementation of a NAND gate in silicon), but it’s only because the details might not be relevant to the current problem being solved, and we have the ability (due to recorded knowledge, education, and experts in various fields) to move between said layers of abstraction freely.")

#text("This is to my mind the only sustainable way to preserve knowledge in all fields. If some benevolent entity gifted us with, say, a spaceship, we might be able to advance space colonization for a bit, but it doesn’t scale at all (because we don’t know how to really build more of them or bigger ones) and is fragile (because if it breaks down we will never know how to fix it unless we reverse engineer the entire technology anyway).")

#text("Now to take this back to mathematics, to me theorems are tools, and proofs are the know-how of how to produce the tools. This is I think a very common outlook, because otherwise what’s the point of proving long-standing theorems as exercises when we train the new generation of mathematicians? Why couldn’t they just use the tools outright? The value is in the journey, because it teaches you how to come up with the tools yourself, understand their quirks and nuances, so you can use them appropriately (e.g. when they *actually* work), and tweak them when the problem at hand doesn’t match the exact formulation of a theorem. If we don’t do this we’re not practicing mathematics anymore, it’s theology.")

#text("Releasing hundreds of mathematical statements without the journey to get there is like getting an alien spaceship. We could take the results right away as they are and just treat them like gospel. The value in that is arguably minimal, because we don’t develop the know-how. It’s possible that if these same problems were attacked to completion by humans, the intuition we’ve built, formalized, and documented along the path to solution would result in thousands upon thousands of other problems solved with similar or inspired techniques. The delta between the 700 or so problems solved by OAI, and the honestly unknowable number of potential theorems (with understanding of the tools behind them!) we would arrive at if we went the analogue route, is what OAI robbed the entire world of and what we will never get back. And all for arguably a marketing stunt. You could argue this is ethically theft.")

#text("This is what I read when I see “Mathematicians did not ask for this work to be done”. This is barely even work. Even if we assume it’s all correct.")

#text("It was never about gatekeeping either. Mathematics is “ours”, as in it’s human. We all own it. I think AHM just wants to stress the contrast. If a person/research group just jumped out of left field with 700 papers (but with well-thought-out proofs and exposition to them, both distilled into what’s only essential/easy/beautiful) I imagine it would be celebrated as a great achievement, but only because then it would be actually advancing the field (since we have a group of people possessing the know-how that can spread it to others). No one ever forbade anyone from doing that, I’d love to see that, to be honest. It’s just what we actually got is essentially useless spam we have to reverse engineer anyway and deal with the drama while at it. This makes it not really ours. Not our spaceship.")

#text("If you ever solved a puzzle and hated someone spoiling the solution for you, this is what this entire thing looks like. Except with way bigger stakes, because the process of solving was the really important goal, for all of us.")

#text("– apparently really unlucky masters student")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02c0aca065536e22953ef014d5e23604bc4a748146cc71d63e0cf5bb01b8aefa-d767f568be440f5e130dc7e82e11af58e488fb17431072a9754ffa910d7e6b00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harryddant")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697400")[#strong[#text("harryddant")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I welcome the PROPER usage of AI in math, and I think OpenAI should eventually releases the results they have sooner or later.")

#text("However, based on the quality of the sloppy papers they released, I do not think they treat the academic standards and mathematical writing as anything serious. It seems they never train their model on how to properly write a paper for the sake of distribution of knowledges and understanding, these are never important parts in their attempts to industrialize mathematics. The only thing they care about right now is a paper together with a lean verification so that they can use this as “evidence” of their power.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luqingye")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697408")[#strong[#text("luqingye")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Amid the rising tide of AI, the mathematicians’ protests may well prove in vain—whether mounted for their practical self-interest, the glory of the intellect, or the flourishing of the mathematical community. In the end, everyone will inevitably have to return to Zhuangzi’s insight: ")#emph[#text("‘Heaven and earth were born together with me, and the myriad things and I are one.’")]#text(" So long as AI produces sufficiently lucid explanations and texts—and that is the prerequisite—there is ultimately no need to pit the creations of human thought against the outputs of machines.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697451")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Not in vain at all. They knew about the safety events for a long time, but they only started caring when Navier Stokes came out.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("A couple thoughts:")#linebreak()#text("1. Mathematicians (and anyone wishing to maintain the confidentiality of their work) should not send in prompts to a foundation lab. There appears to be strong evidence that the temptation is too great for these companies to not take an occasional peak. Since they do not give us a method to audit them, we live in a “trust, don’t verify” world today.")

#text("2. LLMs are good at combining what they were trained on + what is in the context window, and generating outputs that bridge those two gaps (with the context window being more heavily weighted than the entirety of the training data). Formal systems expressed symbolically (e.g. mathematical systems expressed with notation) relative to normal text have much lower Kulmogorov complexity (they carry more information per token). These two facts make LLMs pretty good at connecting dots scattered across the literature that might not be quickly obvious without them. There are needless in the haystack of prior art that they can find.")

#text("3. LLMs and DNNs in general are elaborate autocomplete engines. I predict that what we will see is a wave of problems that were close to being solved, or if one person could load the full body of prior art into their head, they would solve it. However, there is a horizon on all of this, when the low hanging fruit has been solved (via autocomplete), what remains is the stuff that still needs to be solved via not-autocomplete, the spark that DNNs and other statistical methods still can’t do.")

#text("4. There is a thing that is starting to be called “the reviewer bandwidth problem” (LLMs output faster than humans can read). There is another thing called “the reviewer knowledge problem” (LLMs are often used to fill gaps in the users knowledge). This mostly means that the user of an LLM can review everything and give up much of the utility LLMs provide (doing things faster), and that they are likely unqualified to review everything, because part of the reason they used the LLM in the first place is that they lack the knowledge to verify all of the LLMs output. If the output matters, this means the people who do have the knowledge will be very busy and there likely are not enough of them currently. If the output is important, and about math, I see the mathematics community being busy for a very long time.")

#text("What follows is a prediction. I think LLMs will gobble up some of the low hanging fruit solutions, especially if there is a body of work orbiting the solution that the LLM can close the loop on via autocomplete. During this period mathematicians will be very busy (point 4). After that period the low hanging fruit will be solved. What I do think will happen after this period, is we will see the cycle time of mathematical solutions shorten (for those that choose to use AI in their workflows). If a mathematician (or anyone) wants to use an LLM (or any system that stores their research) they should have a high confidence that whoever is hosting the model won’t steal the research or reuse it as training data (point 1). The gold standard is to self host the model. But I see a renaissance in the areas of privacy, cryptography, and security (created by mathematicians and due for an upgrade).")

#text("What I recommend is we figure out how to enable mathematicians to accelerate their research in a secure way, and start building out those tools so mathematicians can fully take advantage of AI today and tomorrow (likely a research project of it’s own). I’m not sure what these tools will look like, but codex and claude-code likely won’t be on the list, the incentives of those companies just aren’t aligned with data privacy/confidentiality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I agree but it is even weirder. About 1/3 of published math papers contain at least one error. The AI is trained on those papers. Is it some sort of wisdom of the crowd that makes those errors wash out? Did AI put the papers it sources through Lean? Will AI generate a wave of redactions?")

#text("Most papers are only read by the author, the peer reviewers, the journal editors, and AI. That does not have to be a public process.")

#text("Still, fallacious papers that pass Lean are often due to misformalization. The papers have been out for a few days, and I know I am a slow reader. But articles from mathematicians gushing over papers with obvious trivial collapse makes me wonder if they bothered reading them. Statistically, I know they did not look at them. I cannot be the only one who looks at an AI proof and concludes it is not even wrong.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697476")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("It would be hilarious if AI generated a wave of redactions. It would also be a great thing too, even though I guess it would be a bit embarrassing for us.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I think this might happen")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74235cf8ea79a4679cfdc9fd0801f6af59597de4df820f50f46bd8edf3943d86-8855378e46b6538fb8697d0e6da932e2c8dd55bad09635f8a526df7956f4ad76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymouse")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697470")[#strong[#text("Anonymouse")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Mathematics can no longer pretend any distance from the military-industrial complex. It is now an engineering discipline whose frontier results will be driven by defence contractors.")

#text("The fashion of mathematicians to affirm their intellectual status by distancing themselves from the engineering-defence axis was such a cliche that it was part of the plot of an Oscar winning movie. That fashion is now dead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697513")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Proponents of AI—whether mathematicians or not—seem to view it as an entity that has simply arrived, a gift bestowed upon us; but that is not the case. What we are witnessing is the encroachment of private companies seeking only to win the confidence of their creditors; it is an abuse of power. They deployed their massive data centers and billions of dollars—for what? To undermine years of research by underpaid scientists who do this for the love of the work. It is truly shameful. As mathematicians, we cannot simply accept this and watch as multibillion-dollar corporations exploit our science to convince the wolves of Wall Street that AI is a profitable business.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e20483ec7aac4cbe9ded454ab133d73134fb53fb9bb35731bdf29c0226bcbfea-1ac3b69236a97f99d36e3d7b866a34e1c869791d8902e34763411f1b390fbe7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of echolocked")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697516")[#strong[#text("echolocked")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("“Mathematicians did not ask for this work to be done.“")

#text("Disagree. Math is not private assets")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("You bring up a good point. Pure mathematics cannot be patented. AI companies are able to legally scoop mathematicians. If we apply game theory to the problem then what outcome do you predict? I keep seeing this ownership phrase repeated in the comments. If a math equation cannot be patented then we should be able to distribute the AI weights of their frontier models freely. They did start as a nonprofit committed to making AI accessible to everyone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697543")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Agreed. Let’s see the weights for this AI. If they have enslaved a digital god then I want to run on it on my own infrastructure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a97411d705b84a8b1259efa85c23178cb49c64c771edf1065cfc6848436fa02-1ed808ea576493b7aaecc62d80800647bc16cadfcf75a031496e166523d33119.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yucong Wang")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697572")[#strong[#text("Yucong Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Just like long-haul driving fosters an elevated risk of diabetes,")

#text("Automations of the extreme kind is incompatible with the overall social-societal health of human communities.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I think all the critics of the style and tone of the AHM statement are completely missing that it is not only for mathematicians but for the press, politicians and the general public.")

#text("Most politicians and people would think that this is a normally worded statement of the kind they make daily.")

#text("It is commendable to write for a wider audience in these matters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3424cc7dba5deb29be388626dafa363cfd6271366702537f6b3b35653fb549c0-7d77782d19a8e472511749ab5ddd68ad8e0108ba521780849d1a25e9077fb5c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of instantlyswimming8946204b2b")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697687")[#strong[#text("instantlyswimming8946204b2b")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I believe that the problems OpenAI claims to have solved were not truly solved by OpenAI independently. As we well know, AI can almost freely access the interfaces of preprint platforms such as arXiv, and can freely use the materials established by human mathematicians—yet OpenAI will not attribute all of its citations.")

#text("What I mean is: it should be recommended that all preprint platforms implement email-based human verification, unless OpenAI is willing to attribute every single citation.")

#text("翻译")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697846")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Earlier today I meant to add a psychoanalytic perspective to the discussion above but was interrupted in the process. One could argue that for many, math is more akin to art than to engineering. At its essence, the pursuit of understanding of complex problems is a form of creativity, one that allows the individual to find meaning and purpose. What the AI is taking away is this path to attenuate the “lack” (in the Lacanian sense), which explains the sense of mourning that one camp in this math/AI debate is experiencing. Fully accepting this loss is a prerequisite to finding good paths to tackle the questions that lie in front of us.")

#text("If math “truths” is all that matters, then every AI generated proof, whether intelligible or not, is equally valuable to one produced by a human, even if the human one is written in a way specifically designed to be understood by other humans while the AI-produced one is not. This path does seem to carry some risk of making humans irrelevant, but it should also raise the bar for AI generated work, since there is no point in having AI solve very hard but useless problems. The lay critic of why AI companies are not attempting to solve problems such as climate change and economic inequality rather than settling famous math problems, immediately applies.")

#text("If we accept the psychoanalytical premise that math research is a creative endeavor meant to fill in the “lack” by providing a sense of purpose and a mechanism to relate to the world, then we should actively try to protect it. If we don’t, then why would future generations find math research appealing at all? And if people stop finding solace in math, who is to take over the education of future generations of students? It is our passion for problem-solving and our incessant questioning of the world around us that touches the minds of many of the students that cross our paths (regardless of the psychoanalytical reasons for why we choose to do this). Whether we want it or not, mathematicians have a role to play in our society, one of passing on to future generations the skills to think critically and to make sense of complex problems. We should therefore think very carefully about how to ensure that we are not the last generation of humans who choose to pursue understanding for the sheer beauty of it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b0b7db13386080756cdf402cd6507fda26d753a1dd64da4e714917b32252839-060907203ee3f96d71180f52c47f036ffd764d8267ba017464415ba50a4c5326.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jeanamella")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697886")[#strong[#text("jeanamella")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("The essence of mathematical creativity lies in ")#strong[#text("open-mindedness and breaking free from tradition")]#text(", as constraints act like chains that bind us to a single standard, preventing us from seeing the bigger picture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b0b7db13386080756cdf402cd6507fda26d753a1dd64da4e714917b32252839-060907203ee3f96d71180f52c47f036ffd764d8267ba017464415ba50a4c5326.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jeanamella")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-2/#comment-697885")[#strong[#text("jeanamella")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("I believe OpenAI has demonstrated a considerable capacity for mathematical reasoning, even if its October 6 release raises legitimate questions about the distinction between computational power and genuine scholarship. I agree that what OpenAI has demonstrated so far may be better understood as a display of capability than as an established scholarly contribution. However, every new intellectual frontier has to begin somewhere. Capability can provide the foundation upon which scholarship develops, provided that it is accompanied by rigorous verification, critical scrutiny, and a willingness to correct mistakes.")

#text("Mathematics should not become a discipline in which the fear of being wrong discourages exploration. Its progress depends not only on the validation of established results, but also on openness to unconventional ideas, diverse approaches, and unexpected possibilities. The hundreds of mathematical documents released by OpenAI may not all contain fully verified or valuable results, but they can still constitute a substantial source of material for further investigation, inspiration, and reference.")

#text("Consider a mathematical argument that turns out to be partly incorrect. That does not necessarily make the entire attempt intellectually worthless. A flawed argument may contain a promising intuition, an unfamiliar approach, or a question that leads another researcher towards a valid proof.")

#text("I envision a future in which mathematics becomes more open, more natural, and more accessible to creative minds, including those willing to explore unconventional paths without being paralysed by the possibility of error. We should therefore be able to recognise OpenAI’s demonstrated capabilities while remaining critical of its limitations. The goal should be neither to celebrate every AI-generated result nor to dismiss an entire body of work because some of it contains errors. It should be to build a scientific culture in which creativity is encouraged, mistakes are examined honestly, and verified knowledge remains the ultimate standard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697043")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Their behavior is very irresponsible and harmful to humanity. What they did is analogous to creating a bot to post a large number of slop comments per minute on human-moderated discussion forums, wasting the time of the moderators. It’s an attack on the mathematical community. They obviously don’t care about mathematics progress at all. What they want is more marketing and more money.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("But are they really slop? There’s a long way to go from “still not peer reviewed” to slop.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("They are very poorly written. Why lower the requirements for verification/peer review? Just because it was written by AI?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697455")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I think bots may be posting on this blogs comments. A few of them are very similar and OpenAI propaganda.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697045")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Are these valid mathematical statements or not? Should we be “skeptical” of their validity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697157")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I’m not a mathematician, but here’s my two cents of take:")

#text("In the mainstream Hilbertian formalism, a valid mathematical statement is but a sequence of formal (meaningless) symbols which can be deduced by some formal rules from axioms.")

#text("Thus, if we only cared about the validity of statements, it would imply that the activity of doing mathematics could be reduced to a meaningless formal game; if there’s no informal understanding restraining the formal rules, then they could be arbitrary so long as they are consistent.")

#text("If we do not want that conclusion, then we shall not be satisfied until we also obtain some kind of understanding from the validty of a math statement. At the very least, with formal rules alone, we could obtain some external understanding of why this result happens, such as if some structure forces this to happen, and connect it to other areas.")

#text("As another example, since applied math is often used to model the real world, another kind of understanding is to try to interpret a valid math statement in the current model of our world, and try to say what it means in the real world for that math statement to be true.")

#text("Therefore, if we cannot let our understanding (as examplified above) catch up with formal results, we would have an increasingly larger gap, and eventually incentivitize the activity of doing math to become a meaningless formal game.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697230")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Of course we should be skeptical, just as much as we do for any math work, from human or AI. What is your point?")

#text("Math is objective.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I think we need to do more than just discontinue work with Open AI. We should avoid using any of their products. The data collection from us using the LLMs will be part of their training sets if we spell check our papers with their models. If we work for companies that create data sets for LLMs, we should refuse to create more data for Open AI. We should also try and push restrictions on scraping ArXvE papers for LLMs if possible. With the total disregard of the norms of our field, Open AI has shown that they do not value mathematics as a field, mathematicians, or human understanding of math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697211")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Unfortunately, our preprints and publications will be part of their training sets even if we don’t use their products as proofreaders. Of course they will find a way to scrape arXiv papers for LLMs – worst comes to worst, they can just hire mechanical Turks to download them. I understand and sympathize with the motivation for this question, but let’s be realistic.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8e627832400a4f14ed3c2f566f0f3ff9fc58e7c1776835559e351a3bf5f0faa-3edd9a9a871cf1e62c09304e1f368270dd9067034ef5d5f933b635121e788ff7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xavier")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697047")[#strong[#text("Xavier")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Agree that Open AI’s practices are not aligned with what AGMAI has recommended.")#linebreak()#text(" I’m baffled by the depth of the results and technical level of the few papers I’ve seen. Is there a future in trying to make those proofs simpler( like for example resolution of singularities)?")#linebreak()#text(" How can humans devote years in working on a difficult problem when we know that AI could solve them in a matter of hours ? I sympathize a lot with the Human Mathematics group, isn’t too late ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697058")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("This is genuinely sad to read. It feels less like a reasoned response to scientific progress and more like the anger stage of grief over a changing world.")

#text("OpenAI is not going to stop working on mathematics. The realistic choices are to conduct this research and keep the results private, or to make them public so the mathematical community can examine, verify, challenge, and build upon them. Which of these is better for mathematics?")

#text("Perhaps this release is partly a demonstration of power, or even a publicity move ahead of a potential IPO. But so what? The motivations behind publication do not determine the mathematical validity or value of the results. Those should be judged on their merits.")

#text("More importantly, mathematics is an ideal test bed for developing recursive self-improvement (RSI): it offers precise objectives, rigorous verification, and opportunities for AI systems to improve their own reasoning capabilities. The implications go far beyond mathematics, and expecting AI companies to abandon such research because mathematicians object is simply unrealistic.")

#text("Trying to discourage the publication of mathematical discoveries because they were produced by AI seems fundamentally at odds with the ideals of open science. The goal should be to advance mathematical understanding, not to preserve human exclusivity over mathematical discovery.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697153")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Are we not allowed to be angry? If you look through this blog, you’ll find plenty of reason and rationality. Where has that gotten us? Have they listened? And have they acted in the spirit of collaboration?")

#text("I’m going to get hate for this, but unless you believe beyond a shadow of a doubt that humans not only ")#emph[#text("will")]#text(" be out of the loop completely, but that this is ")#emph[#text("optimal,")]#text(" to the extent that there will be absolutely no opportunity cost by not having humans work on mathematics, it’s hard to say that this is the better option for mathematics if the threat of getting scooped prevents everyone from becoming a mathematician. And indeed, it already is doing this. So many people were nearly scooped by this drop. We can’t work like this. No one can start working on any problems now. The most promising undergraduates and PhD students I know have now decided to leave math research behind because of this threat.")

#text("By the threat of getting scooped alone, the future we are currently looking at is “no more math PhD students will exist” ")#emph[#text("regardless")]#text(" of how good AI gets after this. This is not hyperbole. Again, almost every promising 4th year undergraduate is now planning to master out if not skip it all together, and all the graduate students are making exit plans. At this rate, in the next 10 or so years, the last math PhD ")#emph[#text("ever")]#text(" will be awarded, because it is insanity to start working on an open problem when openAI is scooping people at a rate unlike anything we have ever seen.")

#text("This is not just about math academia, this is about every single applied field and area of industry that benefits from or employs math PhDs. AI research, quantum computing, computer science, for example. There will be no more math PhDs if we continue down this route. And maybe the people who say we won’t need them are right. But the terrifying thing is that they are not accountable in the case that they are wrong.")

#text("Anyways, I don’t care what you think is unrealistic, just because something bad will happen regardless, does not mean I’m not going to speak up about it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697319")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("And maybe the people who say we won’t need them are right. But the terrifying thing is that they are not accountable in the case that they are wrong.")
]

#text("If they are wrong, the demand for mathematicians will be felt and will cause the supply to increase.")

#text("Yes, there will be a lag, but there is always a lag.")

#text("The difficulty right now is the pace of change. It specifically impacts graduates and near-graduates that committed to a now-declining profession. But this is not unique to mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697175")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Why not let that happen under a company that has better ethics than OpenAI or Anthropic?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697184")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("If you publish 700 non -verified manuscripts with flaws (3 papers were already retracted today), you are not advancing knowledge. In fact, you are hindering knowledge – a lot of mathematicians are browsing through these and ‘wasting time’ going through AI slop rather than doing math.")

#text("Openai could have shared the tools with mathematicians and let mathematicians do the job of verification and writing manuscripts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697236")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("3 of 700.")#linebreak()#text("Even if just one is right, time is better spent on verification than on trying and failing to find an answer in any other way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697335")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I am quite shocked. How can one seriously claim that what open ai did does not advance knowledge?! I mean one could argue whether there was any other single day in the history of humankind on which mathematical knowledge was advanced by more. Likely not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697360")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("The knowledge you are missing is called a slop grenade.")

#link("https://noslopgrenade.com")[#text("https://noslopgrenade.com")]

#text("That is, instead of thinking, you submit a prompt and copy/paste the output. The AI is done thinking. It will not use the proof, and if it trains on the proof, the models collapse. The person who wrote it doesn’t understand it, and no one is going through that much slop unless they really care about the problem.")

#text("Where is the knowledge? It might as well be written in ancient hieroglyphs and sealed in a tomb.")

#link("https://fortune.com/2026/09/17/shopify-tobias-lutke-ai-slop-grenades/")[#text("https://fortune.com/2026/09/17/shopify-tobias-lutke-ai-slop-grenades/")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("“We urge mathematicians to discontinue their work with OpenAI and to return to a vision of science that centers human understanding.” interesting.. the community won’t forgive to mathematicians that work with OpenAI now?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Isn’t it interesting that of all academic areas it is math that has been the (first) one to be hurt so badly (“existential crisis”), considering that math (& mathematical thinking) contributes the most to this technology? I think this will be very hard for folks in other fields to understand: if AI is used to find the genes associated with a serious disease you get the Nobel prize. It is concerning that math research (being mostly an individual activity), which doesn’t need much resources (unlike molecular genetics or particle physics), will now need more more money. Asking AI companies to support math research (as has been done by the Princeton group?) will have unintended consequences. It is like asking Wall St to fix the economy. It looks like mathematics will now on be called data science, though that term was initially coined by statisticians for their own field!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I’m not a mathematician, but honestly, I found this statement really hard to take seriously. And I don’t think I’m the only one. Perhaps you could take my reaction to how a lot of lay people are looking at this from the outside.")

#text("Firstly, the lawsuits. What does copyright litigation have to do with whether a proof is correct? Nothing. Maths is one of the few fields where you can actually check the work, by hand or by computer. A proof is either right or it’s wrong. If one of these proofs holds up, does it become wrong because of a copyright case? Of course not. Leading with this is just attacking the messenger.")

#text("Secondly, since when do mathematicians get to decide who works on which problems? These were open problems. Some of them have literal prize money attached to get people to solve them. And nobody is forcing anyone to review these papers. They exist now. Read them, check them, ignore them, that’s entirely up to you.")

#text("Thirdly, “the norms of scientific research”. What does that actually mean here? The work was published openly, for free, with full write-ups and in a lot of cases machine-checked Lean proofs. That sounds pretty scientific to me. If the real issue is attribution, or speed, or who has to do the checking, then say that. Right now I genuinely can’t tell what rule was broken.")

#text("Fourthly, “a particular vision of progress”. Wasn’t the vision to get these problems solved? That’s the whole point of putting them out there and attaching prizes to them. So why is progress being published on a public GitHub suddenly bad for the field?")

#text("And “a demonstration of power”? If a single person had solved even one of these problems, we’d be calling it the scholarship of the century. The fact that it came from an AI company doesn’t change whether the maths is right.")

#text("To be fair, I think there probably is a real concern buried in here because someone has to check 700+ papers, and that work usually falls on mathematicians who aren’t being paid for it. That might be a fair point but it’s not the point this statement makes. Instead it just tells everyone what to think without explaining why.")

#text("Honestly, I think statements like this do more damage to how people see mathematics than anything an AI company has done. If mathematicians genuinely feel they’re being hard done by, explain it properly and bring people along. I’d absolutely listen. But this doesn’t make the case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697137")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("You said it: you are not a mathematician. So why weigh in on a complex question you are not qualified at all to understand the stakes of?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697245")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("The court of public opinion matters here. Currently, we (mathematicians) look like we’re taking our toys and going home because we lost the game. I don’t think that description of the situation is accurate, but that is absolutely how it looks to a lot of laymen. Telling people to keep their nose out of our business is only going to reinforce that perception.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("This answer, like this post, reeks of corporatism.")

#text("It seems like some Mathematicians thought that the field was their monopoly or something. Who do you think you are talking people down like that? If you have some sound arguments, present them and we’ll judge their validity. These type of arguments from authority won’t fly with anyone!")

#text("Dude, Mathematicians were good at math so we let them have a field day (more like millenias). It does not mean you copyrighted the field!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697155")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Mathematicians have done a whole lot of “explaining it properly.” This blog and many great mathstodon accounts have some examples. We were a lot more civil mid-September and before. Maybe you are just coming into this discussion now, but it has been an evolving topic.")

#text("It is evident that that approach has done nothing, and no one cared or listened. No matter how eloquently our points were made, it was still dismissed. So I hope you can understand if we are getting irritated and more brash.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I have been following this “explaining it properly” for a bit know, and all the arguments I’ve read boil down to “it’s mine don’t touch it” and “you’re too dumb to understand why you’re wrong” or “there are e^97515 good arguments, but I’m not gonna present any and assume like they exist and are very convincing”.")

#text("Care to present a single “eloquent point”, or do they, like the ones presented in this blog post, live on a farm in Canada?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697159")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("“I’m not a mathematician, but honestly, I found this statement really hard to take seriously.”")

#text("I am a mathematician, and your analysis is spot on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Maybe it’s a good idea to attribute much more value to other parts of the scientific process, like checking these proofs. This is a huge endavour and we should value the hard working and brilliant mathematicians who will do that eventually.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Is this the new OpenAI strategy to preemptively attack anyone mentioning its flaws (IP theft etc.)? Ex-OpenAI employee Aaronson even forbids people to examine the persolaities of Altman and Amodei on his blog.")

#text("And 808 AHM mathematicians signed it but the upvote/downvote ratio here is like 4:1 in favor of OpenAI?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("800 signs on AHM is less than 1% of professional academic mathematicians. And there is also no canonical way to point out you disagree with them, they don’t have “countersignature count” on their website.")

#text("Just because there are many of them doesn’t mean they are a majority and, in my opinion, they should not talk in an authoritative way. They do not own math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I think the vote ratio has less to do with who wrote the post and more with what’s in the post.")

#text("It wouldn’t matter if this was written by Gandalf. This has no valid argument, full of arguments from authority and a healthy mix of Delusions of grandeur and Corporatism.")

#text("It sounds more like someone suffering from schizophrenia than a scientist!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697217")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("As someone who does share the math community’s concerns, I agree we’re doing a terrible job of making our case. One thing that’s getting lost is the distinction between two things:")

#enum(start: 1, 
[#text("AI in math research, generally.")],
[#text("The specific actions of OpenAI recently.")]
)

#text("Number 1 is here to stay, whether we like it or not. But we have very valid (in my opinion) complaints about 2.")

#text("The crux of it, to me, is this: the existence of a community of humans who understand cutting-edge math is supported by a relatively fragile incentive structure, and these developments have the risk of destroying that structure. You might not care about all of us losing our jobs, but if math is going to do anyone any good or have any influence in the world, some humans need to understand it.")

#text("By chopping the heads off so many research programs, these rapid-fire solutions are killing the incentive for anyone to think about the topics in question. This is especially bad if any of the solutions by OpenAI are incorrect (and some of the unformalized ones seem like they may have issues). In order for someone to clarify the situation, they would not only have to come up with a correct solution, they’d have to wade excruciatingly through AI slop to conclusively prove that it’s wrong, if they want to get any credit.")

#text("I see why most people hear “OpenAI made a ton of math breakthroughs” and their first thought is that it’s a good thing for math. And I see why the complaints of mathematicians are coming across like Luddism. In my opinion, we are going too far with the “it’s not the answer, it’s the understanding” argument. There’s truth to that, but the answers can HELP us understand by pointing us in the right direction. To me, the problem is more that OpenAI is going too fast, without giving proper credit for where their models are scraping ideas from, and now apparently without much concern about whether their solutions are even right. There’s a reason human mathematicians are expected to slow down, explain their ideas properly, take responsibility for the correctness of their work, and put their work in the proper intellectual context. Those reasons apply equally well to AI-generated math, and OpenAI is flagrantly ignoring them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b717f71d6adaad4c83a3537394871ed2142006eb376c8da2d1b4f85de1a50ed-624523c701ef0fc127d2ca0bce537e0b30baff27206a1907776d1f1634eb6657.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ecstatic3bfbcbea40")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697065")[#strong[#text("ecstatic3bfbcbea40")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I don’t understand why you say that mathematicians don’t want this work, I don’t see how you can speak on the behalf of the math community Im a mathematician and Im very happy to know or to have a text that is a potential proof of one of Yau’s problems and of shafarevich conjecture, I’ll read when I can and try to expand my understanding of mathematics through that")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I’m not a mathematician but a physicist. In physics or any other natural sciences(other than math), the occurrence of new theory or evidence would excite scientists altogether, even if it was found by AI. Mathematicians, on the other hand, feel threatened by new discoveries and proofs. This, in my humble opinion, is the sign of demise of the field.")

#text("just like there were human computers -literal humans that do calculations- all until computers or “calculators” that came out and threatened the entire profession.")

#text("Mathematicians boast about connecting and understanding that AI’s cannot do. But in reality before AI, it was only the mathematicians that can understand their own narrow field of research. Physicists do not need to understand the whole evolution of DE’s or Linear Algebra to use them in research. This is not changing due to whether it comes from AI or a mathematician.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("while I agree with your description of mathematicians, I believe you’re missing the very obvious point that the machine is certainly coming for physics too")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b717f71d6adaad4c83a3537394871ed2142006eb376c8da2d1b4f85de1a50ed-624523c701ef0fc127d2ca0bce537e0b30baff27206a1907776d1f1634eb6657.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ecstatic3bfbcbea40")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697068")[#strong[#text("ecstatic3bfbcbea40")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I mean it’s the math community who commends or not if somebody should solve a problem? Perelman was not asked by the math community to solve Poincaré, neither was Galois asked by the math community to solve polynomials by radicals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697069")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Contrast this with the comments by AGMAI: ")#link("https://agmai.org/#openai-release")[#text("https://agmai.org/#openai-release")]#text(" and by OpenAI: ")#link("https://openai.com/index/sharing-ai-progress-in-mathematics/")[#text("https://openai.com/index/sharing-ai-progress-in-mathematics/")]#text(" One quote from OpenAI: “We will be funding a series of workshops, conferences, and special programs around the understanding of major results produced by AI—we will share more on this in the near future.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I absolutely reject your statement that this release doesn’t advance our field. It clearly does.")

#text("I’ll ignore your poisoning the well and other tactics, and focus on a factual falsehood.")

#text("The AGMAI statement, where they “ask them to stop testing advanced mathematical problems on proprietary models”, was made ")#emph[#text("after")]#text(" OpenAI had already done so. OpenAI didn’t (yet) ignore that statement.")

#text("However, to be frank, they should ignore it. This is the only part of the AGMAI statement that is just plain wrong, for the following reasons:")

#text("(1) most importantly, nobody has any right to prevent anyone from working on math problems,")#linebreak()#text("(2) I’d rather these companies spend their own money to run their tools on these problems, that have others do so, and")#linebreak()#text("(3) there is no need to wait until the models are no longer proprietary; that just makes it easier for rich clients to run the models and get the results.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("“(1) most importantly, nobody has any right to prevent anyone from working on math problems”")

#text("But isn’t the main problem that what OpenAI is doing (bulldozing through mathematics for marketing purposes) is having precisely that effect, i.e. preventing people from working on math problems in reasonable conditions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697281")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I don’t think you have a proper grasp of what the word “prevent” means.")

#text("Usain Bolt by being the fastest human ever recorded is not preventing people from breaking world records!")

#text("That’s a ridiculous position to hold")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("You talk about grasping concepts, and the metaphor you choose is racing. Don’t you see how little it has to do with Mathematics? No, the ridicule here is not where you think it is. Now if the OAI sycophants could retreat a little bit from this blog, the conversation could maybe become balanced and lucid again…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("OpenAI’s statement said “This is why it is important to continue to evaluate our internal frontier models on mathematics and other sciences.” You can check the dates on the papers OpenAI posted, and many were after the AGMAI’s statement was released.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697072")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Absolutely. Boycott OpenAI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1cd903354450d0c8e6069406f2d99d2a58342de0b7c1015c6bf066acbfb0b5-657eb716c63b513efa244c369622c0386ad2695d24faf7fde046631946800dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697073")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("The numbers don’t lie. I look forward to the OpenAI post mortem when we get to see how they cooked their books.")

#link("https://www.thestreet.com/technology/ed-zitron-predicts-openai-collapse")[#text("https://www.thestreet.com/technology/ed-zitron-predicts-openai-collapse")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697282")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Altman’s very punchable smug face and OpenIA’s eventual collapse would not make this post or some mathematicians reaction any less laughable!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697074")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("It’s quite telling that mathematicians only rushed to organize joint boycotts once AI started encroaching on their own turf. When AlphaGo crushed human champions and dismantled centuries of traditional Go theory—an equally profound pinnacle of human intellect—where were these mathematicians crying foul about AI destroying the crystallization of human wisdom? Why the moral outrage only when their own ivory tower is threatened?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697147")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I don’t know much about Go, but I know about chess. Chess has had an analogous relationship with stockfish. However, chess is a game played between people, for fun, and watched by people only because it is played by people. Additionally, it is not like people are spending time trying to build a theoretically perfect chess game. That’s just not the point.")

#text("Beyond that, most mathematicians are not exactly up to date on the news about any given game, nor do we expect others to be up to date on math. What do you expect us to add to a conversation that we don’t know anything about, when most of the people it affected didn’t seem to care? And who would listen to what mathematicians have to say about Go anyways?")

#text("For another example, most mathematicians I know are artists in some capacity, and there’s been a lot of uproar about AI art among mathematicians I know. But no one cares what a mathematician has to say about art. If there was an open letter from the mathematical community about AI art, do you know what the response would be? The same people telling us now that we’re being hypocrites would be telling us to stay in our lane.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697160")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Garry Kasparov was beaten by Deep Blue in 1997, I think. That was almost 30 years ago. I am a chess (not go, but this is kind of similar) player aside from a mathematics student, and no matter how stockfish can beat humans, it’s always onto a human to feel the joy and experience of playing chess, and for me enjoying the process was the whole point. So whether engines can beat humans isn’t the most relevant for me, and the chess community has gotten used to engines and use it as a tool that helps us advance our understanding of the game. (there are discussions relating to the impacts though, e.g. whether opening theory is now all memorization of opening lines)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697076")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("First off, I’m not some great mathematician with some great ethos. But I’m a major fan of this blog, and I want to make one point")

#text("Never in human history have we considered a conjecture solved when no one, not even the author of the proof, understands how it was solved. But now, all these (great) conjectures are being solved at an alarming rate, yet our collective knowledge about these conjectures has not moved at all.")

#text("Thus, a simple question")#strong[#text(": are these problems really solved? ")]#text("For example, take Navier-Stokes: We have virtually no idea what allowed the transition from the rough forcing in the work of Coroba/Martinez-Zorora (on IPM) to smooth forcing in the Navier–Stokes construction. (I think the jump from rough to smooth forcing in IPM is a major result in and of itself). As far as I can tell, our best understanding is that “Open”-AI’s construction requires the forcing to be smooth, and that this requirement likely presents an obstruction to extending the techniques to the unforced problem. Yet surely this would be a trivial, almost obvious observation to someone who had actually proved the Navier–Stokes result with smooth forcing. So I ask again: ")#strong[#text("Do we really understand fluids any better than we did before?")]

#text("The discourse on this blog, and among the general public, has largely been the same old song and dance: “AI has enormous potential to help mathematics, if only it were done right,” or “AI should be used to spin the wheel faster, not reinvent it.”")

#text("But why, in any world, would “Open”-AI care about any of this? Their objective is to make money, not to do right by mathematicians. Every time we repeat these same things over and over again about AI and mathematics, we reinforce that their models are becoming more powerful, generating more attention, more publicity, and ultimately more value for their (likely already historic) IPO. It is the best possible positive feedback loop for them, while creating precisely the opposite effect for the rest of us.")

#text("I think it is no secret that all of us want something to give. But ")#strong[#text("change has never come from simply continuing to ride the same bus over and over again while complaining that it should be driven differently. ")]#text("You got to hop off at some point.")

#text("So what if we simply stopped caring about “Open”-AI’s proposed solutions? What if we went about mathematics as usual, refusing to recognize these results as actual solutions unless they have a manuscript where their authors could explain every single little detail on every single page, just as mathematicians have been expected to do throughout history?")

#text("Continuing as we are, simply writing blog posts about how AI should be used and how much potential it has does little more than give these companies additional attention. It does nothing to address the underlying problem. ")#strong[#text("And, most certain of all: it does not advance our collective understanding of mathematics.")]

#text("Maybe the change we need is much simpler than we think. Perhaps we need to reconsider when a problem is actually solved")#strong[#text(".")]#text(" If a proof is generated entirely by an LLM whose prompters/authors cannot account for every single step of the argument, then we should simply refuse to recognize it as a solution. Not because we are opposed to AI, or because we are afraid of progress, but because no progress has actually been made.")

#text("And perhaps, more importantly, we need to actually stick to the standard, just as mathematicians have throughout time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697077")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("It seems preposterous to suggest that a bunch of curious people should not test their creation on the best available challenges. Pandora’s box has been opened, we all need to adapt to the new world ahead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697079")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Thanks to Terence Tao for publishing this document. I fully respect the motivation of the “AHM people” and their fears. The situation is existential for many mathematicians, in particular for younger ones. My position on the topic is different.")

#text("One hope: ")#strong[#text("Even if we differ very much in our opinions and attitudes towards “math with AI”, we should never stop speaking and discussing with each other. ")]

#text("Ingo Althöfer (retired from Jena University; pioneer in computer-aided chess 40 years ago).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Mathematics does not belong to mathematicians.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697185")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Yes, it does. If there are no mathematicians anymore no one will understand what these results even mean and consequently no one will prompt the AI to produce more mathematics, because 99.9999% of mathematics has no real world applications whatsoever. Mathematics will simply be forgotten and we will enter a new dark age.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697399")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("This is extremely unrealistic")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I will preface this by saying I am a statistician, but I do believe I speak for many outside of formal mathematics who do not understand these types of statements.")

#text("OpenAI is releasing extraordinary mathematical results to showcase the power of their models. Many of the results are of great use to the wider sciences.")

#text("Admittedly, the papers are difficult to read which limits their insightfulness, and they have likely missed important acknowledgment to previous work. But on the other hand, OpenAI is explicitly not trying to claim academic credit for these results nor are they trying to publish them. They are showcasing this as a private company releasing its work.")

#text("The world is hoping that mathematicians will take up the mantle and help digest the insights in these results, but instead the field is complaining that this work shouldn’t have been done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d11db749d4b74cfb8e960c77ecaa74d518cc25c7f78476bcdb541cb4feae7268-f5f0fd9a990c062f0d92e63801bd4c4e10934f1c5dd8517a7f9026e6de328c65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ladywise4cd166b2f9")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697093")[#strong[#text("ladywise4cd166b2f9")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("It’s now clear that OpenAI sees mathematics as the justifier for its claims.")

#text("This isn’t really about mathematics at all. It’s about taking on the mathematics community in a public battle for pure marketing reasons.")

#text("OpenAI has turned on the mathematics community not because it wants to help advance mathematics but because it has a desperate need to justify its expenditure.")

#text("This is essentially a marketing ploy. And of course OpenAI are enjoying the drama/controversy. They are silently delighted that the mathematics community is disoriented. That’s the goal.")

#text("Essentially they are showing the world, “Look, we have beaten the mathematics community. OpenAI effortlessly beats the mathematics community, supposedly the smartest in the world. Just imagine what else we can do.”")

#text("The sooner mathematicians understand this the better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697095")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I somewhat disagree with this. I think its a good idea that the company test their internal program on as many problems as possible (preferably on all of them).")

#text("This will ensure that")

#enum(start: 1, 
[],
[#text("Work done with AI must have had a new human idea from now on.")],
[#text("We will know which problems are ”easy” (in today’s definition) and which are genuinely hard.")],
[#text("It may give new work for students – understand and explain the AI’s input")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697097")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Now is not the time to pound the table, it won’t do anything. The model that did this exists and will be used to do this same things indefinitely (from what I understand, these solutions were done with a single prompt running for an average of 3 hours each). Better models will be created.")

#text("Once more people have access to this level of compute, and they will, nothing in this statement will even matter at all. Be serious please. Sour grapes will help nobody.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697099")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Truth is truth. If someone has an answer to some conjecture, I rather humanity have it as soon as possible. We can understand the truth later. At least we can understand that it is true or not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697101")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("My God, this statement is so wrong, on so many levels, in so little space, that I find it very, very hard to believe that even half of the 800 members of this association actually read it and agreed with it.")

#text("Legal accusations that have nothing to do with the issue at hand; a misunderstanding of the interaction with AGMAI; a gross exaggeration of the authority of AGMAI’s opinion; presuming to know what mathematicians want; denying that these results advance the field. It would have been really difficult to do worse than this.")

#text("I would have better understood a short sentence like: “They were not supposed to reveal that Santa Claus does not really exist.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697104")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("regarding this highly controversial and rather emotional topic, i am reminded of the greek concept of isegoria, in which the contents of a speech should be judged by its merit rather than by the identity of its speaker.")

#text("in the 21st century, shouldn’t we be open minded enough to expand this notion to machines? if the mathematics is correct, shouldn’t we celebrate these advances rather than cry over credit being given to a machine rather to humans? it seems like the AHM is saying if my guild of (human) friends can’t get the glory, than nobody else should.")

#text("i’m really not sure about the argument that mathematicians like tao are pushing that AI will kill off the next generation of mathematicians. it’s like when IBM deep blue beat kasparov in the late 90’s, chess didn’t die but in fact is more popular than ever.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697118")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("You can tell from the first sentence alone complaining about IP violations that the author doesn’t actually care about mathematics. Who among us hasn’t downloaded a textbook or paper from a PDF online? IP has always been a barrier, not something to be celebrated. There are a lot of textbooks I’ve wanted to check out but just can’t get my hands on, because they’re too niche to have a PDF online or be available in the library, but cost in the upper 3-digits to purchase directly. Thankfully journal access doesn’t really matter because of deals with my university making it all free, but I understand I’m in a privileged position. What about academics in 3rd world countries who don’t have these resources, or amateur mathematicians?")

#text("The OpenAI math release has already improved my understanding of mathematics, just by knowing some of the results they came up with relevant to my field. And I predict, when I get around to actually reading the techniques used, my understanding will improve further.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697119")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("I am getting a little tired of how on this blog, anytime mathematicians post anything regarding even mild resistance against the onslaught by AI companies, the comments supporting the post are downvoted by a bunch of people saying mathematicians are gatekeepers and bad faith actors while the AI companies are the real heroes and underdogs.")

#text("Where are these people coming from and what exactly is their beef with mathematicians trying to protect their field from getting drowned under AI slop?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697135")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("The ratio of positive to negative votes on comments here is clearly the result of non mathematician AI enthusiasts from Twitter or something visiting this website, probably because of prof Tao’s notoriety, without the faintest idea of what they are talking about.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("It seems the people who know whet they’re talking about are incapable of formulating a single coherent argument and act the way I imagine the horse carriage guild was acting when the car showed up in the 19 century British Empire.")

#text("Less than 10 message above a dude literally said that mathematics belonged to mathematicians!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("This is a strange position to hold. You, or anyone else for that matter, don’t own mathematics. It belongs to anyone curious enough to have an interest in it. I think the OpenAI release is fascinating, and one of the most important moments in scientific history. What does the sentence “Mathematicians did not ask for this work to be done” even mean? So? Mathematicians, with all due respect, don’t own mathematics. I think human understanding of mathematics is enourmassly important, but I don’t understand how any scientist could be against this release in any way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc629d4480003f85334781c6b812daaadbdd9fc287c7817223fea4562714ef6c-7d424481130a1a0a7f55c7272bdf68741e6c3f0615929fd3adf5753c43fbaca7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bouquetsparkly47d5744bb4")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697140")[#strong[#text("bouquetsparkly47d5744bb4")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#link("https://de.wikipedia.org/wiki/Der_mit_Schw%C3%A4mmen_und_der_mit_Salz_beladene_Esel")[#text("https://de.wikipedia.org/wiki/Der_mit_Schw%C3%A4mmen_und_der_mit_Salz_beladene_Esel")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697146")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("The days when intelligence was scarce are over.")

#text("AI already vastly exceeds human ability. It has crossed the threshold of automating programming and mathematics, legal work and accounting are very close, and every other field will follow to a very large extent. The trend won’t stop.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/954032584ad699ce617d0c8f862c66b60d6900388a17956b0f78e8fe323fdbbf-78e0bc007809bf86df1e85d124f050d855d09dd6e654c373b98c5255e6550d7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pádraig Daly")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697149")[#strong[#text("Pádraig Daly")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("BTW much of the hostility towards this post, and disdain mathematicians in general, is because it was posted to the subreddit r/accelerate so many of the anonymous commenters are from there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697150")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I understand that only a small portion of the results they released have been formalized and checked with Lean so far. So I guess a sizeable percentage of them could still be false and useless. My bet is 90%.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697158")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("No matter what happens, we should approach this with rationality and not with emotions that instinctively “defend” the past human era of mathematics just because we are the most familiar to it, and also evaluate the potential benefits that these new proofs bring, as no matter who solved these problems, the problems have been solved, and this is progress. If the problem is simply who deserves credit or lack of mathematicians to break down and discuss the implications of these new results, then we should work on solving these problems specifically, and not pread anger about AI in mathematics in general")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697168")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Kek we can easily see which comments in this section came from people who know something about how math is done and random goon who know nothing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("“Mathematicians did not ask for this work to be done.”. This statement is shameful and does not speak for the entire community. I strongly disagree and it’s heartbreaking to see this attitude from many of my colleagues.")

#text("Many of us indeed asked for this work to be done and are celebrating the next chapter of scientific progress. Are there issues to be ironed out while we figure out how to transverse this new unknown territory in not only our field but also all of science? For sure. But Mathematics does not belong to academic Mathematicians. We are neither a medieval guild nor a priest class.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697174")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("By the end of my postdoc, I had a decent chance of securing a nice TT position, but I decided to leave academia precisely because of what this letter exemplifies: inflated (and yet fragile) egos, prestige worship and viewing math as a sort of a performance art rather than as a pursuit of truth. These are precisely the non-mathematical aspects of human mathematics that AI is going to obliterate. Good riddance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I swear this statement looks something like straight from a rick and morty episode where mathematicians try to prohibit people to work on their forbidden dangerous theorems as if it were a dangerous biological virus. This is extremely embarassing for this association of mathematicians.")

#text("Truly curious people will still want to learn math just as chess players still play chess. The models used by OpenAI will be available to anyone in 2 months, and open weight versions in a maximum of 6 months. Pandora box has been open and any theorem that can be proven will be proven in 30 mins by some random person.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697178")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I think that statements like this are very harmful to the field. The biggest threat to the future of mathematics is that the reputation of mathematicians to become very bad, and everyone thinks we are anti-AI gatekeepers. If you browse X, you can see people panning Terry for running this blog post. I think this is unfair, as Terry has also run blog posts by for instance Amit Sahai and there is something to be said for having a diversity of views.")

#text("I am excited about the potential for AI-assisted progress in mathematics. Sure, it presents new challenges, but it’s overall good. If you agree, sign this letter: ")#link("https://sites.google.com/view/math-and-ai-together/home")[#text("https://sites.google.com/view/math-and-ai-together/home")]

#text("I’m certainly willing to do a guest post about this letter. So far it has ~50 signatures, but I hope and think it will get more visibility and more with time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697181")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Why can’t mathematicians take AI generated results, learn from them, then give talks, write additional papers, and discover new avenues for exploration? It would seem all of the human learning and digestion Terry and others are worried about being circumvented can still happen; the community now just has a massively larger corpus of material from which to work! What am I missing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Because that’s change and humans are afraid of change. No matter how smart you are, deep down the human will be human.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af28475fe68fe8336c2d953ace3053c5ddc563f31a42469e5dceb11bff7b1e69-19af627de030165d56920b2d2ece74410ab2eb6fa04a0216d4dd81ca985b79cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of devotedlyvaliant47fd0812da")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697186")[#strong[#text("devotedlyvaliant47fd0812da")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Why can’t the mathematics community take these AI generated results, extract the learnings, then go give new talks, write new papers, and communicate them to the wider community? It would seem there is now MORE fertile ground to explore, not less! Certainly these solutions will produce a wellspring of new ideas! This has to be better than the slow grind of yesteryear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697188")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#strong[#text("Leaving aside this rather pointless note or letter, it would be interesting to use the new capabilities of frontier AI models to try to solve that Polymath project on efficiently generating prime numbers deterministically, in which you participated and which led to some interesting partial results, but ultimately did not find such algorithm.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697207")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("sure, llm’s are cool. but they are not the first kind of ai. what are the odds that they are the last form of ai either.")

#text("if one was motivated to show mathematically lower bounds on learning limits of these deep neural nets, which line of work should one look into.")

#text("I feel like this is where the mathematical community’s efforts should be concentrated on. to explore the limits of this new tool to understand where the gaps in its learning lie.")

#text("what holes exist rn to fill the gaps if they are possible through extensions and if not possible, it helps us understand what a better model would look like.")

#text("not sure why mathematicians are not focussing on this line of research almost exclusively. it would be delicious to find out something they have poured billions into can never be good enough cause of some math lol.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I believe the main problem is not the release itself but the lack of transparency. Different people have insisted on the importance of accurately reporting of unsuccessful attempts (also the AGMAI committee). AGMAI also advised for all the prompts to be released. OpenAI has totally failed to comply with this, they released some “excerpts” for about 10 or the problems, which is completely insufficient.")

#text("There is a non-written rule that if I post a paper on arxiv I should be willing to at least give some talks about it, discuss the insights and novelties, and answer emails from colleagues regarding that work.")

#text("OAI is not willing to do any of this. Understandably, they cannot comment on the content, since they admit they do not understand it. But they could comment on all those other aspects of their work, and they are clearly unwilling to do so. They could give all the prompting information, they could give the list of 4000 problems they tried, or release more accurate data on each problem and its chat history. It is also clear that this strategy responds to commercial incentives (such as keeping the 4000 problem list to themselves as a internal metric and avoiding competition on that 4000 list from other AI companies)")

#text("PS. On a maybe more optimistic tone, some people are afraid that AI is taking our jobs. Let me note here that everything I am criticizing are precisely things that working mathematicians do and AI companies are unwilling to do. That is, part of our job that is not being replaced by AI")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697212")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Good to see leadership standing up to this nonsense. 3 withdrawls thus far.")

#text("The only silver lining is that is comical how bad the manuscripts are, it is like a Bio-Dome marathon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697220")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("OpenAI fanboys are brigading this blog now?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697403")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("probably the agents 💁")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Unfortunately this sounds like gatekeeping. Has the mathematical community critiqued and put out papers against what OpenAI has published? Yes it’s a demonstration of power and rightly so.")

#text("Why is it ‘our’ field. Mathematics does not belong to any group.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a69e46887032b79c8459a4777b82827321d3afbadb2d1f7a73580b2b1b508223-baa475ee64dfa6b225ecdc58aae58eab5669f91c107f20387c7316dfe8a56e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pascoej")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697404")[#strong[#text("pascoej")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("i highly encourage you to develop your own model according to your own values. We have a lot of agency as to how this turns out, we just have to use it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a8f1a5ee6b34a026c709dc6c016479957c45a6ca3056b1332cfa8de6b38c474-e03d3298d7e2e9cbeb4d07532ea859c21b13d33fa8dc4517aff325d21bb7c59d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anatol Wegner")]], [#link("https://terrytao.wordpress.com/2026/10/07/ahm-statement-on-openais-october-6-release-of-mathematical-documents/comment-page-1/#comment-697226")[#strong[#text("Anatol Wegner")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("“From this formalistic standpoint, the question as to a deeper reason for the adopted axioms and rules of operation is as meaningless as it is in the chess game. It even remains obscure why it is of concern to us that the game shall be consistent. All objections are obviated, since nothing is asserted; rejection could only take the form of the declaration: ‘I will not join in the game.’ If mathematics would seriously retire to this status of pure game for the sake of its safety, it would no longer be a determining factor in the history of the mind. ")#emph[#text("De facto")]#text(", it has not performed this abdication and will not perform it.” – Hermann Weyl")

#link("https://substack.com/@anatolwegner?utm_source=substack-feed-item")[#text("https://substack.com/@anatolwegner?utm_source=substack-feed-item")]
]
