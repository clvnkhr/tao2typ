// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/07/07/hassells-proof-of-scarring-for-the-bunimovich-stadium/
// Converted to Typst by tao2typ: "2026-10-14T16:35:22.310570+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Hassell’s proof of scarring for the Bunimovich stadium", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Hassell’s proof of scarring for the Bunimovich stadium")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 July 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/07/07/hassells-proof-of-scarring-for-the-bunimovich-stadium/")[#text("https://terrytao.wordpress.com/2008/07/07/hassells-proof-of-scarring-for-the-bunimovich-stadium/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Last year, as part of my “")#link("https://terrytao.wordpress.com/category/question/")[#text("open problem of the week")]#text("” series (now long since on hiatus), I featured one of my favorite problems, namely that of ")#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/")[#text("establishing scarring for the Bunimovich stadium")]#text(". I’m now happy to say that this problem has been solved (for generic stadiums, at least, and for phase space scarring rather than physical space scarring) by my old friend (and fellow Aussie), ")#link("http://wwwmaths.anu.edu.au/~hassell/")[#text("Andrew Hassell")]#text(", in a ")#link("http://arxiv.org/abs/0807.0666")[#text("recent preprint")]#text(". Congrats Andrew!")

#text("Actually, the argument is beautifully simple and short (the paper is a mere 9 pages), though it of course uses the basic theory of eigenfunctions on domains, such as Weyl’s law, and I can give the gist of it here (suppressing all technical details).")

#metadata(none) <tao-f66b61660ec6f23ac5e9>

#text("Let’s first recall the problem. We consider a stadium domain formed by adjoining two semicircles on the ends of a rectangle, like so:")

#align(center)[#image("../assets/9cbc987e841234ccd3352d8d1d632c79b5f4e788f9f78c79bf293c98535a56ae-182e46916ea9003e59f3b02e10ab7d51a46207bdc6e8214df87b02b26e27e7e9.png", width: 90%, alt: "Bunimovich stadium - Wikipedia")]

#text("We can normalise the rectangle to have height 1 and width t, and will call this stadium ")#mi("S_t")#text(". For reasons that will be clearer later, it is convenient to view t as a time parameter, so that the stadium is steadily getting elongated in time. The Laplacian on this domain (with ")#link("http://en.wikipedia.org/wiki/Dirichlet_boundary_condition")[#text("Dirichlet boundary conditions")]#text(") has a countable sequence of eigenfunctions ")#mi("u_1, u_2, \\ldots")#text(" associated to an increasing sequence of eigenvalues ")#mi("0 = \\lambda_1 < \\lambda_2 \\leq \\lambda_3 \\leq \\ldots")#text(", which we can normalise so that ")#tao-math("\\int_{S_t} \\left|u_k\\right|^2 = 1", block: false)#text(" for all k. The conjecture is that the ")#mi("u_k")#text(" do ")#emph[#text("not ")]#text("equidistribute in physical space (or in phase space) in the limit ")#mi("k \\to \\infty")#text(", or in other words that quantum unique ergodicity fails. In physical space, the conjecture is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Scarring conjecture")]#text(". There exists a subset ")#mi("A \\subset \\Omega")#text(" and a sequence ")#mi("u_{k_j}")#text(" of eigenfunctions with ")#mi("\\lambda_{k_j} \\to\\infty")#text(", such that ")#tao-math("\\int_A \\left|u_{k_j}\\right|^2", block: false)#text(" does ")#emph[#text("not")]#text(" converge to ")#tao-math("\\left|A\\right|/\\left|\\Omega\\right|", block: false)#text(". Informally, the eigenfunctions either concentrate (or “scar”) in A, or on the complement of A.")
]

#text("There is some numerical evidence for this conjecture, as discussed in ")#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/")[#text("my previous post")]#text("; more relevantly for Hassell’s argument, there is also a heuristic argument, which we recall shortly.")

#text("The above conjecture only considered scarring in physical space. There is a (slightly weaker) form of this conjecture which considers scarring in ")#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/")[#text("phase space ")]#text("instead (thus the indicator function ")#mi("1_A")#text(" is replaced by a more general ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential operator")]#text("); alternatively, one can phrase things using the ")#link("http://en.wikipedia.org/wiki/Wigner_quasi-probability_distribution")[#text("Wigner transform")]#text(". The precise statement is slightly technical and will not be given here.")

#text("Hassell’s result is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text("The phase space version of the scarring conjecture is true for ")#mi("S_t")#text(" for almost every ")#mi("t > 0")#text(".")
]

#text("Thus, for most stadiums, there is an infinite sequence of eigenfunctions which exhibit significant non-uniformity in phase space.")

#text("Hassell’s argument relies on three ingredients:")

#text("1. ")#strong[#text("The Heller-Zelditch argument")]#text(". As discussed in ")#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/")[#text("my previous article")]#text(", there is already a heuristic argument due ")#link("http://www.ams.org/mathscinet-getitem?mr=1188425")[#text("to Heller")]#text(" and refined ")#link("http://www.ams.org/mathscinet-getitem?mr=2051153")[#text("by Zelditch")]#text(", which almost gives the scarring already for any given stadium ")#mi("S_t")#text(" – but it requires one to exclude eigenvalue concentration in an interval ")#mi("{}[\\pi^2 n^2-O(1), \\pi^2 n^2+O(1)]")#text(" for some integer n. The point is that the stadium already exhibits some explicit quasimodes (i.e. approximate eigenfunctions), namely the tensor products ")#mi("v_n = \\sin(\\pi n y) \\psi(x)")#text(" for some suitable cutoff function ")#mi("\\psi(x)")#text(". Note that ")#mi("\\Delta v_n = \\pi^2 n^2 v_n + O(1)")#text(", so morally this means that the spectrum of ")#mi("v_n")#text(" with respect to the Laplacian is concentrated in the interval ")#mi("{}[\\pi^2 n^2-O(1), \\pi^2 n^2+O(1)]")#text(". On the other hand, this quasimode is highly scarred in phase space (it is extremely concentrated in momentum space). So if one knew that there were only O(1) eigenfunctions in this interval, then one of these eigenfunctions must itself be scarred (basically by the pigeonhole principle, or triangle inequality). (The above argument can be made rigorous with a dash of microlocal analysis; see Andrew’s paper.)")

#text("The difficulty, as discussed in ")#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/")[#text("my previous article")]#text(", was that nobody knew how to prevent a lot of eigenvalues concentrating in the intervals ")#mi("{}[\\pi^2 n^2-O(1), \\pi^2 n^2+O(1)]")#text(" – the standard tool for understanding eigenvalue distribution, namely Weyl’s law, had far too large an error term for this task. So we need some new ingredients…")

#text("2. ")#strong[#text("The Hadamard eigenvalue variation formula")]#text(". Andrew now started exploiting the parameter t. As t varies, the eigenvalues and eigenfunctions of the Laplacian on ")#mi("S_t")#text(" will of course change. How do they change? One can already get some understanding of what is going on by looking at the variation of eigenvalues and eigenvectors for self-adjoint ")#emph[#text("matrices")]#text(" rather than operators. Suppose we have a family ")#mi("A(t)")#text(" of self-adjoint ")#mi("n \\times n")#text(" matrices depending smoothly on a time parameter t, with some eigenvalue ")#mi("\\lambda_k(t)")#text(" and eigenvector ")#mi("u_k(t)")#text(", also varying smoothly, thus")

#align(center)[#tao-fit-display[#mitex("A(t) u_k(t) = \\lambda_k(t) u_k(t).")]]

#text("We normalise the eigenvectors to have unit magnitude. We can differentiate both sides with respect to t using the product rule to obtain")

#align(center)[#mi("\\dot A(t) u_k(t) + A(t) \\dot u_k(t) = \\dot \\lambda_k(t) u_k(t) + \\lambda_k(t) \\dot u_k(t)")#text(".")]

#text("Now we take the dot product with ")#mi("u_k(t)")#text(". Since we have normalised ")#mi("u_k(t)")#text(" to be a unit vector, we have ")#mi("u_k(t) \\cdot u_k(t) = 1")#text(" and ")#mi("u_k(t) \\cdot \\dot u_k(t) = 0")#text(", and we conclude the variation formula")

#align(center)[#mi("\\langle u_k(t), \\dot A_k(t) u_k(t) \\rangle = \\dot \\lambda_k(t)")#text(".")]

#text("Thus, the rate of change of the ")#mi("k^{th}")#text(" eigenvalue ")#mi("\\lambda_k")#text(" can be computed by testing the rate of change of the matrix ")#mi("A")#text(" against the normalised eigenvalue ")#mi("u_k")#text(".")

#text("It turns out that one can do a similar thing for the Laplacian ")#mi("\\Delta = \\Delta_t")#text(" on the domain ")#mi("S_t")#text(". Since the domain ")#mi("S_t")#text(" is growing with t, one could imagine that the Laplacian ")#mi("\\Delta")#text(" is also “growing”, and its “time derivative” should be given by something on the boundary ")#mi("\\partial S_t")#text(". It requires some care to make this intuition precise, but Hassell was able to show a Hadamard-type variation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\dot \\lambda_k(t) = - \\int_{\\partial S_t} (X \\cdot n) \\left|\\partial_n u_k(t,x)\\right|^2\\ ds", block: true)]]

#text("where ")#mi("ds")#text(" is the length element on ")#mi("\\partial S_t")#text(", n is the outward unit normal, and X is the vector field which equals ")#mi("+\\frac{1}{2} \\partial_x")#text(" on the right semicircle (this is the vector field that grows the width t of the stadium ")#mi("S_t")#text(" at a unit rate).")

#text("Note that ")#mi("X \\cdot n")#text(" is always non-negative; so the formula (1) implies that the eigenvalues are decreasing as the width t increases. This is consistent with ")#emph[#text("Weyl’s law")]#text(" ")#tao-math("\\lambda_k = \\frac{4\\pi}{\\left|S_t\\right|} (1+o(1)) k", block: false)#text(" for these eigenvalues. Actually, one can be a bit more precise; heat kernel methods reveal that ")#tao-math("\\left|\\partial_n u_k(t,x)\\right| \\sim \\lambda_k^{1/2}", block: false)#text(" on average, and so from (1) we expect to have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("- \\dot \\lambda_k \\sim \\lambda_k")]]

#text("on the average, which is broadly consistent with Weyl’s law. [Incidentally, Andrew and I happen to have a ")#link("http://front.math.ucdavis.edu/math.AP/0202140")[#text("short paper")]#text(" establishing a variant of this fact, where we average in x rather than in k.]")

#text("3. ")#strong[#text("Quantum unique ergodicity.")]#text(" The last trick of Andrew is to prove Theorem 1 by contradiction. To illustrate the idea, let us suppose that the extreme opposite to Theorem 1 holds, namely that no scarring occurs for ")#emph[#text("any")]#text(" stadium ")#mi("S_t")#text(". Informally, this means that any eigenfunction (with large eigenvalue) for any stadium will be approximately uniformly distributed in phase space.")

#text("According to Egorov’s theorem, eigenfunctions should propagate their position and momentum in phase space by geodesic flow. Since all geodesics in the stadium hit the boundary, this in principle allows us to understand the distribution of an eigenfunction on the boundary in terms of the eigenfunction in the interior. Indeed, one can show that an eigenfunction which is uniformly distributed in phase space in the interior, will have a normal derivative which is uniformly distributed on the boundary (rigorous formulations of this fact date back to ")#link("http://www.ams.org/mathscinet-getitem?mr=1233448")[#text("Gérard and Leichtnam")]#text("). Thus, by assumption, ")#emph[#text("every")]#text(" eigenvector is uniformly distributed on the boundary. Because of this, the eigenvalue decay (2) does not just hold on the average – it holds for ")#emph[#text("all")]#text(" k. Thus all eigenvalues decay exponentially in t at a steady rate.")

#text("But once one has this, it is not hard to show that the eigenvalues cannot concentrate close to any given interval ")#mi("{}[\\pi^2 n^2-O(1), \\pi^2 n^2+O(1)]")#text(" for extended periods of time t. We then apply the Heller-Zelditch argument and get a contradiction. That’s it! (Modulo details, of course.)")

#text("There are of course some natural further directions to pursue, for instance to improve the scarring so that one obtains non-equidistribution in physical space. This seems to be related to the question of improving the quality of the quasimode used in the Heller-Zelditch argument (see this ")#link("http://math.berkeley.edu/~zworski/bz1.pdf")[#text("survey of Zworski")]#text(" for some discussion). I believe Andrew is looking at these issues right now.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/07/hassells-proof-of-scarring-for-the-bunimovich-stadium/#comment-30848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2008")])]

#text("Dear Terence,")

#text("thank you very much for this entry, I enjoyed it a lot!!! This is an org*smic problem.")

#text("I beg your pardon for my lasts words, but i can’t find any other that could expose my feelings about it.")

#text("Jordi-Lluis Figueras Romero")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e510271c02c3261a77816bedda5d48a826205ba2435a5be453512ad3c3383060-3903d940d0fd14e9792224157252b50223a32bcbac2cc4f1b5fd507f7b7bf331.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hopefully Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/07/hassells-proof-of-scarring-for-the-bunimovich-stadium/#comment-30871")[#strong[#text("Hopefully Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2008")])]

#text("This blog is a wonderful resource. It inspires me to improve my mathematical understanding so as to fully appreciate your posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Km")]], [#link("https://terrytao.wordpress.com/2008/07/07/hassells-proof-of-scarring-for-the-bunimovich-stadium/#comment-31044")[#strong[#text("Km")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2008")])]

#text("Hi Terence,")

#text("Is the Bunimovich stadium problem completely solved now? Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/07/hassells-proof-of-scarring-for-the-bunimovich-stadium/#comment-474908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2016")])]

#text("Do you have a proof for formula (1) for the Laplacian?")

#emph[#text("[This is Lemma 3 of Hassell’s paper; he refers to the reference [11] of Garabedian for a proof. -T.]")]
]
