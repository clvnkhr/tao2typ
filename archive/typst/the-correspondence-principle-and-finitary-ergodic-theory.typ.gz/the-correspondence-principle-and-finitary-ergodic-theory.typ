// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:35:24.275718+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The correspondence principle and finitary ergodic theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The correspondence principle and finitary ergodic theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 August 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This month I am at ")#link("http://www.msri.org")[#text("MSRI")]#text(", for the programs of ")#link("http://www.msri.org/calendar/programs/ProgramInfo/252/show_program")[#text("Ergodic Theory and Additive Combinatorics")]#text(", and ")#link("http://www.msri.org/calendar/programs/ProgramInfo/250/show_program")[#text("Analysis on Singular Spaces")]#text(", that are currently ongoing here. This week I am giving ")#link("http://www.msri.org/calendar/workshops/ScheduleInfo/895/show_abstract")[#text("three lectures")]#text(" on the correspondence principle, and on finitary versions of ergodic theory, for the ")#link("http://www.msri.org/calendar/workshops/WorkshopInfo/439/show_workshop")[#text("introductory workshop in the former program")]#text(". The article here is broadly describing the content of these talks (which are slightly different in theme from that announced in the ")#link("http://www.msri.org/calendar/workshops/ScheduleInfo/895/show_abstract")[#text("abstract")]#text(", due to some recent developments). [These lectures were also recorded on video and should be available from the MSRI web site within a few months.]")

#metadata(none) <tao-6656c0147a775e475c12>

#text("My lectures are devoted to the ")#emph[#text("correspondence principle")]#text(" between finite dynamical systems and infinite dynamical systems, that allows one to convert certain statements about the former to logically equivalent statements about the latter. (I will be vague here about what “dynamical system” means; very broadly, just about anything with a group action could qualify here.) A little more specifically, the correspondence principle equates four types of results, which we informally describe as follows:")

#enum(start: 1, 
[#text("Local quantitative results for concrete finite systems.")],
[#text("Local qualitative results for concrete infinite systems.")],
[#text("Continuous quantitative results for abstract finite systems.")],
[#text("Continuous qualitative results for abstract infinite systems.")]
)

#text("(The meaning of these terms should become clearer once we give some specific examples.)")

#text("There are many contexts in which this principle shows up (e.g. in ")#link("http://en.wikipedia.org/wiki/Ramsey_theory")[#text("Ramsey theory")]#text(", recurrence theory, graph theory, group theory, etc.) but the basic ingredients are always the same. Namely, the correspondence between Type 1 and Type 2 (or Type 3 and Type 4) arises from a ")#emph[#text("weak sequential compactness property")]#text(", which, roughly speaking asserts that given any sequence of (increasingly large) finite systems, there exists a subsequence of such systems which converges (in a suitably “weak” sense) to an infinite system. [We will define these terms more precisely in concrete situations later.] More informally, any “sufficiently large” finite system can be “approximated” in some weak sense by an infinite system. (One can make this informal statement more rigorous using ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("nonstandard analysis and/or ultrafilters")]#text(", but we will not take such an approach here.) Because of this, we obtain a ")#emph[#text("correspondence principle")]#text(": any ")#emph[#text("qualitative")]#text(" statement about infinite systems (e.g. that a certain quantity is always strictly positive) is equivalent to a ")#emph[#text("quantitative ")]#text("statement about sufficiently large finite systems (e.g. a certain quantity is always uniformly bounded from below). This principle forms a crucial bridge between finitary (or quantitative) mathematics and infinitary (or qualitative) mathematics; in particular, by taking advantage of this principle, tools from one type of mathematics can be used to prove results in the other. (See my previous ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("post on soft analysis and hard analysis")]#text(" for further discussion.)")

#text("In addition to the use of compactness, the other key pillar of the correspondence principle is that of ")#emph[#text("abstraction")]#text(" – the ability to generalise from a concrete system (on a very explicit space, e.g. the infinite cube ")#mi("\\{0,1\\}^{\\Bbb Z}")#text(") to an more general abstract setting (e.g. an abstract dynamical system, measure-preserving system, group, etc.) One of the reasons for doing this is that there are various maneuvres one can do in the abstract setting (e.g. passing from a system to a subsystem, a factor, or an extension, or by reasoning by analogy from other special systems that are different from the original concrete system) which can be quite difficult to execute or motivate if one stays within the confines of a single concrete setting.")

#text("We now turn to several specific examples of this principle in various contexts. We begin with the more “combinatorial” or “non-ergodic theoretical” instances of this principle, in which there is no underlying probability measure involved; these situations are simpler than the ergodic-theoretic ones, but already illustrate many of the key features of this principle in action.")

#strong[#text("1. The correspondence principle in Ramsey theory")]

#text("We begin with the classical correspondence principle that connects Ramsey results about finite colourings, to Ramsey results about infinite colourings, or (equivalently) about the topological dynamics of covers of open sets. We illustrate this by demonstrating the equivalence of three statements. The first two are as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Van_der_Waerden%27s_theorem")[#text("van der Waerden theorem")]#text(", Type 2 formulation) Suppose the integers are coloured by finitely many colours. Then there exist arbitrarily long monochromatic arithmetic progressions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (van der Waerden theorem, Type 1 formulation) For every c and k there exists N such that whenever ")#mi("\\{1,\\ldots,N\\}")#text(" is coloured by c colours, there exists a monochromatic arithmetic progression of length k.")
]

#text("It is easy to see that Theorem 2 implies Theorem 1. Conversely, to deduce Theorem 2 from Theorem 1 we use the correspondence principle as follows. Assume for contradiction that Theorem 1 was true, but Theorem 2 was false. Untangling the quantifiers, this means that there exist positive integers k, c, a sequence ")#mi("N_n")#text(" going to infinity, and colourings ")#mi("\\{1,\\ldots,N_n\\} = A_{n,1} \\cup \\ldots \\cup A_{n,c}")#text(" of ")#mi("\\{1,\\ldots,N_n\\}")#text(" into c colours, none of which contain any monochromatic arithmetic progressions of length k.")

#text("By shifting the sets ")#mi("\\{1,\\ldots,N_n\\}")#text(" and redefining ")#mi("N_n")#text(" a little, we can replace ")#mi("\\{1,\\ldots,N_n\\}")#text(" by ")#mi("\\{-N_n,\\ldots,N_n\\}")#text(". This sequence of colourings on the increasingly large sets ")#mi("\\{-N_n,\\ldots,N_n\\}")#text(". One can now extract a subsequence of such colourings on finite sets of integers that converge ")#emph[#text("pointwise")]#text(" or ")#emph[#text("weakly")]#text(" to a colouring on the whole set of integers by the usual “")#link("http://en.wikipedia.org/wiki/Arzela-Ascoli_theorem")[#text("Arzelà-Ascoli")]#text(" diagonalisation trick”. Indeed, by passing to an initial subsequence (and using the infinite pigeonhole principle), one can ensure that all of these colourings eventually become a constant colour at 0; refining to another subsequence, we can ensure it is a constant colour at 1; then at -1, 2, -2, and so forth. Taking a diagonal subsequence of these sequences, we obtain a final subsequence of finite colourings that converges pointwise to an infinite limit colouring. By Theorem 1, this limit colouring contains an monochromatic arithmetic progression of length k. Now note that the property of being monochromatic at this progression is a ")#emph[#text("local")]#text(" one: one only needs to inspect the colour of finitely many of the integers in order to verify this property. Because of this, this property of the infinite limit colouring will also be shared by the finite colourings that are sufficiently far along the converging sequence. But we assumed at the very beginning that none of these finite colourings have a monochromatic arithmetic progression of length k, a contradiction, and the claim follows.")

#text("The above argument has all the basic ingredients of the correspondence principle in action: a proof by contradiction, use of weak compactness to extract an infinite limiting object, application of the infinitary result to that object, and checking that the conclusion of that result is sufficiently “finitary”, “local”, or “continuous” that it extends back to some of the finitary sequence, leading to the desired contradiction. [It is essential that one manages to reduce to purely local properties before passing from the converging sequence to the limit, or vice versa, since non-local properties are usually not preserved by the limit. For instance, consider the colouring of ")#mi("\\{-N,\\ldots,N\\}")#text(" which colours every integer between -N/2 and N/2 blue, and all the rest red. Then this converges weakly to the all-blue colouring, and clearly the (non-local) property of containing at least one red element is not preserved by the limit.]")

#text("A key disadvantage of the use of the correspondence principle, though, is that it is quite difficult to extract specific quantitative bounds from any argument that uses this principle; for instance, while one can eventually “proof mine” the above argument (combined with some standard proof of Theorem 1) to eventually get a bound on N in terms of k and d, such a bound is extremely poor (of ")#link("http://en.wikipedia.org/wiki/Ackermann_function")[#text("Ackermann function")]#text(" type).")

#text("Theorem 1 can be reformulated in a more abstract form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" (van der Waerden theorem, Type 4 version) Let X be a compact space, let ")#mi("T: X \\to X")#text(" be a ")#link("http://en.wikipedia.org/wiki/Homeomorphism")[#text("homeomorphism")]#text(", and let ")#mi("(V_\\alpha)_{\\alpha \\in A}")#text(" be an open cover of X. Then for any k there exists a positive integer n and an open set ")#mi("V_\\alpha")#text(" in the cover such that ")#mi("V_\\alpha \\cap T^{-n} V_\\alpha \\cap \\ldots T^{-(k-1)n} V_\\alpha")#text(" is non-empty.")
]

#text("The deduction of Theorem 3 from Theorem 1 is easy, after using the compactness to refine the open cover to a finite subcover, picking a point ")#mi("x_0")#text(" in X, and then colouring each integer n by the index ")#mi("\\alpha")#text(" of the first open set ")#mi("V_\\alpha")#text(" that contains ")#mi("T^n x_0")#text(". The converse deduction of Theorem 1 from Theorem 3 is the one which shows the “dynamical” aspect of this theorem: we can encode a colouring ")#mi("{\\Bbb Z} = A_1 \\cup \\ldots \\cup A_c")#text(" of the integers as a point ")#mi("x_0 := (c_n)_{n \\in {\\Bbb Z}}")#text(" in the infinite product space ")#mi("\\{1,\\ldots,c\\}^{\\Bbb Z}")#text(", where ")#mi("c_n")#text(" is the unique class such that ")#mi("n \\in A_{c_n}")#text(" (indeed, one can think of this product space as the space of all c-colourings of the integers). The infinite product space is compact with the ")#link("http://en.wikipedia.org/wiki/Product_topology")[#text("product")]#text(" (or weak) topology used earlier, thus a sequence of colourings converge to a limit iff they converge locally (or pointwise). This space also comes with the standard shift ")#mi("T: (x_n)_{n \\in {\\Bbb Z}} \\to (x_{n-1})_{n \\in {\\Bbb Z}}")#text(" (corresponding to right shift on the space of colourings). If we let X be the closure of the orbit ")#mi("\\{ T^n x_0: n \\in {\\Bbb Z} \\}")#text(", and let ")#mi("V_1,\\ldots,V_c")#text(" be the open cover ")#mi("V_i := \\{ (x_n)_{n \\in {\\Bbb Z}}: x_0 = i \\}")#text(", it is straightforward to show that Theorem 3 implies Theorem 1.")

#strong[#text("2. The correspondence principle for finitely generated groups")]

#text("The combinatorial correspondence used above for colourings can also be applied to other situations, such as that of finitely generated groups. Recall that if G is a group generated by a finite set S, we say that G has polynomial growth if there exists constants K, d such that the ball ")#mi("B_r")#text(" of radius r (i.e. the set of words in S of length at most r) has cardinality at most ")#mi("Kr^d")#text(". Such groups were classified by a well-known ")#link("http://en.wikipedia.org/wiki/Gromov%27s_theorem_on_groups_of_polynomial_growth")[#text("theorem of Gromov")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4.")]#text(" (Gromov’s theorem on polynomial growth, Type 4 version) Let G be a finitely generated group of polynomial growth. Then G is ")#link("http://en.wikipedia.org/wiki/Virtually")[#text("virtually")]#text(" ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent")]#text(" (i.e. it has a finite index subgroup that is nilpotent).")
]

#text("As observed in Gromov’s original paper, this result is equivalent to a finitary version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5. ")]#text(" (Gromov’s theorem on polynomial growth, Type 3) For every integers s, K, d, there exists R such that any finitely generated group with s generators, such that ")#mi("B_r")#text(" has cardinality at most ")#mi("Kr^d")#text(" for all ")#mi("1 \\leq r \\leq R")#text(", is virtually nilpotent.")
]

#text("It is clear that Theorem 5 implies Theorem 4; for the converse implication, we use the correspondence principle. We sketch the details as follows. First, we make things more concrete (i.e. move from Type 3 and Type 4 to Type 1 and Type 2 respectively) by observing that every group G on s generators can be viewed as a quotient ")#mi("{\\Bbb F}_s/\\Gamma")#text(" of the (nonabelian) free group on s generators by some normal subgroup ")#mi("\\Gamma")#text(".")

#text("Suppose for contradiction that Theorem 5 failed in this concrete setting; then there exists s, K, d, a sequence ")#mi("R_n")#text(" going to infinity, and a sequence ")#mi("G_n = {\\Bbb F}_s/\\Gamma_n")#text(" of groups such that each ")#mi("G_n")#text(" obeys the volume condition ")#tao-math("\\left|B_r\\right| \\leq K r^d", block: false)#text(" for all ")#mi("1 \\leq r \\leq R_n")#text(".")

#text("The next step, as before, is to exploit weak sequential compactness and extract a subsequence of groups ")#mi("G_n = {\\Bbb F}_s/\\Gamma_n")#text(" that “converge” to some limit ")#mi("G = {\\Bbb F}_s/\\Gamma")#text(", in the “weak” or “pointwise” sense that ")#mi("\\Gamma_n")#text(" converges pointwise (or locally) to ")#mi("\\Gamma")#text(" (much as with the convergence of colourings in the previous setting). The Arzelà-Ascoli argument as before shows that we can find a subsequence of ")#mi("G_n = {\\Bbb F}_s/\\Gamma_n")#text(" which do converge pointwise to some limit object ")#mi("G = {\\Bbb F}_s/\\Gamma")#text("; one can check that the property of being a normal subgroup is sufficiently “local” that it is preserved under limits, thus ")#mi("\\Gamma")#text(" is a normal subgroup of ")#mi("{\\Bbb F}_s")#text(" and so G is well-defined as a group. (One way to view this convergence is that algebraic identity obeyed by the generators of G, is eventually obeyed by the groups sufficiently far along the convergent subsequence, and conversely.)")

#text("As volume growth is a local condition (involving only words of bounded length for any fixed r), we then easily conclude that G is of polynomial growth, and thus by Theorem 4 is virtually nilpotent. Some nilpotent algebra reveals that every virtually nilpotent group is finitely presented, so in particular there are a finite list of relations among the generators which guarantee this virtual nilpotency property. Such properties are local enough that they must then persist to groups ")#mi("G_n")#text(" sufficiently far along the subsequence, contradicting Theorem 5.")

#text("A slight modification of the above argument also reveals that the step and index of the nilpotent subgroup of G can be bounded by some constant depending only on K, d, s; this gives Theorem 5 meaningful content even when G is finite (in contrast to Theorem 4, which is trivial for finite groups). On the other hand, no explicit bound for this constant (or for R) in terms of s, K, d is currently known, though presumably some such bound can eventually be extracted from the above argument and the existing proofs of Gromov’s theorem by proof mining techniques.")

#strong[#text("3. The correspondence principle for dense sets of integers")]

#text("Now we turn to the more “ergodic” variants of the correspondence principle, starting with the fundamental ")#emph[#text("Furstenberg correspondence principle")]#text(" connecting combinatorial number theory with ergodic theory. We will illustrate this with the classic example of ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(".")

#text("There are many finitary versions of Szemerédi’s theorem. Here is one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6.")]#text(" (Szemerédi’s theorem, Type 1 version) Let ")#mi("k \\geq 2")#text(" and ")#mi("0 < \\delta \\leq 1")#text(". Then there exists a positive integer ")#mi("N = N(\\delta,k)")#text(" such that every subset A of ")#mi("\\{1,\\ldots,N\\}")#text(" with ")#tao-math("\\left|A\\right| \\geq \\delta N", block: false)#text(" contains at least one k-term arithmetic progression.")
]

#text("The standard “Type 2” formulation of this theorem is the assertion that any subset of the integers of positive upper density has arbitrarily long arithmetic progressions. While this statement is indeed easily shown to be equivalent to Theorem 6, the Furstenberg correspondence principle instead connects this formulation to a rather different one, in which the deterministic infinite set is replaced by a random one. Recall that a random subset of integers ")#mi("{\\Bbb Z}")#text(" is a random variable A taking values in the power set ")#mi("2^{\\Bbb Z}")#text(" of the integers (or more formally, with a distribution that is a ")#link("http://en.wikipedia.org/wiki/Borel_measure")[#text("Borel probability measure")]#text(" on ")#mi("2^{\\Bbb Z}")#text(" with the product topology), and so in particular the probabilities of any ")#emph[#link("http://en.wikipedia.org/wiki/Cylinder_set")[#text("cylinder events")]#text(" ")]#text("such as")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( 3, 5 \\in A; 7, 11 \\not \\in A )")]]

#text("that involve only finitely many of the elements of A, are well-defined as numbers between 0 and 1. The ")#link("http://en.wikipedia.org/wiki/Caratheodory_extension_theorem")[#text("Carathéodory extension theorem")]#text(" (combined with some topological properties of ")#mi("2^{\\Bbb Z}")#text(") shows, conversely, that any assignment of numbers between 0 and 1 to each cylinder set, which obeys various compatibility conditions such as")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( 3 \\in A ) = {\\Bbb P}( 3, 5 \\in A ) + {\\Bbb P}( 3 \\in A; 5 \\not \\in A )")]]

#text("can be shown to give rise to a well-defined random set A.")

#text("We say that a random set A of integers is ")#link("http://en.wikipedia.org/wiki/Stationary_process")[#emph[#text("stationary")]]#text(" if for every integer h, the shifted set A+h has the same probability distribution as A. In terms of cylinder events, this is equivalent to a collection of assertions such as")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( 3, 5 \\in A; 7, 11 \\not \\in A ) = {\\Bbb P}( 3-h, 5-h \\in A; 7-h, 11-h \\not \\in A )")]]

#text("and so forth. One can then equate Theorem 6 with")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7.")]#text(" (Szemerédi’s theorem, Type 2 version) Let A be a stationary random infinite set of integers such that ")#mi("{\\Bbb P}(0 \\in A) > 0")#text(" (which, by stationarity, implies that ")#mi("{\\Bbb P}(n \\in A) > 0")#text(" for all n), and let ")#mi("k \\geq 2")#text(". Then, with positive probability, A contains a k-term arithmetic progression for each k.")
]

#text("It is not difficult to show that Theorem 6 implies Theorem 7. We briefly sketch the converse implication, which goes through the usual compactness-and-contradiction method. Suppose for contradiction that Theorem 7 is true, but Theorem 6 fails. Then we can find k and ")#mi("\\delta")#text(", a sequence of ")#mi("N_n")#text(" going to infinity, and sets ")#mi("A_n \\subset \\{1,\\ldots,N_n\\}")#text(" with ")#tao-math("\\left|A_n\\right| \\geq \\delta N_n", block: false)#text(" with no k-term arithmetic progressions.")

#text("We now need to extract a stationary random infinite set A of integers as a limit of the deterministic finite sets ")#mi("A_n")#text(". The way one does that is by randomly translating each of the ")#mi("A_n")#text(". More precisely, let ")#mi("B_n")#text(" denote the random finite set ")#mi("A_n - h")#text(", where ")#mi("h")#text(" is chosen from ")#mi("\\{1,\\ldots,N_n\\}")#text(" uniformly at random. The probability distribution ")#mi("\\mu_n")#text(" of ")#mi("B_n")#text(" is a discrete probability measure on ")#mi("2^{\\Bbb Z}")#text(" which is “almost stationary” in the sense that ")#mi("B_n+1")#text(" (say) has a distribution very close to ")#mi("B_n")#text("; for instance probabilities such as ")#mi("{\\Bbb P}( 3, 5 \\in B_n )")#text(" and ")#mi("{\\Bbb P}(3,5 \\in B_n+1)")#text(" can easily be seen to differ only by ")#mi("O(1/N_n)")#text(". Also, the fact that ")#tao-math("\\left|A_n\\right| \\geq \\delta N_n", block: false)#text(" equates to the assertion that ")#mi("{\\Bbb P}(0 \\in B_n) \\geq \\delta")#text(".")

#text("By using the same type of Arzelà-Ascoli argument as before, we can show that some subsequence of the random variables ")#mi("B_n")#text(" converge ")#emph[#text("weakly")]#text(" to a limit ")#mi("B")#text(" in the sense that the cylinder probabilities of ")#mi("B_n")#text(" converge to those of B along this subsequence; thus for instance")

#align(center)[#mi("\\lim_{n \\to \\infty} {\\Bbb P}(3, 5 \\in B_n; 17 \\not \\in B_n) = {\\Bbb P}(3, 5 \\in B; 17 \\not \\in B)")#text(".")]

#text("(To get from the cylinder probabilities back to a random variable, one uses the ")#link("http://en.wikipedia.org/wiki/Caratheodory_extension_theorem")[#text("Carathéodory extension theorem")]#text(". Weak convergence (or more precisely, ")#link("http://en.wikipedia.org/wiki/Weak_topology#The_weak-.2A_topology")[#text("weak-* convergence")]#text(") of measures is also known as ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague convergence")]#text(", or ")#link("http://en.wikipedia.org/wiki/Convergence_of_random_variables")[#text("convergence in distribution")]#text(".)")

#text("Since the ")#mi("B_n")#text(" are approximately stationary, one can show that ")#mi("B")#text(" is exactly stationary. Since ")#mi("{\\Bbb P}( 0 \\in B_n)")#text(" is bounded uniformly away from zero, one can show that ")#mi("{\\Bbb P}(0 \\in B)")#text(" is positive. Thus, we can apply Theorem 7 to show that B contains a k-term arithmetic progression with positive probability. Since there are only countably many k-term arithmetic progressions, the countable pigeonhole principle then tells us that there exists some k-term arithmetic progression ")#mi("a, n+r, \\ldots, a+(k-1) r")#text(" which lies in B with positive probability. This is a “local” property on B. By weak convergence, this means that this same is true for ")#mi("B_n")#text(" for n sufficiently far along this subsequence; in particular, the corresponding deterministic sets ")#mi("A_n")#text(" contain k-term arithmetic progressions, a contradiction. Thus Theorem 7 does imply Theorem 6.")

#text("Much as Theorem 1 is equivalent to Theorem 4, Theorem 7 can be reformulated in a more abstract manner, known as the ")#emph[#text("Furstenberg recurrence theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8.")]#text(" (Szemerédi’s theorem, Type 4 version) Let ")#mi("(X, \\mu, T)")#text(" be a probability space with a measure-preserving bimeasurable map ")#mi("T: X \\to X")#text(" (thus T is invertible, and ")#mi("T, T^{-1}")#text(" are measurable and measure-preserving), and let ")#mi("A \\subset X")#text(" have positive measure ")#mi("\\mu(A) > 0")#text(". Then there exists ")#mi("r > 0")#text(" such that ")#mi("\\mu( A \\cap T^{-r} A \\cap \\ldots \\cap T^{(k-1)r} A) > 0")#text(".")
]

#text("We leave the equivalence of Theorem 8 with Theorems 6,7 as an exercise.")

#strong[#text("4. The correspondence principle for dense sets of integers II.")#linebreak()#text(" ")]

#text("The deduction of Theorem 6 from Theorem 7, gives that the set A appearing in Theorem 6 has at least one k-term arithmetic progression, but if one inspects the argument more carefully, one sees that in fact one has a stronger statement that if N is large enough, there exists some ")#mi("1 \\leq r \\leq C( k, \\delta )")#text(" such that A contains at least ")#mi("c(k,\\delta) N")#text(" k-term arithmetic progressions ")#mi("a, a+r, \\ldots, a+(k-1)r")#text(" of step r. We leave this derivation as an exercise.")

#text("It is possible however to find even more progressions in the set A:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8′.")]#text(" (Szemerédi’s theorem, Varnavides-type version) Let ")#mi("k \\geq 2")#text(" and ")#mi("0 < \\delta \\leq 1")#text(". Then there exists a positive integer ")#mi("N_0 = N_0(\\delta,k)")#text(" and ")#mi("c = c(k,\\delta) > 0")#text(" such that for every ")#mi("N \\geq N_0")#text(" and every subset A of ")#mi("\\{1,\\ldots,N\\}")#text(" with ")#tao-math("\\left|A\\right| \\geq \\delta N", block: false)#text(" contains at least ")#mi("c N^2")#text(" k-term arithmetic progressions.")
]

#text("This can be obtained from Theorem 7 by repeating the derivation of Theorem 6 with two additional twists. Firstly, it is not difficult to modify the ")#mi("N_n")#text(" appearing in this derivation to be prime (for instance, by appealing to Bertrand’s postulate). This allows us to identify ")#mi("\\{1,\\ldots,N_n\\}")#text(" with the finite field ")#mi("{\\Bbb Z}/N_n {\\Bbb Z}")#text(", giving us the ability to ")#emph[#text("dilate")]#text(" within this set as well as translate. For technical reasons it is also convenient to restrict ")#mi("A_n")#text(" to lie in the bottom half ")#mi("\\{1,\\ldots,\\lfloor N_n/2\\rfloor\\}")#text(" of this set, which is also easy to arrange. We then argue as before, but with the randomly translated set ")#mi("B_n := A_n - h")#text(" replaced by the randomly translated ")#emph[#text("and")]#text(" dilated set ")#mi("B_n := (A_n-h) \\cdot r")#text(", where h and r are independently chosen at random from this finite field. If one does this, one finds that probabilities such as ")#mi("{\\Bbb P}( 0, 1, \\ldots, k-1 \\in B_n )")#text(" are essentially equal to the number of k-term arithmetic progressions in ")#mi("A_n")#text(", divided by ")#mi("N_n^2")#text(" (the restriction of ")#mi("A_n")#text(" to the bottom half of ")#mi("\\{1,\\ldots,N_n\\}")#text(" is necessary to avoid certain “wraparound” issues). If one then repeats the previous arguments one can establish Theorem 8′ from Theorem 7.")

#text("This type of argument was implicitly first introduced by Varnavides. Basically, this argument exploits the ")#emph[#link("http://en.wikipedia.org/wiki/Affine_group")[#text("affine")]#text(" invariance")]#text(" (i.e. ")#mi("\\text{Aff}({\\Bbb Z})")#text(" invariance) of the space of arithmetic progressions, as opposed to mere ")#emph[#text("translation invariance")]#text(" (i.e. ")#mi("{\\Bbb Z}")#text(" invariance).")

#text("One can rephrase Theorem 8 in a quantitative ergodic formulation, essentially due to ")#link("http://www.ams.org/mathscinet-getitem?mr=1784213")[#text("Bergelson, Host, McCutcheon, and Parreau")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9.")]#text(" (Szemerédi’s theorem, Type 3 version) Let ")#mi("k \\geq 2")#text(" and ")#mi("0 < \\delta \\leq 1")#text(". Then there exists ")#mi("c(k,\\delta) > 0")#text(" such that for every measure-preserving system ")#mi("(X,\\mu,T)")#text(" and any measurable set A with ")#mi("\\mu(A) > \\delta")#text(", we have ")#mi("\\liminf_{N \\to \\infty} {\\Bbb E}_{n \\in \\{1,\\ldots,N\\}} \\mu( A \\cap T^{-n} A \\cap \\ldots \\cap T^{-(k-1)n} A) \\geq c(k,\\delta)")#text(".")
]

#strong[#text("5. The correspondence principle for sparse sets of integers")]

#text("It is possible to squeeze even more finitary results out of Theorem 7 than was done in the previous two sections. In particular, one has the following relative version of Szemerédi’s theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10.")]#text(" (Relative Szemerédi theorem) Let ")#mi("k \\geq 2")#text(" and ")#mi("0 < \\delta \\leq 1")#text(". Let N be a sufficiently large integer, and let R be a “sufficiently pseudorandom” subset of ")#mi("\\{1,\\ldots,N\\}")#text(". Then every subset A of R with ")#tao-math("\\left|A\\right| \\geq \\delta \\left|R\\right|", block: false)#text(" contains one k-term arithmetic progression.")
]

#text("I did not define above what “sufficiently pseudorandom” meant as it is somewhat technical, but very roughly speaking it is a package of approximate independence conditions which include things like")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\Bbb E}_{n,h,k \\in [N]} \\nu(n) \\nu(n+h) \\nu(n+k) \\nu(n+h+k)=1+o(1),")]]

#text("where ")#tao-math("\\nu(n) := \\frac{N}{\\left|R\\right|} 1_R(n)", block: false)#text(" is the normalised indicator function of R, and all arithmetic operations are taking place in the cyclic group ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(".")

#text("The point of Theorem 10 is that it allows one to detect arithmetic progressions inside quite sparse sets of integers (typically, R will have size about ")#mi("N/\\log N")#text(", so A and R would be logarithmically sparse). In particular, a relative Szemerédi theorem similar to this one (but somewhat stronger) was a key ingredient in ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("my result with Ben Green")]#text(" that the primes contain arbitrarily long arithmetic progressions. (Theorem 10 is unfortunately insufficient for this task, because the amount of pseudorandomness needed here depends on ")#mi("\\delta")#text("; the relative Szemerédi’s theorem developed in my paper with Ben only needs a number of pseudorandomness conditions that depend on k but – crucially – not on ")#mi("\\delta")#text(".)")

#text("The derivation of Theorem 10 from Theorem 7 is discussed in this ")#link("https://www.math.ucla.edu/~tao/preprints/Expository/limiting.pdf")[#text("unpublished note of mine")]#text(". We sketch the main ideas here. Once again, we argue by contradiction. If Theorem 10 failed, then one can find k and ")#mi("\\delta")#text(", a sequence ")#mi("N_n")#text(" going to infinity, a sequence ")#mi("R_n")#text(" of “increasingly pseudorandom” subsets of ")#mi("\\{1,\\ldots,N_n\\}")#text(", and sets ")#mi("A_n \\subset R_n")#text(" with ")#tao-math("\\left|A_n\\right| \\geq \\delta \\left|R_n\\right|", block: false)#text(" such that none of the ")#mi("A_n")#text(" contain k-term arithmetic progressions.")

#text("As before, it is not difficult to ensure ")#mi("N_n")#text(" to be prime, and that ")#mi("A_n")#text(" lives in the bottom half ")#mi("R_n \\cap \\{1,\\ldots,\\lfloor N_n/2\\lfloor\\}")#text(" of ")#mi("R_n")#text(". We then create the random translated and dilated set ")#mi("B_n := (A_n - h) \\cdot r")#text(" as before; note that ")#mi("B_n")#text(" still has no k-term arithmetic progressions (except in the degenerate case r=0, but this case is extremely rare and becomes irrelevant in the limit). We can also randomly translated and dilate ")#mi("R_n")#text(" by the same parameters to obtain a random set ")#mi("S_n := (R_n - r) \\cdot r")#text("; thus ")#mi("B_n")#text(" is a relatively dense subset of the random (and potentially quite sparse) set ")#mi("S_n")#text(".")

#text("In the previous two sections, we looked at the (Borel) probability measure ")#mi("\\mu_n")#text(" on the power set ")#mi("2^{\\Bbb Z}")#text(" formed by the distribution of ")#mi("B_n")#text(", which can be viewed as a collection of cylinder statistics such as")

#align(center)[#tao-fit-display[#mitex("\\mu_n( C(3, 5, \\overline{17}) ) = {\\Bbb P}( 3, 5 \\in B_n; 17 \\not \\in B_n )")]]

#text("where ")#mi("C(3,5,\\overline{17})")#text(" is the cylinder set ")#mi("\\{ A \\subset {\\Bbb Z}: 3, 5 \\in A; 17 \\not \\in A \\}")#text(". In order for these statistics to actually arise from a Borel probability measure, these statistics have to be numbers lying between 0 and 1, and they have to obey compatibility conditions such as")

#align(center)[#tao-fit-display[#mitex("\\mu_n( C(3, \\overline{17}) ) = \\mu_n( C(3, 5, \\overline{17}) ) + \\mu_n( C(3, \\overline{5}, \\overline{17}) ),")]]

#text("and also")

#align(center)[#mi("\\mu_n( 2^{\\Bbb Z}) = \\mu_n(C()) = 1")#text(".")]

#text("Conversely, any set of non-negative numbers obeying these properties will give a Borel probability measure, thanks to the ")#link("http://en.wikipedia.org/wiki/Caratheodory_extension_theorem")[#text("Carathéodory extension theorem")]#text(".")

#text("In the sparse case, this approach does not work, because ")#mi("\\mu_n")#text(" degenerates in the limit if ")#mi("R_n")#text(" is sparse. For instance, because ")#mi("B_n")#text(" is so sparse, the probability ")#mi("{\\Bbb P}( 3, 5 \\in B_n; 17 \\not \\in B_n )")#text(" can go to zero; indeed, we expect this quantity to look like ")#tao-math("O( \\left|R_n\\right|/ N )^2", block: false)#text(". To fix this we do two things. Firstly, we replace the absolute complement ")#mi("\\overline{B_n} = \\{1,\\ldots,N_n\\} \\backslash B_n")#text(" that implicitly appears above by the relative complement ")#mi("S_n")#text(". Secondly, we introduce the normalising factor ")#tao-math("N_n/\\left|R_n\\right|", block: false)#text(", so for instance the cylinder set ")#mi("C( 3, 5, \\overline{17} )")#text(" will now be assigned the normalised weight")

#align(center)[#tao-fit-display[#tao-math("\\mu_n( C(3, 5, \\overline{17}) ) = (\\frac{N_n}{\\left|R_n\\right|})^3 {\\Bbb P}( 3, 5 \\in B_n; 17 \\in S_n \\backslash B_n )", block: true)]]

#text("and similarly for other cylinder sets. Perhaps more suggestively, we have")

#align(center)[#tao-fit-display[#mitex("\\mu_n( C(3, 5, \\overline{17}) ) ={\\Bbb E}_{a, r \\in {\\Bbb Z}/N_n {\\Bbb Z}} \\Lambda_n(a+3r) \\Lambda_n(a+5r) (\\nu_n-\\Lambda_n)(a+17r)")]]

#text("where ")#tao-math("\\Lambda_n := \\frac{N_n}{\\left|R_n\\right|} 1_{A_n}", block: false)#text(" and ")#tao-math("\\nu_n := \\frac{N_n}{\\left|R_n\\right|} 1_{R_n}", block: false)#text(".")

#text("This gives us a non-negative number assigned to every cylinder set, but unfortunately these numbers do not obey the compatibility conditions required to make these numbers arise from a probability measure. However, if one assumes enough pseudorandomness conditions such as (1), one can show that the compatibility conditions are satisfied approximately, thus for instance")

#align(center)[#tao-fit-display[#mitex("\\mu_n( C(3, \\overline{17}) ) = \\mu_n( C(3, 5, \\overline{17}) ) + \\mu_n( C(3, \\overline{5}, \\overline{17}) ) + o(1)")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_{a,r \\in {\\Bbb Z}/N_n {\\Bbb Z}} \\Lambda(a+3r) (\\nu-1)(a+5r) (\\nu-\\Lambda)(a+17r) = o(1).")]]

#text("These conditions can be checked using a large number of applications of the Cauchy-Schwarz inequality, which we omit here. Thus, ")#mi("\\mu_n")#text(" is not a true probability measure, but is some sort of approximate “virtual probability measure”. It turns out that these virtual probability measures enjoy the same crucial weak compactness property as actual probability measures, and one can repeat all the previous arguments to deduce Theorem 10 from Theorem 7.")

#strong[#text("6. The correspondence principle for graphs")]

#text("In the previous three sections we considered the correspondence principle in the integers ")#mi("{\\Bbb Z}")#text(". It is not difficult to replace the integers with other amenable groups, such as ")#mi("{\\Bbb Z}^d")#text(" for some fixed d. Now we discuss a somewhat different-looking instance of the correspondence principle, coming from graph theory, in which the underlying group is now the (small) permutation group ")#mi("\\text{Perm}_0({\\Bbb Z})")#text(" consisting of those permutations ")#mi("\\sigma: {\\Bbb Z} \\to {\\Bbb Z}")#text(" which permute only finitely many elements. (It is convenient to work with this group, rather than the entire group of permutations, as it is countable.) We illustrate the graph correspondence principle with the following old result ")#link("http://www.ams.org/mathscinet-getitem?mr=519318")[#text("of Ruzsa and Szemerédi")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11.")]#text(" (Triangle removal lemma, Type 3 version) For every ")#mi("\\epsilon > 0")#text(" there exists ")#mi("\\delta > 0")#text(" and ")#mi("N_0 > 0")#text(" such that for any ")#mi("G = (V,E)")#text(" be a graph on N vertices for some ")#mi("N \\geq N_0")#text(" which has at most ")#mi("\\delta N^3")#text(" triangles, one can remove at most ")#mi("\\epsilon N^2")#text(" edges from the graph to make the graph triangle free.")
]

#text("We will not discuss why this theorem is of interest, other than to mention in passing that it actually implies the k=3 case of Szemerédi’s theorem. (See also my ")#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/")[#text("blog")]#text(" ")#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/")[#text("posts")]#text(" ")#link("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/")[#text("on")]#text(" related topics.) It turns out that this result can be deduced from some infinitary versions of this lemma. Here is one instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12.")]#text(" (Triangle removal lemma, Type 2 version) Let G be a random graph on the integers ")#mi("{\\Bbb Z}")#text(" which is ")#emph[#text("exchangeable")]#text(" in the sense that any permutation of G has the same distribution as G. (This is the analogue of stationarity in this setting.) Suppose that G is almost surely triangle free, and let ")#mi("\\varepsilon > 0")#text(". Then there exists a continuous function F from the space ")#mi("2^{\\binom{\\Bbb Z}{2}}")#text(" of graphs on ")#mi("{\\Bbb Z}")#text(" (with the product topology) to the space ")#mi("2^{\\binom{\\Bbb N}{2}}")#text(" of graphs on ")#mi("{\\Bbb N}")#text(", which is equivariant with respect to permutations of ")#mi("{\\Bbb N}")#text(", such that ")#mi("G^{\\prime} := F(G)")#text(" is ")#emph[#text("surely ")]#text("(not just ")#link("http://en.wikipedia.org/wiki/Almost_surely")[#text("almost surely")]#text(") a subgraph of G which is triangle free, and such that ")#mi("{\\Bbb P}( (1,2) \\in G \\backslash G^{\\prime} ) \\leq \\varepsilon")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13. ")]#text("(Triangle removal lemma, Type 3 version) Let ")#mi("(X, \\mu)")#text(" be a probability space with a measure-preserving action of ")#mi("\\text{Perm}_0({\\Bbb Z})")#text(", and let ")#mi("E_{12}, E_{23}, E_{31}")#text(" be three measurable sets which are invariant under the stabiliser of ")#mi("\\{1,2\\}")#text(", ")#mi("\\{2,3\\}")#text(", and ")#mi("\\{3,1\\}")#text(" respectively. Suppose that ")#mi("E_{12} \\cap E_{23} \\cap E_{31}")#text(" has measure zero. Then one can find subsets ")#mi("E^{\\prime}_{12}, E^{\\prime}_{23}, E^{\\prime}_{31}")#text(" respectively of ")#mi("E_{12}, E_{23}, E_{31}")#text(", which remain invariant under the stabilisers of ")#mi("\\{1,2\\}")#text(", ")#mi("\\{2,3\\}")#text(", and ")#mi("\\{3,1\\}")#text(" respectively, such that ")#mi("E^{\\prime}_{12} \\cap E^{\\prime}_{23} \\cap E^{\\prime}_{31}")#text(" is empty (and not just measure zero).")
]

#text("The proofs that Theorem 12 and Theorem 13 imply Theorem 11 are somewhat technical, but in the same spirit as the previous applications of the correspondence principle; see this ")#link("http://arxiv.org/abs/0801.2179")[#text("paper")]#text(" (or ")#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/")[#text("blog")]#text(" posts) and ")#link("http://front.math.ucdavis.edu/math.CO/0602037")[#text("this paper")]#text(" respectively for details. In fact they prove slightly stronger statements than Theorem 11, in that they give a bit more information as to how the triangle-free graph G’ is obtained from the nearly triangle-free graph G. The same methods also apply to hypergraphs without much further difficulty, as is done in the above papers, but we will not discuss the details here.")

#strong[#text("7. The correspondence principle over finite fields")]

#text("The correspondence principle can also be applied quite effectively to the finite field setting, which is a dyadic model for the integer setting. In particular, Tamar Ziegler and I have very recently shown the equivalence of the following two results:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14.")]#text(" (Inverse Gowers conjecture for finite fields, Type 1 version) Let F be a finite field, let ")#mi("k \\geq 2")#text(", let ")#mi("\\delta > 0")#text(", and let ")#mi("f: F^n \\to {\\Bbb C}")#text(" be a function on some vector space ")#mi("F^n")#text(" bounded in magnitude by 1, and such that the Gowers norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^k(F^n)} := ({\\Bbb E}_{h_1,\\ldots,h_k,x \\in F^n} \\Delta_{h_1} \\ldots \\Delta_{h_k} f(x))^{1/2^k}", block: true)]]

#text("is larger than ")#mi("\\delta")#text(", where ")#mi("\\Delta_h f(x) := f(x+h) \\overline{f(x)}")#text(". Then there exists a function ")#mi("\\phi: F^n \\to S^1")#text(" which is a ")#emph[#text("phase polynomial of degree at most k")]#text(" in the sense that ")#mi("\\Delta_{h_1} \\ldots \\Delta_{h_k} \\phi(x) = 1")#text(" for all ")#mi("h_1,\\ldots,h_k,x \\in F^n")#text(" (or equivalently, that ")#tao-math("\\left\\|\\phi\\right\\|_{U^k(F^n)} = 1", block: false)#text("), such that we have the correlation ")#tao-math("\\left|{\\Bbb E}_{x \\in F^n} f(x) \\overline{\\phi(x)}\\right| \\geq c(F,k,\\delta)", block: false)#text(" for some ")#mi("c(F,k,\\delta) > 0")#text(" independent of n.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15.")]#text(" (Inverse Gowers conjecture for finite fields, Type 4 version) Let ")#mi("(X,\\mu)")#text(" be a probability space, let F be a finite field, and let ")#mi("g \\mapsto T_g")#text(" be a measure-preserving action of the infinite group ")#mi("F^\\omega := \\lim_{\\leftarrow} F^n")#text(". Let ")#mi("f \\in L^\\infty(X)")#text(" be such that the Gowers-Host-Kra seminorm")

#tao-math("\\left\\|f\\right\\|_{U^k(X)} := \\lim_{n \\to \\infty} ({\\Bbb E}_{h_1,\\ldots,h_k \\in F^n} \\int_X \\Delta_{h_1} \\ldots \\Delta_{h_k} f \\mu)^{1/2^k}", block: false)

#text("is positive, where ")#mi("\\Delta_h f(x) := f( T^h x ) \\overline{f(x)}")#text(". Then there exists ")#mi("\\phi: X \\to S^1")#text(" which is a phase polynomial in the sense that ")#mi("\\Delta_{h_1} \\ldots \\Delta_{h_k} \\phi = 1")#text(" a.e., and which correlates with f in the sense that ")#mi("\\int_X f \\overline{\\phi}\\ d\\mu \\neq 0")#text(".")
]

#text("In a forthcoming paper of Bergelson, Ziegler, and myself (which I hope to discuss here on this blog in the near future), Theorem 15 was established, which by the correspondence principle alluded to above, implies Theorem 14. (See my ")#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/")[#text("previous blog post")]#text(" for some discussion of Theorem 14, which had been conjectured for a few years. Interestingly, this result also holds in the low characteristic case, for which (as discussed in that post) the conjecture was believed to fail. The issue here is a little subtle: counterexamples are known if the phase polynomial ")#mi("\\phi")#text(" is constrained to be an ")#tao-math("\\left|F\\right|^{th}", block: false)#text(" root of unity, but with the above results we now know that these counterexamples are no longer present when the phase polynomial is allowed to range freely in ")#mi("S^1")#text(".)")

#text("I will try to discuss these things in more detail in a later post, but very roughly speaking the reason why the correspondence principle is more effective here than on the integers is because the vector space ")#mi("F^n")#text(" enjoys a massively ")#link("http://en.wikipedia.org/wiki/Transitive_group_action#Types_of_actions")[#text("transitive")]#text(" action of the ")#link("http://en.wikipedia.org/wiki/General_linear_group")[#text("general linear group")]#text(" ")#mi("GL(F^n)")#text(" that mixes things around in a manner much stronger than even the affine action ")#mi("\\text{Aff}({\\Bbb Z})")#text(" mentioned earlier (which is basically 2-transitive but not k-transitive for any higher k).")

#strong[#text("8. The correspondence principle for convergence of ergodic averages")]

#text("My final instance of the correspondence principle goes in the opposite direction from previous instances. In the preceding seven instances, the interesting aspect of the principle was that one could use a qualitative result about infinite systems to deduce a quantitative result about finite systems. Here, we will do the reverse: we show how a result about infinite systems can be deduced from one from a finite system. We will illustrate this with a very simple result from ergodic theory, the mean ")#link("http://en.wikipedia.org/wiki/Ergodic_theorem")[#text("ergodic theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 16")]#text(" (Mean ergodic theorem, Type 4 version) Let ")#mi("(X,\\mu,T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^2(X)")#text(". Let ")#mi("S_N")#text(" be the averaging operators ")#mi("S_N f := {\\Bbb E}_{1 \\leq n \\leq N} T^n f")#text(". Then ")#mi("S_N f")#text(" is a convergent sequence in ")#mi("L^2(X)")#text(" as ")#mi("N \\to \\infty")#text(".")
]

#text("This is of course a well-known result with many short and elegant proofs; the proof method that we sketch here (essentially due ")#link("http://arxiv.org/abs/0706.1512")[#text("to Avigad, Gerhardy, and Towsner")]#text(") is lengthier and messier than the purely infinitary proofs, but can be extended to some situations in which it had been difficult to proceed in an infinitary manner (in particular on ")#link("http://arxiv.org/abs/0707.1117")[#text("my result")]#text(" on convergence for multiple commuting transformations, as discussed in this ")#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/")[#text("post of mine")]#text(").")

#text("The basic problem with finitising this theorem is that there is no uniform rate of convergence in the mean ergodic theorem: given any ")#mi("\\epsilon > 0")#text(", we know that the averages ")#mi("S_N f")#text(" eventually lie within ")#mi("\\varepsilon")#text(" of their limit for N large enough, but it is known that the N we need for this is not uniform in the choice of the system ")#mi("(X,\\mu,T)")#text(" or the function f, and can indeed by arbitrarily large for given ")#mi("\\varepsilon")#text(" even after fixing the size of f. So a “naive” finitisation does not work, much as a naive finitisation of the infinite convergence principle (every bounded monotone sequence converges), as discussed in ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this post")]#text(".")

#text("The resolution is in fact very similar to that discussed in the above-mentioned post. Observe that if ")#mi("x_1, x_2, \\ldots")#text(" is any sequence in a complete metric space (e.g. the real line, or ")#mi("L^2(X)")#text("), the statement that “")#mi("x_n")#text("” converges”, or equivalently that “")#mi("x_n")#text(" is ")#link("http://en.wikipedia.org/wiki/Cauchy_sequence")[#text("Cauchy")]#text("“, is equivalent to")

#align(center)[#text("For every ")#mi("\\varepsilon > 0")#text(", there exists n such that for all sufficiently large m, ")#mi("d(x_n,x_m) \\leq \\varepsilon")#text(",")]

#text("which is in turn equivalent to")

#align(center)[#text("For every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("F_0: {\\Bbb N} \\to {\\Bbb N}")#text(" such that for every ")#mi("F: {\\Bbb N} \\to {\\Bbb N}")#text(" that grows faster than ")#mi("F_0")#text(" in the sense that ")#mi("F(n) > F_0(n)")#text(" for all n, one has ")#mi("d(x_n,x_{F(n)}) \\leq \\varepsilon")#text(" for some n.")]

#text("The point here is that once the function F is selected, one only has to verify the closeness of a single pair of elements in the sequence, rather than infinitely many. This makes it easier to finitise the convergence statement effectively. Indeed, Theorem 16 is easily seen (by another compactness and contradiction argument) to be equivalent to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17")]#text(" (Mean ergodic theorem, Type 3 version) For every ")#mi("\\varepsilon > 0")#text(" and every sufficiently rapid F (i.e. F grows faster than some ")#mi("F_0")#text(" depending on ")#mi("\\varepsilon")#text(") there exists N such that for every measure-preserving system ")#mi("(X,\\mu,T)")#text(" and every ")#mi("f \\in L^2(X)")#text(" with ")#tao-math("\\left\\|f\\right\\|_{L^2(X)} \\leq 1", block: false)#text(", we have ")#tao-math("\\left\\|S_n f - S_{F(n)} f \\right\\|_{L^2(X)} \\leq \\varepsilon", block: false)#text(" for some ")#mi("1 \\leq n \\leq N")#text(".")
]

#text("Note that this theorem is quantitative in the sense that N depends only on ")#mi("\\varepsilon")#text(" and F, and not on the underlying system; indeed one can give an explicit value for N, arising from iterating F about ")#mi("1/\\varepsilon^2")#text(" times. This result is essentially proven as Corollary 2 of my ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("254A lecture notes on this topic")]#text(".")

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32321")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2008")])]

#text("Terry, that’s great news and I look forward to hearing more about it. For now, let me say congratulations and also make the stupid remark that you seem to have forgotten a “latex” in your statement of Theorem 15.")

#text("There’s a sort of intermediate reformulation of Szemeredi’s theorem that I like (and that you of course know well), which serves a bridge between the finitary statement and the ergodic one. It’s that if ")#mi("f")#text(" is a function on ")#mi("\\mathbb{Z}/n\\mathbb{Z}")#text(" that takes values in ")#mi("{}[0,1]")#text(" and has average ")#mi("\\delta>0")#text(" then there’s a constant ")#mi("c")#text(" that depends on ")#mi("\\delta")#text(" only such that the average value of ")#mi("f(x)f(x+d)f(x+2d)")#text(" is bounded below by ")#mi("c")#text(". It’s easily seen to be equivalent to the Varnavides version and I find it the most natural one to think about from an analytic-but-finite point of view.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32332")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2008")])]

#text("Theorem 12 should include something about the triangle-freeness of the graph, right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32334")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2008")])]

#text("Dear Tim and Anthony: thanks for the corrections! Tim, you are of course right that the finitary versions of Szemeredi’s theorem are best phrased using functions instead of sets (and the infinitary versions can be formulated that way also), but the correspondence principle is a little bit trickier to pull off in that setting (though not by too much) so I avoided it in my lectures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32341")[#strong[#text("Sean")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2008")])]

#text("Here are some possible typos:")#linebreak()#text(" – In the ‘approximate independence conditions’ stated after Theorem 10, the definition of ")#mi("\\nu")#text(" is not typesetting.")#linebreak()#text(" – Should the G’ in Theorem 12 equal F(G)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32353")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2008")])]

#text("Dear Sean: thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3cab72c6f7c640c47ff649b3411d9a3f34129389be3418febc4e4a65d08e5b5-29091e9390891e05aba45dfc1d3ba5582c4e7800ae2409ab8bcfef2012909d2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Indian")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32355")[#strong[#text("Indian")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2008")])]

#text("REQUEST")

#text("Dear Prof Terence Tao, I was waiting for a reply to this query , I surmise you might have overlooked this query, it’s an important query that plays a pivotal role in solving intricate problems.")

#text("QUERY")

#text("Hello Mr Tao, I would like to know if imagination plays a comprehensive role in solving intricate problems, if so do you possess vivid powers of imagination? How do you approach a convoluted problem? Do you apply “Imagination” , other “tricks” ,etc, in arriving at a solution, please answer this query, I thank you in advance.")

#text("Prof Terence Tao, I humbly request you to answer this query, I am requesting you, please, I will be grateful to you, i apologize for posting this query over here, I thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32382")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2008")])]

#text("Dear Indian,")

#text("I think each mathematician has his or her own way to make progress, but I personally do not think of myself as particularly imaginative, and in fact imagination does not play much of a role in my own mathematics; to me, other attributes, such as having insight, intuition, knowledge, clarity of thought, concentration, appreciation of the “big picture”, and immersion in a problem, are significantly more important. While one does of course have to come up with new ideas (as well as applying, refining, clarifying, or modifying existing technology, of course) when solving any genuinely non-trivial problem, I find that such ideas tend to be found naturally – without the need for any wildly creative or imaginative leap of faith – after one has thought about the problem long enough, isolated the main difficulties, found the key test cases or model problems, understood the key counterexamples, grasped the strengths and weaknesses of existing methods, and so forth. Such new ideas may ")#emph[#text("appear")]#text(" to come “out of the blue” to outside observers who have not spent quite as much time being immersed in the problem, but they are usually in fact closely connected to the context that one is working in.")

#text("It does happen from time to time that a truly original idea causes an important breakthrough in a field, but in the majority of cases (particularly in mature fields), mathematical progress is usually based primarily on existing technology, and to organic refinements and modifications to that technology, as these are, after all, tried and tested ideas that are proven to work. Most new ideas in fact end up not being particularly effective, especially if they are not guided by the existing body of results, intuition, heuristics, etc., although often the ")#emph[#text("reason")]#text(" for the failure of these ideas tends to be rather instructive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of philipp")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32386")[#strong[#text("philipp")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2008")])]

#text("dear prof. tao,")

#text("right at the end of 1. it should be “Theorem 3 implies Theorem 1” and not vice versa.")

#text("best regards,")

#text("philipp")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32441")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2008")])]

#text("Dear philipp: thanks for the correction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32442")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2008")])]

#text("Dr. Tao,")

#text("I’m a bit confused about how your new result on the inverse Gower’s conjecture reconciles with the previously discussed “counterexample.” Did the formulation of the statement change in low characteristic, or is the counterexample, in fact, not a counterexample?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-32500")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2008")])]

#text("Dear anonymous:")

#text("It turns out that there are two formulations of the Gowers inverse conjecture in finite fields, one in which polynomials are constrained to lie in p^th roots of unity, and the other in which polynomials are allowed to range freely in the unit circle. For high characteristic (p >= k) some simple algebra shows that the two formulations are equivalent. But in low characteristic, there exist polynomials that do not take values in p^th roots of unity (even after multiplying by constants). For instance, the function that maps 0 to 1 and 1 to i is a quadratic phase polynomial from F_2 to S^1 which does not take values in the second roots of unity {-1,1}.")

#text("The first formulation of the Gowers inverse conjecture fails in low characteristic, but our result (which we are still checking and polishing, but should be ready for uploading soon) shows that the second formulation continues to hold in this case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The inverse conjecture for the Gowers norm over finite fields via the correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-33354")[#strong[#text("The inverse conjecture for the Gowers norm over finite fields via the correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2008")])]

#text("[…] principle“, submitted to Analysis & PDE. As announced a few months ago in this blog post, this paper establishes (most of) the inverse conjecture for the Gowers norm from an ergodic theory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Infinite fields, finite fields, and the Ax-Grothendieck theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-36428")[#strong[#text("Infinite fields, finite fields, and the Ax-Grothendieck theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("[…] correspondence Serre discusses is slightly different from the one I discuss for instance in here or here, although there seems to be a common theme of “compactness” (or of model theory) tying […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The completeness and compactness theorems of first-order logic « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-38115")[#strong[#text("The completeness and compactness theorems of first-order logic « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2009")])]

#text("[…] as the elementary limits of sequences of finite fields. I recently discovered that other several correspondence principles between finitary and infinitary objects, such as the Furstenberg correspondence principle between […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Szemeredi’s regularity lemma via the correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-38653")[#strong[#text("Szemeredi’s regularity lemma via the correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2009")])]

#text("[…] through a graph-theoretic version of the Furstenberg correspondence principle (mentioned briefly in this earlier post of mine). While this approach superficially looks quite different from the combinatorial approach, it in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-41106")[#strong[#text("GILA 1: van der Waerden and all that « Portrait of the Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2009")]

#text("[…] be seen to be equivalent to the infinitary version stated earlier in the post, by what Terry Tao calls the Arzela-Ascoli trick. The key is to proceed by induction on k; fix some k and assume the theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A finitary version of Gromov’s polynomial growth theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-41985")[#strong[#text("A finitary version of Gromov’s polynomial growth theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2009")])]

#text("[…] subgroup of , and the step of that subgroup). However, a compactness argument (sketched in this previous blog post) shows that some such relationship must exist; indeed, if one has (1) for all for some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate bases, sunflowers, and nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-42809")[#strong[#text("Approximate bases, sunflowers, and nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")])]

#text("[…] theorems to each other without a significant increase in effort. (This is closely related to various correspondence principles between combinatorics and parts of infinitary mathematics, such as ergodic theory; see also my post […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultralimit analysis, and quantitative algebraic geometry « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-43423")[#strong[#text("Ultralimit analysis, and quantitative algebraic geometry « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("[…] analysis, ultrafilters, ultralimit analysis | by Terence Tao I have blogged a number of times in the past about the relationship between finitary (or “hard”, or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Free probability « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-43563")[#strong[#text("245A, Notes 5: Free probability « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("[…] up in the application of ergodic theory to combinatorics via the correspondence principle; see this previous blog post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A computational perspective on set theory « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-43935")[#strong[#text("A computational perspective on set theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("[…] only finitely many points or numbers, etc.); I have explored this theme in a number of previous blog posts. So, one may ask: what is the finitary analogue of statements such as Cantor’s theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nonstandard analysis as a completion of standard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-48285")[#strong[#text("Nonstandard analysis as a completion of standard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2010")])]

#text("[…] theorem for ultrapowers to establish various versions of the correspondence principle, as discussed previously on this blog. A simple example occurs when demonstrating the equivalence of colouring theorems, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-49767")[#strong[#text("The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2011")])]

#text("[…] a crucial role in Gromov’s proof of his theorem on groups of polynomial growth (discussed previously on this blog), and in a more recent paper of Hrushovski on approximate groups (also discussed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A topological proof of Van der Waerden’s Theorem | YAMB")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-49969")[#strong[#text("A topological proof of Van der Waerden’s Theorem | YAMB")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")])]

#text("[…] 2. We now present a standard compactness argument, explored in great detail by Terence Tao in his blog, to derive the other […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-150825")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2012")])]

#text("In the statement of Theorem 8′, I assume you want to add that ")#mi("N \\geq N_0")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An informal version of the Furstenberg correspondence principle | What's new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-221341")[#strong[#text("An informal version of the Furstenberg correspondence principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2013")])]

#text("[…] the string , and leads to the Furstenberg correspondence principle, discussed for instance in these previous blog posts. Such principles allow one to rigorously pass back and forth between the combinatorics […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-478883")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] correspondence principle is discussed in these previous blog posts. One way to establish the principle is by introducing a Banach limit that extends the usual limit […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1f8ba60258f2fe287742c70e31c82fc784f2f1d90366d94305084d291f3ff04-46edd238a81d690eb0e927bbe8b2fcf73aadf386f1bf4b986acf14ebb9da4f76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ahartel")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-497969")[#strong[#text("ahartel")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2018")])]

#text("I have a question regarding the proof that Theorem 1 implies Theorem 2. I’m not sure if anybody will read my question at all given the fact that this post is almost 10 years old, but I’ll try anyway.")#linebreak()#text(" But let me first express my gratitude to you for writing this blog and for exposing so much of your mathematical thinking. I think you serve the discipline invaluably in writing this blog and being so open with your ideas.")#linebreak()#text(" But back to my question: While thinking about the proof that the infinitary vdW impies the finitary vdW (Theorem 2) I was wondering if the diagonalization trick is even necessary. After all, we’re interested in a finite section of the “limit coloring” of all integers, a finite section that only just contains our k-term AP. Now we want to make sure that there also exist finite colorings with the same colors in that section in order to complete the contradiction.")#linebreak()#text(" So in order to construct the “pre-infinite” coloring with the k-term AP we might start by picking a subsequence along one position (say 17). We then proceed along all positions of our finite section and get “thinner and thinner” subsequences for the other positions. Since we only “thin out” finitely often we should be fine and end up with stable colors (for some N) all along the section. Contradiction complete, proof complete. So I don’t understand why we need to add finitely many elements to each sub-sub-sequence by picking the diagonalized subsequence globally. I would be very thankfull if someone could help me improve my understanding.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-498050")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("I’m not sure I follow your argument – it would help if you would give names to all the colorings etc. you are discussing – but one can’t apply the infinitary van der Waerden theorem unless one has an infinite coloring; merely being able to color a finite portion of the integers doesn’t immediately yield any conclusion. (One could add dummy colors to all the integers outside this finite portion, but then the monochromatic AP provided by the infinitary van der Waerden theorem might reside partially or fully in the dummy region, and again one does not obtain any useful conclusion.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1f8ba60258f2fe287742c70e31c82fc784f2f1d90366d94305084d291f3ff04-46edd238a81d690eb0e927bbe8b2fcf73aadf386f1bf4b986acf14ebb9da4f76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ahartel")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-498270")[#strong[#text("ahartel")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2018")])]

#text("Thank you for taking the time to read and answer my question. Your reply was very helpful indeed. Of course you can only apply Thm. 1 once you’ve obtained a coloring of all the integers.")#linebreak()#text(" And also, next time I’ll try to be more precise in naming my objects.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-498387")[#strong[#text("Finitary versions of theorems – Write down what you’ve done")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2018")]

#text("[…] ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abstracting induction on scales arguments | What's new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-517385")[#strong[#text("Abstracting induction on scales arguments | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2019")])]

#text("[…] In this post I would like to observe that one can clean up and made more systematic this final step (iii) by passing to upper exponents (12) to eliminate the role of the parameter (and also “tropicalising” all the estimates), and then taking similar limit superiors to eliminate some other less important parameters, until one is left with a simple linear programming problem (which, among other things, could be amenable to computer-assisted proving techniques). This method is analogous to that of passing to a simpler asymptotic limit object in many other areas of mathematics (for instance using the Furstenberg correspondence principle to pass from a combinatorial problem to an ergodic theory problem, as discussed in this previous post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-564648")[#strong[#text("247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("[…] correspondence Serre discusses is slightly different from the one I discuss for instance in here or here, although there seems to be a common theme of “compactness” (or of model theory) tying […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-685713")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2024")])]

#text("Dear Terry,")

#text("The ‘unpublished not of mine’ link is dead. Do you know where I can find this unpublished note? Cheers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/#comment-685714")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2024")])]

#text("I have found it: ")#link("https://www.math.ucla.edu/~tao/preprints/Expository/limiting.pdf")[#text("https://www.math.ucla.edu/~tao/preprints/Expository/limiting.pdf")]

#emph[#text("[Link corrected, thanks – T.]")]
]
]
