// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/
// Converted to Typst by tao2typ: "2026-10-14T16:35:08.066132+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series I: Avi Wigderson, “The power and weakness of randomness in computation”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series I: Avi Wigderson, “The power and weakness of randomness in computation”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/")[#text("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("http://www.math.ucla.edu/dls/index.html")[#text("Distinguished Lecture Series")]#text(" at UCLA for this winter quarter is given by ")#link("http://en.wikipedia.org/wiki/Avi_Wigderson")[#text("Avi Wigderson")]#text(", who is lecturing on “")#link("http://www.math.ucla.edu/dls/2008/aw.html")[#text("some topics in computational complexity")]#text("“. In his first lecture on Wednesday, Avi gave a wonderful talk (in his inimitably entertaining style) on “")#link("http://www.math.ucla.edu/dls/2008/absaw1.html")[#text("The power and weakness of randomness in computation")]#text("“. The talk was based on ")#link("http://www.math.ucla.edu/dls/2008/Gibbs.pdf")[#text("these slides")]#text(". He also gave a sort of “encore” on ")#link("http://en.wikipedia.org/wiki/Zero-knowledge_proof")[#text("zero-knowledge proofs")]#text(" in more informal discussions after the main talk.")

#text("As always, any errors here are due to my transcription and interpretation.")

#metadata(none) <tao-8418dbfebf67e8ccc0d6>

#text("The theme of this talk was the close relationship between ")#emph[#text("hardness ")]#text("(computational complexity) and ")#emph[#text("randomness")]#text(" (and specifically, the use of randomness to save on resources such as time or memory).")

#heading(level: 1)[#text("— Computational complexity —")]

#text("Avi began with some examples to illustrate “easy” and “hard” computational problems. For instance:")

#enum(start: 1, 
[#emph[#text("Multiplication")]#text(" of two n-digit numbers is easy; the ")#link("http://en.wikipedia.org/wiki/Multiplication_algorithm#Long_multiplication")[#text("long multiplication")]#text(" algorithm one learns in primary school lets one do this in ")#mi("O(n^2)")#text(" steps (and ")#link("http://en.wikipedia.org/wiki/Multiplication_algorithm")[#text("faster algorithms are also known")]#text("); but")],
[#emph[#text("Factorisation")]#text(" of an n-digit number is believed to be hard; for large n, the ")#link("http://en.wikipedia.org/wiki/General_number_field_sieve")[#text("fastest known factoring algorithm")]#text(" is believed to take ")#mi("\\exp( O( n^{1/3} \\log^{2/3} n ) )")#text(" steps (the ")#link("http://en.wikipedia.org/wiki/Quadratic_sieve")[#text("fastest algorithm with a rigorous costing")]#text(" takes ")#mi("\\exp( O( n^{1/2} \\log^{1/2} n ) )")#text(" steps). Avi made the point that all of us implicitly agree with this belief of hardness when we entrust modern cryptographic protocols to protect our information when, say, using a credit card over the internet.")],
[#emph[#text("Theorem-proving")]#text(" – the task of finding a proof of a given statement S using at most n steps in a given axiom system – is also widely believed to be hard (indeed, my job, and the job of my colleagues, arguably depends crucially on this belief :-) ). [In contrast, ")#emph[#text("verifying")]#text(" that a given n-step proof actually does prove S is (in principle) easy, though not always in practice…]")]
)

#text("It is not known whether factoring is truly hard, or whether theorem-proving is truly hard. But there is a known reduction: if theorem-proving is easy (in the sense that it is a ")#link("http://en.wikipedia.org/wiki/P_%28complexity%29")[#text("polynomial time algorithm")]#text("), then factoring is also easy. This is because theorem-proving is an ")#link("http://en.wikipedia.org/wiki/NP-complete")[#text("NP-complete")]#text(" problem (this follows from the ")#link("http://en.wikipedia.org/wiki/Cook-Levin_theorem")[#text("Cook-Levin theorem")]#text(").")

#text("The famous ")#link("http://en.wikipedia.org/wiki/P_%3D_NP_problem")[#mi("P \\neq NP")#text(" problem")]#text(" is thus formally equivalent to the statement that theorem proving is not easy. At a more philosophical level, one can view ")#mi("P \\neq NP")#text(" as an assertion that “creativity cannot be automated”.")

#text("There are many other NP-complete problems known in mathematics and science (indeed, Avi noted that such problems appear to be “uniformly distributed” throughout these disciplines). We thus have the following informal")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Belief 1")]#text(": “natural” problems such as factoring, theorem-proving, ")#link("http://en.wikipedia.org/wiki/Graph_coloring")[#text("3-colourability of graphs")]#text(", computation of the ")#link("http://en.wikipedia.org/wiki/Permanent")[#text("permanent")]#text(", etc. are hard.")
]

#text("(One can view the assertion ")#mi("P \\neq NP")#text(" as a particularly famous instantiation of this belief, but there are others.)")

#heading(level: 1)[#text("— The power of randomness —")]

#text("Avi now turned from hardness to randomness. There is a vast body of empirical evidence suggesting that probabilistic algorithms can be much faster than deterministic algorithms, at the cost of introducing a small probability that the algorithm can fail. In particular, there are many problems for which a polynomial time probabilistic algorithm is known, but all known deterministic algorithms require exponential time at least.")

#text("More formally, we say that a problem has a polynomial time probabilistic algorithm if there exists an algorithm that takes the given input, combines it with a polynomially long string of random independent unbiased bits (or “coin flips”), and after a polynomial number of computations returns an output which correctly solves the problem for at least 99% (say) of the possible values of the random bits. Note that there is nothing special about 99%; by iterating the algorithm repeatedly with the same input (but with fresh random bits) and then taking a ")#link("http://en.wikipedia.org/wiki/Majority")[#text("majority ")]#text("vote, one can amplify the accuracy to the point where the failure rate is exponentially small while the run time remains polynomial.")

#text("All things being equal, of course, a deterministic algorithm would still be preferable to a probabilistic one: 100% success is better than 99% success. But probabilistic algorithms can be much faster, as the following four diverse examples show:")

#enum(start: 1, 
[#link("http://en.wikipedia.org/wiki/Primality_test")[#text("Primality testing")]#text(". The question of whether one can quickly determine whether a given n-digit number is prime was considered as far back as Gauss (who mused whether there was an “indefatigable calculator” who could perform such tasks). Naive primality testing methods tend to be exponential time; the first polynomial time algorithms (such as ")#link("http://en.wikipedia.org/wiki/Miller-Rabin_primality_test")[#text("Miller-Rabin")]#text(" and ")#link("http://en.wikipedia.org/wiki/Solovay-Strassen_primality_test")[#text("Solovay-Strassen")]#text(", discovered in the late 1970s) were probabilistic. A polynomial time deterministic primality test was only recently discovered ")#link("http://en.wikipedia.org/wiki/AKS_primality_test")[#text("by Agrawal, Kayal, and Saxena")]#text(" (though, in practice, it is still a little slower than the probabilistic tests). On the other hand, if we modify the problem slightly to that of ")#emph[#text("finding")]#text(" an n-digit prime for a given n, no polynomial time deterministic algorithm is known, although one can trivially iterate the probabilistic primality tests to obtain a polynomial time probabilistic prime-finding algorithm.")],
[#link("http://en.wikipedia.org/wiki/Schwartz-Zippel_lemma_and_testing_polynomial_identities")[#text("Verification of polynomial identities")]#text(". Suppose one is given two polynomials ")#mi("P(x_1,\\ldots,x_n), Q(x_1,\\ldots,x_n)")#text(" of degree at most d in n variables, expressed in some easily computable formula (e.g. involving determinants). Can one quickly determine whether the two polynomials are equal? (A good example here is ")#link("http://en.wikipedia.org/wiki/Vandermonde_matrix")[#text("Vandermonde’s identity")]#text("). Expanding out all the coefficients can take exponential time. But there is a quick and simple probabilistic algorithm: simply test the identity ")#mi("P(x_1,\\ldots,x_n)=Q(x_1,\\ldots,x_n)")#text(" for some randomly chosen inputs ")#mi("(x_1,\\ldots,x_n) \\in \\{1,\\ldots,100d\\}^n")#text("; the fact that this algorithm is probabilistically ")#link("http://en.wikipedia.org/wiki/Soundness")[#text("sound")]#text(" (gives few ")#link("http://en.wikipedia.org/wiki/False_positive#False_positive_rate")[#text("false positives")]#text(") ")#link("http://en.wikipedia.org/wiki/Schwartz-Zippel_lemma_and_testing_polynomial_identities")[#text("follows from the Schwartz-Zippel lemma")]#text(". (It is clear that the test gives no false negatives.) On the other hand, no sub-exponential deterministic algorithm for polynomial identity testing is known.")],
[#text("Large Fourier coefficients. Given an n-bit boolean function ")#mi("f: {\\Bbb F}_2^n \\to \\{-1,1\\}")#text(" (expressed in some rapidly computable form) and a threshold ")#mi("\\varepsilon > 0")#text(", a simple application of ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel’s identity")]#text(" shows that there are at most ")#mi("1/\\varepsilon^2")#text(" frequencies ")#mi("\\xi \\in {\\Bbb F}_2^n")#text(" for which the ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier coefficient")]#text(" ")#mi("\\hat f(\\xi) := \\frac{1}{2^n} \\sum_{x \\in {\\Bbb F}_2^n} (-1)^{x \\cdot \\xi} f(x)")#text(" has magnitude at least ")#mi("\\varepsilon")#text(". But how can one find these frequencies? Even using a ")#link("http://en.wikipedia.org/wiki/Fast_Fourier_transform")[#text("fast Fourier transform")]#text(", a direct search would require exponential time in n; no deterministic subexponential time algorithm is known. However, the ")#link("http://portal.acm.org/citation.cfm?id=73010")[#text("Goldreich-Levin theorem")]#text(" can be used to provide a probabilistic polynomial time algorithm for this task.")],
[#text("Computing volume. Given some effective description of a d-dimensional convex body (e.g. a list of bounding hyperplanes), can one quickly determine the volume? This problem is ")#link("http://en.wikipedia.org/wiki/Sharp-P")[#text("#P complete")]#text(" (thus, even harder than NP-complete!), thanks to work of ")#link("http://portal.acm.org/citation.cfm?id=65094")[#text("Dyer-Frieze")]#text(" and Khachiyan, so the answer is almost certainly no. But what if one wanted to compute the volume up to a factor of 2? No fast deterministic algorithm is known, but by use of random walks in the polytope one can obtain a probabilistic polynomial time algorithm; this was first done ")#link("http://portal.acm.org/citation.cfm?id=102783&dl=ACM&coll=GUIDE")[#text("by Dyer, Frieze, and Kannan")]#text(".")]
)

#text("Based on this empirical evidence, one is led to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Belief 2")]#text(": There are problems which have easy probabilistic algorithms, but no easy deterministic algorithms.")
]

#text("(This belief is often formalised as the assertion ")#link("http://en.wikipedia.org/wiki/BPP")[#mi("P \\neq BPP")]#text(".)")

#heading(level: 1)[#text("— The weakness of randomness —")]

#text("Recent developments by Avi and his co-authors strongly suggest the following surprising fact:")

#align(center)[#emph[#text("Belief 1 and Belief 2 cannot simultaneously be true.")]]

#text("Morally, one now expects that if ")#mi("P \\neq NP")#text(", then ")#mi("P = BPP")#text(", although the strongest rigorous result in this direction so far is that if a sufficiently difficult problem (")#link("http://en.wikipedia.org/wiki/Boolean_satisfiability_problem")[#text("3-SAT")]#text(" will do, or any problem in the class ")#link("http://qwiki.stanford.edu/wiki/Complexity_Zoo#e")[#text("E")]#text(") requires an exponentially large ")#link("http://en.wikipedia.org/wiki/Circuit_complexity")[#text("circuit")]#text(" to solve, then ")#mi("P=BPP")#text(" (this is a slight oversimplification; the precise result is in this ")#link("http://www.ams.org/mathscinet-getitem?mr=1715634")[#text("paper of Impagliazzo and Wigderson")]#text("). For a more complete survey, I can recommend Avi’s ")#link("http://www.math.ias.edu/~avi/PUBLICATIONS/MYPAPERS/W06/w06.pdf")[#text("ICM lecture article")]#text(" on these topics.")

#text("The underlying reason for this phenomenon is this: if computationally hard problems exist, then these problems can be used to create strong ")#link("http://en.wikipedia.org/wiki/Pseudorandom_number_generator")[#text("pseudorandom generators")]#text(" – streams of bits which can “fool” fast probabilistic algorithms in the sense that they are indistinguishable from genuinely random bits, even if they actually have much lower ")#link("http://en.wikipedia.org/wiki/Information_entropy")[#text("entropy")]#text(". These generators are deterministic except for the choice of seed, but one can arrange the number of possible seeds to be polynomial rather than exponential (by requiring the length of the seed to be logarithmic). As such, one can then substitute the random bits in a probabilistic algorithm by the pseudorandom bits to ")#emph[#text("derandomise")]#text(" the algorithm into a deterministic one with comparable run-time.")

#text("[As pointed out in the comments, the use of pseudorandom number generators is of course used heavily in real-life computers, since modern (classical) computers usually do not have access to high-quality streams of genuine randomness. Also, I should mention (and Avi noted also) that the computational complexity notion of pseudorandomness has some relation to the additive combinatorial notion of pseudorandomness that I refer to sometimes in my own lectures; here one is fooling an algorithm or computable function rather than a linear or polynomial phase, but the idea is basically the same.]")

#text("Avi showed just one key step in the process, in which k random bits were converted into k+1 pseudorandom bits, for a logarithmically small value of k (which is how long one can arrange the seed to be). The idea is to add a new bit which is equal to the output of a computationally hard problem with the preceding k bits as input. If one can ensure that this problem is in fact computationally hard for average-case inputs (and not just worst-case inputs, which is what hypotheses such as ")#mi("P \\neq NP")#text(" provide), then this stream of bits cannot be easily distinguished from genuinely random bits. So one needs some ")#emph[#text("hardness amplification")]#text(" tricks to convert worst-case difficult problems to average-case difficult problems.")

#heading(level: 1)[#text("— The power of randomness in other settings —")]

#text("Avi then turned to some other advantages of randomness in algorithms, beyond that of saving time. Another is that of saving memory, which he illustrated with the classical maze exploration problem. Suppose one wanted to get from one vertex in a connected n-vertex graph (representing the maze) to another. If one is allowed to map out the graph, it is easy to achieve this deterministically in polynomial time using a polynomial amount of memory. But what if one has essentially no memory capacity (other than to remember which vertex is the destination vertex)? Then one can still reach the desired vertex in polynomial time (")#mi("O(n^2)")#text(", in fact) with high probability by an utterly simple random algorithm, namely a ")#link("http://en.wikipedia.org/wiki/Random_walk")[#text("random walk")]#text(" on the graph.")

#text("Two other famous, and striking, applications of randomness lie in interactive proof systems, in which a verifier is trying to check a claim that a prover can prove a given statement S (e.g. the Riemann hypothesis). More formally, the verifier employs some algorithm V that takes S as input, performs some queries to the prover, and then returns a boolean output. A deterministic verifier should satisfy the following two properties:")

#enum(start: 1, 
[#link("http://en.wikipedia.org/wiki/Random_walk")[#text("Completeness")]#text(". If the prover does indeed have a proof of S, then V should return “true”.")],
[#link("http://en.wikipedia.org/wiki/Soundness")[#text("Soundness")]#text(". If the prover does not have a proof of S, then V should return “false”.")]
)

#text("A probabilistic verifier is defined similarly, except that if the prover does not have a proof of S, we only expect V to return “false” with probability at least 99% (say).")

#text("Constructing a verifier with these properties is not too difficult: the prover can simply hand over the entire proof to the verifier when asked, and the verifier can then check all the steps of the proof. Of course, if the proof has length n, then this procedure will take time O(n). But a remarkable fact is that a probabilistic verifier only needs to see a very tiny portion of the proof to verify it!")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/PCP_theorem")[#strong[#text("PCP theorem")]]#text(". Every proof of a statement S of length n in a formal system can be converted (in polynomial time) into a proof which can be verified by a probabilistic verifier in O(log n) time using only O(1) queries to the prover.")
]

#text("In a rather different direction, instead of addressing the verifier’s desire to verify a proof as quickly as possible, one can consider the prover’s problem of wanting to have his or her claim of proving S verified without allowing the verifier to learn enough of the proof to publish it first. Another remarkable fact is that this is, in fact, possible (conditioning on a complexity hypothesis):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Zero-knowledge_proof")[#strong[#text("Existence of zero-knowledge proofs")]]#text(". Suppose factoring is hard. There exists a polynomial time probabilistic verifier for proofs of a statement S of length n which is ")#emph[#text("zero-knowledge")]#text(" in the sense that even in the absence of the prover (or of the proof), the verifier can simulate the distribution of answers that the prover would supply to the verifier’s queries (given at least one proof in hand, of course); more informally, the verification algorithm does not tell the verifier anything that the verifier did not already know, other than that the statement S is provable.")
]

#text("This statement is rather unintuitive to comprehend, let alone accept, at first, but Avi then explained the basic idea using a graph colouring model.")

#heading(level: 1)[#text("— 3-colouring and zero-knowledge proofs —")]

#text("The question of determining whether a given graph G with n edges is ")#link("http://en.wikipedia.org/wiki/Graph_coloring")[#text("3-colourable")]#text(" is known to be NP-complete (and thus just as hard as theorem proving). Because of this (and a little bit of extra work), it is possible to reduce matters to considering the problem of verifying a very specific type of claim: that a given graph G (which is known to both the verifier and prover) admits a 3-colouring.")

#text("Suppose that the prover has in fact managed to 3-colour the graph G (using, say, the colours red, green, and blue), and wants to convince the verifier of this fact, without letting the verifier learn anything about how to colour this graph himself or herself, or indeed to learn anything at all other than the fact that G is 3-colourable.")

#text("This can be done probabilistically by exploiting a simple symmetry in the space of all 3-colourings of G, namely the ability to permute the colours around and convert any given 3-colouring into one of 3! = 6 colourings. We use this to create the following verification algorithm:")

#enum(start: 1, 
[#text("The prover picks a 3-colouring of the graph using red, green, and blue, permuting the colours randomly if desired. The prover then ")#emph[#text("commits")]#text(" to this colouring; if this were done physically, the prover could place the colour of each vertex in an envelope atop that vertex. To do it digitally, one needs a cryptographic ")#link("http://en.wikipedia.org/wiki/Commitment_scheme")[#text("commitment scheme")]#text(", which can be set up provided that factoring is hard (other complexity assumptions can be substituted here).")],
[#text("The verifier then picks two adjacent vertices of the graph arbitrarily, and asks the prover to reveal the colours of the two selected vertices. If the two colours agree (or if a colour other than red, green, or blue appears), then the algorithm returns “false”.")],
[#text("Otherwise, return to Step 1 and start over. If the algorithm does not return false in (say) ")#mi("n^2")#text(" iterations of this process, return “true”.")]
)

#text("Note that if the prover does not in fact know of any 3-colouring of G, then the verifier will be able to detect this fact with probability at least 1/n in any round of the above procedure, since by picking an edge at random one has at least a 1/n probability of picking an edge for which the prover’s colouring fails to be a 3-colouring. So the algorithm is probabilistically sound. It is also obviously complete. So why is it zero knowledge? Because if the prover randomly shuffles the colours at each round, independently of all previous rounds, then for any given round, the two colours that the verifier gets to see are distributed completely at random among all six ordered pairs of distinct colours. This is a distribution of query responses that the verifier could have generated himself or herself, and so (provided that the prover really does have a colouring) this algorithm is not providing any new information that the verifier did not already have.")

#text("[")#emph[#text("Update")]#text(", Jan 10: typos corrected, comments added.]")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of otto")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23746")[#strong[#text("otto")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2008")])]

#text("Terry, it seems that Belief 2 would be formalized as P \\neq BPP.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87dc3d3277d5e4ab14817697984631540cd905a8ecb030bbc33be406ac686b88-7b7acb63482ef391c1a0aa5d5016ce427bbc46dd8613fae7921772986b32a225.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23756")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2008")])]

#text("Hi Terry, thanks for posting your interpretations of lectures/seminars. They are a model of clarity.")

#text("A small typo : it should read Agrawal, Kay")#emph[#text("al")]#text(", and Sax")#emph[#text("ena")]#text(". Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of roland")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23761")[#strong[#text("roland")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2008")])]

#text("SAT does not need exponential space. The possible assignments of a SAT instance can be tested one after the other reusing space. BBP=P if there is a language in E (exponantial time, linear exponent) that can’t be solved in subexponential time even with some subexponential advice ( the deciding machine processes the word and the advice which depends on the length of the word.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23765")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2008")])]

#text("The verifier given by the PCP Theorem will require O(log n) random bits. Simply to read those bits, it will need O(log n) time, not O(1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dbb388caee534c33f914b537280eb600bbe6bf21d396ce07e221e1b561073b-05efbf875afb17d0655237cf1a1b3f84cfccf6f11ed708175023bd13d505cce8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23772")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2008")])]

#text("Maybe you pointed out this out somewhere and I missed it: it seems worth reminding the reader that the idea of using a computationally subtle function to produce bits to then hand off to a randomized algorithm is, indeed, exactly how randomized algorithms are run on computers in practice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23779")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2008")])]

#text("Thanks for the corrections and suggestions!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("I didn’t realize it was considered surprising that beliefs 1 and 2 can’t be simultaneously true. I thought most theorists (certainly anyone who does cryptography) believes P=BPP because otherwise there would be no pseudo-random generators in NP.")

#text("Russell Impagliazzo has an interesting essay about different levels at which P=NP could be true or false. A summary and link is here:")

#link("http://weblog.fortnow.com/2004/06/impagliazzos-five-worlds.html")[#text("http://weblog.fortnow.com/2004/06/impagliazzos-five-worlds.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23883")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("Question about PCP theorem: suppose it turns out that the first occurrence of the ten-digit sequence 0123456789 in the decimal expansion of pi starts at the 37 trillionth digit. We could write the statement S:")

#text("statement S: FIRST_PI(‘0123456789’) = N (where N = 37 trillion)")

#text("Obviously we can confirm S in poly(N) time by computing all those digits.")

#text("Does the PCP theorem really say that if we do enough work, we should be able to convince another person of S in O(log N) steps by answering O(1) queries that they send us?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series II: Avi Wigderson, “Expander graphs - constructions and applications” « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23915")[#strong[#text("Distinguished Lecture Series II: Avi Wigderson, “Expander graphs - constructions and applications” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("[…] with his second lecture “Expander Graphs – Constructions and Applications“. As in the previous lecture, he spent some additional time after the talk on an “encore”, which in this case was […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("Dear Anonymous 1,")

#text("I think Avi’s point was that based purely on empirical evidence of one can actually do in polynomial time, it would seem that both ")#mi("P \\neq NP")#text(" and ")#mi("P \\neq BPP")#text(", but once one sees the connection between hardness and pseudorandom number generation one would be led instead to the presumably more correct position that ")#mi("P \\neq NP")#text(" and ")#mi("P = BPP")#text(".")

#text("Dear Anonymous 2,")

#text("I am not an expert in PCP (apart from a conversation this morning with Avi), but I believe the answer is yes, that after computing N digits of pi and then doing poly(N) more work to encode that computation in a suitable format, that the resulting encoded computation can be verified probabilistically using only O(1) inspections of that code and O(log N) work.")

#text("An analogy would be with locally testable (and locally decodable) codes. There are error-correcting codes in which one can take an N-bit string and verify quickly (just by looking at O(1) of the bits) whether this string is indeed close to a codeword. In particular, those O(1) queries can be used as a “proof” that the prover possesses a codeword. If I understand correctly, the original proofs of the PCP theorem proceeded by showing that the assertion that one possesses a proof of a statement S can be converted (roughly speaking) after a polynomial amount of work into an assertion that one possesses a codeword of a certain locally testable error-correcting code. (There is a later and simpler proof of Dinur which proceeds in a slightly different manner, combining error correcting codes with expander graphs in a clever way.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-23934")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("Thanks. This theorem sounds amazing and I’m going to have to try to learn something about it. (Note: anonymouses 1 and 2 and 3 (me) are all the same person).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/932ed592f893eef3bc636a8f4beb1296a0e591646747b9b56c21c30da01c6440-328e45c09d3dd1e43bcff04745a90e7031cd3f2c8e9e5a53a55855f03a975551.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Richter")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-24095")[#strong[#text("Johan Richter")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("There is an explanation of the PCP theorem and its proof in volume 44, number 1 of the Bulletin of the AMS. ")#link("http://www.ams.org/bull/2007-44-01/S0273-0979-06-01143-8/S0273-0979-06-01143-8.pdf")[#text("http://www.ams.org/bull/2007-44-01/S0273-0979-06-01143-8/S0273-0979-06-01143-8.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-24401")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("i was wondering about the suggestive statement ‘creativity cannot be automated’ in the context of quantum computation, for example theorem proving. i have heard a characterization of modern computers as built largely on newtonian principles and hence capable of solving problems of newtonian complexity: iterative ode/pde etc. but quantum computers built on quantum principles can process information at the quantum level, hence solve schroedinger eqn at the atomic level across an entire material or simultaneously calculate on all numbers etc.")

#text("it doesnt seem implausible that a quantum computer might be able to do theorem proving and exhibit ‘creativity’ in the sense of this blog entry, does this have any philosophical or scientific implications? for instance, if a quantum computer can do theorem proving, then should we not consider theorem proving essentially ‘creative’?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-24418")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("Dear Anonymous,")

#text("It is currently not known whether quantum computers are powerful enough to solve NP-complete problems in polynomial time. (I believe the name for this assertion is ")#mi("NP \\subset BQP")#text(".) Quantum computing has some aspects of parallelism but it is not as strong as a massively parallel classical computer, due to the sharply limited number of operations one is permitted to perform on a superposition of states.")

#text("This article by Scott Aaronson (who, incidentally, states the above point in the very title of his blog) has more discussion on this topic:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/")[#text("Why are solitons stable?")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of P=NP, relativisation, and multiple choice exams « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-40780")[#strong[#text("P=NP, relativisation, and multiple choice exams « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2009")])]

#text("[…] of time, but are difficult to distinguish from genuinely random strings by any quick tests. See my writeup of this lecture by Avi Wigderson for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adf8700e5c4f52823968b37a867f75f2955d2a03d4818c391dadf1fe78d690b1-dfddcdbecc34c502ef5c2fe3488112668683c88509b66e7b4c2906d5249b2669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PneqBPP")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-480344")[#strong[#text("PneqBPP")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("‘Morally, one now expects that if P \\neq NP, then P = BPP’. This statement cannot be right since contrapositive is false.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-480371")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("The equivalence of a statement with its contrapositive is always valid when working with deductive logic, but is not always accurate when working with non-deductive forms of reasoning, such as inductive logic. A classic example of this distinction arises in the raven paradox: ")#link("https://en.wikipedia.org/wiki/Raven_paradox")[#text("https://en.wikipedia.org/wiki/Raven_paradox")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-506702")[#strong[#text("IdeaGraph’s POCO vis-a-vis Blockchain’s POW – Crypto 3.0 – IdeaGraph")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2018")]

#text("[…] source: https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/#comment-682846")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2024")])]

#text("An ")#mi("\\mathrm{O}(n\\mathrm{log}(n))")#text(" multitape machine exists to multiply two ")#mi("n")#text("-bit integers.Every circuit multiplying two ")#mi("n")#text("-bit integers must have size ")#mi("\\Omega(n\\mathrm{log}(n))")#text(" unless some conjecture is false.")
]
