// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/
// Converted to Typst by tao2typ: "2026-10-14T16:35:56.337836+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The “no self-defeating object” argument", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The “no self-defeating object” argument")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 November 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A fundamental tool in any mathematician’s toolkit is that of ")#link("http://en.wikipedia.org/wiki/Reductio_ad_absurdum")[#text("reductio ad absurdum")]#text(": showing that a statement ")#mi("{X}")#text(" is false by assuming first that ")#mi("{X}")#text(" is true, and showing that this leads to a logical contradiction. A particulary pure example of ")#emph[#text("reductio ad absurdum")]#text(" occurs when establishing the non-existence of a hypothetically overpowered object or structure ")#mi("{X}")#text(", by showing that ")#mi("{X}")#text("‘s powers are “self-defeating”: the very existence of ")#mi("{X}")#text(" and its powers can be used (by some clever trick) to construct a counterexample to that power. Perhaps the most well-known example of a self-defeating object comes from the ")#link("http://en.wikipedia.org/wiki/Omnipotence_paradox")[#text("omnipotence paradox")]#text(" in philosophy (“Can an omnipotent being create a rock so heavy that He cannot lift it?”); more generally, a large number of other paradoxes in logic or philosophy can be reinterpreted as a proof that a certain overpowered object or structure does not exist.")

#text("In mathematics, perhaps the first example of a self-defeating object one encounters is that of a largest natural number:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (No largest natural number)")]#text(" ")#metadata(none) <tao-7936560c828789f93666>#text(" There does not exist a natural number ")#mi("{N}")#text(" which is larger than all other natural numbers.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that there was such a largest natural number ")#mi("{N}")#text(". Then ")#mi("{N+1}")#text(" is also a natural number which is strictly larger than ")#mi("{N}")#text(", contradicting the hypothesis that ")#mi("{N}")#text(" is the largest natural number. ")#mi("\\Box")

#text("Note the argument does not apply to the ")#emph[#text("extended natural number system")]#text(" in which one adjoins an additional object ")#mi("{\\infty}")#text(" beyond the natural numbers, because ")#mi("{\\infty+1}")#text(" is defined equal to ")#mi("{\\infty}")#text(". However, the above argument does show that the existence of a largest number is not compatible with the ")#link("http://en.wikipedia.org/wiki/Peano_axioms")[#text("Peano axioms")]#text(".")

#text("This argument, by the way, is perhaps the only mathematical argument I know of which is routinely taught to primary school children ")#emph[#text("by other primary school children")]#text(", thanks to the schoolyard game of naming the largest number. It is arguably one’s first exposure to a mathematical ")#emph[#text("non-existence result")]#text(", which seems innocuous at first but can be surprisingly deep, as such results preclude in advance all future attempts to establish existence of that object, no matter how much effort or ingenuity is poured into this task. One sees this in a typical instance of the above schoolyard game; one player tries furiously to cleverly construct some impressively huge number ")#mi("{N}")#text(", but no matter how much effort is expended in doing so, the player is defeated by the simple response “… plus one!” (unless, of course, ")#mi("{N}")#text(" is infinite, ill-defined, or otherwise not a natural number).")

#text("It is not only individual objects (such as natural numbers) which can be self-defeating; structures (such as orderings or enumerations) can also be self-defeating. (In modern set theory, one considers structures to themselves be a kind of object, and so the distinction between the two concepts is often blurred.) Here is one example (related to, but subtly different from, the previous one):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (The natural numbers cannot be finitely enumerated)")]#text(" ")#metadata(none) <tao-f46368ba70d2e10e3ac2>#text(" The natural numbers ")#mi("{{\\Bbb N} = \\{0,1,2,3,\\ldots\\}}")#text(" cannot be written as ")#mi("{\\{ a_1,\\ldots,a_n\\}}")#text(" for any finite collection ")#mi("{a_1,\\ldots,a_n}")#text(" of natural numbers.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that such an enumeration ")#mi("{{\\Bbb N} = \\{a_1,\\ldots,a_n\\}}")#text(" existed. Then consider the number ")#mi("{a_1+\\ldots+a_n+1}")#text("; this is a natural number, but is larger than (and hence not equal to) any of the natural numbers ")#mi("{a_1,\\ldots,a_n}")#text(", contradicting the hypothesis that ")#mi("{{\\Bbb N}}")#text(" is enumerated by ")#mi("{a_1,\\ldots,a_n}")#text(". ")#mi("\\Box")

#text("Here it is the ")#emph[#text("enumeration")]#text(" which is self-defeating, rather than any individual natural number such as ")#mi("{a_1}")#text(" or ")#mi("{a_n}")#text(". (For this post, we allow enumerations to contain repetitions.)")

#text("The above argument may seem trivial, but a slight modification of it already gives an important result, namely ")#link("http://en.wikipedia.org/wiki/Euclid%27s_theorem")[#text("Euclid’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (The primes cannot be finitely enumerated)")]#text(" ")#metadata(none) <tao-d54f5fedac0862695c43>#text(" The prime numbers ")#mi("{{\\mathcal P} = \\{2,3,5,7,\\ldots\\}}")#text(" cannot be written as ")#mi("{\\{p_1,\\ldots,p_n\\}}")#text(" for any finite collection of prime numbers.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that such an enumeration ")#mi("{{\\mathcal P} = \\{p_1,\\ldots,p_n\\}}")#text(" existed. Then consider the natural number ")#mi("{p_1 \\times \\ldots \\times p_n + 1}")#text("; this is a natural number larger than ")#mi("{1}")#text(" which is not divisible by any of the primes ")#mi("{p_1,\\ldots,p_n}")#text(". But, by the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(" (or by the method of ")#link("http://en.wikipedia.org/wiki/Infinite_descent")[#text("Infinite descent")]#text(", which is another classic application of ")#emph[#text("reductio ad absurdum")]#text("), every natural number larger than ")#mi("{1}")#text(" must be divisible by some prime, contradicting the hypothesis that ")#mi("{{\\mathcal P}}")#text(" is enumerated by ")#mi("{p_1,\\ldots,p_n}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Continuing the number-theoretic theme, the “dueling conspiracies” arguments in a ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("previous blog post")]#text(" can also be viewed as an instance of this type of “no-self-defeating-object”; for instance, a zero of the Riemann zeta function at ")#mi("{1+it}")#text(" implies that the primes anti-correlate almost completely with the multiplicative function ")#mi("{n^{it}}")#text(", which is self-defeating because it also implies complete anti-correlation with ")#mi("{n^{-it}}")#text(", and the two are incompatible. Thus we see that the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" (a much stronger version of Proposition ")#link(<tao-d54f5fedac0862695c43>)[#text("3")]#text(") also emerges from this type of argument.")
]

#text("In this post I would like to collect several other well-known examples of this type of “no self-defeating object” argument. Each of these is well studied, and probably quite familiar to many of you, but I feel that by collecting them all in one place, the commonality of theme between these arguments becomes more apparent. (For instance, as we shall see, many well-known “paradoxes” in logic and philosophy can be interpreted mathematically as a rigorous “no self-defeating object” argument.)")

#metadata(none) <tao-11653275ccd6035c3b2e>

#heading(level: 1)[#strong[#text(" — 1. Set theory — ")]]

#text("Many famous foundational results in set theory come from a “no self-defeating object” argument. (Here, we shall be implicitly be using a standard axiomatic framework for set theory, such as ")#link("http://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory")[#text("Zermelo-Frankel set theory")]#text("; the situation becomes different for other set theories, much as results such as Proposition ")#link(<tao-7936560c828789f93666>)[#text("1")]#text(" changes if one uses other number systems such as the extended natural numbers.) The basic idea here is that any sufficiently overpowered set-theoretic object is capable of encoding a version of the ")#link("http://en.wikipedia.org/wiki/Liar_paradox")[#text("liar paradox")]#text(" (“this sentence is false”, or more generally a statement which can be shown to be logically equivalent to its negation) and thus lead to a contradiction. Consider for instance this variant of ")#link("http://en.wikipedia.org/wiki/Russell%27s_paradox")[#text("Russell’s paradox")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (No universal set)")]#text(" ")#metadata(none) <tao-60dc2d5aede9c753d57d>#text(" There does not exist a set which contains all sets (including itself).")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that there existed a universal set ")#mi("{X}")#text(" which contained all sets. Using the ")#link("http://en.wikipedia.org/wiki/Axiom_schema_of_specification")[#text("axiom schema of specification")]#text(", one can then construct the set")

#align(center)[#tao-fit-display[#mitex("Y := \\{ A \\in X: A \\not \\in A\\}")]]

#text("of all sets in the universe which did not contain themselves. As ")#mi("{X}")#text(" is universal, ")#mi("{Y}")#text(" is contained in ")#mi("{X}")#text(". But then, by definition of ")#mi("{Y}")#text(", one sees that ")#mi("{Y \\in Y}")#text(" if and only if ")#mi("{Y \\not \\in Y}")#text(", a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" As a corollary, there also does not exist any set ")#mi("{Z}")#text(" which contains all ")#emph[#text("other")]#text(" sets (not including itself), because the set ")#mi("{X := Z \\cup \\{Z\\}}")#text(" would then be universal.")
]

#text("One can “localise” the above argument to a smaller domain than the entire universe, leading to the important")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Cantor’s theorem)")]#text(" ")#metadata(none) <tao-9c29aa77c9a9a49639f9>#text(" Let ")#mi("{X}")#text(" be a set. Then the power set ")#mi("{2^X := \\{ A: A \\subset X \\}}")#text(" of ")#mi("{X}")#text(" cannot be enumerated by ")#mi("{X}")#text(", i.e. one cannot write ")#mi("{2^X := \\{ A_x: x \\in X \\}}")#text(" for some collection ")#mi("{(A_x)_{x \\in X}}")#text(" of subsets of ")#mi("{X}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that there existed a set ")#mi("{X}")#text(" whose power set ")#mi("{2^X}")#text(" could be enumerated as ")#mi("{\\{ A_x: x \\in X \\}}")#text(" for some ")#mi("{(A_x)_{x \\in X}}")#text(". Using the axiom schema of specification, one can then construct the set")

#align(center)[#tao-fit-display[#mitex("Y := \\{ x \\in X: x \\not \\in A_x \\}.")]]

#text("The set ")#mi("{Y}")#text(" is an element of the power set ")#mi("{2^X}")#text(". As ")#mi("{2^X}")#text(" is enumerated by ")#mi("{\\{ A_x: x \\in X \\}}")#text(", we have ")#mi("{Y = A_y}")#text(" for some ")#mi("{y \\in X}")#text(". But then by the definition of ")#mi("{Y}")#text(", one sees that ")#mi("{y \\in A_y}")#text(" if and only if ")#mi("{y \\not \\in A_y}")#text(", a contradiction. ")#mi("\\Box")

#text("As is well-known, one can adapt Cantor’s argument to the real line, showing that the reals are uncountable:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (The real numbers cannot be countably enumerated)")]#text(" ")#metadata(none) <tao-a997312b0db160903758>#text(" The real numbers ")#mi("{{\\bf R}}")#text(" cannot be written as ")#mi("{\\{ x_n: n \\in {\\bf N} \\}}")#text(" for any countable collection ")#mi("{x_1,x_2,\\ldots}")#text(" of real numbers.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that there existed a countable enumeration of ")#mi("{{\\bf R}}")#text(" by a sequence ")#mi("{x_1,x_2,\\ldots}")#text(" of real numbers. Consider the decimal expansion of each of these numbers. Note that, due to the well-known “")#mi("{0.999\\ldots=1.000\\ldots}")#text("” issue, the decimal expansion may be non-unique, but each real number ")#mi("{x_n}")#text(" has at most two decimal expansions. For each ")#mi("{n}")#text(", let ")#mi("{a_n \\in \\{0,1,\\ldots,9\\}}")#text(" be a digit which is not equal to the ")#mi("{n^{th}}")#text(" digit of any of the decimal expansions of ")#mi("{x_n}")#text("; this is always possible because there are ten digits to choose from and at most two decimal expansions of ")#mi("{x_n}")#text(". (One can avoid any implicit invocation of the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(" here by setting ")#mi("{a_n}")#text(" to be (say) the ")#emph[#text("least")]#text(" digit which is not equal to the ")#mi("{n^{th}}")#text(" digit of any of the decimal expansions of ")#mi("{x_n}")#text(".) Then the real number given by the decimal expansion ")#mi("{0.a_1a_2a_3\\ldots}")#text(" differs in the ")#mi("{n^{th}}")#text(" digit from any of the decimal expansions of ")#mi("{x_n}")#text(" for each ")#mi("{n}")#text(", and so is distinct from every ")#mi("{x_n}")#text(", a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" One can of course deduce Proposition ")#link(<tao-a997312b0db160903758>)[#text("6")]#text(" directly from Proposition ")#link(<tao-9c29aa77c9a9a49639f9>)[#text("5")]#text(", by using the decimal representation to embed ")#mi("{2^{\\bf N}}")#text(" into ")#mi("{{\\bf R}}")#text(". But notice how the two arguments have a slightly different (though closely related) basis; the former argument proceeds by encoding the liar paradox, while the second proceeds by exploiting Cantor’s diagonal argument. The two perspectives are indeed a little different: for instance, Cantor’s diagonal argument can also be modified to establish the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzela-Ascolí theorem")]#text(", whereas I do not see any obvious way to prove that theorem by encoding the liar paradox.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" It is an interesting psychological phenomenon that Proposition ")#link(<tao-a997312b0db160903758>)[#text("6")]#text(" is often considered far more unintuitive than any of the other propositions here, despite being in the same family of arguments; most people have no objection to the fact that every effort to finitely enumerate the natural numbers, for instance, is doomed to failure, but for some reason it is much harder to let go of the belief that, at some point, some sufficiently ingenious person will work out a way to countably enumerate the real numbers. I am not exactly sure why this disparity exists, but I suspect it is at least partly due to the fact that the rigorous construction of the real numbers is quite sophisticated and often not presented properly until the advanced undergraduate level. (Or perhaps it is because we do not play the game “enumerate the real numbers” often enough in schoolyards.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can also use the diagonal argument to show that any reasonable notion of a “constructible real number” must itself be non-constructive (this is related to the ")#link("http://en.wikipedia.org/wiki/Interesting_number_paradox")[#text("interesting number paradox")]#text("). Part of the problem is that the question of determining whether a proposed construction of a real number is actually well-defined is a variant of the ")#link("http://en.wikipedia.org/wiki/Halting_problem")[#text("halting problem")]#text(", which we will discuss below.")
]

#text("While a genuinely universal set is not possible in standard set theory, one at least has the notion of an ")#link("http://en.wikipedia.org/wiki/Ordinal_number")[#text("ordinal")]#text(", which contains all the ordinals less than it. (In the discussion below, we assume familiarity with the theory of ordinals.) One can modify the above arguments concerning sets to give analogous results about the ordinals. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Ordinals do not form a set)")]#text(" There does not exist a set that contains all the ordinals.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that such a set existed. By the axiom schema of specification, one can then find a set ")#mi("{\\Omega}")#text(" which consists precisely of all the ordinals and nothing else. But then ")#mi("{\\Omega \\cup \\{\\Omega\\}}")#text(" is an ordinal which is not contained in ")#mi("{\\Omega}")#text(" (by the ")#link("http://en.wikipedia.org/wiki/Axiom_of_regularity")[#text("axiom of foundation")]#text(", also known as the ")#emph[#text("axiom of regularity")]#text("), a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" This proposition(together with the theory of ordinals) can be used to give a quick proof of ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(": see ")#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/")[#text("these lecture notes of mine")]#text(" for further discussion. Notice the similarity between this argument and the proof of Proposition ")#link(<tao-7936560c828789f93666>)[#text("1")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" Once one has Zorn’s lemma, one can show that various other classes of mathematical objects do not form sets. Consider for instance the class of all vector spaces. Observe that any chain of (real) vector spaces (ordered by inclusion) has an upper bound (namely the union or limit of these spaces); thus, if the class of all vector spaces was a set, then Zorn’s lemma would imply the existence of a maximal vector space ")#mi("{V}")#text(". But one can simply adjoin an additional element not already in ")#mi("{V}")#text(" (e.g. ")#mi("{\\{V\\}}")#text(") to ")#mi("{V}")#text(", and contradict this maximality. (An alternate proof: every object is an element of some vector space, and in particular every set is an element of some vector space. If the class of all vector spaces formed a set, then by the ")#link("http://en.wikipedia.org/wiki/Axiom_of_union")[#text("axiom of union")]#text(", we see that union of all vector spaces is a set also, contradicting Proposition ")#link(<tao-60dc2d5aede9c753d57d>)[#text("4")]#text(".)")
]

#text("One can localise the above argument to smaller cardinalities, for instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8 (Countable ordinals are uncountable)")]#text(" There does not exist a countable enumeration ")#mi("{\\omega_1, \\omega_2, \\ldots}")#text(" of the countable ordinals. (Here we consider finite sets and countably infinite sets to both be countable.)")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that there exists a countable enumeration ")#mi("{\\omega_1, \\omega_2, \\ldots}")#text(" of the countable ordinals. Then the set ")#mi("{\\Omega := \\bigcup_n \\omega_n}")#text(" is also a countable ordinal, as is the set ")#mi("{\\Omega \\cup \\{\\Omega \\}}")#text(". But ")#mi("{\\Omega \\cup \\{\\Omega \\}}")#text(" is not equal to any of the ")#mi("{\\omega_n}")#text(" (by the axiom of foundation), a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" One can show the existence of uncountable ordinals (e.g. by considering all the well-orderings of subsets of the natural numbers, up to isomorphism), and then there exists a least uncountable ordinal ")#mi("{\\Omega}")#text(". By construction, this ordinal consists precisely of all the countable ordinals, but is itself uncountable, much as ")#mi("{{\\bf N}}")#text(" consists precisely of all the finite natural numbers, but is itself infinite (Proposition ")#link(<tao-f46368ba70d2e10e3ac2>)[#text("2")]#text("). The least uncountable ordinal is notorious, among other things, for providing a host of counterexamples to various intuitively plausible assertions in point set topology, and in particular in showing that the topology of sufficiently uncountable spaces cannot always be adequately explored by countable objects such as sequences.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" The existence of the least uncountable ordinal can explain why one cannot contradict Cantor’s theorem on the uncountability of the reals simply by iterating the diagonal argument (or any other algorithm) in an attempt to “exhaust” the reals. From ")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("transfinite induction")]#text(" we see that the diagonal argument allows one to assign a different real number to each countable ordinal, but this does not establish countability of the reals, because the set of all countable ordinals is itself uncountable. (This is similar to how one cannot contradict Proposition ")#link(<tao-60dc2d5aede9c753d57d>)[#text("4")]#text(" by iterating the ")#mi("{N \\rightarrow N+1}")#text(" map, as the set of all finite natural numbers is itself infinite.) In any event, even once one reaches the first uncountable ordinal, one may not yet have completely exhausted the reals; for instance, using the diagonal argument given in the proof of Proposition ")#link(<tao-a997312b0db160903758>)[#text("6")]#text(", only the real numbers in the interval ")#mi("{[0,1]}")#text(" will ever be enumerated by this procedure. (Also, the question of whether ")#emph[#text("all")]#text(" real numbers in ")#mi("{[0,1]}")#text(" can be enumerated by the iterated diagonal algorithm requires the ")#link("http://en.wikipedia.org/wiki/Continuum_hypothesis")[#text("continuum hypothesis")]#text(", and even with this hypothesis I am not sure whether the statement is decidable.)")
]

#heading(level: 1)[#strong[#text(" — 2. Logic — ")]]

#text("The “no self-defeating object” argument leads to a number of important non-existence results in logic. Again, the basic idea is to show that a sufficiently overpowered logical structure will eventually lead to the existence of a self-contradictory statement, such as the liar paradox. To state examples of this properly, one unfortunately has to invest a fair amount of time in first carefully setting up the language and theory of logic. I will not do so here, and instead use informal English sentences as a proxy for precise logical statements to convey a taste (but not a completely rigorous description) of these logical results here.")

#text("The liar paradox itself – the inability to assign a consistent truth value to “this sentence is false” – can be viewed as an argument demonstrating that there is no consistent way to interpret (i.e. assign a truth value to) sentences, when the sentences are (a) allowed to be self-referential, and (b) allowed to invoke the very notion of truth given by this interpretation. One’s first impulse is to say that the difficulty here lies more with (a) than with (b), but there is a clever trick, known as ")#link("http://en.wikipedia.org/wiki/Quining")[#text("Quining")]#text(" (or ")#emph[#text("indirect self-reference")]#text("), which allows one to modify the liar paradox to produce a non-self-referential statement to which one still cannot assign a consistent truth value. The idea is to work not with fully formed sentences ")#mi("{S}")#text(", which have a single truth value, but instead with ")#link("http://en.wikipedia.org/wiki/Predicate_%28mathematical_logic%29")[#text("predicates")]#text(" ")#mi("{S}")#text(", whose truth value depends on a variable ")#mi("{x}")#text(" in some range. For instance, ")#mi("{S}")#text(" may be “")#mi("{x}")#text(" is two characters long.”, and the range of ")#mi("{x}")#text(" may be the set of strings (i.e. finite sequences of characters); then for every string ")#mi("{T}")#text(", the statement ")#mi("{S(T)}")#text(" (formed by replacing every appearance of ")#mi("{x}")#text(" in ")#mi("{S}")#text(" with ")#mi("{T}")#text(") is either true or false. For instance, ")#mi("{S(``ab^{\\prime\\prime})}")#text(" is true, but ")#mi("{S(``abc^{\\prime\\prime})}")#text(" is false. Crucially, predicates are themselves strings, and can thus be fed into themselves as input; for instance, ")#mi("{S(S)}")#text(" is false. If however ")#mi("{U}")#text(" is the predicate “")#mi("{x}")#text(" is sixty-five characters long.”, observe that ")#mi("{U(U)}")#text(" is true.")

#text("Now consider the ")#emph[#text("Quine predicate")]#text(" ")#mi("{Q}")#text(" given by")

#text("“")#mi("{x}")#text(" is a predicate whose range is the set of strings, and ")#mi("{x(x)}")#text(" is false.”")

#text("whose range is the set of strings. Thus, for any string ")#mi("{T}")#text(", ")#mi("{Q(T)}")#text(" is the sentence")

#text("“")#mi("{T}")#text(" is a predicate whose range is the set of strings, and ")#mi("{T(T)}")#text(" is false.”")

#text("This predicate is defined non-recursively, but the sentence ")#mi("{Q(Q)}")#text(" captures the essence of the liar paradox: it is true if and only if it is false. This shows that there is no consistent way to interpret sentences in which the sentences are allowed to come from predicates, are allowed to use the concept of a string, and also allowed to use the concept of truth as given by that interpretation.")

#text("Note that the proof of Proposition ")#link(<tao-60dc2d5aede9c753d57d>)[#text("4")]#text(" is basically the set-theoretic analogue of the above argument, with the connection being that one can identify a predicate ")#mi("{T(x)}")#text(" with the set ")#mi("{\\{x: T(x) \\text{ true} \\}}")#text(".")

#text("By making one small modification to the above argument – replacing the notion of truth with the related notion of provability – one obtains the celebrated ")#link("http://en.wikipedia.org/wiki/G%C3%B6del%27s_incompleteness_theorems")[#text("Gödel’s (second) incompleteness theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Gödel’s incompleteness theorem)")]#text(" (Informal statement) No consistent logical system which has the notion of a string, can provide a proof of its own logical consistency. (Note that a proof can be viewed as a certain type of string.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" Because one can encode strings in numerical form (e.g. using the ASCII code), it is also true (informally speaking) that no consistent logical system which has the notion of a natural number, can provide a proof of its own logical consistency.")
]

#emph[#text("Proof:")]#text(" (Informal sketch only) Suppose for contradiction that one had a consistent logical system inside of which its consistency could be proven. Now let ")#mi("{Q}")#text(" be the predicate given by")

#text("“")#mi("{x}")#text(" is a predicate whose range is the set of strings, and ")#mi("{x(x)}")#text(" is not provable”")

#text("and whose range is the set of strings. Define the ")#emph[#text("Gödel sentence")]#text(" ")#mi("{G}")#text(" to be the string ")#mi("{G := Q(Q)}")#text(". Then ")#mi("{G}")#text(" is logically equivalent to the assertion “")#mi("{G}")#text(" is not provable”. Thus, if ")#mi("{G}")#text(" were false, then ")#mi("{G}")#text(" would be provable, which (by the consistency of the system) implies that ")#mi("{G}")#text(" is true, a contradiction; thus, ")#mi("{G}")#text(" must be true. Because the system is provably consistent, the above argument can be placed inside the system itself, to ")#emph[#text("prove")]#text(" inside that system that ")#mi("{G}")#text(" must be true; thus ")#mi("{G}")#text(" is provable and ")#mi("{G}")#text(" is then false, a contradiction. (It becomes quite necessary to carefully distinguish the notions of truth and provability (both inside a system and externally to that system) in order to get this argument straight!) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" It is not hard to show that a consistent logical system which can model the standard natural numbers cannot ")#emph[#text("disprove")]#text(" its own consistency either (i.e. it cannot establish the statement that one can deduce a contradiction from the axioms in the systems in ")#mi("{n}")#text(" steps for some natural number ")#mi("{n}")#text("); thus the consistency of such a system is undecidable within that system. Thus this theorem strengthens the (more well known) first Gödel incompleteness theorem, which asserts the existence of undecidable statements inside a consistent logical system which contains the concept of a string (or a natural number). On the other hand, the incompleteness theorem does not preclude the possibility that the consistency of a weak theory could be proven in a strictly stronger theory (e.g. the consistency of Peano arithmetic is provable in Zermelo-Frankel set theory).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" One can use the incompleteness theorem to establish the undecidability of other overpowered problems. For instance, ")#link("http://en.wikipedia.org/wiki/Matiyasevich's_theorem")[#text("Matiyasevich’s theorem")]#text(" demonstrates that the problem of determining the solvability of a system of Diophantine equations is, in general, undecidable, because one can encode statements such as the consistency of set theory inside such a system.")
]

#heading(level: 1)[#strong[#text(" — 3. Computability — ")]]

#text("One can adapt these arguments in logic to analogous arguments in the theory of computation; the basic idea here is to show that a sufficiently overpowered computer program cannot exist, by feeding the source code for that program into the program itself (or some slight modification thereof) to create a contradiction. As with logic, a properly rigorous formalisation of the theory of computation would require a fair amount of preliminary machinery, for instance to define the concept of Turing machine (or some other universal computer), and so I will once again use informal English sentences as an informal substitute for a precise programming language.")

#text("A fundamental “no self-defeating object” argument in the subject, analogous to the other liar paradox type arguments encountered previously, is the ")#link("http://en.wikipedia.org/wiki/Halting_Theorem")[#text("Turing halting theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Turing halting theorem)")]#text(" There does not exist a program ")#mi("{P}")#text(" which takes a string ")#mi("{S}")#text(" as input, and determines in finite time whether ")#mi("{S}")#text(" is a program (with no input) that halts in finite time.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that such a program ")#mi("{P}")#text(" existed. Then one could easily modify ")#mi("{P}")#text(" to create a variant program ")#mi("{Q}")#text(", which takes a string ")#mi("{S}")#text(" as input, and halts if and only if ")#mi("{S}")#text(" is a program (with ")#mi("{S}")#text(" itself as input) that does not halts in finite time. Indeed, all ")#mi("{Q}")#text(" has to do is call ")#mi("{P}")#text(" with the string ")#mi("{S(S)}")#text(", defined as the program (with no input) formed by declaring ")#mi("{S}")#text(" to be the input string for the program ")#mi("{S}")#text(". If ")#mi("{P}")#text(" determines that ")#mi("{S(S)}")#text(" does not halt, then ")#mi("{Q}")#text(" halts; otherwise, if ")#mi("{P}")#text(" determines that ")#mi("{S(S)}")#text(" does halt, then ")#mi("{Q}")#text(" performs an infinite loop and does not halt. Then observe that ")#mi("{Q(Q)}")#text(" will halt if and only if it does not halt, a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" As one can imagine from the proofs, this result is closely related to, but not quite identical with, the Gödel incompleteness theorem. That latter theorem implies that the question of whether a given program halts or not in general is undecidable (consider a program designed to search for proofs of the inconsistency of set theory). By contrast, the halting theorem (roughly speaking) shows that this question is ")#emph[#text("uncomputable")]#text(" (i.e. there is no algorithm to decide halting in general) rather than ")#emph[#text("undecidable")]#text(" (i.e. there are programs whose halting can neither be proven nor disproven).")

#text("On the other hand, the halting theorem can be used to establish the incompleteness theorem. Indeed, suppose that all statements in a suitably strong and consistent logical system were either provable or disprovable. Then one could build a program that determined whether an input string ")#mi("{S}")#text(", when run as a program, halts in finite time, simply by searching for all proofs or disproofs of the statement “")#mi("{S}")#text(" halts in finite time”; this program is guaranteed to terminate with a correct answer by hypothesis.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" While it is not possible for the halting problem for a given computing language to be computable in that language, it is certainly possible that it is computable in a strictly stronger language. When that is the case, one can then invoke ")#link("http://en.wikipedia.org/wiki/Newcomb%27s_paradox")[#text("Newcomb’s paradox")]#text(" to argue that the weaker language does not have unlimited “free will” in some sense.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" In the language of ")#link("http://en.wikipedia.org/wiki/Recursion_theory")[#text("recursion theory")]#text(", the halting theorem asserts that the set of programs that do not halt is not a ")#link("http://en.wikipedia.org/wiki/Recursive_set")[#text("decidable set")]#text(" (or a ")#emph[#text("recursive set")]#text("). In fact, one can make the slightly stronger assertion that the set of programs that do not halt is not even a ")#link("http://en.wikipedia.org/wiki/Recursively_enumerable")[#text("semi-decidable set")]#text(" (or a ")#emph[#text("recursively enumerable set")]#text("), i.e. there is no algorithm which takes a program as input and halts in finite time if and only if the input program does not halt. This is because the complementary set of programs that do halt is clearly semi-decidable (one simply runs the program until it halts, running forever if it does not), and so if the set of programs that do not halt is also semi-decidable, then it is decidable (by running both algorithms in parallel; this observation is a special case of ")#link("http://en.wikipedia.org/wiki/Post's_theorem")[#text("Post’s theorem")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" One can use the halting theorem to exclude overly general theories for certain types of mathematical objects. For instance, one cannot hope to find an algorithm to determine the existence of smooth solutions to arbitrary nonlinear partial differential equations, because it is possible to simulate a Turing machine using the laws of classical physics, which in turn can be modeled using (a moderately complicated system of) nonlinear PDE. Instead, progress in nonlinear PDE has instead proceeded by focusing on much more specific classes of such PDE (e.g. elliptic PDE, parabolic PDE, hyperbolic PDE, gauge theories, etc.).")
]

#text("One can place the halting theorem in a more “quantitative” form. Call a function ")#mi("{f: {\\bf N} \\rightarrow {\\bf N}}")#text(" ")#emph[#text("computable")]#text(" if there exists a computer program which, when given a natural number ")#mi("{n}")#text(" as input, returns ")#mi("{f(n)}")#text(" as output in finite time. Define the ")#link("http://en.wikipedia.org/wiki/Busy_beaver_function")[#text("Busy Beaver function")]#text(" ")#mi("{BB: {\\bf N} \\rightarrow {\\bf N}}")#text(" by setting ")#mi("{BB(n)}")#text(" to equal the largest output of any program of at most ")#mi("{n}")#text(" characters in length (and taking no input), which halts in finite time. Note that there are only finitely many such programs for any given ")#mi("{n}")#text(", so ")#mi("{BB(n)}")#text(" is well-defined. On the other hand, it is uncomputable, even to upper bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11")]#text(" There does not exist a computable function ")#mi("{f}")#text(" such that one has ")#mi("{BB(n) \\leq f(n)}")#text(" for all ")#mi("{n}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that there existed a computable function ")#mi("{f(n)}")#text(" such that ")#mi("{BB(n) \\leq f(n)}")#text(" for all ")#mi("{n}")#text(". We can use this to contradict the halting theorem, as follows. First observe that once the Busy Beaver function can be upper bounded by a computable function, then for any ")#mi("{n}")#text(", the run time of any halting program of length at most ")#mi("{n}")#text(" can also be upper bounded by a computable function. This is because if a program of length ")#mi("{n}")#text(" halts in finite time, then a trivial modification of that program (of length larger than ")#mi("{n}")#text(", but by a computable factor) is capable of outputting the run time of that program (by keeping track of a suitable “clock” variable, for instance). Applying the upper bound for Busy Beaver to that increased length, one obtains the bound on run time.")

#text("Now, to determine whether a given program ")#mi("{S}")#text(" halts in finite time or not, one simply simulates (runs) that program for time up to the computable upper bound of the possible running time of ")#mi("{S}")#text(", given by the length of ")#mi("{S}")#text(". If the program has not halted by then, then it never will. This provides a program ")#mi("{P}")#text(" obeying the hypotheses of the halting theorem, a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" A variant of the argument shows that ")#mi("{BB(n)}")#text(" grows faster than any computable function: thus if ")#mi("{f}")#text(" is computable, then ")#mi("{BB(n) > f(n)}")#text(" for all sufficiently large ")#mi("{n}")#text(". We leave the proof of this result as an exercise to the reader.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" Sadly, the most important unsolved problem in complexity theory, namely the ")#link("http://en.wikipedia.org/wiki/P_%3D_NP_problem")[#mi("{P \\neq NP}")#text(" problem")]#text(", does not seem to be susceptible to the no-self-defeating-object argument, basically because such arguments tend to be ")#emph[#text("relativisable")]#text(" whereas the ")#mi("{P \\neq NP}")#text(" problem is not; see ")#link("https://terrytao.wordpress.com/2009/08/01/pnp-relativisation-and-multiple-choice-exams/")[#text("this earlier blog post")]#text(" for more discussion. On the other hand, one has the curious feature that many proposed ")#emph[#text("proofs")]#text(" that ")#mi("{P \\neq NP}")#text(" appear to be self-defeating; this is most strikingly captured in the celebrated work of Razborov and Rudich, who showed (very roughly speaking) that any sufficiently “natural” proof that ")#mi("{P \\neq NP}")#text(" could be used to disprove the existence of an object closely related to the belief that ")#mi("{P \\neq NP}")#text(", namely the existence of pseudorandom number generators. (I am told, though, that diagonalisation arguments can be used to prove some other inclusions or non-inclusions in complexity theory that are not subject to the relativisation barrier, though I do not know the details.)")
]

#heading(level: 1)[#strong[#text(" — 4. Game theory — ")]]

#text("Another basic example of the no-self-defeating-objects argument arises from game theory, namely the ")#link("http://en.wikipedia.org/wiki/Strategy-stealing_argument")[#text("strategy stealing argument")]#text(". Consider for instance a generalised version of naughts and crosses (tic-tac-toe), in which two players take turns placing naughts and crosses on some game board (not necessarily square, and not necessarily two-dimensional), with the naughts player going first, until a certain pattern of all naughts or all crosses is obtained as a subpattern, with the naughts player winning if the pattern is all naughts, and the crosses player winning if the pattern is all crosses. (If all positions are filled without either pattern occurring, the game is a draw.) We assume that the winning patterns for the cross player are exactly the same as the winning patterns for the naughts player (but with naughts replaced by crosses, of course).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" ")#metadata(none) <tao-a1d9890884c1b4b960c2>#text(" In any generalised version of naughts and crosses, there is no strategy for the second player (i.e. the crosses player) which is guaranteed to ensure victory.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that the second player had such a winning strategy ")#mi("{W}")#text(". The first player can then ")#emph[#text("steal")]#text(" that strategy by placing a naught arbitrarily on the board, and then pretending to be the second player and using ")#mi("{W}")#text(" accordingly. Note that occasionally, the ")#mi("{W}")#text(" strategy will compel the naughts player to place a naught on the square that he or she has already occupied, but in such cases the naughts player may simply place the naught somewhere else instead. (It is not possible that the naughts player would run out of places, thus forcing a draw, because this would imply that ")#mi("{W}")#text(" could lead to a draw as well, a contradiction.) If we denote this stolen strategy by ")#mi("{W^{\\prime}}")#text(", then ")#mi("{W^{\\prime}}")#text(" guarantees a win for the naughts player; playing the ")#mi("{W^{\\prime}}")#text(" strategy for the naughts player against the ")#mi("{W}")#text(" strategy for the crosses player, we obtain a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 19")]#text(" The key point here is that in naughts and crosses games, it is possible to play a ")#emph[#text("harmless move")]#text(" – a move which gives up the turn of play, but does not actually decrease one’s chance of winning. In games such as chess, there does not appear to be any analogue of the harmless move, and so it is not known whether black actually has a strategy guaranteed to win or not in chess, though it is suspected that this is not the case.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 20")]#text(" The ")#link("http://en.wikipedia.org/wiki/Hales%E2%80%93Jewett_theorem")[#text("Hales-Jewett theorem")]#text(" shows that for any fixed board length, an ")#mi("{n}")#text("-dimensional game of naughts and crosses is unable to end in a draw if ")#mi("{n}")#text(" is sufficiently large. An induction argument shows that for any two-player game that terminates in bounded time in which draws are impossible, one player must have a guaranteed winning strategy; by the above proposition, this strategy must be a win for the naughts player. Note, however, that Proposition ")#link(<tao-a1d9890884c1b4b960c2>)[#text("12")]#text(" provides no information as to ")#emph[#text("how")]#text(" to locate this winning strategy, other than that this strategy belongs to the naughts player. Nevertheless, this gives a second example in which the no-self-defeating-object argument can be used to ensure the ")#emph[#text("existence")]#text(" of some object, rather than the ")#emph[#text("non-existence")]#text(" of an object. (The first example was the prime number theorem, discussed earlier.)")
]

#text("The strategy-stealing argument can be applied to real-world economics and finance, though as with any other application of mathematics to the real world, one has to be careful as to the implicit assumptions one is making about reality and how it conforms to one’s mathematical model when doing so. For instance, one can argue that in any market or other economic system in which the net amount of money is approximately constant, it is not possible to locate a universal trading strategy which is guaranteed to make money for the user of that strategy, since if everyone applied that strategy then the net amount of money in the system would increase, a contradiction. Note however that there are many loopholes here; it may be that the strategy is difficult to copy, or relies on exploiting some other group of participants who are unaware or unable to use the strategy, and would then lose money (though in such a case, the strategy is not truly universal as it would stop working once enough people used it). Unfortunately, there can be strong psychological factors that can cause people to override the conclusions of such strategy-stealing arguments with their own rationalisations, as can be seen, for instance, in the perennial popularity of pyramid schemes, or to a lesser extent, market bubbles (though one has to be careful about applying the strategy-stealing argument in the latter case, since it is possible to have net wealth creation through external factors such as advances in technology).")

#text("Note also that the strategy-stealing argument also limits the universal predictive power of ")#link("http://en.wikipedia.org/wiki/Technical_analysis")[#text("technical analysis")]#text(" to provide predictions other than that the prices obey a ")#link("http://en.wikipedia.org/wiki/Martingale_(probability_theory)")[#text("martingale")]#text(", though again there are loopholes in the case of markets that are illiquid or highly volatile.")

#heading(level: 1)[#strong[#text(" — 5. Physics — ")]]

#text("In a similar vein, one can try to adapt the no-self-defeating-object argument from mathematics to physics, but again one has to be much more careful with various physical and metaphysical assumptions that may be implicit in one’s argument. For instance, one can argue that under the laws of special relativity, it is not possible to construct a totally immovable object. The argument would be that if one could construct an immovable object ")#mi("{O}")#text(" in one inertial reference frame, then by the ")#link("http://en.wikipedia.org/wiki/Principle_of_relativity")[#text("principle of relativity")]#text(" it should be possible to construct an object ")#mi("{O^{\\prime}}")#text(" which is immovable in another inertial reference frame which is moving with respect to the first; setting the two on a collision course, we obtain the classic contradiction between an irresistible force and an immovable object. Note however that there are several loopholes here which allow one to avoid contradiction; for instance, the two objects ")#mi("{O, O^{\\prime}}")#text(" could simply pass through each other without interacting.")

#text("In a somewhat similar vein, using the laws of special relativity one can argue that it is not possible to systematically generate and detect tachyon particles – particles traveling faster than the speed of light – because these could be used to transmit localised information faster than the speed of light, and then (by the principle of relativity) to send localised information back into the past, from one location to a distant one. Setting up a second tachyon beam to reflect this information back to the original location, one could then send localised information back to one’s own past (rather than to the past of an observer at a distant location), allowing one to set up a classic ")#link("http://en.wikipedia.org/wiki/Grandfather_paradox")[#text("grandfather paradox")]#text(". However, as before, there are a large number of loopholes in this argument which could let one avoid contradiction; for instance, if the apparatus needed to set up the tachyon beam may be larger than the distance the beam travels (as is for instance the case in ")#link("http://en.wikipedia.org/wiki/Mexican_wave")[#text("Mexican wave")]#text("-type tachyon beams) then there is no causality paradox; another loophole is if the tachyon beam is not fully localised, but propagates in spacetime in a manner to interfere with the second tachyon beam. A third loophole occurs if the universe exhibits quantum behaviour (in particular, the ability to exist in entangled states) instead of non-quantum behaviour, which allows for such superluminal mechanisms as wave function collapse to occur without any threat to causality or the principle of relativity. A fourth loophole occurs if the effects of relativistic gravity (i.e. general relativity) become significant. Nevertheless, the paradoxical effect of time travel is so strong that this physical argument is a fairly convincing way to rule out many commonly imagined types of faster-than-light travel or communication (and we have a number of other arguments too that exclude more modes of faster-than-light behaviour, though this is an entire blog post topic in its own right).")

#heading(level: 1)[#text("Comments (98)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e0958f6ce6e89fed88a2a8b74fc80bcd8228d6c64259f29c5e670c913c1122d-ef7998c9a0e936631224ecbc16990b0b6f572c66d1f170bf4b892365a08940be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ray Cheung")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-95694")[#strong[#text("Ray Cheung")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2011")])]

#text("About the proof for Theorem 10 (Halting problem):")

#text("Why doesn’t the proof show only that it is impossible for Q to exist? If P -> Q, and Q leads to a contradiction, P is impossible – which I suppose is what the proof is. However, it is unclear to me why P -> Q.")

#text("If, on the other hand, the proof is supposed to use Q as a counterexample to P’s ability in determining whether a programme halts (for all programmes), one may simply reply that Q is not a (possible) programme.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-95697")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2011")])]

#text("The third and fourth sentences of the proof describe how the existence of a program P that can solve the halting problem implies the existence of a program Q that halts on S iff S(S) does not halt. Because of this implication, the non-existence of the latter program implies the nonexistence of the former program.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e0958f6ce6e89fed88a2a8b74fc80bcd8228d6c64259f29c5e670c913c1122d-ef7998c9a0e936631224ecbc16990b0b6f572c66d1f170bf4b892365a08940be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ray Cheung")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-95696")[#strong[#text("Ray Cheung")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2011")])]

#text("Sorry: “P -> Q” reads if P exists, Q exists, etc")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-134216")[#strong[#text("Carnival of Mathematics #59 « The Number Warrior")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2012")]

#text("[…] Can an omnipotent deity create a rock he can’t lift? Terry Tao tackles mathematical equivalents when considering the “no self-defeating object” argument. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic limitations of the circle method « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-143791")[#strong[#text("Heuristic limitations of the circle method « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("[…] be used to conspire against itself (in the spirit of “self-defeating object” arguments, discussed previously several times on this blog). This is actually a fairly common technique in analytic number theory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e39655931025bca733a58c2d3028d41bac912fab2d30320e41cf1addd61a6f7c-95fd0d95f69b15e2e466a3f408b237b602531ce5c56bc0489decf54d067dc883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trevor Wilson")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-163615")[#strong[#text("Trevor Wilson")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2012")])]

#text("Dear Professor Tao, I noticed that your proof that the set of countable ordinals is uncountable uses the axiom of choice and in fact proves the stronger statement that omega_1 is regular, for which some some amount of choice is required to prove. But one can prove the original statement in ZF: the set of countable ordinals is itself an ordinal, so if it were countable then it would contain itself as an element.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-420736")[#strong[#text("My great WordPress blog – Weekend Econlinks")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2014")]

#text("[…] nice recap post of Terry Tao on the “no self-defeating object” argument in mathematical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08f902cb63544c0f2dc12a2ecfe9bc4bd0185788a82b43d061b2a029b899586a-dbe65a51df6466e17bd00a34b7ef2cb524e1cdf2c35f5c6e73eef0a5e6aeb8a0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diagonal Basilisks: Slashing the Field of Enlightened Intelligence | Conflated Automatons")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-485725")[#strong[#text("Diagonal Basilisks: Slashing the Field of Enlightened Intelligence | Conflated Automatons")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2017")])]

#text("[…] Tao describes Cantor’s diagonal proof as belonging to a loose collection of “no self-defeating object” arguments, where “the very existence of {X} and its powers can be used (by some clever trick) to construct […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2229b984900b0b520d8c24e92fa34bb161f9c42ef66ae594ae1e6dad0308d3a2-95bd257c2e2657147882ed1a4dd3b375234491bb53f444fec1701f1ecf47600e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby Bartels")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-486799")[#strong[#text("Toby Bartels")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2017")])]

#text("Rather late to the party, but … using Zorn’s Lemma to prove that the class of all vector spaces is a proper class seems like using the proverbial sledgehammer to kill a fly, since already the class of all *zero-dimensional* vector spaces is proper! Any such vector space has an element, and that element could be anything at all, so once you have any proper class whatsoever (which we have by this point in the article), then you have a proper class of zero-dimensional vector spaces. (To avoid using Replacement, consider the union of the underlying sets of the vector spaces.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-486806")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2017")])]

#text("No, the class of zero-dimensional vector spaces is a set of exactly one element, namely the unique zero-dimensional vector space which in turn contains the unique zero-length vector.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2229b984900b0b520d8c24e92fa34bb161f9c42ef66ae594ae1e6dad0308d3a2-95bd257c2e2657147882ed1a4dd3b375234491bb53f444fec1701f1ecf47600e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby Bartels")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-487148")[#strong[#text("Toby Bartels")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2017")])]

#text("That’s a fine way to look at things, but it’s not how it works with abstract vector spaces in ZFC. Feel free to use a less abstract notion of vector space or even a different foundation of mathematics, but can you come up with a way in which Terry’s argument (involving unions of chains of vector spaces) proves a nontrivial theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-487688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2017")])]

#text("The same argument also shows, for instance, that there is no moduli space for vector spaces up to isomorphism which is a set. (Though this stronger assertion does require some version of Cantor’s theorem to show that there is no vector space that is maximal modulo isomorphism.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2229b984900b0b520d8c24e92fa34bb161f9c42ef66ae594ae1e6dad0308d3a2-95bd257c2e2657147882ed1a4dd3b375234491bb53f444fec1701f1ecf47600e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 732e3e6f")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-687524")[#strong[#text("732e3e6f")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2025")])]

#text("Alright, I guess that this is a theorem that uses Zorn’s Lemma nontrivially, although it’s a bit removed from the language used in the rest of the post. (I seem to have missed this comment the first time around.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/089d0cedccdbee32786c7e296994cf315ef1b3c6f13b880e696921e040d47aec-d939e5745c48f83ef6584b0b100445f6f5430f1060f2ee4de3f5348e174ac098.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arunava mondal")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-530493")[#strong[#text("Arunava mondal")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2019")])]

#text("Prof terence tao and math seems like made for each other. wonderful problem solving skills by worlds greatest mathematician ever.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-684482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2024")])]

#text("Proposed large cardinals that turned out to be inconsistent sound like possible examples of self-defeating objects. The most famous of which is Reinhardt’s axiom proposed in 1967, which is that, when ")#mi("V")#text(" is the class of all sets, there is a cardinal ")#mi("\\kappa")#text(" and a mapping ")#mi("j:V\\to V")#text(" where ")#mi("j(\\kappa)\\neq\\kappa")#text(", such that ")#mi("j")#text(" preserves truth of first-order formulae in the language of set theory. (Such ")#mi("j")#text(" is called an “elementary embedding from ")#mi("j:V\\to V")#text(".) For example, ")#mi("j(\\varnothing)")#text(" must equal ")#mi("\\varnothing")#text(", since if ")#mi("x")#text(" is the empty set, then ")#mi("\\forall y(y\\notin x)")#text(" is true, so ")#mi("\\forall y(y\\notin j(x))")#text(" must be true, therefore ")#mi("j(x)")#text(" must be empty. Similarly for ")#mi("j(\\mathbb Z)=\\mathbb Z")#text(": if ")#mi("x=\\mathbb Z")#text(", then ")#mi("\\forall y(y\\textrm{ is an integer}\\implies y\\in\\mathbb Z)")#text(" is true, so ")#mi("\\forall y(y\\textrm{ is an integer}\\implies y\\in j(\\mathbb Z))")#text(" is true, similarly ")#mi("j(\\sqrt{2})=\\sqrt{2}")#text(", ")#mi("j(\\aleph_0)=\\aleph_0")#text(", etc. In general for any mathematical object which is first-order definable in set theory, ")#mi("j")#text(" is the identity on it. (This reasoning has to be done in MK, as “definability” is not first-order formalizable due to Tarski’s theorem on the undefinability of truth.) For one of Reinhardt’s cardinals ")#mi("\\kappa")#text(", the set ")#mi("j(\\kappa)")#text(" is not equal to ")#mi("\\kappa")#text(", so such a ")#mi("\\kappa")#text(" would be “very undefinable” in that it cannot be singled out by a first-order set-theoretical property. (If it could, the property would hold of ")#mi("j(\\kappa)")#text(" too!)")

#text("Four years after it was proposed, Kunen gave a construction of a set which cannot occur in the range of any given such ")#mi("j")#text(", which means the range of any elementary embedding ")#mi("j:V\\to M")#text(" cannot be $V$. In this way a ")#mi("j:V\\to V")#text(" with this property is overpowered as its range is too large. But unlike the self-defeating objects in this blog post, this doesn’t seem to have been shown through a diagonal argument, but instead via infinitary combinatorics. (Additionally Kunen’s proof assumes the axiom of choice, and it is currently an active project in set theory to try to remove this assumption.) However, if restricting only to maps ")#mi("j:V\\to V")#text(" that are definable, there is a short proof by contradiction due to Akira Suzuki that fits in seven lines. (V. Dimonte, “I0 and rank-into-rank axioms”, arXiv 1707.02613, theorem 3.12)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-687520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2025")])]

#text("U(U) isn’t true, because U is only 32 characters long. U(U) is however 65 characters long, which means U(U(U)) is true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-2/#comment-687531")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2025")])]

#text("Dear Prof. Tao,")

#text("Could we extend our view from focusing on how one overpowered object defeats itself into what an overpowered object may affect a system of many objects?")

#text("For example, I noticed it is common for the power/freedom of one object to limit the others’. Suppose one person wants to sit on a chair (that can only contain one), then the person’s power of doing so has made it impossible for everyone else. In this specific example, there’s even some sense of conservation of the power to sit at chairs, which I find interesting.")

#text("Do you know some interesting math examples that are concerned with such power interactions among a group of objects?")

#text("Thank you for your time in advance. Yours truly, Guanyuming He")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24e4f0acbdcc91b2c7ba7aa365b93230645de6434c5bb00b576cb2e5b7b4b5d4-c613a49f867fec7449a638a997a449750baa68478c75c7b8283270fc50513284.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Peccati")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42229")[#strong[#text("Giovanni Peccati")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Nice post !")

#text("Minor remark : it is my impression that the proof of Proposition 3 is not concluded – as it merges into some further discussion.")

#text("All the best")

#text("Giovanni")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42230")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Interesting post. A quick thought on “it is much harder to let go of the belief that, at some point, some sufficiently ingenious person will work out a way to countably enumerate the real numbers”:")

#text("this may be tied up with the notion of infinity itself, since (not thinking precisely at all) finite things are things that can be laid out in a field and counted and “infinity” is already larger than anything that can be concretely visualized and hence, how can there be a bigger “infinity” than “infinity”?")

#text("There appears to be a broken link in Remark 8 ")#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/313a0f0931977193ccb0170ffac75a1558db11f6f92689c957ca80a4f297cf54-c1366d4ddba5532cb29d54d0f2449fece6cc48efe9556cfa7792f3e1dcc87a0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rune")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42233")[#strong[#text("Rune")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("You comment on chess reminds me of this question: If two computationally unbounded players play Chess, does White win? Is it a draw? Does Black win?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42234")[#strong[#text("The omnipotence paradox « Cam's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")]

#text("[…] omnipotence paradox Filed under: Uncategorized — cfranc @ 2:49 pm Just read Terrence Tao’s latest post over at his blog. He mentioned the omnipotence paradox, which is likely familiar to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b6c183e66bf0d5eea5ac2c7f580ab4cdfce5df6bb0a7bc70cdf5008e4cde674-f39eadc61e7438c735baff1677a31f5b42dffa64142bf167f143e1c7ef681e6f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bruno")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42235")[#strong[#text("Bruno")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("In Remark 14, the proposition you use (if a set is both recursively-enumerable and co-recursively-enumerable, then it is recursive) is often referred as Post’s Theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f67cfa61b927c9420df8f6465fbb08864ae4148507e821529abc0cc879b9cf1a-6693181fe60d9046bba05ef0b4c1ac8fe9f7c4c64b6c3a1ebefeeeffeaa272e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42236")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Thanks for this nice post.")

#text("I have a question about the proof of Proposition 12.")

#text("You suppose that the second player has a winning strategy W, and then write “The first player can then steal that strategy by placing a naught arbitrarily on the board, and then pretending to be the second player and using W accordingly.” Remark 18 explains that this kind of strategy stealing depends on the fact that it is possible in naughts and crosses to play a “harmless move.”")

#text("What I do not follow is how can it be possible for there to be such a")#linebreak()#text(" “harmless move” under the assumption that the other player has a")#linebreak()#text(" winning strategy? If we assume the second player has a winning strategy, then she can win regardless of the move (arbitrarily placed, “harmless” or whatever) made by the first player.")

#text("A related question is the following. How does one prove that a given game has a “harmless move” or prove that it does not?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8e02c0f12d32b272bdc386cb1b4ad5d300575eaca52b69fa473451e2a3c7c25-1737a78443d7004c976a1bf61475c4e35240eed32cfd3cdc9bdb7d8c6890ac31.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter LeFanu Lumsdaine")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42241")[#strong[#text("Peter LeFanu Lumsdaine")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Doug: As you say, the existence of a “harmless move” for one player is incompatible with the existence of a winning strategy for the other. So by proving directly that there _is_ a harmless move (and TT’s argument for noughts and crosses gives the essentials of such a proof), we get a contradiction, which shows the assumption can’t have been right.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f3110a4fe11b8f0b11e3ce966c2ab2ac2e8f0a67944606caffbfd26cbfe3313-6c6d41a295497437ca2e6ac72536111291bf8459ae5a38a65e89cd98d8469fe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjil P. Saikia")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42237")[#strong[#text("Manjil P. Saikia")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Thanks for the nice post, it is really stimulating to read this in your blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42238")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Hi Terry,")#linebreak()#text(" It looks like a line was left out at the end of Prop. 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42244")[#strong[#text("Ulrich")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Tery, can you please check if you have put the html-code in the graphics mode to WordPress? I can see the original code (, ..) and not the formatted one.")

#text("Thanks")

#text("Ulrich")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42245")[#strong[#text("Ulrich")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("… has gone. Mysteriously.")

#text("Ulrich ")#emph[#text("[Sorry, that was a temporary glitch while trying to fix an earlier error. It should all be OK now – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f67cfa61b927c9420df8f6465fbb08864ae4148507e821529abc0cc879b9cf1a-6693181fe60d9046bba05ef0b4c1ac8fe9f7c4c64b6c3a1ebefeeeffeaa272e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42247")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Peter, Thanks. The way you wrote it is better than my ramblings. Now I just need to see a precise definition of a “harmless move” and a proof that naughts and crosses has one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d70f1d7103f3dae1a2a27b98564227eea9159398aa822dca9a79f0094808b778-f19af20018e4c529868296225fe3b99f806567268fa386a34c68014c65fdf3ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42251")[#strong[#text("Ted")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("I’m not entirely sure of the distinction being made in Remark 13. What’s the essential difference between uncomputable and undecidable here?")

#text("At first, I thought perhaps uncomputable might mean that it’s not even recursively enumerable, but that cannot be right in this context. (The halting set is r.e., as you state in remark 15.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42254")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Well, the distinction I had in mind was this: I could conceive, in principle, of a world in which the halting theorem failed but the incompleteness theorem held. Namely, imagine that there was some miraculous algorithm that could decide whether any given program halted in finite time, but nobody could explain why it worked (in particular, there was no proof that the answers it gave were correct). Then one could ask the algorithm whether a demonstration of (say) the inconsistency of ZFC existed, and it would give the correct answer (which would be NO, assuming that ZFC is consistent), but this would not constitute a proof that ZFC is consistent, because one could not prove the soundness of the algorithm.")

#text("The halting theorem excludes the existence of such miraculous algorithms, even if their soundness is unproven. (But perhaps there is a clever way to arrange things so that one could use the incompleteness theorem to prove the halting theorem or vice versa. I wasn’t able to come up with one, though.)")

#text("It’s a little unfortunate that the term “decidable” has two different contexts here (existence of a proof or disproof of a statement, vs. existence of an algorithm that can correctly answer a class of yes-no questions), though of course they are very closely related.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb44e2738f7c3f1c593ab72676656f5ac8b514847e02263d3aac0111d89e7bc1-1678ced985578c8de61fcc0acfb1f566d73425eea6f6b4182282ebef7414067a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42277")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("You can deduce the incompleteness theorem from the undecidability of the halting problem as follows: consider all statements of the form “machine M halts on input w” and “machine M does not halt on input w” over all machines M and possible inputs w.")

#text("I claim that, assuming consistency, there is some M,w such that neither the statement “machine M halts on input w” nor its negation are provable, and hence the statement is undecidable (in the logical sense).")

#text("Otherwise, given a machine M and a string w, I could enumerate all possible strings P, and check if P happens to be a valid proof of “M halts on input w” or of “M does not halt on input w.” This search would always terminate, and so I would have an algorithm for the halting problem.")

#text("This can be made more constructive by exhibiting a specific true and unprovable (assuming consistency) statement, rather than having a non-constructive existence argument above, by folding the above argument with the proof of undecidability of the halting problem.")

#text("Consider the machine D that, on input the description of a machine M, enumerates all strings P, and halts if P happens to be a proof of the statement “machine M does not halt when given the description of M as an input”")

#text("Consider the statement “D does not halt when given D as an input.” Assuming consistency, neither this statement nor its negation can be provable.")

#text("At this point we can also get the Second Incompleteness Theorem, by noting that if consistency were provable, then we could formalize the above argument, prove the statement “there exists no proof P that D does not halt when given D as an input,” and then realize then suddenly we do in fact have a proof that “D does not halt when given D as an input,” leading to a contradiction. (Hence if consistency of our logical system is provable within the logical systems itself, then our logical system must be inconsistent.)")

#text("These arguments are due to Turing. I don’t know if there is a way to deduce the halting Theorem from the incompleteness theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42284")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Thanks Luca, that is quite clarifying! I will adjust the remark accordingly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42252")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("I have one small quibble, with your statement that the proof of the existence of a winning strategy for naughts-and-crosses is highly nonconstructive. The proof does give a strategy: exhaustively analyze all possible plays of the (finite!) game, and then play along a winning one. (The strategy is, of course, useless for practical purposes except when n is small, but mathematically valid.)")

#text("It isn’t entirely obvious that this strategy is the one witnessing the claim, because the argument here is given by contradiction, but the methods used in the proof are entirely elementary, so metatheorems guarantee that there are finitely many possible witnesses hidden in the proof. It’s not hard to check that this rather boring strategy is the one in question.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42255")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Fair enough. I guess what I wanted to say is that the proof that naughts has a winning strategy is ")#emph[#text("no more constructive")]#text(" than the general statement that any two-player deterministic game without draws has a winning strategy for one side, in that the knowledge that naughts wins is of essentially zero help in actually constructing a winning strategy (though I suppose it might prune the strategy tree by a factor of two, at best).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42256")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Note that although the behavior of naughts and crosses (which I think many Americans call xs and ohs) does have a surprisingly counterintuitive result. Namely there are boards one can construct such that the first player has a winning strategy but there is an expansion of the board such that the second player can force a draw.")

#text("Also note that in regards to the connection between the Halting Theorem and Godel’s Undecidability can be thought of as a bit closer. Godel’s result follows from showing that any sufficiently powerful axiomatic system can model Turing machines and that one can construct a Turing machine which enumerates all the theorems in a given axiomatic system. Thus, Halting theorem implies Godel’s theorem. It isn’t that hard to see that the other direction also goes through.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42281")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Can you sketch the argument that Godel’s theorem implies the Halting theorem?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42258")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Consider the following modification of chess. Every player makes two moves in a row. White can start by moving a knight and returning it to its initial square. This harmless move shows that there is no winning strategy for black.")

#text("A common technique in regular chess is called ")#link("http://en.wikipedia.org/wiki/Zugzwang")[#text("zugzwang")]#text(". The fact that a player must make a move leads to a loss. This is the opposite notion of a harmless move.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42260")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("@Zelinsky How is that counterintuitive? 1 needs to pin down 2, and extra spaces may give 2 enough room to wiggle out of it.")

#text("Also, “")#emph[#text("although")]#text(" the behavior has a ‘counterintuitive result’…” what?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42265")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Er, there’s a clause missing after “although” I meant to say something of the form “although the intuition that the second player never has a winning strategy is correct.” Some sort of brain to keyboard error there.")

#text("I’m not sure what you mean about pinning down and wiggling out. In a standard xs and ohs game the goal is to get a configuration of your pieces lying in a certain set of patterns. The issue then becomes that there are boards which are winning boards for the first player that become drawn boards when expanded. Note that this doesn’t happen for well-behaved boards. If one is using fairly symmetric configurations on a square board and that board is a win for the first player then larger square boards is also a win. The boards that don’t do this are a bit pathological.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42278")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("The winning paths through game trees generally consist of restricting the possible good plays of 2. 1 plays in such a way as to constantly threaten a win, which gives 2 only one option of where to play next, and effectively gives 1 a free move.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90eb6754b49a40a99c747e6919248c50a8328e8f15e803e81c48889c356bc3e3-d1534dba4fba9f7980f57523c4e7223bcfc57bfc031f7c4cdcb1b9a2c94b5e5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of V. V. Volkov")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42262")[#strong[#text("V. V. Volkov")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Dear Prof. Tao,")

#text("Thank you for the elegant and straightforward exposition! Even for an undergrad and non-mathematician like myself, these types of explanatory posts and talks (the “Distance Ladder” slides, for example) are fascinating and inviting to read through.")

#text("With regards to Remark 2: is it fair to say that, by definition, the hypothetical almost-universal set Z would have to contain the universal set X as a member, a priori? (Because X =/= Z, and Z supposedly contains “all” sets other than Z itself…) Otherwise, how could one claim that X = Z U {Z} is a universal set, which must contain itself?")

#text("Thank you again for the thought-provoking post and references!")#linebreak()#text(" – Vasiliy")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42285")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Yes, this is correct. By hypothesis, Z consists of all sets other than Z itself, so by adding Z, one obtains all sets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Your way of unifying mathematical topics by focusing on a single underlying trick is very enlightening. All the math books should be rewritten to emphasize the recurring tricks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T. Tao: „Self Defeating Object Argument“ « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42280")[#strong[#text("T. Tao: „Self Defeating Object Argument“ « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("[…] November 2009 in Mathematik | Tags: tao mathematik grundwissen Ich kann nur empfehlen, diesen Artikel von Terence Tao zu studieren. Zum Inhalt zitiere ich den Anfang: „A fundamental tool in any […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d51ce1eae8a466b08c37f4a3cc0daff2ad5394ac19cfd8ba470753832c795e3c-52eeef7276aa5dfa76f4c67ce41bf0ba0b274805200258bec7cbbe707aae982e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kunal")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42288")[#strong[#text("kunal")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Great post!")

#text("While I have always seen the proof of non-enumerbility of reals as above, I find the details dealing with recurring decimals very distracting. After all, the theorem still holds if you wrote the reals in binary, but this proof fails.")#linebreak()#text(" Why don’t we use something like the following argument:")#linebreak()#text(" Lemma 1: If the reals are enumerable, then so is the set of all decimal representations. (There are at most two per real).")#linebreak()#text(" Lemma 2: The set of all decimal representations is no enumerable. (This is now much shorter.)")

#text("Isn’t this proof didactically better?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42289")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Wonderful thread! I discussed “… by other primary school children…” with my Physics professor wife, after posting a link to this for my roughly 500 Facebook friends.")

#text("I have seen primary school children argue in the schoolyard variations of “can God make a rock so big that he can’t lift it?” which I’ve heard expressed, not as Theophysics, but as pop culture: “can Superman fly to a planet so big that he can’t move it?”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42291")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("I also once heard a child, puzzled by perspective or optics, ask another child: “Is there something so big that when you stand so far away from it that you can see all of it, you’re so far away that you can’t see it at all?”")

#text("But that’s a single datum, and does not diminish Terry Tao’s great point: “ROUTINELY taught to primary school children by other primary school children…”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Borcherds")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42296")[#strong[#text("Richard Borcherds")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("The statement “It is not hard to show that a consistent logical system cannot disprove its own consistency either” in remark 11 is a little misleading. One can take a consistent system, say Peano arithmetic, and add the statement that it is inconsistent as a new axiom. This produces a system which is consistent (otherwise Peano arithmetic would prove its own inconsistency) but which in some sense asserts its own inconsistency! Models of this give rather strange non-standard models of Peano arithmetic. I have a vague memory that there is something called omega-consistency which may be relevant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42309")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2009")])]

#text("Ah yes, one does have to restrict attention to systems which actually model the standard natural numbers (or more generally, to omega-consistent systems), otherwise a proof of inconsistency within the system does not actually imply that one can establish inconsistency in a finite amount of time. I’ve reworded the text accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42300")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2009")])]

#text("This was a really nice post!")

#text("To ask about something less interesting:")#linebreak()#text(" Do you find that proofs by contradiction like these can be a bit confusing in the way they tend to be presented? For example, one sometimes uses the words “Assume” or “Suppose” to precede all assumptions (including those which will later be contradicted), but then it is unclear the proof will proceed by contradiction, and sometimes even unclear what will be contradicted (since this matter can be quite subtle). For example, bootstrap arguments in PDE can sometimes be proofs by contradiction, which can be obscured in casual presentations.")

#text("Using the phrase “Suppose for contradiction” (as you have done) or “assume by contradiction” seems to clarify that there will be a contradiction and exactly which assumption will create the contradiction. To a mathematician it’s clear what this phrase means, but it seems to require that one already be familiar with it.")

#text("Using the phrase “Pretend” seems to serve the same purpose, it’s brief and I think it resembles more familiar English, but perhaps it is not sufficiently precise or otherwise why it’s not as common.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42304")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2009")])]

#text("A variation of this that I use is “Anticipating a contradiction, suppose that …”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42317")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("Minor point, but in general proof by contradiction will imply that one or more of the assumptions you make is false. When it is not so obvious that all the other assumptions are true, I think it can be misleading to place “Suppose for contradiction” or “Pretend” on a single assumption.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42306")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2009")]

#text("[…] The “no self-defeating object” argument A fundamental tool in any mathematician’s toolkit is that of reductio ad absurdum: showing that a statement is […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39a4fceeb5fa895b182955dc46b734f784f11fe493a5abf750cca5bcf6181b03-d94280e92cc5786c867cc7a5570266aa4345f474152471d19d34ea416160769d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of null")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42319")[#strong[#text("null")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("I think prop 2 is to close to the foundation to be proved in such a manner. Formally prop 2:: does not exist f surjective f:{1..n}->N since image(f) is N we have a question if that sum f(i) is well defined. Also the introduction of + function is not necessary. I suggest: does not exist f bijection f:{1..n}->{1..n+1} then prop 2 follows (prop 8 “Algebra By Saunders Mac Lane, Garrett Birkhoff” p.158)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42324")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("One can define ")#mi("\\sum_{i=1}^n f(i)")#text(" for any function ")#mi("f: \\{1,\\ldots,n\\} \\to {\\Bbb N}")#text(" by induction on n (and a small amount of set theory), using the fact that the natural numbers are closed under addition. Of course, this is inconsistent with the hypothesis that the natural numbers are finitely enumerated, but that’s the whole point – we’re ")#emph[#text("trying")]#text(" to establish a contradiction!")

#text("One can prove Proposition 2 without use of the addition function, but I chose this proof in order to motivate the proof of Proposition 3.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f45ac1e57b0cc191d57d12bd76ab2471fd643988ce5db3661ca7d2d57d7bb9e-b719f8ee7693f457b32a4ac9fe0540d1c40c44b8ef3a9e6e8b591ac7f1a43668.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of crosslegged")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42320")[#strong[#text("crosslegged")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("Hello. In the proof of proposition 5, why is it “Y = A_y with y in Y” and not “Y = A_x with x in X”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42323")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("One could use any dummy variable here. I chose to call this particular element ")#mi("y")#text(" to emphasise that it is the element that indexes ")#mi("Y")#text(" in the enumeration, but one could of course give it another name if one pleased.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f45ac1e57b0cc191d57d12bd76ab2471fd643988ce5db3661ca7d2d57d7bb9e-b719f8ee7693f457b32a4ac9fe0540d1c40c44b8ef3a9e6e8b591ac7f1a43668.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of crosslegged")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42331")[#strong[#text("crosslegged")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2009")])]

#text("Thank you for replying professor Tao. My problem is not the name of the variable, but the fact that the element that indexes Y is in particular in Y, and not just in X. I think it should just be in X. ")#emph[#text("[Ah, I see now. Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06a0f9a2923198f2285100d9e3e689827039aaeeb0acbce5c98c8d4ea5e4064e-47bdd26f554020be44a3e0ff25c059c59181867ff559e503932fba42a2bc037a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Varun")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-79009")[#strong[#text("Varun")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2011")])]

#text("By your definition of {Y}, {y \\in Y} iff {y \\not \\in A_x}, not {A_y}. So your contradiction doesn’t readily follow.")

#text("I’m sure one can still somehow complete the argument from here, but I don’t immediately see how.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-79016")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2011")])]

#text("In the definition of Y, x is a ")#link("http://en.wikipedia.org/wiki/Free_variables_and_bound_variables")[#text("bound variable")]#text(", and may be substituted for any other expression if desired, by the ")#link("http://en.wikipedia.org/wiki/Universal_instantiation")[#text("rule of universal instantiation")]#text(". Thus, for instance, if ")#mi("x \\in X")#text(", then ")#mi("x \\in Y")#text(" if and only if ")#mi("x \\not \\in A_x")#text("; if ")#mi("y \\in X")#text(", then ")#mi("y \\in Y")#text(" if and only if ")#mi("y \\not \\in A_y")#text("; if ")#mi("57 \\in X")#text(", then ")#mi("57 \\in Y")#text(" if and only if ")#mi("57 \\not \\in A_{57}")#text("; and so forth.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04d9122a4f5a65fbc4c97e1913c8923ff4e487fec00e589d1e9ba63d2b711419-069869cb30be63e27c55cab11e831649bc80ef4161d99462da03503b399c2fe4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny Easwaran")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42321")[#strong[#text("Kenny Easwaran")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("The set-theoretic arguments of course all assume that we’re working in something like ZFC, with either an axiom of separation or an axiom of foundation or both. Of course, there are consistent set theories (like Quine’s “New Foundations” and one discussed in ")#link("http://www.pgrim.org/philosophersannual/pa28articles/forsterset.pdf")[#text("a recent article by Thomas Forster")]#text(") where there is a universal set. (When I say “consistent”, in the one case there are explicit relative consistency results showing that this theory is consistent iff ZFC is. For NF, I don’t think there is such a relative consistency result yet, but I think people are nearly as confident of consistency here as they are of ZFC.)")

#text("Also, for the elimination of faster-than-light communication in relativity, I don’t see why the grandfather paradox is a strong enough paradox to rule any of this out. What you’d need to do is show that it’s possible to send arbitrary messages, and to set up devices that respond to arbitrary messages in inconsistent ways.")

#text("That is, you might set up two devices such that one of them is guaranteed to send a message at some time, which is different from any message it receives one second earlier, if there is such a message. Meanwhile, you can make sure that there is a machine at its destination that is guaranteed to send out a message identical to the one that it receives, in such a way that its message reaches the input time of the device it receives from. If the construction of a tachyon device allowed this sort of construction, it would clearly be contradictory.")

#text("But this sort of argument wouldn’t rule out a tachyon device that only sends messages if it receives a message (neither device would send a message then), or a device that can only send messages that agree with its input in some way, or a device that can’t respond to inputs in any way, or devices with other sorts of restrictions.")

#text("The initial grandfather paradox assumes a strong conception of free will (that is, one that assumes that every single action of a certain class is possible for an ordinary human). But if you only assume a version of free will that is compatible with a deterministic universe, then there is no grandfather paradox.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04d9122a4f5a65fbc4c97e1913c8923ff4e487fec00e589d1e9ba63d2b711419-069869cb30be63e27c55cab11e831649bc80ef4161d99462da03503b399c2fe4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny Easwaran")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42322")[#strong[#text("Kenny Easwaran")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("Oh, and in Remark 14, I don’t see what work Newcomb’s paradox is doing here. The problem there is just a paradox involving two concepts of rationality (one says that it’s rational to perform an act iff it has the highest expected payoff; the other says that it’s rational to perform an act if it increases your payoff conditional on any state the universe outside of you may already be in). Without a notion of rationality, there is no paradox. (You can take one box or both, and both have consistent outcomes.) Since there is no notion of rationality involved in a formal logical system, I don’t see the relevance here. Maybe I’m misunderstanding the metaphor?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42326")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("1. Yes, the discussion in Section 2 is specific to ZFC-type systems (see the first paragraph). And yes, there are certainly plenty of loopholes in the grandfather paradox (I mention a few in the post), though it’s hard to come up with a plausible realisation of such loopholes which continues to give the tachyon device any sort of physical influence on the world while always avoiding the possibility of paradox.")

#text("2. Regarding Newcomb’s paradox, the point is that if one assumes free will, together with causality (one’s present choices, made of one’s free will, cannot influence the prior state of the universe), then there is no distinction between the two types of rationality you mention, at the time one “chooses” whether to take one box or both. The paradox shows that a robot programmed using a language L that can be simulated in advance by another entity cannot always be both rational (i.e. always acting to increase expected payoff) and logically consistent while assuming both free will and causality. To me, this is a convincing demonstration that such a robot does not, in fact, have free will.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80ed17b0a9ca583b1105e476b6af80dd8f244fcc9a23ade804810bf73d37f0b-01a28f9cc6b908126320c63a0dcd0e26b95be19c987a15b8c7f6a7991f3abce6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42327")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2009")])]

#text("You mention the extended natural numbers, which are the ")#link("http://golem.ph.utexas.edu/category/2008/12/the_status_of_coalgebra.html")[#text("terminal coalgebra")]#text(" for the functor on the category of sets, ")#mi("F: X \\to 1 + X")#text(". Both ")#link("http://ncatlab.org/nlab/show/terminal+coalgebra")[#text("terminal coalgebras")]#text(" and ")#link("http://ncatlab.org/nlab/show/initial+algebra")[#text("initial algebras")]#text(" are fixed points of the relevant functors, respectively greatest and least. The initial ")#mi("F")#text("-algebra is of course the natural numbers, from which induction and recursion follow.")

#text("Peter Aczel in his book ‘Non-well-founded sets’ shows what can be done when giving up well-foundedness. One current formulation of this in ‘algebraic set theory’ is that the class of well-founded sets form an initial algebra, and the class of non-well-sets a terminal coalgebra for the functor on the category of classes which takes a class to the class of set-sized subclasses.")

#text("Aczel speaks of maximalising and minimalising axiomatisations. One example of a maximalising axiomatisation was Paul Finsler’s 1926 definition of the system of sets as the maximal system satisfying certain properties (this is more or less Aczel’s class of non-well-founded sets). Not understanding this kind of definition, Baer argued using a self-defeating argument that there could be no such thing – for any system of sets satisying Finsler’s axioms, a new set could be found which when added would still be a Finslerian system.")

#text("Maximalising axiomatisations exist throughout mathematics, for example, one of Hilbert’s axioms of Euclidean geometry states:")

#text("V.2: Line completeness. To a system of points, straight lines, and planes, it is impossible to add other elements in such a manner that the system thus generalized shall form a new geometry obeying all of the five groups of axioms. In other words, the elements of geometry form a system which is not susceptible of extension, if we regard the five groups of axioms as valid.")

#text("The real interval has only recently (a decade ago) been ")#link("http://golem.ph.utexas.edu/category/2008/11/coalgebraically_thinking.html#c020415")[#text("characterised")]#text(" in a coalgebraic fashion as a terminal coalgebra for a certain functor on bipointed spaces.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8361501f810f10c23207f9d499f1269e2413b19dd805b969a4b9721921f33a9f-203bedfa413e279a5d8ee8cbbe59e447c01df8af339ef5bdf4b4d30de3bc2bff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Gerdes")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42334")[#strong[#text("Peter Gerdes")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2009")])]

#text("The reason people have so much difficulty with the cardinality of the real numbers is that most people understand cardinality as ‘size’ and this is easily confused with the notion of size provided by extent (kinda a half-assed version of measure). I mean we can enumerate the rationals and in terms of extent this has the same size as the reals.")

#text("I suspect if you asked the same question about \\omega^\\omega people wouldn’t find it so troubling because they don’t start with any preconceived notion of size in the baire space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1a29b83d3715f084733cbf3b4d6ebeb0bd60852598b56cfdcefb1ca59292e95-be295ea13410f76f66eab689ea4c87a5f2c5418a1f6f3a28544dee0db39727c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of konradswanepoel")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42337")[#strong[#text("konradswanepoel")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2009")])]

#text("In Remark 8 you don’t need the axiom of choice. The ordinals can be defined in ZF as sets that are well ordered by the ")#mi("\\varepsilon")#text(" relation and whose elements are also subsets. Then the first uncountable ordinal is simply the set of all countable ordinals. Other properties such as transfinite induction also hold in ZF.")

#text("Of course Choice comes in when showing that an arbitrary set can be given a well ordering (with its consequences such as Zorn’s Lemma).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42343")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2009")])]

#text("I can see why the class of countable ordinals is a class, but in ZF how does one ensure that it is actually a set? If one tries to use transfinite induction it seems that one needs an uncountable ordinal to begin with in order to ensure that it is a set rather than merely a class, which seems circular…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42345")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2009")])]

#text("Hi Terry. Just look at the collection of well-orderings of subsets of ")#mi("{\\mathbb N},")#text(" thought of as binary relations. This is a set. Consider the equivalence relation where 2 such well-orderings are equivalent iff they are (order) isomorphic. The quotient is a set. Well-order this quotient by saying that ")#mi("[(A,<_1)]")#text(" is below ")#mi("[(B,<_2)]")#text(" iff $(A,<_1)$ is order isomorphic to a proper initial segment of ")#mi("(B,<_2)")#text(" (this is well-defined). The resulting well-order is uncountable, but all its initial segments are countable. Choice was not used in this construction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1a29b83d3715f084733cbf3b4d6ebeb0bd60852598b56cfdcefb1ca59292e95-be295ea13410f76f66eab689ea4c87a5f2c5418a1f6f3a28544dee0db39727c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of konradswanepoel")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42348")[#strong[#text("konradswanepoel")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2009")])]

#text("Yes! This idea goes back to ")#link("http://en.wikipedia.org/wiki/Hartogs_number")[#text("Hartogs")]#text(". And note that this argument needs the most powerful axioms in ZF: the power set axiom and the axiom scheme of replacement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42362")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("Thanks for the argument (which I was not aware of). I’ve updated the remark accordingly.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9239126993d77f97253c84f7e6ed6f3531411cd1705413363f13701f7cf799cf-3bf816850c327eba55e60225a2c74cb7b5310f3f97a7dfe8739821bd3f336afc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of scineram")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42373")[#strong[#text("scineram")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")])]

#text("I would add that none of the ordinal statements require axiom of regularity or foundation by definition of ordinals as stets well-ordered by the element relation.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42378")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")])]

#text("I have always had a problem with Prop 6 proof.")

#text("It is not clear to me why the new decimal expansion you constructed in NOT is the enumerated list. It seems to me all you have done is created a number which is different from x_n. Why is the new decimal not in the enumerated list somewhere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42379")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")])]

#text("The new decimal expansion is, by construction, distinct from ")#mi("x_n")#text(" for every n: distinct from ")#mi("x_1")#text(" (because of the way the first digit was chosen), distinct from ")#mi("x_2")#text(" (because of the way the second digit was chosen), distinct from ")#mi("x_{37}")#text(" (because of the way the 37th digit was chosen) and so forth. It is thus distinct from every real number already in the enumeration.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42383")[#strong[#text("Reductio ad absurdum")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2009")]

#text("[…] Reductio ad absurdum […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7afc98263ba0b47908100442c0da2babee68fa2a29513a1004b2a1762392e654-716f757855f1e75b0e2e5c58e4bb6cb65a965f998dcf8ad794a650e0562130dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sirval")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42413")[#strong[#text("sirval")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2009")])]

#text("Very nice post!")#linebreak()#text(" I would like to make a comment about the application of the “no self-defeating object” to physics, and is that I believe that proofs of the non-existence of a deterministic theory compatible with the results of experiments such as GHZ or EPR are good examples of the use of a “reductio ad absurdum” method.")#linebreak()#text(" It is possible to argue that locality can be violated, or the existence of dependence in the state of the particles related to the measuring apparatus, but I believe that this one is also a good example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9298082e2e355dedc5956dfa26c44c110a64c133a00bb23fda85fdd97ec8aa83-72ed8411d923e3258beb396319d0c7ecd6e49fae29446a8e815af7471dbd20f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of piergiorgio odifreddi")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42423")[#strong[#text("piergiorgio odifreddi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2009")])]

#text("dear tao,")

#text("a propos of the relationships between incompleteness and the halting problem, it is known that while the latter implies the former, as correctly stated in the post, the converse is not true.")

#text("more precisely, the halting problem corresponds to proving undecidability (and hence incompleteness, for formal systems) by showing that SOME (and actually, the most complicated, in a precise sense) non computable, computably enumerable set is representable in the system.")

#text("but it is als possible to prove undecidability (and hence incompleteness) of a formal system by showing that ALL computable sets are representable in it.")

#text("now, it was proven in the ’60s by shoenfield (and this was, historically, the first application of the so-called “infinite injury method” in computability theory) that there is a formal system in which all recursive sets are representable, but the halting problem is not.")

#text("if you want details, discussions and references see my “classical recursion theory” (north holland, 1989 and 1999), in particular pp. 352-353 of volume I.")

#text("ciao!")

#text("george odifreddi")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42562")[#strong[#text("hyangchun's me2DAY")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2009")]

#strong[#text("향천의 생각…")]

#text("The “no self-defeating object” argument « What’s new…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e180391a286fb32b6fb4729c08985d031ed5e4a39d0228ec8db8b306bf83825e-246e61db3b09882c8ab7a01c598c83726d3e00ffe59ca0c07769cf0c879ceb40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of artur")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-42618")[#strong[#text("artur")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2009")])]

#text("For generalizing the tic-tac-toe example, I guess one should also specify that the winning pattern is monotone. For instance, if the winning pattern for the first player required that certain squares should have crosses, then I don’t see how the harmless move idea can be implemented.")

#emph[#text("[Added a clarification that the winning pattern is a subpattern only, and consists entirely of naughts or entirely of crosses. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A computational perspective on set theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-43936")[#strong[#text("A computational perspective on set theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("[…] computational resources and the latter in the case of unlimited computational resources. (See also my previous blog post for further discussion of these “no self-defeating object” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-44762")[#strong[#text("The Hilbert Hotel - Opinionator Blog - NYTimes.com")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2010")]

#text("[…] wishing to go deeper into infinity might enjoy Terry Tao’s blog post about “self-defeating objects.” In a very accessible way, he presents and elucidates a lot of fundamental arguments about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The “no self-defeating object” argument, revisited « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-47674")[#strong[#text("The “no self-defeating object” argument, revisited « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("[…] Some time ago on this blog, I collected a family of well-known results in mathematics that were proven by contradiction, and specifically by a type of argument that I called the “no self-defeating object” argument; that any object that was so ridiculously overpowered that it could be used to “defeat” its own existence, could not actually exist. Many basic results in mathematics can be phrased in this manner: not only Cantor’s theorem, but Euclid’s theorem on the infinitude of primes, Gödel’s incompleteness theorem, or the conclusion (from Russell’s paradox) that the class of all sets cannot itself be a set. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b710c4938470342948ae9394b70d9236850d725183f069069d7e5baf6f83155-56c14b4577bc1a8147538afef4e30aaab682cdbe707714f8b32a4362a6da1d8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luke Grecki")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-47802")[#strong[#text("Luke Grecki")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("I don’t follow your reasoning in Remark 16.")

#text("Suppose one had an algorithm to determine the existence of smooth solutions to arbitrary nonlinear partial differential equations. I don’t see how this implies you would know whether the Turing machine you were modeling with such equations halts. You would know there existed solutions describing it’s behavior, but you wouldn’t necessarily be able to compute them or prove that they had certain properties.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-47804")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("The idea is to set up a PDE problem which admits smooth solutions if and only if a certain Turing machine halts. One way to do this is to create an analog Turing machine that takes ")#mi("2^{-n}")#text(" units of time to do the ")#mi("n^{th}")#text(" step of the computation. If the machine does not halt, then the evolution of this machine will develop a singularity at time ")#mi("1")#text(", but otherwise it will exist and be smooth for all time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b710c4938470342948ae9394b70d9236850d725183f069069d7e5baf6f83155-56c14b4577bc1a8147538afef4e30aaab682cdbe707714f8b32a4362a6da1d8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luke Grecki")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-47805")[#strong[#text("Luke Grecki")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("Gotcha. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-52162")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2011")])]

#text("This is a really nice construction. And it looks like there would be alot more to investigate (and some of it has already been investigated) on PDE and classical/Church-Turing computation -like computability of certain qualitative properties of solutions, and relations between chaos, stability and generalized Church-Turing theses.")

#text("Relevant links:")#linebreak()#text(" ")#link("http://mathoverflow.net/questions/15309/simulating-turing-machines-with-o-pdes")[#text("http://mathoverflow.net/questions/15309/simulating-turing-machines-with-o-pdes")]#linebreak()#text(" ")#link("http://mathoverflow.net/questions/15292/why-cant-there-be-a-general-theory-of-nonlinear-pde")[#text("http://mathoverflow.net/questions/15292/why-cant-there-be-a-general-theory-of-nonlinear-pde")]

#text("Questions:")

#text("Can you precise slightly the kind of ODE/PDE you have in mind that would yield $2^{-n}$ unit of time computations?")

#text("Also, in general I have a hard time figuring what is folklore, what is known to you and a few others, and what you have just discovered. These are important data when trying to learn. So is the present construction yours? When did you come up with it?")

#text("If you could indicate when an argument is yours that would be of great ultility. Or are there canonical rules to determine this that I am missing -maybe this question was asked or I should ask on mathoverflow?")

#text("I guess it does not look too good repeating “…, my idea”. So when you do not put references I tend to attribute the result to you. I.e. I assume you give references for things that look nontrivial and are not your ideas.")

#text("But in the end the phenomenon here is probably one of those irreducible/unavoidable losses of information/entropy increases responsible for the economic crisis we are in and I should just live with it. :)")

#text("For instance I find your last post on the limiting absorption principle extremely illuminating (and thank you for it) but it is difficult for me to figure what makes that post so relevant to you now. I understand you are developing a generalization of the limiting absorption principle. Are there other reasons? And why/whence the generalization?")#linebreak()#text(" Well I comment profusely just in case this may be useful. Sorry if it is not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-52165")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2011")])]

#text("One can start with an ODE or PDE that performs each step of a Turing machine calculation in unit time, and then perform a change of variables in the time coordinate (with the new time variable t’ related to the old one t by, say, ")#mi("t^{\\prime} = 1 - 2^{-t}")#text("). This will give a new ODE or PDE (which, admittedly, will not be autonomous, but can be converted to an autonomous one by the usual trick of adding a “clock” variable to the system to keep track of the time variable autonomously).")

#text("One can think of an evolutionary ODE or PDE as a kind of (imperative) programming language, except that it is being executed using a continuous time model rather than a discrete time one; each equation one places in the system can be viewed as analogous to a line of instruction in a more traditional programming language.")

#text("In general, I would classify most of my commentary on my blog that is not otherwise explicitly attributed to be “folklore” by default. Indeed, making mathematical folklore explicit has always been one of the objectives of this blog.")

#text("For the specific idea that PDE and ODE can model just about any computation, I think I picked this up from multiple informal conversations with other differential equations experts (and I think I was also influenced by this ")#link("http://alanrendall.wordpress.com/2009/04/16/when-is-a-dynamical-system-empty-of-information/")[#text("this blog post by Alan Rendall")]#text(" on a closely related topic). The Math Overflow threads you cite give more formal references to this idea, though (in particular, Smale seems to have been one of the first mathematicians to prominently push this point of view).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-52169")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2011")])]

#text("Thank you.")

#text("My poor ODE skills make me slow here but it seems to me there is a problem with taking a nonsurjective change of variables. The resulting ODE, say du/dy=g(u,y) would not have a well-defined RHS for y>1, with y(t)=1-2^{-t}.")

#text("So the equation has “a priori” no solution extending past 1, a “singularity”, but solutions may be differentiably continued iff the simulated TM halts/stabilizes/tends to a limit at y=1 (t=\\infty). But this does not yield a differential equation with a well-defined RHS that has smooth solutions for all time iff the corresponding TM halts.")

#text("However no need to reply. I guess I am probably mistaken, and there must be tons of fancy and insightful constructions in the literature that I should read, before abusing further.")

#text("Thank you again.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The “no self-defeating object” argument, and the vagueness paradox « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-47954")[#strong[#text("The “no self-defeating object” argument, and the vagueness paradox « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2010")])]

#text("[…] is the third in a series of posts on the “no self-defeating object” argument in mathematics – a powerful […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt C.")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-48975")[#strong[#text("Matt C.")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2010")])]

#text("All I will say is that Cantor’s results are highly suspect, given that he assumed completed infinity to make the argument. Using reductio ad absurdum means that at least one premise is incorrect. Ridding the idea of a mapping hardly gets rid of paradox. Assuming the results about transfinite ordinals by way of Cantor’s argument, we can see that it defeats itself in relying on the ordering of the list. Getting rid of completed infinity, on the other hand, does eliminate many paradoxes. Infinite sets in extension and completed infinite processes were ridded from mathematics for a very good reason.")

#text("“we can, I think, convince ourselves that all the remarkable problems and discoveries of the Foundations of Mathematics, the paradoxes of the theory of aggregates, Russell’s theory of types, with its axiom of reducibility, Cantor’s arithmetic of transfinite numbers, with its insoluble problems such as the ” continuum problem “, the problems connected with functions in extension and the multiplicative axiom- all these merely express in one way or another the well-known difficulties which arise when we attempt to treat an infinite process as completed.”")#linebreak()#text(" ")#link("http://www.jstor.org/stable/2250384")[#text("http://www.jstor.org/stable/2250384")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-50363")[#strong[#text("Finite Sets | Poincare's Paradise")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2011")]

#text("[…] links are link1,link2,link3. By going through these links we can understand how this method has been used in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-59938")[#strong[#text("Self-Defeating Sentences « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")]

#text("[…] that straightforward attempts to prove circuit lower bounds are self-defeating. This suggests the need for new ideas. In a fight-fire-with-fire mood, we hope that exploring the arena of self-defeat will […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db518652cc3070afcdabaa00554b256190b351b0c4b9c71591e17406f7c13d2c-3aeee3abec9d9c13ede67bd756ec0d9e752e956fb03715ee421141933f4762d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Itai Bar-Natan")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-70328")[#strong[#text("Itai Bar-Natan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("In remark 11 you claim that a consistent axiom system cannot prove it’s own inconsistency. This is incorrect. For example, the system PA+not(Con(PA)) is consistent, because if it isn’t consistent then it is possible to prove in PA the statement Con(PA) (by contradiction). However, not(Con(PA)) implies not(Con( PA+not(Con(PA)) )), so this system disproves it’s own consistency. Note that while in this system it’s possible to prove “There is an n which is a Godel number of a proof of 0=1 in PA”, for any specific n it is possible to prove that “n isn’t a Godel number of a proof of 0=1 in PA”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-70333")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("PA + not(Con(PA)) does not model the standard natural numbers ")#mi("{\\bf N}")#text(" (all its models are nonstandard).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06a0f9a2923198f2285100d9e3e689827039aaeeb0acbce5c98c8d4ea5e4064e-47bdd26f554020be44a3e0ff25c059c59181867ff559e503932fba42a2bc037a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Varun")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-79028")[#strong[#text("Varun")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2011")])]

#text("Ahh, I had failed to notice that the x in A_x is the same as the one in the set’s membership definition. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-89384")[#strong[#text("Basic logic — relationships between statements — converses and contrapositives « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2011")]

#text("[…] and from that you proceed to deduce a contradiction: that is, you deduce a statement and its negation. There is an interesting discussion of this difference at Mathoverflow, which also contains a link to a highly recommended blog post of Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-93972")[#strong[#text("indirect proofs: contrapositives vs. proofs by contradiction « Sebastian Pokutta’s Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2011")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")]#text(" Advertisement Eco World Content From Across The Internet. Featured on EcoPressed \"Something in the Environment\" Share this:DiggRedditFacebookTwitterLike this:LikeBe the first to like this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b7f8b21ef24b23090030fff21f49e44a2834d9742225aac6fa3bb2b52eec690-601240e65c5f2c19051ec7418b5314fc7f344b3385d9d8f0a405a9420b695948.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doglas")]], [#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/comment-page-1/#comment-94912")[#strong[#text("Doglas")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2011")])]

#text("thank you for this interesting article.. have learnt a lot.")
]
