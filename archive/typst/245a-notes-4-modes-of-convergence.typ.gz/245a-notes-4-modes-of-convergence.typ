// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/
// Converted to Typst by tao2typ: "2026-10-14T09:03:22.161460+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245A, Notes 4: Modes of convergence", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245A, Notes 4: Modes of convergence")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 October 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/")[#text("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("If one has a sequence ")#mi("{x_1, x_2, x_3, \\ldots \\in {\\bf R}}")#text(" of real numbers ")#mi("{x_n}")#text(", it is unambiguous what it means for that sequence to converge to a limit ")#mi("{x \\in {\\bf R}}")#text(": it means that for every ")#mi("{\\varepsilon > 0}")#text(", there exists an ")#mi("{N}")#text(" such that ")#tao-math("{\\left|x_n-x\\right| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{n > N}")#text(". Similarly for a sequence ")#mi("{z_1, z_2, z_3, \\ldots \\in {\\bf C}}")#text(" of complex numbers ")#mi("{z_n}")#text(" converging to a limit ")#mi("{z \\in {\\bf C}}")#text(".")

#text("More generally, if one has a sequence ")#mi("{v_1, v_2, v_3, \\ldots}")#text(" of ")#mi("{d}")#text("-dimensional vectors ")#mi("{v_n}")#text(" in a real vector space ")#mi("{{\\bf R}^d}")#text(" or complex vector space ")#mi("{{\\bf C}^d}")#text(", it is also unambiguous what it means for that sequence to converge to a limit ")#mi("{v \\in {\\bf R}^d}")#text(" or ")#mi("{v \\in {\\bf C}^d}")#text("; it means that for every ")#mi("{\\varepsilon > 0}")#text(", there exists an ")#mi("{N}")#text(" such that ")#tao-math("{\\left\\|v_n-v\\right\\| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{n \\geq N}")#text(". Here, the norm ")#tao-math("{\\left\\|v\\right\\|}", block: false)#text(" of a vector ")#mi("{v = (v^{(1)},\\ldots,v^{(d)})}")#text(" can be chosen to be the Euclidean norm ")#tao-math("{\\left\\|v\\right\\|_2 := (\\sum_{j=1}^d (v^{(j)})^2)^{1/2}}", block: false)#text(", the supremum norm ")#tao-math("{\\left\\|v\\right\\|_\\infty := \\sup_{1 \\leq j \\leq d} \\left|v^{(j)}\\right|}", block: false)#text(", or any other number of norms, but for the purposes of convergence, these norms are all ")#emph[#text("equivalent")]#text("; a sequence of vectors converges in the Euclidean norm if and only if it converges in the supremum norm, and similarly for any other two norms on the finite-dimensional space ")#mi("{{\\bf R}^d}")#text(" or ")#mi("{{\\bf C}^d}")#text(".")

#text("If however one has a sequence ")#mi("{f_1, f_2, f_3, \\ldots}")#text(" of functions ")#mi("{f_n: X \\rightarrow {\\bf R}}")#text(" or ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" on a common domain ")#mi("{X}")#text(", and a putative limit ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" or ")#mi("{f: X \\rightarrow {\\bf C}}")#text(", there can now be many different ways in which the sequence ")#mi("{f_n}")#text(" may or may not converge to the limit ")#mi("{f}")#text(". (One could also consider convergence of functions ")#mi("{f_n: X_n \\rightarrow {\\bf C}}")#text(" on different domains ")#mi("{X_n}")#text(", but we will not discuss this issue at all here.) This is contrast with the situation with scalars ")#mi("{x_n}")#text(" or ")#mi("{z_n}")#text(" (which corresponds to the case when ")#mi("{X}")#text(" is a single point) or vectors ")#mi("{v_n}")#text(" (which corresponds to the case when ")#mi("{X}")#text(" is a finite set such as ")#mi("{\\{1,\\ldots,d\\}}")#text("). Once ")#mi("{X}")#text(" becomes infinite, the functions ")#mi("{f_n}")#text(" acquire an infinite number of degrees of freedom, and this allows them to approach ")#mi("{f}")#text(" in any number of inequivalent ways.")

#text("What different types of convergence are there? As an undergraduate, one learns of the following two basic ")#link("http://en.wikipedia.org/wiki/Modes_of_convergence")[#text("modes of convergence")]#text(":")

#enum(start: 1, 
[#text("We say that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" ")#link("http://en.wikipedia.org/wiki/Pointwise_convergence")[#text("pointwise")]#text(" if, for every ")#mi("{x \\in X}")#text(", ")#mi("{f_n(x)}")#text(" converges to ")#mi("{f(x)}")#text(". In other words, for every ")#mi("{\\varepsilon > 0}")#text(" and ")#mi("{x \\in X}")#text(", there exists ")#mi("{N}")#text(" (that depends on ")#emph[#text("both")]#text(" ")#mi("{\\varepsilon}")#text(" and ")#mi("{x}")#text(") such that ")#tao-math("{\\left|f_n(x)-f(x)\\right| \\leq \\varepsilon}", block: false)#text(" whenever ")#mi("{n \\geq N}")#text(".")],
[#text("We say that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" ")#link("http://en.wikipedia.org/wiki/Uniform_convergence")[#text("uniformly")]#text(" if, for every ")#mi("{\\varepsilon > 0}")#text(", there exists ")#mi("{N}")#text(" such that for every ")#mi("{n \\geq N}")#text(", ")#tao-math("{\\left|f_n(x) - f(x)\\right| \\leq \\varepsilon}", block: false)#text(" for every ")#mi("{x \\in X}")#text(". The difference between uniform convergence and pointwise convergence is that with the former, the time ")#mi("{N}")#text(" at which ")#mi("{f_n(x)}")#text(" must be permanently ")#mi("{\\varepsilon}")#text("-close to ")#mi("{f(x)}")#text(" is not permitted to depend on ")#mi("{x}")#text(", but must instead be chosen uniformly in ")#mi("{x}")#text(".")]
)

#text("Uniform convergence implies pointwise convergence, but not conversely. A typical example: the functions ")#mi("{f_n: {\\bf R} \\rightarrow {\\bf R}}")#text(" defined by ")#mi("{f_n(x) := x/n}")#text(" converge pointwise to the zero function ")#mi("{f(x) := 0}")#text(", but not uniformly.")

#text("However, pointwise and uniform convergence are only two of dozens of many other modes of convergence that are of importance in analysis. We will not attempt to exhaustively enumerate these modes here (but see ")#link("http://en.wikipedia.org/wiki/Modes_of_convergence_(annotated_index)")[#text("this Wikipedia page")]#text(", and see also ")#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")[#text("these 245B notes on strong and weak convergence")]#text("). We will, however, discuss some of the modes of convergence that arise from measure theory, when the domain ")#mi("{X}")#text(" is equipped with the structure of a measure space ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(", and the functions ")#mi("{f_n}")#text(" (and their limit ")#mi("{f}")#text(") are measurable with respect to this space. In this context, we have some additional modes of convergence:")

#enum(start: 1, 
[#text("We say that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" ")#link("http://en.wikipedia.org/wiki/Almost_everywhere_convergence")[#text("pointwise almost everywhere")]#text(" if, for (")#mi("{\\mu}")#text("-)almost everywhere ")#mi("{x \\in X}")#text(", ")#mi("{f_n(x)}")#text(" converges to ")#mi("{f(x)}")#text(".")],
[#text("We say that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" ")#emph[#text("uniformly almost everywhere")]#text(", ")#emph[#text("essentially uniformly")]#text(", or ")#emph[#text("in ")#mi("{L^\\infty}")#text(" norm")]#text(" if, for every ")#mi("{\\varepsilon > 0}")#text(", there exists ")#mi("{N}")#text(" such that for every ")#mi("{n \\geq N}")#text(", ")#tao-math("{\\left|f_n(x) - f(x)\\right| \\leq \\varepsilon}", block: false)#text(" for ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(".")],
[#text("We say that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" ")#emph[#text("almost uniformly")]#text(" if, for every ")#mi("{\\varepsilon > 0}")#text(", there exists an exceptional set ")#mi("{E \\in {\\mathcal B}}")#text(" of measure ")#mi("{\\mu(E) \\leq \\varepsilon}")#text(" such that ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(" on the complement of ")#mi("{E}")#text(".")],
[#text("We say that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" ")#link("http://en.wikipedia.org/wiki/Lp_space")[#text("in ")#mi("{L^1}")#text(" norm")]#text(" if the quantity ")#tao-math("{\\left\\|f_n-f\\right\\|_{L^1(\\mu)} = \\int_X |f_n(x)-f(x)|\\ d\\mu}", block: false)#text(" converges to ")#mi("{0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#text("We say that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" ")#link("http://en.wikipedia.org/wiki/Convergence_in_measure")[#text("in measure")]#text(" if, for every ")#mi("{\\varepsilon > 0}")#text(", the measures ")#tao-math("{\\mu( \\{ x \\in X: \\left|f_n(x) - f(x)\\right| \\geq \\varepsilon \\} )}", block: false)#text(" converge to zero as ")#mi("{n \\rightarrow \\infty}")#text(".")]
)

#text("Observe that each of these five modes of convergence is unaffected if one modifies ")#mi("{f_n}")#text(" or ")#mi("{f}")#text(" on a set of measure zero. In contrast, the pointwise and uniform modes of convergence can be affected if one modifies ")#mi("{f_n}")#text(" or ")#mi("{f}")#text(" even on a single point.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In the context of probability theory, in which ")#mi("{f_n}")#text(" and ")#mi("{f}")#text(" are interpreted as random variables, convergence in ")#mi("{L^1}")#text(" norm is often referred to as ")#link("http://en.wikipedia.org/wiki/Convergence_in_mean#Convergence_in_mean")[#text("convergence in mean")]#text(", pointwise convergence almost everywhere is often referred to as ")#link("http://en.wikipedia.org/wiki/Convergence_in_mean#Almost_sure_convergence")[#text("almost sure convergence")]#text(", and convergence in measure is often referred to as ")#link("http://en.wikipedia.org/wiki/Convergence_in_mean#Convergence_in_probability")[#text("convergence in probability")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Linearity of convergence)")]#text(" ")#metadata(none) <tao-7f2fe580edb35154041f>#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, let ")#mi("{f_n, g_n: X \\rightarrow {\\bf C}}")#text(" be sequences of measurable functions, and let ")#mi("{f, g: X \\rightarrow {\\bf C}}")#text(" be measurable functions.")

#enum(start: 1, 
[#text("Show that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" along one of the above seven modes of convergence if and only if ")#tao-math("{\\left|f_n-f\\right|}", block: false)#text(" converges to ")#mi("{0}")#text(" along the same mode.")],
[#text("If ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" along one of the above seven modes of convergence, and ")#mi("{g_n}")#text(" converges to ")#mi("{g}")#text(" along the same mode, show that ")#mi("{f_n+g_n}")#text(" converges to ")#mi("{f+g}")#text(" along the same mode, and that ")#mi("{cf_n}")#text(" converges to ")#mi("{cf}")#text(" along the same mode for any ")#mi("{c \\in {\\bf C}}")#text(".")],
[#text("(Squeeze test) If ")#mi("{f_n}")#text(" converges to ")#mi("{0}")#text(" along one of the above seven modes, and ")#tao-math("{\\left|g_n\\right| \\leq f_n}", block: false)#text(" pointwise for each ")#mi("{n}")#text(", show that ")#mi("{g_n}")#text(" converges to ")#mi("{0}")#text(" along the same mode.")]
)
]

#text("We have some easy implications between modes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Easy implications)")]#text(" ")#metadata(none) <tao-97c10efe01d5c9c88704>#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu)}")#text(" be a measure space, and let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" and ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be measurable functions.")

#enum(start: 1, 
[#text("If ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" uniformly, then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" pointwise.")],
[#text("If ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" uniformly, then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^\\infty}")#text(" norm. Conversely, if ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^\\infty}")#text(" norm, then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" uniformly outside of a null set (i.e. there exists a null set ")#mi("{E}")#text(" such that the restriction ")#mi("{f_n\\downharpoonright_{X \\backslash E}}")#text(" of ")#mi("{f_n}")#text(" to the complement of ")#mi("{E}")#text(" converges to the restriction ")#mi("{f\\downharpoonright_{X \\backslash E}}")#text(" of ")#mi("{f}")#text(").")],
[#text("If ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^\\infty}")#text(" norm, then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" almost uniformly.")],
[#text("If ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" almost uniformly, then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" pointwise almost everywhere.")],
[#text("If ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" pointwise, then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" pointwise almost everywhere.")],
[#text("If ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^1}")#text(" norm, then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in measure.")],
[#text("If ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" almost uniformly, then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in measure.")]
)
]

#text("The reader is encouraged to draw a diagram that summarises the logical implications between the seven modes of convergence that the above exercise describes.")

#text("We give four key examples that distinguish between these modes, in the case when ")#mi("{X}")#text(" is the real line ")#mi("{{\\bf R}}")#text(" with Lebesgue measure. The first three of these examples already were introduced in the ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("previous set of notes")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4 (Escape to horizontal infinity)")]#text(" Let ")#mi("{f_n := 1_{[n,n+1]}}")#text(". Then ")#mi("{f_n}")#text(" converges to zero pointwise (and thus, pointwise almost everywhere), but not uniformly, in ")#mi("{L^\\infty}")#text(" norm, almost uniformly, in ")#mi("{L^1}")#text(" norm, or in measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5 (Escape to width infinity)")]#text(" Let ")#mi("{f_n := \\frac{1}{n} 1_{[0,n]}}")#text(". Then ")#mi("{f_n}")#text(" converges to zero uniformly (and thus, pointwise, pointwise almost everywhere, in ")#mi("{L^\\infty}")#text(" norm, almost uniformly, and in measure), but not in ")#mi("{L^1}")#text(" norm.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6 (Escape to vertical infinity)")]#text(" Let ")#mi("{f_n := n 1_{[\\frac{1}{n}, \\frac{2}{n}]}}")#text(". Then ")#mi("{f_n}")#text(" converges to zero pointwise (and thus, pointwise almost everywhere) and almost uniformly (and hence in measure), but not uniformly, in ")#mi("{L^\\infty}")#text(" norm, or in ")#mi("{L^1}")#text(" norm.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7 (Typewriter sequence)")]#text(" Let ")#mi("{f_n}")#text(" be defined by the formula")

#align(center)[#tao-fit-display[#mitex("f_n := 1_{[\\frac{n-2^k}{2^k}, \\frac{n-2^k+1}{2^k}]}")]]

#text("whenever ")#mi("{k \\geq 0}")#text(" and ")#mi("{2^k \\leq n < 2^{k+1}}")#text(". This is a sequence of indicator functions of intervals of decreasing length, marching across the unit interval ")#mi("{[0,1]}")#text(" over and over again. Then ")#mi("{f_n}")#text(" converges to zero in measure and in ")#mi("{L^1}")#text(" norm, but not pointwise almost everywhere (and hence also not pointwise, not almost uniformly, nor in ")#mi("{L^\\infty}")#text(" norm, nor uniformly).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The ")#emph[#mi("{L^\\infty}")#text(" norm")]#text(" ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(\\mu)}}", block: false)#text(" of a measurable function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" is defined to the infimum of all the quantities ")#mi("{M \\in [0,+\\infty]}")#text(" that are ")#emph[#text("essential upper bounds")]#text(" for ")#mi("{f}")#text(" in the sense that ")#tao-math("{\\left|f(x)\\right| \\leq M}", block: false)#text(" for almost every ")#mi("{x}")#text(". Then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^\\infty}")#text(" norm if and only if ")#tao-math("{\\left\\|f_n-f\\right\\|_{L^\\infty(\\mu)} \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". The ")#mi("{L^\\infty}")#text(" and ")#mi("{L^1}")#text(" norms are part of the larger family of ")#link("http://en.wikipedia.org/wiki/Lp_space")[#mi("{L^p}")#text(" norms")]#text(", which we will study in more detail ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("in 245B")]#text(".")
]

#text("One particular advantage of ")#mi("{L^1}")#text(" convergence is that, in the case when the ")#mi("{f_n}")#text(" are absolutely integrable, it implies convergence of the integrals,")

#align(center)[#tao-fit-display[#mitex("\\int_X f_n\\ d\\mu \\rightarrow \\int_X f\\ d\\mu,")]]

#text("as one sees from the triangle inequality. Unfortunately, none of the other modes of convergence automatically imply this convergence of the integral, as the above examples show.")#linebreak()#text(" The purpose of these notes is to compare these modes of convergence with each other. Unfortunately, the relationship between these modes is not particularly simple; unlike the situation with pointwise and uniform convergence, one cannot simply rank these modes in a linear order from strongest to weakest. This is ultimately because the different modes react in different ways to the three “escape to infinity” scenarios described above, as well as to the “typewriter” behaviour when a single set is “overwritten” many times. On the other hand, if one imposes some additional assumptions to shut down one or more of these escape to infinity scenarios, such as a finite measure hypothesis ")#mi("{\\mu(X) < \\infty}")#text(" or a ")#link("http://en.wikipedia.org/wiki/Uniformly_integrable")[#text("uniform integrability hypothesis")]#text(", then one can obtain some additional implications between the different modes.")

#metadata(none) <tao-724d14066d29ff8cfbd7>

#heading(level: 1)[#strong[#text(" — 1. Uniqueness — ")]]

#text("Throughout these notes, ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" denotes a measure space. We abbreviate “")#mi("{\\mu}")#text("-almost everywhere” as “almost everywhere” throughout.")

#text("Even though the modes of convergence all differ from each other, they are all ")#emph[#text("compatible")]#text(" in the sense that they never disagree about ")#emph[#text("which")]#text(" function ")#mi("{f}")#text(" a sequence of functions ")#mi("{f_n}")#text(" converges to, outside of a set of measure zero. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" Let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions, and let ")#mi("{f, g: X \\rightarrow {\\bf C}}")#text(" be two additional measurable functions. Suppose that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" along one of the seven modes of convergence defined above, and ")#mi("{f_n}")#text(" converges to ")#mi("{g}")#text(" along another of the seven modes of convergence (or perhaps the same mode of convergence as for ")#mi("{f}")#text("). Then ")#mi("{f}")#text(" and ")#mi("{g}")#text(" agree almost everywhere.")
]

#text("Note that the conclusion is the best one can hope for in the case of the last five modes of convergence, since as remarked earlier, these modes of convergence are unaffected if one modifies ")#mi("{f}")#text(" or ")#mi("{g}")#text(" on a set of measure zero.")

#emph[#text("Proof:")]#text(" In view of Exercise ")#link(<tao-97c10efe01d5c9c88704>)[#text("3")]#text(", we may assume that ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" either pointwise almost everywhere, or in measure, and similarly that ")#mi("{f_n}")#text(" converges to ")#mi("{g}")#text(" either pointwise almost everywhere, or in measure.")

#text("Suppose first that ")#mi("{f_n}")#text(" converges to both ")#mi("{f}")#text(" and ")#mi("{g}")#text(" pointwise almost everywhere. Then by Exercise ")#link(<tao-7f2fe580edb35154041f>)[#text("2")]#text(", ")#mi("{0}")#text(" converges to ")#mi("{f-g}")#text(" pointwise almost everywhere, which clearly implies that ")#mi("{f-g}")#text(" is zero almost everywhere, and the claim follows. A similar argument applies if ")#mi("{f_n}")#text(" converges to both ")#mi("{f}")#text(" and ")#mi("{g}")#text(" in measure.")

#text("By symmetry, the only remaining case that needs to be considered is when ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" pointwise almost everywhere, and ")#mi("{f_n}")#text(" converges to ")#mi("{g}")#text(" in measure. We need to show that ")#mi("{f=g}")#text(" almost everywhere. It suffices to show that for every ")#mi("{\\varepsilon>0}")#text(", that ")#tao-math("{\\left|f(x)-g(x)\\right| \\leq \\varepsilon}", block: false)#text(" for almost every ")#mi("{x}")#text(", as the claim then follows by setting ")#mi("{\\varepsilon = 1/m}")#text(" for ")#mi("{m=1,2,3,\\ldots}")#text(" and using the fact that the countable union of null sets is again a null set.")

#text("Fix ")#mi("{\\varepsilon>0}")#text(", and let ")#tao-math("{A := \\{ x \\in X: \\left|f(x)-g(x)\\right| > \\varepsilon \\}}", block: false)#text(". This is a measurable set; our task is to show that it has measure zero. Suppose for contradiction that ")#mi("{\\mu(A) > 0}")#text(". We consider the sets")

#align(center)[#tao-fit-display[#tao-math("A_N := \\{ x \\in A: \\left|f_n(x)-f(x)\\right| \\leq \\varepsilon/2 \\text{ for all } n \\geq N \\}.", block: true)]]

#text("These are measurable sets that are increasing in ")#mi("{N}")#text(". As ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" almost everywhere, we see that almost every ")#mi("{x \\in A}")#text(" belongs to at least one of the ")#mi("{A_N}")#text(", thus ")#mi("{\\bigcup_{N=1}^\\infty A_N}")#text(" is equal to ")#mi("{A}")#text(" outside of a null set. In particular,")

#align(center)[#tao-fit-display[#mitex("\\mu( \\bigcup_{N=1}^\\infty A_N ) > 0.")]]

#text("Applying monotone convergence for sets, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\mu(A_N) > 0")]]

#text("for some finite ")#mi("{N}")#text(". But by the triangle inequality, we have ")#tao-math("{\\left|f_n(x)-g(x)\\right| > \\varepsilon/2}", block: false)#text(" for all ")#mi("{x \\in A_N}")#text(" and all ")#mi("{n \\geq N}")#text(". As a consequence, ")#mi("{f_n}")#text(" cannot converge in measure to ")#mi("{g}")#text(", which gives the desired contradiction. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. The case of a step function — ")]]

#text("One way to appreciate the distinctions between the above modes of convergence is to focus on the case when ")#mi("{f=0}")#text(", and when each of the ")#mi("{f_n}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Step_function")[#text("step function")]#text(", by which we mean a constant multiple ")#mi("{f_n = A_n 1_{E_n}}")#text(" of a measurable set ")#mi("{E_n}")#text(". For simplicity we will assume that the ")#mi("{A_n > 0}")#text(" are positive reals, and that the ")#mi("{E_n}")#text(" have a positive measure ")#mi("{\\mu(E_n) > 0}")#text(". We also assume the ")#mi("{A_n}")#text(" exhibit one of two modes of behaviour: either the ")#mi("{A_n}")#text(" converge to zero, or else they are bounded away from zero (i.e. there exists ")#mi("{c>0}")#text(" such that ")#mi("{A_n \\geq c}")#text(" for every ")#mi("{n}")#text(". It is easy to see that if a sequence ")#mi("{A_n}")#text(" does not converge to zero, then it has a subsequence that is bounded away from zero, so it does not cause too much loss of generality to restrict to one of these two cases.")

#text("Given such a sequence ")#mi("{f_n = A_n 1_{E_n}}")#text(" of step functions, we now ask, for each of the seven modes of convergence, what it means for this sequence to converge to zero along that mode. It turns out that the answer to question is controlled more or less completely by the following three quantities:")

#list(
[#text("The ")#emph[#text("height")]#text(" ")#mi("{A_n}")#text(" of the ")#mi("{n^{th}}")#text(" function ")#mi("{f_n}")#text(";")],
[#text("The ")#emph[#text("width")]#text(" ")#mi("{\\mu(E_n)}")#text(" of the ")#mi("{n^{th}}")#text(" function ")#mi("{f_n}")#text("; and")],
[#text("The ")#mi("{N^{th}}")#text(" ")#emph[#text("tail support")]#text(" ")#mi("{E^*_N := \\bigcup_{n \\geq N} E_n}")#text(" of the sequence ")#mi("{f_1, f_2, f_3, \\ldots}")#text(".")]
)

#text("Indeed, we have:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Convergence for step functions)")]#text(" ")#metadata(none) <tao-3e64cc41cf8e07b43936>#text(" Let the notation and assumptions be as above. Establish the following claims:")

#enum(start: 1, 
[#mi("{f_n}")#text(" converges uniformly to zero if and only if ")#mi("{A_n \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#mi("{f_n}")#text(" converges in ")#mi("{L^\\infty}")#text(" norm to zero if and only if ")#mi("{A_n \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#mi("{f_n}")#text(" converges almost uniformly to zero if and only if ")#mi("{A_n \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", or ")#mi("{\\mu(E^*_N) \\rightarrow 0}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(".")],
[#mi("{f_n}")#text(" converges pointwise to zero if and only if ")#mi("{A_n \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", or ")#mi("{\\bigcap_{N=1}^\\infty E^*_N = \\emptyset}")#text(".")],
[#mi("{f_n}")#text(" converges pointwise almost everywhere to zero if and only if ")#mi("{A_n \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", or ")#mi("{\\bigcap_{N=1}^\\infty E^*_N}")#text(" is a null set.")],
[#mi("{f_n}")#text(" converges in measure to zero if and only if ")#mi("{A_n \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", or ")#mi("{\\mu(E_n) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#mi("{f_n}")#text(" converges in ")#mi("{L^1}")#text(" norm if and only if ")#mi("{A_n \\mu(E_n) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")]
)
]

#text("To put it more informally: when the height goes to zero, then one has convergence to zero in all modes except possibly for ")#mi("{L^1}")#text(" convergence, which requires that the product of the height and the width goes to zero. If instead the height is bounded away from zero and the width is positive, then we never have uniform or ")#mi("{L^\\infty}")#text(" convergence, but we have convergence in measure if the width goes to zero, we have almost uniform convergence if the tail support (which has larger measure than the width) has measure that goes to zero, we have pointwise almost everywhere convergence if the tail support shrinks to a null set, and pointwise convergence if the tail support shrinks to the empty set.")

#text("It is instructive to compare this exercise with Exercise ")#link(<tao-97c10efe01d5c9c88704>)[#text("3")]#text(", or with the four examples given in the introduction. In particular:")

#list(
[#text("In the escape to horizontal infinity scenario, the height and width do not shrink to zero, but the tail set shrinks to the empty set (while remaining of infinite measure throughout).")],
[#text("In the escape to width infinity scenario, the height goes to zero, but the width (and tail support) go to infinity, causing the ")#mi("{L^1}")#text(" norm to stay bounded away from zero.")],
[#text("In the escape to vertical infinity, the height goes to infinity, but the width (and tail support) go to zero (or the empty set), causing the ")#mi("{L^1}")#text(" norm to stay bounded away from zero.")],
[#text("In the typewriter example, the width goes to zero, but the height and the tail support stay fixed (and thus bounded away from zero).")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" The monotone convergence theorem can also be specialised to this case. Observe that the ")#mi("{f_n = A_n 1_{E_n}}")#text(" are monotone increasing if and only if ")#mi("{A_n \\leq A_{n+1}}")#text(" and ")#mi("{E_n \\subset E_{n+1}}")#text(" for each ")#mi("{n}")#text(". In such cases, observe that the ")#mi("{f_n}")#text(" converge pointwise to ")#mi("{f := A 1_E}")#text(", where ")#mi("{A := \\lim_{n \\rightarrow \\infty} A_n}")#text(" and ")#mi("{E := \\bigcup_{n=1}^\\infty E_n}")#text(". The monotone convergence theorem then asserts that ")#mi("{A_n \\mu(E_n) \\rightarrow A \\mu(E)}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", which is a consequence of the monotone convergence theorem ")#mi("{\\mu(E_n) \\rightarrow \\mu(E)}")#text(" for sets.")
]

#heading(level: 1)[#strong[#text(" — 3. Finite measure spaces — ")]]

#text("The situation simplifies somewhat if the space ")#mi("{X}")#text(" has finite measure (and in particular, in the case when ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text("). This shuts down two of the four examples (namely, escape to horizontal infinity or width infinity) and creates a few more equivalences. Indeed, from ")#link("http://en.wikipedia.org/wiki/Egorov's_theorem")[#text("Egorov’s theorem")]#text(" (Exercise 30 from ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text("), we now have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Egorov’s theorem, again)")]#text(" Let ")#mi("{X}")#text(" have finite measure, and let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" and ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be measurable functions. Then ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" pointwise almost everywhere if and only if ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" almost uniformly.")
]

#text("Note that when one specialises to step functions using Exercise ")#link(<tao-3e64cc41cf8e07b43936>)[#text("10")]#text(", then Egorov’s theorem collapses to the downward monotone convergence property for sets (Exercise 23 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text(").")

#text("Another nice feature of the finite measure case is that ")#mi("{L^\\infty}")#text(" convergence implies ")#mi("{L^1}")#text(" convergence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{X}")#text(" have finite measure, and let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" and ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be measurable functions. Show that if ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^\\infty}")#text(" norm, then ")#mi("{f_n}")#text(" also converges to ")#mi("{f}")#text(" in ")#mi("{L^1}")#text(" norm.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{X}")#text(" be a probability space. Given any real-valued measurable function ")#mi("{f: X \\rightarrow {\\bf R}}")#text(", we define the ")#link("http://en.wikipedia.org/wiki/Cumulative_distribution_function")[#text("cumulative distribution function")]#text(" ")#mi("{F: {\\bf R} \\rightarrow [0,1]}")#text(" of ")#mi("{f}")#text(" to be the function ")#mi("{F(\\lambda) := \\mu( \\{x \\in X: f(x) \\leq \\lambda \\} )}")#text(". Given another sequence ")#mi("{f_n: X \\rightarrow {\\bf R}}")#text(" of real-valued measurable functions, we say that ")#mi("{f_n}")#text(" ")#link("http://en.wikipedia.org/wiki/Convergence_of_random_variables#Convergence_in_distribution")[#text("converges in distribution")]#text(" to ")#mi("{f}")#text(" if the cumulative distribution function ")#mi("{F_n(\\lambda)}")#text(" of ")#mi("{f_n}")#text(" converges pointwise to the cumulative distribution function ")#mi("{F(\\lambda)}")#text(" of ")#mi("{f}")#text(" at all ")#mi("{\\lambda \\in {\\bf R}}")#text(" for which ")#mi("{F}")#text(" is continuous.")

#enum(start: 1, 
[#text("Show that if ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in any of the seven senses discussed above (uniformly, essentially uniformly, almost uniformly pointwise, pointwise almost everywhere, in ")#mi("{L^1}")#text(", or in measure), then it converges in distribution to ")#mi("{f}")#text(".")],
[#text("Give an example in which ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in distribution, but not in any of the above seven senses.")],
[#text("Show that convergence in distribution is not linear, in the sense that if ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in distribution, and ")#mi("{g_n}")#text(" converges to ")#mi("{g}")#text(", then ")#mi("{f_n+g_n}")#text(" need not converge to ")#mi("{f+g}")#text(".")],
[#text("Show that a sequence ")#mi("{f_n}")#text(" can converge in distribution to two different limits ")#mi("{f, g}")#text(", which are not equal almost everywhere.")]
)

#text("Convergence in distribution (not to be confused with convergence in the sense of ")#link("http://en.wikipedia.org/wiki/Distribution_(mathematics)")[#text("distributions")]#text(", which we will study ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("later in this sequence")]#text(") is commonly used in probability; but, as the above exercise demonstrates, it is quite a weak notion of convergence, lacking many of the properties of the modes of convergence discussed here.")
]

#heading(level: 1)[#strong[#text(" — 4. Fast convergence — ")]]

#text("The typewriter example shows that ")#mi("{L^1}")#text(" convergence is not strong enough to force almost uniform or pointwise almost everywhere convergence. However, this can be rectified if one assumes that the ")#mi("{L^1}")#text(" convergence is sufficiently fast:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Fast ")#mi("{L^1}")#text(" convergence)")]#text(" Suppose that ")#mi("{f_n, f: X \\rightarrow {\\bf C}}")#text(" are measurable functions such that ")#tao-math("{\\sum_{n=1}^\\infty \\left\\|f_n-f\\right\\|_{L^1(\\mu)} < \\infty}", block: false)#text("; thus, not only do the quantities ")#tao-math("{\\left\\|f_n-f\\right\\|_{L^1(\\mu)}}", block: false)#text(" go to zero (which would mean ")#mi("{L^1}")#text(" convergence), but they converge in an absolutely summable fashion.")

#enum(start: 1, 
[#text("Show that ")#mi("{f_n}")#text(" converges pointwise almost everywhere to ")#mi("{f}")#text(".")],
[#text("Show that ")#mi("{f_n}")#text(" converges almost uniformly to ")#mi("{f}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" If you have trouble getting started, try working first in the special case in which ")#mi("{f_n= A_n 1_{E_n}}")#text(" are step functions and ")#mi("{f=0}")#text(" and use Exercise ")#link(<tao-3e64cc41cf8e07b43936>)[#text("10")]#text(" in order to gain some intuition. The second part of the exercise implies the first, but the first is a little easier to prove and may thus serve as a useful warmup. The ")#mi("{\\varepsilon/2^n}")#text(" trick may come in handy for the second part.)")
]

#text("As a corollary, we see that ")#mi("{L^1}")#text(" convergence implies almost uniform or pointwise almost everywhere convergence if we are allowed to pass to a subsequence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 16")]#text(" Suppose that ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" are a sequence of measurable functions that converge in ")#mi("{L^1}")#text(" norm to a limit ")#mi("{f}")#text(". Then there exists a subsequence ")#mi("{f_{n_j}}")#text(" that converges almost uniformly (and hence, pointwise almost everywhere) to ")#mi("{f}")#text(" (while remaining convergent in ")#mi("{L^1}")#text(" norm, of course).")
]

#emph[#text("Proof:")]#text(" Since ")#tao-math("{\\left\\|f_n-f\\right\\|_{L^1(\\mu)} \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", we can select ")#mi("{n_1 < n_2 < n_3 < \\ldots}")#text(" such that ")#tao-math("{\\left\\|f_{n_j} - f\\right\\|_{L^1(\\mu)} \\leq 2^{-j}}", block: false)#text(" (say). This is enough for the previous exercise to apply. ")#mi("\\Box")

#text("Actually, one can strengthen this corollary a bit by relaxing ")#mi("{L^1}")#text(" convergence to convergence in measure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-7818799270c5ffdc89f2>#text(" Suppose that ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" are a sequence of measurable functions that converge in measure to a limit ")#mi("{f}")#text(". Then there exists a subsequence ")#mi("{f_{n_j}}")#text(" that converges almost uniformly (and hence, pointwise almost everywhere) to ")#mi("{f}")#text(". (")#emph[#text("Hint:")]#text(" Choose the ")#mi("{n_j}")#text(" so that the sets ")#tao-math("{\\{ x \\in X: \\left|f_{n_j}(x) - f(x)\\right| > 1/j \\}}", block: false)#text(" have a suitably small measure.)")
]

#text("It is instructive to see how this subsequence is extracted in the case of the typewriter sequence. In general, one can view the operation of passing to a subsequence as being able to eliminate “typewriter” situations in which the tail support is much larger than the width.")

#heading(level: 1)[#strong[#text(" — 5. Domination and uniform integrability — ")]]

#text("Now we turn to the reverse question, of whether almost uniform convergence, pointwise almost everywhere convergence, or convergence in measure can imply ")#mi("{L^1}")#text(" convergence. The escape to vertical and width infinity examples shows that without any further hypotheses, the answer to this question is no. However, one can do better if one places some ")#emph[#text("domination")]#text(" hypotheses on the ")#mi("{f_n}")#text(" that shut down both of these escape routes.")

#text("We say that a sequence ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" is ")#emph[#text("dominated")]#text(" if there exists an absolutely integrable function ")#mi("{g: X \\rightarrow {\\bf C}}")#text(" such that ")#tao-math("{\\left|f_n(x)\\right| \\leq g(x)}", block: false)#text(" for all ")#mi("{n}")#text(" and almost every ")#mi("{x}")#text(". For instance, if ")#mi("{X}")#text(" has finite measure and the ")#mi("{f_n}")#text(" are uniformly bounded, then they are dominated. Observe that the sequences in the vertical and width escape to infinity examples are ")#emph[#text("not")]#text(" dominated (why?).")

#text("The ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(" (Theorem 17 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text(") then asserts that if ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" pointwise almost everywhere, then it necessarily converges to ")#mi("{f}")#text(" in ")#mi("{L^1}")#text(" norm (and hence also in measure). Here is a variant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" ")#metadata(none) <tao-f1308241eb02418033bc>#text(" Suppose that ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" are a dominated sequence of measurable functions, and let ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be another measurable function. Show that ")#mi("{f_n}")#text(" converges in ")#mi("{L^1}")#text(" norm to ")#mi("{f}")#text(" if and only if ")#mi("{f_n}")#text(" converges in measure to ")#mi("{f}")#text(". (")#emph[#text("Hint:")]#text(" one way to establish the “if” direction is first show that every subsequence of the ")#mi("{f_n}")#text(" has a further subsequence that converges in ")#mi("{L^1}")#text(" to ")#mi("{f}")#text(", using Exercise ")#link(<tao-7818799270c5ffdc89f2>)[#text("17")]#text(" and the dominated convergence theorem. Alternatively, use monotone convergence to find a set ")#mi("{E}")#text(" of finite measure such that ")#mi("{\\int_{X \\backslash E} g\\ d\\mu}")#text(", and hence ")#mi("{\\int_{X \\backslash E} f_n\\ d\\mu}")#text(" and ")#mi("{\\int_{X \\backslash E} f\\ d\\mu}")#text(", are small.)")
]

#text("There is a more general notion than domination, known as ")#link("http://en.wikipedia.org/wiki/Uniform_integrability")[#text("uniform integrability")]#text(", which serves as a substitute for domination in many (but not all) contexts.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 19 (Uniform integrability)")]#text(" A sequence ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" of absolutely integrable functions is said to be ")#emph[#text("uniformly integrable")]#text(" if the following three statements hold:")

#list(
[#text("(Uniform bound on ")#mi("{L^1}")#text(" norm) One has ")#tao-math("{\\sup_n \\left\\|f_n\\right\\|_{L^1(\\mu)} = \\sup_n \\int_X |f_n|\\ d\\mu < +\\infty}", block: false)#text(".")],
[#text("(No escape to vertical infinity) One has ")#tao-math("{\\sup_n \\int_{\\left|f_n\\right| \\geq M} |f_n|\\ d\\mu \\rightarrow 0}", block: false)#text(" as ")#mi("{M \\rightarrow +\\infty}")#text(".")],
[#text("(No escape to width or horizontal infinity) For every ")#mi("{\\varepsilon>0}")#text(", there is a finite measure subset ")#mi("{E_\\varepsilon}")#text(" of ")#mi("{X}")#text(" such that ")#mi("{\\int_{X \\backslash E_\\varepsilon} |f_n|\\ d\\mu \\leq \\varepsilon}")#text(" for all ")#mi("{n}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 20")]#text(" It is instructive to understand uniform integrability in the step function case ")#mi("{f_n = A_n 1_{E_n}}")#text(". The uniform bound on the ")#mi("{L^1}")#text(" norm then asserts that ")#mi("{A_n \\mu(E_n)}")#text(" stays bounded. The lack of escape to vertical infinity means that along any subsequence for which ")#mi("{A_n \\rightarrow \\infty}")#text(", ")#mi("{A_n \\mu(E_n)}")#text(" must go to zero. The lack of escape to width or horizontal infinity (also known as ")#link("https://en.wikipedia.org/wiki/Tightness_of_measures")[#text("tightness")]#text(") means that for any ")#mi("{\\varepsilon}")#text(", there is a finite measure set ")#mi("{E_\\varepsilon}")#text(" such that ")#mi("{A_n \\mu(E_n \\backslash E_\\varepsilon)}")#text(" is at most ")#mi("{\\varepsilon}")#text("; informally, the bulk of the ")#mi("{L^1}")#text(" mass of the ")#mi("{f_n}")#text(" is trapped inside a finite measure set.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]

#enum(start: 1, 
[#text("Show that if ")#mi("{f}")#text(" is an absolutely integrable function, then the constant sequence ")#mi("{f_n=f}")#text(" is uniformly integrable. (")#emph[#text("Hint:")]#text(" use the monotone convergence theorem.)")],
[#text("Show that every dominated sequence of measurable functions is uniformly integrable.")],
[#text("Give an example of a sequence that is uniformly integrable but not dominated.")]
)
]

#text("In the case of a finite measure space, there is no escape to width infinity, and the criterion for uniform integrability simplifies to just that of excluding vertical infinity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Suppose that ")#mi("{X}")#text(" has finite measure, and let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions. Show that ")#mi("{f_n}")#text(" is uniformly integrable if and only if ")#tao-math("{\\sup_n \\int_{\\left|f_n\\right| \\geq M} |f_n|\\ d\\mu \\rightarrow 0}", block: false)#text(" as ")#mi("{M \\rightarrow +\\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Uniform ")#mi("{L^p}")#text(" bound on finite measure implies uniform integrability)")]#text(" Suppose that ")#mi("{X}")#text(" have finite measure, let ")#mi("{1 < p < \\infty}")#text(", an d suppose that ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" is a sequence of measurable functions such that ")#tao-math("{\\sup_n \\int_X \\left|f_n\\right|^p\\ d\\mu < \\infty}", block: false)#text(". Show that the sequence ")#mi("{f_n}")#text(" is uniformly integrable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-8db59feb4d217f26c79d>#text(" Let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a uniformly integrable sequence of functions. Show that for every ")#mi("{\\varepsilon > 0}")#text(" there exists a ")#mi("{\\delta > 0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_E |f_n|\\ d\\mu \\leq \\varepsilon")]]

#text("whenever ")#mi("{n \\geq 1}")#text(" and ")#mi("{E}")#text(" is a measurable set with ")#mi("{\\mu(E) \\leq \\delta}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" This exercise is a partial converse to Exercise ")#link(<tao-8db59feb4d217f26c79d>)[#text("24")]#text(". Let ")#mi("{X}")#text(" be a probability space, and let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a sequence of absolutely integrable functions with ")#tao-math("{\\sup_n \\left\\|f_n\\right\\|_{L^1} < \\infty}", block: false)#text(". Suppose that for every ")#mi("{\\varepsilon > 0}")#text(" there exists a ")#mi("{\\delta > 0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_E |f_n|\\ d\\mu \\leq \\varepsilon")]]

#text("whenever ")#mi("{n \\geq 1}")#text(" and ")#mi("{E}")#text(" is a measurable set with ")#mi("{\\mu(E) \\leq \\delta}")#text(". Show that the sequence ")#mi("{f_n}")#text(" is uniformly integrable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" ")#metadata(none) <tao-75e3090289e2955dfaec>#text(" If ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" is a uniformly integrable sequence of functions, show that ")#tao-math("{\\sup_n \\int_{\\left|f_n\\right| \\leq \\delta} |f_n|\\ d\\mu \\rightarrow 0}", block: false)#text(" as ")#mi("{\\delta \\rightarrow 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Hunt’s definition of uniform integrability)")]#text(" Let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions. Show that ")#mi("{f_n}")#text(" is uniformly integrable if and only if for every ")#mi("{\\varepsilon>0}")#text(", there exists an absolutely integrable ")#mi("{h: X \\rightarrow [0,+\\infty]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sup_n \\int_{\\left|f_n\\right| > h} |f_n|\\ d\\mu \\leq \\varepsilon.", block: true)]]
]

#text("The dominated convergence theorem extends to the uniformly integrable setting:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" If ")#mi("{f_n:X \\rightarrow {\\bf C}}")#text(" is a sequence of uniformly integrable functions that converges almost everywhere to a function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(", show that ")#mi("{f}")#text(" is absolutely integrable and ")#mi("{\\int_X f_n\\ d\\mu}")#text(" converges to ")#mi("{\\int_X f\\ d\\mu}")#text(".")
]

#text("One also has an analogue of Exercise ")#link(<tao-f1308241eb02418033bc>)[#text("18")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 29 (Uniformly integrable convergence in measure)")]#text(" Let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a uniformly integrable sequence of functions, and let ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be another function. Then ")#mi("{f_n}")#text(" converges in ")#mi("{L^1}")#text(" norm to ")#mi("{f}")#text(" if and only if ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in measure.")
]

#emph[#text("Proof:")]#text(" The “only if” part follows from Exercise ")#link(<tao-97c10efe01d5c9c88704>)[#text("3")]#text(", so we establish the “if” part.")

#text("By uniform integrability, there exists a finite ")#mi("{A > 0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_X |f_n|\\ d\\mu \\leq A")]]

#text("for all ")#mi("{n}")#text(". By Exercise ")#link(<tao-7818799270c5ffdc89f2>)[#text("17")]#text(", there is a subsequence of the ")#mi("{f_n}")#text(" that converges pointwise almost everywhere to ")#mi("{f}")#text(". Applying Fatou’s lemma, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_X |f|\\ d\\mu \\leq A,")]]

#text("thus ")#mi("{f}")#text(" is absolutely integrable.")#linebreak()#text(" Now let ")#mi("{\\varepsilon > 0}")#text(" be arbitrary. By Exercise ")#link(<tao-75e3090289e2955dfaec>)[#text("26")]#text(", one can find ")#mi("{\\delta > 0}")#text(" such that ")#metadata(none) <tao-270478f288c6ea6957be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\int_{\\left|f_n\\right| \\leq \\delta} |f_n|\\ d\\mu \\leq \\varepsilon", block: true)]]

#linebreak()#text(" for all ")#mi("{n}")#text(". By dominated convergence, and decreasing ")#mi("{\\delta}")#text(" if necessary, we may say the same for ")#mi("{f}")#text(", thus ")#metadata(none) <tao-daa4f3f514a1153b7787>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\int_{\\left|f\\right| \\leq \\delta} |f|\\ d\\mu \\leq \\varepsilon.", block: true)]]

#text("Let ")#mi("{0 < \\kappa < \\delta/2}")#text(" be another small quantity (that can depend on ")#mi("{A,\\varepsilon,\\delta}")#text(") that we will choose a bit later. From ")#link(<tao-270478f288c6ea6957be>)[#text("(1)")]#text(", ")#link(<tao-daa4f3f514a1153b7787>)[#text("(2)")]#text(" and the hypothesis ")#mi("{\\kappa < \\delta/2}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|f_n-f\\right| < \\kappa; \\left|f\\right| \\leq \\delta/2} |f_n|\\ d\\mu \\leq \\varepsilon", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|f_n-f\\right| < \\kappa; \\left|f\\right| \\leq \\delta/2} |f|\\ d\\mu \\leq \\varepsilon", block: true)]]

#text("and hence by the triangle inequality ")#metadata(none) <tao-bf29083a741f265945c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\int_{\\left|f_n-f\\right| < \\kappa; \\left|f\\right| \\leq \\delta/2} |f-f_n|\\ d\\mu \\leq 2\\varepsilon.", block: true)]]

#text("Finally, from ")#link("http://en.wikipedia.org/wiki/Markov's_inequality")[#text("Markov’s inequality")]#text("(Exercise 34 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text(") we have")

#align(center)[#tao-fit-display[#tao-math("\\mu( \\{ x: \\left|f(x)\\right| > \\delta/2 \\} ) \\leq \\frac{A}{\\delta/2}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|f_n-f\\right| < \\kappa; \\left|f\\right| > \\delta/2} |f-f_n|\\ d\\mu \\leq \\varepsilon \\leq \\frac{A}{\\delta/2} \\kappa.", block: true)]]

#text("In particular, by shrinking ")#mi("{\\kappa}")#text(" further if necessary we see that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|f_n-f\\right| < \\kappa; \\left|f\\right| > \\delta/2} |f-f_n|\\ d\\mu \\leq \\varepsilon", block: true)]]

#text("and hence by ")#link(<tao-bf29083a741f265945c9>)[#text("(3)")]#text(" ")#metadata(none) <tao-a5b9c6a1efc5182f0009>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\int_{\\left|f_n-f\\right| < \\kappa} |f-f_n|\\ d\\mu \\leq 3\\varepsilon", block: true)]]

#text("for all ")#mi("{n}")#text(".")#linebreak()#text(" Meanwhile, since ")#mi("{f_n}")#text(" converges in measure to ")#mi("{f}")#text(", we know that there exists an ")#mi("{N}")#text(" (depending on ")#mi("{\\kappa}")#text(") such that")

#align(center)[#tao-fit-display[#tao-math("\\mu( \\left|f_n(x)-f(x)\\right| \\geq \\kappa ) \\leq \\kappa", block: true)]]

#text("for all ")#mi("{n \\geq N}")#text(". Applying Exercise ")#link(<tao-8db59feb4d217f26c79d>)[#text("24")]#text(", we conclude (making ")#mi("{\\kappa}")#text(" smaller if necessary) that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|f_n-f\\right| \\geq \\kappa} |f_n|\\ d\\mu \\leq \\varepsilon", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|f_n-f\\right| \\geq \\kappa} |f|\\ d\\mu \\leq \\varepsilon", block: true)]]

#text("and hence by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|f_n-f\\right| \\geq \\kappa} |f-f_n|\\ d\\mu \\leq 2\\varepsilon", block: true)]]

#text("for all ")#mi("{n \\geq N}")#text(". Combining this with ")#link(<tao-a5b9c6a1efc5182f0009>)[#text("(4)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_n-f\\right\\|_{L^1(\\mu)} = \\int_{X} |f-f_n|\\ d\\mu \\leq 5\\varepsilon", block: true)]]

#text("for all ")#mi("{n \\geq N}")#text(", and so ")#mi("{f_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^1}")#text(" norm as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Monotone convergence theorem)")]#text(" Suppose that ")#mi("{f_n: X \\rightarrow [0,+\\infty)}")#text(" are measurable, monotone non-decreasing in ")#mi("{n}")#text(" and are such that ")#mi("{\\sup_n \\int_X f_n\\ d\\mu < \\infty}")#text(". Show that ")#mi("{f_n}")#text(" converges in ")#mi("{L^1}")#text(" norm to ")#mi("{\\sup_n f_n}")#text(". (Note that ")#mi("{\\sup_n f_n}")#text(" can be infinite on a null set, but the definition of ")#mi("{L^1}")#text(" convergence can be easily modified to accomodate this.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31 (Defect version of Fatou’s lemma)")]#text(" Suppose that ")#mi("{f_n: X \\rightarrow [0,+\\infty)}")#text(" are measurable, are such that ")#mi("{\\sup_n \\int_X f_n\\ d\\mu < \\infty}")#text(", and converge pointwise almost everywhere to some measurable limit ")#mi("{f: X \\rightarrow [0,+\\infty)}")#text(". Show that ")#mi("{f_n}")#text(" converges in ")#mi("{L^1}")#text(" norm to ")#mi("{f}")#text(" if and only if ")#mi("{\\int_X f_n\\ d\\mu}")#text(" converges to ")#mi("{\\int_X f\\ d\\mu}")#text(". Informally, we see that in the unsigned, bounded mass case, pointwise convergence implies ")#mi("{L^1}")#text(" norm convergence if and only if there is no loss of mass.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Let ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" be a measure space, let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions converging pointwise almost everywhere as ")#mi("{n \\rightarrow \\infty}")#text(" to a measurable limit ")#mi("{f: X \\rightarrow {\\bf C}}")#text(", and for each ")#mi("{n}")#text(", let ")#mi("{f_{n,m}: X \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions converging pointwise almost everywhere as ")#mi("{m \\rightarrow\\infty}")#text(" (keeping ")#mi("{n}")#text(" fixed) to ")#mi("{f_n}")#text(".")

#enum(start: 1, 
[#text("If ")#mi("{\\mu(X)}")#text(" is finite, show that there exists a sequence ")#mi("{m_1,m_2,\\ldots}")#text(" such that ")#mi("{f_{n,m_n}}")#text(" converges pointwise almost everywhere to ")#mi("{f}")#text(".")],
[#text("Show the same claim is true if, instead of assuming that ")#mi("{\\mu(X)}")#text(" is finite, we merely assume that ")#mi("{X}")#text(" is ")#link("http://en.wikipedia.org/wiki/%CE%A3-finite_measure")[#mi("{\\sigma}")#text("-finite")]#text(", i.e. it is the countable union of sets of finite measure.")]
)

#text("(The claim can fail if ")#mi("{X}")#text(" is not ")#mi("{\\sigma}")#text("-finite. A counterexample is if ")#mi("{X = {\\bf N}^{\\bf N}}")#text(" with counting measure, ")#mi("{f_n}")#text(" and ")#mi("{f}")#text(" are identically zero for all ")#mi("{n \\in {\\bf N}}")#text(", and ")#mi("{f_{n,m}}")#text(" is the indicator function the space of all sequences ")#mi("{(a_i)_{i \\in {\\bf N}} \\in {\\bf N}^{\\bf N}}")#text(" with ")#mi("{a_n \\geq m}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" ")#metadata(none) <tao-21276f3727cfdab00193>#text(" Suppose that ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" are a dominated sequence of measurable functions, and let ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be another measurable function. Show that ")#mi("{f_n}")#text(" converges pointwise almost everywhere to ")#mi("{f}")#text(" if and only if ")#mi("{f_n}")#text(" converges in almost uniformly to ")#mi("{f}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions, and let ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be another measurable function. Show that the following are equivalent:")

#enum(start: 1, 
[#mi("{f_n}")#text(" converges in measure to ")#mi("{f}")#text(".")],
[#text("Every subsequence ")#mi("{f_{n_j}}")#text(" of the ")#mi("{f_n}")#text(" has a further subsequence ")#mi("{f_{n_{j_i}}}")#text(" that converges almost uniformly to ")#mi("{f}")#text(".")]
)
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (84)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-2/#comment-688085")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2025")])]

#text("Dear professor Tao:")

#text("For part (1) of Exercise 15 I can see that the general measurable case follows from the step function case by contradiction. For part (2) though, it seems that the general case can be proven without the special case serving as a stepping stone. Can you explain a little bit on how the special case helps to show the general case in part (2)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-2/#comment-688086")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2025")])]

#text("Dear professor Tao:")

#text("I figured out the connection in my previous question, thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-2/#comment-688087")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2025")])]

#text("Dear professor Tao:")

#text("Regarding the alternative approach for Exercise 18, if one consider the sets ")#mi("E_k := \\{x \\in X: g(x) \\geq 1/k\\}")#text(", then ")#mi("E")#text(" can be taken as ")#mi("E_k")#text(" for large enough ")#mi("k")#text(". In this case one can control ")#mi("\\int_{X \\backslash E} |f_n - f| d\\mu")#text(" by the triangle inequality, yet how should one use the convergence in measure condition to control the integral on the set ")#mi("E")#text("?")

#emph[#text("[You may find it convenient to refine ")#mi("E")#text(" further to make ")#mi("g")#text(" bounded. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-2/#comment-688090")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2025")])]

#text("Dear professor Tao:")

#text("Small typos in Remark 20: ")#mi("EE_\\varepsilon")#text(" should be ")#mi("E_\\varepsilon")#text(", “trapped inside a finite set” should be “trapped inside a finite measure set”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-2/#comment-688096")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2025")])]

#text("Dear professor Tao:")

#text("It appears that one only need no escape to infinity in Exercise 24, did you intend to only give a sufficient condition for this problem?")

#emph[#text("[The problem is not stated as an “if and only if” statement. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-2/#comment-689580")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2026")])]

#text("Dr Tao, could be combine this posted below where you also mention “convergence”? ")#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/")[#text("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47372")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("in proposition 1, you repeat ")#mi("f_n, f")#text(" twice.")

#text("Thanks")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of P.")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47379")[#strong[#text("P.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2010")])]

#text("Dear Terry, in the third paragraph you mention convergence of functions on different domains. Are there any standard notions for this? Can you (or any other reader) give me an example or reference? Thanks for another nice entry.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47382")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2010")])]

#link("http://en.wikipedia.org/wiki/Convergence_of_random_variables#Convergence_in_distribution")[#text("Convergence in distribution")]#text(" is one typical example. The notion of convergence in moments and convergence in *-moments also ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("shows up in free probability theory")]#text(", and can be viewed as a noncommutative generalisation of convergence in distribution.")

#link("http://en.wikipedia.org/wiki/Gromov%E2%80%93Hausdorff_convergence")[#text("Gromov-Hausdorff convergence")]#text(" is, strictly speaking, a convergence of metric spaces rather than of functions, but is certainly in a similar spirit.")

#text("There is also the notion of ")#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/")[#text("elementary convergence")]#text(" of a sequence of models in model theory; for instance, an ultraproduct can be viewed as an elementary limit of its factors. One could specialise this notion to a sequences of models, each of which contained a distinguished function f_n to obtain a notion of convergence on functions f_n on different domains X_n. (For instance, if f_n was a bounded function on a measure space X_n, the language permitted one to take polynomial operations on f_n together with integration against the measure, then elementary convergence becomes the same as convergence in moments, and thus convergence in distribution.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of P.")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47384")[#strong[#text("P.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2010")])]

#text("Thank you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-216122")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("It is not exactly the classical calculus but there is a notion of epigraphical convergence in the book Variational analysis from Terry Rockafellar and Roger Wets. This notion works with epigraph of functions (or graphs if mapping into more-dimensional spaces or working with multifunctions) and taking the Painleve-Kuratowski (outer and inner) set limit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47380")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2010")])]

#text("You write that if f_n(x) := nx then (f_n) converges pointwise but not uniformly to the zero function, but obviously that isn’t true. Did you mean f_n(x) := x/n?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce9920f5436c6b5dd499a56e6f4c6dfbad19c0a7ad97190fc3cea6c646b1fbb0-495cf2702c6facea9540d9ccbfd2790e3438febd9a7b99111df9fcfe294e9498.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kioftoulas Keftes Kioftopoulos")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-467144")[#strong[#text("Kioftoulas Keftes Kioftopoulos")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2016")])]

#text("But $x/n<\\varepsilon$ implies $x/\\varepsilon 1/\\varepsilon\\geq x/\\varepsilon$, which is true for all $x\\in [0,1]$, isn’t it?. Maybe it is better to take $f_n=x^n$.")

#emph[#text("[The example was on the domain ")#mi("{\\bf R}")#text(", not ")#mi("[0,1]")#text(" – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47390")[#strong[#text("Cao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I am a graduate student in the math department. I think your lecture notes of real analysis are even more readable than lots of the textbooks about real analysis. It is because you pile up the materials logically according to your understanding, isn’t it? Lots of teachers usually go too quickly to too many details of the subject. This drives me crazy that I nearly lost myself in analysis without any hope of seeing the whole pictures. Do you suggest your students to try to write down the topic in their own for understanding? What if the materials in the textbook that some student is using are arranged in an unsatisfying order?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47402")[#strong[#text("Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2010")])]

#text("[…] 1: Das Lebesguesche Maß. Lecture 2: Das Lebesguesche Integral Lecture 3: Maße und Maßräume Lecture 4: Konvergenzbegriffe […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8173daa61f80b674375fabf3cc300a58d8b78253834b35d8828048234180582a-915c722ea51bff490b1c5db1258d704dba6ed772e687940456cd1004f79c9692.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Sullivan")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47460")[#strong[#text("Tim Sullivan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("Prof. Tao,")

#text("As always, great notes. Mention of “modes of convergence” (as opposed to “topologies”) always reminds me of the following nice pathology related to the typewriter sequence: because it converges to zero in measure but not almost everywhere, it follows that there can be no such thing as a “topology of almost everywhere convergence”. If there were such a topology, then the typewriter sequence would have to have a subsequence isolated from the zero function, yet the convergence to zero in measure implies that that subsequence has a further subsequence that *does* converge to zero, which is a contradiction. There’s a nice note by Ordman (1966) on this point.")

#text("— T.J.S.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47491")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2010")])]

#text("Yes, this is a nice argument; it was surprising to me when I first found out that almost everywhere convergence is not topologisable. (I put a version of this example as an exercise to a ")#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")[#text("later set of notes")]#text(", see Exercise 8 there.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47506")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2010")])]

#text("There appears to be a typo in the definition of f_n in the first sentence of Example 4. ")#emph[#text("[Sorry, I was unable to see the issue here. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47652")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] Exercise 42, is absolutely integrable. By Exercise 8 of Notes 4, is thus uniformly integrable. Now let . By Exercise 11 of Notes 4, we can […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7588e612613620029650b20d10d725b681c044d58e38c7d1bf77443d283e5399-6a86a5e4121c3c5441054088ef0813add15c630c755bcb8d1dc85054184c6c9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Petter")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47931")[#strong[#text("Petter")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2010")])]

#text("It might be helpful to draw a diagram of all the mentioned modes of convergence with arrows denoting implications, e.g. an arrow form the box labeled “uniform convergence” to “pointwise convergence”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47932")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2010")])]

#text("I mention this in the post (after Exercise 2). It is a subtle diagram (particularly if one wants to include the additional implications one can gain in the case of finite measure, domination, after taking subsequences, or assuming that there is no loss of mass), and I think the only way to really appreciate it is to actually draw it from scratch, rather than see someone else’s version.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-241685")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2013")])]

#text("In fact,I don’t like to draw diagram because this makes mathematics looks like chemistry.I just try to prove all the implications and try to visualize them in my heart.")

#text("Then after learning this post it seems that I remember nothing but if I think carefully everything will go back in my mind.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3a4ad2bffece83e0b30983e48ae41ce7275975ac2c7e192db28c4bb4c835f16-0823e52cd2b464508a8804303cab6dc926d532ef8acf98e82fed1419ec145e85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Minyu")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47975")[#strong[#text("Minyu")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("Hi, Professor Tao:")

#text("The explanation of uniformly integrability you mentioned in Remark 5 via rearrangement is very interesting, I have never saw it before. Can you give some more explanation about that? Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-47976")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("Oops, upon closer inspection I realised that that remark was inaccurate, and I have deleted it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lei")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-48037")[#strong[#text("Lei")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("There is a typo in the first example you gave for the pointwise convergence does not imply uniform convergence should be f_n=x/n instead of nx.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lei")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-48041")[#strong[#text("Lei")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("A typo in equation (4), the right hand side should be 3*\\epsilon; also, the last inequality of Theorem 5, it supposed to be 5*\\epsilon.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57ef29cc7827291fc5c13af1f08968bb6d462406b9bfcf22ef01aa58249b6e79-8735728e280688c848bc9a6f7670af542350bf84cd0486e816f090082fb9841d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Chi")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-48842")[#strong[#text("David Chi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2010")])]

#text("Professor Tao:")#linebreak()#text(" Is it ture that pointwise convergence implies Cauchy convergence under the Lp norm, i.e. if fn converges to f a.e. (Lp functions), does it follow that fn is a Cauchy sequence under the metric induced by Lp norm?")#linebreak()#text(" It seems trivial, but I got quite confused about it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-48851")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2010")])]

#text("No; Example 1 in the notes (escape to horizontal infinity) provides a counterexample.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27648ef9a93399e3bcb4f55404eb06d8594f62bdbf36c163d7854570df3174dd-8ff0137d4325ebfdc21d3643c9b7eaff6f263daa3be1b8544d6eef9329d85d17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-48875")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2010")])]

#text("Dear Professor Tao,")

#text("Would you be teaching Math 245A next Fall? I want to take it if offered. Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-52976")[#strong[#text("The chi function tells the same thing about weak-* convergence as Young measures « regularize")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2011")]

#text("[…] can distinguish several “modes” that a sequence of functions can obey: In this blog entry of Terry Tao he introduces four more modes apart from […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-101474")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2011")])]

#text("I believe there is a mistake in the typewriter example. It should be 1_[(n-2^k)/(2^(k+1),(n+1-2^k)/(2^(k+1))] rather than 1_[(n-2^k)/2^k,(n+1-2^k)/2^k)], or it will be in [1,2] rather than the unit interval.")

#emph[#text("[Actually, I believe the example is correct as stated; note that ")#mi("n")#text(" is constrained between ")#mi("2^k")#text(" and ")#mi("2^{k+1}-1")#text(", so that [(n-2^k)/2^k,(n+1-2^k)/2^k] is contained in [0,1] rather than [1,2]. -T] ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-101951")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2011")])]

#text("Why is there no almost pointwise convergence (i.e. for any delta, exists E_delta whose measure is less than delta, f_k->f on E\\E_delta). Is it strictly stronger than almost everywhere pointwise convergence?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-101976")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2011")])]

#text("This concept is equivalent to almost everywhere convergence; if one has ")#mi("f_k(x) \\to f(x)")#text(" for all ")#mi("x \\in E \\backslash E_\\delta")#text(" and all ")#mi("\\delta > 0")#text(", then one also has ")#mi("f_k(x) \\to f(x)")#text(" for all ")#mi("x \\in E \\backslash \\bigcap_{n=1}^\\infty E_{1/n}")#text(". But ")#mi("\\bigcap_{n=1}^\\infty E_{1/n}")#text(" has measure zero, so this gives almost everywhere convergence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-102528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2011")])]

#text("Sorry, I don’t quite follow. I understand f_k(x)->f(x) for x in E\\Union_{n=1}^{Infinity}E_{1\\n}. Why is f_k(x)->f(x) for x in E\\Intersection_{n=1}^{Infinity}E_{1\\n}?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-102566")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2011")])]

#link("http://en.wikipedia.org/wiki/De_Morgan's_laws")[#text("http://en.wikipedia.org/wiki/De_Morgan's_laws")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe5abad82d1b11c42452250f551c9ae384aa46339448bf281fe909359bb9389e-a4adb42b2cc858da8f4b388f7068a08411f69046d7e6b39d8c2235ec3096678a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Konstantinos")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-141866")[#strong[#text("Konstantinos")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2012")])]

#text("Reblogged this on ")#link("http://inlieuofabettertitle.wordpress.com/2012/05/06/611/")[#text("Room 196, Hilbert's Hotel")]#text(" and commented:")#linebreak()#text(" Useful notes! Kudos to professor Tao for writing them!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-168469")[#strong[#text("Characterising almost uniform convergence for step functions | Q&A System")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2012")]

#text("[…] 3 of those notes describes modes of convergence by showing their relationship with step functions converging to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-190228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2012")])]

#text("Why are these modes of convergence introduced? (Is it because people are always interested in finding some class of functions which are “convergent” in some sense?) As a beginner in your course, I feel that the implications between different modes are just bunch of exercises for me. A diagram is indeed helpful to remember the logical implications. But how can one internalize these modes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-190238")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2012")])]

#text("One basic reason to understand different modes of convergence in analysis is that one frequently wants to interchange integrals and limits; for instance, if a sequence of functions ")#mi("f_n")#text(" converges in some sense to some limit ")#mi("f")#text(", one wants to conclude that ")#mi("\\int f_n")#text(" also converges to ")#mi("\\int f")#text(". Unfortunately, if the mode of convergence is too weak (or the functions ")#mi("f_n")#text(" do not obey good bounds) then one cannot justify this interchange of limits and integrals, which can lead to serious errors in one’s argument. So it becomes important to be aware of the relative differences of strength between various modes.")

#text("Also, some basic results in analysis tend to only give certain types of modes of convergence but not others. For instance, ergodic theorems tend to give either norm convergence or pointwise almost everywhere convergence results, but usually cannot provide pointwise everywhere or uniform convergence results unless one has some additional structure that one can exploit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-241375")[#strong[#text("Asymptote")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2013")]

#text("[…] In this post I prove theorem 5 of 245A, Notes 4: Modes of convergence. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-241863")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2013")])]

#text("Dear Prof.Tao,")

#text("I think I found a counter example to exercise 18(the last exercise in this post),in this counter example,pointwise convergence does not imply convergence in distribution:")

#text("Let ")#mi("f=1")#text(" be a function whose domain is ")#mi("[0,1]")#text(".Let ")#mi("f_n=1+\\frac{1}{n}")#text(" whose domain is also ")#mi("[0,1]")#text(".It is obvious that ")#mi("f_n")#text(" converges pointwise to ")#mi("f")#text(",but we know that ")#mi("F_n(1)=0")#text(" for all ")#mi("n\\in\\mathbf{N}^+")#text(" and ")#mi("F(1)=1")#text(".So ")#mi("f_n")#text(" does not convergent in distribution to ")#mi("f")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-241866")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2013")])]

#text("Oh I am wrong,It seems that this counterexample is not a counterexample because ")#mi("F")#text(" is not continuous here.I overlook the condition that ")#mi("F")#text(" has to be continuous.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-241922")[#strong[#text("Solution to Exercise 18 of 245a:modes of convergence | Asymptote")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2013")]

#text("[…] Now I prove that if converges in measure to then it converges in distribution to .This is a simple corollary of Exercise 17. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-460553")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2015")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2015/10/15/245a-notes-4-modes-of-convergence/")[#text("Singapore Maths Tuition")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08375cec724870c30e716e94b5c0b95ab418f0211204e1465021574c0b3c96c0-5080eda75ca3341edb7a89c6895eb48cae10aa2ef7fa312eedb19e447b273add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-461891")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#text("Professor Tao:")#linebreak()#text(" I’d like to ask you about the last part in exercise 8-2. How can one show that domination of the sequence $f_n$ prevents escape to width-infinity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-461896")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#text("If one denotes the dominating function by ")#mi("g")#text(", then from dominated convergence we have ")#tao-math("\\int_{\\left|g\\right| \\leq \\varepsilon} \\left|g\\right| \\to 0", block: false)#text(" as ")#mi("\\varepsilon \\to 0")#text(". This allows one to focus attention on the set ")#tao-math("\\{ \\left|g\\right| > \\varepsilon \\}", block: false)#text(", which has finite measure and thus precludes escape to width infinity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08375cec724870c30e716e94b5c0b95ab418f0211204e1465021574c0b3c96c0-5080eda75ca3341edb7a89c6895eb48cae10aa2ef7fa312eedb19e447b273add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-461909")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2015")])]

#text("Thank you very much, I see it now.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-463420")[#strong[#text("Typewriter sequence of a U(0,1) random variable | justanothermathblog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")]

#text("[…] “disguise” is that is really just the “typewriter sequence” from e.g. Terry Tao’s blog, with some minor tweaks that do not affect […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc2dd4ebeefc8f65e28a9c9451011d784b1081d92dd66b32a550061eaa39c9a7-355f8ffe79f68f85468dad0c9a96b005398fdabe28bcea7a6de74736a6df92bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikolas")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-468263")[#strong[#text("Nikolas")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2016")])]

#text("Dear Professor Tao,")

#text("thank you for these excellent notes!")

#text("In the proof of Theorem 5, when passing from eq. (1) to (2), I cannot figure out how to invoke monotone convergence. Which is the right monotone sequence one should consider here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-468272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2016")])]

#text("Sorry, this should be dominated convergence instead of monotone convergence, the point being that ")#tao-math("\\int_{\\left|f\\right| \\leq \\delta} |f|\\ d\\mu", block: false)#text(" goes to zero as ")#mi("\\delta \\to 0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Coupon.clipper")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-474991")[#strong[#text("Coupon.clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2016")])]

#text("Sorry I’m still not seeing it. You’re using the monotone convergence theorem for integrals? What sequence of functions are you integrating and what are they dominated by?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-474995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2016")])]

#text("One is applying dominated convergence to ")#tao-math("\\left|f\\right| 1_{\\left|f\\right| \\leq \\delta}", block: false)#text(" as ")#mi("\\delta \\to 0")#text(", which is dominated by ")#tao-math("\\left|f\\right|", block: false)#text(" which was already shown to be absolutely integrable. (We are not using (1) directly here. Alternatively, one could deduce (2) from (1) using Fatou’s lemma, after shrinking ")#mi("\\delta")#text(" slightly as mentioned in the blog post.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-474996")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2016")])]

#text("Yup, that’ll do it. Thanks so much for your help. (I don’t think I had professors in college as responsive as you, and I’m not even taking your class!)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c50e5f1f8109cc87a6a3394a68e11c763b6092dcb32a39c8ede2899c1d295ac7-43b5289b51f93c075c052b51197fc2a7f761321fdc8daaea8bbb8d7f7c9c8bdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunting")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-470366")[#strong[#text("Sunting")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2016")])]

#text("dear prof. tao, i think about the exercises 3, the third part, i consider an counterexample but i don’t know why it is not correct. suppose An is presumed to be 1,1,1/2,1,1/4,1,…,with the odd one be 1/2^(n-1) and the even one be 1. and we can presume that En=[0,1] for any odd n, and En=[0,1/2^n] for any even n. for any small epsilon, we could find")#linebreak()#text(" the measure of union of all E(2n) for n>= a specific N is less than epsilon. and")#linebreak()#text(" outside this set we can see that it only involves finite number of En(n even) and infinitely many En=[0.1](n is odd). and i think in this set, the convergence to zero is uniform. we can find that An and measure of EN* is not converging to zero.")#linebreak()#text(" something must be wrong here. but i spend much time to find out but it turns out in vain.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-470373")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2016")])]

#text("One of the running assumptions (see first paragraph of Section 2) is that ")#mi("A_n")#text(" either tends to zero, or is bounded away from zero.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-474253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("The definition of “uniform integrability” in the link you gave (")#link("https://en.wikipedia.org/wiki/Uniform_integrability")[#text("https://en.wikipedia.org/wiki/Uniform_integrability")]#text(") seems essentially different from the one in Definition 4. Are some of the assumptions in Definition 4 redundant?")

#emph[#text("[The definitions are basically equivalent, at least for probability spaces; see Exercise 11 for one direction of this. In this case there is indeed redundancy; see Exercise 9. For infinite measure spaces the definition is not completely standardised, and some of the definitions are slightly stronger or weaker than others. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-484253")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2017")])]

#text("When you write ")#tao-math("\\left|f_n(x)\\right| \\leq g(x)", block: false)#text(" do you implicitly assume ")#mi("g:X\\to \\mathbf{R}")#text("? For example in the definition of dominated ")#mi("f_n")#text(" and in Exercise 1.3 (Squeeze test).")

#emph[#text("[Yes; the convention throughout these notes is that the order relation is only defined on the real numbers. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-484256")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2017")])]

#text("Do you think it is a little bit redundant to assume ")#mi("f_n")#text(" is absolutely integrable functions in the definition of Uniform integrability? Since I think this is implied by (i) (Uniform bound on L1 norm).")

#emph[#text("[Yes, but I prefer to describe the functions this way (as opposed to merely being measurable functions) for emphasis. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33e196db20a8b6931ff3c4777307678abac36c2ffea328c27fb0d755909d8e1c-0c1bb1eb1379857f0de3701ab2e0b96abd2074b9d7e1a816e9c797a1464454bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer Yue")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-496054")[#strong[#text("Spencer Yue")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("In section 1 on Uniqueness, when you say:")#linebreak()#text(" “Then by Exercise 1, {0} converges to {f-g} pointwise almost everywhere”")#linebreak()#text(" what exactly do you mean?")#linebreak()#text(" I understand that by the triangle inequality:")#linebreak()#text(" {|f – g| \\le |f – f_n| + |f_n – g| \\forall n}")#linebreak()#text(" so that convergence pointwise a.e. of the terms on the right-hand side to 0 implies the left-hand side is 0 a.e.")#linebreak()#text(" But were you suggesting a slightly different way of looking at it from your wording (“{0} converges to …”) and mention of Exercise 1?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-496055")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("Since ")#mi("f_n")#text(" converges to ")#mi("f")#text(", and ")#mi("f_n")#text(" converges to ")#mi("g")#text(", the difference sequence ")#mi("f_n - f_n = 0")#text(" converges to ")#mi("f-g")#text(", thanks to Exercise 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f6389068638f41dbc3dd8d15bcbb6b83609fb2299f17d95130109862311b6e5-02367edd0fc7b4cb4eff2e1ae15c06c9bf286b5f2eeadd8afa3ded3030def7ae.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maxie Schmidt")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-497495")[#strong[#text("Maxie Schmidt")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")])]

#text("We recently had a similar extra credit assignment in my graduate Analysis II course. The assignment was to create a “roadmap” of notions of (modes of) convergence relevant to the course. I talked with the professor after showing him this link as a reference, and he suggested that I post my solution roadmap as a comment here. Without going on too much about what’s in the pdf and why it’s useful to organize and compare these topics for understanding, I will just give the link to my comparison:")#link("http://people.math.gatech.edu/~mschmidt34/files/roadmap.pdf")[#text("http://people.math.gatech.edu/~mschmidt34/files/roadmap.pdf")]#text(". I would appreciate any **constructive** feedback about this document.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72789d03a67fbeab81ef3d17c0c0745c84a6e801efb0957f79431ed2aad8ce39-a74f271550fdfa5bed81dd507db77663cbf69c670e907b5517af6ae425b0fafd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anilpedgaonka")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-517047")[#strong[#text("anilpedgaonka")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2019")])]

#text("dear professor Tao, can Egorovs theorem be modified to set of possibly infinite measure")#linebreak()#text(" can we modify it so hat it works for not necessarily measurable functions.")#linebreak()#text(" relevance can gt a good generalization of dominated converence theorem for vector( banach space valued)maps and or vector measures.")#linebreak()#text(" in particular one has decreasing sequence of sets of finite outer measure decreasing to null set such that the teir indicator functions are integrable with respect tovector measure then the vecor measure –>0")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-518901")[#strong[#text("Fast L1 convergence implies a.e. convergence | Negro's notes")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2019")]

#text("[…] Suppose that Then, for all , (this argument is essentially the Borel-Cantelli lemma), which implies that almost everywhere. See ")#link(<tao-3e64cc41cf8e07b43936>)[#text("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/#step")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b06d0d153d7b459e2103f5f664b1c3babab49d2fda99dcac3c10193bd3c654a-07a931caac66cb969dc1311a0bff4285dcf51a4917d636cce552e7dc2a9ca6a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of biswajitrajaguru")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-568483")[#strong[#text("biswajitrajaguru")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2020")])]

#text("Sir help with Ex 15")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ff73154dc428f08297ad4d30fc006888ac829d422564c3f3375b06496842082-fe109d66a0435e928bc05fec8259d28ae6540fc85ad7f564e9ae3bc59577b88f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Chen")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-625341")[#strong[#text("Benjamin Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2021")])]

#text("Reblogged this on ")#link("https://nerasnow.wordpress.com/2021/04/29/245a-notes-4-modes-of-convergence/")[#text("NeraSnow")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-630543")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2021")])]

#text("Beside the typewriter, can one find an example so that a Riemann integrable sequence ")#mi("f_k")#text(" converge to ")#mi("0")#text(" in ")#mi("L^2([0,1])")#text(" but the pointwise limit ")#mi("\\lim_{k\\to\\infty} f_k(x)")#text(" fails to exist for any ")#mi("x\\in[0,1]")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-634910")[#strong[#text("pr.chance - Confusion round uniform integrability and Vitali convergence theorem Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2021")]

#text("[…] this weblog entry, Professor Tao outlined uniform integrability as uniformly constrained in $ L ^ 1 $, not vertically […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/263424b2da3c1b1b358608bdd60a4196c5cbb0857a57562322639aa27f7ed0db-4964a769ebb877ffd75f75761885b8b332b5ad1429957cbb2cc8ce0366409261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Diaz")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-643207")[#strong[#text("Oliver Diaz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2022")])]

#text("Definition 4 is a curious definition of uniform integrability as it is not equivalent to the commonly adopted definition by G. A. Hunt (in Hunt, G.A., Martingales et Precessus de Markov, Paris: Dunod, 1966 pp. 254) that states that a family ")#mi("\\mathcal{F}\\subset L_1(X,\\mathscr{B},\\mu)")#text(" is uniformly integrable iff ")#tao-math("\\inf_{g\\in L^+_1}\\sup_{f\\in\\mathcal{F}}\\int_{\\{\\left|f\\right|>g\\}}|f|\\,d\\mu=0", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-643230")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("They are equivalent definitions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-643368")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2022")])]

#text("Thanks for pointing this out. My personal preference is to separate the rearrangement-invariant aspects of uniform integrability (the parts that only depend on the distribution of the ")#mi("f_n")#text(") from the tightness aspect, but I will defer to existing convention and adapt the text to use the extant definition of uniform integrability that combines both aspects together.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-650184")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2022")])]

#text("I think the horizontal moving bump function is a counterexample to exercise 27 right? Along the same line I wonder why definition 19 doesn’t prohibit the escape to horizonal infinity. Is it because it is hard to formulate for arbitrary measure space?")

#emph[#text("[The third condition of Definition 19 excludes the horizontal moving bump function (note that the set ")#mi("{\\bf E}_\\varepsilon")#text(" is required to be independent of ")#mi("n")#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Khaled Alekasir")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-650189")[#strong[#text("Khaled Alekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2022")])]

#text("Dear prof. Tao")#linebreak()#text(" After doing exercise3, I draw a graph of modes of convergence (where vertices where modes of convergence) and when I was putting the edges (u~v iff u implies v) I thought if x~y and y~z then we should have x~z (because it seemed to me when one can approximate y with x and z with y then It`s more likely that you can app. z with x) but in")#linebreak()#text(" Example 4 (Escape to horizontal infinity) I found out that this is not the case since sequence is convergence pointwise and therefor pointwise almost everywhere but obviously not in L^1 norm.")#linebreak()#text(" Can you please explain me intuitively that why x~y and y~z doesn`t imply x~z?")#linebreak()#text(" Thanks;)")

#emph[#text("[Convergence pointwise almost everywhere does not always imply convergence in ")#mi("L^1")#text(" (unless one has some sort of additional domination or tightness hypothesis -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-650541")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2022")])]

#text("Dr. Tao:")#linebreak()#text(" Looking for a super nice function (non-trivial) that satisfy all the 7 modes of convergence. Is this possible? The example I came up is putting a factor ")#mi("\\frac{1}{n}")#text(" in front of the Typewriter sequence, i.e.")#linebreak()#text(" ")#mi("f_n = \\frac{1}{n}\\mathbf{1}_{[\\frac{n-2^k}{2^k},\\frac{n-2^k+1}{2^k}]}")#text(".")#linebreak()#text(" Is this correct? Maybe you have other good examples.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-656976")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2022")])]

#text("Dear Terry Tao, in exercise 10 second part, isn`t it necessary to assume that ")#mi("m(E_n)")#text(" doesn`t tend to 0 as n tends to infinity?")#linebreak()#text(" because if ")#mi("m(E_n)")#text(" tends to 0 then ")#mi("f_n")#text(" tends to 0 a.e without needing ")#mi("A_n")#text(" to tend to 0,isn`t it?")

#emph[#text("[Convergence a.e. is not the same as convergence in ")#mi("L^\\infty")#text(". -T]</I?")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-656994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2022")])]

#text("It is assumed that ")#mi("\\mu(E_n)>0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-675547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For part (1) of the fast convergence exercise, can we get the result by simply using Tonelli’s theorem and observe that ")#mi("\\int_X \\sum_{n=1}^\\infty |f_n - f| d\\mu < \\infty")#text(" implies that the function ")#tao-math("\\sum_{n=1}^\\infty \\left|f_n - f\\right|", block: false)#text(" is finite almost everywhere and thus ")#tao-math("\\lim_{n \\to \\infty}\\left|f_n(x) - f(x)\\right| = 0", block: false)#text(" for almost every ")#mi("x")#text("?")

#emph[#text("[Yes, that is one way to proceed. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of false")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-675774")[#strong[#text("false")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2023")])]

#text("Thank you so much professor.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-680181")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" for proving uniqueness(proposition 9), you first established that if both modes of convergence are similar (namely when they are both $a.e$ or in measure) the proposition holds.")#linebreak()#text(" then for the case when modes are different(namely one of them in measure and one of them $a.e$ you gave a proof.")#linebreak()#text(" Is it possible to say that since $f_n \\to f a.e$ then $f_n \\to f $ in measure thus we are again back to first step where both modes of convergence were the same and we are done.")#linebreak()#text(" Isn’t this proof valid?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-680777")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2023")])]

#text("Convergence a.e. only implies convergence in measure when the measure space has finite measure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-680288")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2023")])]

#text("Dear Tao:")#linebreak()#text(" for Exercise 28 I ‘ve argued as follows:")#linebreak()#text(" 1.I’ve shown ")#mi("f_1 , f_2 , \\cdots")#text(" forms a Cauchy sequence in ")#mi("L^1(\\mu)")#text("(using Egorov’s theorem and the fact that this sequence converges to ")#mi("f")#text(")")#linebreak()#text(" 2.By applying the fact that ")#mi("L^1(\\mu)")#text(" forms a complete metric space and applying uniqueness (Proposition 9), conclusion follows.")#linebreak()#text(" I’m not sure my solution is correct since it answers both questions($latex f \\in L^1(\\mu)? f_n \\to f in L^1(\\mu) norm?)simultaneously.")#linebreak()#text(" Is anything wrong in this solution?")#linebreak()#text(" Thanks.")

#emph[#text("[This is fine -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-682847")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2024")])]

#text("Dear Tao,")#linebreak()#text(" I’ve been trying to make a little intuition about monotone convergence theorem and I came up with the following argument:(assuming ")#mi("f")#text(" is an unsigned function)$latex \\\\$")#linebreak()#text(" 1.show that ")#mi("\\int f = \\lim \\int g_n")#text(" where ")#mi("g_n")#text(" is a sequence of simple functions converging to f a.e.(My idea is considering the sequence of simple of functions gievn in theorem 4.1 Stein’s book) $latex \\\\$")#linebreak()#text(" 2.Now for each element of a sequence ")#mi("{f_n}_{1}^{\\infty}")#text(" we can make a sequence ")#mi("{f_{n,j}}_{j=1}^{\\infty}")#text(" of simple functions that monotonically converge to ")#mi("f_n")#linebreak()#text(" 3.use diagonalization argument. $latex \\\\$")#linebreak()#text(" But actually I’m not sure this is correct and also step1 of proof seems intuitively correct to me but I haven’t proved it yet(and I’m sure it’s true).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-686969")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2024")])]

#text("Does f_nto f in measue imply f_n^2to f^2 in measure?")

#emph[#text("[This is a good exercise for you to work out – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2629cf3a36953fc3baa147d276b0a2a6de168f4276ef31701ce9cac8fd74877d-52ca3316efce02bf79257e11c69f653d9efb4c1300f54aa0d50233a37f928196.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalek")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-687643")[#strong[#text("khaledalek")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")])]

#text("Isn’t the first condition in the definition of uniform integrability redundant in the sense that (2) and (3) imply (1)? Given a sequence ")#mi("{f_n}")#text(", choose ")#mi("E_\\varepsilon")#text(" as in (3), then apply Exercise 22. For small enough ")#mi("\\varepsilon")#text(", the bound ")#mi("M+1")#text(" gives a uniform ")#mi("L^1")#text(" bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/comment-page-1/#comment-687648")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")])]

#text("Yes, this condition is technically redundant, but I find it conceptually useful to emphasize it as being a necessary (but not sufficient) consequence of uniform integrability.")
]
]
