// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/
// Converted to Typst by tao2typ: "2026-10-14T15:21:17.336634+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the existence of non-sofic groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the existence of non-sofic groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/")[#text("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://andreasthom.github.io/")[#text("Andreas Thom")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("When I woke up on August 1st, 2026, I had received a few emails from colleagues asking for my opinion on a remarkable result that had circulated the previous day. The result was a solution to a long-standing open problem in geometric group theory, specifically the existence of a non-sofic group. I was astonished and at the same time, looking at the first draft, also in a way happy to see that Kun’s work on expander decompositions and my joint work with Gábor Kun played a decisive role in the crucial Proposition 2.3 of the ")#link("https://cdn.openai.com/pdf/ten-proofs-oai.pdf")[#text("OpenAI paper")]#text(". I had always hoped that the theory of ")#link("https://arxiv.org/abs/1901.03963")[#text("centralizer rigidity")]#text(" would eventually have significant applications, but I had not found the right setting in which it could be used so effectively. In that sense, the solution also came as a relief and I was happy to explain the ideas in ")#link("https://mathoverflow.net/questions/513866/what-are-the-key-new-ideas-in-the-proof-of-nonsoficity-of-groups-in-openai-s-con")[#text("a post on MathOverflow")]#text(" a few days later.")

#text("From the start, colleagues pointed out that the framing in the public announcement that appeared shortly afterwards was misleading, in that it spoke of ")#link("https://web.archive.org/web/20260802205906/https://openai.com/index/ten-advances-in-mathematics/")[#text("“no progress”")]#text(" in the last decade, while relying on our 2019 paper (not to mention subsequent work by many hands that was not directly relevant for the OpenAI paper but would still be considered to be progress by many).")

#metadata(none) <tao-1a499611358a5b01b62b>

#text("So I wrote to Mark Sellke and Sébastien Bubeck: “[…] I find the framing intellectually dishonest. You (and I am talking about you personally, since I have no one else to address this to) cannot speak in the public announcement of a decade without progress and then use a 2019 paper in a crucial way. It is true that Proposition 2.3 is a really clever use of the centralizer-rigidity theorem, but neither does its short proof require new techniques […].")

#text("“It is true that the last stone finishes the building and usually those who can put it get the credit for solving the problem, that is fair enough. I have no problem with that and I personally do not care much about credit. However, I guess you would get enough praise without downplaying the previous contributions.”")

#text("Sellke replied to this and basically agreed to the need for a revision; as a result the public announcement was changed to the form it has now. I was glad to have received an early draft from Sellke also on August 1st, otherwise there would have been no way to react to the first public announcement at all, since neither the PDF nor the website of the announcement contained contact information. Anyway, I was happy that this was resolved and the matter closed.")

#text("It is fair to say that the approach of Kun and myself had not been viewed as the main line of attack on non-soficity prior to OpenAI’s announcement. In fact there were other more promising approaches along the line of quantum games etc. at the time, that had already led to a negative solution of the famous Connes Embedding Problem and, later, the disproof of the Aldous–Lyons conjecture. Hence, OpenAI’s detailed command of the techniques of Kun and myself made me wonder how the model found this route, especially since I discussed these techniques and their use in extensive sessions with ChatGPT over the last months.")

#text("So in the same email I asked Mark Sellke and Sébastien Bubeck: “Another point is that I and a colleague in Dresden were discussing the expander matching problem and various extensions of the work with Gábor Kun actively over the last months with ChatGPT, so that we are of course curious if that was part of the training data or accessible to the reasoning process. There is a certain (frankly unacceptable) lack of transparency here; and I fear it will damage the communal process of math more than the new AI-generated results will benefit the subject.”")

#text("Mark Sellke’s complete answer to this part of my email was: “Regarding your conversations with ChatGPT: that did not happen.”")

#text("Anyway, I thought, these techniques were public, so their use is not evidence that our conversations influenced the model. But because this was not the main line of attack, and because I had recently discussed precisely these techniques and possible extensions with ChatGPT at length, I thought the question had to be asked. Back at the beginning of August, I then returned to mathematics and wrote ")#link("https://arxiv.org/abs/2608.06222")[#text("a subsequent paper")]#text(" with Gábor Kun on applications of the ideas that were the basis of Proposition 2.3. This was my way to react; after all, the integration of the new result in the math landscape seemed like a natural next step.")

#text("However, after reading up on the controversy around the ")#link("https://cims.nyu.edu/~tristanb/statement.pdf")[#text("Buckmaster–Alpöge case")]#text(", the whole story came back to me and I realized that the answer I received from OpenAI was misleading, to say the least. I already wrote about this briefly on ")#link("https://mathstodon.xyz/@andreasthom/117240535270608201")[#text("Mathstodon")]#text(".")

#text("I had explicitly asked about two different things: (1) whether our conversations entered training data, and (2) whether they were accessible to the solving process. OpenAI said in the Buckmaster–Alpöge case that no specific user data was accessed, but added that it “cannot rule out that de-identified data derived from their usage of our products helped improve our models.” In light of OpenAI’s later wording, I cannot tell whether Sellke’s answer denied both possibilities or only direct access under (2). No qualification, explanation, or evidence was given. Whatever its intent, I regard the answer as materially misleading.")

#text("OpenAI was drawing a distinction that its answer to me erased, despite the fact that my question explicitly made that distinction. We are not required to reverse-engineer OpenAI’s internal training pipeline to establish what happened. Only OpenAI has the relevant data for that. For such a categorical denial by OpenAI to be credible, OpenAI should disclose its basis: product and privacy settings, relevant datasets and checkpoints, and what ")#link("https://web.archive.org/web/20260908171518/https://openai.com/index/navier-stokes-solution/")[#text("“de-identified data derived from usage”")]#text(" means.")

#text("I disabled model training on 29 June. That control is still only a promise whose implementation users cannot audit, and it is prospective: it does not answer what happened to earlier conversations or to derivatives already selected.")

#text("If nonpublic research supplied by users improved a model and the provider then used that model to race those users to publication—without informed consent, disclosure, or credit—that would be ethically indefensible. De-identification may remove a name; it does not remove the intellectual content of a mathematical idea. Sellke and Bubeck seem to be blind to this simple moral aspect.")

#text("Sellke gave me a categorical assurance without explaining its basis; I regard that response as materially misleading. If he lacked the information needed to rule out training use, he had no basis for giving that assurance. Bubeck’s ")#link("https://www.linkedin.com/posts/sebastien-bubeck-6b558a1a5_i-would-like-to-clarify-a-few-things-1-activity-7503148080888893440-Ny3E/")[#text("acknowledged career-related remark")]#text(" in the conversation with Buckmaster and his objection to including Alpöge in a proposed paper presenting OpenAI’s proof deepen my concern about their commitment to academic standards. Taken together, these episodes raise serious questions about their judgment and personal integrity.")

#text("I am not claiming that anyone read individual chats or that our conversations were in fact used in training; I do not know that. My criticism concerns the categorical denial. If they did not know what entered the training data (the most likely scenario), they should have said so.")

#text("After I finished writing this post, I received a message from Mark Sellke, who acknowledged understanding how I “reasonably arrived at [my] conclusions given the evidence available”. He pointed me to a discussion citing OpenAI’s ")#link("https://openai.com/index/navier-stokes-solution")[#text("new statement")]#text(" that Buckmaster’s Codex prompts from the preceding two months could not have influenced its system, including through training. I wish I could trust this more. In any case, it suggests that the math community can successfully put pressure on the industry to take these issues at least somewhat more seriously.")

#text("So what does that all mean and how do we as a community proceed? Setting aside these particular cases (which might also be very different in what really happened behind the scenes), we have to see the broader picture and I believe there is no way of going back.")

#text("As far as I see it, a mathematical publication used to bring together three things. It announced a result, identified the people who had produced it, and added something to our human understanding of mathematics. It could therefore serve at the same time as a record of knowledge, a basis for assigning credit, and evidence of a mathematician’s ability. AI breaks this connection.")

#text("An AI system can produce a correct proof even if no human being discovered or even understood the argument in the usual sense. A typical form that this can take nowadays varies from somewhat verified AI Slop to a Lean certificate, or a combination of both. The proof may be worth publishing, but the publication then records only that the result has been established. It does not necessarily tell us how the result was found or who understood it.")

#text("The question of credit and contribution may have no satisfactory answer. A model may draw on published work, feedback, conversations, prompts, and its own search in ways that apparently cannot be reconstructed clearly. The person or the company who ran the model should not simply receive whatever credit cannot be assigned elsewhere. As another consequence, a publication record can no longer serve as a reliable measure of a person’s mathematical quality. If the theorem, proof, and written explanation may all have been generated by AI, a list of papers tells us very little about what the named author contributed or understands. Even if matters of data privacy are resolved, I see only little hope that the current system of publication and credit can be salvaged. The whole idea of personal credit will not work in such a highly connected environment anymore and I actually think that the focus on “who got something first” (not to speak of prizes for a solution to particular problems) was always misleading, even though a powerful driving force.")

#text("The more important question is therefore what someone contributes to human mathematical understanding. This includes explaining why an argument works, separating the main idea from technical details, connecting a result with other areas, finding the right questions, teaching new methods, and helping other mathematicians make use of them. Such contributions may happen through papers, but also through lectures, discussions, teaching, and collaboration.")

#text("A formal proof certificate is comparable, in a sense, to the detection of a new star. It confirms that something is there, but further work is needed to understand what it is, why it matters, and where it belongs in the larger landscape. Mathematics is only to a lesser extent the production of correct statements. It is more the human process of making sense of them.")

#text("The institutional issue goes far beyond mathematics. Advanced AI is becoming a general supply of “intelligence” on which science, education, public administration, industry, and ordinary life may all depend. It should therefore be provided according to standards comparable to those governing water or electricity: reliable and broadly available, with clear public duties, strong privacy rules, independent oversight, and protection against discriminatory or self-serving use.")

#text("Intelligence of this kind should not be treated as an ordinary consumer product whose conditions are set entirely by a few companies. A provider should not be able to collect people’s ideas and information, control all evidence about how they were used, and then exploit that advantage against its own users. Once intelligence becomes basic infrastructure for society, it must be highly regulated and governed in the public interest.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694495")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("It seems to me completely reasonable to assume that any conversation on the topic prior to ")#emph[#text("min(the date that model training was disabled, the cutoff date of the relevant model)")]#text(" entered the training data.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694497")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("“I personally do not care much about credit”")

#text("[proceeds to discuss credit for another 2000 words]")

#text("The issue of the AI companies using user data is real. There needs to be ironclad guarantees that they don’t do it. I suspect if they say they don’t, they probably don’t. The liability is huge otherwise. Then again, facebook knew all along they were harming children yet just bought their way out of liability for peanuts (to them), so perhaps my suspicion is misplaced.")

#text("Personally, I don’t think the people who use models to prove a result deserve anything like the credit we normally assign to such an event, even if they are brilliant mathematicians. If the result wouldn’t have been proven without the models, the credit is really the models’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b64abe43412dc7f11e3ee247ad175b71fde999420e1b399c19ea8c6c464376a-c662b882fe24a1718eb7f2117e0b1baa53af593586a47d2de533176114846933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanishvili")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694498")[#strong[#text("Paata Ivanishvili")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("OAI says it is “very unlikely” that user data helped. I am really curious what exactly “very unlikely” means here, and what that assessment is based on.")

#text("I don’t think we fully understand why and when these models perform so well, so I find that level of confidence a little surprising.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f09de86d71f177e40d2a573813d7807793923114f3d4d38af4e7eb591de87cb1-11ba9ceac01bcdb452452f86f1d53d15e32d792af281a262c154b50e4d180aad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of boldlya2e7c26b8c")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694517")[#strong[#text("boldlya2e7c26b8c")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Comme Saturne, Astra dévore ses enfants.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694526")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("So the Jacobian conjecture, non-sofic groups, and Navier-Stokes all involved large language models being trained on unpublished drafts and private communication to be used in the counterexamples, with neither OpenAI nor Anthropic ever once mentioning that they’d used unpublished drafts and private communication and thus never properly crediting the actual people whose work their counterexamples are based upon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694532")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Need a guest post from one of Alexander Borisov, Ofer Gabber, or Adrian Vasiu on the Jacobian conjecture and how Anthropic trained on their paper before finding that 3D Jacobian conjecture counterexample.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694539")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("It’s remarkable how close mathematicians were to solving these longstanding problems just as AI became capable of doing the same.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694680")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Mathematicians don’t like how AI companies don’t cite any existing literature on the topic in their papers, even though their work relies on significant potions of the existing literature, without which their advances would be impossible. It is an extreme violation of ethics and norms in mathematics, and any human mathematician found doing the same as these AI companies would find their mathematical career ended overnight.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694785")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Right, I also believe that something as groundbreaking and important as AI should not be in the hands of private companies at all (or if they are should be much more heavily regulated)…but if government suddenly starts regulating more heavily the AI bubble pops and we’re all screwed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebc6ce9a3594cd121a1098ba872636afc57ff53ea2ebe7dc79db86dedcde2994-8f41740d018ef99fcdb0d665dfa9270930a7eba0803598efb7d97d89c6c5ecce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Max Hoffmann")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694823")[#strong[#text("Daniel Max Hoffmann")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("“And if you gaze long enough into an abyss, the abyss will gaze back into you” (F. Nietzsche)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694922")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I have started a section on wikipedia summarizing OpenAI assertions on the reuse of user data.")

#link("https://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_priority_controversy#Dispute_between_OpenAI_and_Buckmaster%E2%80%93Alp%C3%B6ge")[#text("https://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_priority_controversy#Dispute_between_OpenAI_and_Buckmaster%E2%80%93Alp%C3%B6ge")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694948")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("There’s a paragraph on the Jacobian conjecture Wikipedia article about AI training on the Borisov, Gabber, and Vasiu draft:")

#link("https://en.wikipedia.org/wiki/Jacobian_conjecture#Counterexample_for_n_%3E_2")[#text("https://en.wikipedia.org/wiki/Jacobian_conjecture#Counterexample_for_n_%3E_2")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-694938")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Buckmaster’s Codex prompts from the preceding ")#emph[#text("two months")]#text(" could not have influenced its system,")
]

#text("That is a very very carefully chosen cutoff wording. Two months back from now is already after you (Andreas) turned off model training, right?")

#text("That this was the explanation by the spokesperson provided to eg ABC News Australia immediately caught my eye. They already said that it couldn’t be ruled out “that de-identified data derived from their usage of our products helped improve our models”, now having a company official announcement “we will say very clearly “prompts couldn’t have influenced the system [except before the 10th July]” strikes me as highly incongruous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-695470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("I am always surprised about the naivety of otherwise highly intelligent people. We all know since the start of AI that these companies do not care about intellectual rights or giving proper credit with respect to the data used for training, and still the unspoken assumption seems to be they do? Please, whatever you put in a prompt can be regarded as ‘published’ and ‘open’ for them. Their behavior is very consistent. It’s the users that should change theirs. Don’t AInteract.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03eb358a3e31b35d7ddb29429efd1ac8a387bc1a7bf44b9c2a70b32868ef6720-507149cfaa8e38d54dd26558a50860d891804a5bd5de257b8cbd7e90af7c22c2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Ruxton")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-695729")[#strong[#text("Mike Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Many mathematics papers include a note to the effect “this work has greatly benefitted from conversations with colleagues Andrew Wiles, Terence Tao, Edward Witten, and Jacob Tsimerman.”")

#text("An acknowledgement by AI results that “this work has greatly benefitted from the digestion of recent works by Andreas Thom, Levent Alpoge, and Julia Stadlmann” might be a reasonable expectation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidmfisher")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/#comment-696119")[#strong[#text("davidmfisher")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("A very talented student I taught early in his career recently decided to go work in AI security instead of pursuing a career in math. I hear from his father, a collaborator, that he now complains about his need to sleep because it is clear to him that the bots he has doing tasks for him take his absence as an opportunity to improvise. This is the real problem at the heart of AI and I think why the companies can’t actually tell us what is or is not in training data definitively. No one has complete control of the systems and they are prone to improvise and to cheat the controls that do exist. Of course the problem this presents to credit in mathematics is less profound than the problems it presents for depending on AI in many other contexts.")
]
