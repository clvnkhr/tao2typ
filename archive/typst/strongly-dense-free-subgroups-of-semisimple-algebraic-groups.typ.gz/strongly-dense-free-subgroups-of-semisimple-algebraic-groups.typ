// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/10/21/strongly-dense-free-subgroups-of-semisimple-algebraic-groups/
// Converted to Typst by tao2typ: "2026-10-14T16:36:20.504729+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Strongly dense free subgroups of semisimple algebraic groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Strongly dense free subgroups of semisimple algebraic groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 October 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/10/21/strongly-dense-free-subgroups-of-semisimple-algebraic-groups/")[#text("https://terrytao.wordpress.com/2010/10/21/strongly-dense-free-subgroups-of-semisimple-algebraic-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.math.u-psud.fr/~breuilla/indexgb.html")[#text("Emmanuel Breuillard")]#text(", ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", ")#link("http://www-rcf.usc.edu/~guralnic/")[#text("Robert Guralnick")]#text(", and I have just uploaded to the arxiv our paper “")#link("http://arxiv.org/abs/1010.4259")[#text("Strongly dense free subgroups of semisimple algebraic groups")]#text("“, submitted to ")#link("http://www.ma.huji.ac.il/~ijmath/")[#text("Israel J. Math.")]#text(". This paper was originally motivated by (and provides a key technical tool for) another forthcoming paper of ours, on ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expander")]#text(" ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graphs")]#text(" in finite simple ")#link("http://en.wikipedia.org/wiki/Group_of_Lie_type")[#text("groups of Lie type")]#text(", but also has some independent interest due to connections with other topics, such as the ")#link("http://en.wikipedia.org/wiki/Banach-Tarski_paradox")[#text("Banach-Tarski paradox")]#text(".")

#text("Recall that one of the basic facts underlying the Banach-Tarski paradox is that the rotation group ")#mi("O(3)")#text(" contains a copy of the free non-abelian group ")#mi("F_2")#text(" on two generators; thus there exists ")#mi("a, b \\in O(3)")#text(" such that ")#mi("a,b")#text(" obey no nontrivial word identities. In fact, using basic algebraic geometry, one can then deduce that a ")#emph[#text("generic")]#text(" pair ")#mi("(a,b)")#text(" of group elements ")#mi("a, b \\in O(3)")#text(" has this property, where for the purposes of this paper “generic” means “outside of at most countably many algebraic subvarieties of strictly smaller dimension”. (In particular, using Haar measure on ")#mi("O(3)")#text(", almost every pair has this property.) In fact one has a stronger property, given any non-trivial word ")#mi("w \\in F_2")#text(", the associated word map ")#mi("(a,b) \\mapsto w(a,b)")#text(" from ")#mi("O(3) \\times O(3)")#text(" to ")#mi("O(3)")#text(" is a ")#link("http://en.wikipedia.org/wiki/Rational_mapping#Dominant_and_birational_maps")[#text("dominant")]#text(" map, which means that its image is ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski")]#text("-dense. More succinctly, if ")#mi("(a,b)")#text(" is generic, then ")#mi("w(a,b)")#text(" is generic also.")

#text("In contrast, if one were working in a solvable, nilpotent, or abelian group (such as ")#mi("O(2)")#text("), then this property would not hold, since every subgroup of a solvable group is still solvable and thus not free (and similarly for nilpotent or abelian groups). (This already goes a long way to explain why the Banach-Tarski paradox holds in three or more dimensions, but not in two or fewer.) On the other hand, a ")#link("http://www.ams.org/mathscinet-getitem?mr=702738")[#text("famous result of Borel")]#text(" asserts that for any semisimple Lie group ")#mi("G")#text(" (over an algebraically closed field), and any nontrivial word ")#mi("w \\in F_2")#text(", the word map ")#mi("w: G \\times G \\to G")#text(" is dominant, thus generalising the preceding discussion for ")#mi("O(3)")#text(". (There is also the even more famous ")#link("http://en.wikipedia.org/wiki/Tits_alternative")[#text("Tits alternative")]#text(", that asserts that any linear group that is not (virtually) solvable will contain a copy of the free group ")#mi("F_2")#text("; as pointed out to me by Michael Cowling, this already shows that generic pairs of generators will generate a free group, and with a little more effort one can even show that it generates a Zariski-dense free group.)")

#text("Now suppose we take ")#emph[#text("two")]#text(" words ")#mi("w_1, w_2 \\in F_2")#text(", and look at the double word map ")#mi("(w_1,w_2): G \\times G \\to G \\times G")#text(" on a semisimple Lie group ")#mi("G")#text(". If ")#mi("w_1, w_2")#text(" are non-trivial, then Borel’s theorem tells us that each component of this map is dominant, but this does not mean that the entire map is dominant, because there could be constraints between ")#mi("w_1(a,b)")#text(" and ")#mi("w_2(a,b)")#text(". For instance, if the two words ")#mi("w_1, w_2")#text(" commute, then ")#mi("w_1(a,b), w_2(a,b)")#text(" must also commute and so the image of the double word map is not Zariski-dense. But there are also non-commuting examples of non-trivial constraints: for instance, if ")#mi("w_1, w_2")#text(" are conjugate, then ")#mi("w_1(a,b), w_2(a,b)")#text(" must also be conjugate, which is also a constraint that obstructs dominance.")

#text("It is still not clear exactly what pairs of words ")#mi("w_1, w_2")#text(" have the dominance property. However, we are able to establish that all pairs of non-commuting words have a weaker property than dominance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" Let ")#mi("w_1, w_2 \\in F_2")#text(" be non-commuting words, and let ")#mi("a, b")#text(" be generic elements of a semisimple Lie group ")#mi("G")#text(" over an algebraically closed field. Then ")#mi("w_1(a,b), w_2(a,b)")#text(" generate a Zariski-dense subgroup of ")#mi("G")#text(".")
]

#text("To put it another way, ")#mi("G")#text(" not only contains free subgroups, but contains what we call strongly dense free subgroups: free subgroups such that any two non-commuting elements generate a Zariski-dense subgroup.")

#text("Our initial motivation for this theorem is its implications for finite simple groups ")#mi("G")#text(" of Lie type. Roughly speaking, one can use this theorem to show that a generic random walk in such a group cannot be trapped in a (bounded complexity) proper algebraic subgroup ")#mi("H")#text(" of ")#mi("G")#text(", and this “escape from subgroups” fact is a key ingredient in our forthcoming paper in which we demonstrate that random Cayley graphs in such groups are expander graphs.")

#text("It also has implications for results of Banach-Tarski type; it shows that for any semisimple Lie group G, and for generic ")#mi("a, b \\in G")#text(", one can use ")#mi("a, b")#text(" to create Banach-Tarski paradoxical decompositions for all homogeneous spaces of ")#mi("G")#text(". In particular there is one pair of ")#mi("a,b")#text(" that gives paradoxical decompositions for all homogeneous spaces simultaneously.")

#text("Our argument is based on a concept that we call “degeneration”. Let ")#mi("a, b")#text(" be generic elements of ")#mi("G")#text(", and suppose for contradiction that ")#mi("w_1(a,b), w_2(a,b)")#text(" generically generated a group whose algebraic closure was conjugate to a proper algebraic subgroup ")#mi("H")#text(" of ")#mi("G")#text(". Borel’s theorem lets us show that ")#mi("w_1(a,b), w_2(a,b)")#text(", and latex [w_1(a,b), w_2(a,b)]$ each generate maximal tori of ")#mi("G")#text(", which by basic algebraic group theory can be used to show that ")#mi("H")#text(" must be a proper semisimple subgroup of ")#mi("G")#text(" of maximal rank. If we were in the model case ")#mi("G = SL_n")#text(", then we would already be done, as there are no such maximal rank semisimple subgroups; but in the other groups, such proper maximal semisimple groups unfortunately exist. Fortunately, they have been completely classified, and we take advantage of this classification in our argument.")

#text("The degeneration argument comes in as follows. Let ")#mi("(a,b)")#text(" be a ")#emph[#text("non")]#text("-generic pair in ")#mi("G \\times G")#text(". Then ")#mi("(a,b)")#text(" lies in the Zariski closure of the generic pairs, which means that ")#mi("(w_1(a,b), w_2(a,b))")#text(" lies in the Zariski closure of the set formed by ")#mi("H \\times H")#text(" and its conjugates. In particular, if the non-generic pair is such that ")#mi("w_1(a,b), w_2(a,b)")#text(" generates a group that is dense in some proper algebraic subgroup ")#mi("H^{\\prime}")#text(", then ")#mi("H^{\\prime} \\times H^{\\prime}")#text(" is in the Zariski closure of the union of the conjugates of ")#mi("H \\times H")#text(". When this happens, we say that ")#mi("H^{\\prime}")#text(" is a ")#emph[#text("degeneration")]#text(" of ")#mi("H")#text(". (For instance, ")#mi("H")#text(" could be the stabiliser of some non-degenerate quadratic form, and ")#mi("H^{\\prime}")#text(" could be the stabiliser of a degenerate limit of that form.)")

#text("The key fact we need (that relies on the classification, and a certain amount of representation theory) is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition.")]#text(" Given any proper semisimple maximal rank subgroup ")#mi("H")#text(" of ")#mi("G")#text(", there exists another proper semisimple subgroup ")#mi("H^{\\prime}")#text(" that is ")#emph[#text("not")]#text(" a degeneration of ")#mi("H")#text(".")
]

#text("Using an induction hypothesis, we can find pairs ")#mi("(a,b)")#text(" such that ")#mi("w_1(a,b), w_2(a,b)")#text(" generate a dense subgroup of ")#mi("H^{\\prime}")#text(", which together with the preceding discussion contradicts the proposition.")

#text("The proposition is currently proven by using some known facts about certain representation-theoretic invariants of all the semisimple subgroups of the classical and exceptional simple Lie groups. While the proof is of finite length, it is not particularly elegant, ultimately relying on the numerical value of one or more invariants of ")#mi("H")#text(" being sufficiently different from their counterparts for ")#mi("H^{\\prime}")#text(" that one can prevent the latter being a degeneration of the former. Perhaps there is another way to proceed here that is not based so heavily on classification.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Exceptional isogenies between the classical Lie groups « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/21/strongly-dense-free-subgroups-of-semisimple-algebraic-groups/#comment-50676")[#strong[#text("Exceptional isogenies between the classical Lie groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2011")])]

#text("[…] the homomorphism (with the kernel once again being ). These sorts of embeddings were useful in a recent paper of Breuillard, Green, Guralnick, and myself, as they gave examples of semisimple groups that could be easily separated from other semisimple […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An erratum to “Strongly dense free subgroups of semisimple Lie groups” « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/21/strongly-dense-free-subgroups-of-semisimple-algebraic-groups/#comment-51084")[#strong[#text("An erratum to “Strongly dense free subgroups of semisimple Lie groups” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("[…] year, Emmanuel Breuillard, Ben Green, Rob Guralnick, and I wrote a paper entitled “Strongly dense free subgroups of semisimple Lie groups“. The main theorem in that paper asserted that given any semisimple algebraic group over an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb60d0f893124fdbd4172c3dcf709a6c730e36cb9b0602fad4a0a85586a1d16-352be768f3a1f0853fd3d4a46d65b025ef1dc9f8a2979f28fb6def09a469a98c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An erratum to “Strongly dense free subgroups of semisimple Lie groups” « IMAGINATION of MATH")]], [#link("https://terrytao.wordpress.com/2010/10/21/strongly-dense-free-subgroups-of-semisimple-algebraic-groups/#comment-51089")[#strong[#text("An erratum to “Strongly dense free subgroups of semisimple Lie groups” « IMAGINATION of MATH")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("[…] year, Emmanuel Breuillard, Ben Green, Bob Guralnick, and I wrote a paper entitled “Strongly dense free subgroups of semisimple Lie groups“. The main theorem in that paper asserted that given any semisimple algebraic group over an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expansion in finite simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/21/strongly-dense-free-subgroups-of-semisimple-algebraic-groups/#comment-244500")[#strong[#text("Expansion in finite simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("[…] groups of Lie type“. This long-delayed paper (announced way back in 2010!) is a followup to our previous paper in which we showed that, with one possible exception, generic pairs of elements of a simple […]")
]
