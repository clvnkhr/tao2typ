// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/
// Converted to Typst by tao2typ: "2026-10-14T15:16:31.551474+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the property testing of hereditary graph and hypergraph properties", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the property testing of hereditary graph and hypergraph properties")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/")[#text("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This month I have been at the ")#link("http://www.math.ias.edu/")[#text("Institute for Advanced Study")]#text(", participating in their ")#link("http://www.math.ias.edu/pages/activities/special-programs/arithmetic-combinatorics.php")[#text("semester program on additive combinatorics")]#text(". Today I gave a talk on my forthcoming paper with ")#link("http://www.math.ucla.edu/~timaustin/")[#text("Tim Austin")]#text(" on the property testing of graphs and ")#link("http://en.wikipedia.org/wiki/Hypergraph")[#text("hypergraphs")]#text(" (I hope to make a preprint available here soon). There has been an immense amount of progress on these topics recently, based in large part on the graph and hypergraph regularity lemmas; but we have discovered some surprising subtleties regarding these results, namely a distinction between undirected and directed graphs, between graphs and hypergraphs, between partite hypergraphs and non-partite hypergraphs, and between monotone hypergraph properties and hereditary ones.")

#text("For simplicity let us first work with (uncoloured, undirected, loop-free) ")#link("http://en.wikipedia.org/wiki/Graph_%28mathematics%29")[#text("graphs")]#text(" G = (V,E). In the subject of graph property testing, one is given a property ")#mi("{\\mathcal P}")#text(" which any given graph G may or may not have. For example, ")#mi("{\\mathcal P}")#text(" could be one of the following properties:")

#enum(start: 1, 
[#text("G is ")#link("http://en.wikipedia.org/wiki/Planar_graph")[#text("planar")]#text(".")],
[#text("G is ")#link("http://en.wikipedia.org/wiki/Graph_coloring")[#text("four-colourable")]#text(".")],
[#text("G has a number of edges equal to a power of two.")],
[#text("G contains no triangles.")],
[#text("G is ")#link("http://en.wikipedia.org/wiki/Bipartite_graph")[#text("bipartite")]#text(".")],
[#text("G is empty.")],
[#text("G is a ")#link("http://en.wikipedia.org/wiki/Complete_bipartite_graph")[#text("complete bipartite graph")]#text(".")]
)

#text("We assume that the labeling of the graph is irrelevant. More precisely, we assume that whenever two graphs G, G’ are ")#link("http://en.wikipedia.org/wiki/Graph_isomorphism")[#text("isomorphic")]#text(", that G satisfies ")#mi("{\\mathcal P}")#text(" if and only if G’ satisfies ")#mi("{\\mathcal P}")#text(". For instance, all seven of the graph properties listed above are invariant under graph isomorphism.")

#text("We shall think of G as being very large (so ")#tao-math("\\left|V\\right|", block: false)#text(" is large) and dense (so ")#tao-math("\\left|E\\right| \\sim \\left|V\\right|^2", block: false)#text("). We are interested in obtaining some sort of test that can answer the question “does G satisfy ")#mi("{\\mathcal P}")#text("?” with reasonable speed and reasonable accuracy. By “reasonable speed”, we mean that we will only make a bounded number of queries about the graph, i.e. we only look at a bounded number k of distinct vertices in V (selected at random) and base our test purely on how these vertices are connected to each other in E. (We will always assume that the number of vertices in V is at least k.) By “reasonable accuracy”, we will mean that we specify in advance some error tolerance ")#mi("\\varepsilon > 0")#text(" and require the following:")

#enum(start: 1, 
[#text("(No ")#link("http://en.wikipedia.org/wiki/False_negative")[#text("false negatives")]#text(") If G indeed satisfies ")#mi("{\\mathcal P}")#text(", then our test will always (correctly) accept G.")],
[#text("(Few ")#link("http://en.wikipedia.org/wiki/False_positive")[#text("false positives")]#text(" in the ")#mi("\\varepsilon")#text("-far case) If G fails to satisfy ")#mi("{\\mathcal P}")#text(", and is furthermore ")#mi("\\varepsilon")#text("-far from satisfying ")#mi("{\\mathcal P}")#text(" in the sense that one needs to add or remove at least ")#tao-math("\\varepsilon \\left|V\\right|^2", block: false)#text(" edges in G before ")#mi("{\\mathcal P}")#text(" can be satisfied, then our test will (correctly) reject G with probability at least ")#mi("\\varepsilon")#text(".")]
)

#text("When a test with the above properties exists for each given ")#mi("\\varepsilon > 0")#text(" (with the number of queried vertices k being allowed to depend on ")#mi("\\varepsilon")#text("), we say that the graph property ")#mi("{\\mathcal P}")#text(" is ")#emph[#text("testable with one-sided error")]#text(". (The general notion of property testing was introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=1379300")[#text("by Rubinfeld and Sudan")]#text(", and first studied for graph properties ")#link("http://www.ams.org/mathscinet-getitem?mr=1450632")[#text("by Goldreich, Goldwasser, and Ron")]#text("; see ")#link("http://www.wisdom.weizmann.ac.il/~oded/test.html")[#text("this web page of Goldreich")]#text(" for further references and discussion.) The rejection probability ")#mi("\\varepsilon")#text(" is not very important in this definition, since if one wants to improve the success rate of the algorithm one can simply run independent trials of that algorithm (selecting fresh random vertices each time) in order to increase the chance that G is correctly rejected. However, it is intuitively clear that one must allow ")#emph[#text("some ")]#text("probability of failure, since one is only inspecting a small portion of the graph and so cannot say with complete certainty whether the entire graph has the property ")#mi("{\\mathcal P}")#text(" or not. For similar reasons, one cannot reasonably demand to have a low false positive rate for all graphs that fail to obey ")#mi("{\\mathcal P}")#text(", since if the graph is only one edge modification away from obeying ")#mi("{\\mathcal P}")#text(", this modification is extremely unlikely to be detected by only querying a small portion of the graph. This explains why we need to restrict attention to graphs that are ")#mi("\\varepsilon")#text("-far from obeying ")#mi("{\\mathcal P}")#text(".")

#text("An example should illustrate this definition. Consider for instance property 6 above (the property that G is empty). To test whether a graph is empty, one can perform the following obvious algorithm: take k vertices in G at random and check whether they have any edges at all between them. If they do, then the test of course rejects G as being non-empty, while if they don’t, the test accepts G as being empty. Clearly there are no false negatives in this test, and if k is large enough depending on ")#mi("\\varepsilon")#text(" one can easily see (from the law of large numbers) that we will have few false positives if G is ")#mi("\\varepsilon")#text("-far from being empty (i.e. if it has at least ")#tao-math("\\varepsilon \\left|V\\right|^2", block: false)#text(" vertices). So the property of being empty is testable with one-sided error.")

#text("On the other hand, it is intuitively obvious that property 3 (having an number of edges equal to a power of 2) is not testable with one-sided error.")

#text("So it is reasonable to ask: what types of graph properties are testable with one-sided error, and which ones are not?")

#metadata(none) <tao-d988fa354dd8bc253334>

#text("If we “deconstruct” at our test for property 6 (that a graph is empty), we see that we implicitly relied on the (obvious) fact that any ")#link("http://en.wikipedia.org/wiki/Induced_subgraph")[#text("induced subgraph")]#text(" of an empty graph is again empty. This leads to a definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition")]#text(". A graph property ")#mi("{\\mathcal P}")#text(" is ")#emph[#text("hereditary")]#text(" if whenever a graph G obeys ")#mi("{\\mathcal P}")#text(", then all induced subgraphs of G obey ")#mi("{\\mathcal P}")#text(" also.")
]

#text("For instance, except for property 3, all the graph properties listed previously are hereditary.")

#text("Given a hereditary property ")#mi("{\\mathcal P}")#text(", and a positive integer k, there is an obvious test ")#mi("\\text{Test}_k")#text(" for this property, which samples k vertices from a graph G at random, looks at the induced subgraph, and declares that G obeys ")#mi("{\\mathcal P}")#text(" if and only if the induced subgraph does. The hereditary nature of ")#mi("{\\mathcal P}")#text(" ensures that ")#mi("\\text{Test}_k")#text(" generates no false negative. What about false positives? A ")#link("http://www.math.tau.ac.il/~nogaa/PDFS/heredit2.pdf")[#text("result of Alon and Shapira")]#text(" (building on an enormous number of partial results by several authors, too many to be listed here) shows that this is OK as long as k is large enough:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(". Let ")#mi("{\\mathcal P}")#text(" be a hereditary graph property, and let ")#mi("\\varepsilon > 0")#text(". Then if k is sufficiently large depending on ")#mi("{\\mathcal P}")#text(" and ")#mi("\\varepsilon")#text(", then ")#mi("\\text{Test}_k")#text(" has a false positive rate of at most ")#mi("\\varepsilon")#text(" for any graph which is ")#mi("\\varepsilon")#text("-far from satisfying ")#mi("{\\mathcal P}")#text(".")
]

#text("In particular, they show that every hereditary graph property is testable with one-sided error. In the converse direction, they show that any “natural” property which is testable with one-sided error is “almost” hereditary, though the definitions of “natural” and “almost” are slightly technical and will not be discussed here. (One also needs a further technical assumption that the tester is oblivious to the number of vertices in the graph.) One amusing fact is that even if ")#mi("{\\mathcal P}")#text(" is a computable property, the size of k required in order for the above theorem to apply need not be computable (for reasons related to the ")#link("http://en.wikipedia.org/wiki/Halting_problem")[#text("halting problem")]#text("); indeed, it can be shown that given the right choice of ")#mi("{\\mathcal P}")#text(", k can grow faster than any given function of ")#mi("1/\\varepsilon")#text(" (e.g. the ")#link("http://en.wikipedia.org/wiki/Ackermann_function")[#text("Ackermann function")]#text(").")

#text("The result of Alon-Shapira was extended to hypergraphs by several authors (including ")#link("http://www.ams.org/mathscinet-getitem?mr=1967402")[#text("Kohayakawa-Nagle-Rödl")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2195580")[#text("Gowers")]#text(", ")#link("http://www.informatik.hu-berlin.de/~schacht/pub/preprints/dense_reg2.pdf")[#text("Rödl-Schacht")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2299696")[#text("Avart-Rödl-Schacht")]#text(", ")#link("http://arxiv.org/abs/math/0612669")[#text("Ishigami")]#text(", and ")#link("http://arxiv.org/abs/0705.2179")[#text("Elek-Szegedy")]#text("); the definitions of terms such as “hereditary” and “testable with one sided error” are straightforward. In particular one has the following result of ")#link("http://www.informatik.hu-berlin.de/~schacht/pub/preprints/gen_removal.pdf")[#text("Rödl-Schacht")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(". For any fixed k, the results of Theorem 1 are also true for k-uniform hypergraphs (i.e. hypergraphs in which every edge consists of exactly k vertices).")
]

#text("These results are rather non-trivial to prove, relying heavily on the graph regularity lemma and hypergraph regularity lemma respectively. (As an indication of the depth of these results, Theorem 1 already implies ")#link("http://en.wikipedia.org/wiki/Roth's_theorem")[#text("Roth’s theorem")]#text(" on arithmetic progressions of length 3, and Theorem 2 implies ")#link("http://scholarpedia.org/article/Szemer%C3%A9di's_Theorem")[#text("Szemerédi’s theorem")]#text("; this connection was first observed by Ruzsa and Szemerédi.)")

#text("In my forthcoming paper with Tim Austin, we extend Theorem 2 slightly by allowing the hypergraphs to be directed, multi-coloured, and ")#mi("\\leq k")#text("-uniform rather than k-uniform (so that edges are also allowed to have fewer than k edges). However, this is not the focus of my talk today.")

#text("The above results give a fairly definitive answer as to what properties of graphs and hypergraphs are testable with one-sided error. However, this is not the end of the story, because the Alon-Shapira and Rödl-Schacht arguments are quite different. In particular, the Alon-Shapira argument is constructive in the following sense. One can rephrase Theorem 1 in the following equivalent form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1, again")]#text(": If ")#mi("{\\mathcal P}")#text(" is a hereditary property and ")#mi("\\varepsilon > 0")#text(", then there exists ")#mi("k \\geq 1")#text(" and ")#mi("\\delta > 0")#text(" such that whenever G=(V,E) is a graph with k-locally verifies ")#mi("{\\mathcal P}")#text(" to accuracy ")#mi("\\delta")#text(", in the sense that a random induced subgraph of G on k vertices will obey ")#mi("{\\mathcal P}")#text(" with probability at least ")#mi("1-\\delta")#text(", then G can be “repaired” to obtain a new graph G’ that globally verifies ")#mi("{\\mathcal P}")#text(" by modifying at most ")#tao-math("\\varepsilon \\left|V\\right|^2", block: false)#text(" edges.")
]

#text("The argument of Alon and Shapira in fact provides a constructive (randomised) algorithm to build G’ from G. To oversimplify enormously, the idea is to first apply the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" to G to create a finite complexity model for G, and then use that model to decide how to modify G to create G’. Actually there are two significant difficulties that arise in this approach. Firstly, it may be that the property ")#mi("{\\mathcal P}")#text(" is not “local”, in which case a single application of the regularity lemma does not suffice due to the accumulation of error terms in the associated “counting lemma”. For instance, the property of being bipartite is equivalent to containing no odd cycles, so in order to completely check for bipartiteness one needs to deal with cycles of arbitrarily long length, which cannot be evaluated locally and so which cannot be counted accurately in terms of a Szemerédi partition. However, once one fixes the finite complexity model for G, there are only finitely many modification rules that are possible; each one of these will either create a graph that obeys ")#mi("{\\mathcal P}")#text(", or will fail to do so for some local reason (e.g. a rule may fail to give a bipartite graph because it allows for cycles of length 37). Combining all these potential local failures together, we see that we can effectively replace the non-local property ")#mi("{\\mathcal P}")#text(" by a local property ")#mi("{\\mathcal P}_{loc}")#text(" for the purposes of modification rules based on this finite complexity model (it is at this point where one needs to solve a problem analogous to the halting problem). One then applies the regularity lemma again at a much finer degree of accuracy (depending on how local ")#mi("{\\mathcal P}_{loc}")#text(" really is) in order to obtain a counting lemma that is sufficiently accurate to enable one to design a good modification rule. But then one runs into a second difficulty concerning “diagonal interactions”. More precisely, the problem is that the edges within a single Szemerédi cell need not be regular enough for one to be able to safely design a modification rule for these edges. In order to fix this, one needs to regularise even further, replacing each cell with a moderately large number of smaller cells, which have various edge density behaviours with respect to each other, but such that the interactions between pairs of these cells is always regular. One can then appeal to ")#link("http://en.wikipedia.org/wiki/Ramsey%27s_theorem")[#text("Ramsey’s theorem")]#text(" to make all these edge densities coherent enough to design a viable modification rule. [If the above paragraph made no sense to you, don’t worry; the only thing you really need to remember from it for the purposes of this talk is that the Alon-Shapira argument uses Ramsey’s theorem. It also uses the regularity lemma repeatedly, but the parameters involved in using that lemma do not depend on the size of the graph.]")

#text("From the nature of the Alon-Shapira argument, it turns out that the repaired graph G’ can be obtained from the original graph G by a local modification rule. More precisely, there exists an integer k and a rule A which takes graphs on k+2 labeled vertices and returns either 0 or 1, such that one can generate G’ from G by first selecting k vertices ")#mi("v_1,\\ldots,v_k")#text(" from G at random, and then defining G’ by declaring two vertices ")#mi("w_1")#text(" and ")#mi("w_2")#text(" to be joined by an edge in G’ if and only if the rule A, when applied to the restriction of G to ")#mi("v_1,\\ldots,v_k,w_1,w_2")#text(", gives 1.")

#text("To illustrate how this type of local repair rule works (it is analogous to the notion of a ")#link("http://en.wikipedia.org/wiki/Error_detection_and_correction")[#text("locally correctable code")]#text(" in coding theory), let us use property 7 above, i.e. that of being a complete bipartite graph. Suppose that G is a slightly corrupted complete bipartite graph, e.g. it was obtained from a random complete bipartite graph between two classes A, B on a large number N of vertices by adding and deleting ")#mi("\\varepsilon N^2")#text(" of the edges, thus G will now contain a small number of edges within one of the bipartite classes A, B, and also exclude a small number of edges between the two classes A, B. The challenge is now to locally repair this graph G to obtain a new graph G’ which is close to G and which is genuinely complete bipartite (but it does not necessarily have to be the original uncorrupted graph).")

#text("[To give an experimental analogy for this task, imagine a large collection of identical-seeming balls, half of which are positively charged and half of which are negatively charged. Suppose we can conduct experiments on pairs of these balls to see whether they attract each other or not, but due to experimental error, these experiments are occasionally unreliable: a pair of like charged particles may accidentally be reported to attract each other, and similarly there is a small probability that a pair of unlike charged particles may be reported to not attract each other. Our task is to conduct these slightly unreliable experiments so that we can efficiently separate the balls into two classes, so that balls within one class almost never attract each other, while balls in different classes almost always do.]")

#text("To do this, we do the following. We first pick a large odd number k (we take k to be odd to break ties later) and inspect k vertices ")#mi("v_1,\\ldots,v_k")#text(" at random from G. The restriction ")#mi("G_k")#text(" of G to this set will also look like a corruption of the complete bipartite graph between the classes . By brute force search over all the complete bipartite graphs on k vertices, one can then (with high probability) find a complete bipartite graph ")#mi("G^{\\prime}_k")#text(" on these vertices which is close to ")#mi("G_k")#text(". Let ")#mi("A^{\\prime}_k")#text(" and ")#mi("B^{\\prime}_k")#text(" denote the bipartite classes of ")#mi("G^{\\prime}_k")#text(", thus ")#mi("\\{v_1,\\ldots,v_k\\} = A^{\\prime}_k \\cup B^{\\prime}_k")#text(". These classes are likely to be very close to the restrictions ")#mi("A_k := A \\cap \\{v_1,\\ldots,v_k\\}")#text(", ")#mi("B_k := B \\cap \\{v_1,\\ldots,v_k\\}")#text(" of the oclasses for the original (uncorrupted) bipartite graph restricted to ")#mi("\\{v_1,\\ldots,v_k\\}")#text("; it is also possible that the classes become swapped (thus ")#mi("B^{\\prime}_k")#text(" is close to ")#mi("A_k")#text(" and ")#mi("A^{\\prime}_k")#text(" is close to ")#mi("B_k")#text("), although this will turn out to not be important. Because of these considerations, we see that most of the vertices in G will either be highly connected with ")#mi("A^{\\prime}_k")#text(" (and almost totally disconnected with ")#mi("B^{\\prime}_k")#text("), or vice versa. This suggests partitioning these vertices into two classes A’ and B’ by majority vote: B’ consists of those vertices which have more connections with ")#mi("A^{\\prime}_k")#text(" than with ")#mi("B^{\\prime}_k")#text(", and vice versa for A’. One can then verify that the complete bipartite graph between A’ and B’ will be very close to G (or to the original uncorrupted bipartite graph) with high probability, with the accuracy of this repair algorithm increasing with k. (Actually, this algorithm is already rather good just for k=1.)")

#text("Let us call a graph property ")#mi("{\\mathcal P}")#text(" locally repairable if, in the situation in Theorem 1, there is a local repair rule to generate from G (and from a random choice ")#mi("v_1,\\ldots,v_k")#text(" of vertices) a repaired graph G’ which always obeys ")#mi("{\\mathcal P}")#text(", and which will differ by at most ")#tao-math("\\varepsilon \\left|V\\right|^2", block: false)#text(" edges from G with probability at least ")#mi("1 - \\varepsilon")#text(".")

#text("Tim Austin and I were then able to adapt the Alon-Shapira argument show the following strengthening of Theorem 1:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1′")]#text(". Every hereditary graph property is locally repairable. In fact, the same result holds if one allows the graph to be multi-coloured, to contain loops, or be infinite (but in the latter case one has to provide some probability distribution on the set of vertices as a substitute for the uniform distribution).")
]

#text("The Alon-Shapira argument used Ramsey theory, and so do we. In fact, this is an essential component of the argument, because Theorem 1′ (in particular, the generalisation to looped graphs) implies Ramsey’s theorem. To see this, let ")#mi("{\\mathcal P}")#text(" be the property that a looped graph contains no monochromatic induced subgraphs of some fixed size k. This property is impossible to satisfy for any non-trivial graph, since by considering the subgraph induced by k repetitions ")#mi("v, \\ldots, v")#text(" of a single vertex we necessarily obtain a monochromatic graph. Hence, it is clearly not possible to locally repair a graph to obey ")#mi("{\\mathcal P}")#text(". Applying Theorem 1′ in the contrapositive, we deduce that every graph must fail to k-locally verify ")#mi("{\\mathcal P}")#text(" with some positive probability, which implies Ramsey’s theorem.")

#text("In view of Theorem 2, it was of course natural to try to extend Theorem 1′ to hypergraphs. Unfortunately, the Rödl-Schacht argument does not provide such a local repair argument; their argument proceeded by an indirect method, assuming for contradiction that Theorem 2 failed, and then producing a sequence ")#mi("G_n")#text(" of increasingly large counterexamples to that theorem. One then performed the rather unusual trick of regularising (very large) hypergraphs that were late in this sequence at a level of accuracy that depended on the size of (much smaller) hypergraphs that were early in this sequence; this allowed one to “almost embed” the small hypergraphs in the large ones, which could eventually be used to repair the small hypergraph. Another indication why the Rödl-Schacht argument would be insufficient to obtain a local repair version of Theorem 2 is that that argument did not use any Ramsey theory.")

#text("On the other hand, it is tempting to extend the Alon-Shapira method to hypergraphs. This was done for instance ")#link("http://arxiv.org/abs/math/0612669")[#text("by Ishigami")]#text(" for partite hypergraphs, and we were also able to extend Theorem 1′ to hypergraph properties that were not only hereditary, but also monotone (which means that deletion of edges cannot destroy the property). Monotone properties are significantly easier to study than hereditary ones, because any collection of edges which is causing some difficulty for the purposes of designing a modification rule can simply be deleted, so long as the total number of edges deleted is not too large. Partite graphs were also simpler because the troublesome “diagonal interactions”, in which an edge intersected with a single Szemerédi cell multiple times, were completely eliminated.")

#text("For the general situation of hereditary properties on non-partite hypergraphs, a large portion of the Alon-Shapira argument goes through, but we found that the Ramsey theory step (which was needed to deal with diagonal interactions) caused a lot of trouble. Eventually, we in fact found a counterexample to the Ramsey theory statement that we needed (which is unfortunately too technical to state here), which then soon propagated to a counterexample to the entire statement itself. More precisely, we were able to show the following negative results:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(". There exists a hereditary property of 3-uniform hypergraphs which is not locally repairable. Also, there exists a hereditary property of directed graphs which is not locally repairable.")
]

#text("Thus there are some interesting transitions in behaviour between the testability of hereditary properties for graphs and hypergraphs, for undirected graphs and directed graphs, for partite hypergraphs and non-partite hypergraphs, and for monotone hypergraph properties and hereditary hypergraph properties. In all four cases, the former properties are locally repairable, whereas the latter are merely testable.")

#text("To sketch the ideas behind Theorem 3, it is simpler to start with the latter statement, concerning directed graphs. We can think of a directed graph as a pair ")#mi("(V,<)")#text(" consisting of a finite vertex set V, together with a relation < on that set. The property ")#mi("{\\mathcal P}")#text(" we shall pick for this directed graph is very simple: it is the property that the relation < is a ")#link("http://en.wikipedia.org/wiki/Total_ordering")[#text("total ordering")]#text(". This is clearly a hereditary property, and thus testable with one-sided error (by the usual testing method of sampling a few vertices from V and seeing whether < is a total ordering on those vertices).")

#text("Unfortunately, the property of being a total ordering is not locally repairable. One can intuitively see this as follows. Let <‘ be a slight random corruption of the standard total ordering < on the numbers ")#mi("\\{1,\\ldots,N\\}")#text(", thus if ")#mi("1 \\leq i < j \\leq n")#text(" then the relation ")#mi("i <^{\\prime} j")#text(" will hold true with probability ")#mi("1-\\varepsilon")#text(" and fail with probability ")#mi("\\varepsilon")#text(", and vice versa for the relation ")#mi("j <^{\\prime} i")#text(", with all events being independent. (In particular, we will occasionally discover that ")#mi("i <^{\\prime} j")#text(" and ")#mi("j <^{\\prime} i")#text(" are both true, or both false.)")

#text("Now let us try to locally repair this corrupted total ordering <‘ into a new total ordering <” by a local repair rule. This entails selecting k numbers ")#mi("v_1,\\ldots,v_k")#text(" from ")#mi("\\{1,\\ldots,n\\}")#text(" at random, and then designing a rule for the ordering <” by deciding the truth value of ")#mi("w_1 <^{\\prime\\prime} w_2")#text(" based solely on how ")#mi("v_1,\\ldots,v_k,w_1,w_2")#text(" are ordered via <‘.")

#text("For the sake of this informal discussion, let us suppose that we are lucky enough that the relation <‘ is uncorrupted for the purposes of comparing any element with ")#mi("v_1,\\ldots,v_k")#text(", or comparing two elements between ")#mi("v_1,\\ldots,v_k")#text(". This allows us to order ")#mi("v_1,\\ldots,v_k")#text(" correctly, and then all other vertices w can be correctly positioned in one of the intervals ")#mi("(v_i,v_{i+1})")#text(" between two adjacent vertices (or in one of the boundary intervals ")#mi("{}[1,v_1)")#text(", ")#mi("(v_k,N]")#text("). This already allows us to design a local repair rule that will correctly rank any two vertices ")#mi("w_1, w_2")#text(" which lie in different intervals, simply by declaring all elements in the higher interval to be greater than those in the lower. However, we run into problems when deciding on what to do for ")#mi("w_1 <^{\\prime\\prime} w_2")#text(" in the case when ")#mi("w_1, w_2")#text(" both lie in the same interval; in that case, ")#mi("w_1")#text(" and ")#mi("w_2")#text(" are indistinguishable from each other as far as their connectivity to ")#mi("v_1,\\ldots,v_k")#text(" is concerned. One still has the relations ")#mi("w_1 <^{\\prime} w_2")#text(" and ")#mi("w_2 <^{\\prime} w_1")#text(" available to us, but this information is corrupted and thus unreliable. Indeed, it is possible to find ")#mi("w_1, w_2")#text(" in the same interval such that ")#mi("w_1 <^{\\prime} w_2")#text(" and ")#mi("w_2 <^{\\prime} w_1")#text(" have the same truth value, so we have total indistinguishability between ")#mi("w_1")#text(" and ")#mi("w_2")#text(". In particular, any local repair rule for <” will necessarily be such that ")#mi("w_1 <^{\\prime\\prime} w_2")#text(" and ")#mi("w_2 <^{\\prime\\prime} w_1")#text(" have the same truth value, so that this rule cannot possibly give a total ordering. This basically explains how we verify the second part of Theorem 3.")

#text("To modify these arguments to also establish the first part of Theorem 3, we used two encoding tricks: one trick that encoded a directed graph property as a property of ")#mi("\\leq 3")#text("-uniform hypergraphs, and a second trick that encoded a property of ")#mi("\\leq 3")#text("-uniform hypergraphs as a property of 3-uniform hypergraphs. I will only discuss the first trick, as it accomplishes the surprising and unintuitive feat of modeling an asymmetric property by a symmetric one.")

#text("Let us first understand what a ")#mi("\\leq 3")#text("-uniform hypergraph is. One can think of this hypergraph as a collection of three things: a 1-uniform hypergraph ")#mi("G_1")#text(" (i.e. a vertex colouring), a 2-uniform hypergraph ")#mi("G_2")#text(" (i.e. an ordinary graph), and a 3-uniform hypergraph ")#mi("G_3")#text(" (a collection of triples of vertices). (Strictly speaking, there is also a 0-uniform component, but this component is rather trivial and plays no role). To make things a bit easier to visualise, let us describe these objects ")#mi("G_1, G_2, G_3")#text(" using more colourful notation:")

#enum(start: 1, 
[#text("We call a vertex ")#emph[#text("blue")]#text(" if it lies in ")#mi("G_1")#text(", and ")#emph[#text("red")]#text(" otherwise.")],
[#text("We say that two vertices ")#emph[#text("like")]#text(" each other if they lie in ")#mi("G_2")#text(", and ")#emph[#text("dislike")]#text(" each other otherwise.")],
[#text("We say that three vertices are ")#emph[#text("properly ranked")]#text(" iff they lie in ")#mi("G_3")#text(".")]
)

#text("The property ")#mi("{\\mathcal P}")#text(" will be some property relating the notions of blue, red, like, dislike, and proper ranking. Before we describe this propertly, let us first describe a model example of a hypergraph that obeys this property. It is defined as follows:")

#enum(start: 1, 
[#text("The vertex set consists of the 2N integers ")#mi("\\{1,\\ldots,2N\\}")#text(".")],
[#text("The first N integers ")#mi("\\{1,\\ldots,N\\}")#text(" are blue, the rest are red.")],
[#text("Each red vertex will like a given blue vertex with an independent probability of 1/2. (We will not care whether blue vertices like each other or not, and similarly for a pair of red vertices.)")],
[#text("We say that three vertices are properly ranked iff one vertex is red, the other two are blue, the red vertex likes one of the blue vertices and dislikes the other, and the blue vertex which is liked has a higher numerical value than the one which is disliked.")]
)

#text("Now let us describe the property ")#mi("{\\mathcal P}")#text(" which the above hypergraph satisfies. For every red vertex r, we define a relation ")#mi("<_{r}")#text(" on the blue vertices by declaring $latex b")

#text("It is then possible to adapt the indistinguishability argument used for directed graphs to obtain a failure of local repairability for this property. A further adaptation then gives the first part of Theorem 3.")

#text("It may well be that this failure of local repairability can be avoided by weakening the notion of local repairability into some notion intermediate between local repairability and testability, but we have not explored this issue thoroughly.")

#text("[")#emph[#text("Update")]#text(", Nov 1: References added.]")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6faa8c428d3d589e8c3a215286dc3436f0a45a2179137716ec086a56cf7e24-027f32b39ece402c5524c74fa9c532ba5fcdfd950078a47bce4932c42a45e138.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Internet")]], [#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/#comment-13402")[#strong[#text("The Internet")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2007")])]

#text("1. This is very interesting work – how soon will there be a preprint ?")

#text("2. If you are still at IAS, please give Sasha and Russell a kick in the butt and tell them that The Internet wants them to file their letters of recommendation in a timely manner.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/#comment-13486")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2007")])]

#text("Hi Terence,")

#text("For the above ‘… properties: 1 G is planar.’")

#text("Lacking rigorous ability, intuitively, I suspect that G may be generalized to some or perhaps all minimum surfaces?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/#comment-18297")[#strong[#text("Carnival of Mathematics #21: Bar-hopping at last « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2007")]

#text("[…] of course, the carnivalist is spoiled for choice. One of the more interesting selections lately was On the property testing of hereditary graph and hypergraph properties. (As you may note, this post also played on my school spirit [institute spirit?] by name-checking […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the testability and repair of hereditary hypergraph properties « What’s new")]], [#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/#comment-24582")[#strong[#text("On the testability and repair of hereditary hypergraph properties « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2008")])]

#text("[…] negative results have already been discussed in a previous posting of mine, so today I will focus on the positive results. The property testing results here are finitary […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The correspondence principle and finitary ergodic theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/#comment-32348")[#strong[#text("The correspondence principle and finitary ergodic theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2008")])]

#text("[…] that it actually implies the k=3 case of Szemerédi’s theorem. (See also my previous blog posts on related topics.) It turns out that this result can be deduced from some infinitary versions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/353141aae94df7fa820777cb2404306103c8b4d2cb07198e646dd27cd03b4fd8-ae54acbeb25fd6976c81a2bd90e2755b6b6bf11acb02b45569f51a48e53cc15f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JFG")]], [#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/#comment-35242")[#strong[#text("JFG")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2009")])]

#text("Dear Prof. Tao:")#linebreak()#text(" do you know what is the easier ( more simple) latex package to draw graphs and hypergraphs?And what is the best at this moment? I would be very glad if you could give me some link or orientation.")#linebreak()#text(" Many thanks")#linebreak()#text(" Sincerely yours")#linebreak()#text(" JFGH")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/226868f1639f07bf0e81ec2ec6f13a19c4a88fc1303d9efd3d7f8a10016a55e6-e2de1802d9acb8d938e289887c39d1038d94654cef9517dae329a03a9c490985.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vitaly")]], [#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/#comment-39632")[#strong[#text("Vitaly")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2009")])]

#text("Just to inform about new textbook “Introduction to Graph and Hypergraph Theory”")

#link("https://www.novapublishers.com/catalog/advanced_search_result.php?keywords=vitaly+voloshin&osCsid=d784a24d32097bffc878bd9c831a2591")[#text("https://www.novapublishers.com/catalog/advanced_search_result.php?keywords=vitaly+voloshin&osCsid=d784a24d32097bffc878bd9c831a2591")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/#comment-454246")[#strong[#text("New Isoperimetric Results for Testing Monotonicity | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2015")]

#text("[…] Property testing is an exciting area which lies between mathematics and the theory of computing. (Closely related to PCP and to some modern aspects of error-correcting codes.) Here is a post about it in Terry Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c23fddc6998ce0ec65a3cf62b2ad3ab144990071004bc3a676561d1fdcf0be7-bf9ee5fb646bad1459880c423ac08ab3ac8278241dbcba3e552db49f6c44053c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/31/on-the-property-testing-of-hereditary-graph-and-hypergraph-properties/#comment-455990")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2015")])]

#text("Dear Terence,")

#text("Small correction: In theorem 1 and the paragraph above it – false negative should be false positive, to be consistent with your definition of testable with one sided error.")

#text("Great blog by the way, as noticeable – it was discovered late by me but I’ll catch up.")

#text("Yair")

#emph[#text("[Corrected, thanks – T.]")]
]
