// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/
// Converted to Typst by tao2typ: "2026-10-14T15:19:41.925032+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Equivalence of the logarithmically averaged Chowla and Sarnak conjectures", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Equivalence of the logarithmically averaged Chowla and Sarnak conjectures")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 May 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/")[#text("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1605.04628")[#text("Equivalence of the logarithmically averaged Chowla and Sarnak conjectures")]#text("“, submitted to the Festschrift “Number Theory – Diophantine problems, uniform distribution and applications” in honour of ")#link("https://de.wikipedia.org/wiki/Robert_Tichy")[#text("Robert F. Tichy")]#text(". This paper is a spinoff of ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("my previous paper")]#text(" establishing a logarithmically averaged version of the Chowla (and Elliott) conjectures in the two-point case. In that paper, the estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n) \\lambda(n+h)}{n} = o( \\log x )")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" was demonstrated, where ")#mi("{h}")#text(" was any positive integer and ")#mi("{\\lambda}")#text(" denoted the Liouville function. The proof proceeded using a method I call the “entropy decrement argument”, which ultimately reduced matters to establishing a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\frac{\\left|\\sum_{h \\leq H} \\lambda(n+h) e( \\alpha h)\\right|}{n} = o( H \\log x )", block: true)]]

#text("whenever ")#mi("{H}")#text(" was a slowly growing function of ")#mi("{x}")#text(". This was in turn established in a ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("previous paper of Matomaki, Radziwill, and myself")]#text(", using the ")#link("http://arxiv.org/abs/1501.04585")[#text("recent breakthrough of Matomaki and Radziwill")]#text(".")

#text("It is natural to see to what extent the arguments can be adapted to attack the higher-point cases of the logarithmically averaged Chowla conjecture (ignoring for this post the more general Elliott conjecture for other bounded multiplicative functions than the Liouville function). That is to say, one would like to prove that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n+h_1) \\dots \\lambda(n+h_k)}{n} = o( \\log x )")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" for any fixed distinct integers ")#mi("{h_1,\\dots,h_k}")#text(". As it turns out (and as is detailed in the current paper), the entropy decrement argument extends to this setting (after using some known facts about linear equations in primes), and allows one to reduce the above estimate to an estimate of the form")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\frac{1}{n} \\left\\| \\lambda \\right\\|_{U^d[n, n+H]} = o( \\log x )", block: true)]]

#text("for ")#mi("{H}")#text(" a slowly growing function of ")#mi("{x}")#text(" and some fixed ")#mi("{d}")#text(" (in fact we can take ")#mi("{d=k-1}")#text(" for ")#mi("{k \\geq 3}")#text("), where ")#mi("{U^d}")#text(" is the (normalised) local Gowers uniformity norm. (In the case ")#mi("{k=3}")#text(", ")#mi("{d=2}")#text(", this becomes the Fourier-uniformity conjecture discussed in ")#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/")[#text("this previous post")]#text(".) If one then applied the (now proven) inverse conjecture for the Gowers norms, this estimate is in turn equivalent to the more complicated looking assertion ")#metadata(none) <tao-a39bec7c3dc2c0bae76c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sum_{n \\leq x} \\frac{1}{n} \\sup \\left|\\sum_{h \\leq H} \\lambda(n+h) F( g^h x )\\right| = o( \\log x )", block: true)]]

#text("where the supremum is over all possible choices of ")#emph[#text("nilsequences")]#text(" ")#mi("{h \\mapsto F(g^h x)}")#text(" of controlled step and complexity (see the paper for definitions of these terms).")

#text("The main novelty in the paper (elaborating upon a ")#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-462979")[#text("previous comment")]#text(" I had made on this blog) is to observe that this latter estimate in turn follows from the logarithmically averaged form of Sarnak’s conjecture (discussed in ")#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("this previous post")]#text("), namely that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1}{n} \\lambda(n) F( T^n x )= o( \\log x )")]]

#text("whenever ")#mi("{n \\mapsto F(T^n x)}")#text(" is a zero entropy (i.e. deterministic) sequence. Morally speaking, this follows from the well-known fact that nilsequences have zero entropy, but the presence of the supremum in ")#link(<tao-a39bec7c3dc2c0bae76c>)[#text("(1)")]#text(" means that we need a little bit more; roughly speaking, we need the ")#emph[#text("class")]#text(" of nilsequences of a given step and complexity to have “uniformly zero entropy” in some sense.")

#text("On the other hand, it was already known (see ")#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("previous post")]#text(") that the Chowla conjecture implied the Sarnak conjecture, and similarly for the logarithmically averaged form of the two conjectures. Putting all these implications together, we obtain the pleasant fact that the logarithmically averaged Sarnak and Chowla conjectures are equivalent, which is the main result of the current paper. There have been a large number of special cases of the Sarnak conjecture worked out (when the deterministic sequence involved came from a special dynamical system), so these results can now also be viewed as partial progress towards the Chowla conjecture also (at least with logarithmic averaging). However, my feeling is that the full resolution of these conjectures will not come from these sorts of special cases; instead, conjectures like the Fourier-uniformity conjecture in ")#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/")[#text("this previous post")]#text(" look more promising to attack.")

#text("It would also be nice to get rid of the pesky logarithmic averaging, but this seems to be an inherent requirement of the entropy decrement argument method, so one would probably have to find a way to avoid that argument if one were to remove the log averaging.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/#comment-468695")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2016")])]

#text("Did you mean “It was already know that the Chowla conjecture implies the Sarnak conjecture” instead of the other way around?")

#emph[#text("[Corrected, thanks -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/#comment-468696")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2016")])]

#text("It seems that the exponent ")#mi("(d+1)/2^d")#text(" (in the estimate above (1)) does not appear in the arXiv paper.")

#emph[#text("[Ah, I had forgotten I had used the normalised Gowers norms in the paper rather than the non-normalised norms. The notation is now aligned -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Bombieri asymptotic sieve | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/#comment-470706")[#strong[#text("Notes on the Bombieri asymptotic sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("[…] Chowla conjecture, for which there has been some recent progress (discussed for instance in these recent posts). Informally, the Bombieri asymptotic sieve lets us (on GEH) view the twin prime conjecture […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/#comment-478889")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] I was able to show that this conjecture was equivalent to the logarithmically averaged Chowla conjecture, and hence to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/#comment-484809")[#strong[#text("The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("[…] be difficult (though perhaps not completely impossible if one allows for logarithmic averaging): in a previous paper I showed that achieving this in the context of the Liouville function would be equivalent to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/#comment-508356")[#strong[#text("Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("[…] the same hypotheses on and . As I worked out in a previous paper, this conjecture would imply a logarithmically averaged three-point Chowla conjecture, implying for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/#comment-578368")[#strong[#text("Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("[…] as for any fixed and any that goes to infinity as , where is the (normalized) Gowers uniformity norm. Among other things this conjecture implies (logarithmically averaged version of) the Chowla and Sarnak conjectures for the Liouville function (or the Möbius function), see this previous blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of arithmetic functions in short intervals II. Almost all intervals | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/#comment-686736")[#strong[#text("Higher uniformity of arithmetic functions in short intervals II. Almost all intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("[…] There is particular interest in such estimates in the case of the Möbius function (where, as per the Möbius pseudorandomness conjecture, the approximant should be taken to be zero, at least in the absence of a Siegel zero). This is because if one could get estimates of this form for any that grows sufficiently slowly in (in particular ), this would imply the (logarithmically averaged) Chowla conjecture, as I showed in a previous paper. […]")
]
