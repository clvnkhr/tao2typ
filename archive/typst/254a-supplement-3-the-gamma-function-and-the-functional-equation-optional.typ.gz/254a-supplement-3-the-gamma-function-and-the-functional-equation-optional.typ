// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/
// Converted to Typst by tao2typ: "2026-10-14T15:19:19.002575+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Supplement 3: The Gamma function and the functional equation (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Supplement 3: The Gamma function and the functional equation (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 December 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" ")#mi("{\\zeta}")#text(" (and more generally, the ")#link("http://en.wikipedia.org/wiki/Dirichlet_L-function")[#text("Dirichlet ")#mi("{L}")#text("-functions")]#text(" ")#mi("{L(\\cdot,\\chi)}")#text(") were extended meromorphically into the region ")#mi("{\\{ s: \\text{Re}(s) > 0 \\}}")#text(" in and to the right of the critical strip. This is a sufficient amount of meromorphic continuation for many applications in analytic number theory, such as establishing the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" and its variants. The zeroes of the zeta function in the critical strip ")#mi("{\\{ s: 0 < \\text{Re}(s) < 1 \\}}")#text(" are known as the ")#emph[#text("non-trivial zeroes")]#text(" of ")#mi("{\\zeta}")#text(", and thanks to the truncated explicit formulae developed in ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", they control the asymptotic distribution of the primes (up to small errors).")

#text("The ")#mi("{\\zeta}")#text(" function obeys the trivial functional equation ")#metadata(none) <tao-9f70a08b9c3424cb3380>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\zeta(\\overline{s}) = \\overline{\\zeta(s)}")]]

#linebreak()#text(" for all ")#mi("{s}")#text(" in its domain of definition. Indeed, as ")#mi("{\\zeta(s)}")#text(" is real-valued when ")#mi("{s}")#text(" is real, the function ")#mi("{\\zeta(s) - \\overline{\\zeta(\\overline{s})}}")#text(" vanishes on the real line and is also meromorphic, and hence vanishes everywhere. Similarly one has the functional equation ")#metadata(none) <tao-d007e6d8c8a31cc6e98c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\overline{L(s, \\chi)} = L(\\overline{s}, \\overline{\\chi}).")]]

#text("From these equations we see that the zeroes of the zeta function are symmetric across the real axis, and the zeroes of ")#mi("{L(\\cdot,\\chi)}")#text(" are the reflection of the zeroes of ")#mi("{L(\\cdot,\\overline{\\chi})}")#text(" across this axis.")#linebreak()#text(" It is a remarkable fact that these functions obey an additional, and more non-trivial, functional equation, this time establishing a symmetry across the ")#emph[#text("critical line")]#text(" ")#mi("{\\{ s: \\text{Re}(s) = \\frac{1}{2} \\}}")#text(" rather than the real axis. One consequence of this symmetry is that the zeta function and ")#mi("{L}")#text("-functions may be extended meromorphically to the entire complex plane. For the zeta function, the functional equation was discovered by Riemann, and reads as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Functional equation for the Riemann zeta function)")]#text(" ")#metadata(none) <tao-f63827270b16435ec079>#text(" The Riemann zeta function ")#mi("{\\zeta}")#text(" extends meromorphically to the entire complex plane, with a simple pole at ")#mi("{s=1}")#text(" and no other poles. Furthermore, one has the functional equation ")#metadata(none) <tao-3c417b7ea567c3115dee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\zeta(s) = \\alpha(s) \\zeta(1-s)")]]

#text("or equivalently ")#metadata(none) <tao-44ba554e17977b31413d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\zeta(1-s) = \\alpha(1-s) \\zeta(s)")]]

#text("for all complex ")#mi("{s}")#text(" other than ")#mi("{s=0,1}")#text(", where ")#mi("{\\alpha}")#text(" is the function ")#metadata(none) <tao-757671c7f82e739e630e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\alpha(s) := 2^s \\pi^{s-1} \\sin( \\frac{\\pi s}{2}) \\Gamma(1-s).")]]

#text("Here ")#mi("{\\cos(z) := \\frac{e^{iz} + e^{-iz}}{2}}")#text(", ")#mi("{\\sin(z) := \\frac{e^{-iz}-e^{-iz}}{2i}}")#text(" are the complex-analytic extensions of the classical trigionometric functions ")#mi("{\\cos(x), \\sin(x)}")#text(", and ")#mi("{\\Gamma}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(", whose definition and properties we review below the fold.")
]

#text("The functional equation can be placed in a more symmetric form as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2 (Functional equation for the Riemann xi function)")]#text(" ")#metadata(none) <tao-17057013652043f03365>#text(" The ")#link("http://en.wikipedia.org/wiki/Riemann_Xi_function")[#text("Riemann xi function")]#text(" ")#metadata(none) <tao-c765d2f7b42f2a483927>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\xi(s) := \\frac{1}{2} s(s-1) \\pi^{-s/2} \\Gamma(\\frac{s}{2}) \\zeta(s)")]]

#text("is analytic on the entire complex plane ")#mi("{{\\bf C}}")#text(" (after removing all removable singularities), and obeys the functional equations")

#align(center)[#tao-fit-display[#mitex("\\xi(\\overline{s}) = \\overline{\\xi(s)}")]]

#text("and ")#metadata(none) <tao-d9914b51fa0bad0262cd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\xi(s) = \\xi(1-s).")]]

#text("In particular, the zeroes of ")#mi("{\\xi}")#text(" consist precisely of the non-trivial zeroes of ")#mi("{\\zeta}")#text(", and are symmetric about both the real axis and the critical line. Also, ")#mi("{\\xi}")#text(" is real-valued on the critical line and on the real axis.")
]

#text("Corollary ")#link(<tao-17057013652043f03365>)[#text("2")]#text(" is an easy consequence of Theorem ")#link(<tao-f63827270b16435ec079>)[#text("1")]#text(" together with the duplication theorem for the Gamma function, and the fact that ")#mi("{\\zeta}")#text(" has no zeroes to the right of the critical strip, and is left as an exercise to the reader (Exercise ")#link(<tao-05669361000669df75ba>)[#text("19")]#text("). The functional equation in Theorem ")#link(<tao-f63827270b16435ec079>)[#text("1")]#text(" has many proofs, but most of them are related in on way or another to the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(" ")#metadata(none) <tao-c8c3727df724362b5453>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_n f(n) = \\sum_m \\hat f(2\\pi m)")]]

#linebreak()#text(" (Theorem 34 from ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(", at least in the case when ")#mi("{f}")#text(" is twice continuously differentiable and compactly supported), which can be viewed as a Fourier-analytic link between the coarse-scale distribution of the integers and the fine-scale distribution of the integers. Indeed, there is a quick heuristic proof of the functional equation that comes from formally applying the Poisson summation formula to the function ")#mi("{1_{x>0} \\frac{1}{x^s}}")#text(", and noting that the functions ")#mi("{x \\mapsto \\frac{1}{x^s}}")#text(" and ")#mi("{\\xi \\mapsto \\frac{1}{\\xi^{1-s}}}")#text(" are formally Fourier transforms of each other, up to some Gamma function factors, as well as some trigonometric factors arising from the distinction between the real line and the half-line. Such a heuristic proof can indeed be made rigorous, and we do so below the fold, while also providing Riemann’s two classical proofs of the functional equation.")#linebreak()#text(" From the functional equation (and the poles of the Gamma function), one can see that ")#mi("{\\zeta}")#text(" has ")#emph[#text("trivial zeroes")]#text(" at the negative even integers ")#mi("{-2,-4,-6,\\dots}")#text(", in addition to the non-trivial zeroes in the critical strip. More generally, the following table summarises the zeroes and poles of the various special functions appearing in the functional equation, after they have been meromorphically extended to the entire complex plane, and with zeroes classified as “non-trivial” or “trivial” depending on whether they lie in the critical strip or not. (Exponential functions such as ")#mi("{2^{s-1}}")#text(" or ")#mi("{\\pi^{-s}}")#text(" have no zeroes or poles, and will be ignored in this table; the zeroes and poles of rational functions such as ")#mi("{s(s-1)}")#text(" are self-evident and will also not be displayed here.)")

#table(columns: 4, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Function")],
table.cell(colspan: 1, rowspan: 1)[#text("Non-trivial zeroes")],
table.cell(colspan: 1, rowspan: 1)[#text("Trivial zeroes")],
table.cell(colspan: 1, rowspan: 1)[#text("Poles")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\zeta(s)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-2,-4,-6,\\dots}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\zeta(1-s)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#mi("{3,5,\\dots}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\sin(\\pi s/2)}")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Even integers")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\cos(\\pi s/2)}")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Odd integers")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\sin(\\pi s)}")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Integers")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\Gamma(s)}")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0,-1,-2,\\dots}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\Gamma(s/2)}")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0,-2,-4,\\dots}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\Gamma(1-s)}")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1,2,3,\\dots}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\Gamma((1-s)/2)}")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1,3,5,\\dots}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\xi(s)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("No")]
)

#text("Among other things, this table indicates that the Gamma and trigonometric factors in the functional equation are tied to the trivial zeroes and poles of zeta, but have no direct bearing on the distribution of the non-trivial zeroes, which is the most important feature of the zeta function for the purposes of analytic number theory, beyond the fact that they are symmetric about the real axis and critical line. In particular, the Riemann hypothesis is not going to be resolved just from further analysis of the Gamma function!")

#text("The zeta function computes the “global” sum ")#mi("{\\sum_n \\frac{1}{n^s}}")#text(", with ")#mi("{n}")#text(" ranging all the way from ")#mi("{1}")#text(" to infinity. However, by some Fourier-analytic (or complex-analytic) manipulation, it is possible to use the zeta function to also control more “localised” sums, such as ")#mi("{\\sum_n \\frac{1}{n^s} \\psi(\\log n - \\log N)}")#text(" for some ")#mi("{N \\gg 1}")#text(" and some smooth compactly supported function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(". It turns out that the functional equation ")#link(<tao-3c417b7ea567c3115dee>)[#text("(3)")]#text(" for the zeta function localises to this context, giving an ")#emph[#text("approximate functional equation")]#text(" which roughly speaking takes the form")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{1}{n^s} \\psi( \\log n - \\log N ) \\approx \\alpha(s) \\sum_m \\frac{1}{m^{1-s}} \\psi( \\log M - \\log m )")]]

#text("whenever ")#mi("{s=\\sigma+it}")#text(" and ")#tao-math("{NM = \\frac{\\left|t\\right|}{2\\pi}}", block: false)#text("; see Theorem ")#link(<tao-16fd1a0850622e16b737>)[#text("39")]#text(" below for a precise formulation of this equation. Unsurprisingly, this form of the functional equation is also very closely related to the Poisson summation formula ")#link(<tao-c8c3727df724362b5453>)[#text("(8)")]#text(", indeed it is essentially a special case of that formula (or more precisely, of the ")#link("http://en.wikipedia.org/wiki/Van_der_Corput%27s_method")[#text("van der Corput ")#mi("{B}")#text("-process")]#text("). This useful identity relates long smoothed sums of ")#mi("{\\frac{1}{n^s}}")#text(" to short smoothed sums of ")#mi("{\\frac{1}{m^{1-s}}}")#text(" (or vice versa), and can thus be used to shorten exponential sums involving terms such as ")#mi("{\\frac{1}{n^s}}")#text(", which is useful when obtaining some of the more advanced estimates on the Riemann zeta function.")#linebreak()#text(" We will give two other basic uses of the functional equation. The first is to get a good count (as opposed to merely an upper bound) on the density of zeroes in the critical strip, establishing the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")[#text("Riemann-von Mangoldt formula")]#text(" that the number ")#mi("{N(T)}")#text(" of zeroes of imaginary part between ")#mi("{0}")#text(" and ")#mi("{T}")#text(" is ")#mi("{\\frac{T}{2\\pi} \\log \\frac{T}{2\\pi} - \\frac{T}{2\\pi} + O(\\log T)}")#text(" for large ")#mi("{T}")#text(". The other is to obtain untruncated versions of the explicit formula from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory")[#text("Notes 2")]#text(", giving a remarkable exact formula for sums involving the von Mangoldt function in terms of zeroes of the Riemann zeta function. These results are not strictly necessary for most of the material in the rest of the course, but certainly help to clarify the nature of the Riemann zeta function and its relation to the primes.")

#text("In view of the material in previous notes, it should not be surprising that there are analogues of all of the above theory for Dirichlet ")#mi("{L}")#text("-functions ")#mi("{L(\\cdot,\\chi)}")#text(". We will restrict attention to primitive characters ")#mi("{\\chi}")#text(", since the ")#mi("{L}")#text("-function for imprimitive characters merely differs from the ")#mi("{L}")#text("-function of the associated primitive factor by a finite Euler product; indeed, if ")#mi("{\\chi = \\chi^{\\prime} \\chi_0}")#text(" for some principal ")#mi("{\\chi_0}")#text(" whose modulus ")#mi("{q_0}")#text(" is coprime to that of ")#mi("{\\chi^{\\prime}}")#text(", then ")#metadata(none) <tao-1c1e366a18160655959a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("L(s,\\chi) = L(s,\\chi^{\\prime}) \\prod_{p|q_0} (1 - \\frac{1}{p^s})")]]

#linebreak()#text(" (cf. equation (45) of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory")[#text("Notes 2")]#text(").")#linebreak()#text(" The main new feature is that the Poisson summation formula needs to be “twisted” by a Dirichlet character ")#mi("{\\chi}")#text(", and this boils down to the problem of understanding the finite (additive) Fourier transform of a Dirichlet character. This is achieved by the classical theory of ")#link("http://en.wikipedia.org/wiki/Gauss_sum")[#text("Gauss sums")]#text(", which we review below the fold. There is one new wrinkle; the value of ")#mi("{\\chi(-1) \\in \\{-1,+1\\}}")#text(" plays a role in the functional equation. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Functional equation for ")#mi("{L}")#text("-functions)")]#text(" ")#metadata(none) <tao-4ef6f0b42e4be3ba589c>#text(" Let ")#mi("{\\chi}")#text(" be a primitive character of modulus ")#mi("{q}")#text(" with ")#mi("{q>1}")#text(". Then ")#mi("{L(s,\\chi)}")#text(" extends to an entire function on the complex plane, with")

#align(center)[#tao-fit-display[#mitex("L(s,\\chi) = \\varepsilon(\\chi) 2^s \\pi^{s-1} q^{1/2-s} \\sin(\\frac{\\pi}{2}(s+\\kappa)) \\Gamma(1-s) L(1-s,\\overline{\\chi})")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("L(1-s,\\overline{\\chi}) = \\varepsilon(\\overline{\\chi}) 2^{1-s} \\pi^{-s} q^{s-1/2} \\sin(\\frac{\\pi}{2}(1-s+\\kappa)) \\Gamma(s) L(s,\\chi)")]]

#text("for all ")#mi("{s}")#text(", where ")#mi("{\\kappa}")#text(" is equal to ")#mi("{0}")#text(" in the even case ")#mi("{\\chi(-1)=+1}")#text(" and ")#mi("{1}")#text(" in the odd case ")#mi("{\\chi(-1)=-1}")#text(", and ")#metadata(none) <tao-ecba710d4a728b1971a8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\varepsilon(\\chi) := \\frac{\\tau(\\chi)}{i^\\kappa \\sqrt{q}}")]]

#text("where ")#mi("{\\tau(\\chi)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Gauss_sum")[#text("Gauss sum")]#text(" ")#metadata(none) <tao-d5e49029578bedaffc67>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\tau(\\chi) := \\sum_{n \\in {\\bf Z}/q{\\bf Z}} \\chi(n) e(n/q).")]]

#text("and ")#mi("{e(x) := e^{2\\pi ix}}")#text(", with the convention that the ")#mi("{q}")#text("-periodic function ")#mi("{n \\mapsto e(n/q)}")#text(" is also (by abuse of notation) applied to ")#mi("{n}")#text(" in the cyclic group ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(".")
]

#text("From this functional equation and ")#link(<tao-d007e6d8c8a31cc6e98c>)[#text("(2)")]#text(" we see that, as with the Riemann zeta function, the non-trivial zeroes of ")#mi("{L(s,\\chi)}")#text(" (defined as the zeroes within the critical strip ")#mi("{\\{ s: 0 < \\text{Re}(s) < 1 \\}}")#text(" are symmetric around the critical line (and, if ")#mi("{\\chi}")#text(" is real, are also symmetric around the real axis). In addition, ")#mi("{L(s,\\chi)}")#text(" acquires trivial zeroes at the negative even integers and at zero if ")#mi("{\\chi(-1)=1}")#text(", and at the negative odd integers if ")#mi("{\\chi(-1)=-1}")#text(". For imprimitive ")#mi("{\\chi}")#text(", we see from ")#link(<tao-1c1e366a18160655959a>)[#text("(9)")]#text(" that ")#mi("{L(s,\\chi)}")#text(" also acquires some additional trivial zeroes on the left edge of the critical strip.")

#text("There is also a symmetric version of this equation, analogous to Corollary ")#link(<tao-17057013652043f03365>)[#text("2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(" ")#metadata(none) <tao-9d3e1d99bbb47e290f2e>#text(" Let ")#mi("{\\chi,q,\\varepsilon(\\chi)}")#text(" be as above, and set")

#align(center)[#tao-fit-display[#mitex("\\xi(s,\\chi) := (q/\\pi)^{(s+\\kappa)/2} \\Gamma((s+\\kappa)/2) L(s,\\chi),")]]

#text("then ")#mi("{\\xi(\\cdot,\\chi)}")#text(" is entire with ")#mi("{\\xi(1-s,\\overline{\\chi}) = \\varepsilon(\\chi) \\xi(s,\\chi)}")#text(".")
]

#text("For further detail on the functional equation and its implications, I recommend the classic ")#link("http://www.ams.org/mathscinet-getitem?mr=882550")[#text("text of Titchmarsh")]#text(" or the ")#link("http://www.ams.org/mathscinet-getitem?mr=606931")[#text("text of Davenport")]#text(".")

#metadata(none) <tao-031d7d3f9ac35c983f13>

#heading(level: 1)[#strong[#text(" — 1. The Gamma function — ")]]

#text("There are many ways to define the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(", but we will use the following classical definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Gamma function)")]#text(" For any complex number ")#mi("{s}")#text(" with ")#mi("{\\text{Re} s > 0}")#text(", the Gamma function ")#mi("{\\Gamma(s)}")#text(" is defined as ")#metadata(none) <tao-3d9219b73013678e9663>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\Gamma(s) = \\int_0^\\infty t^{s-1} e^{-t}\\ dt = \\int_0^\\infty t^s e^{-t} \\frac{dt}{t}.")]]
]

#text("It is easy to see that the integrals here are absolutely convergent. One can view ")#mi("{\\Gamma}")#text(" as the inner product between the multiplicative character ")#mi("{t \\mapsto t^s}")#text(" and the additive character ")#mi("{t \\mapsto e^{-t}}")#text(" with respect to multiplicative Haar measure ")#mi("{\\frac{dt}{t}}")#text(". As such, the Gamma function often appears as a normalisation factor in integrals that involve both additive and multiplicative characters. For instance, by a simple change of variables we see that ")#metadata(none) <tao-f745a15153c4dacf0ea4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\int_0^\\infty t^{s-1} e^{-at}\\ dt = \\frac{\\Gamma(s)}{a^s}")]]

#linebreak()#text(" whenever ")#mi("{\\text{Re}(s)>0}")#text(" and ")#mi("{a>0}")#text("; indeed, from a contour shift we see that the above identity also holds for complex ")#mi("{a}")#text(" with ")#mi("{\\text{Re}(a) > 0, \\text{Re}(s)>0}")#text(", if we use the standard interpretation ")#mi("{t^{s-1} = \\exp((s-1) \\log t))}")#text(" of the complex exponential with positive real base. Making the further substitution ")#mi("{t = x^2}")#text(" and performing some additional manipulations, we see that the Gamma function is also related to integrals involving Gaussian functions, in that ")#metadata(none) <tao-b6b1ecf2b1b3b58ba2e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\int_{\\bf R} \\left|t\\right|^{s-1} e^{-a^2 t^2}\\ dt = \\frac{\\Gamma(s/2)}{a^s}", block: true)]]

#text("for ")#mi("{\\text{Re}(a), \\text{Re}(s) > 0}")#text(". Later on we will also need the variant ")#metadata(none) <tao-65021ed80cd3995b0709>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\int_{\\bf R} a \\left|t\\right|^{s} e^{-a^2 t^2}\\ dt = \\frac{\\Gamma((s+1)/2)}{a^s},", block: true)]]

#text("which follows from ")#link(<tao-b6b1ecf2b1b3b58ba2e7>)[#text("(14)")]#text(" by replacing ")#mi("{s}")#text(" with ")#mi("{s+1}")#text(".")#linebreak()#text(" From ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_integral_theorem")[#text("Cauchy’s theorem")]#text(" and ")#link("http://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini’s theorem")]#text(" one easily verifies that ")#mi("{\\Gamma}")#text(" has vanishing contour integral on any closed contour in the half-space ")#mi("{\\{ s: \\text{Re}(s) > 0 \\}}")#text(", and thus by ")#link("http://en.wikipedia.org/wiki/Morera%27s_theorem")[#text("Morera’s theorem")]#text(" is holomorphic on this half-space.")

#text("From ")#link(<tao-3d9219b73013678e9663>)[#text("(12)")]#text(" and an integration by parts we see that ")#metadata(none) <tao-01ea9df76bc63a172589>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("s \\Gamma(s) = \\Gamma(s+1)")]]

#linebreak()#text(" for any ")#mi("{s}")#text(" with ")#mi("{\\text{Re}(s) > 0}")#text(". Among other things, this allows us to extend ")#mi("{\\Gamma}")#text(" meromorphically to the entire complex plane, by repeatedly using the form")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) = \\frac{1}{s} \\Gamma(s+1)")]]

#text("of ")#link(<tao-01ea9df76bc63a172589>)[#text("(16)")]#text(" as a ")#emph[#text("definition")]#text(" to meromorphically extend the domain of definition of ")#mi("{\\Gamma}")#text(" leftwards by one unit.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that ")#mi("{\\Gamma(n) = (n-1)!}")#text(" for any natural number ")#mi("{n}")#text(" (thus ")#mi("{\\Gamma(1)=\\Gamma(2) = 1}")#text(", ")#mi("{\\Gamma(3) = 2}")#text(", etc.), and that ")#mi("{\\Gamma}")#text(" has simple poles at ")#mi("{s = 0, -1, -2, \\dots}")#text(" and no further singularities. Thus one can view the Gamma function as a (shifted) generalisation of the factorial function.")
]

#text("By repeating the proof of ")#link(<tao-9f70a08b9c3424cb3380>)[#text("(1)")]#text(", we obtain the conjugation symmetry ")#metadata(none) <tao-df90448e8a2a9f105933>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\Gamma(\\overline{s}) = \\overline{\\Gamma(s)}")]]

#linebreak()#text(" for all ")#mi("{s}")#text(" outside of the poles of ")#mi("{\\Gamma}")#text(". Translating this to the ")#mi("{\\alpha}")#text("-function ")#link(<tao-757671c7f82e739e630e>)[#text("(5)")]#text(", we see that ")#mi("{\\alpha}")#text(" is meromorphic, with a pole at ")#mi("{s=1}")#text(", and that ")#metadata(none) <tao-08b08df04c2b2c05c94e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\alpha(\\overline{s}) = \\overline{\\alpha(s)}")]]

#text("for all ")#mi("{s}")#text(" outside of this pole.")#linebreak()#text(" The Gamma function is also closely connected to the ")#link("http://en.wikipedia.org/wiki/Beta_function")[#text("beta function")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Beta function identity)")]#text(" ")#metadata(none) <tao-f44e64e75f3948e9f73f>#text(" One has")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s_1+s_2) \\int_0^1 t^{s_1-1} (1-t)^{s_2-1}\\ dt = \\Gamma(s_1) \\Gamma(s_2)")]]

#text("whenever ")#mi("{\\text{Re}(s_1), \\text{Re}(s_2) > 0}")#text(". (Note that this hypothesis makes the integral on the left-hand side absolutely integrable.)")
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-3d9219b73013678e9663>)[#text("(12)")]#text(" and Fubini’s theorem one has")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s_1) \\Gamma(s_2) = \\int_0^\\infty \\int_0^\\infty t_1^{s_1-1} t_2^{s_2-1} e^{-t_1-t_2}\\ dt_1 dt_2.")]]

#text("Making the change of variables ")#mi("{(t_1,t_2) = (ut, u(1-t))}")#text(" for ")#mi("{u \\in [0,\\infty)}")#text(" and ")#mi("{t \\in [0,1]}")#text(" (and using absolute integrability to justify this change of variables), the right-hand side becomes")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\int_0^1 u^{s_1+s_2-1} e^{-u} t^{s_1-1} (1-t)^{s_2-1}\\ dt du,")]]

#text("and the claim follows another appeal to ")#link(<tao-3d9219b73013678e9663>)[#text("(12)")]#text(" and Fubini’s theorem. ")#mi("\\Box")#linebreak()#text(" This gives an important ")#link("http://en.wikipedia.org/wiki/Reflection_formula")[#text("reflection formula")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Euler reflection formula)")]#text(" ")#metadata(none) <tao-421c47d8c413985f08df>#text(" One has")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) \\Gamma(1-s) = \\frac{\\pi}{\\sin(\\pi s)}")]]

#text("as meromorphic functions (that is to say, the identity holds outside of the poles of the left or right-hand sides, which occur at the integers). In particular, ")#mi("{\\Gamma}")#text(" has no zeroes in the complex plane.")
]

#text("Note that the reflection formula, when written in terms of the ")#mi("{\\alpha}")#text("-function ")#link(<tao-757671c7f82e739e630e>)[#text("(5)")]#text(", is simply ")#metadata(none) <tao-882c9e2c6858c0a41cc7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\alpha(s) \\alpha(1-s) = 1")]]

#linebreak()#text(" after removing any singularities from the left-hand side. In particular, ")#mi("{\\alpha}")#text(" has zeroes at ")#mi("{s=0,-2,-4,\\dots}")#text(" and poles at ")#mi("{1,3,5,\\dots}")#text(", with no further poles and zeroes. Note that ")#link(<tao-882c9e2c6858c0a41cc7>)[#text("(19)")]#text(" is consistent with the functional equations ")#link(<tao-44ba554e17977b31413d>)[#text("(4)")]#text(", ")#link(<tao-3c417b7ea567c3115dee>)[#text("(3)")]#text(".")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" By unique continuation of meromorphic functions, it suffices to verify this identity in the critical strip ")#mi("{\\{ s: 0 < \\text{Re}(s) < 1 \\}}")#text(". By the beta function identity (and the value ")#mi("{\\Gamma(1)=1}")#text("), it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 t^{s-1} (1-t)^{-s}\\ dt = \\frac{\\pi}{\\sin(\\pi s)}")]]

#text("for ")#mi("{s}")#text(" in the critical strip.")#linebreak()#text(" If we make the substitution ")#mi("{z := \\frac{t}{1-t}}")#text(", so that ")#mi("{t = \\frac{z}{z+1}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 t^{s-1} (1-t)^{-s}\\ dt = \\int_0^\\infty \\frac{z^{s-1}}{1+z}\\ dz.")]]

#text("We extend the function ")#mi("{z \\mapsto z^{s-1}}")#text(" to the complex plane (excluding the origin) by the formula ")#mi("{z^{s-1} := \\exp((s-1) \\log_{[0,2\\pi)} z)}")#text(", where ")#mi("{\\log_{[0,2\\pi)}z}")#text(" is the branch of the complex logarithm whose imaginary part lies in the half-open interval ")#mi("{[0,2\\pi)}")#text(". This agrees with the usual power function ")#mi("{z \\mapsto z^{s-1}}")#text(" at (or infinitesimally above) the positive real axis, but instead converges to ")#mi("{z \\mapsto e^{2\\pi i (s-1)} z^{s-1}}")#text(" infinitesimally below this axis. Thus, if one lets ")#mi("{C}")#text(" be a contour that loops clockwise around the positive real axis, and stays sufficiently close to this axis, we see (using Cauchy’s theorem to justify the passage from infinitesimal neighbourhoods of the real axis to non-infinitesimal ones, and using the hypothesis ")#mi("{0<\\text{Re}(s) < 1}")#text(" to handle the contributions near the origin and infinity) we have")

#align(center)[#tao-fit-display[#mitex("\\int_C \\frac{z^{s-1}}{1+z}\\ dz = (1 - e^{2\\pi i(s-1)}) \\int_0^\\infty \\frac{z^{s-1}}{1+z}\\ dz.")]]

#text("On the other hand, outside of the non-negative real axis, ")#mi("{\\frac{z^{s-1}}{1+z}}")#text(" is meromorphic, with a simple pole at ")#mi("{z=-1}")#text(" of residue ")#mi("{e^{\\pi i(s-1)}}")#text(", and decays faster than ")#tao-math("{1/\\left|z\\right|}", block: false)#text(" at infinity. From the residue theorem we then have")

#align(center)[#tao-fit-display[#mitex("\\int_C \\frac{z^{s-1}}{1+z}\\ dz = 2\\pi i e^{\\pi i(s-1)}")]]

#text("and the claim then follows by putting the above identities together. ")#mi("\\Box")#linebreak()#text(" As a quick application of ")#link(<tao-421c47d8c413985f08df>)[#text("(8)")]#text(", if we set ")#mi("{s=1/2}")#text(" and observe that ")#mi("{\\Gamma(1/2)}")#text(" is clearly positive, we have")

#align(center)[#tao-fit-display[#mitex("\\Gamma(1/2) = \\sqrt{\\pi}")]]

#text("and thus (by ")#link(<tao-b6b1ecf2b1b3b58ba2e7>)[#text("(14)")]#text(") we recover the classical Gaussian identity ")#metadata(none) <tao-c7c5f1441e059892c19e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\int_{\\bf R} e^{-a^2 t^2}\\ dt = \\frac{\\sqrt{\\pi}}{a}")]]

#text("whenever ")#mi("{\\text{Re} a > 0}")#text(".")#linebreak()#text(" Next, we give an alternate definition of the Gamma function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Euler form of Gamma function)")]#text(" If ")#mi("{s}")#text(" is not a pole of ")#mi("{\\Gamma}")#text(" (i.e., ")#mi("{s \\neq 0, -1, -2, \\dots}")#text("), then")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) = \\lim_{n \\rightarrow \\infty} \\frac{n! n^s}{s(s+1) \\dots (s+n)} = \\frac{1}{s} \\prod_n \\frac{(1+1/n)^s}{1+s/n}.")]]
]

#emph[#text("Proof:")]#text(" It is easy to verify the second identity, and that the product and limit are convergent. One also easily verifies that the expression ")#mi("{s \\mapsto \\lim_{n \\rightarrow \\infty} \\frac{n! n^s}{s(s+1) \\dots (s+n)}}")#text(" obeys ")#link(<tao-01ea9df76bc63a172589>)[#text("(16)")]#text(", so it will suffice to establish the claim when ")#mi("{\\text{Re}(s) > 0}")#text(".")

#text("We use a trick previously employed to prove Lemma 40 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(". By ")#link(<tao-3d9219b73013678e9663>)[#text("(12)")]#text(" and the dominated convergence theorem, we have")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) = \\lim_{n \\rightarrow \\infty} \\int_0^n t^{s-1} (1-\\frac{t}{n})^n\\ dt.")]]

#text("But by Lemma ")#link(<tao-f44e64e75f3948e9f73f>)[#text("7")]#text(" and a change of variables we have")

#align(center)[#tao-fit-display[#mitex("\\int_0^n t^{s-1} (1-\\frac{t}{n})^n\\ dt = n^s \\frac{\\Gamma(s) \\Gamma(n+1)}{\\Gamma(s+n+1)}.")]]

#text("From ")#link(<tao-01ea9df76bc63a172589>)[#text("(16)")]#text(" one has ")#mi("{\\Gamma(n+1)=n!}")#text(" and ")#mi("{\\Gamma(s+n+1) = \\Gamma(s) s(s+1) \\dots (s+n)}")#text(", and the claim follows (recall that ")#mi("{\\Gamma(s)}")#text(" is never zero). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Weierstrass form of Gamma function)")]#text(" If ")#mi("{s}")#text(" is not a pole of ")#mi("{\\Gamma}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) = \\frac{e^{-\\gamma s}}{s} \\prod_n \\frac{e^{s/n}}{1+s/n}")]]

#text("where ")#mi("{\\gamma}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler constant")]#text(", with the product being absolutely convergent. (")#emph[#text("Hint:")]#text(" you may need Lemma 40 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Digamma function)")]#text(" ")#metadata(none) <tao-ebbde58a4bbe357e599b>#text(" Define the ")#link("http://en.wikipedia.org/wiki/Digamma_function")[#text("digamma function")]#text(" to be the logarithmic derivative ")#mi("{\\frac{\\Gamma^{\\prime}}{\\Gamma}}")#text(" of the Gamma function. Show that the digamma function is a meromorphic function, with simple poles of residue ")#mi("{-1}")#text(" at the non-positive integers ")#mi("{0, -1, -2, \\dots}")#text(" and no other poles, and that")

#tao-aligned(keep: true)[


#tao-math("\\frac{\\Gamma^{\\prime}}{\\Gamma}(s)  & = \\lim_{N \\rightarrow \\infty} \\log N - \\sum_{n=0}^N \\frac{1}{s+n}", block: true)



#tao-math(" & = -\\gamma + \\sum_{\\rho = 0, -1, -2, \\dots} (\\frac{1}{1-\\rho} - \\frac{1}{s-\\rho})", block: true)
]

#text("for ")#mi("{s}")#text(" outside of the poles of ")#mi("{\\frac{\\Gamma^{\\prime}}{\\Gamma}}")#text(", with the sum being absolutely convergent. Establish the reflection formula ")#metadata(none) <tao-909ca0096d519dcf94ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\frac{\\Gamma^{\\prime}}{\\Gamma}(1-s) - \\frac{\\Gamma^{\\prime}}{\\Gamma}(s) = \\pi \\cot(\\pi s)")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\pi \\cot(\\pi s) = \\sum_{\\rho \\in {\\bf Z}} (\\frac{1}{s-\\rho} - \\frac{1}{\\rho})")]]

#text("for non-integer ")#mi("{s}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Show that ")#mi("{\\Gamma^{\\prime}(1) = -\\gamma}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Legendre duplication formula)")]#text(" ")#metadata(none) <tao-c7fce3cad585a3110c96>#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\Gamma(\\frac{s}{2}) \\Gamma(\\frac{s+1}{2}) = \\sqrt{\\pi} 2^{1-s} \\Gamma(s)")]]

#text("whenever ")#mi("{s}")#text(" is not a pole of ")#mi("{\\Gamma}")#text(". (")#emph[#text("Hint:")]#text(" using the digamma function, show that the logarithmic derivatives of both sides differ by a constant. Then test the formula at two values of ")#mi("{s}")#text(" to verify that the normalising factor of ")#mi("{\\sqrt{\\pi} 2^{1-s}}")#text(" is correct.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Gauss multiplication theorem)")]#text(" For any natural number ")#mi("{k}")#text(", establish the ")#link("http://en.wikipedia.org/wiki/Multiplication_theorem")[#text("multiplication theorem")]

#align(center)[#tao-fit-display[#mitex("\\Gamma(\\frac{s}{k}) \\Gamma(\\frac{s+1}{k}) \\dots \\Gamma(\\frac{s+k-1}{k}) = (2\\pi)^{(k-1)/2} k^{1/2 - s} \\Gamma(s)")]]

#text("whenever ")#mi("{s}")#text(" is not a pole of ")#mi("{\\Gamma}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Bohr-Mollerup theorem)")]#text(" Establish the ")#link("http://en.wikipedia.org/wiki/Bohr%E2%80%93Mollerup_theorem")[#text("Bohr-Mollerup theorem")]#text(": the function ")#mi("{\\Gamma: (0,+\\infty) \\rightarrow (0,+\\infty)}")#text(", which is the Gamma function restricted to the positive reals, is the unique ")#link("http://en.wikipedia.org/wiki/Logarithmic_convexity")[#text("log-convex function")]#text(" ")#mi("{f :(0,+\\infty) \\rightarrow (0,+\\infty)}")#text(" on the positive reals with ")#mi("{f(1)=1}")#text(" and ")#mi("{sf(s) = f(s+1)}")#text(" for all ")#mi("{s>0}")#text(".")
]

#text("Now we turn to the question of asymptotics for ")#mi("{\\Gamma}")#text(". We begin with the corresponding asymptotics for the digamma function ")#mi("{\\frac{\\Gamma^{\\prime}}{\\Gamma}}")#text(". Recall (see Exercise 11 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") that one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{y \\leq n \\leq x} f(n) = \\int_y^x f(t)\\ dt + O( \\int_x^y |f^{\\prime}(t)|\\ dt + \\left|f(y)\\right| )", block: true)]]

#text("for any real ")#mi("{y \\leq x}")#text(" and any continuously differentiable functions ")#mi("{f: [y,x] \\rightarrow {\\bf C}}")#text(". This gives")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=0}^N \\frac{1}{s+n} = \\text{Log}(N+s) - \\text{Log}(s) + O( \\frac{1}{\\left|s\\right|} )", block: true)]]

#text("for ")#mi("{s}")#text(" in a sector of the form ")#mi("{\\text{Arg}(z) < \\pi - \\varepsilon}")#text(" for some fixed ")#mi("{\\varepsilon>0}")#text(" (that is, ")#mi("{s}")#text(" makes at least a fixed angle with the negative real axis), where ")#mi("{\\text{Arg}}")#text(" and ")#mi("{\\text{Log}}")#text(" are the standard branches of the argument and logarithm respectively (with branch cut on the negative real axis). From Exercise ")#link(<tao-ebbde58a4bbe357e599b>)[#text("11")]#text(", we obtain the asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\Gamma^{\\prime}}{\\Gamma}(s) = \\text{Log}(s) + O( \\frac{1}{\\left|s\\right|} )", block: true)]]

#text("in this regime. (For the other values of ")#mi("{s}")#text(", one can use the reflection formula ")#link(<tao-909ca0096d519dcf94ab>)[#text("(21)")]#text(" to obtain an analogous asymptotic.) Actually, it will be convenient to sharpen this approximation a bit, using the following version of the ")#link("http://en.wikipedia.org/wiki/Trapezoidal_rule")[#text("trapezoid rule")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Trapezoid rule)")]#text(" Let ")#mi("{y < x}")#text(" be distinct ")#emph[#text("integers")]#text(", and let ")#mi("{f: [y,x] \\rightarrow {\\bf C}}")#text(" be a continuously twice differentiable function. Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq n \\leq x} f(n) = \\int_y^x f(t)\\ dt + \\frac{1}{2} f(x) + \\frac{1}{2} f(y) + O( \\int_x^y |f^{\\prime\\prime}(t)|\\ dt ).")]]

#text("(")#emph[#text("Hint:")]#text(" first establish the case when ")#mi("{x=y+1}")#text(".)")
]

#text("From this exercise, we obtain a sharper estimate")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=0}^N \\frac{1}{s+n} = \\text{Log}(N+s) - \\text{Log}(s) + \\frac{1}{2s} + \\frac{1}{2(s+N)} + O( \\frac{1}{\\left|s\\right|^2} ),", block: true)]]

#text("and hence ")#metadata(none) <tao-a66865332ad998f19a80>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\frac{\\Gamma^{\\prime}}{\\Gamma}(s) = \\text{Log}(s) - \\frac{1}{2s} + O( \\frac{1}{\\left|s\\right|^2} ),", block: true)]]

#text("in the region where ")#mi("{\\text{Arg}(z) < \\pi - \\varepsilon}")#text(". Integrating this, we obtain a branch ")#mi("{\\log \\Gamma}")#text(" of the logarithm of ")#mi("{\\Gamma}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\log \\Gamma(s) = (s -\\frac{1}{2}) \\text{Log}(s) - s + C + O( \\frac{1}{\\left|s\\right|} )", block: true)]]

#text("for some absolute constant ")#mi("{C}")#text(". To find this constant ")#mi("{C}")#text(", we apply the reflection formula (Lemma ")#link(<tao-421c47d8c413985f08df>)[#text("8")]#text(") and ")#mi("{s=\\frac{1}{2}+it}")#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("\\log \\frac{\\pi}{\\sin(\\pi (\\frac{1}{2}+it))} = it ( \\text{Log}(\\frac{1}{2}+it) - \\text{Log}(\\frac{1}{2}-it) ) - 1 + 2C + O( \\frac{1}{t} ).")]]

#text("for ")#mi("{t > 0}")#text(". Since (up to multiples of ")#mi("{2\\pi i}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\log \\frac{\\pi}{\\sin(\\pi (\\frac{1}{2}+it))} = -\\pi t + \\log 2\\pi + O( \\frac{1}{t} )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\text{Log}(\\frac{1}{2}+it) - \\text{Log}(\\frac{1}{2}-it) = \\pi i - \\frac{i}{2t} + O( \\frac{1}{t} ),")]]

#text("we conclude that ")#mi("{C}")#text(" is equal to ")#mi("{\\frac{1}{2} \\log 2\\pi}")#text(" up to multiples of ")#mi("{\\pi i}")#text("; but as ")#mi("{\\Gamma}")#text(" is positive on the positive reals, we can normalise ")#mi("{\\log \\Gamma}")#text(" so that ")#mi("{C = \\frac{1}{2} \\log 2\\pi}")#text(", thus we obtain the ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling approximation")]

#align(center)[#tao-fit-display[#tao-math("\\log \\Gamma(s) = (s -\\frac{1}{2}) \\text{Log}(s) - s + \\frac{1}{2} \\log 2\\pi + O( \\frac{1}{\\left|s\\right|} ).", block: true)]]

#text("In particular, we have the approximation")

#tao-aligned(keep: true)[


#tao-math("\\log \\Gamma(\\sigma+it)  & = - \\frac{\\pi}{2} \\left|t\\right| + (\\sigma-\\frac{1}{2}) \\log \\left|t\\right| + it (\\log\\left|t\\right|-1)", block: true)



#tao-math(" & + \\frac{1}{2} \\log 2\\pi + \\frac{\\pi i}{2} (\\sigma-\\frac{1}{2}) \\text{sgn}(t) + O( \\frac{1}{\\left|t\\right|} )", block: true)
]

#text("when ")#tao-math("{\\left|\\sigma\\right| \\ll 1}", block: false)#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(", which implies that ")#metadata(none) <tao-6ca5cab77e702c787b4c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\left|\\Gamma(\\sigma+it)\\right| \\asymp e^{-\\pi\\left|t\\right|/2} \\left|t\\right|^{\\sigma-\\frac{1}{2}}", block: true)]]

#text("in this region. For sake of comparison, note that ")#metadata(none) <tao-ef7c967436632d3042bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\left|\\sin( \\pi(\\sigma+it) )\\right|, \\left|\\cos( \\pi(\\sigma+it) )\\right| \\asymp e^{\\pi\\left|t\\right|}", block: true)]]

#text("in this region (note this is consistent with the reflection formula, Lemma ")#link(<tao-421c47d8c413985f08df>)[#text("8")]#text(", as well as the duplication formula, Exercise ")#link(<tao-c7fce3cad585a3110c96>)[#text("13")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-76b5a357391276b282a5>#text(" When ")#mi("{s=\\sigma+it}")#text(" with ")#tao-math("{\\left|\\sigma\\right| \\ll 1}", block: false)#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\alpha^{\\prime}}{\\alpha}(s) = - \\log \\frac{\\left|t\\right|}{2\\pi} + i \\frac{\\sigma-1/2}{t} + O( \\frac{1}{\\left|t\\right|^2} )", block: true)]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\log \\alpha(s)  & = -(\\sigma-\\frac{1}{2}) \\log \\frac{\\left|t\\right|}{2\\pi} + 2\\pi i(\\frac{t}{2\\pi}\\log\\frac{\\left|t\\right|}{2\\pi}-\\frac{t}{2\\pi})", block: true)



#tao-math(" & + \\frac{\\pi i}{4} \\text{sgn}(t) + O(\\frac{1}{\\left|t\\right|})", block: true)
]

#text("for a suitable choice of branch of ")#mi("{\\log \\alpha}")#text("; equivalently, using the notation ")#mi("{e(x) := e^{2\\pi i x}}")#text(", one has ")#metadata(none) <tao-343677762813eaeb6570>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\alpha(s) = \\left|t\\right|^{\\frac{1}{2}-\\sigma} e( \\frac{t}{2\\pi}\\log\\frac{\\left|t\\right|}{2\\pi}-\\frac{t}{2\\pi} ) e( \\frac{\\text{sgn}(t)}{8} + O( \\frac{1}{\\left|t\\right|} ) ).", block: true)]]

#text("Also show that the error ")#tao-math("{O(\\frac{1}{\\left|t\\right|})}", block: false)#text(" in ")#link(<tao-343677762813eaeb6570>)[#text("(25)")]#text(" is real-valued when ")#mi("{\\sigma=1/2}")#text(", so that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha(\\frac{1}{2}+it)\\right| = 1.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" ")#metadata(none) <tao-05669361000669df75ba>#text(" Assume Theorem ")#link(<tao-f63827270b16435ec079>)[#text("1")]#text(", and deduce Corollary ")#link(<tao-17057013652043f03365>)[#text("2")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#text(" Assume Theorem ")#link(<tao-4ef6f0b42e4be3ba589c>)[#text("3")]#text(", and deduce Corollary ")#link(<tao-9d3e1d99bbb47e290f2e>)[#text("4")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Using the trapezoid rule, show that for any ")#mi("{s}")#text(" in the region ")#mi("{\\{ s: \\text{Re}(s) > -1 \\}}")#text(" with ")#mi("{s \\neq 1}")#text(", there exists a unique complex number ")#mi("{\\zeta(s)}")#text(" for which one has the asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^N \\frac{1}{n^s} = \\zeta(s) + \\frac{N^{1-s}}{1-s} + \\frac{1}{2} N^{-s} + O( \\frac{\\left|s\\right| \\left|s+1\\right|}{\\sigma+1} N^{-s-1} )", block: true)]]

#text("for any natural number ")#mi("{N}")#text(", where ")#mi("{s=\\sigma+it}")#text(". Use this to extend the Riemann zeta function meromorphically to the region ")#mi("{\\{ s: \\text{Re}(s) > -1 \\}}")#text(". Conclude in particular that ")#mi("{\\zeta(0)=-\\frac{1}{2}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" ")#metadata(none) <tao-348a629f5ceed032c3e8>#text(" Obtain the refinement")

#tao-aligned(keep: true)[


#tao-math("\\sum_{y \\leq n \\leq x} f(n)  & = \\int_y^x f(t)\\ dt + \\frac{1}{2} f(x) + \\frac{1}{2} f(y)", block: true)



#tao-math(" & + \\frac{1}{12} (f^{\\prime}(y) - f^{\\prime}(x)) + O( \\int_x^y |f^{\\prime\\prime\\prime}(t)|\\ dt )", block: true)
]

#text("to the trapezoid rule when ")#mi("{y < x}")#text(" are integers and ")#mi("{f: [y,x] \\rightarrow {\\bf C}}")#text(" is continuously three times differentiable. Then show that for any ")#mi("{s}")#text(" in the region ")#mi("{\\{ s: \\text{Re}(s) > -2 \\}}")#text(" with ")#mi("{s \\neq -1}")#text(", there exists a unique complex number ")#mi("{\\zeta(s)}")#text(" for which one has the asymptotic")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n=1}^N \\frac{1}{n^s}  & = \\zeta(s) + \\frac{N^{1-s}}{1-s} + \\frac{1}{2} N^{-s} + \\frac{s}{12} N^{-s-1}", block: true)



#tao-math(" & + O( \\frac{\\left|s\\right| \\left|s+1\\right| \\left|s+2\\right|}{\\sigma+2} N^{-s-2} )", block: true)
]

#text("for any natural number ")#mi("{N}")#text(", where ")#mi("{s=\\sigma+it}")#text(". Use this to extend the Riemann zeta function meromorphically to the region ")#mi("{\\{ s: \\text{Re}(s) > -2 \\}}")#text(". Conclude in particular that ")#mi("{\\zeta(-1)=-\\frac{1}{12}}")#text("; this is a rigorous interpretation of the ")#link("http://en.wikipedia.org/wiki/1_%2B_2_%2B_3_%2B_4_%2B_%E2%8B%AF")[#text("infamous formula")]

#align(center)[#tao-fit-display[#mitex("1 + 2 +3 + \\dots = -\\frac{1}{12}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" One can continue this procedure to extend ")#mi("{\\zeta}")#text(" meromorphically to the entire complex plane by using the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Maclaurin_formula")[#text("Euler-Maclaurin formula")]#text("; see ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("this previous blog post")]#text(". However, we will not pursue this approach to the meromorphic continuation of zeta further here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Use the Stirling approximation to establish the ")#link("https://en.wikipedia.org/wiki/Wallis_product")[#text("Wallis product formula")]

#tao-aligned(keep: true)[


#tao-math("\\frac{\\pi}{2}  & = \\prod_{n=1}^\\infty \\frac{2n}{2n-1} \\frac{2n}{2n+1}", block: true)



#tao-math(" & = (\\frac{2}{1} \\cdot \\frac{2}{3}) \\cdot (\\frac{4}{3} \\cdot \\frac{4}{5}) \\cdot (\\frac{6}{5} \\cdot \\frac{6}{7}) \\cdot \\dots", block: true)
]
]

#heading(level: 1)[#strong[#text(" — 2. The functional equation — ")]]

#metadata(none) <tao-074558d320ca70a74505>#linebreak()#text(" We now give three different (although not wholly unrelated) proofs of the functional equation, Theorem ")#link(<tao-f63827270b16435ec079>)[#text("1")]#text(".")

#text("The first proof (due to Riemann) relies on a relationship between the Dirichlet series")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(s) = \\sum_n \\frac{f(n)}{n^s}")]]

#text("of an arithmetic function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(", and the Taylor series ")#metadata(none) <tao-8bd574fdb05c2dc50171>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("F(z) := \\sum_n f(n) z^n.")]]

#text("Given that both of the transforms ")#mi("{f \\mapsto {\\mathcal D} f}")#text(" and ")#mi("{f \\mapsto F}")#text(" are linear and (formally, at least) injective, it is not surprising that there should be some linear relationship between the two. It turns out that we can use the Gamma function to mediate such a relationship:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 24 (Dirichlet series from power series)")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be an arithmetic function such that ")#mi("{f(n) = O(n^{o(1)})}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Then for any complex number ")#mi("{s}")#text(" with ")#mi("{\\text{Re}(s) > 1}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) {\\mathcal D} f(s) = \\int_0^\\infty t^{s-1} F( e^{-t} )\\ dt")]]

#text("where ")#mi("{F}")#text(" is the Taylor series ")#link(<tao-8bd574fdb05c2dc50171>)[#text("(26)")]#text(", which is absolutely convergent in the unit disk ")#tao-math("{\\{ z: \\left|z\\right| < 1 \\}}", block: false)#text(". The integral on the right-hand side is absolutely integrable.")
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-f745a15153c4dacf0ea4>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\Gamma(s)}{n^s} = \\int_0^\\infty t^{s-1} e^{-nt}\\ dt")]]

#text("for any natural number ")#mi("{n}")#text(". Multiplying by ")#mi("{f(n)}")#text(", summing, and using Fubini’s theorem, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) {\\mathcal D} f(s) = \\int_0^\\infty t^{s-1} \\sum_n f(n) e^{-nt}\\ dt,")]]

#text("and the claim follows. (By restricting to the case when ")#mi("{s}")#text(" is real and ")#mi("{f}")#text(" is non-negative, we can see that all integrals here are absolutely integrable.) ")#mi("\\Box")#linebreak()#text(" Specialising to the case ")#mi("{f(n)=1}")#text(", so that ")#mi("{F(z) = \\frac{z}{1-z}}")#text(", we obtain the identity ")#metadata(none) <tao-2fe840e13244a9d74888>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\Gamma(s) \\zeta(s) = \\int_0^\\infty \\frac{t^{s-1}}{e^t - 1}\\ dt")]]

#linebreak()#text(" for ")#mi("{\\text{Re}(s) > 1}")#text(", which can be compared with ")#link(<tao-3d9219b73013678e9663>)[#text("(12)")]#text(". Now we recall the contour ")#mi("{C}")#text(" introduced in the proof of Lemma ")#link(<tao-421c47d8c413985f08df>)[#text("8")]#text(", which goes around the positive real axis in the clockwise direction. As in the proof of that lemma, we see that")

#align(center)[#tao-fit-display[#mitex("\\int_C \\frac{z^{s-1}}{e^z - 1}\\ dz = (1 - e^{2\\pi i(s-1)}) \\int_0^\\infty \\frac{t^{s-1}}{e^t-1}\\ dt")]]

#text("for ")#mi("{C}")#text(" sufficiently close to the real axis (specifically, it has to not wind around any of the zeroes of ")#mi("{e^z-1}")#text(" other than ")#mi("{0}")#text("), where we use the branch ")#mi("{z^{s-1} = \\exp( (s-1) \\text{Log}_{[0,2\\pi)}(z) )}")#text(" as in the proof of Lemma ")#link(<tao-421c47d8c413985f08df>)[#text("8")]#text(". Thus we have ")#metadata(none) <tao-9597914896177b517761>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\zeta(s) = \\frac{1}{\\Gamma(s) (1-e^{2\\pi i(s-1)})} \\int_C \\frac{z^{s-1}}{e^z-1}\\ dz")]]

#text("for ")#mi("{\\text{Re}(s) > 1}")#text(" with ")#mi("{s}")#text(" non-integer (to avoid the zeroes of ")#mi("{1-e^{2\\pi i(s-1)}}")#text(").")#linebreak()#text(" The contour integral ")#mi("{\\int_C \\frac{z^{s-1}}{e^z-1}\\ dz}")#text(" is in fact absolutely convergent for ")#emph[#text("any")]#text(" ")#mi("{s \\in {\\bf C}}")#text(", and from the usual argument involving the Cauchy, Fubini, and Morera theorems we see that this integral depends holomorphically on ")#mi("{s}")#text(". Thus, we can use ")#link(<tao-9597914896177b517761>)[#text("(28)")]#text(" as a ")#emph[#text("definition")]#text(" for the Riemann zeta function that extends it meromorphically to the entire complex plane with no further poles (note that ")#mi("{\\Gamma(s) (1-e^{2\\pi i s})}")#text(" has no zeroes to the left of the critical strip, after removing all singularities).")

#text("Now suppose that we are in the region ")#mi("{\\{ s: \\text{Re}(s) < 0 \\}}")#text(", with ")#mi("{s}")#text(" not an integer. For any natural number ")#mi("{N}")#text(", we shift the contour ")#mi("{C}")#text(" to the rectangular contour ")#mi("{C_N}")#text(", which starts at ")#mi("{+\\infty + 2\\pi i (-N-\\frac{1}{2})}")#text(", goes leftwards to ")#mi("{-1 + 2\\pi i (-N-\\frac{1}{2})}")#text(", then upwards to ")#mi("{-1 + 2\\pi i (N+\\frac{1}{2})}")#text(", then rightwards to ")#mi("{+\\infty + 2\\pi i (N + \\frac{1}{2} )}")#text(". As ")#mi("{\\frac{z^{s-1}}{e^z-1}}")#text(" has simple poles at ")#mi("{2\\pi i n}")#text(" for each non-zero integer ")#mi("{n}")#text(" with residue ")#mi("{(2\\pi i n)^{s-1}}")#text(", we see from the residue theorem (and the exponential decay of ")#mi("{\\frac{z^{s-1}}{e^z-1}}")#text(" as ")#mi("{z}")#text(" goes to infinity to the right) that")

#align(center)[#tao-fit-display[#tao-math("\\int_C \\frac{z^{s-1}}{e^z-1}\\ dz = 2\\pi i \\sum_{0 < \\left|n\\right| \\leq N} (2\\pi i n)^{s-1} + \\int_{C_N} \\frac{z^{s-1}}{e^z-1}\\ dz.", block: true)]]

#text("If ")#mi("{\\text{Re}(s) < 0}")#text(", then one can compute that the integral ")#mi("{\\int_{C_N} \\frac{z^{s-1}}{e^z-1}\\ dz}")#text(" goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\int_C \\frac{z^{s-1}}{e^z-1}\\ dz = 2\\pi i \\sum_{\\left|n\\right| > 0} (2\\pi i n)^{s-1}.", block: true)]]

#text("From the choice of branch for ")#mi("{z \\mapsto z^{s-1}}")#text(", one sees that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|n\\right| > 0} (2\\pi i n)^{s-1} = (2\\pi)^{s-1} \\zeta(1-s) ( e^{(s-1)\\pi i/2} + e^{(s-1)3 \\pi i/2} ).", block: true)]]

#text("Inserting these identities into ")#link(<tao-9597914896177b517761>)[#text("(28)")]#text(", we obtain ")#link(<tao-44ba554e17977b31413d>)[#text("(4)")]#text(" after a brief calculation, at least in the region when ")#mi("{\\text{Re}(s) < 0}")#text(" and ")#mi("{s}")#text(" is not an integer; the remaining cases then follow from unique continuation of meromorphic functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 25")]#text(" The Poisson summation formula was not explicitly used in the above proof of the functional equation. However, if one inspects the contour integration proof of the Poisson summation formula in ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(", one sees an application of the residue theorem which is quite similar to that in the above argument, and so that formula is still present behind the scenes.")
]

#text("Now we give Riemann’s second proof of the functional equation. We again start in the region ")#mi("{\\text{Re}(s) > 1}")#text(". If we repeat the derivation of ")#link(<tao-2fe840e13244a9d74888>)[#text("(27)")]#text(", but use ")#link(<tao-b6b1ecf2b1b3b58ba2e7>)[#text("(14)")]#text(" in place of ")#link(<tao-f745a15153c4dacf0ea4>)[#text("(13)")]#text(", we obtain the variant identity")

#align(center)[#tao-fit-display[#tao-math("\\Gamma(\\frac{s}{2}) \\zeta(s) = \\int_{\\bf R} \\left|t\\right|^{s-1} \\sum_n e^{-n^2 t^2}\\ dt.", block: true)]]

#text("Introducing the ")#link("http://en.wikipedia.org/wiki/Theta_function")[#text("theta function")]#text(" ")#metadata(none) <tao-45b182f566f2efb3077f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\vartheta(z) := \\sum_{n \\in {\\bf Z}} e^{\\pi i n^2 z}")]]

#text("in the half-plane ")#mi("{\\text{Im}(z) > 0}")#text(" and using symmetry, we thus see that")

#align(center)[#tao-fit-display[#mitex("\\Gamma(\\frac{s}{2}) \\zeta(s) = \\int_0^\\infty t^{s-1} (\\vartheta( i t^2 / \\pi ) - 1 )\\ dt.")]]

#text("Making the change of variables ")#mi("{x = t^2/\\pi}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("\\pi^{-s/2} \\Gamma(\\frac{s}{2}) \\zeta(s) = \\frac{1}{2} \\int_0^\\infty x^{\\frac{s}{2}} (\\vartheta( i x ) - 1 )\\ \\frac{dx}{x}.")]]

#text("Recall from the Poisson summation formula that ")#metadata(none) <tao-e204073f8805bb3a8e05>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\vartheta(z) = \\frac{1}{\\sqrt{-iz}} \\vartheta(-\\frac{1}{z})")]]

#text("for ")#mi("{z}")#text(" in the upper half-plane, using the principal branch of the square root; see Exercise 36 of . In particular, ")#mi("{\\vartheta(ix)}")#text(" blows up like ")#mi("{x^{-1/2}}")#text(" as ")#mi("{x \\rightarrow 0^+}")#text(". We use this formula to transform the previous integral to an integral just on ")#mi("{[1,\\infty)}")#text(" rather than ")#mi("{[0,\\infty)}")#text(". First observe that")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 x^{\\frac{s}{2}} (-1)\\ \\frac{dx}{x} = - \\frac{2}{s}.")]]

#text("Next, from ")#link(<tao-e204073f8805bb3a8e05>)[#text("(30)")]#text(" (using the hypothesis ")#mi("{\\text{Re}(s)>1}")#text(" to ensure absolute convergence) and the change of variables ")#mi("{y=1/x}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 x^{\\frac{s}{2}} \\vartheta(ix)\\ \\frac{dx}{x} = \\int_1^\\infty y^{\\frac{1-s}{2}} \\vartheta(iy)\\ \\frac{dy}{y}.")]]

#text("Finally")

#align(center)[#tao-fit-display[#mitex("\\int_1^\\infty y^{\\frac{1-s}{2}} \\ \\frac{dy}{y} = -\\frac{2}{1-s}.")]]

#text("Putting all this together, we see that ")#metadata(none) <tao-cbde028ae2a023fe5741>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\pi^{-s/2} \\Gamma(\\frac{s}{2}) \\zeta(s) = - \\frac{1}{s} - \\frac{1}{1-s} + \\frac{1}{2} \\int_1^\\infty (x^{\\frac{s}{2}} + x^{\\frac{1-s}{2}}) (\\vartheta(ix)-1)\\ \\frac{dx}{x}")]]

#text("for ")#mi("{\\text{Re}(s)>1}")#text(".")#linebreak()#text(" Note from the definition of the theta function that ")#mi("{\\vartheta(ix)-1}")#text(" decays exponentially fast as ")#mi("{x \\rightarrow +\\infty}")#text(". As such, the integral in the right-hand is absolutely convergent for any ")#mi("{s \\in {\\bf C}}")#text(", and by the usual Morera theorem argument is in fact holomorphic in ")#mi("{s}")#text(". Thus ")#link(<tao-cbde028ae2a023fe5741>)[#text("(31)")]#text(" may be used to give a meromorphic extension of ")#mi("{\\zeta}")#text(" to the entire complex plane. The right-hand side of ")#link(<tao-cbde028ae2a023fe5741>)[#text("(31)")]#text(" is also manifestly symmetric with respect to the reflection ")#mi("{s \\mapsto 1-s}")#text(", giving the functional equation in the form ")#link(<tao-d9914b51fa0bad0262cd>)[#text("(7)")]#text(".")

#text("Next, we give a short heuristic proof of the functional equation arising from formally applying the Poisson summation formula ")#link(<tao-c8c3727df724362b5453>)[#text("(8)")]#text(" to the function")

#align(center)[#tao-fit-display[#mitex("f(x) := 1_{x>0} \\frac{1}{x^s}")]]

#text("ignoring all infinite divergences. Formally, the Fourier transform ")#mi("{\\hat f(y) = \\int_{\\bf R} f(x) e^{ixy}\\ dx}")#text(" is then given by")

#align(center)[#tao-fit-display[#mitex("\\hat f(y) = \\Gamma(1-s) \\frac{1}{(-iy)^{1-s}}")]]

#text("thanks to ")#link(<tao-f745a15153c4dacf0ea4>)[#text("(13)")]#text(". The Poisson summation formula ")#link(<tao-c8c3727df724362b5453>)[#text("(8)")]#text(" then ")#emph[#text("formally")]#text(" yields")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{1}{n^s} = \\Gamma(1-s) \\sum_{m \\in {\\bf Z}} \\frac{1}{(-2\\pi i m)^{1-s}}")]]

#text("and the functional equation ")#link(<tao-3c417b7ea567c3115dee>)[#text("(3)")]#text(" formally follows after some routine calculation if we discard the divergent ")#mi("{m=0}")#text(" term on the right-hand side, converts the sum over negative ")#mi("{m}")#text(" to a sum over positive ")#mi("{m}")#text(" by the change of variables ")#mi("{m \\mapsto -m}")#text(", and formally identify ")#mi("{\\sum_n \\frac{1}{n^s}}")#text(" and ")#mi("{\\sum_m \\frac{1}{m^{1-s}}}")#text(" with ")#mi("{\\zeta(s), \\zeta(1-s)}")#text(" respectively.")#linebreak()#text(" The above heuristic argument may be made rigorous by using suitable regularisations. This is the purpose of the exercise below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Rigorous justification of functional equation)")]#text(" ")#metadata(none) <tao-6f62d10313bb7adb62fb>#text(" Let ")#mi("{s}")#text(" be an element of the critical strip ")#mi("{\\{s: 0 < \\text{Re}(s) < 1 \\}}")#text(".")

#list(
[#text("(i) For any ")#mi("{\\alpha, \\beta > 0}")#text(", show that the function ")#mi("{f_{\\alpha,\\beta}: {\\bf R} \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{f_{\\alpha,\\beta}(x) := 1_{x>0} \\frac{1}{x^s} (e^{-\\alpha x} - e^{-\\beta x})}")#text(" is continuous, absolutely integrable, and has Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat f_{\\alpha,\\beta}(y) = \\Gamma(1-s) ( \\frac{1}{(-iy+\\alpha)^{1-s}} - \\frac{1}{(-iy+\\beta)^{1-s}} )")]]

#text("for ")#mi("{y \\in {\\bf R}}")#text(", using the standard branch of the logarithm to define ")#mi("{z \\mapsto z^{1-s}}")#text(".")],
[#text("(ii) Rigorously justify the Poisson summation formula")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} f_{\\alpha,\\beta}(n) = \\sum_{m \\in {\\bf Z}} \\hat f_{\\alpha,\\beta}(2\\pi m)")]]

#text("for any ")#mi("{\\alpha, \\beta > 0}")#text(". (In ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(", the Poisson summation formula was only established for continuously twice differentiable, compactly supported functions; ")#mi("{f_{\\alpha,\\beta}}")#text(" is neither of these, but one can still recover the formula in this instance by an approximation argument.)")],
[#text("(iii) Show that ")#mi("{\\sum_{n \\in {\\bf Z}} f_{\\varepsilon,1/\\varepsilon}(n) = \\zeta(s) + \\varepsilon^{s-1} \\Gamma(1-s) + o(1)}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0^+}")#text(".")],
[#text("(iv) Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\in {\\bf N}} \\frac{1}{(\\pm 2\\pi i m+\\varepsilon)^{1-s}} - \\frac{1}{(\\pm 2\\pi i m)^{1-s}} = o(1)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\in {\\bf N}} \\frac{1}{(\\pm 2\\pi i m)^{1-s}} - \\frac{1}{(\\pm 2\\pi i m+1/\\varepsilon)^{1-s}}")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{1}{(\\pm 2\\pi i)^{1-s}} \\zeta(1-s) \\mp \\frac{\\varepsilon^{-s}}{2\\pi i s} + o(1)")]]

#text("as ")#mi("{\\varepsilon \\rightarrow 0^+}")#text(", for either choice of sign ")#mi("{\\pm}")#text(".")],
[#text("(v) Prove ")#link(<tao-3c417b7ea567c3115dee>)[#text("(3)")]#text(" for ")#mi("{s}")#text(" in the critical strip, and then prove the rest of Theorem ")#link(<tao-f63827270b16435ec079>)[#text("1")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 27")]#text(" There are many further proofs of the functional equation than the three given above; see for instance the ")#link("http://www.ams.org/mathscinet-getitem?mr=882550")[#text("text of Titchmarsh")]#text(" for several further proofs. Most of the proofs can be connected in one form or another to the Poisson summation formula. One important proof worth mentioning is ")#link("http://en.wikipedia.org/wiki/Tate%27s_thesis")[#text("Tate’s adelic proof")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/")[#text("this previous post")]#text(", which is well suited for generalising the functional equation to many other zeta functions and ")#mi("{L}")#text("-functions, but will not be discussed further in this post.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Use the formula ")#mi("{\\zeta(-1)=\\frac{-1}{12}}")#text(" from Exercise ")#link(<tao-348a629f5ceed032c3e8>)[#text("21")]#text(", together with the functional equation, to show that ")#mi("{\\zeta(2) = \\frac{\\pi^2}{6}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Relation between zeta function and Bernoulli numbers)")]#text(" In this exercise we give the classical connection between the zeta function and Bernoulli numbers; this connection is not so relevant for analytic number theory, as it only involves values of the zeta function that are far from the critical strip, but is of interest for some other applications.")

#list(
[#text("(i) For any complex number ")#mi("{z}")#text(" with ")#mi("{\\text{Re}(z)>0}")#text(", use the Poisson summation formula ")#link(<tao-c8c3727df724362b5453>)[#text("(8)")]#text(" to establish the identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in {\\bf Z}} e^{-\\left|n\\right|z} = \\sum_{m \\in {\\bf Z}} \\frac{2z}{z^2+(2\\pi m)^2}.", block: true)]]],
[#text("(ii) For ")#mi("{z}")#text(" as above and sufficiently small, show that")

#align(center)[#tao-fit-display[#mitex("2\\sum_k (-1)^{k+1} \\zeta(2k) (z/2\\pi)^k = \\frac{z}{1-e^{-z}} - 1 - \\frac{z}{2}.")]]

#text("Conclude that")

#align(center)[#tao-fit-display[#mitex("\\zeta(2k) = \\frac{(-1)^{k+1} (2\\pi)^k}{2 (2k!)} B_{2k}")]]

#text("for any natural number ")#mi("{k}")#text(", where the ")#link("http://en.wikipedia.org/wiki/Bernoulli_number")[#text("Bernoulli numbers")]#text(" ")#mi("{B_2, B_4, B_6, \\dots}")#text(" are defined through the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\frac{z}{1-e^{-z}} = 1 + \\frac{z}{2} + \\sum_k \\frac{B_{2k}}{(2k)!} z^{2k}.")]]

#text("Thus for instance ")#mi("{B_2 = 1/6}")#text(", ")#mi("{B_4 = -1/30}")#text(", and so forth.")],
[#text("(iii) Show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\zeta(-n) = -\\frac{B_{n+1}}{n+1}")]]

#text("for any odd natural number ")#mi("{n}")#text(". (This identity can also be deduced from the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Maclaurin_formula")[#text("Euler-Maclaurin formula")]#text(", which generalises the approach in Exercise ")#link(<tao-348a629f5ceed032c3e8>)[#text("21")]#text("; see ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation")[#text("this previous post")]#text(".)")],
[#text("(iv) Use ")#link(<tao-9597914896177b517761>)[#text("(28)")]#text(" and the residue theorem (now working inside the contour ")#mi("{C}")#text(", rather than outside) to give an alternate proof of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#zoot")[#text("(32)")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Show that ")#mi("{\\zeta^{\\prime}(0) = -\\frac{1}{2} \\log 2\\pi}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" The functional equation is almost certainly not sufficient, by itself, to establish the Riemann hypothesis. For instance, there is a classical example of Davenport and Heilbronn of a finite linear combination of Dirichlet L-functions which obeys a functional equation very similar (though not quite identical) to ")#link(<tao-44ba554e17977b31413d>)[#text("(4)")]#text(", but which possesses zeroes off of the critical line; see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=2336280")[#text("this article")]#text(" for a recent analysis of the counterexample. ")#link("http://en.wikipedia.org/wiki/Eisenstein_series")[#text("Eisenstein series")]#text(" can also be used to construct a “natural” variant of a zeta function that has a Dirichlet series and a functional equation, but has zeroes off the critical line. For a “cheaper” counterexample, take two nearby non-trivial zeroes ")#mi("{\\rho_1, \\rho_2}")#text(" of ")#mi("{\\zeta}")#text(" on the critical line, and “replace” them with two other nearby complex numbers ")#mi("{\\rho_3, \\rho_4}")#text(" symmetric around the critical line, but not on the line, by introducing the modified zeta function")

#align(center)[#tao-fit-display[#mitex("\\tilde \\zeta(s) := \\frac{(s-\\rho_3)(s-\\rho_4)}{(s-\\rho_1)(s-\\rho_2)} \\zeta(s).")]]

#text("This function also obeys the functional equation, and behaves very similarly (though not identically) to the Riemann zeta function in all the regions in which we have a good understanding of this function (in particular, it has similar behaviour to ")#mi("{\\zeta}")#text(" around ")#mi("{s=1}")#text(" or around the edges of the critical strip), but clearly has zeroes off of the critical line. Such constructions would be particularly hard to exclude by analytic methods if there happened to be a repeated zero ")#mi("{\\rho_1=\\rho_2}")#text(" of ")#mi("{\\zeta}")#text(" on the critical line, as one could then make ")#mi("{\\rho_3,\\rho_4}")#text(" extremely close to both of ")#mi("{\\rho_1,\\rho_2}")#text("; it is conjectured that such a repeated zero does not occur, but we cannot exclude this possibility with current technology, which creates a family of “infinitesimal counterexamples” to the Riemann hypothesis which rules out a large number of potential approaches to this hypothesis.")#linebreak()#text(" On the other hand, unlike the Davenport-Heilbronn counterexample, ")#mi("{\\tilde \\zeta}")#text(" does not arise from a Dirichlet series, and certainly does not have an Euler product. One can show (see Section 2.13 of ")#link("http://www.ams.org/mathscinet-getitem?mr=882550")[#text("Titchmarsh")]#text(") that if one insists on the functional equation ")#link(<tao-44ba554e17977b31413d>)[#text("(4)")]#text(" on the nose (as opposed to, say, the modified functional equation that the Davenport-Heilbronn example obeys, or the functional equation obeyed by a Dirichlet ")#mi("{L}")#text("-function) as well as a Dirichlet series representation, then the only possible functions available are scalar multiples of the Riemann zeta function; this was first established by Hamburger in 1921. It could well be that the analogue of the Riemann hypothesis is in fact obeyed by any function which obeys a suitable functional equation, ")#emph[#text("together with")]#text(" a Dirichlet series representation (with appropriate size bounds on the coefficients) ")#emph[#text("and")]#text(" an Euler product factorisation; a precise form of this statement is the Riemann hypothesis for ")#link("http://en.wikipedia.org/wiki/Selberg_class")[#text("the Selberg class")]#text(". But one would somehow need to make essential use of ")#emph[#text("all three")]#text(" of the above axioms to try to prove the Riemann hypothesis, as we have numerous counterexamples that show that zeroes can be produced off the critical line if one drops one or more of these axioms.")
]

#heading(level: 1)[#strong[#text(" — 3. Approximate and localised forms of the functional equation — ")]]

#text("In our construction of the Riemann zeta function in ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", we had the asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\zeta(s) = \\sum_{n \\leq x} \\frac{1}{n^s} - \\frac{x^{1-s}}{1-s} + O( \\frac{\\left|s\\right|}{\\sigma} x^{-s} )", block: true)]]

#text("for ")#mi("{x > 0}")#text(" and ")#mi("{s}")#text(" in the region ")#mi("{\\{s: \\text{Re}(s) > 0; s \\neq 1\\}}")#text(". Thus, ")#mi("{\\zeta(s)}")#text(" is the limit of the functions ")#mi("{\\sum_{n \\leq x} \\frac{1}{n^s} - \\frac{x^{1-s}}{1-s}}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", locally uniformly for ")#mi("{s}")#text(" in this region. We have an analogous limit for smoothed sums:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32 (Smoothed sums)")]#text(" ")#metadata(none) <tao-19b738c219c435150a1b>#text(" Let ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth function such that ")#mi("{\\eta(x)}")#text(" vanishes for ")#mi("{x>C}")#text(" and equals ")#mi("{1}")#text(" for ")#mi("{x<-C}")#text(" for some constant ")#mi("{C>0}")#text(". Show that the functions")

#align(center)[#tao-fit-display[#mitex("s \\mapsto \\sum_n \\frac{1}{n^s} \\eta( \\log n - \\log x) + x^{1-s} \\int_{\\bf R} \\frac{e^{(1-s) u}}{1-s} \\eta^{\\prime}(u)\\ du.")]]

#text("converge locally uniformly to ")#mi("{\\zeta}")#text(" on the region ")#mi("{\\{s: \\text{Re}(s) > 0; s \\neq 1\\}}")#text(". In the critical strip ")#mi("{\\{ s: 0 < \\text{Re}(s) < 1 \\}}")#text(", show that the second term may be replaced by ")#mi("{- x^{1-s} \\int_{\\bf R} e^{(1-s) u} \\eta(u)\\ du}")#text(".")
]

#text("It is of interest to understand the rate of convergence of these approximations to the zeta function. We restrict attention to ")#mi("{s}")#text(" in the critical strip ")#mi("{\\{ s: 0 < \\text{Re}(s) < 1 \\}}")#text(". The first observation is that the smoothed sums have negligible contribution once ")#mi("{n}")#text(" is much larger than ")#tao-math("{\\left|t\\right|}", block: false)#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 33")]#text(" ")#metadata(none) <tao-e4d00226255e697db90b>#text(" Let ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth, compactly supported function. Let ")#mi("{s = \\sigma+it}")#text(" lie in the critical strip. If ")#tao-math("{x \\geq C (1+\\left|t\\right|)}", block: false)#text(" for some sufficiently large ")#mi("{C}")#text(" (depending on the support of ")#mi("{\\psi}")#text("), then we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{1}{n^s} \\psi( \\log n - \\log x ) - x^{1-s} \\int_{\\bf R} e^{(1-s) u} \\psi(u)\\ du = O_{\\psi,A}( x^{-A} )")]]

#text("for any ")#mi("{A > 0}")#text(".")
]

#emph[#text("Proof:")]#text(" By the Poisson summation formula ")#link(<tao-c8c3727df724362b5453>)[#text("(8)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{1}{n^s} \\psi( \\log n - \\log x ) = \\sum_{m \\in {\\bf Z}} \\Psi(m)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Psi(m) := \\int_0^\\infty \\frac{1}{y^s} \\psi(\\log y - \\log x) e^{2\\pi i m y}\\ dy.")]]

#text("If we write ")#mi("{s = \\sigma+it}")#text(" and ")#mi("{u = \\log y - \\log x}")#text(", then after a change of variables we have")

#align(center)[#tao-fit-display[#mitex("\\Psi(m) = x^{1-s} \\int_{\\bf R} \\tilde \\psi(u) e^{2 \\pi i m x \\phi_m(u)}\\ du")]]

#text("where ")#mi("{\\tilde \\psi(u) := e^{(1-\\sigma)u} \\psi(u)}")#text(" and ")#mi("{\\phi_m(u) := e^u - \\frac{t}{2\\pi m x} u}")#text(". In particular we have")

#align(center)[#tao-fit-display[#mitex("\\Psi(0) = x^{1-s} \\int_{\\bf R} e^{(1-s) u} \\psi(u)\\ du")]]

#text("so it suffices by the triangle inequality to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\tilde \\psi(u) e^{2\\pi i m x \\phi_m(u)}\\ du \\ll_{A,\\psi} (\\left|m\\right| x)^{-A}", block: true)]]

#text("for any ")#mi("{A>0}")#text(" and any non-zero integer ")#mi("{m}")#text(". But by hypothesis on ")#mi("{x}")#text(", we see that we have the derivative bounds ")#mi("{\\phi_m^{(k)}(u) = O_{\\psi,k}(1)}")#text(" on the support of the smooth compactly supported function ")#mi("{\\tilde \\psi}")#text(". If one repeatedly writes ")#mi("{e^{2\\pi i m x \\phi_m(u)} = (\\frac{d}{du} e^{2\\pi i m x \\phi_m(u)}) \\times \\frac{1}{2\\pi i mx \\phi^{\\prime}_m(u)}}")#text(" and integrates by parts to move the derivative off of the phase, one obtains the claim. ")#mi("\\Box")#linebreak()#text(" This gives us a good approximation to ")#mi("{\\zeta(\\sigma+it)}")#text(" in the critical strip, involving a smoothed sum consisting of ")#tao-math("{O(1+\\left|t\\right|)}", block: false)#text(" terms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" ")#metadata(none) <tao-693c278188ead836d92b>#text(" Let ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth function such that ")#mi("{\\eta(x)}")#text(" vanishes for ")#mi("{x>C}")#text(" and equals ")#mi("{1}")#text(" for ")#mi("{x<-C}")#text(" for some constant ")#mi("{C>0}")#text(". Let ")#mi("{s = \\sigma+it}")#text(" be in the critical strip. Show that ")#metadata(none) <tao-6d41366d187aab337437>

#tao-aligned(keep: true)[


#tao-math("\\zeta(s)  & = \\sum_n \\frac{1}{n^s} \\eta( \\log n - \\log x) - x^{1-s} \\int_{\\bf R} e^{(1-s) u} \\eta(u)\\ du", block: true, numbering: n => [#text("(33)")])



#tao-math(" & + O_{\\eta, A, \\sigma}( x^{-A} )", block: true)
]

#text("for any ")#mi("{A>0}")#text(", if one has ")#tao-math("{x \\geq C^{\\prime} (1+\\left|t\\right|)}", block: false)#text(" for some sufficiently large ")#mi("{C^{\\prime}}")#text(" depending on ")#mi("{C}")#text(". (")#emph[#text("Hint:")]#text(" use Lemma 4 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", Exercise ")#link(<tao-19b738c219c435150a1b>)[#text("32")]#text(", Lemma ")#link(<tao-e4d00226255e697db90b>)[#text("33")]#text(", and dyadic decomposition.) Conclude in particular that ")#metadata(none) <tao-72d7027887e4341e0d65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#tao-math("\\zeta(s) = \\sum_n \\frac{1}{n^s} \\eta( \\log n - \\log x) + O_{\\eta,\\sigma,A}( (1+\\left|t\\right|)^{-A} )", block: true)]]

#text("for any ")#mi("{A>0}")#text(", if ")#tao-math("{C^{\\prime}(1+\\left|t\\right|) \\leq x \\ll (1+\\left|t\\right|)}", block: false)#text(".")
]

#text("We remark that the asymptotic ")#link(<tao-72d7027887e4341e0d65>)[#text("(34)")]#text(" is also valid (with a somewhat worse error term) for the ordinary partial sums ")#mi("{\\sum_{n \\leq x} \\frac{1}{n^s}}")#text(" (a classical result of Hardy and Littlewood); see Theorem 4.11 of ")#link("http://www.ams.org/mathscinet-getitem?mr=882550")[#text("Titchmarsh")]#text(". However, it will be slightly more convenient for us here to work exclusively with smoothed sums.")

#text("From ")#link(<tao-72d7027887e4341e0d65>)[#text("(34)")]#text(" and the triangle inequality, we have the crude bound ")#metadata(none) <tao-c1d431286ff2704f5e08>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#tao-math("\\zeta(s) \\ll_\\sigma (1+\\left|t\\right|)^{1-\\sigma}", block: true)]]

#linebreak()#text(" in the interior of the critical strip. One can do better through the functional equation. Indeed, from ")#link(<tao-44ba554e17977b31413d>)[#text("(4)")]#text(", ")#link(<tao-6ca5cab77e702c787b4c>)[#text("(23)")]#text(", ")#link(<tao-ef7c967436632d3042bd>)[#text("(24)")]#text(" we see that ")#metadata(none) <tao-731f46507cc5394513e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#tao-math("\\left|\\zeta(1-s)\\right| \\asymp_\\sigma (1+\\left|t\\right|)^{\\sigma-\\frac{1}{2}} \\left|\\zeta(s)\\right|", block: true)]]

#text("in this region, and thus ")#metadata(none) <tao-6d2a1e11c2a207b7d640>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#tao-math("\\zeta(s) \\ll_\\sigma (1+\\left|t\\right|)^{1/2}.", block: true)]]

#text("One can then use the ")#link("http://en.wikipedia.org/wiki/Hadamard_three-lines_theorem")[#text("Hadamard three lines theorem")]#text(" to interpolate between ")#link(<tao-c1d431286ff2704f5e08>)[#text("(35)")]#text(" and ")#link(<tao-6d2a1e11c2a207b7d640>)[#text("(37)")]#text(" to obtain the ")#emph[#text("convexity bound")]#text(" ")#metadata(none) <tao-91b9fae3d797b93d82e9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#tao-math("\\zeta(s) \\ll_{\\sigma,\\varepsilon} (1+\\left|t\\right|)^{\\frac{1-\\sigma}{2}+\\varepsilon}", block: true)]]

#text("for any ")#mi("{0 < \\sigma < 1}")#text(" and ")#mi("{\\varepsilon > 0}")#text("; we leave the details to the interested reader (and we will reprove the convexity bound shortly). Further improvements to ")#link(<tao-91b9fae3d797b93d82e9>)[#text("(38)")]#text(" for the zeta function and other ")#mi("{L}")#text("-functions are known as ")#emph[#text("subconvexity bounds")]#text(" and have many applications in analytic number theory, though we will only discuss the simplest subconvexity bounds in this course.")#linebreak()#text(" Exercise ")#link(<tao-693c278188ead836d92b>)[#text("34")]#text(" describes the zeta function in terms of smoothed sums of ")#mi("{\\frac{1}{n^s}}")#text(". In the converse direction, one can use Fourier inversion to express smoothed sums of ")#mi("{\\frac{1}{n^s}}")#text(" in terms of the zeta function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 35 (Fourier inversion)")]#text(" ")#metadata(none) <tao-d5f750a27b402ce4cdcc>#text(" Let ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth, compactly supported function, and let ")#mi("{s = \\sigma+it}")#text(" lie in the critical strip. Then for any ")#tao-math("{1 \\ll x \\ll 1+\\left|t\\right|}", block: false)#text(", we have ")#metadata(none) <tao-e5b564a7a4059dccb9c2>

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\frac{1}{n^s} \\psi( \\log n - \\log x )  & = \\frac{1}{2\\pi} \\int_{\\bf R} \\hat \\psi(y) x^{iy} \\zeta(s+iy)\\ dy", block: true, numbering: n => [#text("(39)")])



#tao-math(" & + O_{A,\\sigma}( (1+\\left|t\\right|)^{-A} )", block: true)
]

#text("for all ")#mi("{A>0}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\hat \\psi(y) := \\int_{\\bf R} \\psi(u) e^{iyu}\\ du")]]

#text("is the Fourier transform of ")#mi("{\\psi}")#text(".")
]

#emph[#text("Proof:")]#text(" We can write the left-hand side of ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(39)")]#text(" as ")#mi("{\\sum_n \\frac{1}{n} g(\\log n)}")#text(", where ")#mi("{g(u) := e^{(1-s)u} \\psi(u-\\log x)}")#text(". By Proposition 7 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", this can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi} \\int_{\\bf R} \\zeta(2+it) \\hat g( t - i )\\ dt.")]]

#text("Noting that")

#align(center)[#tao-fit-display[#mitex("\\hat g(y) = x^{1-s+iy} \\hat \\psi( y - i(1-s) )")]]

#text("we thus rewrite the left-hand side of ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(39)")]#text(" as the contour integral")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\int_{2-i\\infty}^{2+\\infty} \\zeta(z) x^{z-s} \\hat \\psi(-i(z-s))\\ dz.")]]

#text("The function ")#mi("{z \\mapsto \\zeta(z) x^{z-s} \\hat \\psi(-i(z-s))}")#text(" has a pole at ")#mi("{z=1}")#text(" with residue ")#mi("{x^{1-s} \\hat \\psi( is )}")#text(", which by Exercise 28 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(" is of size ")#tao-math("{O_A( (1+\\left|t\\right|)^{-A})}", block: false)#text(" for any ")#mi("{A>0}")#text(". By another appeal to that exercise, together with ")#link(<tao-c1d431286ff2704f5e08>)[#text("(35)")]#text(", we see that ")#mi("{\\zeta(z) x^{z-s} \\hat \\psi(-i(z-s))}")#text(" goes to zero as ")#mi("{\\text{Im}(z) \\rightarrow \\pm \\infty}")#text(" uniformly when ")#mi("{\\text{Re}(z)}")#text(" is bounded. By the residue theorem, we can thus shift the contour integral to")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2\\pi i} \\int_{s-i\\infty}^{s+\\infty} \\zeta(z) x^{z-s} \\hat \\psi(-i(z-s))\\ dz + O_A( (1+\\left|t\\right|)^{-A})", block: true)]]

#text("and the claim follows by performing the substitution ")#mi("{z = s + iy}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Establish ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(39)")]#text(" directly from the Fourier inversion formula, without invoking contour integration methods.")
]

#text("Among other things, this lemma shows that growth bounds in the Riemann zeta function are equivalent to growth bounds on smooth exponential sums of ")#mi("{n^{-it}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" ")#metadata(none) <tao-94135de9942ba0fc04fd>#text(" Let ")#mi("{0 < \\sigma < 1}")#text(" and ")#mi("{\\theta \\in {\\bf R}}")#text(". Show that the following claims are equivalent:")

#list(
[#text("(i) One has ")#tao-math("{\\zeta(\\sigma+it) \\ll \\left|t\\right|^{\\theta+o(1)}}", block: false)#text(" as ")#tao-math("{\\left|t\\right| \\rightarrow \\pm \\infty}", block: false)#text(".")],
[#text("(ii) One has the bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_n n^{-it} \\psi( \\log n - \\log x ) \\ll_{\\sigma,\\alpha,\\varepsilon,\\psi} x^\\sigma \\left|t\\right|^{\\theta+\\varepsilon}", block: true)]]

#text("whenever ")#mi("{\\varepsilon>0}")#text(", ")#tao-math("{1 \\ll x \\ll \\left|t\\right|}", block: false)#text(", and ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a compactly supported smooth function.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" ")#metadata(none) <tao-fa34f521b2c2ee9c4d09>#text(" For any ")#mi("{\\sigma \\in {\\bf R}}")#text(", let ")#mi("{\\mu(\\sigma)}")#text(" denote the least exponent for which one has the asymptotic ")#tao-math("{\\zeta(\\sigma+it) \\ll \\left|t\\right|^{\\mu(\\sigma)+o(1)}}", block: false)#text(" as ")#tao-math("{\\left|t\\right| \\rightarrow \\pm \\infty}", block: false)#text(".")

#list(
[#text("(i) Show that ")#mi("{\\mu}")#text(" is convex and obeys the functional equation ")#mi("{\\mu(1-\\sigma) = \\sigma-\\frac{1}{2} + \\mu(\\sigma)}")#text(" for ")#mi("{\\sigma \\in {\\bf R}}")#text(".")],
[#text("(ii) Show that ")#mi("{\\max( 1/2-\\sigma, 0 ) \\leq \\mu(\\sigma) \\leq \\frac{1-\\sigma}{2}}")#text(" for all ")#mi("{\\sigma}")#text(", and that ")#mi("{\\mu(\\sigma) = \\max(1/2-\\sigma,0)}")#text(" for ")#mi("{\\sigma \\leq 0}")#text(" or ")#mi("{\\sigma \\geq 1}")#text(". (In particular, this reproves ")#link(<tao-91b9fae3d797b93d82e9>)[#text("(38)")]#text(".)")],
[#text("(iii) Show that the ")#link("http://en.wikipedia.org/wiki/Lindel%C3%B6f_hypothesis")[#text("Lindelöf hypothesis")]#text(" (Exercise 34 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") is equivalent to the assertion that ")#mi("{\\mu(\\sigma) = \\max(1/2-\\sigma,0)}")#text(" for all ")#mi("{\\sigma \\in {\\bf R}}")#text(".")]
)
]

#text("Lemma ")#link(<tao-d5f750a27b402ce4cdcc>)[#text("35")]#text(" and Theorem ")#link(<tao-f63827270b16435ec079>)[#text("1")]#text(" suggest that there should be some approximate functional equation for the smoothed sums ")#mi("{\\sum_n \\frac{1}{n^s} \\psi( \\log n - \\log x )}")#text(". This is indeed the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 39 (Approximate functional equation for smoothed sums)")]#text(" ")#metadata(none) <tao-16fd1a0850622e16b737>#text(" Let ")#mi("{s=\\sigma+it}")#text(" with ")#mi("{0 < \\sigma < 1}")#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(". Let ")#mi("{N, M \\gg 1}")#text(" be such that ")#tao-math("{NM = \\frac{\\left|t\\right|}{2\\pi}}", block: false)#text(". Let ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth compactly supported function. Then ")#metadata(none) <tao-2f33612b18aa8b5e912e>

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\frac{1}{n^s} \\psi( \\log n - \\log N )  & = \\alpha(s) \\sum_m \\frac{1}{m^{1-s}} \\psi( \\log M - \\log m )", block: true, numbering: n => [#text("(40)")])



#tao-math(" & + O_{\\sigma,\\varepsilon,\\psi}( \\left|t\\right|^{-\\sigma/2-1/2+\\varepsilon} )", block: true)
]

#text("for any ")#mi("{\\varepsilon>0}")#text(", where ")#mi("{\\alpha}")#text(" is as in ")#link(<tao-757671c7f82e739e630e>)[#text("(5)")]#text(".")
]

#text("This approximate functional equation can also be established directly from the Poisson summation formula using the ")#link("http://en.wikipedia.org/wiki/Stationary_phase_approximation")[#text("method of stationary phase")]#text("; see Chapter 4 of ")#link("http://www.ams.org/mathscinet-getitem?mr=882550")[#text("Titchmarsh")]#text(". The error term of ")#tao-math("{O_{\\sigma,\\varepsilon}( \\left|t\\right|^{-\\sigma/2-1/2+\\varepsilon} )}", block: false)#text(" can be improved further by using better growth bounds on ")#mi("{\\zeta}")#text(" (or by further Taylor expansion of ")#mi("{\\alpha}")#text("), but the error term given here is adequate for applications. Note that the true functional equation ")#link(<tao-3c417b7ea567c3115dee>)[#text("(3)")]#text(" is formally the ")#mi("{\\psi=1}")#text(" case of ")#link(<tao-2f33612b18aa8b5e912e>)[#text("(40)")]#text(" if one ignores the error term.")

#emph[#text("Proof:")]#text(" By ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(39)")]#text(", the left-hand side is")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi} \\int_{\\bf R} \\hat \\psi(y) N^{iy} \\zeta(s+iy)\\ dy")]]

#text("up to negligible errors. Using the rapid decrease of ")#mi("{\\hat \\psi}")#text(" (Exercise 28 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(") and ")#link(<tao-c1d431286ff2704f5e08>)[#text("(35)")]#text(", we may restrict ")#mi("{y}")#text(" to the range ")#tao-math("{\\left|y\\right| \\leq \\left|t\\right|/2}", block: false)#text(", up to negligible error. Applying the functional equation ")#link(<tao-3c417b7ea567c3115dee>)[#text("(3)")]#text(", we rewrite this as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2\\pi} \\int_{\\left|y\\right| \\leq \\left|t\\right|/2} \\hat \\psi(y) N^{iy} \\alpha(s+iy) \\zeta(1-s-iy)\\ dy.", block: true)]]

#text("For ")#tao-math("{\\left|y\\right| \\leq \\left|t\\right|/2}", block: false)#text(", we see from Exercise ")#link(<tao-76b5a357391276b282a5>)[#text("17")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\alpha^{\\prime}}{\\alpha}(s+iy) = -\\log\\frac{\\left|t\\right|}{2\\pi} + O( \\frac{1+\\left|y\\right|}{\\left|t\\right|})", block: true)]]

#text("and thus from the fundamental theorem of calculus we have")

#align(center)[#tao-fit-display[#tao-math("\\log \\alpha( s+iy ) - \\log \\alpha(s) = -iy \\log\\frac{\\left|t\\right|}{2\\pi} + O( \\frac{\\left|y\\right|+\\left|y\\right|^2}{\\left|t\\right|} )", block: true)]]

#text("or equivalently (using ")#tao-math("{NM = \\frac{\\left|t\\right|}{2\\pi})}", block: false)#text(")")

#align(center)[#tao-fit-display[#tao-math("\\alpha(s+iy) = \\alpha(s) (NM)^{-iy} (1 + O( \\frac{\\left|y\\right|+\\left|y\\right|^2}{\\left|t\\right|} )).", block: true)]]

#text("We can thus write the left-hand side of ")#link(<tao-2f33612b18aa8b5e912e>)[#text("(40)")]#text(" up to acceptable errors as")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\alpha(s)}{2\\pi} \\int_{\\left|y\\right| \\leq \\left|t\\right|/2} \\hat \\psi(y) M^{-iy} \\zeta(1-s-iy) (1 + O( \\frac{\\left|y\\right|+\\left|y\\right|^2}{\\left|t\\right|} ))\\ dy.", block: true)]]

#text("From Exercise ")#link(<tao-76b5a357391276b282a5>)[#text("17")]#text(" we have ")#tao-math("{\\alpha(s) \\ll \\left|t\\right|^{1/2-\\sigma}}", block: false)#text(". From ")#link(<tao-91b9fae3d797b93d82e9>)[#text("(38)")]#text(" and the rapid decrease of ")#mi("{\\hat \\psi}")#text(", the contribution of the error term can then be controlled by ")#tao-math("{O( \\left|t\\right|^{-\\sigma/2-1/2+\\varepsilon} )}", block: false)#text(". Thus, up to acceptable errors, ")#link(<tao-2f33612b18aa8b5e912e>)[#text("(40)")]#text(" is equal to")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\alpha(s)}{2\\pi} \\int_{\\left|y\\right| \\leq \\left|t\\right|/2} \\hat \\psi(y) M^{-iy} \\zeta(1-s-iy)\\ dy.", block: true)]]

#text("By another appeal to ")#link(<tao-91b9fae3d797b93d82e9>)[#text("(38)")]#text(" and the rapid decrease of ")#mi("{\\psi}")#text(" (and the growth bound on ")#mi("{F(s)}")#text(" we may remove the constraint ")#tao-math("{\\left|y\\right| \\leq \\left|t\\right|/2}", block: false)#text(". The claim then follows by changing ")#mi("{y}")#text(" to ")#mi("{-y}")#text(" and using ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(39)")]#text(" again. ")#mi("\\Box")#linebreak()#text(" Let ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{0 < \\sigma < 1}")#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(", and let ")#mi("{\\eta}")#text(" be as in Exercise ")#link(<tao-693c278188ead836d92b>)[#text("34")]#text(". From ")#link(<tao-72d7027887e4341e0d65>)[#text("(34)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\zeta(s) = \\sum_n \\frac{1}{n^s} \\eta( \\log n - \\log x) + O_{\\eta,\\sigma,A}( \\left|t\\right|^{-A} )", block: true)]]

#text("for any ")#mi("{A}")#text(", and from the functional equation we have")

#align(center)[#tao-fit-display[#tao-math("\\zeta(s) = \\alpha(s) \\sum_m \\frac{1}{m^{1-s}} \\eta( \\log m - \\log x) + O_{\\eta,\\sigma,A}( \\left|t\\right|^{-A} ).", block: true)]]

#text("Using Theorem ")#link(<tao-16fd1a0850622e16b737>)[#text("39")]#text(", we may split the difference:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (Approximate functional equation)")]#text(" ")#metadata(none) <tao-5c96102ce9ece52097a0>#text(" Let ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth function such that ")#mi("{\\eta(x)}")#text(" vanishes for ")#mi("{x>C}")#text(" and equals ")#mi("{1}")#text(" for ")#mi("{x<-C}")#text(" for some constant ")#mi("{C>0}")#text(", and let ")#mi("{\\tilde \\eta(u) := 1 - \\eta(-u)}")#text(". Let ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{0 < \\sigma < 1}")#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(". Let ")#mi("{N,M \\gg 1}")#text(" be such that ")#mi("{NM = \\frac{t}{2\\pi}}")#text(". Show that ")#metadata(none) <tao-fa54ea93e4a2e5b6a88f>

#tao-aligned(keep: true)[


#tao-math("\\zeta(s)  & = \\sum_n \\frac{1}{n^s} \\eta( \\log n - \\log N) + \\alpha(s) \\sum_m \\frac{1}{m^{1-s}} \\tilde \\eta( \\log m - \\log M)", block: true, numbering: n => [#text("(41)")])



#tao-math(" & + O_{\\eta, \\sigma, \\varepsilon} ( \\left|t\\right|^{-\\sigma/2-1/2+\\varepsilon} )", block: true)
]

#text("for all ")#mi("{\\varepsilon>0}")#text(".")
]

#text("One can also obtain a version of this equation using partial sums instead of smoothed sums, but with slightly worse error terms, known as the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Siegel_formula")[#text("Riemann-Siegel formula")]#text("; see e.g. Theorem 4.13 of ")#link("http://www.ams.org/mathscinet-getitem?mr=882550")[#text("Titchmarsh")]#text(". Setting ")#mi("{N=M}")#text(", we see that we may now approximate ")#mi("{\\zeta(\\sigma+it)}")#text(" by smoothed sums consisting of about ")#tao-math("{O( \\left|t\\right|^{1/2} )}", block: false)#text(" terms, improving upon the sum with ")#tao-math("{O(\\left|t\\right|)}", block: false)#text(" terms appearing in Exercise ")#link(<tao-693c278188ead836d92b>)[#text("34")]#text(". Using the triangle inequality, this gives a slight improvement to ")#link(<tao-91b9fae3d797b93d82e9>)[#text("(38)")]#text(", namely that")

#align(center)[#tao-fit-display[#tao-math("\\zeta(\\sigma+it) \\ll_{\\sigma} (1+\\left|t\\right|)^{\\frac{1-\\sigma}{2}}", block: true)]]

#text("whenever ")#mi("{0 < \\sigma < 1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(". The equation ")#link(<tao-fa54ea93e4a2e5b6a88f>)[#text("(41)")]#text(" is particularly useful for getting reasonably good bounds on ")#mi("{\\zeta(\\frac{1}{2}+it)}")#text("; we will see an example of this in subsequent notes.")

#heading(level: 1)[#strong[#text(" — 4. Further applications of the functional equation — ")]]

#text("One basic application of the functional equation is to improve the control on zeroes of the Riemann zeta function, beyond what was obtained in Notes 2.")

#text("From Exercise ")#link(<tao-fa34f521b2c2ee9c4d09>)[#text("38")]#text(", we now have the crude bounds")

#align(center)[#tao-fit-display[#tao-math("\\zeta(\\sigma+it) = O( \\left|t\\right|^{O(1)} )", block: true)]]

#text("and in particular")

#align(center)[#tao-fit-display[#tao-math("\\log\\left|\\zeta(\\sigma+it)\\right| \\leq O(\\log t)", block: true)]]

#text("whenever ")#mi("{\\sigma = O(1)}")#text(" and ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(". The Jensen formula argument from Proposition 16 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" is no longer restricted to the region ")#mi("{\\{\\text{Re}(s) > \\varepsilon\\}}")#text(", and shows that there are ")#tao-math("{O( \\log(2+\\left|t\\right|) )}", block: false)#text(" zeroes of the Riemann zeta function in any disk of the form ")#mi("{\\{ z: z = it + O(1) \\}}")#text(". Similarly, Proposition 19 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" extends to give the formula ")#metadata(none) <tao-f3cf3f52140e146702cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#tao-math("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = - \\sum_{\\rho: \\rho = s + O(1)} \\frac{1}{s-\\rho} + \\frac{1}{s-1} + O( \\log(2+\\left|t\\right|) )", block: true)]]

#text("whenever ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{\\sigma = O(1)}")#text(". Corollary 20 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" also extends to show that ")#metadata(none) <tao-78675cc176081372c43a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#tao-math("\\int_{\\sigma = O(1)} \\int_{t = t_0 + O(1)} |\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it)|\\ dt d\\sigma \\ll \\log(2+\\left|t_0\\right|)", block: true)]]

#text("for any ")#mi("{t_0 \\in {\\bf R}}")#text(".")#linebreak()#text(" We can say more about the zeroes. For any ")#mi("{T>0}")#text(", let ")#mi("{N(T)}")#text(" denote the number of zeroes of ")#mi("{\\zeta}")#text(" in the rectangle ")#mi("{\\{ \\sigma+it: 0 < \\sigma < 1; 0 < t \\leq T \\}}")#text(". (If there were zeroes of ")#mi("{\\zeta}")#text(" on the interval ")#mi("{[0,1]}")#text(", they should each count for ")#mi("{1/2}")#text(" towards ")#mi("{N(T)}")#text(", but it turns out (as can be computationally verified) that there are no such zeroes.) Equivalently, ")#mi("{2N(T)}")#text(" is the number of zeroes in ")#tao-math("{\\{ \\sigma+it: 0 < \\sigma < 1; \\left|t\\right| \\leq T \\}}", block: false)#text(". We have the following asymptotic for ")#mi("{N(T)}")#text(", ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")[#text("conjectured by Riemann and established by von Mangoldt")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 41 (Riemann-von Mangoldt formula)")]#text(" ")#metadata(none) <tao-9bcc91b4b9f08ed96fc9>#text(" For ")#mi("{T \\geq 2}")#text(" (say), we have ")#mi("{N(T) = \\frac{T}{2\\pi} \\log \\frac{T}{2\\pi} - \\frac{T}{2\\pi} + O( \\log T )}")#text(".")
]

#emph[#text("Proof:")]#text(" We use the Riemann ")#mi("{\\xi}")#text(" function, whose zeroes are the non-trivial zeroes of ")#mi("{\\zeta}")#text(". From ")#link(<tao-c765d2f7b42f2a483927>)[#text("(6)")]#text(", ")#link(<tao-78675cc176081372c43a>)[#text("(43)")]#text(", ")#link(<tao-a66865332ad998f19a80>)[#text("(22)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\int_{\\sigma = O(1)} \\int_{t = T + O(1)} |\\frac{\\xi^{\\prime}}{\\xi}(\\sigma+it)|\\ dt d\\sigma \\ll \\log T")]]

#text("and so by the pigeonhole principle we can find ")#mi("{T_-, T_+}")#text(" in ")#mi("{[T-1,T]}")#text(" and ")#mi("{[T,T+1]}")#text(" respectively such that ")#metadata(none) <tao-507a9a8be3d145a86daa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("\\int_{-1}^2 |\\frac{\\xi^{\\prime}}{\\xi}(\\sigma+iT_\\pm)|\\ d\\sigma \\ll \\log T;")]]

#text("in particular, the line segments ")#mi("{\\{\\sigma+iT_\\pm: -1 \\leq \\sigma \\leq 2\\}}")#text(" does not meet any of the zeroes of ")#mi("{\\xi}")#text(" or ")#mi("{\\zeta}")#text(". We will show for either choice of sign ")#mi("{\\pm}")#text(" that the rectangle ")#tao-math("{\\{ \\sigma+it: -1 \\leq \\sigma \\leq 2; \\left|t\\right| \\leq T_\\pm \\}}", block: false)#text(" contains ")#mi("{\\frac{T_\\pm}{\\pi} \\log \\frac{T_\\pm}{2\\pi} - \\frac{T_\\pm}{\\pi} + O( \\log T )}")#text(" zeroes, which gives the claim since ")#mi("{\\frac{T_\\pm}{\\pi} \\log \\frac{T_\\pm}{2\\pi} - \\frac{T_\\pm}{\\pi}}")#text(" and ")#mi("{\\frac{T}{\\pi} \\log \\frac{T}{2\\pi} - \\frac{T}{\\pi}}")#text(" only differ by ")#mi("{O(\\log T)}")#text(".")#linebreak()#text(" By the residue theorem (or the ")#link("http://en.wikipedia.org/wiki/Argument_principle")[#text("argument principle")]#text("), the number of zeroes in this rectangle is equal to ")#mi("{\\frac{1}{2\\pi i}}")#text(" times the contour integral of ")#mi("{\\frac{\\xi^{\\prime}}{\\xi}}")#text(" anticlockwise around the boundary of the rectangle. By ")#link(<tao-507a9a8be3d145a86daa>)[#text("(44)")]#text(", the contribution of the upper and lower edges of this contour are ")#mi("{O(\\log T)}")#text("; from the functional equation (Corollary ")#link(<tao-17057013652043f03365>)[#text("2")]#text(") we see that the contribution of the left and right edges of the contour are the same, and from conjugation symmetry we see that the contribution of the upper half of the right edge is the complex conjugate of that of the lower half. Putting all this together, we see that it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\text{Re} \\frac{2}{\\pi i} \\int_2^{2+iT_\\pm} \\frac{\\xi^{\\prime}}{\\xi}(s)\\ ds = \\frac{T_\\pm}{\\pi} \\log \\frac{T_\\pm}{2\\pi} - \\frac{T_\\pm}{\\pi} + O( \\log T ),")]]

#text("or equivalently (after removing the integral from ")#mi("{2}")#text(" to ")#mi("{2+2i}")#text(", which is ")#mi("{O(1)}")#text("), that")

#align(center)[#tao-fit-display[#mitex("\\text{Re} \\int_2^{T_\\pm} \\frac{\\xi^{\\prime}}{\\xi}(2+it)\\ dt = \\frac{1}{2}( T_\\pm \\log T_\\pm - T_\\pm - \\frac{T_\\pm}{2} \\log(2\\pi)) + O( \\log T ).")]]

#text("From ")#link(<tao-c765d2f7b42f2a483927>)[#text("(6)")]#text(", ")#link(<tao-a66865332ad998f19a80>)[#text("(22)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\xi^{\\prime}}{\\xi}(2+it) = \\frac{\\zeta^{\\prime}}{\\zeta}(2+it) - \\frac{1}{2} \\log 2\\pi + \\frac{1}{2} \\log t + \\frac{\\pi i}{4} + O( \\frac{1}{t} )")]]

#text("for ")#mi("{t \\geq 2}")#text(". Since ")#mi("{\\log \\zeta}")#text(" is given by a Dirichlet series that is uniformly bounded on ")#mi("{\\{ 2+it: t \\in {\\bf R}\\}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\int_2^{T_\\pm} \\frac{\\zeta^{\\prime}}{\\zeta}(2+it) = O(1),")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" Establish the more precise formula")

#align(center)[#tao-fit-display[#mitex("N(T) = \\frac{T}{2\\pi} \\log \\frac{T}{2\\pi} - \\frac{T}{2\\pi} + \\frac{7}{8} + S(T) + O( \\frac{1}{T} )")]]

#text("whenever ")#mi("{T \\geq 2}")#text(" and the line ")#mi("{\\{ \\sigma+iT: \\sigma \\in {\\bf R}\\}}")#text(" avoids all zeroes of ")#mi("{\\zeta}")#text(", where ")#mi("{S(T) = \\frac{1}{\\pi} \\text{Im} \\log \\zeta(\\frac{1}{2}+iT)}")#text(", and the logarithm is extended leftwards from the region ")#mi("{\\{ s: \\text{Re}(s) > 1 \\}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("S(T) = \\frac{1}{\\pi} \\text{Im} \\log \\zeta(2+iT) - \\frac{1}{\\pi} \\text{Im} \\int_{1/2}^2 \\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+iT)\\ d\\sigma.")]]

#text("Theorem ")#link(<tao-9bcc91b4b9f08ed96fc9>)[#text("41")]#text(" then asserts that ")#mi("{S(T) = O(\\log T)}")#text(" for all ")#mi("{T \\geq 2}")#text(". It is in fact conjectured that ")#mi("{S(T) = o(\\log T)}")#text(" as ")#mi("{T \\rightarrow +\\infty}")#text(", but this problem has resisted solution for over a century (although it is known that this bound would follow from powerful hypotheses such as the ")#link("http://en.wikipedia.org/wiki/Lindel%C3%B6f_hypothesis")[#text("Lindelöf hypothesis")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 43")]#text(" In principle, ")#mi("{N(T)}")#text(" can be numerically computed exactly for any ")#mi("{T}")#text(", as long as the line ")#mi("{\\{ \\sigma+iT: \\sigma \\in {\\bf R}\\}}")#text(" has no zeroes of ")#mi("{\\zeta}")#text(", by evaluating the contour integral of ")#mi("{\\xi^{\\prime}/\\xi}")#text(" to sufficiently high accuracy. Similarly, one can also obtain a numerical lower bound for the number of zeroes of ")#mi("{\\zeta}")#text(" on the critical line by finding sign changes for the function ")#mi("{\\xi}")#text(", which is real-valued on the critical line. If the zeroes are all simple and on the critical line, then this (in principle) allows one to numerically verify the Riemann hypothesis up to height ")#mi("{T}")#text(". In practice, faster methods for numerically verifying the Riemann hypothesis (e.g. based on the Riemann-Siegel formula) are available.")
]

#text("We can now obtain global explicit formulae for the log-derivatives of ")#mi("{\\xi}")#text(" and ")#mi("{\\zeta}")#text(". Since ")#mi("{\\xi}")#text(" has zeroes only at the non-trivial zeroes of ")#mi("{\\zeta}")#text(", and no poles, one heuristically expects a relationship of the form")

#align(center)[#tao-fit-display[#mitex("\\frac{\\xi^{\\prime}}{\\xi}(s) = \\sum_\\rho \\frac{1}{s-\\rho}.")]]

#text("Unfortunately, the right-hand side is divergent; but we can normalise it by considering the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_\\rho (\\frac{1}{s-\\rho} + \\frac{1}{\\rho}).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Show that the sum ")#mi("{F(s) = \\sum_\\rho \\frac{1}{s-\\rho} + \\frac{1}{\\rho}}")#text(" converges locally uniformly to a meromorphic function away from the non-trivial zeroes of ")#mi("{\\zeta}")#text(", with ")#mi("{\\frac{\\xi^{\\prime}}{\\xi}(s) - F(s)}")#text(" an entire function (after removing all singularities). Also establish the bounds")

#align(center)[#tao-fit-display[#tao-math("F(s) = \\sum_{\\rho: \\left|\\rho-s\\right| \\leq 1} \\frac{1}{s-\\rho} + O( \\log(2+\\left|s\\right|) )", block: true)]]

#text("for all ")#mi("{s}")#text(" in the complex plane. (")#emph[#text("Hint:")]#text(" You will need to use the Riemann-von Mangoldt formula.)")
]

#text("From ")#link(<tao-c765d2f7b42f2a483927>)[#text("(6)")]#text(", ")#link(<tao-f3cf3f52140e146702cb>)[#text("(42)")]#text(", ")#link(<tao-a66865332ad998f19a80>)[#text("(22)")]#text(" one also has")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\xi^{\\prime}}{\\xi}(s) = \\sum_{\\rho: \\left|\\rho-s\\right| \\leq 1} \\frac{1}{s-\\rho} + O( \\log(2+\\left|s\\right|) )", block: true)]]

#text("for all ")#mi("{s = \\sigma+it}")#text(" in the strip ")#mi("{\\sigma = O(1), t \\in {\\bf R}}")#text("; from ")#link(<tao-a66865332ad998f19a80>)[#text("(22)")]#text(" and the boundedness of ")#mi("{\\frac{\\zeta^{\\prime}}{\\zeta}}")#text(" in the region ")#mi("{\\sigma > 2}")#text(" one sees that this bound also holds with ")#mi("{\\sigma > 2}")#text(", and from the functional equation we see that it also holds for ")#mi("{\\sigma < -1}")#text(". In particular, with ")#mi("{F}")#text(" as in the preceding exercise, we see that the entire function ")#mi("{\\frac{\\xi^{\\prime}}{\\xi}(s) - F(s)}")#text(" is bounded by ")#tao-math("{O( \\log(2+\\left|s\\right|))}", block: false)#text(" on the entire complex plane. By the generalised Cauchy integral formula (Exercise 9 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(") applied to a disk of radius ")#mi("{R}")#text(" we conclude that ")#mi("{\\frac{\\xi^{\\prime}}{\\xi}(s) - F(s)}")#text(" has derivative ")#tao-math("{O( \\log(2+\\left|s\\right|+R) / R )}", block: false)#text(" for any ")#mi("{R>0}")#text(", and by sending ")#mi("{R \\rightarrow \\infty}")#text(" we conclude that this function is constant; thus we have the representation")

#align(center)[#tao-fit-display[#mitex("\\frac{\\xi^{\\prime}}{\\xi}(s) = B + \\sum_\\rho \\frac{1}{s-\\rho} + \\frac{1}{\\rho}")]]

#text("for some absolute constant ")#mi("{B}")#text(", and all ")#mi("{s}")#text(" away from the non-trivial zeroes of ")#mi("{\\zeta}")#text(". From ")#link(<tao-c765d2f7b42f2a483927>)[#text("(6)")]#text(" and Exercise ")#link(<tao-ebbde58a4bbe357e599b>)[#text("11")]#text(", we conclude the representation ")#metadata(none) <tao-1143321fb569a85798a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#mitex("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = B^{\\prime} + \\frac{1}{s-1} - \\sum_\\rho (\\frac{1}{s-\\rho} + \\frac{1}{\\rho}) - \\sum_n (\\frac{1}{s+2n} - \\frac{1}{2n})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("B^{\\prime} = -B - \\frac{1}{2} \\log \\pi - \\frac{1}{2} \\gamma.")]]

#text("The exact values of ")#mi("{B, B^{\\prime}}")#text(" are not terribly important for applications, but can be computed explicitly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45")]#text(" By inspecting both sides of the above equations as ")#mi("{s \\rightarrow 0}")#text(", show that ")#mi("{B^{\\prime} = - \\log 2\\pi + 1}")#text(", and hence ")#mi("{B = \\log 2 + \\frac{1}{2} \\log \\pi - 1 - \\frac{1}{2} \\gamma}")#text(".")
]

#text("By inserting ")#link(<tao-1143321fb569a85798a5>)[#text("(45)")]#text(" into Perron’s formula (Exercise 11 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("), we obtain the ")#link("http://en.wikipedia.org/wiki/Explicit_formulae_%28L-function%29")[#text("Riemann-von Mangoldt explicit formula")]#text(" for the von Mangoldt summatory function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46 (Riemann-von Mangoldt explicit formula)")]#text(" For any non-integer ")#mi("{x > 1}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\Lambda(n) = x - 1 - \\lim_{T \\rightarrow \\infty} \\sum_{\\rho: \\left|\\text{Im}(\\rho)\\right| \\leq T} \\frac{x^\\rho}{\\rho} - \\sum_n \\frac{x^{-2n}}{-2n} + B^{\\prime}.", block: true)]]

#text("Conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\Lambda(n) = x - \\lim_{T \\rightarrow \\infty} \\sum_{\\rho: \\left|\\text{Im}(\\rho)\\right| \\leq T} \\frac{x^\\rho}{\\rho} - \\log(2\\pi) - \\frac{1}{2} \\log( 1 - x^{-2} ).", block: true)]]
]

#text("This is an exact counterpart of the truncated explicit formula (Theorem 21 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("), although in many applications the truncated formula is a little bit more convenient to use; the untruncated formula supplies all of the “lowest order terms”, but these terms are destined to be absorbed into error terms in most applications anyway.")

#text("We similarly have a global smoothed explicit formula, refining Exercise 22 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47 (Smoothed explicit formula)")]#text(" ")#metadata(none) <tao-baf97b94534f5197f0ba>#text(" Let ")#mi("{g: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth function, compactly supported on the positive real axis. Show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\Lambda(n) g(\\log n)  & = \\hat g(-i) - \\sum_\\rho \\hat g(-i\\rho)", block: true)



#tao-math(" & - \\sum_n \\hat g(2in)", block: true)
]

#text("with the sums being absolutely convergent. Conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\Lambda(n) \\eta(n) = \\int_{\\bf R} (1 - \\frac{1}{y^3-y}) \\eta(y)\\ dy - \\sum_\\rho \\int_{\\bf R} \\eta(y) y^{\\rho-1}\\ dy")]]

#text("whenever ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a smooth function, compactly supported in ")#mi("{(1,+\\infty)}")#text(".")
]

#text("The following variant of the smoothed explicit formula is particularly useful for studying the behaviour of zeroes of the zeta function on the critical line ")#mi("{\\text{Re} s = \\frac{1}{2}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 48 (Riemann-Weil explicit formula)")]#text(" Let ")#mi("{g: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth compactly supported function. Show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_\\gamma \\hat g(\\gamma)  & = \\hat g(i/2) + \\hat g(-i/2) - \\sum_n \\frac{\\Lambda(n)}{\\sqrt{n}} (g(\\log n) + g(-\\log n))", block: true)



#tao-math(" & + \\frac{1}{2\\pi} \\int_{\\bf R} \\hat g(t) (\\frac{\\Gamma^{\\prime}_\\infty}{\\Gamma_\\infty}(\\frac{1}{2}+it) + \\frac{\\Gamma^{\\prime}_\\infty}{\\Gamma_\\infty}(\\frac{1}{2}-it))\\ dt", block: true)
]

#text("where the non-trivial zeroes ")#mi("{\\rho}")#text(" of the zeta function are parameterised as ")#mi("{\\rho = \\frac{1}{2}+i\\gamma}")#text(", and ")#mi("{\\Gamma_\\infty(s) := \\pi^{-s/2} \\Gamma(\\frac{s}{2})}")#text(", with the sum over ")#mi("{\\gamma}")#text(" being absolutely convergent. (")#emph[#text("Hint:")]#text(" first reduce to the case when ")#mi("{g}")#text(" (and hence ")#mi("{\\hat g}")#text(") is an even function, by eliminating the case when ")#mi("{g}")#text(" is odd. Then, integrate the meromorphic function ")#mi("{\\frac{\\xi^{\\prime}}{\\xi}(s) \\hat g(i(s-\\frac{1}{2}))}")#text(" around a rectangle with vertices ")#mi("{2 \\pm iT}")#text(", ")#mi("{-1\\pm iT}")#text(" (say) for some large ")#mi("{T}")#text(" and apply the residue theorem and the contour integration. It is also possible to derive this formula from Exercise ")#link(<tao-baf97b94534f5197f0ba>)[#text("47")]#text(" by starting with the case when ")#mi("{g}")#text(" is supported on the positive real axis, then the negative axis, then for ")#mi("{g}")#text(" supported in an infinitesimally small neighbourhood of the origin.)")
]

#heading(level: 1)[#strong[#text(" — 5. The functional equation for Dirichlet ")#mi("{L}")#text("-functions — ")]]

#text("Now we turn to the functional equation for Dirichlet ")#mi("{L}")#text("-functions ")#mi("{L(\\cdot,\\chi)}")#text(", Theorem ")#link(<tao-4ef6f0b42e4be3ba589c>)[#text("3")]#text(". Henceforth ")#mi("{\\chi}")#text(" is a primitive character of modulus ")#mi("{q}")#text(". To obtain the functional equation for ")#mi("{L(s,\\chi)}")#text(", we will need a twisted version of the Poisson summation formula ")#link(<tao-c8c3727df724362b5453>)[#text("(8)")]#text(". The key to performing the twist is the following expression for the additive Fourier coefficients of ")#mi("{\\chi}")#text(" in the group ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 49")]#text(" Let ")#mi("{e(x) := e^{2\\pi i x}}")#text(", and let ")#mi("{\\chi}")#text(" be a primitive character of modulus ")#mi("{q}")#text(". Then for any ")#mi("{a \\in {\\bf Z}/q{\\bf Z}}")#text(", we have ")#metadata(none) <tao-4a04926224a93c5e8ca3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("\\sum_{n \\in {\\bf Z}/q{\\bf Z}} \\chi(n) e(an/q) = \\overline{\\chi(a)} \\tau(\\chi)")]]

#text("where we abuse notation by viewing the ")#mi("{q}")#text("-periodic functions ")#mi("{n \\mapsto \\chi(n)}")#text(" and ")#mi("{n \\mapsto e(n/q)}")#text(" as functions on ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(", and the ")#link("http://en.wikipedia.org/wiki/Gauss_sum")[#text("Gauss sum")]#text(" ")#mi("{\\tau(\\chi)}")#text(" is defined by the formula ")#link(<tao-d5e49029578bedaffc67>)[#text("(11)")]#text(".")
]

#emph[#text("Proof:")]#text(" The formula ")#link(<tao-4a04926224a93c5e8ca3>)[#text("(46)")]#text(" is trivial when ")#mi("{a=1}")#text(", and by making the substitution ")#mi("{m=an}")#text(" we see that it is also true when ")#mi("{a}")#text(" is coprime to ")#mi("{q}")#text(". Now suppose that ")#mi("{a}")#text(" shares a common factor ")#mi("{q_1>1}")#text(" with ")#mi("{q}")#text(", then the right-hand side of ")#link(<tao-4a04926224a93c5e8ca3>)[#text("(46)")]#text(" vanishes. Writing ")#mi("{q = q_1 q_2}")#text(", we see that ")#mi("{n \\mapsto e(an/q)}")#text(" is periodic with period ")#mi("{q_2}")#text(", and in particular is invariant with respect to multiplication by any invertible element ")#mi("{m}")#text(" of ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" whose projection to ")#mi("{{\\bf Z}/q_2{\\bf Z}}")#text(" is one; thus the left-hand side of ")#link(<tao-4a04926224a93c5e8ca3>)[#text("(46)")]#text(" is invariant under multiplication by ")#mi("{\\chi(m)}")#text(". We are thus done unless ")#mi("{\\chi(m)=1}")#text(" for all invertible ")#mi("{m}")#text(" that projects down to one on ")#mi("{{\\bf Z}/q_2{\\bf Z}}")#text(". But then ")#mi("{\\chi}")#text(" factors as the product of a character of modulus ")#mi("{q_2}")#text(" and a principal character, contradicting the hypothesis that ")#mi("{\\chi}")#text(" is primitive. ")#mi("\\Box")

#text("The Gauss sum ")#mi("{\\tau(\\chi)}")#text(", being an inner product between a multiplicative character ")#mi("{n \\mapsto \\chi(n)}")#text(" and an additive character ")#mi("{n \\mapsto e(n/q)}")#text(", is analogous to the Gamma function ")#mi("{\\Gamma(s)}")#text(", which is also an inner product between a multiplicative character ")#mi("{t \\mapsto t^s}")#text(" and an additive character ")#mi("{t \\mapsto e^{-t}}")#text(". This analogy can be deepened by working in ")#link("http://en.wikipedia.org/wiki/Tate%27s_thesis")[#text("Tate’s adelic formalism")]#text(", but we will not do so here. But we will give one further demonstration of the analogy between Gauss sums and Gamma functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50 (Jacobi sum identity)")]#text(" ")#metadata(none) <tao-4d6d9ac0752cd209cc3e>#text(" Let ")#mi("{\\chi, \\chi^{\\prime}}")#text(" be Dirichlet characters modulo a prime ")#mi("{p}")#text(", such that ")#mi("{\\chi,\\chi^{\\prime},\\chi\\chi^{\\prime}}")#text(" are all non-principal. By computing the sum ")#mi("{\\sum_{n,n^{\\prime} \\in {\\bf Z}/p{\\bf Z}} \\chi(n) \\chi^{\\prime}(n^{\\prime}) e( (n+n^{\\prime})/p )}")#text(" in two different ways, establish the ")#link("http://en.wikipedia.org/wiki/Jacobi_sum")[#text("Jacobi sum")]#text(" identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/p{\\bf Z}} \\chi(n) \\chi^{\\prime}(1-n) = \\frac{\\tau(\\chi) \\tau(\\chi^{\\prime})}{\\tau(\\chi\\chi^{\\prime})}.")]]

#text("This should be compared with the beta function identity, Lemma ")#link(<tao-f44e64e75f3948e9f73f>)[#text("7")]#text(".")
]

#text("From ")#link(<tao-4a04926224a93c5e8ca3>)[#text("(46)")]#text(" and the Fourier inversion formula on ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" (")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Theorem 69")]#text(" from Notes 1), we have ")#metadata(none) <tao-39a48ec00390940c0bda>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#mitex("\\chi(n) = \\frac{\\tau(\\chi)}{q} \\sum_{a \\in {\\bf Z}/q{\\bf Z}} \\overline{\\chi(a)} e(-an/q);")]]

#linebreak()#text(" setting ")#mi("{n=-1}")#text(", we conclude in particular that ")#metadata(none) <tao-556782d0d8f96049f349>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#mitex("\\tau(\\chi) \\tau(\\overline{\\chi}) = q \\chi(-1),")]]

#text("which is somewhat analogous to the reflection formula for the Gamma function (Lemma ")#link(<tao-421c47d8c413985f08df>)[#text("8")]#text("). On the other hand, from ")#link(<tao-4a04926224a93c5e8ca3>)[#text("(46)")]#text(" with ")#mi("{a=-1}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\tau(\\overline{\\chi}) = \\overline{\\tau(\\chi)} \\chi(-1)")]]

#text("and thus ")#metadata(none) <tao-560c48d6c73e72bde5e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#tao-math("\\left|\\tau(\\chi)\\right|^2 = q.", block: true)]]

#text("This determines the magnitude of ")#mi("{\\tau(\\chi)}")#text("; in particular, the quantity ")#mi("{\\varepsilon(\\chi)}")#text(" defined in ")#link(<tao-ecba710d4a728b1971a8>)[#text("(10)")]#text(" has magnitude one, and ")#metadata(none) <tao-e1fd6c028c076f1cda5c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(50)")])
#mitex("\\varepsilon(\\chi) \\varepsilon(\\overline{\\chi}) = 1.")]]

#text("The phase of ")#mi("{\\tau(\\chi)}")#text(" (or ")#mi("{\\varepsilon(\\chi)}")#text(") is harder to compute, except when ")#mi("{\\chi}")#text(" is a real primitive character, where we have the remarkable discovery of Gauss that ")#mi("{\\varepsilon(\\chi)=+1}")#text("; see the appendix below.")#linebreak()#text(" Now suppose that ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a twice continuously differentiable, compactly supported function. We can expand the sum ")#mi("{\\sum_n f(n) \\chi(n)}")#text(" using ")#link(<tao-39a48ec00390940c0bda>)[#text("(47)")]#text(" (and identifying ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" with ")#mi("{\\{0,\\dots,q-1\\}}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(n) \\chi(n) = \\frac{\\tau(\\chi)}{q} \\sum_{a=0}^{q-1} \\overline{\\chi(a)} \\sum_n f(n) e(-an/q);")]]

#text("applying the Poisson summation formula ")#link(<tao-c8c3727df724362b5453>)[#text("(8)")]#text(" to the modulated function ")#mi("{x \\mapsto f(x) e(-ax/q)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(n) \\chi(n) = \\frac{\\tau(\\chi)}{q} \\sum_{a=0}^{q-1} \\overline{\\chi(a)} \\sum_m \\hat f(2\\pi m - \\frac{2\\pi a}{q}),")]]

#text("which on making the change of variables ")#mi("{\\tilde m := qm - a}")#text(", and then relabeling ")#mi("{\\tilde m}")#text(" as ")#mi("{m}")#text(", becomes the ")#emph[#text("twisted Poisson summation formula")]#text(" ")#metadata(none) <tao-126cedc995cfb1f51b13>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(51)")])
#mitex("\\sum_n f(n) \\chi(n) = \\frac{(-1)^\\kappa \\tau(\\chi)}{q} \\sum_m \\hat f(\\frac{2\\pi m}{q}) \\overline{\\chi}(m)")]]

#text("where ")#mi("{\\kappa:=0}")#text(" when ")#mi("{\\chi(-1)=+1}")#text(" and ")#mi("{\\kappa:=1}")#text(" when ")#mi("{\\chi(-1)=-1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 51")]#text(" One can view both the ordinary Poisson summation formula ")#link(<tao-c8c3727df724362b5453>)[#text("(8)")]#text(" and its twisted analogue ")#link(<tao-126cedc995cfb1f51b13>)[#text("(51)")]#text(" as special cases of the adelic Poisson summation formula; see ")#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/")[#text("this previous blog post")]#text(". However, we will not explicitly adopt the adelic viewpoint here.")
]

#text("We now adapt the proofs of the functional equation for ")#mi("{\\zeta}")#text(" to prove Theorem ")#link(<tao-4ef6f0b42e4be3ba589c>)[#text("3")]#text(", using ")#link(<tao-126cedc995cfb1f51b13>)[#text("(51)")]#text(" as a replacement for ")#link(<tao-c8c3727df724362b5453>)[#text("(8)")]#text(". One can use any of the three proofs for this purpose, but I found it easiest to work with the third proof. We first work heuristically. As before, we formally apply ")#link(<tao-126cedc995cfb1f51b13>)[#text("(51)")]#text(" with ")#mi("{f(x) := 1_{x>0} \\frac{1}{x^s}}")#text(", ignoring all infinite divergences. Again, the Fourier transform is given by")

#align(center)[#tao-fit-display[#mitex("\\hat f(y) = \\Gamma(1-s) \\frac{1}{(-iy)^{1-s}}")]]

#text("and so ")#link(<tao-126cedc995cfb1f51b13>)[#text("(51)")]#text(" formally yields")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\chi(n)}{n^s} = \\frac{\\chi(-1) \\tau(\\chi)}{q} \\Gamma(1-s) \\sum_m \\frac{\\overline{\\chi}(m)}{(-2\\pi i m/q)^{1-s}}.")]]

#text("The ")#mi("{m=0}")#text(" term is formally absent since ")#mi("{\\chi(0)=0}")#text(". If one converts the sum over negative ")#mi("{m}")#text(" to a sum over positive ")#mi("{m}")#text(" by the change of variables ")#mi("{m \\mapsto -m}")#text(", and formally identifies ")#mi("{\\sum_n \\frac{\\chi(n)}{n^s}}")#text(" and ")#mi("{\\sum_m \\frac{\\overline{\\chi}(m)}{m^{1-s}}}")#text(" with ")#mi("{L(s,\\chi)}")#text(" and ")#mi("{L(1-s,\\overline{\\chi})}")#text(", one formally obtains Theorem ")#link(<tao-4ef6f0b42e4be3ba589c>)[#text("3")]#text(" after some routine calculation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 52")]#text(" Make the above argument rigorous by adapting the argument in Exercise ")#link(<tao-6f62d10313bb7adb62fb>)[#text("26")]#text(".")
]

#text("The following exercise develops the analogue of Riemann’s second proof of the functional equation, which is the proof of the functional equation for Dirichlet ")#mi("{L}")#text("-functions that is found in most textbooks.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 53")]#text(" Let ")#mi("{\\chi}")#text(" be a primitive character of conductor ")#mi("{q>1}")#text(", and let ")#mi("{s}")#text(" be such that ")#mi("{\\text{Re}(s) > 1}")#text(". Define the theta-type function")

#align(center)[#tao-fit-display[#mitex("\\vartheta_\\kappa(z,\\chi) := \\sum_{n \\in {\\bf Z}} n^\\kappa \\chi(n) e^{\\pi i n^2 z/q}.")]]

#text("in the half-plane ")#mi("{\\text{Im} z > 0}")#text(". The purpose of the ")#mi("{n^\\kappa}")#text(" factor is to make the summand even in ")#mi("{n}")#text(", rather than odd (as the theta-function would be trivial if the summand were odd).")

#list(
[#text("(i) Establish the functional equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(52)")])
#mitex("\\vartheta_\\kappa( z, \\chi ) = \\varepsilon(\\chi) \\frac{1}{(-iz)^{\\kappa+1/2}} \\vartheta_\\kappa( -\\frac{1}{z}, \\overline{\\chi} )")]]

#text("for ")#mi("{\\text{Im}(z) > 0}")#text(", using the standard branch of the square root.")],
[#text("(ii) Show that")

#align(center)[#tao-fit-display[#mitex("(q/\\pi)^{(s+\\kappa)/2} \\Gamma(\\frac{s+\\kappa}{2}) L(s,\\chi) = \\frac{1}{2} \\int_0^\\infty x^{\\frac{s+\\kappa}{2}} \\vartheta_\\kappa(ix, \\chi)\\ \\frac{dx}{x}.")]]

#text("(")#emph[#text("Hint:")]#text(" use either ")#link(<tao-b6b1ecf2b1b3b58ba2e7>)[#text("(14)")]#text(" or ")#link(<tao-65021ed80cd3995b0709>)[#text("(15)")]#text(", depending on the value of ")#mi("{\\kappa}")#text(".)")],
[#text("(iii) Show that")

#tao-aligned(keep: true)[


#tao-math("(q/\\pi)^{(s+\\kappa)/2} \\Gamma(\\frac{s+\\kappa}{2}) L(s,\\chi)  & = \\frac{1}{2} \\int_1^\\infty [ x^{\\frac{s+\\kappa}{2}} \\vartheta_\\kappa(ix, \\chi)", block: true)



#tao-math(" & + \\varepsilon(\\chi) x^{\\frac{1-s+\\kappa}{2}} \\vartheta_\\kappa(ix, \\overline{\\chi}) ] \\frac{dx}{x}.", block: true)
]],
[#text("(iv) Prove Corollary ")#link(<tao-9d3e1d99bbb47e290f2e>)[#text("4")]#text(".")]
)
]

#text("One can also adapt the first proof of Riemann to the ")#mi("{L}")#text("-function setting, as was done in ")#link("http://www.ams.org/mathscinet-getitem?mr=311593")[#text("this paper of Berndt")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 54")]#text(" Let ")#mi("{\\chi}")#text(" be a primitive character of conductor ")#mi("{q>1}")#text(".")

#list(
[#text("(i) Show that the function ")#mi("{z \\mapsto \\sum_n \\chi(n) e^{-nz}}")#text(", initially defined for ")#mi("{\\text{Re}(z) > 0}")#text(", extends to a rational function on the complex plane with poles at ")#mi("{2\\pi i m/q}")#text(" for ")#mi("{m \\in {\\bf Z}}")#text(" coprime to ")#mi("{q}")#text(", and a residue of ")#mi("{\\frac{\\overline{\\chi}(-m) \\tau(\\chi)}{q}}")#text(" at ")#mi("{2\\pi i m/q}")#text(".")],
[#text("(ii) Prove Theorem ")#link(<tao-4ef6f0b42e4be3ba589c>)[#text("3")]#text(" by expressing ")#mi("{L(s,\\chi)}")#text(" for ")#mi("{\\text{Re}(s) > 1}")#text(" as a contour integral over the contour ")#mi("{C}")#text(" used in Section ")#link(<tao-074558d320ca70a74505>)[#text("2")]#text(".")]
)
]

#text("The next exercise extends the approximate functional equations for the zeta function to Dirichlet ")#mi("{L}")#text("-functions for primitive characters of some conductor ")#mi("{q>1}")#text(". As may be expected from Notes 2, the role of ")#tao-math("{1+\\left|t\\right|}", block: false)#text(" in the error terms will be replaced with ")#tao-math("{q(1+\\left|t\\right|)}", block: false)#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55 (Approximate functional equation)")]#text(" ")#metadata(none) <tao-e82786a21564528d6b08>#text(" Let ")#mi("{\\chi}")#text(" be a primitive Dirichlet character of conductor ")#mi("{q>1}")#text(". Let ")#mi("{s = \\sigma+it}")#text(" in the critical strip.")

#list(
[#text("(i) Show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(53)")])
#mitex("L(s,\\chi) = \\sum_n \\frac{\\chi(n)}{n^s} \\eta( \\log n - \\log x) + O_{\\eta, A, \\sigma}( x^{-A} )")]]

#text("for any ")#mi("{A>0}")#text(", if ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a smooth function such that ")#mi("{\\eta(x)}")#text(" vanishes for ")#mi("{x>C}")#text(" and equals ")#mi("{1}")#text(" for ")#mi("{x<-C}")#text(" for some constant ")#mi("{C>0}")#text(", and ")#tao-math("{x \\geq C^{\\prime} q (1+\\left|t\\right|)}", block: false)#text(" for some sufficiently large ")#mi("{C^{\\prime}}")#text(" depending on ")#mi("{C}")#text(".")],
[#text("(ii) Show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(54)")])
#mitex("\\sum_n \\frac{\\chi(n)}{n^s} \\psi( \\log n - \\log x ) = \\frac{1}{2\\pi} \\int_{\\bf R} \\hat \\psi(y) x^{iy} L(s+iy,\\chi)\\ dy")]]

#text("for any smooth, compactly supported function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" and any ")#mi("{x > 0}")#text(".")],
[#text("(iii) Suppose that ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(", and let ")#mi("{N,M \\gg 1}")#text(" be such that ")#tao-math("{NM = \\frac{q\\left|t\\right|}{2\\pi}}", block: false)#text(". Let ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth compactly supported function. Then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(55)")])
#mitex("\\sum_n \\frac{\\chi(n)}{n^s} \\psi( \\log n - \\log N ) =")]]

#align(center)[#tao-fit-display[#tao-math("\\alpha(s,\\chi) \\sum_m \\frac{\\overline{\\chi(m)}}{m^{1-s}} \\psi( \\log M - \\log m ) + O_{\\sigma,\\varepsilon,\\psi}( (q\\left|t\\right|)^{-\\sigma/2-1/2+\\varepsilon} )", block: true)]]

#text("for any ")#mi("{\\varepsilon>0}")#text(" and any smooth, compactly supported ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\alpha(s,\\chi) := \\varepsilon(\\chi) 2^s \\pi^{s-1} q^{1/2-s} \\sin(\\frac{\\pi}{2}(s+\\kappa)) \\Gamma(1-s).")]]],
[#text("(iv) With ")#mi("{t,N,M}")#text(" as in (iii), and ")#mi("{\\eta}")#text(" as in (i), show that")

#tao-aligned(keep: true)[


#tao-math("L(s,\\chi)  & = \\sum_n \\frac{\\chi(n)}{n^s} \\eta( \\log n - \\log N)", block: true)



#tao-math(" & + \\alpha(s,\\chi) \\sum_m \\frac{\\overline{\\chi(m)}}{m^{1-s}} \\tilde \\eta( \\log m - \\log M)", block: true)



#tao-math(" & + O_{\\eta, \\sigma, \\varepsilon} ( (q\\left|t\\right|)^{-\\sigma/2-1/2+\\varepsilon} ),", block: true)
]

#text("where ")#mi("{\\tilde \\eta(u) := 1 - \\eta(-u)}")#text(".")]
)
]

#text("There are useful variants of the approximate functional equation for ")#mi("{L}")#text("-functions that are valid in the low-lying regime ")#mi("{t=O(1)}")#text(", but we will not detail them here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 56")]#text(" Let ")#mi("{\\chi}")#text(" be a primitive character of modulus ")#mi("{q > 1}")#text(", and let ")#mi("{T \\geq 2}")#text(". Let ")#mi("{N(T,\\chi)}")#text(" denote the number of zeroes of ")#mi("{L(s,\\chi)}")#text(" in the rectangle ")#tao-math("{\\{ \\sigma+it: 0 < \\sigma < 1; \\left|t\\right| \\leq T \\}}", block: false)#text(" (note that we are now including the lower half-plane as well as the upper half-plane, as the zeroes of ")#mi("{L(s,\\chi)}")#text(" need not be symmetric around the real axis when ")#mi("{\\chi}")#text(" is complex). Show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} N(T,\\chi) = \\frac{T}{2\\pi} \\log \\frac{qT}{2\\pi} - \\frac{T}{2\\pi} + O( \\log(qT) ).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 57 (Riemann-von Mangoldt explicit formula for ")#mi("{L}")#text("-functions)")]#text(" Let ")#mi("{x > 1}")#text(" be a non-integer, and let ")#mi("{\\chi}")#text(" be a primitive Dirichlet character of conductor ")#mi("{q > 1}")#text(".")

#list(
[#text("(i) If ")#mi("{\\chi(-1)=-1}")#text(", show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\Lambda(n) \\chi(n)  & = - \\lim_{T \\rightarrow \\infty} \\sum_{\\rho: \\left|\\text{Im}(\\rho)\\right| \\leq T} \\frac{x^\\rho}{\\rho} - \\frac{L^{\\prime}(0,\\chi)}{L(0,\\chi)}", block: true)



#tao-math(" & + \\sum_n \\frac{x^{1-2n}}{2n-1}.", block: true)
]],
[#text("(ii) If ")#mi("{\\chi(-1)=+1}")#text(", show that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\Lambda(n) \\chi(n)  & = - \\lim_{T \\rightarrow \\infty} \\sum_{\\rho: \\left|\\text{Im}(\\rho)\\right| \\leq T} \\frac{x^\\rho}{\\rho} - \\log x + b(\\chi)", block: true)



#tao-math(" & + \\sum_n \\frac{x^{-2n}}{2n}", block: true)
]

#text("for some quantity ")#mi("{b(\\chi)}")#text(" depending only on ")#mi("{\\chi}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 58")]#text(" Let ")#mi("{f: (0,+\\infty) \\rightarrow {\\bf R}}")#text(" be the function ")#mi("{f(t) := \\frac{1}{e^t-1}-\\frac{1}{t}}")#text(" from Exercise 67 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(". Let ")#mi("{\\chi}")#text(" be a non-principal Dirichlet character of conductor ")#mi("{q}")#text(". Use the twisted Poisson formula to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\chi(n) (f(\\frac{n}{2x}) - f(\\frac{n}{x})) \\ll \\sqrt{q}")]]

#text("for any ")#mi("{x \\geq q}")#text(", where the sum is in the conditionally convergent sense. (You may need to smoothly truncate the function ")#mi("{f(\\frac{t}{2}) - f(t)}")#text(" before applying the twisted Poisson formula.) Use this and the argument from the previous exercise to establish the bound ")#mi("{L(1,\\chi) \\gg q^{-1/2}}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 6. Appendix: Gauss sum for real primitive characters — ")]]

#metadata(none) <tao-b455b345a7b8a850e8a9>#linebreak()#text(" The material here is not needed elsewhere in this course, or even in this set of notes, but I am including it because it is a very pretty piece of mathematics; it is also the very first hint of a much deeper connection between automorphic forms and Galois theory known as the ")#link("http://en.wikipedia.org/wiki/Langlands_program")[#text("Langlands program")]#text(", which I will not be able to discuss further here.")

#text("Suppose that ")#mi("{\\chi}")#text(" is a real primitive character. Then from ")#link(<tao-e1fd6c028c076f1cda5c>)[#text("(50)")]#text(", ")#mi("{\\varepsilon(\\chi)}")#text(" must be either ")#mi("{+1}")#text(" or ")#mi("{-1}")#text(". Applying Corollary ")#link(<tao-9d3e1d99bbb47e290f2e>)[#text("4")]#text(" with ")#mi("{s=1/2}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\xi(1/2,\\chi) = \\varepsilon(\\chi) \\xi(1/2,\\chi)")]]

#text("which strongly suggests that ")#mi("{\\varepsilon(\\chi)=+1}")#text(", but one has to prevent vanishing of ")#mi("{\\xi(1/2,\\chi)}")#text(" (or equivalently, ")#mi("{L(1/2,\\chi)}")#text("). (A similar argument using ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#thunk")[#text("(52)")]#text(" would also give ")#mi("{\\varepsilon(\\chi)=+1}")#text(" if one could somehow prevent vanishing of ")#mi("{\\theta_\\kappa(i)}")#text(".) While it has been conjectured (")#link("http://www.ams.org/mathscinet-getitem?mr=177943")[#text("by Chowla")]#text(") that ")#mi("{L(1/2,\\chi)}")#text(" is never zero (and should in fact be positive), this is still not proven unconditionally; see this ")#link("http://arxiv.org/abs/1403.7079")[#text("preprint of Fiorilli")]#text(" for recent work in this direction. (Indeed, understanding the vanishing of ")#mi("{L}")#text("-functions at the central point ")#mi("{s=1/2}")#text(" is a very deep problem, as attested to by the difficulty of the ")#link("http://en.wikipedia.org/wiki/Birch_and_Swinnerton-Dyer_conjecture")[#text("Birch and Swinnerton-Dyer conjecture")]#text(".) Nevertheless we still have the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 59 (Gauss sum for real primitive characters)")]#text(" ")#metadata(none) <tao-ebbde92862f7e39a4f74>#text(" One has ")#mi("{\\varepsilon(\\chi)=+1}")#text(" for any real primitive character ")#mi("{\\chi}")#text(".")
]

#text("This result is surprisingly tricky to prove. The exercises below give one such proof, essentially due to Dirichlet. First we reduce to quadratic characters modulo a prime:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 60 (Classification of real primitive characters)")]

#list(
[#text("(i) Let ")#mi("{q_1,q_2}")#text(" be coprime natural numbers. Show that if ")#mi("{\\chi_1, \\chi_2}")#text(" are real primitive characters of conductors ")#mi("{q_1, q_2}")#text(" respectively, then ")#mi("{\\chi_1 \\chi_2}")#text(" is a real primitive character of conductor ")#mi("{q_1 q_2}")#text(", and that ")#mi("{\\varepsilon(\\chi_1 \\chi_2) = \\varepsilon(\\chi_1) \\varepsilon(\\chi_2)}")#text(".")],
[#text("(ii) Conversely, if ")#mi("{q_1,q_2}")#text(" are coprime natural numbers and ")#mi("{\\chi}")#text(" is a real primitive character of conductor ")#mi("{q_1 q_2}")#text(", show that there exist unique real primitive characters ")#mi("{\\chi_1, \\chi_2}")#text(" of conductors ")#mi("{q_1, q_2}")#text(" respectively such that ")#mi("{\\chi = \\chi_1 \\chi_2}")#text(". (")#emph[#text("Hint:")]#text(" use the Chinese remainder theorem to identify ")#mi("{({\\bf Z}/q_1q_2{\\bf Z})^\\times}")#text(" with ")#mi("{({\\bf Z}/q_1)^\\times}")#text(" and ")#mi("{({\\bf Z}/q_2)^\\times}")#text(".")],
[#text("(iii) If ")#mi("{p}")#text(" is an odd prime and ")#mi("{j}")#text(" is a natural number, show that an element of ")#mi("{({\\bf Z}/p^j{\\bf Z})^\\times}")#text(" is a quadratic residue if and only if it is a quadratic residue after reduction to ")#mi("{({\\bf Z}/p{\\bf Z})^\\times}")#text(". Conclude that there are no real primitive characters of conductor ")#mi("{p^j}")#text(" if ")#mi("{j > 1}")#text(", and the only real primitive character of conductor ")#mi("{p}")#text(" is the quadratic character ")#mi("{n \\mapsto (\\frac{n}{p})}")#text(".")],
[#text("(iv) If ")#mi("{j \\geq 3}")#text(", show that an element of ")#mi("{({\\bf Z}/2^j{\\bf Z})^\\times}")#text(" is a quadratic residue if and only if it is a quadratic residue after reduction to ")#mi("{({\\bf Z}/8{\\bf Z})^\\times}")#text(". Conclude that there are no real primitive characters of conductor ")#mi("{2^j}")#text(" if ")#mi("{j > 3}")#text(", and show that there is one such character of conductor ")#mi("{4}")#text(", two characters of conductor ")#mi("{8}")#text(", and no characters of conductor ")#mi("{2}")#text(". Verify that ")#mi("{\\varepsilon(\\chi)=1}")#text(" for each of these characters.")]
)
]

#text("In view of this exercise and the fundamental theorem of arithmetic, we see that to verify Theorem ")#link(<tao-ebbde92862f7e39a4f74>)[#text("59")]#text(", it suffices to do so when ")#mi("{\\chi(n) = (\\frac{n}{p})}")#text(" for some odd prime ")#mi("{p}")#text(". This can be achieved using the functional equation ")#link(<tao-e204073f8805bb3a8e05>)[#text("(30)")]#text(" for the theta function ")#mi("{\\vartheta}")#text(" defined in ")#link(<tao-45b182f566f2efb3077f>)[#text("(29)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 61 (Landsberg-Schaar relation and its consequences)")]#text(" Let ")#mi("{p}")#text(" be an odd prime, and let ")#mi("{\\chi(n) = ( \\frac{n}{p} )}")#text(" be the quadratic character to modulus ")#mi("{p}")#text(".")

#list(
[#text("(i) Show that ")#mi("{\\tau(\\chi) = \\sum_{n \\in {\\bf Z}/p{\\bf Z}} e( n^2 / p )}")#text(". (")#emph[#text("Hint:")]#text(" rewrite both sides in terms of the sum of ")#mi("{e(n/p)}")#text(" over quadratic residues or non-residues ")#mi("{n}")#text(".)")],
[#text("(ii) For any natural numbers ")#mi("{p, q}")#text(", establish the ")#link("http://en.wikipedia.org/wiki/Landsberg%E2%80%93Schaar_relation")[#text("Landsberg-Schaar relation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(56)")])
#mitex("\\frac{1}{\\sqrt{p}} \\sum_{n \\in {\\bf Z}/p{\\bf Z}} e( n^2 q / p ) = \\frac{e^{\\pi i/4}}{\\sqrt{2q}} \\sum_{m \\in {\\bf Z}/2q{\\bf Z}} e( - n^2 p / 4q )")]]

#text("by using the functional equation ")#link(<tao-e204073f8805bb3a8e05>)[#text("(30)")]#text(" with ")#mi("{z = 2q/p + i \\varepsilon}")#text(" and sending ")#mi("{\\varepsilon \\rightarrow 0^+}")#text(".")],
[#text("(iii) By using the ")#mi("{q=1}")#text(" case of the Landsberg-Schaar relation, show that ")#mi("{\\chi(-1)}")#text(" is equal to ")#mi("{1}")#text(" when ")#mi("{p = 1\\ (4)}")#text(" and ")#mi("{-1}")#text(" when ")#mi("{p = 3\\ (4)}")#text(", and that ")#mi("{\\varepsilon(\\chi)=+1}")#text(".")],
[#text("(iv) By applying the Landsberg-Schaar relation with ")#mi("{q}")#text(" an odd prime distinct from ")#mi("{p}")#text(", establish the ")#link("http://en.wikipedia.org/wiki/Quadratic_reciprocity")[#text("law of quadratic reciprocity")]

#align(center)[#tao-fit-display[#mitex("(\\frac{q}{p}) (\\frac{p}{q}) = (-1)^{(p-1)(q-1)/4}.")]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 62")]#text(" Define a ")#emph[#text("fundamental discriminant")]#text(" to be an integer ")#mi("{D}")#text(" that is the discriminant of a quadratic number field; recall from ")#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/")[#text("Supplement 1")]#text(" that such ")#mi("{D}")#text(" take the form ")#mi("{-4d}")#text(" if ")#mi("{d}")#text(" is a squarefree integer with ")#mi("{d=1,2\\ (4)}")#text(", or ")#mi("{-d}")#text(" if ")#mi("{d}")#text(" is a squarefree integer with ")#mi("{d=3\\ (4)}")#text(". (Supplement 1 focused primarily on the negative discriminant case when ")#mi("{d>0}")#text(", but the above statement also holds for positive discriminant.) Show that if ")#mi("{D}")#text(" is a fundamental discriminant, then ")#mi("{n \\mapsto ( \\frac{D}{n} )}")#text(" is a primitive real character, where ")#mi("{( \\frac{D}{n} )}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Kronecker_symbol")[#text("Kronecker symbol")]#text(". Conversely, show that all primitive real characters arise in this fashion.")
]

#heading(level: 1)[#text("Comments (49)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445191")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Being simple")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288e2c8a58a6268a6c8ff5df98ea4d047e748e5401d15fc45a4deaeb19bb4078-828aa9dcba2c09b6126bddb8a926925bf25b82608a8eb26e5a314925f35b286f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicolas Templier")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445194")[#strong[#text("Nicolas Templier")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("Dear Terry,")

#text("The formula for ")#mi("\\zeta(-n)")#text(" can be deduced elegantly from the identity (27) in Riemann’s first proof of the functional equation. This may be a good exercise in addition to the other approaches.")

#emph[#text("[Thanks for the suggestion; I’ve extended the appropriate exercise to include this. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445204")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("It is interesting to observe that if RH is undecidable than it must be true, so it is impossible(!) to prove that RH is undecidable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("One has to be careful here in distinguishing truth (in a specific model) from probability (in a specific formal system); see e.g. ")#link("http://mathoverflow.net/questions/27755/knuths-intuition-that-goldbach-might-be-unprovable")[#text("http://mathoverflow.net/questions/27755/knuths-intuition-that-goldbach-might-be-unprovable")]#text(" for a similar discussion. If it turns out that RH is undecidable in (say) ZFC, this implies that RH is true in the ")#emph[#text("standard model")]#text(" of ZFC, but (by the completeness theorem) there would also be more exotic models of ZFC in which RH was false. (This is of course all under the ambient assumption that ZFC ")#strike[#text("is consistent")]#text(" has a standard model.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445225")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("I’m definitely not an expert on these things, but I think one should rather say something like “If RH is undecidable in ZFC, this implies that RH is true in the standard model of PA.” That is, unless you want to additionally assume the consistency of ZFC plus a certain large cardinal axiom; since whether or not ZFC has a standard model appears to be equivalent to a large cardinal axiom. See this mathoverflow answer: ")#link("http://mathoverflow.net/questions/124720/standard-model-of-zfc")[#text("http://mathoverflow.net/questions/124720/standard-model-of-zfc")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445252")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("I think Eytan was mostly getting at the not-obvious result that RH is equivalent to some ")#mi("\\Pi^0_1")#text(" arithmetic statements (similar to the Goldbach conjecture). Therefore if RH is false, there is a counterexample to one of those equivalent statements, that can be verified with ordinary arithmetic. It rules out the possibility that RH is false but this fact can’t be proven due to the counterexample’s imaginary part being non-constructable or something like that.")

#text("MO has some references:")

#link("http://mathoverflow.net/questions/31846/is-the-riemann-hypothesis-equivalent-to-a-pi-1-sentence")[#text("http://mathoverflow.net/questions/31846/is-the-riemann-hypothesis-equivalent-to-a-pi-1-sentence")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445273")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2014")])]

#text("I agree (of course) to the above remarks.")#linebreak()#text(" Another interesting (but very unlikely) possibility is to disprove RH (nonconstructively!) if it can be proved that RH implies that the infinite sequence ")#mi("\\mu (n)")#text(" (for squarefree ")#mi("n \\geq 1")#text(") is “sufficiently random” to have unbounded algorithmic complexity – contradicting its bounded algorithmic complexity!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sands")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-448171")[#strong[#text("Sands")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2015")])]

#text("The Riemann hypothesis is almost certainly true and provable. In order of time, I think you are highly likely to see shortly that these conjectures will be proven (or disproven) in this order:")

#text("1. The Riemann Hypothesis;")

#text("2. The Pair Correlation Conjecture; and")

#text("3. The Twin Prime Conjecture (but not with B-V-Zhang methods).")

#text("In order of difficulty, the problems should probably be ranked this way, most difficult to easiest:")

#text("1. Twin Prime Conjecture;")

#text("2. Riemann Hypothesis; and")

#text("3. The Pair Correlation Conjecture.")

#text("I know this will raise eyebrows, about which a bit more. Riemann says,")

#text("“One now finds indeed approximately this number")#linebreak()#text(" of real roots within these limits, and it is very probable that all roots are")#linebreak()#text(" real. Certainly one would wish for a stricter proof here; I have meanwhile")#linebreak()#text(" temporarily put aside the search for this after some fleeting futile attempts,")#linebreak()#text(" as it appears unnecessary for the next objective of my investigation.”")

#text("It is fairly obvious that Riemann thought that a proof was reachable, but that he didn’t see it as that important. It is reachable (looks around room of raised eyebrows). It is not in the class of true but unprovable problems, and I think you will see this within six months at most.")

#text("It is almost surely the case the Fermat’s last theorem was harder. I am not sure why the PCC has not been proven (or rather, why somone hasn’t done the math to derive the correct distribution function — perhaps it is the old joke about the drunk man circling a light post looking for his keys, if you know it.)")

#text("To back up my claim, I am willing to take bets. Since you believe I am wrong, I think it only fair that you give me 3-1 odds on $5. I will take up to 100 bets if given 3-1 odds on $5. I am happy to find an intemediary, trusted by all parties, to collect the money from me, and from you. Perhaps I will take 200 bets, 3-1 odds in my favor, at $5 each.")

#text("Don’t argue or put a thumbs down, accept the bet.")

#text("S")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445243")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("Riemann’s Mellin transform for the Riemann zeta in his original paper determines the Riemann zeta fct. in the complex plane, and Siegel discovered almost a century later in Riemann’s salvaged notes Riemann’s method of determining the non-trivial zeros from the complex integral, which is essentially the Mellin transform of the e.g.f. of the Bernoulli numbers ")#mi("B_n(0)=(-1)^n B_n(1)")#text(" determined by the Bernoulli polynomials ")#mi("B_n(x)")#text(", whose e.g.f. is ")#mi("\\frac{t}{e^t-1}e^{xt}=e^{B.(x)t}")#text(". The Hurwitz zeta is the Mellin transform of ")#mi("e^{-B.(x)t}")#text(". In this sense, the Bernoulli numbers/polynomials determine the zeros of the Riemann zeta everywhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445274")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2014")])]

#text("Reblogged this on ")#link("http://tomcircle.wordpress.com/2014/12/16/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Math Online Tom Circle")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445296")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2014")])]

#text("In the second expression in exercise 45, it seems that “-1” (due to B’) is missing (wrt the first expression).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Cory")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445712")[#strong[#text("Matthew Cory")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2014")])]

#text("Analysis is an outdated dead end. The continuum is bunk! Use computers!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43ddb330150afecf37c6afea712795be45fe35eca9cf725fda6befea5027b1b4-35ec653ba5a2d80b0362359c061d1a655855a0941115ea5977030d72cc025026.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Cory")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-445757")[#strong[#text("Matthew Cory")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2014")])]

#text("I can’t help but get psychoanalytic about the rebellion against combinatorics.")#linebreak()#text(" The continuum is a self-contradictory fantasy.")

#text("Hilbert: “No one shall expel us from the paradise that Cantor has created for us.”")

#text("“The mandate of scientific thought, according to Freud, is to abolish all the fallacies that arise from anthropocentrism, from ascribing a privileged position in the natural world to human values or a human point of view. Copernican astronomy, Darwinian biology, and now psychoanalysis all give expression to this paramount motive of science, ‘the destruction of . . . narcissistic illusion.'”")

#link("http://www.math.rutgers.edu/~zeilberg/mamarim/mamarimPDF/real.pdf")[#text("Click to access real.pdf")]

#text("Appeared in “New Progress in Difference Equations”, edited by Bernd Aulbach, Saber Elaydi, and Gerry Ladas, (Proc. ICDEA 2001), Bernd Aulbach, ed., Taylor and Frances, London.")

#text("I can certainly agree that Christopher Lasch about the death drive: ")#link("https://books.google.com/books?id=eUgpnidNOBMC&lpg=PP1&dq=life%20against%20death&pg=PR7#v=onepage&q&f=false")[#text("https://books.google.com/books?id=eUgpnidNOBMC&lpg=PP1&dq=life%20against%20death&pg=PR7#v=onepage&q&f=false")]

#text("Solomon Feferman basically implies that computer scientists will win. Get with the future and accept irreducible complexity. Proof theory is basically dead, given the ghastly output of theorem solvers. ")#mi("{1*10}^{-100} code")#text(" is good enough for anyone! Automation will replace the Ted Kaczynskis no matter how many pipe bombs they hurl.")

#text("Norman Wildberger says that these people are failing high school math:")#linebreak()

#text("Being a computer scientist, I get used to the errors made by those who insist on declarative instead of imperative expressions. We live in a world of exactitude and they live in a realm of regressive primary narcissism. Well, I guess that explains the fifth-rate nature of their mathematical intuition.")

#text("How many angels were on the head of that pin again?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henrik S. Perrson")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-448750")[#strong[#text("Henrik S. Perrson")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2015")])]

#text("A complete proof of the Riemann hypothesis was completed on November 25. (Actually two proofs. A third is being reviewed.)")

#text("The author has been advised by the Chair of one of the top mathematics departments in the United States not to post any part of it on ArXiv until the manuscript is complete in all respects and, to the best of one’s abilities, has been vetted. He also suggests not posting it on ArXiv but submitting it directly to a Journal.")

#text("It is likely that proofs one and two will appear as one manuscript. Proof three will appear as a separate manuscript. Proof One has been verified by an Analyst (the techniques are techniques in Analysis – or analytic number theory if you prefer).")

#text("All mistakes are the author’s own. It is possible, but doubtful, that there are any mistakes.")

#text("We decided this notice was appropriate for a broader community at this time. Let the wolves loose.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henrik S. Perrson")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-448760")[#strong[#text("Henrik S. Perrson")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2015")])]

#text("We may have found a subtle error. Or maybe not. It seems it is so subtle that the best mathematicians can’t quite figure out wether it is an error. Probabilistically, I suppose, it must be untrue. Do you know the George Burns joke here?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 5: Bounding exponential sums and the zeta function | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-451617")[#strong[#text("254A, Notes 5: Bounding exponential sums and the zeta function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2015")])]

#text("[…] Now we seek better upper bounds on . We will reduce the problem to that of bounding certain exponential sums, in the spirit of Exercise 34 of Supplement 3: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-451888")[#strong[#text("254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2015")])]

#text("[…] (Hint: use the approximate functional equation, Exercise 39 from Supplement 3.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-452287")[#strong[#text("254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("[…] below, one could also use the slightly weaker estimates in Exercise 67 of Notes 2 or Exercise 57 of Notes 3 and still obtain comparable results. We will however not rely on Siegel’s theorem (Theorem 62 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-452617")[#strong[#text("254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2015")])]

#text("[…] e.g. Exercise 37 from Supplement 3.) In view of this, let us define the normalised log-magnitudes for any by the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-452850")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2015")])]

#text("In Exercise 31, the integral need not converge (and certainly does not converge absolutely) unless ")#mi("s")#text(" is in the critical strip. Wouldn’t it make sense to replace it by ")#mi("\\int_{\\mathbb{R}} \\frac{e^{(1-s) u}}{1-s} \\eta^{\\prime}(u) du")#text("? The result in that form can be easily proven (for ")#mi("\\Re(s)>0")#text(") from the displayed equation right before the exercise – and it implies directly the statement of Exercise 31 when ")#mi("s")#text(" is in the critical strip.")

#emph[#text("[Suggestion implemented, thanks – T.]")]

#text("Incidentally, there are two typos in the proof of Lemma 32 – the factor of ")#mi("e^{(1-\\sigma) u}")#text(" in the third displayed equation in the proof shouldn’t be there, and ")#mi("\\Phi")#text(" in the fourth displayed equation should be ")#mi("\\Psi")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-452853")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2015")])]

#text("PS. Why would dyadic decomposition be needed in Exercise 33?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-452867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2015")])]

#text("To get the good decay rate of ")#mi("O(x^{-A})")#text(" via Lemma 32, one needs to dyadically decompose the difference between two rescaled copies of ")#mi("\\eta")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-452942")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2015")])]

#text("In exercise 60, ")#mi("z = q/2p + i \\varepsilon")#text(" should be ")#mi("z = 2q/p + i \\varepsilon")#text(". Also, just saying “sending ")#mi("\\varepsilon \\rightarrow 0^+")#text("” leaves the impression that this is straightforward; in fact, a fairly detailed analysis of what happens as ")#mi("\\varepsilon \\rightarrow 0^+")#text(" is needed – see, e.g., ")#link("https://books.google.fr/books?id=kBsHBgAAQBAJ&lpg=PA222&ots=d80DtqLXdh&dq=landsberg-schaar%20relation&hl=fr&pg=PA221#v=onepage&q=landsberg-schaar%20relation&f=false")[#text("https://books.google.fr/books?id=kBsHBgAAQBAJ&lpg=PA222&ots=d80DtqLXdh&dq=landsberg-schaar%20relation&hl=fr&pg=PA221#v=onepage&q=landsberg-schaar%20relation&f=false")]#text(" . (Or is there a shortcut?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-452950")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2015")])]

#text("Thanks for the correction. One can simplify the analysis a little bit by estimating the sum by an integral (after first splitting into arithmetic progressions mod p or mod q as appropriate, to make the summands slowly varying), using tools such as Exercise 11 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", and then one can rescale the integrals by ")#mi("\\sqrt{\\varepsilon}")#text(" and use dominated convergence to extract the limit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-458475")[#strong[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("[…] can be proven by elementary means (see e.g. Exercise 57 of this post), although one can use Siegel’s theorem to obtain the better bound . Standard arguments (see […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab82efe8db2841454b1457793a9953a5a2a37cfd671dc7a9b01203b83c318270-25487a2c0a8940e06137563ee9850144e03d4637018ec997716042f03779ecb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiang Yu")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-469089")[#strong[#text("Xiang Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2016")])]

#text("In the table after equation (8), the trivial zeroes of ")#mi("\\zeta(1-s)")#text(" should be ")#mi("3,5,\\dots")#text(", $1$ is not a trivial zero of ")#mi("\\zeta(1-s)")#text(".")

#text("Lemma 8: From the definition of the ")#mi("\\alpha")#text("-function, we have ")#mi("\\alpha(s)=2^{s}\\pi^{s-1}\\sin(\\frac{\\pi s}{2})\\Gamma(1-s)")#text(", so ")#mi("\\alpha(s)")#text(" should have zeroes at ")#mi("0,-2,-4,\\dots")#text(" and poles at ")#mi("1,3,5,\\dots")#text(" (After removing all singularities). I’m confused about why you say from (19) that ")#mi("\\alpha")#text(" has a zero at ")#mi("s=0")#text(" and no other zeroes. After removing all removable singularities of ")#mi("\\alpha(s)\\alpha(1-s)")#text(", I think equation (19) is valid for all ")#mi("s\\in\\mathbf{C}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab82efe8db2841454b1457793a9953a5a2a37cfd671dc7a9b01203b83c318270-25487a2c0a8940e06137563ee9850144e03d4637018ec997716042f03779ecb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiang Yu")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-470219")[#strong[#text("Xiang Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2016")])]

#text("In Exercise 10, it should be ")#mi("\\Gamma(s)=e^{-\\gamma s}\\frac{1}{s}\\prod_n \\frac{e^{s/n}}{1+s/n}")#text(", since ")#mi("0")#text(" is a pole of ")#mi("\\Gamma")#text(".")

#text("In the text after Exercise 15, I’m a little confused about what the standard braches of the logarithm ")#mi("\\mathrm{Log}")#text(" means, is it defined by the formula ")#tao-math("\\mathrm{Log}(z):=\\log \\left|z\\right|+\\mathrm{arg}_{(-\\pi,\\pi]} z", block: false)#text("?")

#text("The first formula after Exercise 16 should be ")#tao-math("\\displaystyle\\sum_{n=0}^N\\frac{1}{s+n}=\\mathrm{Log}(N+s)-\\mathrm{Log}(s)+\\frac{1}{2s}+\\frac{1}{2(s+N)}+O(\\frac{1}{\\left|s\\right|^2})", block: false)#text(".")

#text("Small typo in the last formula before Exercise 39, it should be ")#tao-math("\\zeta(s)=\\alpha(s)\\sum_m \\frac{1}{m^{1-s}}\\eta(\\log m-\\log x)+O_{\\eta,\\sigma,A}(\\left|t\\right|-A)", block: false)#text(".")

#text("In the proof of Theorem 40, I think the last second formula should be")

#mi("\\displaystyle \\frac{\\xi}{\\xi}^{\\prime}(2+it)=\\frac{\\zeta^{\\prime}}{\\zeta}(2+it)-\\frac{1}{2}\\log 2\\pi+\\frac{1}{2}\\log t+\\frac{\\pi i}{4}+O(\\frac{1}{t})")

#text("for ")#mi("t\\geq 2")#text(", since")

#tao-math("\\displaystyle \\frac{\\Gamma^{\\prime}}{\\Gamma}(2+it)=\\mathrm{Log}(2+it)+O(\\frac{1}{t})=\\log t+\\frac{\\pi i}{2}+O(\\frac{1}{\\left|t\\right|})", block: false)

#text("for ")#mi("t\\geq 2")#text(".")

#text("Exercise 45: Should the first formula be")

#tao-math("\\displaystyle  \\sum_{n\\leq x}\\Lambda(n)=x-1-\\lim_{T\\to\\infty}\\sum_{\\rho:\\left|\\mathrm{Im}(\\rho)\\right|\\leq T}\\frac{x^\\rho}{\\rho}-\\sum_{n}\\frac{x^{-2n}}{-2n}+B^{\\prime}", block: false)#text("?")

#text("Exercise 49: Do we need the assumption that ")#mi("q")#text(" is prime? I can prove the case that ")#mi("q")#text(" is prime, but have no idea to prove the general cases.")

#text("In the last sentence before Remark 50, it’s better to define ")#mi("\\kappa=1")#text(" when ")#mi("\\chi(-1)=-1")#text(", it is consistent with the definition in Theorem 3. And in the text after Remark 50, so (51) formally yields")

#mi("\\displaystyle \\sum_{n}\\frac{\\chi(n)}{n^s}=\\frac{\\chi(-1)\\tau(\\chi)}{q}\\Gamma(1-s)\\sum_m \\frac{\\overline{\\chi}(m)}{(-2\\pi im /q)^{1-s}},")#linebreak()#text(" you forgot a ")#mi("\\Gamma(1-s)")#text(" factor.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-470221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2016")])]

#text("In exercise 10, it seems better to give the product for the entire function ")#mi("1/ \\Gamma (s)")#text(" – for any ")#mi("s \\in \\mathbb C")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-477029")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2017")])]

#text("In the second part of remark 30, it may be added that the characterization (up to scalar multiples) of the zeta function by its functional equation was first given (in 1921) by Hamburger.")

#emph[#text("[Updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e329bc2e27c78b84de3c31a01b9c21a38b4a572e094c88eb22c18810ff61a577-7cc1877ab26a5a0f20fe2fa37a3cb4b544d1c25a9e5745016cbfcbc7e61da5d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ion Simbotin")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-480188")[#strong[#text("Ion Simbotin")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2017")])]

#text("The table listing the zeros and poles of various functions (")#mi("\\zeta, \\xi, \\Gamma")#text(", etc) has a misprint on the penultimate row. Namely, ")#mi("\\Gamma((1-s)/2)")#text(" has poles at $\\latex s=1,3,5,\\ldots$ (rather than ")#mi("s=2,4,6,\\ldots")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Continuous approximations to arithmetic functions | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-488634")[#strong[#text("Continuous approximations to arithmetic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("[…] is a heuristic form of the Riemann-von Mangoldt explicit formula (see Exercise 45 of these notes for a rigorous version of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d39ed43e7d88b9b7465fa9cd1acecb80a5c1eeafddb50798f686945e9af8e144-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Javier Garcia Moreta")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-496189")[#strong[#text("Jose Javier Garcia Moreta")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("explicit formula for other arithmetical functions can be found in my paper :D here : ")#link("http://vixra.org/abs/1704.0146")[#text("http://vixra.org/abs/1704.0146")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-497686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#text("“One can view ")#mi("{\\Gamma}")#text(" as the inner product between the multiplicative character ")#mi("{t \\mapsto t^s}")#text(" and the additive character ")#mi("{t \\mapsto e^{-t}}")#text(" with respect to multiplicative Haar measure ")#mi("{\\frac{dt}{t}}")#text(". ”")

#text("What is the underlying topological group for which the mentioned Haar measure is defined? What does “multiplicative” mean?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-497690")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#mi("\\frac{dt}{t}")#text(" is Haar measure for the multiplicative group ")#mi("{\\bf R}^+ := \\{ t: t > 0 \\}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-497821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2018")])]

#text("I can never memorize/internalize the change of variable trick in the proof of Lemma 7. How on earth can one come up with such map that maps ")#mi("A;=(0,\\infty)\\times (0,\\infty)")#text(" to ")#mi("B:=(0,\\infty)\\times(0,1)")#text("?")

#text("Consider the inverse of the map you take (using different notations):")

#mi("\\displaystyle z = v+u, t = \\frac{u}{u+v}")

#text("It seems that this is related to some fractional linear transformation? Is there anything in complex analysis that would lead one naturally to the change of variables map used in the proof of Lemma 7?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-497838")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2018")])]

#text("The main thing is to introduce the ")#mi("u")#text(" variable ")#mi("u = s+t")#text("; it is not really relevant what the remaining variable ")#mi("v")#text(" is chosen to be, as the integral will simplify regardless, basically because the exponential weight ")#mi("e^{-s-t}")#text(" simplifies to ")#mi("e^{-u}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c04eafc15b455ca1d0eaa42bfba6828a3c9c3229eb91c9488bc7f36b9000a479-6a5253f0852e20b6d8fdca6bbe7f14174774342dc9572ba049acf440d7d31773.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helen")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-505373")[#strong[#text("Helen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2018")])]

#text("In Lemma 9, you write that it is easy to see that the limit is convergent. It is straightforward to show that the limit is convergent by showing that the product is convergent; is there a more direct way of seeing that the limit is convergent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-505543")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("I think using the product form of the expression in the limit is indeed the fastest way to show convergence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f3d1cd9ce4bdb8c6612eda632e89f24dbb1b64a6bbcc5dfaaab0a2af8b34d31-e00acffcdb83512a20cb51f8e53c822c1e3f89d33860a7fa698b44c120c7d778.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helen")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-505609")[#strong[#text("Helen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2018")])]

#text("You write in the proof of Euler’s reflection identity that one should use a contour “looping clockwise around the real axis”. Maybe I am missing something obvious, but since we have defined ")#mi("z^{s-1}")#text(" as ")#mi("\\exp((s-1)\\log_{[0,2\\pi)} (z),")#text(" will we not be going over the branch cut? Maybe I am misinterpreting what you wrote.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-505618")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2018")])]

#text("One uses a contour that loops around the ")#emph[#text("positive")]#text(" real axis, e.g. the clockwise semicircle from ")#mi("-\\varepsilon i")#text(" to ")#mi("+\\varepsilon i")#text(", together with the ray from ")#mi("+\\varepsilon i")#text(" to ")#mi("+\\varepsilon i + i \\infty")#text(" and the ray from $-\\varepsilon i + i \\infty$ to ")#mi("-\\varepsilon i")#text(" (cf. the “keyhole contours” that are often used in complex analysis).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c04eafc15b455ca1d0eaa42bfba6828a3c9c3229eb91c9488bc7f36b9000a479-6a5253f0852e20b6d8fdca6bbe7f14174774342dc9572ba049acf440d7d31773.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helen")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-505732")[#strong[#text("Helen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2018")])]

#text("I guess what troubles me is the fact that the contour does not seem to be closed, Do you close it off with a large semi-circle or something and then take some limiting procedure, concluding that the integral over semi-circle vanishes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-505788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2018")])]

#text("Yes (except that one uses almost a full circle rather than a semicircle, the contour is a “keyhole contour” ")#link("https://en.m.wikipedia.org/wiki/File:Keyhole_contour.svg")[#text("https://en.m.wikipedia.org/wiki/File:Keyhole_contour.svg")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-528003")[#strong[#text("254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2019")])]

#text("[…] Remark 18 As a corollary of Proposition 16, we see that the number of zeroes of in the region is for any . Once we establish the functional equation for , we will be able to match this upper bound with a comparable lower bound, and also set to zero; see Supplement 3. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-622255")[#strong[#text("246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("[…] The meromorphic continuation (iii) of the zeta function is initially surprising, but can be interpreted either as a manifestation of the extremely regular spacing of the natural numbers occurring in the sum (1), or as a consequence of various integral representations of (or slight modifications thereof). We will focus in this set of notes on a particular representation of as essentially the Mellin transform of the theta function that briefly appeared in previous notes, and the functional equation (iv) can then be viewed as a consequence of the modularity of that theta function. This in turn was established using the Poisson summation formula, so one can view the functional equation as ultimately being a manifestation of Poisson summation. (For a direct proof of the functional equation via Poisson summation, see these notes.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-637884")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2021")])]

#text("Typo in definition of sine/cosine in Theorem 1.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-637886")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2021")])]

#text("Typo underneath exercise 6, where you say “By repeating the proof of (31)”. Should be (1).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-637934")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2021")])]

#text("Typo underneath Exercise 15: “for ")#mi("s")#text(" in a sector of the form ")#mi("\\text{Arg}(z) 0")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-637937")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2021")])]

#text("Typo in Exercise 21: “[…]to the trapezoid rule when ")#mi("y  -2 \\}")#text(" with ")#mi("s \\neq -1")#text(", there exists a unique complex number ")#mi("\\zeta(s)")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/#comment-637942")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2021")])]

#text("In Exercise 31, it seems you forgot a ")#mi("<")#text(" between the ")#mi("x")#text(" and the ")#mi("0")#text(". Similarly in Exercise 33.")

#text("Right before Lemma 34, there's a typo in the phrase \"for any ")#mi("0 < \\sigma  0")#text("; we leave the details to the interested reader\".")

#emph[#text("[Corrected, thanks – T.]")]
]
