// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:35.169178+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Localisation and compactness properties of the Navier-Stokes global regularity problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Localisation and compactness properties of the Navier-Stokes global regularity problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 August 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")[#text("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the ")#link("http://arxiv.org")[#text("arXiv")]#text(" my paper “")#link("http://arxiv.org/abs/1108.1165")[#text("Localisation and compactness properties of the Navier-Stokes global regularity problem")]#text("“, submitted to ")#link("http://msp.berkeley.edu/apde")[#text("Analysis and PDE")]#text(". This paper concerns the ")#link("http://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_existence_and_smoothness")[#text("global regularity problem")]#text(" for the Navier-Stokes system of equations ")#metadata(none) <tao-7bfba6e0021f1fd1183d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_t u + (u \\cdot \\nabla) u = \\Delta u - \\nabla p + f")]]

#metadata(none) <tao-940861638261344eb267>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\nabla \\cdot u = 0")]]

#metadata(none) <tao-ac1b5c0961a7269b6a05>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u(0,\\cdot) = u_0")]]

#text("in three dimensions. Thus, we specify ")#emph[#text("initial data")]#text(" ")#mi("{(u_0,f,T)}")#text(", where ")#mi("{0 < T < \\infty}")#text(" is a time, ")#mi("{u_0: {\\bf R}^3 \\rightarrow {\\bf R}^3}")#text(" is the initial velocity field (which, in order to be compatible with ")#link(<tao-940861638261344eb267>)[#text("(2)")]#text(", ")#link(<tao-ac1b5c0961a7269b6a05>)[#text("(3)")]#text(", is required to be divergence-free), ")#mi("{f: [0,T] \\times {\\bf R}^3 \\rightarrow {\\bf R}^3}")#text(" is the forcing term, and then seek to extend this initial data to a solution ")#mi("{(u,p,u_0,f,T)}")#text(" with this data, where the velocity field ")#mi("{u: [0,T] \\times {\\bf R}^3 \\rightarrow {\\bf R}^3}")#text(" and pressure term ")#mi("{p: [0,T] \\times {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" are the unknown fields.")

#text("Roughly speaking, the ")#emph[#text("global regularity problem")]#text(" asserts that given every smooth set of initial data ")#mi("{(u_0,f,T)}")#text(", there exists a smooth solution ")#mi("{(u,p,u_0,f,T)}")#text(" to the Navier-Stokes equation with this data. However, this is not a good formulation of the problem because it does not exclude the possibility that one or more of the fields ")#mi("{u_0, f, u, p}")#text(" grows too fast at spatial infinity. This problem is evident even for the much simpler ")#emph[#text("heat equation")]

#tao-aligned(keep: true)[


#tao-math("\\partial_t u  & = \\Delta u", block: true)



#tao-math("u(0,\\cdot)  & = u_0.", block: true)
]

#text("As long as one has some mild conditions at infinity on the smooth initial data ")#mi("{u_0: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" (e.g. polynomial growth at spatial infinity), then one can solve this equation using the fundamental solution of the heat equation:")

#align(center)[#tao-fit-display[#tao-math("u(t,x) = \\frac{1}{(4\\pi t)^{3/2}} \\int_{{\\bf R}^3} u_0(y) e^{-\\left|x-y\\right|^2/4t}\\ dy.", block: true)]]

#text("If furthermore ")#mi("{u}")#text(" is a tempered distribution, one can use Fourier-analytic methods to show that this is the unique solution to the heat equation with this data. But once one allows sufficiently rapid growth at spatial infinity, existence and uniqueness can break down. Consider for instance the backwards heat kernel")

#align(center)[#tao-fit-display[#tao-math("u(t,x) = \\frac{1}{(4\\pi(T-t))^{3/2}} e^{\\left|x\\right|^2/(T-t)}", block: true)]]

#text("for some ")#mi("{T>0}")#text(", which is smooth (albeit exponentially growing) at time zero, and is a smooth solution to the heat equation for ")#mi("{0 \\leq t < T}")#text(", but develops a dramatic singularity at time ")#mi("{t=T}")#text(". A famous ")#link("http://www.mathnet.ru/php/archive.phtml?wshow=paper&jrnid=sm&paperid=6410&option_lang=eng")[#text("example of Tychonoff")]#text(" from 1935, based on a power series construction, also shows that uniqueness for the heat equation can also fail once growth conditions are removed. An explicit example of non-uniqueness for the heat equation is given by the contour integral")

#align(center)[#tao-fit-display[#mitex("u(t,x_1,x_2,x_3) = \\int_\\gamma \\exp(e^{\\pi i/4} x_1 z + e^{5\\pi i/8} z^{3/2} - itz^2)\\ dz")]]

#text("where ")#mi("{\\gamma}")#text(" is the ")#mi("{L}")#text("-shaped contour consisting of the positive real axis and the upper imaginary axis, with ")#mi("{z^{3/2}}")#text(" being interpreted with the standard branch (with cut on the negative axis). One can show by contour integration that this function solves the heat equation and is smooth (but rapidly growing at infinity), and vanishes for ")#mi("{t<0}")#text(", but is not identically zero for ")#mi("{t>0}")#text(".")

#text("Thus, in order to obtain a meaningful (and physically realistic) problem, one needs to impose some decay (or at least limited growth) hypotheses on the data ")#mi("{u_0,f}")#text(" and solution ")#mi("{u,p}")#text(" in addition to smoothness. For the data, one can impose a variety of such hypotheses, including the following:")

#list(
[#text("(Finite energy data) One has ")#tao-math("{\\left\\|u_0\\right\\|_{L^2_x({\\bf R}^3)} < \\infty}", block: false)#text(" and ")#tao-math("{\\left\\| f \\right\\|_{L^\\infty_t L^2_x([0,T] \\times {\\bf R}^3)} < \\infty}", block: false)#text(".")],
[#text("(")#mi("{H^1}")#text(" data) One has ")#tao-math("{\\left\\|u_0\\right\\|_{H^1_x({\\bf R}^3)} < \\infty}", block: false)#text(" and ")#tao-math("{\\left\\| f \\right\\|_{L^\\infty_t H^1_x([0,T] \\times {\\bf R}^3)} < \\infty}", block: false)#text(".")],
[#text("(Schwartz data) One has ")#tao-math("{\\sup_{x \\in {\\bf R}^3} \\left|\\left|x\\right|^m \\nabla_x^k u_0(x)\\right| < \\infty}", block: false)#text(" and ")#tao-math("{\\sup_{(t,x) \\in [0,T] \\times {\\bf R}^3} \\left|\\left|x\\right|^m \\nabla_x^k \\partial_t^l f(t,x)\\right| < \\infty}", block: false)#text(" for all ")#mi("{m,k,l \\geq 0}")#text(".")],
[#text("(Periodic data) There is some ")#mi("{0 < L < \\infty}")#text(" such that ")#mi("{u_0(x+Lk) = u_0(x)}")#text(" and ")#mi("{f(t,x+Lk) = f(t,x)}")#text(" for all ")#mi("{(t,x) \\in [0,T] \\times {\\bf R}^3}")#text(" and ")#mi("{k \\in {\\bf Z}^3}")#text(".")],
[#text("(Homogeneous data) ")#mi("{f=0}")#text(".")]
)

#text("Note that smoothness alone does not necessarily imply finite energy, ")#mi("{H^1}")#text(", or the Schwartz property. For instance, the (scalar) function ")#tao-math("{u(x) = \\exp( i \\left|x\\right|^{10} ) (1+\\left|x\\right|)^{-2}}", block: false)#text(" is smooth and finite energy, but not in ")#mi("{H^1}")#text(" or Schwartz. Periodicity is of course incompatible with finite energy, ")#mi("{H^1}")#text(", or the Schwartz property, except in the trivial case when the data is identically zero.")

#text("Similarly, one can impose conditions at spatial infinity on the solution, such as the following:")

#list(
[#text("(Finite energy solution) One has ")#tao-math("{\\left\\| u \\right\\|_{L^\\infty_t L^2_x([0,T] \\times {\\bf R}^3)} < \\infty}", block: false)#text(".")],
[#text("(")#mi("{H^1}")#text(" solution) One has ")#tao-math("{\\left\\| u \\right\\|_{L^\\infty_t H^1_x([0,T] \\times {\\bf R}^3)} < \\infty}", block: false)#text(" and ")#tao-math("{\\left\\| u \\right\\|_{L^2_t H^2_x([0,T] \\times {\\bf R}^3)} < \\infty}", block: false)#text(".")],
[#text("(Partially periodic solution) There is some ")#mi("{0 < L < \\infty}")#text(" such that ")#mi("{u(t,x+Lk) = u(t,x)}")#text(" for all ")#mi("{(t,x) \\in [0,T] \\times {\\bf R}^3}")#text(" and ")#mi("{k \\in {\\bf Z}^3}")#text(".")],
[#text("(Fully periodic solution) There is some ")#mi("{0 < L < \\infty}")#text(" such that ")#mi("{u(t,x+Lk) = u(t,x)}")#text(" and ")#mi("{p(t,x+Lk) = p(t,x)}")#text(" for all ")#mi("{(t,x) \\in [0,T] \\times {\\bf R}^3}")#text(" and ")#mi("{k \\in {\\bf Z}^3}")#text(".")]
)

#text("(The ")#mi("{L^2_t H^2_x}")#text(" component of the ")#mi("{H^1}")#text(" solution is for technical reasons, and should not be paid too much attention for this discussion.) Note that we do not consider the notion of a Schwartz solution; as we shall see shortly, this is too restrictive a concept of solution to the Navier-Stokes equation.")

#text("Finally, one can downgrade the regularity of the solution down from smoothness. There are many ways to do so; two such examples include")

#list(
[#text("(")#mi("{H^1}")#text(" mild solutions) The solution is not smooth, but is ")#mi("{H^1}")#text(" (in the preceding sense) and solves the equation ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(1)")]#text(" in the sense that the Duhamel formula")

#align(center)[#tao-fit-display[#mitex("u(t) = e^{t\\Delta} u_0 + \\int_0^t e^{(t-t^{\\prime})\\Delta} (-(u\\cdot\\nabla) u-\\nabla p+f)(t^{\\prime})\\ dt^{\\prime}")]]

#text("holds.")],
[#text("(Leray-Hopf weak solution) The solution ")#mi("{u}")#text(" is not smooth, but lies in ")#mi("{L^\\infty_t L^2_x \\cap L^2_t H^1_x}")#text(", solves ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(1)")]#text(" in the sense of distributions (after rewriting the system in divergence form), and obeys an energy inequality.")]
)

#text("Finally, one can ask for two types of global regularity results on the Navier-Stokes problem: a ")#emph[#text("qualitative regularity result")]#text(", in which one merely provides existence of a smooth solution without any explicit bounds on that solution, and a ")#emph[#text("quantitative regularity result")]#text(", which provides bounds on the solution in terms of the initial data, e.g. a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{L^\\infty_t H^1_x([0,T] \\times {\\bf R}^3)} \\leq F( \\left\\|u_0\\right\\|_{H^1_x({\\bf R}^3)} + \\left\\|f\\right\\|_{L^\\infty_t H^1_x([0,T] \\times {\\bf R}^3)}, T )", block: true)]]

#text("for some function ")#mi("{F: {\\bf R}^+ \\times {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(". One can make a further distinction between ")#emph[#text("local quantitative")]#text(" results, in which ")#mi("{F}")#text(" is allowed to depend on ")#mi("{T}")#text(", and ")#emph[#text("global quantitative")]#text(" results, in which there is no dependence on ")#mi("{T}")#text(" (the latter is only reasonable though in the homogeneous case, or if ")#mi("{f}")#text(" has some decay in time).")

#text("By combining these various hypotheses and conclusions, we see that one can write down quite a large number of slightly different variants of the global regularity problem. In the ")#link("http://claymath.org/millennium/Navier-Stokes_Equations/")[#text("official formulation of the regularity problem")]#text(" for the ")#link("http://www.claymath.org/millennium/")[#text("Clay Millennium prize")]#text(", a positive correct solution to either of the following two problems would be accepted for the prize:")

#list(
[#strong[#text("Conjecture 1.4")]#text(" (Qualitative regularity for homogeneous periodic data) If ")#mi("{(u_0,0,T)}")#text(" is periodic, smooth, and homogeneous, then there exists a smooth partially periodic solution ")#mi("{(u,p,u_0,0,T)}")#text(" with this data.")],
[#strong[#text("Conjecture 1.3")]#text(" (Qualitative regularity for homogeneous Schwartz data) If ")#mi("{(u_0,0,T)}")#text(" is Schwartz and homogeneous, then there exists a smooth finite energy solution ")#mi("{(u,p,u_0,0,T)}")#text(" with this data.")]
)

#text("(The numbering here corresponds to the numbering in the paper.)")

#text("Furthermore, a negative correct solution to either of the following two problems would also be accepted for the prize:")

#list(
[#strong[#text("Conjecture 1.6")]#text(" (Qualitative regularity for periodic data) If ")#mi("{(u_0,f,T)}")#text(" is periodic and smooth, then there exists a smooth partially periodic solution ")#mi("{(u,p,u_0,f,T)}")#text(" with this data.")],
[#strong[#text("Conjecture 1.5")]#text(" (Qualitative regularity for Schwartz data) If ")#mi("{(u_0,f,T)}")#text(" is Schwartz, then there exists a smooth finite energy solution ")#mi("{(u,p,u_0,f,T)}")#text(" with this data.")]
)

#text("I am ")#strong[#text("not")]#text(" announcing any major progress on these conjectures here. What my paper does study, though, is the question of whether the answer to these conjectures is somehow sensitive to the choice of formulation. For instance:")

#enum(start: 1, 
[#text("Note in the periodic formulations of the Clay prize problem that the solution is only required to be partially periodic, rather than fully periodic; thus the pressure has no periodicity hypothesis. One can ask the extent to which the above problems change if one also requires pressure periodicity.")],
[#text("In another direction, one can ask the extent to which quantitative formulations of the Navier-Stokes problem are stronger than their qualitative counterparts; in particular, whether it is possible that each choice of initial data in a certain class leads to a smooth solution, but with no uniform bound on that solution in terms of various natural norms of the data.")],
[#text("Finally, one can ask the extent to which the conjecture depends on the category of data. For instance, could it be that global regularity is true for smooth periodic data but false for Schwartz data? True for Schwartz data but false for smooth ")#mi("{H^1}")#text(" data? And so forth.")]
)

#text("One motivation for the final question (which was posed to me by my colleague, ")#link("http://www.math.ucla.edu/~bertozzi/")[#text("Andrea Bertozzi")]#text(") is that the Schwartz property on the initial data ")#mi("{u_0}")#text(" tends to be instantly destroyed by the Navier-Stokes flow. This can be seen by introducing the ")#link("http://en.wikipedia.org/wiki/Vorticity")[#text("vorticity")]#text(" ")#mi("{\\omega := \\nabla \\times u}")#text(". If ")#mi("{u(t)}")#text(" is Schwartz, then from Stokes’ theorem we necessarily have vanishing of certain moments of the vorticity, for instance:")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^3} \\omega_1 (x_2^2-x_3^2)\\ dx = 0.")]]

#text("On the other hand, some integration by parts using ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(1)")]#text(" reveals that such moments are usually ")#emph[#text("not")]#text(" preserved by the flow; for instance, one has the law")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\int_{{\\bf R}^3} \\omega_1(t,x) (x_2^2-x_3^2)\\ dx = 4\\int_{{\\bf R}^3} u_2(t,x) u_3(t,x)\\ dx,")]]

#text("and one can easily concoct examples for which the right-hand side is non-zero at time zero. This suggests that the Schwartz class may be unnecessarily restrictive for Conjecture 1.3 or Conjecture 1.5.")

#text("My paper arose out of an attempt to address these three questions, and ended up obtaining partial results in all three directions. Roughly speaking, the results that address these three questions are as follows:")

#enum(start: 1, 
[#text("(Homogenisation) If one only assumes partial periodicity instead of full periodicity, then the forcing term ")#mi("{f}")#text(" becomes irrelevant. In particular, Conjecture 1.4 and Conjecture 1.6 are equivalent.")],
[#text("(Concentration compactness) In the ")#mi("{H^1}")#text(" category (both periodic and nonperiodic, homogeneous or nonhomogeneous), the qualitative and quantitative formulations of the Navier-Stokes global regularity problem are essentially equivalent.")],
[#text("(Localisation) The (inhomogeneous) Navier-Stokes problems in the Schwartz, smooth ")#mi("{H^1}")#text(", and finite energy categories are essentially equivalent to each other, and are also implied by the (fully) periodic version of these problems.")]
)

#text("The first two of these families of results are relatively routine, drawing on existing methods in the literature; the localisation results though are somewhat more novel, and introduce some new local energy and local enstrophy estimates which may be of independent interest.")

#text("Broadly speaking, the moral to draw from these results is that the precise formulation of the Navier-Stokes equation global regularity problem is only of secondary importance; modulo a number of caveats and technicalities, the various formulations are close to being equivalent, and a breakthrough on any one of the formulations is likely to lead (either directly or indirectly) to a comparable breakthrough on any of the others.")

#text("This is only a caricature of the actual implications, though. Below is the diagram from the paper indicating the various formulations of the Navier-Stokes equations, and the known implications between them:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/implications.png")[#image("../assets/4f2d7b5996fa480a53785284ade7665b13f9b72db68bbd3ce39866e8df1f2091-2f06bc4a993397847912ca873cf461ea72db2537c8712e5ac036c942b8eb4759.png", width: 90%)]

#text("The above three streams of results are discussed in more detail below the fold.")

#metadata(none) <tao-cba50abe6841646f9369>

#heading(level: 1)[#strong[#text(" — 1. Homogenisation — ")]]

#text("We first discuss the homogenisation results. Let us first give the fully periodic version of the periodic regularity conjectures:")

#list(
[#strong[#text("Conjecture 1.13")]#text(" (Qualitative fully periodic regularity for periodic data) If ")#mi("{(u_0,f,T)}")#text(" is periodic and smooth, then there exists a smooth fully periodic solution ")#mi("{(u,p,u_0,f,T)}")#text(" with this data.")],
[#strong[#text("Conjecture 7.5")]#text(" (Qualitative fully periodic regularity for homogeneous periodic data) If ")#mi("{(u_0,0,T)}")#text(" is periodic, homogeneous, and smooth, then there exists a smooth fully periodic solution ")#mi("{(u,p,u_0,0,T)}")#text(" with this data.")]
)

#text("The implications are then that Conjecture 1.4, Conjecture 1.6, and Conjecture 7.5 are equivalent, with Conjecture 1.13 implying any of the previous three conjectures.")

#text("The equivalence of Conjecture 1.4 and Conjecture 7.5 is fairly well known (it is explicitly made for instance in ")#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/")[#text("my previous paper")]#text("). The only remaining nontrivial implication is the deduction of Conjecture 1.6 from Conjecture 1.4, i.e. the deduction of global regularity for the inhomogeneous periodic problem from global regularity for the homogeneous periodic problem.")

#text("The deduction relies on the trick of using an asymptotic version of the ")#emph[#text("Galilean symmetry")]#text(" ")#mi("{(u,p,u_0,f,T) \\mapsto (\\tilde u,\\tilde p,\\tilde u_0, \\tilde f, T)}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("\\tilde u(t,x)  & := u(t,x-\\int_0^t v(s)\\ ds) + v(t)", block: true)



#tao-math("\\tilde p(t,x)  & := p(t,x-\\int_0^t v(s)\\ ds) - x \\cdot v^{\\prime}(t)", block: true)



#tao-math("\\tilde u_0(x)  & := u_0(x) + v(0)", block: true)



#tao-math("\\tilde f(t,x)  & := f(t,x-\\int_0^t v(s)\\ ds),", block: true)
]

#text("and ")#mi("{v: [0,T]\\rightarrow {\\bf R}^3}")#text(" is an arbitrary smooth velocity function. One can verify that this symmetry preserves the Navier-Stokes system of equations. One can apply this symmetry to some rapidly growing velocity, say ")#mi("{v = 2wt}")#text(" for some large vector ")#mi("{w \\in {\\bf R}^3}")#text(". Then the transformation does not change the initial data ")#mi("{u_0}")#text(", but introduces a rapid time oscillation to the forcing term ")#mi("{f}")#text(", replacing it by ")#mi("{\\tilde f(t,x) := f(t,x-wt^2)}")#text(". As one sends ")#mi("{w}")#text(" to infinity in a suitable “irrational” direction, ")#mi("{\\tilde f}")#text(" converges weakly to a function that is constant in space (this is an application of the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Lebesgue_lemma")[#text("Riemann-Lebesgue lemma")]#text("). It turns out that the Navier-Stokes system of equations has enough smoothing (or compactness) properties that we may then (for ")#mi("{w}")#text(" large and irrational enough) approximate ")#mi("{f}")#text(" effectively as if it ")#emph[#text("was")]#text(" a constant. Applying a further Galilean-type symmetry")

#tao-aligned(keep: true)[


#tao-math("\\tilde u(t,x)  & := u(t,x-\\int_0^t v(s)\\ ds) + v(t)", block: true)



#tao-math("\\tilde p(t,x)  & := p(t,x-\\int_0^t v(s)\\ ds)", block: true)



#tao-math("\\tilde u_0(x)  & := u_0(x) + v(0)", block: true)



#tao-math("\\tilde f(t,x)  & := f(t,x-\\int_0^t v(s)\\ ds) + v^{\\prime}(t),", block: true)
]

#text("for a suitable ")#mi("{v}")#text(" (not the same as the previous ")#mi("{v}")#text("), we can then set ")#mi("{\\tilde f}")#text(" to be identically zero, without adjusting the initial data ")#mi("{u_0}")#text(". Thus, we have effectively transformed the inhomogeneous problem to a homogeneous one, which gives the deduction of Conjecture 1.6 from Conjecture 1.4.")

#text("Note that at one stage we subtracted a linear term ")#mi("{x \\cdot v^{\\prime}(t)}")#text(" from the pressure. This would destroy any periodicity properties the pressure had, and so this trick does not work in the fully periodic setting.")

#text("One interpretation of this result is that the partially periodic setting is not the right setting to discuss the inhomogeneous problem. (For the homogeneous problem, it is not difficult to use Galilean transformations to show that the global regularity problem for the partially periodic and fully periodic problem are equivalent.) Indeed, the Galilean invariance reveals a breakdown of ")#emph[#text("uniqueness")]#text(" for the Navier-Stokes flow in the partially periodic setting. Once one fixes the pressure to be periodic also, it is possible (by a variety of means, e.g. energy methods) to recover uniqueness for the flow (modulo the rather trivial caveat that the Navier-Stokes equations only determine the pressure ")#mi("{p}")#text(" up to a time-dependent constant, which does not have any net impact on ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(1)")]#text(" since ")#mi("{p}")#text(" only appears through its gradient).")

#heading(level: 1)[#strong[#text(" — 2. Concentration compactness — ")]]

#text("The compactness results in the paper relate qualitative and quantitative versions of the Navier-Stokes regularity problem. This portion of the argument is based on ")#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/")[#text("my previous paper")]#text(" in this topic, which dealt with the periodic homogeneous case; in the non-periodic setting it also uses the concentration-compactness method as developed ")#link("http://www.ams.org/mathscinet-getitem?mr=1705001")[#text("by Bahouri-Gerard")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1632171")[#text("by Gerard")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=1871299")[#text("by Gallagher")]#text(".")

#text("In the periodic homogeneous setting, the results in my previous paper show the equivalence of Conjecture 1.4 (and hence Conjectures 1.6 and 7.5) with the following conjectures:")

#list(
[#strong[#text("Conjecture 7.4")]#text(" (Global existence of ")#mi("{H^1}")#text(" mild solutions for homogeneous periodic data) If ")#mi("{(u_0,0,T)}")#text(" is periodic, homogeneous, and ")#mi("{H^1}")#text(", then there exists a periodic ")#mi("{H^1}")#text(" mild solution ")#mi("{(u,p,u_0,0,T)}")#text(" with this data.")],
[#strong[#text("Conjecture 7.2")]#text(" (Local quantitative regularity for homogeneous periodic ")#mi("{H^1}")#text(" data) If ")#mi("{(u,p,u_0,0,T)}")#text(" is a periodic homogeneous smooth solution, then one can bound ")#tao-math("{\\left\\|u\\right\\|_{L^\\infty_t H^1_x}}", block: false)#text(" by a function of ")#tao-math("{\\left\\|u_0\\right\\|_{H^1_x}}", block: false)#text(" and ")#mi("{T}")#text(".")],
[#strong[#text("Conjecture 7.3")]#text(" (Global quantitative regularity for homogeneous periodic ")#mi("{H^1}")#text(" data) If ")#mi("{(u,p,u_0,0,T)}")#text(" is a periodic homogeneous smooth solution, then one can bound ")#tao-math("{\\left\\|u\\right\\|_{L^\\infty_t H^1_x}}", block: false)#text(" by a function of ")#tao-math("{\\left\\|u_0\\right\\|_{H^1_x}}", block: false)#text(".")]
)

#text("The equivalences were largely based on a compactness property of the periodic Navier-Stokes flow (which was inherited by a corresponding compactness property of the periodic heat equation), in that for short times, the flow map mapped weakly convergent data in ")#mi("{H^1}")#text(" to strongly convergent solutions, and in particular maps closed balls in ")#mi("{H^1}")#text(" (which are weakly compact) to compact subsets; because continuous functions on compact sets are bounded, we can then convert qualitative estimates to quantitative ones. The global form of quantitative regularity was obtained by using the fact (from energy estimates) that the energy dissipation (which is essentially the ")#mi("{H^1}")#text(" norm of the solution ")#mi("{u}")#text(") must eventually become small.")

#text("It turns out that the same method partially applies in the inhomogeneous setting (after stating the conjectures properly, see Conjectures 1.14 and 1.15 in the text); we will not detail this here. Note that the inhomogeneous equation can add energy to the system, as well as dissipate it out, and so we do not have the equivalence between local and global quantitative estimates in this setting.")

#text("The method also works in the homogeneous non-periodic setting (with the right formulations of the conjectures, which are Conjectures 1.9, 1.17, 1.18, 1.19 in the text), but with the key additional difficulty that the Navier-Stokes flow is no longer compact, but merely ")#emph[#text("concentration-compact")]#text(", due to the non-compact translation symmetry that is available for the space ")#mi("{H^1_x({\\bf R}^3)}")#text(". (Concentration compactness is discussed in ")#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/")[#text("previous")]#text(" blog posts.) One then has to deal with sequences of data that are not strongly convergent, but are essentially the superposition of a number of ")#emph[#text("profiles")]#text(" that are being translated off to infinity in different directions. However, the theory for dealing with this is well-developed; in particular, the ")#link("http://www.ams.org/mathscinet-getitem?mr=1871299")[#text("paper of Gallagher")]#text(" already treats this sort of profile decomposition for Navier-Stokes in the critical regularity regime, which is more difficult than the subcritical regularity regime considered here. As such, we were able to use standard techniques to obtain the equivalences here. The main point here is that if one superimposes two profiles that are translated to be sufficiently far from each other, then the nonlinear interactions between the two profiles are weak enough that one can use perturbative techniques to obtain an approximate principle of superposition; the evolution of the superimposed profiles is essentially just the superposition of the individual profiles.")

#heading(level: 1)[#strong[#text(" — 3. Localisation — ")]]

#text("The most novel arguments in the paper concern the the localisation results, which connect the periodic, Schwartz, smooth finite energy, and smooth ")#mi("{H^1}")#text(" categories to each other. Before stating the results precisely, let us consider a simpler (but still unsolved) situation, namely that of the ")#emph[#text("supercritical nonlinear wave equation")]#text(" ")#metadata(none) <tao-7ade893d8bd880ac6133>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("- \\partial_{tt} u + c^2 \\Delta u = u^7,")]]

#text("for some scalar field ")#mi("{u: [0,T] \\times {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" with a given smooth initial position ")#mi("{u(0,x) = u_0(x)}")#text(" and (for simplicity) zero initial velocity ")#mi("{\\partial_t u(0,x) = 0}")#text(", and where ")#mi("{c>0}")#text(" is a fixed constant (the speed of light). One can phrase the global regularity problem in this setting for periodic smooth ")#mi("{u_0}")#text(", Schwartz ")#mi("{u_0}")#text(", smooth finite energy ")#mi("{u_0}")#text(" (where the energy is now the ")#mi("{H^1_x({\\bf R}^3)}")#text(" norm rather than the ")#mi("{L^2_x({\\bf R}^3)}")#text(" norm), and so forth. But for this equation, all formulations of the problem are logically equivalent, thanks to the ")#emph[#text("finite speed of propagation")]#text(" property. Among other things, this property asserts that if one has two solutions ")#mi("{u, \\tilde u}")#text(" to the equation ")#link(<tao-7ade893d8bd880ac6133>)[#text("(4)")]#text(" that initially agree on a ball ")#mi("{B(x_0,R)}")#text(", then for subsequent times ")#mi("{t>0}")#text(", the solutions will continue to agree on a slightly smaller ball ")#mi("{B(x_0,R-ct)}")#text(" (of course, this statement becomes vacuous once ")#mi("{t}")#text(" is large enough). This property allows us, for instance, to deduce global regularity for arbitrary smooth data (of unlimited growth) from, say, the Schwartz data case. Indeed, to obtain a solution up to time ")#mi("{T}")#text(" for smooth data ")#mi("{u_0}")#text(", one could cover the domain ")#mi("{{\\bf R}^3}")#text(" by balls ")#mi("{B(x_i,T)}")#text(" of radius ")#mi("{T}")#text(", then for each such ball ")#mi("{B(x_i,T)}")#text(", smoothly truncate the data ")#mi("{u_0}")#text(" to the ball ")#mi("{B(x_i,3T)}")#text(" in such a way that it still agreed with ")#mi("{u_0}")#text(" on ")#mi("{B(x_i,2T)}")#text(". This truncated data is Schwartz, and so by hypothesis can be extended to a smooth solution up to time ")#mi("{[0,T] \\times B(x_i,T)}")#text("; from finite speed of propagation we see that these partially defined solutions agree with each other on their common domain of definition, and can thus be glued together to form a global solution for the original data. The same sort of argument (combined with the trick of embedding a ball such as ")#mi("{B(x_i,T)}")#text(" into a sufficiently large torus) lets one deduce the non-periodic global regularity conjecture for ")#link(<tao-7ade893d8bd880ac6133>)[#text("(4)")]#text(" from the periodic one.")

#text("The finite speed of propagation property for ")#link(<tao-7ade893d8bd880ac6133>)[#text("(4)")]#text(" is proven by energy estimates; one basically computes the energy at time ")#mi("{t}")#text(" on the ball ")#mi("{B(x_0,R-ct)}")#text(" and shows via integration by parts that this local energy is non-increasing in time.")

#text("The Navier-Stokes equation ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(1)")]#text(" unfortunately does not enjoy finite speed of propagation. However, due to the transport term ")#mi("{(u \\cdot \\nabla)u}")#text(" in ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(1)")]#text(", it is reasonable to expect that the solution propagates at velocity ")#mi("{u}")#text(" (this is of course consistent with the physical interpretation of ")#mi("{u}")#text(" as the velocity field, though with the caveat that ")#mi("{u}")#text(" is actually the particle velocity rather than the group velocity). As such, if one had an ")#emph[#text("a priori")]#text(" bound on the ")#mi("{L^1_t L^\\infty_x}")#text(" norm of ")#mi("{u}")#text(", this would suggest that solutions to the Navier-Stokes equation only propagate themselves by a bounded distance. This would, heuristically at least, allow one to repeat the above types of arguments to equate the various forms of the Navier-Stokes conjecture.")

#text("It turns out, somewhat remarkably, that an ")#emph[#text("a priori")]#text(" bound on the norm ")#mi("{L^1_t L^\\infty_x}")#text(" of ")#mi("{u}")#text(" is indeed available. This does not resolve the main difficulty in the global regularity problem – the lack of a controlled coercive quantity that is either subcritical or critical, as discussed ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("in this post")]#text(" – because this norm is supercritical. Actually, one can guess at the existence of such a bound by using the amplitude-frequency heuristics, ")#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/")[#text("discussed in this post")]#text(". If the Navier-Stokes solution ")#mi("{u}")#text(" has an amplitude ")#mi("{A}")#text(" and a frequency ")#mi("{N}")#text(" for a period of time ")#mi("{\\tau}")#text(" over a volume ")#mi("{V}")#text(" of space, then the energy dissipation estimate")

#align(center)[#tao-fit-display[#tao-math("\\int_0^T \\int_{{\\bf R}^3} \\left|\\nabla u(t,x)\\right|^2\\ dx \\leq \\int_{{\\bf R}^3} \\frac{1}{2} \\left|u_0(t,x)\\right|^2\\ dx", block: true)]]

#text("(setting ")#mi("{f=0}")#text(" for simplicity) suggests that")

#align(center)[#tao-fit-display[#mitex("\\tau N^2 A^2 V \\lesssim 1,")]]

#text("while the uncertainty principle (discussed ")#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("in this post")]#text(") suggests that ")#mi("{V \\gtrsim N^{-3}}")#text(". Finally, the linear term ")#mi("{\\Delta u}")#text(" and nonlinear term ")#mi("{(u \\cdot \\nabla) u}")#text(" have heuristic magnitudes about ")#mi("{N^2 A}")#text(" and ")#mi("{A^2 N}")#text(" respectively, so nonlinear-dominant behaviour should only occur when ")#mi("{A \\gtrsim N}")#text(". Putting all this together, one soon calculates heuristically that")

#align(center)[#tao-fit-display[#mitex("\\tau A \\lesssim 1,")]]

#text("which then predicts the ")#mi("{L^1_t L^\\infty_x}")#text(" bound. It turns out that one can make this argument rigorous by a routine application of Littlewood-Paley theory.")

#text("Even with the rigorous bound on ")#tao-math("{\\left\\|u\\right\\|_{L^1_t L^\\infty_x}}", block: false)#text(", though, there is still work to do to make the localisation results rigorous. The main technical tool used in this paper is a localisation result for the ")#link("http://en.wikipedia.org/wiki/Enstrophy")[#text("enstrophy")]

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{{\\bf R}^3} \\left|\\omega(t,x)\\right|^2\\ dx.", block: true)]]

#text("The precise local enstrophy estimate we derive is technical, but roughly speaking, this result asserts that if the enstrophy is initially small on some ball ")#mi("{B(x_0,R)}")#text(", then it will remain small on the ball ")#mi("{B(x_0,R-O(1))}")#text(". It is proven somewhat similarly to finite speed of propagation for wave equations, in that one computes the local enstrophy adapted to a ball ")#mi("{B(x_0,R(t))}")#text(" of shrinking radius and tries to keep this enstrophy from blowing up. Whereas ")#mi("{R(t)}")#text(" was previously shrinking at a constant speed ")#mi("{c}")#text(", though, now one needs to shrink the radius at a speed proportional to ")#tao-math("{\\left\\|u(t)\\right\\|_{L^\\infty_x}}", block: false)#text(".")

#text("A key difficulty though arises from non-local effects. If one takes the curl of ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(1)")]#text(" one obtains the ")#emph[#text("vorticity equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t \\omega + (u \\cdot \\nabla) \\omega = (\\omega \\cdot \\nabla) u + \\nabla \\times f.")]]

#text("The problem is with the nonlinear term ")#mi("{(\\omega \\cdot \\nabla) u}")#text(". Using the divergence-free nature of ")#mi("{u}")#text(", one can solve for ")#mi("{u}")#text(" in terms of ")#mi("{\\omega}")#text(" via the ")#emph[#text("Biot-Savart law")]

#align(center)[#tao-fit-display[#mitex("u = \\Delta^{-1} \\nabla \\times \\omega.")]]

#text("Unfortunately this law is non-local; the value of ")#mi("{u}")#text(" at a given point ")#mi("{x}")#text(" can be influenced by the vorticity at quite distant parts of space. In particular, the velocity field ")#mi("{u}")#text(" inside the ball ")#mi("{B(x_0,R(t))}")#text(" is influenced by the vorticity outside of ")#mi("{B(x_0,R(t))}")#text(", which will not be controlled by local enstrophy. One can still control this influence using other expressions, such as the total energy, but these are supercritical quantities and if one relies on them too heavily, then it will be impossible to keep the local enstrophy under control.")

#text("To resolve this, one has to perform some delicate harmonic analysis (in particular, a Whitney decomposition of the ball ")#mi("{B(x_0,R(t))}")#text(", and local elliptic regularity), and to carefully choose the right cutoffs to define local enstrophy properly; it turns out that one can (barely) reduce the non-local effects mentioned earlier to the point where they can actually be controlled satisfactorily by the quantities one has to play with (namely, local enstrophy and the total energy).")

#text("Using the local enstrophy inequality, one can deduce global regularity for Schwartz or smooth ")#mi("{H^1}")#text(" data from the periodic global well-posedness result in ")#mi("{H^1}")#text(". The idea is to locate a large ball ")#mi("{B(0,R)}")#text(" outside of which the data has small enstrophy; using the local enstrophy inequality, combined with standard partial regularity methods, this keeps the solution uniformly smooth (spatially, at least) outside of a slightly larger ball, say ")#mi("{B(0,2R)}")#text(". One can then truncate this solution to be compactly supported in, say, ")#mi("{B(0,3R)}")#text(", at the cost of introducing a forcing term to compensate for the error terms introduced by the truncation. One can then embed the resulting object into a sufficiently large torus to deduce the smooth ")#mi("{H^1}")#text(" regularity problem from the periodic theory. A related argument (using weak compactness, as in the construction of Leray-Hopf weak solutions) almost allows one to construct global smooth solutions from finite energy data once one has smooth solutions from finite enstrophy data.")

#text("In both of these results, though, there is an annoying technical quirk that prevents the results from being stated as cleanly as one might initially hope, which is that the partial regularity methods alluded to earlier give plenty of regularity in ")#emph[#text("space")]#text(" in regions of small enstrophy, but very little regularity in ")#emph[#text("time")]#text(". This seems to be an inherent feature of the Navier-Stokes problem: if a singularity or near-singularity occurs at one point ")#mi("{x_0}")#text(" in time, then this instantaneously propagates (via the incompressibility of the fluid) to create discontinuities in time (but not in space) for the pressure at points ")#mi("{x}")#text(" very far from ")#mi("{x_0}")#text(". (Think of how, for instance, a heart beat can cause instantaneous change in blood pressure throughout the body, or how a collision in ")#link("http://en.wikipedia.org/wiki/Newton%27s_cradle")[#text("Newton’s cradle")]#text(" instantaneously creates an effect at the other end of the cradle.) This effect prevents one from completely localising the effect of a singularity to a bounded region of space, and causes some unpleasant technicalities to be introduced into the various implications one can prove by this method. For instance, the solutions ")#mi("{u}")#text(" we construct from smooth finite energy data are not completely smooth; they are smooth for all positive times (thanks to parabolic regularising effects) and are ")#mi("{C^1_t C^\\infty_x}")#text(" in a neighbourhood of the initial time ")#mi("{t=0}")#text(", but I was unable to get more regularity in time beyond ")#mi("{C^1}")#text(".")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8837af00930de74d9f00080b1632feb9d01c80311732f1102da9b3c590d26cac-dda99ae828de759f1685e0a4dfbf1ed47eb9d7b45733b2997ced900e1d90d03b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-63766")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2011")])]

#text("missed some word in the first sentence.:) ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-63812")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2011")])]

#text("Hi Terry,")

#text("In the first sentence of point 3.localisation there is a double “the”.")

#text("Best,")

#text("Marco")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8442ab05981b5f2944ef3387ce95faae79fbbcab0252627380eb6bfff76e97bd-386a3fdbcc0a12b60077e9dd23e718db90aed0b2988d3cbcebaf044b057408f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Coulter")]], [#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-64364")[#strong[#text("Robert Coulter")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2011")])]

#text("We have seen attempts at creating a “pseudo” pressure grad term that is actually the sum of the pressure grad and a “hidden” external force. Perhaps it would have been better to have put limits on the external supply of energy rather than the force which has turned out to be awkward to bind. For example, any point cannot exceed a predefined external energy extraction rate per unit volume (power draw density). This would be coupled with a total external energy supply limit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/829adc5d6c70d666e6c2d4f173d718b466b975df93e93fce7726ffecd07988f6-46a57f79849ef5ecae11aeeeec4dfc1dd352ec5fcefe552ee4d0b7219da48e10.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vydonhu")]], [#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-64410")[#strong[#text("vydonhu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2011")])]

#text("Thank Terry!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A correction to “Localisation and compactness properties of the Navier-Stokes global regularity problem” « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-64423")[#strong[#text("A correction to “Localisation and compactness properties of the Navier-Stokes global regularity problem” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2011")])]

#text("[…] and compactness properties of the Navier-Stokes global regularity problem“, discussed in this previous blog post. As it turns out, I was somewhat impatient to finalise the paper and move on to other things, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-66062")[#strong[#text("W.EthanEagle (@EthanEagle)")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2011")]

#text("Hi Terry,")

#text("I have very much enjoyed your posts on the N-S equations. I have been thinking about these ‘annoying technical quirks’ of the NS equations. As a fluid physicist, it is at times deeply unsettling that I tacitly allow for effects to propagate instantaneously in the formulations as written and analyzed. I wanted to see if you (or others) worry about the non-physicality of these mathematical representations of fluids, and whether non-regularity could simply be an inevitable result of this physical contradiction.")

#text("This problem seems to arise when using the kinematic approximation of the Biot-Savart (valid only for a steady flow) in the dynamic NS equations for an unsteady process. I see more complexity being needed in the definition of vorticity in these flows. e.g. replacing Biot with something like: ")#link("http://en.wikipedia.org/wiki/Jefimenko%27s_equations")[#text("http://en.wikipedia.org/wiki/Jefimenko%27s_equations")]

#text("This would be akin to how E-M fields were proven to change each other in time and space (Maxwell’s original 1861 proof was in terms of ‘molecular vorticies’!) I believe accurately describing the mechanism of local flow organization (in space and time) via the vorticity could be key to unlocking this process.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-66112")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2011")])]

#text("Well, just about any useful mathematical model makes nonphysical assumptions – for instance, fluids are almost always modeled by a continuum, when in reality they are composed of a huge number of interacting particles. But if the model is robust enough, one can still expect it to give an accurate prediction of reality, even if at an ontological level it is quite distinct.")

#text("With regard to the instantaneous propagation of the pressure, one could use the compressible Navier-Stokes equation instead of the incompressible one, which would presumably be a more faithful model, and one without the instantaneous pressure issue. But in the incompressible limit I believe that it is expected that solutions of the former equation should converge to that of the latter (assuming, of course, that solutions to the latter are regular). There is quite a bit of literature on these topics; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1697038")[#text("this paper")]#text(" of Desjardins, Grenier, Lions, and Masmoudi.")

#text("My feeling though is that this non-locality of pressure, while technically annoying, is not the main factor in determining the regularity, stability, or validity of the Navier-Stokes flow. The nonlocal aspects of the Biot-Savart law primarily affect the low frequency (i.e. coarse scale) components of the flow, whereas all the interesting nonlinear and turbulent behaviour is occuring at fine scales. Of course, in this highly nonlinear equation the coarse scales and fine scales are not completely decoupled, and so the non-locality of the Biot-Savart law does have some impact on the fine-scale dynamics, but it is indirect and I would be surprised if it ends up playing a decisive role in the regularity theory (except at the initial time t=0, where as noted in the post, slowly decaying fine-scale behaviour in the velocity can cause instantaneous loss of time smoothness for the pressure).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54986f61a7c8b8f33f476385c14d92ba7ecf10d38374bcdd44628ec7c53ce7cf-9b277bf0a54097fa9700b16ebe736dba0982ffbd74f26134c309049475a0b703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rob")]], [#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-69419")[#strong[#text("rob")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2011")])]

#text("Think EthanEagle may have a point, though I feel a bit like an acolyte commenting to the masters.")

#text("While I am certainly nowhere near of your level in mathematics, could we not posit that the mathematical model need not be treated as a per se continuum or at the level of abstraction that it is. Based on the 2-d NS solution it would seem that the pressure terms are the problem.")

#text("Just as a thought model suppose we remove the concept of pressure and treat the fluid mass as a bounded variable step size n dimensional matrix populated with point sources (containing all the variables with which a molecule would be endowed), with n degrees of freedom and thermally defined mean free path step sizes.")

#text("Introduce a planer heat source and planer cold sink on either side of the fluid mass and one would simultaneously have an expansion wave propagating through the medium from the planar heat source, an increase in the mean free path of the area surrounding the heat source, and a decrease in the mean free path of the area surrounding the cold sink. This would introduce a density gradient from one side of the mass to the other. The random motion of the molecules within the mass would engender a momentum flux in the sparse direction. If this were occurring with gravity the expansion wave would propagate across the upper portion of the mass and the momentum flux from dense to sparse would propagate along the lower portion, i.e. a natural convective loop. The steeper the gradient the stronger the flow except in the region where the expansion and momentum force interact and counterbalance each other in the middle of the counter rotating flow which would also be the region of minimum bulk velocity and maximum turbulence provided the walls of the “container” did not have physical properties.")

#text("With this thought model it is a natural extension that turbulent regions are a function of the presence of introduced local density imbalances combined with energy conditions under which the directionally chaotic energy of the molecules expresses itself in structured turbulent motion simply because the energy of the flow near the source of turbulence is insufficient to apparently suppress the random motion (except at mach the random motion would never be suppressed) but instead “interacts” with it imparting a degree of local structure to the essentially chaotic motion. This thought model would satisfy the no-slip condition and the formation of turbulent boundary layers near physical objects.")

#text("Simplified the model would parse the flow into uni-directional and omni-directional momentum flux components based on local and global density and energy conditions. From the continuum perspective this would not be dissimilar to the pressure-velocity relationship, i.e. when pressure is at a maximum omni-directional flux is at a maximum and when velocity is at a maximum unidirectional flux is at a maximum.")

#text("I have been working on ambient flows (mainly wind) for the last 6 years and the pressure conceptual model is particularly problematic in accurately explaining or predicting the dynamics of these types of flows under certain conditions in the absence of a large body of empirical data.")

#text("It may be worth noting that the conceptual framework of incompressible vs. compressible flows comes from late 19th and early 20th century aerodynamics and forced flow environments such as wind tunnels, planes, or pipes, i.e. either driving a fluid through or at a physical object or driving a physical object through a fluid. It was convenient when analyzing those types of flows (which are most of the flows we need to analyze) to deal with subsonic flows as incompressible. It makes sense as any “compressible” effects are negligible compared to the energy contained in the forced flow except in the boundary layer where, notably, turbulence develops.")

#text("Perhaps the solution to NS may be to reformulate the state equations without the pressure term. That would of course mean stepping way back and having to reformulate all the associated equations sans pressure.")

#text("Such an approach would also inherently solve the coarse vs fine issue based on the resolution of the applied matrix. Only real problem would be introducing the right basis functions to generate the chaotic turbulent behavior in regions of high turbulence. It would never be fully accurate at describing the “reality” of the turbulence as the turbulence in this model is inherently chaotic but it should do a decent job of coming quite close at the fine scale and be very accurate at the coarse scale.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/841c0e8b00b1ba1d79a76c2dc4a338c45b86a4e51f17ee9315a42a347e9c9096-b757c319cd1e27458c979d13cd653616178c4cedb65e57e9f9fce9813bfe6bb2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Nguyen")]], [#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-77713")[#strong[#text("Tim Nguyen")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2011")])]

#text("Hi Terry, it seems that your blog posts are not updating on your buzz (at least for me).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-490011")[#strong[#text("Aleph Null – bonefactory")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")]

#text("[…] brain, and indeed, the whole mind, are much more than information processors). This is also why the Navier-Stokes equations are generally unsolvable. The equations may be scalable to coarse grain or fine grain […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantitative bounds for critically bounded solutions to the Navier-Stokes equations | What's new")]], [#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-519678")[#strong[#text("Quantitative bounds for critically bounded solutions to the Navier-Stokes equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("[…] form of) the entrosphy is small at time ; using a version of the localised enstrophy estimates from a previous paper of mine, one can then propagate this sort of control forward in time, obtaining an “annulus of […]")
]
