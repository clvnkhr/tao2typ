// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/
// Converted to Typst by tao2typ: "2026-10-14T10:23:56.964362+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwiłł (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwiłł (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 February 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/")[#text("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In analytic number theory, it is a well-known phenomenon that for many arithmetic functions ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" of interest in number theory, it is significantly easier to estimate logarithmic sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{f(n)}{n}")]]

#text("than it is to estimate summatory functions such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} f(n).")]]

#text("(Here we are normalising ")#mi("{f}")#text(" to be roughly constant in size, e.g. ")#mi("{f(n) = O( n^{o(1)} )}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".) For instance, when ")#mi("{f}")#text(" is the von Mangoldt function ")#mi("{\\Lambda}")#text(", the logarithmic sums ")#mi("{\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n}}")#text(" can be adequately estimated by ")#link("http://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("Mertens’ theorem")]#text(", which can be easily proven by elementary means (see ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("); but a satisfactory estimate on the summatory function ")#mi("{\\sum_{n \\leq x} \\Lambda(n)}")#text(" requires the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", which is substantially harder to prove (see ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("). (From a complex-analytic or Fourier-analytic viewpoint, the problem is that the logarithmic sums ")#mi("{\\sum_{n \\leq x} \\frac{f(n)}{n}}")#text(" can usually be controlled just from knowledge of the Dirichlet series ")#mi("{\\sum_n \\frac{f(n)}{n^s}}")#text(" for ")#mi("{s}")#text(" near ")#mi("{1}")#text("; but the summatory functions require control of the Dirichlet series ")#mi("{\\sum_n \\frac{f(n)}{n^s}}")#text(" for ")#mi("{s}")#text(" on or near a large portion of the line ")#mi("{\\{ 1+it: t \\in {\\bf R} \\}}")#text(". See ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" for further discussion.)")

#text("Viewed conversely, whenever one has a difficult estimate on a summatory function such as ")#mi("{\\sum_{n \\leq x} f(n)}")#text(", one can look to see if there is a “cheaper” version of that estimate that only controls the logarithmic sums ")#mi("{\\sum_{n \\leq x} \\frac{f(n)}{n}}")#text(", which is easier to prove than the original, more “expensive” estimate. In this post, we shall do this for two theorems, a classical ")#link("http://www.ams.org/mathscinet-getitem?mr=319930")[#text("theorem of")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=369292")[#text("Halasz")]#text(" on mean values of multiplicative functions on long intervals, and a much more ")#link("http://arxiv.org/abs/1501.04585")[#text("recent result of Matomaki and Radziwiłł")]#text(" on mean values of multiplicative functions in short intervals. The two are related; the former theorem is an ingredient in the latter (though in the special case of the Matomaki-Radziwiłł theorem considered here, we will not need Halasz’s theorem directly, instead using a key tool in the ")#emph[#text("proof")]#text(" of that theorem).")

#text("We begin with Halasz’s theorem. Here is a version of this theorem, due to Montgomery and ")#link("http://www.ams.org/mathscinet-getitem?mr=1342300")[#text("to Tenenbaum")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Halasz-Montgomery-Tenenbaum)")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a multiplicative function with ")#tao-math("{\\left|f(n)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{n}")#text(". Let ")#mi("{x \\geq 3}")#text(" and ")#mi("{T \\geq 1}")#text(", and set")

#align(center)[#tao-fit-display[#tao-math("M := \\min_{\\left|t\\right| \\leq T} \\sum_{p \\leq x} \\frac{1 - \\text{Re}( f(p) p^{-it} )}{p}.", block: true)]]

#text("Then one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) \\ll (1+M) e^{-M} + \\frac{1}{\\sqrt{T}}.")]]
]

#text("Informally, this theorem asserts that ")#mi("{\\sum_{n \\leq x} f(n)}")#text(" is small compared with ")#mi("{x}")#text(", unless ")#mi("{f}")#text(" “pretends” to be like the character ")#mi("{p \\mapsto p^{it}}")#text(" on primes for some small ")#mi("{y}")#text(". (This is the starting point of the “pretentious” approach of Granville and Soundararajan to analytic number theory, as developed for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2276774")[#text("here")]#text(".) We now give a “cheap” version of this theorem which is significantly weaker (both because it settles for controlling logarithmic sums rather than summatory functions, it requires ")#mi("{f}")#text(" to be completely multiplicative instead of multiplicative, it requires a strong bound on the analogue of the quantity ")#mi("{M}")#text(", and because it only gives qualitative decay rather than quantitative estimates), but easier to prove:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Cheap Halasz)")]#text(" ")#metadata(none) <tao-6d51c8e0e28e139be61f>#text(" Let ")#mi("{x}")#text(" be an asymptotic parameter goingto infinity. Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a completely multiplicative function (possibly depending on ")#mi("{x}")#text(") such that ")#tao-math("{\\left|f(n)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{n}")#text(", such that ")#metadata(none) <tao-de70fa60cac227cbc132>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{p \\leq x} \\frac{1 - \\text{Re}( f(p) )}{p} \\gg \\log\\log x.")]]



#text(" Then ")#metadata(none) <tao-6b9cd7872ae634539ea1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{f(n)}{n} = o(1).")]]




]

#text("Note that now that we are content with estimating exponential sums, we no longer need to preclude the possibility that ")#mi("{f(p)}")#text(" pretends to be like ")#mi("{p^{it}}")#text("; see Exercise 11 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" for a related observation.")

#text("To prove this theorem, we first need a special case of the ")#link("http://en.wikipedia.org/wiki/Tur%C3%A1n%E2%80%93Kubilius_inequality")[#text("Turan-Kubilius inequality")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Turan-Kubilius)")]#text(" ")#metadata(none) <tao-28949ea86dcc7636bf5b>#text(" Let ")#mi("{x}")#text(" be a parameter going to infinity, and let ")#mi("{1 < P < x}")#text(" be a quantity depending on ")#mi("{x}")#text(" such that ")#mi("{P = x^{o(1)}}")#text(" and ")#mi("{P \\rightarrow \\infty}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\frac{ \\left| \\frac{1}{\\log \\log P} \\sum_{p \\leq P: p|n} 1 - 1 \\right|}{n} = o( \\log x ).", block: true)]]
]

#text("Informally, this lemma is asserting that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq P: p|n} 1 \\approx \\log \\log P")]]

#text("for most large numbers ")#mi("{n}")#text(". Another way of writing this heuristically is in terms of Dirichlet convolutions:")

#align(center)[#tao-fit-display[#mitex("1 \\approx 1 * \\frac{1}{\\log\\log P} 1_{{\\mathcal P} \\cap [1,P]}.")]]

#text("This type of estimate was previously discussed as a tool to establish a criterion of Katai and Bourgain-Sarnak-Ziegler for Möbius orthogonality estimates in ")#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")[#text("this previous blog post")]#text(". See also Section 5 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" for some similar computations.")

#emph[#text("Proof:")]#text(" By Cauchy-Schwarz it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\frac{ \\left| \\frac{1}{\\log \\log P} \\sum_{p \\leq P: p|n} 1 - 1 \\right|^2}{n} = o( \\log x ).", block: true)]]

#text("Expanding out the square, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{ (\\frac{1}{\\log \\log P} \\sum_{p \\leq P: p|n} 1)^j}{n} = \\log x + o( \\log x )")]]

#text("for ")#mi("{j=0,1,2}")#text(".")

#text("We just show the ")#mi("{j=2}")#text(" case, as the ")#mi("{j=0,1}")#text(" cases are similar (and easier). We rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(\\log\\log P)^2} \\sum_{p_1, p_2 \\leq P} \\sum_{n \\leq x: p_1,p_2|n} \\frac{1}{n}.")]]

#text("We can estimate the inner sum as ")#mi("{(1+o(1)) \\frac{1}{[p_1,p_2]} \\log x}")#text(". But a routine application of Mertens’ theorem (handling the diagonal case when ")#mi("{p_1=p_2}")#text(" separately) shows that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1, p_2 \\leq P} \\frac{1}{[p_1,p_2]} = (1+o(1)) (\\log\\log P)^2")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" As an alternative to the Turan-Kubilius inequality, one can use the Ramaré identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq P: p|n} \\frac{1}{\\# \\{ p^{\\prime} \\leq P: p^{\\prime}|n\\} + 1} - 1 = 1_{(p,n)=1 \\text{ for all } p \\leq P}")]]

#text("(see e.g. Section 17.3 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander-Iwaniec")]#text("). This identity turns out to give superior quantitative results than the Turan-Kubilius inequality in applications; see ")#link("http://arxiv.org/abs/1501.04585")[#text("the paper of Matomaki and Radziwiłł")]#text(" for an instance of this.")
]

#text("We now prove Theorem ")#link(<tao-6d51c8e0e28e139be61f>)[#text("2")]#text(". Let ")#mi("{Q}")#text(" denote the left-hand side of ")#link(<tao-6b9cd7872ae634539ea1>)[#text("(2)")]#text("; by the triangle inequality we have ")#mi("{Q=O(1)}")#text(". By Lemma ")#link(<tao-28949ea86dcc7636bf5b>)[#text("3")]#text(" (for some ")#mi("{P = x^{o(1)}}")#text(" to be chosen later) and the triangle inequality we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\frac{1}{\\log \\log P} \\sum_{p \\leq P: p|n} f(n)}{n} = Q \\log x + o( \\log x ).")]]

#text("We rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log\\log P} \\sum_{p \\leq P} \\frac{f(p)}{p} \\sum_{m \\leq x/p} \\frac{f(m)}{m}.")]]

#text("We now replace the constraint ")#mi("{m \\leq x/p}")#text(" by ")#mi("{m \\leq x}")#text(". The error incurred in doing so is")

#align(center)[#tao-fit-display[#mitex("O( \\frac{1}{\\log\\log P} \\sum_{p \\leq P} \\frac{1}{p} \\sum_{x/P \\leq m \\leq x} \\frac{1}{m} )")]]

#text("which by Mertens’ theorem is ")#mi("{O(\\log P) = o( \\log x )}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log\\log P} \\sum_{p \\leq P} \\frac{f(p)}{p} \\sum_{m \\leq x} \\frac{f(m)}{m} = Q \\log x + o( \\log x ).")]]

#text("But by definition of ")#mi("{Q}")#text(", we have ")#mi("{\\sum_{m \\leq x} \\frac{f(m)}{m} = Q \\log x}")#text(", thus ")#metadata(none) <tao-ce4e9a0dad1eed8d69c7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("[1 - \\frac{1}{\\log\\log P} \\sum_{p \\leq P} \\frac{f(p)}{p}] Q = o(1).")]]



#text(" From Mertens’ theorem, the expression in brackets can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log\\log P} \\sum_{p \\leq P} \\frac{1 - f(p)}{p} + o(1)")]]

#text("and so the real part of this expression is")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log\\log P} \\sum_{p \\leq P} \\frac{1 - \\text{Re} f(p)}{p} + o(1).")]]

#text("By ")#link(<tao-de70fa60cac227cbc132>)[#text("(1)")]#text(", Mertens’ theorem and the hypothesis on ")#mi("{f}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x^\\varepsilon} \\frac{(1 - \\text{Re} f(p)) \\log p}{p} \\gg \\log\\log x^\\varepsilon - O_\\varepsilon(1)")]]

#text("for any ")#mi("{\\varepsilon > 0}")#text(". This implies that we can find ")#mi("{P = x^{o(1)}}")#text(" going to infinity such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq P} \\frac{(1 - \\text{Re} f(p)) \\log p}{p} \\gg (1-o(1))\\log\\log P")]]

#text("and thus the expression in brackets has real part ")#mi("{\\gg 1-o(1)}")#text(". The claim follows.")

#text("The Turan-Kubilius argument is certainly not the most efficient way to estimate sums such as ")#mi("{\\frac{1}{n} \\sum_{n \\leq x} f(n)}")#text(". In the exercise below we give a significantly more accurate estimate that works when ")#mi("{f}")#text(" is non-negative.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" (")#link("http://arxiv.org/abs/1205.0413")[#text("Granville-Koukoulopoulos-Matomaki")]#text(")")

#list(
[#text("(i) If ")#mi("{g}")#text(" is a completely multiplicative function with ")#mi("{g(p) \\in \\{0,1\\}}")#text(" for all primes ")#mi("{p}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("(e^{-\\gamma}-o(1)) \\prod_{p \\leq x} (1 - \\frac{g(p)}{p})^{-1} \\leq \\sum_{n \\leq x} \\frac{g(n)}{n} \\leq \\prod_{p \\leq x} (1 - \\frac{g(p)}{p})^{-1}.")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" for the upper bound, expand out the Euler product. For the lower bound, show that ")#mi("{\\sum_{n \\leq x} \\frac{g(n)}{n} \\times \\sum_{n \\leq x} \\frac{h(n)}{n} \\ge \\sum_{n \\leq x} \\frac{1}{n}}")#text(", where ")#mi("{h}")#text(" is the completely multiplicative function with ")#mi("{h(p) = 1-g(p)}")#text(" for all primes ")#mi("{p}")#text(".)")],
[#text("(ii) If ")#mi("{g}")#text(" is multiplicative and takes values in ")#mi("{[0,1]}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{g(n)}{n} \\asymp \\prod_{p \\leq x} (1 - \\frac{g(p)}{p})^{-1}")]]

#align(center)[#tao-fit-display[#mitex("\\asymp \\exp( \\sum_{p \\leq x} \\frac{g(p)}{p} )")]]

#text("for all ")#mi("{x \\geq 1}")#text(".")]
)
]

#text("Now we turn to a very ")#link("http://arxiv.org/abs/1501.04585")[#text("recent result of Matomaki and Radziwiłł")]#text(" on mean values of multiplicative functions in short intervals. For sake of illustration we specialise their results to the simpler case of the Liouville function ")#mi("{\\lambda}")#text(", although their arguments actually work (with some additional effort) for arbitrary multiplicative functions of magnitude at most ")#mi("{1}")#text(" that are real-valued (or more generally, stay far from complex characters ")#mi("{p \\mapsto p^{it}}")#text("). Furthermore, we give a qualitative form of their estimates rather than a quantitative one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Matomaki-Radziwiłł, special case)")]#text(" Let ")#mi("{X}")#text(" be a parameter going to infinity, and let ")#mi("{2 \\leq h \\leq X}")#text(" be a quantity going to infinity as ")#mi("{X \\rightarrow \\infty}")#text(". Then for all but ")#mi("{o(X)}")#text(" of the integers ")#mi("{x \\in [X,2X]}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq x+h} \\lambda(n) = o( h ).")]]

#text("Equivalently, one has ")#metadata(none) <tao-5870f9bfd157bd7ef057>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\sum_{X \\leq x \\leq 2X} \\left|\\sum_{x \\leq n \\leq x+h} \\lambda(n)\\right|^2 = o( h^2 X ).", block: true)]]




]

#text("A simple sieving argument (see Exercise 18 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") shows that one can replace ")#mi("{\\lambda}")#text(" by the Möbius function ")#mi("{\\mu}")#text(" and obtain the same conclusion. See ")#link("http://arxiv.org/abs/1502.02374")[#text("this recent note of Matomaki and Radziwiłł")]#text(" for a simple proof of their (quantitative) main theorem in this special case.")

#text("Of course, ")#link(<tao-5870f9bfd157bd7ef057>)[#text("(4)")]#text(" improves upon the trivial bound of ")#mi("{O( h^2 X )}")#text(". Prior to this paper, such estimates were only known (using arguments similar to those in Section 3 of ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text(") for ")#mi("{h \\geq X^{1/6+\\varepsilon}}")#text(" unconditionally, or for ")#mi("{h \\geq \\log^A X}")#text(" for some sufficiently large ")#mi("{A}")#text(" if one assumed the Riemann hypothesis. This theorem also represents some progress towards Chowla’s conjecture (discussed in ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\lambda(n+h_1) \\dots \\lambda(n+h_k) = o( x )")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" for any fixed distinct ")#mi("{h_1,\\dots,h_k}")#text("; indeed, it implies that this conjecture holds if one performs a small amount of averaging in the ")#mi("{h_1,\\dots,h_k}")#text(".")

#text("Below the fold, we give a “cheap” version of the Matomaki-Radziwiłł argument. More precisely, we establish")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Cheap Matomaki-Radziwiłł)")]#text(" ")#metadata(none) <tao-c6f556046e0c00469fe2>#text(" Let ")#mi("{X}")#text(" be a parameter going to infinity, and let ")#mi("{1 \\leq T \\leq X}")#text(". Then ")#metadata(none) <tao-b977b950c1ae31e5aeb9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\int_X^{X^A} \\left|\\sum_{x \\leq n \\leq e^{1/T} x} \\frac{\\lambda(n)}{n}\\right|^2\\frac{dx}{x} = o\\left( \\frac{\\log X}{T^2} \\right),", block: true)]]



#text(" for any fixed ")#mi("{A>1}")#text(".")
]

#text("Note that ")#link(<tao-b977b950c1ae31e5aeb9>)[#text("(5)")]#text(" improves upon the trivial bound of ")#mi("{O( \\frac{\\log X}{T^2} )}")#text(". Again, one can replace ")#mi("{\\lambda}")#text(" with ")#mi("{\\mu}")#text(" if desired. Due to the cheapness of Theorem ")#link(<tao-c6f556046e0c00469fe2>)[#text("7")]#text(", the proof will require few ingredients; the deepest input is the improved zero-free region for the Riemann zeta function due to Vinogradov and Korobov. Other than that, the main tools are the Turan-Kubilius result established above, and some Fourier (or complex) analysis.")

#metadata(none) <tao-802e4bf35621fa6bb801>

#heading(level: 1)[#strong[#text(" — 1. Proof of theorem — ")]]

#text("We now prove Theorem ")#link(<tao-c6f556046e0c00469fe2>)[#text("7")]#text(". We first observe that it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty \\varphi( \\frac{\\log x}{\\log X} ) \\left|\\sum_n \\eta( T( \\log x - \\log n ) ) \\frac{\\lambda(n)}{n}\\right|^2\\ \\frac{dx}{x} = o\\left( \\frac{\\log X}{T^2} \\right)", block: true)]]

#text("for any smooth ")#mi("{\\eta, \\varphi: {\\bf R} \\rightarrow {\\bf R}}")#text(" supported on (say) ")#mi("{[-2,2]}")#text(" and ")#mi("{(1,+\\infty)}")#text(" respectively, as the claim follows by taking ")#mi("{\\eta}")#text(" and ")#mi("{\\varphi}")#text(" to be approximations to ")#mi("{1_{[-1,0]}}")#text(" and ")#mi("{1_{[1,A]}}")#text(" respectively and using the triangle inequality to control the error.")

#text("We need some quantities ")#mi("{P_- \\leq P_+ \\leq X}")#text(" that go to infinity reasonably fast; more specifically we take")

#align(center)[#tao-fit-display[#mitex("P_- := \\exp(\\log^{0.98} X )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P_+ := \\exp(\\log^{0.99} X).")]]

#text("By Lemma ")#link(<tao-28949ea86dcc7636bf5b>)[#text("3")]#text(" and the triangle inequality, we can replace ")#mi("{\\lambda(n)}")#text(" in ")#link(<tao-b977b950c1ae31e5aeb9>)[#text("(5)")]#text(" by ")#mi("{\\frac{1}{\\log \\log P_+ - \\log\\log P_-} \\sum_{P_- < p \\leq P_+: p|n} \\lambda(n)}")#text(" while only incurring an acceptable error. Indeed, writing")

#align(center)[#tao-fit-display[#mitex("f(n) := \\lambda(n) - \\frac{1}{\\log \\log P_+ - \\log\\log P_-} \\sum_{P_- < p \\leq P_+: p|n} \\lambda(n),")]]

#text("we have")

#align(center)[#tao-fit-display[#tao-math("\\left|f(n)\\right| \\ll \\left|\\frac{1}{\\log\\log P_+} \\sum_{p \\leq P_+: p|n} 1 - 1\\right| + \\left|\\frac{1}{\\log\\log P_-} \\sum_{p \\leq P_-: p|n} 1 - 1\\right|", block: true)]]

#text("and so from Lemma ")#link(<tao-28949ea86dcc7636bf5b>)[#text("3")]#text(" and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n: x \\leq n \\leq x^A} \\frac{\\left|f(n)\\right|}{n} = o( \\log X )", block: true)]]

#text("for any fixed ")#mi("{A}")#text(", which implies that")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty \\varphi( \\frac{\\log x}{\\log X} ) \\sum_n \\eta( T( \\log x - \\log n ) ) \\frac{\\left|f(n)\\right|}{n}\\ \\frac{dx}{x} = o\\left( \\frac{\\log X}{T} \\right)", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty \\varphi( \\frac{\\log x}{\\log X} ) \\left|\\sum_n \\eta( T( \\log x - \\log n ) ) \\frac{f(n)}{n}\\right|^2\\ \\frac{dx}{x} = o\\left( \\frac{\\log X}{T^2} \\right)", block: true)]]

#text("since the inner sum is ")#mi("{O(1/T)}")#text(". The claim then follows from the triangle inequality.")

#text("Since ")#mi("{\\log\\log P_- = 0.98 \\log\\log X}")#text(" and ")#mi("{\\log\\log P_+ = 0.99 \\log\\log X}")#text(", our task is now to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty \\varphi( \\frac{\\log x}{\\log X} ) \\left|\\sum_n \\eta( T(\\log x - \\log n)) \\frac{\\sum_{P_- < p \\leq P_+: p|n} \\lambda(n)}{n}\\right|^2\\frac{dx}{x}", block: true)]]

#align(center)[#tao-fit-display[#mitex("= o\\left( \\frac{\\log X}{T^2} (\\log\\log X)^2 \\right).")]]

#text("I will (perhaps idiosyncratically) adopt a Fourier-analytic point of view here, rather than a more traditional complex-analytic point of view (for instance, we will use Fourier transforms as a substitute for Dirichlet series). To bring the Fourier perspective to the forefront, we make the change of variables ")#mi("{x = e^u}")#text(" and ")#mi("{n = pm}")#text(", and note that ")#mi("{\\varphi( \\frac{\\log x}{\\log X} ) = \\varphi( \\frac{\\log m}{\\log X} ) + o(1)}")#text(", to rearrange the previous claim as")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\left|\\sum_{P_- < p \\leq P_+} \\frac{1}{p} F( u - \\log p )\\right|^2\\ du = o( \\log X (\\log\\log X)^2 ).", block: true)]]

#text("where ")#metadata(none) <tao-3f85fab9cc147a837fed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("F(y) := T \\sum_m \\varphi( \\frac{\\log m}{\\log X} ) \\eta( T( y - \\log m) ) \\frac{\\lambda(m)}{m}.")]]





#text("Introducing the normalised discrete measure")

#align(center)[#tao-fit-display[#mitex("\\mu := \\frac{1}{\\log\\log P_+ - \\log\\log P_-} \\sum_{P_- < p \\leq P_+} \\frac{1}{p} \\delta_{\\log p},")]]

#text("it thus suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F * \\mu \\right\\|_{L^2({\\bf R})}^2 = o( \\log X )", block: true)]]

#text("where ")#mi("{*}")#text(" now denotes ordinary (Fourier) convolution rather than Dirichlet convolution.")

#text("From Mertens’ theorem we see that ")#mi("{\\mu}")#text(" has total mass ")#mi("{O(1)}")#text("; also, from the triangle inequality (and the hypothesis ")#mi("{T \\leq X}")#text(") we see that ")#mi("{F}")#text(" is supported on ")#mi("{[(1-o(1)) \\log X, (2+o(1))\\log X]}")#text(" and obeys the pointwise bound of ")#mi("{O(1)}")#text(". Thus we see that the trivial bound on ")#tao-math("{\\left\\| F * \\mu \\right\\|_{L^2({\\bf R})}^2}", block: false)#text(" is ")#mi("{O( \\log X)}")#text(" by Young’s inequality. To improve upon this, we use Fourier analysis. By Plancherel’s theorem, we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F * \\mu \\right\\|_{L^2({\\bf R})}^2 = \\int_{\\bf R} \\left|\\hat F(\\xi)\\right|^2 \\left|\\hat \\mu(\\xi)\\right|^2\\ d\\xi", block: true)]]

#text("where ")#mi("{\\hat F, \\hat \\mu}")#text(" are the Fourier transforms")

#align(center)[#tao-fit-display[#mitex("\\hat F(\\xi) := \\int_{\\bf R} F(x) e^{-2\\pi i x \\xi}\\ dx")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\hat \\mu(\\xi) := \\int_{\\bf R} e^{-2\\pi i x \\xi}\\ d\\mu(x).")]]

#text("From Plancherel’s theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\left|\\hat F(\\xi)\\right|^2 \\ll \\log X.", block: true)]]

#text("Since the derivative of ")#mi("{F}")#text(" is bounded by ")#mi("{O(T)}")#text(", a similar application of Plancherel also gives")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\left|\\xi\\right|^2 \\left|\\hat F(\\xi)\\right|^2 \\ll T^2 \\log X \\leq X^2 \\log X", block: true)]]

#text("so the contribution of those ")#mi("{\\xi}")#text(" with ")#mi("{\\hat \\mu(\\xi)=o(1)}")#text(" or ")#tao-math("{X/\\left|\\xi\\right| = o(1)}", block: false)#text(" is acceptable. Also, from the definition of ")#mi("{F}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\hat F(\\xi) = \\hat \\eta( \\xi / T ) \\sum_m \\varphi( \\frac{\\log m}{\\log X} ) \\frac{\\lambda(m)}{m^{1 + 2\\pi i \\xi}}")]]

#text("and so from the prime number theorem we have ")#mi("{\\hat F(\\xi) = o(1)}")#text(" when ")#mi("{\\xi = O(1)}")#text("; since ")#mi("{\\hat \\mu(\\xi) = O(1)}")#text(", we see that the contribution of the region ")#tao-math("{\\left|\\xi\\right| = O(1)}", block: false)#text(" is also acceptable. It thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\hat \\mu(\\xi) = o(1)")]]

#text("whenever ")#mi("{\\xi = O(X)}")#text(" and ")#tao-math("{1/\\left|\\xi\\right|=o(1)}", block: false)#text(". But by definition of ")#mi("{\\mu}")#text(", we may expand ")#mi("{\\hat \\mu(\\xi)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log\\log P_+ - \\log\\log P_-} \\sum_{P_- < p \\leq P_+} \\frac{1}{p^{1 + 2\\pi i \\xi}}")]]

#text("so by smoothed dyadic decomposition it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_p \\varphi( \\frac{\\log p}{\\log Q} ) \\frac{\\log p}{p^{1 + \\frac{1}{\\log Q} + 2\\pi i \\xi}} = o( \\log Q )")]]

#text("whenever ")#mi("{P_- \\ll Q \\ll P_+}")#text(". We replace the summation over primes with a von Mangoldt function weight to rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\varphi( \\frac{\\log n}{\\log Q} ) \\frac{\\Lambda(n)}{n^{1 + \\frac{1}{\\log Q} + 2\\pi i \\xi}} = o( \\log Q ).")]]

#text("Performing a Fourier expansion of the smooth function ")#mi("{\\varphi}")#text(", it thus suffices to show the Dirichlet series bound")

#align(center)[#tao-fit-display[#tao-math("-\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) = \\sum_n \\frac{\\Lambda(n)}{n^{\\sigma+it}} = o( \\log^{0.98} \\left|t\\right| )", block: true)]]

#text("as ")#tao-math("{\\left|t\\right| \\rightarrow \\infty}", block: false)#text(" and ")#mi("{\\sigma > 1}")#text(" (we use the crude bound ")#mi("{-\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) \\ll \\frac{1}{\\sigma-1}}")#text(" to deal with the ")#mi("{t=O(1)}")#text(" contribution). But this follows from the Vinogradov-Korobov bounds (who in fact get a bound of ")#tao-math("{O( \\log^{2/3}(\\left|t\\right|) \\log\\log^{1/3}(\\left|t\\right|) )}", block: false)#text(" as ")#tao-math("{\\left|t\\right| \\rightarrow \\infty}", block: false)#text("); see Exercise 43 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" combined with Exercise 4(i) of ")#link("https://terrytao.wordpress.com/")[#text("Notes 5")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" If one were working with a more general completely multiplicative function ")#mi("{f}")#text(" than the Liouville function ")#mi("{\\lambda}")#text(", then one would have to use a duality argument to control the large values of ")#mi("{\\hat \\mu}")#text(" (which could occur at a couple more locations than ")#mi("{\\xi = O(1)}")#text("), and use some version of Halasz’s theorem to also obtain some non-trivial bounds on ")#mi("{F}")#text(" at those large values (this would require some hypothesis that ")#mi("{f}")#text(" does not pretend to be like any of the characters ")#mi("{p \\mapsto p^{it}}")#text(" with ")#mi("{t = O(X)}")#text("). These new ingredients are in a similar spirit to the “log-free density theorem” from Theorem 6 of ")#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/")[#text("Notes 7")]#text(". See the ")#link("http://arxiv.org/abs/1501.04585")[#text("Matomaki-Radziwiłł paper")]#text(" for details (in the non-cheap case).")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-452404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2015")])]

#text("In the statement of theorem 6, the function ")#mi("\\phi")#text(" is not defined.")

#emph[#text("[Oops, that term should not have been there; deleted now. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-452421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2015")])]

#text("Which kind of estimate is needed to prove that for almost every x the error term in the PNT is the conjectured one? (perhaps some kind of averaged Chowla conjecture is sufficient?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-452432")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2015")])]

#text("I’m not sure which conjectured error term for PNT you are referring to, but if one wants ")#mi("\\sum_{n \\leq x} \\Lambda(n) = x + O(x^{1/2+o(1)})")#text(" to hold for almost all ")#mi("x")#text(", this is already equivalent (via the explicit formula) to the Riemann hypothesis (which is in turn equivalent to the stronger statement that ")#mi("\\sum_{n \\leq x} \\Lambda(n) = x + O( \\sqrt{x} \\log^2 x )")#text(", part of the remarkable “self-improving” property of the RH).")

#text("If instead one wants ")#mi("\\sum_{x \\leq n \\leq x+x^\\varepsilon} \\Lambda(n) = (1+o(1)) x^\\varepsilon")#text(" for most ")#mi("x")#text(", then it would basically suffice to get good asymptotics for ")#mi("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+h)")#text(" for ")#mi("h")#text(" averaged between 1 and ")#mi("x^{\\varepsilon}")#text(" – that is to say, an averaged form of the prime tuples conjecture. In principle one could derive such asymptotics from (averaged) Chowla type estimates but one would need the error term to be better than the main term by a factor of ")#mi("1/\\log x")#text(" or more (in fact with the usual sieves one would need a gain of the order of ")#mi("1/\\log^2 x")#text("). This seems out of reach of current methods, even with the recent breakthrough of Matomaki and Radziwill.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-452480")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2015")])]

#text("When you say “cheap”, do you mean “weaker and easier to prove” or something slightly different?")

#emph[#text("[Yes, this is the intended meaning; see the second paragraph of the blog post. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d1bf0250e8642527361d99a227c956a19a0e0fd73ff87ded859e8e5bef1aa1be-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bharath Ramsundar")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-452511")[#strong[#text("Bharath Ramsundar")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2015")])]

#text("In the introductory section the statement “The two are related; the latter theorem is an ingredient in the former” should read “The two are related; the former theorem is an ingredient in the latter.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-452704")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2015")])]

#text("This is an instructive post. One comment: in Theorem 2 and its proof, “tends to infinity” should perhaps be “does not tend to zero” (for the sake of applicability), and further care with the dependence of f upon x in the final steps might be warranted")

#emph[#text("[The current argument can tolerate an arbitrary dependence of ")#mi("f")#text(" on ")#mi("x")#text(", so long as it stays bounded by 1 of course. For applications, I would recommend using the “expensive” version of Halasz’s theorem rather than the “cheap” version, which is intended to illustrate the basic idea behind the theorem rather than to be of direct use in applications. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-452717")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2015")])]

#text("I meant (unless I’m just really confused) that the theorem can never be applied because its hypothesis is never satisfied (by Merten’s theorem), and even the weakened hypothesis is consistent with f vanishing on primes up to x^1/10 and being -1 on the rest, which makes the second to last step hard to follow")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-452728")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2015")])]

#text("Oops, you’re right, there were a number of issues with the statement and proof of the theorem. I think I’ve fixed them now (replacing the hypothesis with one that actually can be satisfied).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/900f331aaf0d8380d0b98bd41f31726d408d29bca595cafba6223a9f9b00ef10-ccfbe68fc7789fa8f614eb5f78c452a4e89d0562671ba12bcf82711b188e22ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luq Malik")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-452739")[#strong[#text("Luq Malik")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2015")])]

#text("Reblogged this on ")#link("https://luqmalik.wordpress.com/2015/03/05/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill-optional/")[#text("Luq Malik")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea38b26efe23c05a469c4d4d5531d1fbf8907b6522c72cfd0beb2d22f747c950-31fe085c9d7656ecd214ac89214c70c495faf120628f35950ea22152196d6ab3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-453096")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2015")])]

#text("A minor typographical remark: it should be Radziwiłł (in LaTeX: Radziwi\\l \\l )")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An averaged form of Chowla’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-453190")[#strong[#text("An averaged form of Chowla’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2015")])]

#text("[…] this bound from a generalisation of a recent result of Matomaki and Radziwill (discussed in this previous post) on averages of multiplicative functions in short intervals. For “minor arc” , we can […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-458139")[#strong[#text("Updates and plans III. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2015")]

#text("[…] (Thanks to Tami Ziegler) We followed over here here sparsely and laymanly a few developments in analytic number theory (mainly related to gaps in primes and Möbius randomness). It is a pleasure to mention another breakthrough, largely orthogonal to earlier ones by Kaisa Matomaki and Maksym Radziwill. (Here is a link to the paper and to related blog posts by Terry Tao (1), (2)). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5847c6514a59d6caa69ed38de473afd4b344121e0f1639f9bb5638d4ad9170de-013f79e7a7d3b1328f8a00ea38250b84d92d617eab0fcd55b33528761e5878b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of EG")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-459227")[#strong[#text("EG")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2015")])]

#text("Dear professor,")

#text("Assuming that ")#mi("f")#text(" is roughly constant in size, you said that it’s been observed for many years that ")#mi("\\sum\\frac{f(n)}{n}")#text(" is more easily handled than ")#mi("\\sum f(n)")#text(". Putting asside any complex analysis -which we often use to handle these sums-, isn’t it because of the following observation ?")

#text("If ")#mi("f")#text(" has an exceptionnally big value ")#mi("f(n_0)=A")#text(", then the relative error coming from this term in ")#mi("\\sum_{n\\leq x} f(n)")#text(" is approximately ")#mi("\\frac{A}{x}")#text(", whereas in the case of ")#mi("\\sum_{n\\leq x}\\frac{f(n)}{n}")#text(", the relative error would be approximately ")#mi("\\frac{A}{x\\log x}")#text(" which is smaller.")

#text("From this point view, wouldn’t it be even easier to study sums like ")#mi("\\sum\\frac{f(n)}{n\\log n}")#text(" or even ")#mi("\\sum\\frac{f(n)}{n\\log n\\log\\log n}")#text(" (and so on…) when ")#mi("f")#text(" is “small” (e.g. the number of distinct prime divisors ")#mi("\\omega")#text(") ?")#linebreak()#text(" We for sure lose the multiplicativity though… And in a sense, ")#mi("\\frac{1}{n}")#text(" seems optimal because it’s the best easy way to have a small relative error altogether with the multiplicativity, but there may be more complicated multiplicative functions that allow us to have a smaller error ?")

#text("I find it interesting to notice that this only occurs around “these functions” (")#mi("\\frac{1}{n\\log n}")#text(" etc…) because in any other case, going from ")#mi("n^k")#text(" to ")#mi("n^{-k}")#text(", the relative error is always ")#mi("\\frac{A}{n}")#text(".")

#text("Thanks for your time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-459303")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2015")])]

#text("Yes, this is one way of thinking about it. To put it another way: the sum ")#mi("\\sum_{n \\leq x} f(n)")#text(" is sensitive to the values of ")#mi("f")#text(" on intervals such as ")#mi("[x/2,x]")#text(" (as this would be expected to contribute about half of the total sum) or even ")#mi("[(1-\\varepsilon)x,x]")#text(" for some fixed ")#mi("\\varepsilon>0")#text(". As such, this sum can be influenced by components of ")#mi("f(n)")#text(" of the form ")#mi("n^{it}")#text(" for some bounded ")#mi("t")#text(" (as such functions can be almost constant on intervals such as ")#mi("[(1-\\varepsilon)x, x]")#text(" if ")#mi("\\varepsilon \\ll 1/t")#text("). This is the main reason why the prime number theorem (which is basically about estimating ")#mi("\\sum_{n \\leq x} \\Lambda(n)")#text(") is so difficult to prove, as one must show that the von Mangoldt function ")#mi("\\Lambda(n)")#text(" does not contain a component that looks like ")#mi("n^{it}")#text(", and this is equivalent to ruling out zeroes of the zeta function at ")#mi("1+it")#text(" (as can be seen by the explicit formula).")

#text("For the logarithmic sum ")#mi("\\sum_{n \\leq x} \\frac{f(n)}{n}")#text(", the behaviour of ")#mi("f")#text(" at ")#mi("[x/2,x]")#text(" is negligible; one needs to look at ")#mi("f")#text(" on a much larger interval such as ")#mi("[\\sqrt{x},x]")#text(" or at least ")#mi("[x^{1-\\varepsilon},x]")#text(" before one starts to influence a significant portion of this sum. Because of this, components of ")#mi("f(n)")#text(" such as ")#mi("n^{it}")#text(" are now irrelevant; in the language of Dirichlet series, it is now only the behaviour of the Dirichlet series of ")#mi("f")#text(" near ")#mi("s=1")#text(" (as opposed to near ")#mi("s=1+it")#text(") which is of any significant consequence.")

#text("In principle one could take advantage of further averaging as you say by using a sum such as ")#mi("\\sum_{n \\leq x} \\frac{f(n)}{n \\log n}")#text(", which now only “sees” components that do not oscillate over such large intervals as ")#mi("[\\exp(\\sqrt{\\log x}), x]")#text(" or ")#mi("[\\exp(\\log^{1-\\varepsilon} x), x]")#text(". In particular, any component that looks like ")#mi("(\\log n)^{it}")#text(" would now have negligible impact (whereas such components still have a significant influence on the logarithmic and unweighted sums). However, as you say, in multiplicative number theory one does not usually see expressions such as ")#mi("(\\log n)^{it}")#text(" (which are not multiplicative in n), and so there is usually little additional benefit in performing any additional averaging beyond logarithmic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-459311")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2015")])]

#text("Since ")#mi("\\log \\tau (n)")#text(" has normal order ")#mi("(\\log 2) \\log \\log n")#text(", is it possible to approximate ")#mi("\\log n")#text(" by the (multiplicative!) function ")#mi("\\tau (n)^{1/ \\log 2}")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-459321")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2015")])]

#text("Such an approximation is not very good for controlling sums, due to the heavy-tailed nature of ")#mi("\\tau")#text(". For instance, ")#mi("\\tau(n)")#text(" has an average value of about ")#mi("\\log n")#text(", despite being typically of size ")#mi("\\log^{\\log 2} n")#text(" – the mean and median are very different from each other! Also one runs into significant problems when trying to localise ")#mi("n")#text(" to primes (or almost primes), on which ")#mi("\\tau(n)")#text(" becomes bounded.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-459394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("The difficulty of approximating ")#mi("\\log n")#text(" by a multiplicative function may be explained by a theorem of Birch (J. London Math. Soc. 42(1967) , 149-151), according to which the only multiplicative functions of ")#mi("n")#text(" with a non-decreasing(!) normal order are the positive powers of ")#mi("n")#text("..")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5847c6514a59d6caa69ed38de473afd4b344121e0f1639f9bb5638d4ad9170de-013f79e7a7d3b1328f8a00ea38250b84d92d617eab0fcd55b33528761e5878b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elie520")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-459763")[#strong[#text("elie520")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2015")])]

#text("Thanks for your anwser :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-461882")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#text("Sorry to resurrect a dead comments sections, but I was hoping you could explain how we arrive at the last equation of the post. It seems to me that we still require ")#mi("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = o(\\log Q)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-461883")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#mi("Q")#text(" is chosen to be ")#mi("X^{o(1)}")#text(" for a sufficiently slowly decaying ")#mi("o(1)")#text(" exponent, and ")#mi("t = O(X)")#text(", so any expression which is ")#tao-math("o(\\log \\left|t\\right|)", block: false)#text(" (independently of the choice of Q) will also be ")#mi("o(\\log Q)")#text(" for a sufficiently slowly growing o(1).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-461884")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#text("I do not see how we can take ")#mi("Q")#text(" to be so large, i.e. that the ")#mi("o(1)")#text(" in ")#mi("Q = X^{o(1)}")#text(" goes to zero sufficiently slowly. By trivial estimation we can ignore all ")#mi("Q")#text(" with ")#mi("\\frac{\\log \\log Q}{\\log \\log P} = o(1)")#text(", so we can take ")#mi("Q \\geq \\exp((\\log P)^{o(1)})")#text(". But if ")#mi("Q")#text(" is this small and ")#tao-math("\\left|t\\right|", block: false)#text(" is large (near ")#mi("X")#text(") it seems that ")#mi("\\log Q")#text(" is smaller than ")#tao-math("(\\log \\left|t\\right|)^{2/3}", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-461885")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#text("Ah, I see the problem now, thanks. One has to remove the small primes from ")#mi("\\mu")#text(" to avoid this. I’ve rewritten the argument accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-461951")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#text("I think Lemma 3 as written is insufficient for the proof of Theorem 7. To get a factor of ")#mi("o\\left(\\frac{1}{T} \\right)")#text(", we would want a version where we can sum over ")#mi("n")#text(" with ")#mi("y<n \\leq x")#text(", and an error term of ")#mi("o(\\log x - \\log y)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-461953")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#text("Actually, I think Lemma 3 is enough once one uses Cauchy-Schwarz to eliminate the local averaging in intervals like ")#mi("[x, e^{1/T} x]")#text(". I’ve added some text to the argument to detail this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-461955")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#text("In the equation immediately after ‘for any fixed ")#mi("A")#text(", which implies that’, could you provide more detail here? The appearance of the ")#mi("T")#text(" factor seems mysterious. Also, in the equation beneath, it seems like one would use the trivial bound on one of the sums, and then use the equation above for the other, instead of Cauchy-Schwarz.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-461956")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#text("Thanks for the correction. The factor of T comes from interchanging the sum and integral, and then upper bounding the integral.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-461957")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#text("Great! Thanks.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-478884")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] For instance, in a recent breakthrough result of Matomaki and Radziwill (discussed previously here), it was shown that the Liouville function exhibited cancellation on short intervals in the sense […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8c2016a95d7871dcb511ae984e701ed78c8c69bcbea8aed09b3f13b3dbc827a-acbdc4f59b530120b45a1ec4380cb421d042b21bae300a1a2688683d5cfce060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-517289")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2019")])]

#text("Is there a typo in Remark 4? The left hand side depends only on P and n, but the right hand side appears to depend also on p.")

#emph[#text("[The right-hand side has ")#mi("p")#text(" as a bound variable rather than a free variable (the “for all ")#mi("p \\leq P")#text("” is in the subscript) – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8653ab8dfac3a25c6f9340943b33970aa07b2ad6caf3ef2abe1d67163efdec5-1415eb6c7007c23d93e793782eb1ea04e9adfd85195233713cf70b9cbe27af22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mukherjee")]], [#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/#comment-523541")[#strong[#text("Mukherjee")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2019")])]

#text("Dear Prof. Tao,")#linebreak()#text(" It seems that in Theorem 6, the name Radziwill renders a bit wierdly: the two Ls are replaces by As with dots above them.")

#emph[#text("[Corrected, thanks – T.]")]
]
