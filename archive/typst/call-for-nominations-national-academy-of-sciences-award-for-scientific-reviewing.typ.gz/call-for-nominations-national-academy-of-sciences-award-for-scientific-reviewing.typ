// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/
// Converted to Typst by tao2typ: "2026-10-14T15:18:27.007954+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Call for nominations: National Academy of Sciences Award for Scientific Reviewing", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Call for nominations: National Academy of Sciences Award for Scientific Reviewing")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 July 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/")[#text("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("http://www.nasonline.org/")[#text("National Academy of Sciences")]#text(" ")#link("http://www.nasonline.org/programs/awards/scientific-reviewing.html")[#text("award for Scientific Reviewing")]#text(" is slated to be given in Mathematics (understood to include Applied Mathematics) in April 2013. The award cycles among many fields, and the last (and only) time it was given in Mathematics was 1995. This year, I am on the prize committee for this award and am therefore circulating a call for nominations.")

#text("This award is intended “to recognize authors whose reviews have synthesized extensive and difficult material, rendering a significant service to science and influencing the course of scientific thought”. As such, it is slightly different in focus from most awards in mathematics, which tend to focus more on original research contributions than on synthesis and exposition, which in my opinion is an equally important component of mathematical research.")

#text("In 1995, this prize was awarded to ")#link("http://math.berkeley.edu/~kirby/")[#text("Rob Kirby")]#text(" “For his list of problems in low-dimensional topology and his tireless maintenance of it; several generations have been greatly influenced by Kirby’s list.”.")

#text("Instructions for how to submit nominations can be found at ")#link("http://www.nasonline.org/programs/awards/how-to-nominate.html")[#text("this page")]#text(". Nominees and awardees do not need to be members of the Academy, and can be based outside of the United States. The award comes with a medal and a $10,000 prize. The deadline for nominations is 1 October 2012.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/135675b97fe69927e91cb748f831870f446e71fa8a739aaa849d5b42124f522b-faba070bded647fdb7b69b0b854f013008755e8866cfcdf59dd568d10fcd5222.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Agol")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-151969")[#strong[#text("Ian Agol")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("John Morgan might be a good choice. His expository paper on Thurston’s geometrization theorem for Haken manifolds was quite important, as well as his exposition with Tian of Perelman’s proof of the geometrization conjecture. He also has expositions of works of Sullivan, Donaldson, and Seiberg-Witten, some of the most important developments in geometric topology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-151974")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("Ah, um, perhaps I should have mentioned that John is the chair of this committee, and is thus ineligible for this award. :-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-151983")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("In light of the last award, I think Richard Guy ought to be considered for his “Unsolved Problems in …” books.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/736fbb44c637b091598c1db7c43b5dcb024b851a41647691c2242fdf6da5bf44-e24542b7ce20b9954711dd87fc6c225001edbaf212adb79dce55f9e09680ffb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim van Beek")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-152546")[#strong[#text("Tim van Beek")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2012")])]

#text("What about John Baez and his column “This Week’s Finds in Mathematical Physics”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85a188b385a378b90299ed773ab1af8bd6b68720a58f3c1a01880221a92773ea-0f6bee3bb8f9ca5c929594aa64a739946773ec2f7e24c059441b8fe685297059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiftach")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-152856")[#strong[#text("Yiftach")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2012")])]

#text("It is sort of obvious, but you should consider Gorenstein, Lyons and Solomon for the revision of the classifcation of finite simple groups.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-152864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2012")])]

#text("If I had the time or ability to nominate Richard Guy, I would go with him! He is an incredible expositor of mathematics and has been tirelessly surviving the mathematical community for almost an entire century!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0400076dc057edec8e589d61f82aa09f2ad678d733f172986432c23791c9fb69-04792883ed12fe6555927c881fe80c2f011f37d6ac74323047454ce0604dc4f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bobito")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-152884")[#strong[#text("Bobito")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2012")])]

#text("As someone who had to teach numerical analysis without being an expert in it, I found numerous reviews written by N. Trefethen to be very clear and very useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87f609b600c0011801e3fecf434b7175b6160f6413a0a344294a78069e0ee4b6-ea67f17c33a5367d97698d0335387c231d9aaae45cc6b588cf0cf51f250cbd8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yan Xiaodong")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-153111")[#strong[#text("Yan Xiaodong")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2012")])]

#text("I think that Yau S-T is the best choice for his open problems in geometry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dca4c91bfc9c5d99183d923daef22a1921b080c308a82bae44767235b4a85bb8-c2d20e3daefb42a0cd54a77a7a9b7ba9b97ff661915a2a69854ab884f1cba2f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-153785")[#strong[#text("Christian")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2012")])]

#text("I really hope to be there, or, at least, to buy a t-shirt of the event…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef274d11880037ea629ae972bcf0876424d7bd85aa3fad3774cfe54b805430e5-b51040075ba8e8cc84fa990daad1df3a25b900317227e5b137367ad42509c471.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claver")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-160944")[#strong[#text("claver")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2012")])]

#text("Where is Terry?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-161119")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2012")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2012/08/20/224/")[#text("Being simple")]#text(" and commented:")#linebreak()#text(" This award is too important for all of us, Terence call for nominations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71057e2fd53f41ae3af7bc11e4f9ba881ea0dba8c065e4fe79054cfae8d21198-ad7d545c36596c57166e06dff42a29681b48b6a192da658762b824911786a028.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yo soy josefina")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-164808")[#strong[#text("Yo soy josefina")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2012")])]

#text("I say Bill Nye the science guy!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-165185")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2012")])]

#text("Thurston could have been a good one. Maybe John Horton Conway for many contributions including writing books at all levels.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed35c5d7176aab396f5f62be1d0f89df48965aee1b50f703f15e0f6f381f4818-5e6ea25c2b0feea6120a591f5f613d87f6668cf9a4e4f8b85ba769919326395f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cczy")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-166580")[#strong[#text("cczy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2012")])]

#text("Actually I much respect people who develop Mathematic.")#linebreak()#text(" very nice, that award is not money onlt, but also nedal, will be interesting to see picture.")#linebreak()#text(" 1995 winner, Rob Kirby, if I’m correct, he is from University of California, isn’t he?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/13/call-for-nominations-national-academy-of-sciences-award-for-scientific-reviewing/#comment-212459")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2013")])]

#text("An update: after considering many strong applications (including those contributed from the comments here), the committee recommended to award the prize to Bruce Kleiner and John Lott for their extensive explication of Perelman’s proof of the Poincare and geometrisation conjectures. (The full citation may be ")#link("http://www.nasonline.org/news-and-multimedia/news/jan-7-2013-NASawards.html")[#text("found here")]#text(".)")
]
