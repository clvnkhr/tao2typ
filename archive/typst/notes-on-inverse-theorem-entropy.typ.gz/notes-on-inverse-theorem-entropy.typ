// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/
// Converted to Typst by tao2typ: "2026-10-14T16:39:02.276770+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Notes on inverse theorem entropy", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Notes on inverse theorem entropy")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 May 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/")[#text("https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{G}")#text(" be a finite set of order ")#mi("{N}")#text("; in applications ")#mi("{G}")#text(" will be typically something like a finite abelian group, such as the cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(". Let us define a ")#emph[#mi("{1}")#text("-bounded function")]#text(" to be a function ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" such that ")#tao-math("{\\left|f(n)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{n \\in G}")#text(". There are many seminorms ")#mi("{\\| \\|}")#text(" of interest that one places on functions ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" that are bounded by ")#mi("{1}")#text(" on ")#mi("{1}")#text("-bounded functions, such as the ")#link("https://en.wikipedia.org/wiki/Gowers_norm")[#text("Gowers uniformity seminorms")]#text(" ")#mi("{\\| \\|_k}")#text(" for ")#mi("{k \\geq 1}")#text(" (which are genuine norms for ")#mi("{k \\geq 2}")#text("). All seminorms in this post will be implicitly assumed to obey this property.")

#text("In additive combinatorics, a significant role is played by ")#emph[#text("inverse theorems")]#text(", which abstractly take the following form for certain choices of seminorm ")#mi("{\\| \\|}")#text(", some parameters ")#mi("{\\eta, \\varepsilon>0}")#text(", and some class ")#mi("{{\\mathcal F}}")#text(" of ")#mi("{1}")#text("-bounded functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Inverse theorem template)")]#text(" If ")#mi("{f}")#text(" is a ")#mi("{1}")#text("-bounded function with ")#tao-math("{\\left\\|f\\right\\| \\geq \\eta}", block: false)#text(", then there exists ")#mi("{F \\in {\\mathcal F}}")#text(" such that ")#tao-math("{\\left|\\langle f, F \\rangle\\right| \\geq \\varepsilon}", block: false)#text(", where ")#mi("{\\langle,\\rangle}")#text(" denotes the usual inner product")

#align(center)[#tao-fit-display[#mitex("\\langle f, F \\rangle := {\\bf E}_{n \\in G} f(n) \\overline{F(n)}.")]]
]

#text("Informally, one should think of ")#mi("{\\eta}")#text(" as being somewhat small but fixed independently of ")#mi("{N}")#text(", ")#mi("{\\varepsilon}")#text(" as being somewhat smaller but depending only on ")#mi("{\\eta}")#text(" (and on the seminorm), and ")#mi("{{\\mathcal F}}")#text(" as representing the “structured functions” for these choices of parameters. There is some flexibility in exactly how to choose the class ")#mi("{{\\mathcal F}}")#text(" of structured functions, but intuitively an inverse theorem should become more powerful when this class is small. Accordingly, let us define the ")#emph[#mi("{(\\eta,\\varepsilon)}")#text("-entropy")]#text(" of the seminorm ")#mi("{\\| \\|}")#text(" to be the least cardinality of ")#mi("{{\\mathcal F}}")#text(" for which such an inverse theorem holds. Seminorms with low entropy are ones for which inverse theorems can be expected to be a useful tool. This concept arose in some discussions I had with Ben Green many years ago, but never appeared in print, so I decided to record some observations we had on this concept here on this blog.")

#text("Lebesgue norms ")#tao-math("{\\left\\| f\\right\\|_{L^p} := ({\\bf E}_{n \\in G} \\left|f(n)\\right|^p)^{1/p}}", block: false)#text(" for ")#mi("{1 < p < \\infty}")#text(" have exponentially large entropy (and so inverse theorems are not expected to be useful in this case):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (")#mi("{L^p}")#text(" norm has exponentially large inverse entropy)")]#text(" ")#metadata(none) <tao-15dbb1cfb37311812bdb>#text(" Let ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{0 < \\eta < 1}")#text(". Then the ")#mi("{(\\eta,\\eta^p/4)}")#text("-entropy of ")#mi("{\\| \\|_{L^p}}")#text(" is at most ")#mi("{(1+8/\\eta^p)^N}")#text(". Conversely, for any ")#mi("{\\varepsilon>0}")#text(", the ")#mi("{(\\eta,\\varepsilon)}")#text("-entropy of ")#mi("{\\| \\|_{L^p}}")#text(" is at least ")#mi("{\\exp( c \\varepsilon^2 N)}")#text(" for some absolute constant ")#mi("{c>0}")#text(".")
]

#emph[#text("Proof:")]#text(" If ")#mi("{f}")#text(" is ")#mi("{1}")#text("-bounded with ")#tao-math("{\\left\\|f\\right\\|_{L^p} \\geq \\eta}", block: false)#text(", then we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f, \\left|f\\right|^{p-2} f \\rangle\\right| \\geq \\eta^p", block: true)]]

#text("and hence by the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f, F \\rangle\\right| \\geq \\eta^p/2", block: true)]]

#text("where ")#mi("{F}")#text(" is either the real or imaginary part of ")#tao-math("{\\left|f\\right|^{p-2} f}", block: false)#text(", which takes values in ")#mi("{[-1,1]}")#text(". If we let ")#mi("{\\tilde F}")#text(" be ")#mi("{F}")#text(" rounded to the nearest multiple of ")#mi("{\\eta^p/4}")#text(", then by the triangle inequality again we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f, \\tilde F \\rangle\\right| \\geq \\eta^p/4.", block: true)]]

#text("There are only at most ")#mi("{1+8/\\eta^p}")#text(" possible values for each value ")#mi("{\\tilde F(n)}")#text(" of ")#mi("{\\tilde F}")#text(", and hence at most ")#mi("{(1+8/\\eta^p)^N}")#text(" possible choices for ")#mi("{\\tilde F}")#text(". This gives the first claim.")

#text("Now suppose that there is an ")#mi("{(\\eta,\\varepsilon)}")#text("-inverse theorem for some ")#mi("{{\\mathcal F}}")#text(" of cardinality ")#mi("{M}")#text(". If we let ")#mi("{f}")#text(" be a random sign function (so the ")#mi("{f(n)}")#text(" are independent random variables taking values in ")#mi("{-1,+1}")#text(" with equal probability), then there is a random ")#mi("{F \\in {\\mathcal F}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f, F \\rangle\\right| \\geq \\varepsilon", block: true)]]

#text("and hence by the pigeonhole principle there is a deterministic ")#mi("{F \\in {\\mathcal F}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\langle f, F \\rangle\\right| \\geq \\varepsilon ) \\geq 1/M.", block: true)]]

#text("On the other hand, from the ")#link("https://en.wikipedia.org/wiki/Hoeffding%27s_inequality")[#text("Hoeffding inequality")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\langle f, F \\rangle\\right| \\geq \\varepsilon ) \\ll \\exp( - c \\varepsilon^2 N )", block: true)]]

#text("for some absolute constant ")#mi("{c}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("M \\geq \\exp( c \\varepsilon^2 N )")]]

#text("as claimed. ")#mi("\\Box")

#text("Most seminorms of interest in additive combinatorics, such as the Gowers uniformity norms, are bounded by some finite ")#mi("{L^p}")#text(" norm thanks to Hölder’s inequality, so from the above proposition and the obvious monotonicity properties of entropy, we conclude that all Gowers norms on finite abelian groups ")#mi("{G}")#text(" have at most exponential inverse theorem entropy. But we can do significantly better than this:")

#list(
[#text("For the ")#mi("{U^1}")#text(" seminorm ")#tao-math("{\\left\\|f\\right\\|_{U^1(G)} := \\left|{\\bf E}_{n \\in G} f(n)\\right|}", block: false)#text(", one can simply take ")#mi("{{\\mathcal F} = \\{1\\}}")#text(" to consist of the constant function ")#mi("{1}")#text(", and the ")#mi("{(\\eta,\\eta)}")#text("-entropy is clearly equal to ")#mi("{1}")#text(" for any ")#mi("{0 < \\eta < 1}")#text(".")],
[#text("For the ")#mi("{U^2}")#text(" norm, the standard Fourier-analytic inverse theorem asserts that if ")#tao-math("{\\left\\|f\\right\\|_{U^2(G)} \\geq \\eta}", block: false)#text(" then ")#tao-math("{\\left|\\langle f, e(\\xi \\cdot) \\rangle\\right| \\geq \\eta^2}", block: false)#text(" for some Fourier character ")#mi("{\\xi \\in \\hat G}")#text(". Thus the ")#mi("{(\\eta,\\eta^2)}")#text("-entropy is at most ")#mi("{N}")#text(".")],
[#text("For the ")#mi("{U^k({\\bf Z}/N{\\bf Z})}")#text(" norm on cyclic groups for ")#mi("{k > 2}")#text(", the inverse theorem ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("proved by Green, Ziegler, and myself")]#text(" gives an ")#mi("{(\\eta,\\varepsilon)}")#text("-inverse theorem for some ")#mi("{\\varepsilon \\gg_{k,\\eta} 1}")#text(" and ")#mi("{{\\mathcal F}}")#text(" consisting of nilsequences ")#mi("{n \\mapsto F(g(n) \\Gamma)}")#text(" for some filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" of degree ")#mi("{k-1}")#text(" in a finite collection of cardinality ")#mi("{O_{\\eta,k}(1)}")#text(", some polynomial sequence ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(" (which was subsequently observed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3211031")[#text("by Candela-Sisask")]#text(" (see also ")#link("https://arxiv.org/abs/1404.7742")[#text("Manners")]#text(") that one can choose to be ")#mi("{N}")#text("-periodic), and some Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(" of Lipschitz norm ")#mi("{O_{\\eta,k}(1)}")#text(". By the Arzela-Ascoli theorem, the number of possible ")#mi("{F}")#text(" (up to uniform errors of size at most ")#mi("{\\varepsilon/2}")#text(", say) is ")#mi("{O_{\\eta,k}(1)}")#text(". By standard arguments one can also ensure that the coefficients of the polynomial ")#mi("{g}")#text(" are ")#mi("{O_{\\eta,k}(1)}")#text(", and then by periodicity there are only ")#mi("{O(N^{O_{\\eta,k}(1)}}")#text(" such polynomials. As a consequence, the ")#mi("{(\\eta,\\varepsilon)}")#text("-entropy is of polynomial size ")#mi("{O_{\\eta,k}( N^{O_{\\eta,k}(1)} )}")#text(" (a fact that seems to have first been implicitly observed in Lemma 6.2 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2585398")[#text("this paper of Frantzikinakis")]#text("; thanks to Ben Green for this reference). One can obtain more precise dependence on ")#mi("{\\eta,k}")#text(" using the quantitative version of this inverse theorem due to ")#link("https://arxiv.org/abs/1811.00718")[#text("Manners")]#text("; back of the envelope calculations using Section 5 of that paper suggest to me that one can take ")#mi("{\\varepsilon = \\eta^{O_k(1)}}")#text(" to be polynomial in ")#mi("{\\eta}")#text(" and the entropy to be of the order ")#mi("{O_k( N^{\\exp(\\exp(\\eta^{-O_k(1)}))} )}")#text(", or alternatively one can reduce the entropy to ")#mi("{O_k( \\exp(\\exp(\\eta^{-O_k(1)})) N^{\\eta^{-O_k(1)}})}")#text(" at the cost of degrading ")#mi("{\\varepsilon}")#text(" to ")#mi("{1/\\exp\\exp( O(\\eta^{-O(1)}))}")#text(".")],
[#text("If one replaces the cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" by a vector space ")#mi("{{\\bf F}_p^n}")#text(" over some fixed finite field ")#mi("{{\\bf F}_p}")#text(" of prime order (so that ")#mi("{N=p^n}")#text("), then the inverse theorem of Ziegler and myself (available in both ")#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("high")]#text(" and ")#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")[#text("low")]#text(" characteristic) allows one to obtain an ")#mi("{(\\eta,\\varepsilon)}")#text("-inverse theorem for some ")#mi("{\\varepsilon \\gg_{k,\\eta} 1}")#text(" and ")#mi("{{\\mathcal F}}")#text(" the collection of non-classical degree ")#mi("{k-1}")#text(" polynomial phases from ")#mi("{{\\bf F}_p^n}")#text(" to ")#mi("{S^1}")#text(", which one can normalize to equal ")#mi("{1}")#text(" at the origin, and then by ")#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/")[#text("the classification of such polynomials")]#text(" one can calculate that the ")#mi("{(\\eta,\\varepsilon)}")#text(" entropy is of quasipolynomial size ")#mi("{\\exp( O_{p,k}(n^{k-1}) ) = \\exp( O_{p,k}( \\log^{k-1} N ) )}")#text(" in ")#mi("{N}")#text(". By using the ")#link("https://arxiv.org/abs/2002.11667")[#text("recent work of Gowers and Milicevic")]#text(", one can make the dependence on ")#mi("{p,k}")#text(" here more precise, but we will not perform these calcualtions here.")],
[#text("For the ")#mi("{U^3(G)}")#text(" norm on an arbitrary finite abelian group, the recent ")#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/")[#text("inverse theorem of Jamneshan and myself")]#text(" gives (after some calculations) a bound of the polynomial form ")#mi("{O( q^{O(n^2)} N^{\\exp(\\eta^{-O(1)})})}")#text(" on the ")#mi("{(\\eta,\\varepsilon)}")#text("-entropy for some ")#mi("{\\varepsilon \\gg \\eta^{O(1)}}")#text(", which one can improve slightly to ")#mi("{O( q^{O(n^2)} N^{\\eta^{-O(1)}})}")#text(" if one degrades ")#mi("{\\varepsilon}")#text(" to ")#mi("{1/\\exp(\\eta^{-O(1)})}")#text(", where ")#mi("{q}")#text(" is the maximal order of an element of ")#mi("{G}")#text(", and ")#mi("{n}")#text(" is the rank (the number of elements needed to generate ")#mi("{G}")#text("). This bound is polynomial in ")#mi("{N}")#text(" in the cyclic group case and quasipolynomial in general.")]
)

#text("For general finite abelian groups ")#mi("{G}")#text(", we do not yet have an inverse theorem of comparable power to the ones mentioned above that give polynomial or quasipolynomial upper bounds on the entropy. However, there is a cheap argument that at least gives some subexponential bounds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Cheap subexponential bound)")]#text(" ")#metadata(none) <tao-c47f8598ebaafafcccc3>#text(" Let ")#mi("{k \\geq 2}")#text(" and ")#mi("{0 < \\eta < 1/2}")#text(", and suppose that ")#mi("{G}")#text(" is a finite abelian group of order ")#mi("{N \\geq \\eta^{-C_k}}")#text(" for some sufficiently large ")#mi("{C_k}")#text(". Then the ")#mi("{(\\eta,c_k \\eta^{O_k(1)})}")#text("-complexity of ")#mi("{\\| \\|_{U^k(G)}}")#text(" is at most ")#mi("{O( \\exp( \\eta^{-O_k(1)} N^{1 - \\frac{k+1}{2^k-1}} ))}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) We use a standard random sampling argument, of the type used for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2738997")[#text("by Croot-Sisask")]#text(" or ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4216700")[#text("Briet-Gopi")]#text(" (thanks to Ben Green for this latter reference). We can assume that ")#mi("{N \\geq \\eta^{-C_k}}")#text(" for some sufficiently large ")#mi("{C_k>0}")#text(", since otherwise the claim follows from Proposition ")#link(<tao-15dbb1cfb37311812bdb>)[#text("2")]#text(".")

#text("Let ")#mi("{A}")#text(" be a random subset of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" with the events ")#mi("{n \\in A}")#text(" being iid with probability ")#mi("{0 < p < 1}")#text(" to be chosen later, conditioned to the event ")#tao-math("{\\left|A\\right| \\leq 2pN}", block: false)#text(". Let ")#mi("{f}")#text(" be a ")#mi("{1}")#text("-bounded function. By a standard second moment calculation, we see that with probability at least ")#mi("{1/2}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\|f\\right\\|_{U^k(G)}^{2^k}  & = {\\bf E}_{n, h_1,\\dots,h_k \\in G} f(n) \\prod_{\\omega \\in \\{0,1\\}^k \\backslash \\{0\\}} {\\mathcal C}^{\\left|\\omega\\right|} \\frac{1}{p} 1_A f(n + \\omega \\cdot h)", block: true)



#tao-math(" & + O((\\frac{1}{N^{k+1} p^{2^k-1}})^{1/2}).", block: true)
]

#text("Thus, by the triangle inequality, if we choose ")#mi("{p := C \\eta^{-2^{k+1}/(2^k-1)} / N^{\\frac{k+1}{2^k-1}}}")#text(" for some sufficiently large ")#mi("{C = C_k > 0}")#text(", then for any ")#mi("{1}")#text("-bounded ")#mi("{f}")#text(" with ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)} \\geq \\eta/2}", block: false)#text(", one has with probability at least ")#mi("{1/2}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n, h_1,\\dots,h_k \\i2^n G} f(n) \\prod_{\\omega \\in \\{0,1\\}^k \\backslash \\{0\\}} {\\mathcal C}^{\\left|\\omega\\right|} \\frac{1}{p} 1_A f(n + \\omega \\cdot h)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\geq \\eta^{2^k}/2^{2^k+1}.")]]

#text("We can write the left-hand side as ")#tao-math("{\\left|\\langle f, F \\rangle\\right|}", block: false)#text(" where ")#mi("{F}")#text(" is the randomly sampled dual function")

#align(center)[#tao-fit-display[#tao-math("F(n) := {\\bf E}_{n, h_1,\\dots,h_k \\in G} f(n) \\prod_{\\omega \\in \\{0,1\\}^k \\backslash \\{0\\}} {\\mathcal C}^{\\left|\\omega\\right|+1} \\frac{1}{p} 1_A f(n + \\omega \\cdot h).", block: true)]]

#text("Unfortunately, ")#mi("{F}")#text(" is not ")#mi("{1}")#text("-bounded in general, but we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{L^2(G)}^2 \\leq {\\bf E}_{n, h_1,\\dots,h_k ,h^{\\prime}_1,\\dots,h^{\\prime}_k \\in G}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\prod_{\\omega \\in \\{0,1\\}^k \\backslash \\{0\\}} \\frac{1}{p} 1_A(n + \\omega \\cdot h) \\frac{1}{p} 1_A(n + \\omega \\cdot h^{\\prime})")]]

#text("and the right-hand side can be shown to be ")#mi("{1+o(1)}")#text(" on the average, so we can condition on the event that the right-hand side is ")#mi("{O(1)}")#text(" without significant loss in falure probability.")

#text("If we then let ")#mi("{\\tilde f_A}")#text(" be ")#mi("{1_A f}")#text(" rounded to the nearest Gaussian integer multiple of ")#mi("{\\eta^{2^k}/2^{2^{10k}}}")#text(" in the unit disk, one has from the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f, \\tilde F \\rangle\\right| \\geq \\eta^{2^k}/2^{2^k+2}", block: true)]]

#text("where ")#mi("{\\tilde F}")#text(" is the discretised randomly sampled dual function")

#align(center)[#tao-fit-display[#tao-math("\\tilde F(n) := {\\bf E}_{n, h_1,\\dots,h_k \\in G} f(n) \\prod_{\\omega \\in \\{0,1\\}^k \\backslash \\{0\\}} {\\mathcal C}^{\\left|\\omega\\right|+1} \\frac{1}{p} \\tilde f_A(n + \\omega \\cdot h).", block: true)]]

#text("For any given ")#mi("{A}")#text(", there are at most ")#mi("{2np}")#text(" places ")#mi("{n}")#text(" where ")#mi("{\\tilde f_A(n)}")#text(" can be non-zero, and in those places there are ")#mi("{O_k( \\eta^{-2^{k}})}")#text(" possible values for ")#mi("{\\tilde f_A(n)}")#text(". Thus, if we let ")#mi("{{\\mathcal F}_A}")#text(" be the collection of all possible ")#mi("{\\tilde f_A}")#text(" associated to a given ")#mi("{A}")#text(", the cardinality of this set is ")#mi("{O( \\exp( \\eta^{-O_k(1)} N^{1 - \\frac{k+1}{2^k-1}} ) )}")#text(", and for any ")#mi("{f}")#text(" with ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)} \\geq \\eta/2}", block: false)#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\tilde F \\in {\\mathcal F}_A} \\left|\\langle f, \\tilde F \\rangle\\right| \\geq \\eta^{2^k}/2^{k+2}", block: true)]]

#text("with probability at least ")#mi("{1/2}")#text(".")

#text("Now we remove the failure probability by independent resampling. By rounding to the nearest Gaussian integer multiple of ")#mi("{c_k \\eta^{2^k}}")#text(" in the unit disk for a sufficiently small ")#mi("{c_k>0}")#text(", one can find a family ")#mi("{{\\mathcal G}}")#text(" of cardinality ")#mi("{O( \\eta^{-O_k(N)})}")#text(" consisting of ")#mi("{1}")#text("-bounded functions ")#mi("{\\tilde f}")#text(" of ")#mi("{U^k(G)}")#text(" norm at least ")#mi("{\\eta/2}")#text(" such that for every ")#mi("{1}")#text("-bounded ")#mi("{f}")#text(" with ")#tao-math("{\\left\\|f\\right\\|_{U^k(G)} \\geq \\eta}", block: false)#text(" there exists ")#mi("{\\tilde f \\in {\\mathcal G}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f-\\tilde f\\right\\|_{L^\\infty(G)} \\leq \\eta^{2^k}/2^{k+3}.", block: true)]]

#text("Now, let ")#mi("{A_1,\\dots,A_M}")#text(" be independent samples of ")#mi("{A}")#text(" for some ")#mi("{M}")#text(" to be chosen later. By the preceding discussion, we see that with probability at least ")#mi("{1 - 2^{-M}}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\tilde F \\in \\bigcup_{j=1}^M {\\mathcal F}_{A_j}} \\left|\\langle \\tilde f, \\tilde F \\rangle\\right| \\geq \\eta^{2^k}/2^{k+2}", block: true)]]

#text("for any given ")#mi("{\\tilde f \\in {\\mathcal G}}")#text(", so by the union bound, if we choose ")#mi("{M = \\lfloor C N \\log \\frac{1}{\\eta} \\rfloor}")#text(" for a large enough ")#mi("{C = C_k}")#text(", we can find ")#mi("{A_1,\\dots,A_M}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\tilde F \\in \\bigcup_{j=1}^M {\\mathcal F}_{A_j}} \\left|\\langle \\tilde f, \\tilde F \\rangle\\right| \\geq \\eta^{2^k}/2^{k+2}", block: true)]]

#text("for ")#emph[#text("all")]#text(" ")#mi("{\\tilde f \\in {\\mathcal G}}")#text(", and hence y the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\tilde F \\in \\bigcup_{j=1}^M {\\mathcal F}_{A_j}} \\left|\\langle f, \\tilde F \\rangle\\right| \\geq \\eta^{2^k}/2^{k+3}.", block: true)]]

#text("Taking ")#mi("{{\\mathcal F}}")#text(" to be the union of the ")#mi("{{\\mathcal F}_{A_j}}")#text(" (applying some truncation and rescaling to these ")#mi("{L^2}")#text("-bounded functions to make them ")#mi("{L^\\infty}")#text("-bounded, and then ")#mi("{1}")#text("-bounded), we obtain the claim. ")#mi("\\Box")

#text("One way to obtain ")#emph[#text("lower")]#text(" bounds on the inverse theorem entropy is to produce a collection of almost orthogonal functions with large norm. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" Let ")#mi("{\\| \\|}")#text(" be a seminorm, let ")#mi("{0 < \\varepsilon \\leq \\eta < 1}")#text(", and suppose that one has a collection ")#mi("{f_1,\\dots,f_M}")#text(" of ")#mi("{1}")#text("-bounded functions such that for all ")#mi("{i=1,\\dots,M}")#text(", ")#tao-math("{\\left\\|f_i\\right\\| \\geq \\eta}", block: false)#text(" one has ")#tao-math("{\\left|\\langle f_i, f_j \\rangle\\right| \\leq \\varepsilon^2/2}", block: false)#text(" for all but at most ")#mi("{L}")#text(" choices of ")#mi("{j \\in \\{1,\\dots,M\\}}")#text(" for all distinct ")#mi("{i,j \\in \\{1,\\dots,M\\}}")#text(". Then the ")#mi("{(\\eta, \\varepsilon)}")#text("-entropy of ")#mi("{\\| \\|}")#text(" is at least ")#mi("{\\varepsilon^2 M / 2L}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose we have an ")#mi("{(\\eta,\\varepsilon)}")#text("-inverse theorem with some family ")#mi("{{\\mathcal F}}")#text(". Then for each ")#mi("{i=1,\\dots,M}")#text(" there is ")#mi("{F_i \\in {\\mathcal F}}")#text(" such that ")#tao-math("{\\left|\\langle f_i, F_i \\rangle\\right| \\geq \\varepsilon}", block: false)#text(". By the pigeonhole principle, there is thus ")#mi("{F \\in {\\mathcal F}}")#text(" such that ")#tao-math("{\\left|\\langle f_i, F \\rangle\\right| \\geq \\varepsilon}", block: false)#text(" for all ")#mi("{i}")#text(" in a subset ")#mi("{I}")#text(" of ")#mi("{\\{1,\\dots,M\\}}")#text(" of cardinality at least ")#tao-math("{M/\\left|{\\mathcal F}\\right|}", block: false)#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left|I\\right| \\geq M / \\left|{\\mathcal F}\\right|.", block: true)]]

#text("We can sum this to obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{i \\in I} c_i \\langle f_i, F \\rangle\\right| \\geq \\left|I\\right| \\varepsilon", block: true)]]

#text("for some complex numbers ")#mi("{c_i}")#text(" of unit magnitude. By Cauchy-Schwarz, this implies")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i \\in I} c_i f_i \\right\\|_{L^2(G)}^2 \\geq \\left|I\\right|^2 \\varepsilon^2", block: true)]]

#text("and hence by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i,j \\in I} \\left|\\langle f_i, f_j \\rangle\\right| \\geq \\left|I\\right|^2 \\varepsilon^2.", block: true)]]

#text("On the other hand, by hypothesis we can bound the left-hand side by ")#tao-math("{\\left|I\\right| (L + \\varepsilon^2 \\left|I\\right|/2)}", block: false)#text(". Rearranging, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|I\\right| \\leq 2 L / \\varepsilon^2", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal F}\\right| \\geq \\varepsilon^2 M / 2L", block: true)]]

#text("giving the claim. ")#mi("\\Box")

#text("Thus for instance:")

#list(
[#text("For the ")#mi("{U^2(G)}")#text(" norm, one can take ")#mi("{f_1,\\dots,f_M}")#text(" to be the family of linear exponential phases ")#mi("{n \\mapsto e(\\xi \\cdot n)}")#text(" with ")#mi("{M = N}")#text(" and ")#mi("{L=1}")#text(", and obtain a linear lower bound of ")#mi("{\\varepsilon^2 N/2}")#text(" for the ")#mi("{(\\eta,\\varepsilon)}")#text("-entropy, thus matching the upper bound of ")#mi("{N}")#text(" up to constants when ")#mi("{\\varepsilon}")#text(" is fixed.")],
[#text("For the ")#mi("{U^k({\\bf Z}/N{\\bf Z})}")#text(" norm, a similar calculation using polynomial phases of degree ")#mi("{k-1}")#text(", combined with the Weyl sum estimates, gives a lower bound of ")#mi("{\\gg_{k,\\varepsilon} N^{k-1}}")#text(" for the ")#mi("{(\\eta,\\varepsilon)}")#text("-entropy for any fixed ")#mi("{\\eta,\\varepsilon}")#text("; by considering nilsequences as well, together with nilsequence equidistribution theory, one can replace the exponent ")#mi("{k-1}")#text(" here by some quantity that goes to infinity as ")#mi("{\\eta \\rightarrow 0}")#text(", though I have not attempted to calculate the exact rate.")],
[#text("For the ")#mi("{U^k({\\bf F}_p^n)}")#text(" norm, another similar calculation using polynomial phases of degree ")#mi("{k-1}")#text(" should give a lower bound of ")#mi("{\\gg_{p,k,\\eta,\\varepsilon} \\exp( c_{p,k,\\eta,\\varepsilon} n^{k-1} )}")#text(" for the ")#mi("{(\\eta,\\varepsilon)}")#text("-entropy, though I have not fully performed the calculation.")]
)

#text("We close with one final example. Suppose ")#mi("{G}")#text(" is a product ")#mi("{G = A \\times B}")#text(" of two sets ")#mi("{A,B}")#text(" of cardinality ")#mi("{\\asymp \\sqrt{N}}")#text(", and we consider the Gowers box norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\Box^2(G)}^4 := {\\bf E}_{a,a^{\\prime} \\in A; b,b^{\\prime} \\in B} f(a,b) \\overline{f}(a,b^{\\prime}) \\overline{f}(a^{\\prime},b) f(a,b).", block: true)]]

#text("One possible choice of class ")#mi("{{\\mathcal F}}")#text(" here are the indicators ")#mi("{1_{U \\times V}}")#text(" of “rectangles” ")#mi("{U \\times V}")#text(" with ")#mi("{U \\subset A}")#text(", ")#mi("{V \\subset B}")#text(" (cf. this previous blog post on ")#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/")[#text("cut norms")]#text("). By standard calculations, one can use this class to show that the ")#mi("{(\\eta, \\eta^4/10)}")#text("-entropy of ")#mi("{\\| \\|_{\\Box^2(G)}}")#text(" is ")#mi("{O( \\exp( O(\\sqrt{N}) )}")#text(", and a variant of the proof of the second part of Proposition ")#link(<tao-15dbb1cfb37311812bdb>)[#text("2")]#text(" shows that this is the correct order of growth in ")#mi("{N}")#text(". In contrast, a modification of Proposition ")#link(<tao-c47f8598ebaafafcccc3>)[#text("3")]#text(" only gives an upper bound of the form ")#mi("{O( \\exp( O( N^{2/3} ) ) )}")#text(" (the bottleneck is ensuring that the randomly sampled dual functions stay bounded in ")#mi("{L^2}")#text("), which shows that while this cheap bound is not optimal, it can still broadly give the correct “type” of bound (specifically, intermediate growth between polynomial and exponential).")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ea88ad08485536281c087889f484488330196b5813cb308c05ed0aa1cc96ca0-f9761ae55b49c75371327ae0d6450b2bc5b7df8441d94ce0c6341358e78ba586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cynicus Rex")]], [#link("https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/#comment-644093")[#strong[#text("Cynicus Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2022")])]

#text("I wonder to what degree an average person could understand this, given an indefinite time to learn all the prerequisite maths.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad7219e5d2b18b5bd21328dbed2ef62677fed49e2e7c7d3808c2c4cc0202a07d-95153fcbfa12d832313fa4454d6a29be664e850a0c764b41682f23381cddcc6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix Johan Schistad Jacobsen")]], [#link("https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/#comment-644136")[#strong[#text("Felix Johan Schistad Jacobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2022")])]

#text("May I ask a question about a subject I know you’re familiar with? Are there any thinkable way, to develop an algorithm to valify the entire Collatz conjecture in a bounded amount of time (by using analytic tools)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bb842258b040d699c721f644030fecdc22c9238ba0571551bda772faf17210e-2cc94c6bf194e5f0820ef564dde484baadd6d805623e6bbc5b4fa0616a1b258d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/#comment-644137")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2022")])]

#text("Nice post!")

#text("This construction seems to imply that the exact values of ")#mi("\\eta")#text(" and ")#mi("\\epsilon")#text(" are irrelevant (except, perhaps, insofar as ")#mi("\\eta\\leq\\epsilon")#text("). Naïvely, I would think that we should observe different regimes in the ")#mi("(\\eta,\\epsilon)")#text(" entropy as ")#mi("\\epsilon")#text(" decreases (or ")#mi("\\eta")#text(" increases). So, is your expositional emphasis because")#linebreak()#text(" * the choice of ")#mi("\\eta")#text(" and ")#mi("\\epsilon")#text(" is irrelevant for applications (in combinatorics)?")#linebreak()#text(" * such different regimes don’t exist?")#linebreak()#text(" * or current technology is too crude to observe such regimes, if they do exist?")

#text("(Lastly, some typos:")#linebreak()#text(" * In paragraph 1, I think you forgot to delete an earlier version: “on functions {f: G \\rightarrow {\\bf C}} that are bounded by {1} on {1}-bounded functions”")#linebreak()#text(" * In the proof of proposition 2, following the application of pigeonhole, I think the inequality is reversed.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/#comment-644286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2022")])]

#text("Thanks for the second correction! But the first sentence is as intended: we restrict attention to seminorms ")#mi("\\| \\|")#text(" with the property that ")#tao-math("\\left\\|f\\right\\| \\leq 1", block: false)#text(" for ")#mi("1")#text("-bounded ")#mi("f")#text(".")

#text("The correct dependence between ")#mi("\\eta")#text(" and ")#mi("\\varepsilon")#text(" is of interest in additive combinatorics: in particular there is a folklore “polynomial inverse conjecture for the Gowers norms” that suggests that we should be able to take ")#mi("\\varepsilon")#text(" of polynomial size in ")#mi("\\eta")#text(" while keeping very good structural control on ")#mi("F")#text(" (e.g., that it is a nilsequence with polynomial bounds on complexity). Sometimes it is important that the bounds are polynomial; in ")#link("https://terrytao.wordpress.com/2021/07/05/quantitative-bounds-for-gowers-uniformity-of-the-mobius-and-von-mangoldt-functions/")[#text("a recent paper with Joni Teravainen")]#text(" it was crucial for a certain “densification” argument that one of the inverse theorems of Manners’ had such a polynomial dependence (at the cost of a weaker class of structured functions). The tools presented here though to lower bound the inverse theorem entropy do not make much of a distinction between polynomial and non-polynomial bounds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bb842258b040d699c721f644030fecdc22c9238ba0571551bda772faf17210e-2cc94c6bf194e5f0820ef564dde484baadd6d805623e6bbc5b4fa0616a1b258d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/#comment-644344")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2022")])]

#text("I see! Thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3aea697ac1b41cbf1f2f8399fa9bd40c5bd3d6ac8ea715f0ec70066a5c987707-295099e174dc6f1f6e7f13f5be954fc1485290d0a076a883a04cc6d111d5df85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nyrhil Muhanis")]], [#link("https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/#comment-644243")[#strong[#text("Nyrhil Muhanis")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2022")])]

#text("Would you please remove that obnoxious fearmongering image about “flattening the curve” from the top of your website? It’s 2022, at this point it is quite clear for anybody with at least two working brain cells that “flattening the curve” rhetoric was full of bυllshiτ.")

#text("Remember, the hardest part of the “two weeks to flatten the curve” is always the first two years. Seriously, save yourself the embarrassment and get rid of that image.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8b2e751c941899671368185e840a640c16d6548e1a1a2e7cbfa7cc6c543761d-f4999ed38d5dd1f20b6f5e9a7903e9416caba6c25a72bc2cbf308b3fc2abc388.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rich Townsend")]], [#link("https://terrytao.wordpress.com/2022/05/27/notes-on-inverse-theorem-entropy/#comment-644279")[#strong[#text("Rich Townsend")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2022")])]

#text("No, it definitely had an effect on the pandemic. Here’s a study ")#link("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7603980/")[#text("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7603980/")]

#text("What’s your evidence countering this?")
]
]
