// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/
// Converted to Typst by tao2typ: "2026-10-14T10:43:36.513767+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An inverse theorem for an inequality of Kneser", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An inverse theorem for an inequality of Kneser")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 November 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/")[#text("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have just uploaded to the arXiv the paper “")#link("https://arxiv.org/abs/1711.04337")[#text("An inverse theorem for an inequality of Kneser")]#text("“, submitted to a special issue of the ")#link("http://www.springer.com/mathematics/journal/11501")[#text("Proceedings of the Steklov Institute of Mathematics")]#text(" in honour of ")#link("https://en.wikipedia.org/wiki/Sergei_Konyagin")[#text("Sergei Konyagin")]#text(". It concerns an ")#link("http://www.ams.org/mathscinet-getitem?mr=81438")[#text("inequality of Kneser")]#text(" discussed ")#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/")[#text("previously in this blog")]#text(", namely that ")#metadata(none) <tao-045572b36ac9385054fc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu(A+B) \\geq \\min(\\mu(A)+\\mu(B), 1)")]]

#text("whenever ")#mi("{A,B}")#text(" are compact non-empty subsets of a compact connected additive group ")#mi("{G}")#text(" with probability Haar measure ")#mi("{\\mu}")#text(". (A later ")#link("http://www.ams.org/mathscinet-getitem?mr=202913")[#text("result of Kemperman")]#text(" extended this inequality to the nonabelian case.) This inequality is non-trivial in the regime ")#metadata(none) <tao-d9072eb0057230c79a69>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mu(A), \\mu(B), 1- \\mu(A)-\\mu(B) > 0.")]]

#text("The connectedness of ")#mi("{G}")#text(" is essential, otherwise one could form counterexamples involving proper subgroups of ")#mi("{G}")#text(" of positive measure. In the blog post, I indicated how this inequality (together with a more “robust” strengthening of it) could be deduced from submodularity inequalities such as ")#metadata(none) <tao-38760eabb666e8e61ee6>

#align(center)[#tao-fit-display[#mitex("\\mu( (A_1 \\cup A_2) + B) + \\mu( (A_1 \\cap A_2) + B)")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\leq \\mu(A_1+B) + \\mu(A_2+B)")]]

#text("which in turn easily follows from the identity ")#mi("{(A_1 \\cup A_2) + B = (A_1+B) \\cup (A_2+B)}")#text(" and the inclusion ")#mi("{(A_1 \\cap A_2) + B \\subset (A_1 +B) \\cap (A_2+B)}")#text(", combined with the inclusion-exclusion formula.")

#text("In the non-trivial regime ")#link(<tao-d9072eb0057230c79a69>)[#text("(2)")]#text(", equality can be attained in ")#link(<tao-045572b36ac9385054fc>)[#text("(1)")]#text(", for instance by taking ")#mi("{G}")#text(" to be the unit circle ")#mi("{G = {\\bf R}/{\\bf Z}}")#text(" and ")#mi("{A,B}")#text(" to be arcs in that circle (obeying ")#link(<tao-d9072eb0057230c79a69>)[#text("(2)")]#text("). A bit more generally, if ")#mi("{G}")#text(" is an arbitrary connected compact abelian group and ")#mi("{\\xi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a non-trivial character (i.e., a continuous homomorphism), then ")#mi("{\\xi}")#text(" must be surjective (as ")#mi("{{\\bf R}/{\\bf Z}}")#text(" has no non-trivial connected subgroups), and one can take ")#mi("{A = \\xi^{-1}(I)}")#text(" and ")#mi("{B = \\xi^{-1}(J)}")#text(" for some arcs ")#mi("{I,J}")#text(" in that circle (again choosing the measures of these arcs to obey ")#link(<tao-d9072eb0057230c79a69>)[#text("(2)")]#text("). The main result of this paper is an inverse theorem that asserts that this is the only way in which equality can occur in ")#link(<tao-045572b36ac9385054fc>)[#text("(1)")]#text(" (assuming ")#link(<tao-d9072eb0057230c79a69>)[#text("(2)")]#text("); furthermore, if ")#link(<tao-045572b36ac9385054fc>)[#text("(1)")]#text(" is close to being satisfied with equality and ")#link(<tao-d9072eb0057230c79a69>)[#text("(2)")]#text(" holds, then ")#mi("{A,B}")#text(" must be close (in measure) to an example of the above form ")#mi("{A = \\xi^{-1}(I), B = \\xi^{-1}(J)}")#text(". Actually, for technical reasons (and for the applications we have in mind), it is important to establish an inverse theorem not just for ")#link(<tao-045572b36ac9385054fc>)[#text("(1)")]#text(", but for the more robust version mentioned earlier (in which the sumset ")#mi("{A+B}")#text(" is replaced by the partial sumset ")#mi("{A +_\\varepsilon B}")#text(" consisting of “popular” sums).")

#text("Roughly speaking, the idea is as follows. Let us informally call ")#mi("{(A,B)}")#text(" a ")#emph[#text("critical pair")]#text(" if ")#link(<tao-d9072eb0057230c79a69>)[#text("(2)")]#text(" holds and the inequality ")#link(<tao-045572b36ac9385054fc>)[#text("(1)")]#text(" (or more precisely, a robust version of this inequality) is almost obeyed with equality. The notion of a critical pair obeys some useful closure properties. Firstly, it is symmetric in ")#mi("{A,B}")#text(", and invariant with respect to translation of either ")#mi("{A}")#text(" or ")#mi("{B}")#text(". Furthermore, from the submodularity inequality ")#link(<tao-38760eabb666e8e61ee6>)[#text("(3)")]#text(", one can show that if ")#mi("{(A_1,B)}")#text(" and ")#mi("{(A_2,B)}")#text(" are critical pairs (with ")#mi("{\\mu(A_1 \\cap A_2)}")#text(" and ")#mi("{1 - \\mu(A_1 \\cup A_2) - \\mu(B)}")#text(" positive), then ")#mi("{(A_1 \\cap A_2,B)}")#text(" and ")#mi("{(A_1 \\cup A_2, B)}")#text(" are also critical pairs. (Note that this is consistent with the claim that critical pairs only occur when ")#mi("{A,B}")#text(" come from arcs of a circle.) Similarly, from associativity ")#mi("{(A+B)+C = A+(B+C)}")#text(", one can show that if ")#mi("{(A,B)}")#text(" and ")#mi("{(A+B,C)}")#text(" are critical pairs, then so are ")#mi("{(B,C)}")#text(" and ")#mi("{(A,B+C)}")#text(".")

#text("One can combine these closure properties to obtain further ones. For instance, suppose ")#mi("{A,B}")#text(" is such that ")#mi("{\\mu(A+B)  0}")#text(". Then (cheating a little bit), one can show that ")#mi("{(A+B,C)}")#text(" is also a critical pair, basically because ")#mi("{A+B}")#text(" is the union of the ")#mi("{A+b}")#text(", ")#mi("{b \\in B}")#text(", the ")#mi("{(A+b,C)}")#text(" are all critical pairs, and the ")#mi("{A+b}")#text(" all intersect each other. This argument doesn’t quite work as stated because one has to apply the closure property under union an uncountable number of times, but it turns out that if one works with the robust version of sumsets and uses a random sampling argument to approximate ")#mi("{A+B}")#text(" by the union of finitely many of the ")#mi("{A+b}")#text(", then the argument can be made to work.")

#text("Using all of these closure properties, it turns out that one can start with an arbitrary critical pair ")#mi("{(A,B)}")#text(" and end up with a small set ")#mi("{C}")#text(" such that ")#mi("{(A,C)}")#text(" and ")#mi("{(kC,C)}")#text(" are also critical pairs for all ")#mi("{1 \\leq k \\leq 10^4}")#text(" (say), where ")#mi("{kC}")#text(" is the ")#mi("{k}")#text("-fold sumset of ")#mi("{C}")#text(". (Intuitively, if ")#mi("{A,B}")#text(" are thought of as secretly coming from the pullback of arcs ")#mi("{I,J}")#text(" by some character ")#mi("{\\xi}")#text(", then ")#mi("{C}")#text(" should be the pullback of a much shorter arc by the same character.) In particular, ")#mi("{C}")#text(" exhibits linear growth, in that ")#mi("{\\mu(kC) = k\\mu(C)}")#text(" for all ")#mi("{1 \\leq k \\leq 10^4}")#text(". One can now use standard technology from inverse sumset theory to show first that ")#mi("{C}")#text(" has a very large Fourier coefficient (and thus is biased with respect to some character ")#mi("{\\xi}")#text("), and secondly that ")#mi("{C}")#text(" is in fact almost of the form ")#mi("{C = \\xi^{-1}(K)}")#text(" for some arc ")#mi("{K}")#text(", from which it is not difficult to conclude similar statements for ")#mi("{A}")#text(" and ")#mi("{B}")#text(" and thus finish the proof of the inverse theorem.")

#text("In order to make the above argument rigorous, one has to be more precise about what the modifier “almost” means in the definition of a critical pair. I chose to do this in the language of “cheap” nonstandard analysis (aka asymptotic analysis), as discussed in ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("this previous blog post")]#text("; one could also have used the full-strength version of nonstandard analysis, but this does not seem to convey any substantial advantages. (One can also work in a more traditional “non-asymptotic” framework, but this requires one to keep much more careful account of various small error terms and leads to a messier argument.)")

#emph[#text("[Update, Nov 15: Corrected the attribution of the inequality (1) to Kneser instead of Kemperman. Thanks to John Griesmer for pointing out the error.]")]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15fdd26260b7494ddff8ae819232b8672e2244d264a794710238bd87a2460350-bf33e1a619ddefa0ea9c77e08888cfca229a3c54d92f5aa63c15cd9e70570d84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicodean")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-488842")[#strong[#text("nicodean")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2017")])]

#text("Reference 12 says “preprint”, but doesnt give a link to the preprint.")

#emph[#text("[This will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hxypqr")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-488855")[#strong[#text("hxypqr")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("Could this result be looked as a continuous version generate of “Cauchy-Davenport theorem”, i.e. ")#tao-math("\\left|A+B\\right|\\geq \\min\\{|p,\\left|A\\right|+\\left|B\\right|-1\\}", block: false)#text(" for any nonempty set ")#mi("A,B \\subset F_p")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-488881")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("Yes, in particular one can deduce the ")#mi("G = {\\bf R}/{\\bf Z}")#text(" case of Kneser’s inequality from the Cauchy-Davenport inequality by a discretisation argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-488870")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("The inverse theorem for the case G=R/Z was proved earlier by Candela and Roton? See Theorem 1.5 in their paper:")

#link("https://arxiv.org/pdf/1709.04501.pdf")[#text("Click to access 1709.04501.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-488880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("Thanks for this reference. It seems that I did not do an adequate literature search before finalising this paper; I will revise it to add in a number of additional references including this one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-488874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("Dear Terence Tao,")#linebreak()#text(" This year 2017 is coming to end.We have one more month.I have been waiting for you for over 10 years with your strongest and greatest result.I am very very far away you,but I feel to be near you every day.Math community has recently had many shocks of the Field medalist’s death.Life is short.Mathematician or vendor,farmer,finally they die for karma.when they pass away,we sometime remind them on book,or magazine or anniversary within 15minutes.that’s all.We turn back the land ,air,water.The Tao is greater than science.But ,you are lucky to have these both.So,I think you are able to do more than other people.Many times I think that you can solve to 100 best problems ,not simply 6 best problems.You certainly succeed and that time your name is the second sun.Once you goodbye forever to this world, your name is sacared to students in all exams,your name is forever")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-488884")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("missing “paper” tag")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/250e4399e0f0e3744a9f80a5f31e3eb9249660dab33b7f5947897c750f460c75-a0e0dc5309700b9546b30fc9af03eb436dd37396d855456f9461f6780da3c643.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wanzg")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-488895")[#strong[#text("wanzg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("Prof Tao,")

#text("You might also change one of tags: Kemperman’s inequality")

#emph[#text("[Changed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-488909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("P. 13, l. 4: woudl –> would")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-489054")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2017")])]

#text("Equation tag in the blog post: “3)” –> “(3)”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-489151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2017")])]

#text("Corrections to the bibliography:")

#text("[2]: “343353” –> “343–353”")#linebreak()#text(" [9]: remove “p.”")#linebreak()#text(" [15]: “49, (1953) 40”–> “49, (1953), 40”")#linebreak()#text(" [16]: “1973) 148” –> “1973), 148”")#linebreak()#text(" [18]: “(1939). 425” –> “(1939), 425”")#linebreak()#text(" [22]: “(1955) 57” –> “(1955), 57”")

#emph[#text("[Thanks, this will be corrected in the next version of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Charlie")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-489661")[#strong[#text("Not Charlie")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2017")])]

#text("What’s that mu operator do")

#emph[#text("[")#mi("\\mu")#text(" is a ")#link("https://en.wikipedia.org/wiki/Measure_(mathematics)")[#text("measure")]#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c8909c9c0523282dc6adf9a6fd8207d0747c6225a9b5060e95c1c99b7a7a906-e7e2088a6d74e8cdd022da358c8ab8c9356178cdc0a7e2cbe96ef29543537b06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of H.H.Holmes")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-489668")[#strong[#text("H.H.Holmes")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2017")])]

#text("imagine that the golbach’s conjectur say that for any positive integer n, and π(2n) random positive integer numbers less than 2n, there are at least two numbers which the sum of them is 2n. even the numbers are not certainly prime, but the probability of existing the numbers is very close to 1. for example we have π(500) different number less than 500. then the probability of existing two of the numbers with sum of 2n is :")#linebreak()#text(" 99.99999999999999999999479116…")#linebreak()#text(" and for bigger numbers it is even closer to 1.")#linebreak()#text(" So □")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Value patterns of multiplicative functions and related sequences | What's new")]], [#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-514801")[#strong[#text("Value patterns of multiplicative functions and related sequences | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2019")])]

#text("[…] the existence of such patterns, but by using an inverse theorem for Kneser’s inequality in this previous paper of mine we are able to identify precisely the obstruction for this method to work, and rule it out by an ad […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/11/15/an-inverse-theorem-for-kempermans-inequality/#comment-515181")[#strong[#text("Value patterns of multiplicative functions and related sequences – 刘展均工作室")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2019")]

#text("[…] the existence of such patterns, but by using an inverse theorem for Kneser’s inequality in this previous paper of mine we are able to identify precisely the obstruction for this method to work, and rule it out by an ad […]")
]
