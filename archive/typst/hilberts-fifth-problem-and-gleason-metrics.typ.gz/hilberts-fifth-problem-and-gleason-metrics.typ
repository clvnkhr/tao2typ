// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/
// Converted to Typst by tao2typ: "2026-10-14T09:11:47.090383+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Hilbert’s fifth problem and Gleason metrics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Hilbert’s fifth problem and Gleason metrics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 June 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/")[#text("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(" asks to clarify the extent that the assumption on a differentiable or smooth structure is actually needed in the theory of Lie groups and their actions. While this question is not precisely formulated and is thus open to some interpretation, the following result of ")#link("http://www.ams.org/mathscinet-getitem?mr=49203")[#text("Gleason")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=49204")[#text("Montgomery-Zippin")]#text(" answers at least one aspect of this question:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Hilbert’s fifth problem)")]#text(" ")#metadata(none) <tao-1774b8eebdec58c5f119>#text(" Let ")#mi("{G}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological group")]#text(" which is ")#link("http://en.wikipedia.org/wiki/Locally_Euclidean")[#text("locally Euclidean")]#text(" (i.e. it is a topological manifold). Then ")#mi("{G}")#text(" is isomorphic to a Lie group.")
]

#text("Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("1")]#text(" can be viewed as an application of the more general structural theory of ")#link("http://en.wikipedia.org/wiki/Locally_compact_group")[#text("locally compact groups")]#text(". In particular, Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("1")]#text(" can be deduced from the following structural theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=39730")[#text("Gleason")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=58607")[#text("Yamabe")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Gleason-Yamabe theorem)")]#text(" ")#metadata(none) <tao-a75ac051e25e3f0a0ff5>#text(" Let ")#mi("{G}")#text(" be a locally compact group, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity in ")#mi("{G}")#text(". Then there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(", and a compact subgroup ")#mi("{N}")#text(" of ")#mi("{G^{\\prime}}")#text(" contained in ")#mi("{U}")#text(", such that ")#mi("{G^{\\prime}/N}")#text(" is isomorphic to a Lie group.")
]

#text("The deduction of Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("1")]#text(" from Theorem ")#link(<tao-a75ac051e25e3f0a0ff5>)[#text("2")]#text(" proceeds using the Brouwer ")#link("http://en.wikipedia.org/wiki/Invariance_of_domain")[#text("invariance of domain")]#text(" theorem and is discussed in ")#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/")[#text("this previous post")]#text(". In this post, I would like to discuss the proof of Theorem ")#link(<tao-a75ac051e25e3f0a0ff5>)[#text("2")]#text(". We can split this proof into three parts, by introducing two additional concepts. The first is the property of having ")#link("http://en.wikipedia.org/wiki/No_small_subgroup")[#text("no small subgroups")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (NSS)")]#text(" A topological group ")#mi("{G}")#text(" is said to have ")#emph[#text("no small subgroups")]#text(", or is ")#emph[#text("NSS")]#text(" for short, if there is an open neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(" that contains no subgroups of ")#mi("{G}")#text(" other than the trivial subgroup ")#mi("{\\{ \\text{id}\\}}")#text(".")
]

#text("An equivalent definition of an NSS group is one which has an open neighbourhood ")#mi("{U}")#text(" of the identity that every non-identity element ")#mi("{g \\in G \\backslash \\{\\text{id}\\}}")#text(" ")#emph[#text("escapes")]#text(" in finite time, in the sense that ")#mi("{g^n \\not \\in U}")#text(" for some positive integer ")#mi("{n}")#text(". It is easy to see that all Lie groups are NSS; we shall shortly see that the converse statement (in the locally compact case) is also true, though significantly harder to prove.")

#text("Another useful property is that of having what I will call a ")#emph[#text("Gleason metric")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4")]#text(" Let ")#mi("{G}")#text(" be a topological group. A ")#emph[#text("Gleason metric")]#text(" on ")#mi("{G}")#text(" is a left-invariant metric ")#mi("{d: G \\times G \\rightarrow {\\bf R}^+}")#text(" which generates the topology on ")#mi("{G}")#text(" and obeys the following properties for some constant ")#mi("{C>0}")#text(", writing ")#tao-math("{\\left\\|g\\right\\|}", block: false)#text(" for ")#mi("{d(g,\\text{id})}")#text(":")

#list(
[#text("(Escape property) If ")#mi("{g \\in G}")#text(" and ")#mi("{n \\geq 1}")#text(" is such that ")#tao-math("{n \\left\\|g\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then ")#tao-math("{\\left\\|g^n\\right\\| \\geq \\frac{1}{C} n \\left\\|g\\right\\|}", block: false)#text(".")],
[#text("(Commutator estimate) If ")#mi("{g, h \\in G}")#text(" are such that ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then")

#metadata(none) <tao-79ada907e679ba85642c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|[g,h]\\right\\| \\leq C \\left\\|g\\right\\| \\left\\|h\\right\\|,", block: true)]]

#text("where ")#mi("{[g,h] := g^{-1}h^{-1}gh}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("commutator")]#text(" of ")#mi("{g}")#text(" and ")#mi("{h}")#text(".")]
)
]

#text("For instance, the unitary group ")#mi("{U(n)}")#text(" with the operator norm metric ")#tao-math("{d(g,h) := \\left\\|g-h\\right\\|_{op}}", block: false)#text(" can easily verified to be a Gleason metric, with the commutator estimate ")#link(<tao-79ada907e679ba85642c>)[#text("(1)")]#text(" coming from the inequality")

#tao-aligned(keep: true)[


#tao-math("\\left\\| [g,h] - 1 \\right\\|_{op}  & = \\left\\| gh - hg \\right\\|_{op}", block: true)



#tao-math(" & = \\left\\| (g-1) (h-1) - (h-1) (g-1) \\right\\|_{op}", block: true)



#tao-math(" & \\leq 2 \\left\\|g-1\\right\\|_{op} \\left\\|g-1\\right\\|_{op}.", block: true)
]

#text("Similarly, any left-invariant Riemannian metric on a (connected) Lie group can be verified to be a Gleason metric. From the escape property one easily sees that all groups with Gleason metrics are NSS; again, we shall see that there is a partial converse.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The escape and commutator properties are meant to capture “Euclidean-like” structure of the group. Other metrics, such as Carnot-Carathéodory metrics on Carnot Lie groups such as the Heisenberg group, usually fail one or both of these properties.")
]

#text("The proof of Theorem ")#link(<tao-a75ac051e25e3f0a0ff5>)[#text("2")]#text(" can then be split into three subtheorems:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Reduction to the NSS case)")]#text(" ")#metadata(none) <tao-a340749430d19809ef11>#text(" Let ")#mi("{G}")#text(" be a locally compact group, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity in ")#mi("{G}")#text(". Then there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(", and a compact subgroup ")#mi("{N}")#text(" of ")#mi("{G^{\\prime}}")#text(" contained in ")#mi("{U}")#text(", such that ")#mi("{G^{\\prime}/N}")#text(" is NSS, locally compact, and metrisable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Gleason’s lemma)")]#text(" ")#metadata(none) <tao-8ec8af8f8051bc58cb70>#text(" Let ")#mi("{G}")#text(" be a locally compact metrisable NSS group. Then ")#mi("{G}")#text(" has a Gleason metric.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Building a Lie structure)")]#text(" ")#metadata(none) <tao-dbb989e8b02ce27d11d4>#text(" Let ")#mi("{G}")#text(" be a locally compact group with a Gleason metric. Then ")#mi("{G}")#text(" is isomorphic to a Lie group.")
]

#text("Clearly, by combining Theorem ")#link(<tao-a340749430d19809ef11>)[#text("5")]#text(", Theorem ")#link(<tao-8ec8af8f8051bc58cb70>)[#text("6")]#text(", and Theorem ")#link(<tao-dbb989e8b02ce27d11d4>)[#text("7")]#text(" one obtains Theorem ")#link(<tao-a75ac051e25e3f0a0ff5>)[#text("2")]#text(" (and hence Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("1")]#text(").")

#text("Theorem ")#link(<tao-a340749430d19809ef11>)[#text("5")]#text(" and Theorem ")#link(<tao-8ec8af8f8051bc58cb70>)[#text("6")]#text(" proceed by some elementary combinatorial analysis, together with the use of Haar measure (to build convolutions, and thence to build “smooth” bump functions with which to create a metric, in a variant of the analysis used to prove the ")#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/")[#text("Birkhoff-Kakutani theorem")]#text("); Theorem ")#link(<tao-a340749430d19809ef11>)[#text("5")]#text(" also requires Peter-Weyl theorem (to dispose of certain compact subgroups that arise en route to the reduction to the NSS case), which was ")#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/")[#text("discussed previously on this blog")]#text(".")

#text("In this post I would like to detail the final component to the proof of Theorem ")#link(<tao-a75ac051e25e3f0a0ff5>)[#text("2")]#text(", namely Theorem ")#link(<tao-dbb989e8b02ce27d11d4>)[#text("7")]#text(". (I plan to discuss the other two steps, Theorem ")#link(<tao-a340749430d19809ef11>)[#text("5")]#text(" and Theorem ")#link(<tao-8ec8af8f8051bc58cb70>)[#text("6")]#text(", in a separate post.) The strategy is similar to that used to prove von Neumann’s theorem, as discussed in ")#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("this previous post")]#text(" (and von Neumann’s theorem is also used in the proof), but with the Gleason metric serving as a substitute for the faithful linear representation. Namely, one first gives the space ")#mi("{L(G)}")#text(" of one-parameter subgroups of ")#mi("{G}")#text(" enough of a structure that it can serve as a proxy for the “Lie algebra” of ")#mi("{G}")#text("; specifically, it needs to be a vector space, and the “exponential map” needs to cover an open neighbourhood of the identity. This is enough to set up an “adjoint” representation of ")#mi("{G}")#text(", whose image is a Lie group by von Neumann’s theorem; the kernel is essentially the centre of ")#mi("{G}")#text(", which is abelian and can also be shown to be a Lie group by a similar analysis. To finish the job one needs to use arguments ")#link("http://www.ams.org/mathscinet-getitem?mr=36238")[#text("of Kuranishi")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=33830")[#text("of Gleason")]#text(", as discussed in ")#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/")[#text("this previous post")]#text(".")

#text("The arguments here can be phrased either in the standard analysis setting (using sequences, and passing to subsequences often) or in the nonstandard analysis setting (selecting an ultrafilter, and then working with infinitesimals). In my view, the two approaches have roughly the same level of complexity in this case, and I have elected for the standard analysis approach.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" From Theorem ")#link(<tao-dbb989e8b02ce27d11d4>)[#text("7")]#text(" we see that a Gleason metric structure is a good enough substitute for smooth structure that it can actually be used to reconstruct the entire smooth structure; roughly speaking, the commutator estimate ")#link(<tao-79ada907e679ba85642c>)[#text("(1)")]#text(" allows for enough “Taylor expansion” of expressions such as ")#mi("{g^n h^n}")#text(" that one can simulate the fundamentals of Lie theory (in particular, construction of the Lie algebra and the exponential map, and its basic properties. The advantage of working with a Gleason metric rather than a smoother structure, though, is that it is relatively undemanding with regards to regularity; in particular, the commutator estimate ")#link(<tao-79ada907e679ba85642c>)[#text("(1)")]#text(" is roughly comparable to the imposition ")#mi("{C^{1,1}}")#text(" structure on the group ")#mi("{G}")#text(", as this is the minimal regularity to get the type of Taylor approximation (with quadratic errors) that would be needed to obtain a bound of the form ")#link(<tao-79ada907e679ba85642c>)[#text("(1)")]#text(". We will return to this point in a later post.")
]

#metadata(none) <tao-51452a391fdb9a19d030>

#heading(level: 1)[#strong[#text(" — 1. Proof of theorem — ")]]

#text("We now prove Theorem ")#link(<tao-dbb989e8b02ce27d11d4>)[#text("7")]#text(". Henceforth, ")#mi("{G}")#text(" is a locally compact group with a Gleason metric ")#mi("{d}")#text(" (and an associated “norm” ")#tao-math("{\\left\\|g\\right\\| = d(g, \\text{id})}", block: false)#text("). In particular, by the Heine-Borel theorem, ")#mi("{G}")#text(" is complete with this metric.")

#text("We use the asymptotic notation ")#mi("{X \\ll Y}")#text(" in place of ")#mi("{X \\leq CY}")#text(" for some constant ")#mi("{C}")#text(" that can vary from line to line (in particular, ")#mi("{C}")#text(" need not be the constant appearing in the definition of a Gleason metric), and write ")#mi("{X \\sim Y}")#text(" for ")#mi("{X \\ll Y \\ll X}")#text(". We also let ")#mi("{\\epsilon > 0}")#text(" be a sufficiently small constant (depending only on the constant in the definition of a Gleason metric) to be chosen later.")

#text("Note that the left-invariant metric properties of ")#mi("{d}")#text(" give the symmetry property")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g^{-1} \\right\\| = \\left\\|g\\right\\|", block: true)]]

#text("and the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g_1 \\ldots g_n \\right\\| \\leq \\sum_{i=1}^n \\|g_i\\|.", block: true)]]

#text("From the commutator estimate ")#link(<tao-79ada907e679ba85642c>)[#text("(1)")]#text(" and the triangle inequality we also obtain a conjugation estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| ghg^{-1} \\right\\| \\sim \\left\\|h\\right\\|", block: true)]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\epsilon}", block: false)#text(". Since left-invariance gives")

#align(center)[#tao-fit-display[#tao-math("d(g,h) = \\left\\| g^{-1} h \\right\\|", block: true)]]

#text("we then conclude an approximate right invariance")

#align(center)[#tao-fit-display[#mitex("d(gk,hk) \\sim d(g,h)")]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\|, \\left\\|k\\right\\| \\leq \\epsilon}", block: false)#text(". In a similar spirit, the commutator estimate ")#link(<tao-79ada907e679ba85642c>)[#text("(1)")]#text(" also gives ")#metadata(none) <tao-861ef4e9fdbbff6a151f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("d(gh,hg) \\ll \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\epsilon}", block: false)#text(".")

#text("This has the following useful consequence, which asserts that the power maps ")#mi("{g \\mapsto g^n}")#text(" behave like dilations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8")]#text(" ")#metadata(none) <tao-2f8c0b475a71847a5766>#text(" If ")#mi("{n \\geq 1}")#text(" and ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\epsilon/n}", block: false)#text(", then")

#align(center)[#tao-fit-display[#tao-math("d(g^n h^n, (gh)^n) \\lesssim n^2 \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("d(g^n,h^n) \\sim n d(g,h).")]]
]

#emph[#text("Proof:")]#text(" We begin with the first inequality. By the triangle inequality, it suffices to show that ")#metadata(none) <tao-b14311345409a01c4bee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("d( (gh)^i g^{n-i} h^{n-i}, (gh)^{i+1} g^{n-i-1} h^{n-i-1} ) \\ll n \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("uniformly for all ")#mi("{0 \\leq i < n}")#text(". By left-invariance and approximate right-invariance, the left-hand side is comparable to")

#align(center)[#tao-fit-display[#mitex("d( g^{n-i-1} h, h g^{n-i-1} ),")]]

#text("which by ")#link(<tao-861ef4e9fdbbff6a151f>)[#text("(2)")]#text(" is bounded above by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\left\\|g^{n-i-1}\\right\\| \\left\\|h\\right\\| \\ll n \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("as required.")

#text("Now we prove the second estimate. Write ")#mi("{g = hk}")#text(", then ")#tao-math("{\\left\\|k \\right\\| = d(g,h) \\leq 2\\epsilon/n}", block: false)#text(". We have")

#align(center)[#tao-fit-display[#tao-math("d(h^n k^n,h^n) = \\left\\|k^n\\right\\| \\sim n \\left\\|k\\right\\|", block: true)]]

#text("thanks to the escape property (shrinking ")#mi("{\\epsilon}")#text(" if necessary). On the other hand, from the first inequality, we have")

#align(center)[#tao-fit-display[#tao-math("d(g^n, h^n k^n) \\ll n^2 \\left\\|h\\right\\| \\left\\|k\\right\\|.", block: true)]]

#text("If ")#mi("{\\epsilon}")#text(" is small enough, the claim now follows from the triangle inequality. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("8")]#text(" implies (by a standard covering argument) that the group ")#mi("{G}")#text(" is locally of bounded doubling, though we will not use this fact here.")
]

#text("Now we introduce the space ")#mi("{L(G)}")#text(" of one-parameter subgroups, i.e. continuous homomorphisms ")#mi("{\\phi: {\\bf R} \\rightarrow G}")#text(". We give this space the ")#link("http://en.wikipedia.org/wiki/Compact-open_topology")[#text("compact-open topology")]#text(", thus the topology is generated by balls of the form")

#align(center)[#tao-fit-display[#mitex("\\{ \\phi \\in L(G): \\sup_{t \\in I} d(\\phi(t),\\phi_0(t)) < r \\}")]]

#text("for ")#mi("{\\phi_0 \\in L(G)}")#text(", ")#mi("{r > 0}")#text(", and compact ")#mi("{I}")#text(". Actually, using the homomorphism property, one can use a single compact interval ")#mi("{I}")#text(", such as ")#mi("{[-1,1]}")#text(", to generate the topology if desired, thus making ")#mi("{L(G)}")#text(" a metric space.")

#text("Given that ")#mi("{G}")#text(" is eventually going to be shown to be a Lie group, ")#mi("{L(G)}")#text(" must be isomorphic to a Euclidean space. We now move towards this goal by establishing various properties of ")#mi("{L(G)}")#text(" that Euclidean spaces enjoy.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9")]#text(" ")#mi("{L(G)}")#text(" is locally compact.")
]

#emph[#text("Proof:")]#text(" It is easy to see that ")#mi("{L(G)}")#text(" is complete. Let ")#mi("{\\phi_0 \\in L(G)}")#text(". As ")#mi("{\\phi_0}")#text(" is continuous, we can find an interval ")#mi("{I = [-T,T]}")#text(" small enough that ")#tao-math("{\\left\\| \\phi_0(t) \\right\\| \\leq \\epsilon}", block: false)#text(" for all ")#mi("{t \\in [-T,T]}")#text(". By the Heine-Borel theorem, it will suffice to show that the set")

#align(center)[#tao-fit-display[#mitex("B := \\{ \\phi \\in L(G): \\sup_{t \\in [-T,T]} d(\\phi(t),\\phi_0(t)) < \\epsilon \\}")]]

#text("is totally bounded. By the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(", it suffices to show that the family of functions in ")#mi("{B}")#text(" is ")#link("http://en.wikipedia.org/wiki/Equicontinuous")[#text("equicontinuous")]#text(".")

#text("By construction, we have ")#tao-math("{\\left\\| \\phi(t) \\right\\| \\leq 2\\epsilon}", block: false)#text(" whenever ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(". By the escape property, this implies (for ")#mi("{\\epsilon}")#text(" small enough, of course) that ")#tao-math("{\\left\\| \\phi(t/n) \\right\\| \\ll \\epsilon/n}", block: false)#text(" for all ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(" and ")#mi("{n \\geq 1}")#text(", thus ")#tao-math("{\\left\\| \\phi(t) \\right\\| \\ll \\epsilon \\left|t\\right| / T}", block: false)#text(" whenever ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(". From the homomorphism property, we conclude that ")#tao-math("{d(\\phi(t),\\phi(t^{\\prime})) \\ll \\epsilon \\left|t-t^{\\prime}\\right| / T}", block: false)#text(" whenever ")#tao-math("{\\left|t\\right|, \\left|t^{\\prime}\\right| \\leq T}", block: false)#text(", which gives uniform Lipschitz control and hence equicontinuity as desired. ")#mi("\\Box")

#text("We observe for future reference that the proof of the above lemma also shows that all one-parameter subgroups are locally Lipschitz.")

#text("Now we put a vector space structure on ")#mi("{L(G)}")#text(", which we define by analogy with the Lie group case, in which each tangent vector ")#mi("{X}")#text(" generates a one-parameter subgroup ")#mi("{t \\mapsto \\exp(tX)}")#text(". From this analogy, the scalar multiplication operation has an obvious definition: if ")#mi("{\\phi \\in L(G)}")#text(" and ")#mi("{c \\in {\\bf R}}")#text(", we define ")#mi("{c\\phi \\in L(G)}")#text(" to be the one-parameter subgroup")

#align(center)[#tao-fit-display[#mitex("c \\phi(t) := \\phi(ct)")]]

#text("which is easily seen to actually be a one-parameter subgroup.")

#text("Now we turn to the addition operation. In the Lie group case, one can express the one-parameter subgroup ")#mi("{t \\mapsto \\exp(t(X+Y))}")#text(" in terms of the one-parameter subgroups ")#mi("{t \\mapsto \\exp(tX)}")#text(", ")#mi("{t \\mapsto \\exp(tY)}")#text(" by the limiting formula")

#align(center)[#tao-fit-display[#mitex("\\exp(t(X+Y)) = \\lim_{n \\rightarrow \\infty} (\\exp(tX/n) \\exp(tY/n))^n.")]]

#text("In view of this, we would like to define the sum ")#mi("{\\phi+\\psi}")#text(" of two one-parameter subgroups ")#mi("{\\phi, \\psi \\in L(G)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(\\phi+\\psi)(t) := \\lim_{n \\rightarrow \\infty} (\\phi(t/n) \\psi(t/n))^n.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10")]#text(" ")#metadata(none) <tao-fd7275bbea343cb9700f>#text(" If ")#mi("{\\phi, \\psi \\in L(G)}")#text(", then ")#mi("{\\phi+\\psi}")#text(" is well-defined and also lies in ")#mi("{L(G)}")#text(".")
]

#emph[#text("Proof:")]#text(" To show well-definedness, it suffices to show that for each ")#mi("{t}")#text(", the sequence ")#mi("{(\\phi(t/n) \\psi(t/n))^n}")#text(" is a Cauchy sequence. It suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sup_{m \\geq 1} d( (\\phi(t/n) \\psi(t/n))^n, (\\phi(t/nm) \\psi(t/nm))^{nm}) \\rightarrow 0")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". By the continuity of multiplication, it suffices to show that there is some ")#mi("{\\delta > 0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sup_{m \\geq 1} \\sup_{1 \\leq n^{\\prime} \\leq \\delta n} d( (\\phi(t/n) \\psi(t/n))^{n^{\\prime}}, (\\phi(t/nm) \\psi(t/nm))^{n^{\\prime}m}) \\rightarrow 0")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("Since ")#mi("{\\phi,\\psi}")#text(" are locally Lipschitz, we can find a quantity ")#mi("{A}")#text(" (depending on ")#mi("{t, \\phi, \\psi}")#text(") such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\phi(t/n) \\right\\|, \\left\\| \\psi(t/n) \\right\\| \\ll A / n", block: true)]]

#text("for all ")#mi("{n}")#text(". From Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("8")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("d( \\phi(t/n) \\psi(t/n), (\\phi(t/nm) \\psi(t/nm)^m) ) \\ll m^2 (A/nm) (A/nm) = A^2 / n^2")]]

#text("if ")#mi("{m \\geq 1}")#text(" and ")#mi("{n}")#text(" is sufficiently large. Another application of Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("8")]#text(" then gives")

#align(center)[#tao-fit-display[#mitex("d( (\\phi(t/n) \\psi(t/n))^{n^{\\prime}}, (\\phi(t/nm) \\psi(t/nm)^{n^{\\prime}m}) ) \\ll m^2 (A/nm) (A/nm) = A^2 / n")]]

#text("if ")#mi("{m \\geq 1}")#text(", ")#mi("{n}")#text(" is sufficiently large, ")#mi("{1 \\leq n^{\\prime} \\leq \\delta n}")#text(", and ")#mi("{\\delta}")#text(" is sufficiently small depending on ")#mi("{A}")#text(". The claim follows.")

#text("The above argument in fact shows that ")#mi("{(\\phi(t/n) \\psi(t/n))^n}")#text(" is uniformly Cauchy for ")#mi("{t}")#text(" in a compact interval, and so the pointwise limit ")#mi("{\\phi+\\psi}")#text(" is in fact a uniform limit of continuous functions and is thus continuous. To prove that ")#mi("{\\phi+\\psi}")#text(" is a homomorphism, it suffices by density of the rationals to show that")

#align(center)[#tao-fit-display[#mitex("(\\phi+\\psi)( at ) (\\phi+\\psi)( bt ) = (\\phi+\\psi)( (a+b)t )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(\\phi+\\psi)(-t) = (\\phi+\\psi)(t)^{-1}")]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(" and all positive integers ")#mi("{a,b}")#text(". To prove the first claim, we observe that")

#tao-aligned(keep: true)[


#tao-math("(\\phi+\\psi)(at)  & = \\lim_{n \\rightarrow \\infty} (\\phi(at/n) \\psi(at/n))^n", block: true)



#tao-math(" & = \\lim_{n \\rightarrow \\infty} (\\phi(t/n) \\psi(t/n))^{an}", block: true)
]

#text("and similarly for ")#mi("{(\\phi+\\psi)(bt)}")#text(" and ")#mi("{(\\phi+\\psi)((a+b)t)}")#text(", whence the claim. To prove the second claim, we see that")

#tao-aligned(keep: true)[


#tao-math("(\\phi+\\psi)(-t)^{-1}  & = \\lim_{n \\rightarrow \\infty} (\\phi(-t/n) \\psi(-t/n))^{-n}", block: true)



#tao-math(" & = \\lim_{n \\rightarrow \\infty} (\\psi(t/n) \\phi(t/n))^n,", block: true)
]

#text("but ")#mi("{(\\psi(t/n) \\phi(t/n))^n}")#text(" is ")#mi("{(\\phi(t/n) \\psi(t/n))^n}")#text(" conjugated by ")#mi("{\\psi(t/n)}")#text(", which goes to the identity; and the claim follows. ")#mi("\\Box")

#mi("{L(G)}")#text(" also has an obvious zero element, namely the trivial one-parameter subgroup ")#mi("{t \\mapsto \\text{id}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#mi("{L(G)}")#text(" is a topological vector space.")
]

#emph[#text("Proof:")]#text(" We first show that ")#mi("{L(G)}")#text(" is a vector space. It is clear that the zero element ")#mi("{0}")#text(" of ")#mi("{L(G)}")#text(" is an additive and scalar multiplication identity, and that scalar multiplication is associative. To show that addition is commutative, we again use the observation that ")#mi("{(\\psi(t/n) \\phi(t/n))^n}")#text(" is ")#mi("{(\\phi(t/n) \\psi(t/n))^n}")#text(" conjugated by an element that goes to the identity. A similar argument shows that ")#mi("{(-\\phi) + (-\\psi) = -(\\phi+\\psi)}")#text(", and a change of variables argument shows that ")#mi("{(a\\phi) + (a\\psi) = a(\\phi+\\psi)}")#text(" for all positive integers ")#mi("{a}")#text(", hence for all rational ")#mi("{a}")#text(", and hence by continuity for all real ")#mi("{a}")#text(". The only remaining thing to show is that addition is associative, thus if ")#mi("{\\phi, \\psi, \\eta \\in L(G)}")#text(", that ")#mi("{((\\phi+\\psi)+\\eta)(t) = (\\phi+(\\psi+\\eta))(t)}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". By the homomorphism property, it suffices to show this for all sufficiently small ")#mi("{t}")#text(".")

#text("An inspection of the argument used to establish ")#link(<tao-fd7275bbea343cb9700f>)[#text("(10)")]#text(" reveals that there is a constant ")#mi("{A}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("d( (\\phi+\\psi)(t), (\\phi(t/n) \\psi(t/n))^n ) \\ll A^2 / n")]]

#text("for all small ")#mi("{t}")#text(" and all large ")#mi("{n}")#text(", and hence also that")

#align(center)[#tao-fit-display[#mitex("d( (\\phi+\\psi)(t/n), \\phi(t/n) \\psi(t/n) ) \\ll A^2 / n^2")]]

#text("(thanks to Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("8")]#text("). Similarly we have (after adjusting ")#mi("{A}")#text(" if necessary)")

#align(center)[#tao-fit-display[#mitex("d( ((\\phi+\\psi)+\\eta)(t), ((\\phi+\\psi)(t/n) \\eta(t/n))^n ) \\ll A^2 / n.")]]

#text("From Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("8")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("d( ((\\phi+\\psi)(t/n) \\eta(t/n))^n, (\\phi(t/n) \\psi(t/n)\\eta(t/n))^n ) \\ll A^2/n")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("d( ((\\phi+\\psi)+\\eta)(t), (\\phi(t/n) \\psi(t/n) \\eta(t/n))^n ) \\ll A^2 / n.")]]

#text("Similarly for ")#mi("{\\phi+(\\psi+\\eta)}")#text(". By the triangle inequality we conclude that")

#align(center)[#tao-fit-display[#mitex("d( ((\\phi+\\psi)+\\eta)(t), (\\phi+(\\psi+\\eta))(t)) \\ll A^2 / n;")]]

#text("sending ")#mi("{t}")#text(" to zero, the claim follows.")

#text("Finally, we need to show that the vector space operations are continuous. It is easy to see that scalar multiplication is continuous, as are the translation operations; the only remaining thing to verify is that addition is continuous at the origin. Thus, for every ")#mi("{\\epsilon > 0}")#text(" we need to find a ")#mi("{\\delta > 0}")#text(" such that ")#tao-math("{\\sup_{t \\in [-1,1]} \\left\\| (\\phi+\\psi)(t) \\right\\| \\leq \\epsilon}", block: false)#text(" whenever ")#tao-math("{\\sup_{t \\in [-1,1]} \\left\\| \\phi(t) \\right\\| \\leq \\delta}", block: false)#text(" and ")#tao-math("{\\sup_{t \\in [-1,1]} \\left\\| \\psi(t) \\right\\| \\leq \\delta}", block: false)#text(". But if ")#mi("{\\phi, \\psi}")#text(" are as above, then by the escape property (assuming ")#mi("{\\delta}")#text(" small enough) we conclude that ")#tao-math("{\\left\\| \\phi(t)\\right\\|, \\left\\|\\psi(t)\\right\\| \\ll \\delta \\left|t\\right|}", block: false)#text(" for ")#mi("{t \\in [-1,1]}")#text(", and then from the triangle inequality we conclude that ")#tao-math("{\\left\\| (\\phi+\\psi)(t) \\right\\| \\ll \\delta}", block: false)#text(" for ")#mi("{t \\in [-1,1]}")#text(", giving the claim. ")#mi("\\Box")

#text("As ")#mi("{L(G)}")#text(" is both locally compact, metrisable, and a topological vector space, it must be isomorphic to a finite-dimensional vector space ")#mi("{{\\bf R}^n}")#text(" with the usual topology (see ")#link("https://terrytao.wordpress.com/2011/05/24/locally-compact-topological-vector-spaces/")[#text("this blog post")]#text(" for a proof).")

#text("In analogy with the Lie algebra setting, we define the ")#emph[#text("exponential map")]#text(" ")#mi("{\\exp: L(G) \\rightarrow G}")#text(" by setting ")#mi("{\\exp(\\phi) := \\phi(1)}")#text(". Given the topology on ")#mi("{L(G)}")#text(", it is clear that this is a continuous map. Using Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("8")]#text(" one can see that the exponential map is locally injective near the origin, although we will not actually need this fact.")

#text("We have proved a number of useful things about ")#mi("{L(G)}")#text(", but at present we have not established that ")#mi("{L(G)}")#text(" is ")#emph[#text("large")]#text(" in any substantial sense; indeed, at present, ")#mi("{L(G)}")#text(" could be completely trivial even if ")#mi("{G}")#text(" was large. In particular, the image of the exponential map ")#mi("{\\exp}")#text(" could conceivably be quite small. We now address this issue. As a warmup, we show that ")#mi("{L(G)}")#text(" is at least non-trivial if ")#mi("{G}")#text(" is non-trivial:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" Suppose that ")#mi("{G}")#text(" is not a discrete group. Then ")#mi("{L(G)}")#text(" is non-trivial.")
]

#text("Of course, the converse is obvious; discrete groups do not admit any non-trivial one-parameter subgroups.")

#emph[#text("Proof:")]#text(" As ")#mi("{G}")#text(" is not discrete, there is a sequence ")#mi("{g_n}")#text(" of non-identity elements of ")#mi("{G}")#text(" such that ")#tao-math("{\\left\\|g_n\\right\\| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Writing ")#mi("{N_n}")#text(" for the integer part of ")#tao-math("{\\epsilon / \\left\\|g_n\\right\\|}", block: false)#text(", then ")#mi("{N_n \\rightarrow \\infty}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", and we conclude from the escape property that ")#tao-math("{\\left\\| g_n^{N_n} \\right\\| \\sim \\epsilon}", block: false)#text(" for all ")#mi("{n}")#text(".")

#text("We define the approximate one-parameter subgroups ")#mi("{\\phi_n: [-1,1] \\rightarrow G}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\phi_n(t) := g_n^{\\lfloor t N_n \\rfloor}.")]]

#text("Then we have ")#tao-math("{\\left\\|\\phi_n(t) \\right\\| \\ll \\epsilon \\left|t\\right| + \\frac{\\epsilon}{N_n}}", block: false)#text(" for ")#tao-math("{\\left|t\\right| \\leq 1}", block: false)#text(", and we have the approximate homomorphism property")

#align(center)[#tao-fit-display[#mitex("d( \\phi_n(t+s), \\phi_n(t) \\phi_n(s) ) \\rightarrow 0")]]

#text("uniformly whenever ")#tao-math("{\\left|t\\right|, \\left|s\\right|, \\left|t+s\\right| \\leq 1}", block: false)#text(". As a consequence, ")#mi("{\\phi_n}")#text(" is asymptotically equicontinuous on ")#mi("{[-1,1]}")#text(", and so by (a slight generalisation of) the Arzéla-Ascoli theorem, we may pass to a subsequence in which ")#mi("{\\phi_n}")#text(" converges uniformly to a limit ")#mi("{\\phi: [-1,1] \\rightarrow G}")#text(", which is a genuine homomorphism that is genuinely continuous, and is thus can be extended to a one-parameter subgroup. Also, ")#tao-math("{\\left\\|\\phi_n(1)\\right\\| = \\left\\|g_n^{N_n} \\right\\| \\sim \\epsilon}", block: false)#text(" for all ")#mi("{n}")#text(", and thus ")#tao-math("{\\left\\|\\phi(1)\\right\\| \\sim \\epsilon}", block: false)#text("; in particular, ")#mi("{\\phi}")#text(" is non-trivial, and the claim follows. ")#mi("\\Box")

#text("We now generalise the above proposition to a more useful result.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13")]#text(" ")#metadata(none) <tao-8e567ee3e03f4b0bf31a>#text(" For any neighbourhood ")#mi("{K}")#text(" of the origin in ")#mi("{L(G)}")#text(", ")#mi("{\\exp(K)}")#text(" is a neighbourhood of the identity in ")#mi("{G}")#text(".")
]

#emph[#text("Proof:")]#text(" We use an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=967314")[#text("of Hirschfeld")]#text(" (communicated to me by van den Dries and Goldbring). By shrinking ")#mi("{K}")#text(" if necessary, we may assume that ")#mi("{K}")#text(" is a compact star-shaped neighbourhood, with ")#mi("{\\exp(K)}")#text(" contained in the ball of radius ")#mi("{\\epsilon}")#text(" around the origin. As ")#mi("{K}")#text(" is compact, ")#mi("{\\exp(K)}")#text(" is compact also.")

#text("Suppose for contradiction that ")#mi("{\\exp(K)}")#text(" is not a neighbourhood of the identity, then there is a sequence ")#mi("{g_n}")#text(" of elements of ")#mi("{G \\backslash K}")#text(" such that ")#tao-math("{\\left\\|g_n\\right\\| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". By the compactness of ")#mi("{K}")#text(", we can find an element ")#mi("{h_n}")#text(" of ")#mi("{K}")#text(" that minimises the distance ")#mi("{d(g_n,h_n)}")#text(". If we then write ")#mi("{g_n = h_n k_n}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\|k_n\\right\\| = d(g_n,h_n) \\leq d(g_n,\\text{id}) = \\left\\|g_n\\right\\|", block: true)]]

#text("and hence ")#tao-math("{\\left\\|h_n\\right\\|, \\left\\|k_n\\right\\| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("Let ")#mi("{N_n}")#text(" be the integer part of ")#tao-math("{\\epsilon_n / \\left\\|k_n\\right\\|}", block: false)#text(", then ")#mi("{N_n \\rightarrow \\infty}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", and ")#tao-math("{\\left\\|k_n^{N_n} \\right\\| \\sim \\epsilon}", block: false)#text(" for all ")#mi("{n}")#text(".")

#text("Let ")#mi("{\\phi_n: [-1,1] \\rightarrow G}")#text(" be the approximate one-parameter subgroups defined as")

#align(center)[#tao-fit-display[#mitex("\\phi_n(t) := k_n^{\\lfloor t N_n \\rfloor}.")]]

#text("As before, we may pass to a subsequence such that ")#mi("{\\phi_n}")#text(" converges uniformly to a limit ")#mi("{\\phi: [-1,1] \\rightarrow G}")#text(", which extends to a one-parameter subgroup ")#mi("{\\phi \\in L(G)}")#text(".")

#text("In a similar vein, since ")#mi("{h_n \\in \\exp(K)}")#text(", we can find ")#mi("{\\psi_n \\in K}")#text(" such that ")#mi("{\\psi_n(1) = h_n}")#text(", which by the escape property (and the smallness of ")#mi("{K}")#text(" implies that ")#tao-math("{\\left\\| \\psi_n(t) \\right\\| \\ll t \\left\\| h_n\\right\\|}", block: false)#text(" for ")#tao-math("{\\left|t\\right| \\leq 1}", block: false)#text(". In particular, ")#mi("{\\psi_n}")#text(" goes to zero in ")#mi("{L(G)}")#text(".")

#text("We now claim that ")#mi("{\\exp( \\psi_n + \\frac{1}{N_n} \\phi )}")#text(" is close to ")#mi("{g_n}")#text(". Indeed, from Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("8")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("d( \\exp( \\psi_n + \\frac{1}{N_n} \\phi ), \\exp( \\psi_n ) \\exp( \\frac{1}{N_n} \\phi ) ) \\ll \\frac{1}{N_n} \\| h_n \\|.")]]

#text("Since ")#mi("{\\exp(\\psi_n) = h_n}")#text(", we conclude from the triangle inequality and left-invariance that")

#align(center)[#tao-fit-display[#tao-math("d( \\exp( \\psi_n + \\frac{1}{N_n} \\phi ), g_n) \\ll \\frac{1}{N_n} \\left\\| h_n \\right\\| + d( k_n, \\exp( \\frac{1}{N_n} \\phi ) ).", block: true)]]

#text("But from Lemma ")#link(<tao-2f8c0b475a71847a5766>)[#text("8")]#text(" again, one has")

#align(center)[#tao-fit-display[#mitex("d( k_n, \\exp( \\frac{1}{N_n} \\phi ) ) \\ll \\frac{1}{N_n} d( k_n^{N_n}, \\exp( \\phi ) ) = o( 1/N_n )")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("d( \\exp( \\psi_n + \\frac{1}{N_n} \\phi ), g_n) = o(1/N_n).")]]

#text("But for ")#mi("{n}")#text(" large enough, ")#mi("{\\psi_n + \\frac{1}{N_n} \\phi}")#text(" lies in ")#mi("{K}")#text(", and so the distance from ")#mi("{g_n}")#text(" to ")#mi("{K}")#text(" is ")#mi("{o(1/N_n) = o(d(g_n,h_n))}")#text(". But this contradicts the minimality of ")#mi("{h_n}")#text(" for ")#mi("{n}")#text(" large enough, and the claim follows. ")#mi("\\Box")

#text("We have some easy corollaries of this result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 14")]#text(" ")#metadata(none) <tao-a7f32380cf3336594523>#text(" ")#mi("{G}")#text(" is locally connected. In particular, the connected component ")#mi("{G^\\circ}")#text(" of the identity is an open subgroup of ")#mi("{G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 15 (Abelian case)")]#text(" ")#metadata(none) <tao-9bd79e9a2f1ccb9e2153>#text(" If ")#mi("{G}")#text(" is abelian, then ")#mi("{G}")#text(" is isomorphic to a Lie group. In particular, in the non-abelian setting, the centre ")#mi("{Z(G)}")#text(" of ")#mi("{G}")#text(" is a Lie group.")
]

#emph[#text("Proof:")]#text(" In the abelian case one easily sees that ")#mi("{\\exp}")#text(" is a homomorphism. Thus we see from Proposition ")#link(<tao-8e567ee3e03f4b0bf31a>)[#text("13")]#text(" that ")#mi("{G}")#text(" has locally the structure of a vector space, and the claim clearly follows in that case. ")#mi("\\Box")

#text("We are now finally ready to prove Theorem ")#link(<tao-dbb989e8b02ce27d11d4>)[#text("7")]#text(". By Corollary ")#link(<tao-a7f32380cf3336594523>)[#text("14")]#text(" we may assume without loss of generality that ")#mi("{G}")#text(" is connected. (Note that if a topological group ")#mi("{G}")#text(" is locally connected, and the connected component of the identity ")#mi("{G^\\circ}")#text(" is a Lie group, then the entire group a Lie group, because all outer automorphisms of ")#mi("{G^\\circ}")#text(" are necessarily smooth, as ")#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("discussed here")]#text(".)")

#text("Now we consider the adjoint action of ")#mi("{G}")#text(" on ")#mi("{L(G)}")#text(". If ")#mi("{g \\in G}")#text(" and ")#mi("{\\phi \\in L(G)}")#text(", we can define another one-parameter subgroup ")#mi("{\\text{Ad}_g(\\phi) \\in L(G)}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\text{Ad}_g(\\phi)(t) := g\\phi(t) g^{-1}.")]]

#text("As conjugation by ")#mi("{g}")#text(" is an automorphism, one easily verifies that ")#mi("{\\text{Ad}_g: L(G) \\rightarrow L(G)}")#text(" is linear, thus ")#mi("{\\text{Ad}}")#text(" is a map from ")#mi("{G}")#text(" to the finite-dimensional linear group ")#mi("{GL(L(G))}")#text(". One easily verifies that this map is continuous, and so ")#mi("{\\text{Ad}}")#text(" is a finite-dimensional linear representation of ")#mi("{G}")#text(". If ")#mi("{g}")#text(" is in the kernel of this representation, then by construction, ")#mi("{g}")#text(" centralises ")#mi("{\\exp(L(G))}")#text(", and thus by Proposition ")#link(<tao-8e567ee3e03f4b0bf31a>)[#text("13")]#text(", centralises an open neighbourhood of the identity in ")#mi("{G}")#text(". As we are assuming ")#mi("{G}")#text(" to be connected, we conclude that ")#mi("{g}")#text(" is central. Thus we see that the kernel of ")#mi("{\\text{Ad}}")#text(" is the center ")#mi("{Z(G)}")#text(", thus giving a short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow Z(G) \\rightarrow G \\rightarrow G/Z(G) \\rightarrow 0.")]]

#text("The adjoint representation ")#mi("{\\text{Ad}}")#text(" is a faithful finite-dimensional linear representation of ")#mi("{G/Z(G)}")#text(", and so ")#mi("{G/Z(G)}")#text(" is a Lie group by a theorem of von Neumann (discussed ")#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("here")]#text("). By Corollary ")#link(<tao-9bd79e9a2f1ccb9e2153>)[#text("15")]#text(", ")#mi("{Z(G)}")#text(" is a central Lie group. By a result of Kuranishi and Gleason (discussed ")#link("https://terrytao.wordpress.com/2011/06/07/central-extensions-of-lie-groups-and-cocycle-averaging/")[#text("here")]#text("), this implies that ")#mi("{G}")#text(" is itself a Lie group, as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" An alternate approach to Theorem ")#link(<tao-dbb989e8b02ce27d11d4>)[#text("7")]#text(" would be to construct a Lie bracket on ")#mi("{L(G)}")#text(", and then show that the multiplication law on ")#mi("{G}")#text(" is locally given by the Baker-Campbell-Hausdorff formula; we will discuss this approach in a sequel to this post.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bba6d64c6e86b206bc8206b472f52d0c3af622e795b2f4aa1066aed6ba7c5f6d-64670efe990936d97afac48c67b7d2e55e21fa39f82eea35613dcd34e2a4800e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-54028")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("Professor Tao, the link to “this previous post” in “The deduction of Theorem 1 from Theorem 2 proceeds using the Brouwer invariance of domain theorem and is discussed in this previous post” is broken. I suspect you have made a copy-and-pasting error. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gleason metric and CC distance | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-54062")[#strong[#text("Gleason metric and CC distance | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2011")])]

#text("[…] In the series of posts on Hilbert’s fifth problem, Terence Tao defines a Gleason metric, definition 4 here, which is a very important ingredient of the proof of the solution to H5 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ed6288e8669727851f80b88c0f19aa472d4acf91d66f3cb59d9668eb0bc3211-02872aadafb531d1c053c2820b868e3f677b2503e46ec9d9ed709b7a56c9925f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang M,")]], [#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-54131")[#strong[#text("Wolfgang M,")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2011")])]

#text("In the final paragraph and line of the proof for theorem 7, it says:")

#text("“By a result of Kakutani and Gleason (discussed here), this implies that is itself a Lie group, as required.”")

#text("The corresponding blogpost seems (?) to suggest the proof goes back to Kuranishi and Gleason:")

#text("“This result can be obtained by combining a result of Kuranishi with a result of Gleason;”")

#text("Is this a typo?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ed6288e8669727851f80b88c0f19aa472d4acf91d66f3cb59d9668eb0bc3211-02872aadafb531d1c053c2820b868e3f677b2503e46ec9d9ed709b7a56c9925f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang M,")]], [#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-54132")[#strong[#text("Wolfgang M,")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2011")])]

#text("Just noticed that the next post appears to answer the question in the affirmative,")

#text("“With this approach, one can avoid any appeal to von Neumann’s theorem and Cartan’s theorem (discussed in this post), or the Kuranishi-Gleason extension theorem (discussed in this post).”")

#text("W.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-54262")[#strong[#text("Eighth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2011")]

#text("[…] Tao: Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem, Hilbert’s Fifth Problem and Gleason metrics, The C^{1,1} Baker-Campbell-Hausdorff […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gleason’s lemma « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-56084")[#strong[#text("Gleason’s lemma « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2011")])]

#text("[…] real analytic regularity is relatively routine, with two different such approaches indicated in the preceding blog posts.) In particular, the easiest task to accomplish will be that of Proposition 10, which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of How not to get bored, by reading Gromov and Tao | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-62091")[#strong[#text("How not to get bored, by reading Gromov and Tao | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2011")])]

#text("[…] are some things that I understood from the posts of Tao, especially that a central concept is a Gleason metric and its relations with group commutators. In previous posts (last is this) I argue that Gleason […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Hilbert-Smith conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-66751")[#strong[#text("The Hilbert-Smith conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2011")])]

#text("[…] theory of locally compact groups (specifically, the Gleason-Yamabe theorem discussed in previous posts) and some results of Newman that sharply restrict the ability of periodic actions on a manifold to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Intrinsic characterizations of riemannian and sub-riemannian spaces (I) | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-146027")[#strong[#text("Intrinsic characterizations of riemannian and sub-riemannian spaces (I) | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2012")])]

#text("[…] Gleason metrics and Hilbert’s fifth problem. Let us compare this with the formulation of the solution of the Hilbert’s fifth problem by Terence Tao. THe problem is somehow similar, namely recover the differential structure of a Lie group from its […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f1dd58f13ff930bafea6595f5e3ca5d50db3a2ff624eb270c8cf99e37414765-2307910323607f5cd8e0028770cc1a50d6bce11405f003d3c913f5c01800698a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chunxiaoliu")]], [#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/#comment-474204")[#strong[#text("chunxiaoliu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("Reblogged this on ")#link("https://chunxiaoliu.wordpress.com/2016/11/09/hilberts-fifth-problem-and-gleason-metrics/")[#text("chunxiaoliu")]#text(" and commented:")#linebreak()#text(" The easy version of this question is: when a topological group is a Lie group?")
]
