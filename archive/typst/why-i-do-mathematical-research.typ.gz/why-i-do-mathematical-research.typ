// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/14/why-i-do-mathematical-research/
// Converted to Typst by tao2typ: "2026-10-14T15:21:19.440624+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Why I do mathematical research", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Why I do mathematical research")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/14/why-i-do-mathematical-research/")[#text("https://terrytao.wordpress.com/2026/09/14/why-i-do-mathematical-research/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://math.jhu.edu/~eriehl/")[#text("Emily Riehl")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Like many mathematicians, I was drawn to the field as a little girl by its aesthetics: questions that I found endlessly fascinating and arguments that struck me as delightful and elegant. As I grew older, I came to appreciate how personal mathematical aesthetics are. One of the great strengths of our community is the breadth of our collective view of what mathematics is. (Even better: those views are not static. My sense of what mathematics is has changed considerably in the 15 years since my PhD, but that’s a story for another time.)")

#text("The point of this preamble is to clarify that what follows is a personal view of the purpose of mathematical research, or more precisely one aspect of it. It would be too strong to speak of “the” purpose of mathematics, even using ")#link("https://ncatlab.org/nlab/show/generalized+the")[#text("category theorists’ “the”")]#text(", so I’ll instead describe ")#emph[#text("a")]#text(" purpose of mathematics, focusing on one particular perspective.")

#metadata(none) <tao-61f6ca79212ad2aae4ba>

#text("Of the many purposes of mathematics, my favorite is to search for the simplest explanation of a particular phenomenon. This often requires inventing a clarifying abstract language to isolate a common pattern from distracting specifics: not necessarily the maximal level of generality but the “right” one. As with mathematical aesthetics, the ")#emph[#text("simplest")]#text(" proof, ")#emph[#text("most clarifying")]#text(" abstraction, and ")#emph[#text("right")]#text(" level of generality are also matters of taste — and that’s a good thing! While mathematicians tend to agree about what’s true and false, we have countless different opinions about what is intuitive or interesting. (I take a similar relativist view of the foundations of mathematics, preferring to occupy a mathematical multiverse — again a topic for another time.)")

#text("To give an example, when I was first learning about sets and functions, it really bothered me that the inverse image preserves both unions and intersections of subsets, while the direct image preserves only unions. The direct image seemed simpler to define, so why was its behavior more complicated? Several years later I learned that the inverse image can be regarded as a functor between powersets, and that functor admits both right and left adjoints, while the direct image only admits a right adjoint. Since left adjoints preserve colimits and right adjoints preserve limits — by a proof that strikes me as straight from the book, expressed exactly at the right level of generality — I now consider my set-theoretic confusion resolved. (Your mileage may vary.)")

#text("My mathematical tastes tend towards this sort of “abstract nonsense” (a phrase that, like “queer,” is often used affectionately by insiders). Mathematics like this is sometimes called “theory building,” whose aim is to make it easier for more people to hold increasingly complicated mathematical thoughts in their heads. (Bill Thurston, in his famous essay “On proof and progress in mathematics,” offers ")#link("https://arxiv.org/html/math/9404236v1")[#text("manifolds")]#text(" as an example of a unifying definition that makes insights easier to communicate to non-experts.) As Michael Atiyah put it in “")#link("https://global.oup.com/academic/product/michael-atiyah-collected-works-9780198532750")[#text("How research is carried out")]#text("“:")

#emph[#text("The aim of theory really is, to a great extent, that of systematically organizing past experience in such a way that the next generation, our students and their students and so on, will be able to absorb the essential aspects in as painless a way as possible, and this is the only way in which you can go on cumulatively building up any kind of scientific activity without eventually coming to a dead end.")]

#text("It’s not always obvious from the outset what the long-term aesthetic value of a newly proposed theory will be. The two contributions that I am most proud of are the theory of ")#link("https://ncatlab.org/nlab/show/infinity-cosmos")[#mi("{\\infty}")#text("-cosmoi")]#text(", developed with ")#link("https://dom-verity.github.io/")[#text("Dominic Verity")]#text(", and ")#link("https://ncatlab.org/nlab/show/simplicial+type+theory")[#text("simplicial type theory")]#text(", introduced in joint work with ")#link("https://home.sandiego.edu/~shulman/")[#text("Mike Shulman")]#text(". In both cases, I think our most important contribution is not the specific axiomatization — there are good reasons to tweak the axioms, and others have since extended both theories productively — but the accompanying methodology and proof techniques. (As ")#link("https://www.dpmms.cam.ac.uk/~wtg10/2cultures.pdf")[#text("Tim Gowers notes")]#text(", theory building and problem solving aren’t as far apart as they are sometimes thought to be.)")

#text("I think what Atiyah means by “eventually coming to a dead end” is something like the aftermath of Babel, where the frontiers of mathematics have extended so far in so many directions that ")#link("https://www.science.org/doi/10.1126/science.aec9014")[#text("experts in different fields are no longer able to talk to one another")]#text(". I am not suggesting that we need to pace the frontier of mathematical discovery to let those attempting to consolidate these findings catch up. But I do think that time spent reaching back to bring others up to the frontier is as valuable as time spent pushing it forward.")

#text("I have been ")#link("https://www.sciencefriday.com/segments/world-models-for-robots-ai-math/")[#text("working on a metaphor")]#text(" to help describe the mathematical universe to the general public: mathematicians are simultaneously constructing and exploring a mansion so vast that no architect has seen the floor plans and no contractor is directing the work. Instead, individuals and small teams wander down dark corridors to see whether a stuck door can be opened with a bit of force applied in the right place, or with a key someone has just found. Opening a new door is cause for celebration, but the work is just beginning. Someone needs to go inside to reinforce the ceiling and try to turn on a light; someone needs to see whether the door opens onto a closet or an undiscovered wing of the building; and someone needs to relay the message to teams in nearby hallways and on to whoever is drawing the map.")

#text("The impetus for that radio conversation and for writing down these thoughts is the rapid advance of AI’s mathematical capabilities over the past several months. Our community is now facing the kind of shock that has confronted countless other occupations. But at the same time, as mathematicians, we are part of a very long conversation that has persisted for millennia, through no shortage of upheaval, and the community it has produced is as robust as it has ever been. It’s hard to predict what the future might bring, but I plan to keep searching for better ways for us to talk about mathematics with each other.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/14/why-i-do-mathematical-research/#comment-695264")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("This post is gold, it reminds me why I fell in love with mathematics. Thank you so much")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/14/why-i-do-mathematical-research/#comment-695312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#strong[#emph[#text("As Steve Jobs stated in his Stanford speech, ")]]

#strong[#emph[#text("“")#text("The only way to do great work is to love what you do")#text("” ")]]

#strong[#text("not just to feed ego, out of sense of insecurity.")]

#strong[#text("X -VIII")]

#link("https://news.stanford.edu/stories/2005/06/youve-got-find-love-jobs-says")[#text("https://news.stanford.edu/stories/2005/06/youve-got-find-love-jobs-says")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/14/why-i-do-mathematical-research/#comment-695461")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Our community is now facing the kind of shock ….. ")#linebreak()#text("But at the same time, as mathematicians we are part of a very long conversation that has persisted for millennia, through no shortage of upheaval, and the community it has produced is as robust as it has ever been. ")#linebreak()#text("It’s hard to predict what the future might bring, but I plan to keep searching for better ways for us to talk about mathematics with each other.")

#text("Well put; this supports and inspires a forward-looking vision for mathematical research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/560f4a91a5cd50f865eb38fc8a2e6908c92821fafdf3146d7b460db7e1fdbada-91bce0fdcb860de8cfba0d1ae6258a996852c82272810f0864cfa0a031eeeaf9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of billy leblanc")]], [#link("https://terrytao.wordpress.com/2026/09/14/why-i-do-mathematical-research/#comment-695482")[#strong[#text("billy leblanc")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I really like your metaphore.")
]
