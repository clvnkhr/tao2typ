// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/23/headlines-and-inside-stories-understanding-and-trust-in-ai-for-mathematics-science-and-engineering/
// Converted to Typst by tao2typ: "2026-10-14T11:20:20.206995+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Headlines and inside stories: understanding and trust in AI for mathematics, science, and engineering", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Headlines and inside stories: understanding and trust in AI for mathematics, science, and engineering")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/23/headlines-and-inside-stories-understanding-and-trust-in-ai-for-mathematics-science-and-engineering/")[#text("https://terrytao.wordpress.com/2026/09/23/headlines-and-inside-stories-understanding-and-trust-in-ai-for-mathematics-science-and-engineering/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.gps.caltech.edu/people/tapio-schneider")[#text("Tapio Schneider")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("[This will be cross-posted on the ")#link("https://clima.caltech.edu/category/blog/")[#text("CliMA blog")]#text(".]")

#text("The apparent proof of finite-time blow-up of the forced Navier-Stokes equation, ")#link("https://openai.com/index/navier-stokes-solution/")[#text("announced by OpenAI")]#text(" on September 8, has brought into focus a debate about the role of AI in mathematics. The proof was produced with a system of some 10,000 AI agents that explored many approaches in parallel; it was then formalized and verified in Lean. The formal verification supports its correctness, but mathematicians are still working to digest it. A proof settles the truth value of a statement, but Terry Tao and others have argued that this is only part of the point of proofs; the other part is to advance our conceptual understanding of “")#link("https://mathandai.org/")[#text("basic structures of shapes, numbers, and natural phenomena")]#text(".” As Yehuda Rav put it a quarter-century ago, “")#link("https://doi.org/10.1093/philmat/7.1.5")[#text("theorems are the headlines, proofs are the inside story")]#text(".” A proof that is correct but incomprehensible, or undigested by the mathematical community, gives us the headline without the story. The issue is not whether the prover is a human or a machine, but whether the reasoning advances our collective understanding of methods and structures, which can spur new thinking and further advances. As ")#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/")[#text("Timothy Gowers")]#text(" has noted, the inadequate AI-generated write-ups of proofs are likely a temporary annoyance.")

#metadata(none) <tao-4aa599b2bb0295859433>

#text("I want to argue that the same point about understanding holds in the natural sciences and engineering, where it also has intrinsic value and, in addition, acquires instrumental value when predictions must be trusted before they can be verified empirically. One role of science is what ancient philosophers called ")#link("https://plato.stanford.edu/entries/episteme-techne/")[#text("episteme")]#text(", roughly explanatory understanding; here, understanding is the goal itself. Another role is ")#link("https://plato.stanford.edu/entries/episteme-techne/")[#text("techne")]#text(", roughly the craft of predicting and making: forecasting how natural or engineered systems will behave under circumstances not yet observed. Whether the two roles can be separated depends on how easily predictions can be checked. When they can, techne can stand on its own. A black-box AI weather prediction model can predict tomorrow’s weather, and we can trust it because its forecasts can be checked every day. Techne can then also serve episteme as an instrument. For example, ")#link("https://deepmind.google/science/alphafold/")[#text("AlphaFold")]#text(" predicts 3D protein structures without providing explanations. But its predictions can be checked against experimentally determined structures, and they have become invaluable for understanding how drugs bind to their targets. Episteme and techne become inseparable when predictions must be acted upon, and hence trusted, before they can be empirically verified, because verification is too slow, costly, or dangerous, as in projecting climate change decades ahead or designing an aircraft. In those cases, an auditable causal chain from assumptions and input data to the predicted outcomes is what makes predictions trustworthy, and this constrains how AI can be used.")

#text("The Navier-Stokes equation, which describes fluid flow, is a good example, as it is at the heart not only of a Millennium Prize problem but also of aircraft design and climate prediction. The claimed result says that a fluid starting from rest, driven by just the right smooth stirring, develops an infinite velocity spike in finite time while its total kinetic energy remains bounded; the forcing is constructed to sustain the collapse. (The unforced version of the problem, whether smooth solutions exist for all time without external forcing, remains open.) Despite the mathematical singularity, nothing infinite happens physically: the incompressible equation stops being valid once energy concentrates at very small scales, where compressibility and molecular effects take over, as has long been known. By contrast, in turbulence, viscosity dissipates energy at a small but finite scale (the Kolmogorov scale), and the continuum description is valid across all scales of motions. Therefore, the result says little about how we model, predict, and understand the physical phenomenon of turbulence, which is likewise a solution of the Navier-Stokes equation, and one that, unlike finite-time blow-up, is ubiquitously realized.")

#text("The Navier-Stokes equation governs the flow and turbulence that control lift and drag around an aircraft wing, cloud formation in the atmosphere, and mixing in the oceans. In both aircraft design and climate prediction, verification comes late or is difficult and expensive. An aircraft is flight-tested only after it is built; a projection of how extreme rainfall statistics intensify in the coming decades must inform stormwater infrastructure that is built now but will likely be put to the extreme test only decades later. Such predictions earn trust not by end-to-end verification but by being the output of an auditable chain stretching from inputs (design parameters, atmospheric composition) to outcomes, whose links have known limits of validity and can be tested individually. Computational fluid dynamics (CFD) solves the Navier-Stokes equation together with additional equations (e.g., for thermodynamics) numerically. Its numerical methods for the resolved scales are based on established theories of stability, consistency, and convergence, and its subgrid-scale models for unresolved turbulence rest on plausible assumptions of universality at small scales (e.g., local isotropy) that can be tested separately against high-resolution simulations or laboratory experiments with canonical flows. Understanding and auditability of the individual links are what allow the chain as a whole to be trusted beyond the distribution of large-scale cases already observed, such as the present climate or existing aircraft wing designs.")

#text("Contrast that with end-to-end AI methods for weather prediction. Daily empirical verifiability suffices to establish trust in their forecasts. However, they do not come with a stability, consistency, and convergence theory (no analog of von Neumann stability analysis or the Lax equivalence theorem has been established for them), and how an initial condition becomes a forecast is difficult to audit. This is inconsequential for forecasting a few days ahead, where the forecasts can be checked daily. But it does matter for climate projection, which is a different task: predicting how weather statistics change over decades in response to a forcing such as increased greenhouse gas concentrations. An end-to-end model can learn the day-to-day evolution of weather states in today’s climate, but it contains no pathway through which greenhouse gases alter this evolution; their concentrations are typically not among its inputs, and if they were, no observations exist to learn about the response. The causal chain from greenhouse gases to their effects on radiative transfer, temperature, and winds, represented in physics-based models through their equations, is absent. Additionally, such models do not enforce conservation laws, for example of energy, so long integrations can drift by accumulating errors (e.g., in temperature). We would not currently trust them to project how the climate system responds to previously unobserved changes in the concentration of greenhouse gases over decades. Nor would we trust an AI surrogate of CFD simulations to certify an aircraft of novel shape. AI surrogates are used to explore and narrow down design spaces quickly, but the final assessment returns to established CFD methods or wind tunnel experiments, whose errors are controlled and whose steps are auditable.")

#text("So how do we best use AI in cases where episteme and techne combine, where understanding is essential for trust because predictions are difficult to verify? An answer suggested by the preceding argument is to embed AI at the links in the chain where trust can be earned by empirical verification. Concretely, use AI inside auditable scaffolds, such as physical conservation laws. Then use numerical methods with controlled errors to solve, e.g., the Navier-Stokes equation on the resolved large scales, while learning closure models for the unresolved subgrid scales from data, where some universality assumptions are defensible and individually testable. The rationale, in the case of the climate system, is that the large scales are where climate change moves the system out of the current distribution, whereas small-scale physics obeys the same local laws in a warmer or colder climate as in today’s. For an aircraft wing of novel shape, similarly, the geometry may be new but the functional relation between larger-scale conditions and the small-scale turbulence around it is not. The scaffold thus guides the extrapolation on the basis of the known equations, rather than with end-to-end models tied to the data available today.")

#text("Closures must be learned as functions of the resolved state, and extrapolation problems may reappear if the conditions for which data are available do not span the range of conditions for which predictions are needed (e.g., the temperature and humidity regimes in which cloud turbulence has been sampled, or the pressure gradients along a wing of novel shape). This can be mitigated with established tools, such as local high-resolution simulations for offline calibration and uncertainty quantification. Climate models and CFD codes have been built from resolved dynamics with embedded closures for decades. AI now enables a wider and faster search. Neural network closures can be individually tested and, to some extent, interpreted. Symbolic regression, which learns equations by selecting terms from a dictionary, as in ")#link("https://arxiv.org/abs/1605.06682")[#text("SINDy")]#text(", can sometimes produce closures that are more easily interpretable. AI agents are beginning to run the closure search in a closed loop, proposing symbolic closures, testing them against high-resolution simulations, observations, or experiments, and revising them. When this is successful, the resulting closure can be audited and, after the fact, understood.")

#text("This closed loop is similar to how AI is used in mathematics. In both cases, a verifier is used for checking: Lean for proofs; high-resolution simulations, observations, or experiments for turbulence closures. In the case of mathematics, the checks are complete; in the case of turbulence closures, they are limited to the conditions covered, so trust is restricted to the tested conditions. AI can accelerate this program by searching a larger space of possible closures or proof strategies than can be explored by humans in the same time. Once candidates have passed the checks, they become new objects for human study. In this way, understanding (episteme) and prediction (techne) improve together and reinforce each other, with humans, for now, remaining essential for extracting understanding and building trust in the end result: for writing the story behind the headline.")

#text("I thank Thomas Müller for pointing me to the paper by Yehuda Rav, and Thomas and my ")#link("https://clima.caltech.edu/")[#text("CliMA")]#text(" colleagues for discussions of the topics here over several years. I used AI for copy-editing.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/23/headlines-and-inside-stories-understanding-and-trust-in-ai-for-mathematics-science-and-engineering/#comment-696280")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("I’m curious: What do people think a neurosymbolic AI would accomplish with an equivalent amount of R&D and compute?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/23/headlines-and-inside-stories-understanding-and-trust-in-ai-for-mathematics-science-and-engineering/#comment-696297")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("It would be easier to verify and trust. However, there may still be hardware failures that creep into solutions and errors that compound.")

#text("10,000 agents running on thousands of GPUs for 88 continuous hours without a hardware failure or small errors compounding into larger ones is statistically impossible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9aac05a558797d32c15f55d878a48d42da70b746702d86f0d119ed7c3d5d3f7-271938281befc09d4e62e209f9ef583576efda8ebe21909421f3a2ddbe083be5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/09/23/headlines-and-inside-stories-understanding-and-trust-in-ai-for-mathematics-science-and-engineering/#comment-696305")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("I really like this overall methodology for thinking about the problem. I think this methodology will be successful in the end, because it starts to get at a very important underlying question: what ")#emph[#text("precisely")]#text(" is the difference between pure mathematics on the one hand, and empirical science/engineering on the other?")

#text("This is of course a question that scratches at deeper philosophical questions, like the difference between a-priori and a-posteriori propositions, and synthetic, vs analytic propositions. But the question itself does not necessarily rely on these deeper philosophical questions.")

#text("That said my main issue is a subtle one: it is not that I think you have said anything I strongly disagree with per se, but more that I feel as though the answer to that specific question has been dodged here, and therefore renders your conclusion misleading.")

#text("This is in no way specific to this post, I just feel as though I have seen a conflation of science and mathematics in the discussion around AI, and have come to the conclusion that whether or not mathematics and science should be conflated, or whether there is any difference between mathematical understanding and scientific understanding, is probably the source of much of the controversy surrounding AI and mathematics. In particular, the")#emph[#text(" ")]#text("methodology")#emph[#text(" ")]#text("or ")#emph[#text("way ")]#text("we should be arriving at knowledge in the two disciplines is very different, and I think most people would agree. But how?")

#text("To me, mathematical")#emph[#text(" ")]#text("trust (in pure mathematics) is a much higher standard than scientific or empirical trust, by definition. In other words, without this much higher standard, there is no such thing as pure mathematics as a discipline at all: the very act of doubting this distinguishing feature of pure mathematics destroys pure mathematics as a discipline entirely. So in order to have a discipline of pure mathematics at all, we ")#emph[#text("must ")]#text("have a higher standard of trust than is typically employed in pure math.")

#text("This point may seem tangential at first, but if you accept it, you you must apply your own analysis of “trust” to the proof verifiers themselves, and in my opinion, Lean proof verification does not survive this analysis, by your own argumentation. In other words, we have a kind of infinite regress: you propose that if all links in the chain are ‘auditable’, then we can trust the entire chain. But what audits the auditer?")

#text("This may seem rather nitpicky, but this is why I brought up the above points about mathematical trust, and the difference between pure mathematics and science, and a-priori vs a-posteriori knowledge. I think whether or not you agree that this is a valid point to make depends on your opinion on these matters.")

#text("The issue for me is that ")#emph[#text("pure mathematics is nitpicky by definition. ")]#text("It is about a-priori knowledge, so that there are no auditers, there are only raw mathematical truths that are directly observed. If it is not about this, then it has no distinguishing features.")

#text("So what I am saying here is that your essay is actually about ")#emph[#text("science")]#text(", it is ")#emph[#text("not ")]#text("about pure mathematics. I think the loop you propose at the end is not a mathematical one, it is a scientific one. I think such analysis will be important for scientists, but it is not the nature of how mathematical truth is arrived at.")

#text("In other words ")#emph[#text("the ability to trust the truth of some claim independently of any authority or empirical observation is the very definition of mathematical understanding")]#text(". So I am making a somewhat strong claim: that if a proof does not meet the standard of being")

#list(
[#text("entirely understandable by a single mathematician")],
[#text("establish the truth of some mathematical claim independently of any authority or empirical observation: as a-priori knowledge.")]
)

#text("then it is not a proof at all, even if it is verified by a proof checker.")

#text("This may seem rather uncomfortable, for two reasons")

#enum(start: 1, 
[#text("Because it rules out many existing proofs as mathematical proofs, even many proofs discovered before the advent of AI, such as the proof of the 4 color theorem, or the classification of finite simple groups, because neither can be held in the head of a single mathematician at once, and are thus not utterly convincing of the truth of the claim: it is not a-priori in practice.")],
[#text("It may also seem uncomfortable because this distinction is “vague”.")]
)

#text("Regarding the first point of discomfort, I think this discomfort only comes when you think that this implies these results are not valuable. These results ")#emph[#text("are")]#text(" extremely valuable, but are simply in a different category than pure mathematics. In the context of pure mathematics, I think such problems should be considered “open” in our new paradigm. Call such proofs “applied”, and other kinds of proofs “pure”. Perhaps there is a suitable notion of “independence” that can be formalized in this context: that some results have no “pure” proof in a specific formal system, and thus have no way of being proven in a standard system using “pure” mathematics. This, in my opinion, would lead to far more understanding. In such contexts where we produce “applied” proofs that do not meet the above two criteria, we should still consider the problem open until a “pure” proof is found, or we have a “pure” proof that none exist. Creating some formal distinction between “pure” and “applied” proofs seems almost impossible at first, but I am increasingly of the opinion that such a formal distinction is possible: which leads me to the second point.")

#text("Regarding the second point of discomfort, I think this is where the concept of mathematical truth plays a crucial role. If, instead of defining math in terms of formal proofs, we define math in terms of ")#emph[#text("truth")]#text(", then we have a far more precise way of dealing with meta-questions about the future of mathematics, because unlike proofs, ")#emph[#text("truth ")]#text("is independent of a specific formal system. This is because truth gives us a relatively formal way of talking about properties that truth must satisfy, and several formal theories of truth at our disposal (Tarski’s original correspondence theory – and within this several possible sub theories depending on what kind of model you think is the ‘true’ model, Kripke’s theory of truth, Paraconsistent theories of truth, situation theory, revision theory, and probably others I dont know about or that have not been discovered yet). Moreover, might we find some more commonalities between all of them? New properties of truth that help us in our current crisis?")

#text("Then instead of defining mathematics in terms of the somewhat vague notion of mathematical understanding (which may be accidentally conflated with e.g. scientific understanding) we should redefine mathematics as the more refined notion of the establishment and discovery of mathematical truth, for which a ")#emph[#text("formal ")]#text("proof is neither necessary (since a claim can be true even if it is not provable, and we may establish the truth of some mathematical claim in some informal way, e.g. how the univalence axiom seems true ")#link("https://en.wikipedia.org/wiki/Proofs_and_Refutations#Method")[#text("in some sense")]#text(", even if we cannot prove it) nor sufficient (since the mere production of, e.g. a lean proof on its own does not seem to establish a-priori knowledge if it does not fit into the mind of any mathematician).")

#text("So, in some sense I find the most misleading claim in your post to be this one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A proof settles the truth value of a statement")
]

#text("This depends heavily on what you mean by a “proof” and what your specific philosophy of mathematics is. If, for example, you think that ")#emph[#text("only ")]#text("a proof settles the truth value of a mathematical statement, and you think that an inconsistent system may prove untrue statements, then you also have to accept that a proof only ")#emph[#text("maybe ")]#text("settles the truth value of a statement, because of Gödel’s second incompleteness theorem.")

#text("We only establish the truth value of a statement from a “pure” proof, as I have defined it above (this follows essentially by definition, since establishing the truth value requires the establishment of a-priori knowledge, which cannot be attained empirically).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/23/headlines-and-inside-stories-understanding-and-trust-in-ai-for-mathematics-science-and-engineering/#comment-696361")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#list(
[#text("entirely understandable by a single mathematician")],
[#text("establish the truth of some mathematical claim independently of any authority or empirical observation: as a-priori knowledge.")]
)

#text("Yes. I agree.")

#text("For me, the four-color theorem is not proven. I know it is ‘true,’ but it is not proven (to me) because I don’t have a simple way to have that epiphany. You would think knowing something is true or false would motivate people even more to find a simple and elegant proof. I know the Riemann hypothesis is likely true because computers have done so much numerical analysis.")

#text("Maybe we are missing an entire branch of mathematics, like how people were stuck until the invention of complex numbers.")

#text("For the Navier-Stokes proof. I cannot shake the feeling it hallucinated a proof because OpenAI was desperate to match Anthropic’s attempt at the Riemann hypothesis. In the math I worry, they conflate definitions to distort the truth a way to optimize passing a LEAN checker through continuous changing of definitions until it passes. I have seen beautiful proofs, and I have seen proofs that leave me thinking, “I don’t like this step, but I cannot explain why.”")

#text("In the Navier-Stokes proof, they use an offset to keep a point of zero velocity slightly off the origin, and it is needed to drive amplification in the z direction to diverge. Without 0 < j < 0.05, it breaks down. It biases fluid flow in one direction. It feels like they are laying down a velocity source without a velocity sink, but they try to hide it by making it part of a scalar constant. They also keep the energy bounded as in goes to zero as velocity diverges but velocity depends on volume and time and then switches to time at the singularity.")

#text("A slop grenade, uncanny valley, or mathslop is a better description. If AI be imes ubiquitous then how can we know something is proven if people can disable guardrails to force it to pass?")
]
]
