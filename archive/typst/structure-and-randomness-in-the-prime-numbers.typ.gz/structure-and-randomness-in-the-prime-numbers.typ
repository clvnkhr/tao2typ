// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/
// Converted to Typst by tao2typ: "2026-10-14T16:35:11.989244+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Structure and randomness in the prime numbers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Structure and randomness in the prime numbers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/")[#text("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This Thursday I was at the ")#link("http://www.science.usyd.edu.au/news/")[#text("University of Sydney")]#text(", Australia, giving a public lecture on a favourite topic of mine, “")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/02/structure-and-randomness-in-the-prime-numbers.ppt")[#text("Structure and randomness in the prime numbers")]#text("“. My ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/02/structure-and-randomness-in-the-prime-numbers.ppt")[#text("slides here")]#text(" are a merge between ")#link("http://www.math.ucla.edu/%7Etao/preprints/Structure%20and%20Randomness%20in%20the%20prime%20numbers.ppt")[#text("my slides")]#text(" for a ")#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/")[#text("Royal Society meeting")]#text(" and the ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/primes.pdf")[#text("slides")]#text(" I gave for the ")#link("http://www.calendar.ucla.edu/event_detail.cfm?MeetingID=123080")[#text("UCLA Science Colloquium")]#text("; now that I figured out to use Powerpoint a little bit better, I was able to make the latter a bit more colourful (and the former less abridged).")

#heading(level: 1)[#text("Comments (76)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a31a82c10f6c0c0fb72e58403deed3a1a817f3e10e81bf7290d0b466929c4e3f-9fcb3f90b882e997de502a07b649fecc68c20a8748676d1893e77ec08d2ea72a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete Quinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-49512")[#strong[#text("Pete Quinn")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2011")])]

#text("If anyone is interested, I’ve tried to explain the ideas more concisely in the form of a draft paper. Note it’s written by an engineer, not a mathematician, and therefore is written intuitively in the way the ideas developed, but not necessarily in a particularly elegant fashion.")

#link("http://petequinnramblings.wordpress.com/2011/01/09/draft-paper-on-patterns-in-prime-numbers/")[#text("http://petequinnramblings.wordpress.com/2011/01/09/draft-paper-on-patterns-in-prime-numbers/")]

#text("I’d appreciate if anyone could tell me if the ideas have been published before, and please note it’s a rough draft, so references in particular need to be tightened up, and the formatting is a little icky.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0441ad4120474238d4c28fe45ebc4c49615972e68d2c21e02af4e0916a90d24d-9d67c541c41d96a80fb7f409d50bfba408de7f6a48f4cce706ad952021426151.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hugh")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-49517")[#strong[#text("Hugh")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2011")])]

#text("Sorry, the attempt twin prime proof is here:")

#link("http://barkerhugh.blogspot.com/2011/01/twin-primes-and-polignac-conjecture.html")[#text("http://barkerhugh.blogspot.com/2011/01/twin-primes-and-polignac-conjecture.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/695de786c9d393fce34bec65916413ba358609668cf188a2788feeefc47652db-3bc56624561ed7ca30bebf54d2185d31e3d2708ba55bd810ad2e339f3f8ca6c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mobiusfunction")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-50463")[#strong[#text("mobiusfunction")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")])]

#text("Two recurrences:")#linebreak()#text(" T(1,1)=1, n>1: T(n,1)=0, k>1: T(n,k) = (0 + (sum from i = 1 to k-1 of T(n-i,k-1))) mod 2.")

#text("T(1,1)=1, n>1: T(n,1)=0, k>1: T(n,k) = (1 + (sum from i = 1 to k-1 of T(n-i,k-0))) mod 2.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://mobiusfunction.wordpress.com/2011/02/25/mahonian-numbers-modulo-2/")[#text("Mahonian numbers modulo 2")]
]

#link("http://mobiusfunction.wordpress.com/2011/02/25/mahonian-numbers-modulo-2/")[#text("Mahonian numbers mod 2")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-50926")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2011")])]

#text("Hopefully this is not seen as using up unnecessary bandwidth.")

#text("Acknowledging again this is just a bit of a hobby project, for fun. We’ve been playing with this a little further, and can offer a couple of observations perhaps a little more concisely.")

#text("Within any primorial, there is a symmetric pattern of “non-primes” that repeats for all repetitions of that primorial to infinity. These numeric positions can never be prime, as they all represent multiples of primes (namely the factors of that primorial). There is also an asymmetric, non-repetitive component of non-primes within each primorial. This asymmetric component represents all additional “non-primes” that need to be deleted to leave behind only primes.")

#text("The repetitive pattern, whose symmetry turns out to be fairly easy (I think) to prove, involves only the primes that are factors of the primorial. The asymmetric, non-repetitive, component involves (prime) multiples of all primes higher than the prime factors but less than the square root of the primorial.")

#text("Each of the higher primes not involved in the symmetric pattern within a primorial has a repetitive, symmetric pattern that eventually emerges as the numbers get high enough. But this does not emerge until you reach the first primorial involving that prime as a factor.")

#text("Of interest (if perhaps only to me), is there are “long” sequences of non-primes leading up to and following every primorial, and every multiple of every primorial. If the nth primorial is Pn#, then (Pn# – 1) and (Pn# + 1) could be prime (common knowledge), but every other number between (xPn# – P(n+1)+1) and (xPn# + P(n+1)-1) must not be prime, where x is some arbitrary integer (also, I think, fairly simple to prove). So if for some reason you need an arbitrarily long string of sequential non-primes, simply go to the primorial corresponding to the closest higher prime (or any multiple thereof).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/695de786c9d393fce34bec65916413ba358609668cf188a2788feeefc47652db-3bc56624561ed7ca30bebf54d2185d31e3d2708ba55bd810ad2e339f3f8ca6c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-51747")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2011")])]

#text("The prime zeta function (Wikipedia) is defined as:")#linebreak()#text(" ")#mi("P(s)=\\sum\\limits_{p\\,\\in\\mathrm{\\,primes}} \\frac{1}{p^s}")

#text("It is known that:")#linebreak()#text(" ")#mi("\\log(\\zeta(s))=\\sum\\limits_{n=1}^\\infty \\frac{\\Lambda(n)}{\\log(n)}\\frac{1}{n^{s}}")

#text("We may consider:")#linebreak()#text(" ")#mi("a_n=\\prod\\limits_{d\\mid n} \\frac{\\Lambda(d)}{\\log(d)}")#linebreak()#text(" where zero is not included in the multiplication and ")#mi("a_1=1")#text(".")

#text("Doctormatt rewrote ")#mi("a_n")#text(" as:")#linebreak()#text(" ")#mi("a_n=\\prod\\limits_{p^k \\mid \\mid n} \\frac{1}{k}")

#text("Can it be proven that:")#linebreak()#text(" ")#mi("P(s)=\\log\\sum\\limits_{n=1}^\\infty \\frac{a_n}{n^s}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df7fa6a76a5c91fac28dee298c4e5719db787724fb58d8a8471b063a3ec32b90-9a1ce6f403fa5b5de72039cd76de8507a617724e83fe2b4abd1cc9676b94e27f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of spaghetti monster")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-59958")[#strong[#text("spaghetti monster")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")])]

#text("Ian Robinson: You said…..")#linebreak()#text(" “The image of the physical makeup of the Whirlpool Galaxy looks identical to my drawing, I have deliberately withheld an important piece of the jigsaw until a later date.")#linebreak()#text(" The truth is I require someone with a bit of mathematical clout to give these findings the validity and respect they deserve, no one else is aware of my findings.”")#linebreak()#text(" —————————————-")

#text("You might find the link below more helpful than Terry Tao’s blog.")#linebreak()#text(" ")#link("http://math.ucr.edu/home/baez/crackpot.html")[#text("http://math.ucr.edu/home/baez/crackpot.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-82543")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("In case anyone is interested, I extended the previous bit of numerical experimentation to twin primes, and found (perhaps unsurprisingly) some similar patterns. Some details here:")

#link("http://wp.me/p1h3oO-O")[#text("http://wp.me/p1h3oO-O")]

#text("Was just playing around a bit to try to understand the bounds of the twin prime conjecture problem. No breakthroughs to share (surprise!) but I find the patterns and trends to be interesting, and help me, as a visual thinker, to put the challenge in perspective.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-98766")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2011")])]

#text("CRACKPOT ALERT :-)")

#text("More on primes and twin primes from a complete amateur. Looking for help answering a question…")

#text("What I’ve tried to describe in previous posts are some patterns that develop within primorials. For the n-th primorial, Pn#, the distribution of primes can obviously be fully developed by repetition of all primes less that sqrt(Pn#). The removal (or sieving) of all non-primes can be divided into two broad components: (1) a symmetric pattern of non-primes removed through repetition of all primes from 2 to Pn (symmetric since these all divide evenly into Pn#), and (2) a non-symmetric distribution of non-primes generated by all other primes from P(n+1) to the highest prime < sqrt(Pn#).")

#text("Numerical experimentation shows that the symmetric component of non-primes projects outward, presumably to infinity, for every subsequent repetition of Pn#, so that primes can never fall on those positions, and primes appear, at \"random\" (clearly not random, but apparently random) intervals at the other positions that were not \"non-primes\" within Pn# screened by the primes to Pn.")

#text("Interestingly, if only to me, is that the number of \"possible primes\" (i.e. not \"non-primes\" screened by the primes to Pn), which I will call Nn, within any given primorial, Pn# ( obviously defined as the product of all primes to Pn), is related to the primorial as follows: Nn = (product for all i=1 to n) [Pn – 1]")

#text("(sorry I don't have LaTEX)")

#text("In my last post I linked to some notes describing results of numerical experimentation that show that similar patterns develop for twin primes. Within any given primorial, all possible twin primes can be sieved via symmetric removal due to primes to Pn, and then non-symmetric removal by higher primes to sqrt(Pn#). The symmetric pattern of \"non-twins\" removed by, and lingering \"possible twins\" left alone by, the sieving of primes to Pn, then repeats to infinity for all repetitions of Pn#, so that higher twins will always only occur at these \"possible twin\" locations.")

#text("Even more interesting (probably still only to me, haha) is that the number of \"possible twins\" within any given primorial is ALSO related to the primorial, similar to the way the \"possible primes\" are, but with the following form, where Tn is the number of \"possible twins\" within any given repetition of a primorial:")

#text("Tn = (product for all i=2 to n) [Pn – 2]")

#text("Alternatively, one can describe the number of \"possible twins\" removed when going from Pn# to P(n+1)# as:")

#text("T(n+1) = P(n+1)*Tn – 2 * (product for all i=2 to n) [P(n-1) – 2]")#linebreak()#text(" = P(n+1)*Tn – 2 * Tn")#linebreak()#text(" = (Pn – 2)*Tn")

#text("Using a couple of random examples to illustrate this observation:")

#text("consider P4 = 7, where P4# = 210.")

#text("The number of possible positions for primes within repetitions of 210 projecting out to infinity is 48, a result you can check for yourself fairly easily (work out Pi(mod 210) for as many primes as you like and you will find exactly 48 unique values). This is (7-1)*(5-1)*(3-1)*(2-1)")

#text("Similarly, the number of possible twin prime pairs within repetitions of 210 is T4=15, which is (7-2)*(5-2)*(3-2). You can readily see that T3 would be 3, or (5-2)*(3-2).")

#text("Note that T4 = 15 = (P4 – 2)*T3 = 5*3")

#text("I can't work out the math to prove these results, but they seem far to simple to be accidental, and to not continue to infinity. Can anyone suggest a way to demonstrate these results algebraicly, or otherwise?")

#text("Thanks for humouring me.")

#text("Pete")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-98768")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2011")])]

#text("dangit, no editing function… there are a few silly typos that should be obvious by context, like some n’s in products should be i’s")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-99310")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2011")])]

#text("Goodness I left numerous irritating little typos in that post, sorry. To correct a few:")

#text("“Possible primes” within the nth primorial, Pn#, is:")

#text("Nn = (product for all i=1 to n) [Pi – 1]")

#text("“Possible twins” within the nth primorial is:")

#text("Tn = (product for all i=2 to n) [Pi – 2]")

#text("or")

#text("T(n+1) = [P(n+1) – 2]*Tn")

#text("For a few moments, let’s suspend disbelief and pretend these definitions for Nn and Tn are proven.")

#text("I now propose that the density of primes, within all natural numbers, is less than Nn/Pn#, and converges on Nn/Pn# as n approaches infinity. I will claim this without proof for the moment and maybe elaborate later. More disbelief to suspend, sorry. :-)")

#text("I also propose that the density of twin pairs, within all natural numbers, is less than Tn/Pn#, and converges on Tn/Pn# as n approaches infinity.")

#text("The ratio of the density of twin pairs to the density of primes, within all natural numbers, which is the same as the density of twin pairs within all primes, can be taken as (Tn/Pn#)/(Nn/Pn#) = Tn/Nn, n approaching infinity")

#text("Let’s now compare the density of twin pairs within the set of primes to the density of primes within the set of natural numbers, as:")

#text("[Tn/Nn]/[Nn/Pn#], as n approaches infinity.")

#text("I believe it is fairly straightforward to show that this ratio converges on about 1.320…, the twin prime constant.")

#text("This result tells us, I think, that the set of twin primes corresponding to the set of primes is 1.32 times larger than the set of primes corresponding to the set of natural numbers (with apologies, if this isn’t written correctly from a mathematical perspective). Since the set of primes is infinite, hence the set of twin primes is also infinite.")

#text("Does that make sense?")

#text("I’ve claimed a couple of things in here without proof – the first being the existence and definitions of Nn and Tn, which I’ve demonstrated (to myself anyway) through numerical experimentation but not proven mathematically. I would think that, given the simplicity of the relationships they should be easy to develop algebraically, but admit that they are beyond my ability. The second unproven claim is that the ratios converge to the values indicated as n approaches infinity. I think those claims are much easier to rationalize, and the fact that they lead to the twin prime constant would seem to suggest they must be correct.")

#text("Thoughts?")

#text("Thanks for reading. :-)")

#text("Pete")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-99507")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2011")])]

#text("One more crackpot post, thanks for the indulgence Prof. Tao.")

#text("I’d appreciate if someone would comment, even if only to make fun of me. This is the internet after all. :-)")

#text("I know this is a famous problem and it’s bad form to hastily claim a proof (or “near-proof,” as in this case I think) of a famous problem, but since I am not a mathematician, I have no reputation to lose by exposing myself to ridicule for this, and I can easily slink back to the day job when someone pokes a big hole through this. :-)")

#text("Let me elaborate on two of the items I’ve claimed without proof in the previous post, and then also show why the ratio of twin pair/primes density to primes/natural numbers density is 1.32, or at least converges and is not less than 1. That will be in the next post to keep this one relatively short.")

#text("To find all prime numbers, we need to strip away all composite numbers. We can imagine doing this by progressively removing, or sieving, all prime multiples, working our way from the lowest prime through to infinity.")

#text("Let’s start with by removing all multiples of 2, the even numbers, from the set of natural numbers. This strips out half of all natural numbers as prime candidates, leaving only the odd numbers as possible primes. Then remove all multiples of 3, 5, 7 and so on through to Pn, the nth prime, with n approaching infinity.")

#text("Consider the second primorial, P2# = 6, after first removing the even numbers, so we have 1, 3 and 5 as prime candidates, and 2, 4 and 6 as confirmed “non-primes” between 1 and 6. Note that this pattern, which is symmetric within 6, repeats ad infinitum, or in other words, after sieving the even numbers, all remaining numbers (mod 6) are either 1, 3 or 5.")

#text("Now remove all multiples of 3 from the remaining set of “possible primes.” This removes one possible prime candidate between 1 and 6, leaving 1 and 5 as possible primes. Note again this leaves a symmetric pattern, which, since we have now only removed multiples of 2 and 3, repeats ad infinitum, removing 2/3 of all natural numbers as non-primes and leaving 1/3 for further consideration as possible primes. After having sieved the 2s and 3s, the remaining “possible prime” candidates (mod 6) are all either 1 or 5.")

#text("We can continue in the same fashion to remove all remaining multiples of 5, 7, 11, 13, …. to Pn. Each time we do this, we will be left with a set of non-primes and “possible primes” that is symmetric within the respective primorial, and which repeats ad infinitum. The density of “possible primes” within the set of natural numbers, after sieving all primes to some arbitrary Pn, is equal to the number of “possible primes” within the respective primorial divided by the value of the primorial.")

#text("The complete set of prime numbers is revealed when we have sieved all possible composite numbers by repeating to infinity each prime, and striking out all these repetitions as non-prime. Therefore, if we continue this process as described, ad infinitum, to remove all multiples of all primes to Pn, where n approaches infinity, then we will be left with only primes. Hence, if we call Nn the number of “possible primes” within Pn#, then Nn/Pn# converges on the density of primes within the set of natural numbers as n approaches infinity, since as n approaches infinity, Nn becomes the set of primes and Pn# becomes the set of natural numbers.")

#text("Now let’s examine how many natural numbers are removed as candidates for any given prime, Pn. Choose an arbitrary prime, Pn, and consider the number of multiples of Pn within Pn#. This is clearly P(n-1)#. If no multiples of primes smaller than Pn had yet been removed, then repetitions of Pn to infinity would eliminate Pn prime candidates out of every Pn# natural numbers. However, assuming Pn > 2, and following our sieving process sequentially with monotonically increasing n, by the time we are set to remove remaining candidates that are multiples of Pn, there are a number of multiples that have already been removed, namely all those that are multiples of lower primes < Pn. If you conduct a simple accounting exercise, starting with the smallest prime numbers and working up through a few, you should be able to convince yourself that of the P(n-1)# possible multiples of Pn within Pn#, [P(n-1)# – N(n-1)] have already been eliminated by the multiples of Pn with lower primes, where N(n-1) means the number of possible primes left within the lower primorial, P(n-1)#, after sieving of all primes up to P(n-1), and Nn is equal to, as claimed before:")

#text("Nn = (product for all i=1 to n) [Pi – 1] —– eqn [1]")

#text("To demonstrate… removal of all even numbers eliminates half of all numbers between 1 and 2 (= P1#), and by extension removes half of all numbers within every multiple of P1# to infinity, or half of all natural numbers.")

#text("Removal of all remaining multiples of P2 = 3 between 1 and 6 (= P2#) eliminates the number 3 as a possible prime within subsequent repetitions of P2#. Note that 6 was already removed, since it is a multiple of 2. So there were 2 (= P1#) multiples of 3 within P2#, but 1 (i.e. {P1# – N1}, or {P1# – eqn [1] for n-1, where n = 2} had already been removed by multiples of 3 by 2, leaving only 1 possible prime candidate to be removed at this sieving pass, to leave 2 remaining “possible prime” candidates (1 and 5) within P2#, or 2/6 = 1/3 “possible primes” within the set of all natural numbers after repeating this pattern an infinite number of times. Hence all primes (mod 6) greater than P2 must equal 1 or 5, a well known result.")

#text("Now if we remove the remaining multiples of P3 = 5 between 1 and 30, we find that of the 6 (i.e. P2#) possible multiples of 5, 4 had already been removed, leaving only 2 (i.e. {P2# – eqn [1] for n-1 where n = 3}), namely 5 and 25, to be screened by repetitions of 5. Thus of the 10 possible primes within 30 existing after sieving by 2 and 3, two more candidates (5 and 25) have been removed, and all primes (mod 30) greater than P3 must equal 1, 7, 11, 13, 17, 19, 23 or 29 (i.e. exactly 8 possibilities).")

#text("Repeating the same logic now for multiples of P4 = 7 up to 210, of the 30 (= P3#) multiples of 7 to be removed, 22 ({P3# – product for i = 1 to 3 of [Pi – 1]}) were already screened by multiples of 7 with 2, 3 or 5, leaving 8 other multiples of 7 to be eliminated at this stage. Thus of 8 x 7 = 56 possible primes within 210 remaining after sieving by 2, 3 and 5, the further sieving by 7 removes 8 other possible prime candidates, leaving 48 “possible primes” within repetitions of 210, and therefore 48 unique values for all primes higher than 7 (mod 210), which I won’t list here.")

#text("Now let’s examine why Nn takes the form I’ve claimed, using P4 as a working example.")

#text("If we want to count the number of multiples of 7 with 2, 3 and 5, we should expect:")

#text("3 x 5 multiples of 2 x 7,")#linebreak()#text(" 2 x 5 multiples of 3 x 7,")#linebreak()#text(" 2 x 3 multiples of 5 x 7,")#linebreak()#text(" 2 multiples of 3 x 5 x 7,")#linebreak()#text(" 3 multiples of 2 x 5 x 7,")#linebreak()#text(" 5 multiples of 2 x 3 x 7, and")#linebreak()#text(" 1 multiple of 2 x 3 x 5 x 7")

#text("In order to identify unique multiples of 7 already removed by 2, 3 and 5, we obtain [(3 x 5) + (2 x 3) + (2 x 3)] – (2 + 3 + 5 + 1) = 22, which we can re-organize and re-write as {5 x 3 x 2 – [(5 – 1) x (3 – 1) x (2 – 1)]} = 22. Or, the number of unique multiples of 7 removed within multiples of 210 is 8 = (5 – 1) x (3 – 1). And hence the number of possible primes remaining within multiples of 210 is 8 (from P3#) x 7 – 8, or 48, or 8 x 6, or 8 x (P4 – 1), or (P4 – 1) x (P3 – 1) x (P2 – 1) x (P1 -1).")

#text("Hence, Nn = (product for all i=1 to n) [Pi – 1]")

#text("Phew. :-)")

#text("I think that is fairly straightforward, and I expect the logic to generate the product formula for Tn is very similar, but this came to me on today’s 9 mile run, and I think I need another good run or two to come around to figuring that one out. :-)")

#text("To wrap this post, I think I’ve defended the prior claimed definition of Nn, the number of “possible prime” candidates within the nth primorial (which by extension serves to define the density of “possible prime” candidates within the set of natural numbers after sieving by primes up to Pn). And, I think I’ve defended the claim that this density of “possible primes” within the nth primorial converges to the density of primes within the set of natural numbers as n approaches infinity.")

#text("OK, on to producing the twin prime constant, or something like it, in one more post…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-99520")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2011")])]

#text("So let’s start with the assumption that the claimed definitions of Nn and Tn are proven. I think I’ve proven the first, and can only say I believe the second from numerical experimentation, and will try to defend it, given more time and more miles. :-)")

#text("Let’s pick up from two posts back with the idea that the ratio of the density of twin pairs within the set of primes to the density of primes within the set of natural numbers can be expressed as:")

#text("D(t:p)/D(p:nat) = [Tn/Nn]/[Nn/Pn#] = Tn(Pn#)/(Nn)^2, with n approaching infinity")

#text("Where D(t:p) means the density of twin pairs within the set of primes, and D(p:nat) = density of primes within the set of natural numbers.")

#text("This can be re-written as:")

#text("D(t:p)/D(p:nat) = product for i = 1 to infinity {Pi x P(i – 2)/[P(i-1)]^2} ——- eqn [2]")

#text("Where we include P0 = 1 to allow us to simplify the examination of the products with no change to the result.")

#text("This can be written as:")

#text("D(t:p)/D(p:nat) = limit as n approaches infinity {Pn x P(n – 2)/[P(n-1)]^2} x … x {13 x 11/12^2} x … x {3 x 1/2^2} x {2 x 1/1^2}")

#text("Numerical experimentation shows this series converges quite nicely to 1.320… as claimed. I won’t attempt to work out the arithmetic, but by inspection, as n increases, the nth term steadily converges on 1, being always < 1, and with n = 1, 2, 3 and 4 we get 2, 1.5, 1.406…, and 1.367…")

#text("Without knowing the actual value of this infinite product, we can obtain a lower bound by examining:")

#text("Product for i = 1 to infinity {i x (i – 2)/(i – 1)^2}")

#text("which converges on 1.")

#text("This latter product includes all the terms in eqn [2], but also includes additional terms less than 1 for values of i that are not prime. Hence it decreases more quickly than eqn [2], and is always lower than eqn [2], after the first two terms, when the same number of terms has been included in both products. Therefore in the limit, eqn [2] converges on a positive number that is less than 1.367… (by inspection) and not less than 1.")

#text("So, if we believe the definition of Tn as claimed, I think we have shown that the set of twin prime pairs is infinite, since its density within the infinite set of primes is at least equal to the density of primes within the infinite set of natural numbers.")

#text("Of course the definition of Tn is not yet proven. A few more miles to be run first… :-)")

#text("Questions, comments, rotten tomatoes welcome.")

#text("Hopefully no fatal typos in this post, fingers crossed…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-99806")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")])]

#text("And of course there were some critical typos. Corrections:")

#text("D(t:p)/D(p:nat) = product for i = 1 to infinity {Pi x (Pi – 2)/[(Pi-1)]^2} ——- eqn [2]")

#text("Where we include (P1 – 1) = 1 (instead of 0)…")

#text("——")

#text("I think that’s the worst of it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-100109")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2011")])]

#text("Goodness even the corrections need corrections:")

#text("Where we include (P1 – 2) = 1…")

#text("The idea there is simply to keep 1 as a placeholder (instead of (2 – 2 = 0) for when we group the individual product terms. It’s not a necessary element, just a convenience to make the elaboration of the infinite product easier to manage and look at.")

#text("I see there are still some other minor typos in the preceding posts: a (2 x 3) instead of (2 x 5), and at least one Pn instead of the correct P(n-1)#. Sorry for those.")

#text("I think I’ve just about got the correct explanation for Tn, will try to elaborate after the end of the work day. Meanwhile, I should probably explain one thing I’ve glossed over that may have some readers stuck or rejecting my logic.")

#text("In the preceding posts I’ve made no specific mention of “actual primes,” but have rather focussed on a discussion of confirmed “non-primes” (as ruled out in any given sieving by a given Pn) and “possible primes” that remain after each sieving step. I’ve suggested that these values can be extrapolated to infinity to obtain the ultimate densities of primes and twin primes.")

#text("But what about the pesky ACTUAL primes that develop as we go, namely 2, 3, 5, …. Pn? These actual primes occupy positions I have called “non-primes.” Is this a fatal flaw in my logic? I’m fairly confident this has no bearing, and here is why…")

#text("If we take Nn and Tn to be the number of possible primes and possible twins within the nth primorial, where “possible” implies “still standing as candidates after sieving by primes to Pn,” then these values represent the numbers of possibilities within all primorials after the first one (accepting for the moment that Tn remains to be developed/defended).")

#text("Within the first primorial, we know that we have n ACTUAL primes, which are sitting on n “non-prime” positions. If we want to be precise, then, we should perhaps state that the number of “possible primes, “within the first Pn# only, is actually Nn + n, and thereafter remains Nn. We may also have some number, which must be less than n, of actual twin primes.")

#text("It is trivial to show to show that (Nn + n)/Pn#, the density of primes within the first primorial, converges to Nn/Pn# as n grows. It is also trivial to show that this addition of n “possible primes” within the first primorial has no bearing on the density of “possible primes” in the set of natural numbers after the nth sieving step, when we recall that the first primorial containing the extra n “possible primes” is only one of an infinite number, with the rest all containing exactly Nn “possible primes.”")

#text("Hence the density of “possible primes” within the set of natural numbers after n sieving steps remains Nn/Pn#, and the density of twin pairs Tn/Pn#.")

#text("Now if only we could prove the definition of Tn, we might have the problem licked. :-)")

#text("(or I could be completely wrong, and given the fact that I’ve never done anything elegant in math on my own, this latter outcome seems somehow more likely, yet this continues to be fun and intellectually stimulating to me, so thanks again for the continued indulgence)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-100118")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2011")])]

#text("I think any further discussion of these matters should take place on your own web site, where you have the ability to edit your own posts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-100120")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2011")])]

#text("OK fair enough, thanks for letting it go on this far.")

#text("All the best!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-101102")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("One final post to let anyone who may have been following this know the story continues to develop here:")

#link("http://petequinnramblings.wordpress.com/2011/11/05/prime-triples/")[#text("http://petequinnramblings.wordpress.com/2011/11/05/prime-triples/")]

#text("Further numerical experimentation shows predictable numbers of candidate k-tuples, other than primes and twin primes, within the primorials.")

#text("Thanks again Prof. Tao, I won’t post here on this topic again, I promise.")

#text("Cheers,")

#text("Pete")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9996141e5f58d00d06bda579bc0b2900d52db0bd92516ea0ce56c9293c7c8fa0-13046d25a493826bc6881484050d80198ad3dc6c224233045a5ca3e6acd3d597.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jose javier garcia")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-127878")[#strong[#text("jose javier garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#link("http://vixra.org/pdf/1111.0105v4.pdf")[#text("Click to access 1111.0105v4.pdf")]

#text("the Riemann Xi function can be written as $ \\xi(s)=Cdet(H+s(s-1)+1/4) $")

#text("Here ‘H’ is a Hamiltonian operator whose potential is $ V^{-1}(x) = A \\sqrt D n(x) $ where N(x) is the eigenvalue staircase :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9996141e5f58d00d06bda579bc0b2900d52db0bd92516ea0ce56c9293c7c8fa0-13046d25a493826bc6881484050d80198ad3dc6c224233045a5ca3e6acd3d597.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jose javier garcia")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-128428")[#strong[#text("jose javier garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2012")])]

#text("my operator is correct but none put attention because i am no famous :( , you can check the energies and see that they agree with the square of the riemann zeros :D")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-395495")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2014")])]

#mi("\\Longrightarrow \\ -\\ {\\rm means}{\\rm \\ }{\\rm that\\ the}{\\rm \\ }{\\rm number\\ is\\ represented}{\\rm \\ }{\\rm as\\ a\\ product\\ of}{\\rm \\ }{\\rm two\\ numbers}")#linebreak()#text(" ")#mi("\\longrightarrow \\ -\\ means\\ that\\ the\\ number\\ is\\ not\\ represented\\ as\\ a\\ product\\ of\\ two\\ numbers")#linebreak()#text(" ")#mi("\\displaystyle {\\mathbb O}\\ \\Longrightarrow mm\\longrightarrow nn\\longrightarrow nm")#linebreak()#text(" ")#mi("\\displaystyle {\\mathbb D}\\Longrightarrow nn\\longrightarrow nm\\longrightarrow mm")#linebreak()#text(" ")#mi("\\displaystyle {\\mathbb G}\\Longrightarrow nm\\longrightarrow mm\\longrightarrow nn")#linebreak()#text(" ")#mi("\\displaystyle {\\mathbb P}\\longrightarrow nn\\longrightarrow mm\\longrightarrow nm")#linebreak()#text(" ")#mi("\\displaystyle mm-product\\ of\\ an\\ odd\\ number\\ and\\ an\\ odd")#linebreak()#text(" ")#mi("\\displaystyle nn-\\ 2^{a_i};;\\ a_i\\ (1,2,3,4,5\\dots )")#linebreak()#text(" ")#mi("\\displaystyle nm-{\\rm the\\ product}{\\rm \\ }{\\rm of\\ an\\ even\\ number}{\\rm \\ }{\\rm and\\ odd}\\$")#text("latex \\displaystyle {\\mathbb P}\\in \\left(2,3,5,7,11\\right)-prime\\ numbers$")#linebreak()#text(" To exhaust all combinations")#linebreak()#text(" ")#mi("\\displaystyle {\\mathbb S}\\Longrightarrow nn\\Longrightarrow mm\\longrightarrow nm")#linebreak()#text(" ")#mi("\\displaystyle {\\mathbb T}\\Longrightarrow nn\\Longrightarrow nm\\longrightarrow mm")#linebreak()#text(" ")#mi("\\displaystyle {\\mathbb K}\\Longrightarrow mm\\Longrightarrow nm\\longrightarrow nn")#linebreak()#text(" ")#mi("\\displaystyle {\\mathbb Z}\\Longrightarrow nn\\Longrightarrow mm\\Longrightarrow nm")

#text("The question is a mirror image of the entire sequence of numbers or through an extension of the product operator. Or the first and the second time. And most importantly, how it can help to understand the nature of prime numbers, I do not know")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-395897")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2014")])]

#text("@0_Lesh_a: Will you please stop your comments? They are obviously gibberish.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-396143")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("It’s just your opinion")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-2/#comment-517277")[#strong[#text("Otro valiente más (o una nueva \"demostración\" de la hipótesis de Riemann) - La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2019")]

#text("[…] Fields en el ICM de Madrid de 2006, uno de los matemáticos más geniales vivos en la actualidad) afirma en su blog que ha encontrado ciertos “problemas” con una descomposición presentada en la página […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-25721")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Nice slides!")#linebreak()#text(" I would recommend to convert them (directly) into")#linebreak()#text(" PDF (unless you have significant animation in them).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e67010639132cd3578d4d9f8615ea08ee844a5acdcb885d3728638165b04bf8-2c870f2026246c69813eee1d4721f755de625663ea00ea21e899fc1d3e926595.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derek Buchanan")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-25756")[#strong[#text("Derek Buchanan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("The date on the first page is wrong. It’s the 7th, not the 8th.")

#text("Anyway, Terry, I was the one who asked you later about polynomial progressions of primes. I’m curious as to why you did not mention this in your talk.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f57672c90a1d370ba6a76dd8badd812c9f6269c80a537bf71f9d59f7efd0c7d5-dfe3729fe9c65aa89912f407f8060c60c5926b63b5f890799a75a44c816f5b8d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mitchan88")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-26351")[#strong[#text("mitchan88")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Nice slides!")

#text("I like your site very much, but unfortunately I’m only at the first year of University, so I can understand only 0,5% of your articles :p")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1c6342ac1721745a7353468cd3c901d2f73a04aa0acaf218a02ff62ff1eb2d-c7a0c0f4d89df933bff8c10095e5496289ddc8d307ba1797246a4882182011ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dsilvestre")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-26687")[#strong[#text("dsilvestre")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2008")])]

#text("Dear Dr Tao,")#linebreak()#text(" I watched this video and liked it very much.")#linebreak()#text(" Hey, if I want to find a drawing on the gaussian primes constelation, say, this ")#link("http://bp3.blogger.com/_XEmuCMo7K8Q/R8WbFZTnJ1I/AAAAAAAAAPQ/IhZPmTVPr1Q/s1600-h/coneja.GIF")[#text("rabbit")]#linebreak()#text(" do I have a chance? (my mom drew it)")#linebreak()#text(" what are the chances of finding it using 1-year of a pentium4 time?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e784177fc46895caaeee9a472790a28984f0a8a7b388f06a6a7f4275b041e9a0-6e712960fa5d2f8d482b5a4a30d86d7aa27f8099b97eae1cc4a7ec9563dc689a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexandru")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-26878")[#strong[#text("alexandru")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2008")])]

#text("yes, pdf would be great… especially for linux users…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04744c1ec556b963891f014d87e635420009d945cde8e0de90496523a9c9f249-faba070bded647fdb7b69b0b854f013008755e8866cfcdf59dd568d10fcd5222.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Agol")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30708")[#strong[#text("Ian Agol")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2008")])]

#text("Anyone understand Xian-Jin Li’s paper claiming to prove the Riemann hypothesis?")#linebreak()#text(" ")#link("http://arxiv.org/abs/0807.0090")[#text("http://arxiv.org/abs/0807.0090")]#linebreak()#text(" Look’s like he’s completing a program of Bombieri and Connes.")#linebreak()#text(" He seems to be an expert on RH, and has done some nice work on it before.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30711")[#strong[#text("I Can Has Riemann Hypothesis? « The Unapologetic Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2008")]

#text("[…] Can Has Riemann Hypothesis? Everybody is talking about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30714")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2008")])]

#text("It unfortunately seems that the decomposition claimed in equation (6.9) on page 20 of that paper is, in fact, impossible; it would endow the function h (which is holding the arithmetical information about the primes) with an extremely strong dilation symmetry which it does not actually obey. It seems that the author was relying on this symmetry to make the adelic Fourier transform far more powerful than it really ought to be for this problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30716")[#strong[#text("Not Even Wrong » Blog Archive » Proof of the Riemann Hypothesis?")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2008")]

#text("[…] It looks like a problem with the proof has been found. Terry Tao comments on his blog It unfortunately seems that the decomposition claimed in equation (6.9) on page 20 of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30717")[#strong[#text("Another attempted proof of the Riemann hypothesis « Muse Free")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2008")]

#text("[…] I’d think that the chances of this proof being correct are extremely low; in fact Terry Tao claims to have already found a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30721")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("I also have some (perhaps milder) troubles with the proof. It seems to me as if Li had treated the Dirac delta on L^2(A) as a function. For example, the first 5 lines of page 28 make little sense to me. Am I missing something here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30729")[#strong[#text("Ars Mathematica » Blog Archive » Li’s Preprint")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")]

#text("[…] proof the Riemann Hypothesis. The optics of it looked good (Li is clearly not a crank), but Terry Tao has identified an apparent […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30738")[#strong[#text("Terence Tao encuentra un fallo en la demostración de Li de la Hipótesis de Riemann [ENG]")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")]

#text("[…] Terence Tao encuentra un fallo en la demostración de Li de la Hipótesis de Riemann [ENG]terrytao.wordpress.com/2008/02/07/structure-and-randomness-i… por emulenews hace pocos segundos […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30739")[#strong[#text("Otro valiente más (o una nueva “demostración” de la hipótesis de Riemann) « Francis (th)E mule Science’s News")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")]

#text("[…] Fields en el ICM de Madrid de 2006, uno de los matemáticos más geniales vivos en la actualidad) afirma en su blog que ha encontrado ciertos “problemas” con una descomposición presentada en la página […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30741")[#strong[#text("Request: Li’s preprint, or “on not being a crackpot” « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")]

#text("[…] of us seemed inclined to go through the paper and look for mistakes. Luckily, Terry Tao did and thinks he has found a mistake (which the author may claim to have fixed…things are starting to get a little confusing). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30755")[#strong[#text("Richard Elwes - Riemann Hypothesis")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")]

#text("[…] Terry Tao and Alain Connes both say “no”. Ok, Li’s apparently “updated” the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30756")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("The function ")#mi("h(u)")#text(" defined on page 20 does have a strong dilation symmetry: it is invariant by multiplication by ideles of norm one (since it is merely a function of the norm of ")#mi("u")#text("). In particular, it is invariant under multiplication by elements of ")#mi("k^{*}")#text(". I’m probably missing something here.")

#text("Probably the subtlety is in passing from integration over the nice space ")#mi("J")#text(" of idele classes to the singular space ")#mi("\\mathbb{A}/k^{*}")#text(". The topologies on the spaces of adeles and ideles are quite different.")

#text("There is a formal error in Theorem 3.1 which doesn’t affect the paper: the distribution discussed is not unique. A distribution supported at a point is a sum of derivatives of the delta distribution. Clearly there exist many such with a given special value of the Fourier transform.")

#text("There is also something odd about this paper: nowhere is it pointed out what is the new contribution of the paper. Specifically, what is the new insight about number theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30759")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("A remark concerning Lior’s remark: the function h(u) in the current (v4) version of the paper is _not_ the same as the one that was defined when T. Tao pointed out a problem with it. This earlier one (still visible on arXiv, v1) was defined in different ways depending on whether the idele had at most one or more than one non-unit component, and was therefore not invariant under multiplication by ")#mi("k^{*}")#text(".")

#text("(It is another problem with looking at such a paper if corrections as drastic as that are made without any indication of when and why).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("Dear Lior,")

#text("Emmanuel is correct. The old definition of h was in fact problematic for a large number of reasons (the author was routinely integrating h on the idele class group C, which is only well-defined if h was ")#mi("k^*")#text("-invariant). Changing the definition does indeed fix the problem I pointed out (and a number of other issues too). But ")#link("http://noncommutativegeometry.blogspot.com/2008/06/fun-day-two.html?showComment=1215071400000#c8876982000013974667")[#text("Connes has pointed out")]#text(" a much more serious issue, in the proof of the trace formula in Theorem 7.3 (which is the heart of the matter, and is what should be focused on in any future revision): the author is trying to use adelic integration to control a function (namely, h) supported on the ideles, which cannot work as the ideles have measure zero in the adeles. (The first concrete error here arises in the equation after (7.13): the author has made a change of variables ")#mi("\\lambda \\mapsto \\lambda u")#text(" on the idele class group C that only makes sense when u is an idele, but u is being integrated over the adeles instead. All subsequent manipulations involving the adelic Fourier transform Hh of h are also highly suspect, since h is zero almost everywhere on the adeles.)")

#text("More generally, there is a philosophical objection as to why a purely multiplicative adelic approach such as this one cannot work. The argument only uses the multiplicative structure of ")#mi("k^*")#text(", but not the additive structure of k. (For instance, the fact that k is a cocompact discrete additive subgroup of A is not used.) Because of this, the arguments would still hold if we simply deleted a finite number of finite places v from the adeles (and from ")#mi("k^*")#text("). If the arguments worked, this would mean that the Weil-Bombieri positivity criterion (Theorem 3.2 in the paper) would continue to hold even after deleting an arbitrary number of places. But I am pretty sure one can cook up a function g which (assuming RH) fails this massively stronger positivity property (basically, one needs to take g to be a well chosen slowly varying function with broad support, so that the Mellin transforms at Riemann zeroes, as well as the pole at 1 and the place at infinity, are negligible but which gives a bad contribution to a single large prime (and many good contributions to other primes which we delete).)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30765")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("That’s an interesting point indeed, if one considers that the RH doesn’t work over function fields once we take out a point of a (smooth projective) curve — there arise zeros of the zeta function which are not on the critical line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30767")[#strong[#text("Update on Riemann hypothesis « Muse Free")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")]

#text("[…] Tao explains here why an approach such as Li’s, which basically only uses the multiplicative structure of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9775c35524b0bf73fbc1ffba467701393e17b68caffaea92f73c1590cfde362-96ee93eefc1d247288e35649b29508fa5d2afbd225781ed402af2c30a558f24c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Posible demostración de la hipótesis de Riemann « Edumate Perú")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30772")[#strong[#text("Posible demostración de la hipótesis de Riemann « Edumate Perú")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("[…] debate lo plantea el matemático Terence Tao de la Universidad de los California – Los Ángeles. En su blog plantea que ciertos pasos seguidos por Xian-Jin Li no están del todo bien. It unfortunately seems that the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1ed27d07cbe928ef9caebf52fcb809a9e7bc8a4321fce7bdb477e740c2bc5cb-68baed02534c9e5ff1fdd4c6aada4282982a4c3b429bb5372d3fa293c38036bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Moshe Klein")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30781")[#strong[#text("Moshe Klein")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2008")])]

#text("Dear Terence Tao, 5.7.08")

#text("Maybe You and A.Connes can work together to close the gap which you discover in Li new paper on RH.")

#text("B.Riemann claim in 1859 that the zeros of the Zeta function lies all on the critical line ( This is one part of the 8 problem of Hilbert) Do you think that an interaction between a line and points as individual")#linebreak()#text(" atoms can create a new mathematical framework which can be consider as a")#linebreak()#text(" solution to the 6 th’ problem of Hilbert about the connection between mathematics and physics ?")

#text("Best Wishes")#linebreak()#text(" Moshe Klein")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30783")[#strong[#text("Desmontada la demostración de Li")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2008")]

#text("[…] en la UCLA y ganador de la medalla Fields (considerada el premio nobel de las matemáticas), ha encontrado un fallo en su demostración. El error está en una fórmula donde se atribuye a los números primos unas […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7dd72493aa77cd813db3ec3df6d6cbfc771cafeb443e416973cf4c55c7f24a5c-0cb5f51b95561e53b7c88248c9fe4e81706970927857d65da79a617a4e3b2fdf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30796")[#strong[#text("Abhishek")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2008")])]

#text("Xian-Jin Li has now withdrawn his paper from the arXiv.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/662dd8418d0a7ab765178e0d8317d2f876f411bd8ade016b9ac9b815df29832f-51290b51ad1c066d7892cc1f446cda374d1b0117363c782d93e64a2aebc9cd32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chip Neville")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30818")[#strong[#text("Chip Neville")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2008")])]

#text("Terence,")

#text("I have a question about your comment:")

#text("“Because of this, the arguments would still hold if we simply deleted a finite number of finite places v from the adeles (and from k^*). … (basically, one needs to take g to be a well chosen slowly varying function with broad support, so that the Mellin transforms at Riemann zeroes, as well as the pole at 1 and the place at infinity, are negligible but which gives a bad contribution to a single large prime (and many good contributions to other primes which we delete).)”")

#text("Does this mean that you would be considering the “reduced” (for lack of a better name) zeta function \\prod 1/(1-1/p^{-s}), where the product is taken over the set of primes not in a finite subset S? If so, this “reduced” zeta function has the same zeroes as the standard Riemann zeta function, since the finite product \\prod_S 1/(1-1/p^{-s}) is an entire function with no zeroes in the complex plane. Thus the classical situation in the complex plane seems to be very different in this regard from the situation with function fields over smooth projective curves alluded to by Emmanuel above.")

#text("Does anyone have an example of an infinite set S and corresponding reduced zeta function with zeroes in the half plane Re z > 1/2? A set S of primes p so that \\sum_S 1/p^{1/2} converges will not do, since \\prod_S 1/(1-1/p^{-s}) is holomorphic in the half plane Re z > 1/2 with no zeroes there. Perhaps a set S of primes P thick enough so that \\sum_S 1/p^{1/2} diverges, but thin enough so that \\sum_S 1/p converges, might do. This seems to me to be a delicate and difficult matter.")

#text("I hope these questions do not sound too foolish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30819")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2008")])]

#text("Dear Chip,")

#text("Actually, the product ")#mi("\\prod_S 1/(1-1/p^{-s})")#text(" has a number of poles on the line ")#mi("\\text{Re}(s)=0")#text(", when s is a multiple of ")#mi("2\\pi i/\\log p")#text(".")

#text("Li’s approach to the RH was not to tackle it directly, but instead to establish the Weil-Bombieri positivity condition which is known to be equivalent to RH. However, the proof of that equivalence implicitly uses the functional equation for the zeta function (via the explicit formula). If one starts deleting places (i.e. primes) from the problem, the RH stays intact (at least on the half-plane ")#mi("\\text{Re}(s) \\geq 1/2")#text("), but the positivity condition does not, because the functional equation has been distorted.")

#text("The functional equation, incidentally, is perhaps the one non-trivial way we ")#emph[#text("do")]#text(" know how to exploit the additive structure of k inside the adeles, indeed I believe this equation can be obtained from the Poisson summation formula for the adeles relative to k. But it seems that the functional equation alone is not enough to yield the RH; some other way of exploiting additive structure is also needed, but I have no idea what it should be.")

#text("[")#emph[#text("Revised")]#text(", July 7:] Looking back at Li’s paper, I see now that Poisson summation was indeed used quite a few times, and in actually a rather essential way, so my previous philosophical objection does not actually apply here. My revised opinion is now that, beyond the issues with the trace formula that caused the paper to be withdrawn, there is another fundamental problem with the paper, which is that the author is in fact implicitly assuming the Riemann hypothesis in order to justify some facts about the operator E (which one can think of as a sort of Mellin transform multiplier with symbol equal to the zeta function, related to the operator ")#mi("f(x) \\mapsto \\sum_{n=1}^\\infty f(x/n)")#text(" on ")#mi("{\\Bbb R}^+")#text("). More precisely, on page 18, the author establishes that ")#mi("E(\\theta_1) \\not \\in L^2(C)")#text(" and asserts that this implies that ")#mi("E(H\\theta_1) \\not \\in L^2_0(C)")#text(", but this requires certain invertibility properties of E which fail if there is a zero off of the critical line. (A related problem is that the decomposition ")#mi("H\\theta_1 = f_1 + f_2")#text(" used immediately afterwards is not justified, because ")#mi("E(S_0(A))")#text(" is merely dense in ")#mi("L^2_0(C)")#text(" rather than equal to it.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30820")[#strong[#text("Riemann hypothesis proved? - Bad Astronomy and Universe Today Forum")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2008")]

#text("[…] make the adelic Fourier transform far more powerful than it really ought to be for this problem. Source. __________________ MacTalk – The Australian Apple Community – iPod, iPhone and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e3ea0e461d1d736c668411472d5f628588e8adf015c16fbbe10de0d15fd1eca-70ff2301f8f81ca485a632489f67c0312ea697218a8a0e60e2a3013f321cf13e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30826")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2008")])]

#text("Chip, look up Beurling primes. It will give a sort of an answer to your question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b77f3d74a31e0fde1830ac545a09623fb7b464c89fb43ff865f3c6b173659ff7-3864adc90404362eb6f051bcab355dbdc9b29d3307d992132c589871f048b3bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of javier")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30829")[#strong[#text("javier")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2008")])]

#text("Dear Terence,")

#text("I am not sure I understand your “philosophical” complain on using only the multiplicative structure and not the additive one. This is essentially the philosophy while working over the (so over-hyped lately) field with one element, which apparently comes into the game in the description of the Connes-Bost system on the latest Connes-Consani-Marcolli paper (Fun with F_un).")

#text("From an algebraic point of view, you can often recover the additive structure of a ring from the multiplicative one provided that you fix the zero. There is an explanation of this fact (using the language of monads) in the (also famous lately) work by Nikolai Durov “")#link("http://arxiv.org/abs/0704.2030")[#text("A new approach to Arakelov geometry")]#text(" (Section 4.8, on additivity on algebraic monads).")

#text("By the way, I wanted to tell you that I think you are doing an impressive work with this blog and that I really enjoy learning from it, even if this is the very first time I’ve got something sensible to say :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30833")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2008")])]

#text("Dear Javier,")

#text("I must confess I do not understand the field with one element much at all (beyond the formal device of setting q to 1 in any formula derived using ")#mi("F_q")#text(" and seeing what one gets), and don’t have anything intelligent to say on that topic. Regarding my philosophical objection, the point was that if one deleted some places from the adele ring A and the multiplicative group ")#mi("k^*")#text(" (e.g. if k was the rationals, one could delete the place 2 by replacing ")#mi("k^*")#text(" with the group of non-zero rationals with odd numerator and denominator) then one would still get a perfectly good “adele” ring in place of A, and a perfectly good multiplicative group in place of ")#mi("k^*")#text(" (which would be the invertible elements in the ring of rationals with odd denominator), but somehow the arithmetic aspects of the adeles have been distorted in the process (in particular, Poisson summation and the functional equation get affected). The Riemann hypothesis doesn’t seem to extend to this general setting, so that suggests that if one wants to use adeles to prove RH, one has to somehow exploit the fact that one has all places present, and not just a subset of such places. Now, Poisson summation does exploit this very fact, and so technically this means that my objection does not apply to Li’s paper, but I feel that Poisson summation is not sufficient by itself for this task (just as the functional equation is insufficient to resolve RH), and some further exploitation of additive (or field-theoretic) structure of k should be needed. I don’t have a precise formalisation of this feeling, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20f84cef92794cf246f05dcb9261ab5fb8c27156c8baf7be823af31943851321-cf92ce41652929d5d2f92578b1747480bc0a4279f61d65d243114e59ea03d178.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amr Alturky")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-468460")[#strong[#text("Amr Alturky")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2016")])]

#text("my dear terence tao iam sure at this i am egyptain arabic man and ihave 2 soultion on rimann hypothesis my number is 01095162649")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30839")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2008")])]

#text("Dear Terry,")

#text("you are absolutely right that Poisson summation over k inside A is the (now) standard way to obtain the functional equation for Hecke L-functions. This proof is due to Tate (his thesis from 1950), you can also find it in Weil’s Basic Number Theory, Chapter 7, Section 5.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ffbc19d0c3c6aeb395fa894e412bb93e5dcf78d6996c6e9affdc8d5e3ea44ed4-3551ed8515fb51768647a5e5d410b3a3bcc15d673575a7b82e105359f1d38ef2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of j.")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-30869")[#strong[#text("j.")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2008")])]

#text("Why don’t you use LaTeX for your slides?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Babak")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-31091")[#strong[#text("Babak")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2008")])]

#text("Hi Terrance,")

#text("A few months ago I stumbled upon an interesting differential equation while using probability heuristics to explore the distribution of primes. It’s probably nothing, but on the off-chance that it might mean something to a better trained mind, I decided to blog about it: ")#link("http://babaksjournal.blogspot.com/2008/07/differential-equation-estimating.html")[#text("http://babaksjournal.blogspot.com/2008/07/differential-equation-estimating.html")]

#text("-Babak")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/646969cb23c79b7ecb24f94dd0782a585b76cb0930a07832c050ea8e61b4aa8b-ec1ffdbeac677c73067c13ffd22de51796583e09bda19145ead50fb5060eae21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michele")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-31121")[#strong[#text("michele")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2008")])]

#text("I think that the paper of Prof. Xian-Jin Li will be very useful for a future and definitive proof of the Riemann hypothesis. Furthermore, many mathematics contents of this paper can be applied for further progress in varios sectors of theoretical physics (p-adic and adelic strings, zeta strings).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d58677b4023c07b9b61cf0df9fef1bc113847e309100e069a0553cbecbd3aa2-30758f8d1f45cd3689e45046e6532a6d5e9799c1bc00d595c3d66f9be73b61c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yonghui Wang")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-31186")[#strong[#text("Yonghui Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("“functional equation is insufficient to resolve RH”")

#text("Yes, For example, The Hurwitz zeta-function and the Eisenstein series (See")

#text("Lagarias paper or my paper on Acta Math Hung.~mine is very easy, just for")

#text("an test) do not satisfy RH, though they have functional equation.")

#text("The point is that, they do not have Euler product! ~a multiplicative")

#text("structure!")

#text("By the way, the Possion Summation on Adele do use the fact that ” k is a")

#text("cocompact discrete additive subgroup of A”, which takes the role as the")

#text("Fourier analysis on R/Z. This certifies that “Functional equation” (deduced")

#text("from Poisson Summation) represents the additive structure.")

#text("So, the philosophy of “multiplicative” and “additive” is really critical for")

#text("analytic number theorist.")

#text("Usually, the analytic number theorist believe that a general L-function")

#text("which satisfies both functional equation and Euler Products will posses RH.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-31838")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2008")])]

#text("Professor Tao, I’m not quite sure where to put this comment, but I was wondering whether your results with Ziegler on polynomial progressions in the primes implied or could be used to deduce effective bounds that would help explain patterns like the ")#link("http://en.wikipedia.org/wiki/Ulam_spiral")[#text("Ulam spiral")]#text(". In other words, can it be deduced that certain quadratic patterns (such as the well-known n^2 + n + 41) appear more often in the primes than “expected” (for an appropriate definition of “expected”) from your results?")

#text("Since that particular example is related to the Heegner numbers, I would be pleasantly surprised if the answer was affirmative, although from what I’ve read the techniques you apply do not actually use much information about the primes themselves, so perhaps it’s not philosophically likely.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-31844")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2008")])]

#text("Dear Qiaochu,")

#text("My result with Tamar is only able to deal with polynomial expressions involving two or more variables, e.g. n + P(r) where n, r are integers and P is a polynomial. It is still an open problem whether there is even a single non-linear polynomial P such that P(n) is prime infinitely often (though it is widely believed that any such polynomial which is coprime to any given modulus infinitely often, such as n^2+n+41, will in fact capture infinitely many primes, cf. Schinzel’s hypothesis H).")

#text("In our paper, we do look a little bit at the “local factors” of a polynomial such as P(n) or P(n,r) with respect to a given modulus q, and in particular how often the polynomial is coprime to q. For certain quadratics such as n^2+n+41, this factor is slightly higher for many small q than for generic quadratics, which may at least partially explain the Ulam spiral phenomenon. But we did not need very precise bounds on these local factors, and we ended up just using extremely crude bounds from baby algebraic geometry. (At one point we were worried that we would have to use some version of the BSD conjecture, though this turned out (fortunately) to be based on a misconception as to where the pole of a certain zeta function was.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uniform uncertainty principle and compressed sensing « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-33765")[#strong[#text("The uniform uncertainty principle and compressed sensing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2008")])]

#text("[…] and randomness in the prime numbers. This lecture is largely equivalent to the one posted here.] Possibly related posts: (automatically generated)Law School Prof: “Never, Ever Talk to a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-33865")[#strong[#text("Quotes on primes « Asymptotics")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2008")]

#text("[…] makes a mathematician go beyond theorems and proofs to praise them. A couple of quotes I found on Terrence Tao’s blog . The first one is based on the reductio ad absurdum proof for the existence of infinitely many […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-35161")[#strong[#text("Más sobre la posible demostración de la hipótesis de Riemann")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2009")]

#text("[…] les dejo un comentarios de vengoroso donde explica las fallas: Traduzco un comentario de Terry Tao en su propio blog: Desafortunadamente parece que la descomposición propuesta en la ecuación (6.9) de la página 20 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Two more Clay-Mahler lectures « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-41315")[#strong[#text("Two more Clay-Mahler lectures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2009")])]

#text("[…] and randomness in the prime numbers“. This public lecture is slightly updated from a previous talk of the same name given last year, but is largely the same […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fef8f70f4107cea8412e6ac23aa94b18e9cf4808cd8f072d9526a0165a7fd32-f5b550e5d611f34e98fecc05b5f0def559211164ebab8ad3421da40c3748f782.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Robinson")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-41630")[#strong[#text("Ian Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Dear Professor Tao")

#text("Good morning, my name is Ian Robinson living on the east coast of Australia. I am contacting you with regards to the distribution of Prime Numbers. There seems to be two accepted facts about their distribution, one is that they do seem to grow like weeds among the natural numbers, and two they do have stunning regularity with laws governing their behaviour with military precision.")#linebreak()#text(" I am writing with a humble air of confidence because yesterday I re-discovered the true distribution of Primes and their supporting Composites.")#linebreak()#text(" The Prime Numbers are responsible for the physical structure of in this instance the ‘Whirlpool Galaxy.’ In a nutshell the Prime Numbers are strategically placed on the spiralling arms of the galaxy, they can be seen as naturally plotted prominent star clusters on the spiralling arms that give physical structure to the trunk and branches. I achieved this discovery by measuring the distance of each prime number from a centre point then plotted the distance down onto paper whilst moving in a clockwise direction,I then joined up the dots to complete the spiralling picture of Prime Numbers. I repeated the process with the composite numbers and joined up the dots that spiralled outwards with stunning regularity resembling a spiders web, yet both sets of numbers are working in complete unison.")#linebreak()#text(" The image of the physical makeup of the Whirlpool Galaxy looks identical to my drawing, I have deliberately withheld an important piece of the jigsaw until a later date.")#linebreak()#text(" The truth is I require someone with a bit of mathematical clout to give these findings the validity and respect they deserve, no one else is aware of my findings.")#linebreak()#text(" A timely response will be much appreciated Professor Tao and believe me this discovery is for real and not a fabricated hoax.")

#text("Thank you")

#text("Regards")

#text("Ian Robinson")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/045d1f61a73bb9b4fd9574480712bc131bd044d5078e18bf759e745c7b2a0f26-16d79c66a3f90c0024bcdcb05ecc46522c6c9243bd8b21726f6227bb7a6adde0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primepatterns")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-49396")[#strong[#text("primepatterns")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2011")])]

#text("Ian, I see the whirlpool galaxy too //primepatterns.wordpress.com should get you there. Don’t be shy, share your findings!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5434cbe6735b39d016df344c98f14c3f516eaa1b059789e3898f678bca6b896a-a13f575b72506d6bfba68bcd531eb570ba3ec515ea61a8f396e9926169ea1c9e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Struktur dan keteracakan bilangan prima « Proof { }")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-42314")[#strong[#text("Struktur dan keteracakan bilangan prima « Proof { }")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")])]

#text("[…] Struktur dan keteracakan bilangan prima 2009 February 19 tags: bilangan, matematika, Math, prima, struktur by Aria Turns Structure and randomness in the prime numbers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ed5ea838ea42194d6ef5dabd317881aa826e0388029e5a9b6b29e9f9abe0cd-d9eea670f465dea5f792b23d153eac63a7072166cbc3a218ff81ecf1c405f385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pardamean Panjaitan")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-42623")[#strong[#text("Pardamean Panjaitan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2009")])]

#text("Very glad to know you, Mr.Terence Tao. I’m Pardamean Panjaitan from Indonesian. Hmmm, there is any simple arithmatic or geometric series equation that can produce first ten prime numbers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df2daf7703ca488772c4b7faaac22c54dede777827e70dba047a3fc0d77abefe-547bb32fbaeb7ae99ad30708abd44ddf6dea237f32504739b9f035cc1e57bf3a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tarandeep")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-42642")[#strong[#text("tarandeep")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("Hi Prof. Tao,")

#text("I had a query. Assuming I have two numbers that are relatively prime (a,b) and a>b . Now if I perform the following operation :")

#text("a/b => c. Its obvious c is a real number.")

#text("The query I have is the following: Is there any generic method/formula using which we can eliminate/minimize/reduce the decimal part of the resulting number (that can be applied to all or almost all a,b pairs).")

#text("For eg: (17,3) or (19,3)..")

#text("Thanks a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e13182a44f061c8601df5e94f22e72296f833f4520df4541d553abd1d800ae6d-d61f54a7c7316c5d6beeb53fc2349dfd34e87cbd7cb78d48522eb5466abf1291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michele")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-47355")[#strong[#text("michele")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2010")])]

#text("Dear Prof. Tao,")

#text("I’m very glad to point out a very intersting example of the mathematical connections between some sectors of Number Theory and some sectors of String Theory. I think that the Number Theory will be always very useful for the future applications of the theoretical physics")

#link("http://eprints.bice.rm.cnr.it/2981/1/TNC2.pdf")[#text("Click to access TNC2.pdf")]

#text("all my best wishes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a31a82c10f6c0c0fb72e58403deed3a1a817f3e10e81bf7290d0b466929c4e3f-9fcb3f90b882e997de502a07b649fecc68c20a8748676d1893e77ec08d2ea72a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete Quinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-49369")[#strong[#text("Pete Quinn")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2011")])]

#text("Dr. Tao,")

#text("I’m wondering if you are aware of any peer reviewed work discussing patterns and symmetry of prime numbers in relation to the primorials.")

#text("Cheers,")

#text("Pete")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a31a82c10f6c0c0fb72e58403deed3a1a817f3e10e81bf7290d0b466929c4e3f-9fcb3f90b882e997de502a07b649fecc68c20a8748676d1893e77ec08d2ea72a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete Quinn")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-49390")[#strong[#text("Pete Quinn")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2011")])]

#text("Dr. Tao, let me elaborate on the reason for my question. I’ve also posted this in similar form a few hours ago at PrimeGrid here:")

#link("http://www.primegrid.com/forum_thread.php?id=2991")[#text("http://www.primegrid.com/forum_thread.php?id=2991")]

#text("For any primorial Pn#, there appears to be a pattern of possible primes that repeats forward to infinity. For example, P2# (i.e. 3#, or 6), the repeating pattern is 6m +/-1.")

#text("We can find the possible prime repetition pattern for P(n+1)# by first repeating the Pn# pattern P(n+1) times, and then removing all prime products of Pn, using only other prime numbers greater than P(n+1) but less than Pn#.")

#text("For example, start with 1,0,0,0,1,0 as a series of possible primes for P2#. This is the P2# sieve. To get the P3# sieve, repeat the series 5 times:")

#text("1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0 (here 1 indicates a number in this position “may” be prime, and a 0 indicates the number is not prime)")

#text("Now remove all multiples of five from this series. The only ones that remain involve a product of 5 with 1 and other primes greater than or equal to 5. In this case that means only 5 (since 5 x 7 is outside P3# and is therefore of no interest for this step), so we remove 5 and 25. The following represents the possible primes for every subsequent group of 30 integers:")

#text("1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")

#text("Note, the values removed through this first sweep are symmetric about the mid-point of P3#. This seems to be the case for all primorial sets for the first pass of removal. Therefore, we only need to remove the prime multiples of 5 up to P3#/2, and then we can simply reflect the result about P3#/2 (e.g. reflecting 5 about 15 would give us 25 as expected).")

#text("This leaves the P3# sieve, which can be repeated forever as an indication of all possible future primes, but refined again at the next level (i.e. converted to a 7# sieve by repeating 7 times and then removing all products of 7 with 1, then primes from 7 to 30, including any products involving more than one other prime) to help us get the primes at subsequent levels.")

#text("The next step within P3#, to leave only prime numbers standing (the whole point, right?), is to remove all products of primes using only prime numbers greater than P3 (5 in this case). For Pn=5 there are no other products of primes greater than 5 less than 30, so this step makes no difference.")

#text("Note that for 1 to 30, this pattern is correct except for the primes already established up to P2#, which need to be retained in the list of known primes. In this stage we’re ony interested in finding the primes between 6 and 30, as primes up to 6 were previously decided and recorded.")

#text("Note that as Pn increases, and we have more primes as factors in Pn#, the process attracts a little more complexity. Recall the sieve for the next higher primordial uses the following sequence:")

#text("1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")

#text("but will be repeated 7 times:")

#text("1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")

#text("To generate the sieve for the next primorial, remove all prime products of 7 as previously described, e.g. 7, 49, 77, 91, 119, 133, 161, 203. The distribution of these prime products involving 7 and one other number will be symmetric, so we could only find the first four, then reflect then about 105.")

#text("1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,0")#linebreak()#text(" 1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0")#linebreak()#text(" 0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,1,0")

#text("We can duplicate this pattern 11 times to get the possible primes for every 2310 (11#) numbers.")

#text("However, we first want to identify all the prime numbers between 5# and 7# (30 and 210). To do this, we now need to remove all products of primes GREATER than 7 yielding a product of interest. This means if we delete 121 (11 x 11), 143 (11 x 13), 169 (13 x 13) and 209 (11 x 19), it will leave us with only prime numbers up to 210.")

#text("The process is the same for larger Pn#, except we need to consider products of a larger number of primes in the sieving within a given range from P(n-1)# to Pn#.")

#text("At first glance this might seem to boil down to an equivalent of the sieve of Erathosthenes, but I think it reduces to an exponentially smaller number of calculations as you are able to take advantage of the patterns, periodicity and symmetry embedded in the sequence of prime numbers.")

#text("This would be easier for me to explain with some of the graphs I used to visualize this. I have likely not fully explained the key steps, but hopefully you can get the gist.")

#text("I’ve only explained the general process of generating the sieves and focussing the search to eliminate the rest of the non-pimes, but it should be obvious that those other steps can also be described coherently.")

#text("Please note I tend to be a little careless with details, so it’s quite possible (likely even!) there are some minor errors embedded in this post. I don’t think they detract from what I’ve presented, but perhaps they do, and feel free to let me know.")

#text("I’m interested to know whether there are any obvious errors in this algoritm, and if not, whether it may represent a novel idea. I realize the possibility of novelty is quite remote, but I haven’t seen the idea yet anywhere else, at least not fully developed. I’ve found a blogger with some similar ideas working on a helix concept here:")

#link("http://primepatterns.wordpress.com/2010/06/12/6/")[#text("http://primepatterns.wordpress.com/2010/06/12/6/")]

#text("And I’ve seen some mention of patterns within the primorials elsewhere. But the discussion of patterns in the peer reviewed literature does not seem to cover this ground, at least not from what I’ve managed to find.")

#text("Criticism from others, either friendly or harsh, is also welcome. :-)")

#text("Cheers,")

#text("Pete")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-49516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2011")])]

#text("Pete,")

#text("What you’re saying about prime patterns seems correct to me.")

#text("See my blog for a related attempt to prove the twin prime conjecture, which relies on symmetrical primorial patterns..")

#link("http://barkerhugh.blogspot.com/")[#text("http://barkerhugh.blogspot.com/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63507d58f2688659e3ec289e8dedf0e9fe7dafc97de53fe1f4087c53ab84cad6-9c143ef9e4134bbefac6c9ec79045ef7cc7df8023eb751a81b33587e2fc3de00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ฟังเพลง")]], [#link("https://terrytao.wordpress.com/2008/02/07/structure-and-randomness-in-the-prime-numbers/comment-page-1/#comment-49408")[#strong[#text("ฟังเพลง")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2011")])]

#text("I achieved this discovery by measuring the distance of each prime number from a centre point then plotted the distance down onto paper whilst moving in a clockwise direction")
]
