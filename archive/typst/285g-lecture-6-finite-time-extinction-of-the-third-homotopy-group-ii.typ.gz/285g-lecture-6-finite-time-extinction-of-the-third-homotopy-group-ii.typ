// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/
// Converted to Typst by tao2typ: "2026-10-14T06:59:10.927882+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 6: Finite time extinction of the third homotopy group, II", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 6: Finite time extinction of the third homotopy group, II")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/")[#text("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("In this lecture we discuss Perelman’s original approach to finite time extinction of the third homotopy group (Theorem 1 from the ")#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/")[#text("previous lecture")]#text("), which, as previously discussed, can be combined with the finite time extinction of the second homotopy group to imply finite time extinction of the entire Ricci flow with surgery for any compact simply connected Riemannian 3-manifold, i.e. Theorem 4 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(".")

#metadata(none) <tao-0230552622bbf9e5481e>

#heading(level: 1)[#text("— Minimal disks —")]

#text("In ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("Lecture 4")]#text(", we studied ")#link("http://en.wikipedia.org/wiki/Minimal_surface")[#text("minimal")]#text(" ")#link("http://en.wikipedia.org/wiki/Immersion_%28mathematics%29")[#text("immersed")]#text(" spheres ")#mi("f: S^2 \\to M")#text(" into a three-manifold, and how their area varied with respect to Ricci flow. This area variation formula was used to establish ")#mi("\\pi_2")#text(" extinction, and was also used in the Colding-Minicozzi approach to ")#mi("\\pi_3")#text(" extinction (see ")#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/")[#text("Lecture 5")]#text("). The Perelman approach is similar, but is based upon minimal disks rather than minimal 2-spheres, which we will define as Lipschitz immersed maps ")#mi("f: D^2 \\to M")#text(" from the unit disk D to M which are smooth on the interior of the disk, and with mean curvature zero on the interior of the disk.")

#text("For simplicity let us restrict attention to 3-manifolds (M,g) which are simply connected (this case is, of course, our main concern in this course). Then every loop ")#mi("\\gamma: S^1 \\to M")#text(" spans at least one disk. Let ")#mi("A(\\gamma,g)")#text(" denote the minimal area of all such spanning disks. From the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=27137")[#text("Morrey")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=248650")[#text("Hildebrandt")]#text(" on ")#link("http://en.wikipedia.org/wiki/Plateau_problem")[#text("Plateau’s problem")]#text(" in Riemannian manifolds, it is known that this area is in fact attained by a minimal disk whose boundary traces out ")#mi("\\gamma")#text(". (The fact that this disk is immersed was established by ")#link("http://www.ams.org/mathscinet-getitem?mr=346641")[#text("Gulliver-Lesley")]#text(" and by ")#link("http://www.ams.org/mathscinet-getitem?mr=809969")[#text("Hardt-Simon")]#text(".) One can think of ")#mi("A(\\gamma,g)")#text(" as the two-dimensional generalisation of the distance function ")#mi("d(x,y)")#text(" between two points ")#mi("x,y")#text(" (which one can think of a map from ")#mi("S^0")#text(" to M). For instance, we have the following first variation formula for ")#mi("A(\\gamma,g)")#text(" analogous to that for the distance function.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (First variation formula) Let ")#mi("\\gamma: S^1 \\to M")#text(" be a loop in a 3-manifold (M,g), and let ")#mi("f: D^2 \\to M")#text(" be a minimal-area disk spanning ")#mi("\\gamma")#text(", thus ")#mi("\\int_{f(D^2)}\\ d\\mu = A(\\gamma,g)")#text(". Let ")#mi("t \\mapsto \\gamma_t")#text(" be a smooth deformation of ")#mi("\\gamma")#text(" with ")#mi("\\gamma_0 = \\gamma")#text(". Then we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{d}{dt} A(\\gamma_t,g)|_{t=0} \\leq \\int_\\gamma g( N, \\frac{d}{dt} \\gamma_t|_{t=0} )\\ ds")]]

#text("where ds is the length element and n is the outward normal vector to ")#mi("f(D^2)")#text(" on the boundary ")#mi("\\gamma")#text(".")
]

#strong[#text("Proof. ")]#text("First suppose that ")#mi("\\frac{d}{dt} \\gamma_t|_{t=0}")#text(" is orthogonal to the disk ")#mi("f(D^2)")#text(". Then one can deform the disk ")#mi("f(D^2)")#text(" to span ")#mi("\\gamma_t")#text(" for infinitesimally non-zero times t by flowing the disk along a vector field normal to that disk. Since ")#mi("f(D^2)")#text(" is minimal, it has mean curvature zero, and so the first variation of the area in this case is zero by the calculation used to prove Proposition 2 of ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("Lecture 4")]#text(". Since the area of this deformed disk is an upper bound for ")#mi("A(\\gamma_t,g)")#text(", this proves (1) in this case.")

#text("In the case when ")#mi("\\frac{d}{dt} \\gamma_t|_{t=0}")#text(" is tangential to ")#mi("f(D^2)")#text(", the claim is clear simply by modifying the disk ")#mi("f(D^2)")#text(" at the boundary to accommodate the change in ")#mi("\\gamma_t")#text(" with respect to the time parameter t. The general case then follows by combining the above two arguments. ")#mi("\\Box")

#text("Now we let the manifold evolve by Ricci flow, and obtain a similar variation formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" (First variation formula with Ricci flow) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a Ricci flow, and for each time t let ")#mi("\\gamma_t: S^1 \\to M")#text(" be a loop in a 3-manifold (M,g) smoothly varying in t, and let ")#mi("f_t: D^2 \\to M")#text(" be a minimal-area disk spanning ")#mi("\\gamma_t")#text(". Then we have")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dt} A(\\gamma_t,g(t))  & \\leq -\\int_{f_t(D^2)} K_{f_t(D^2)}\\ d\\mu - \\frac{1}{2} R_{\\min} A(\\gamma_t,g(t))", block: true)



#tao-math(" & + \\int_{\\gamma_t} g( N_t, \\frac{d}{dt} \\gamma_t)\\ ds", block: true, numbering: n => [#text("(2)")])
]

#text("where ")#mi("K_{f_t(D^2)}")#text(" is the Gauss curvature of ")#mi("f_t(D^2)")#text(".")
]

#strong[#text("Proof.")]#text(" This follows from the chain rule and the computations used to derive equation (13) from Lecture 4. ")#mi("\\Box")

#text("To deal with the Gauss curvature term, we need an analogue of the Gauss-Bonnet theorem for disks. Fortunately, we have such a result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" (Gauss-Bonnet for disks) Let ")#mi("f: D^2 \\to M")#text(" be an immersed disk with boundary ")#mi("\\gamma")#text(". Then we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\int_{f(D^2)} K_{f(D^2)}\\ d\\mu + \\int_\\gamma k_{\\gamma,f(D^2)}\\ ds = 2\\pi")]]

#text("where ")#mi("k_{\\gamma,f(D^2)} = -g( \\nabla_T T, N )")#text(" is the signed ")#link("http://en.wikipedia.org/wiki/Curvature")[#text("curvature")]#text(" of the curve ")#mi("\\gamma")#text(" relative to the disk ")#mi("f(D^2)")#text(" (here T is the unit tangent vector to ")#mi("\\gamma")#text(", oriented in either direction; we are also abusing notation slightly by pulling back the Levi-Civita connection on TM to the pullback bundle ")#mi("S^1")#text(" in order to define ")#mi("\\nabla_T T")#text(" properly).")
]

#strong[#text("Proof.")]#text(" We use another flow argument. All quantities here are intrinsic and so we may pull back to the unit disk ")#mi("D^2")#text(". Our task is now to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\int_{D^2} K\\ d\\mu - \\int_{S^1} g(\\nabla_T T, N)\\ ds = 2\\pi")]]

#text("for all metrics ")#mi("(D^2,g)")#text(" on the unit disk. (Note that the vectors T, N will depend on g.) By the argument used to prove Proposition 1 in ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("Lecture 4")]#text(", the left-hand side is invariant under any ")#emph[#text("compactly supported")]#text(" perturbation of the metric g, so we may assume that the metric is Euclidean on some neighbourhood of the origin.")

#text("We express ")#mi("D^2")#text(" in polar coordinates ")#mi("(r,\\theta)")#text(". It will then suffice to establish the R=1 case of the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\int_0^R \\int_0^{2\\pi} K(r,\\theta) (\\partial_r \\wedge \\partial_\\theta)\\ d\\theta dr - \\int_0^{2\\pi} (\\nabla_{\\partial_\\theta} T \\wedge T)(R,\\theta)\\ d\\theta = 2\\pi")]]

#text("where we use the metric g to identify the 2-form ")#mi("\\partial_r \\wedge \\partial_\\theta")#text(" with a scalar, and T and N on ")#mi("(R,\\theta)")#text(" are the tangent and outward normal vectors to the circle ")#mi("\\{r=R\\}")#text(" (the orientation of T is not relevant, but let us fix it as anticlockwise for sake of discussion, with the orientation chosen so that ")#mi("N \\wedge T")#text(" is positive). Note here that we are heavily relying on the two-dimensionality of the situation!")

#text("Because the metric is Euclidean near the origin, (5) is true for R close to zero. Thus by the fundamental theorem of calculus, it suffices to verify the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_0^{2\\pi} K(r,\\theta) (\\partial_r \\wedge \\partial_\\theta)\\ d\\theta - \\int_0^{2\\pi} \\partial_r (\\nabla_{\\partial_\\theta} T \\wedge T)(R,\\theta)\\ d\\theta = 0.")]]

#text("for all ")#mi("0 < r < 1")#text(". But as the Levi-Civita connection respects the metric (and all constructions arising from that metric, such as the identification of 2-forms with scalars) we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\partial_r (\\nabla_{\\partial_\\theta} T \\wedge T) = (\\nabla_{\\partial_r} \\nabla_{\\partial_\\theta} T \\wedge T) + (\\nabla_{\\partial_\\theta} T \\wedge \\nabla_{\\partial_r} T).")]]

#text("Since T is always a unit vector, ")#mi("\\nabla_{\\partial_\\theta} T")#text(" and ")#mi("\\nabla_{\\partial_r} T")#text(" must be orthogonal to T and thus (in this two-dimensional setting) must be parallel, so the last term in (7) vanishes. An integration by parts then shows that ")#mi("(\\nabla_{\\partial_\\theta} \\nabla_{\\partial_r} T \\wedge T")#text(" has vanishing integral. Finally, from the Bianchi identities that allow one to express Riemann curvature of 2-manifolds in terms of Gauss curvature, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("(\\nabla_{\\partial_r} \\nabla_{\\partial_\\theta} - \\nabla_{\\partial_\\theta} \\nabla_{\\partial r})T \\wedge T = K (\\partial_r \\wedge \\partial_\\theta)")]]

#text("and the claim follows. ")#mi("\\Box")

#strong[#text("Exercise 1.")]#text(" Use Proposition 1 to reprove Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("Lecture 4")]#text(". ")#mi("\\diamond")

#text("We can now combine Corollary 1 and Proposition 1as follows. We say that a family of curves ")#mi("\\gamma_t: S^1 \\to M")#text(" is undergoing ")#emph[#text("curve-shortening flow")]#text(" if we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\frac{\\partial}{\\partial t} \\gamma_t = \\nabla_T T")]]

#text("where T is the tangent vector to ")#mi("\\gamma_t")#text(".")

#strong[#text("Exercise 2. ")]#text("If ")#mi("\\gamma_t")#text(" undergoes curve-shortening flow, show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\frac{d}{dt} \\int_{\\gamma_t}\\ ds = - \\int_{\\gamma_t} \\left|\\nabla_T T\\right|_g^2\\ ds", block: true)]]

#text("which may help explain the terminology “curve-shortening flow”. ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2.")]#text(" (First variation formula with Ricci flow and curve shortening flow) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a Ricci flow, and for each time t let ")#mi("\\gamma_t: S^1 \\to M")#text(" be a loop in a 3-manifold (M,g) undergoing curve shortening flow, and let ")#mi("f_t: D^2 \\to M")#text(" be a minimal-area disk spanning ")#mi("\\gamma_t")#text(". Then we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{d}{dt} A(\\gamma_t,g(t)) \\leq -2\\pi + \\frac{1}{2} R_{\\min} A(\\gamma_t,g(t)).")]]
]

#heading(level: 1)[#text("— Perelman’s width functional —")]

#text("We now begin a non-rigorous discussion of Perelman’s width functional, and how it is used to derive finite time ")#mi("\\pi_3")#text(" extinction. There is a significant analytical difficulty regarding singularities in curve shortening flow, but we will address this issue later.")

#text("To simplify the exposition slightly, we will restrict attention to compact 3-manifolds whose components are all simply connected, and take advantage of Remark 2 in ")#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/")[#text("Lecture 5")]#text(", although one can avoid use of this remark (and extend the analysis here to slightly more general manifolds, namely those with fundamental group a direct sum of cyclic groups and finite groups, and which contain no embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle) by using the ")#mi("\\pi_2")#text(" extinction theory from ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("Lecture 4")]#text(".")

#text("By this remark, all connected components of such manifolds are ")#link("http://en.wikipedia.org/wiki/Homotopy_sphere")[#text("homotopy spheres")]#text(", and in particular have trivial ")#mi("\\pi_2")#text(" and ")#mi("\\pi_3")#text(" isomorphic to the integers; thus every map ")#mi("f: S^3 \\to M")#text(" has a ")#link("http://en.wikipedia.org/wiki/Degree_%28continuous_map%29")[#text("degree")]#text(" ")#mi("\\text{deg}(f) \\in {\\Bbb Z}")#text(". This degree only fixed up to sign, so we shall work primarily with the magnitude ")#tao-math("\\left|\\text{deg}(f)\\right|", block: false)#text(" of this degree.")

#text("Let M be one of these connected components, and fix a base point ")#mi("x_0 \\in M")#text(".")

#text("We can identify ")#mi("S^3")#text(" with the space ")#mi("S^2 \\times S^1 / (\\{ p_2 \\} \\times S^1) \\cup (S^2 \\times \\{p_1\\})")#text(", where ")#mi("p_1, p_2")#text(" are base points of ")#mi("S^1, S^2")#text(" respectively, thus we contract ")#mi("\\{ p_2 \\} \\times S^1")#text(" and ")#mi("S^2 \\times \\{p_1\\}")#text(" to a single point ")#mi("p_3")#text(". (To see why these spaces are topologically isomorphic, use the standard identification of n-sphere ")#mi("S^n")#text(" with an n-cube ")#mi("{}[0,1]^n")#text(" with the entire boundary identified with a point ")#mi("p_n")#text(".) Thus, any map ")#mi("f: S^3 \\to M")#text(" with ")#mi("f(p_3) = x_0")#text(" can be viewed as a family ")#mi("\\gamma_\\omega: S^1 \\to M")#text(" of loops with fixed base point ")#mi("\\gamma_\\omega(p_1) = x_0")#text(" for ")#mi("\\omega \\in S^2")#text(", such that ")#mi("\\gamma_\\omega")#text(" varies continuously in ")#mi("\\omega")#text(" and is identically equal to ")#mi("x_0")#text(" when ")#mi("\\omega = p_2")#text(".")

#text("A little more generally, define a ")#emph[#text("loop family")]#text(" ")#mi("\\gamma = (\\gamma_\\omega)_{\\omega \\in S^2}")#text(" to be a family ")#mi("\\gamma_\\omega: S^1 \\to M")#text(" of loops parameterised continuously by ")#mi("\\omega \\in S^2")#text(", such that ")#mi("\\gamma_{p_2} \\equiv x_0")#text(". (To put it another way, a loop family is a continuous map from ")#mi("S^2")#text(" to the ")#link("http://en.wikipedia.org/wiki/Loop_space")[#text("loop space")]#text(" ")#mi("\\Lambda M")#text(" which has the constant loop ")#mi("x_0")#text(" as base point; equivalently, a loop family is a continuous map from ")#mi("S^2 \\times S^1 / \\{p_2\\} \\times S^1")#text(" which maps ")#mi("\\{p_2\\} \\times S^1")#text(" to ")#mi("x_0")#text(".) Thus we see that every map ")#mi("f: S^3 \\to M")#text(" with ")#mi("f(p_3)=x_0")#text(" generates a loop family. The converse is not quite true, because we are not requiring the loops ")#mi("\\gamma_\\omega")#text(" in a loop family to have fixed base point (i.e. we do not require ")#mi("\\gamma_\\omega(p_1)=x_0")#text(" for all ")#mi("\\omega")#text(", only for ")#mi("\\omega=p_2")#text("). However, as ")#mi("\\pi_2(M)")#text(" is trivial, the 2-sphere ")#mi("\\omega \\mapsto \\gamma_\\omega(p_1)")#text(" is contractible, and so every loop family is homotopic to a loop family associated to a map ")#mi("f: S^3 \\to M")#text(", and so in particular can be assigned a degree ")#tao-math("\\left|\\text{deg}(\\gamma)\\right|", block: false)#text(". This degree is well-defined and stable under deformations:")

#strong[#text("Exercise 3.")]#text(" Show that each loop family ")#mi("\\gamma")#text(" is associated to a unique degree magnitude, no matter how one chooses to contract the 2-sphere ")#mi("\\omega \\mapsto \\gamma_\\omega(p_1)")#text(". Also, show that if a loop family ")#mi("\\gamma")#text(" can be continuously deformed to another loop family ")#mi("\\tilde \\gamma")#text(" while staying within the class of loop families, then both loop families have the same degree . Conclude that the space of homotopy classes ")#mi("\\pi_2(\\Lambda M, x_0)")#text(" of loop families can be canonically identified with ")#mi("\\pi_3(M) \\equiv {\\Bbb Z}")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 4.")]#text(" Show that for any ")#mi("d \\geq 1")#text(", the quotient ")#mi("S^d \\times S^1 / \\text{pt} \\times S^1")#text(" is ")#link("http://en.wikipedia.org/wiki/Homotopy_equivalent#Homotopy_equivalence_and_null-homotopy")[#text("homotopy equivalent")]#text(" to the ")#link("http://en.wikipedia.org/wiki/Wedge_sum")[#text("wedge sum")]#text(" ")#mi("S^d \\vee S^{d+1}")#text(", and then use this to give another proof of Exercise 3. (Hint: first show that both spaces are homotopy equivalent to a sphere ")#mi("S^{d+1}")#text(" with a disk ")#mi("D^d")#text(" glued to it (identifying the boundary ")#mi("\\partial D^d")#text(" of the disk with some copy of ")#mi("S^{d-1}")#text(" in ")#mi("S^{d+1}")#text("). The case ")#mi("d=1")#text(" might be easiest to visualise.) (Thanks to Kenny Maples, Peter Petersen, and Paul Smith for this hint.) ")#mi("\\diamond")

#text("[")#emph[#text("Aside")]#text(": the identification of ")#mi("\\pi_3(M)")#text(" with ")#mi("\\pi_2(\\Lambda M, x_0)")#text(" presumably must also be immediate from the ")#link("http://en.wikipedia.org/wiki/Homotopy_group#Long_exact_sequence_of_a_fibration")[#text("homotopy long exact sequence for fibrations")]#text(", though I wasn’t able to see this clearly.]")

#text("Given a loop family ")#mi("\\gamma = (\\gamma_\\omega)_{\\omega \\in S^2}")#text(", define the ")#emph[#text("width")]#text(" ")#mi("\\tilde W_3(\\gamma)")#text(" of this family to be the quantity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\tilde W_3(\\gamma) := \\sup_{\\omega \\in S^2} A( \\gamma_\\omega )")]]

#text("and then for every non-negative ")#mi("\\xi \\in {\\Bbb Z}^+")#text(", define the width ")#mi("\\tilde W_3(\\xi)")#text(" to be the quantity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\tilde W_3(\\xi) := \\inf_{\\gamma: \\left|\\text{deg}(\\gamma)\\right|= \\xi} \\tilde W_3(\\gamma)", block: true)]]

#text("(this is an inf of a sup of an inf!). We can define this concept for non-empty disconnected manifolds M also, by taking the infimum across all components and all choices of base point.")

#text("I do not know if ")#mi("\\tilde W_3(\\xi)")#text(" is always positive when M is non-empty and ")#mi("\\xi")#text(" is positive (or equivalently, that if one has a loop family in which each loop is spanned by a disk of small area, that the entire loop family is contractible to a point). However, one can at least say that if ")#mi("\\gamma")#text(" is a loop family associated to a non-trivial degree ")#mi("\\xi")#text(", then the length ")#mi("\\int_{\\gamma_\\omega} ds")#text(" of at least one of the loops ")#mi("\\gamma_\\omega")#text(" is bounded away from zero by some constant depending only on ")#mi("M = (M,g)")#text(", because if instead all loops had small length, then they could be contracted to a point, thus degenerating the loop family to an image of ")#mi("S^2")#text(", which is contractible since we are assuming ")#mi("\\pi_2(M)")#text(" to be trivial. This lower bound on length is important for technical reasons (which we are mostly suppressing here).")

#text("Let us temporarily pretend, though, that at some point in time during a Ricci flow ")#mi("t \\mapsto (M,g(t))")#text(", that ")#mi("\\tilde W_3(\\xi) = \\tilde W_3(\\xi,t)")#text(" is positive for some positive ")#mi("\\xi")#text(", and that the infimum in (12) is attained by a smooth loop family ")#mi("\\gamma")#text(", thus ")#mi("A(\\gamma_\\omega,g(t))")#text(" attains a maximum value of ")#mi("\\tilde W_3(\\xi,t)")#text(" for some ")#mi("\\omega \\in S^2")#text(".")

#text("We now run the Ricci flow, while simultaneously deforming each loop ")#mi("\\gamma_\\omega")#text(" in the loop family by curve-shortening flow (local existence for the latter flow is a result of ")#link("http://www.ams.org/mathscinet-getitem?mr=840401")[#text("Gage and Hamilton")]#text("). Applying (10), we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\frac{d}{dt} \\tilde W_3(\\gamma) \\leq -2\\pi - \\frac{1}{2} R_{\\min} \\tilde W_3(\\gamma)")]]

#text("(in the sense of forward difference quotients), and thus by assumption on ")#mi("\\gamma")#text(" that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\frac{d}{dt} \\tilde W_3(\\xi) \\leq -2\\pi - \\frac{1}{2} R_{\\min} \\tilde W_3(\\xi).")]]

#text("Now we investigate what happens when a surgery occurs. It turns out that whenever a component of a pre-surgery manifold is disconnected into components of a post-surgery manifold, that there exist degree 1 (or -1) maps from the pre-surgery components to each of the post-surgery components (recall that all components are homotopy spheres, and in particular the 2-spheres that one performs surgery on are automatically contractible). Furthermore, these maps can be chosen to have Lipschitz constant less than ")#mi("1 + \\eta")#text(" for any fixed ")#mi("\\eta > 0")#text(", thus they are almost contractions. (We will discuss this fact later in this course, when we define surgery properly.) Because of this, we can convert any loop family on the pre-surgery component to a loop family on the post-surgery component which has the same degree magnitude and which has only slightly larger width at worst. Because of this, we can conclude that ")#mi("\\tilde W_3(\\xi)")#text(" does not increase during surgery.")

#text("By arguing as in ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("Lecture 4")]#text(" we now conclude (using (14) and lower bounds in ")#mi("R_{\\min}")#text(") that either the manifold becomes totally extinct or that ")#mi("\\tilde W_3(\\xi)")#text(" becomes negative. The latter is absurd, and so we obtain the required finite time extinction (indeed, we have shown extinction not just of ")#mi("\\pi_3")#text(" here, but of the entire manifold).")

#heading(level: 1)[#text("— Ramps —")]

#text("The above argument had one significant gap in it; it assumed that the infimum in (12) was always attained. In practice, this is not necessarily the case, and so the best one can do is find loop families ")#mi("\\gamma")#text(" for each time t with homotopy class ")#mi("\\xi")#text(" whose width is within ")#mi("\\varepsilon")#text(" of the minimal width ")#mi("\\tilde W_3(\\xi, t)")#text(", for any small ")#mi("\\varepsilon > 0")#text(". One can try to run the above arguments with this near-minimiser ")#mi("\\gamma")#text(" in place of an exact minimiser, but in order to do so, it is necessary to ensure that the curve-shortening flow, when applied to ")#mi("\\gamma")#text(", exists for a period of time that is bounded from below uniformly in ")#mi("\\varepsilon")#text(".")

#text("Unfortunately, the local existence theory of ")#link("http://www.ams.org/mathscinet-getitem?mr=840401")[#text("Gage and Hamilton")]#text(" (see also ")#link("http://www.ams.org/mathscinet-getitem?mr=1158337")[#text("Altschuler and Grayson")]#text(") only guarantees such a uniform lower bound on time of existence when the curvature magnitude ")#tao-math("\\kappa := \\left|\\nabla_T T\\right|_g", block: false)#text(" of these curves is uniformly bounded from above. (Indeed, by considering what curve-shortening flow does to small circles in Euclidean space, it is clear that one cannot hope to obtain uniform lifespan bounds without such a curvature bound.) And, in general, such curvature bounds are not available. (For instance, as one approaches the minimal value of ")#mi("\\tilde W_3(\\xi,t)")#text(", the curves may begin to develop cusps or folds (i.e. they cease to be immersed).)")

#text("To resolve this moderately serious technical obstacle, Perelman employed the use of ")#emph[#text("ramps")]#text(", following the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=1158337")[#text("Altschuler and Grayson")]#text(" (see also a related argument of ")#link("http://www.ams.org/mathscinet-getitem?mr=1117150")[#text("Ecker and Huisken")]#text("). The basic idea is to give all the loops an upward “slope” that is bounded from below, which (in conjunction with the maximum principle) will prevent singularities from forming. In order to create this upward slope, it is necessary to increase the dimension of the ambient manifold M by one, working with ")#mi("M \\times S^1_\\lambda")#text(" instead of M, where ")#mi("S^1_\\lambda = {\\Bbb R}/\\lambda {\\Bbb Z}")#text(" is the circle of length ")#mi("\\lambda")#text(" for some small ")#mi("\\lambda > 0")#text(". (Amusingly, this idea of attaching some tightly rolled up dimensions to space also appears in string theory, though I doubt that there is any connection here.)")

#text("We now turn to the details. We first develop some general variation formulae and estimates for a curve-shortening flow ")#mi("t \\mapsto \\gamma_t")#text(" in a time-varying Riemannian manifold ")#mi("(M,g(t))")#text(" of arbitrary dimension. As before, we let T denote the unit tangent vector along ")#mi("\\gamma_t")#text(". We write ")#mi("H := \\nabla_T T = \\frac{\\partial}{\\partial t} \\gamma")#text(" for the curvature vector, which is of course also the rate of change of the curve under curve shortening flow, and write ")#tao-math("k := \\left|H\\right|_g", block: false)#text(" for the curvature.")

#text("Write x for the variable parameterising the loop ")#mi("\\gamma_t: S^1 \\to M")#text(", and write ")#mi("X := \\frac{\\partial}{\\partial x} \\gamma_t")#text(" for the spatial velocity vector for this loop, thus X is a scalar multiple of the tangent vector T. Here and in the sequel we abuse notation by identifying connections on the tangent bundle TM with connections on pullback bundles.")

#strong[#text("Exercise 5.")]#text(" (Commutativity of X and H) Show that ")#mi("\\nabla_X H = \\nabla_H X")#text(". (Hint: first show that ")#mi("\\nabla_H \\nabla_X F = \\text{Hess}(F)( H, X ) + dF( \\nabla_H X )")#text(" for any scalar function ")#mi("F: M \\to {\\Bbb R}")#text(", and similarly with the roles of H and X reversed. Now use the torsion-free nature of the Levi-Civita connection and duality.) ")#mi("\\diamond")

#text("We now record a variation formula for the squared speed ")#mi("g(X,X)")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" For fixed x, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\frac{\\partial}{\\partial t} g( X, X ) = - 2 \\text{Ric}(X,X) - 2k^2 g(X,X).")]]
]

#strong[#text("Proof. ")]#text("From the chain rule we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\frac{\\partial}{\\partial t} g( X, X ) = ( \\frac{\\partial}{\\partial t} g )(X,X) + 2 g( \\nabla_H X, X ).")]]

#text("The first term on the right-hand side of (16) is ")#mi("- 2 \\text{Ric}(X,X)")#text(" by the Ricci flow equation. On the other hand, H is orthogonal to T (as T is a unit vector), and so ")#mi("g(X,H)=0")#text(". From this and Exercise 5 we have")#mi("g( \\nabla_H X, X ) = g( \\nabla_X H, X ) = - g( H, \\nabla_X X )")#text(". (17)")

#text("Writing X = g(X,X)^{1/2} T, and again using that H is orthogonal to T, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("g( H, \\nabla_X X ) = g(X,X) g( H, \\nabla_T T ) = g(X,X) g(H,H).")]]

#text("Since ")#mi("g(H,H) = k^2")#text(", the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2.")]#text(" We have ")#mi("{}[H,T] = (k^2 + \\text{Ric}(T,T)) T")#text(".")
]

#strong[#text("Proof. ")]#text("We already know that [H,X] vanishes. Expressing ")#mi("X = g(X,X)^{1/2} T")#text(" and using the previous lemma (writing ")#mi("\\frac{\\partial}{\\partial t} g(X,X)")#text(" as ")#mi("\\nabla_H g(X,X)")#text("), the corollary follows after a brief computation. ")#mi("\\Box")

#text("We can now derive a heat equation for the curvature (vaguely reminiscent of a Bochner-type identity):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3.")]#text(" (First variation of squared curvature) We have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\frac{\\partial}{\\partial t} k^2 = \\nabla_T \\nabla_T (k^2) - 2 g( \\pi(\\nabla_T H), \\pi(\\nabla_T H) ) + 2k^4 + O( k^2 )")]]

#text("where ")#mi("\\pi")#text(" is the projection to the orthogonal complement of X, and the implied constants in the O() terms depend only on the Riemannian manifold (M,g(t)) (and in particular on bounds on the Riemann curvature tensor).")
]

#strong[#text("Proof. ")]#text("We write ")#mi("k^2 = g(H,H)")#text(". By the chain rule and the Ricci flow equation we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\frac{\\partial}{\\partial t} g(H,H) = - 2 \\text{Ric}(H,H) + 2 g(\\nabla_H H,H).")]]

#text("The first term on the right-hand side is ")#mi("O(k^2)")#text(" which is acceptable. As for the second term, we expand")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\nabla_H H = \\nabla_H \\nabla_T T = \\nabla_T \\nabla_H T + \\nabla_{[H,T]} T + O(k).")]]

#text("The O(k) term gives a contribution of ")#mi("O(k^2)")#text(" to (20) which is acceptable. By Corollary 2, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\nabla_{[H,T]} T = (k^2 + O(1)) \\nabla_T T = k^2 H + O(k)")]]

#text("which gives a contribution of ")#mi("2k^4 + O(k^2)")#text(" to (20). Finally, we deal with the top-order term ")#mi("\\nabla_T \\nabla_H T")#text(". We express ")#mi("\\nabla_H T = \\nabla_T H + [H,T]")#text(". Applying Corollary 2 (and the orthogonality of T and H), we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("g( \\nabla_T [H,T], H ) = (k^2+O(1)) g( \\nabla_T T, H ) = k^4 + O(k^2)")]]

#text("whereas from the Leibniz rule we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("g(\\nabla_T \\nabla_T H, H) = \\frac{1}{2} \\nabla_T \\nabla_T g(H,H) - g( \\nabla_T H, \\nabla_T H ).")]]

#text("Since H is orthogonal to T, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("g(\\nabla_T H, T) = - g(H, \\nabla_T T) = - g(H,H) = -k^2")]]

#text("and so by Pythagoras")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("g(\\nabla_T H,\\nabla_T H) = g(\\pi(\\nabla_T H),\\pi(\\nabla_T H)) - k^4.")]]

#text("Substituting (26) into (24), and combining this with (23) to calculate the net contribution of ")#mi("\\nabla_T \\nabla_H T")#text(", we obtain (19) as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3.")]#text(" (First variation of curvature) We have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\frac{\\partial}{\\partial t} k \\leq \\nabla_T \\nabla_T k + k^3 + O( k )")]]
]

#strong[#text("Proof.")]#text(" Expanding out (19) using the product rule and comparing with (27), we see that it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("(\\nabla_T k)^2 \\leq g( \\pi(\\nabla_T H), \\pi(\\nabla_T H) ).")]]

#text("But if we differentiate the identity ")#mi("k^2 = g(H,H)")#text(" along T, we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("k \\nabla_T k = g( \\nabla_T H, H ) = g( \\pi(\\nabla_T H), H )")]]

#text("(since H is orthogonal to T) and the claim now follows from Cauchy-Schwarz. ")#mi("\\Box")

#text("Note that by combining this corollary with the maximum principle (Corollary 1 of ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text(") we can get upper bounds on k for short times based on upper bounds for k at time zero. (By using energy estimates, one can also control higher derivatives of k, obtaining the usual parabolic type estimates as a consequence; such estimates are important for the analysis here but we will omit them.) Unfortunately, the non-linear term ")#mi("k^3")#text(" on the right-hand side has an unfavourable sign and can generate finite time blowup.")

#text("The situation is much improved, however, for a special class of loops known as ")#emph[#text("ramps")]#text(". These curves take values not in an arbitrary manifold M, but in a product manifold ")#mi("M \\times S^1_\\lambda")#text(" (with the product Riemannian metric). The point here is that we have a vertical unit vector field U on this manifold (corresponding to infinitesimal rotation of the ")#mi("S^1_\\lambda")#text(" factor) which is completely parallel to the Levi-Civita connection: ")#mi("\\nabla_\\alpha U = 0")#text(". Define a ramp to be a curve ")#mi("\\gamma: S^1 \\to M \\times S^1_\\lambda")#text(" whose unit tangent vector T is always upward sloping in the sense that ")#mi("g(T,U) > 0")#text(" on all of ")#mi("\\gamma")#text(" (thus the ramp must “wrap around” the vertical fibre ")#mi("S^1_\\lambda")#text(" at least once, in order to return to its starting point). In particular, since ")#mi("\\gamma")#text(" is compact, we have a uniform lower bound ")#mi("g(T,U) \\geq c")#text(" for some ")#mi("c > 0")#text(".")

#text("Write ")#mi("u := g(T,U)")#text(" for the evolution of such a ramp under curve shortening flow, thus one can view u as a function of t and x. On the one hand, we have the trivial pointwise bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#tao-math("\\left|u\\right| \\leq 1", block: true)]]

#text("from Cauchy-Schwarz. On the other hand, we have an evolution equation for u:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" (First variation of u) We have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\frac{\\partial}{\\partial t} u = \\nabla_T \\nabla_T u + (k^2 + O(1) )u")]]
]

#strong[#text("Proof. ")]#text("Differentiating u = g(T,U) by the chain rule as before (using the fact that U is parallel to the connection, as well as the Ricci flow equation) we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\frac{\\partial}{\\partial t} u = - 2\\text{Ric}(T,U) + g( \\nabla_H T, U ).")]]

#text("Since U is parallel to the connection, it is annihilated by any commutator ")#mi("\\text{Riem}(X,Y) = [\\nabla_X, \\nabla_Y]")#text(" and thus ")#mi("\\text{Ric}(T,U) = 0")#text(". Writing ")#mi("\\nabla_H T = [H,T] + \\nabla_T H = [H,T] + \\nabla_T \\nabla_T T")#text(" and using Corollary 2, we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\frac{\\partial}{\\partial t} u = (k^2 + O(1)) u + g( \\nabla_T \\nabla_T T, U).")]]

#text("Since U is parallel to the connection, we can write ")#mi("g( \\nabla_T \\nabla_T T, U) = \\nabla_T \\nabla_T g(T,U)")#text(", and the claim follows from the definition of u. ")#mi("\\Box")

#text("As a particular corollary of (31), we have the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#tao-math("\\frac{\\partial}{\\partial t} u \\geq \\nabla_T \\nabla_T u - O(\\left|u\\right|).", block: true)]]

#text("Using the maximum principle (Corollary 1 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text("), and the assumption that u is initially bounded away from zero, we conclude that u continues to be bounded away from zero for all time t for which the curve-shortening flow exists (though this bound can deteriorate exponentially fast in t). In particular, u is positive and the curve continues to be a ramp. Furthermore, by applying the quotient rule to (27) and (31), one obtains after some calculation the differential inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\frac{\\partial}{\\partial t} f \\leq \\nabla_T \\nabla_T f + \\frac{2 \\nabla_T u}{u} \\nabla_T f + O( f )")]]

#text("for the quantity ")#mi("f := k/u")#text(". Applying the maximum principle again, and noting that f is initially bounded at time zero, we conclude that f is bounded for all time for which the solution exists (though again, the bound can deteriorate exponentially in t). Combining this with the trivial bound (30), we conclude that the curvature k is bounded for any period of time on which the solution exists, with the bound deteriorating exponentially in t. Combining this with the local existence theory (see ")#link("http://www.ams.org/mathscinet-getitem?mr=1158337")[#text("Altschuler and Grayson")]#text("), which asserts that the curve shortening flow can be continued whenever the curvature remains bounded, we conclude that curve shortening flows for ramps persist globally in time.")

#text("Of course, in our applications to Ricci flow, the curves ")#mi("\\gamma_\\omega")#text(" that we are applying curve shortening flow to are not ramps; they live in M rather than ")#mi("M \\times S^1_\\lambda")#text(". To address this, one has to embed M in ")#mi("M \\times S^1_\\lambda")#text(" for some small ")#mi("\\lambda")#text(" and approximate each ")#mi("\\gamma_\\omega")#text(" by a ramp that wraps around ")#mi("M \\times S^1_\\lambda")#text(" exactly once. One then flows the ramps by curve shortening flow, and works with the minimal spanning areas ")#mi("A(\\gamma)")#text(" of these evolved ramps (rather than working with the curve shortening flow applied directly to the original curves).")

#text("There are of course many technical obstacles to this strategy. One of them is that one needs to show that small changes in the ramp ")#mi("\\gamma")#text(" do not significantly affect the area ")#mi("A(\\gamma)")#text(" of the minimal spanning disk. To achieve this, one needs to show that if two ramps ")#mi("\\gamma_1, \\gamma_2")#text(" are initially close in the sense that there is an annulus connecting them of small area, then they stay close (in the same sense) for any bounded period of time under curve shortening flow. This can be accomplished by using a first variation formula for area of minimal annuli which is similar to Corollary 2. There are several other technical difficulties of an analytical nature to resolve; see Chapter 19 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(" for full details.")

#text("[")#emph[#text("Update")]#text(", Apr 21: New exercise added; various corerctions.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-29233")[#strong[#text("285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("[…] and are also supercritical. Thus the various bounds we have on these quantities from Lectures 4, 5, 6 do not directly tell us anything about asymptotic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-29715")[#strong[#text("285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2008")])]

#text("[…] and is the pullback of the Levi-Civita connection applied in the direction (cf. Exercise 5 from Lecture 6). An integration by parts (again using the parallel nature of g) then gives the first variation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-30257")[#strong[#text("ky")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2008")])]

#text("I don’t see how")

#text("“we can identify S^3 with the space S^2 x S^1 / ({p_2} x S^1) U (S^2 x {p_1})} where p_1, p_2 are base points of S^1, S^2 respectively.”")

#text("Only way I know how to imagine S^3 is extension of one-point compactification.")

#text("Can somebody elaborate?")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-30260")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2008")])]

#text("Dear Ky,")

#text("One can think of ")#mi("S^1")#text(" as the unit interval [0,1] with the boundary ")#mi("\\partial [0,1] =[0,1] \\backslash (0,1)")#text(" identified with a single point ")#mi("p_1")#text(", and ")#mi("S^2")#text(" as the unit square ")#mi("{}[0,1]^2")#text(" with the boundary ")#mi("\\partial [0,1]^2 = [0,1]^2 \\backslash (0,1)^2")#text(" identified with a single point ")#mi("p_2")#text(". Thus ")#mi("S^2 \\times S^1")#text(" can be viewed as the unit cube ")#mi("{}[0,1]^3")#text(" with the sets ")#mi("x_2 \\times \\partial [0,1]")#text(" identified with a single point ")#mi("(x_2,p_1)")#text(" for each ")#mi("x_2 \\in (0,1)^2")#text(", ")#mi("\\partial [0,1]^2 \\times x_1")#text(" identified with a single point ")#mi("(p_2,x_1)")#text(" for each ")#mi("x_1 \\in (0,1)")#text(", and ")#mi("\\partial [0,1]^2 \\times \\partial [0,1]")#text(" identified with ")#mi("(p_2,p_1)")#text(". In particular, the set ")#mi("(\\{p_2\\} \\times S^1) \\cup (S^2 \\times \\{p_1\\})")#text(" comprises the entire boundary ")#mi("\\partial [0,1]^3")#text(" of the cube. Identifying this to a single point ")#mi("p_3")#text(" thus gives ")#mi("S^3")#text(".")

#text("(For visualisation purposes, it may help to first imagine the situation one dimension lower down, in which ")#mi("S^2")#text(" can be viewed as the torus ")#mi("S^1 \\times S^1")#text(" (which one can think of as the unit square with opposing edges identified) with ")#mi("(\\{p_1\\} \\times S^1) \\cup (S^1 \\times \\{p_1\\})")#text(" (i.e. the entire boundary of the square) identified to a point ")#mi("p_2")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-93547")[#strong[#text("285G, Lecture 19: The structure of Ricci flow at the singular time, surgery, and the Poincaré conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2011")])]

#text("[…] for Ricci flows, also work for Ricci flows with surgery, as discussed for in Lecture 5 and Lecture 6. Even if the manifold is not irreducible, one can show that there are only finitely many surgeries […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-271342")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("hi, professor Tao, (29) seems not very clear to me: we want to estimate ")#mi("\\nabla_T\\nabla_T k")#text(", but (29) only gives us the estimation of ")#mi("\\nabla_T k")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-271419")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("Sorry, that was a typo: ")#mi("\\nabla_T \\nabla_T k")#text(" in (28) should be ")#mi("\\nabla_T k")#text("; I’ve now corrected it in the post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48119438af825165a29bc3ce6ec6b3a0452493708c55d54314283c020d9781bf-57c07d245c064285376661b188068002451802545dfc5de0fd382c33fffc0bd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of handaoyuan")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-271794")[#strong[#text("handaoyuan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2014")])]

#text("Hi, Professor Tao, on the deduction of (2), by using chain rule, do you mean that ")#mi("\\frac{d}{dt} A(\\gamma_t, g(t))=A(\\frac{d}{dt}\\gamma_t, g(t))+A(\\gamma_t, \\frac{d}{dt} g(t))")#text("?")

#emph[#text("[That’s not quite the right formula for the ")#link("http://en.wikipedia.org/wiki/Total_derivative")[#text("total derivative")]#text(" – one needs some partial derivatives on the A – but basically yes. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48119438af825165a29bc3ce6ec6b3a0452493708c55d54314283c020d9781bf-57c07d245c064285376661b188068002451802545dfc5de0fd382c33fffc0bd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of handaoyuan")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-272049")[#strong[#text("handaoyuan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("Hi, Professor Tao, it seems the coefficient in (9) should be -1 rather than -1/2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48119438af825165a29bc3ce6ec6b3a0452493708c55d54314283c020d9781bf-57c07d245c064285376661b188068002451802545dfc5de0fd382c33fffc0bd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of handaoyuan")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-272321")[#strong[#text("handaoyuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Hi, professor Tao, since we’ve got almost the same formula (10) for minimal area as the following one for width functional, why do we need the width functional, why don’t we just use (10) to deduce the finite time extinction of the whole manifold ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-272385")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("As M is simply connected, it is quite possible for the area of a minimal disk to shrink to zero without the manifold itself developing any singularity or extinction, simply because the loop itself is shrinking to zero. One needs to work instead with families of loops, rather than just a single loop, to maintain topological non-triviality and avoid this scenario.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48119438af825165a29bc3ce6ec6b3a0452493708c55d54314283c020d9781bf-57c07d245c064285376661b188068002451802545dfc5de0fd382c33fffc0bd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of handaoyuan")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-272427")[#strong[#text("handaoyuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Thanks, but the contradiction point is that the solution of (14) and (10) (both could be viewed as the same differential equation) will go to negative (just as the last paragraph before section “Ramp” said) if we don’t have finite time extinction; since ")#mi("A(\\gamma, g)")#text(" is area which can’t be negative, couldn’t that have the same contradiction effect as the case of ")#mi("W_3")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-272429")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("No, because once ")#mi("\\gamma")#text(" shrinks to a point (and ")#mi("A(\\gamma,g)")#text(" shrinks to zero), the curve shortening flow is no longer definable and one cannot continue (10) beyond that time to reach a contradiction. In contrast, when working with a topologically non-trivial loop family, the loop with the largest minimal spanning area must be non-trivial, and one can perform curve shortening flow on that loop. (This assumes that there is a loop which attains this maximum; in practice, one has to modify the strategy via the ramp device, as discussed later in the blog post.)")

#text("To put it another way: the problem with trying to use (10) is that extinction of the loop can occur before extinction of the manifold. In contrast, with topologically non-trivial loop families, the (extremising) loop cannot become extinct before the manifold does.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48119438af825165a29bc3ce6ec6b3a0452493708c55d54314283c020d9781bf-57c07d245c064285376661b188068002451802545dfc5de0fd382c33fffc0bd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of handaoyuan")]], [#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/#comment-272436")[#strong[#text("handaoyuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Thanks, now I understand it.")
]
]
]
]
]
