// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/
// Converted to Typst by tao2typ: "2026-10-14T15:19:32.505471+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sign patterns of the Mobius and Liouville functions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sign patterns of the Mobius and Liouville functions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 September 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/")[#text("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://users.utu.fi/ksmato/")[#text("Kaisa Matomäki")]#text(", ")#link("http://math.rutgers.edu/~maksym/")[#text("Maksym Radziwiłł")]#text(", and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1509.01545")[#text("Sign patterns of the Liouville and Möbius functions")]#text("“. This paper is somewhat similar to our ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("previous paper")]#text(" in that it is using the ")#link("http://arxiv.org/abs/1501.04585")[#text("recent breakthrough of Matomäki and Radziwiłł")]#text(" on mean values of multiplicative functions to obtain partial results towards the ")#link("http://www.ams.org/mathscinet-getitem?mr=177943")[#text("Chowla conjecture")]#text(". This conjecture can be phrased, roughly speaking, as follows: if ")#mi("{k}")#text(" is a fixed natural number and ")#mi("{n}")#text(" is selected at random from a large interval ")#mi("{[1,x]}")#text(", then the sign pattern ")#mi("{(\\lambda(n), \\lambda(n+1),\\dots,\\lambda(n+k-1)) \\in \\{-1,+1\\}^k}")#text(" becomes asymptotically equidistributed in ")#mi("{\\{-1,+1\\}^k}")#text(" in the limit ")#mi("{x \\rightarrow \\infty}")#text(". This remains open for ")#mi("{k \\geq 2}")#text(". In fact even the significantly weaker statement that each of the sign patterns in ")#mi("{\\{-1,+1\\}^k}")#text(" is attained infinitely often is open for ")#mi("{k \\geq 4}")#text(". However, in 1986, ")#link("http://www.ams.org/mathscinet-getitem?mr=874689")[#text("Hildebrand showed")]#text(" that for ")#mi("{k \\leq 3}")#text(" all sign patterns are indeed attained infinitely often. Our first result is a strengthening of Hildebrand’s, moving a little bit closer to Chowla’s conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{k \\leq 3}")#text(". Then each of the sign patterns in ")#mi("{\\{-1,+1\\}^k}")#text(" is attained by the Liouville function for a set of natural numbers ")#mi("{n}")#text(" of positive lower density.")
]

#text("Thus for instance one has ")#mi("{\\lambda(n)=\\lambda(n+1)=\\lambda(n+2)}")#text(" for a set of ")#mi("{n}")#text(" of positive lower density. The ")#mi("{k \\leq 2}")#text(" case of this theorem already appears in ")#link("http://arxiv.org/abs/1501.04585")[#text("the original paper of Matomäki and Radziwiłł")]#text(" (and the significantly simpler case of the sign patterns ")#mi("{++}")#text(" and ")#mi("{--}")#text(" was treated previously ")#link("http://www.ams.org/mathscinet-getitem?mr=886032")[#text("by Harman, Pintz, and Wolke")]#text(").")

#text("The basic strategy in all of these arguments is to assume for sake of contradiction that a certain sign pattern occurs extremely rarely, and then exploit the complete multiplicativity of ")#mi("{\\lambda}")#text(" (which implies in particular that ")#mi("{\\lambda(2n) = -\\lambda(n)}")#text(", ")#mi("{\\lambda(3n) = -\\lambda(n)}")#text(", and ")#mi("{\\lambda(5n) = -\\lambda(n)}")#text(" for all ")#mi("{n}")#text(") together with some combinatorial arguments (vaguely analogous to solving a Sudoku puzzle!) to establish more complex sign patterns for the Liouville function, that are either inconsistent with each other, or with results such as the Matomäki-Radziwiłł result. To illustrate this, let us give some ")#mi("{k=2}")#text(" examples, arguing a little informally to emphasise the combinatorial aspects of the argument. First suppose that the sign pattern ")#mi("{(\\lambda(n),\\lambda(n+1)) = (+1,+1)}")#text(" almost never occurs. The prime number theorem tells us that ")#mi("{\\lambda(n)}")#text(" and ")#mi("{\\lambda(n+1)}")#text(" are each equal to ")#mi("{+1}")#text(" about half of the time, which by inclusion-exclusion implies that the sign pattern ")#mi("{(\\lambda(n),\\lambda(n+1))=(-1,-1)}")#text(" almost never occurs. In other words, we have ")#mi("{\\lambda(n+1) = -\\lambda(n)}")#text(" for almost all ")#mi("{n}")#text(". But from the multiplicativity property ")#mi("{\\lambda(2n)=-\\lambda(n)}")#text(" this implies that one should have")

#tao-aligned(keep: true)[


#tao-math("\\lambda(2n+2)  & = -\\lambda(2n)", block: true)



#tao-math("\\lambda(2n+1)  & = -\\lambda(2n)", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lambda(2n+2) = -\\lambda(2n+1)")]]

#text("for almost all ")#mi("{n}")#text(". But the above three statements are contradictory, and the claim follows.")

#text("Similarly, if we assume that the sign pattern ")#mi("{(\\lambda(n),\\lambda(n+1)) = (+1,-1)}")#text(" almost never occurs, then a similar argument to the above shows that for any fixed ")#mi("{h}")#text(", one has ")#mi("{\\lambda(n)=\\lambda(n+1)=\\dots=\\lambda(n+h)}")#text(" for almost all ")#mi("{n}")#text(". But this means that the mean ")#mi("{\\frac{1}{h} \\sum_{j=1}^h \\lambda(n+j)}")#text(" is abnormally large for most ")#mi("{n}")#text(", which (for ")#mi("{h}")#text(" large enough) contradicts the results of Matomäki and Radziwiłł. Here we see that the “enemy” to defeat is the scenario in which ")#mi("{\\lambda}")#text(" only changes sign very rarely, in which case one rarely sees the pattern ")#mi("{(+1,-1)}")#text(".")

#text("It turns out that similar (but more combinatorially intricate) arguments work for sign patterns of length three (but are unlikely to work for most sign patterns of length four or greater). We give here one fragment of such an argument (due ")#link("http://www.ams.org/mathscinet-getitem?mr=874689")[#text("to Hildebrand")]#text(") which hopefully conveys the Sudoku-type flavour of the combinatorics. Suppose for instance that the sign pattern ")#mi("{(\\lambda(n),\\lambda(n+1),\\lambda(n+2)) = (+1,+1,+1)}")#text(" almost never occurs. Now suppose ")#mi("{n}")#text(" is a typical number with ")#mi("{\\lambda(15n-1)=\\lambda(15n+1)=+1}")#text(". Since we almost never have the sign pattern ")#mi("{(+1,+1,+1)}")#text(", we must (almost always) then have ")#mi("{\\lambda(15n) = -1}")#text(". By multiplicativity this implies that")

#align(center)[#tao-fit-display[#mitex("(\\lambda(60n-4), \\lambda(60n), \\lambda(60n+4)) = (+1,-1,+1).")]]

#text("We claim that this (almost always) forces ")#mi("{\\lambda(60n+5)=-1}")#text(". For if ")#mi("{\\lambda(60n+5)=+1}")#text(", then by the lack of the sign pattern ")#mi("{(+1,+1,+1)}")#text(", this (almost always) forces ")#mi("{\\lambda(60n+3)=\\lambda(60n+6)=-1}")#text(", which by multiplicativity forces ")#mi("{\\lambda(20n+1)=\\lambda(20n+2)=+1}")#text(", which by lack of ")#mi("{(+1,+1,+1)}")#text(" (almost always) forces ")#mi("{\\lambda(20n)=-1}")#text(", which by multiplicativity contradicts ")#mi("{\\lambda(60n)=-1}")#text(". Thus we have ")#mi("{\\lambda(60n+5)=-1}")#text("; a similar argument gives ")#mi("{\\lambda(60n-5)=-1}")#text(" almost always, which by multiplicativity gives ")#mi("{\\lambda(12n-1)=\\lambda(12n)=\\lambda(12n+1)=+1}")#text(", a contradiction. Thus we almost never have ")#mi("{\\lambda(15n-1)=\\lambda(15n+1)=+1}")#text(", which by the inclusion-exclusion argument mentioned previously shows that ")#mi("{\\lambda(15n+1) = - \\lambda(15n-1)}")#text(" for almost all ")#mi("{n}")#text(".")

#text("One can continue these Sudoku-type arguments and conclude eventually that ")#mi("{\\lambda(3n-1)=-\\lambda(3n+1)=\\lambda(3n+2)}")#text(" for almost all ")#mi("{n}")#text(". To put it another way, if ")#mi("{\\chi_3}")#text(" denotes the non-principal Dirichlet character of modulus ")#mi("{3}")#text(", then ")#mi("{\\lambda \\chi_3}")#text(" is almost always constant away from the multiples of ")#mi("{3}")#text(". (Conversely, if ")#mi("{\\lambda \\chi_3}")#text(" changed sign very rarely outside of the multiples of three, then the sign pattern ")#mi("{(+1,+1,+1)}")#text(" would never occur.) Fortunately, the main result of Matomäki and Radziwiłł shows that this scenario cannot occur, which establishes that the sign pattern ")#mi("{(+1,+1,+1)}")#text(" must occur rather frequently. The other sign patterns are handled by variants of these arguments.")

#text("Excluding a sign pattern of length three leads to useful implications like “if ")#mi("{\\lambda(n-1)=\\lambda(n)=+1}")#text(", then ")#mi("{\\lambda(n+1)=-1}")#text("” which turn out are just barely strong enough to quite rigidly constrain the Liouville function using Sudoku-like arguments. In contrast, excluding a sign pattern of length four only gives rise to implications like “`if ")#mi("{\\lambda(n-2)=\\lambda(n-1)=\\lambda(n)=+1}")#text(", then ")#mi("{\\lambda(n+1)=-1}")#text("“, and these seem to be much weaker for this purpose (the hypothesis in these implications just isn’t satisfied nearly often enough). So a different idea seems to be needed if one wishes to extend the above theorem to larger values of ")#mi("{k}")#text(".")

#text("Our second theorem gives an analogous result for the ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu}")#text(" (which takes values in ")#mi("{\\{-1,0,+1\\}}")#text(" rather than ")#mi("{\\{-1,1\\}}")#text("), but the analysis turns out to be remarkably difficult and we are only able to get up to ")#mi("{k=2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" Let ")#mi("{k \\leq 2}")#text(". Then each of the sign patterns in ")#mi("{\\{-1,0,+1\\}^k}")#text(" is attained by the Möbius function for a set ")#mi("{n}")#text(" of positive lower density.")
]

#text("It turns out that the prime number theorem and elementary sieve theory can be used to handle the ")#mi("{k=1}")#text(" case and all the ")#mi("{k=2}")#text(" cases that involve at least one ")#mi("{0}")#text(", leaving only the four sign patterns ")#mi("{(\\pm 1, \\pm 1)}")#text(" to handle. It is here that the zeroes of the Möbius function cause a significant new obstacle. Suppose for instance that the sign pattern ")#mi("{(+1, -1)}")#text(" almost never occurs for the Möbius function. The same arguments that were used in the Liouville case then show that ")#mi("{\\mu(n)}")#text(" will be almost always equal to ")#mi("{\\mu(n+1)}")#text(", ")#emph[#text("provided that ")#mi("{n,n+1}")#text(" are both square-free")]#text(". One can try to chain this together as before to create a long string ")#mi("{\\mu(n)=\\dots=\\mu(n+h) \\in \\{-1,+1\\}}")#text(" where the Möbius function is constant, but this cannot work for any ")#mi("{h}")#text(" larger than three, because the Möbius function vanishes at every multiple of four.")

#text("The constraints we assume on the Möbius function can be depicted using a graph on the squarefree natural numbers, in which any two adjacent squarefree natural numbers are connected by an edge. The main difficulty is then that this graph is highly disconnected due to the multiples of four not being squarefree.")

#text("To get around this, we need to enlarge the graph. Note from multiplicativity that if ")#mi("{\\mu(n)}")#text(" is almost always equal to ")#mi("{\\mu(n+1)}")#text(" when ")#mi("{n,n+1}")#text(" are squarefree, then ")#mi("{\\mu(n)}")#text(" is almost always equal to ")#mi("{\\mu(n+p)}")#text(" when ")#mi("{n,n+p}")#text(" are squarefree and ")#mi("{n}")#text(" is divisible by ")#mi("{p}")#text(". We can then form a graph on the squarefree natural numbers by connecting ")#mi("{n}")#text(" to ")#mi("{n+p}")#text(" whenever ")#mi("{n,n+p}")#text(" are squarefree and ")#mi("{n}")#text(" is divisible by ")#mi("{p}")#text(". If this graph is “locally connected” in some sense, then ")#mi("{\\mu}")#text(" will be constant on almost all of the squarefree numbers in a large interval, which turns out to be incompatible with the results of Matomäki and Radziwiłł. Because of this, matters are reduced to establishing the connectedness of a certain graph. More precisely, it turns out to be sufficient to establish the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" For each prime ")#mi("{p}")#text(", let ")#mi("{a_p \\text{ mod } p^2}")#text(" be a residue class chosen uniformly at random. Let ")#mi("{G}")#text(" be the random graph whose vertices ")#mi("{V}")#text(" consist of those integers ")#mi("{n}")#text(" not equal to ")#mi("{a_p \\text{ mod } p^2}")#text(" for any ")#mi("{p}")#text(", and whose edges consist of pairs ")#mi("{n,n+p}")#text(" in ")#mi("{V}")#text(" with ")#mi("{n = a_p \\text{ mod } p}")#text(". Then with probability ")#mi("{1}")#text(", the graph ")#mi("{G}")#text(" is connected.")
]

#text("We were able to show the connectedness of this graph, though it turned out to be remarkably tricky to do so. Roughly speaking (and suppressing a number of technicalities), the main steps in the argument were as follows.")

#list(
[#text("(Early stage) Pick a large number ")#mi("{X}")#text(" (in our paper we take ")#mi("{X}")#text(" to be odd, but I’ll ignore this technicality here). Using a moment method to explore neighbourhoods of a single point in ")#mi("{V}")#text(", one can show that a vertex ")#mi("{v}")#text(" in ")#mi("{V}")#text(" is almost always connected to at least ")#mi("{\\log^{10} X}")#text(" numbers in ")#mi("{[v,v+X^{1/100}]}")#text(", using relatively short paths of short diameter. (This is the most computationally intensive portion of the argument.)")],
[#text("(Middle stage) Let ")#mi("{X^{\\prime}}")#text(" be a typical number in ")#mi("{[X/40,X/20]}")#text(", and let ")#mi("{R}")#text(" be a scale somewhere between ")#mi("{X^{1/40}}")#text(" and ")#mi("{X^{\\prime}}")#text(". By using paths ")#mi("{n, n+p_1, n+p_1-p_2, n+p_1-p_2+p_3}")#text(" involving three primes, and using a variant of Vinogradov’s theorem and some routine second moment computations, one can show that with quite high probability, any “good” vertex in ")#mi("{[v+X^{\\prime}-R, v+X^{\\prime}-0.99R]}")#text(" is connected to a “good” vertex in ")#mi("{[v+X^{\\prime}-0.01R, v+X-0.0099 R]}")#text(" by paths of length three, where the definition of “good” is somewhat technical but encompasses almost all of the vertices in ")#mi("{V}")#text(".")],
[#text("(Late stage) Combining the two previous results together, we can show that most vertices ")#mi("{v}")#text(" will be connected to a vertex in ")#mi("{[v+X^{\\prime}-X^{1/40}, v+X^{\\prime}]}")#text(" for any ")#mi("{X^{\\prime}}")#text(" in ")#mi("{[X/40,X/20]}")#text(". In particular, ")#mi("{v}")#text(" will be connected to a set of ")#mi("{\\gg X^{9/10}}")#text(" vertices in ")#mi("{[v,v+X/20]}")#text(". By tracking everything carefully, one can control the length and diameter of the paths used to connect ")#mi("{v}")#text(" to this set, and one can also control the parity of the elements in this set.")],
[#text("(Final stage) Now if we have two vertices ")#mi("{v, w}")#text(" at a distance ")#mi("{X}")#text(" apart. By the previous item, one can connect ")#mi("{v}")#text(" to a large set ")#mi("{A}")#text(" of vertices in ")#mi("{[v,v+X/20]}")#text(", and one can similarly connect ")#mi("{w}")#text(" to a large set ")#mi("{B}")#text(" of vertices in ")#mi("{[w,w+X/20]}")#text(". Now, by using a Vinogradov-type theorem and second moment calculations again (and ensuring that the elements of ")#mi("{A}")#text(" and ")#mi("{B}")#text(" have opposite parity), one can connect many of the vertices in ")#mi("{A}")#text(" to many of the vertices ")#mi("{B}")#text(" by paths of length three, which then connects ")#mi("{v}")#text(" to ")#mi("{w}")#text(", and gives the claim.")]
)

#text("It seems of interest to understand random graphs like ")#mi("{G}")#text(" further. In particular, the graph ")#mi("{G^{\\prime}}")#text(" on the integers formed by connecting ")#mi("{n}")#text(" to ")#mi("{n+p}")#text(" for all ")#mi("{n}")#text(" in a randomly selected residue class mod ")#mi("{p}")#text(" for each prime ")#mi("{p}")#text(" is particularly interesting (it is to the Liouville function as ")#mi("{G}")#text(" is to the Möbius function); if one could show some “local expander” properties of this graph ")#mi("{G^{\\prime}}")#text(", then one would have a chance of modifying the above methods to attack the first unsolved case of the Chowla conjecture, namely that ")#mi("{\\lambda(n)\\lambda(n+1)}")#text(" has asymptotic density zero (perhaps working with logarithmic density instead of natural density to avoids some technicalities).")

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip Lee")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-458947")[#strong[#text("Philip Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2015")])]

#text("Please pardon me if this doesn’t belong here. I saw a glance of the wave equation approach to automorphic function, though not having any special skills in the area, it did remind me of the generating functions from combinatorics. There is also in my mind relationship to Newman’s proof of the prime number theorem. I am trying to read and understand it, at least to try to learn the estimation involved or the techniques that lead to it.")

#text("Generating functions as complex functions, and their singularities (by Cauchy integral theorem) give asymptotic estimates for the size of combinatorial objects. This is inspired by an Analysis of Algorithms course online. Are there any specific connections worked out connecting these and the primes as a combinatorial (set?)? There is a Fourier series for the Mobius function in connection to the post above, otherwise I hope that this post doesn’t distract the comments anyway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-458950")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2015")])]

#text("Can theorem 1 be generalized for the sign patterns of ")#mi("\\lambda(n+h_1), \\lambda (n+h_2), \\lambda (n+h_3)")#text(" for some fixed nonconsecutive(!) triples ")#mi("(h_1, h_2, h_3)")#text("?")#linebreak()#text(" (obviously, we may assume ")#mi("h_1 = 0")#text(" and ")#mi("h_1 < h_2 < h_3")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-458971")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2015")])]

#text("Good question! Each such triple will generate a different “Sudoku puzzle” that needs to be solved (where the Sudoku-type constraints are that ")#mi("(\\lambda(a(n+h_1)), \\lambda(a(n+h_2)), \\lambda(a(n+h_3))")#text(" avoids a certain sign pattern as ")#mi("a")#text(" ranges over small numbers and ")#mi("n")#text(" ranges over all natural numbers). We were lucky in the ")#mi("(h_1,h_2,h_3) = (0,1,2)")#text(" case that these constraints (together with some additional information on ")#mi("\\lambda")#text(" coming from the prime number theorem) were enough to limit the possible solutions to ones that could be ruled out by Matomaki-Radziwill. However for other choices of this triple, it is not clear that the solution set is as rigid, the problem may become seriously underdetermined. (One may have to work in the asymptotic regime where ")#mi("a")#text(" is allowed to be large, in contrast with our analysis which basically only needs those ")#mi("a")#text(" that are divisible by 60.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-458966")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2015")])]

#text("Is it crucial that this graph be on the integers and not some interval of the integers? I’m trying to formalize the expander graph problem at the end and I want to work with the graph on the interval ")#mi("[0,X]")#text(" where you connect one residue class mod ")#mi("p")#text(" for all ")#mi("p\\leq X")#text(". There are only ")#mi("\\prod_{p < X} p \\approx e^X")#text(" possible choices of residue classes and ")#mi("2^X")#text(" sets the graph could fail to expand, so trying to use the probabilistic method and the union bound in the obvious way there isn't a lot of extra room.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-458973")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2015")])]

#text("It doesn’t seem to make much difference where one restricts the integers, but one can weaken the expansion requirement by only needing to test sets that are well distributed locally. More precisely, the claim needed is the following:")

#text("* Let ")#mi("H \\geq 1")#text(" be large, and let ")#mi("X \\geq H")#text(" be sufficiently large depending on ")#mi("H")#text(". Form the random graph ")#mi("G = (V,E)")#text(" on ")#mi("[0,X]")#text(" by connecting together ")#mi("n")#text(" and ")#mi("n+p")#text(" for all odd primes ")#mi("p \\leq X")#text(" and all ")#mi("n, n+p \\in [0,X]")#text(" in a randomly selected residue class ")#mi("a_p \\text{ mod } p")#text(". Then, with probability ")#mi("1-o(1)")#text(" (as ")#mi("H,X")#text(" go to infinity), one has a bound of the form ")#mi("\\sum_{\\{v,w\\} \\in E} f(v) f(w) = o( X \\log \\log X )")#text(" whenever ")#mi("f: [0,X] \\to \\{-1,+1\\}")#text(" has the property that ")#mi("\\sum_{y \\leq n \\leq y+H: n = a \\text{ mod } q} f(n) = o(H)")#text(" for all ")#mi("[y,y+H] \\subset [0,X]")#text(" and all residue classes ")#mi("a \\text{ mod } q")#text(" with ")#mi("q = O(1)")#text(" (probably one only needs this for q=2, to deal with the bipartite nature of G).")

#text("If one has this claim then one can show that ")#mi("\\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{\\lambda(n) \\lambda(n+1)}{n} = o(1)")#text(", that is to say one has the first nontrivial case of Chowla’s conjecture in the logarithmic density category. One can also restrict the primes ")#mi("p")#text(" to a subset ")#mi("{\\mathcal P}")#text(" of the primes less than X, at the cost of replacing ")#mi("\\log\\log X")#text(" by ")#mi("\\sum_{p \\in {\\mathcal P}} \\frac{1}{p}")#text(".")

#text("As you say, a direct probabilistic argument looks unpromising. One may have to locate some other property that implies expansion (e.g. some mixing property of the random walk) which does not require one to verify an exponential number of assertions. Unfortunately one has to control the random walk for times up to almost ")#mi("\\log X")#text(" to make a naive version of this strategy work; in our paper we were able to control the walk up to a little bit less than ")#mi("\\log\\log X")#text(" but the combinatorics became quite complicated beyond that point and we used a different method to propagate the graph further.")

#text("A model problem may be to replace G by a weighted Erdos-Turan model in which any pair n,n+p are connected with an independent probability of 1/p (rather than only connecting those n,n+p in a random residue class). Now there is a lot more randomness and a Pinsker type probabilistic argument of the type you propose may work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459005")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2015")])]

#text("Did a quick back of the envelope calculation using ")#link("https://en.wikipedia.org/wiki/Bennett%27s_inequality")[#text("Bennett’s inequality")]#text(" for the Erdos-Turan model mentioned above. For a fixed choice of ")#mi("f")#text(", ")#mi("\\sum_{\\{v,w\\} \\in E} f(v) f(w)")#text(" is the sum of about ")#mi("X^2 / \\log X")#text(" random variables of total variance about ")#mi("X \\log\\log X")#text(", so if I did my calculations correctly, Bennett’s inequality predicts some cancellation in this sum with probability about ")#mi("\\exp( - c X (\\log\\log X)^2 )")#text(", which is superexponential and so one usually has the desired expansion property. Heuristically this predicts (but does not prove) that the original random graph G should also have the required expansion property.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-458975")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2015")])]

#text("6th paragraph: “a similar argument gives {\\lambda(60n-5)} *= -1* almost always,…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459021")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2015")])]

#text("The Sudoku-flavor arguments remind me on the EDP Polymath project, where some of us tried to prove (without computer) that completely multiplicative sequences with values in ")#mi("{\\pm 1}")#text(" have discrepancy greater than 3. Can these recent results of Matomaki and Radziwill be used/adapted/generalized to help with this problem or is there some obstacle to make that hopeless ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459035")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2015")])]

#text("There is indeed some similarity on the surface, but Matomaki-Radziwill only lets one control the sum of a ")#mi("\\pm 1")#text("-valued multiplicative functions ")#mi("f")#text(" in short intervals such as ")#mi("[x,x+H]")#text(" where ")#mi("H")#text(" is much smaller than ")#mi("x")#text(", basically by using Fourier inversion (or Perron’s formula) to convert this to a question about the Dirichlet series ")#mi("\\sum_n \\frac{f(n)}{n^s} = \\sum_n \\frac{f(n)}{n^{\\sigma+it}}")#text(". Roughly speaking, the relationship between the intervals ")#mi("[x,x+H]")#text(" and the phases ")#mi("n^{it}")#text(" is that ")#mi("n^{it}")#text(" and ")#mi("n^{it^{\\prime}}")#text(" essentially differ only by a constant when ")#mi("t^{\\prime}-t \\ll \\frac{H}{x}")#text(". By using Dirichlet characters one can also control ")#mi("f")#text(" in short progressions such as ")#mi("\\{n \\in [x,x+H]: n = a \\text{ mod } q \\}")#text(" for ")#mi("q")#text(" small, ")#mi("H")#text(" medium size, and ")#mi("x")#text(" very large, but I don’t see an obvious way to control the EDP type discrepancies which are more to do with progressions such as ")#mi("\\{ n \\leq x: n = 0 \\text{ mod } d \\}")#text(" when ")#mi("x,d")#text(" are both large.")

#text("EDIT: Ah, using complete multiplicativity I see that the EDP for completely multiplicative functions is equivalent to ")#emph[#text("lower bounding")]#text(" the sum of ")#mi("f")#text(" on intervals such as ")#mi("[x,x+H]")#text(" rather than upper bounding it. The Matomaki-Radziwill technology is geared towards upper bounds only. As usual we have the problem that Dirichlet characters already have bounded discrepancy, so one has to somehow use the fact that the multiplicative function doesn’t vanish…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Domi")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459829")[#strong[#text("Domi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#text("In the end this was useful: ")#link("http://arxiv.org/abs/1509.05363")[#text("http://arxiv.org/abs/1509.05363")]#linebreak()#text(" Congratulations!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459038")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2015")])]

#text("2nd paragraph after Theorem 1, the fragment “…which implies for in particular that…” seems to have an extra “for”.")

#text("And I’d like to second Uwe Stroinsky’s query, re: EDP for the multiplicative case.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459044")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2015")])]

#text("Hmm, actually there does appear to be a connection between the EDP and something we looked at in our previous paper, namely Elliott’s conjecture (a generalisation of Chowla’s conjecture to arbitrary bounded multiplicative functions). There is in fact a chance that a suitable version of this conjecture implies that all +1,-1 sequences have unbounded discrepancy. I’ll work this out in detail a subsequent blog post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Erdos discrepancy problem via the Elliott conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459080")[#strong[#text("The Erdos discrepancy problem via the Elliott conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2015")])]

#text("[…] number . This conjecture remains open, though there are a number of partial results (e.g. these two previous results of Matomaki, Radziwill, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459391")[#strong[#text("Updates and plans III. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")]

#text("[…] posts by Terry Tao (1), (2) (reporting also on subsequent works by Matomaki, Radzwill, and Tao) NEW (3) (4)). Update (Sept 18, 2015): Terry Tao have just uploaded a paper to the arxive where he solves […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459424")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] pair of papers is an outgrowth of these two recent blog posts and the ensuing discussion. In the first paper, we establish the following […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-459650")[#strong[#text("Frogs and Lily Pads and Discrepancy | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")]

#text("[…] famous Discrepancy Conjecture” (DC) of Paul Erdős. This emerged from discussion of his two earlier posts this month on his blog. They and his 9/18 announcement post re-create much of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-460595")[#strong[#text("A Magical Answer to an 80-Year-Old Puzzle | Quorai")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")]

#text("[…] of potential applications of their method to problems in number theory. On September 6, Tao wrote a blog post about some of this work pertaining to the Liouville function, and he mentioned that the problem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a8180ce1210a5eb1f23978493566e6416dbf3ac37c330124e955da6fb013b1f-5396e8cfdc2e932f2b73ac47d6e97b7cf4ce8191edfe8b5105776da12c43220e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Problem rozbieżności Erdősa | Nowe Problemy")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-461629")[#strong[#text("Problem rozbieżności Erdősa | Nowe Problemy")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2015")])]

#text("[…] od tego tematu, chociaż związanymi z własnościami ciągów multiplikatywnych. 6 września opisał na swoim blogu stan swoich prac. 9 września Uwe Stroinski pozostawił pod tym wpisem komentarz o możliwym […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-484810")[#strong[#text("The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("[…] and all possible length four sign patterns occur with the conjectured logarithmic density. (In a previous paper with Matomaki and Radziwill, we obtained comparable results for length three patterns of Liouville […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-490966")[#strong[#text("A Magical Answer to an 80-Year-Old Puzzle | News")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2017")]

#text("[…] of potential applications of their method to problems in number theory. On September 6, Tao wrote a blog post about some of this work pertaining to the Liouville function, and he mentioned that the problem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Value patterns of multiplicative functions and related sequences | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-514799")[#strong[#text("Value patterns of multiplicative functions and related sequences | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2019")])]

#text("[…] lower density as sign patterns of this function. The analogous result for was already known (see this paper of Matomäki, Radziwiłł, and myself), and in that case it is even known that all sign patterns occur with equal logarithmic density […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-515180")[#strong[#text("Value patterns of multiplicative functions and related sequences – 刘展均工作室")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2019")]

#text("[…] lower density as sign patterns of this function. The analogous result for was already known (see this paper of Matomäki, Radziwiłł, and myself), and in that case it is even known that all sign patterns occur with equal logarithmic density […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e0660fa5699fe0a15cbe4bfb2c8f978d4de6880be73373ce6e12bdcc87183ba-bd5ceb35b0fb559d945b9defca4b4756da75166f3eddfe5c1a7deb7c487a43d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-533108")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("Do you have a conjecture of the true density of each of the possible consecutive moebius sign patterns of length 3? of greater lengths?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-533122")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("Yes, this can be derived from the Chowla conjecture for the Mobius function (which assserts that averages such as ")#mi("\\frac{1}{x} \\sum_{n \\leq x} \\mu^{a_1}(n+h_1) \\dots \\mu^{a_k}(n+h_k)")#text(" for distinct ")#mi("h_1,\\dots,h_k")#text(" are ")#mi("o(1)")#text(" under the condition that at least one of the ")#mi("a_i")#text(" are odd.) This predicts that the density of a given sign pattern ")#mi("(\\epsilon_1,\\dots,\\epsilon_k)")#text(" for Mobius is equal to ")#mi("2^{-l}")#text(" times the density of the sign pattern ")#mi("(\\epsilon_1^2,\\dots,\\epsilon_k^2)")#text(" for the square ")#mi("\\mu^2")#text(" of the Mobius function, where ")#mi("l")#text(" is the number of non-zero values. The latter density can be worked out from sieve theoretic methods (it is an Euler product). See for instance Corollary 1.7 of my paper ")#link("https://arxiv.org/pdf/1509.05422.pdf")[#text("https://arxiv.org/pdf/1509.05422.pdf")]#text(" for some examples of these sorts of calculations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e0660fa5699fe0a15cbe4bfb2c8f978d4de6880be73373ce6e12bdcc87183ba-bd5ceb35b0fb559d945b9defca4b4756da75166f3eddfe5c1a7deb7c487a43d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-534719")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2020")])]

#text("Is it known whether there are infinitely many n such that ")#mi("\\mu(n)=\\mu(n+2) = -1")#text(" ? (a weak form of the twin primes conjecture).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00d273d608ef6354da8f19f2b0c7e86f3cfb54ef4ce008d736b03a20183a93d2-eeb29b1df81e6b66ddadbcbbac6283d5178d97a8ab0f96dd340ee8396bedee83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-534722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2020")])]

#text("This can (probably) be shown using elementary number theory. It also follows from the Matomaki-Radziwill theorem that there is a positive proportion of such n.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9375f5d616d09d0ecdf0cd6674f750ef0055c421e51bbdfaf04cb0f83311819e-e6537048a9679de987e1c82b58abda5bda30153ef25069c1e5be4b178646f1dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-534723")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2020")])]

#text("Sorry my comment is only relevant for ")#mi("(\\lambda(n), \\lambda(n + 2))")#text(". The case of ")#mi("(\\mu(n), \\mu(n + 2))")#text(" is a bit more tricky but should still follow from a variant of the argument from this blog post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-534808")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2020")])]

#text("With the logarithmically averaged two-point correlation estimates established in my subsequent paper ")#link("https://arxiv.org/abs/1509.05422")[#text("https://arxiv.org/abs/1509.05422")]#text(" it is in fact possible to compute the logarithmic density of the set ")#mi("\\{ n: \\mu(n) = \\mu(n+2)=-1\\}")#text(" which is some explicit positive constant, by a slight modification of Corollary 1.7 of that paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-534813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2020")])]

#text("If this set has also a standard (“linear”) density, should it necessarily coincide with the logarithmic density ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-534817")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2020")])]

#text("Yes. Whenever the natural density exists, the logarithmic density exists also and is equal to the natural density (Exercise 7 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("this set of notes")]#text("), but there are sets for which the logarithmic density is defined but the natural density is not (Exercise 11 from the same notes).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-534924")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2020")])]

#text("If the tween prime conjecture (that ")#mi("\\pi_2(x)")#text(" is asymptotically equivalent to ")#mi("2 C_2 x / (\\log x)^2")#text(" where ")#mi("C_2")#text(" is the tween prime constant) is true, is it possible to represent ")#mi("C_2")#text(" in terms of the logarithmic density (which is also the natural density) of the tween primes and verify the Hardy-Littlewood conjecture on the value of ")#mi("C_2")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-534951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2020")])]

#text("I’m not sure I understand your question; the set of primes has natural density and logarithmic density equal to zero, and hence the set of twin primes does also. In fact ")#link("https://en.wikipedia.org/wiki/Brun%27s_theorem")[#text("Brun’s theorem")]#text(" asserts that the sum of reciprocals of twin primes converges to a constant (as opposed to growing like ")#mi("\\log x")#text(", which is what a set of positive density would do). If we knew that ")#mi("\\pi_2(x) \\sim 2 C_2 \\frac{x}{\\log^2 x}")#text(", then one could obtain asymptotics for various other sums over twin primes using summation by parts; for instance one could use this hypothesis to show that ")#mi("\\sum_{p \\leq x; p+2 \\text{ prime}} \\frac{1}{p} = B_2 - \\frac{2C_2+o(1)}{\\log x}")#text(" as ")#mi("x \\to \\infty")#text(" for some constant ")#mi("B_2")#text(" (known as Brun’s constant).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-534960")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2020")])]

#text("In fact, my question was about the possibility to “design” a set ")#mi("S")#text(" of integers, such that if ")#mi("\\pi_2(x) \\sim 2 C_2 x / (\\log x)^2")#text(" for some ")#mi("C_2")#text(", the logarithmic density of ")#mi("S")#text(" can be computed and is sufficient to imply the precise value (or at least new information) of ")#mi("C_2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-535137")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2020")])]

#text("With present technology one is unable to rule out the scenario ")#mi("\\pi_2(x) \\sim 2C^{\\prime}_2 x/(\\log^2 x)")#text(" for any constant ")#mi("C^{\\prime}_2")#text(" between ")#mi("0")#text(" and ")#mi("4C_2")#text(". Assuming the Elliot-Halberstam conjecture in sieve theory one can narrow this range down to between ")#mi("0")#text(" and ")#mi("2C_2")#text(", but going beyond this would require breaking the ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("parity barrier")]#text(" which has not been done for the twin prime problem (although there are a small handful of other situations in which the parity barrier can be overcome). This situation can be contrasted with that for ")#mi("\\pi(x)")#text(", since it is an easy consequence of Mertens’ theorems that the only constant ")#mi("C")#text(" for which the asymptotic ")#mi("\\pi(x) \\sim C x / \\log x")#text(" can possibly hold is ")#mi("C=1")#text(". Basically, the analogue of Mertens’ theorem for twin primes, namely an asymptotic for ")#mi("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2) / n")#text(", is currently just as open as the asymptotic for ")#mi("\\pi_2(x)")#text(" (or equivalently for ")#mi("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2)")#text("), though it does look a tiny bit less impossible to attack the former than the latter. (For instance, a nontrivial estimate for ")#mi("\\sum_{n \\leq x} \\mu(n) \\mu(n+2)/n")#text(" was recently established, but the corresponding estimate for ")#mi("\\sum_{n \\leq x} \\mu(n) \\mu(n+2)")#text(" remains open.) The difficulty is not so much with the choice of averaging method (in particular, in any particularly clever design choice for a set ")#mi("S")#text(" to average over), but on finding a tractable way to manipulate expressions such as ")#mi("\\Lambda(n) \\Lambda(n+2)")#text(" into other expressions that have any sort of computable average.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efe11754f44896b254631cc83e7ce538511599ecd447c72084d6f8f07ab9fa28-c39430b8847f9ce7973b700af1ea58da3f6b304a88d096c045e413ad152de042.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob Copeland")]], [#link("https://terrytao.wordpress.com/2015/09/06/sign-patterns-of-the-mobius-and-liouville-functions/#comment-571044")[#strong[#text("Bob Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2020")])]

#text("I’m not naturally wired for mathematics so I don’t have a clue however, I accidentally discovered Tesla Mathematics, expanded it & came up with this fast way to calculate prime numbers & hence their differences. I also accidentally found a method of mathematically grouping all the infinite numbers using Tesla Mathematics. I realize that as you’re a hell of a lot cleverer than I, it might bore you to tears but it might be of some use to you. Anyway let me know. Prime numbers are related to Tesla mathematics. Column zero (0) or the first column of potential prime numbers end in (1, 3, 7, and 9) For instance these numbers are prime (11, 13, 17, 19). If you add all the digits in a potentially prime number you will see they sum to (1, 2, 4, 5, 7, and 8) but not in order. For instance prime number (19) goes like this (1 + 9 = 10, 1 + 0 = 1).You will notice that (3, 6, and 9) which are Tesla’s universe numbers are missing. Therefore you can eliminate the maybe prime numbers that end in (1, 3, 7, 9) that sum to the single digits (3, 6, 9) since they aren’t primes. You can test the remaining potentially prime numbers to see if they are primes by trying to divide them by numbers ending in (1, 3, 7, and 9) in column zero (0) or the far right column. Prime differences are a multiple of (2).")
]
