// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/
// Converted to Typst by tao2typ: "2026-10-14T10:43:49.799620+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Bi-invariant metrics of linear growth on the free group", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Bi-invariant metrics of linear growth on the free group")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 December 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/")[#text("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Here is a curious question posed to me by ")#link("http://www.math.iisc.ac.in/~khare/")[#text("Apoorva Khare")]#text(" that I do not know the answer to. Let ")#mi("{F_2}")#text(" be the free group on two generators ")#mi("{a,b}")#text(". Does there exist a metric ")#mi("{d}")#text(" on this group which is")

#list(
[#text("bi-invariant, thus ")#mi("{d(xg,yg)=d(gx,gy) = d(x,y)}")#text(" for all ")#mi("{x,y,g \\in F_2}")#text("; and")],
[#text("linear growth in the sense that ")#mi("{d(x^n,1) = n d(x,1)}")#text(" for all ")#mi("{x \\in F_2}")#text(" and all natural numbers ")#mi("{n}")#text("?")]
)

#text("By defining the “norm” of an element ")#mi("{x \\in F_2}")#text(" to be ")#tao-math("{\\left\\| x\\right\\| := d(x,1)}", block: false)#text(", an equivalent formulation of the problem asks if there exists a non-negative norm function ")#mi("{\\| \\|: F_2 \\rightarrow {\\bf R}^+}")#text(" that obeys the conjugation invariance ")#metadata(none) <tao-3d576808b5fed6b92786>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| gxg^{-1} \\right\\| = \\left\\|x \\right\\|", block: true)]]

#text("for all ")#mi("{x,g \\in F_2}")#text(", the triangle inequality ")#metadata(none) <tao-cddd67830982a78cc839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| xy \\right\\| \\leq \\left\\| x\\right\\| + \\left\\| y\\right\\|", block: true)]]

#text("for all ")#mi("{x,y \\in F_2}")#text(", and the linear growth ")#metadata(none) <tao-e5b564a7a4059dccb9c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| x^n \\right\\| = \\left|n\\right| \\left\\|x\\right\\|", block: true)]]

#text("for all ")#mi("{x \\in F_2}")#text(" and ")#mi("{n \\in {\\bf Z}}")#text(", and such that ")#tao-math("{\\left\\|x\\right\\| > 0}", block: false)#text(" for all non-identity ")#mi("{x \\in F_2}")#text(". Indeed, if such a norm exists then one can just take ")#tao-math("{d(x,y) := \\left\\| x y^{-1} \\right\\|}", block: false)#text(" to give the desired metric.")

#text("One can normalise the norm of the generators to be at most ")#mi("{1}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| a \\right\\|, \\left\\| b \\right\\| \\leq 1.", block: true)]]

#text("This can then be used to upper bound the norm of other words in ")#mi("{F_2}")#text(". For instance, from ")#link(<tao-3d576808b5fed6b92786>)[#text("(1)")]#text(", ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(3)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| aba^{-1} \\right\\|, \\left\\| b^{-1} a b \\right\\|, \\left\\| a^{-1} b^{-1} a \\right\\|, \\left\\| bab^{-1}\\right\\| \\leq 1.", block: true)]]

#text("A bit less trivially, from ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(3)")]#text(", ")#link(<tao-cddd67830982a78cc839>)[#text("(2)")]#text(", ")#link(<tao-3d576808b5fed6b92786>)[#text("(1)")]#text(" one can bound commutators as")

#tao-aligned(keep: true)[


#tao-math("\\left\\| aba^{-1} b^{-1} \\right\\|  & = \\frac{1}{3} \\left\\| (aba^{-1} b^{-1})^3 \\right\\|", block: true)



#tao-math(" & = \\frac{1}{3} \\left\\| (aba^{-1}) (b^{-1} ab) (a^{-1} b^{-1} a) (b ab^{-1}) \\right\\|", block: true)



#tao-math(" & \\leq \\frac{4}{3}.", block: true)
]

#text("In a similar spirit one has")

#tao-aligned(keep: true)[


#tao-math("\\left\\| aba^{-2} b^{-1} \\right\\|  & = \\frac{1}{2} \\left\\| (aba^{-2} b^{-1})^2 \\right\\|", block: true)



#tao-math(" & = \\frac{1}{2} \\left\\| (aba^{-1}) (a^{-1} b^{-1} a) (ba^{-1} b^{-1}) (ba^{-1} b^{-1}) \\right\\|", block: true)



#tao-math(" & \\leq 2.", block: true)
]

#text("What is not clear to me is if one can keep arguing like this to continually improve the upper bounds on the norm ")#tao-math("{\\left\\| g\\right\\|}", block: false)#text(" of a given non-trivial group element ")#mi("{g}")#text(" to the point where this norm must in fact vanish, which would demonstrate that no metric with the above properties on ")#mi("{F_2}")#text(" would exist (and in fact would impose strong constraints on similar metrics existing on other groups as well). It is also tempting to use some ideas from geometric group theory (e.g. asymptotic cones) to try to understand these metrics further, though I wasn’t able to get very far with this approach. Anyway, this feels like a problem that might be somewhat receptive to a more crowdsourced attack, so I am posing it here in case any readers wish to try to make progress on it.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (104)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490066")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")])]

#text("As a rather trivial observation, it may be worth noting that conjugation invariance is automatic,")

#tao-math("\\displaystyle \\left\\|gxg^{-1}\\right\\| = \\frac{\\left\\|(gxg^{-1})^n\\right\\|}{n} = \\frac{\\left\\|gx^ng^{-1}\\right\\|}{n} \\leq \\left\\|x\\right\\| + O(n^{-1}).", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05419cbe1040e6996bd6a080dc34518f0bb5b064d0d2f90468ef801fe66880c8-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490068")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")])]

#text("> What is not clear to me is if one can keep arguing like this to continually improve the upper bounds on the norm ")#tao-math("\\left\\| g\\right\\|", block: false)#text(" of a given non-trivial group element ")#mi("g")#text(" to the point where this norm must in fact vanish")

#text("If ")#mi("g")#text(" has a nontrivial image in the abelianization then its norm definitely doesn’t have to be zero – for example, one could get a seminorm by pulling back the log of the spectral radius in a faithful representation of the abelianization of ")#mi("F_2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490070")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Take the direct sum of the representation and the inverse to ensure the spectral radius satisfies ")#mi("\\rho(g^{-1}) = \\rho(g)")#text(". More generally, one may take any norm on ")#mi("\\mathbb{R}^2")#text(", restrict it to ")#mi("\\mathbb{Z}^2")#text(", and pull it back to ")#mi("F_2")#text(".")

#text("It may now be worth considering the norms on the Heisenberg group.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a861b523fdb5071ea2d4a76fc38e1e600a3ba2bd97dce963341b3770c82a2e-f09146c65c3fa56f5cfde78a2d6c10c19270ab040979ff9bf0dfd539cba72163.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490074")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("There is no such norm on the Heisenberg group, because ")#tao-math("n^2 \\left|\\left| ab a^{-1} b^{-1} \\right|\\right| = \\left|\\left| (a ba^{-1} b^{-1})^{n^2} \\right|\\right| = || ( a^n b^n a^{-n} b^{-n} \\left|\\left| \\leq 2n \\right|\\right|a\\left|\\left| + 2n \\right|\\right|b||", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490099")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Great! This shows that every norm on a nilpotent group pulls back from the abelianization. Solvable groups are next, and I think there the situation is the same.")

#text("Can we find an example of a norm that doesn’t come from the abelianization?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490076")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("In other words, every pseudonorm on ")#mi("\\mathbb{R}^2")#text(" yields a linear-growth pseudometric on ")#mi("F_2")#text(" by pulling back along the abelianization map ")#mi("F_2\\to\\mathbb{Z}^2")#text(".")

#text("Suppose that we can show that any linear-growth pseudometric on ")#mi("F_2")#text(" satisfies ")#tao-math("\\left|\\left|aba^{-1}b^{-1}\\right|\\right| = 0", block: false)#text(". Then in fact every linear-growth pseudometric comes from ")#mi("\\mathbb{Z}^2")#text(" as above. To see this, let’s show first that every commutator ")#mi("xyx^{-1}y^{-1}")#text(" must have zero (psuedo-)norm; this is again by pulling back the norm along the homomorphism ")#mi("F_2\\to F_2")#text(" that takes ")#mi("a\\mapsto x")#text(" and ")#mi("b\\mapsto y")#text(", and using the assumption. Therefore by the triangle inequality, every element of the commutator subgroup has vanishing norm, and hence the norm of an element only depends on its image in the abelianization ")#mi("\\mathbb{Z}^2")#text(". Now it’s straightforward to see that this induces a linear-growth pseudonorm on $\\mathbb{Z}^2$ which uniquely extends to a pseudonorm on $\\mathbb{R}^2$ in the usual sense.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("A natural closely related question is about uniqueness (or the number of) such metrics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/568b39c5f16abcbecb107a3f3c8f0b73c881fdadcfbe0f5511f1066079134a30-b20a9013674d1728be5bb84d20666f183d81afafe034529b5e3612acaa91e9ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of duetosymmetry")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490100")[#strong[#text("duetosymmetry")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Consider making the Cayley graph of F2 in the typical way, and putting this into R^2 so that element a marches one step in the +x direction, b marches one step in the +y direction, and the opposite directions for their inverses. Then take the L1 norm on this space.")

#text("Does this satisfy the desired properties?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490101")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("You’ve described the pullback of a metric on ")#mi("{\\bf Z}^2")#text(", which is also being discussed in other comments. Unfortunately this metric has a kernel so is only a seminorm on ")#mi("F_2")#text(", for instance the commutator ")#mi("aba^{-1}b^{-1}")#text(" will have norm zero.")

#text("A norm on ")#mi("{\\bf Z}^d")#text(" with these properties can be seen to induce a norm on the real completion ")#mi("{\\bf R}^d")#text(" (for any vector ")#mi("v \\in {\\bf R}^d")#text(", define ")#tao-math("\\left\\|v\\right\\| := \\lim_{n \\to \\infty} \\frac{1}{n} \\left\\| [nv] \\right\\|", block: false)#text(" where ")#mi("[nv]")#text(" is the nearest lattice point to ")#mi("nv")#text(" (breaking ties arbitrarily)). If another group element acts by conjugation on a copy of ")#mi("{\\bf Z}^d")#text(" then it will induce a norm-preserving action of ")#mi("{\\bf R}^d")#text(", and thus lie in the finite group ")#mi("SL_d({\\bf Z}) \\cap O_d({\\bf R})")#text(", which forces the action to be virtually trivial. I think this is enough to show that norms on finitely generated solvable groups with the stated properties have to come from the abelianisation (possibly after first passing to a finite index subgroup).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490104")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("I’ve been thinking about this. Minor quibble is that the norm need not be the Euclidean one (though the isometry group is always compact). A major quibble is that a finitely generated solvable group can have infinitely generated subgroups (e.g. the lamplighter, though there I think I can show all norms are trivial on the lamps).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490106")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Ah, good points! For the lamplighter, I assume you mean the lamplighter group over ")#mi("{\\bf Z}")#text(" rather than ")#mi("{\\bf F}_2")#text(", since the torsion in the latter case would immediately make all the norms in the commutator vanish. But I don’t know how to proceed over ")#mi("{\\bf Z}")#text(". The norm on the commutator group ")#mi("{\\bf Z}^{\\bf Z}")#text(" is shift-invariant, and the norms of vectors in this group such as ")#mi("v + Tv + \\dots + T^n v")#text(" grow linearly in ")#mi("n")#text(" if ")#mi("T")#text(" denotes the shift, but this doesn’t seem to pin down the structure further.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490108")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Yes, I’m thinking of the lamplighter ")#mi("\\mathbb{Z} \\ltimes \\mathbb{Z}^{\\oplus \\mathbb{Z}}")#text(" where $Z$ acts by translation. The norm on the lamps is a translation-invariant norm, bounded wrt the ")#mi("\\ell^1")#text(" norm. The point is that if the norm on the lamps is non-zero then the conjugates of ")#mi("T")#text(" by a configuration of lamps of large norm have large norm, but this needs to be bounded because conjugates have the same norm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490109")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Never mind, I figured it out. If ")#mi("e_n")#text(" is the basis for ")#mi("{\\bf Z}^{\\bf Z}")#text(" and the lamplighter is generated by ")#mi("e_n")#text(" and an additional generator ")#mi("f")#text(" with ")#mi("fe_n f^{-1} = e_{n+1}")#text(", then ")#mi("f e_0 e_1^{-1} e_2 e_3^{-1} \\dots e_{2n} e_{2n+1}^{-1}")#text(" squares to something of bounded word length and thus has bounded norm (all generators ")#mi("e_n")#text(" are conjugate and thus have the same norm), and hence ")#mi("(f^2 v)^n")#text(" and ")#mi("(f^2 v e_0 e_1^{-1})^n")#text(" differ by bounded distance for any ")#mi("v \\in {\\bf Z}^{\\bf Z}")#text(", hence ")#mi("f^2 v")#text(" and ")#mi("f^2 v e_0 e_1^{-1}")#text(" must have the same norm. But this implies that ")#mi("f^2 (e_0 e_1^{-1})^n")#text(" and ")#mi("f^2")#text(" have the same norm, hence ")#mi("(e_0 e_1^{-1})^n")#text(" is bounded, but it must grow linearly, contradiction.")

#text("None of this sort of trickery seems to be available in the free group, though…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490168")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("Not applicable to the free group, but this lamplighter group is kind of a free solvable group on two generators, so this argumetn is enough to show that every norm on a solvable group comes from the abelianization.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490102")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Worth noting that in any group the elements ")#mi("xy")#text(" and ")#mi("yx")#text(" are conjugate, so the norm of non-commutators must arise from a norm on the abelianization.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a861b523fdb5071ea2d4a76fc38e1e600a3ba2bd97dce963341b3770c82a2e-f09146c65c3fa56f5cfde78a2d6c10c19270ab040979ff9bf0dfd539cba72163.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490105")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("I don’t think “non-commutators” is a rigorous concept here. The key point is that conjugation shows ")#tao-math("\\left|\\left| xyz\\right|\\right|= \\left|\\left|yzx\\right|\\right| = |\\left|zxy\\right|l", block: false)#text(" but not anything about how this compares to ")#tao-math("\\left|\\left|xzy\\right|\\right|=\\left|\\left|zyx\\right|\\right|=\\left|\\left|yxz\\right|\\right|", block: false)#text(", even though all six agree on the abelianization.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d3f3f347a7b10f10ed00a073d27a6a782b68fe64db3137033118f00a93c55ab-956416f7ec8ae648e224ec3aa663df7c74ba2d2ac89fa20ba9892e64ddd51878.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Putman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490110")[#strong[#text("Andy Putman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("I haven’t had time to carefully read through all the comments, but I thought I’d throw out the following simple idea. Let ")#mi("S")#text(" be any generating set for ")#mi("F_n")#text(" that is closed under conjugation (such an ")#mi("S")#text(" must be infinite) and define the ")#mi("S")#text("-norm on ")#mi("F_n")#text(" to be the word length with respect to ")#mi("S")#text(". It is clear that this satisfies conjugation-invariance and the triangle inequality, so the key is finding an ")#mi("S")#text(" where the norm satisfies linear growth. There are a whole ton of possible choices of ")#mi("S")#text(" that might work. One attractive possibility is taking ")#mi("S")#text(" to be the set of primitive elements, that is, elements that form part of a free basis.")

#text("An interesting observation is that the above “primitive element norm” is actually invariant under all automorphisms of the free group (not just inner automorphisms).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490112")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("The element ")#mi("a^n.b")#text(" is primitive, so you won’t get linear growth this way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d3f3f347a7b10f10ed00a073d27a6a782b68fe64db3137033118f00a93c55ab-956416f7ec8ae648e224ec3aa663df7c74ba2d2ac89fa20ba9892e64ddd51878.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Putman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490113")[#strong[#text("Andy Putman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Good point Lior! Another possibility would be to take ")#mi("S")#text(" to be the set of all conjugates of the usual free basis for ")#mi("F_n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490114")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Terry’s original bound of ")#mi("4/3")#text(" shows that if you use a word metric, then your generating set ")#mi("S")#text(" must be closed under commutators.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d3f3f347a7b10f10ed00a073d27a6a782b68fe64db3137033118f00a93c55ab-956416f7ec8ae648e224ec3aa663df7c74ba2d2ac89fa20ba9892e64ddd51878.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Putman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490115")[#strong[#text("Andy Putman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Is that so? His 4/3 bound concerned the norm not of a general commutator, but rather of the commutator of two elements in the standard free basis. But I agree that in my suggested ")#mi("S")#text(" the norm of [a,b] would be 2, and thus would violate Terry’s bound.")

#text("One obvious thing to try to do would be to symmetrize a (conjugation-invariant) word norm ")#tao-math("\\left|\\left|x\\right|\\right|_S", block: false)#text(" by letting ")#tao-math("\\left|\\left|x\\right|\\right|^{\\prime}_S", block: false)#text(" equal the limit as ")#mi("n")#text(" goes to infinity of ")#tao-math("(1/n) \\left|\\left|x^n\\right|\\right|_S", block: false)#text(" (this limit clearly exists). We then clearly have ")#tao-math("\\left|\\left|x^n\\right|^{\\prime}_S = n \\right||x||^{\\prime}_S", block: false)#text(", and the triangle inequality holds. What might go wrong is that it is possible for ")#tao-math("\\left|\\left|x\\right|\\right|^{\\prime}_S = 0", block: false)#text(" for some nontrivial ")#mi("x")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490117")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Well, Terry’s estimate in its general form is ")#tao-math("\\left|\\left|[x,y]\\right|\\right|\\leq\\tfrac{2}{3}(\\left|\\left|x\\right|\\right| + \\left|\\left|y\\right|\\right|)", block: false)#text(" for arbitrary ")#mi("x,y\\in F_2")#text(", using verbatim the same argument for the proof. Since an element is in ")#mi("S")#text(" if and only if its word norm is 1, we can conclude that ")#mi("x,y\\in S")#text(" implies ")#mi("[x,y]\\in S")#text(".")

#text("I had also considered your suggestion of taking ")#tao-math("\\lim_n \\left|\\left|x^n\\right|\\right|/n", block: false)#text(", but it wasn’t clear to me how to prove the triangle inequality. This is straightforward (and standard) in the commutative case, but in a noncommutative group I don’t know what to do with ")#tao-math("\\left|\\left|(xy)^n\\right|\\right|", block: false)#text(", and would suspect the triangle inequality to be violated in general. Any thoughts?")

#text("For example, stable commutator length seems to be a quantity of this type, defined on the commutator subgroup of a group where ")#mi("S")#text(" is taken to be the set of commutators. Does it satisfy the triangle inequality?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d3f3f347a7b10f10ed00a073d27a6a782b68fe64db3137033118f00a93c55ab-956416f7ec8ae648e224ec3aa663df7c74ba2d2ac89fa20ba9892e64ddd51878.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Putman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490121")[#strong[#text("Andy Putman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("You’re absolutely right about the triangle inequality. I’m not sure what I was thinking.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a861b523fdb5071ea2d4a76fc38e1e600a3ba2bd97dce963341b3770c82a2e-f09146c65c3fa56f5cfde78a2d6c10c19270ab040979ff9bf0dfd539cba72163.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490153")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("It seems likely not. It’s known that if ")#mi("g_1,g_2")#text(" are elements of infinite order in (the commutator subgroups of) groups ")#mi("G_1,G_2")#text(", then ")#mi("scl(g_1g_2) = scl(g_1) + scl(g_2) +1/2")#text(" where ")#mi("g_1g_2")#text(" is taken in the free product ")#mi("G_1 * G_2")#text(" (Theorem 2.93 in scl by Danny Calegari, originally due to Christophe Bavard, though apparently not with a correct proof). So in particular the triangle inequality fails in the free group on four generators ")#mi("a,b,c,d")#text(" for the product of a commutator in the free group on ")#mi("a,b")#text(" and one in the free group on ")#mi("c,d")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490124")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Perhaps the existence of an invariant norm satisfying (1)-(3) may be proved by a method similar to the proof of the existence of Haar measure?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490125")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("Some simple remarks:")#linebreak()#text(" * The maximum, or supremum of a set of linear semi-norms with norms of generators bounded above by 1 is a linear semi-norm.")#linebreak()#text(" * Hence we have a canonical semi-norm, the largest linear semi-norm for which the generators have norm at most one.")#linebreak()#text(" * The question is thus reduced to whether this is a norm, or equivalently whether for a specific element g in the free group, there exists a linear semi-norm which is positive on g.")#linebreak()#text(" * I would guess that if there is such a semi-norm for the commutator ")#mi("[a, b]")#text(", there is one for all elements.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490129")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("A very speculative construction of such a norm:")

#text("We take a linear combination of two terms associated to a word ")#mi("w")#text(", with the second having a very small coefficient.")#linebreak()#text(" (1) The norm in the abelianisation.")#linebreak()#text(" (2′) Consider maximal matchings of the letters of ")#mi("w=a_1 a_2\\dots a_n")#text(" such that a letter is matched to an inverse letter (i.e., pairs of indices ")#mi("(i, j)")#text(" such that ")#mi("a_i")#text(" and ")#mi("a_j")#text(" are inverses). For such matchings, we consider the number of crossings (pair of pairs ")#mi("(i, j)")#text(" and ")#mi("(k, l)")#text(" with ")#mi("i < k < l j <l")#text(" after flips if necessary). We associate to the word the minimum number of crossings over all matchings.")#linebreak()#text(" (2) We need to make (2') linear by taking powers and limits as usual.")

#text("The minimal number of crossings does satisfy the triangle inequality. What we need is the norm after the linearization correction also does so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cjerdonek")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490138")[#strong[#text("cjerdonek")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("I could be off here, but why doesn’t it work to take a compact hyperbolic surface with geodesic boundary whose fundamental group is the free group on two generators (e.g. a “pair of pants”), and then define the norm to be the length of the free geodesic representing the element?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490141")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("This fails the triangle inequality (I assume you mean the geodesic representing a conjugacy class)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490140")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("An addendum: one can clearly do a Kobayashi-style construction to get the triangle inequality, so the question is whether after all this we get positivity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490147")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("Just a clean up of the above, the main idea is to consider the following function of a word ")#mi("w")#text(" in the free group:")

#text("(1) Consider partial matchings of the letters without crossing and so that letters can only be matched with their inverse.")#linebreak()#text(" (2) For such a matching, we count the number of letters that are unmatched.")#linebreak()#text(" (3) Minimize this over all such partial matchings")

#text("This may even be a linear norm – if not I conjecture that after the usual constructions to make it linear and a norm, we still get positivity (related stuff is in arXiv:0809.3110)")

#text("Incidentally, for the commutator ")#mi("[a, b]")#text(", the value of the function is exactly 2, the Tao bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490154")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("What are “the usual constructions” to make it linear and a norm?")

#text("Over in ")#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490117")[#text("the other thread")]#text(", we ran into the problem that it’s not clear whether linearizing via ")#tao-math("\\lim_n \\left|\\left|x^n\\right|\\right|/n", block: false)#text(" retains the triangle inequality. And as Will pointed out, stable commutator length is essentially a counterexample (taking it to be infinite on elements that are not commutators).")

#text("On the other hand, when starting with a linear quantity and enforcing the triangle inequality by taking shortest paths, it’s also not obvious why linearity would be preserved, or is it?")

#text("So in general, it may be that one has to iterate both constructions, resulting in an infinite regress.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490155")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("That’s true, one may in general have to iterate infinitely often, so the key is to understand to what extent linearity fails for the “unmatched letters” function, and control the process. Triangle inequality clears holds (but will be in general broken by linearization).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490159")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("A small observation: the linear growth and conjugation invariance axioms for the norm can be replaced without loss of generality to just the ")#mi("n=2")#text(" case ")#tao-math("\\left\\| x^2 \\right\\| = 2 \\left\\|x\\right\\|", block: false)#text(" of the linear growth axiom. This implies ")#tao-math("\\left\\|x^n \\right\\| = n \\left\\|x\\right\\|", block: false)#text(" for ")#mi("n")#text(" a power of two, while the triangle inequality gives ")#tao-math("\\left\\| x^n \\right\\| \\leq n \\left\\|x\\right\\|", block: false)#text(" for all positive ")#mi("n")#text("; since any natural number is eventually upper bounded by a power of two, the triangle inequality again then gives ")#tao-math("\\left\\| x^n \\right\\| = n \\left\\|x\\right\\|", block: false)#text(" for all positive ")#mi("n")#text(". Finally, replacing ")#tao-math("\\left\\|x\\right\\|", block: false)#text(" with ")#tao-math("\\max( \\left\\|x\\right\\|, \\left\\|x^{-1} \\right\\|)", block: false)#text(" gives the negative ")#mi("n")#text(" cases of the linear growth axiom, and ")#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490066")[#text("Tobias’s observation")]#text(" then recovers the conjugation invariance axiom.")

#text("Equivalently, the problem may be reduced to the following. Is there a function ")#mi("\\| \\|: {\\bf F}_2 \\to {\\bf R}^+")#text(" such that ")#tao-math("\\left\\|xy\\right\\| \\leq \\left\\|x\\right\\| + \\left\\|y\\right\\|", block: false)#text(" for all ")#mi("x,y \\in {\\bf F}_2")#text(" with equality whenever ")#mi("x=y")#text(", such that ")#tao-math("\\left\\|x\\right\\| > 0", block: false)#text(" for all non-identity ")#mi("x")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("It seems that one can take the norm of ")#mi("x")#text(" to be the minimal length over all the words conjugate to it. (the norm of the identity is defined to be 0).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490162")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("Let ")#mi("d(\\cdot,\\cdot )")#text(" be the Levenshtein distance defined on the set of all strings on 5 alphabets ")#mi("a, a^{-1}, b , b^{-1}, \\epsilon")#text(". Note that ")#mi("\\epsilon")#text(" represents the empty string. Let further identify ")#mi("a a^{-1}=a^{-1}a=b b^{-1}=b^{-1} b")#text(" with ")#mi("\\epsilon")#text(". Under this identification, each element of ")#mi("F_2")#text(" can be uniquely identified with a string with minimum length. For example, the string ")#mi("aba^{-1}\\epsilon ab^{-1}")#text(" is ")#mi("a")#text(". Under this identification, I think the Levenshtein distance is well defined on ")#mi("F_2")#text(" and has all the desired properties.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490165")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("Interesting idea, but it can’t work as stated: edit distance is always an integer while as noted above commutators have norm at most ")#mi("\\frac43")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490166")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("Ultimately the problem is that there are words ")#mi("x")#text(" (such as ")#mi("aba^{-1}b^{-1}aba^{-1}b^{-1}")#text(") for which one can efficiently edit ")#mi("x^2")#text(" to the identity in a manner that is cheaper than editing the two copies of ")#mi("x")#text(" to the identity separately.")

#text("Here is another idea I had for constructing a norm, coming from functional analysis. If one assigns unitary operators ")#mi("U_a, U_b: H \\to H")#text(" on a Hilbert space, then this generates a unitary representation ")#mi("g \\mapsto U_g")#text(" on the free group. It is then tempting to define ")#mi("d(g,h)")#text(" to be some conjugation invariant operator norm of the difference ")#mi("U_g - U_h")#text(", such as a Schatten p-norm ")#tao-math("d(g,h) = \\left\\|U_g - U_h\\right\\|_p", block: false)#text(". The problem is that this doesn’t obey the doubling property. However, it comes close to obeying doubling near the origin of the spectrum, so one could imagine trying some sort of asymptotic Schatten p-norm such as ")#tao-math("d(g,h) = \\lim_{p \\to p_0^+} (p-p_0)^\\alpha \\left\\|U_g - U_h\\right\\|_p", block: false)#text(" for a suitable exponent ")#mi("\\alpha>0")#text(", where ")#mi("p_0")#text(" is some sort of critical exponent whose Schatten class the differences ")#mi("U_g - U_h")#text(" just fail to live in, as this sort of limit will be insensitive to the portion of the spectrum away from the origin, and one recovers doubling after taking a limit. Unfortunately the problem is that the commutator ")#mi("[U_g,U_h] - 1")#text(" tends to have much better Schatten properties than ")#mi("U_g-1")#text(" or ")#mi("U_h-1")#text(" (the former is essentially the Lie bracket of the latter, up to conjugation) and so all the implementations of this idea I tried produced a seminorm that vanished on commutators, much as with previous constructions. But maybe some variant of this construction will work (I’m pretty sure one needs an infinite dimensional representation though, for finite dimensional reps the doubling condition is way too limiting.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490176")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("What’s wrong with taking two generic positive symmetric matrices instead, and considering the logarithm of the condition number?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490177")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("or actually two generic matrices without restrictions")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4414fdd6857c1755e1e6ab3e8dee970721893f4ef5d7205c3229d99052b1986d-a9a6fdfba3784d559baa8640ce10d5508d3a7b4825f2427525826a0d59bbd822.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexmaplegm")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490288")[#strong[#text("alexmaplegm")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Why do you expect this to to obey the triangle inequality?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490180")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("sorry, symmetry is required obviously for the condition number to work, obviously")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2017")])]

#text("Is it clear that such metric exists on words with length bounded by let’s say 100?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("This problem of assigning norm values to words of bounded length (for any given fixed bound) can be formulated as a linear programming problem – for which the existence of admissible norm values can be decided.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490264")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Exactly. I just wondered if somebody ran it for small values.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490265")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("There are about ")#mi("3^{100}")#text(" elements in the ball of radius ")#mi("100")#text(", so we won’t be checking that by computer. On the other hand, even the ")#mi("\\frac{4}{3}")#text(" bound on commutators was obtained above by considering ")#mi("[a,b]^3")#text(" which has word length ")#mi("12")#text(". In short, I find it hard to believe that you’ll get something non-trivial at radii which are computationally accessible. That said, I’d be very happy to be proven wrong.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490268")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("By putting together the two bounds Terry gave, we get that commutators of the generators are bounded in norm by 5/4, which improves over 4/3.")

#mi("(aba^{-1}b^{-1})^4=[(ab)(\\text{ three conjugates of norm at most 1 })(ab)^{-1}](a^2ba^{-1}b^{-1})")

#text("and that last quantity ")#mi("a^2ba^{-1}b^{-1}")#text(" has norm at most 2 (by Terry’s second argument). This idea might be useful to push things further.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490269")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Perhaps there is a generalization of such identities for higher powers of the commutators (or some recursive relations among consecutive powers) to push the bound arbitrarily close to 1 ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490270")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("This is exciting! There are indeed ")#link("http://www.ms.uky.edu/~jack/2013-06-21-Commutator.pdf")[#text("commutator formulas")]#text(" that could be related, but previously I hadn’t seen concretely how we could apply them to derive better bounds. Perhaps Pace’s new observation can provide some guidance here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Ad hoc iteration of this seems to give further improvements. Firstly, the argument bounding ")#tao-math("\\left\\| ab^2 a^{-1}b^{-1}\\right\\|", block: false)#text(" in the blog post more generally gives")

#tao-math("\\displaystyle \\left\\| x y^2 x^{-1} y^{-1} \\right\\| \\leq \\left\\|x\\right\\| + \\left\\| y\\right\\|", block: false)

#text("for any ")#mi("x,y")#text(", and similarly for other words that are similar to ")#mi("xy^2 x^{-1}y^{-1}")#text(", such as ")#mi("x^2 y x^{-1} y^{-1}")#text(". Your argument then gives")

#tao-math("\\displaystyle \\left\\| xyx^{-1}y^{-1} \\right\\| \\leq \\frac{1}{4} ( 2\\left\\|x\\right\\| + 3 \\left\\|y\\right\\| )", block: false)

#text("(side note: curious that the LHS is symmetric in ")#mi("x,y")#text(" but the RHS is not) and in particular")

#tao-math("\\displaystyle \\left\\| a^2 b a^{-2} b^{-1} \\right\\| \\leq \\frac{7}{4},", block: false)

#text("improving over the more obvious upper bound of 2 coming from ")#tao-math("\\left\\|a^2 b a^{-2} \\right\\|, \\left\\|b^{-1} \\right\\| \\leq 1", block: false)#text(".")

#text("On the other hand, your argument also gives")

#tao-math("\\displaystyle \\left\\| aba^{-1}b^{-1} \\right\\| \\leq \\frac{1}{4} ( \\left\\| (a^{-1} b^{-1} a) (b a^{-1} b) (aba^{-1}) \\right\\| + \\left\\|a^2 b a^{-1} b^{-1}\\right\\|)", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\leq \\frac{1}{4} ( \\left\\| (b a^{-1} b) (aba^{-1}) (a^{-1} b^{-1} a) \\right\\| + 2 )", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\leq \\frac{1}{4} ( \\left\\| (aba^{-1}) (a^{-1} b^{-1} a) \\right\\| + 3 )", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle = \\frac{1}{4} ( \\left\\|  a^2 ba^{-2} b^{-1} \\right\\| + 3 )", block: false)#linebreak()#text(" ")#mi("\\displaystyle \\leq \\frac{1}{4} ( \\frac{7}{4} + 3 ) = \\frac{19}{16}")

#text("which is a small improvement over the previous bound of ")#mi("5/4 = 20/16")#text(". It looks like some further improvement is possible by additional iteration, though I’m not seeing a fully systematic way to keep doing this. As mentioned previously, a completely brute force search is likely to be computationally infeasible, but maybe there is still some scope for computer assisted location of bounds here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490273")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("If I haven’t made an error, I think we have the identity ")#mi("[x,y]^k = (xyx)\\left(x^{-2}y^{-1}xy[x^{-1},y^{-1}]^{k-3}\\right)(xyx)^{-1} (x^2yx^{-1}y^{-1})")#text(" and hence ")#tao-math("\\left\\| [x,y]\\right\\| \\leq \\frac13\\left(\\left\\| x^{-2} y^{-1} xy\\right\\| + \\left\\| x^2 y x^{-1}y^{-1}\\right\\|\\right)", block: false)#text(" that is")

#tao-math("\\left\\| [a,b] \\right\\| \\leq \\frac23 \\frac74 = \\frac76", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490276")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Does the 7/4 show up for the word you are using too, Lior, or is it for a commutator like Terry wrote? (I had obtained the same identity, but wasn’t sure how to beat 2 for that word.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490279")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("@Lior: could you please elaborate on the use of 7/4 here? (I had worked out the same identity, but didn’t see how to plug in 7/4 in it instead of 2.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490290")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("You’re right — it should have been 2.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d512ca171a41af1190c06095ed4f8adf49cde65a930b64f20a11fcefbafafba-60485da70f03b542d93f7d2d7d588eab8266257342081a9e4440a3d1cf6588ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490272")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("This is very exciting! I’ll just add a few remarks here.")

#text("(1) The observation that Terry made about linear growth being equivalent to “doubling” (norm(x^2) = 2*norm(x)) can also be found in the preprint ")#link("http://arxiv.org/abs/1610.03037")[#text("http://arxiv.org/abs/1610.03037")]

#text("(2) The preprint explores how *abelian* groups with linear growth embed into “minimal” vector spaces, and those into “minimal” Banach spaces – whence the linear growth is just the property of the norm. Two corresponding questions in the non-abelian setting would be:")

#text("(i) Do such non-abelian groups with linear growth exist in the first place? In particular, if they do, restrict to the subgroup generated by two non-commuting elements a,b.")

#text("(ii) Would such a group embed into a “geodesically” closed group, say a connected Lie group?")

#text("The latter question can be answered negatively: by Lemma 7.5 in Milnor’s 1976 Advances paper")#linebreak()#text(" ")#link("http://www.sciencedirect.com/science/article/pii/S0001870876800023")[#text("http://www.sciencedirect.com/science/article/pii/S0001870876800023")]#linebreak()#text(" every such group would be (compact) x (abelian); but the (compact) has torsion so much be trivial, and then (abelian) cannot work. So there are no such Lie groups, whence no embedding. This leaves the former question.")

#text("(3) A small typo, in Terry’s latest computation involving 19/16: the last b^{-1} should be b. ")#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99077de2ce4cd90a3bab5c7a180eb894bd6bb365e81afb59c315af204aca3bbb-36afb7bbf9d844f5451ab123fdd86fedf8736cf48b85879d1658adbe17de608a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of António Machiavelo")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490278")[#strong[#text("António Machiavelo")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("A very simple remark that may be worth noticing is that, for all ")#mi("x,y\\in F_2")#text(", one has ")#tao-math("\\left\\| xy\\right\\| = \\left\\| yx\\right\\|", block: false)#text(". This follows from the fact that, for all ")#mi("m\\in\\mathbb{N}")#text(", ")#tao-math("\\left\\| xy\\right\\| = \\frac{1}{m}\\left\\| (xy)^m \\right\\| = \\frac{1}{m} \\left\\| x(yx)^{m-1}y\\right\\| \\leq (1-\\frac{1}{m}) \\left\\| yx \\right\\| + \\frac{\\left\\| x\\right\\| + \\left\\| y\\right\\|}{m}", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d512ca171a41af1190c06095ed4f8adf49cde65a930b64f20a11fcefbafafba-60485da70f03b542d93f7d2d7d588eab8266257342081a9e4440a3d1cf6588ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490280")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Taking a step back, notice that *all* bounds obtained so far on the norm of [a,b], are above 1. And we want to get this estimate down to zero!")

#text("What kind of technique or result would (at least) push the bound below 1? Do we think that current techniques will do so?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d512ca171a41af1190c06095ed4f8adf49cde65a930b64f20a11fcefbafafba-60485da70f03b542d93f7d2d7d588eab8266257342081a9e4440a3d1cf6588ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490282")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("(PS. Perhaps stating the obvious: can this in fact be done at all?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490284")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Perhaps a related question is about possible derivation (by similar methods) of some nontrivial (i.e. positive) lower(!) bounds on commutators norms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490283")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("I have to get home soon, so I ran out of time to work out exactly what happens, but I thought I’d share another observation now so people can play with it:")

#tao-math("\\left\\|xyx^{-2}y^{-1}| = \\frac{1}{2}\\right\\|(xyx^{-2}y^{-1})^2\\|", block: false)

#tao-math("=\\frac{1}{2}\\left\\|(xyx^{-2}y^{-1}x)(yx^{-2}y^{-1})\\right\\|", block: false)

#tao-math("\\leq\\frac{1}{2}(\\left\\|xyx^{-2}y^{-1}x\\right\\|+ 2\\left\\|x^{-1}\\right\\|)", block: false)

#tao-math("=\\frac{1}{2}(\\left\\|x^2yx^{-2}y^{-1}\\right\\|+2\\left\\|x\\right\\|)", block: false)

#text("Thus, the bound on ")#tao-math("\\left\\|x^2yx^{-1}y^{-1}\\right\\|", block: false)#text(" improves as the bound on ")#tao-math("\\left\\|x^2yx^{-2}y^{-1}\\right\\|", block: false)#text(" improves. This quantity improves as the bound on ")#tao-math("\\left\\|xyx^{-1}y^{-1}\\right\\|", block: false)#text(" improves, and this in turn improves as bounds on the first quantity improve. [There is also the possibility that simultaneously playing with ")#mi("y")#text(" might help too.] I got at down to 37/32 after one iteration of this idea.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("One could start automating this to some extent. We are finding a number of inequalities of the form")

#tao-math("\\left\\| x y x^{-1} y^{-1} \\right\\| \\leq \\alpha \\left\\| x\\right\\| + \\beta \\|y\\| \\quad (1)", block: false)

#text("or")

#tao-math("\\left\\| x y x^{-2} y^{-1} \\right\\| \\leq \\gamma \\left\\| x\\right\\| + \\delta \\|y\\| \\quad (2)", block: false)

#text("for various ")#mi("\\alpha,\\beta, \\gamma,\\delta")#text(". For instance (1) holds for ")#mi("(\\alpha,\\beta) = (0,2), (2/3,2/3), (1/2,3/4)")#text(", while (2) holds for ")#mi("(\\gamma,\\delta)=(1,1)")#text(". We now also have a number of rules that allow one to convert existing bounds to other ones. For instance your argument shows that if (1) holds for ")#mi("(\\alpha,\\beta)")#text(" then (2) holds for ")#mi("(\\alpha+1, \\frac{\\beta}{2})")#text(". Swapping ")#mi("x,y")#text(" we also know that if (1) holds for ")#mi("(\\alpha,\\beta)")#text(" then (1) also holds for ")#mi("(\\beta,\\alpha)")#text(". Lior’s identity shows that if (2) holds for ")#mi("(\\gamma,\\delta)")#text(" then (1) holds for ")#mi("(\\frac{2 \\gamma}{3}, \\frac{2\\delta}{3})")#text(". My previous argument shows (I think) that if (1) holds for ")#mi("(\\alpha,\\beta)")#text(" and (2) holds for ")#mi("(\\gamma,\\delta)")#text(", then (1) holds for ")#mi("(\\frac{2\\alpha+1+\\gamma}{4},\\frac{\\delta+\\beta}{4})")#text(". Perhaps one could start collecting more implications like this and then use a computer to iterate and optimise?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("One may try also to derive similar lower bounds on the norms (which may be used to prove that such a metric can’t exist if after optimization they become larger than the corresponding optimized upper bounds)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490293")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Assuming we expect ")#tao-math("\\left\\|[x,y]\\right\\|=0", block: false)#text(" I’d replace ")#mi("\\gamma")#text(" with ")#mi("1+\\gamma")#text(".")

#text("Also, we know that if (1) holds for ")#mi("(\\alpha,\\beta)")#text(" it also holds for ")#mi("(\\frac23+\\frac13\\alpha,\\frac13\\beta)")#text(". This is a contracting map with fixed point ")#mi("(\\frac23,0)")#text(".")

#text("Did I make a mistake?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490294")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Of course I did. The fixed point is ")#mi("(1,0)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d512ca171a41af1190c06095ed4f8adf49cde65a930b64f20a11fcefbafafba-60485da70f03b542d93f7d2d7d588eab8266257342081a9e4440a3d1cf6588ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490295")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("That looks right to me! I was working very crudely it seems.")

#text("Now just start with e.g. (0,2), and one gets to (2/3,0). We are below 1!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d512ca171a41af1190c06095ed4f8adf49cde65a930b64f20a11fcefbafafba-60485da70f03b542d93f7d2d7d588eab8266257342081a9e4440a3d1cf6588ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490296")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Aha, even I got carried away. But then my original point remains: can we check starting with (0,2) that we might come below 1? Or use Terry’s bound at some point.")

#text("The fixed point is (1,0), but as long as we can approach it from below…")

#text("(Sorry, I’m attending a conference in honor of Thangavelu here, so cannot work it out right now…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490298")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("But the following is correct: iterating ")#mi("(\\gamma,\\delta)\\mapsto(\\frac{2\\alpha+1+\\gamma}{4},\\frac{\\beta+\\delta}{4})")#text(" gives the fixed point ")#mi("(\\gamma,\\delta)=(\\frac{2\\alpha+1}{3},\\frac{\\beta}{3})")#text(".")

#text("Using ")#mi("(\\alpha,\\beta)=(1,0)")#text(" we get ")#mi("(\\gamma,\\delta)=(1,0)")#text(" which is exciting to me because that’s the bound consistent with ")#tao-math("\\left\\|[x,y]\\right\\| = 0", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490303")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Something is wrong somewhere: if the fixed point ")#mi("\\gamma = \\frac{2\\alpha+1}{3}")#text(" really were correct then using the admissible value ")#mi("alpha = \\frac23 \\gamma")#text(" gives the transformation ")#mi("\\gamma \\mapsto \\frac49\\alpha + \\frac13")#text(" with fixed point ")#mi("\\gamma = \\frac35")#text(". It follows that we can take ")#mi("(\\gamma,\\delta) = (\\frac35,0)")#text(" and ")#mi("(\\alpha,\\beta) = (\\frac25,0)")#text(".")

#text("Unfortunately, it should be impossible to take ")#mi("\\gamma\\leq 1")#text(" because there exist norms vanishing on the commutators and for those")#linebreak()#text(" ")#tao-math("\\left\\| x^2yx^{-1}y^{-1} \\right\\| = \\left\\| x \\right\\|", block: false)#text(" independently of ")#mi("y")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490306")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("The problem is that the pair ")#mi("(\\frac{2\\alpha+1+\\gamma}{4}, \\frac{\\beta+\\delta}{4})")#text(" is a pair for the ")#mi("(\\alpha,\\beta)")#text(" inequality, not the ")#mi("(\\gamma,\\delta)")#text(" inequality, so the iteration doesn’t work.")

#text("I’ve written up the arguments that I was able to check were correct, and put then on a fresh blog post. Given the large number of comments on this thread, it is probably best for everyone to move over to the new post (as per the polymath projects, which I guess this question has become a ")#emph[#text("de facto")]#text(" version of).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490297")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("The pair ")#mi("(\\alpha, \\beta) = (1/2, 3/4)")#text(" is equivalent to ")#mi("(3/4,1/2)")#text(" which (by taking their mean) implies the pair ")#mi("(5/8, 5/8)")#text(" which is better than ")#mi("(2/3, 2/3)")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d512ca171a41af1190c06095ed4f8adf49cde65a930b64f20a11fcefbafafba-60485da70f03b542d93f7d2d7d588eab8266257342081a9e4440a3d1cf6588ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490289")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Very nice – in that case I think we can cross below the magic bound of 1 at least, in Equation (1)! Here’s how: let A = \\alpha + \\beta, C = \\gamma + \\delta.")#linebreak()#text(" Start with (1) for \\alpha = 1/2, \\beta = 3/4, so A = 5/4.")#linebreak()#text(" By iteratively applying Lior and Pace alternately, we converge to A = 1, C = 3/2.")#linebreak()#text(" But now once we get close enough to these values, apply Terry’s previous argument. This will get us close to A = 7/8, which means we are below 1.")

#text("(If I did the math correctly.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d512ca171a41af1190c06095ed4f8adf49cde65a930b64f20a11fcefbafafba-60485da70f03b542d93f7d2d7d588eab8266257342081a9e4440a3d1cf6588ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490291")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Oops, I was using the wrong bound. My crude estimates suggest we will get to something not close to 7/8 (as I’d just written), but to something bounded *above* by 9/8. Exactly what it is (i.e. \\leq 1 or not) should be computable by examining not just A,C, but what \\alpha and \\beta become in the limit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490299")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Here’s a proof that we can assume the norm is invariant to natural symmetries (so we get for instance that ")#tao-math("\\left|\\left|ab\\right|\\right| = \\left|\\left|ba^{-1}\\right|\\right|", block: false)#text(").")

#text("Let ")#mi("I_a : F_2 \\to F_2")#text(" be the “inversing ")#mi("a")#text("” map (e.g. ")#mi("I_a(aba^{-1}ba^2) = a^{-1}baba^{-2}")#text(") and ")#mi("I_b")#text(" be analogous. Let ")#mi("S: F_2 \\to F_2")#text(" be the “switch” map, switching ")#mi("a")#text(" and ")#mi("b")#text(" (e.g. ")#mi("S(aba^{-1}ba^2) = bab^{-1}ab^2")#text("). Then ")#mi("X := \\{Id, I_a, I_b, I_aI_b, S, I_aS, I_bS, I_aI_bS\\}")#text(" is invariant to left multiplication by any of its elements.")

#text("So, if we have any norm ")#mi("||\\cdot||_1")#text(", we can form a norm ")#mi("||\\cdot||_2")#text(" by ")#tao-math("\\left|\\left|x\\right|\\right|_2 = \\frac{1}{8}\\sum_{T \\in X} \\left|\\left|Tx\\right|\\right|_1", block: false)#text(". Since for any ")#mi("T \\in X")#text(" and any ")#mi("x,y \\in F_2")#text(", ")#mi("T(xy) = TxTy")#text(", it is easy to see that ")#mi("||\\cdot||_2")#text(" also satisfies the requirements (cf Terry’s simplification in one of the comments) and is invariant to any ")#mi("T \\in X")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490301")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Looks like some computer searching does give a bound on the commutator that is below 1. If correct I will get “proofs” output by the same code soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490302")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("We can get below 1 (as others seem to have recognized). Here is one way:")

#text("We previously derived ")#tao-math("\\left\\|x^2yx^{-1}y^{-1}\\right\\|\\leq \\frac{1}{2}\\left\\|x^2yx^{-2}y^{-1}\\right\\|+\\left\\|x\\right\\|", block: false)#text(". Plugging this into the general argument Terry gave, which was used to get the bound 19/16, yields ")#tao-math("\\left\\|xyx^{-1}y^{-1}\\right\\|\\leq \\frac{3}{8}\\left\\|x^2yx^{-2}y^{-1}\\right\\|+\\frac{1}{2}\\left\\|x\\right\\|", block: false)#text(".")

#text("Now, if ")#tao-math("\\left\\|xyx^{-1}y^{-1}\\right\\|\\leq \\alpha \\left\\|x\\right\\|+\\beta\\left\\|y\\right\\|", block: false)#text(", then ")#tao-math("\\left\\|x^2yx^{-2}y^{-1}\\right\\|\\leq 2\\alpha\\left\\|x\\right\\|+\\beta\\left\\|y\\right\\|", block: false)#text(". So, plugging this into the formula above we reach ")#tao-math("\\left\\|xyx^{-1}y^{-1}\\right\\|\\leq (\\frac{3}{4}\\alpha+\\frac{1}{2})\\left\\|x\\right\\|+\\frac{3}{8}\\beta\\left\\|y\\right\\|", block: false)#text(". By symmetry, we have the corresponding inequality with those same coefficients switched. Thus if we set ")#mi("f(\\alpha,\\beta)=(\\frac{3}{8}\\beta,\\frac{3}{4}\\alpha+\\frac{1}{2})")#text(", the output is a valid set of new ")#mi("\\alpha,\\beta")#text(" coefficients. Starting with ")#mi("(\\alpha,\\beta)=(1/2,3/4)")#text(" the fifth iteration has a sum below 1. It appears to converge to about ")#mi("0.956522")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490304")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("The map ")#mi("(\\alpha,\\beta)\\mapsto (\\frac38\\beta,\\frac34\\alpha+\\frac12)")#text(" is evidently contracting, so the iterates will converge to the fixed point which is ")#mi("(\\alpha,\\beta)=(\\frac{6}{23},\\frac{16}{23})")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490305")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Adding that ")#mi("\\frac{6}{23} + \\frac{16}{23} = \\frac{22}{23} \\approx 0.956522")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bi-invariant metrics of linear growth on the free group, II | What's new")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490307")[#strong[#text("Bi-invariant metrics of linear growth on the free group, II | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("[…] Terence Tao on Bi-invariant metrics of linear… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490309")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Let’s first build such a “norm” on the kernel ")#mi("G")#text(" of the natural map from ")#mi("F_2")#text(" to ")#mi("\\mathbb{Z}^2")#text(". An element in ")#mi("G")#text(" is an equivalence class of closed loops based at ")#mi("0")#text(" on ")#mi("\\mathbb{Z}^2")#text(", two loops being equivalent if they are the same “modulo backtracking”. Now consider the area enclosed by the loop, more precisely the integral over ")#mi("\\mathbb{R}^2")#text(" of the absolute value of the winding number. This only depends on the equivalence class and satisfies the conditions. To extend this norm to ")#mi("F_2")#text(", one can set the norm of the elements outside ")#mi("G")#text(" to be the norm of their image in ")#mi("\\mathbb{Z}^2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490311")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2017")])]

#text("Unfortunately once one enlarges ")#mi("G")#text(", one ceases to be a norm. For instance, with your construction, the word ")#mi("a^n b^n a^{-n} b^{-n}")#text(" has norm ")#mi("n^2")#text(", but by the triangle inequality it can only have norm ")#mi("O(n)")#text(" once one is allowed to use the generators outside of ")#mi("G")#text(", leading to a contradiction when ")#mi("n")#text(" is large. (There is also a secondary issue, namely that there are some non-trivial elements of ")#mi("G")#text(" that continue to have zero norm because the winding numbers all cancel each other out.) The obstructions here are related to those showing that there are no seminorms on nilpotent groups other than those coming from the abelianisation.")

#text("However, this does raise an interesting question: what additional conditions of a norm on ")#mi("G")#text(" are sufficient to permit an extension to all of ")#mi("F_2")#text("? The question may be easier if one looks at the kernel of a map to ")#mi("{\\bf Z}")#text(" rather than to ")#mi("{\\bf Z}^2")#text(" (e.g. the homomorphism that sends ")#mi("a")#text(" to ")#mi("1")#text(" and annihilates ")#mi("b")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490312")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("And again, this is an example of a seminorm that arises by pullback from the abelianization: if ")#mi("x")#text(" and ")#mi("y")#text(" are closed loops, then the oriented area enclosed by ")#mi("xyx^{-1}y^{-1}")#text(" is zero.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490396")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("One can get a bound on the commutator of 0.816 with a brutal proof (not optimized by any means). The proof (computer generated but formatted to be readable) is at")

#link("https://github.com/siddhartha-gadgil/Superficial/wiki/A-commutator-bound")[#text("https://github.com/siddhartha-gadgil/Superficial/wiki/A-commutator-bound")]

#text("Comments welcome. Someone cleverer may extract useful inequalities from this (or find an error).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490400")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("This was beautiful! My intuition was, before scouring your file, that we now have strong evidence that the norm will be forced to equal zero on commutators. Thus, elements like ")#mi("xyx^{-1}y^{-1}x")#text(" should have norm the same as ")#mi("x")#text(". Our job is then to bound the norm of words like ")#mi("(xyx^{-1}y^{-1})^kx")#text(" (for larger and larger values of ")#mi("k")#text(") nearer and nearer the norm of ")#mi("x")#text(".")

#text("I was surprised, when reading your file, that this seems to be the path that the computer has taken, with a few additional ideas thrown in. The first 43 lines establish")

#tao-math("\\left\\|(xyx^{-1}y^{-1})^2x\\right\\|\\leq \\frac{1}{18}(20\\left\\|x\\right\\|+18\\left\\|y\\right\\|)", block: false)

#text("and lines 44 to 73 establish")

#tao-math("\\left\\|xyx^{-1}y^{-1}x\\right\\|\\leq \\frac{1}{18}(18\\left\\|x\\right\\|+10\\left\\|y\\right\\|)", block: false)

#text("(which, incidentally, gives a new ")#mi("(\\gamma,\\delta)=(1,5/9)")#text(" value). Lines 74 to 119, using these previous bounds, establishe a similar type of bound on ")#tao-math("\\left\\|(xyx^{-1}y^{-1})^6x\\right\\|", block: false)#text(". And the last few lines use this information to bound the norm of a commutator.")

#text("This was very well done!")

#text("We can improve the first computation to the bound")

#tao-math("\\left\\|(xyx^{-1}y^{-1})^2x\\right\\|\\leq \\left\\|x\\right\\|+\\left\\|y\\right\\|", block: false)

#text("as follows. Let ")#mi("n")#text(" be an extremely large power. Then (following what the computer did), when we expand ")#mi("(xyx^{-1}y^{-1}xyx^{-1}y^{-1}x)^n")#text(" it has two ")#mi("x")#text("‘s on the edges, which we peel off, and the rest looks like")

#mi("(((y^{-1}xy)(x^{-1}y^{-1}x))^{x^{-1}}....((xyx^{-1})(y^{-1}xy))^{x})^y")

#text("where the dots in the middle means that this pattern repeats inwardly. [Note: When writing powers in variables I’m just using the standard conjugation notation.] This pattern continues until we reach the very middle, where there are a bounded number of terms that don’t fit this pattern. Thus,")

#tao-math("\\left\\|xyx^{-1}y^{-1}x\\right\\|\\leq \\frac{1}{n}\\left\\|(xyx^{-1}y^{-1}x)^n\\right\\|  \\leq \\frac{1}{n}((n+O(1))\\left\\|x\\right\\|+(n+O(1))\\left\\|y\\right\\|)", block: false)#text(".")

#text("I’ll take a look at the computer’s bound on ")#tao-math("\\left\\|xyx^{-1}y^{-1}x\\right\\|", block: false)#text(" to see if we can get a similar improvement.")

#text("P.S. I’ll probably post anything I find to the newer thread Terry created.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490488")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Pace, I’m not able to verify the identity for ")#mi("(xyx^{-1}y^{-1}xyx^{-1}y^{-1}x)^n")#text(" you’ve claimed above. Could you elaborate on what “repeating inwardly” means, perhaps by supplying the next few terms in the ")#mi("...")#text("?")

#text("EDIT: Never mind, I figured it out (thanks also to Pace for simultaneously communicating this), as you keep going inwards you keep on conjugating further, so your expansion is of the form")

#mi("\\displaystyle (A (A (A \\dots B)^{y} B)^{y} B)^{y}")

#text("where ")#mi("A := ((y^{-1}xy)(x^{-1}y^{-1}x))^{x^{-1}}")#text(" and ")#mi("B := ((xyx^{-1})(y^{-1}xy))^{x}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490401")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Wow. How did you find this? There’s no way you did a computation on the entire ball of radius 500.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490402")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2017")])]

#text("Now to explicate lines 44-73. The pattern found by the computer gives the bounds")

#tao-math("\\left\\|xyx^{-1}y^{-1}x\\right\\|\\leq \\frac{1}{2}\\left\\|x^2yx^{-1}y^{-1}x^2yx^{-1}\\right\\|\\leq \\left\\|x\\right\\|+\\frac{1}{2}\\left\\|y\\right\\|", block: false)#text(".")

#text("This is derived in a manner similar to what I did above. Taking a very large power of ")#mi("y^{-1}x^2yx^{-1}")#text(", and dropping the last ")#mi("x^{-1}")#text(", it has the pattern")

#mi("((x^2yx^{-1}y^{-1}x^2yx^{-1})...(x^{-1}y^{-1}x^2yx^{-1}y^{-1}x^2))^{y^{-1}}")

#text("where again the dots means the pattern repeats inward (with some ")#mi("O(1)")#text(" terms in the middle). Now ")#mi("(x^2yx^{-1}y^{-1}x^2yx^{-1})=((xyx^{-1})(x^2)^{y^{-1}})^x")#text(" has norm bounded by ")#tao-math("2\\left\\|x\\right\\|+\\left\\|y\\right\\|", block: false)#text(" so the result follows.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490414")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("What amazing developments!")

#text("Especially this inward-repetition method seems quite powerful. So why not apply it to the commutator itself? Like this, I think I can show ")#tao-math("\\left|\\left|xyx^{-1}y^{-1}\\right|\\right|\\leq \\tfrac{1}{2}(\\left|\\left|x^{-2}y^{-1}xy\\right|\\right|  + \\left|\\left|x^2yx^{-1}y^{-1}\\right|\\right|", block: false)#text(". The reason is that a high power of the commutator gives the inward repeating pattern")

#mi("xyx^{-1}y^{-1}xyx^{-1}y^{-1}\\ldots y^{-1}xyx^{-1}y^{-1}xyx^{-1},")

#text("ignoring edge and centre terms. This pattern is the same as")

#mi("((x^{-1}y^{-1}xyx^{-1})^y\\ldots (xyx^{-1}y^{-1}x)^{y^{-1}})^x")

#text("Since per pattern, this corresponds to four copies of the commutator, we obtain the claimed bound.")

#text("I’ve lost track of the current best bounds on ")#tao-math("\\left|\\left|x^2yx^{-1}y^{-1}\\right|\\right|", block: false)#text(", so I’m not sure about how this compares with the other results that we have so far. But I’ll keep trying to get down to ")#mi("0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490420")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Whoops, I meant half of that, ")#tao-math("\\left|\\left|xyx^{-1}y^{-1}\\right|\\right|\\leq \\tfrac{1}{4}(\\left|\\left|x^{-2}y^{-1}xy\\right|\\right| + \\left|\\left|x^2yx^{-1}y^{-1}\\right|\\right|)", block: false)#text(".")

#text("In terms of yesterday’s Proposition 1, this now genuinely improves upon (iii): If (2) holds for ")#mi("(\\gamma,\\delta)")#text(", then (1) holds for ")#mi("(\\tfrac{\\gamma}{2},\\tfrac{\\delta}{2})")#text(".")

#text("Since we (and especially me) have already made so many small mistakes that resulted in incorrect claims, I’d appreciate it if somebody else could double-check this.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490443")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I did double-check this part. It worked out the same for me.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99077de2ce4cd90a3bab5c7a180eb894bd6bb365e81afb59c315af204aca3bbb-36afb7bbf9d844f5451ab123fdd86fedf8736cf48b85879d1658adbe17de608a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of António Machiavelo")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490423")[#strong[#text("António Machiavelo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("As I have noted in a small note on the continuation of this post, ")#tao-math("\\left\\| x^2 y x^{-1} y^{-1}\\right\\|", block: false)#text(" is bounded from below by the max of the norms of ")#mi("x,y")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490495")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I think that you showed it is it is bounded below by ")#tao-math("\\left\\|x\\right\\|", block: false)#text(". (Your argument, and the quantity to be bounded, is not symmetric in arbitrary ")#mi("x,y")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99077de2ce4cd90a3bab5c7a180eb894bd6bb365e81afb59c315af204aca3bbb-36afb7bbf9d844f5451ab123fdd86fedf8736cf48b85879d1658adbe17de608a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of António Machiavelo")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490537")[#strong[#text("António Machiavelo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Yes, you are right, of course. I should have been more careful with this last post.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490405")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("I should clarify how the computer found these – I tried various constructions of norms, which were all obstructed by lack of linearity on elements ")#mi("(aba^{-1}b^{-1})^k a")#text(", so I explicitly looked at such elements. In particular the k=6 I had earlier found was useful.")

#text("The bound has improved since then (to about .75), but with longer proofs. The code is open sourced in the same repository where this proof is, i.e. at ")#link("https://github.com/siddhartha-gadgil/Superficial")[#text("https://github.com/siddhartha-gadgil/Superficial")]#text(", specifically the package ")#link("https://github.com/siddhartha-gadgil/Superficial/tree/master/src/main/scala/freegroups")[#text("https://github.com/siddhartha-gadgil/Superficial/tree/master/src/main/scala/freegroups")]#text(" but has to be run in a console.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490406")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("You can avoid ")#mi("k=6")#text(", and get the better bound ")#mi("8/11\\approx 0.72")#text(", using the recent idea of Tobias. Take the 11th power of ")#mi("aba^{-1}b^{-1}")#text(" and note this is a product of four equal length monomials, each conjugate to something that looks like ")#mi("(aba^{-1}b^{-1})^2a")#text(". By the work above, each is bounded in norm by 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490407")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Ah — ")#mi("[x,y]^kx")#text(" is the point. I was looking at ")#mi("x^k[x,y]")#text(" and this wasn’t fruitful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21d2707da5f09985358eb8d9c302f1f099e2ca4ce8effa2ed76480c2711d5684-c147da4c3cd11cda24572399ecabe150a6f0ba0fbf1d273701e5c3b08207f824.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siddhartha Gadgil")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490408")[#strong[#text("Siddhartha Gadgil")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Thanks. I did use ")#mi("k=1, 2, 6")#text(", but what I did not use was ")#mi("b^{-1}(aba^{-1}b^{-1}")#text(", which I should do. Another change I am making is taking the closure under various symmetries.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490434")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Using the inward-repetition technique on powers of the commutator ")#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490414")[#text("as above")]#text(", I can also show that ")#tao-math("(2k+2)\\left|\\left|[x,y]\\right|\\right|\\leq \\left|\\left|[x,y]^kx\\right|\\right| + \\left|\\left|x^{-1}[x^{-1},y^{-1}]^k\\right|\\right|", block: false)#text(" in pretty much the same way.")

#text("Applying this for ")#mi("k=2")#text(" together with ")#tao-math("\\left|\\left|[x,y]^2x\\right|\\right|\\leq 2", block: false)#text(", which seems to be the result from above, gives a new best bound of ")#tao-math("\\left|\\left|[x,y]\\right|\\right|\\leq\\tfrac{2}{3}", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490478")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Should that be ")#mi("2k+1")#text("? (I gather you’re using ")#mi("[x,y]^{2k+1} = [x,y]^k x ([x^{-1}, y^{-1}]^k x^{-1})^{y^{-1}})")#text("?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490483")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Thank you for checking! What I was using is the inward-repetition method which was ")#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490400")[#text("extracted")]#text(" by Pace from Siddhartha’s computer calculations. For large ")#mi("n")#text(", the power ")#mi("[x,y]^n")#text(" will consist of nestings of")

#mi("(([x^{-1},y^{-1}]^kx^{-1})^y\\ldots ([x,y]^kx)^{y^{-1}})^x")

#text("plus a bunch of boundary and centre terms that can be neglected in the limit ")#mi("n\\to\\infty")#text(". Here, ")#mi("k")#text(" is fixed as ")#mi("n")#text(" varies. It may help to write this out as")

#mi("xy[x^{-1},y^{-1}]^kx^{-1}y^{-1}\\ldots y^{-1}[x,y]^k xyx^{-1}")

#text("in order to see explicitly that each nesting comprises exactly ")#mi("2k+2")#text(" commutator terms. So it seems to me that the ")#mi("2k+2")#text(" is correct.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cbc2d27be35b52d76218f729437fb6f59d7159dd6ad519e6b5824e55164b893-b88a1ccc43798cb3a67a8dee5b4ebd33a294ad10b1c2db24678b09ee1cd9bfdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490481")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Or rather, I can see that ")#tao-math("\\left\\|[x,y]\\right\\|/4 \\leq \\left\\|[x,y]^k x \\right\\|/(4k+3)", block: false)#text(" (assuming wlog that the norm has some basic symmetry, so that we can write the RHS simply). The reason is that a large power of ")#mi("[x,y]")#text(" can be decomposed into a sequence of expressions of the form ")#mi("([x,y]^k x)^y")#text(" or ")#mi("([x^{-1}, y^{-1}]^k x^{-1})^{y^{-1}}")#text(" (plus as you say some small edge effects), and each such term contributes ")#mi("4k+3")#text(" letters without any cancellation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490484")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("Aha, that’s interesting, too! It’s slightly weaker and generalizes the bound that I ")#link("https://terrytao.wordpress.com/2017/12/19/bi-invariant-metrics-of-linear-growth-on-the-free-group-ii/#comment-490353")[#text("found")]#text(" yesterday to ")#mi("k>1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490491")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#emph[#text("[This was a response to a comment of myself that I had deleted. -T]")]

#text("You also have to repeat the outer conjugation by ")#mi("x")#text(" on the inside, since it’s intended to be part of the repeating pattern. Like that, one nesting of the pattern should correspond to the explicit words on the left and right that I had written down ")#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490414")[#text("here")]#text(".")

#text("Does this clear it up? At least this was the issue that had gotten me confused for a while as I was studying Pace’s considerations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Metrics of linear growth – the solution | What's new")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-490580")[#strong[#text("Metrics of linear growth – the solution | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2017")])]

#text("[…] the tradition of “Polymath projects”, the problem posed in the previous two blog posts has now been solved, thanks to the cumulative effect of many small contributions by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spontaneous Polymath 14 – A success! | The polymath blog")]], [#link("https://terrytao.wordpress.com/2017/12/16/bi-invariant-metrics-of-linear-growth-on-the-free-group/#comment-491783")[#strong[#text("Spontaneous Polymath 14 – A success! | The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("[…] project, now called polymath 14 that took place over Terry Tao’s blog. A problem was posed by Apoorva Khare was presented and discussed and openly and collectively solved. (And the […]")
]
