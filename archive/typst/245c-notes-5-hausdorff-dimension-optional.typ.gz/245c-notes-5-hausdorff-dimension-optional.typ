// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/
// Converted to Typst by tao2typ: "2026-10-14T07:22:02.631157+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245C, Notes 5: Hausdorff dimension (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245C, Notes 5: Hausdorff dimension (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 May 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/")[#text("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A fundamental characteristic of many mathematical spaces (e.g. vector spaces, metric spaces, topological spaces, etc.) is their ")#emph[#text("dimension")]#text(", which measures the “complexity” or “degrees of freedom” inherent in the space. There is no single notion of dimension; instead, there are a variety of different versions of this concept, with different versions being suitable for different classes of mathematical spaces. Typically, a single mathematical object may have several subtly different notions of dimension that one can place on it, which will be related to each other, and which will often agree with each other in “non-pathological” cases, but can also deviate from each other in many other situations. For instance:")

#list(
[#text("One can define the dimension of a space ")#mi("{X}")#text(" by seeing how it compares to some standard reference spaces, such as ")#mi("{{\\bf R}^n}")#text(" or ")#mi("{{\\bf C}^n}")#text("; one may view a space as having dimension ")#mi("{n}")#text(" if it can be (locally or globally) identified with a standard ")#mi("{n}")#text("-dimensional space. The dimension of a vector space or a manifold can be defined in this fashion.")],
[#text("Another way to define dimension of a space ")#mi("{X}")#text(" is as the largest number of “independent” objects one can place inside that space; this can be used to give an alternate notion of ")#link("http://en.wikipedia.org/wiki/Dimension_(vector_space)")[#text("dimension for a vector space")]#text(", or of ")#link("http://en.wikipedia.org/wiki/Dimension_of_an_algebraic_variety")[#text("an algebraic variety")]#text(", as well as the closely related notion of the ")#link("http://en.wikipedia.org/wiki/Transcendence_degree")[#text("transcendence degree")]#text(" of a field. The concept of ")#link("http://en.wikipedia.org/wiki/VC_dimension")[#text("VC dimension")]#text(" in machine learning also broadly falls into this category.")],
[#text("One can also try to define dimension inductively, for instance declaring a space ")#mi("{X}")#text(" to be ")#mi("{n}")#text("-dimensional if it can be “separated” somehow by an ")#mi("{n-1}")#text("-dimensional object; thus an ")#mi("{n}")#text("-dimensional object will tend to have “maximal chains” of sub-objects of length ")#mi("{n}")#text(" (or ")#mi("{n+1}")#text(", depending on how one initialises the chain and how one defines length). This can give a notion of ")#link("http://en.wikipedia.org/wiki/Inductive_dimension")[#text("dimension for a topological space")]#text(" or ")#link("http://en.wikipedia.org/wiki/Krull_dimension")[#text("a commutative ring")]#text(".")]
)

#text("The notions of dimension as defined above tend to necessarily take values in the natural numbers (or the cardinal numbers); there is no such space as ")#mi("{{\\bf R}^{\\sqrt{2}}}")#text(", for instance, nor can one talk about a basis consisting of ")#mi("{\\pi}")#text(" linearly independent elements, or a chain of maximal ideals of length ")#mi("{e}")#text(". There is however a somewhat different approach to the concept of dimension which makes no distinction between integer and non-integer dimensions, and is suitable for studying “rough” sets such as ")#link("http://en.wikipedia.org/wiki/Fractal")[#text("fractals")]#text(". The starting point is to observe that in the ")#mi("{d}")#text("-dimensional space ")#mi("{{\\bf R}^d}")#text(", the volume ")#mi("{V}")#text(" of a ball of radius ")#mi("{R}")#text(" grows like ")#mi("{R^d}")#text(", thus giving the following heuristic relationship ")#metadata(none) <tao-929f1ca4b2be58d78c26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{\\log V}{\\log R} \\approx d")]]

#text(" between volume, scale, and dimension. Formalising this heuristic leads to a number of useful notions of dimension for subsets of ")#mi("{{\\bf R}^n}")#text(" (or more generally, for metric spaces), including (upper and lower) ")#link("http://en.wikipedia.org/wiki/Minkowski-Bouligand_dimension")[#text("Minkowski dimension")]#text(" (also known as box-packing dimension or Minkowski-Bougliand dimension), and ")#link("http://en.wikipedia.org/wiki/Hausdorff_dimension")[#text("Hausdorff dimension")]#text(".")#linebreak()#text(" [In ")#link("http://en.wikipedia.org/wiki/K-theory")[#mi("{K}")#text("-theory")]#text(", it is also convenient to work with “virtual” vector spaces or vector bundles, such as formal differences of such spaces, and which may therefore have a negative dimension; but as far as I am aware there is no connection between this notion of dimension and the metric ones given here.]")#linebreak()#text(" Minkowski dimension can either be defined externally (relating the external volume of ")#mi("{\\delta}")#text("-neighbourhoods of a set ")#mi("{E}")#text(" to the scale ")#mi("{\\delta}")#text(") or internally (relating the internal ")#mi("{\\delta}")#text("-entropy of ")#mi("{E}")#text(" to the scale). Hausdorff dimension is defined internally by first introducing the ")#mi("{d}")#text("-dimensional ")#emph[#text("Hausdorff measure")]#text(" of a set ")#mi("{E}")#text(" for any parameter ")#mi("{0 \\leq d < \\infty}")#text(", which generalises the familiar notions of length, area, and volume to non-integer dimensions, or to rough sets, and is of interest in its own right. Hausdorff dimension has a lengthier definition than its Minkowski counterpart, but is more robust with respect to operations such as countable unions, and is generally accepted as the “standard” notion of dimension in metric spaces. We will compare these concepts against each other later in these notes.")#linebreak()#text(" One use of the notion of dimension is to create finer distinctions between various types of “small” subsets of spaces such as ")#mi("{{\\bf R}^n}")#text(", beyond what can be achieved by the usual Lebesgue measure (or Baire category). For instance, a point, line, and plane in ")#mi("{{\\bf R}^3}")#text(" all have zero measure with respect to three-dimensional Lebesgue measure (and are nowhere dense), but of course have different dimensions (")#mi("{0}")#text(", ")#mi("{1}")#text(", and ")#mi("{2}")#text(" respectively). (The Kakeya set conjecture, discussed recently on this blog, offers another good example.) This can be used to clarify the nature of various singularities, such as that arising from non-smooth solutions to PDE; a function which is non-smooth on a set of large Hausdorff dimension can be considered less smooth than one which is non-smooth on a set of small Hausdorff dimension, even if both are smooth almost everywhere. While many properties of the singular set of such a function are worth studying (e.g. their ")#link("http://en.wikipedia.org/wiki/Rectifiable_set")[#text("rectifiability")]#text("), understanding their dimension is often an important starting point. The interplay between these types of concepts is the subject of ")#link("http://en.wikipedia.org/wiki/Geometric_measure_theory")[#text("geometric measure theory")]#text(".")#linebreak()#text(" ")#metadata(none) <tao-9e44b55ea54ede3cdeaf>

#heading(level: 1)[#strong[#text(" — 1. Minkowski dimension — ")]]

#text("Before we study the more standard notion of Hausdorff dimension, we begin with the more elementary concept of the (upper and lower) Minkowski dimension of a subset ")#mi("{E}")#text(" of a Euclidean space ")#mi("{{\\bf R}^n}")#text(".")#linebreak()#text(" There are several equivalent ways to approach Minkowski dimension. We begin with an “external” approach, based on a study of the ")#mi("{\\delta}")#text("-neighbourhoods ")#mi("{E_\\delta := \\{ x \\in {\\bf R}^n: \\text{dist}(x,E) < \\delta \\}}")#text(" of ")#mi("{E}")#text(", where ")#tao-math("{\\text{dist}(x,E) := \\inf \\{ \\left|x-y\\right|: y \\in E \\}}", block: false)#text(" and we use the Euclidean metric on ")#mi("{{\\bf R}^n}")#text(". These are open sets in ")#mi("{{\\bf R}^n}")#text(" and therefore have a ")#mi("{n}")#text("-dimensional volume (or Lebesgue measure) ")#mi("{\\text{vol}^n(E_\\delta)}")#text(". To avoid divergences, let us assume for now that ")#mi("{E}")#text(" is bounded, so that the ")#mi("{E_\\delta}")#text(" have finite volume.")#linebreak()#text(" Let ")#mi("{0 \\leq d \\leq n}")#text(". Suppose ")#mi("{E}")#text(" is a bounded portion of a ")#mi("{d}")#text("-dimensional subspace, e.g. ")#mi("{E = B^d(0,1) \\times \\{0\\}^{n-d}}")#text(", where ")#mi("{B^d(0,1) \\subset {\\bf R}^d}")#text(" is the unit ball in ")#mi("{{\\bf R}^d}")#text(" and we identify ")#mi("{{\\bf R}^n}")#text(" with ")#mi("{{\\bf R}^d \\times {\\bf R}^{n-d}}")#text(" in the usual manner. Then we see from the triangle inequality that")

#align(center)[#tao-fit-display[#mitex("B^d(0,1) \\times B^{n-d}(0,\\delta) \\subset E_\\delta \\subset B^d(0,2) \\times B^{n-d}(0,\\delta)")]]

#text("for all ")#mi("{0 < \\delta < 1}")#text(", which implies that")

#align(center)[#tao-fit-display[#mitex("c \\delta^{n-d} \\leq \\text{vol}^n( E_\\delta ) \\leq C \\delta^{n-d}")]]

#text("for some constants ")#mi("{c, C> 0}")#text(" depending only on ")#mi("{n, d}")#text(". In particular, we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\delta \\rightarrow 0} n - \\frac{ \\log \\text{vol}^n( E_\\delta ) }{ \\log \\delta } = d")]]

#text("(compare with ")#link(<tao-929f1ca4b2be58d78c26>)[#text("(1)")]#text("). This motivates our first definition of Minkowski dimension:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" Let ")#mi("{E}")#text(" be a bounded subset of ")#mi("{{\\bf R}^n}")#text(". The ")#emph[#text("upper Minkowski dimension")]#text(" ")#mi("{\\overline{\\text{dim}}_M(E)}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("\\overline{\\text{dim}}_M(E) := \\limsup_{\\delta \\rightarrow 0} n - \\frac{ \\log \\text{vol}^n( E_\\delta ) }{ \\log \\delta }")]]

#text("and the ")#emph[#text("lower Minkowski dimension")]#text(" ")#mi("{\\underline{\\text{dim}}_M(E)}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("\\underline{\\text{dim}}_M(E) := \\liminf_{\\delta \\rightarrow 0} n - \\frac{ \\log \\text{vol}^n( E_\\delta ) }{ \\log \\delta }.")]]

#text("If the upper and lower Minkowski dimensions match, we refer to ")#mi("{\\text{dim}_M(E) := \\overline{\\text{dim}}_M(E) = \\underline{\\text{dim}}_M(E)}")#text(" as the Minkowski dimension of ")#mi("{E}")#text(". In particular, the empty set has a Minkowski dimension of ")#mi("{-\\infty}")#text(".")
]

#text("Unwrapping all the definitions, we have the following equivalent formulation, where ")#mi("{E}")#text(" is a bounded subset of ")#mi("{{\\bf R}^n}")#text(" and ")#mi("{\\alpha \\in {\\bf R}}")#text(":")

#list(
[#text("We have ")#mi("{\\overline{\\text{dim}}_M(E) < \\alpha}")#text(" iff for every ")#mi("{\\varepsilon > 0}")#text(", one has ")#mi("{\\text{vol}^n(E_\\delta) \\leq C \\delta^{n-\\alpha-\\varepsilon}}")#text(" for ")#emph[#text("all sufficiently small")]#text(" ")#mi("{\\delta > 0}")#text(" and some ")#mi("{C > 0}")#text(".")],
[#text("We have ")#mi("{\\underline{\\text{dim}}_M(E) < \\alpha}")#text(" iff for every ")#mi("{\\varepsilon > 0}")#text(", one has ")#mi("{\\text{vol}^n(E_\\delta) \\leq C \\delta^{n-\\alpha-\\varepsilon}}")#text(" for ")#emph[#text("arbitrarily small")]#text(" ")#mi("{\\delta > 0}")#text(" and some ")#mi("{C > 0}")#text(".")],
[#text("We have ")#mi("{\\overline{\\text{dim}}_M(E) > \\alpha}")#text(" iff for every ")#mi("{\\varepsilon > 0}")#text(", one has ")#mi("{\\text{vol}^n(E_\\delta) \\geq c \\delta^{n-\\alpha-\\varepsilon}}")#text(" for ")#emph[#text("arbitrarily small")]#text(" ")#mi("{\\delta > 0}")#text(" and some ")#mi("{c > 0}")#text(".")],
[#text("We have ")#mi("{\\overline{\\text{dim}}_M(E) > \\alpha}")#text(" iff for every ")#mi("{\\varepsilon > 0}")#text(", one has ")#mi("{\\text{vol}^n(E_\\delta) \\geq c \\delta^{n-\\alpha-\\varepsilon}}")#text(" for ")#emph[#text("all sufficiently small")]#text(" ")#mi("{\\delta > 0}")#text(" and some ")#mi("{c > 0}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-efc6fcebaf3b710b5650>

#list(
[#text("(i) Let ")#mi("{C \\subset {\\bf R}}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Cantor_set")[#text("Cantor set")]#text(" consisting of all base ")#mi("{4}")#text(" strings ")#mi("{\\sum_{i=1}^\\infty a_i 4^{-i}}")#text(", where each ")#mi("{a_i}")#text(" takes values in ")#mi("{\\{0,3\\}}")#text(". Show that ")#mi("{C}")#text(" has Minkowski dimension ")#mi("{1/2}")#text(". (Hint: approximate any small ")#mi("{\\delta}")#text(" by a negative power of ")#mi("{4}")#text(".)")],
[#text("(ii) Let ")#mi("{C^{\\prime} \\subset {\\bf R}}")#text(" be the Cantor set consisting of all base ")#mi("{4}")#text(" strings ")#mi("{\\sum_{i=1}^\\infty a_i 4^{-i}}")#text(", where each ")#mi("{a_i}")#text(" takes values in ")#mi("{\\{0,3\\}}")#text(" when ")#mi("{(2k)! \\leq i < (2k+1)!}")#text(" for some integer ")#mi("{k \\geq 0}")#text(", and ")#mi("{a_i}")#text(" is arbitrary for the other values of ")#mi("{i}")#text(". Show that ")#mi("{C^{\\prime}}")#text(" has a lower Minkowski dimension of ")#mi("{1/2}")#text(" and an upper Minkowski dimension of ")#mi("{1}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-f5ff23dae9de2b27673f>#text(" Suppose that ")#mi("{E \\subset {\\bf R}^n}")#text(" is a compact set with the property that there exist ")#mi("{0 < r < 1}")#text(" and an integer ")#mi("{k > 1}")#text(" such that ")#mi("{E}")#text(" is equal to the union of ")#mi("{k}")#text(" disjoint translates of ")#mi("{r \\cdot E := \\{ rx: x \\in E \\}}")#text(". (This is a special case of a ")#link("http://en.wikipedia.org/wiki/Fractal")[#text("self-similar fractal")]#text("; the ")#link("http://en.wikipedia.org/wiki/Cantor_set")[#text("Cantor set")]#text(" is a typical example.) Show that ")#mi("{E}")#text(" has Minkowski dimension ")#mi("{\\frac{\\log k}{\\log 1/r}}")#text(".")#linebreak()#text(" If the ")#mi("{k}")#text(" translates of ")#mi("{r \\cdot E}")#text(" are allowed to overlap, establish the upper bound ")#mi("{\\overline{\\text{dim}}_M(E) \\leq \\frac{\\log k}{\\log 1/r}}")#text(".")
]

#text("It is clear that we have the inequalities")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\underline{\\text{dim}}_M(E) \\leq \\overline{\\text{dim}}_M(E) \\leq n")]]

#text("for non-empty bounded ")#mi("{E \\subset {\\bf R}^n}")#text(", and the monotonicity properties")

#align(center)[#tao-fit-display[#mitex("\\underline{\\text{dim}}_M(E) \\leq \\underline{\\text{dim}}_M(F); \\quad \\overline{\\text{dim}}_M(E) \\leq \\overline{\\text{dim}}_M(F)")]]

#text("whenever ")#mi("{E \\subset F \\subset {\\bf R}^n}")#text(" are bounded sets. It is thus natural to extend the definitions of lower and upper Minkowski dimension to unbounded sets ")#mi("{E}")#text(" by defining ")#metadata(none) <tao-de0a863ec57b57a0541d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\underline{\\text{dim}}_M(E) := \\sup_{F \\subset E, \\text{ bounded}} \\underline{\\text{dim}}_M(F)")]]

#text(" and ")#metadata(none) <tao-457e6effbd1763c267e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\overline{\\text{dim}}_M(E) := \\sup_{F \\subset E, \\text{ bounded}} \\overline{\\text{dim}}_M(F).")]]

#text(" In particular, we easily verify that ")#mi("{d}")#text("-dimensional subspaces of ")#mi("{{\\bf R}^n}")#text(" have Minkowski dimension ")#mi("{d}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Show that any subset of ")#mi("{{\\bf R}^n}")#text(" with lower Minkowski dimension less than ")#mi("{n}")#text(" has Lebesgue measure zero. In particular, any subset ")#mi("{E \\subset {\\bf R}^n}")#text(" of positive Lebesgue measure must have full Minkowski dimension ")#mi("{\\text{dim}_M(E) = n}")#text(".")
]

#text("Now we turn to other formulations of Minkowski dimension. Given a bounded set ")#mi("{E}")#text(" and ")#mi("{\\delta > 0}")#text(", we make the following definitions:")

#list(
[#mi("{{\\mathcal N}_\\delta^{\\text{ext}}(E)}")#text(" (the ")#emph[#text("external ")#mi("{\\delta}")#text("-covering number")]#text(" of ")#mi("{E}")#text(") is the fewest number of open balls of radius ")#mi("{\\delta}")#text(" with centres in ")#mi("{{\\bf R}^n}")#text(" needed to cover ")#mi("{E}")#text(".")],
[#mi("{{\\mathcal N}_\\delta^{\\text{int}}(E)}")#text(" (the ")#emph[#text("internal ")#mi("{\\delta}")#text("-covering number")]#text(" of ")#mi("{E}")#text(") is the fewest number of open balls of radius ")#mi("{\\delta}")#text(" with centres in ")#mi("{E}")#text(" needed to cover ")#mi("{E}")#text(".")],
[#mi("{{\\mathcal N}_\\delta^{\\text{net}}(E)}")#text(" (the ")#emph[#mi("{\\delta}")#text("-metric entropy")]#text(") is the cardinality of the largest ")#mi("{\\delta}")#text("-net in ")#mi("{E}")#text(", i.e. the largest set ")#mi("{x_1,\\ldots,x_k}")#text(" in ")#mi("{E}")#text(" such that ")#tao-math("{\\left|x_i-x_j\\right| \\geq \\delta}", block: false)#text(" for every ")#mi("{1 \\leq i < j \\leq k}")#text(".")],
[#mi("{{\\mathcal N}_\\delta^{\\text{pack}}(E)}")#text(" (the ")#emph[#mi("{\\delta}")#text("-packing number")]#text(" of ")#mi("{E}")#text(") is the largest number of disjoint open balls one can find of radius ")#mi("{\\delta}")#text(" with centres in ")#mi("{E}")#text(".")]
)

#text("These three quantities are closely related to each other, and to the volumes ")#mi("{\\text{vol}^n( E_\\delta )}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-b9f96d32df991613b151>#text(" For any bounded set ")#mi("{E \\subset {\\bf R}^n}")#text(" and any ")#mi("{\\delta > 0}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal N}_{2\\delta}^{\\text{net}}(E) = {\\mathcal N}_\\delta^{\\text{pack}}(E) \\leq \\frac{\\text{vol}^n( E_\\delta )}{\\text{vol}^n(B^n(0,\\delta))} \\leq 2^n {\\mathcal N}_\\delta^{\\text{ext}}(E)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\mathcal N}_\\delta^{\\text{ext}}(E) \\leq {\\mathcal N}_\\delta^{\\text{int}}(E) \\leq {\\mathcal N}_\\delta^{\\text{net}}(E).")]]
]

#text("As a consequence of this exercise, we see that ")#metadata(none) <tao-e0a00515b1b43adac3eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\overline{\\text{dim}}_M(E) = \\limsup_{\\delta \\rightarrow 0} \\frac{ \\log {\\mathcal N}_\\delta^*(E) }{ \\log {1/\\delta} }")]]

#text(" and ")#metadata(none) <tao-ecda9209e92eb382c2ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\underline{\\text{dim}}_M(E) = \\liminf_{\\delta \\rightarrow 0} \\frac{ \\log {\\mathcal N}_\\delta^*(E) }{ \\log {1/\\delta} }.")]]

#text(" where ")#mi("{*}")#text(" is any of ")#mi("{\\text{ext}, \\text{int}, \\text{net}, \\text{pack}}")#text(".")#linebreak()#text(" One can now take the formulae ")#link(<tao-e0a00515b1b43adac3eb>)[#text("(4)")]#text(", ")#link(<tao-ecda9209e92eb382c2ba>)[#text("(5)")]#text(" as the ")#emph[#text("definition")]#text(" of Minkowski dimension for bounded sets (and then use ")#link(<tao-de0a863ec57b57a0541d>)[#text("(2)")]#text(", ")#link(<tao-457e6effbd1763c267e5>)[#text("(3)")]#text(" to extend to unbounded sets). The formulations ")#link(<tao-e0a00515b1b43adac3eb>)[#text("(4)")]#text(", ")#link(<tao-ecda9209e92eb382c2ba>)[#text("(5)")]#text(" for ")#mi("{* = \\text{int}, \\text{net}, \\text{pack}}")#text(" have the advantage of being ")#emph[#text("intrinsic")]#text(" – they only involve ")#mi("{E}")#text(", rather than the ambient space ")#mi("{{\\bf R}^n}")#text(". For metric spaces, one still has a partial analogue of Exercise ")#link(<tao-b9f96d32df991613b151>)[#text("5")]#text(", namely")

#align(center)[#tao-fit-display[#mitex("{\\mathcal N}_{2\\delta}^{\\text{net}}(E) \\leq {\\mathcal N}_\\delta^{\\text{pack}}(E) \\leq {\\mathcal N}_\\delta^{\\text{int}}(E) \\leq {\\mathcal N}_\\delta^{\\text{net}}(E).")]]

#text("As such, these formulations of Minkowski dimension extend without any difficulty to arbitrary bounded metric spaces ")#mi("{(E,d)}")#text(" (at least when the spaces are locally compact), and then to unbounded metric spaces by ")#link(<tao-de0a863ec57b57a0541d>)[#text("(2)")]#text(", ")#link(<tao-457e6effbd1763c267e5>)[#text("(3)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" If ")#mi("{\\phi: (X,d_X) \\rightarrow (Y,d_Y)}")#text(" is a Lipschitz map between metric spaces, show that ")#mi("{\\overline{\\text{dim}}_M(\\phi(E)) \\leq \\overline{\\text{dim}}_M(E)}")#text(" and ")#mi("{\\underline{\\text{dim}}_M(\\phi(E)) \\leq \\underline{\\text{dim}}_M(E)}")#text(" for all ")#mi("{E \\subset X}")#text(". Conclude in particular that the graph ")#mi("{\\{ (x,\\phi(x)): x \\in {\\bf R}^d \\}}")#text(" of any Lipschitz function ")#mi("{\\phi: {\\bf R}^d \\rightarrow {\\bf R}^{n-d}}")#text(" has Minkowski dimension ")#mi("{d}")#text(", and the graph of any measurable function ")#mi("{\\phi: {\\bf R}^d \\rightarrow {\\bf R}^{n-d}}")#text(" has Minkowski dimension at least ")#mi("{d}")#text(".")
]

#text("Note however that the dimension of graphs can become larger than that of the base in the non-Lipschitz case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-e10a29bd64976f51f739>#text(" Show that the graph ")#mi("{\\{ (x,\\sin\\frac{1}{x}): 0 < x < 1 \\}}")#text(" has Minkowski dimension ")#mi("{3/2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{(X,d)}")#text(" be a bounded metric space. For each ")#mi("{n \\geq 0}")#text(", let ")#mi("{E_n}")#text(" be a maximal ")#mi("{2^{-n}}")#text("-net of ")#mi("{X}")#text(" (thus the cardinality of ")#mi("{E_n}")#text(" is ")#mi("{{\\mathcal N}_{2^{-n}}^{net}(X)}")#text("). Show that for any continuous function ")#mi("{f: X \\rightarrow {\\bf R}}")#text(", one has the inequality")

#tao-aligned(keep: true)[


#tao-math("\\sup_{x \\in X} f(x)  & \\leq \\sup_{x_0 \\in E_0} f(x_0) +", block: true)



#tao-math(" & + \\sum_{n=0}^\\infty \\sup_{x_n \\in E_n, x_{n+1} \\in E_{n+1}: \\left|x_n-x_{n+1}\\right| \\leq \\frac{3}{2} 2^{-n}} (f(x_n)-f(x_{n+1})).", block: true)
]

#text("(")#emph[#text("Hint:")]#text(" For any ")#mi("{x \\in X}")#text(", define ")#mi("{x_n \\in E_n}")#text(" to be the nearest point in ")#mi("{E_n}")#text(" to ")#mi("{x}")#text(", and use a telescoping series.) This inequality (and variants thereof), which replaces a continuous supremum of a function ")#mi("{f(x)}")#text(" by a sum of discrete suprema of differences ")#mi("{f(x_n)-f(x_{n+1})}")#text(" of that function, is the basis of the ")#emph[#text("generic chaining")]#text(" technique in probability, used to estimate the supremum of a continuous family of random processes. It is particularly effective when combined with bounds on the metric entropy ")#mi("{{\\mathcal N}_{2^{-n}}^{net}(X)}")#text(", which of course is closely related to the Minkowski dimension of ")#mi("{X}")#text(", and with ")#emph[#text("large deviation")]#text(" bounds on the differences ")#mi("{f(x_n)-f(x_{n+1})}")#text(". A good reference for generic chaining is the ")#link("http://www.ams.org/mathscinet-getitem?mr=2133757")[#text("text by Talagrand")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" If ")#mi("{E \\subset {\\bf R}^n}")#text(" and ")#mi("{F \\subset {\\bf R}^m}")#text(" are bounded sets, show that")

#align(center)[#tao-fit-display[#mitex("\\underline{\\text{dim}}_M(E) + \\underline{\\text{dim}}_M(F) \\leq \\underline{\\text{dim}}_M(E \\times F)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\overline{\\text{dim}}_M(E \\times F) \\leq \\overline{\\text{dim}}_M(E) + \\overline{\\text{dim}}_M(F).")]]

#text("Give a counterexample that shows that either of the inequalities here can be strict. (")#emph[#text("Hint:")]#text(" There are many possible constructions; one of them is a modification of Exercise ")#link(<tao-efc6fcebaf3b710b5650>)[#text("2")]#text("(ii).)")
]

#text("It is easy to see that Minkowski dimension reacts well to finite unions, and more precisely that")

#align(center)[#tao-fit-display[#mitex("\\overline{\\text{dim}}_M(E \\cup F) = \\max( \\overline{\\text{dim}}_M(E), \\overline{\\text{dim}}_M(F) )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\underline{\\text{dim}}_M(E \\cup F) = \\max( \\underline{\\text{dim}}_M(E), \\underline{\\text{dim}}_M(F) )")]]

#text("for any ")#mi("{E, F \\subset {\\bf R}^n}")#text(". However, it does not respect countable unions. For instance, the rationals ")#mi("{{\\bf Q}}")#text(" have Minkowski dimension ")#mi("{1}")#text(", despite being the countable union of points, which of course have Minkowski dimension ")#mi("{0}")#text(". More generally, it is not difficult to see that any set ")#mi("{E \\subset {\\bf R}^n}")#text(" has the same upper or lower Minkowski dimension as its topological closure ")#mi("{\\overline{E}}")#text(", since both sets have the same ")#mi("{\\delta}")#text("-neighbourhoods. Thus we see that the notion of Minkowski dimension misses some of the fine structure of a set ")#mi("{E}")#text(", in particular the presence of “holes” within the set. We now turn to the notion of Hausdorff dimension, which rectifies some of these defects.")

#heading(level: 1)[#strong[#text(" — 2. Hausdorff measure — ")]]

#text("The Hausdorff approach to dimension begins by noting that ")#mi("{d}")#text("-dimensional objects in ")#mi("{{\\bf R}^n}")#text(" tend to have a meaningful ")#mi("{d}")#text("-dimensional measure to assign to them. For instance, the ")#mi("{1}")#text("-dimensional boundary of a polygon has a perimeter, the ")#mi("{0}")#text("-dimensional vertices of that polygon have a cardinality, and the polygon itself has an area. So to define the notion of a ")#mi("{d}")#text("-Hausdorff dimensional set, we will first define the notion of the ")#mi("{d}")#text("-dimensional Hausdorff measure ")#mi("{{\\mathcal H}^d(E)}")#text(" of a set ")#mi("{E}")#text(".")#linebreak()#text(" To do this, let us quickly review one of the (many) constructions of ")#mi("{n}")#text("-dimensional Lebesgue measure, which we are denoting here by ")#mi("{\\text{vol}^n}")#text(". One way to build this measure is to work with half-open boxes ")#mi("{B = \\prod_{i=1}^n [a_i,b_i)}")#text(" in ")#mi("{{\\bf R}^n}")#text(", which we assign a volume of ")#tao-math("{\\left|B\\right| := \\prod_{i=1}^n (b_i - a_i)}", block: false)#text(". Given this notion of volume for boxes, we can then define the ")#emph[#text("outer Lebesgue measure")]#text(" ")#mi("{(\\text{vol}^n)^*(E)}")#text(" of any set ")#mi("{E \\subset {\\bf R}^n}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("(\\text{vol}^n)^*(E) := \\inf \\{ \\sum_{k=1}^\\infty \\left|B_k\\right|: B_k \\text{ covers } E \\}", block: true)]]

#text("where the infimum ranges over all at most countable collections ")#mi("{B_1,B_2,\\ldots}")#text(" of boxes that cover ")#mi("{E}")#text(". One easily verifies that ")#mi("{(\\text{vol}^n)^*}")#text(" is indeed an outer measure (i.e. it is monotone, countably subadditive, and assigns zero to the empty set). We then define a set ")#mi("{A \\subset {\\bf R}^n}")#text(" to be ")#emph[#mi("{(\\text{vol}^n)^*}")#text("-measurable")]#text(" if one has the additivity property")

#align(center)[#tao-fit-display[#mitex("(\\text{vol}^n)^*(E) = (\\text{vol}^n)^*(E \\cap A) + (\\text{vol}^n)^*(E \\backslash A)")]]

#text("for all ")#mi("{E \\subset {\\bf R}^n}")#text(". By ")#link("http://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_theorem_(measure_theory)")[#text("Carathéodory’s theorem")]#text(", the space of ")#mi("{(\\text{vol}^n)^*}")#text("-measurable sets is a ")#mi("{\\sigma}")#text("-algebra, and outer Lebesgue measure is a countably additive measure on this ")#mi("{\\sigma}")#text("-algebra, which we denote ")#mi("{\\text{vol}^n}")#text(". Furthermore, one easily verifies that every box ")#mi("{B}")#text(" is ")#mi("{(\\text{vol}^n)^*}")#text("-measurable, which soon implies that every Borel set is also; thus Lebesgue measure is a Borel measure (though it can of course measure some non-Borel sets also).")#linebreak()#text(" Finally, one needs to verify that the Lebesgue measure ")#mi("{\\text{vol}^n(B)}")#text(" of a box is equal to its classical volume ")#tao-math("{\\left|B\\right|}", block: false)#text("; the above construction trivially gives ")#tao-math("{\\text{vol}^n(B) \\leq \\left|B\\right|}", block: false)#text(" but the converse is not as obvious. This is in fact a rather delicate matter, relying in particular on the completeness of the reals; if one replaced ")#mi("{{\\bf R}}")#text(" by the rationals ")#mi("{{\\bf Q}}")#text(", for instance, then all the above constructions go through but now boxes have Lebesgue measure zero (why?). See Chapter 1 of Folland’s book, for instance, for details.")#linebreak()#text(" Anyway, we can use this construction of Lebesgue measure as a model for building ")#mi("{d}")#text("-dimensional Hausdorff measure. Instead of using half-open boxes as the building blocks, we will instead work with the open balls ")#mi("{B(x,r)}")#text(". For ")#mi("{d}")#text("-dimensional measure, we will assign each ball ")#mi("{B(x,r)}")#text(" a measure ")#mi("{r^d}")#text(" (cf. ")#link(<tao-929f1ca4b2be58d78c26>)[#text("(1)")]#text("). We can then define the ")#emph[#text("unlimited Hausdorff content")]#text(" ")#mi("{h_{d,\\infty}(E)}")#text(" of a set ")#mi("{E \\subset {\\bf R}^n}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("h_{d,\\infty}(E) := \\inf \\{ \\sum_{k=1}^\\infty r_k^d: B(x_k,r_k) \\text{ covers } E \\}")]]

#text("where the infimum ranges over all at most countable families of balls that cover ")#mi("{E}")#text(". (Note that if ")#mi("{E}")#text(" is compact, then it would suffice to use finite coverings, since every open cover of ")#mi("{E}")#text(" has a finite subcover. But in general, for non-compact ")#mi("{E}")#text(" we must allow the use of infinitely many balls.)")#linebreak()#text(" As with Lebesgue measure, ")#mi("{h_{d,\\infty}}")#text(" is easily seen to be an outer measure, and one could define the notion of a ")#mi("{h_{d,\\infty}}")#text("-measurable set on which Carathéodory’s theorem applies to build a countably additive measre. Unfortunately, a key problem arises: once ")#mi("{d}")#text(" is less than ")#mi("{n}")#text(", most sets cease to be ")#mi("{h_{d,\\infty}}")#text("-measurable! We illustrate this in the one-dimensional case with ")#mi("{n=1}")#text(" and ")#mi("{d=1/2}")#text(", and consider the problem of computing the unlimited Hausdorff content ")#mi("{h_{1/2,\\infty}([a,b])}")#text(". On the one hand, this content is at most ")#tao-math("{\\left|\\frac{b-a}{2}\\right|^{1/2}}", block: false)#text(", since one can cover ")#mi("{[a,b]}")#text(" by the ball of radius ")#mi("{\\frac{b-a}{2}+\\varepsilon}")#text(" centred at ")#mi("{\\frac{a+b}{2}}")#text(" for any ")#mi("{\\varepsilon > 0}")#text(". On the other hand, the content is also at ")#emph[#text("least")]#text(" ")#tao-math("{\\left|\\frac{b-a}{2}\\right|^{1/2}}", block: false)#text(". To see this, suppose we cover ")#mi("{[a,b]}")#text(" by a finite or countable family of balls ")#mi("{B(x_k,r_k)}")#text(" (one can reduce to the finite case by compactness, though it isn’t necessary to do so here). The total one-dimensional Lebesgue measure ")#mi("{\\sum_k 2r_k}")#text(" of these balls must equal or exceed the Lebesgue measure of the entire interval ")#tao-math("{\\left|b-a\\right|}", block: false)#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\sum_k r_k \\geq \\frac{\\left|b-a\\right|}{2}.", block: true)]]

#text("From the inequality ")#mi("{\\sum_k r_k \\leq (\\sum_k r_k^{1/2})^2}")#text(" (which is obvious after expanding the RHS and discarding cross-terms) we see that")

#align(center)[#tao-fit-display[#tao-math("\\sum_k r_k^{1/2} \\geq (\\frac{\\left|b-a\\right|}{2})^{1/2}", block: true)]]

#text("and the claim follows.")#linebreak()#text(" We now see some serious breakdown of additivity: for instance, the unlimited ")#mi("{1/2}")#text("-dimensional content of ")#mi("{[0,2]}")#text(" is ")#mi("{1}")#text(", despite being the disjoint union of ")#mi("{[0,1]}")#text(" and ")#mi("{(1,2]}")#text(", which each have an unlimited content of ")#mi("{1/\\sqrt{2}}")#text(". In particular, this shows that ")#mi("{[0,1]}")#text(" (for instance) is not measurable with respect to the unlimited content. The basic problem here is that the most efficient cover of a union such as ")#mi("{[0,1] \\cup (1,2]}")#text(" for the purposes of unlimited ")#mi("{1/2}")#text("-dimensional content is not coming from covers of the separate components ")#mi("{[0,1]}")#text(" and ")#mi("{(1,2]}")#text(" of that union, but is instead coming from one giant ball that covers ")#mi("{[0,2]}")#text(" directly.")#linebreak()#text(" To fix this, we will ")#emph[#text("limit")]#text(" the Hausdorff content by working only with small balls. More precisely, for any ")#mi("{r > 0}")#text(", we define the Hausdorff content ")#mi("{h_{d,r}(E)}")#text(" of a set ")#mi("{E \\subset {\\bf R}^n}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("h_{d,r}(E) := \\inf \\{ \\sum_{k=1}^\\infty r_k^d: B(x_k,r_k) \\text{ covers } E; r_k \\leq r \\}")]]

#text("where the balls ")#mi("{B(x_k,r_k)}")#text(" are now restricted to be less than or equal to ")#mi("{r}")#text(" in radius. This quantity is decreasing in ")#mi("{r}")#text(", and we then define the ")#emph[#text("Hausdorff outer measure")]#text(" ")#mi("{({\\mathcal H}^d)^*(E)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("({\\mathcal H}^d)^*(E) := \\lim_{r \\rightarrow 0} h_{d,r}(E).")]]

#text("(This is analogous to the Riemann integral approach to volume of sets, covering them by balls, boxes, or rectangles of increasingly small size; this latter approach is also closely connected to the Minkowski dimension concept studied earlier. The key difference between the Lebesgue/Hausdorff approach and the Riemann/Minkowski approach is that in the former approach one allows the balls or boxes to be countable in number, and to be variable in size, whereas in the latter approach the cover is finite and uniform in size.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Show that if ")#mi("{d > n}")#text(", then ")#mi("{({\\mathcal H}^d)^*(E) = 0}")#text(" for all ")#mi("{E \\subset {\\bf R}^n}")#text(". Thus ")#mi("{d}")#text("-dimensional Hausdorff measure is only a non-trivial concept for subsets of ")#mi("{{\\bf R}^n}")#text(" in the regime ")#mi("{0 \\leq d \\leq n}")#text(".")
]

#text("Since each of the ")#mi("{h_{d,r}}")#text(" are outer measures, ")#mi("{({\\mathcal H}^d)^*}")#text(" is also. But the key advantage of moving to the Hausdorff measure rather than Hausdorff content is that we obtain a lot more additivity. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-706a30129a591c339036>#text(" Let ")#mi("{E, F}")#text(" be subsets of ")#mi("{{\\bf R}^n}")#text(" which have a non-zero separation, i.e. the quantity ")#tao-math("{\\text{dist}(E,F) = \\inf \\{ \\left|x-y\\right|: x \\in E, y \\in F \\}}", block: false)#text(" is strictly positive. Show that ")#mi("{({\\mathcal H}^d)^*(E \\cup F) = ({\\mathcal H}^d)^*(E) + ({\\mathcal H}^d)^*(F)}")#text(". (")#emph[#text("Hint:")]#text(" one inequality is easy. For the other, observe that any small ball can intersect ")#mi("{E}")#text(" or intersect ")#mi("{F}")#text(", but not both.)")
]

#text("One consequence of this is that there is a large class of measurable sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" Let ")#mi("{d \\geq 0}")#text(". Then every Borel subset of ")#mi("{{\\bf R}^n}")#text(" is ")#mi("{({\\mathcal H}^d)^*}")#text("-measurable.")
]

#emph[#text("Proof:")]#text(" Since the collection of ")#mi("{({\\mathcal H}^d)^*}")#text("-measurable sets is a ")#mi("{\\sigma}")#text("-algebra, it suffices to show the claim for closed sets ")#mi("{A}")#text(". (It will be slightly more convenient technically to work with closed sets rather than open ones here.) Thus, we take an arbitrary set ")#mi("{E \\subset {\\bf R}^n}")#text(" and seek to show that")

#align(center)[#tao-fit-display[#mitex("({\\mathcal H}^d)^*(E) = ({\\mathcal H}^d)^*(E \\cap A) + ({\\mathcal H}^d)^*(E \\backslash A).")]]

#text("We may assume that ")#mi("{({\\mathcal H}^d)^*(E \\cap A)}")#text(" and ")#mi("{({\\mathcal H}^d)^*(E \\backslash A)}")#text(" are both finite, since the claim is obvious otherwise from monotonicity.")#linebreak()#text(" From Exercise ")#link(<tao-706a30129a591c339036>)[#text("11")]#text(" and the fact that ")#mi("{({\\mathcal H}^d)^*}")#text(" is an outer measure, we already have")

#align(center)[#tao-fit-display[#mitex("({\\mathcal H}^d)^*(E \\cap A) + ({\\mathcal H}^d)^*(E \\backslash A_{1/m}) \\leq ({\\mathcal H}^d)^*(E) \\leq ({\\mathcal H}^d)^*(E \\cap A) + ({\\mathcal H}^d)^*(E \\backslash A),")]]

#text("where ")#mi("{A_{1/m}}")#text(" is the ")#mi("{1/m}")#text("-neighbourhood of ")#mi("{A}")#text(". So it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\lim_{m \\rightarrow \\infty} ({\\mathcal H}^d)^*(E \\backslash A_{1/m}) = ({\\mathcal H}^d)^*(E \\backslash A).")]]

#text("For any ")#mi("{m}")#text(", we have the telescoping sum ")#mi("{E \\backslash A = (E \\backslash A_{1/m}) \\cup \\bigcup_{l > m} F_l}")#text(", where ")#mi("{F_l := (E \\backslash A_{1/(l+1)}) \\cap A_l}")#text(", and thus by countable subadditivity and monotonicity")

#align(center)[#tao-fit-display[#mitex("({\\mathcal H}^d)^*(E \\backslash A_{1/m}) \\leq ({\\mathcal H}^d)^*(E \\backslash A) \\leq ({\\mathcal H}^d)^*(E \\backslash A_{1/m}) + \\sum_{l>m} ({\\mathcal H}^d)^*(F_l)")]]

#text("so it suffices to show that the sum ")#mi("{\\sum_{l=1}^\\infty ({\\mathcal H}^d)^*(F_l)}")#text(" is absolutely convergent.")#linebreak()#text(" Consider the even-indexed sets ")#mi("{F_2, F_4, F_6, \\ldots}")#text(". These sets are separated from each other, so by many applications of Exercise ")#link(<tao-706a30129a591c339036>)[#text("11")]#text(" followed by monotonicity we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{l=1}^L ({\\mathcal H}^d)^*(F_{2l}) = ({\\mathcal H}^d)^*(\\bigcup_{l=1}^L F_{2l}) \\leq ({\\mathcal H}^d)^*(E \\backslash A) < \\infty")]]

#text("for all ")#mi("{L}")#text(", and thus ")#mi("{\\sum_{l=1}^\\infty ({\\mathcal H}^d)^*(F_{2l})}")#text(" is absolutely convergent. Similarly for ")#mi("{\\sum_{l=1}^\\infty ({\\mathcal H}^d)^*(F_{2l-1})}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" On the ")#mi("{({\\mathcal H}^d)^*}")#text("-measurable sets ")#mi("{E}")#text(", we write ")#mi("{{\\mathcal H}^d(E)}")#text(" for ")#mi("{({\\mathcal H}^d)^*(E)}")#text(", thus ")#mi("{{\\mathcal H}^d}")#text(" is a Borel measure on ")#mi("{{\\bf R}^n}")#text(". We now study what this measure looks like for various values of ")#mi("{d}")#text(". The case ")#mi("{d=0}")#text(" is easy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" ")#metadata(none) <tao-1a23f95c703071aa7d7e>#text(" Show that every subset of ")#mi("{{\\bf R}^n}")#text(" is ")#mi("{({\\mathcal H}^0)^*}")#text("-measurable, and that ")#mi("{{\\mathcal H}^0}")#text(" is counting measure.")
]

#text("Now we look at the opposite case ")#mi("{d=n}")#text(". It is easy to see that any Lebesgue-null set of ")#mi("{{\\bf R}^n}")#text(" has ")#mi("{n}")#text("-dimensional Hausdorff measure zero (since it may be covered by balls of arbitrarily small total content). Thus ")#mi("{n}")#text("-dimensional Hausdorff measure is absolutely continuous with respect to Lebesgue measure, and we thus have ")#mi("{\\frac{d {\\mathcal H}^n}{d \\text{vol}^n} = c}")#text(" for some locally integrable function ")#mi("{c}")#text(". As Hausdorff measure and Lebesgue measure are clearly translation-invariant, ")#mi("{c}")#text(" must also be translation-invariant and thus constant. We therefore have")

#align(center)[#tao-fit-display[#mitex("{\\mathcal H}^n = c \\text{vol}^n")]]

#text("for some constant ")#mi("{c \\geq 0}")#text(".")#linebreak()#text(" We now compute what this constant is. If ")#mi("{\\omega_n}")#text(" denotes the volume of the unit ball ")#mi("{B(0,1)}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("\\sum_k r_k^n = \\frac{1}{\\omega_n} \\sum_k \\text{vol}^n(B(x_k,r_k)) \\geq \\frac{1}{\\omega_n} \\text{vol}^n( \\bigcup_k B(x_k,r_k) )")]]

#text("for any at most countable collection of balls ")#mi("{B(x_k,r_k)}")#text(". Taking infima, we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal H}^n \\geq \\frac{1}{\\omega_n} \\text{vol}^n")]]

#text("and so ")#mi("{c \\geq \\frac{1}{\\omega_n}}")#text(".")#linebreak()#text(" In the opposite direction, observe from Exercise ")#link(<tao-b9f96d32df991613b151>)[#text("5")]#text(" that given any ")#mi("{0 < r < 1}")#text(", one can cover the unit cube ")#mi("{[0,1]^n}")#text(" by at most ")#mi("{C_n r^{-n}}")#text(" balls of radius ")#mi("{r}")#text(", where ")#mi("{C_n}")#text(" depends only on ")#mi("{n}")#text("; thus")

#align(center)[#tao-fit-display[#mitex("{\\mathcal H}^n( [0,1]^n ) \\leq C_n")]]

#text("and so ")#mi("{c \\leq C_n}")#text("; in particular, ")#mi("{c}")#text(" is finite.")#linebreak()#text(" We can in fact compute ")#mi("{c}")#text(" explicitly (although knowing that ")#mi("{c}")#text(" is finite and non-zero already suffices for many applications):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14")]#text(" ")#metadata(none) <tao-30fec3ee539a08c750a2>#text(" We have ")#mi("{c = \\frac{1}{\\omega_n}}")#text(", or in other words ")#mi("{{\\mathcal H}^n = \\frac{1}{\\omega_n} \\text{vol}^n}")#text(". (In particular, a ball ")#mi("{B^n(x,r)}")#text(" has ")#mi("{n}")#text("-dimensional Hausdorff measure ")#mi("{r^n}")#text(".)")
]

#emph[#text("Proof:")]#text(" Let us consider the Hausdorff measure ")#mi("{{\\mathcal H}^n( [0,1]^n )}")#text(" of the unit cube. By definition, for any ")#mi("{\\varepsilon > 0}")#text(" one can find an ")#mi("{0 < r < 1/2}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("h_{n,r}( [0,1]^n ) \\geq {\\mathcal H}^n( [0,1]^n ) - \\varepsilon.")]]

#text("Observe (using Exercise ")#link(<tao-b9f96d32df991613b151>)[#text("5")]#text(") that we can find at least ")#mi("{c_n r^{-n}}")#text(" disjoint balls ")#mi("{B(x_1,r),\\ldots,B(x_k,r)}")#text(" of radius ")#mi("{r}")#text(" inside the unit cube. We then observe that")

#align(center)[#tao-fit-display[#mitex("h_{n,r}( [0,1]^n ) \\leq k r^n + {\\mathcal H}^n( [0,1]^n \\backslash \\bigcup_{i=1}^k B(x_k,r) ).")]]

#text("On the other hand,")

#align(center)[#tao-fit-display[#mitex("{\\mathcal H}^n( [0,1]^n \\backslash \\bigcup_{i=1}^k B(x_k,r) ) = c \\text{vol}^n( [0,1]^n \\backslash \\bigcup_{i=1}^k B(x_k,r) ) = c( 1 - k \\omega_n r^n );")]]

#text("putting all this together, we obtain")

#align(center)[#tao-fit-display[#mitex("c = {\\mathcal H}^n( [0,1]^n ) \\leq k r^n + c (1-k \\omega_n r^n) + \\varepsilon")]]

#text("which rearranges as")

#align(center)[#tao-fit-display[#mitex("1-c\\omega_n \\geq -\\frac{\\varepsilon}{k r^n}.")]]

#text("Since ")#mi("{kr^n}")#text(" is bounded below by ")#mi("{c_n}")#text(", we can then send ")#mi("{\\varepsilon \\rightarrow 0}")#text(" and conclude that ")#mi("{c \\leq \\frac{1}{\\omega_n}}")#text("; since we already showed ")#mi("{c \\geq \\frac{1}{\\omega_n}}")#text(", the claim follows. ")#mi("\\Box")#linebreak()#text(" Thus ")#mi("{n}")#text("-dimensional Hausdorff measure is an explicit constant multiple of ")#mi("{n}")#text("-dimensional Lebesgue measure. The same argument shows that for integers ")#mi("{0 < d < n}")#text(", the restriction of ")#mi("{d}")#text("-dimensional Hausdorff measure to any ")#mi("{d}")#text("-dimensional linear subspace (or affine subspace) ")#mi("{V}")#text(" is equal to the constant ")#mi("{\\frac{1}{\\omega_d}}")#text(" times ")#mi("{d}")#text("-dimensional Lebesgue measure on ")#mi("{V}")#text(". (This shows, by the way, that ")#mi("{{\\mathcal H}^d}")#text(" is not a ")#mi("{\\sigma}")#text("-finite measure on ")#mi("{{\\bf R}^n}")#text(" in general, since one can partition ")#mi("{{\\bf R}^n}")#text(" into uncountably many ")#mi("{d}")#text("-dimensional affine subspaces. In particular, it is ")#emph[#text("not")]#text(" a Radon measure in general).")#linebreak()#text(" One can then compute ")#mi("{d}")#text("-dimensional Hausdorff measure for other sets than subsets of ")#mi("{d}")#text("-dimensional affine subspaces by changes of variable. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Let ")#mi("{0 \\leq d \\leq n}")#text(" be an integer, let ")#mi("{\\Omega}")#text(" be an open subset of ")#mi("{{\\bf R}^d}")#text(", and let ")#mi("{\\phi: \\Omega \\rightarrow {\\bf R}^n}")#text(" be a smooth injective map which is ")#emph[#text("non-degenerate")]#text(" in the sense that the Hessian ")#mi("{D \\phi}")#text(" (which is a ")#mi("{d \\times n}")#text(" matrix) has full rank at every point of ")#mi("{\\Omega}")#text(". For any compact subset ")#mi("{E}")#text(" of ")#mi("{\\Omega}")#text(", establish the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal H}^d( \\phi(E) ) = \\int_E J\\ d{\\mathcal H}^d = \\frac{1}{\\omega_d} \\int_E J\\ d\\text{vol}^d")]]

#text("where the ")#emph[#text("Jacobian")]#text(" ")#mi("{J}")#text(" is the square root of the sum of squares of all the determinants of the ")#mi("{d \\times d}")#text(" minors of the ")#mi("{d \\times n}")#text(" matrix ")#mi("{D \\phi}")#text(". (")#emph[#text("Hint:")]#text(" By working locally, one can assume that ")#mi("{\\phi}")#text(" is the graph of some map from ")#mi("{\\Omega}")#text(" to ")#mi("{{\\bf R}^{n-d}}")#text(", and so can be inverted by the projection function; by working even more locally, one can assume that the Jacobian is within an epsilon of being constant. The image of a small ball in ")#mi("{\\Omega}")#text(" then resembles a small ellipsoid in ")#mi("{\\phi(\\Omega)}")#text(", and conversely the projection of a small ball in ")#mi("{\\phi(\\Omega)}")#text(" is a small ellipsoid in ")#mi("{\\Omega}")#text(". Use some linear algebra and several variable calculus to relate the content of these ellipsoids to the radius of the ball.) It is possible to extend this formula to Lipschitz maps ")#mi("{\\phi: \\Omega \\rightarrow {\\bf R}^n}")#text(" that are not necessarily injective, leading to the ")#emph[#text("area formula")]

#align(center)[#tao-fit-display[#mitex("\\int_{\\phi(E)} \\#(\\phi^{-1}(y))\\ d{\\mathcal H}^d(y) = \\frac{1}{\\omega_d} \\int_E J\\ d\\text{vol}^d")]]

#text("for such maps, but we will not prove this formula here.")
]

#text("From this exercise we see that ")#mi("{d}")#text("-dimensional Hausdorff measure does coincide to a large extent with the ")#mi("{d}")#text("-dimensional notion of surface area; for instance, for a simple smooth curve ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf R}^n}")#text(" with everywhere non-vanishing derivative, the ")#mi("{{\\mathcal H}^1}")#text(" measure of ")#mi("{\\gamma([a,b])}")#text(" is equal to its classical length ")#tao-math("{\\left|\\gamma\\right| = \\int_a^b |\\gamma^{\\prime}(t)|\\ dt}", block: false)#text(". One can also handle a certain amount of singularity (e.g. piecewise smooth non-degenerate curves rather than everywhere smooth non-degenerate curves) by exploiting the countable additivity of ")#mi("{{\\mathcal H}^1}")#text(" measure, or by using the area formula alluded to earlier.")#linebreak()#text(" Now we see how the Hausdorff dimension varies in ")#mi("{d}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{0 \\leq d^{\\prime} < d}")#text(", and let ")#mi("{E \\subset {\\bf R}^n}")#text(" be a Borel set. Show that if ")#mi("{{\\mathcal H}^{d^{\\prime}}(E)}")#text(" is finite, then ")#mi("{{\\mathcal H}^{d}(E)}")#text(" is zero; equivalently, if ")#mi("{{\\mathcal H}^d(E)}")#text(" is positive, then ")#mi("{{\\mathcal H}^{d^{\\prime}}}")#text(" is infinite.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 17")]#text(" Let ")#mi("{0 \\leq d \\leq n}")#text(" be integers. The unit ball ")#mi("{B^d(0,1) \\subset {\\bf R}^d \\subset {\\bf R}^n}")#text(" has a ")#mi("{d}")#text("-dimensional Hausdorff measure of ")#mi("{1}")#text(" (by Lemma ")#link(<tao-30fec3ee539a08c750a2>)[#text("14")]#text("), and so it has zero ")#mi("{d^{\\prime}}")#text("-dimensional Hausdorff dimensional measure for ")#mi("{d^{\\prime} > d}")#text(" and infinite ")#mi("{d^{\\prime}}")#text("-dimensional measure for ")#mi("{d^{\\prime} < d}")#text(".")
]

#text("On the other hand, we know from Exercise ")#link(<tao-1a23f95c703071aa7d7e>)[#text("13")]#text(" that ")#mi("{{\\mathcal H}^0(E)}")#text(" is positive for any non-empty set ")#mi("{E}")#text(", and that ")#mi("{{\\mathcal H}^d(E) = 0}")#text(" for every ")#mi("{d > n}")#text(". We conclude (from the least upper bound property of the reals) that for any Borel set ")#mi("{E \\subset {\\bf R}^n}")#text(", there exists a unique number in ")#mi("{[0,n]}")#text(", called the ")#emph[#text("Hausdorff dimension")]#text(" ")#mi("{\\text{dim}_H(E)}")#text(" of ")#mi("{E}")#text(", such that ")#mi("{{\\mathcal H}^d(E) = 0}")#text(" for all ")#mi("{d > \\text{dim}_H(E)}")#text(" and ")#mi("{{\\mathcal H}^d(E) = \\infty}")#text(" for all ")#mi("{d < \\text{dim}_H(E)}")#text(". Note that at the critical dimension ")#mi("{d = \\text{dim}_H}")#text(" itself, we allow ")#mi("{{\\mathcal H}^d(E)}")#text(" to be zero, finite, or infinite, and we shall shortly see in fact that all three possibilities can occur. By convention, we give the empty set a Hausdorff dimension of ")#mi("{-\\infty}")#text(". One can also assign Hausdorff dimension to non-Borel sets, but we shall not do so to avoid some (very minor) technicalities.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 18")]#text(" The unit ball ")#mi("{B^d(0,1) \\subset {\\bf R}^d \\subset {\\bf R}^n}")#text(" has Hausdorff dimension ")#mi("{d}")#text(", as does ")#mi("{{\\bf R}^d}")#text(" itself. Note that the former set has finite ")#mi("{d}")#text("-dimensional Hausdorff measure, while the latter has an infinite measure. More generally, any ")#mi("{d}")#text("-dimensional smooth manifold in ")#mi("{{\\bf R}^n}")#text(" has Hausdorff dimension ")#mi("{d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Show that the graph ")#mi("{\\{ (x,\\sin\\frac{1}{x}): 0 < x < 1 \\}}")#text(" has Hausdorff dimension ")#mi("{1}")#text("; compare this with Exercise ")#link(<tao-e10a29bd64976f51f739>)[#text("7")]#text(".")
]

#text("It is clear that Hausdorff dimension is monotone: if ")#mi("{E \\subset F}")#text(" are Borel sets, then ")#mi("{\\text{dim}_H(E) \\leq \\text{dim}_H(F)}")#text(". Since Hausdorff measure is countably additive, it is also not hard to see that Hausdorff dimension interacts well with countable unions:")

#align(center)[#tao-fit-display[#mitex("\\text{dim}_H( \\bigcup_{i=1}^\\infty E_i ) = \\sup_{1 \\leq i \\leq \\infty} \\text{dim}_H( E_i ).")]]

#text("Thus for instance the rationals, being a countable union of ")#mi("{0}")#text("-dimensional points, have Hausdorff dimension ")#mi("{0}")#text(", in contrast to their Minkowski dimension of ")#mi("{1}")#text(". On the other hand, we at least have an inequality between Hausdorff and Minkowski dimension:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" For any Borel set ")#mi("{E \\subset {\\bf R}^n}")#text(", show that ")#mi("{\\text{dim}_H(E) \\leq \\underline{\\text{dim}}_M(E) \\leq\\overline{\\text{dim}}_M(E)}")#text(". (Hint: use ")#link(<tao-ecda9209e92eb382c2ba>)[#text("(5)")]#text(". Which of the choices of ")#mi("{*}")#text(" is most convenient to use here?)")
]

#text("It is instructive to compare Hausdorff dimension and Minkowski dimension as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{E}")#text(" be a bounded Borel subset of ")#mi("{{\\bf R}^n}")#text(", and let ")#mi("{d \\geq 0}")#text(".")

#list(
[#text("Show that ")#mi("{\\overline{\\text{dim}}_M(E) \\leq d}")#text(" if and only if, for every ")#mi("{\\varepsilon > 0}")#text(" and arbitrarily small ")#mi("{r > 0}")#text(", one can cover ")#mi("{E}")#text(" by finitely many balls ")#mi("{B(x_1,r_1),\\ldots,B(x_k,r_k)}")#text(" of radii ")#mi("{r_i=r}")#text(" equal to ")#mi("{r}")#text(" such that ")#mi("{\\sum_{i=1}^k r_i^{d+\\varepsilon} \\leq \\varepsilon}")#text(".")],
[#text("Show that ")#mi("{\\underline{\\text{dim}}_M(E) \\leq d}")#text(" if and only if, for every ")#mi("{\\varepsilon > 0}")#text(" and all sufficiently small ")#mi("{r > 0}")#text(", one can cover ")#mi("{E}")#text(" by finitely many balls ")#mi("{B(x_1,r_1),\\ldots,B(x_k,r_k)}")#text(" of radii ")#mi("{r_i=r}")#text(" equal to ")#mi("{r}")#text(" such that ")#mi("{\\sum_{i=1}^k r_i^{d+\\varepsilon} \\leq \\varepsilon}")#text(".")],
[#text("Show that ")#mi("{\\text{dim}_H(E) \\leq d}")#text(" if and only if, for every ")#mi("{\\varepsilon > 0}")#text(" and ")#mi("{r > 0}")#text(", one can cover ")#mi("{E}")#text(" by countably many balls ")#mi("{B(x_1,r_1),\\ldots}")#text(" of radii ")#mi("{r_i \\leq r}")#text(" at most ")#mi("{r}")#text(" such that ")#mi("{\\sum_{i=1}^k r_i^{d+\\varepsilon} \\leq \\varepsilon}")#text(".")]
)
]

#text("The previous two exercises give ways to upper-bound the Hausdorff dimension; for instance, we see from Exercise ")#link(<tao-f5ff23dae9de2b27673f>)[#text("3")]#text(" that self-similar fractals ")#mi("{E}")#text(" of the type in that exercise (i.e. ")#mi("{E}")#text(" is ")#mi("{k}")#text(" translates of ")#mi("{r \\cdot E}")#text(") have Hausdorff dimension at most ")#mi("{\\frac{\\log k}{\\log 1/r}}")#text(". To lower bound the Hausdorff dimension of a set ")#mi("{E}")#text(", one convenient way to do so is to find a measure with a certain “dimension” property (analogous to ")#link(<tao-929f1ca4b2be58d78c26>)[#text("(1)")]#text(") that assigns a positive mass to ")#mi("{E}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" ")#metadata(none) <tao-e4f72e459c6833675d7b>#text(" Let ")#mi("{d \\geq 0}")#text(". A Borel measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}^n}")#text(" is said to be a ")#emph[#text("Frostman measure of dimension at least ")#mi("{d}")]#text(" if it is compactly supported there exists a constant ")#mi("{C}")#text(" such that ")#mi("{\\mu(B(x,r)) \\leq C r^d}")#text(" for all balls ")#mi("{B(x,r)}")#text(" of radius ")#mi("{0 < r < 1}")#text(". Show that if ")#mi("{\\mu}")#text(" has dimension at least ")#mi("{d}")#text(", then any Borel set ")#mi("{E}")#text(" with ")#mi("{\\mu(E) > 0}")#text(" has positive ")#mi("{d}")#text("-dimensional Hausdorff content; in particular, ")#mi("{\\text{dim}_H(E) \\geq d}")#text(".")
]

#text("Note that this gives an alternate way to justify the fact that smooth ")#mi("{d}")#text("-dimensional manifolds have Hausdorff dimension ")#mi("{d}")#text(", since on the one hand they have Minkowski dimension ")#mi("{d}")#text(", and on the other hand they support a non-trivial ")#mi("{d}")#text("-dimensional measure, namely Lebesgue measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Show that the Cantor set in Exercise ")#link(<tao-efc6fcebaf3b710b5650>)[#text("2")]#text("(i) has Hausdorff dimension ")#mi("{1/2}")#text(". More generally, establish the analogue of the first part of Exercise ")#link(<tao-f5ff23dae9de2b27673f>)[#text("3")]#text(" for Hausdorff measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Construct a subset of ")#mi("{{\\bf R}}")#text(" of Hausdorff dimension ")#mi("{1}")#text(" that has zero Lebesgue measure. (")#emph[#text("Hint:")]#text(" A modified Cantor set, vaguely reminiscent of Exercise ")#link(<tao-efc6fcebaf3b710b5650>)[#text("2")]#text("(ii), can work here.)")
]

#text("A useful fact is that Exercise ")#link(<tao-e4f72e459c6833675d7b>)[#text("22")]#text(" can be reversed:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 25 (Frostman’s lemma)")]#text(" Let ")#mi("{d \\geq 0}")#text(", and let ")#mi("{E \\subset {\\bf R}^n}")#text(" be a compact set with ")#mi("{{\\mathcal H}^d(E) > 0}")#text(". Then there exists a non-trivial Frostman measure of dimension at least ")#mi("{d}")#text(" supported on ")#mi("{E}")#text(" (thus ")#mi("{\\mu(E) > 0}")#text(" and ")#mi("{\\mu({\\bf R}^d \\backslash E)=0}")#text(").")
]

#emph[#text("Proof:")]#text(" Without loss of generality we may place the compact set ")#mi("{E}")#text(" in the half-open unit cube ")#mi("{[0,1)^n}")#text(". It is convenient to work dyadically. For each integer ")#mi("{k \\geq 0}")#text(", we subdivide ")#mi("{[0,1)^n}")#text(" into ")#mi("{2^{kn}}")#text(" half-open cubes ")#mi("{Q_{k,1},\\ldots,Q_{k,2^{nk}}}")#text(" of sidelength ")#mi("{\\ell(Q_{k,i}) = 2^{-k}}")#text(" in the usual manner, and refer to such cubes as ")#emph[#text("dyadic cubes")]#text(". For each ")#mi("{k}")#text(" and any ")#mi("{F \\subset [0,1)^n}")#text(", we can define the ")#emph[#text("dyadic Hausdorff content")]#text(" ")#mi("{h^\\Delta_{d,k}(F)}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#mitex("h^\\Delta_{d,2^{-k}}(F) := \\inf \\{ \\sum_j \\ell( Q_{k_j,i_j} )^d: Q_{k_j,i_j} \\text{ cover } F; k_j \\geq k \\}")]]

#text("where the ")#mi("{Q_{k_j,i_j}}")#text(" range over all at most countable families of dyadic cubes of sidelength at most ")#mi("{2^{-k}}")#text(" that cover ")#mi("{F}")#text(". By covering cubes by balls and vice versa, it is not hard to see that")

#align(center)[#tao-fit-display[#mitex("c h_{d,C2^{-k}}(F) \\leq h^\\Delta_{d,2^{-k}}(F) \\leq C h_{d,c2^{-k}}(F)")]]

#text("for some absolute constants ")#mi("{c,C}")#text(" depending only on ")#mi("{d,n}")#text(". Thus, if we define the dyadic Hausdorff measure")

#align(center)[#tao-fit-display[#mitex("({\\mathcal H}^d)^\\Delta(F) := \\lim_{k \\rightarrow \\infty} h^\\Delta_{d,2^{-k}}(F)")]]

#text("then we see that the dyadic and non-dyadic Huausdorff measures are comparable:")

#align(center)[#tao-fit-display[#mitex("c {\\mathcal H}^d(F) \\leq ({\\mathcal H}^d)^\\Delta(F) \\leq C ({\\mathcal H}^d)^\\Delta(F).")]]

#text("In particular, the quantity ")#mi("{\\sigma := ({\\mathcal H}^d)^\\Delta(E)}")#text(" is strictly positive.")#linebreak()#text(" Given any dyadic cube ")#mi("{Q}")#text(" of length ")#mi("{\\ell(Q) = 2^{-k}}")#text(", define the upper Frostman content ")#mi("{\\mu^+(Q)}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#mitex("\\mu^+(Q) := h^\\Delta_{d,k}(E \\cap Q).")]]

#text("Then ")#mi("{\\mu^+([0,1)^n) \\geq \\sigma}")#text(". By covering ")#mi("{E \\cap Q}")#text(" by ")#mi("{Q}")#text(", we also have the bound")

#align(center)[#tao-fit-display[#mitex("\\mu^+(Q) \\leq \\ell(Q)^d.")]]

#text("Finally, by the subadditivity property of Hausdorff content, if we decompose ")#mi("{Q}")#text(" into ")#mi("{2^n}")#text(" cubes ")#mi("{Q^{\\prime}}")#text(" of sidelength ")#mi("{\\ell(Q^{\\prime}) = 2^{-k-1}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mu^+(Q) \\leq \\sum_{Q^{\\prime}} \\mu^+(Q^{\\prime}).")]]

#text("The quantity ")#mi("{\\mu^+}")#text(" behaves like a measure, but is subadditive rather than additive. Nevertheless, one can easily find another quantity ")#mi("{\\mu(Q)}")#text(" to assign to each dyadic cube such that")

#align(center)[#tao-fit-display[#mitex("\\mu([0,1)^n) = \\mu^+([0,1)^n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mu(Q) \\leq \\mu^+(Q)")]]

#text("for all dyadic cubes, and such that")

#align(center)[#tao-fit-display[#mitex("\\mu(Q) = \\sum_{Q^{\\prime}} \\mu(Q^{\\prime})")]]

#text("whenever a dyadic cube is decomposed into ")#mi("{2^n}")#text(" sub-cubes of half the sidelength. Indeed, such a ")#mi("{\\mu}")#text(" can be constructed by a greedy algorithms starting at the largest cube ")#mi("{[0,1)^n}")#text(" and working downward; we omit the details. One can then use this “measure” ")#mi("{\\mu}")#text(" to integrate any continuous compactly supported function on ")#mi("{{\\bf R}^n}")#text(" (by approximating such a function by one which is constant on dyadic cubes of a certain scale), and so by the Riesz representation theorem, it extends to a Radon measure ")#mi("{\\mu}")#text(" supported on ")#mi("{[0,1]^n}")#text(". (One could also have used the Caratheódory extension theorem at this point.) Since ")#mi("{\\mu([0,1)^n) \\geq \\sigma}")#text(", ")#mi("{\\mu}")#text(" is non-trivial; since ")#mi("{\\mu(Q) \\leq \\mu^+(Q) \\leq \\ell(Q)^d}")#text(" for all dyadic cubes ")#mi("{Q}")#text(", it is not hard to see that ")#mi("{\\mu}")#text(" is a Frostman measure of dimension at least ")#mi("{d}")#text(", as desired. ")#mi("\\Box")#linebreak()#text(" The study of Hausdorff dimension is then intimately tied to the study of the dimensional properties of various measures. We give some examples in the next few exercises.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Let ")#mi("{0 < d \\leq n}")#text(", and let ")#mi("{E \\subset {\\bf R}^n}")#text(" be a compact set. Show that ")#mi("{\\text{dim}_H(E) \\geq d}")#text(" if and only if, for every ")#mi("{0 < \\varepsilon < d}")#text(", there exists a probability Borel measure ")#mi("{\\mu}")#text(" supported on ")#mi("{E}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^n} \\int_{{\\bf R}^n} \\frac{1}{\\left|x-y\\right|^{d-\\varepsilon}}\\ d\\mu(x) d\\mu(y) < \\infty.", block: true)]]

#text("Show that this condition is also equivalent to ")#mi("{\\mu}")#text(" lying in the Sobolev space ")#mi("{H^{-(n-d+\\varepsilon)/2}({\\bf R}^n)}")#text(". Thus we see a link here between Hausdorff dimension and Sobolev norms: the lower the dimension of a set, the rougher the measures that it can support, where the Sobolev scale is used to measure roughness.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Let ")#mi("{E}")#text(" be a compact subset of ")#mi("{{\\bf R}^n}")#text(", and let ")#mi("{\\mu}")#text(" be a Borel probability measure supported on ")#mi("{E}")#text(". Let ")#mi("{0 \\leq d \\leq n}")#text(".")

#list(
[#text("Suppose that for every ")#mi("{\\varepsilon > 0}")#text(", every ")#mi("{0 < \\delta < 1/10}")#text(", and every subset ")#mi("{E^{\\prime}}")#text(" of ")#mi("{E}")#text(" with ")#mi("{\\mu(E^{\\prime}) \\geq \\frac{1}{\\log^2 (1/\\delta)}}")#text(", one could establish the bound ")#mi("{{\\mathcal N}_\\delta^*(E^{\\prime}) \\geq c_\\varepsilon (\\frac{1}{\\delta})^{d-\\varepsilon}}")#text(" for ")#mi("{*}")#text(" equal to any of ")#mi("{\\text{ext}, \\text{int}, \\text{net}, \\text{pack}}")#text(" (the exact choice of ")#mi("{*}")#text(" is irrelevant thanks to Exercise ")#link(<tao-b9f96d32df991613b151>)[#text("5")]#text("). Show that ")#mi("{E}")#text(" has Hausdorff dimension at least ")#mi("{d}")#text(". (Hint: cover ")#mi("{E}")#text(" by small balls, then round the radius of each ball to the nearest power of ")#mi("{2}")#text(". Now use countable additivity and the observation that sum ")#mi("{\\sum_\\delta \\frac{1}{\\log^2(1/\\delta)}}")#text(" is small when ")#mi("{\\delta}")#text(" ranges over sufficiently small powers of ")#mi("{2}")#text(".)")],
[#text("Show that one can replace ")#mi("{\\mu(E^{\\prime}) \\geq \\frac{1}{\\log^2 (1/\\delta)}}")#text(" with ")#mi("{\\mu(E^{\\prime}) \\geq \\frac{1}{\\log \\log^2 (1/\\delta)}}")#text(" in the previous statement. (Hint: instead of rounding the radius to the nearest power of ")#mi("{2}")#text(", round instead to radii of the form ")#mi("{1/2^{2^{\\varepsilon n}}}")#text(" for integers ")#mi("{n}")#text(".) This trick of using a hyper-dyadic range of scales rather than a dyadic range of scales is ")#link("http://www.ams.org/mathscinet-getitem?mr=1692486")[#text("due to Bourgain")]#text(". The exponent ")#mi("{2}")#text(" in the double logarithm can be replaced by any other exponent strictly greater than ")#mi("{1}")#text(".")]
)

#text("This should be compared with the task of lower bounding the lower Minkowski dimension, which only requires control on the entropy of ")#mi("{E}")#text(" itself, rather than of large subsets ")#mi("{E^{\\prime}}")#text(" of ")#mi("{E}")#text(". The results of this exercise are exploited to establish lower bounds on the Hausdorff dimension of Kakeya sets (and in particular, to conclude such bounds from the Kakeya maximal function conjecture, as discussed in ")#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/")[#text("this previous post")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{E \\subset {\\bf R}^n}")#text(" be a Borel set, and let ")#mi("{\\phi: E \\rightarrow {\\bf R}^m}")#text(" be a locally Lipschitz map. Show that ")#mi("{\\text{dim}_H(\\phi(E)) \\leq \\text{dim}_H(E)}")#text(", and that if ")#mi("{E}")#text(" has zero ")#mi("{d}")#text("-dimensional Hausdorff measure then so does ")#mi("{\\phi(E)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Let ")#mi("{\\phi: {\\bf R}^n \\rightarrow {\\bf R}}")#text(" be a smooth function, and let ")#mi("{g: {\\bf R}^n \\rightarrow {\\bf R}}")#text(" be a test function such that ")#tao-math("{\\left|\\nabla \\phi\\right| > 0}", block: false)#text(" on the support of ")#mi("{g}")#text(". Establish the ")#link("http://en.wikipedia.org/wiki/Coarea_formula")[#text("co-area formula")]#text(" ")#metadata(none) <tao-a14e05d8052516df6c00>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_{{\\bf R}^n} g(x) |\\nabla \\phi(x)|\\ dx = \\int_{\\bf R} (\\int_{\\phi^{-1}(t)} g(x)\\ d{\\mathcal H}^{n-1}(x))\\ dt.")]]

#text(" (Hint: Subdivide the support of ")#mi("{g}")#text(" to be small, and then apply a change of variables to make ")#mi("{\\phi}")#text(" linear, e.g. ")#mi("{\\phi(x) = x_1}")#text(".) This formula is in fact valid for all absolutely integrable ")#mi("{g}")#text(" and Lipschitz ")#mi("{\\phi}")#text(", but is difficult to prove for this level of generality, requiring a version of ")#link("http://en.wikipedia.org/wiki/Sard%27s_theorem")[#text("Sard’s theorem")]#text(".")
]

#text("The coarea formula ")#link(<tao-a14e05d8052516df6c00>)[#text("(6)")]#text(" can be used to link geometric inequalities to analytic ones. For instance, the sharp isoperimetric inequality")

#align(center)[#tao-fit-display[#mitex("\\text{vol}^n(\\Omega)^{\\frac{n-1}{n}} \\leq \\frac{1}{n \\omega_n^{1/n}} {\\mathcal H}^{n-1}(\\partial \\Omega),")]]

#text("valid for bounded open sets ")#mi("{\\Omega}")#text(" in ")#mi("{{\\bf R}^n}")#text(", can be combined with the coarea formula (with ")#mi("{g := 1}")#text(") to give the sharp Sobolev inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\phi\\right\\|_{L^{\\frac{n}{n-1}}({\\bf R}^n)} \\leq \\frac{1}{n \\omega_n^{1/n}} \\int_{{\\bf R}^n} |\\nabla \\phi(x)|\\ dx", block: true)]]

#text("for any test function ")#mi("{\\phi}")#text(", the main point being that ")#mi("{\\phi^{-1}(t) \\cup \\phi^{-1}(-t)}")#text(" is the boundary of ")#tao-math("{\\{ \\left|\\phi\\right| \\geq t \\}}", block: false)#text(" (one also needs to do some manipulations relating the volume of those level sets to ")#tao-math("{\\left\\| \\phi\\right\\|_{L^{\\frac{n}{n-1}}({\\bf R}^n)}}", block: false)#text("). We omit the details.")#linebreak()#text(" Further discussion of Hausdorff dimension can be found in the books ")#link("http://www.ams.org/mathscinet-getitem?mr=2118797")[#text("of Falconer")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1333890")[#text("of Mattila")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2003254")[#text("of Wolff")]#text(", as well as in many other places.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (67)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36abc819a6f677defa6ba3c408a97bffe2efa24e82fcfca5703ef73e9a87888-4e318a7da43897d74b01c84efb8d07bc264d85aa2fabd65ef866bc106874b4d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Morgan")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-38886")[#strong[#text("Frank Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2009")])]

#text("On infinite dimensional spaces, such as function spaces, there are many notions of small sets, such as category and measure 0, but the strongest is probably that of “positive codimension”; see B. White’s “Generic regularity of unoriented two-dimensional area minimizing surfaces,” MR MR794375.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-38887")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2009")])]

#emph[#text("[In {K}-theory, it is also convenient to work with “virtual” vector spaces or vector bundles, such as formal differences of such spaces, and which may therefore have a negative dimension; but as far as I am aware there is no connection between this notion of dimension and the metric ones given here.] ")]

#text("Interesting question. One way that those formal differences show up as honest dimensions is the following. If M is a topological space carrying a vector bundle V, and sigma is a generic section of V, then the dimension of sigma^{-1}(0) is dim M – dim V (where the second is the fiber dimension).")

#text("But for many purposes one may not want to take an actual section, e.g. because one doesn’t want to prejudice one over the other, or one may not have generic enough sections available because one’s working in a holomorphic context, or just because dim M – dim V would be negative (and so sigma^{-1}(0) would be empty). In such cases, rather than taking sigma^{-1}(0) as the object of interest, one should just keep around M and V, and declare the fibers to be odd vector bundles (in the supermanifold sense).")

#text("This point of view shows up (without mention of supermanifolds) in Fulton-MacPherson intersection theory, where the naive intersection M of two subvarieties is too big, and the correct intersection is represented by a vector bundle V over M, which may or may not have generic enough sections.")

#text("I don’t see any reason M can’t be a fractal. For these oddness purposes, I’m pretty sure V should be an actual vector bundle, not a bundle with fractal fibers.")

#text("Maybe you’d like this question. Let M,N be fractals, with dim M > dim N. Do “most” maps sigma from M -> N have the property that “most” fibers are fractals with dim = dim M – dim N? Add on whatever assumptions, e.g. compactness, you like.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-38892")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2009")])]

#emph[#text("Maybe you’d like this question. Let M,N be fractals, with dim M > dim N. Do “most” maps sigma from M -> N have the property that “most” fibers are fractals with dim = dim M – dim N? Add on whatever assumptions, e.g. compactness, you like.")]

#text("There are indeed results of this general flavour, though one often does have to assume various non-pathological assumptions, e.g. that various notions of dimension for M or N coincide. Here is a typical result (due to Marstrand, and later refined by Peres and Schlag, and stated somewhat informally): if ")#mi("E \\subset {\\Bbb R}^2")#text(" is compact and has dimension d for some ")#mi("1 < d < 2")#text(", then the image of E under \"most\" orthogonal projections ")#mi("(x,y) \\mapsto x \\cos \\theta + y \\sin \\theta")#text(" has full dimension (and even positive measure). In fact the set of directions for which this statement fails has dimension at most ")#mi("2-d")#text(". This isn't quite the type of thing you asked, but is in a similar spirit.")

#text("Incidentally, if one defines the complex Hausdorff dimension of a set to be half the real dimension, then there are some \"algebraic\" examples of fractals in complex geometry: the real m-dimensional manifolds become m/2-dimensional in this sense. In particular the real line is now a 1/2-dimensional complex fractal. I suppose one could try building a half-integer K-theory of real sections of complex vector bundles (maybe restricting to real algebraic varieties to avoid some pathologies); it would probably be a good model for any putative \"fractal K-theory\".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-38904")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Wow, I’d never thought about this general idea of trying to unify fractal dimension and topological ideas in this sort of way, but once one starts thinking along these lines then there seem to be lots of possibilities. For instance, could one develop a notion of cohomology in which one could prove statements like that if ")#mi("A")#text(" and ")#mi("B")#text(" are suitable subsets of a ")#mi("d")#text("-dimensional set, then as you deform them in some suitable way the cohomology class of ")#mi("A\\cap B")#text(" in the group ")#mi("H^a")#text(", where ")#mi("a=\\dim A+\\dim B-d")#text(", does not change? And could one develop an infinitesimal boundary map (that is, one that reduces the dimension infinitesimally)? And in K-theory, could one have a continuous Bott periodicity theorem? Etc. etc. Do people think about this kind of question? And if so, is it generalization for the fun of it or is it conceivable that fractal algebraic topology could have applications?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vicky")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-38905")[#strong[#text("Vicky")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("On a rather less profound note, I think that n and d in the sentence including equation (1) should perhaps be the same. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36abc819a6f677defa6ba3c408a97bffe2efa24e82fcfca5703ef73e9a87888-4e318a7da43897d74b01c84efb8d07bc264d85aa2fabd65ef866bc106874b4d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Morgan")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-38907")[#strong[#text("Frank Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("A simple remark on Terry’s question: in general the Hausdorff dimension of a product is greater than the sum of the Hausdorff dimensions of the factors (see ")#link("http://en.wikipedia.org/wiki/Hausdorff_dimension")[#text("http://en.wikipedia.org/wiki/Hausdorff_dimension")]#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-38915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Dear Frank: Yes, to get a good theory (at least initially), one would have to exclude “pathological” sets (perhaps in analogy to how algebraic geometry works better when one only considers smooth varieties and transverse intersections; one can “fix” all these problems by passing to schemes, but I wouldn’t want to try to conjecture what a fractal scheme would look like yet). For instance, if one restricts attention to sets whose Hausdorff and Minkowski dimenion match, then one does recover the expected identity ")#mi("\\text{dim}(A \\times B) = \\text{dim}(A) + \\text{dim}(B)")#text(". Note that many standard examples of fractals, particularly self-similar fractals, do indeed have matching Hausdorff and Minkowski dimension. (It is also likely to help if one also assumes that the Hausdorff dimension matches some other useful notions of dimension as well, e.g. Fourier dimension.)")

#text("As I said before, perhaps an initial toy case would be that of trying to work out the cohomology or K-theory of smooth real manifolds or algebraic varieties inside complex manifolds (or complex vector bundles), as such “half-integer-dimensional complex fractals” are highly non-pathological in the analytic sense, even if they totally fail to have any complex structure. [Imagine for instance an alien race living in some complexified spacetime whose mathematicians had somehow managed to discover the complex numbers without ever learning about the real numbers, until they stumble upon some strange “fractal” objects in ")#mi("{\\Bbb C}^n")#text(" which we would recognise as real submanifolds, but which they are having a lot of difficulty understanding the geometry of with their purely complex methods. How would they begin to set up, say, the intersection theory of these objects?] But even here one has to be careful; intersection numbers of real manifolds, for instance, aren’t nearly as stable with respect to deformations as their complex counterparts (imagine perturbing two tangent circles, for instance). But presumably the real algebraic geometers have figured out all sorts of ways to deal with these sorts of issues, and perhaps some of those may extend to other well-behaved fractal settings. (For instance, one could start orienting these real manifolds to get signed intersections, but I have no idea how one would orient a more general fractal.)")

#text("In response to one of Tim’s questions, though, I would say that this would be a “generalization for the fun of it”, at least until something non-trivial gets discovered…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-38926")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Dear Prof Tao,")

#text("is it possible to post your lectures in class to the web in the video lecture form?")

#text("some universities have opencourseware and they put some of their classes.")

#text("I think it would be perfect for the math community all over the world to watch your lectures online.")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-39046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2009")])]

#text("Dear Prof. Tao,")

#text("It seems straightforward to generalize Hausdorff measure to non-Euclidean settings, say the p-adics, but are any such generalizations important?")

#text("More generally, I guess, what are some good applications of the study of Hausdorff dimension/measure to questions which do not seem at first to involve it? The Sobolev inequality you mentioned is a good example, but are there others? Maybe something connected in some way to Ratner’s theorems or dynamics/ergodic theory?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-39080")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2009")])]

#text("Dear anonymous,")

#text("I know that Hausdorff dimension plays a role in complex dynamics (indeed, many iconic examples of fractals, such as the Mandelbrot set, come from this field of mathematics), and also in random processes (Brownian motion, SLE, percolation, etc.), and have also made an appearance in other aspects of dynamical systems (e.g. Diophantine approximation), but I am not too familiar with these things. There is also a Hausdorff dimension-like notion for von Neumann algebras due to Voicolescu (though perhaps it is closer in some ways to Minkowski dimension) based on a non-commutative version of the metric entropy, but again I don’t know the details too well. As for the p-adics, I would imagine that metric methods such as Hausdorff dimension could theoretically be of use here, but the number-theoretic structure is much more powerful here than in the Euclidean setting and so the metric theory is likely to be overshadowed by the arithmetic one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89eca54a2b4828138d7aaa4e01819f523e3a053b74a66ab0afb87273f49779d5-7719ad429624b988e156d8bf0f717e1483e0120a910766b6d7b639198ca4ada0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Confused")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-39835")[#strong[#text("Confused")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2009")])]

#text("Sorry to ask but once in a while I happen to bump into both Hausdorff dimension and Hausdorff exponent in some papers on fractal and chaos. Is it the same thing?")

#text("Also curious, is the relations between Haudorff exponent and the power law exponent of the power spectrum is often confused with Hurst exponent… Does the Hausdorff exponent and the Hurst exponent define the same thing and meant the same thing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang M.")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-46128")[#strong[#text("Wolfgang M.")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2010")])]

#text("There appear to be four typo’s between definition 1 and exercise 1: some d’s should be alpha’s. Thanks for the post!")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang M.")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-46133")[#strong[#text("Wolfgang M.")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2010")])]

#text("Thanks for making the changes; but now there are too many alpha’s in there! =) ")#emph[#text("[Oops, wasn’t paying enough attention. Fixed now – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Snegud")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-47202")[#strong[#text("Snegud")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("Dear prof. Tao,")#linebreak()#text(" There seems to be something wrong with second inequality in Exercise 4. If we take ")#mi("n=1")#text(", ")#mi("E=\\langle 0,1\\rangle")#text(" and ")#mi("\\delta = \\frac12")#text(", then ")#mi("vol^n(E_{\\delta}) = 2")#text(", ")#mi("vol^n(B(0,\\delta))=1")#text(" and ")#mi("N_{\\delta}^{ext}=1")#text(" (we take ball with centre at ")#mi("\\frac12")#text(")")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcde9d76d8520bb667f4695e5c1844744a4a69ca17198e07a222153294a93ccc-d2b34d09a92de6c70ba395fdfe68f9515c6d7c841e1626e50c966d40b3c17275.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raina")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-52820")[#strong[#text("Raina")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2011")])]

#text("Dear Prof. Tao,")

#text("I have just started reading about Hausdorff dimensions.")#linebreak()#text(" Let S in n-dimensional Euclidean Plane be a compact set of Hausdorff dimension t where 0<t<n is a non-integer. Let S-epsilon be the union of epsilon neighborhoods of all points in S. I could imagine a relation between the Lebesgue measure of S-epsilon and Hausdorff measure of S. But I could not think clearly. Is there any relation?")#linebreak()#text(" Could you suggest me books for reference (to read in detail about relation between Hausdorff measures and other(Borel,probability,Lebesgue) measures)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-52823")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2011")])]

#text("Yes. See Exercises 15 and 16 of the above post.")

#text("As for references, I can recommend the books ")#link("http://www.ams.org/mathscinet-getitem?mr=867284")[#text("of Falconer")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1333890")[#text("of Mattila")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcde9d76d8520bb667f4695e5c1844744a4a69ca17198e07a222153294a93ccc-d2b34d09a92de6c70ba395fdfe68f9515c6d7c841e1626e50c966d40b3c17275.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raina")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-52836")[#strong[#text("Raina")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2011")])]

#text("Thanks sir..")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-126204")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2012")])]

#text("Typo: “…the dyadic and non-dyadic Huausdorff measures are comparable”")

#emph[#text("[Corrected, thanks-T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcde9d76d8520bb667f4695e5c1844744a4a69ca17198e07a222153294a93ccc-d2b34d09a92de6c70ba395fdfe68f9515c6d7c841e1626e50c966d40b3c17275.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raina")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-133257")[#strong[#text("Raina")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2012")])]

#text("Is there any Co-area formula involving non integer Hausdorff dimension?")#linebreak()#text(" Moreover is it sensible to write the following:")#linebreak()#text(" Let S be a subset in ")#mi("\\mathbb{R}^n")#text(" with Hausdorff dimension s ")#mi("(0<s<n)")#text(" and ")#mi("S_{\\epsilon}=\\cup_{x \\in S}B(x,\\epsilon)")#text(".")

#mi("\\int_{S_{\\epsilon}} dy = \\int_S \\int_{B(x,\\epsilon)} dy d\\mu(x)")#text(" where ")#mi("\\mu")#text(" is a uniformly s-dimensional measure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dfd09ea8a1b95074e59369f28c4275ae1486f01a0e53fa4e11efea8c9e3f87b-f86ebe862d8bcb79d4b22ab36e52359a48a8d0cb1fdc84a43405add520151805.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hamsi kafalı temel")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-154228")[#strong[#text("hamsi kafalı temel")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2012")])]

#text("prof tao I love you so much your real analysis notes are like a water in mohab desert")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-158510")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2012")])]

#text("Small typo in the passage: “Let {0 \\leq d \\leq n}. Suppose {E} is a bounded portion of a {k}-dimensional subspace, e.g. {E = B^d(0,1) \\times \\{0\\}^{n-d}}, where {B^d(0,1) \\subset {\\bf R}^d} is the unit ball in {{\\bf R}^d} and we identify {{\\bf R}^n} with {{\\bf R}^d \\times {\\bf R}^{n-d}} in the usual manner.”")

#text("I believe the {k} here should be a {d}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-158511")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2012")])]

#text("Whoops. My login seems to have failed…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lucas Braune")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-160792")[#strong[#text("Lucas Braune")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2012")])]

#text("You meant to write ‘prime’ instead of ‘maximal’ in the phrase “a chain of maximal ideals”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-161243")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2012")]

#strong[#text("What are the basic differences between physical and mathematical dimensions? And what are some uses, applications or examples of mathematical dimensions in the physical world?…")]

#text("Terence Tao has a wonderful overview of the dimension concept [1]. Basically, there are several definitions of ‘dimension’ which we tend to use interchangeably because they give the same number in most cases. For instance determining the dimension by…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-161244")[#strong[#text("Dimensions: What are the basic differences between physical and mathematical dimensions? And what are some uses, applications or examples of mathematical dimensions in the physical world? - Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2012")]

#text("[…] of fractals. The sierpinski triangle for instance, has dimension 1.58. [1] ")#link("https://terrytao.wordpress.com/20")[#text("https://terrytao.wordpress.com/20")]#text("…\"},\"cls:a.app.view.components:BlurredAnswer:MgVYc2IwuP1/dH\",{}), […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39cd0f2ad568a17f364d5b927dadae5cb0c5074f521c1b6554ad8b3bdda9be49-8fdcd50dc4b62dbce1dfabf6a183e711d79b89e12d8cae843367047ccb5f549a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Pearson")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-223961")[#strong[#text("John Pearson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2013")])]

#text("I believe that there are a couple of typos at the end of the proof of Lemma 3. At the end of the proof, I believe you should have")

#mi("\\displaystyle  1-c\\omega_n \\geq \\frac{-\\varepsilon}{k r^n}")#text(".")

#text("This allows you to conclude that ")#mi("c \\leq \\frac{1}{\\omega_n}")#text(" which is what you want since you had shown ")#mi("c \\geq \\frac{1}{\\omega_n}")#text(" in the lead-up to the lemma. (The inequalities were swapped in the version above.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35e1dd4c70f3f91ffff65faf4a5c12d9a98e665178bbc68d448592e076078157-bfef78253dd440411fa3afaf419c4a0956d32191309af0ef78ad68e407e0d80f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-347942")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2014")])]

#text("Dear Terry,")

#text("I’ve noticed that many sources define Hausdorff measure somewhat differently in that they allow coverings by arbitrary sets U and then take the sum of the contributions (diam U)^s. Is this an important difference? I think it makes showing n-dim Hausdorff measure = Lebesgue measure more difficult. Is there any effect on applications?")

#text("Actually, is there much in the way of applications at all, or is Hausdorff dimension more of an end than a means? A hypothetical application would be, say, an existence proof which proceeds by showing that the set of desired objects has positive dimension.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-348114")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2014")])]

#text("The two definitions of Hausdorff dimension are equivalent, because any set U can be covered by a ball of diameter comparable to that of U. I suppose one could use the other definition of Hausdorff dimension if one wished to downplay the role of metric balls.")

#text("As for applications, Hausdorff dimension is often equal to other notions of dimension for “non-pathological” sets; for instance, for real algebraic varieties, the real algebraic dimension is equal to the Hausdorff dimension. So one can often use results about Hausdorff dimension to say something about other notions of dimension.")

#text("One can also use Hausdorff dimension to extract some topological information. For instance, suppose one removes a closed set ")#mi("E")#text(" from ")#mi("{\\bf R}^n")#text(". If all one knows about ")#mi("E")#text(" is that it has measure zero, then this can disconnect ")#mi("{\\bf R}^n")#text("; consider for instance removing a hyperplane from ")#mi("{\\bf R}^n")#text(". But if one knows that ")#mi("E")#text(" has Hausdorff dimension strictly less than ")#mi("n-1")#text(", one can show that the complement remains topologically path-connected (proof: given any two points ")#mi("x,y")#text(" in the complement, connect them by line segments to a randomly selected third point ")#mi("z")#text(", and show that this almost surely avoids ")#mi("E")#text("). If ")#mi("E")#text(" has dimension strictly less than ")#mi("n-2")#text(", then the complement is also simply connected, and so forth. Several years ago, I used these facts with Gang Tian to show some singularity removal theorems for Yang-Mills fields, by first bounding the Hausdorff dimension of the singular set, and then exploiting the topological triviality of the complement as a consequence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-687936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2025")])]

#text("Dear Prof. Tao,")#linebreak()#text("I understand that use of coverings by arbitrary sets of diameter at most s can be extended to Minkowski-Bouligand dimension as well in R^n. Could such a definition be shown to hold on the 2-sphere too?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-687942")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2025")])]

#text("Yes, the standard notions of dimension are all invariant with respect to diffeomorphisms (or even locally Lipschitz maps) and so the theory transports itself quite readily to other manifolds, even somewhat non-smooth ones.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98714b90c40ffcc4b3ec5113bba2f3a2aa107152aab79abd68b79f151528b466-e976ddbc5d836a5e0b59122d893ba3dd3686a98e6b70ec32567faac67796f99c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Itay")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-369435")[#strong[#text("Itay")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2014")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I seem to be missing something. In the reformulation of upper and lower Minkowski dimension, it is not clear how does alpha play a role in the new formulation, and also maybe the volume should be the n-dimensional volume?")

#emph[#text("[Typos in post corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/215d157019e6ebe68c1b499e7873c16cdd6cef92085a749860759a74a11cfcaf-7a088a2a4d6f043f5d8dc970f4538325aca5312cc53d6b176a3f5b84351056da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of priya jain")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-451451")[#strong[#text("priya jain")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2015")])]

#text("Is there proof of exercise question????")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a01f264f48f5e05d5d685b9021d8eabe021cba75bb29f31f0c2c489198037bd-3a332be6c68a6a6e665ca9294ad450f10654091c15e3a2b8f42c50a2c9b259ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Kakeya problem | Anurag's Math Blog")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-453317")[#strong[#text("The Kakeya problem | Anurag's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2015")])]

#text("[…] Kakeya sets in have Hausdorff dimension equal to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7623bac5d45f2d15d00486e34c76dbe92a014639fb1d263bedd661765c0a781e-fbe1da168dfd7c1e14aa47d82f0a3c5b092b5d34a47988fe33410d6796c4870c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cyril")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-454307")[#strong[#text("Cyril")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2015")])]

#text("Dear Terry;")

#text("I’ve been try to answer this question for a very long time:")

#text("What can on say about Hausdorff dimension of a subfield of $\\mathbb{R}$ ?")

#text("I have already built a proper uncountable subfield of $\\mathbb{R}$ with null Hausdorff dimension but I don’t know there exists such subfields with not null Haussdorff dimension. Have you got any idea ?")

#text("Thanks a lot for the quality of your blog and the time you spend to answer questions of such beginners as I am.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-454310")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2015")])]

#text("In the case of Borel-measurable subfields, the Hausdorff dimension must be either 0 or 1, a result of Edgar and Miller (answering a question of Erdos and Volkmann): ")#link("http://www.ams.org/mathscinet-getitem?mr=1948103")[#text("http://www.ams.org/mathscinet-getitem?mr=1948103")]#text(" . There is a more technical quantitative version of this, due to Bourgain, which has a number of important applications such as in the theory of expander graphs (and most recently, in the Kakeya problem): ")#link("http://www.ams.org/mathscinet-getitem?mr=1982147")[#text("http://www.ams.org/mathscinet-getitem?mr=1982147")]

#text("I don’t know what happens if the hypothesis of Borel measurability is dropped; the question may be sensitive to the axioms of set theory in the ambient mathematical universe.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-454317")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2015")])]

#text("Hi Terry,")

#text("I’m curious what the “most recent” application of Bourgain’s ring theorem to the Kakeya problem is. I know in some non-rigorous / heuristic sense Bourgain’s theorem should imply the KLT $5/2+\\epsilon$ result (based on, say, the BKT finite field argument) but I am not familiar with any literature on this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-454318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2015")])]

#text("This is extremely recent work of Katz and Zahl, which should appear on the arXiv in a few weeks. As you guessed, it gives a Hausdorff dimension bound of ")#mi("5/2+\\varepsilon")#text(" for Kakeya sets via a Euclidean version of the BKT argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-456227")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2015")])]

#text("I think there is a typo in the second paragraph of section 1 (“Minkowski dimension”), in particular, in this sentence:")

#text("“These are open sets in {{\\bf R}^n} and therefore have a {d}-dimensional volume (or Lebesgue measure) {\\hbox{vol}^d(E_\\delta)}.”")

#text("Should the two {d}’s be {n}’s?")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6937c74d8057f577857d569fe88beef3917f25a4b1f6423390f91c131378ca04-6c07ff71b80e6c96ffdb170a137476cd870899e394fbf07f6b6fbed50be57605.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245C, Notes 5: Hausdorff dimension (optional) | Alabair's Weblog")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-467742")[#strong[#text("245C, Notes 5: Hausdorff dimension (optional) | Alabair's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2016")])]

#text("[…] Source : 245C, Notes 5: Hausdorff dimension (optional) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous2")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-468520")[#strong[#text("Anonymous2")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("Does anybody happen to know where Minkowski gave his original work on “Minkowski dimension”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-468563")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("In Exercise 13, I think you mean ")#mi("0\\leq d^{\\prime}<d")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-469070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2016")])]

#text("By Lemma 3, one can find the ")#mi("n")#text("-dimension Hausdorff measure of an ")#mi("n")#text("-dimensional ball ")#mi("B(x,r)")#text(". Do you have a hint how to find the (n-1)-dimension Hausdorff measure of the boundary ")#mi("\\partial B(x,r)\\subset\\mathbb{R}^n")#text("?")

#emph[#text("[Use Exercise 12 – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-469875")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2016")])]

#text("Hi Terry,")

#text("I think in equations both (4) and (5), there should be “log” in the numerator as well.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 2: complex integration | What's new")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-472642")[#strong[#text("246A, Notes 2: complex integration | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("[…] is clarified once one develops the theory of Hausdorff dimension, as is done for instance in this previous post: any curve of Hausdorff dimension strictly greater than one will be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bad040db24676b212dd71d23a86951c6673133545bd7ef895eee872b4220f91-50b8d66dccd4f72e4bba51ecddcd9bafd9261cd8cb63a9567153ee6028bc9273.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dominik")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-479958")[#strong[#text("Dominik")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2017")])]

#text("There is a typo in Lemma 4 (Frostman’s lemma). It should say “of dimension at most d” instead of “at least d”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bad040db24676b212dd71d23a86951c6673133545bd7ef895eee872b4220f91-50b8d66dccd4f72e4bba51ecddcd9bafd9261cd8cb63a9567153ee6028bc9273.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dominik")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-479997")[#strong[#text("Dominik")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2017")])]

#text("Now its wrong in both Lemma 4 and Exercise 17. It should say “at most d”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bad040db24676b212dd71d23a86951c6673133545bd7ef895eee872b4220f91-50b8d66dccd4f72e4bba51ecddcd9bafd9261cd8cb63a9567153ee6028bc9273.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dominik")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-480012")[#strong[#text("Dominik")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2017")])]

#text("Ok, now I see that it really should say “at least d”, because that’s what the condition in the definition of a Frostman measure means. So, it’s right now in Lemma 4 and Exercise 17, but still in the last line of the proof of Frostman’s lemma it says “at most d”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-487341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2017")])]

#text("I think there are a few typos below definition 1")#linebreak()#text(" (e.g. the upper minkowski statement should have + \\epsilon in it rather than a – \\epsilon)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-493915")[#strong[#text("The co-area formula exercise from Terry Tao’s blog | zulfahmed")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2018")]

#text("[…] is an exercise from Terry’s blog on Hausdorff […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce491590c3e260b7d1581dcd4198fbfd9c28077a9ea1612fd61810005a559286-8b3d0c68cf147da61413922a1c9e1d625bde6b7bd9ee3dce96cf75de749543e7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-507038")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2018")])]

#text("How do we get the sigma-additivity of the measure obtained in the proof of Frostman’s lemma (on the semiring of dyadic cubes)? Does it require some additional care on the greedy procedure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-507475")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2018")])]

#text("The measure provided by the Riesz representation theorem is automatically sigma-additive. (Alternatively one could also argue using the Kolmogorov extension theorem.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-511116")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#text("For exercise 9, if ")#mi("r_jn")#text(", then")#linebreak()#text(" ")#mi("\\displaystyle \\sum_jr_j^d\\leq \\delta^{d-n}\\sum_j r_j^n")#linebreak()#text(" This shows that ")#emph[#text("if")]#text(" ")#mi("\\mathcal{H}^n(E)<\\infty")#text(" then ")#mi("\\mathcal{H}^d(E)=0")#text("; this is weaker than the statement in Exercise 9. And it seems that the argument above does not exploit the special number ")#mi("n")#text(" yet. Can you give a hint?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-511144")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#text("First show that any bounded subset of ")#mi("{\\bf R}^n")#text(" has finite ")#mi("n")#text("-dimensional Hausdorff outer measure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-511150")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#text("Looks like Trick 6 in")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("245A: Problem solving strategies")]
]

#text("One can show this by covering the bounded subset of ")#mi("\\mathbf{R}^n")#text(" with balls of a smaller radius. It then follows by the observation in the previous comment that")#linebreak()#text(" ")#mi("\\displaystyle (\\mathcal{H}^d)^*(E)=0")#linebreak()#text(" for all bounded subsets. How to “patch things together”?")

#text("Without countably subadditive, how can one pass it to the unbounded case? (Stein-Shakarchi established subadditivity; one could look it up in the book. Can one do it alternatively?) Or does one have to establish some “continuity” of ")#mi("(\\mathcal{H}^d)^*")#text(" (which I don’t find a way to show) so that one can look at the Hausdorff outer measure of sets ")#mi("E\\cap B(0,R)")#text("?")

#text("(It’s interesting to look at different proofs. In Wolff’s notes that mentioned in the last sentence of this post, the author gave a mysterious one-sentence proof: “when ")#mi("d>n")#text(", one can cover ")#mi("\\mathbf{R}^n")#text(" by discs ")#mi("B(x_j,r_j)")#text(" with ")#mi("\\sum_jr_j^d")#text(" arbitrarily small.”, which I have no ideas what he means.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-511210")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2019")])]

#text("Use Trick 11 (combined with Trick 2).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arash")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-511139")[#strong[#text("Arash")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#text("Hi, “this quantity is increasing in $r$”. Should not it be decreasing with $r$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-512881")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2019")])]

#text("Dear Prof. Tao,")

#text("In Exercise 20, the statement asserted to be equivalent to ")#mi("\\mathrm{dim}_H(E)\\leq d")#text(" seems independent to the set ")#mi("E")#text(". It may be better to correct this statement.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-513130")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2019")])]

#text("Dear Prof. Tao,")

#text("I’m struggling with Exercise 21.(i). I don’t see how ")#mi("\\sum_\\delta \\frac{1}{\\log ^2\\frac{1}{\\delta}}")#text(" being small is used. I see directly that the lower Minkowski dimension of any set with positive ")#mi("\\mu -")#text("measure is greater or equal to ")#mi("d")#text(", but I guess the problem is treating covering by balls of varying radius.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-513211")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2019")])]

#text("The point is that if ")#mi("a_\\delta")#text(" is a sequence of nonnegative numbers such that ")#mi("\\sum_\\delta a_\\delta")#text(" is large, then one must have ")#mi("a_\\delta \\geq \\frac{1}{\\log^2 \\frac{1}{\\delta}}")#text(" for some ")#mi("\\delta")#text(" (pigeonhole principle). In this question, the numbers ")#mi("a_\\delta")#text(" are basically the Frostman measure of the union of balls of radius equal (after rounding) to ")#mi("\\delta")#text(" in a suitable covering of the set by balls of variable radius.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-515189")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2019")])]

#text("Dear prof. Tao.")

#text("I am having problem with exercise 5, especifically for the unbounded generalization of the definion of Minkowski dimension. Any hint? Thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bf7c324b72742fba31c7da10d6dd43613c5d0f6a5d40944f1b49d96e357f856-389bbf8210dadf7964f10a329b58a83227f74e3d3226e948b8c737f1df9544c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yi")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-613496")[#strong[#text("yi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2020")])]

#text("Dear prof. Tao : there seems to have a typo in here “We have {\\overline{\\hbox{dim}}_M(E) 0}, one has {\\hbox{vol}^n(E_\\delta) \\leq C \\delta^{n-\\alpha-\\epsilon}} for all sufficiently small {\\delta > 0} and some {C > 0}”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-678079")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2023")])]

#text("Dear Professor Tao:")#linebreak()#text(" I have a question on the statement of Exercise 8, you said that for any $x_0\\in X$, the inequality holds. However, in the inequality, the 1st term of right hand side is $\\sup_{x_0\\in E_0}f(x_0)$, so in fact, the $x_0$ in the statement is not used in the inequality(because you already take a supremum). Why do you say that for any $x_0\\in X$?")

#emph[#text("[This was a typo, now corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-682863")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2024")])]

#text("I really liked that interpretation of the Hausdorff dimension of a set in terms of “its roughness”, because it is also what the Sobolev dimension of measures tells us. Do you also interpret the energies of the Fourier dimension spectrum as quantifying how smooth the measure is in terms of its fractional derivatives?")#linebreak()#text(" The energy I talk about is defined as:")

#tao-math("\\displaystyle \\mathcal{J}_{s,\\theta}  = \\bigg( \\int_{\\mathbb{R}^n} \\left|\\hat\\mu(z)\\right|^{2/\\theta}\\left|z\\right|^{s/\\theta - d} \\bigg)^{\\theta}", block: false)

#text("I believe the integrals in Exercise 26 should be on ")#mi("\\mathbb{R}^n")#text(" instead of ")#mi("\\mathbb{R}^d")#text("?")

#emph[#text("[Erratum added, thanks. These energies can also be viewed as measures of regularity; this can be clarified by looking at Littlewood-Paley components of the measure. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-687457")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2025")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("This can be used to clarify the nature of various singularities, such as that arising from non-smooth solutions to PDE; a function which is non-smooth on a set of large Hausdorff dimension can be considered less smooth than one which is non-smooth on a set of small Hausdorff dimension, even if both are smooth almost everywhere.")
]

#text("I’m curious about this statement. Could you provide an example illustrating this phenomenon?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-687459")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2025")])]

#text("There are several papers relating the dimension of the singular set of a function with its Sobolev regularity, e.g., ")#link("https://www.sciencedirect.com/science/article/pii/S1631073X02023166")[#text("https://www.sciencedirect.com/science/article/pii/S1631073X02023166")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-693900")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("The dimension of topological spaces mentioned in the article refers to the inductive dimension. There is another definition that assigns dimensions to topological spaces, namely the Lebesgue covering dimension. Does it also belong to the category of defining dimension inductively? Why are topological spaces suitable for defining dimension inductively?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/#comment-693906")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("I am outsourcing ")#link("https://claude.ai/share/ca22270b-07fe-496e-b44f-6ff1344900b0")[#text("this question to an AI")]#text(".")

#text("Intuitively, the concept of inductive dimension is trying to capture the phenomenon that the boundary of an n-dimensional space tends to be at least n-1-dimensional (it can be higher, though, due to fractals, space-filling curves, etc.).")
]
]
