// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/
// Converted to Typst by tao2typ: "2026-10-14T11:00:39.167694+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Exploring the toolkit of Jean Bourgain", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Exploring the toolkit of Jean Bourgain")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 September 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/")[#text("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I have uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/2009.06736")[#text("Exploring the toolkit of Jean Bourgain")]#text("“. This is one of a collection of papers to be published in the Bulletin of the American Mathematical Society describing aspects of the work of Jean Bourgain; other contributors to this collection include Keith Ball, Ciprian Demeter, and Carlos Kenig. Because the other contributors will be covering specific areas of Jean’s work in some detail, I decided to take a non-overlapping tack, and focus instead on some basic tools of Jean that he frequently used across many of the fields he contributed to. Jean had a surprising number of these “basic tools” that he wielded with great dexterity, and in this paper I focus on just a few of them:")

#list(
[#text("Reducing qualitative analysis results (e.g., convergence theorems or dimension bounds) to quantitative analysis estimates (e.g., variational inequalities or maximal function estimates).")],
[#text("Using dyadic pigeonholing to locate good scales to work in or to apply truncations.")],
[#text("Using random translations to amplify small sets (low density) into large sets (positive density).")],
[#text("Combining large deviation inequalities with metric entropy bounds to control suprema of various random processes.")]
)

#text("Each of these techniques is individually not too difficult to explain, and were certainly employed on occasion by various mathematicians prior to Bourgain’s work; but Jean had internalized them to the point where he would instinctively use them as soon as they became relevant to a given problem at hand. I illustrate this at the end of the paper with an exposition of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=937795")[#text("one particular result of Jean")]#text(", on the Erdős similarity problem, in which his main result (that any sum ")#mi("{S = S_1+S_2+S_3}")#text(" of three infinite sets of reals has the property that there exists a positive measure set ")#mi("{E}")#text(" that does not contain any homothetic copy ")#mi("{x+tS}")#text(" of ")#mi("{S}")#text(") is basically proven by a sequential application of these tools (except for dyadic pigeonholing, which turns out not to be needed here).")

#text("I had initially intended to also cover some other basic tools in Jean’s toolkit, such as the uncertainty principle and the use of probabilistic decoupling, but was having trouble keeping the paper coherent with such a broad focus (certainly I could not identify a single paper of Jean’s that employed all of these tools at once). I hope though that the examples given in the paper gives some reasonable impression of Jean’s research style.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13adaff32d54f3bdf4caf53abe3d7d7661f47307b45be7dfe4a21eeb122bc96c-30478c564e1d0b5eb16035de2a3eae50d90ef7462ef80bb9d6ab9ae482bb19a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Zaharopol")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589293")[#strong[#text("Radu Zaharopol")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("Dear Professor Tao,")

#text("I think that you did a great service to the mathematical community in “Exploring the Toolkit of Jean Bourgain.”")

#text("Sincerely yours, Radu Zaharopol")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3bba8bad3bd41d3a51ea3cf13e57cde3954bcd80cab7bba209038c99df180345-16e2e1da6446b54abfe3edb133dfac323362cad05b04a75c35cfe07a06a8ebaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Jones")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589300")[#strong[#text("Alex Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("Thank you for this amazing article! I am a bit confused about something though. Your abstract suggests that Jean only had a few tricks (“Every mathematician only has a few tricks. Jean … may … appear to be a counterexample. However,…”), but the paper and this blog post (“surprising number”) suggests that he has a lot of core, useful tricks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589301")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("The number of Bourgain’s core tricks was few in number relative to his total research output, but was large in absolute terms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589334")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("The idea of decoupling is closely related to the general principle of reducing the complexity of a given mathematical structure by trying to identify its “building blocks” or substructures (e.g. representing a polynomial as a product of its irreducible factors) which may greatly simplify the analysis of the whole structure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2020")])]

#text("In the definition of property E (the arxiv paper, page 14), it seems that the word “whenever” is not needed.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2176c531c812ad2d9c77ce67dc4b06a0d07a3f49d9fcf95991966eedee8b0c27-e2c4cda0ae09e24de3b31ff0cde3305c92f4dd6a1f994eccfc09695131452d82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of s")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589552")[#strong[#text("s")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2020")])]

#text("ha thank you. I was having trouble parsing that.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/202ddfca269a36f903ca88cfbce5d66e94df2cf32cd7ecd9f4b6cf4f63df6488-57371a1b9029cf83f03fae14bb0450d41984e043bbe151e6b3b6cfe74c04c3c7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jochen Voss")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589506")[#strong[#text("Jochen Voss")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2020")])]

#text("In the arxived paper, I believe the summation in the displayed equation after (4.4) should be dropped (since the pigeonhole principle selects one j).")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chang")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589581")[#strong[#text("Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2020")])]

#text("Dear Professor")#linebreak()#text(" I just have founded a typo in the reference [30] (Stein, 1961) of your paper: seqences –> sequences.")#linebreak()#text(" Congratulations for your present contribution to the diffusion of the original works of Jean.")#linebreak()#text(" Sincerely yours")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zeng")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589585")[#strong[#text("Zeng")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2020")])]

#text("Yet another little on the blog : Erdos similarity problem ==> Erdo”s similarity problem.")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shaw")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-589944")[#strong[#text("Shaw")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2020")])]

#text("Dear Professor Tao,")#linebreak()#text(" In Theorem 3.1, it seems that “|x-y|>=l” should be “|x-y|=l”.")

#emph[#text("[Thanks, this will be fixed in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-679840")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2023")])]

#text("Hello: I guess that there is a mistake in the formula after (4.4):…hence by the pigeonhole principle we can find a scale ")#mi("t_j")#text(" for which ")#tao-math("\\sum_{j=1}^J\\int_{\\delta/t_j\\leq\\left|\\xi\\right|\\leq 1/\\delta t_j}", block: false)#text(", there should not be a summation in this formula?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/15/exploring-the-toolkit-of-jean-bourgain/#comment-679843")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2023")])]

#text("Ah I just found that Jochen Voss already pointed this. He was right, there shouldn’t be a summation.")
]
]
