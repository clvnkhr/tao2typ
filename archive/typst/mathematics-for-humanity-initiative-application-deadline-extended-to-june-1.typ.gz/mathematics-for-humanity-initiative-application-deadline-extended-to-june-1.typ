// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/03/09/mathematics-for-humanity-initiative-application-deadline-extended-to-june-1/
// Converted to Typst by tao2typ: "2026-10-14T11:09:45.192926+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematics for Humanity initiative – application deadline extended to June 1", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematics for Humanity initiative – application deadline extended to June 1")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 March 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/03/09/mathematics-for-humanity-initiative-application-deadline-extended-to-june-1/")[#text("https://terrytao.wordpress.com/2023/03/09/mathematics-for-humanity-initiative-application-deadline-extended-to-june-1/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("https://www.icms.org.uk/")[#text("International Center for Mathematical Sciences")]#text(" in Edinburgh recently launched its “")#link("https://www.icms.org.uk/funding-opportunities/mathematics-humanity")[#text("Mathematics for Humanity")]#text("” initiative with a call for research activity proposals (ranging from small collaborations to courses, workshops and conferences) aimed at using mathematics to contributing to the betterment of humanity. (I have agreed to serve on the scientific committee to evaluate these proposals.) We launched this initiative in January and initially set the deadline for April 15, but several people who had expressed interest felt that this was insufficient time to prepare a quality proposal, so we have now ")#link("https://www.icms.org.uk/funding-opportunities/mathematics-humanity")[#text("extended the deadline to June 1")]#text(", and welcome ")#link("https://www.icms.org.uk/sites/default/files/downloads/MFH%20submission%20guidelines%20v4.pdf")[#text("further applications")]#text(".")

#text("See also ")#link("https://mathstodon.xyz/@johncarlosbaez/109404604041655398")[#text("this Mathstodon post")]#text(" from fellow committee member John Baez last year where he solicited some preliminary suggestions for proposals, and my ")#link("https://mathstodon.xyz/@tao/109755867761178880")[#text("previous Mathstodon announcement")]#text(" of this programme.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac983530f20629f4d6e12ed54d2c022994334e0007072844a9a19b9b77c49faa-26b3da4f96a0cc2cf8a013ca1b744afcc1424286468e4b004d12168291232854.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Smith")]], [#link("https://terrytao.wordpress.com/2023/03/09/mathematics-for-humanity-initiative-application-deadline-extended-to-june-1/#comment-676555")[#strong[#text("Joe Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2023")])]

#text("I guess that best initiative that we, as mathematicians, can take for humanity is to stop teaching engineers and economists.")#linebreak()#text(" As the Chinese philosopher Zhuanzi wrote: “Do not those who are vulgarly called wise prove to be collectors for the great thieves? And do not those who are called sages prove to be but guardians in the interest of the great thieves?” (Translation by James Legge. See ")#link("https://ctext.org/zhuangzi/cutting-open-satchels")[#text("https://ctext.org/zhuangzi/cutting-open-satchels")]#text(" for the full citation). I like to read this text thinking that we, mathematicians, are the ones who are called wise, while the great thieves are those who are destroying the world using all the mathematics we have been developing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c15bdad08863c037699e938fc8c36bfb2aa1c00a320d36ab54ee7289e24222aa-208baf2d4285b5d755cf6ef012c3388499d510362a96677b3bcf91fe7ecdcd40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webmaster")]], [#link("https://terrytao.wordpress.com/2023/03/09/mathematics-for-humanity-initiative-application-deadline-extended-to-june-1/#comment-676979")[#strong[#text("Webmaster")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2023")])]

#text("If you want to remain above the sea level, perhaps you should tell the POTUS not to approve new fossil fuel extraction projects. Why should we not produce energy WITHOUT destroying the planet?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f4ab6a97eed723a6ad6a5b844d810fbd6c648fae1698642d600addb347eb778-0229b0abb126c079b34eb5e69b6059e03018f50fed0949d47ae4f68eb843f6d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2023/03/09/mathematics-for-humanity-initiative-application-deadline-extended-to-june-1/#comment-676997")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2023")])]

#text("During terrible conditions, which is the human legacy, you should choose not to be decreased. You have your mankind, and you should not permit anything to decrease that. We are obliged to realize we are worldwide residents. Catastrophes remind us we are world residents, regardless of whether we like it.")
]
