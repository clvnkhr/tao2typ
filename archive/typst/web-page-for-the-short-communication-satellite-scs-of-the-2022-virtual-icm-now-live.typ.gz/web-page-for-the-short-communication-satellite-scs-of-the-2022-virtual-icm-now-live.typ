// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/
// Converted to Typst by tao2typ: "2026-10-14T15:20:44.818525+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Web page for the Short Communication Satellite (SCS) of the 2022 virtual ICM now live", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Web page for the Short Communication Satellite (SCS) of the 2022 virtual ICM now live")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 March 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/")[#text("https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a brief update to ")#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/")[#text("the previous post")]#text(". Gerhard Paseman and I have now ")#link("https://sites.google.com/view/scs-2022-call/")[#text("set up a web site")]#text(" for the Short Communication Satellite (SCS) for the virtual International Congress of Mathematicians (ICM), which will be an experimental independent online satellite event in which short communications on topics relevant to one or two of the ")#link("https://www.mathunion.org/fileadmin/IMU/Publications/CircularLetters/2019-2020/IMU%20AO%20CL%2012_2020_ICM2022_structure.pdf")[#text("sections of the ICM")]#text(" can be submitted, reviewed by peers, and (if appropriate for the SCS event) displayed in a virtual “poster room” during the Congress on July 6-14 (which, by the way, has recently released ")#link("https://www.mathunion.org/fileadmin/IMU/ICM2022/Program/Virtual_ICM_2022_Program_Schedule.pdf")[#text("its schedule")]#text(" and ")#link("https://www.mathunion.org/fileadmin/IMU/ICM2022/Program/Virtual_ICM_2022_Sectional_Schedule.pdf")[#text("list of speakers")]#text("). Our plan is to open the registration for this event on April 5, and start taking submissions on April 20; we are also currently accepting any expressions of interest in helping out with the event, for instance by serving as a reviewer. For more information about the event, please see the ")#link("https://sites.google.com/view/scs-2022-call/overview")[#text("overview page")]#text(", the ")#link("https://sites.google.com/view/scs-2022-call/guidelines")[#text("guidelines page")]#text(", and the ")#link("https://sites.google.com/view/scs-2022-call/faq")[#text("FAQ page")]#text(" of the web site. As viewers will see, the web site is still somewhat under construction, but will be updated as we move closer to the actual Congress.")

#text("The comments section of this post would be a suitable place to ask further questions about this event, or give any additional feedback.")

#text("UPDATE: for readers who have difficulty accessing the links above, here are backup copies of the ")#link("https://terrytao.wordpress.com/about/short-communications-satellite-overview/")[#text("overview page")]#text(" and ")#link("https://terrytao.wordpress.com/about/short-communications-satellite-registration/")[#text("guidelines page")]#text(".")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76e8de2c3cca167b1d0566f32da897b3d9298f211c78bb70f6678c9eeb20b503-c29d80bd4582cf9ef7198011436c89512fb43a8d195bc19af4bc46ebe3a7108a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jyotishraj thoudam")]], [#link("https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/#comment-642104")[#strong[#text("jyotishraj thoudam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2022")])]

#text("Dear Professor Tao,")#linebreak()#text(" I fully support the conference from the comfort of their homes. This is consistent with my theory if innateness the if we all stayed at home our quantum mechanical brains will be relaxed and much more efficient! Which Perelman went home and solved Poincare, which Andrew wiles was relaxed at home which is consistent with my two preprints I published on osf. Please look into it")#linebreak()#text(" 1. ")#link("https://osf.io/u847n")[#text("https://osf.io/u847n")]#text(" (A mixture of things, where innateness in learning is also major part)")#linebreak()#text(" 2. 5. Comfort and efficiency and productivity: ")#link("https://osf.io/psu6y/")[#text("https://osf.io/psu6y/")]

#text("I ama doctoral student at IIT Gandhinagar, working with Professor Dilip Sundaram. Please do comment on the articles. I’m also on wordpress, I was inspired by your site and made my own : jrthoudam.wordpress.com")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76e8de2c3cca167b1d0566f32da897b3d9298f211c78bb70f6678c9eeb20b503-c29d80bd4582cf9ef7198011436c89512fb43a8d195bc19af4bc46ebe3a7108a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jyotishraj thoudam")]], [#link("https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/#comment-642105")[#strong[#text("jyotishraj thoudam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2022")])]

#text("I am also work on a project to make people smarter and heal! “Let’s be alien’s project” : ")#link("https://jrthoudam.wpcomstaging.com/prjec/")[#text("https://jrthoudam.wpcomstaging.com/prjec/")]

#text("Join me!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/#comment-642125")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2022")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2022/03/31/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/194fd0f6b9b66d3f7a2a6e830a7690740de681ddd75b20f04f077dce4c8ecf0a-76040c278e74e5710f4a80658218ef03554e9725985bd3e80c3a9e156560fac4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mi Zhou")]], [#link("https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/#comment-642145")[#strong[#text("Mi Zhou")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2022")])]

#text("The rule of infinite twin prime")#linebreak()#text(" Write the twin primes up to 5000 in order")#linebreak()#text(" {3,5},{5,7},{11,13},{17,19},{29,31},{41,43},{59,61},{71,73},{101,103},{107,109},")#linebreak()#text(" {137,139},{149,151},{179,181},{191,193},{197,199},{227,229},{239,241},{269,271},{281,283},{311,313},{347,349},{419,421},{431,433},{461,463},{521,523},{569,571},{599,601},{617,619},{641,643},{659,661},{809,811},{821,823},{827,829},{857,859},{881,883},{1019,1021},{1031,1033},{1049,1051},{1061,1063},{1091,1093},{1151,1153},{1229,1231},{1277,1279},{1289,1291},{1301,1303},{1319,1321},{1427,1429},{1451,1453},{1481,1483},{1487,1489},{1607,1609},{1619,1621},{1667,1669},{1697,1699},{1721,1723},{1787,1789},{1871,1873},{1877,1879},{1931,1933},{1949,1951},{1997,1999},{2027,2029},{2081,2083},{2087,2089},{2111,2113},{2129,2131},{2141,2143},{2237,2239},{2267,2269},{2309,2311},{2339,2341},{2381,2383},{2549,2551},{2591,2593},{2657,2659},{2687,2689},{2711,2713},{2729,2731},{2789,2791},{2801,2803},{2969,2971},{2999,3001},{3119,3121}, {3167,3169},{3251,3253},{3257,3259},{3299,3301},{3329,3331},{3359,3361},{3371,3373},{3389,3391}{3461,3463},{3467,3469},{3527,3529},{3539,3541},{3557,3559},{3581,3583},{3671,3673},{3767,3769},{3821,3823},{3851,3853},{3917,3919},{3929,3931},{4001,4003},{4019,4021},{4049,4051},{4091,4093},{4127,4129},{4157,4159},{4217,4219},{4229,4231},{4241,4243},{4259,4261},{4271,4273},{4337,4339},{4421,4423},{4481,4483},{4517,4519},{4547,4549},{4637,4639},{4649,4651},{4721,4723},{4787,4789},{4799,4801},{4931,4933},{4967,4969}.")#linebreak()#text(" Then the sum➗2，")#linebreak()#text(" 4,6,12,18,30,42,60,72,102,108,138,150,180,192,198228,240,270,282,312,348,420,432,462,522,570,600,618,642,660,810,822,828,858,882,1020,1032,1050,1062,1092,1152,1230,1278,1290,1302,1320,1428,1452,1482,1488,1608,1620,1668,1698,1722,1788,1872,1878,1932,1950,1998,2028,2082,2088,2112,2130,2142,2238,2268,2310,2340,2382,2550,2592,2658,3300,3330,3360,3372,3390,3462,3468,3528,3540,3558,3582,3672,3768,3822,3852,3918,3930,4002,4020,4050,4092,4128,4158,4218,4230,4242,4260,4272,4338,4422,4482,4518,4548,4638,4650,4722,4788,4800,4932,4968.")#linebreak()#text(" Rule")#linebreak()#text(" 18=6+12,30=12+18,42=30+12,60=42+18,72=60+18,102=72+30,108=102+6, 138=108+30,150=138+12,180=150+30,192=180+12,198=192+6,228=198+30,240=228+12,270=240+30,282=270+12,312=282+30,348=240+108,420=348+72,432=420+12,462=432+30,522=462+60,570=462+108,600=570+30,618=600+18,642=600+42,660=642+18=618+42,810=660+150,822=810+12,828=822+6,858=828+30,882=822+60,1020=828+192,1032=1020+12,1050=1020+30,1062=1050+12,1092=1062+30,1152=1092+60,1230=1092+138,1278=858+420,1290=1278+12=1230+60,1302=1290+12,1320=1302+18,1428=1320+108,1452=1302+150,1482=1452+30,1488=1482+6,1608=180+1428,1620=1608+12,1668=1608+60,1698=1668+30，1722=1152+570=1620+102,")#linebreak()#text(" 1788=1608+180,1872=1722+150,1878=1872+6=1698+180,1932=1872+60,1950=1932+18,1998=1428+570,2028=1998+30,2082=1932+150,2088=2082+6,2112=2082+30,2130=2112+18,2142=2130+12,2238=2130+108,2268=2238+30,2310=2268+42,2340=2310+30,2382=2340+42,2550=2310+240,2592=2550+42,2658=2550+108,3300=642+2658,3330=3300+30,3360=3330+30,3372=3360+12,3390=3372+18,3462=72+3390,3468=3462+6,3528=3468+60,3540=3528+12,3558=3540+18,3582=3540+42,3672=282+3390,3768=3672+6,3822=150+3672,3852=3822+30,3918=3768+150,3930=3918+12,4002=3930+72,4020=4002+18,4050=4020+30,4092=4050+42,4128=4020+108,4158=4128+30,4218=4158+60,4230=4218+12,4242=4230+12,4260=4242+18,4272=4260+12,4338=4230+108,4422=4272+150,4482=4422+60,4518=180+4338,4548=4518+30,4638=420+4218,4650=4638+12,4722=4650+72,4788=4722+60,4800=4788+12,4932=282+4650,4968=4788+180.")#linebreak()#text(" According it，two twin prime can get third，the third get fourth，and become more and more，infinite")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/#comment-642322")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2022")])]

#text("What is this?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/#comment-642733")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2022")])]

#text("Guidelines link goes to an email registration template. More information is available on request by emailing ")#link("mailto:pre.scs.2022@gmail.com")[#text("pre.scs.2022@gmail.com")]#text(".")

#text("Gerhard, 2022.04.13.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/30/web-page-for-the-short-communication-satellite-scs-of-the-2022-virtual-icm-now-live/#comment-646057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2022")])]

#text("Useful info.")
]
