// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/
// Converted to Typst by tao2typ: "2026-10-14T16:38:10.001005+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Maryam Mirzakhani", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Maryam Mirzakhani")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 July 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/")[#text("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am totally stunned to learn that ")#link("https://en.wikipedia.org/wiki/Maryam_Mirzakhani")[#text("Maryam Mirzakhani")]#text(" ")#link("http://news.stanford.edu/2017/07/15/maryam-mirzakhani-stanford-mathematician-and-fields-medal-winner-dies/")[#text("died ")#strike[#text("today")]#text(" yesterday")]#text(", aged 40, after a severe recurrence of the cancer she had been fighting for several years. I had planned to email her some wishes for a speedy recovery after learning about the relapse yesterday; I still can’t fully believe that she didn’t make it.")

#text("My first encounter with Maryam was in 2010, when I was giving some ")#link("https://mrc.stanford.edu/events/annual-bergman-lecture-terence-tao")[#text("lectures at Stanford")]#text(" – one on Perelman’s proof of the Poincare conjecture, and another on random matrix theory. I remember a young woman sitting in the front who asked perceptive questions at the end of both talks; it was only afterwards that I learned that it was Mirzakhani. (I really wish I could remember exactly what the questions were, but I vaguely recall that she managed to put a nice dynamical systems interpretation on both of the topics of my talks.)")

#text("After she won the Fields medal in 2014 (as I posted about ")#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/")[#text("previously on this blog")]#text("), we corresponded for a while. The Fields medal is of course one of the highest honours one can receive in mathematics, and it clearly advances one’s career enormously; but it also comes with a huge initial burst of publicity, a marked increase in the number of responsibilities to the field one is requested to take on, and a strong expectation to serve as a public role model for mathematicians. As the first female recipient of the medal, and also the first to come from Iran, Maryam was experiencing these pressures to a far greater extent than previous medallists, while also raising a small daughter and fighting off cancer. I gave her what advice I could on these matters (mostly that it was acceptable – and in fact necessary – to say “no” to the vast majority of requests one receives).")

#text("Given all this, it is remarkable how productive she still was mathematically in the last few years. Perhaps her greatest recent achievement has been her “")#link("https://arxiv.org/abs/1502.05654")[#text("magic wand")]#text("” ")#link("https://arxiv.org/abs/1302.3320")[#text("theorem with Alex Eskin")]#text(", which is basically the analogue of the famous measure classification and orbit closure ")#link("https://en.wikipedia.org/wiki/Ratner%27s_theorems")[#text("theorems of Marina Ratner")]#text(", in the context of moduli spaces instead of unipotent flows on homogeneous spaces. (I discussed Ratner’s theorems in ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("this previous post")]#text(". By an unhappy coincidence, Ratner ")#link("https://math.berkeley.edu/about/history/in-memoriam")[#text("also passed away this month")]#text(", aged 78.) Ratner’s theorems are fundamentally important to any problem to which a homogeneous dynamical system can be associated (for instance, a special case of that theorem shows up in my work with Ben Green and Tamar Ziegler on the inverse conjecture for the Gowers norms, and on linear equations in primes), as it gives a good description of the equidistribution of any orbit of that system (if it is unipotently generated); and it seems the Eskin-Mirzakhani result will play a similar role in problems associated instead to moduli spaces. The remarkable proof of this result – which ")#link("https://arxiv.org/abs/1302.3320")[#text("now stands at over 200 pages")]#text(", after three years of revision and updating – uses almost all of the latest techniques that had been developed for homogeneous dynamics, and ingeniously adapts them to the more difficult setting of moduli spaces, in a manner that had not been dreamed of being possible only a few years earlier.")

#text("Maryam was an amazing mathematician and also a wonderful and humble human being, who was at the peak of her powers. Today was a huge loss for Maryam’s family and friends, as well as for mathematics.")

#text("[EDIT, Jul 16: New York times obituary ")#link("https://www.nytimes.com/2017/07/16/us/maryam-mirzakhani-dead.html")[#text("here")]#text(".]")

#text("[EDIT, Jul 18: New Yorker memorial ")#link("http://www.newyorker.com/tech/elements/maryam-mirzakhanis-pioneering-mathematical-legacy")[#text("here")]#text(".]")

#heading(level: 1)[#text("Comments (75)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-2/#comment-499105")[#strong[#text("“The beauty of mathematics shows itself to patient followers” — The work of Maryam Mirzakhani – Daniel Mathews")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2018")]

#text("[…] we did not know Maryam Mirzakhani personally, we were both fortunate to have met her. Like many others, we were impressed by her friendliness and enthusiasm. One of us (Dan) met her as a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-2/#comment-512338")[#strong[#text("RIP Professor Maryam Mirzakhani – Science on Google+")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2019")]

#text("[…] ")#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/")[#text("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-2/#comment-532110")[#strong[#text("Some published posts about Maryam Mirzakhani - Esmaeil ASLANI DIRANLOU")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2019")]

#text("[…] Amie Wilkinson describes Mirzakhani’s working style in this article in the NY Times. In a recent blog post, Terry Tao comments on how Mirzakhani was able to see disparate mathematical results through the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-2/#comment-575094")[#strong[#text("Some published posts about Maryam Mirzakhani | Diranlou")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2020")]

#text("[…] Amie Wilkinson describes Mirzakhani’s working style in this article in the NY Times. In a recent blog post, Terry Tao comments on how Mirzakhani was able to see disparate mathematical results through the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-2/#comment-686814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2024")])]

#text("She was an amazing human being.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71159caf7b9fa90414c751f4210c09a69b157904acd3d767b3a3d49a6eb9aead-9b53f60821e931e171c610b1f40ed8d8962e378d5b89007a46bbe8ce84295827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The demon king")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483781")[#strong[#text("The demon king")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("This is very sad news. Maryam and I had worked on very similar things throughout her career (her perhaps best-known result improves a result of mine), and she was a wonderful person. I first met her at Princeton when she was still a graduate student, and she gave perhaps the best talk I had ever seen a graduate student deliver. She will be very sorely missed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2017")])]

#text("I have reluctantly removed a number of comments on this blog (mainly in response to the parent of this comment) as per ")#link("https://terrytao.wordpress.com/about/")[#text("the blog rules")]#text(" that the discussion be “kept constructive, polite, and at least tangentially relevant to the topic at hand.” (Most of the deleted comments may be found through the wayback machine at ")#link("http://web.archive.org/web/20170719045905/https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani")[#text("this link")]#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483783")[#strong[#text("The unprecedented Best Seller! | My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")]

#text("[…] Maryam Mirzakhani […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b40c4da84890be40e8221df895390315289b546dce4d71ca446e10a16386ae8b-0d16a5d1d7bfd245a0f2c577e2fcea2e6e280a0f4c3c2147a831f4f29980d9c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Moe Bidgoli")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483786")[#strong[#text("Moe Bidgoli")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("I’m very sad about death of Prof. Maryam Mirzakhani(one of best Math genius of 21 century). In this time of loss and sadness, I wish cherished memories of her provide her family and friends with comfort and ease their sorrow.")

#text("With deepest sympathy,")

#text("~Moe Bidgoli/SVSU-CSIS Dept")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483787")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("I am just a math researcher who only knew her name as a first Iranian female to receive the Fields medal, and only saw her lecture on Youtube video. I did not know anything about her disease; I was very shocked to hear this news. I sincerely wish her family and all those who were close to her deep condolence and sympathy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483788")[#strong[#text("New top story on Hacker News: Terry Tao on Maryam Mirzakhani | The Internet Junkyard")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")]

#text("[…] Terry Tao on Maryam Mirzakhani 25 by slbenfica | 0 comments on Hacker News. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("“A student can see the beauty of mathematics if he/she is patient”")#linebreak()#text(" “یک دانشجو اگر صبر و پشتکار داشته باشد می تواند زیبایی ریاضیات را لمس کند”")#linebreak()#text(" A sentence from the great mathematician (the queen of the queen of science), Maryam Mirzakhani.")

#text("I read his valuable Persian book in number theory. Her style of book writing was excellent. We lost a valuable person.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b2b28875c52616a95179ed6acf3b066b28cf5fe3cdfc656bd3779f1d5f448e6-756da77589c6db146ada5bb279405a435ef0bdfe95567c28b02a65cb8fdb9164.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jemas Kumar")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483791")[#strong[#text("Jemas Kumar")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("Reblogged this on ")#link("https://beginner007.wordpress.com/2017/07/15/maryam-mirzakhani/")[#text("Jemas Kumar")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7380581d257ddc76f20de6046100d793795b681524e3b29eab31156737305842-6224ec5f03219e3a7407a04b8a3c22068fd9f52b2dfc746c066f41cb4b998cbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xinyi")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483793")[#strong[#text("Xinyi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("Reblogged this on ")#link("https://thexinyij.wordpress.com/2017/07/16/maryam-mirzakhani/")[#text("Xinyi Jiang's Blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0d840df398e1e0ba6cd8824aa93f33788feca67dd2b60c2bd84e36d95577a6-fed37c411e044d84a5729603d3e3b3fc56eb1f74fca57b2143c0a72122c2267d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Décès de Maryam Mirzakhani : les mathématiques en deuil | Coup d'Pouce")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483794")[#strong[#text("Décès de Maryam Mirzakhani : les mathématiques en deuil | Coup d'Pouce")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/")[#text("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebc5e69cd5166f26f26614e7e29da8d9eb8a02dd6dea218cc1dba76850040bb-b06986ed6ce5db2349d269fb9dec1fa3af35b61690af51b6364f83d0b70701a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of galoisian")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483795")[#strong[#text("galoisian")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("Reblogged this on ")#link("https://galoisian.wordpress.com/2017/07/15/maryam-mirzakhani/")[#text("galoisian")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483797")[#strong[#text("Obituaries: Maryam Mirzakhani (1977 – 2017) | Sketches, polytopes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")]

#text("[…] Mirzakhani died today. Terrance Tao writes about her. Elsewhere, Derrida – writing about Deleuze (I’ll Have to Wander All […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f40d973dfab05042ffe8032cc5d98ea97f9c45c9937e547a1693d4fcac0abb0-c9fd914613927993fd059ea1b17c1bb7b360ffcc481f5df673538e9b4cc89a17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sdf")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483798")[#strong[#text("sdf")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("Her recursion formula which I still think of as “science fiction mathematics”, —is one of the most astonishing and bizarre and even beautiful things I’ve seen. She really is gone much too early, it’s clear I think that she had a lot of great mathematics yet to contribute. And of course it will be so difficult for her husband and young daughter. Requiescat in pace.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7395dfddbc8a7a47f51209aef3cd46c4b952bc9263ed574a8736ce4317b8c471-50637e12ed53709451cec68f865271257d2cb5d769440de97320fe2327ba0c45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483809")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("Could you possibly provide a link to the paper with that formula?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71159caf7b9fa90414c751f4210c09a69b157904acd3d767b3a3d49a6eb9aead-9b53f60821e931e171c610b1f40ed8d8962e378d5b89007a46bbe8ce84295827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The demon king")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483850")[#strong[#text("The demon king")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("A survey can be found here: ")#link("https://arxiv.org/abs/1509.06880")[#text("https://arxiv.org/abs/1509.06880")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ba59a863a3dc638a814ae629f5e83d1d9aedca6ab8e391ea76f73afbd09b26a-800597a842cd7d566dc51b041c08ba9aebee15034329c6ce882355a2dbcf3ae3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephanie")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483803")[#strong[#text("Stephanie")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("Terry, do you have any information about the role, if any, that religion played in maryam’s life? It is absent from all discussions of her, and I’m wondering if it ever played a role for her.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71159caf7b9fa90414c751f4210c09a69b157904acd3d767b3a3d49a6eb9aead-9b53f60821e931e171c610b1f40ed8d8962e378d5b89007a46bbe8ce84295827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The demon king")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483843")[#strong[#text("The demon king")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("She was completely un-observant, as far as I could tell, and also a-political. The only way religion affected her life is that her daughter could not get Iranian citizenship because Maryam (her mother) and not her father was Iranian, and women are second-class citizens under the Iranian state religion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dee2bc0c7b6a04fb447f52eea897afd0798f465a9a6b6cd65acc37e626938426-21dca2f0037953d252c2f26a80f37eefb6610bd290fdb79a984a7c348f585d7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483898")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("I don’t know why do you want to comment about everything even about things with minimal knowledge about them?! Yes, Iran like other countries has its own rules about citizenship, sure I don’t like some of them but It doesn’t mean women are second-class citizens in Iran!! Just keep in your mind that Prof. Mirzakhani was a member of Iranian society. They fundament the National Organization for Development of Exceptional Talents (NODET) for both genders and Prof. Mirzakhani attended to the NODET’s high school and won the gold medal in the International Mathematical Olympiad two times. She obtained her BSc in mathematics (1999) from the Sharif University of Technology in Tehran as well. The country and society that more than 50% of universities students are female.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71159caf7b9fa90414c751f4210c09a69b157904acd3d767b3a3d49a6eb9aead-9b53f60821e931e171c610b1f40ed8d8962e378d5b89007a46bbe8ce84295827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The demon king")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483901")[#strong[#text("The demon king")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("I heard the story directly from her. She was sad about this. She never said anything publicly because (a) she was not the sort of person who would and (b) she had family in the Islamic Republic, and she did not want repercussions. That does not contradict what you say – perhaps you might want to look the nationality law (you sound like you might be read Persian reasonably well)- perhaps Maryam was mistaken?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483935")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("I think the New Yorker article (or maybe it was The Guardian) said something about this too. Iran’s government is discussing loosening its laws about travel/residence by non-Iranians who are married to Iranians, because of the trouble Mirzakhani’s husband and daughter had visiting Iran.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dee2bc0c7b6a04fb447f52eea897afd0798f465a9a6b6cd65acc37e626938426-21dca2f0037953d252c2f26a80f37eefb6610bd290fdb79a984a7c348f585d7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483960")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("As I said each country such as Iran has own laws about citizenship and other things and many of us including me are not agree with them but it is totally different with in Iran just because of this kind of laws “women are second-class citizens”. For example, we can say in US women are second-class citizens too because of the gender gap in pay.")

#text("On the other hand, your comment shows how much Iranian citizenship was important for Prof. Mirzakhani and she tried to give it to her daughter as well. Why does she want her daughter has a citizenship of a country that women are second-class citizens?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7afd39e4c35e010d382666365451f48be6c52275e6992fff00bda7aa160145a-d42c805c011c167d52d581df43a7afbdc3477eaafecc3f6ef633643bbdde3164.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Conan the Avenger")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483961")[#strong[#text("Conan the Avenger")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("Well, to answer your whitewashing comments below, here are some links for your delectation:")

#link("http://www.dw.com/en/iranian-women-are-second-class-citizens/a-16817367")[#text("http://www.dw.com/en/iranian-women-are-second-class-citizens/a-16817367")]

#link("http://www.huffingtonpost.com/kaveh-taheri/iranian-women-still-denie_b_9607430.html")[#text("http://www.huffingtonpost.com/kaveh-taheri/iranian-women-still-denie_b_9607430.html")]

#link("http://www.iranchamber.com/society/articles/legal_status_iranian_women.php")[#text("http://www.iranchamber.com/society/articles/legal_status_iranian_women.php")]

#text("So, apparently, others (especially Iranians) agree with The Demon King.")

#text("As for why Professor Mirzakhani would want citizenship for her daughter – maybe so she would not have problems visiting the grandparents? And maybe she (the late Professor Mirzakhani) a proud Persian (which is not the same as being proud of Iran’s current regime)?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dee2bc0c7b6a04fb447f52eea897afd0798f465a9a6b6cd65acc37e626938426-21dca2f0037953d252c2f26a80f37eefb6610bd290fdb79a984a7c348f585d7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483963")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("Ok women are second-class citizens in Iran like women in the USA, here are some links for your delectation as well:")

#link("http://www.huffingtonpost.com/samantha-paige-rosen/women-in-the-us-are-still-wage-gap_b_5018490.html")[#text("http://www.huffingtonpost.com/samantha-paige-rosen/women-in-the-us-are-still-wage-gap_b_5018490.html")]

#link("https://www.theodysseyonline.com/women-class-citizens")[#text("https://www.theodysseyonline.com/women-class-citizens")]

#link("http://www.aauw.org/research/the-simple-truth-about-the-gender-pay-gap/")[#text("http://www.aauw.org/research/the-simple-truth-about-the-gender-pay-gap/")]

#link("http://www.philly.com/philly/blogs/real-time/Carli-Lloyd-Women-feel-like-second-class-citizens.html")[#text("http://www.philly.com/philly/blogs/real-time/Carli-Lloyd-Women-feel-like-second-class-citizens.html")]

#link("http://www.ips-dc.org/african-americans-still-treated-second-class-citizens-law/")[#text("http://www.ips-dc.org/african-americans-still-treated-second-class-citizens-law/")]

#link("https://www.theguardian.com/commentisfree/2014/jul/16/women-second-class-citizens-pregnancy-criminals")[#text("https://www.theguardian.com/commentisfree/2014/jul/16/women-second-class-citizens-pregnancy-criminals")]

#link("https://rewire.news/article/2015/08/13/women-still-treated-like-second-class-workers/")[#text("https://rewire.news/article/2015/08/13/women-still-treated-like-second-class-workers/")]

#link("https://www.quora.com/Why-have-women-historically-been-treated-like-second-class-citizens")[#text("https://www.quora.com/Why-have-women-historically-been-treated-like-second-class-citizens")]

#text("believe me googling of above links took 1min and apparently, others (especially Americans) agree with women are second-class citizens in the USA.")

#text("I hope both countries can overcome this problem, I am totally and proudly in women side.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fcac66bd20c5b5452e4d795c26575be034fd0588fff66fff8d7dea708ebc34d7-d9695d4d9775d9d596393d4b19a185aaf0d5d66682d00502bca522d45bb022fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clarity")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483987")[#strong[#text("Clarity")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2017")])]

#text("dear Gender-Gap Anonymous,")

#text("“Second-class citizenship” usually refers to a situation where the laws are different (and worse) for one group than another. Or that the laws are officially the same but unofficially are applied differently (and more negatively) to that group.")

#text("In countries whose national laws are partly derived from Islamic law, women are second-class citizens under that definition. If Professor Mirzakhani had been male, she would have been able to get a visa for her daughter to enter Iran (among many other improvements to her legal rights).")

#text("In the USA, to the extent that there is any legal difference between women and men, it is always IN FAVOR of women. There is no “gender gap” that comes from the law (such as Iran’s law that women inherit half as much as men). In fact it is illegal in the USA for an employer to pay women differently than men for the same work.")

#text("There is a gender gap in the sense that men’s, on average, earn more money than women. The gap is much smaller after accounting for some of women’s own career choices (or other things under their own personal control). As far as I know it is still under debate in the economics literature whether any remaining gaps in wages are the result of gender-dependent decisions by the employers. It is also not clear if the gap survives when taking into account medical insurance costs (paid by employers) and pensions, which do not work the same for men and women.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-499952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2018")])]

#text("Maybe too late! But you have no idea about religion and its effect on Iranian nationality law. Many European countries did not recognize citizenship from mother side until 80’s. Connecting a citizenship rule to religion is highly unprofessional. Her religious observance is a personal matter but a very very close friend of her has said that she asked her husband to convert to Islam and this took him a year as he did not want to convert just for marrying her and eventually after he did, they got married. Of course, this has nothing to do with her contributions but talking without knowing much about her personal life and spreading misleading information is unethical.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("Iran has lost one of its best and brightest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b3ccfc96b04483b9b0fb1ab46566c6eaea6241eec6dcf8bf119e39938e11e77-fdafffadd2d76f9903091d578475cc3cb7422f4b2cf3e445bccc8c213d3bdea4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aokareem")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483806")[#strong[#text("aokareem")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("Reblogged this on ")#link("https://aokareem.wordpress.com/2017/07/16/maryam-mirzakhani/")[#text("Abdulafeez Abdulkareem")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/472166b7bd61c512c0326fce3f72b2dc53c3e34ac45c1c8bdd2a800342215ff7-fe58d490c5235a00df58ff30cb6d7c052db1f328a168872d29d7f6e6fa8ec631.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ek458")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483808")[#strong[#text("ek458")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("In life I observe a complex mechanism of statistical mechanics born, parameters authenticated with wave to defeat evil similarity and the reality in which every little detail has beautiful ratio randomness structure structures in a benign matter. People’s soul collectively speaks. This appears sensory harmonic mechanism also & dear Maryam has done beautiful work for this being. Her soul will live in many generations just like many other people that do we are. Many mathematicians must know that we see and hear and that our work matters greatly that we even think for the formation for our kind.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cb97baf01a8d8775dba0d42cd12419b2a87d303517e0d16d5416e74581fb516-12159c9e4bce1855eee77e6a392e93d0aadb07ea32098b52903e77dded9b9835.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bolin")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483810")[#strong[#text("Bolin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("What a sad news! The email which hasn’t been sent to her is still inmy draft box TAT")#linebreak()#text(" It’s hard to imagine how her daughter will grow up without her painting and “doughnut”…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483814")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("Dear Prof. Tao,")

#text("note that sadness may be transformed into action. If you can, help taking care of her poor daughter. Maybe she inherited her mother’s mathematical abilities.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71159caf7b9fa90414c751f4210c09a69b157904acd3d767b3a3d49a6eb9aead-9b53f60821e931e171c610b1f40ed8d8962e378d5b89007a46bbe8ce84295827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The demon king")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483845")[#strong[#text("The demon king")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("Her poor daughter has a very good father (also a mathematician/computer scientist), so I don;t think she needs to be a ward of the mathematical community.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d7ed4d3909159896ed9a2ff02177baf73df4dd3096bf8e69197f4c34ca78cf0-5f309dcc50700b4b518adf27335f1fae818790bda17feca14797abc1c3e40a05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of knightofmathematics")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483815")[#strong[#text("knightofmathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("She leaves behind a shining example for women in Mathematics and Science in general; a true milestone in the history of Mathematics. My sincere condolences to her family and her friends.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe466e998feb2d432f87ca82df57b11d73352def93ec6c7bfde2ef58f74c87cb-67e9f838a3c1fe177c5b620dea3177431cfbf843e518f5f5bf06fe8dff6748e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483816")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("Prof. Tao,")

#text("I’m a follower of your blog even though I’ve never understood most of the things as I’m not very good at mathematics. I’ve just scraped through my graduate mathematics courses. But nothing has reduced my interest and love towards this subject.")

#text("I’m shocked to know that Prof. Mirzakhani is no more. I hope her husband and her very young daughter find fortitude to overcome their sadness.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483818")[#strong[#text("Maryam Mirzakhani ist verstorben | Muster der Menschheit - Inspirationen zur Mathematik und zum Rechnen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")]

#text("[…] The Guardian Terry Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9147c5de63249b81e1fe1af4a7b7aaaf4324ee83b11f65fa821266418f500d81-f5c0a7d51262ff4e0bd453f6d0ecb2a94fef62b765607a919b3f82fe5150238c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of milton")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483819")[#strong[#text("milton")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("Es una noticia muy triste.")#linebreak()#text(" una perdida enorme para el mundo.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d2bb1291ff8aa2483ac6992cbe0347da6c4687b5908df582c74903d2d5d2c5f-a64f8ade1fda5a18d1ac08abfd516968e208e89dee397615b7bb372b1ce501d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vahan Stepanyan")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483823")[#strong[#text("Vahan Stepanyan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("I am so sorry to hear about professor Maryam’s untimely death. It is very sad for me to realize that some of us will never have chance to shorten the collaboration distance between us and her to 1. My deep condolences to her family.")

#text("Sincerely,")#linebreak()#text(" V. Stepanyan")#linebreak()#text(" NAS RA, MechIns")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec8375733c8e59aebc8b393cfcfcd6ab0a9c22071a03f94bf5401a0b01f8efd1-ba40e9c319ea3e04b92331fe16284269f910042a2bd216b517bceb199939a292.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dendisuhubdy")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483827")[#strong[#text("dendisuhubdy")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("Reblogged this on ")#link("http://suhubdy.com/blog/index.php/2017/07/16/maryam-mirzakhani/")[#text("The Secret Guild of Silicon Valley")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94d1bf3542565b05b0c280dc71af8d43ede0a43647ca8e1c06ff7ff0c3f1e357-4f34147e4cd01826d5981e5e537f47c44b071f7071d5e09c1008e29af56c0769.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483828")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("Thank you for your words about Mirzakhani. While I never had the chance to meet her, news of her death left me in shock. It is hard to process how unfair it is. I had the sense from colleagues that she was a wonderful and humble human being, as you say, in addition to her incredible research talent. We lost one of the best of us, at such a young age. I have her family in my thoughts today, but it will be the mathematician in me that mourns.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eab1f48d4ca9600d54a12bf80d1457da5ecaf9e46303e1805d698ef1a337bf8d-46df1c30c6df084fe28fad15baba240bcbf602c4a93141a4ff07143c53b4a3a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of emmittsmith")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483831")[#strong[#text("emmittsmith")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("World, opportunity missed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61c1c44ce8f9075a3c112416408adf2afe9b1431830dd9687ac595440facf5c2-de5a43ce38ee59c64d7ed94f997f3eecb4a031bfd9fcb5053b0e5c9989708420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil Nguyen")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483840")[#strong[#text("Phil Nguyen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2017")])]

#text("Could somebody tell me the time of birth of Mrs Maryam Mirzakha ?")#linebreak()#text(" Best Regards .")#linebreak()#text(" Phil Nguyen")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a2020196fcfd2211c48e89ba16cef68e31ad09192f6bc177a1279d5d18fd623-e563ada8d8a6bd5a07756c5538ff5a814b315bea68ac845274f08b65b9ced043.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kokou")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483875")[#strong[#text("Kokou")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("RIP Maryam Mirzakhani!")#linebreak()#text(" Happy Birthday to you Prof Terry Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/732d870d6471164f87db951660ec47f4597650598ade9f921d921fe0b7dd1a9e-9e3d0aaa5455ae3fc5a7bb720ab6cb1a3b5ba59a786475334b9537075aecd1d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sridhar")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483882")[#strong[#text("Sridhar")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("Very shocked sad to hear about passing away of Prof Mirzakhani")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483883")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("Although it is possibly a bit misplaced to say at this point, her death gives another example of how conventional cancer treatment regimes fail patients, even young persons at the height of their mental and physical powers. While I am not in any way informed about the details of her disease and death (and the latter is the usual way conventional medicine disinforms the patients, by the so called medical secret) I think I am entitled to pose certain questions and I think the public has all rights to know the exact details, and I mean the painful details of overblown surgery and baseless ad hoc concepts with little, and if at all then ‘statistics based’ ‘success regime’. I think her death, i.e. the very unexpected and sudden death, which gave noone, including her, a chance to come to terms with her dying, can only be a wake up call for conventional medicine, i.e. in its ignorance to alternative regimes, I mention Asian/Chinese medicine and i.e. the ketogenic diet, a regime which deserves much more financial support than is given now. I am not only sad, I am angry, angry at the way her death is used by western media for their political propaganda wars wrt Iran (‘the hijab’), angry at the way her death is presented as a ‘higher force’ or a ‘will of god’. If it is not now the moment where patients and persons close to her other patients speak out, when is the right moment then?")

#text("For the record: I am not only a random person with an esoteric grudge on ‘medical science’, I exeperienced the arrogance and, frankly speaking, disinformation methods and misleading views of western medicine wrt ‘alternative, i.e. nutrition based ways’ of treatment for a long part of my life having a chronic and allegedly ‘incurable’ autoimmune disease wrt which I do not follow the conventional medication regime anymore (for many reasons which would be too complicated to describe here) since more than 12 years now. According to ‘general nonsense’ I should be dead since exacty 12 years. But here I am writing this, and I will survive another 20 years, I assure you, except when ‘medical science’ ‘gets me’ otherwise. I am linking below one or two links wrt ketogenic diet and individual, while closely related cases, where a refusal of treatment led to longterm survival in situation with very meagre prospects in terms on conventional ‘whisdom’.")

#link("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3662856/")[#text("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3662856/")]

#link("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4726921/")[#text("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4726921/")]

#link("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4215472/")[#text("https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4215472/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483887")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("to explain my anger: in male dominated physics blogs one could read by now comments of the form ‘she was the weaker gender, and she could not overcome this’, something in that direction and one wonders: did career-centred patriarchic ‘research’ fail her? People who care about their publication lists more than for the survival of their patients? Ketogenic diets and related make no good papers, it is considered as ‘not scientific enough’. From her slow and deep pace in mathematics one knew she always was opposed to superficial science ‘successes’. But did exactly these fail to save her? A superficial understanding of science?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483974")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("the truth is that exactly her success in science did probably exclude the mere possibility of her not following the ‘accepted’ ways western science dealed with cancer, she would have risked her own scientific reputation. The mere wall of ignorance one hits here when one criticises disciplines of western ‘science’ and their effectiveness to deal with fundamental human conditions speaks volumes. Also of course, the arrogance of the healthy, nobody who never had a life threatening disease knows the ‘western scientific medicine’ from the inside. And cancer victims have no proper voices in our society also, i.e. not non-white cancer victims. Mirzakhani’s death gives ")#emph[#text("evidence")]#text(" to many blind spots in our societies, many failures and in the end the destructiveness and shallowness of patriarchic ‘reasoning’ in itself.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483889")[#strong[#text("Maryam Mirzakhani | Notiziole di .mau.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")]

#text("[…] Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483900")[#strong[#text("Shtetl-Optimized » Blog Archive » Three things")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")]

#text("[…] horrified to learn of the loss of Maryam Mirzakhani at age 40, after a battle with cancer (see here or here). Mirzakhani was a renowned mathematician at Stanford and the world’s first and so […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483903")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("I share the feeling of sadness and loss which is shared by all commentators from the very first comment and my heart goes for Maryam’s family and friends. I was also very sad to hear about Marina Ratner and my heart goes for her family and friends too. I find the reference, discussion and links to Maryam’s and Marina’s work as giving a little sense of comfort and I dont see any problem with us sometimes see some matters differently. I even found demon king’s reference to his own work that was improved by one of Mizrakhani’s famous contributions as endearing. Certainly, both Maryam and Marina were eminent mathematicians. Unfortunately, I did not know personally these great mathematicians but all my dynamic colleagues that knew both very well were great admirers of their personalities as much as their mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71159caf7b9fa90414c751f4210c09a69b157904acd3d767b3a3d49a6eb9aead-9b53f60821e931e171c610b1f40ed8d8962e378d5b89007a46bbe8ce84295827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The demon king")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483905")[#strong[#text("The demon king")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")])]

#text("Thank you, this is exactly in the right spirit, and I am sorry if my comments have proved contentious (they certainly were not meant to be).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483937")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("I never had any contact with Maryam Mirzakhani but I studied undergraduate real analysis under Prof. Ratner at Berkeley. I’m sad to hear that she has passed, even though it’s less of a blow when the person has lived a full life and reached a reasonably advanced age. Mirzakhani’s death was shocking by comparison.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d38f7d2a6395bd0e8e28934a520023dbd13e5d8fe7ac36c2569fc883249acc75-06364cccdd8f8ae76309369aacdf7a274b9f05abe817ea044cc2457ac5a29324.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harold Mortazavian")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483942")[#strong[#text("Harold Mortazavian")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("The world of mathematics and science mourns the passing of one of its greatest, Maryam Mirzakhani. This exceptional woman left us too early. Her untimely passing is an immense tragedy.")

#text("That chance and destiny should unite to take away from us this extraordinary woman of science and humanity at such an early age, confronts us all with a perplexing existential question that our feeble powers of reason fail to grasp. Destiny has formulated a problem for us that we must admit, we are unable to fully comprehend. We feel the tragedy of a great life cut short at its prime, a child left without a loving mother, a husband deprived of warmth and affection, students having lost their beloved professor, thousands among family, friends, and colleagues forever deprived of her presence, and the world of mathematics, science and culture having lost one of its treasures.")

#text("Maryam Mirzakhani was a mathematician of extraordinary ability. Her works were possessed of exceptional depth and great originality. She was and shall always remain to be a source of pride and honor for the world of science, especially for her compatriots all over the world. She traveled a long and arduous road to the heights of universal recognition. This great woman of science and humanity whom we mourn everywhere today, gave us so much of herself, with her unceasing strivings in pursuit of truth and beauty in the mathematical realm, with the purity of spirit that she brought to her worthy endeavors, with her remarkable sense of humility and with her humanity.")

#text("We owe this great woman, who is no longer with us, a debt of gratitude, for the intellectual treasures she left behind. Before such a great spirit one is seized by an overwhelming feeling of awe and reverence for the courage and dignity with which she faced death.")

#text("Like countless others, I am deeply saddened by her untimely passing. I offer my sincere condolences to her family.")

#text("Maryam Mirzakhani came to the end of her life, leaving behind monuments of thought and ingenuity, a loving family and many grieving hearts. She will always be remembered with love and with honor, and her legacy shall live on. She will have a permanent place in the history of mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cceee6befb53ac97c05e69d0c83a98ff3f363d3c299561a99763195cc17cd48-c2d3d2c0659a7e64e8b247ccbf9bd007624d615c8ff92c1135ed67f2b7872380.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("It’s great loss for mathematics.")#linebreak()#text(" And I have a little request. May I reprint and translate the article on my wechat Public account(it’s non-profit)? Just in order to let the article is available in mainland China, as you know that WordPress is shielded in Mainland China.")

#emph[#text("[Yes, this is fine – see the end of ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483965")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("What a sad!Many great hosres fell down in the race. Perelman turn down maths when he was 40, Grothendieck as well.In the past,Riemann died when he was 39. Oop, human beings are very small to the universe. I admit that Western is better than China in science but the treatment in the cancer,China does not have opponent,China does not need any tablet of medicine, I bet 1000 year later more science never can prove and understand this. If all you understand this , you will know where Pro.Tao’s intelligence come from, he does not do maths with brain as the other mathematician.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483981")[#strong[#text("Maryam Mirzakhani | RSPhotogrammetry Q&A site creation")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")]

#text("[…] Source: Maryam Mirzakhani […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ef96a8463bee37ab1882329b4fe87022215c6ff305c72be48c18b3a1395f189-de762990af54a68ef0ec01c32b4946eeb262fc21a69a58225d6895ae823f2528.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Whewell’s Gazette: Year 3, Vol. #48 | Whewell's Ghost")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-483993")[#strong[#text("Whewell’s Gazette: Year 3, Vol. #48 | Whewell's Ghost")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2017")])]

#text("[…] Terence Tao: Maryam Mirzakhani […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9fe37471f7a934331c4386edf57b5e65a3052f8c3f71b87ae875149b94be71b-20c43104ab6bcb2bd1fdac2268f5abe6c570abc709b9f0b4116fc5b9f2464213.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SH")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484003")[#strong[#text("SH")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2017")])]

#link("https://www.facebook.com/SIGSatUCI/")[#text("https://www.facebook.com/SIGSatUCI/")]

#text("Translation via google scholar:")

#text("Sharif University of Technology in Southern California (SUTA):")#linebreak()#text(" Celebrating the 40th Anniversary of the Life of the Lady of the World of Mathematics, Dr. Maryam Mirzakhani")#linebreak()#text(" Time: Sunday, July 23, 2017 – 11am to 1am")#linebreak()#text(" Location: University of California at Irvine (UCI), Hall of Physical Science Speeches PSLH 100")#linebreak()#text(" Address: Physical Sciences Lecture Hall, Irvine, CA 92617")#linebreak()#text(" Phone: (949) 824-5128")#linebreak()#text(" speakers:")#linebreak()#text(" Cumrun Vafa")#linebreak()#text(" Curtis McMullen")#linebreak()#text(" Firooz Naderi")#linebreak()#text(" Ali Nayiri")#linebreak()#text(" Roia Bhashti")#linebreak()#text(" Mehdi Hatamian")#linebreak()#text(" Heghir Rahmanadad")#linebreak()#text(" Mahdi Yahyanejad")#linebreak()#text(" Hamid Hezari")#linebreak()#text(" And a group of friends and friends Maryam Mirzakhani.")

#text("Please contact as you can.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9fe37471f7a934331c4386edf57b5e65a3052f8c3f71b87ae875149b94be71b-20c43104ab6bcb2bd1fdac2268f5abe6c570abc709b9f0b4116fc5b9f2464213.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SH")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484092")[#strong[#text("SH")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2017")])]

#text("Looks like this event was cancelled, according to the video below.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484076")[#strong[#text("Friday links: women in science x 5, and SO MUCH MOAR | Dynamic Ecology")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2017")]

#text("[…] Thank goodness for her having a different teacher in her second year! And the article goes on to describe how her high school principal encouraged her to pursue math competitions, even though the Iranian team had never had a girl on it. And here’s a short (<3 minute) video where she describes her work. She was clearly an amazing person and mathematician, and it’s so sad that she died so young. (Jeremy adds: more recollections of Mirzakhani here.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484091")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2017")])]

#text("A message by Maryam’s father and husband at her funeral regarding her memorial. Skip to the other half for the English announcement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c9212113c6122b195d2afb201ca36454e52a34451a943cd1743f4fd936939ae-3ccd274bf1531e60332058013400f6966c0bc21b8323181629460e0e9b911118.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of j")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-491007")[#strong[#text("j")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2018")])]

#text("I did not understand but a few words but his Persian is amazing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484108")[#strong[#text("some published posts about Maryam Mirzakhani | Mathpresso")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2017")]

#text("[…] Amie Wilkinson describes Mirzakhani’s working style in this article in the NY Times. In a recent blog post, Terry Tao comments on how Mirzakhani was able to see disparate mathematical results through the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66cb3b299a9134aabe5fcbb9e137653f0d9d93fca3c1064f92c1b34871e34f5c-ddd728813dc591888c940c7b451016f614deb5824a0d9914d1cb54999c15103f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of scriberedefined")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484199")[#strong[#text("scriberedefined")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2017")])]

#text("You write very well. Thanks for sharing your thoughts and opinions on a very memorable woman. Thanks! Looking forward to reading more! :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484339")[#strong[#text("Maryam Mirzakhani, 1977–2017 | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2017")]

#text("[…] Fields Medal in 2014. We and the whole community are grieving after losing her to breast cancer two weeks ago. She made several breakthroughs in the geometric understanding of dynamical systems. Who knows […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484427")[#strong[#text("মাৰিয়াম মিৰ্জাখানী - Gonit Sora: Assamese")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2017")]

#text("[…] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-484450")[#strong[#text("Mirzakhani 1977-2017 | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2017")]

#text("[…] 8. Maryam Mirzakhani | What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-486401")[#strong[#text("Friendship and Sesame, Maryam and Marina, Israel and Iran | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2017")]

#text("[…] Ratner and Maryam Mirzakhani Explored a Universe in Motion. (See also this HUJI memorial page and this post on Terry Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bbbc4a66beb9e6fd3798d08968c8b026cd78677f07ae0066cef260de326d6fc-354013953ff785002bcffe4b3e73cafc9565b0a98b8435f65d3e5076ec78f86c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hans")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-486633")[#strong[#text("Hans")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2017")])]

#text("The fact is able people should not leave their home countries but should use those talents to improve their own country. Also achievements on home soil alone have nationalistic value. Chinese, Indians and Iranians leave their countries for white man countries and cringe with pleasure when the white man pats them on the back and tells them what smart boys they ate. Sorry I see a failure of patriotism and sel respect here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of No, \"Hans\"")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-486664")[#strong[#text("No, \"Hans\"")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2017")])]

#text("Please take your profound ignorance, jingoism, and hatred somewhere else.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bbbc4a66beb9e6fd3798d08968c8b026cd78677f07ae0066cef260de326d6fc-354013953ff785002bcffe4b3e73cafc9565b0a98b8435f65d3e5076ec78f86c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hans")]], [#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-486634")[#strong[#text("Hans")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2017")])]

#text("‘Ate’ is ‘are’. ‘Sel’ is self.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/15/maryam-mirzakhani/comment-page-1/#comment-497777")[#strong[#text("some published posts about Maryam Mirzakhani – Pangan 7")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2018")]

#text("[…] Amie Wilkinson describes Mirzakhani’s working style in this article in the NY Times. In a recent blog post, Terry Tao comments on how Mirzakhani was able to see disparate mathematical results through the […]")
]
