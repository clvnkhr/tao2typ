// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/
// Converted to Typst by tao2typ: "2026-10-17T11:00:58.684094+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "SAIR Open Math OS released", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("SAIR Open Math OS released")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/")[#text("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-17 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As ")#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/")[#text("announced a few weeks ago")]#text(", the ")#link("https://www.openmathmodel.org/")[#text("SAIR Open Math OS is now soft launched")]#text(". It offers services and web interfaces similar to frontier AI models, though currently we are hosting existing open math models (DeepSeek V4.1 Flash, Kimi K3, and GLM 5.3 Flash) which are roughly a year or so behind the current frontier models in capability; so not able to perform “one-shot problem solving” of the type we have heard frequently about in recent months, but capable enough for many other useful mathematical tasks, such as medium-sized Lean formalization, or summarizing or discussing a mathematical argument or topic. Here is a typical screenshot:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/10/image-1.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2026/10/image-1.png?w=1024")[Original image]]]]
]

#text("We are in the process of gathering partners to develop a more fine-tuned model for mathematics by post-training on an existing open model; see this ")#link("https://www.openmathmodel.org/initiative/")[#text("link")]#text(" (and the associated ")#link("https://zulip.sair.foundation/#narrow/channel/27-Open-Math-Model")[#text("Zulip channel")]#text(") for more details.")

#text("One feature of our model is the emphasis on team accounts rather than individual accounts, in which members of a team see each other’s prompts. We believe this could be a better format for using these tools for collaborative projects.")

#text("We are hosting these models using donated compute, and are in the process of granting free accounts to requesters from academic institutions. We may need to adjust the allocation of compute depending on demand and on future donations, but we will try to make the models available to as many users as possible.")

#text("This is still a very early version of the model; we accelerated our timeline for first release due to the increased demand for open models from the community. We will continue developing the model and accompanying features and welcome feedback, for instance at the ")#link("https://zulip.sair.foundation/#narrow/channel/27-Open-Math-Model")[#text("Zulip channel")]#text(".")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698202")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Excellent! Probably this will not be useful in the near future. But I do suspect the current LLM boom to slow down at some point at least as far as mathematics is concerned, and then open source models will catch up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698205")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Do you eventually plan on pretraining a model from scratch?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e5fc495012e60bfd7d5e0a8bfc39710d051d12dd59982c6b38a271c6d60df92-b33fab3401254ed08ad3461e00c4a1a5da0b8be8d483cc683cb8b86f486107f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shacharlovett")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698206")[#strong[#text("shacharlovett")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Very nice, I want to experiment with it. What is the process of getting access?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fdc94626fb3f1d14afd48c0102842980e6950c98012c6b5b6a51777f7788402-4fc6cc3b74447582f22292ac2d32af7fbad470059d4ca65937d23b2547ea7499.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698212")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("One question: like most mathematicians, I have multiple projects that I work on with a variety of subsets of people. (Typically I’ll be working in a general area with a group of 3 to 5 people, and the collaboration would cover multiple papers.) Is the model to apply for a separate team account for each of these collaborations?")

#text("Currently I just applied for an account for myself, for the few things that I’m not (currently) working with anyone else on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698222")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Why not offer a downloadable version that can be run locally instead of having it on the cloud?")
]
