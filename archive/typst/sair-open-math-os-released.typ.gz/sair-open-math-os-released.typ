// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/
// Converted to Typst by tao2typ: "2026-10-24T11:19:29.980321+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "SAIR Open Math OS released", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("SAIR Open Math OS released")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/")[#text("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-24 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As ")#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/")[#text("announced a few weeks ago")]#text(", the ")#link("https://www.openmathmodel.org/")[#text("SAIR Open Math OS is now soft launched")]#text(". It offers services and web interfaces similar to frontier AI models, though currently we are hosting existing open math models (DeepSeek V4.1 Flash, Kimi K3, and GLM 5.3 Flash) which are roughly a year or so behind the current frontier models in capability; so not able to perform “one-shot problem solving” of the type we have heard frequently about in recent months, but capable enough for many other useful mathematical tasks, such as medium-sized Lean formalization, or summarizing or discussing a mathematical argument or topic. Here is a typical screenshot:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/10/image-1.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2026/10/image-1.png?w=1024")[Original image]]]]
]

#text("We are in the process of gathering partners to develop a more fine-tuned model for mathematics by post-training on an existing open model; see this ")#link("https://www.openmathmodel.org/initiative/")[#text("link")]#text(" (and the associated ")#link("https://zulip.sair.foundation/#narrow/channel/27-Open-Math-Model")[#text("Zulip channel")]#text(") for more details.")

#text("One feature of our model is the emphasis on team accounts rather than individual accounts, in which members of a team see each other’s prompts. We believe this could be a better format for using these tools for collaborative projects.")

#text("We are hosting these models using donated compute, and are in the process of granting free accounts to requesters from academic institutions. We may need to adjust the allocation of compute depending on demand and on future donations, but we will try to make the models available to as many users as possible.")

#text("This is still a very early version of the model; we accelerated our timeline for first release due to the increased demand for open models from the community. We will continue developing the model and accompanying features and welcome feedback, for instance at the ")#link("https://zulip.sair.foundation/#narrow/channel/27-Open-Math-Model")[#text("Zulip channel")]#text(".")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698202")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Excellent! Probably this will not be useful in the near future. But I do suspect the current LLM boom to slow down at some point at least as far as mathematics is concerned, and then open source models will catch up.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698271")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Can I ask why one should expect this? When you say slow down you mean LLMs in general will not progress as quickly, or that the gap between open source and the current frontier grow smaller? And why would something with unlimited RLVR capability slow down?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698352")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I mean, there are only so many orders of magnitude in the universe, so the current LLM boom will slow down at some point. It’s been working for a few years. Where it stops no one knows.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698205")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Do you eventually plan on pretraining a model from scratch?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698305")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Pretraining is a very long-term goal for our foundation, it would require significantly more compute than we plan to fundraise for. Our near-term goal is to focus on post-training an existing open-source model with data of a mathematical nature to fine tune its capabilities at mathematical tasks (which will include some problem-solving tasks, although this will not be our primary focus).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e5fc495012e60bfd7d5e0a8bfc39710d051d12dd59982c6b38a271c6d60df92-b33fab3401254ed08ad3461e00c4a1a5da0b8be8d483cc683cb8b86f486107f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shacharlovett")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698206")[#strong[#text("shacharlovett")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Very nice, I want to experiment with it. What is the process of getting access?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fdc94626fb3f1d14afd48c0102842980e6950c98012c6b5b6a51777f7788402-4fc6cc3b74447582f22292ac2d32af7fbad470059d4ca65937d23b2547ea7499.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698212")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("One question: like most mathematicians, I have multiple projects that I work on with a variety of subsets of people. (Typically I’ll be working in a general area with a group of 3 to 5 people, and the collaboration would cover multiple papers.) Is the model to apply for a separate team account for each of these collaborations?")

#text("Currently I just applied for an account for myself, for the few things that I’m not (currently) working with anyone else on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698307")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("One would need separate team accounts if one wanted to avoid sharing the prompts from one team with another. We are still in the process of deciding what limits to place on account creation to prevent a small number of users absorbing all the available donated compute that we have, in particular we may place a cap on how many accounts a given institution or user can have, but we would like to first collect some usage data before finalizing our policies in this regard.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698222")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Why not offer a downloadable version that can be run locally instead of having it on the cloud?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fdc94626fb3f1d14afd48c0102842980e6950c98012c6b5b6a51777f7788402-4fc6cc3b74447582f22292ac2d32af7fbad470059d4ca65937d23b2547ea7499.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698257")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("The hardware requirements for at least Kimi K3 are extremely prohibitive; running that model locally is not going to be an option for almost anyone.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d82859f192cc05a1e53c3c53ca7a12aa946b8dbc8cc027a4d38f736ea03b57e-e9c56ae9ee96e590c09b1719cfd6621fda9597919243af67d619570cd6444530.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Titi")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698245")[#strong[#text("Titi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Why not allowing for local use ? Seems like a strange take…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698261")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Does it say somewhere that local use will not be allowed?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("I suppose because this initiative is very new and you cannot do everything at once. They say that the models will be open weight and the inference code open source::")

#link("https://www.openmathmodel.org/initiative/")[#text("https://www.openmathmodel.org/initiative/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f162ef28adb902780b83fa038e272d068c6de5204ad951e33587ffd4274c0f53-62f4354cb9f4125d6c29d29d2c390f08b2a67dfad27a82846d98dda29df4d134.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Coelho")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698276")[#strong[#text("Terence Coelho")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("I’m a little concerned that there isn’t any mention of safety/alignment. I expect training for a combination of math capability and the ability to automate AI research to boost math capabilities of the next model to be the kind of target that is natural to shoot for with a small team that want to catch up to the frontier in math capabilities, but can go very very wrong without extremely careful safety work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698453")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("We are still in the process of setting up the various subcommittees that will handle various aspects of the training, data gathering, evaluations, etc., of our future model but we definitely plan to make various safety assessments as part of our evaluation. (Hopefully experts in these areas will offer their services to that subcommittee.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698342")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Currently, everyone I know in my field works in fluid teams: 1 to 5 colleagues collaborating on a ")#emph[#text("project")]#text(" until it yields a paper. Then team boundaries shift for the next project.")

#text("What would better suit many mathematicians is having individual accounts alongside team projects. Sharing prompts, conversations, and outputs within a project is extremely useful, but this needs to stay at the project level to preserve our fluid, bottom-up workflow.")

#text("It is quite unsettling that the plan here seems so different—expecting researchers to commit to a fixed team, with a single person applying for everyone and becoming the official “boss.” It feels top-down and disturbing. Is it understood that our relatively horizontal model—which accounts for 90% of the joy at work—is over? I don’t see why it should be discouraged, nor why the arrival of AI should change that (and I’ve seen AI as a good thing for math so far).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d58c699650b8ea50e1b7bbb0f5a972a09e9e05306182c1fb7be81d92f6356c0-901ac2e68d850b6cf310aad3e16fa3f84e395ad0e35b8b5fe400a7d05c1c91a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nurma")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698345")[#strong[#text("Nurma")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("congrats on the release! we’d love to help improve autoformalization with our rl environments")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2125425025cd37626fb7551e942307164ecda3b097a28475194fdd228937ac84-ea831c0e5110b1f0e6f94046aec083ce050c1a0d71775986fd88cd396850a714.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rmahadevan1972")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698600")[#strong[#text("rmahadevan1972")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("i am a working mathematician. i am just interested in using ai to explore my ideas. i tried signing up but to start using it seems you need to belong to a team. i can join an existing team but the search doesn’t show me any. so do i have to create a team to start using? i already proposed a team after signing up with my google account. on second thoughts i thought it be better to sign up with my institutional mail. i still haven’t asked to create a team while i await an answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698655")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Could you please clarify how to get access and start using it? It’s all super vague. What’s the point of an open math os if essentially one cannot sign up and start using it?")

#text("I am not asking for a free service. I would be happy to pay a reasonable monthly fee for using it, as long as its open, keeps its promises, AND I can actually go there, sign up, and start using it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fdc94626fb3f1d14afd48c0102842980e6950c98012c6b5b6a51777f7788402-4fc6cc3b74447582f22292ac2d32af7fbad470059d4ca65937d23b2547ea7499.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/comment-page-1/#comment-698671")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("The short answer is going to be that you apply for a team, perhaps as an individual, and then wait. I’m sure they are thinking about the model, but that’s the current status.")

#text("I did myself apply in this way, and created a team (initially one-person). But your question about giving them money is good: I do have money I’d be happy to send the way of the foundation, but there doesn’t seem to be a current mechanism for that.")
]
]
