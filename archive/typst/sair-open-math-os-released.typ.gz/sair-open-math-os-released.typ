// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/
// Converted to Typst by tao2typ: "2026-11-12T15:28:10.019520+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "SAIR Open Math OS released", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("SAIR Open Math OS released")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/")[#text("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-12 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As ")#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/")[#text("announced a few weeks ago")]#text(", the ")#link("https://www.openmathmodel.org/")[#text("SAIR Open Math OS is now soft launched")]#text(". It offers services and web interfaces similar to frontier AI models, though currently we are hosting existing open math models (DeepSeek V4.1 Flash, Kimi K3, and GLM 5.3 Flash) which are roughly a year or so behind the current frontier models in capability; so not able to perform “one-shot problem solving” of the type we have heard frequently about in recent months, but capable enough for many other useful mathematical tasks, such as medium-sized Lean formalization, or summarizing or discussing a mathematical argument or topic. Here is a typical screenshot:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/10/image-1.png")[#image("../assets/bb4982ccffac6f777276caffb6a4a97468b7caea5d547974d7fcd31b6cfb3bab-ee401f021e917ccffa9b17f5cff091c783681f51e59060fa33641efeac33a459.png", width: 90%)]
]

#text("We are in the process of gathering partners to develop a more fine-tuned model for mathematics by post-training on an existing open model; see this ")#link("https://www.openmathmodel.org/initiative/")[#text("link")]#text(" (and the associated ")#link("https://zulip.sair.foundation/#narrow/channel/27-Open-Math-Model")[#text("Zulip channel")]#text(") for more details.")

#text("One feature of our model is the emphasis on team accounts rather than individual accounts, in which members of a team see each other’s prompts. We believe this could be a better format for using these tools for collaborative projects.")

#text("We are hosting these models using donated compute, and are in the process of granting free accounts to requesters from academic institutions. We may need to adjust the allocation of compute depending on demand and on future donations, but we will try to make the models available to as many users as possible.")

#text("This is still a very early version of the model; we accelerated our timeline for first release due to the increased demand for open models from the community. We will continue developing the model and accompanying features and welcome feedback, for instance at the ")#link("https://zulip.sair.foundation/#narrow/channel/27-Open-Math-Model")[#text("Zulip channel")]#text(".")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698202")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Excellent! Probably this will not be useful in the near future. But I do suspect the current LLM boom to slow down at some point at least as far as mathematics is concerned, and then open source models will catch up.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Can I ask why one should expect this? When you say slow down you mean LLMs in general will not progress as quickly, or that the gap between open source and the current frontier grow smaller? And why would something with unlimited RLVR capability slow down?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698352")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I mean, there are only so many orders of magnitude in the universe, so the current LLM boom will slow down at some point. It’s been working for a few years. Where it stops no one knows.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Do you eventually plan on pretraining a model from scratch?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698305")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Pretraining is a very long-term goal for our foundation, it would require significantly more compute than we plan to fundraise for. Our near-term goal is to focus on post-training an existing open-source model with data of a mathematical nature to fine tune its capabilities at mathematical tasks (which will include some problem-solving tasks, although this will not be our primary focus).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3558065c4103e7e732a1bb3b6edda1fdcdc82fb43bee3899cc8496acc3d604d4-cd9eed67c4ddc6a234700458a70c75a6f582299c348e014ea108ed72d3c8a0fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shacharlovett")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698206")[#strong[#text("shacharlovett")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Very nice, I want to experiment with it. What is the process of getting access?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caa6060ccc2474b57fad1cfe6a3ccf9c17594d61aa2f0e45e09a0f04f102c703-b988e065528f490b921b676de05e1141159fe8e86ae6ec76a35f69ff1261257e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698212")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("One question: like most mathematicians, I have multiple projects that I work on with a variety of subsets of people. (Typically I’ll be working in a general area with a group of 3 to 5 people, and the collaboration would cover multiple papers.) Is the model to apply for a separate team account for each of these collaborations?")

#text("Currently I just applied for an account for myself, for the few things that I’m not (currently) working with anyone else on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698307")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("One would need separate team accounts if one wanted to avoid sharing the prompts from one team with another. We are still in the process of deciding what limits to place on account creation to prevent a small number of users absorbing all the available donated compute that we have, in particular we may place a cap on how many accounts a given institution or user can have, but we would like to first collect some usage data before finalizing our policies in this regard.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698222")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2026")])]

#text("Why not offer a downloadable version that can be run locally instead of having it on the cloud?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caa6060ccc2474b57fad1cfe6a3ccf9c17594d61aa2f0e45e09a0f04f102c703-b988e065528f490b921b676de05e1141159fe8e86ae6ec76a35f69ff1261257e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698257")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("The hardware requirements for at least Kimi K3 are extremely prohibitive; running that model locally is not going to be an option for almost anyone.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87fc86f07930a91dcee13cf867ca3e703f35dd97c6faac9d11d7ccd4972cbadd-a8dbc898cae02481143f53786e7ca3da6afa23e3e43b99cfd165eda0f88b1c59.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Titi")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698245")[#strong[#text("Titi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Why not allowing for local use ? Seems like a strange take…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("Does it say somewhere that local use will not be allowed?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("I suppose because this initiative is very new and you cannot do everything at once. They say that the models will be open weight and the inference code open source::")

#link("https://www.openmathmodel.org/initiative/")[#text("https://www.openmathmodel.org/initiative/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5f744236bd7a1ab19fa995b9b4f1f4fc528a8d322ae8810e4160b08d5e21318-af1b441ad7568b55056eb6b43956b766ed4db9adc8c5549cab48bfa48a69650f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Coelho")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698276")[#strong[#text("Terence Coelho")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("I’m a little concerned that there isn’t any mention of safety/alignment. I expect training for a combination of math capability and the ability to automate AI research to boost math capabilities of the next model to be the kind of target that is natural to shoot for with a small team that want to catch up to the frontier in math capabilities, but can go very very wrong without extremely careful safety work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698453")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("We are still in the process of setting up the various subcommittees that will handle various aspects of the training, data gathering, evaluations, etc., of our future model but we definitely plan to make various safety assessments as part of our evaluation. (Hopefully experts in these areas will offer their services to that subcommittee.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698342")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Currently, everyone I know in my field works in fluid teams: 1 to 5 colleagues collaborating on a ")#emph[#text("project")]#text(" until it yields a paper. Then team boundaries shift for the next project.")

#text("What would better suit many mathematicians is having individual accounts alongside team projects. Sharing prompts, conversations, and outputs within a project is extremely useful, but this needs to stay at the project level to preserve our fluid, bottom-up workflow.")

#text("It is quite unsettling that the plan here seems so different—expecting researchers to commit to a fixed team, with a single person applying for everyone and becoming the official “boss.” It feels top-down and disturbing. Is it understood that our relatively horizontal model—which accounts for 90% of the joy at work—is over? I don’t see why it should be discouraged, nor why the arrival of AI should change that (and I’ve seen AI as a good thing for math so far).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/774631bcf4f1943dbe07d5acf35fbf09046f912d0070340d23a2220051573c33-9fe2345099234b42c0d35087c4a1ad07698eef23198168fae95e49a59084aeeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nurma")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698345")[#strong[#text("Nurma")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("congrats on the release! we’d love to help improve autoformalization with our rl environments")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/561937659d7a346524bba5b286fa720b70b9051d343d2bb9738141ee1e00fec5-e54d02d34f63f0473abb0b65c8def762d6bfbdffc468f1c5b5e233a37bbd188f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rmahadevan1972")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698600")[#strong[#text("rmahadevan1972")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("i am a working mathematician. i am just interested in using ai to explore my ideas. i tried signing up but to start using it seems you need to belong to a team. i can join an existing team but the search doesn’t show me any. so do i have to create a team to start using? i already proposed a team after signing up with my google account. on second thoughts i thought it be better to sign up with my institutional mail. i still haven’t asked to create a team while i await an answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698655")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Could you please clarify how to get access and start using it? It’s all super vague. What’s the point of an open math os if essentially one cannot sign up and start using it?")

#text("I am not asking for a free service. I would be happy to pay a reasonable monthly fee for using it, as long as its open, keeps its promises, AND I can actually go there, sign up, and start using it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caa6060ccc2474b57fad1cfe6a3ccf9c17594d61aa2f0e45e09a0f04f102c703-b988e065528f490b921b676de05e1141159fe8e86ae6ec76a35f69ff1261257e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698671")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("The short answer is going to be that you apply for a team, perhaps as an individual, and then wait. I’m sure they are thinking about the model, but that’s the current status.")

#text("I did myself apply in this way, and created a team (initially one-person). But your question about giving them money is good: I do have money I’d be happy to send the way of the foundation, but there doesn’t seem to be a current mechanism for that.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70ddeab5d9c6b2e56e1efcf9292e8fcbc41ed5b24fd02e8d5d5ad3f45aea0aa2-82fd0c9b2ddeff65cfa6d5c510a1729856196e9a893f1cb183266110d5a6b697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-698714")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Is this an Operating System I can install at home, or is does it run on, say, a “Cloud Collaboration Server” that users “log in” to, with an app?")

#text("On the site, AI agents are referred to as collaborators – it seems metaphorical but it’s possible that the AI agents are expected to have ownership rights and authorship attribution. It’s starting to be risky to assume we’re all at the same point on the slope toward AI “personhood”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a013b693767cae6ec20ecad7577bdc8467e6da38e5c87ff9074624b99539abc-db32dfc124f40eb75f01091e576cbec02efbab20e845f7ed22b3603009bb21f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Helluy")]], [#link("https://terrytao.wordpress.com/2026/10/16/sair-open-math-os-released/#comment-699358")[#strong[#text("Philippe Helluy")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2026")])]

#text("Many thanks for this excellent initiative. I tried it out for my recent work and found it very useful. This is a first step toward keeping research as open and public as possible. I also know that it has lifted the morale of some colleagues who were feeling discouraged by the wave of AI.")
]
