// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/15/mathematics-in-australia/
// Converted to Typst by tao2typ: "2026-10-14T15:16:46.561674+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematics in Australia", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematics in Australia")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/15/mathematics-in-australia/")[#text("https://terrytao.wordpress.com/2008/05/15/mathematics-in-australia/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As readers of this blog have no doubt noted, there has been a significant online response and discussion to the ")#link("https://terrytao.wordpress.com/support-usq-maths/")[#text("campaign to support mathematics at the University of Southern Queensland")]#text(" – thank you all, by the way, for your show of support on this matter! As many commenters noted, the issues here are not purely localised to USQ, but also touch on systemic issues regarding the funding, culture, and support for the university, and for mathematics and related sciences, in Australia.")

#text("Because of the level of interest in discussing these matters online, I (together with others in the Australian mathematical community) have begin a dedicated blog to these matters, entitled “")#link("http://austmaths.wordpress.com/")[#text("Mathematics in Australia")]#text("“. This blog will report on current events in Australian mathematics in general (ranging from education issues, to government policy, to mathematical activities and events, to crises such as those at USQ), be a repository for various reports, media articles, links, etc. relating to Australian mathematics, and be a forum for online discussion on these topics.")

#text("Currently, ")#link("http://austmaths.wordpress.com/")[#text("the new blog")]#text(" only has a handful of articles, including an ")#link("http://austmaths.wordpress.com/2008/05/16/an-update-on-mathematics-statistics-and-computing-at-usq/")[#text("update on the latest situation with the USQ crisis")]#text(", but there should be several more articles (from various authors) coming in shortly (including one involving a situation at the University of New England, which unfortunately shares some features in common with that at USQ). It is intended that there be a lively discussion of these topics, so if you have an interest in these issues, please don’t hesitate to participate. (In particular, if you have some news or information on Australian mathematics to share on that blog, or perhaps a suggestion for a future discussion topic, you can email me about it.)")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2008/05/15/mathematics-in-australia/#comment-29818")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("Dear Terry,")

#text("There are some voices in Israel advocating a change in Israeli universities in the direction of “market based” governance. The 2 months students strike last year and the 3 months professors strike this academic year are related to such initiatives. Often, the Australian reforms are mentioned as a “role model”. I was always skepical about the benefits from such initiatives and the story regarding Austrailian mathematics is quite telling.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ed81c2e3e7a0308c48e6c11eac2f23069e5397ba191899ae14adf927249c44a-1b6d973a1352711e7da8daeaa558cb767f2a64fe6efed261c6b81bc479cad157.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Serge")]], [#link("https://terrytao.wordpress.com/2008/05/15/mathematics-in-australia/#comment-29870")[#strong[#text("Serge")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2008")])]

#text("Hmm, coupled with poor situation with mathematics in Israel high schools the results of cutting math departments in universities should be hilarious. Someone think probably that too successful Israel high-tech is bad for moral or cause women to dress immodestly or something…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ajay")]], [#link("https://terrytao.wordpress.com/2008/05/15/mathematics-in-australia/#comment-29884")[#strong[#text("ajay")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("sir,")#linebreak()#text(" The problem you stated is not confined to Australia only, and i fear its global now.As a student in India i can see the situation is getting from bad to worse.")#linebreak()#text(" I think a big change in waiting and hope its fast otherwise we’ll lose control of it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/816627e3273303126f2d0e06a4fd82b23c5ec780d2c44a006e8efabce8b13c5b-1f123ca506b6eab67a2aee49e33206326d9ee3c892097c9ae875c37bdc393010.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Study In Australia")]], [#link("https://terrytao.wordpress.com/2008/05/15/mathematics-in-australia/#comment-30723")[#strong[#text("Study In Australia")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("I believe on what ajay said. It is not just in AUS that it happens. I just hope thing will be better… :) Thanks for the nice post…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f473a276d82d08a4bc5eedcbc33fa6e08d78fc3f4ff63ada30b829fb6c2115f7-3444f566791ba62c829dd3b44c6fdc4855a7948ab257782e07d6e327ba3a4c1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of reeta sharma")]], [#link("https://terrytao.wordpress.com/2008/05/15/mathematics-in-australia/#comment-32651")[#strong[#text("reeta sharma")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2008")])]

#text("i want teaching jobs for maths in australia. i am so passanate for teaching maths.")
]
