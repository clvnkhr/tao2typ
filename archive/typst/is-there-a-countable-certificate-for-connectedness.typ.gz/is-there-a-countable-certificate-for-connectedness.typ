// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/
// Converted to Typst by tao2typ: "2026-10-14T16:36:09.582991+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Is there a countable certificate for connectedness?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Is there a countable certificate for connectedness?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 April 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/")[#text("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In topology, a non-empty set ")#mi("{E}")#text(" is said to be ")#emph[#text("connected")]#text(" if cannot be decomposed into two nontrivial subsets that are both closed and open relative to ")#mi("{E}")#text(", and ")#emph[#text("path connected")]#text(" if any two points ")#mi("{x,y}")#text(" in ")#mi("{E}")#text(" can be connected by a path (i.e. there exists a continuous map ")#mi("{\\gamma: [0,1] \\rightarrow E}")#text(" with ")#mi("{\\gamma(0)=x}")#text(" and ")#mi("{\\gamma(1)=y}")#text(").")

#text("Path-connected sets are always connected, but the converse is not true, even in the model case of compact subsets of a Euclidean space. The classic counterexample is the set ")#metadata(none) <tao-b002a634647c3350c37b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("E := \\{ (0,y): -1 \\leq y \\leq 1 \\} \\cup \\{ (x, \\sin(1/x)): 0 < x \\leq 1 \\},")]]

#text("which is connected but not path-connected (there is no continuous path from ")#mi("{(0,1)}")#text(" to ")#mi("{(1,\\sin(1))}")#text(").")

#text("Looking at the definitions of the two concepts, one notices a difference: the notion of path-connectedness is somehow a “positive” one, in the sense that a path-connected set can produce the existence of something (a path connecting two points ")#mi("{x}")#text(" and ")#mi("{y}")#text(") for a given type of input (in this case, a pair of points ")#mi("{x, y}")#text("). On the other hand, the notion of connectedness is a “negative” one, in that it asserts the ")#emph[#text("non-existence")]#text(" of something (a non-trivial partition into clopen sets). To put it another way, it is relative easy to convince someone that a set is path-connected (by providing a connecting path for every pair of points) or is disconnected (by providing a non-trivial partition into clopen sets) but if a set is not path-connected, or is connected, how can one easily convince someone of this fact? To put it yet another way: is there a reasonable ")#emph[#text("certificate")]#text(" for connectedness (or for path-disconnectedness)?")

#text("In the case of connectedness for compact subsets ")#mi("{E}")#text(" of Euclidean space, there is an answer as follows. If ")#mi("{\\epsilon > 0}")#text(", let us call two points ")#mi("{x, y}")#text(" in ")#mi("{E}")#text(" ")#emph[#mi("{\\epsilon}")#text("-connected")]#text(" if one can find a finite sequence ")#mi("{x_0 = x, x_1, \\ldots, x_N = y}")#text(" of points in ")#mi("{E}")#text(", such that ")#tao-math("{\\left|x_{i+1}-x_i\\right| < \\epsilon}", block: false)#text(" for all ")#mi("{0 \\leq i < N}")#text("; informally, one can jump from ")#mi("{x}")#text(" to ")#mi("{y}")#text(" in ")#mi("{E}")#text(" using jumps of length at most ")#mi("{\\epsilon}")#text(". Let us call ")#mi("{x_0,\\ldots,x_N}")#text(" an ")#emph[#mi("{\\epsilon}")#text("-discrete path")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Connectedness certificate for compact subsets of Euclidean space)")]#text(" ")#metadata(none) <tao-ac19388a1bf88a2732b3>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be compact and non-empty. Then ")#mi("{E}")#text(" is connected if and only if every pair of points in ")#mi("{E}")#text(" is ")#mi("{\\epsilon}")#text("-connected for every ")#mi("{\\epsilon > 0}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose first that ")#mi("{E}")#text(" is disconnected, then ")#mi("{E}")#text(" can be partitioned into two non-empty closed subsets ")#mi("{F, G}")#text(". Since ")#mi("{E}")#text(" is compact, ")#mi("{F, G}")#text(" are compact also, and so they are separated by some non-zero distance ")#mi("{\\epsilon > 0}")#text(". But then it is clear that points in ")#mi("{F}")#text(" cannot be ")#mi("{\\epsilon}")#text("-connected to points in ")#mi("{G}")#text(", and the claim follows.")

#text("Conversely, suppose that there is a pair of points ")#mi("{x,y}")#text(" in ")#mi("{E}")#text(" and an ")#mi("{\\epsilon > 0}")#text(" such that ")#mi("{x,y}")#text(" are not ")#mi("{\\epsilon}")#text("-connected. Let ")#mi("{F}")#text(" be the set of all points in ")#mi("{E}")#text(" that are ")#mi("{\\epsilon}")#text("-connected to ")#mi("{x}")#text(". It is easy to check that ")#mi("{F}")#text(" is open, closed, and a proper subset of ")#mi("{E}")#text("; thus ")#mi("{E}")#text(" is disconnected. ")#mi("\\Box")

#text("We remark that the above proposition in fact works for any compact metric space. It is instructive to see how the points ")#mi("{(1,\\sin(1))}")#text(" and ")#mi("{(0,1)}")#text(" are ")#mi("{\\epsilon}")#text("-connected in the set ")#link(<tao-b002a634647c3350c37b>)[#text("(1)")]#text("; the ")#mi("{\\epsilon}")#text("-discrete path follows the graph of ")#mi("{\\sin(1/x)}")#text(" backwards until one gets sufficiently close to the ")#mi("{y}")#text("-axis, at which point one “jumps” across to the ")#mi("{y}")#text("-axis to eventually reach ")#mi("{(0,1)}")#text(".")

#text("It is also interesting to contrast the above proposition with path connectedness. Clearly, if two points ")#mi("{x, y}")#text(" are connected by a path, then they are ")#mi("{\\epsilon}")#text("-connected for every ")#mi("{\\epsilon > 0}")#text(" (because every continuous map ")#mi("{\\gamma: [0,1] \\rightarrow E}")#text(" is uniformly continuous); but from the analysis of the example ")#link(<tao-b002a634647c3350c37b>)[#text("(1)")]#text(" we see that the converse is not true. Roughly speaking, the various ")#mi("{\\epsilon}")#text("-discrete paths from ")#mi("{x}")#text(" to ")#mi("{y}")#text(" have to be “compatible” with each other in some sense in order to synthesise a continuous path from ")#mi("{x}")#text(" to ")#mi("{y}")#text(" in the limit (we will not make this precise here).")

#text("But this leaves two (somewhat imprecise) questions, which I do not know how to satisfactorily answer:")

#strong[#text("Question 1:")]#text(" Is there a good certificate for path disconnectedness, say for compact subsets ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^d}")#text("? One can construct lousy certificates, for instance one could look at all continuous paths in ")#mi("{{\\bf R}^d}")#text(" joining two particular points ")#mi("{x, y}")#text(" in ")#mi("{E}")#text(", and verify that each one of them leaves ")#mi("{E}")#text(" at some point. But this is an “uncountable” certificate – it requires one to check an uncountable number of paths. In contrast, the certificate in Proposition ")#link(<tao-ac19388a1bf88a2732b3>)[#text("1")]#text(" is basically a countable one (if one describes a compact set ")#mi("{E}")#text(" by describing a family of ")#mi("{\\epsilon}")#text("-nets for a countable sequence of ")#mi("{\\epsilon}")#text(" tending to zero). (Very roughly speaking, I would like a certificate that can somehow be “verified in countable time” in a suitable oracle model, as discussed in my ")#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/")[#text("previous post")]#text(", though I have not tried to make this vague specification more rigorous.)")

#text("It is tempting to look at the equivalence classes of ")#mi("{E}")#text(" given by the relation of being connected by a path, but these classes need not be closed (as one can see with the example ")#link(<tao-b002a634647c3350c37b>)[#text("(1)")]#text(") and it is not obvious to me how to certify that two such classes are not path-connected to each other.")

#strong[#text("Question 2:")]#text(" Is there a good certificate for connectedness for closed but ")#emph[#text("unbounded")]#text(" closed subsets of ")#mi("{{\\bf R}^d}")#text("? Proposition ")#link(<tao-ac19388a1bf88a2732b3>)[#text("1")]#text(" fails in this case; consider for instance the set ")#metadata(none) <tao-3e64cc41cf8e07b43936>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("E := \\{ (x,0): x \\in {\\bf R} \\} \\cup \\{ (x,\\frac{1}{x}): x > 0 \\}.")]]

#text("Any pair of points ")#mi("{x,y \\in E}")#text(" is ")#mi("{\\epsilon}")#text("-connected for every ")#mi("{\\epsilon > 0}")#text(", and yet this set is disconnected.")

#text("The problem here is that as ")#mi("{\\epsilon}")#text(" gets smaller, the ")#mi("{\\epsilon}")#text("-discrete paths connecting a pair of points such as ")#mi("{(1,0)}")#text(" and ")#mi("{(1,1)}")#text(" have diameter going to infinity. One natural guess is then to require a uniform bound on the diameter, i.e. that for any pair of points ")#mi("{x, y}")#text(", there exists an ")#mi("{R>0}")#text(" such that there is an ")#mi("{\\epsilon}")#text("-discrete path from ")#mi("{x}")#text(" to ")#mi("{y}")#text(" of diameter at most ")#mi("{R}")#text(" for every ")#mi("{\\epsilon > 0}")#text(". This does indeed force connectedness, but unfortunately not all connected sets have this property. Consider for instance the set ")#metadata(none) <tao-c613c7687a303c38a020>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("E := \\{ (x,y,0): x \\in {\\bf R}, y \\in \\pm 1 \\} \\cup \\bigcup_{n=1}^\\infty (E_n \\cup F_n)")]]

#text("in ")#mi("{{\\bf R}^3}")#text(", where")

#align(center)[#tao-fit-display[#mitex("E_n := \\{ (x,y,0): \\frac{x^2}{n^2} + \\frac{y^2}{(1-1/n)^2} = 1\\}")]]

#text("is a rectangular ellipse centered at the origin with minor diameter endpoints ")#mi("{(0,1/n-1), (0,1-1/n)}")#text(" and major diameter endpoints ")#mi("{(-n,0), (n,0)}")#text(", and")

#align(center)[#tao-fit-display[#mitex("F_n := \\{ (n,y,z): (y-1/2)^2+z^2=1/4 \\}")]]

#text("is a circle that connects the ")#mi("{(n,0)}")#text(" endpoint of ")#mi("{E_n}")#text(" to the point ")#mi("{(n,1)}")#text(" in ")#mi("{E}")#text(". One can check that ")#mi("{E}")#text(" is a closed connected set, but the ")#mi("{\\epsilon}")#text("-discrete paths connecting ")#mi("{(0,-1)}")#text(" with ")#mi("{(0,+1)}")#text(" have unbounded diameter as ")#mi("{\\epsilon \\rightarrow 0}")#text(".")

#text("Currently, I do not have any real progress on Question 1. For Question 2, I can only obtain the following strange “second-order” criterion for connectedness, that involves an unspecified gauge function ")#mi("{\\delta}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Second-order connectedness certificate)")]#text(" Let ")#mi("{E}")#text(" be a closed non-empty subset of ")#mi("{{\\bf R}^d}")#text(". Then the following are equivalent:")

#list(
[#mi("{E}")#text(" is connected.")],
[#text("For every monotone decreasing, strictly positive function ")#mi("{\\delta: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" and every ")#mi("{x,y \\in E}")#text(", there exists a discrete path ")#mi("{x_0=x,x_1,\\ldots,x_N=y}")#text(" in ")#mi("{E}")#text(" such that ")#tao-math("{\\left|x_{i+1}-x_i\\right| < \\delta(\\left|x_i\\right|)}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" This is proven in almost the same way as Proposition ")#link(<tao-ac19388a1bf88a2732b3>)[#text("1")]#text(". If ")#mi("{E}")#text(" can be disconnected into two non-trivial sets ")#mi("{F, G}")#text(", then one can find a monotone decreasing gauge function ")#mi("{\\delta: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" such that for each ball ")#tao-math("{B_R := \\{ x \\in {\\bf R}^d: \\left|x\\right| \\leq R \\}}", block: false)#text(", ")#mi("{F \\cap B_R}")#text(" and ")#mi("{G}")#text(" are separated by at least ")#mi("{\\delta(R)}")#text(", and then there is no discrete path from ")#mi("{F}")#text(" to ")#mi("{G}")#text(" in ")#mi("{E}")#text(" obeying the condition ")#tao-math("{\\left|x_{i+1}-x_i\\right| < \\delta(\\left|x_i\\right|)}", block: false)#text(".")

#text("Conversely, if there exists a gauge function ")#mi("{\\delta}")#text(" and two points ")#mi("{x,y \\in E}")#text(" which cannot be connected by a discrete path in ")#mi("{E}")#text(" that obeys the condition ")#tao-math("{\\left|x_{i+1}-x_i\\right| < \\delta(\\left|x_i\\right|)}", block: false)#text(", then if one sets ")#mi("{F}")#text(" to be all the points that can be reached from ")#mi("{x}")#text(" in this manner, one easily verifies that ")#mi("{F}")#text(" and ")#mi("{E \\backslash F}")#text(" disconnect ")#mi("{E}")#text(". ")#mi("\\Box")

#text("It may be that this is somehow the “best” one can do, but I am not sure how to quantify this formally.")

#text("Anyway, I was curious if any of the readers here (particularly those with expertise in point-set topology or descriptive set theory) might be able to shed more light on these questions. (I also considered crossposting this to ")#link("http://mathoverflow.net/")[#text("Math Overflow")]#text(", but I think the question may be a bit too long (and vague) for that.)")

#text("(The original motivation for this question, by the way, stems from an attempt to use methods of topological group theory to attack questions in additive combinatorics, in the spirit of the ")#link("http://arxiv.org/abs/0909.2190")[#text("paper of Hrushovski")]#text(" ")#link("https://terrytao.wordpress.com/category/teaching/logic-reading-seminar/")[#text("studied previously on this blog")]#text(". The connection is rather indirect, though; I may discuss this more in a future post.)")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44199")[#strong[#text("mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2010")])]

#text("I think you mean (0, 1/n-1) instead of (1-1/n,0) in the description of E_n, right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae3ad285561e2495f728b204973c57aaf2e9876a1a399e3b43328a2091dd533f-8bfbc0315efe0024108996e78d05b92b5ada19ca25244fe05bf3a37c083aef03.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of noamnisan")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44208")[#strong[#text("noamnisan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("In Q1 are you really looking for a certificate for non-path-connectedness (as stated) or for path-connectedness (in analogy to the certificate for connectedness)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("Well, I had thought that the definition of path-connectedness already supplied a countable certificate, but on closer reflection I realise that this is not the case (given a path oracle, one can verify in countable time that it will demonstrate path connectedness between two given points, but I don’t know how to search the path space, and also one has to deal with an uncountable number of pairs of points x,y. Todor’s answer suggests in fact that no such certificate exists either for path connectedness or path disconnectedness, which would be a satisfactory answer to Q1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44209")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("Dear Prof. Tao,")

#text("I don’t quite understand the first sentence of Question 2, for a subset of ")#mi("\\mathbf{R}^d")#text(" is compact if and only if it’s closed and bounded (Heine-Borel theorem).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44213")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("Oops! I meant to say “unbounded closed” rather than “unbounded compact”, of course.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/791816348090489ef99b0bae96a98cc12de842970bbda390817c6c860bc78513-96f5eaf66353cf5f00294af4a0bc0470b159bf00a0480be7969026925a603036.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todor Tsankov")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44210")[#strong[#text("Todor Tsankov")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("One possible way to formalize your questions is to ask for the descriptive complexity of the set of connected (resp. path-connected) compact subsets of ")#mi("\\mathbf{R}^d")#text(" in the space of all compact subsets (with the Vietoris topology). Then the existence of a certificate of the kind you are asking for would correspond to that set being analytic (a projection of a Borel set).")

#text("It is easy to see that the condition of being connected is closed (so it is very simple in descriptive set theoretic terms), while it is a theorem of Ajtai and Becker that being path-connected is ")#mi("\\Pi^1_2")#text("-complete (see Kechris, Classical descriptive set theory, 37.11) at least if ")#mi("d \\geq 3")#text(" (so it is very complicated). I believe something similar has been proved in dimension 2 but it is more difficult to trace in the literature. This means that the simplest (in terms of number of changing quantifiers) possible way to say that a set is path-connected is the obvious one: for every pair of points there exists a path between them. In particular, there isn’t a certificate neither for path-connectedness nor for path-disconnectedness, at least if you require that the certificate can be represented as a point in a Polish space and checking it be Borel.")

#text("As for the equivalence relation of being in the same path-component, there is an interesting jump in complexity from dimension 2 to 3. See the paper MR1678350 (MathSciNet) by Becker for details.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44215")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("Thanks! I think this settles Q1 pretty conclusively. The assertion that connectedness is a closed condition for compact sets seems quite consistent with Proposition 1. For Q2, I mistakenly wrote “compact” when I should have written “closed”. I think the topology of all closed sets is much worse than that of all compact sets (in particular, it will not be separable in most reasonable topologies), so the descriptive set theory classification might not be enough.")

#text("I had a vague idea of trying to describe connectedness for unbounded sets in terms of some sort of generalised path connectedness involving something like the long line rather than the unit interval, but it looks messy (I guess ordinals are not sufficient to describe all the possible one-dimensional connected sets out there).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/791816348090489ef99b0bae96a98cc12de842970bbda390817c6c860bc78513-96f5eaf66353cf5f00294af4a0bc0470b159bf00a0480be7969026925a603036.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todor Tsankov")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44219")[#strong[#text("Todor Tsankov")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("To put the second question in the same framework, one can consider the sphere instead of ")#mi("\\mathbf{R}^d")#text(". Then the question becomes: is the set of compact subsets ")#mi("K")#text(" of ")#mi("S^d")#text(" such that ")#mi("K \\setminus \\{x_0\\}")#text(" is connected Borel? (Here ")#mi("x_0 \\in S^d")#text(" is the point at infinity.) Since the set is obviously co-analytic (for all pairs of non-intersecting open subsets of the sphere… etc.; this can also be seen from your Proposition 2), being Borel is equivalent to being analytic (that is, the existence of certification system). I have no idea what the answer is but at least it is a concrete question..")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44211")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("I did some research (however it has white spots that is open problems) of connectedness for funcoids, a generalization of proximites, pretopologies, and preclosures, and reloids, a generalization of uniformities.")

#link("http://www.mathematics21.org/binaries/funcoids-reloids.pdf")[#text("Click to access funcoids-reloids.pdf")]

#link("http://www.mathematics21.org/algebraic-general-topology.html")[#text("http://www.mathematics21.org/algebraic-general-topology.html")]

#text("If you are serious about researching connectedness, you should read my drafts. (However I in no way touch the issue of path-connectedness.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-46508")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2010")])]

#text("See ")#link("http://www.mathematics21.org/binaries/connectedness.pdf")[#text("http://www.mathematics21.org/binaries/connectedness.pdf")]#text(" for my preprint of an article about generalized connectedness of sets. This generalizes topological connectedness, digraph connectedness, proximal connectedness (aka equiconnectedness), uniform connectedness, etc.")

#text("I will also dive deeper in my research into connectedness of filters.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390f81bc403abbaa8705d528326b2523fa57d0b8d96a8625fdf3137195984de9-d72493108d6c1d94a82de1fb4c8ac5733837bfe3934e27530cdeee359b8b1909.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolaennio")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44230")[#strong[#text("nicolaennio")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2010")])]

#text("In the discrete setting you can count the number of a graph connected components as the number of eigenvalues of the graph laplacian operator that are equal to zero. Thus to test if a subset of the graph is disconnected you can build the related eigenvector and plug it into the laplacian definition. I do not know if this can be of help for Q2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44235")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2010")])]

#text("Regarding connected sets with a uniform bound on the diameter of their epsilon-connectedness, your example that you can have a connected set without such a bound requires 3 dimensions. Is there any way to do this with a subset of R^2? (Obviously this can’t be done in R^1(.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a820b0b724de6d13b4c887e4ef81d1a49c9ca5dd9daa7b446978665a6d9b4b1d-0edda1015c8c2ad3e948b28ea8121e7221e89c2f79ec8df82a22d8a5907b56fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 777")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44277")[#strong[#text("777")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2010")])]

#text("I think for that we can just consider the set ")#mi("\\{(0, y) | y \\in \\mathbb{R} \\} \\cup \\{ (x, 1/x \\sin(1/x) | x \\in (0, 1/ \\pi] \\}")#text(". To connect the points ")#mi("{(0,0)}")#text(" and ")#mi("{(1, 0)}")#text(", the ")#mi("\\epsilon")#text("-chain has to have unbounded diameter as ")#mi("{\\epsilon \\to 0}")#text(".")

#text("If this is true (and so far * I * don’t see what fails) Does this give a simpler example for a connected set with unbounded diameter for ")#mi("\\epsilon")#text("-chains connecting two points (and is in ")#mi("\\mathbb{R}^2")#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44278")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2010")])]

#text("That looks like it works to me.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a820b0b724de6d13b4c887e4ef81d1a49c9ca5dd9daa7b446978665a6d9b4b1d-0edda1015c8c2ad3e948b28ea8121e7221e89c2f79ec8df82a22d8a5907b56fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 777")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44282")[#strong[#text("777")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2010")])]

#text("For question 2, we can invert the closed set ")#mi("C")#text(" about any ball in the complement and get a bounded set ")#mi("C^{\\prime}")#text(". (I think Todor Tsankov has already mentioned this above)")

#text("Let ")#mi("p")#text(" be the center of the ball (i.e. image of infinity). ")#mi("C")#text(" being unbounded means infinity is in the closure of ")#mi("C^{\\prime}")#text(" and ")#mi("C^{\\prime} \\cup \\{ p \\}")#text(" compact.")

#text("If ")#mi("C^{\\prime} \\cup \\{ p \\}")#text(" is not connected (by the ")#mi("\\epsilon")#text("-chain test then ")#mi("C")#text(" is also not connected and we are done.")

#text("In continuum theory, ")#mi("p")#text(" is called a ")#strong[#text("cut point")]#text(" of a compact connected set ")#mi("K")#text(" if ")#mi("K \\backslash \\{ p\\}")#text(" is not connected. So the problem is same as giving a countable certificate for determining a given point in a continuum is a non-cut point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f52c0767d308833ee92e2ee660525fe1a3442ae66c08a4ddb51db093f70075c4-58f4f22132558fdffed9585f81b0a4a0cf77aa8c73d42fa701723fef768c39ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Muscat")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44338")[#strong[#text("Joseph Muscat")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("The emphasis above has been on boundedness not completeness. But the latter is crucial for Prop. 1 to work. For example, the Cantor teepee, which is not complete, satisfies the epsilon-connectedness criterion, whether it contains its dispersion point or not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0308f28d06bc1c532868af0f362c77bf2f4a8f96a27fd6ae5530f62fc90752f4-8cc8ef29ec8af0a05c64a6d4c12233ea24d15f7254063597141191166db8cb2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob Brown")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44381")[#strong[#text("Bob Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2010")])]

#text("There seems to be a problem with the proof of Proposition 1. Let E be the 1/n sequence union 0, let x = 0 and y = 1, then F = {0} which is not open in E.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44383")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2010")])]

#text("Dear Bob,")

#text("Hmm, I’m afraid I don’t see the problem (I assume you are referring to the second part of the proof). If ")#mi("\\epsilon > 0")#text(", then the set of points in E that can be ")#mi("\\epsilon")#text("-connected to 0 is just the intersection of E with ")#mi("[0,\\epsilon]")#text(", which is both open and closed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0308f28d06bc1c532868af0f362c77bf2f4a8f96a27fd6ae5530f62fc90752f4-8cc8ef29ec8af0a05c64a6d4c12233ea24d15f7254063597141191166db8cb2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob Brown")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-44403")[#strong[#text("Bob Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2010")])]

#text("Dear Terry,")

#text("Whoops – sorry about that. Well, now that I *do* understand your nice proposition, I’ll show it to my Introduction to Topology class when we get to the section on connectedness. Many thanks for a nice topic.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2010/04/13/is-there-a-countable-certificate-for-connectedness/#comment-470042")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2016")])]

#text("These notions of topology assume you have infinite resources to verify. If we thicken a space-filling curve, the interior is connected. But how long does it take to draw locate a path from one point to another. If you are a dog and the mailman is the maze somewhere, how long does it take before you can bite his leg?")

#text("Even more severely, let the space-filling curve itself be the boundary (which is not even closed) and I am sure the dog will find the mailman.")
]
